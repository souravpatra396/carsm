<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-18 09:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:50:13 --> Config Class Initialized
INFO - 2020-09-18 09:50:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:50:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:50:13 --> Utf8 Class Initialized
INFO - 2020-09-18 09:50:13 --> URI Class Initialized
DEBUG - 2020-09-18 09:50:13 --> No URI present. Default controller set.
INFO - 2020-09-18 09:50:13 --> Router Class Initialized
INFO - 2020-09-18 09:50:13 --> Output Class Initialized
INFO - 2020-09-18 09:50:13 --> Security Class Initialized
DEBUG - 2020-09-18 09:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:50:13 --> Input Class Initialized
INFO - 2020-09-18 09:50:13 --> Language Class Initialized
INFO - 2020-09-18 09:50:13 --> Loader Class Initialized
INFO - 2020-09-18 09:50:13 --> Helper loaded: url_helper
INFO - 2020-09-18 09:50:13 --> Database Driver Class Initialized
INFO - 2020-09-18 09:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:50:13 --> Email Class Initialized
INFO - 2020-09-18 09:50:13 --> Controller Class Initialized
INFO - 2020-09-18 09:50:13 --> Model Class Initialized
INFO - 2020-09-18 09:50:13 --> Model Class Initialized
DEBUG - 2020-09-18 09:50:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:50:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:50:13 --> Final output sent to browser
DEBUG - 2020-09-18 09:50:13 --> Total execution time: 0.1739
ERROR - 2020-09-18 09:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:50:27 --> Config Class Initialized
INFO - 2020-09-18 09:50:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:50:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:50:27 --> Utf8 Class Initialized
INFO - 2020-09-18 09:50:27 --> URI Class Initialized
DEBUG - 2020-09-18 09:50:27 --> No URI present. Default controller set.
INFO - 2020-09-18 09:50:27 --> Router Class Initialized
INFO - 2020-09-18 09:50:27 --> Output Class Initialized
INFO - 2020-09-18 09:50:27 --> Security Class Initialized
DEBUG - 2020-09-18 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:50:27 --> Input Class Initialized
INFO - 2020-09-18 09:50:27 --> Language Class Initialized
INFO - 2020-09-18 09:50:27 --> Loader Class Initialized
INFO - 2020-09-18 09:50:27 --> Helper loaded: url_helper
INFO - 2020-09-18 09:50:27 --> Database Driver Class Initialized
INFO - 2020-09-18 09:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:50:27 --> Email Class Initialized
INFO - 2020-09-18 09:50:27 --> Controller Class Initialized
INFO - 2020-09-18 09:50:27 --> Model Class Initialized
INFO - 2020-09-18 09:50:27 --> Model Class Initialized
DEBUG - 2020-09-18 09:50:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:50:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:50:27 --> Final output sent to browser
DEBUG - 2020-09-18 09:50:27 --> Total execution time: 0.0198
ERROR - 2020-09-18 09:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:50:36 --> Config Class Initialized
INFO - 2020-09-18 09:50:36 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:50:36 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:50:36 --> Utf8 Class Initialized
INFO - 2020-09-18 09:50:36 --> URI Class Initialized
DEBUG - 2020-09-18 09:50:36 --> No URI present. Default controller set.
INFO - 2020-09-18 09:50:36 --> Router Class Initialized
INFO - 2020-09-18 09:50:36 --> Output Class Initialized
INFO - 2020-09-18 09:50:36 --> Security Class Initialized
DEBUG - 2020-09-18 09:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:50:36 --> Input Class Initialized
INFO - 2020-09-18 09:50:36 --> Language Class Initialized
INFO - 2020-09-18 09:50:36 --> Loader Class Initialized
INFO - 2020-09-18 09:50:36 --> Helper loaded: url_helper
INFO - 2020-09-18 09:50:36 --> Database Driver Class Initialized
INFO - 2020-09-18 09:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:50:36 --> Email Class Initialized
INFO - 2020-09-18 09:50:36 --> Controller Class Initialized
INFO - 2020-09-18 09:50:36 --> Model Class Initialized
INFO - 2020-09-18 09:50:36 --> Model Class Initialized
DEBUG - 2020-09-18 09:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:50:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:50:36 --> Final output sent to browser
DEBUG - 2020-09-18 09:50:36 --> Total execution time: 0.0227
ERROR - 2020-09-18 09:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:50:50 --> Config Class Initialized
INFO - 2020-09-18 09:50:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:50:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:50:50 --> Utf8 Class Initialized
INFO - 2020-09-18 09:50:50 --> URI Class Initialized
DEBUG - 2020-09-18 09:50:50 --> No URI present. Default controller set.
INFO - 2020-09-18 09:50:50 --> Router Class Initialized
INFO - 2020-09-18 09:50:50 --> Output Class Initialized
INFO - 2020-09-18 09:50:50 --> Security Class Initialized
DEBUG - 2020-09-18 09:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:50:50 --> Input Class Initialized
INFO - 2020-09-18 09:50:50 --> Language Class Initialized
INFO - 2020-09-18 09:50:50 --> Loader Class Initialized
INFO - 2020-09-18 09:50:50 --> Helper loaded: url_helper
INFO - 2020-09-18 09:50:50 --> Database Driver Class Initialized
INFO - 2020-09-18 09:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:50:50 --> Email Class Initialized
INFO - 2020-09-18 09:50:50 --> Controller Class Initialized
INFO - 2020-09-18 09:50:50 --> Model Class Initialized
INFO - 2020-09-18 09:50:50 --> Model Class Initialized
DEBUG - 2020-09-18 09:50:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:50:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:50:50 --> Final output sent to browser
DEBUG - 2020-09-18 09:50:50 --> Total execution time: 0.0216
ERROR - 2020-09-18 09:51:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:51:27 --> Config Class Initialized
INFO - 2020-09-18 09:51:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:51:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:51:27 --> Utf8 Class Initialized
INFO - 2020-09-18 09:51:27 --> URI Class Initialized
DEBUG - 2020-09-18 09:51:27 --> No URI present. Default controller set.
INFO - 2020-09-18 09:51:27 --> Router Class Initialized
INFO - 2020-09-18 09:51:27 --> Output Class Initialized
INFO - 2020-09-18 09:51:27 --> Security Class Initialized
DEBUG - 2020-09-18 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:51:27 --> Input Class Initialized
INFO - 2020-09-18 09:51:27 --> Language Class Initialized
INFO - 2020-09-18 09:51:27 --> Loader Class Initialized
INFO - 2020-09-18 09:51:27 --> Helper loaded: url_helper
INFO - 2020-09-18 09:51:27 --> Database Driver Class Initialized
INFO - 2020-09-18 09:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:51:27 --> Email Class Initialized
INFO - 2020-09-18 09:51:27 --> Controller Class Initialized
INFO - 2020-09-18 09:51:27 --> Model Class Initialized
INFO - 2020-09-18 09:51:27 --> Model Class Initialized
DEBUG - 2020-09-18 09:51:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:51:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:51:27 --> Final output sent to browser
DEBUG - 2020-09-18 09:51:27 --> Total execution time: 0.0199
ERROR - 2020-09-18 09:51:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:51:32 --> Config Class Initialized
INFO - 2020-09-18 09:51:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:51:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:51:32 --> Utf8 Class Initialized
INFO - 2020-09-18 09:51:32 --> URI Class Initialized
DEBUG - 2020-09-18 09:51:32 --> No URI present. Default controller set.
INFO - 2020-09-18 09:51:32 --> Router Class Initialized
INFO - 2020-09-18 09:51:32 --> Output Class Initialized
INFO - 2020-09-18 09:51:32 --> Security Class Initialized
DEBUG - 2020-09-18 09:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:51:32 --> Input Class Initialized
INFO - 2020-09-18 09:51:32 --> Language Class Initialized
INFO - 2020-09-18 09:51:32 --> Loader Class Initialized
INFO - 2020-09-18 09:51:32 --> Helper loaded: url_helper
INFO - 2020-09-18 09:51:32 --> Database Driver Class Initialized
INFO - 2020-09-18 09:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:51:32 --> Email Class Initialized
INFO - 2020-09-18 09:51:32 --> Controller Class Initialized
INFO - 2020-09-18 09:51:32 --> Model Class Initialized
INFO - 2020-09-18 09:51:32 --> Model Class Initialized
DEBUG - 2020-09-18 09:51:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:51:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:51:32 --> Final output sent to browser
DEBUG - 2020-09-18 09:51:32 --> Total execution time: 0.0230
ERROR - 2020-09-18 09:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:53:04 --> Config Class Initialized
INFO - 2020-09-18 09:53:04 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:53:04 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:53:04 --> Utf8 Class Initialized
INFO - 2020-09-18 09:53:04 --> URI Class Initialized
DEBUG - 2020-09-18 09:53:04 --> No URI present. Default controller set.
INFO - 2020-09-18 09:53:04 --> Router Class Initialized
INFO - 2020-09-18 09:53:04 --> Output Class Initialized
INFO - 2020-09-18 09:53:04 --> Security Class Initialized
DEBUG - 2020-09-18 09:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:53:04 --> Input Class Initialized
INFO - 2020-09-18 09:53:04 --> Language Class Initialized
INFO - 2020-09-18 09:53:04 --> Loader Class Initialized
INFO - 2020-09-18 09:53:04 --> Helper loaded: url_helper
INFO - 2020-09-18 09:53:04 --> Database Driver Class Initialized
INFO - 2020-09-18 09:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:53:04 --> Email Class Initialized
INFO - 2020-09-18 09:53:04 --> Controller Class Initialized
INFO - 2020-09-18 09:53:04 --> Model Class Initialized
INFO - 2020-09-18 09:53:04 --> Model Class Initialized
DEBUG - 2020-09-18 09:53:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:53:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:53:04 --> Final output sent to browser
DEBUG - 2020-09-18 09:53:04 --> Total execution time: 0.0222
ERROR - 2020-09-18 09:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 09:53:24 --> Config Class Initialized
INFO - 2020-09-18 09:53:24 --> Hooks Class Initialized
DEBUG - 2020-09-18 09:53:24 --> UTF-8 Support Enabled
INFO - 2020-09-18 09:53:24 --> Utf8 Class Initialized
INFO - 2020-09-18 09:53:24 --> URI Class Initialized
DEBUG - 2020-09-18 09:53:24 --> No URI present. Default controller set.
INFO - 2020-09-18 09:53:24 --> Router Class Initialized
INFO - 2020-09-18 09:53:24 --> Output Class Initialized
INFO - 2020-09-18 09:53:24 --> Security Class Initialized
DEBUG - 2020-09-18 09:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 09:53:24 --> Input Class Initialized
INFO - 2020-09-18 09:53:24 --> Language Class Initialized
INFO - 2020-09-18 09:53:24 --> Loader Class Initialized
INFO - 2020-09-18 09:53:24 --> Helper loaded: url_helper
INFO - 2020-09-18 09:53:24 --> Database Driver Class Initialized
INFO - 2020-09-18 09:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 09:53:24 --> Email Class Initialized
INFO - 2020-09-18 09:53:24 --> Controller Class Initialized
INFO - 2020-09-18 09:53:24 --> Model Class Initialized
INFO - 2020-09-18 09:53:24 --> Model Class Initialized
DEBUG - 2020-09-18 09:53:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 09:53:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 09:53:24 --> Final output sent to browser
DEBUG - 2020-09-18 09:53:24 --> Total execution time: 0.0229
ERROR - 2020-09-18 10:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:20:18 --> Config Class Initialized
INFO - 2020-09-18 10:20:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:20:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:20:18 --> Utf8 Class Initialized
INFO - 2020-09-18 10:20:18 --> URI Class Initialized
INFO - 2020-09-18 10:20:18 --> Router Class Initialized
INFO - 2020-09-18 10:20:18 --> Output Class Initialized
INFO - 2020-09-18 10:20:18 --> Security Class Initialized
DEBUG - 2020-09-18 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:20:18 --> Input Class Initialized
INFO - 2020-09-18 10:20:18 --> Language Class Initialized
INFO - 2020-09-18 10:20:18 --> Loader Class Initialized
INFO - 2020-09-18 10:20:18 --> Helper loaded: url_helper
INFO - 2020-09-18 10:20:18 --> Database Driver Class Initialized
ERROR - 2020-09-18 10:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:20:18 --> Config Class Initialized
INFO - 2020-09-18 10:20:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:20:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:20:18 --> Utf8 Class Initialized
INFO - 2020-09-18 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:20:18 --> URI Class Initialized
INFO - 2020-09-18 10:20:18 --> Router Class Initialized
INFO - 2020-09-18 10:20:18 --> Output Class Initialized
INFO - 2020-09-18 10:20:18 --> Email Class Initialized
INFO - 2020-09-18 10:20:18 --> Controller Class Initialized
INFO - 2020-09-18 10:20:18 --> Model Class Initialized
INFO - 2020-09-18 10:20:18 --> Security Class Initialized
INFO - 2020-09-18 10:20:18 --> Model Class Initialized
DEBUG - 2020-09-18 10:20:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:20:18 --> Input Class Initialized
INFO - 2020-09-18 10:20:18 --> Language Class Initialized
INFO - 2020-09-18 10:20:18 --> Loader Class Initialized
INFO - 2020-09-18 10:20:18 --> Helper loaded: url_helper
INFO - 2020-09-18 10:20:18 --> Database Driver Class Initialized
INFO - 2020-09-18 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:20:18 --> Email Class Initialized
INFO - 2020-09-18 10:20:18 --> Controller Class Initialized
INFO - 2020-09-18 10:20:18 --> Model Class Initialized
INFO - 2020-09-18 10:20:18 --> Model Class Initialized
DEBUG - 2020-09-18 10:20:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:20:18 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:20:19 --> Config Class Initialized
INFO - 2020-09-18 10:20:19 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:20:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:20:19 --> Utf8 Class Initialized
INFO - 2020-09-18 10:20:19 --> URI Class Initialized
DEBUG - 2020-09-18 10:20:19 --> No URI present. Default controller set.
INFO - 2020-09-18 10:20:19 --> Router Class Initialized
INFO - 2020-09-18 10:20:19 --> Output Class Initialized
INFO - 2020-09-18 10:20:19 --> Security Class Initialized
DEBUG - 2020-09-18 10:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:20:19 --> Input Class Initialized
ERROR - 2020-09-18 10:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:20:19 --> Language Class Initialized
INFO - 2020-09-18 10:20:19 --> Config Class Initialized
INFO - 2020-09-18 10:20:19 --> Hooks Class Initialized
INFO - 2020-09-18 10:20:19 --> Loader Class Initialized
DEBUG - 2020-09-18 10:20:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:20:19 --> Utf8 Class Initialized
INFO - 2020-09-18 10:20:19 --> Helper loaded: url_helper
INFO - 2020-09-18 10:20:19 --> URI Class Initialized
INFO - 2020-09-18 10:20:19 --> Router Class Initialized
INFO - 2020-09-18 10:20:19 --> Output Class Initialized
INFO - 2020-09-18 10:20:19 --> Security Class Initialized
DEBUG - 2020-09-18 10:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:20:19 --> Input Class Initialized
INFO - 2020-09-18 10:20:19 --> Language Class Initialized
INFO - 2020-09-18 10:20:19 --> Database Driver Class Initialized
INFO - 2020-09-18 10:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:20:19 --> Email Class Initialized
INFO - 2020-09-18 10:20:19 --> Controller Class Initialized
INFO - 2020-09-18 10:20:19 --> Model Class Initialized
INFO - 2020-09-18 10:20:19 --> Model Class Initialized
DEBUG - 2020-09-18 10:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:20:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:20:19 --> Final output sent to browser
DEBUG - 2020-09-18 10:20:19 --> Total execution time: 0.0216
INFO - 2020-09-18 10:20:19 --> Loader Class Initialized
INFO - 2020-09-18 10:20:19 --> Helper loaded: url_helper
INFO - 2020-09-18 10:20:19 --> Database Driver Class Initialized
INFO - 2020-09-18 10:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:20:19 --> Email Class Initialized
INFO - 2020-09-18 10:20:19 --> Controller Class Initialized
DEBUG - 2020-09-18 10:20:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:20:19 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:20:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:20:19 --> Config Class Initialized
INFO - 2020-09-18 10:20:19 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:20:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:20:19 --> Utf8 Class Initialized
INFO - 2020-09-18 10:20:19 --> URI Class Initialized
DEBUG - 2020-09-18 10:20:19 --> No URI present. Default controller set.
INFO - 2020-09-18 10:20:19 --> Router Class Initialized
INFO - 2020-09-18 10:20:19 --> Output Class Initialized
INFO - 2020-09-18 10:20:19 --> Security Class Initialized
DEBUG - 2020-09-18 10:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:20:19 --> Input Class Initialized
INFO - 2020-09-18 10:20:19 --> Language Class Initialized
INFO - 2020-09-18 10:20:19 --> Loader Class Initialized
INFO - 2020-09-18 10:20:19 --> Helper loaded: url_helper
INFO - 2020-09-18 10:20:19 --> Database Driver Class Initialized
INFO - 2020-09-18 10:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:20:19 --> Email Class Initialized
INFO - 2020-09-18 10:20:19 --> Controller Class Initialized
INFO - 2020-09-18 10:20:19 --> Model Class Initialized
INFO - 2020-09-18 10:20:19 --> Model Class Initialized
DEBUG - 2020-09-18 10:20:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:20:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:20:19 --> Final output sent to browser
DEBUG - 2020-09-18 10:20:19 --> Total execution time: 0.0199
ERROR - 2020-09-18 10:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:20:54 --> Config Class Initialized
INFO - 2020-09-18 10:20:54 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:20:54 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:20:54 --> Utf8 Class Initialized
INFO - 2020-09-18 10:20:54 --> URI Class Initialized
DEBUG - 2020-09-18 10:20:54 --> No URI present. Default controller set.
INFO - 2020-09-18 10:20:54 --> Router Class Initialized
INFO - 2020-09-18 10:20:54 --> Output Class Initialized
INFO - 2020-09-18 10:20:54 --> Security Class Initialized
DEBUG - 2020-09-18 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:20:54 --> Input Class Initialized
INFO - 2020-09-18 10:20:54 --> Language Class Initialized
INFO - 2020-09-18 10:20:54 --> Loader Class Initialized
INFO - 2020-09-18 10:20:54 --> Helper loaded: url_helper
INFO - 2020-09-18 10:20:54 --> Database Driver Class Initialized
INFO - 2020-09-18 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:20:54 --> Email Class Initialized
INFO - 2020-09-18 10:20:54 --> Controller Class Initialized
INFO - 2020-09-18 10:20:54 --> Model Class Initialized
INFO - 2020-09-18 10:20:54 --> Model Class Initialized
DEBUG - 2020-09-18 10:20:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:20:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:20:54 --> Final output sent to browser
DEBUG - 2020-09-18 10:20:54 --> Total execution time: 0.0210
ERROR - 2020-09-18 10:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:21:05 --> Config Class Initialized
INFO - 2020-09-18 10:21:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:21:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:21:05 --> Utf8 Class Initialized
INFO - 2020-09-18 10:21:05 --> URI Class Initialized
INFO - 2020-09-18 10:21:05 --> Router Class Initialized
INFO - 2020-09-18 10:21:05 --> Output Class Initialized
INFO - 2020-09-18 10:21:05 --> Security Class Initialized
DEBUG - 2020-09-18 10:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:21:05 --> Input Class Initialized
INFO - 2020-09-18 10:21:05 --> Language Class Initialized
INFO - 2020-09-18 10:21:05 --> Loader Class Initialized
INFO - 2020-09-18 10:21:05 --> Helper loaded: url_helper
INFO - 2020-09-18 10:21:05 --> Database Driver Class Initialized
INFO - 2020-09-18 10:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:21:05 --> Email Class Initialized
INFO - 2020-09-18 10:21:05 --> Controller Class Initialized
INFO - 2020-09-18 10:21:05 --> Model Class Initialized
INFO - 2020-09-18 10:21:05 --> Model Class Initialized
DEBUG - 2020-09-18 10:21:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:21:05 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:21:06 --> Config Class Initialized
INFO - 2020-09-18 10:21:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:21:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:21:06 --> Utf8 Class Initialized
INFO - 2020-09-18 10:21:06 --> URI Class Initialized
INFO - 2020-09-18 10:21:06 --> Router Class Initialized
INFO - 2020-09-18 10:21:06 --> Output Class Initialized
INFO - 2020-09-18 10:21:06 --> Security Class Initialized
DEBUG - 2020-09-18 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:21:06 --> Input Class Initialized
INFO - 2020-09-18 10:21:06 --> Language Class Initialized
INFO - 2020-09-18 10:21:06 --> Loader Class Initialized
INFO - 2020-09-18 10:21:06 --> Helper loaded: url_helper
INFO - 2020-09-18 10:21:06 --> Database Driver Class Initialized
INFO - 2020-09-18 10:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:21:06 --> Email Class Initialized
INFO - 2020-09-18 10:21:06 --> Controller Class Initialized
INFO - 2020-09-18 10:21:06 --> Model Class Initialized
INFO - 2020-09-18 10:21:06 --> Model Class Initialized
DEBUG - 2020-09-18 10:21:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:21:06 --> Config Class Initialized
INFO - 2020-09-18 10:21:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:21:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:21:06 --> Utf8 Class Initialized
INFO - 2020-09-18 10:21:06 --> URI Class Initialized
DEBUG - 2020-09-18 10:21:06 --> No URI present. Default controller set.
INFO - 2020-09-18 10:21:06 --> Router Class Initialized
INFO - 2020-09-18 10:21:06 --> Output Class Initialized
INFO - 2020-09-18 10:21:06 --> Security Class Initialized
DEBUG - 2020-09-18 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:21:06 --> Input Class Initialized
INFO - 2020-09-18 10:21:06 --> Language Class Initialized
INFO - 2020-09-18 10:21:06 --> Loader Class Initialized
INFO - 2020-09-18 10:21:06 --> Helper loaded: url_helper
INFO - 2020-09-18 10:21:06 --> Database Driver Class Initialized
INFO - 2020-09-18 10:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:21:06 --> Email Class Initialized
INFO - 2020-09-18 10:21:06 --> Controller Class Initialized
INFO - 2020-09-18 10:21:06 --> Model Class Initialized
INFO - 2020-09-18 10:21:06 --> Model Class Initialized
DEBUG - 2020-09-18 10:21:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:21:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:21:06 --> Final output sent to browser
DEBUG - 2020-09-18 10:21:06 --> Total execution time: 0.0197
ERROR - 2020-09-18 10:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:21:06 --> Config Class Initialized
INFO - 2020-09-18 10:21:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:21:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:21:06 --> Utf8 Class Initialized
INFO - 2020-09-18 10:21:06 --> URI Class Initialized
INFO - 2020-09-18 10:21:06 --> Router Class Initialized
INFO - 2020-09-18 10:21:06 --> Output Class Initialized
INFO - 2020-09-18 10:21:06 --> Security Class Initialized
DEBUG - 2020-09-18 10:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:21:06 --> Input Class Initialized
INFO - 2020-09-18 10:21:06 --> Language Class Initialized
INFO - 2020-09-18 10:21:06 --> Loader Class Initialized
INFO - 2020-09-18 10:21:06 --> Helper loaded: url_helper
INFO - 2020-09-18 10:21:06 --> Database Driver Class Initialized
INFO - 2020-09-18 10:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:21:06 --> Email Class Initialized
INFO - 2020-09-18 10:21:06 --> Controller Class Initialized
DEBUG - 2020-09-18 10:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:21:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:21:06 --> Model Class Initialized
INFO - 2020-09-18 10:21:06 --> Model Class Initialized
INFO - 2020-09-18 10:21:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:21:06 --> Final output sent to browser
DEBUG - 2020-09-18 10:21:06 --> Total execution time: 0.0426
ERROR - 2020-09-18 10:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:21:47 --> Config Class Initialized
INFO - 2020-09-18 10:21:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:21:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:21:47 --> Utf8 Class Initialized
INFO - 2020-09-18 10:21:47 --> URI Class Initialized
INFO - 2020-09-18 10:21:47 --> Router Class Initialized
INFO - 2020-09-18 10:21:47 --> Output Class Initialized
INFO - 2020-09-18 10:21:47 --> Security Class Initialized
DEBUG - 2020-09-18 10:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:21:47 --> Input Class Initialized
INFO - 2020-09-18 10:21:47 --> Language Class Initialized
INFO - 2020-09-18 10:21:47 --> Loader Class Initialized
INFO - 2020-09-18 10:21:47 --> Helper loaded: url_helper
INFO - 2020-09-18 10:21:47 --> Database Driver Class Initialized
INFO - 2020-09-18 10:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:21:47 --> Email Class Initialized
INFO - 2020-09-18 10:21:47 --> Controller Class Initialized
DEBUG - 2020-09-18 10:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:21:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:21:47 --> Model Class Initialized
INFO - 2020-09-18 10:21:47 --> Model Class Initialized
INFO - 2020-09-18 10:21:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-09-18 10:21:47 --> Final output sent to browser
DEBUG - 2020-09-18 10:21:47 --> Total execution time: 0.0730
ERROR - 2020-09-18 10:22:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:22:16 --> Config Class Initialized
INFO - 2020-09-18 10:22:16 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:22:16 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:22:16 --> Utf8 Class Initialized
INFO - 2020-09-18 10:22:16 --> URI Class Initialized
DEBUG - 2020-09-18 10:22:16 --> No URI present. Default controller set.
INFO - 2020-09-18 10:22:16 --> Router Class Initialized
INFO - 2020-09-18 10:22:16 --> Output Class Initialized
INFO - 2020-09-18 10:22:16 --> Security Class Initialized
DEBUG - 2020-09-18 10:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:22:16 --> Input Class Initialized
INFO - 2020-09-18 10:22:16 --> Language Class Initialized
INFO - 2020-09-18 10:22:16 --> Loader Class Initialized
INFO - 2020-09-18 10:22:16 --> Helper loaded: url_helper
INFO - 2020-09-18 10:22:16 --> Database Driver Class Initialized
INFO - 2020-09-18 10:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:22:16 --> Email Class Initialized
INFO - 2020-09-18 10:22:16 --> Controller Class Initialized
INFO - 2020-09-18 10:22:16 --> Model Class Initialized
INFO - 2020-09-18 10:22:16 --> Model Class Initialized
DEBUG - 2020-09-18 10:22:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:22:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:22:16 --> Final output sent to browser
DEBUG - 2020-09-18 10:22:16 --> Total execution time: 0.0227
ERROR - 2020-09-18 10:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:22:20 --> Config Class Initialized
INFO - 2020-09-18 10:22:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:22:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:22:20 --> Utf8 Class Initialized
INFO - 2020-09-18 10:22:20 --> URI Class Initialized
INFO - 2020-09-18 10:22:20 --> Router Class Initialized
INFO - 2020-09-18 10:22:20 --> Output Class Initialized
INFO - 2020-09-18 10:22:20 --> Security Class Initialized
DEBUG - 2020-09-18 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:22:20 --> Input Class Initialized
INFO - 2020-09-18 10:22:20 --> Language Class Initialized
INFO - 2020-09-18 10:22:20 --> Loader Class Initialized
INFO - 2020-09-18 10:22:20 --> Helper loaded: url_helper
INFO - 2020-09-18 10:22:20 --> Database Driver Class Initialized
INFO - 2020-09-18 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:22:20 --> Email Class Initialized
INFO - 2020-09-18 10:22:20 --> Controller Class Initialized
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
DEBUG - 2020-09-18 10:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:22:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
INFO - 2020-09-18 10:22:20 --> Final output sent to browser
DEBUG - 2020-09-18 10:22:20 --> Total execution time: 0.0256
ERROR - 2020-09-18 10:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:22:20 --> Config Class Initialized
INFO - 2020-09-18 10:22:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:22:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:22:20 --> Utf8 Class Initialized
INFO - 2020-09-18 10:22:20 --> URI Class Initialized
INFO - 2020-09-18 10:22:20 --> Router Class Initialized
INFO - 2020-09-18 10:22:20 --> Output Class Initialized
INFO - 2020-09-18 10:22:20 --> Security Class Initialized
DEBUG - 2020-09-18 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:22:20 --> Input Class Initialized
INFO - 2020-09-18 10:22:20 --> Language Class Initialized
INFO - 2020-09-18 10:22:20 --> Loader Class Initialized
INFO - 2020-09-18 10:22:20 --> Helper loaded: url_helper
INFO - 2020-09-18 10:22:20 --> Database Driver Class Initialized
INFO - 2020-09-18 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:22:20 --> Email Class Initialized
INFO - 2020-09-18 10:22:20 --> Controller Class Initialized
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
DEBUG - 2020-09-18 10:22:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:22:20 --> Config Class Initialized
INFO - 2020-09-18 10:22:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:22:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:22:20 --> Utf8 Class Initialized
INFO - 2020-09-18 10:22:20 --> URI Class Initialized
INFO - 2020-09-18 10:22:20 --> Router Class Initialized
INFO - 2020-09-18 10:22:20 --> Output Class Initialized
INFO - 2020-09-18 10:22:20 --> Security Class Initialized
DEBUG - 2020-09-18 10:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:22:20 --> Input Class Initialized
INFO - 2020-09-18 10:22:20 --> Language Class Initialized
INFO - 2020-09-18 10:22:20 --> Loader Class Initialized
INFO - 2020-09-18 10:22:20 --> Helper loaded: url_helper
INFO - 2020-09-18 10:22:20 --> Database Driver Class Initialized
INFO - 2020-09-18 10:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:22:20 --> Email Class Initialized
INFO - 2020-09-18 10:22:20 --> Controller Class Initialized
DEBUG - 2020-09-18 10:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:22:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
INFO - 2020-09-18 10:22:20 --> Model Class Initialized
INFO - 2020-09-18 10:22:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 10:22:20 --> Final output sent to browser
DEBUG - 2020-09-18 10:22:20 --> Total execution time: 0.0333
ERROR - 2020-09-18 10:22:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:22:24 --> Config Class Initialized
INFO - 2020-09-18 10:22:24 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:22:24 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:22:24 --> Utf8 Class Initialized
INFO - 2020-09-18 10:22:24 --> URI Class Initialized
INFO - 2020-09-18 10:22:24 --> Router Class Initialized
INFO - 2020-09-18 10:22:24 --> Output Class Initialized
INFO - 2020-09-18 10:22:24 --> Security Class Initialized
DEBUG - 2020-09-18 10:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:22:24 --> Input Class Initialized
INFO - 2020-09-18 10:22:24 --> Language Class Initialized
INFO - 2020-09-18 10:22:24 --> Loader Class Initialized
INFO - 2020-09-18 10:22:24 --> Helper loaded: url_helper
INFO - 2020-09-18 10:22:24 --> Database Driver Class Initialized
INFO - 2020-09-18 10:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:22:24 --> Email Class Initialized
INFO - 2020-09-18 10:22:24 --> Controller Class Initialized
DEBUG - 2020-09-18 10:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:22:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:22:24 --> Model Class Initialized
INFO - 2020-09-18 10:22:24 --> Model Class Initialized
INFO - 2020-09-18 10:22:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-09-18 10:22:24 --> Final output sent to browser
DEBUG - 2020-09-18 10:22:24 --> Total execution time: 0.0245
ERROR - 2020-09-18 10:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:22:55 --> Config Class Initialized
INFO - 2020-09-18 10:22:55 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:22:55 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:22:55 --> Utf8 Class Initialized
INFO - 2020-09-18 10:22:55 --> URI Class Initialized
INFO - 2020-09-18 10:22:55 --> Router Class Initialized
INFO - 2020-09-18 10:22:55 --> Output Class Initialized
INFO - 2020-09-18 10:22:55 --> Security Class Initialized
DEBUG - 2020-09-18 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:22:55 --> Input Class Initialized
INFO - 2020-09-18 10:22:55 --> Language Class Initialized
INFO - 2020-09-18 10:22:55 --> Loader Class Initialized
INFO - 2020-09-18 10:22:55 --> Helper loaded: url_helper
INFO - 2020-09-18 10:22:55 --> Database Driver Class Initialized
INFO - 2020-09-18 10:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:22:55 --> Email Class Initialized
INFO - 2020-09-18 10:22:55 --> Controller Class Initialized
DEBUG - 2020-09-18 10:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:22:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:22:55 --> Model Class Initialized
INFO - 2020-09-18 10:22:55 --> Model Class Initialized
INFO - 2020-09-18 10:22:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 10:22:55 --> Final output sent to browser
DEBUG - 2020-09-18 10:22:55 --> Total execution time: 0.0276
ERROR - 2020-09-18 10:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:02 --> Config Class Initialized
INFO - 2020-09-18 10:23:02 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:02 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:02 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:02 --> URI Class Initialized
DEBUG - 2020-09-18 10:23:02 --> No URI present. Default controller set.
INFO - 2020-09-18 10:23:02 --> Router Class Initialized
INFO - 2020-09-18 10:23:02 --> Output Class Initialized
INFO - 2020-09-18 10:23:02 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:02 --> Input Class Initialized
INFO - 2020-09-18 10:23:02 --> Language Class Initialized
INFO - 2020-09-18 10:23:02 --> Loader Class Initialized
INFO - 2020-09-18 10:23:02 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:02 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:02 --> Email Class Initialized
INFO - 2020-09-18 10:23:02 --> Controller Class Initialized
INFO - 2020-09-18 10:23:02 --> Model Class Initialized
INFO - 2020-09-18 10:23:02 --> Model Class Initialized
DEBUG - 2020-09-18 10:23:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:23:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:23:02 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:02 --> Total execution time: 0.0218
ERROR - 2020-09-18 10:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:27 --> Config Class Initialized
INFO - 2020-09-18 10:23:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:27 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:27 --> URI Class Initialized
INFO - 2020-09-18 10:23:27 --> Router Class Initialized
INFO - 2020-09-18 10:23:27 --> Output Class Initialized
INFO - 2020-09-18 10:23:27 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:27 --> Input Class Initialized
INFO - 2020-09-18 10:23:27 --> Language Class Initialized
INFO - 2020-09-18 10:23:27 --> Loader Class Initialized
INFO - 2020-09-18 10:23:27 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:27 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:27 --> Email Class Initialized
INFO - 2020-09-18 10:23:27 --> Controller Class Initialized
INFO - 2020-09-18 10:23:27 --> Model Class Initialized
INFO - 2020-09-18 10:23:27 --> Model Class Initialized
DEBUG - 2020-09-18 10:23:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:23:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:23:27 --> Model Class Initialized
INFO - 2020-09-18 10:23:27 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:27 --> Total execution time: 0.0219
ERROR - 2020-09-18 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:28 --> Config Class Initialized
INFO - 2020-09-18 10:23:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:28 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:28 --> URI Class Initialized
INFO - 2020-09-18 10:23:28 --> Router Class Initialized
INFO - 2020-09-18 10:23:28 --> Output Class Initialized
INFO - 2020-09-18 10:23:28 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:28 --> Input Class Initialized
INFO - 2020-09-18 10:23:28 --> Language Class Initialized
INFO - 2020-09-18 10:23:28 --> Loader Class Initialized
INFO - 2020-09-18 10:23:28 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:28 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:28 --> Email Class Initialized
INFO - 2020-09-18 10:23:28 --> Controller Class Initialized
INFO - 2020-09-18 10:23:28 --> Model Class Initialized
INFO - 2020-09-18 10:23:28 --> Model Class Initialized
DEBUG - 2020-09-18 10:23:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:28 --> Config Class Initialized
INFO - 2020-09-18 10:23:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:28 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:28 --> URI Class Initialized
DEBUG - 2020-09-18 10:23:28 --> No URI present. Default controller set.
INFO - 2020-09-18 10:23:28 --> Router Class Initialized
INFO - 2020-09-18 10:23:28 --> Output Class Initialized
INFO - 2020-09-18 10:23:28 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:28 --> Input Class Initialized
INFO - 2020-09-18 10:23:28 --> Language Class Initialized
INFO - 2020-09-18 10:23:28 --> Loader Class Initialized
INFO - 2020-09-18 10:23:28 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:28 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:28 --> Email Class Initialized
INFO - 2020-09-18 10:23:28 --> Controller Class Initialized
INFO - 2020-09-18 10:23:28 --> Model Class Initialized
INFO - 2020-09-18 10:23:28 --> Model Class Initialized
DEBUG - 2020-09-18 10:23:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:23:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:23:28 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:28 --> Total execution time: 0.0248
ERROR - 2020-09-18 10:23:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:50 --> Config Class Initialized
INFO - 2020-09-18 10:23:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:50 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:50 --> URI Class Initialized
INFO - 2020-09-18 10:23:50 --> Router Class Initialized
INFO - 2020-09-18 10:23:50 --> Output Class Initialized
INFO - 2020-09-18 10:23:50 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:50 --> Input Class Initialized
INFO - 2020-09-18 10:23:50 --> Language Class Initialized
INFO - 2020-09-18 10:23:50 --> Loader Class Initialized
INFO - 2020-09-18 10:23:50 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:50 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:50 --> Email Class Initialized
INFO - 2020-09-18 10:23:50 --> Controller Class Initialized
INFO - 2020-09-18 10:23:50 --> Model Class Initialized
INFO - 2020-09-18 10:23:50 --> Model Class Initialized
DEBUG - 2020-09-18 10:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:23:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:23:50 --> Model Class Initialized
INFO - 2020-09-18 10:23:50 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:50 --> Total execution time: 0.0218
ERROR - 2020-09-18 10:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:51 --> Config Class Initialized
INFO - 2020-09-18 10:23:51 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:51 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:51 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:51 --> URI Class Initialized
INFO - 2020-09-18 10:23:51 --> Router Class Initialized
INFO - 2020-09-18 10:23:51 --> Output Class Initialized
INFO - 2020-09-18 10:23:51 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:51 --> Input Class Initialized
INFO - 2020-09-18 10:23:51 --> Language Class Initialized
INFO - 2020-09-18 10:23:51 --> Loader Class Initialized
INFO - 2020-09-18 10:23:51 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:51 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:51 --> Email Class Initialized
INFO - 2020-09-18 10:23:51 --> Controller Class Initialized
INFO - 2020-09-18 10:23:51 --> Model Class Initialized
INFO - 2020-09-18 10:23:51 --> Model Class Initialized
DEBUG - 2020-09-18 10:23:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:23:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:51 --> Config Class Initialized
INFO - 2020-09-18 10:23:51 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:51 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:51 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:51 --> URI Class Initialized
INFO - 2020-09-18 10:23:51 --> Router Class Initialized
INFO - 2020-09-18 10:23:51 --> Output Class Initialized
INFO - 2020-09-18 10:23:51 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:51 --> Input Class Initialized
INFO - 2020-09-18 10:23:51 --> Language Class Initialized
INFO - 2020-09-18 10:23:51 --> Loader Class Initialized
INFO - 2020-09-18 10:23:51 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:51 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:51 --> Email Class Initialized
INFO - 2020-09-18 10:23:51 --> Controller Class Initialized
DEBUG - 2020-09-18 10:23:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:23:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:23:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-18 10:23:51 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:51 --> Total execution time: 0.0460
ERROR - 2020-09-18 10:23:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:23:58 --> Config Class Initialized
INFO - 2020-09-18 10:23:58 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:23:58 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:23:58 --> Utf8 Class Initialized
INFO - 2020-09-18 10:23:58 --> URI Class Initialized
INFO - 2020-09-18 10:23:58 --> Router Class Initialized
INFO - 2020-09-18 10:23:58 --> Output Class Initialized
INFO - 2020-09-18 10:23:58 --> Security Class Initialized
DEBUG - 2020-09-18 10:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:23:58 --> Input Class Initialized
INFO - 2020-09-18 10:23:58 --> Language Class Initialized
INFO - 2020-09-18 10:23:58 --> Loader Class Initialized
INFO - 2020-09-18 10:23:58 --> Helper loaded: url_helper
INFO - 2020-09-18 10:23:58 --> Database Driver Class Initialized
INFO - 2020-09-18 10:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:23:58 --> Email Class Initialized
INFO - 2020-09-18 10:23:58 --> Controller Class Initialized
DEBUG - 2020-09-18 10:23:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:23:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:23:58 --> Model Class Initialized
INFO - 2020-09-18 10:23:58 --> Model Class Initialized
INFO - 2020-09-18 10:23:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-09-18 10:23:58 --> Final output sent to browser
DEBUG - 2020-09-18 10:23:58 --> Total execution time: 0.0252
ERROR - 2020-09-18 10:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:28:38 --> Config Class Initialized
INFO - 2020-09-18 10:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:28:38 --> Utf8 Class Initialized
INFO - 2020-09-18 10:28:38 --> URI Class Initialized
DEBUG - 2020-09-18 10:28:38 --> No URI present. Default controller set.
INFO - 2020-09-18 10:28:38 --> Router Class Initialized
INFO - 2020-09-18 10:28:38 --> Output Class Initialized
INFO - 2020-09-18 10:28:38 --> Security Class Initialized
DEBUG - 2020-09-18 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:28:38 --> Input Class Initialized
INFO - 2020-09-18 10:28:38 --> Language Class Initialized
INFO - 2020-09-18 10:28:38 --> Loader Class Initialized
INFO - 2020-09-18 10:28:38 --> Helper loaded: url_helper
INFO - 2020-09-18 10:28:38 --> Database Driver Class Initialized
INFO - 2020-09-18 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:28:38 --> Email Class Initialized
INFO - 2020-09-18 10:28:38 --> Controller Class Initialized
INFO - 2020-09-18 10:28:38 --> Model Class Initialized
INFO - 2020-09-18 10:28:38 --> Model Class Initialized
DEBUG - 2020-09-18 10:28:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:28:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:28:38 --> Final output sent to browser
DEBUG - 2020-09-18 10:28:38 --> Total execution time: 0.0206
ERROR - 2020-09-18 10:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:29:50 --> Config Class Initialized
INFO - 2020-09-18 10:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:29:50 --> Utf8 Class Initialized
INFO - 2020-09-18 10:29:50 --> URI Class Initialized
INFO - 2020-09-18 10:29:50 --> Router Class Initialized
INFO - 2020-09-18 10:29:50 --> Output Class Initialized
INFO - 2020-09-18 10:29:50 --> Security Class Initialized
DEBUG - 2020-09-18 10:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:29:50 --> Input Class Initialized
INFO - 2020-09-18 10:29:50 --> Language Class Initialized
INFO - 2020-09-18 10:29:50 --> Loader Class Initialized
INFO - 2020-09-18 10:29:50 --> Helper loaded: url_helper
INFO - 2020-09-18 10:29:50 --> Database Driver Class Initialized
INFO - 2020-09-18 10:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:29:50 --> Email Class Initialized
INFO - 2020-09-18 10:29:50 --> Controller Class Initialized
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
DEBUG - 2020-09-18 10:29:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:29:50 --> Config Class Initialized
INFO - 2020-09-18 10:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:29:50 --> Utf8 Class Initialized
INFO - 2020-09-18 10:29:50 --> URI Class Initialized
INFO - 2020-09-18 10:29:50 --> Router Class Initialized
INFO - 2020-09-18 10:29:50 --> Output Class Initialized
INFO - 2020-09-18 10:29:50 --> Security Class Initialized
DEBUG - 2020-09-18 10:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:29:50 --> Input Class Initialized
INFO - 2020-09-18 10:29:50 --> Language Class Initialized
INFO - 2020-09-18 10:29:50 --> Loader Class Initialized
INFO - 2020-09-18 10:29:50 --> Helper loaded: url_helper
INFO - 2020-09-18 10:29:50 --> Database Driver Class Initialized
INFO - 2020-09-18 10:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:29:50 --> Email Class Initialized
INFO - 2020-09-18 10:29:50 --> Controller Class Initialized
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
DEBUG - 2020-09-18 10:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:29:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
INFO - 2020-09-18 10:29:50 --> Final output sent to browser
DEBUG - 2020-09-18 10:29:50 --> Total execution time: 0.0236
ERROR - 2020-09-18 10:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:29:50 --> Config Class Initialized
INFO - 2020-09-18 10:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:29:50 --> Utf8 Class Initialized
INFO - 2020-09-18 10:29:50 --> URI Class Initialized
DEBUG - 2020-09-18 10:29:50 --> No URI present. Default controller set.
INFO - 2020-09-18 10:29:50 --> Router Class Initialized
INFO - 2020-09-18 10:29:50 --> Output Class Initialized
INFO - 2020-09-18 10:29:50 --> Security Class Initialized
DEBUG - 2020-09-18 10:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:29:50 --> Input Class Initialized
INFO - 2020-09-18 10:29:50 --> Language Class Initialized
INFO - 2020-09-18 10:29:50 --> Loader Class Initialized
INFO - 2020-09-18 10:29:50 --> Helper loaded: url_helper
INFO - 2020-09-18 10:29:50 --> Database Driver Class Initialized
INFO - 2020-09-18 10:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:29:50 --> Email Class Initialized
INFO - 2020-09-18 10:29:50 --> Controller Class Initialized
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
INFO - 2020-09-18 10:29:50 --> Model Class Initialized
DEBUG - 2020-09-18 10:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:29:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:29:50 --> Final output sent to browser
DEBUG - 2020-09-18 10:29:50 --> Total execution time: 0.0196
ERROR - 2020-09-18 10:30:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:30:00 --> Config Class Initialized
INFO - 2020-09-18 10:30:00 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:30:00 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:30:00 --> Utf8 Class Initialized
INFO - 2020-09-18 10:30:00 --> URI Class Initialized
INFO - 2020-09-18 10:30:00 --> Router Class Initialized
INFO - 2020-09-18 10:30:00 --> Output Class Initialized
INFO - 2020-09-18 10:30:00 --> Security Class Initialized
DEBUG - 2020-09-18 10:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:30:00 --> Input Class Initialized
INFO - 2020-09-18 10:30:00 --> Language Class Initialized
INFO - 2020-09-18 10:30:00 --> Loader Class Initialized
INFO - 2020-09-18 10:30:00 --> Helper loaded: url_helper
INFO - 2020-09-18 10:30:00 --> Database Driver Class Initialized
INFO - 2020-09-18 10:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:30:00 --> Email Class Initialized
INFO - 2020-09-18 10:30:00 --> Controller Class Initialized
INFO - 2020-09-18 10:30:00 --> Model Class Initialized
INFO - 2020-09-18 10:30:00 --> Model Class Initialized
DEBUG - 2020-09-18 10:30:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:30:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:30:00 --> Model Class Initialized
INFO - 2020-09-18 10:30:00 --> Final output sent to browser
DEBUG - 2020-09-18 10:30:00 --> Total execution time: 0.0233
ERROR - 2020-09-18 10:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:30:01 --> Config Class Initialized
INFO - 2020-09-18 10:30:01 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:30:01 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:30:01 --> Utf8 Class Initialized
INFO - 2020-09-18 10:30:01 --> URI Class Initialized
INFO - 2020-09-18 10:30:01 --> Router Class Initialized
INFO - 2020-09-18 10:30:01 --> Output Class Initialized
INFO - 2020-09-18 10:30:01 --> Security Class Initialized
DEBUG - 2020-09-18 10:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:30:01 --> Input Class Initialized
INFO - 2020-09-18 10:30:01 --> Language Class Initialized
INFO - 2020-09-18 10:30:01 --> Loader Class Initialized
INFO - 2020-09-18 10:30:01 --> Helper loaded: url_helper
INFO - 2020-09-18 10:30:01 --> Database Driver Class Initialized
INFO - 2020-09-18 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:30:01 --> Email Class Initialized
INFO - 2020-09-18 10:30:01 --> Controller Class Initialized
INFO - 2020-09-18 10:30:01 --> Model Class Initialized
INFO - 2020-09-18 10:30:01 --> Model Class Initialized
DEBUG - 2020-09-18 10:30:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:30:01 --> Config Class Initialized
INFO - 2020-09-18 10:30:01 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:30:01 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:30:01 --> Utf8 Class Initialized
INFO - 2020-09-18 10:30:01 --> URI Class Initialized
INFO - 2020-09-18 10:30:01 --> Router Class Initialized
INFO - 2020-09-18 10:30:01 --> Output Class Initialized
INFO - 2020-09-18 10:30:01 --> Security Class Initialized
DEBUG - 2020-09-18 10:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:30:01 --> Input Class Initialized
INFO - 2020-09-18 10:30:01 --> Language Class Initialized
INFO - 2020-09-18 10:30:01 --> Loader Class Initialized
INFO - 2020-09-18 10:30:01 --> Helper loaded: url_helper
INFO - 2020-09-18 10:30:01 --> Database Driver Class Initialized
INFO - 2020-09-18 10:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:30:01 --> Email Class Initialized
INFO - 2020-09-18 10:30:01 --> Controller Class Initialized
DEBUG - 2020-09-18 10:30:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:30:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:30:01 --> Model Class Initialized
INFO - 2020-09-18 10:30:01 --> Model Class Initialized
INFO - 2020-09-18 10:30:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:30:01 --> Final output sent to browser
DEBUG - 2020-09-18 10:30:01 --> Total execution time: 0.0283
ERROR - 2020-09-18 10:34:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:34:43 --> Config Class Initialized
INFO - 2020-09-18 10:34:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:34:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:34:43 --> Utf8 Class Initialized
INFO - 2020-09-18 10:34:43 --> URI Class Initialized
INFO - 2020-09-18 10:34:43 --> Router Class Initialized
INFO - 2020-09-18 10:34:43 --> Output Class Initialized
INFO - 2020-09-18 10:34:43 --> Security Class Initialized
DEBUG - 2020-09-18 10:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:34:43 --> Input Class Initialized
INFO - 2020-09-18 10:34:43 --> Language Class Initialized
INFO - 2020-09-18 10:34:43 --> Loader Class Initialized
INFO - 2020-09-18 10:34:43 --> Helper loaded: url_helper
INFO - 2020-09-18 10:34:43 --> Database Driver Class Initialized
INFO - 2020-09-18 10:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:34:43 --> Email Class Initialized
INFO - 2020-09-18 10:34:43 --> Controller Class Initialized
DEBUG - 2020-09-18 10:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:34:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:34:43 --> Model Class Initialized
INFO - 2020-09-18 10:34:43 --> Model Class Initialized
INFO - 2020-09-18 10:34:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:34:43 --> Final output sent to browser
DEBUG - 2020-09-18 10:34:43 --> Total execution time: 0.0220
ERROR - 2020-09-18 10:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:34:47 --> Config Class Initialized
INFO - 2020-09-18 10:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:34:47 --> Utf8 Class Initialized
INFO - 2020-09-18 10:34:47 --> URI Class Initialized
DEBUG - 2020-09-18 10:34:47 --> No URI present. Default controller set.
INFO - 2020-09-18 10:34:47 --> Router Class Initialized
INFO - 2020-09-18 10:34:47 --> Output Class Initialized
INFO - 2020-09-18 10:34:47 --> Security Class Initialized
DEBUG - 2020-09-18 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:34:47 --> Input Class Initialized
INFO - 2020-09-18 10:34:47 --> Language Class Initialized
INFO - 2020-09-18 10:34:47 --> Loader Class Initialized
INFO - 2020-09-18 10:34:47 --> Helper loaded: url_helper
INFO - 2020-09-18 10:34:47 --> Database Driver Class Initialized
INFO - 2020-09-18 10:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:34:47 --> Email Class Initialized
INFO - 2020-09-18 10:34:47 --> Controller Class Initialized
INFO - 2020-09-18 10:34:47 --> Model Class Initialized
INFO - 2020-09-18 10:34:47 --> Model Class Initialized
DEBUG - 2020-09-18 10:34:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:34:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:34:47 --> Final output sent to browser
DEBUG - 2020-09-18 10:34:47 --> Total execution time: 0.0222
ERROR - 2020-09-18 10:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:34:47 --> Config Class Initialized
INFO - 2020-09-18 10:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:34:47 --> Utf8 Class Initialized
INFO - 2020-09-18 10:34:47 --> URI Class Initialized
INFO - 2020-09-18 10:34:47 --> Router Class Initialized
INFO - 2020-09-18 10:34:47 --> Output Class Initialized
INFO - 2020-09-18 10:34:47 --> Security Class Initialized
DEBUG - 2020-09-18 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:34:47 --> Input Class Initialized
INFO - 2020-09-18 10:34:47 --> Language Class Initialized
ERROR - 2020-09-18 10:34:47 --> 404 Page Not Found: Font-awesome/css
ERROR - 2020-09-18 10:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:34:47 --> Config Class Initialized
INFO - 2020-09-18 10:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:34:47 --> Utf8 Class Initialized
INFO - 2020-09-18 10:34:47 --> URI Class Initialized
INFO - 2020-09-18 10:34:47 --> Router Class Initialized
INFO - 2020-09-18 10:34:47 --> Output Class Initialized
INFO - 2020-09-18 10:34:47 --> Security Class Initialized
DEBUG - 2020-09-18 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:34:47 --> Input Class Initialized
INFO - 2020-09-18 10:34:47 --> Language Class Initialized
ERROR - 2020-09-18 10:34:47 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2020-09-18 10:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:34:48 --> Config Class Initialized
INFO - 2020-09-18 10:34:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:34:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:34:48 --> Utf8 Class Initialized
INFO - 2020-09-18 10:34:48 --> URI Class Initialized
INFO - 2020-09-18 10:34:48 --> Router Class Initialized
INFO - 2020-09-18 10:34:48 --> Output Class Initialized
INFO - 2020-09-18 10:34:48 --> Security Class Initialized
DEBUG - 2020-09-18 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:34:48 --> Input Class Initialized
INFO - 2020-09-18 10:34:48 --> Language Class Initialized
ERROR - 2020-09-18 10:34:48 --> 404 Page Not Found: Css/animate.css
ERROR - 2020-09-18 10:34:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:34:48 --> Config Class Initialized
INFO - 2020-09-18 10:34:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:34:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:34:48 --> Utf8 Class Initialized
INFO - 2020-09-18 10:34:48 --> URI Class Initialized
INFO - 2020-09-18 10:34:48 --> Router Class Initialized
INFO - 2020-09-18 10:34:48 --> Output Class Initialized
INFO - 2020-09-18 10:34:48 --> Security Class Initialized
DEBUG - 2020-09-18 10:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:34:48 --> Input Class Initialized
INFO - 2020-09-18 10:34:48 --> Language Class Initialized
ERROR - 2020-09-18 10:34:48 --> 404 Page Not Found: Css/style.css
ERROR - 2020-09-18 10:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:35:14 --> Config Class Initialized
INFO - 2020-09-18 10:35:14 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:35:14 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:35:14 --> Utf8 Class Initialized
INFO - 2020-09-18 10:35:14 --> URI Class Initialized
INFO - 2020-09-18 10:35:14 --> Router Class Initialized
INFO - 2020-09-18 10:35:14 --> Output Class Initialized
INFO - 2020-09-18 10:35:14 --> Security Class Initialized
DEBUG - 2020-09-18 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:35:14 --> Input Class Initialized
INFO - 2020-09-18 10:35:14 --> Language Class Initialized
INFO - 2020-09-18 10:35:14 --> Loader Class Initialized
INFO - 2020-09-18 10:35:14 --> Helper loaded: url_helper
INFO - 2020-09-18 10:35:14 --> Database Driver Class Initialized
INFO - 2020-09-18 10:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:35:15 --> Email Class Initialized
INFO - 2020-09-18 10:35:15 --> Controller Class Initialized
DEBUG - 2020-09-18 10:35:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:35:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:35:15 --> Model Class Initialized
INFO - 2020-09-18 10:35:15 --> Model Class Initialized
INFO - 2020-09-18 10:35:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:35:15 --> Final output sent to browser
DEBUG - 2020-09-18 10:35:15 --> Total execution time: 0.0279
ERROR - 2020-09-18 10:42:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:42:08 --> Config Class Initialized
INFO - 2020-09-18 10:42:08 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:42:08 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:42:08 --> Utf8 Class Initialized
INFO - 2020-09-18 10:42:08 --> URI Class Initialized
DEBUG - 2020-09-18 10:42:08 --> No URI present. Default controller set.
INFO - 2020-09-18 10:42:08 --> Router Class Initialized
INFO - 2020-09-18 10:42:08 --> Output Class Initialized
INFO - 2020-09-18 10:42:08 --> Security Class Initialized
DEBUG - 2020-09-18 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:42:08 --> Input Class Initialized
INFO - 2020-09-18 10:42:08 --> Language Class Initialized
INFO - 2020-09-18 10:42:08 --> Loader Class Initialized
INFO - 2020-09-18 10:42:08 --> Helper loaded: url_helper
INFO - 2020-09-18 10:42:08 --> Database Driver Class Initialized
INFO - 2020-09-18 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:42:08 --> Email Class Initialized
INFO - 2020-09-18 10:42:08 --> Controller Class Initialized
INFO - 2020-09-18 10:42:08 --> Model Class Initialized
INFO - 2020-09-18 10:42:08 --> Model Class Initialized
DEBUG - 2020-09-18 10:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:42:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:42:08 --> Final output sent to browser
DEBUG - 2020-09-18 10:42:08 --> Total execution time: 0.0215
ERROR - 2020-09-18 10:42:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:42:11 --> Config Class Initialized
INFO - 2020-09-18 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:42:11 --> Utf8 Class Initialized
INFO - 2020-09-18 10:42:11 --> URI Class Initialized
INFO - 2020-09-18 10:42:11 --> Router Class Initialized
INFO - 2020-09-18 10:42:11 --> Output Class Initialized
INFO - 2020-09-18 10:42:11 --> Security Class Initialized
DEBUG - 2020-09-18 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:42:11 --> Input Class Initialized
INFO - 2020-09-18 10:42:11 --> Language Class Initialized
INFO - 2020-09-18 10:42:11 --> Loader Class Initialized
INFO - 2020-09-18 10:42:11 --> Helper loaded: url_helper
INFO - 2020-09-18 10:42:11 --> Database Driver Class Initialized
INFO - 2020-09-18 10:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:42:11 --> Email Class Initialized
INFO - 2020-09-18 10:42:11 --> Controller Class Initialized
INFO - 2020-09-18 10:42:11 --> Model Class Initialized
INFO - 2020-09-18 10:42:11 --> Model Class Initialized
DEBUG - 2020-09-18 10:42:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:42:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:42:11 --> Model Class Initialized
INFO - 2020-09-18 10:42:11 --> Final output sent to browser
DEBUG - 2020-09-18 10:42:11 --> Total execution time: 0.0233
ERROR - 2020-09-18 10:42:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:42:11 --> Config Class Initialized
INFO - 2020-09-18 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:42:11 --> Utf8 Class Initialized
INFO - 2020-09-18 10:42:11 --> URI Class Initialized
INFO - 2020-09-18 10:42:11 --> Router Class Initialized
INFO - 2020-09-18 10:42:11 --> Output Class Initialized
INFO - 2020-09-18 10:42:11 --> Security Class Initialized
DEBUG - 2020-09-18 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:42:11 --> Input Class Initialized
INFO - 2020-09-18 10:42:11 --> Language Class Initialized
INFO - 2020-09-18 10:42:11 --> Loader Class Initialized
INFO - 2020-09-18 10:42:11 --> Helper loaded: url_helper
INFO - 2020-09-18 10:42:11 --> Database Driver Class Initialized
INFO - 2020-09-18 10:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:42:11 --> Email Class Initialized
INFO - 2020-09-18 10:42:11 --> Controller Class Initialized
INFO - 2020-09-18 10:42:11 --> Model Class Initialized
INFO - 2020-09-18 10:42:11 --> Model Class Initialized
DEBUG - 2020-09-18 10:42:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 10:42:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:42:12 --> Config Class Initialized
INFO - 2020-09-18 10:42:12 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:42:12 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:42:12 --> Utf8 Class Initialized
INFO - 2020-09-18 10:42:12 --> URI Class Initialized
INFO - 2020-09-18 10:42:12 --> Router Class Initialized
INFO - 2020-09-18 10:42:12 --> Output Class Initialized
INFO - 2020-09-18 10:42:12 --> Security Class Initialized
DEBUG - 2020-09-18 10:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:42:12 --> Input Class Initialized
INFO - 2020-09-18 10:42:12 --> Language Class Initialized
INFO - 2020-09-18 10:42:12 --> Loader Class Initialized
INFO - 2020-09-18 10:42:12 --> Helper loaded: url_helper
INFO - 2020-09-18 10:42:12 --> Database Driver Class Initialized
INFO - 2020-09-18 10:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:42:12 --> Email Class Initialized
INFO - 2020-09-18 10:42:12 --> Controller Class Initialized
DEBUG - 2020-09-18 10:42:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:42:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:42:12 --> Model Class Initialized
INFO - 2020-09-18 10:42:12 --> Model Class Initialized
INFO - 2020-09-18 10:42:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 10:42:12 --> Final output sent to browser
DEBUG - 2020-09-18 10:42:12 --> Total execution time: 0.0228
ERROR - 2020-09-18 10:42:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:42:15 --> Config Class Initialized
INFO - 2020-09-18 10:42:15 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:42:15 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:42:15 --> Utf8 Class Initialized
INFO - 2020-09-18 10:42:15 --> URI Class Initialized
INFO - 2020-09-18 10:42:15 --> Router Class Initialized
INFO - 2020-09-18 10:42:15 --> Output Class Initialized
INFO - 2020-09-18 10:42:15 --> Security Class Initialized
DEBUG - 2020-09-18 10:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:42:15 --> Input Class Initialized
INFO - 2020-09-18 10:42:15 --> Language Class Initialized
INFO - 2020-09-18 10:42:15 --> Loader Class Initialized
INFO - 2020-09-18 10:42:15 --> Helper loaded: url_helper
INFO - 2020-09-18 10:42:15 --> Database Driver Class Initialized
INFO - 2020-09-18 10:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:42:15 --> Email Class Initialized
INFO - 2020-09-18 10:42:15 --> Controller Class Initialized
DEBUG - 2020-09-18 10:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:42:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:42:15 --> Model Class Initialized
INFO - 2020-09-18 10:42:15 --> Model Class Initialized
INFO - 2020-09-18 10:42:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-18 10:42:15 --> Final output sent to browser
DEBUG - 2020-09-18 10:42:15 --> Total execution time: 0.0257
ERROR - 2020-09-18 10:47:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:47:54 --> Config Class Initialized
INFO - 2020-09-18 10:47:54 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:47:54 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:47:54 --> Utf8 Class Initialized
INFO - 2020-09-18 10:47:54 --> URI Class Initialized
DEBUG - 2020-09-18 10:47:54 --> No URI present. Default controller set.
INFO - 2020-09-18 10:47:54 --> Router Class Initialized
INFO - 2020-09-18 10:47:54 --> Output Class Initialized
INFO - 2020-09-18 10:47:54 --> Security Class Initialized
DEBUG - 2020-09-18 10:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:47:54 --> Input Class Initialized
INFO - 2020-09-18 10:47:54 --> Language Class Initialized
INFO - 2020-09-18 10:47:54 --> Loader Class Initialized
INFO - 2020-09-18 10:47:54 --> Helper loaded: url_helper
INFO - 2020-09-18 10:47:54 --> Database Driver Class Initialized
INFO - 2020-09-18 10:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:47:54 --> Email Class Initialized
INFO - 2020-09-18 10:47:54 --> Controller Class Initialized
INFO - 2020-09-18 10:47:54 --> Model Class Initialized
INFO - 2020-09-18 10:47:54 --> Model Class Initialized
DEBUG - 2020-09-18 10:47:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:47:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 10:47:54 --> Final output sent to browser
DEBUG - 2020-09-18 10:47:54 --> Total execution time: 0.0200
ERROR - 2020-09-18 10:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:48:05 --> Config Class Initialized
INFO - 2020-09-18 10:48:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:48:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:48:05 --> Utf8 Class Initialized
INFO - 2020-09-18 10:48:05 --> URI Class Initialized
INFO - 2020-09-18 10:48:05 --> Router Class Initialized
ERROR - 2020-09-18 10:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:48:05 --> Output Class Initialized
INFO - 2020-09-18 10:48:05 --> Security Class Initialized
INFO - 2020-09-18 10:48:05 --> Config Class Initialized
INFO - 2020-09-18 10:48:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:48:05 --> Input Class Initialized
INFO - 2020-09-18 10:48:05 --> Language Class Initialized
DEBUG - 2020-09-18 10:48:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:48:05 --> Utf8 Class Initialized
INFO - 2020-09-18 10:48:05 --> URI Class Initialized
INFO - 2020-09-18 10:48:05 --> Loader Class Initialized
INFO - 2020-09-18 10:48:05 --> Router Class Initialized
INFO - 2020-09-18 10:48:05 --> Helper loaded: url_helper
INFO - 2020-09-18 10:48:05 --> Output Class Initialized
INFO - 2020-09-18 10:48:05 --> Security Class Initialized
DEBUG - 2020-09-18 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:48:05 --> Input Class Initialized
INFO - 2020-09-18 10:48:05 --> Language Class Initialized
INFO - 2020-09-18 10:48:05 --> Database Driver Class Initialized
INFO - 2020-09-18 10:48:05 --> Loader Class Initialized
INFO - 2020-09-18 10:48:05 --> Helper loaded: url_helper
INFO - 2020-09-18 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:48:05 --> Email Class Initialized
INFO - 2020-09-18 10:48:05 --> Controller Class Initialized
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
INFO - 2020-09-18 10:48:05 --> Database Driver Class Initialized
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
DEBUG - 2020-09-18 10:48:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:48:05 --> Email Class Initialized
INFO - 2020-09-18 10:48:05 --> Controller Class Initialized
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
DEBUG - 2020-09-18 10:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:48:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
INFO - 2020-09-18 10:48:05 --> Final output sent to browser
DEBUG - 2020-09-18 10:48:05 --> Total execution time: 0.0265
ERROR - 2020-09-18 10:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:48:05 --> Config Class Initialized
INFO - 2020-09-18 10:48:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:48:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:48:05 --> Utf8 Class Initialized
INFO - 2020-09-18 10:48:05 --> URI Class Initialized
INFO - 2020-09-18 10:48:05 --> Router Class Initialized
INFO - 2020-09-18 10:48:05 --> Output Class Initialized
INFO - 2020-09-18 10:48:05 --> Security Class Initialized
DEBUG - 2020-09-18 10:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:48:05 --> Input Class Initialized
INFO - 2020-09-18 10:48:05 --> Language Class Initialized
INFO - 2020-09-18 10:48:05 --> Loader Class Initialized
INFO - 2020-09-18 10:48:05 --> Helper loaded: url_helper
INFO - 2020-09-18 10:48:05 --> Database Driver Class Initialized
INFO - 2020-09-18 10:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:48:05 --> Email Class Initialized
INFO - 2020-09-18 10:48:05 --> Controller Class Initialized
DEBUG - 2020-09-18 10:48:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:48:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
INFO - 2020-09-18 10:48:05 --> Model Class Initialized
INFO - 2020-09-18 10:48:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:48:05 --> Final output sent to browser
DEBUG - 2020-09-18 10:48:05 --> Total execution time: 0.0192
ERROR - 2020-09-18 10:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:48:11 --> Config Class Initialized
INFO - 2020-09-18 10:48:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:48:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:48:11 --> Utf8 Class Initialized
INFO - 2020-09-18 10:48:11 --> URI Class Initialized
INFO - 2020-09-18 10:48:11 --> Router Class Initialized
INFO - 2020-09-18 10:48:11 --> Output Class Initialized
INFO - 2020-09-18 10:48:11 --> Security Class Initialized
DEBUG - 2020-09-18 10:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:48:11 --> Input Class Initialized
INFO - 2020-09-18 10:48:11 --> Language Class Initialized
INFO - 2020-09-18 10:48:11 --> Loader Class Initialized
INFO - 2020-09-18 10:48:11 --> Helper loaded: url_helper
INFO - 2020-09-18 10:48:11 --> Database Driver Class Initialized
INFO - 2020-09-18 10:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:48:11 --> Email Class Initialized
INFO - 2020-09-18 10:48:11 --> Controller Class Initialized
DEBUG - 2020-09-18 10:48:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:48:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:48:11 --> Model Class Initialized
INFO - 2020-09-18 10:48:11 --> Model Class Initialized
INFO - 2020-09-18 10:48:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 10:48:11 --> Final output sent to browser
DEBUG - 2020-09-18 10:48:11 --> Total execution time: 0.0224
ERROR - 2020-09-18 10:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:50:21 --> Config Class Initialized
INFO - 2020-09-18 10:50:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:50:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:50:21 --> Utf8 Class Initialized
INFO - 2020-09-18 10:50:21 --> URI Class Initialized
INFO - 2020-09-18 10:50:21 --> Router Class Initialized
INFO - 2020-09-18 10:50:21 --> Output Class Initialized
INFO - 2020-09-18 10:50:21 --> Security Class Initialized
DEBUG - 2020-09-18 10:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:50:21 --> Input Class Initialized
INFO - 2020-09-18 10:50:21 --> Language Class Initialized
INFO - 2020-09-18 10:50:21 --> Loader Class Initialized
INFO - 2020-09-18 10:50:21 --> Helper loaded: url_helper
INFO - 2020-09-18 10:50:21 --> Database Driver Class Initialized
INFO - 2020-09-18 10:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:50:21 --> Email Class Initialized
INFO - 2020-09-18 10:50:21 --> Controller Class Initialized
DEBUG - 2020-09-18 10:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:50:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:50:21 --> Model Class Initialized
INFO - 2020-09-18 10:50:21 --> Model Class Initialized
INFO - 2020-09-18 10:50:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 10:50:21 --> Final output sent to browser
DEBUG - 2020-09-18 10:50:21 --> Total execution time: 0.0246
ERROR - 2020-09-18 10:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:50:27 --> Config Class Initialized
INFO - 2020-09-18 10:50:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:50:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:50:27 --> Utf8 Class Initialized
INFO - 2020-09-18 10:50:27 --> URI Class Initialized
INFO - 2020-09-18 10:50:27 --> Router Class Initialized
INFO - 2020-09-18 10:50:27 --> Output Class Initialized
INFO - 2020-09-18 10:50:27 --> Security Class Initialized
DEBUG - 2020-09-18 10:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:50:27 --> Input Class Initialized
INFO - 2020-09-18 10:50:27 --> Language Class Initialized
ERROR - 2020-09-18 10:50:27 --> 404 Page Not Found: Sale_rep/index.html
ERROR - 2020-09-18 10:50:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:50:32 --> Config Class Initialized
INFO - 2020-09-18 10:50:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:50:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:50:32 --> Utf8 Class Initialized
INFO - 2020-09-18 10:50:32 --> URI Class Initialized
INFO - 2020-09-18 10:50:32 --> Router Class Initialized
INFO - 2020-09-18 10:50:32 --> Output Class Initialized
INFO - 2020-09-18 10:50:32 --> Security Class Initialized
DEBUG - 2020-09-18 10:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:50:32 --> Input Class Initialized
INFO - 2020-09-18 10:50:32 --> Language Class Initialized
INFO - 2020-09-18 10:50:32 --> Loader Class Initialized
INFO - 2020-09-18 10:50:32 --> Helper loaded: url_helper
INFO - 2020-09-18 10:50:32 --> Database Driver Class Initialized
INFO - 2020-09-18 10:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:50:32 --> Email Class Initialized
INFO - 2020-09-18 10:50:32 --> Controller Class Initialized
DEBUG - 2020-09-18 10:50:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:50:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:50:32 --> Model Class Initialized
INFO - 2020-09-18 10:50:32 --> Model Class Initialized
INFO - 2020-09-18 10:50:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 10:50:32 --> Final output sent to browser
DEBUG - 2020-09-18 10:50:32 --> Total execution time: 0.0234
ERROR - 2020-09-18 10:50:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:50:43 --> Config Class Initialized
INFO - 2020-09-18 10:50:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:50:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:50:43 --> Utf8 Class Initialized
INFO - 2020-09-18 10:50:43 --> URI Class Initialized
INFO - 2020-09-18 10:50:43 --> Router Class Initialized
INFO - 2020-09-18 10:50:43 --> Output Class Initialized
INFO - 2020-09-18 10:50:43 --> Security Class Initialized
DEBUG - 2020-09-18 10:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:50:43 --> Input Class Initialized
INFO - 2020-09-18 10:50:43 --> Language Class Initialized
INFO - 2020-09-18 10:50:43 --> Loader Class Initialized
INFO - 2020-09-18 10:50:43 --> Helper loaded: url_helper
INFO - 2020-09-18 10:50:43 --> Database Driver Class Initialized
INFO - 2020-09-18 10:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:50:43 --> Email Class Initialized
INFO - 2020-09-18 10:50:43 --> Controller Class Initialized
DEBUG - 2020-09-18 10:50:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:50:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:50:43 --> Model Class Initialized
INFO - 2020-09-18 10:50:43 --> Model Class Initialized
INFO - 2020-09-18 10:50:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:50:43 --> Final output sent to browser
DEBUG - 2020-09-18 10:50:43 --> Total execution time: 0.0213
ERROR - 2020-09-18 10:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:50:46 --> Config Class Initialized
INFO - 2020-09-18 10:50:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:50:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:50:46 --> Utf8 Class Initialized
INFO - 2020-09-18 10:50:46 --> URI Class Initialized
INFO - 2020-09-18 10:50:46 --> Router Class Initialized
INFO - 2020-09-18 10:50:46 --> Output Class Initialized
INFO - 2020-09-18 10:50:46 --> Security Class Initialized
DEBUG - 2020-09-18 10:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:50:46 --> Input Class Initialized
INFO - 2020-09-18 10:50:46 --> Language Class Initialized
INFO - 2020-09-18 10:50:46 --> Loader Class Initialized
INFO - 2020-09-18 10:50:46 --> Helper loaded: url_helper
INFO - 2020-09-18 10:50:46 --> Database Driver Class Initialized
INFO - 2020-09-18 10:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:50:46 --> Email Class Initialized
INFO - 2020-09-18 10:50:46 --> Controller Class Initialized
DEBUG - 2020-09-18 10:50:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:50:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:50:46 --> Model Class Initialized
INFO - 2020-09-18 10:50:46 --> Model Class Initialized
INFO - 2020-09-18 10:50:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:50:46 --> Final output sent to browser
DEBUG - 2020-09-18 10:50:46 --> Total execution time: 0.0215
ERROR - 2020-09-18 10:53:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:53:54 --> Config Class Initialized
INFO - 2020-09-18 10:53:54 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:53:54 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:53:54 --> Utf8 Class Initialized
INFO - 2020-09-18 10:53:54 --> URI Class Initialized
INFO - 2020-09-18 10:53:54 --> Router Class Initialized
INFO - 2020-09-18 10:53:54 --> Output Class Initialized
INFO - 2020-09-18 10:53:54 --> Security Class Initialized
DEBUG - 2020-09-18 10:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:53:54 --> Input Class Initialized
INFO - 2020-09-18 10:53:54 --> Language Class Initialized
INFO - 2020-09-18 10:53:54 --> Loader Class Initialized
INFO - 2020-09-18 10:53:54 --> Helper loaded: url_helper
INFO - 2020-09-18 10:53:54 --> Database Driver Class Initialized
INFO - 2020-09-18 10:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:53:54 --> Email Class Initialized
INFO - 2020-09-18 10:53:54 --> Controller Class Initialized
DEBUG - 2020-09-18 10:53:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:53:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:53:54 --> Model Class Initialized
INFO - 2020-09-18 10:53:54 --> Model Class Initialized
INFO - 2020-09-18 10:53:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 10:53:54 --> Final output sent to browser
DEBUG - 2020-09-18 10:53:54 --> Total execution time: 0.0260
ERROR - 2020-09-18 10:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 10:53:57 --> Config Class Initialized
INFO - 2020-09-18 10:53:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 10:53:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 10:53:57 --> Utf8 Class Initialized
INFO - 2020-09-18 10:53:57 --> URI Class Initialized
INFO - 2020-09-18 10:53:57 --> Router Class Initialized
INFO - 2020-09-18 10:53:57 --> Output Class Initialized
INFO - 2020-09-18 10:53:57 --> Security Class Initialized
DEBUG - 2020-09-18 10:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 10:53:57 --> Input Class Initialized
INFO - 2020-09-18 10:53:57 --> Language Class Initialized
INFO - 2020-09-18 10:53:57 --> Loader Class Initialized
INFO - 2020-09-18 10:53:57 --> Helper loaded: url_helper
INFO - 2020-09-18 10:53:57 --> Database Driver Class Initialized
INFO - 2020-09-18 10:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 10:53:57 --> Email Class Initialized
INFO - 2020-09-18 10:53:57 --> Controller Class Initialized
DEBUG - 2020-09-18 10:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 10:53:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 10:53:57 --> Model Class Initialized
INFO - 2020-09-18 10:53:57 --> Model Class Initialized
INFO - 2020-09-18 10:53:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 10:53:57 --> Final output sent to browser
DEBUG - 2020-09-18 10:53:57 --> Total execution time: 0.0239
ERROR - 2020-09-18 11:03:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:01 --> Config Class Initialized
INFO - 2020-09-18 11:03:01 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:01 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:01 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:01 --> URI Class Initialized
DEBUG - 2020-09-18 11:03:01 --> No URI present. Default controller set.
INFO - 2020-09-18 11:03:01 --> Router Class Initialized
INFO - 2020-09-18 11:03:01 --> Output Class Initialized
INFO - 2020-09-18 11:03:01 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:01 --> Input Class Initialized
INFO - 2020-09-18 11:03:01 --> Language Class Initialized
INFO - 2020-09-18 11:03:01 --> Loader Class Initialized
INFO - 2020-09-18 11:03:01 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:01 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:01 --> Email Class Initialized
INFO - 2020-09-18 11:03:01 --> Controller Class Initialized
INFO - 2020-09-18 11:03:01 --> Model Class Initialized
INFO - 2020-09-18 11:03:01 --> Model Class Initialized
DEBUG - 2020-09-18 11:03:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:03:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 11:03:01 --> Final output sent to browser
DEBUG - 2020-09-18 11:03:01 --> Total execution time: 0.0206
ERROR - 2020-09-18 11:03:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:06 --> Config Class Initialized
INFO - 2020-09-18 11:03:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:06 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:06 --> URI Class Initialized
INFO - 2020-09-18 11:03:06 --> Router Class Initialized
INFO - 2020-09-18 11:03:06 --> Output Class Initialized
INFO - 2020-09-18 11:03:06 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:06 --> Input Class Initialized
INFO - 2020-09-18 11:03:06 --> Language Class Initialized
INFO - 2020-09-18 11:03:06 --> Loader Class Initialized
INFO - 2020-09-18 11:03:06 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:06 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:06 --> Email Class Initialized
INFO - 2020-09-18 11:03:06 --> Controller Class Initialized
INFO - 2020-09-18 11:03:06 --> Model Class Initialized
INFO - 2020-09-18 11:03:06 --> Model Class Initialized
DEBUG - 2020-09-18 11:03:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:03:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:03:06 --> Model Class Initialized
INFO - 2020-09-18 11:03:06 --> Final output sent to browser
DEBUG - 2020-09-18 11:03:06 --> Total execution time: 0.0233
ERROR - 2020-09-18 11:03:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:06 --> Config Class Initialized
INFO - 2020-09-18 11:03:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:06 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:06 --> URI Class Initialized
INFO - 2020-09-18 11:03:06 --> Router Class Initialized
INFO - 2020-09-18 11:03:06 --> Output Class Initialized
INFO - 2020-09-18 11:03:06 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:06 --> Input Class Initialized
INFO - 2020-09-18 11:03:06 --> Language Class Initialized
INFO - 2020-09-18 11:03:06 --> Loader Class Initialized
INFO - 2020-09-18 11:03:06 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:06 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:06 --> Email Class Initialized
INFO - 2020-09-18 11:03:06 --> Controller Class Initialized
INFO - 2020-09-18 11:03:06 --> Model Class Initialized
INFO - 2020-09-18 11:03:06 --> Model Class Initialized
DEBUG - 2020-09-18 11:03:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 11:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:07 --> Config Class Initialized
INFO - 2020-09-18 11:03:07 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:07 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:07 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:07 --> URI Class Initialized
INFO - 2020-09-18 11:03:07 --> Router Class Initialized
INFO - 2020-09-18 11:03:07 --> Output Class Initialized
INFO - 2020-09-18 11:03:07 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:07 --> Input Class Initialized
INFO - 2020-09-18 11:03:07 --> Language Class Initialized
INFO - 2020-09-18 11:03:07 --> Loader Class Initialized
INFO - 2020-09-18 11:03:07 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:07 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:07 --> Email Class Initialized
INFO - 2020-09-18 11:03:07 --> Controller Class Initialized
DEBUG - 2020-09-18 11:03:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:03:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:03:07 --> Model Class Initialized
INFO - 2020-09-18 11:03:07 --> Model Class Initialized
INFO - 2020-09-18 11:03:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 11:03:07 --> Final output sent to browser
DEBUG - 2020-09-18 11:03:07 --> Total execution time: 0.4130
ERROR - 2020-09-18 11:03:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:12 --> Config Class Initialized
INFO - 2020-09-18 11:03:12 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:12 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:12 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:12 --> URI Class Initialized
INFO - 2020-09-18 11:03:12 --> Router Class Initialized
INFO - 2020-09-18 11:03:12 --> Output Class Initialized
INFO - 2020-09-18 11:03:12 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:12 --> Input Class Initialized
INFO - 2020-09-18 11:03:12 --> Language Class Initialized
INFO - 2020-09-18 11:03:12 --> Loader Class Initialized
INFO - 2020-09-18 11:03:12 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:12 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:12 --> Email Class Initialized
INFO - 2020-09-18 11:03:12 --> Controller Class Initialized
DEBUG - 2020-09-18 11:03:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:03:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:03:12 --> Model Class Initialized
INFO - 2020-09-18 11:03:12 --> Model Class Initialized
INFO - 2020-09-18 11:03:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-18 11:03:12 --> Final output sent to browser
DEBUG - 2020-09-18 11:03:12 --> Total execution time: 0.0321
ERROR - 2020-09-18 11:03:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:14 --> Config Class Initialized
INFO - 2020-09-18 11:03:14 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:14 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:14 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:14 --> URI Class Initialized
INFO - 2020-09-18 11:03:14 --> Router Class Initialized
INFO - 2020-09-18 11:03:14 --> Output Class Initialized
INFO - 2020-09-18 11:03:14 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:14 --> Input Class Initialized
INFO - 2020-09-18 11:03:14 --> Language Class Initialized
INFO - 2020-09-18 11:03:14 --> Loader Class Initialized
INFO - 2020-09-18 11:03:14 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:14 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:14 --> Email Class Initialized
INFO - 2020-09-18 11:03:14 --> Controller Class Initialized
DEBUG - 2020-09-18 11:03:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:03:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:03:14 --> Model Class Initialized
INFO - 2020-09-18 11:03:14 --> Model Class Initialized
INFO - 2020-09-18 11:03:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-18 11:03:14 --> Final output sent to browser
DEBUG - 2020-09-18 11:03:14 --> Total execution time: 0.0352
ERROR - 2020-09-18 11:03:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:03:27 --> Config Class Initialized
INFO - 2020-09-18 11:03:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:03:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:03:27 --> Utf8 Class Initialized
INFO - 2020-09-18 11:03:27 --> URI Class Initialized
INFO - 2020-09-18 11:03:27 --> Router Class Initialized
INFO - 2020-09-18 11:03:27 --> Output Class Initialized
INFO - 2020-09-18 11:03:27 --> Security Class Initialized
DEBUG - 2020-09-18 11:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:03:27 --> Input Class Initialized
INFO - 2020-09-18 11:03:27 --> Language Class Initialized
INFO - 2020-09-18 11:03:27 --> Loader Class Initialized
INFO - 2020-09-18 11:03:27 --> Helper loaded: url_helper
INFO - 2020-09-18 11:03:27 --> Database Driver Class Initialized
INFO - 2020-09-18 11:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:03:27 --> Email Class Initialized
INFO - 2020-09-18 11:03:27 --> Controller Class Initialized
DEBUG - 2020-09-18 11:03:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:03:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:03:27 --> Model Class Initialized
INFO - 2020-09-18 11:03:27 --> Model Class Initialized
INFO - 2020-09-18 11:03:27 --> Model Class Initialized
INFO - 2020-09-18 11:03:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-18 11:03:27 --> Final output sent to browser
DEBUG - 2020-09-18 11:03:27 --> Total execution time: 0.0888
ERROR - 2020-09-18 11:08:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:08:35 --> Config Class Initialized
INFO - 2020-09-18 11:08:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:08:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:08:35 --> Utf8 Class Initialized
INFO - 2020-09-18 11:08:35 --> URI Class Initialized
INFO - 2020-09-18 11:08:35 --> Router Class Initialized
INFO - 2020-09-18 11:08:35 --> Output Class Initialized
INFO - 2020-09-18 11:08:35 --> Security Class Initialized
DEBUG - 2020-09-18 11:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:08:35 --> Input Class Initialized
INFO - 2020-09-18 11:08:35 --> Language Class Initialized
INFO - 2020-09-18 11:08:35 --> Loader Class Initialized
INFO - 2020-09-18 11:08:35 --> Helper loaded: url_helper
INFO - 2020-09-18 11:08:35 --> Database Driver Class Initialized
INFO - 2020-09-18 11:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:08:35 --> Email Class Initialized
INFO - 2020-09-18 11:08:35 --> Controller Class Initialized
DEBUG - 2020-09-18 11:08:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:08:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:08:35 --> Model Class Initialized
INFO - 2020-09-18 11:08:35 --> Model Class Initialized
INFO - 2020-09-18 11:08:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-18 11:08:35 --> Final output sent to browser
DEBUG - 2020-09-18 11:08:35 --> Total execution time: 0.0332
ERROR - 2020-09-18 11:08:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:08:38 --> Config Class Initialized
INFO - 2020-09-18 11:08:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:08:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:08:38 --> Utf8 Class Initialized
INFO - 2020-09-18 11:08:38 --> URI Class Initialized
INFO - 2020-09-18 11:08:38 --> Router Class Initialized
INFO - 2020-09-18 11:08:38 --> Output Class Initialized
INFO - 2020-09-18 11:08:38 --> Security Class Initialized
DEBUG - 2020-09-18 11:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:08:38 --> Input Class Initialized
INFO - 2020-09-18 11:08:38 --> Language Class Initialized
INFO - 2020-09-18 11:08:38 --> Loader Class Initialized
INFO - 2020-09-18 11:08:38 --> Helper loaded: url_helper
INFO - 2020-09-18 11:08:38 --> Database Driver Class Initialized
INFO - 2020-09-18 11:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:08:38 --> Email Class Initialized
INFO - 2020-09-18 11:08:38 --> Controller Class Initialized
DEBUG - 2020-09-18 11:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:08:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:08:38 --> Model Class Initialized
INFO - 2020-09-18 11:08:38 --> Model Class Initialized
INFO - 2020-09-18 11:08:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-18 11:08:38 --> Final output sent to browser
DEBUG - 2020-09-18 11:08:38 --> Total execution time: 0.0267
ERROR - 2020-09-18 11:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:08:46 --> Config Class Initialized
INFO - 2020-09-18 11:08:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:08:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:08:46 --> Utf8 Class Initialized
INFO - 2020-09-18 11:08:46 --> URI Class Initialized
DEBUG - 2020-09-18 11:08:46 --> No URI present. Default controller set.
INFO - 2020-09-18 11:08:46 --> Router Class Initialized
INFO - 2020-09-18 11:08:46 --> Output Class Initialized
INFO - 2020-09-18 11:08:46 --> Security Class Initialized
DEBUG - 2020-09-18 11:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:08:46 --> Input Class Initialized
INFO - 2020-09-18 11:08:46 --> Language Class Initialized
INFO - 2020-09-18 11:08:46 --> Loader Class Initialized
INFO - 2020-09-18 11:08:46 --> Helper loaded: url_helper
INFO - 2020-09-18 11:08:46 --> Database Driver Class Initialized
INFO - 2020-09-18 11:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:08:46 --> Email Class Initialized
INFO - 2020-09-18 11:08:46 --> Controller Class Initialized
INFO - 2020-09-18 11:08:46 --> Model Class Initialized
INFO - 2020-09-18 11:08:46 --> Model Class Initialized
DEBUG - 2020-09-18 11:08:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:08:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 11:08:46 --> Final output sent to browser
DEBUG - 2020-09-18 11:08:46 --> Total execution time: 0.0216
ERROR - 2020-09-18 11:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:28:39 --> Config Class Initialized
INFO - 2020-09-18 11:28:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:28:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:28:39 --> Utf8 Class Initialized
INFO - 2020-09-18 11:28:39 --> URI Class Initialized
DEBUG - 2020-09-18 11:28:39 --> No URI present. Default controller set.
INFO - 2020-09-18 11:28:39 --> Router Class Initialized
INFO - 2020-09-18 11:28:39 --> Output Class Initialized
INFO - 2020-09-18 11:28:39 --> Security Class Initialized
DEBUG - 2020-09-18 11:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:28:39 --> Input Class Initialized
INFO - 2020-09-18 11:28:39 --> Language Class Initialized
INFO - 2020-09-18 11:28:39 --> Loader Class Initialized
INFO - 2020-09-18 11:28:39 --> Helper loaded: url_helper
INFO - 2020-09-18 11:28:39 --> Database Driver Class Initialized
INFO - 2020-09-18 11:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:28:39 --> Email Class Initialized
INFO - 2020-09-18 11:28:39 --> Controller Class Initialized
INFO - 2020-09-18 11:28:39 --> Model Class Initialized
INFO - 2020-09-18 11:28:39 --> Model Class Initialized
DEBUG - 2020-09-18 11:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:28:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 11:28:39 --> Final output sent to browser
DEBUG - 2020-09-18 11:28:39 --> Total execution time: 0.0225
ERROR - 2020-09-18 11:41:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:11 --> Config Class Initialized
INFO - 2020-09-18 11:41:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:11 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:11 --> URI Class Initialized
DEBUG - 2020-09-18 11:41:11 --> No URI present. Default controller set.
INFO - 2020-09-18 11:41:11 --> Router Class Initialized
INFO - 2020-09-18 11:41:11 --> Output Class Initialized
INFO - 2020-09-18 11:41:11 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:11 --> Input Class Initialized
INFO - 2020-09-18 11:41:11 --> Language Class Initialized
INFO - 2020-09-18 11:41:11 --> Loader Class Initialized
INFO - 2020-09-18 11:41:11 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:11 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:11 --> Email Class Initialized
INFO - 2020-09-18 11:41:11 --> Controller Class Initialized
INFO - 2020-09-18 11:41:11 --> Model Class Initialized
INFO - 2020-09-18 11:41:11 --> Model Class Initialized
DEBUG - 2020-09-18 11:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 11:41:11 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:11 --> Total execution time: 0.0183
ERROR - 2020-09-18 11:41:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:13 --> Config Class Initialized
INFO - 2020-09-18 11:41:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:13 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:13 --> URI Class Initialized
INFO - 2020-09-18 11:41:13 --> Router Class Initialized
INFO - 2020-09-18 11:41:13 --> Output Class Initialized
INFO - 2020-09-18 11:41:13 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:13 --> Input Class Initialized
INFO - 2020-09-18 11:41:13 --> Language Class Initialized
INFO - 2020-09-18 11:41:13 --> Loader Class Initialized
INFO - 2020-09-18 11:41:13 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:13 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:13 --> Email Class Initialized
INFO - 2020-09-18 11:41:13 --> Controller Class Initialized
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
DEBUG - 2020-09-18 11:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:41:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
INFO - 2020-09-18 11:41:13 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:13 --> Total execution time: 0.0267
ERROR - 2020-09-18 11:41:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:13 --> Config Class Initialized
INFO - 2020-09-18 11:41:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:13 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:13 --> URI Class Initialized
INFO - 2020-09-18 11:41:13 --> Router Class Initialized
INFO - 2020-09-18 11:41:13 --> Output Class Initialized
INFO - 2020-09-18 11:41:13 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:13 --> Input Class Initialized
INFO - 2020-09-18 11:41:13 --> Language Class Initialized
INFO - 2020-09-18 11:41:13 --> Loader Class Initialized
INFO - 2020-09-18 11:41:13 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:13 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:13 --> Email Class Initialized
INFO - 2020-09-18 11:41:13 --> Controller Class Initialized
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
DEBUG - 2020-09-18 11:41:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 11:41:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:13 --> Config Class Initialized
INFO - 2020-09-18 11:41:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:13 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:13 --> URI Class Initialized
INFO - 2020-09-18 11:41:13 --> Router Class Initialized
INFO - 2020-09-18 11:41:13 --> Output Class Initialized
INFO - 2020-09-18 11:41:13 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:13 --> Input Class Initialized
INFO - 2020-09-18 11:41:13 --> Language Class Initialized
INFO - 2020-09-18 11:41:13 --> Loader Class Initialized
INFO - 2020-09-18 11:41:13 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:13 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:13 --> Email Class Initialized
INFO - 2020-09-18 11:41:13 --> Controller Class Initialized
DEBUG - 2020-09-18 11:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:41:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
INFO - 2020-09-18 11:41:13 --> Model Class Initialized
INFO - 2020-09-18 11:41:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 11:41:13 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:13 --> Total execution time: 0.0201
ERROR - 2020-09-18 11:41:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:18 --> Config Class Initialized
INFO - 2020-09-18 11:41:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:18 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:18 --> URI Class Initialized
INFO - 2020-09-18 11:41:18 --> Router Class Initialized
INFO - 2020-09-18 11:41:18 --> Output Class Initialized
INFO - 2020-09-18 11:41:18 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:18 --> Input Class Initialized
INFO - 2020-09-18 11:41:18 --> Language Class Initialized
INFO - 2020-09-18 11:41:18 --> Loader Class Initialized
INFO - 2020-09-18 11:41:18 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:18 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:18 --> Email Class Initialized
INFO - 2020-09-18 11:41:18 --> Controller Class Initialized
DEBUG - 2020-09-18 11:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:41:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:18 --> Model Class Initialized
INFO - 2020-09-18 11:41:18 --> Model Class Initialized
INFO - 2020-09-18 11:41:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-18 11:41:18 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:18 --> Total execution time: 0.2841
ERROR - 2020-09-18 11:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:22 --> Config Class Initialized
INFO - 2020-09-18 11:41:22 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:22 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:22 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:22 --> URI Class Initialized
INFO - 2020-09-18 11:41:22 --> Router Class Initialized
INFO - 2020-09-18 11:41:22 --> Output Class Initialized
INFO - 2020-09-18 11:41:22 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:22 --> Input Class Initialized
INFO - 2020-09-18 11:41:22 --> Language Class Initialized
INFO - 2020-09-18 11:41:22 --> Loader Class Initialized
INFO - 2020-09-18 11:41:22 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:22 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:22 --> Email Class Initialized
INFO - 2020-09-18 11:41:22 --> Controller Class Initialized
DEBUG - 2020-09-18 11:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:41:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:22 --> Model Class Initialized
INFO - 2020-09-18 11:41:22 --> Model Class Initialized
INFO - 2020-09-18 11:41:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-18 11:41:22 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:22 --> Total execution time: 0.0265
ERROR - 2020-09-18 11:41:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:24 --> Config Class Initialized
INFO - 2020-09-18 11:41:24 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:24 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:24 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:24 --> URI Class Initialized
INFO - 2020-09-18 11:41:24 --> Router Class Initialized
INFO - 2020-09-18 11:41:24 --> Output Class Initialized
INFO - 2020-09-18 11:41:24 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:24 --> Input Class Initialized
INFO - 2020-09-18 11:41:24 --> Language Class Initialized
INFO - 2020-09-18 11:41:24 --> Loader Class Initialized
INFO - 2020-09-18 11:41:24 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:24 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:24 --> Email Class Initialized
INFO - 2020-09-18 11:41:24 --> Controller Class Initialized
DEBUG - 2020-09-18 11:41:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:41:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:24 --> Model Class Initialized
INFO - 2020-09-18 11:41:24 --> Model Class Initialized
INFO - 2020-09-18 11:41:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-18 11:41:24 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:24 --> Total execution time: 0.0243
ERROR - 2020-09-18 11:41:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:41:42 --> Config Class Initialized
INFO - 2020-09-18 11:41:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:41:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:41:42 --> Utf8 Class Initialized
INFO - 2020-09-18 11:41:42 --> URI Class Initialized
INFO - 2020-09-18 11:41:42 --> Router Class Initialized
INFO - 2020-09-18 11:41:42 --> Output Class Initialized
INFO - 2020-09-18 11:41:42 --> Security Class Initialized
DEBUG - 2020-09-18 11:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:41:42 --> Input Class Initialized
INFO - 2020-09-18 11:41:42 --> Language Class Initialized
INFO - 2020-09-18 11:41:42 --> Loader Class Initialized
INFO - 2020-09-18 11:41:42 --> Helper loaded: url_helper
INFO - 2020-09-18 11:41:42 --> Database Driver Class Initialized
INFO - 2020-09-18 11:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:41:42 --> Email Class Initialized
INFO - 2020-09-18 11:41:42 --> Controller Class Initialized
DEBUG - 2020-09-18 11:41:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:41:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:41:42 --> Model Class Initialized
INFO - 2020-09-18 11:41:42 --> Model Class Initialized
INFO - 2020-09-18 11:41:42 --> Model Class Initialized
INFO - 2020-09-18 11:41:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-18 11:41:42 --> Final output sent to browser
DEBUG - 2020-09-18 11:41:42 --> Total execution time: 0.0783
ERROR - 2020-09-18 11:54:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:54:35 --> Config Class Initialized
INFO - 2020-09-18 11:54:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:54:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:54:35 --> Utf8 Class Initialized
INFO - 2020-09-18 11:54:35 --> URI Class Initialized
DEBUG - 2020-09-18 11:54:35 --> No URI present. Default controller set.
INFO - 2020-09-18 11:54:35 --> Router Class Initialized
INFO - 2020-09-18 11:54:35 --> Output Class Initialized
INFO - 2020-09-18 11:54:35 --> Security Class Initialized
DEBUG - 2020-09-18 11:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:54:35 --> Input Class Initialized
INFO - 2020-09-18 11:54:35 --> Language Class Initialized
INFO - 2020-09-18 11:54:35 --> Loader Class Initialized
INFO - 2020-09-18 11:54:35 --> Helper loaded: url_helper
INFO - 2020-09-18 11:54:35 --> Database Driver Class Initialized
INFO - 2020-09-18 11:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:54:36 --> Email Class Initialized
INFO - 2020-09-18 11:54:36 --> Controller Class Initialized
INFO - 2020-09-18 11:54:36 --> Model Class Initialized
INFO - 2020-09-18 11:54:36 --> Model Class Initialized
DEBUG - 2020-09-18 11:54:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:54:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 11:54:36 --> Final output sent to browser
DEBUG - 2020-09-18 11:54:36 --> Total execution time: 0.1761
ERROR - 2020-09-18 11:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:54:53 --> Config Class Initialized
INFO - 2020-09-18 11:54:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:54:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:54:53 --> Utf8 Class Initialized
INFO - 2020-09-18 11:54:53 --> URI Class Initialized
INFO - 2020-09-18 11:54:53 --> Router Class Initialized
INFO - 2020-09-18 11:54:53 --> Output Class Initialized
INFO - 2020-09-18 11:54:53 --> Security Class Initialized
DEBUG - 2020-09-18 11:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:54:53 --> Input Class Initialized
INFO - 2020-09-18 11:54:53 --> Language Class Initialized
INFO - 2020-09-18 11:54:53 --> Loader Class Initialized
INFO - 2020-09-18 11:54:53 --> Helper loaded: url_helper
INFO - 2020-09-18 11:54:53 --> Database Driver Class Initialized
INFO - 2020-09-18 11:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:54:53 --> Email Class Initialized
INFO - 2020-09-18 11:54:53 --> Controller Class Initialized
INFO - 2020-09-18 11:54:53 --> Model Class Initialized
INFO - 2020-09-18 11:54:53 --> Model Class Initialized
DEBUG - 2020-09-18 11:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:54:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:54:53 --> Model Class Initialized
INFO - 2020-09-18 11:54:53 --> Final output sent to browser
DEBUG - 2020-09-18 11:54:53 --> Total execution time: 0.0226
ERROR - 2020-09-18 11:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:54:53 --> Config Class Initialized
INFO - 2020-09-18 11:54:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:54:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:54:53 --> Utf8 Class Initialized
INFO - 2020-09-18 11:54:53 --> URI Class Initialized
INFO - 2020-09-18 11:54:53 --> Router Class Initialized
INFO - 2020-09-18 11:54:53 --> Output Class Initialized
INFO - 2020-09-18 11:54:53 --> Security Class Initialized
DEBUG - 2020-09-18 11:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:54:53 --> Input Class Initialized
INFO - 2020-09-18 11:54:53 --> Language Class Initialized
INFO - 2020-09-18 11:54:53 --> Loader Class Initialized
INFO - 2020-09-18 11:54:53 --> Helper loaded: url_helper
INFO - 2020-09-18 11:54:53 --> Database Driver Class Initialized
INFO - 2020-09-18 11:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:54:53 --> Email Class Initialized
INFO - 2020-09-18 11:54:53 --> Controller Class Initialized
INFO - 2020-09-18 11:54:53 --> Model Class Initialized
INFO - 2020-09-18 11:54:53 --> Model Class Initialized
DEBUG - 2020-09-18 11:54:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 11:54:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:54:54 --> Config Class Initialized
INFO - 2020-09-18 11:54:54 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:54:54 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:54:54 --> Utf8 Class Initialized
INFO - 2020-09-18 11:54:54 --> URI Class Initialized
INFO - 2020-09-18 11:54:54 --> Router Class Initialized
INFO - 2020-09-18 11:54:54 --> Output Class Initialized
INFO - 2020-09-18 11:54:54 --> Security Class Initialized
DEBUG - 2020-09-18 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:54:54 --> Input Class Initialized
INFO - 2020-09-18 11:54:54 --> Language Class Initialized
INFO - 2020-09-18 11:54:54 --> Loader Class Initialized
INFO - 2020-09-18 11:54:54 --> Helper loaded: url_helper
INFO - 2020-09-18 11:54:54 --> Database Driver Class Initialized
INFO - 2020-09-18 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:54:54 --> Email Class Initialized
INFO - 2020-09-18 11:54:54 --> Controller Class Initialized
DEBUG - 2020-09-18 11:54:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:54:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:54:54 --> Model Class Initialized
INFO - 2020-09-18 11:54:54 --> Model Class Initialized
INFO - 2020-09-18 11:54:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 11:54:54 --> Final output sent to browser
DEBUG - 2020-09-18 11:54:54 --> Total execution time: 0.3187
ERROR - 2020-09-18 11:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 11:55:00 --> Config Class Initialized
INFO - 2020-09-18 11:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-18 11:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-18 11:55:00 --> Utf8 Class Initialized
INFO - 2020-09-18 11:55:00 --> URI Class Initialized
INFO - 2020-09-18 11:55:00 --> Router Class Initialized
INFO - 2020-09-18 11:55:00 --> Output Class Initialized
INFO - 2020-09-18 11:55:00 --> Security Class Initialized
DEBUG - 2020-09-18 11:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 11:55:00 --> Input Class Initialized
INFO - 2020-09-18 11:55:00 --> Language Class Initialized
INFO - 2020-09-18 11:55:00 --> Loader Class Initialized
INFO - 2020-09-18 11:55:00 --> Helper loaded: url_helper
INFO - 2020-09-18 11:55:00 --> Database Driver Class Initialized
INFO - 2020-09-18 11:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 11:55:00 --> Email Class Initialized
INFO - 2020-09-18 11:55:00 --> Controller Class Initialized
DEBUG - 2020-09-18 11:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 11:55:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 11:55:00 --> Model Class Initialized
INFO - 2020-09-18 11:55:00 --> Model Class Initialized
INFO - 2020-09-18 11:55:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 11:55:00 --> Final output sent to browser
DEBUG - 2020-09-18 11:55:00 --> Total execution time: 0.0235
ERROR - 2020-09-18 12:09:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:09:52 --> Config Class Initialized
INFO - 2020-09-18 12:09:52 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:09:52 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:09:52 --> Utf8 Class Initialized
INFO - 2020-09-18 12:09:52 --> URI Class Initialized
INFO - 2020-09-18 12:09:52 --> Router Class Initialized
INFO - 2020-09-18 12:09:52 --> Output Class Initialized
INFO - 2020-09-18 12:09:52 --> Security Class Initialized
DEBUG - 2020-09-18 12:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:09:52 --> Input Class Initialized
INFO - 2020-09-18 12:09:52 --> Language Class Initialized
INFO - 2020-09-18 12:09:52 --> Loader Class Initialized
INFO - 2020-09-18 12:09:52 --> Helper loaded: url_helper
INFO - 2020-09-18 12:09:52 --> Database Driver Class Initialized
INFO - 2020-09-18 12:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:09:52 --> Email Class Initialized
INFO - 2020-09-18 12:09:52 --> Controller Class Initialized
DEBUG - 2020-09-18 12:09:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:09:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:09:52 --> Model Class Initialized
INFO - 2020-09-18 12:09:52 --> Model Class Initialized
INFO - 2020-09-18 12:09:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:09:52 --> Final output sent to browser
DEBUG - 2020-09-18 12:09:52 --> Total execution time: 0.0211
ERROR - 2020-09-18 12:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:09:58 --> Config Class Initialized
INFO - 2020-09-18 12:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:09:58 --> Utf8 Class Initialized
INFO - 2020-09-18 12:09:58 --> URI Class Initialized
INFO - 2020-09-18 12:09:58 --> Router Class Initialized
INFO - 2020-09-18 12:09:58 --> Output Class Initialized
INFO - 2020-09-18 12:09:58 --> Security Class Initialized
DEBUG - 2020-09-18 12:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:09:58 --> Input Class Initialized
INFO - 2020-09-18 12:09:58 --> Language Class Initialized
INFO - 2020-09-18 12:09:58 --> Loader Class Initialized
INFO - 2020-09-18 12:09:58 --> Helper loaded: url_helper
INFO - 2020-09-18 12:09:58 --> Database Driver Class Initialized
INFO - 2020-09-18 12:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:09:58 --> Email Class Initialized
INFO - 2020-09-18 12:09:58 --> Controller Class Initialized
DEBUG - 2020-09-18 12:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:09:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:09:58 --> Model Class Initialized
INFO - 2020-09-18 12:09:58 --> Model Class Initialized
INFO - 2020-09-18 12:09:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:09:58 --> Final output sent to browser
DEBUG - 2020-09-18 12:09:58 --> Total execution time: 0.0253
ERROR - 2020-09-18 12:10:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:10:04 --> Config Class Initialized
INFO - 2020-09-18 12:10:04 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:10:04 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:10:04 --> Utf8 Class Initialized
INFO - 2020-09-18 12:10:04 --> URI Class Initialized
DEBUG - 2020-09-18 12:10:04 --> No URI present. Default controller set.
INFO - 2020-09-18 12:10:04 --> Router Class Initialized
INFO - 2020-09-18 12:10:04 --> Output Class Initialized
INFO - 2020-09-18 12:10:04 --> Security Class Initialized
DEBUG - 2020-09-18 12:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:10:04 --> Input Class Initialized
INFO - 2020-09-18 12:10:04 --> Language Class Initialized
INFO - 2020-09-18 12:10:04 --> Loader Class Initialized
INFO - 2020-09-18 12:10:04 --> Helper loaded: url_helper
INFO - 2020-09-18 12:10:04 --> Database Driver Class Initialized
INFO - 2020-09-18 12:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:10:04 --> Email Class Initialized
INFO - 2020-09-18 12:10:04 --> Controller Class Initialized
INFO - 2020-09-18 12:10:04 --> Model Class Initialized
INFO - 2020-09-18 12:10:04 --> Model Class Initialized
DEBUG - 2020-09-18 12:10:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:10:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 12:10:04 --> Final output sent to browser
DEBUG - 2020-09-18 12:10:04 --> Total execution time: 0.0269
ERROR - 2020-09-18 12:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:10:18 --> Config Class Initialized
INFO - 2020-09-18 12:10:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:10:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:10:18 --> Utf8 Class Initialized
INFO - 2020-09-18 12:10:18 --> URI Class Initialized
INFO - 2020-09-18 12:10:18 --> Router Class Initialized
INFO - 2020-09-18 12:10:18 --> Output Class Initialized
INFO - 2020-09-18 12:10:18 --> Security Class Initialized
DEBUG - 2020-09-18 12:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:10:18 --> Input Class Initialized
INFO - 2020-09-18 12:10:18 --> Language Class Initialized
INFO - 2020-09-18 12:10:18 --> Loader Class Initialized
INFO - 2020-09-18 12:10:18 --> Helper loaded: url_helper
INFO - 2020-09-18 12:10:18 --> Database Driver Class Initialized
INFO - 2020-09-18 12:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:10:18 --> Email Class Initialized
INFO - 2020-09-18 12:10:18 --> Controller Class Initialized
INFO - 2020-09-18 12:10:18 --> Model Class Initialized
INFO - 2020-09-18 12:10:18 --> Model Class Initialized
DEBUG - 2020-09-18 12:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:10:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:10:18 --> Model Class Initialized
INFO - 2020-09-18 12:10:18 --> Final output sent to browser
DEBUG - 2020-09-18 12:10:18 --> Total execution time: 0.0273
ERROR - 2020-09-18 12:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:10:18 --> Config Class Initialized
INFO - 2020-09-18 12:10:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:10:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:10:18 --> Utf8 Class Initialized
INFO - 2020-09-18 12:10:18 --> URI Class Initialized
INFO - 2020-09-18 12:10:18 --> Router Class Initialized
INFO - 2020-09-18 12:10:18 --> Output Class Initialized
INFO - 2020-09-18 12:10:18 --> Security Class Initialized
DEBUG - 2020-09-18 12:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:10:18 --> Input Class Initialized
INFO - 2020-09-18 12:10:18 --> Language Class Initialized
INFO - 2020-09-18 12:10:18 --> Loader Class Initialized
INFO - 2020-09-18 12:10:18 --> Helper loaded: url_helper
INFO - 2020-09-18 12:10:18 --> Database Driver Class Initialized
INFO - 2020-09-18 12:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:10:18 --> Email Class Initialized
INFO - 2020-09-18 12:10:18 --> Controller Class Initialized
INFO - 2020-09-18 12:10:18 --> Model Class Initialized
INFO - 2020-09-18 12:10:18 --> Model Class Initialized
DEBUG - 2020-09-18 12:10:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 12:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:10:19 --> Config Class Initialized
INFO - 2020-09-18 12:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:10:19 --> Utf8 Class Initialized
INFO - 2020-09-18 12:10:19 --> URI Class Initialized
INFO - 2020-09-18 12:10:19 --> Router Class Initialized
INFO - 2020-09-18 12:10:19 --> Output Class Initialized
INFO - 2020-09-18 12:10:19 --> Security Class Initialized
DEBUG - 2020-09-18 12:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:10:19 --> Input Class Initialized
INFO - 2020-09-18 12:10:19 --> Language Class Initialized
INFO - 2020-09-18 12:10:19 --> Loader Class Initialized
INFO - 2020-09-18 12:10:19 --> Helper loaded: url_helper
INFO - 2020-09-18 12:10:19 --> Database Driver Class Initialized
INFO - 2020-09-18 12:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:10:19 --> Email Class Initialized
INFO - 2020-09-18 12:10:19 --> Controller Class Initialized
DEBUG - 2020-09-18 12:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:10:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:10:19 --> Model Class Initialized
INFO - 2020-09-18 12:10:19 --> Model Class Initialized
INFO - 2020-09-18 12:10:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 12:10:19 --> Final output sent to browser
DEBUG - 2020-09-18 12:10:19 --> Total execution time: 0.0255
ERROR - 2020-09-18 12:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:10:32 --> Config Class Initialized
INFO - 2020-09-18 12:10:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:10:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:10:32 --> Utf8 Class Initialized
INFO - 2020-09-18 12:10:32 --> URI Class Initialized
INFO - 2020-09-18 12:10:32 --> Router Class Initialized
INFO - 2020-09-18 12:10:32 --> Output Class Initialized
INFO - 2020-09-18 12:10:32 --> Security Class Initialized
DEBUG - 2020-09-18 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:10:32 --> Input Class Initialized
INFO - 2020-09-18 12:10:32 --> Language Class Initialized
INFO - 2020-09-18 12:10:32 --> Loader Class Initialized
INFO - 2020-09-18 12:10:32 --> Helper loaded: url_helper
INFO - 2020-09-18 12:10:32 --> Database Driver Class Initialized
INFO - 2020-09-18 12:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:10:32 --> Email Class Initialized
INFO - 2020-09-18 12:10:32 --> Controller Class Initialized
DEBUG - 2020-09-18 12:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:10:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:10:32 --> Model Class Initialized
INFO - 2020-09-18 12:10:32 --> Model Class Initialized
INFO - 2020-09-18 12:10:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:10:32 --> Final output sent to browser
DEBUG - 2020-09-18 12:10:32 --> Total execution time: 0.0223
ERROR - 2020-09-18 12:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:11:44 --> Config Class Initialized
INFO - 2020-09-18 12:11:44 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:11:44 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:11:44 --> Utf8 Class Initialized
INFO - 2020-09-18 12:11:44 --> URI Class Initialized
INFO - 2020-09-18 12:11:44 --> Router Class Initialized
INFO - 2020-09-18 12:11:44 --> Output Class Initialized
INFO - 2020-09-18 12:11:44 --> Security Class Initialized
DEBUG - 2020-09-18 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:11:44 --> Input Class Initialized
INFO - 2020-09-18 12:11:44 --> Language Class Initialized
INFO - 2020-09-18 12:11:44 --> Loader Class Initialized
INFO - 2020-09-18 12:11:44 --> Helper loaded: url_helper
INFO - 2020-09-18 12:11:44 --> Database Driver Class Initialized
INFO - 2020-09-18 12:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:11:44 --> Email Class Initialized
INFO - 2020-09-18 12:11:44 --> Controller Class Initialized
DEBUG - 2020-09-18 12:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:11:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:11:44 --> Model Class Initialized
INFO - 2020-09-18 12:11:44 --> Model Class Initialized
INFO - 2020-09-18 12:11:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:11:44 --> Final output sent to browser
DEBUG - 2020-09-18 12:11:44 --> Total execution time: 0.0224
ERROR - 2020-09-18 12:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:13:37 --> Config Class Initialized
INFO - 2020-09-18 12:13:37 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:13:37 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:13:37 --> Utf8 Class Initialized
INFO - 2020-09-18 12:13:37 --> URI Class Initialized
INFO - 2020-09-18 12:13:37 --> Router Class Initialized
INFO - 2020-09-18 12:13:37 --> Output Class Initialized
INFO - 2020-09-18 12:13:37 --> Security Class Initialized
DEBUG - 2020-09-18 12:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:13:37 --> Input Class Initialized
INFO - 2020-09-18 12:13:37 --> Language Class Initialized
INFO - 2020-09-18 12:13:37 --> Loader Class Initialized
INFO - 2020-09-18 12:13:37 --> Helper loaded: url_helper
INFO - 2020-09-18 12:13:37 --> Database Driver Class Initialized
INFO - 2020-09-18 12:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:13:37 --> Email Class Initialized
INFO - 2020-09-18 12:13:37 --> Controller Class Initialized
DEBUG - 2020-09-18 12:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:13:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:13:37 --> Model Class Initialized
INFO - 2020-09-18 12:13:37 --> Model Class Initialized
INFO - 2020-09-18 12:13:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:13:37 --> Final output sent to browser
DEBUG - 2020-09-18 12:13:37 --> Total execution time: 0.0231
ERROR - 2020-09-18 12:14:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:14:21 --> Config Class Initialized
INFO - 2020-09-18 12:14:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:14:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:14:21 --> Utf8 Class Initialized
INFO - 2020-09-18 12:14:21 --> URI Class Initialized
INFO - 2020-09-18 12:14:21 --> Router Class Initialized
INFO - 2020-09-18 12:14:21 --> Output Class Initialized
INFO - 2020-09-18 12:14:21 --> Security Class Initialized
DEBUG - 2020-09-18 12:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:14:21 --> Input Class Initialized
INFO - 2020-09-18 12:14:21 --> Language Class Initialized
INFO - 2020-09-18 12:14:21 --> Loader Class Initialized
INFO - 2020-09-18 12:14:21 --> Helper loaded: url_helper
INFO - 2020-09-18 12:14:21 --> Database Driver Class Initialized
INFO - 2020-09-18 12:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:14:21 --> Email Class Initialized
INFO - 2020-09-18 12:14:21 --> Controller Class Initialized
DEBUG - 2020-09-18 12:14:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:14:21 --> Model Class Initialized
INFO - 2020-09-18 12:14:21 --> Model Class Initialized
INFO - 2020-09-18 12:14:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 12:14:21 --> Final output sent to browser
DEBUG - 2020-09-18 12:14:21 --> Total execution time: 0.0345
ERROR - 2020-09-18 12:14:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:14:21 --> Config Class Initialized
INFO - 2020-09-18 12:14:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:14:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:14:21 --> Utf8 Class Initialized
INFO - 2020-09-18 12:14:21 --> URI Class Initialized
INFO - 2020-09-18 12:14:21 --> Router Class Initialized
INFO - 2020-09-18 12:14:21 --> Output Class Initialized
INFO - 2020-09-18 12:14:21 --> Security Class Initialized
DEBUG - 2020-09-18 12:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:14:21 --> Input Class Initialized
INFO - 2020-09-18 12:14:21 --> Language Class Initialized
INFO - 2020-09-18 12:14:21 --> Loader Class Initialized
INFO - 2020-09-18 12:14:21 --> Helper loaded: url_helper
INFO - 2020-09-18 12:14:21 --> Database Driver Class Initialized
INFO - 2020-09-18 12:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:14:21 --> Email Class Initialized
INFO - 2020-09-18 12:14:21 --> Controller Class Initialized
DEBUG - 2020-09-18 12:14:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:14:21 --> Model Class Initialized
INFO - 2020-09-18 12:14:21 --> Model Class Initialized
INFO - 2020-09-18 12:14:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 12:14:21 --> Final output sent to browser
DEBUG - 2020-09-18 12:14:21 --> Total execution time: 0.0233
ERROR - 2020-09-18 12:14:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:14:52 --> Config Class Initialized
INFO - 2020-09-18 12:14:52 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:14:52 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:14:52 --> Utf8 Class Initialized
INFO - 2020-09-18 12:14:52 --> URI Class Initialized
INFO - 2020-09-18 12:14:52 --> Router Class Initialized
INFO - 2020-09-18 12:14:52 --> Output Class Initialized
INFO - 2020-09-18 12:14:52 --> Security Class Initialized
DEBUG - 2020-09-18 12:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:14:52 --> Input Class Initialized
INFO - 2020-09-18 12:14:52 --> Language Class Initialized
INFO - 2020-09-18 12:14:52 --> Loader Class Initialized
INFO - 2020-09-18 12:14:52 --> Helper loaded: url_helper
INFO - 2020-09-18 12:14:52 --> Database Driver Class Initialized
INFO - 2020-09-18 12:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:14:52 --> Email Class Initialized
INFO - 2020-09-18 12:14:52 --> Controller Class Initialized
DEBUG - 2020-09-18 12:14:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:14:52 --> Model Class Initialized
INFO - 2020-09-18 12:14:52 --> Model Class Initialized
INFO - 2020-09-18 12:14:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:14:52 --> Final output sent to browser
DEBUG - 2020-09-18 12:14:52 --> Total execution time: 0.0259
ERROR - 2020-09-18 12:14:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:14:54 --> Config Class Initialized
INFO - 2020-09-18 12:14:54 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:14:54 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:14:54 --> Utf8 Class Initialized
INFO - 2020-09-18 12:14:54 --> URI Class Initialized
INFO - 2020-09-18 12:14:54 --> Router Class Initialized
INFO - 2020-09-18 12:14:54 --> Output Class Initialized
INFO - 2020-09-18 12:14:54 --> Security Class Initialized
DEBUG - 2020-09-18 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:14:54 --> Input Class Initialized
INFO - 2020-09-18 12:14:54 --> Language Class Initialized
INFO - 2020-09-18 12:14:54 --> Loader Class Initialized
INFO - 2020-09-18 12:14:54 --> Helper loaded: url_helper
INFO - 2020-09-18 12:14:54 --> Database Driver Class Initialized
INFO - 2020-09-18 12:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:14:54 --> Email Class Initialized
INFO - 2020-09-18 12:14:54 --> Controller Class Initialized
DEBUG - 2020-09-18 12:14:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:14:54 --> Model Class Initialized
INFO - 2020-09-18 12:14:54 --> Model Class Initialized
INFO - 2020-09-18 12:14:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 12:14:54 --> Final output sent to browser
DEBUG - 2020-09-18 12:14:55 --> Total execution time: 0.0215
ERROR - 2020-09-18 12:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:14:57 --> Config Class Initialized
INFO - 2020-09-18 12:14:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:14:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:14:57 --> Utf8 Class Initialized
INFO - 2020-09-18 12:14:57 --> URI Class Initialized
INFO - 2020-09-18 12:14:57 --> Router Class Initialized
INFO - 2020-09-18 12:14:57 --> Output Class Initialized
INFO - 2020-09-18 12:14:57 --> Security Class Initialized
DEBUG - 2020-09-18 12:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:14:57 --> Input Class Initialized
INFO - 2020-09-18 12:14:57 --> Language Class Initialized
INFO - 2020-09-18 12:14:57 --> Loader Class Initialized
INFO - 2020-09-18 12:14:57 --> Helper loaded: url_helper
INFO - 2020-09-18 12:14:57 --> Database Driver Class Initialized
INFO - 2020-09-18 12:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:14:57 --> Email Class Initialized
INFO - 2020-09-18 12:14:57 --> Controller Class Initialized
DEBUG - 2020-09-18 12:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:14:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:14:57 --> Model Class Initialized
INFO - 2020-09-18 12:14:57 --> Model Class Initialized
INFO - 2020-09-18 12:14:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:14:57 --> Final output sent to browser
DEBUG - 2020-09-18 12:14:57 --> Total execution time: 0.0226
ERROR - 2020-09-18 12:15:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:15:06 --> Config Class Initialized
INFO - 2020-09-18 12:15:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:06 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:06 --> URI Class Initialized
INFO - 2020-09-18 12:15:06 --> Router Class Initialized
INFO - 2020-09-18 12:15:06 --> Output Class Initialized
INFO - 2020-09-18 12:15:06 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:06 --> Input Class Initialized
INFO - 2020-09-18 12:15:06 --> Language Class Initialized
INFO - 2020-09-18 12:15:06 --> Loader Class Initialized
INFO - 2020-09-18 12:15:06 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:06 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:06 --> Email Class Initialized
INFO - 2020-09-18 12:15:06 --> Controller Class Initialized
DEBUG - 2020-09-18 12:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:15:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:15:06 --> Model Class Initialized
INFO - 2020-09-18 12:15:06 --> Model Class Initialized
INFO - 2020-09-18 12:15:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-18 12:15:06 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:06 --> Total execution time: 0.0348
ERROR - 2020-09-18 12:15:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:15:25 --> Config Class Initialized
INFO - 2020-09-18 12:15:25 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:25 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:25 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:25 --> URI Class Initialized
INFO - 2020-09-18 12:15:25 --> Router Class Initialized
INFO - 2020-09-18 12:15:25 --> Output Class Initialized
INFO - 2020-09-18 12:15:25 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:25 --> Input Class Initialized
INFO - 2020-09-18 12:15:25 --> Language Class Initialized
INFO - 2020-09-18 12:15:25 --> Loader Class Initialized
INFO - 2020-09-18 12:15:25 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:25 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:25 --> Email Class Initialized
INFO - 2020-09-18 12:15:25 --> Controller Class Initialized
DEBUG - 2020-09-18 12:15:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:15:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:15:25 --> Model Class Initialized
INFO - 2020-09-18 12:15:25 --> Model Class Initialized
INFO - 2020-09-18 12:15:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-18 12:15:25 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:25 --> Total execution time: 0.0230
ERROR - 2020-09-18 12:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:15:35 --> Config Class Initialized
INFO - 2020-09-18 12:15:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:35 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:35 --> URI Class Initialized
INFO - 2020-09-18 12:15:35 --> Router Class Initialized
INFO - 2020-09-18 12:15:35 --> Output Class Initialized
INFO - 2020-09-18 12:15:35 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:35 --> Input Class Initialized
INFO - 2020-09-18 12:15:35 --> Language Class Initialized
INFO - 2020-09-18 12:15:35 --> Loader Class Initialized
INFO - 2020-09-18 12:15:35 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:35 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:35 --> Email Class Initialized
INFO - 2020-09-18 12:15:35 --> Controller Class Initialized
DEBUG - 2020-09-18 12:15:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:15:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:15:35 --> Model Class Initialized
INFO - 2020-09-18 12:15:35 --> Model Class Initialized
INFO - 2020-09-18 12:15:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-18 12:15:35 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:35 --> Total execution time: 0.0200
ERROR - 2020-09-18 12:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:15:41 --> Config Class Initialized
INFO - 2020-09-18 12:15:41 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:41 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:41 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:41 --> URI Class Initialized
INFO - 2020-09-18 12:15:41 --> Router Class Initialized
INFO - 2020-09-18 12:15:41 --> Output Class Initialized
INFO - 2020-09-18 12:15:41 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:41 --> Input Class Initialized
INFO - 2020-09-18 12:15:41 --> Language Class Initialized
INFO - 2020-09-18 12:15:41 --> Loader Class Initialized
INFO - 2020-09-18 12:15:41 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:41 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:41 --> Email Class Initialized
INFO - 2020-09-18 12:15:41 --> Controller Class Initialized
DEBUG - 2020-09-18 12:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:15:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:15:41 --> Model Class Initialized
INFO - 2020-09-18 12:15:41 --> Model Class Initialized
INFO - 2020-09-18 12:15:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 12:15:41 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:41 --> Total execution time: 0.0242
ERROR - 2020-09-18 12:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 12:15:46 --> Config Class Initialized
INFO - 2020-09-18 12:15:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 12:15:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 12:15:46 --> Utf8 Class Initialized
INFO - 2020-09-18 12:15:46 --> URI Class Initialized
INFO - 2020-09-18 12:15:46 --> Router Class Initialized
INFO - 2020-09-18 12:15:46 --> Output Class Initialized
INFO - 2020-09-18 12:15:46 --> Security Class Initialized
DEBUG - 2020-09-18 12:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 12:15:46 --> Input Class Initialized
INFO - 2020-09-18 12:15:46 --> Language Class Initialized
INFO - 2020-09-18 12:15:46 --> Loader Class Initialized
INFO - 2020-09-18 12:15:46 --> Helper loaded: url_helper
INFO - 2020-09-18 12:15:46 --> Database Driver Class Initialized
INFO - 2020-09-18 12:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 12:15:46 --> Email Class Initialized
INFO - 2020-09-18 12:15:46 --> Controller Class Initialized
DEBUG - 2020-09-18 12:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 12:15:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 12:15:46 --> Model Class Initialized
INFO - 2020-09-18 12:15:46 --> Model Class Initialized
INFO - 2020-09-18 12:15:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-18 12:15:46 --> Final output sent to browser
DEBUG - 2020-09-18 12:15:46 --> Total execution time: 0.0430
ERROR - 2020-09-18 14:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 14:48:37 --> Config Class Initialized
INFO - 2020-09-18 14:48:37 --> Hooks Class Initialized
DEBUG - 2020-09-18 14:48:37 --> UTF-8 Support Enabled
INFO - 2020-09-18 14:48:37 --> Utf8 Class Initialized
INFO - 2020-09-18 14:48:37 --> URI Class Initialized
DEBUG - 2020-09-18 14:48:37 --> No URI present. Default controller set.
INFO - 2020-09-18 14:48:37 --> Router Class Initialized
INFO - 2020-09-18 14:48:37 --> Output Class Initialized
INFO - 2020-09-18 14:48:37 --> Security Class Initialized
DEBUG - 2020-09-18 14:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 14:48:37 --> Input Class Initialized
INFO - 2020-09-18 14:48:37 --> Language Class Initialized
INFO - 2020-09-18 14:48:37 --> Loader Class Initialized
INFO - 2020-09-18 14:48:37 --> Helper loaded: url_helper
INFO - 2020-09-18 14:48:37 --> Database Driver Class Initialized
INFO - 2020-09-18 14:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 14:48:37 --> Email Class Initialized
INFO - 2020-09-18 14:48:37 --> Controller Class Initialized
INFO - 2020-09-18 14:48:37 --> Model Class Initialized
INFO - 2020-09-18 14:48:37 --> Model Class Initialized
DEBUG - 2020-09-18 14:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 14:48:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 14:48:37 --> Final output sent to browser
DEBUG - 2020-09-18 14:48:37 --> Total execution time: 0.0174
ERROR - 2020-09-18 14:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 14:48:47 --> Config Class Initialized
INFO - 2020-09-18 14:48:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 14:48:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 14:48:47 --> Utf8 Class Initialized
INFO - 2020-09-18 14:48:47 --> URI Class Initialized
DEBUG - 2020-09-18 14:48:47 --> No URI present. Default controller set.
INFO - 2020-09-18 14:48:47 --> Router Class Initialized
INFO - 2020-09-18 14:48:47 --> Output Class Initialized
INFO - 2020-09-18 14:48:47 --> Security Class Initialized
DEBUG - 2020-09-18 14:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 14:48:47 --> Input Class Initialized
INFO - 2020-09-18 14:48:47 --> Language Class Initialized
INFO - 2020-09-18 14:48:47 --> Loader Class Initialized
INFO - 2020-09-18 14:48:47 --> Helper loaded: url_helper
INFO - 2020-09-18 14:48:47 --> Database Driver Class Initialized
INFO - 2020-09-18 14:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 14:48:47 --> Email Class Initialized
INFO - 2020-09-18 14:48:47 --> Controller Class Initialized
INFO - 2020-09-18 14:48:47 --> Model Class Initialized
INFO - 2020-09-18 14:48:47 --> Model Class Initialized
DEBUG - 2020-09-18 14:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 14:48:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 14:48:47 --> Final output sent to browser
DEBUG - 2020-09-18 14:48:47 --> Total execution time: 0.0220
ERROR - 2020-09-18 14:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 14:49:09 --> Config Class Initialized
INFO - 2020-09-18 14:49:09 --> Hooks Class Initialized
DEBUG - 2020-09-18 14:49:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 14:49:09 --> Utf8 Class Initialized
INFO - 2020-09-18 14:49:09 --> URI Class Initialized
INFO - 2020-09-18 14:49:09 --> Router Class Initialized
INFO - 2020-09-18 14:49:09 --> Output Class Initialized
INFO - 2020-09-18 14:49:09 --> Security Class Initialized
DEBUG - 2020-09-18 14:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 14:49:09 --> Input Class Initialized
INFO - 2020-09-18 14:49:09 --> Language Class Initialized
INFO - 2020-09-18 14:49:09 --> Loader Class Initialized
INFO - 2020-09-18 14:49:09 --> Helper loaded: url_helper
INFO - 2020-09-18 14:49:09 --> Database Driver Class Initialized
ERROR - 2020-09-18 14:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 14:49:09 --> Config Class Initialized
INFO - 2020-09-18 14:49:09 --> Hooks Class Initialized
DEBUG - 2020-09-18 14:49:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 14:49:09 --> Utf8 Class Initialized
INFO - 2020-09-18 14:49:09 --> URI Class Initialized
INFO - 2020-09-18 14:49:09 --> Router Class Initialized
INFO - 2020-09-18 14:49:09 --> Output Class Initialized
INFO - 2020-09-18 14:49:09 --> Security Class Initialized
DEBUG - 2020-09-18 14:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 14:49:09 --> Input Class Initialized
INFO - 2020-09-18 14:49:09 --> Language Class Initialized
INFO - 2020-09-18 14:49:09 --> Loader Class Initialized
INFO - 2020-09-18 14:49:09 --> Helper loaded: url_helper
INFO - 2020-09-18 14:49:09 --> Database Driver Class Initialized
INFO - 2020-09-18 14:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 14:49:09 --> Email Class Initialized
INFO - 2020-09-18 14:49:09 --> Controller Class Initialized
INFO - 2020-09-18 14:49:09 --> Model Class Initialized
INFO - 2020-09-18 14:49:09 --> Model Class Initialized
DEBUG - 2020-09-18 14:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 14:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 14:49:10 --> Email Class Initialized
INFO - 2020-09-18 14:49:10 --> Controller Class Initialized
INFO - 2020-09-18 14:49:10 --> Model Class Initialized
INFO - 2020-09-18 14:49:10 --> Model Class Initialized
DEBUG - 2020-09-18 14:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 14:49:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 14:49:10 --> Model Class Initialized
INFO - 2020-09-18 14:49:10 --> Final output sent to browser
DEBUG - 2020-09-18 14:49:10 --> Total execution time: 0.3993
ERROR - 2020-09-18 14:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 14:49:10 --> Config Class Initialized
INFO - 2020-09-18 14:49:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 14:49:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 14:49:10 --> Utf8 Class Initialized
INFO - 2020-09-18 14:49:10 --> URI Class Initialized
INFO - 2020-09-18 14:49:10 --> Router Class Initialized
INFO - 2020-09-18 14:49:10 --> Output Class Initialized
INFO - 2020-09-18 14:49:10 --> Security Class Initialized
DEBUG - 2020-09-18 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 14:49:10 --> Input Class Initialized
INFO - 2020-09-18 14:49:10 --> Language Class Initialized
INFO - 2020-09-18 14:49:10 --> Loader Class Initialized
INFO - 2020-09-18 14:49:10 --> Helper loaded: url_helper
INFO - 2020-09-18 14:49:10 --> Database Driver Class Initialized
INFO - 2020-09-18 14:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 14:49:10 --> Email Class Initialized
INFO - 2020-09-18 14:49:10 --> Controller Class Initialized
DEBUG - 2020-09-18 14:49:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 14:49:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 14:49:10 --> Model Class Initialized
INFO - 2020-09-18 14:49:10 --> Model Class Initialized
INFO - 2020-09-18 14:49:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 14:49:10 --> Final output sent to browser
DEBUG - 2020-09-18 14:49:10 --> Total execution time: 0.0377
ERROR - 2020-09-18 15:15:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:15:35 --> Config Class Initialized
INFO - 2020-09-18 15:15:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:15:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:15:35 --> Utf8 Class Initialized
INFO - 2020-09-18 15:15:35 --> URI Class Initialized
DEBUG - 2020-09-18 15:15:35 --> No URI present. Default controller set.
INFO - 2020-09-18 15:15:35 --> Router Class Initialized
INFO - 2020-09-18 15:15:35 --> Output Class Initialized
INFO - 2020-09-18 15:15:35 --> Security Class Initialized
DEBUG - 2020-09-18 15:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:15:35 --> Input Class Initialized
INFO - 2020-09-18 15:15:35 --> Language Class Initialized
INFO - 2020-09-18 15:15:35 --> Loader Class Initialized
INFO - 2020-09-18 15:15:35 --> Helper loaded: url_helper
INFO - 2020-09-18 15:15:35 --> Database Driver Class Initialized
INFO - 2020-09-18 15:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:15:35 --> Email Class Initialized
INFO - 2020-09-18 15:15:35 --> Controller Class Initialized
INFO - 2020-09-18 15:15:35 --> Model Class Initialized
INFO - 2020-09-18 15:15:35 --> Model Class Initialized
DEBUG - 2020-09-18 15:15:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:15:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:15:35 --> Final output sent to browser
DEBUG - 2020-09-18 15:15:35 --> Total execution time: 0.0217
ERROR - 2020-09-18 15:20:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:20:09 --> Config Class Initialized
INFO - 2020-09-18 15:20:09 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:20:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:20:09 --> Utf8 Class Initialized
INFO - 2020-09-18 15:20:09 --> URI Class Initialized
DEBUG - 2020-09-18 15:20:09 --> No URI present. Default controller set.
INFO - 2020-09-18 15:20:09 --> Router Class Initialized
INFO - 2020-09-18 15:20:09 --> Output Class Initialized
INFO - 2020-09-18 15:20:09 --> Security Class Initialized
DEBUG - 2020-09-18 15:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:20:09 --> Input Class Initialized
INFO - 2020-09-18 15:20:09 --> Language Class Initialized
INFO - 2020-09-18 15:20:09 --> Loader Class Initialized
INFO - 2020-09-18 15:20:09 --> Helper loaded: url_helper
INFO - 2020-09-18 15:20:09 --> Database Driver Class Initialized
INFO - 2020-09-18 15:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:20:09 --> Email Class Initialized
INFO - 2020-09-18 15:20:09 --> Controller Class Initialized
INFO - 2020-09-18 15:20:09 --> Model Class Initialized
INFO - 2020-09-18 15:20:09 --> Model Class Initialized
DEBUG - 2020-09-18 15:20:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:20:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:20:09 --> Final output sent to browser
DEBUG - 2020-09-18 15:20:09 --> Total execution time: 0.0223
ERROR - 2020-09-18 15:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:21:08 --> Config Class Initialized
INFO - 2020-09-18 15:21:08 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:21:08 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:21:08 --> Utf8 Class Initialized
INFO - 2020-09-18 15:21:08 --> URI Class Initialized
DEBUG - 2020-09-18 15:21:08 --> No URI present. Default controller set.
INFO - 2020-09-18 15:21:08 --> Router Class Initialized
INFO - 2020-09-18 15:21:08 --> Output Class Initialized
INFO - 2020-09-18 15:21:08 --> Security Class Initialized
DEBUG - 2020-09-18 15:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:21:08 --> Input Class Initialized
INFO - 2020-09-18 15:21:08 --> Language Class Initialized
INFO - 2020-09-18 15:21:08 --> Loader Class Initialized
INFO - 2020-09-18 15:21:08 --> Helper loaded: url_helper
INFO - 2020-09-18 15:21:08 --> Database Driver Class Initialized
INFO - 2020-09-18 15:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:21:08 --> Email Class Initialized
INFO - 2020-09-18 15:21:08 --> Controller Class Initialized
INFO - 2020-09-18 15:21:08 --> Model Class Initialized
INFO - 2020-09-18 15:21:08 --> Model Class Initialized
DEBUG - 2020-09-18 15:21:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:21:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:21:08 --> Final output sent to browser
DEBUG - 2020-09-18 15:21:08 --> Total execution time: 0.0211
ERROR - 2020-09-18 15:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:26:59 --> Config Class Initialized
INFO - 2020-09-18 15:26:59 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:26:59 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:26:59 --> Utf8 Class Initialized
INFO - 2020-09-18 15:26:59 --> URI Class Initialized
DEBUG - 2020-09-18 15:26:59 --> No URI present. Default controller set.
INFO - 2020-09-18 15:26:59 --> Router Class Initialized
INFO - 2020-09-18 15:26:59 --> Output Class Initialized
INFO - 2020-09-18 15:26:59 --> Security Class Initialized
DEBUG - 2020-09-18 15:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:26:59 --> Input Class Initialized
INFO - 2020-09-18 15:26:59 --> Language Class Initialized
INFO - 2020-09-18 15:26:59 --> Loader Class Initialized
INFO - 2020-09-18 15:26:59 --> Helper loaded: url_helper
INFO - 2020-09-18 15:26:59 --> Database Driver Class Initialized
INFO - 2020-09-18 15:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:26:59 --> Email Class Initialized
INFO - 2020-09-18 15:26:59 --> Controller Class Initialized
INFO - 2020-09-18 15:26:59 --> Model Class Initialized
INFO - 2020-09-18 15:26:59 --> Model Class Initialized
DEBUG - 2020-09-18 15:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:26:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:26:59 --> Final output sent to browser
DEBUG - 2020-09-18 15:26:59 --> Total execution time: 0.0178
ERROR - 2020-09-18 15:27:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:27:17 --> Config Class Initialized
INFO - 2020-09-18 15:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:27:17 --> Utf8 Class Initialized
INFO - 2020-09-18 15:27:17 --> URI Class Initialized
INFO - 2020-09-18 15:27:17 --> Router Class Initialized
INFO - 2020-09-18 15:27:17 --> Output Class Initialized
INFO - 2020-09-18 15:27:17 --> Security Class Initialized
DEBUG - 2020-09-18 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:27:17 --> Input Class Initialized
INFO - 2020-09-18 15:27:17 --> Language Class Initialized
INFO - 2020-09-18 15:27:17 --> Loader Class Initialized
INFO - 2020-09-18 15:27:17 --> Helper loaded: url_helper
INFO - 2020-09-18 15:27:17 --> Database Driver Class Initialized
INFO - 2020-09-18 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:27:17 --> Email Class Initialized
INFO - 2020-09-18 15:27:17 --> Controller Class Initialized
INFO - 2020-09-18 15:27:17 --> Model Class Initialized
INFO - 2020-09-18 15:27:17 --> Model Class Initialized
DEBUG - 2020-09-18 15:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:27:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:27:17 --> Model Class Initialized
INFO - 2020-09-18 15:27:17 --> Final output sent to browser
DEBUG - 2020-09-18 15:27:17 --> Total execution time: 0.1142
ERROR - 2020-09-18 15:27:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:27:17 --> Config Class Initialized
INFO - 2020-09-18 15:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:27:17 --> Utf8 Class Initialized
INFO - 2020-09-18 15:27:17 --> URI Class Initialized
INFO - 2020-09-18 15:27:17 --> Router Class Initialized
INFO - 2020-09-18 15:27:17 --> Output Class Initialized
INFO - 2020-09-18 15:27:17 --> Security Class Initialized
DEBUG - 2020-09-18 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:27:17 --> Input Class Initialized
INFO - 2020-09-18 15:27:17 --> Language Class Initialized
INFO - 2020-09-18 15:27:17 --> Loader Class Initialized
INFO - 2020-09-18 15:27:17 --> Helper loaded: url_helper
INFO - 2020-09-18 15:27:17 --> Database Driver Class Initialized
INFO - 2020-09-18 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:27:17 --> Email Class Initialized
INFO - 2020-09-18 15:27:17 --> Controller Class Initialized
INFO - 2020-09-18 15:27:17 --> Model Class Initialized
INFO - 2020-09-18 15:27:17 --> Model Class Initialized
DEBUG - 2020-09-18 15:27:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 15:27:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:27:18 --> Config Class Initialized
INFO - 2020-09-18 15:27:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:27:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:27:18 --> Utf8 Class Initialized
INFO - 2020-09-18 15:27:18 --> URI Class Initialized
INFO - 2020-09-18 15:27:18 --> Router Class Initialized
INFO - 2020-09-18 15:27:18 --> Output Class Initialized
INFO - 2020-09-18 15:27:18 --> Security Class Initialized
DEBUG - 2020-09-18 15:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:27:18 --> Input Class Initialized
INFO - 2020-09-18 15:27:18 --> Language Class Initialized
INFO - 2020-09-18 15:27:18 --> Loader Class Initialized
INFO - 2020-09-18 15:27:18 --> Helper loaded: url_helper
INFO - 2020-09-18 15:27:18 --> Database Driver Class Initialized
INFO - 2020-09-18 15:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:27:18 --> Email Class Initialized
INFO - 2020-09-18 15:27:18 --> Controller Class Initialized
DEBUG - 2020-09-18 15:27:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:27:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:27:18 --> Model Class Initialized
INFO - 2020-09-18 15:27:18 --> Model Class Initialized
INFO - 2020-09-18 15:27:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 15:27:18 --> Final output sent to browser
DEBUG - 2020-09-18 15:27:18 --> Total execution time: 0.0298
ERROR - 2020-09-18 15:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:28:05 --> Config Class Initialized
INFO - 2020-09-18 15:28:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:28:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:28:05 --> Utf8 Class Initialized
INFO - 2020-09-18 15:28:05 --> URI Class Initialized
INFO - 2020-09-18 15:28:05 --> Router Class Initialized
INFO - 2020-09-18 15:28:05 --> Output Class Initialized
INFO - 2020-09-18 15:28:05 --> Security Class Initialized
DEBUG - 2020-09-18 15:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:28:05 --> Input Class Initialized
INFO - 2020-09-18 15:28:05 --> Language Class Initialized
INFO - 2020-09-18 15:28:05 --> Loader Class Initialized
INFO - 2020-09-18 15:28:05 --> Helper loaded: url_helper
INFO - 2020-09-18 15:28:05 --> Database Driver Class Initialized
INFO - 2020-09-18 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:28:05 --> Email Class Initialized
INFO - 2020-09-18 15:28:05 --> Controller Class Initialized
DEBUG - 2020-09-18 15:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:28:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:28:05 --> Model Class Initialized
INFO - 2020-09-18 15:28:05 --> Model Class Initialized
INFO - 2020-09-18 15:28:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-18 15:28:05 --> Final output sent to browser
DEBUG - 2020-09-18 15:28:05 --> Total execution time: 0.0248
ERROR - 2020-09-18 15:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:28:10 --> Config Class Initialized
INFO - 2020-09-18 15:28:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:28:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:28:10 --> Utf8 Class Initialized
INFO - 2020-09-18 15:28:10 --> URI Class Initialized
INFO - 2020-09-18 15:28:10 --> Router Class Initialized
INFO - 2020-09-18 15:28:10 --> Output Class Initialized
INFO - 2020-09-18 15:28:10 --> Security Class Initialized
DEBUG - 2020-09-18 15:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:28:10 --> Input Class Initialized
INFO - 2020-09-18 15:28:10 --> Language Class Initialized
INFO - 2020-09-18 15:28:10 --> Loader Class Initialized
INFO - 2020-09-18 15:28:10 --> Helper loaded: url_helper
INFO - 2020-09-18 15:28:10 --> Database Driver Class Initialized
INFO - 2020-09-18 15:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:28:11 --> Email Class Initialized
INFO - 2020-09-18 15:28:11 --> Controller Class Initialized
DEBUG - 2020-09-18 15:28:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:28:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:28:11 --> Model Class Initialized
INFO - 2020-09-18 15:28:11 --> Model Class Initialized
INFO - 2020-09-18 15:28:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-18 15:28:11 --> Final output sent to browser
DEBUG - 2020-09-18 15:28:11 --> Total execution time: 0.4488
ERROR - 2020-09-18 15:28:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:28:36 --> Config Class Initialized
INFO - 2020-09-18 15:28:36 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:28:36 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:28:36 --> Utf8 Class Initialized
INFO - 2020-09-18 15:28:36 --> URI Class Initialized
INFO - 2020-09-18 15:28:36 --> Router Class Initialized
INFO - 2020-09-18 15:28:36 --> Output Class Initialized
INFO - 2020-09-18 15:28:36 --> Security Class Initialized
DEBUG - 2020-09-18 15:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:28:36 --> Input Class Initialized
INFO - 2020-09-18 15:28:36 --> Language Class Initialized
INFO - 2020-09-18 15:28:36 --> Loader Class Initialized
INFO - 2020-09-18 15:28:36 --> Helper loaded: url_helper
INFO - 2020-09-18 15:28:36 --> Database Driver Class Initialized
INFO - 2020-09-18 15:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:28:36 --> Email Class Initialized
INFO - 2020-09-18 15:28:36 --> Controller Class Initialized
DEBUG - 2020-09-18 15:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:28:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:28:36 --> Model Class Initialized
INFO - 2020-09-18 15:28:36 --> Model Class Initialized
INFO - 2020-09-18 15:28:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-18 15:28:36 --> Final output sent to browser
DEBUG - 2020-09-18 15:28:36 --> Total execution time: 0.0281
ERROR - 2020-09-18 15:29:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:29:32 --> Config Class Initialized
INFO - 2020-09-18 15:29:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:29:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:29:32 --> Utf8 Class Initialized
INFO - 2020-09-18 15:29:32 --> URI Class Initialized
DEBUG - 2020-09-18 15:29:32 --> No URI present. Default controller set.
INFO - 2020-09-18 15:29:32 --> Router Class Initialized
INFO - 2020-09-18 15:29:32 --> Output Class Initialized
INFO - 2020-09-18 15:29:32 --> Security Class Initialized
DEBUG - 2020-09-18 15:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:29:32 --> Input Class Initialized
INFO - 2020-09-18 15:29:32 --> Language Class Initialized
INFO - 2020-09-18 15:29:32 --> Loader Class Initialized
INFO - 2020-09-18 15:29:32 --> Helper loaded: url_helper
INFO - 2020-09-18 15:29:32 --> Database Driver Class Initialized
INFO - 2020-09-18 15:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:29:32 --> Email Class Initialized
INFO - 2020-09-18 15:29:32 --> Controller Class Initialized
INFO - 2020-09-18 15:29:32 --> Model Class Initialized
INFO - 2020-09-18 15:29:32 --> Model Class Initialized
DEBUG - 2020-09-18 15:29:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:29:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:29:32 --> Final output sent to browser
DEBUG - 2020-09-18 15:29:32 --> Total execution time: 0.0196
ERROR - 2020-09-18 15:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:29:43 --> Config Class Initialized
INFO - 2020-09-18 15:29:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:29:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:29:43 --> Utf8 Class Initialized
INFO - 2020-09-18 15:29:43 --> URI Class Initialized
INFO - 2020-09-18 15:29:43 --> Router Class Initialized
INFO - 2020-09-18 15:29:43 --> Output Class Initialized
INFO - 2020-09-18 15:29:43 --> Security Class Initialized
DEBUG - 2020-09-18 15:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:29:43 --> Input Class Initialized
INFO - 2020-09-18 15:29:43 --> Language Class Initialized
INFO - 2020-09-18 15:29:43 --> Loader Class Initialized
INFO - 2020-09-18 15:29:43 --> Helper loaded: url_helper
INFO - 2020-09-18 15:29:43 --> Database Driver Class Initialized
INFO - 2020-09-18 15:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:29:43 --> Email Class Initialized
INFO - 2020-09-18 15:29:43 --> Controller Class Initialized
INFO - 2020-09-18 15:29:43 --> Model Class Initialized
INFO - 2020-09-18 15:29:43 --> Model Class Initialized
DEBUG - 2020-09-18 15:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:29:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:29:43 --> Model Class Initialized
INFO - 2020-09-18 15:29:43 --> Final output sent to browser
DEBUG - 2020-09-18 15:29:43 --> Total execution time: 0.0248
ERROR - 2020-09-18 15:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:29:43 --> Config Class Initialized
INFO - 2020-09-18 15:29:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:29:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:29:43 --> Utf8 Class Initialized
INFO - 2020-09-18 15:29:43 --> URI Class Initialized
INFO - 2020-09-18 15:29:43 --> Router Class Initialized
INFO - 2020-09-18 15:29:43 --> Output Class Initialized
INFO - 2020-09-18 15:29:43 --> Security Class Initialized
DEBUG - 2020-09-18 15:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:29:43 --> Input Class Initialized
INFO - 2020-09-18 15:29:43 --> Language Class Initialized
INFO - 2020-09-18 15:29:43 --> Loader Class Initialized
INFO - 2020-09-18 15:29:43 --> Helper loaded: url_helper
INFO - 2020-09-18 15:29:43 --> Database Driver Class Initialized
INFO - 2020-09-18 15:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:29:43 --> Email Class Initialized
INFO - 2020-09-18 15:29:43 --> Controller Class Initialized
INFO - 2020-09-18 15:29:43 --> Model Class Initialized
INFO - 2020-09-18 15:29:43 --> Model Class Initialized
DEBUG - 2020-09-18 15:29:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 15:29:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:29:44 --> Config Class Initialized
INFO - 2020-09-18 15:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:29:44 --> Utf8 Class Initialized
INFO - 2020-09-18 15:29:44 --> URI Class Initialized
INFO - 2020-09-18 15:29:44 --> Router Class Initialized
INFO - 2020-09-18 15:29:44 --> Output Class Initialized
INFO - 2020-09-18 15:29:44 --> Security Class Initialized
DEBUG - 2020-09-18 15:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:29:44 --> Input Class Initialized
INFO - 2020-09-18 15:29:44 --> Language Class Initialized
INFO - 2020-09-18 15:29:44 --> Loader Class Initialized
INFO - 2020-09-18 15:29:44 --> Helper loaded: url_helper
INFO - 2020-09-18 15:29:44 --> Database Driver Class Initialized
INFO - 2020-09-18 15:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:29:44 --> Email Class Initialized
INFO - 2020-09-18 15:29:44 --> Controller Class Initialized
DEBUG - 2020-09-18 15:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:29:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:29:44 --> Model Class Initialized
INFO - 2020-09-18 15:29:44 --> Model Class Initialized
INFO - 2020-09-18 15:29:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 15:29:44 --> Final output sent to browser
DEBUG - 2020-09-18 15:29:44 --> Total execution time: 0.0251
ERROR - 2020-09-18 15:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:29:50 --> Config Class Initialized
INFO - 2020-09-18 15:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:29:50 --> Utf8 Class Initialized
INFO - 2020-09-18 15:29:50 --> URI Class Initialized
INFO - 2020-09-18 15:29:50 --> Router Class Initialized
INFO - 2020-09-18 15:29:50 --> Output Class Initialized
INFO - 2020-09-18 15:29:50 --> Security Class Initialized
DEBUG - 2020-09-18 15:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:29:50 --> Input Class Initialized
INFO - 2020-09-18 15:29:50 --> Language Class Initialized
INFO - 2020-09-18 15:29:50 --> Loader Class Initialized
INFO - 2020-09-18 15:29:50 --> Helper loaded: url_helper
INFO - 2020-09-18 15:29:50 --> Database Driver Class Initialized
INFO - 2020-09-18 15:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:29:50 --> Email Class Initialized
INFO - 2020-09-18 15:29:50 --> Controller Class Initialized
DEBUG - 2020-09-18 15:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:29:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:29:50 --> Model Class Initialized
INFO - 2020-09-18 15:29:50 --> Model Class Initialized
INFO - 2020-09-18 15:29:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:29:50 --> Final output sent to browser
DEBUG - 2020-09-18 15:29:50 --> Total execution time: 0.0259
ERROR - 2020-09-18 15:30:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:30:35 --> Config Class Initialized
INFO - 2020-09-18 15:30:35 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:30:35 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:30:35 --> Utf8 Class Initialized
INFO - 2020-09-18 15:30:35 --> URI Class Initialized
DEBUG - 2020-09-18 15:30:35 --> No URI present. Default controller set.
INFO - 2020-09-18 15:30:35 --> Router Class Initialized
INFO - 2020-09-18 15:30:35 --> Output Class Initialized
INFO - 2020-09-18 15:30:35 --> Security Class Initialized
DEBUG - 2020-09-18 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:30:35 --> Input Class Initialized
INFO - 2020-09-18 15:30:35 --> Language Class Initialized
INFO - 2020-09-18 15:30:35 --> Loader Class Initialized
INFO - 2020-09-18 15:30:35 --> Helper loaded: url_helper
INFO - 2020-09-18 15:30:35 --> Database Driver Class Initialized
INFO - 2020-09-18 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:30:35 --> Email Class Initialized
INFO - 2020-09-18 15:30:35 --> Controller Class Initialized
INFO - 2020-09-18 15:30:35 --> Model Class Initialized
INFO - 2020-09-18 15:30:35 --> Model Class Initialized
DEBUG - 2020-09-18 15:30:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:30:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:30:35 --> Final output sent to browser
DEBUG - 2020-09-18 15:30:35 --> Total execution time: 0.0224
ERROR - 2020-09-18 15:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:30:38 --> Config Class Initialized
INFO - 2020-09-18 15:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:30:38 --> Utf8 Class Initialized
INFO - 2020-09-18 15:30:38 --> URI Class Initialized
INFO - 2020-09-18 15:30:38 --> Router Class Initialized
INFO - 2020-09-18 15:30:38 --> Output Class Initialized
INFO - 2020-09-18 15:30:38 --> Security Class Initialized
DEBUG - 2020-09-18 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:30:38 --> Input Class Initialized
INFO - 2020-09-18 15:30:38 --> Language Class Initialized
INFO - 2020-09-18 15:30:38 --> Loader Class Initialized
INFO - 2020-09-18 15:30:38 --> Helper loaded: url_helper
INFO - 2020-09-18 15:30:38 --> Database Driver Class Initialized
INFO - 2020-09-18 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:30:38 --> Email Class Initialized
INFO - 2020-09-18 15:30:38 --> Controller Class Initialized
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
DEBUG - 2020-09-18 15:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:30:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
INFO - 2020-09-18 15:30:38 --> Final output sent to browser
DEBUG - 2020-09-18 15:30:38 --> Total execution time: 0.0253
ERROR - 2020-09-18 15:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:30:38 --> Config Class Initialized
INFO - 2020-09-18 15:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:30:38 --> Utf8 Class Initialized
INFO - 2020-09-18 15:30:38 --> URI Class Initialized
INFO - 2020-09-18 15:30:38 --> Router Class Initialized
INFO - 2020-09-18 15:30:38 --> Output Class Initialized
INFO - 2020-09-18 15:30:38 --> Security Class Initialized
DEBUG - 2020-09-18 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:30:38 --> Input Class Initialized
INFO - 2020-09-18 15:30:38 --> Language Class Initialized
INFO - 2020-09-18 15:30:38 --> Loader Class Initialized
INFO - 2020-09-18 15:30:38 --> Helper loaded: url_helper
INFO - 2020-09-18 15:30:38 --> Database Driver Class Initialized
INFO - 2020-09-18 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:30:38 --> Email Class Initialized
INFO - 2020-09-18 15:30:38 --> Controller Class Initialized
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
DEBUG - 2020-09-18 15:30:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 15:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:30:38 --> Config Class Initialized
INFO - 2020-09-18 15:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:30:38 --> Utf8 Class Initialized
INFO - 2020-09-18 15:30:38 --> URI Class Initialized
INFO - 2020-09-18 15:30:38 --> Router Class Initialized
INFO - 2020-09-18 15:30:38 --> Output Class Initialized
INFO - 2020-09-18 15:30:38 --> Security Class Initialized
DEBUG - 2020-09-18 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:30:38 --> Input Class Initialized
INFO - 2020-09-18 15:30:38 --> Language Class Initialized
INFO - 2020-09-18 15:30:38 --> Loader Class Initialized
INFO - 2020-09-18 15:30:38 --> Helper loaded: url_helper
INFO - 2020-09-18 15:30:38 --> Database Driver Class Initialized
INFO - 2020-09-18 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:30:38 --> Email Class Initialized
INFO - 2020-09-18 15:30:38 --> Controller Class Initialized
DEBUG - 2020-09-18 15:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:30:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
INFO - 2020-09-18 15:30:38 --> Model Class Initialized
INFO - 2020-09-18 15:30:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-18 15:30:38 --> Final output sent to browser
DEBUG - 2020-09-18 15:30:38 --> Total execution time: 0.0218
ERROR - 2020-09-18 15:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:30:41 --> Config Class Initialized
INFO - 2020-09-18 15:30:41 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:30:41 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:30:41 --> Utf8 Class Initialized
INFO - 2020-09-18 15:30:41 --> URI Class Initialized
INFO - 2020-09-18 15:30:41 --> Router Class Initialized
INFO - 2020-09-18 15:30:41 --> Output Class Initialized
INFO - 2020-09-18 15:30:41 --> Security Class Initialized
DEBUG - 2020-09-18 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:30:41 --> Input Class Initialized
INFO - 2020-09-18 15:30:41 --> Language Class Initialized
INFO - 2020-09-18 15:30:41 --> Loader Class Initialized
INFO - 2020-09-18 15:30:41 --> Helper loaded: url_helper
INFO - 2020-09-18 15:30:41 --> Database Driver Class Initialized
INFO - 2020-09-18 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:30:41 --> Email Class Initialized
INFO - 2020-09-18 15:30:41 --> Controller Class Initialized
DEBUG - 2020-09-18 15:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:30:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:30:41 --> Model Class Initialized
INFO - 2020-09-18 15:30:41 --> Model Class Initialized
INFO - 2020-09-18 15:30:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-18 15:30:41 --> Final output sent to browser
DEBUG - 2020-09-18 15:30:41 --> Total execution time: 0.0220
ERROR - 2020-09-18 15:30:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:30:47 --> Config Class Initialized
INFO - 2020-09-18 15:30:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:30:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:30:47 --> Utf8 Class Initialized
INFO - 2020-09-18 15:30:47 --> URI Class Initialized
INFO - 2020-09-18 15:30:47 --> Router Class Initialized
INFO - 2020-09-18 15:30:47 --> Output Class Initialized
INFO - 2020-09-18 15:30:47 --> Security Class Initialized
DEBUG - 2020-09-18 15:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:30:47 --> Input Class Initialized
INFO - 2020-09-18 15:30:47 --> Language Class Initialized
INFO - 2020-09-18 15:30:47 --> Loader Class Initialized
INFO - 2020-09-18 15:30:47 --> Helper loaded: url_helper
INFO - 2020-09-18 15:30:47 --> Database Driver Class Initialized
INFO - 2020-09-18 15:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:30:47 --> Email Class Initialized
INFO - 2020-09-18 15:30:47 --> Controller Class Initialized
DEBUG - 2020-09-18 15:30:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:30:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:30:47 --> Model Class Initialized
INFO - 2020-09-18 15:30:47 --> Model Class Initialized
INFO - 2020-09-18 15:30:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-18 15:30:47 --> Final output sent to browser
DEBUG - 2020-09-18 15:30:47 --> Total execution time: 0.0249
ERROR - 2020-09-18 15:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:35:28 --> Config Class Initialized
INFO - 2020-09-18 15:35:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:35:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:35:28 --> Utf8 Class Initialized
INFO - 2020-09-18 15:35:28 --> URI Class Initialized
DEBUG - 2020-09-18 15:35:28 --> No URI present. Default controller set.
INFO - 2020-09-18 15:35:28 --> Router Class Initialized
INFO - 2020-09-18 15:35:28 --> Output Class Initialized
INFO - 2020-09-18 15:35:28 --> Security Class Initialized
DEBUG - 2020-09-18 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:35:28 --> Input Class Initialized
INFO - 2020-09-18 15:35:28 --> Language Class Initialized
INFO - 2020-09-18 15:35:28 --> Loader Class Initialized
INFO - 2020-09-18 15:35:28 --> Helper loaded: url_helper
INFO - 2020-09-18 15:35:28 --> Database Driver Class Initialized
INFO - 2020-09-18 15:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:35:28 --> Email Class Initialized
INFO - 2020-09-18 15:35:28 --> Controller Class Initialized
INFO - 2020-09-18 15:35:28 --> Model Class Initialized
INFO - 2020-09-18 15:35:28 --> Model Class Initialized
DEBUG - 2020-09-18 15:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:35:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 15:35:28 --> Final output sent to browser
DEBUG - 2020-09-18 15:35:28 --> Total execution time: 0.0211
ERROR - 2020-09-18 15:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:35:39 --> Config Class Initialized
INFO - 2020-09-18 15:35:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:35:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:35:39 --> Utf8 Class Initialized
INFO - 2020-09-18 15:35:39 --> URI Class Initialized
INFO - 2020-09-18 15:35:39 --> Router Class Initialized
INFO - 2020-09-18 15:35:39 --> Output Class Initialized
INFO - 2020-09-18 15:35:39 --> Security Class Initialized
DEBUG - 2020-09-18 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:35:39 --> Input Class Initialized
INFO - 2020-09-18 15:35:39 --> Language Class Initialized
INFO - 2020-09-18 15:35:39 --> Loader Class Initialized
INFO - 2020-09-18 15:35:39 --> Helper loaded: url_helper
INFO - 2020-09-18 15:35:39 --> Database Driver Class Initialized
INFO - 2020-09-18 15:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:35:39 --> Email Class Initialized
INFO - 2020-09-18 15:35:39 --> Controller Class Initialized
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
DEBUG - 2020-09-18 15:35:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-18 15:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:35:39 --> Config Class Initialized
INFO - 2020-09-18 15:35:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:35:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:35:39 --> Utf8 Class Initialized
INFO - 2020-09-18 15:35:39 --> URI Class Initialized
INFO - 2020-09-18 15:35:39 --> Router Class Initialized
INFO - 2020-09-18 15:35:39 --> Output Class Initialized
INFO - 2020-09-18 15:35:39 --> Security Class Initialized
DEBUG - 2020-09-18 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:35:39 --> Input Class Initialized
INFO - 2020-09-18 15:35:39 --> Language Class Initialized
INFO - 2020-09-18 15:35:39 --> Loader Class Initialized
INFO - 2020-09-18 15:35:39 --> Helper loaded: url_helper
INFO - 2020-09-18 15:35:39 --> Database Driver Class Initialized
INFO - 2020-09-18 15:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:35:39 --> Email Class Initialized
INFO - 2020-09-18 15:35:39 --> Controller Class Initialized
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
DEBUG - 2020-09-18 15:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:35:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
INFO - 2020-09-18 15:35:39 --> Final output sent to browser
DEBUG - 2020-09-18 15:35:39 --> Total execution time: 0.0245
ERROR - 2020-09-18 15:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:35:39 --> Config Class Initialized
INFO - 2020-09-18 15:35:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:35:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:35:39 --> Utf8 Class Initialized
INFO - 2020-09-18 15:35:39 --> URI Class Initialized
INFO - 2020-09-18 15:35:39 --> Router Class Initialized
INFO - 2020-09-18 15:35:39 --> Output Class Initialized
INFO - 2020-09-18 15:35:39 --> Security Class Initialized
DEBUG - 2020-09-18 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:35:39 --> Input Class Initialized
INFO - 2020-09-18 15:35:39 --> Language Class Initialized
INFO - 2020-09-18 15:35:39 --> Loader Class Initialized
INFO - 2020-09-18 15:35:39 --> Helper loaded: url_helper
INFO - 2020-09-18 15:35:39 --> Database Driver Class Initialized
INFO - 2020-09-18 15:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:35:39 --> Email Class Initialized
INFO - 2020-09-18 15:35:39 --> Controller Class Initialized
DEBUG - 2020-09-18 15:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:35:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
INFO - 2020-09-18 15:35:39 --> Model Class Initialized
INFO - 2020-09-18 15:35:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 15:35:39 --> Final output sent to browser
DEBUG - 2020-09-18 15:35:39 --> Total execution time: 0.0226
ERROR - 2020-09-18 15:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:35:45 --> Config Class Initialized
INFO - 2020-09-18 15:35:45 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:35:45 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:35:45 --> Utf8 Class Initialized
INFO - 2020-09-18 15:35:45 --> URI Class Initialized
INFO - 2020-09-18 15:35:45 --> Router Class Initialized
INFO - 2020-09-18 15:35:45 --> Output Class Initialized
INFO - 2020-09-18 15:35:45 --> Security Class Initialized
DEBUG - 2020-09-18 15:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:35:45 --> Input Class Initialized
INFO - 2020-09-18 15:35:45 --> Language Class Initialized
INFO - 2020-09-18 15:35:45 --> Loader Class Initialized
INFO - 2020-09-18 15:35:45 --> Helper loaded: url_helper
INFO - 2020-09-18 15:35:45 --> Database Driver Class Initialized
INFO - 2020-09-18 15:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:35:45 --> Email Class Initialized
INFO - 2020-09-18 15:35:45 --> Controller Class Initialized
DEBUG - 2020-09-18 15:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:35:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:35:45 --> Model Class Initialized
INFO - 2020-09-18 15:35:45 --> Model Class Initialized
INFO - 2020-09-18 15:35:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:35:45 --> Final output sent to browser
DEBUG - 2020-09-18 15:35:45 --> Total execution time: 0.0237
ERROR - 2020-09-18 15:36:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:36:25 --> Config Class Initialized
INFO - 2020-09-18 15:36:25 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:36:25 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:36:25 --> Utf8 Class Initialized
INFO - 2020-09-18 15:36:25 --> URI Class Initialized
INFO - 2020-09-18 15:36:25 --> Router Class Initialized
INFO - 2020-09-18 15:36:25 --> Output Class Initialized
INFO - 2020-09-18 15:36:25 --> Security Class Initialized
DEBUG - 2020-09-18 15:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:36:25 --> Input Class Initialized
INFO - 2020-09-18 15:36:25 --> Language Class Initialized
INFO - 2020-09-18 15:36:25 --> Loader Class Initialized
INFO - 2020-09-18 15:36:25 --> Helper loaded: url_helper
INFO - 2020-09-18 15:36:25 --> Database Driver Class Initialized
INFO - 2020-09-18 15:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:36:25 --> Email Class Initialized
INFO - 2020-09-18 15:36:25 --> Controller Class Initialized
DEBUG - 2020-09-18 15:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:36:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:36:25 --> Model Class Initialized
INFO - 2020-09-18 15:36:25 --> Model Class Initialized
INFO - 2020-09-18 15:36:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:36:25 --> Final output sent to browser
DEBUG - 2020-09-18 15:36:25 --> Total execution time: 0.0238
ERROR - 2020-09-18 15:36:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:36:31 --> Config Class Initialized
INFO - 2020-09-18 15:36:31 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:36:31 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:36:31 --> Utf8 Class Initialized
INFO - 2020-09-18 15:36:31 --> URI Class Initialized
INFO - 2020-09-18 15:36:31 --> Router Class Initialized
INFO - 2020-09-18 15:36:31 --> Output Class Initialized
INFO - 2020-09-18 15:36:31 --> Security Class Initialized
DEBUG - 2020-09-18 15:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:36:31 --> Input Class Initialized
INFO - 2020-09-18 15:36:31 --> Language Class Initialized
INFO - 2020-09-18 15:36:31 --> Loader Class Initialized
INFO - 2020-09-18 15:36:31 --> Helper loaded: url_helper
INFO - 2020-09-18 15:36:31 --> Database Driver Class Initialized
INFO - 2020-09-18 15:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:36:31 --> Email Class Initialized
INFO - 2020-09-18 15:36:31 --> Controller Class Initialized
DEBUG - 2020-09-18 15:36:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:36:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:36:31 --> Model Class Initialized
INFO - 2020-09-18 15:36:31 --> Model Class Initialized
INFO - 2020-09-18 15:36:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:36:31 --> Final output sent to browser
DEBUG - 2020-09-18 15:36:31 --> Total execution time: 0.0246
ERROR - 2020-09-18 15:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:37:10 --> Config Class Initialized
INFO - 2020-09-18 15:37:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:37:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:37:10 --> Utf8 Class Initialized
INFO - 2020-09-18 15:37:10 --> URI Class Initialized
INFO - 2020-09-18 15:37:10 --> Router Class Initialized
INFO - 2020-09-18 15:37:10 --> Output Class Initialized
INFO - 2020-09-18 15:37:10 --> Security Class Initialized
DEBUG - 2020-09-18 15:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:37:10 --> Input Class Initialized
INFO - 2020-09-18 15:37:10 --> Language Class Initialized
INFO - 2020-09-18 15:37:10 --> Loader Class Initialized
INFO - 2020-09-18 15:37:10 --> Helper loaded: url_helper
INFO - 2020-09-18 15:37:10 --> Database Driver Class Initialized
INFO - 2020-09-18 15:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:37:10 --> Email Class Initialized
INFO - 2020-09-18 15:37:10 --> Controller Class Initialized
DEBUG - 2020-09-18 15:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:37:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:37:10 --> Model Class Initialized
INFO - 2020-09-18 15:37:10 --> Model Class Initialized
INFO - 2020-09-18 15:37:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:37:10 --> Final output sent to browser
DEBUG - 2020-09-18 15:37:10 --> Total execution time: 0.0283
ERROR - 2020-09-18 15:38:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:38:27 --> Config Class Initialized
INFO - 2020-09-18 15:38:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:38:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:38:27 --> Utf8 Class Initialized
INFO - 2020-09-18 15:38:27 --> URI Class Initialized
INFO - 2020-09-18 15:38:27 --> Router Class Initialized
INFO - 2020-09-18 15:38:27 --> Output Class Initialized
INFO - 2020-09-18 15:38:27 --> Security Class Initialized
DEBUG - 2020-09-18 15:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:38:27 --> Input Class Initialized
INFO - 2020-09-18 15:38:27 --> Language Class Initialized
INFO - 2020-09-18 15:38:27 --> Loader Class Initialized
INFO - 2020-09-18 15:38:27 --> Helper loaded: url_helper
INFO - 2020-09-18 15:38:27 --> Database Driver Class Initialized
INFO - 2020-09-18 15:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:38:27 --> Email Class Initialized
INFO - 2020-09-18 15:38:27 --> Controller Class Initialized
DEBUG - 2020-09-18 15:38:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:38:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:38:27 --> Model Class Initialized
INFO - 2020-09-18 15:38:27 --> Model Class Initialized
INFO - 2020-09-18 15:38:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:38:27 --> Final output sent to browser
DEBUG - 2020-09-18 15:38:27 --> Total execution time: 0.0235
ERROR - 2020-09-18 15:39:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:39:08 --> Config Class Initialized
INFO - 2020-09-18 15:39:08 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:39:08 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:39:08 --> Utf8 Class Initialized
INFO - 2020-09-18 15:39:08 --> URI Class Initialized
INFO - 2020-09-18 15:39:08 --> Router Class Initialized
INFO - 2020-09-18 15:39:08 --> Output Class Initialized
INFO - 2020-09-18 15:39:08 --> Security Class Initialized
DEBUG - 2020-09-18 15:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:39:08 --> Input Class Initialized
INFO - 2020-09-18 15:39:08 --> Language Class Initialized
INFO - 2020-09-18 15:39:08 --> Loader Class Initialized
INFO - 2020-09-18 15:39:08 --> Helper loaded: url_helper
INFO - 2020-09-18 15:39:08 --> Database Driver Class Initialized
INFO - 2020-09-18 15:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:39:08 --> Email Class Initialized
INFO - 2020-09-18 15:39:08 --> Controller Class Initialized
DEBUG - 2020-09-18 15:39:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:39:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:39:08 --> Model Class Initialized
INFO - 2020-09-18 15:39:08 --> Model Class Initialized
INFO - 2020-09-18 15:39:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:39:08 --> Final output sent to browser
DEBUG - 2020-09-18 15:39:08 --> Total execution time: 0.0236
ERROR - 2020-09-18 15:39:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:39:29 --> Config Class Initialized
INFO - 2020-09-18 15:39:29 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:39:29 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:39:29 --> Utf8 Class Initialized
INFO - 2020-09-18 15:39:29 --> URI Class Initialized
INFO - 2020-09-18 15:39:29 --> Router Class Initialized
INFO - 2020-09-18 15:39:29 --> Output Class Initialized
INFO - 2020-09-18 15:39:29 --> Security Class Initialized
DEBUG - 2020-09-18 15:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:39:29 --> Input Class Initialized
INFO - 2020-09-18 15:39:29 --> Language Class Initialized
INFO - 2020-09-18 15:39:29 --> Loader Class Initialized
INFO - 2020-09-18 15:39:29 --> Helper loaded: url_helper
INFO - 2020-09-18 15:39:29 --> Database Driver Class Initialized
INFO - 2020-09-18 15:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:39:29 --> Email Class Initialized
INFO - 2020-09-18 15:39:29 --> Controller Class Initialized
DEBUG - 2020-09-18 15:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:39:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:39:29 --> Model Class Initialized
INFO - 2020-09-18 15:39:29 --> Model Class Initialized
INFO - 2020-09-18 15:39:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:39:29 --> Final output sent to browser
DEBUG - 2020-09-18 15:39:29 --> Total execution time: 0.0263
ERROR - 2020-09-18 15:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:39:31 --> Config Class Initialized
INFO - 2020-09-18 15:39:31 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:39:31 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:39:31 --> Utf8 Class Initialized
INFO - 2020-09-18 15:39:31 --> URI Class Initialized
INFO - 2020-09-18 15:39:31 --> Router Class Initialized
INFO - 2020-09-18 15:39:31 --> Output Class Initialized
INFO - 2020-09-18 15:39:31 --> Security Class Initialized
DEBUG - 2020-09-18 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:39:31 --> Input Class Initialized
INFO - 2020-09-18 15:39:31 --> Language Class Initialized
INFO - 2020-09-18 15:39:31 --> Loader Class Initialized
INFO - 2020-09-18 15:39:31 --> Helper loaded: url_helper
INFO - 2020-09-18 15:39:31 --> Database Driver Class Initialized
INFO - 2020-09-18 15:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:39:31 --> Email Class Initialized
INFO - 2020-09-18 15:39:31 --> Controller Class Initialized
DEBUG - 2020-09-18 15:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:39:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:39:31 --> Model Class Initialized
INFO - 2020-09-18 15:39:31 --> Model Class Initialized
INFO - 2020-09-18 15:39:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:39:31 --> Final output sent to browser
DEBUG - 2020-09-18 15:39:31 --> Total execution time: 0.2252
ERROR - 2020-09-18 15:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:40:55 --> Config Class Initialized
INFO - 2020-09-18 15:40:55 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:40:55 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:40:55 --> Utf8 Class Initialized
INFO - 2020-09-18 15:40:55 --> URI Class Initialized
INFO - 2020-09-18 15:40:55 --> Router Class Initialized
INFO - 2020-09-18 15:40:55 --> Output Class Initialized
INFO - 2020-09-18 15:40:55 --> Security Class Initialized
DEBUG - 2020-09-18 15:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:40:55 --> Input Class Initialized
INFO - 2020-09-18 15:40:55 --> Language Class Initialized
INFO - 2020-09-18 15:40:55 --> Loader Class Initialized
INFO - 2020-09-18 15:40:55 --> Helper loaded: url_helper
INFO - 2020-09-18 15:40:55 --> Database Driver Class Initialized
INFO - 2020-09-18 15:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:40:55 --> Email Class Initialized
INFO - 2020-09-18 15:40:55 --> Controller Class Initialized
DEBUG - 2020-09-18 15:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:40:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:40:55 --> Model Class Initialized
INFO - 2020-09-18 15:40:55 --> Model Class Initialized
INFO - 2020-09-18 15:40:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:40:55 --> Final output sent to browser
DEBUG - 2020-09-18 15:40:55 --> Total execution time: 0.0218
ERROR - 2020-09-18 15:42:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:42:58 --> Config Class Initialized
INFO - 2020-09-18 15:42:58 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:42:58 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:42:58 --> Utf8 Class Initialized
INFO - 2020-09-18 15:42:58 --> URI Class Initialized
INFO - 2020-09-18 15:42:58 --> Router Class Initialized
INFO - 2020-09-18 15:42:58 --> Output Class Initialized
INFO - 2020-09-18 15:42:58 --> Security Class Initialized
DEBUG - 2020-09-18 15:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:42:58 --> Input Class Initialized
INFO - 2020-09-18 15:42:58 --> Language Class Initialized
INFO - 2020-09-18 15:42:58 --> Loader Class Initialized
INFO - 2020-09-18 15:42:58 --> Helper loaded: url_helper
INFO - 2020-09-18 15:42:58 --> Database Driver Class Initialized
INFO - 2020-09-18 15:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:42:58 --> Email Class Initialized
INFO - 2020-09-18 15:42:58 --> Controller Class Initialized
DEBUG - 2020-09-18 15:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:42:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:42:58 --> Model Class Initialized
INFO - 2020-09-18 15:42:58 --> Model Class Initialized
INFO - 2020-09-18 15:42:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:42:58 --> Final output sent to browser
DEBUG - 2020-09-18 15:42:58 --> Total execution time: 0.0215
ERROR - 2020-09-18 15:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:43:06 --> Config Class Initialized
INFO - 2020-09-18 15:43:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:43:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:43:06 --> Utf8 Class Initialized
INFO - 2020-09-18 15:43:06 --> URI Class Initialized
INFO - 2020-09-18 15:43:06 --> Router Class Initialized
INFO - 2020-09-18 15:43:06 --> Output Class Initialized
INFO - 2020-09-18 15:43:06 --> Security Class Initialized
DEBUG - 2020-09-18 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:43:06 --> Input Class Initialized
INFO - 2020-09-18 15:43:06 --> Language Class Initialized
INFO - 2020-09-18 15:43:06 --> Loader Class Initialized
INFO - 2020-09-18 15:43:06 --> Helper loaded: url_helper
INFO - 2020-09-18 15:43:06 --> Database Driver Class Initialized
INFO - 2020-09-18 15:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:43:06 --> Email Class Initialized
INFO - 2020-09-18 15:43:06 --> Controller Class Initialized
DEBUG - 2020-09-18 15:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:43:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:43:06 --> Model Class Initialized
INFO - 2020-09-18 15:43:06 --> Model Class Initialized
INFO - 2020-09-18 15:43:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:43:06 --> Final output sent to browser
DEBUG - 2020-09-18 15:43:06 --> Total execution time: 0.0252
ERROR - 2020-09-18 15:43:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:43:08 --> Config Class Initialized
INFO - 2020-09-18 15:43:08 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:43:08 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:43:08 --> Utf8 Class Initialized
INFO - 2020-09-18 15:43:08 --> URI Class Initialized
INFO - 2020-09-18 15:43:08 --> Router Class Initialized
INFO - 2020-09-18 15:43:08 --> Output Class Initialized
INFO - 2020-09-18 15:43:08 --> Security Class Initialized
DEBUG - 2020-09-18 15:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:43:08 --> Input Class Initialized
INFO - 2020-09-18 15:43:08 --> Language Class Initialized
INFO - 2020-09-18 15:43:08 --> Loader Class Initialized
INFO - 2020-09-18 15:43:08 --> Helper loaded: url_helper
INFO - 2020-09-18 15:43:08 --> Database Driver Class Initialized
INFO - 2020-09-18 15:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:43:08 --> Email Class Initialized
INFO - 2020-09-18 15:43:08 --> Controller Class Initialized
DEBUG - 2020-09-18 15:43:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:43:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:43:08 --> Model Class Initialized
INFO - 2020-09-18 15:43:08 --> Model Class Initialized
INFO - 2020-09-18 15:43:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:43:08 --> Final output sent to browser
DEBUG - 2020-09-18 15:43:08 --> Total execution time: 0.0245
ERROR - 2020-09-18 15:43:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:43:12 --> Config Class Initialized
INFO - 2020-09-18 15:43:12 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:43:12 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:43:12 --> Utf8 Class Initialized
INFO - 2020-09-18 15:43:12 --> URI Class Initialized
INFO - 2020-09-18 15:43:12 --> Router Class Initialized
INFO - 2020-09-18 15:43:12 --> Output Class Initialized
INFO - 2020-09-18 15:43:12 --> Security Class Initialized
DEBUG - 2020-09-18 15:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:43:12 --> Input Class Initialized
INFO - 2020-09-18 15:43:12 --> Language Class Initialized
INFO - 2020-09-18 15:43:12 --> Loader Class Initialized
INFO - 2020-09-18 15:43:12 --> Helper loaded: url_helper
INFO - 2020-09-18 15:43:12 --> Database Driver Class Initialized
INFO - 2020-09-18 15:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:43:12 --> Email Class Initialized
INFO - 2020-09-18 15:43:12 --> Controller Class Initialized
DEBUG - 2020-09-18 15:43:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:43:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:43:12 --> Model Class Initialized
INFO - 2020-09-18 15:43:12 --> Model Class Initialized
INFO - 2020-09-18 15:43:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 15:43:12 --> Final output sent to browser
DEBUG - 2020-09-18 15:43:12 --> Total execution time: 0.0205
ERROR - 2020-09-18 15:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:43:15 --> Config Class Initialized
INFO - 2020-09-18 15:43:15 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:43:15 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:43:15 --> Utf8 Class Initialized
INFO - 2020-09-18 15:43:15 --> URI Class Initialized
INFO - 2020-09-18 15:43:15 --> Router Class Initialized
INFO - 2020-09-18 15:43:15 --> Output Class Initialized
INFO - 2020-09-18 15:43:15 --> Security Class Initialized
DEBUG - 2020-09-18 15:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:43:15 --> Input Class Initialized
INFO - 2020-09-18 15:43:15 --> Language Class Initialized
INFO - 2020-09-18 15:43:15 --> Loader Class Initialized
INFO - 2020-09-18 15:43:15 --> Helper loaded: url_helper
INFO - 2020-09-18 15:43:15 --> Database Driver Class Initialized
INFO - 2020-09-18 15:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:43:15 --> Email Class Initialized
INFO - 2020-09-18 15:43:15 --> Controller Class Initialized
DEBUG - 2020-09-18 15:43:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:43:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:43:15 --> Model Class Initialized
INFO - 2020-09-18 15:43:15 --> Model Class Initialized
INFO - 2020-09-18 15:43:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:43:15 --> Final output sent to browser
DEBUG - 2020-09-18 15:43:15 --> Total execution time: 0.0234
ERROR - 2020-09-18 15:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:43:40 --> Config Class Initialized
INFO - 2020-09-18 15:43:40 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:43:40 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:43:40 --> Utf8 Class Initialized
INFO - 2020-09-18 15:43:40 --> URI Class Initialized
INFO - 2020-09-18 15:43:40 --> Router Class Initialized
INFO - 2020-09-18 15:43:40 --> Output Class Initialized
INFO - 2020-09-18 15:43:40 --> Security Class Initialized
DEBUG - 2020-09-18 15:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:43:40 --> Input Class Initialized
INFO - 2020-09-18 15:43:40 --> Language Class Initialized
INFO - 2020-09-18 15:43:40 --> Loader Class Initialized
INFO - 2020-09-18 15:43:40 --> Helper loaded: url_helper
INFO - 2020-09-18 15:43:40 --> Database Driver Class Initialized
INFO - 2020-09-18 15:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:43:40 --> Email Class Initialized
INFO - 2020-09-18 15:43:40 --> Controller Class Initialized
DEBUG - 2020-09-18 15:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:43:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:43:40 --> Model Class Initialized
INFO - 2020-09-18 15:43:40 --> Model Class Initialized
INFO - 2020-09-18 15:43:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:43:40 --> Final output sent to browser
DEBUG - 2020-09-18 15:43:40 --> Total execution time: 0.0254
ERROR - 2020-09-18 15:47:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:47:58 --> Config Class Initialized
INFO - 2020-09-18 15:47:58 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:47:58 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:47:58 --> Utf8 Class Initialized
INFO - 2020-09-18 15:47:58 --> URI Class Initialized
INFO - 2020-09-18 15:47:58 --> Router Class Initialized
INFO - 2020-09-18 15:47:58 --> Output Class Initialized
INFO - 2020-09-18 15:47:58 --> Security Class Initialized
DEBUG - 2020-09-18 15:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:47:58 --> Input Class Initialized
INFO - 2020-09-18 15:47:58 --> Language Class Initialized
INFO - 2020-09-18 15:47:58 --> Loader Class Initialized
INFO - 2020-09-18 15:47:58 --> Helper loaded: url_helper
INFO - 2020-09-18 15:47:58 --> Database Driver Class Initialized
INFO - 2020-09-18 15:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:47:58 --> Email Class Initialized
INFO - 2020-09-18 15:47:58 --> Controller Class Initialized
DEBUG - 2020-09-18 15:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:47:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:47:58 --> Model Class Initialized
INFO - 2020-09-18 15:47:58 --> Model Class Initialized
INFO - 2020-09-18 15:47:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:47:58 --> Final output sent to browser
DEBUG - 2020-09-18 15:47:58 --> Total execution time: 0.0222
ERROR - 2020-09-18 15:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:48:02 --> Config Class Initialized
INFO - 2020-09-18 15:48:02 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:48:02 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:48:02 --> Utf8 Class Initialized
INFO - 2020-09-18 15:48:02 --> URI Class Initialized
INFO - 2020-09-18 15:48:02 --> Router Class Initialized
INFO - 2020-09-18 15:48:02 --> Output Class Initialized
INFO - 2020-09-18 15:48:02 --> Security Class Initialized
DEBUG - 2020-09-18 15:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:48:02 --> Input Class Initialized
INFO - 2020-09-18 15:48:02 --> Language Class Initialized
INFO - 2020-09-18 15:48:02 --> Loader Class Initialized
INFO - 2020-09-18 15:48:02 --> Helper loaded: url_helper
INFO - 2020-09-18 15:48:02 --> Database Driver Class Initialized
INFO - 2020-09-18 15:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:48:02 --> Email Class Initialized
INFO - 2020-09-18 15:48:02 --> Controller Class Initialized
DEBUG - 2020-09-18 15:48:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:48:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:48:02 --> Model Class Initialized
INFO - 2020-09-18 15:48:02 --> Model Class Initialized
INFO - 2020-09-18 15:48:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:48:02 --> Final output sent to browser
DEBUG - 2020-09-18 15:48:02 --> Total execution time: 0.0255
ERROR - 2020-09-18 15:48:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:48:18 --> Config Class Initialized
INFO - 2020-09-18 15:48:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:48:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:48:18 --> Utf8 Class Initialized
INFO - 2020-09-18 15:48:18 --> URI Class Initialized
INFO - 2020-09-18 15:48:18 --> Router Class Initialized
INFO - 2020-09-18 15:48:18 --> Output Class Initialized
INFO - 2020-09-18 15:48:18 --> Security Class Initialized
DEBUG - 2020-09-18 15:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:48:18 --> Input Class Initialized
INFO - 2020-09-18 15:48:18 --> Language Class Initialized
INFO - 2020-09-18 15:48:18 --> Loader Class Initialized
INFO - 2020-09-18 15:48:18 --> Helper loaded: url_helper
INFO - 2020-09-18 15:48:18 --> Database Driver Class Initialized
INFO - 2020-09-18 15:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:48:18 --> Email Class Initialized
INFO - 2020-09-18 15:48:18 --> Controller Class Initialized
DEBUG - 2020-09-18 15:48:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:48:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:48:18 --> Model Class Initialized
INFO - 2020-09-18 15:48:18 --> Model Class Initialized
INFO - 2020-09-18 15:48:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:48:18 --> Final output sent to browser
DEBUG - 2020-09-18 15:48:18 --> Total execution time: 0.0249
ERROR - 2020-09-18 15:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:52:24 --> Config Class Initialized
INFO - 2020-09-18 15:52:24 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:52:24 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:52:24 --> Utf8 Class Initialized
INFO - 2020-09-18 15:52:24 --> URI Class Initialized
INFO - 2020-09-18 15:52:24 --> Router Class Initialized
INFO - 2020-09-18 15:52:24 --> Output Class Initialized
INFO - 2020-09-18 15:52:24 --> Security Class Initialized
DEBUG - 2020-09-18 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:52:24 --> Input Class Initialized
INFO - 2020-09-18 15:52:24 --> Language Class Initialized
INFO - 2020-09-18 15:52:24 --> Loader Class Initialized
INFO - 2020-09-18 15:52:24 --> Helper loaded: url_helper
INFO - 2020-09-18 15:52:24 --> Database Driver Class Initialized
INFO - 2020-09-18 15:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:52:24 --> Email Class Initialized
INFO - 2020-09-18 15:52:24 --> Controller Class Initialized
DEBUG - 2020-09-18 15:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:52:24 --> Model Class Initialized
INFO - 2020-09-18 15:52:24 --> Model Class Initialized
INFO - 2020-09-18 15:52:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:52:24 --> Final output sent to browser
DEBUG - 2020-09-18 15:52:24 --> Total execution time: 0.0305
ERROR - 2020-09-18 15:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:53:15 --> Config Class Initialized
INFO - 2020-09-18 15:53:15 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:53:15 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:53:15 --> Utf8 Class Initialized
INFO - 2020-09-18 15:53:15 --> URI Class Initialized
INFO - 2020-09-18 15:53:15 --> Router Class Initialized
INFO - 2020-09-18 15:53:15 --> Output Class Initialized
INFO - 2020-09-18 15:53:15 --> Security Class Initialized
DEBUG - 2020-09-18 15:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:53:15 --> Input Class Initialized
INFO - 2020-09-18 15:53:15 --> Language Class Initialized
INFO - 2020-09-18 15:53:15 --> Loader Class Initialized
INFO - 2020-09-18 15:53:15 --> Helper loaded: url_helper
INFO - 2020-09-18 15:53:15 --> Database Driver Class Initialized
INFO - 2020-09-18 15:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:53:15 --> Email Class Initialized
INFO - 2020-09-18 15:53:15 --> Controller Class Initialized
DEBUG - 2020-09-18 15:53:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:53:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:53:15 --> Model Class Initialized
INFO - 2020-09-18 15:53:15 --> Model Class Initialized
INFO - 2020-09-18 15:53:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:53:15 --> Final output sent to browser
DEBUG - 2020-09-18 15:53:15 --> Total execution time: 0.0225
ERROR - 2020-09-18 15:53:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:53:26 --> Config Class Initialized
INFO - 2020-09-18 15:53:26 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:53:26 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:53:26 --> Utf8 Class Initialized
INFO - 2020-09-18 15:53:26 --> URI Class Initialized
INFO - 2020-09-18 15:53:26 --> Router Class Initialized
INFO - 2020-09-18 15:53:26 --> Output Class Initialized
INFO - 2020-09-18 15:53:26 --> Security Class Initialized
DEBUG - 2020-09-18 15:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:53:26 --> Input Class Initialized
INFO - 2020-09-18 15:53:26 --> Language Class Initialized
INFO - 2020-09-18 15:53:26 --> Loader Class Initialized
INFO - 2020-09-18 15:53:26 --> Helper loaded: url_helper
INFO - 2020-09-18 15:53:26 --> Database Driver Class Initialized
INFO - 2020-09-18 15:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:53:26 --> Email Class Initialized
INFO - 2020-09-18 15:53:26 --> Controller Class Initialized
DEBUG - 2020-09-18 15:53:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:53:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:53:26 --> Model Class Initialized
INFO - 2020-09-18 15:53:26 --> Model Class Initialized
INFO - 2020-09-18 15:53:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:53:26 --> Final output sent to browser
DEBUG - 2020-09-18 15:53:26 --> Total execution time: 0.0252
ERROR - 2020-09-18 15:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:54:30 --> Config Class Initialized
INFO - 2020-09-18 15:54:30 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:54:30 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:54:30 --> Utf8 Class Initialized
INFO - 2020-09-18 15:54:30 --> URI Class Initialized
INFO - 2020-09-18 15:54:30 --> Router Class Initialized
INFO - 2020-09-18 15:54:30 --> Output Class Initialized
INFO - 2020-09-18 15:54:30 --> Security Class Initialized
DEBUG - 2020-09-18 15:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:54:30 --> Input Class Initialized
INFO - 2020-09-18 15:54:30 --> Language Class Initialized
INFO - 2020-09-18 15:54:30 --> Loader Class Initialized
INFO - 2020-09-18 15:54:30 --> Helper loaded: url_helper
INFO - 2020-09-18 15:54:30 --> Database Driver Class Initialized
INFO - 2020-09-18 15:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:54:30 --> Email Class Initialized
INFO - 2020-09-18 15:54:30 --> Controller Class Initialized
DEBUG - 2020-09-18 15:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:54:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:54:30 --> Model Class Initialized
INFO - 2020-09-18 15:54:30 --> Model Class Initialized
INFO - 2020-09-18 15:54:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:54:30 --> Final output sent to browser
DEBUG - 2020-09-18 15:54:30 --> Total execution time: 0.0289
ERROR - 2020-09-18 15:54:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:54:38 --> Config Class Initialized
INFO - 2020-09-18 15:54:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:54:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:54:38 --> Utf8 Class Initialized
INFO - 2020-09-18 15:54:38 --> URI Class Initialized
INFO - 2020-09-18 15:54:38 --> Router Class Initialized
INFO - 2020-09-18 15:54:38 --> Output Class Initialized
INFO - 2020-09-18 15:54:38 --> Security Class Initialized
DEBUG - 2020-09-18 15:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:54:38 --> Input Class Initialized
INFO - 2020-09-18 15:54:38 --> Language Class Initialized
INFO - 2020-09-18 15:54:38 --> Loader Class Initialized
INFO - 2020-09-18 15:54:38 --> Helper loaded: url_helper
INFO - 2020-09-18 15:54:38 --> Database Driver Class Initialized
INFO - 2020-09-18 15:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:54:38 --> Email Class Initialized
INFO - 2020-09-18 15:54:38 --> Controller Class Initialized
DEBUG - 2020-09-18 15:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:54:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:54:38 --> Model Class Initialized
INFO - 2020-09-18 15:54:38 --> Model Class Initialized
INFO - 2020-09-18 15:54:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:54:38 --> Final output sent to browser
DEBUG - 2020-09-18 15:54:38 --> Total execution time: 0.0271
ERROR - 2020-09-18 15:54:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:54:47 --> Config Class Initialized
INFO - 2020-09-18 15:54:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:54:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:54:47 --> Utf8 Class Initialized
INFO - 2020-09-18 15:54:47 --> URI Class Initialized
INFO - 2020-09-18 15:54:47 --> Router Class Initialized
INFO - 2020-09-18 15:54:47 --> Output Class Initialized
INFO - 2020-09-18 15:54:47 --> Security Class Initialized
DEBUG - 2020-09-18 15:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:54:47 --> Input Class Initialized
INFO - 2020-09-18 15:54:47 --> Language Class Initialized
INFO - 2020-09-18 15:54:47 --> Loader Class Initialized
INFO - 2020-09-18 15:54:48 --> Helper loaded: url_helper
INFO - 2020-09-18 15:54:48 --> Database Driver Class Initialized
INFO - 2020-09-18 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:54:48 --> Email Class Initialized
INFO - 2020-09-18 15:54:48 --> Controller Class Initialized
DEBUG - 2020-09-18 15:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:54:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:54:48 --> Model Class Initialized
INFO - 2020-09-18 15:54:48 --> Model Class Initialized
INFO - 2020-09-18 15:54:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:54:48 --> Final output sent to browser
DEBUG - 2020-09-18 15:54:48 --> Total execution time: 0.0261
ERROR - 2020-09-18 15:54:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:54:55 --> Config Class Initialized
INFO - 2020-09-18 15:54:55 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:54:55 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:54:55 --> Utf8 Class Initialized
INFO - 2020-09-18 15:54:55 --> URI Class Initialized
INFO - 2020-09-18 15:54:55 --> Router Class Initialized
INFO - 2020-09-18 15:54:55 --> Output Class Initialized
INFO - 2020-09-18 15:54:55 --> Security Class Initialized
DEBUG - 2020-09-18 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:54:55 --> Input Class Initialized
INFO - 2020-09-18 15:54:55 --> Language Class Initialized
INFO - 2020-09-18 15:54:55 --> Loader Class Initialized
INFO - 2020-09-18 15:54:55 --> Helper loaded: url_helper
INFO - 2020-09-18 15:54:55 --> Database Driver Class Initialized
INFO - 2020-09-18 15:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:54:55 --> Email Class Initialized
INFO - 2020-09-18 15:54:55 --> Controller Class Initialized
DEBUG - 2020-09-18 15:54:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:54:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:54:55 --> Model Class Initialized
INFO - 2020-09-18 15:54:55 --> Model Class Initialized
INFO - 2020-09-18 15:54:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 15:54:55 --> Final output sent to browser
DEBUG - 2020-09-18 15:54:55 --> Total execution time: 0.0206
ERROR - 2020-09-18 15:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 15:55:01 --> Config Class Initialized
INFO - 2020-09-18 15:55:01 --> Hooks Class Initialized
DEBUG - 2020-09-18 15:55:01 --> UTF-8 Support Enabled
INFO - 2020-09-18 15:55:01 --> Utf8 Class Initialized
INFO - 2020-09-18 15:55:01 --> URI Class Initialized
INFO - 2020-09-18 15:55:01 --> Router Class Initialized
INFO - 2020-09-18 15:55:01 --> Output Class Initialized
INFO - 2020-09-18 15:55:01 --> Security Class Initialized
DEBUG - 2020-09-18 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 15:55:01 --> Input Class Initialized
INFO - 2020-09-18 15:55:01 --> Language Class Initialized
INFO - 2020-09-18 15:55:01 --> Loader Class Initialized
INFO - 2020-09-18 15:55:01 --> Helper loaded: url_helper
INFO - 2020-09-18 15:55:01 --> Database Driver Class Initialized
INFO - 2020-09-18 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 15:55:01 --> Email Class Initialized
INFO - 2020-09-18 15:55:01 --> Controller Class Initialized
DEBUG - 2020-09-18 15:55:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 15:55:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 15:55:01 --> Model Class Initialized
INFO - 2020-09-18 15:55:01 --> Model Class Initialized
INFO - 2020-09-18 15:55:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 15:55:01 --> Final output sent to browser
DEBUG - 2020-09-18 15:55:01 --> Total execution time: 0.0263
ERROR - 2020-09-18 16:10:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:10:10 --> Config Class Initialized
INFO - 2020-09-18 16:10:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:10:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:10:10 --> Utf8 Class Initialized
INFO - 2020-09-18 16:10:10 --> URI Class Initialized
INFO - 2020-09-18 16:10:10 --> Router Class Initialized
INFO - 2020-09-18 16:10:10 --> Output Class Initialized
INFO - 2020-09-18 16:10:10 --> Security Class Initialized
DEBUG - 2020-09-18 16:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:10:10 --> Input Class Initialized
INFO - 2020-09-18 16:10:10 --> Language Class Initialized
INFO - 2020-09-18 16:10:10 --> Loader Class Initialized
INFO - 2020-09-18 16:10:10 --> Helper loaded: url_helper
INFO - 2020-09-18 16:10:10 --> Database Driver Class Initialized
INFO - 2020-09-18 16:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:10:10 --> Email Class Initialized
INFO - 2020-09-18 16:10:10 --> Controller Class Initialized
DEBUG - 2020-09-18 16:10:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:10:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:10:10 --> Model Class Initialized
INFO - 2020-09-18 16:10:10 --> Model Class Initialized
INFO - 2020-09-18 16:10:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:10:10 --> Final output sent to browser
DEBUG - 2020-09-18 16:10:10 --> Total execution time: 0.0271
ERROR - 2020-09-18 16:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:10:20 --> Config Class Initialized
INFO - 2020-09-18 16:10:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:10:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:10:20 --> Utf8 Class Initialized
INFO - 2020-09-18 16:10:20 --> URI Class Initialized
INFO - 2020-09-18 16:10:20 --> Router Class Initialized
INFO - 2020-09-18 16:10:20 --> Output Class Initialized
INFO - 2020-09-18 16:10:20 --> Security Class Initialized
DEBUG - 2020-09-18 16:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:10:20 --> Input Class Initialized
INFO - 2020-09-18 16:10:20 --> Language Class Initialized
INFO - 2020-09-18 16:10:20 --> Loader Class Initialized
INFO - 2020-09-18 16:10:20 --> Helper loaded: url_helper
INFO - 2020-09-18 16:10:20 --> Database Driver Class Initialized
INFO - 2020-09-18 16:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:10:20 --> Email Class Initialized
INFO - 2020-09-18 16:10:20 --> Controller Class Initialized
DEBUG - 2020-09-18 16:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:10:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:10:20 --> Model Class Initialized
INFO - 2020-09-18 16:10:20 --> Model Class Initialized
INFO - 2020-09-18 16:10:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:10:20 --> Final output sent to browser
DEBUG - 2020-09-18 16:10:20 --> Total execution time: 0.0251
ERROR - 2020-09-18 16:14:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:14:16 --> Config Class Initialized
INFO - 2020-09-18 16:14:16 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:14:16 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:14:16 --> Utf8 Class Initialized
INFO - 2020-09-18 16:14:16 --> URI Class Initialized
INFO - 2020-09-18 16:14:16 --> Router Class Initialized
INFO - 2020-09-18 16:14:16 --> Output Class Initialized
INFO - 2020-09-18 16:14:16 --> Security Class Initialized
DEBUG - 2020-09-18 16:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:14:16 --> Input Class Initialized
INFO - 2020-09-18 16:14:16 --> Language Class Initialized
INFO - 2020-09-18 16:14:16 --> Loader Class Initialized
ERROR - 2020-09-18 16:14:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:14:16 --> Helper loaded: url_helper
INFO - 2020-09-18 16:14:16 --> Database Driver Class Initialized
INFO - 2020-09-18 16:14:16 --> Config Class Initialized
INFO - 2020-09-18 16:14:16 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:14:16 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:14:16 --> Utf8 Class Initialized
INFO - 2020-09-18 16:14:16 --> URI Class Initialized
INFO - 2020-09-18 16:14:16 --> Router Class Initialized
INFO - 2020-09-18 16:14:16 --> Output Class Initialized
INFO - 2020-09-18 16:14:16 --> Security Class Initialized
DEBUG - 2020-09-18 16:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:14:16 --> Input Class Initialized
INFO - 2020-09-18 16:14:16 --> Language Class Initialized
INFO - 2020-09-18 16:14:16 --> Loader Class Initialized
INFO - 2020-09-18 16:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:14:16 --> Helper loaded: url_helper
INFO - 2020-09-18 16:14:16 --> Email Class Initialized
INFO - 2020-09-18 16:14:16 --> Controller Class Initialized
DEBUG - 2020-09-18 16:14:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:14:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:14:16 --> Model Class Initialized
INFO - 2020-09-18 16:14:16 --> Model Class Initialized
INFO - 2020-09-18 16:14:16 --> Database Driver Class Initialized
INFO - 2020-09-18 16:14:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:14:16 --> Final output sent to browser
DEBUG - 2020-09-18 16:14:16 --> Total execution time: 0.0501
INFO - 2020-09-18 16:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:14:16 --> Email Class Initialized
INFO - 2020-09-18 16:14:16 --> Controller Class Initialized
DEBUG - 2020-09-18 16:14:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:14:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:14:16 --> Model Class Initialized
INFO - 2020-09-18 16:14:16 --> Model Class Initialized
INFO - 2020-09-18 16:14:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:14:16 --> Final output sent to browser
DEBUG - 2020-09-18 16:14:16 --> Total execution time: 0.0428
ERROR - 2020-09-18 16:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:14:19 --> Config Class Initialized
INFO - 2020-09-18 16:14:19 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:14:19 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:14:19 --> Utf8 Class Initialized
INFO - 2020-09-18 16:14:19 --> URI Class Initialized
INFO - 2020-09-18 16:14:19 --> Router Class Initialized
INFO - 2020-09-18 16:14:19 --> Output Class Initialized
INFO - 2020-09-18 16:14:19 --> Security Class Initialized
DEBUG - 2020-09-18 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:14:19 --> Input Class Initialized
INFO - 2020-09-18 16:14:19 --> Language Class Initialized
INFO - 2020-09-18 16:14:19 --> Loader Class Initialized
INFO - 2020-09-18 16:14:19 --> Helper loaded: url_helper
INFO - 2020-09-18 16:14:19 --> Database Driver Class Initialized
INFO - 2020-09-18 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:14:19 --> Email Class Initialized
INFO - 2020-09-18 16:14:19 --> Controller Class Initialized
DEBUG - 2020-09-18 16:14:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:14:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:14:19 --> Model Class Initialized
INFO - 2020-09-18 16:14:19 --> Model Class Initialized
INFO - 2020-09-18 16:14:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:14:19 --> Final output sent to browser
DEBUG - 2020-09-18 16:14:19 --> Total execution time: 0.0257
ERROR - 2020-09-18 16:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:23:29 --> Config Class Initialized
INFO - 2020-09-18 16:23:29 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:23:29 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:23:29 --> Utf8 Class Initialized
INFO - 2020-09-18 16:23:29 --> URI Class Initialized
INFO - 2020-09-18 16:23:29 --> Router Class Initialized
INFO - 2020-09-18 16:23:29 --> Output Class Initialized
INFO - 2020-09-18 16:23:29 --> Security Class Initialized
DEBUG - 2020-09-18 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:23:29 --> Input Class Initialized
INFO - 2020-09-18 16:23:29 --> Language Class Initialized
INFO - 2020-09-18 16:23:29 --> Loader Class Initialized
INFO - 2020-09-18 16:23:29 --> Helper loaded: url_helper
INFO - 2020-09-18 16:23:29 --> Database Driver Class Initialized
INFO - 2020-09-18 16:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:23:29 --> Email Class Initialized
INFO - 2020-09-18 16:23:29 --> Controller Class Initialized
DEBUG - 2020-09-18 16:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:23:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:23:29 --> Model Class Initialized
INFO - 2020-09-18 16:23:29 --> Model Class Initialized
INFO - 2020-09-18 16:23:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:23:29 --> Final output sent to browser
DEBUG - 2020-09-18 16:23:29 --> Total execution time: 0.0303
ERROR - 2020-09-18 16:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:23:37 --> Config Class Initialized
INFO - 2020-09-18 16:23:37 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:23:37 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:23:37 --> Utf8 Class Initialized
INFO - 2020-09-18 16:23:37 --> URI Class Initialized
INFO - 2020-09-18 16:23:37 --> Router Class Initialized
INFO - 2020-09-18 16:23:37 --> Output Class Initialized
INFO - 2020-09-18 16:23:37 --> Security Class Initialized
DEBUG - 2020-09-18 16:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:23:37 --> Input Class Initialized
INFO - 2020-09-18 16:23:37 --> Language Class Initialized
INFO - 2020-09-18 16:23:37 --> Loader Class Initialized
INFO - 2020-09-18 16:23:37 --> Helper loaded: url_helper
INFO - 2020-09-18 16:23:37 --> Database Driver Class Initialized
INFO - 2020-09-18 16:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:23:37 --> Email Class Initialized
INFO - 2020-09-18 16:23:37 --> Controller Class Initialized
DEBUG - 2020-09-18 16:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:23:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:23:37 --> Model Class Initialized
INFO - 2020-09-18 16:23:37 --> Model Class Initialized
INFO - 2020-09-18 16:23:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:23:37 --> Final output sent to browser
DEBUG - 2020-09-18 16:23:37 --> Total execution time: 0.0264
ERROR - 2020-09-18 16:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:23:39 --> Config Class Initialized
INFO - 2020-09-18 16:23:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:23:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:23:39 --> Utf8 Class Initialized
INFO - 2020-09-18 16:23:39 --> URI Class Initialized
INFO - 2020-09-18 16:23:39 --> Router Class Initialized
INFO - 2020-09-18 16:23:39 --> Output Class Initialized
INFO - 2020-09-18 16:23:39 --> Security Class Initialized
DEBUG - 2020-09-18 16:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:23:39 --> Input Class Initialized
INFO - 2020-09-18 16:23:39 --> Language Class Initialized
INFO - 2020-09-18 16:23:39 --> Loader Class Initialized
INFO - 2020-09-18 16:23:39 --> Helper loaded: url_helper
INFO - 2020-09-18 16:23:39 --> Database Driver Class Initialized
INFO - 2020-09-18 16:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:23:39 --> Email Class Initialized
INFO - 2020-09-18 16:23:39 --> Controller Class Initialized
DEBUG - 2020-09-18 16:23:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:23:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:23:39 --> Model Class Initialized
INFO - 2020-09-18 16:23:39 --> Model Class Initialized
INFO - 2020-09-18 16:23:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:23:39 --> Final output sent to browser
DEBUG - 2020-09-18 16:23:39 --> Total execution time: 0.0248
ERROR - 2020-09-18 16:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:23:42 --> Config Class Initialized
INFO - 2020-09-18 16:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:23:42 --> Utf8 Class Initialized
INFO - 2020-09-18 16:23:42 --> URI Class Initialized
INFO - 2020-09-18 16:23:42 --> Router Class Initialized
INFO - 2020-09-18 16:23:42 --> Output Class Initialized
INFO - 2020-09-18 16:23:42 --> Security Class Initialized
DEBUG - 2020-09-18 16:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:23:42 --> Input Class Initialized
INFO - 2020-09-18 16:23:42 --> Language Class Initialized
INFO - 2020-09-18 16:23:42 --> Loader Class Initialized
INFO - 2020-09-18 16:23:42 --> Helper loaded: url_helper
INFO - 2020-09-18 16:23:42 --> Database Driver Class Initialized
INFO - 2020-09-18 16:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:23:42 --> Email Class Initialized
INFO - 2020-09-18 16:23:42 --> Controller Class Initialized
DEBUG - 2020-09-18 16:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:23:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:23:42 --> Model Class Initialized
INFO - 2020-09-18 16:23:42 --> Model Class Initialized
INFO - 2020-09-18 16:23:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:23:42 --> Final output sent to browser
DEBUG - 2020-09-18 16:23:42 --> Total execution time: 0.0216
ERROR - 2020-09-18 16:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:24:14 --> Config Class Initialized
INFO - 2020-09-18 16:24:14 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:24:14 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:24:14 --> Utf8 Class Initialized
INFO - 2020-09-18 16:24:14 --> URI Class Initialized
INFO - 2020-09-18 16:24:14 --> Router Class Initialized
INFO - 2020-09-18 16:24:14 --> Output Class Initialized
INFO - 2020-09-18 16:24:14 --> Security Class Initialized
DEBUG - 2020-09-18 16:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:24:14 --> Input Class Initialized
INFO - 2020-09-18 16:24:14 --> Language Class Initialized
INFO - 2020-09-18 16:24:14 --> Loader Class Initialized
INFO - 2020-09-18 16:24:14 --> Helper loaded: url_helper
INFO - 2020-09-18 16:24:14 --> Database Driver Class Initialized
INFO - 2020-09-18 16:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:24:14 --> Email Class Initialized
INFO - 2020-09-18 16:24:14 --> Controller Class Initialized
DEBUG - 2020-09-18 16:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:24:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:24:14 --> Model Class Initialized
INFO - 2020-09-18 16:24:14 --> Model Class Initialized
INFO - 2020-09-18 16:24:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:24:14 --> Final output sent to browser
DEBUG - 2020-09-18 16:24:14 --> Total execution time: 0.0260
ERROR - 2020-09-18 16:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:40:34 --> Config Class Initialized
INFO - 2020-09-18 16:40:34 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:40:34 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:40:34 --> Utf8 Class Initialized
INFO - 2020-09-18 16:40:34 --> URI Class Initialized
INFO - 2020-09-18 16:40:34 --> Router Class Initialized
INFO - 2020-09-18 16:40:34 --> Output Class Initialized
INFO - 2020-09-18 16:40:34 --> Security Class Initialized
DEBUG - 2020-09-18 16:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:40:34 --> Input Class Initialized
INFO - 2020-09-18 16:40:34 --> Language Class Initialized
INFO - 2020-09-18 16:40:34 --> Loader Class Initialized
INFO - 2020-09-18 16:40:34 --> Helper loaded: url_helper
INFO - 2020-09-18 16:40:34 --> Database Driver Class Initialized
INFO - 2020-09-18 16:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:40:34 --> Email Class Initialized
INFO - 2020-09-18 16:40:34 --> Controller Class Initialized
DEBUG - 2020-09-18 16:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:40:34 --> Model Class Initialized
INFO - 2020-09-18 16:40:34 --> Model Class Initialized
INFO - 2020-09-18 16:40:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:40:34 --> Final output sent to browser
DEBUG - 2020-09-18 16:40:34 --> Total execution time: 0.0368
ERROR - 2020-09-18 16:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:40:38 --> Config Class Initialized
INFO - 2020-09-18 16:40:38 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:40:38 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:40:38 --> Utf8 Class Initialized
INFO - 2020-09-18 16:40:38 --> URI Class Initialized
INFO - 2020-09-18 16:40:38 --> Router Class Initialized
INFO - 2020-09-18 16:40:38 --> Output Class Initialized
INFO - 2020-09-18 16:40:38 --> Security Class Initialized
DEBUG - 2020-09-18 16:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:40:38 --> Input Class Initialized
INFO - 2020-09-18 16:40:38 --> Language Class Initialized
INFO - 2020-09-18 16:40:38 --> Loader Class Initialized
INFO - 2020-09-18 16:40:38 --> Helper loaded: url_helper
INFO - 2020-09-18 16:40:38 --> Database Driver Class Initialized
INFO - 2020-09-18 16:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:40:38 --> Email Class Initialized
INFO - 2020-09-18 16:40:38 --> Controller Class Initialized
DEBUG - 2020-09-18 16:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:40:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:40:38 --> Model Class Initialized
INFO - 2020-09-18 16:40:38 --> Model Class Initialized
INFO - 2020-09-18 16:40:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:40:38 --> Final output sent to browser
DEBUG - 2020-09-18 16:40:38 --> Total execution time: 0.0221
ERROR - 2020-09-18 16:40:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:40:42 --> Config Class Initialized
INFO - 2020-09-18 16:40:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:40:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:40:42 --> Utf8 Class Initialized
INFO - 2020-09-18 16:40:42 --> URI Class Initialized
INFO - 2020-09-18 16:40:42 --> Router Class Initialized
INFO - 2020-09-18 16:40:42 --> Output Class Initialized
INFO - 2020-09-18 16:40:42 --> Security Class Initialized
DEBUG - 2020-09-18 16:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:40:42 --> Input Class Initialized
INFO - 2020-09-18 16:40:42 --> Language Class Initialized
INFO - 2020-09-18 16:40:42 --> Loader Class Initialized
INFO - 2020-09-18 16:40:42 --> Helper loaded: url_helper
INFO - 2020-09-18 16:40:42 --> Database Driver Class Initialized
INFO - 2020-09-18 16:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:40:42 --> Email Class Initialized
INFO - 2020-09-18 16:40:42 --> Controller Class Initialized
DEBUG - 2020-09-18 16:40:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:40:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:40:42 --> Model Class Initialized
INFO - 2020-09-18 16:40:42 --> Model Class Initialized
INFO - 2020-09-18 16:40:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:40:42 --> Final output sent to browser
DEBUG - 2020-09-18 16:40:42 --> Total execution time: 0.0265
ERROR - 2020-09-18 16:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:40:45 --> Config Class Initialized
INFO - 2020-09-18 16:40:45 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:40:45 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:40:45 --> Utf8 Class Initialized
INFO - 2020-09-18 16:40:45 --> URI Class Initialized
INFO - 2020-09-18 16:40:45 --> Router Class Initialized
INFO - 2020-09-18 16:40:45 --> Output Class Initialized
INFO - 2020-09-18 16:40:45 --> Security Class Initialized
DEBUG - 2020-09-18 16:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:40:45 --> Input Class Initialized
INFO - 2020-09-18 16:40:45 --> Language Class Initialized
INFO - 2020-09-18 16:40:45 --> Loader Class Initialized
INFO - 2020-09-18 16:40:45 --> Helper loaded: url_helper
INFO - 2020-09-18 16:40:45 --> Database Driver Class Initialized
INFO - 2020-09-18 16:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:40:45 --> Email Class Initialized
INFO - 2020-09-18 16:40:45 --> Controller Class Initialized
DEBUG - 2020-09-18 16:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:40:45 --> Model Class Initialized
INFO - 2020-09-18 16:40:45 --> Model Class Initialized
INFO - 2020-09-18 16:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:40:45 --> Final output sent to browser
DEBUG - 2020-09-18 16:40:45 --> Total execution time: 0.0245
ERROR - 2020-09-18 16:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:40:49 --> Config Class Initialized
INFO - 2020-09-18 16:40:49 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:40:49 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:40:49 --> Utf8 Class Initialized
INFO - 2020-09-18 16:40:49 --> URI Class Initialized
INFO - 2020-09-18 16:40:49 --> Router Class Initialized
INFO - 2020-09-18 16:40:49 --> Output Class Initialized
INFO - 2020-09-18 16:40:49 --> Security Class Initialized
DEBUG - 2020-09-18 16:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:40:49 --> Input Class Initialized
INFO - 2020-09-18 16:40:49 --> Language Class Initialized
INFO - 2020-09-18 16:40:49 --> Loader Class Initialized
INFO - 2020-09-18 16:40:49 --> Helper loaded: url_helper
INFO - 2020-09-18 16:40:49 --> Database Driver Class Initialized
INFO - 2020-09-18 16:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:40:49 --> Email Class Initialized
INFO - 2020-09-18 16:40:49 --> Controller Class Initialized
DEBUG - 2020-09-18 16:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:40:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:40:49 --> Model Class Initialized
INFO - 2020-09-18 16:40:49 --> Model Class Initialized
INFO - 2020-09-18 16:40:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:40:49 --> Final output sent to browser
DEBUG - 2020-09-18 16:40:49 --> Total execution time: 0.0268
ERROR - 2020-09-18 16:40:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:40:53 --> Config Class Initialized
INFO - 2020-09-18 16:40:53 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:40:53 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:40:53 --> Utf8 Class Initialized
INFO - 2020-09-18 16:40:53 --> URI Class Initialized
INFO - 2020-09-18 16:40:53 --> Router Class Initialized
INFO - 2020-09-18 16:40:53 --> Output Class Initialized
INFO - 2020-09-18 16:40:53 --> Security Class Initialized
DEBUG - 2020-09-18 16:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:40:53 --> Input Class Initialized
INFO - 2020-09-18 16:40:53 --> Language Class Initialized
INFO - 2020-09-18 16:40:53 --> Loader Class Initialized
INFO - 2020-09-18 16:40:53 --> Helper loaded: url_helper
INFO - 2020-09-18 16:40:53 --> Database Driver Class Initialized
INFO - 2020-09-18 16:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:40:53 --> Email Class Initialized
INFO - 2020-09-18 16:40:53 --> Controller Class Initialized
DEBUG - 2020-09-18 16:40:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:40:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:40:53 --> Model Class Initialized
INFO - 2020-09-18 16:40:53 --> Model Class Initialized
INFO - 2020-09-18 16:40:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:40:53 --> Final output sent to browser
DEBUG - 2020-09-18 16:40:53 --> Total execution time: 0.0287
ERROR - 2020-09-18 16:41:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:41:07 --> Config Class Initialized
INFO - 2020-09-18 16:41:07 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:41:07 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:41:07 --> Utf8 Class Initialized
INFO - 2020-09-18 16:41:07 --> URI Class Initialized
INFO - 2020-09-18 16:41:07 --> Router Class Initialized
INFO - 2020-09-18 16:41:07 --> Output Class Initialized
INFO - 2020-09-18 16:41:07 --> Security Class Initialized
DEBUG - 2020-09-18 16:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:41:07 --> Input Class Initialized
INFO - 2020-09-18 16:41:07 --> Language Class Initialized
INFO - 2020-09-18 16:41:07 --> Loader Class Initialized
INFO - 2020-09-18 16:41:07 --> Helper loaded: url_helper
INFO - 2020-09-18 16:41:07 --> Database Driver Class Initialized
INFO - 2020-09-18 16:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:41:07 --> Email Class Initialized
INFO - 2020-09-18 16:41:07 --> Controller Class Initialized
DEBUG - 2020-09-18 16:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:41:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:41:07 --> Model Class Initialized
INFO - 2020-09-18 16:41:07 --> Model Class Initialized
INFO - 2020-09-18 16:41:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:41:07 --> Final output sent to browser
DEBUG - 2020-09-18 16:41:07 --> Total execution time: 0.0229
ERROR - 2020-09-18 16:41:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:41:12 --> Config Class Initialized
INFO - 2020-09-18 16:41:12 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:41:12 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:41:12 --> Utf8 Class Initialized
INFO - 2020-09-18 16:41:12 --> URI Class Initialized
INFO - 2020-09-18 16:41:12 --> Router Class Initialized
INFO - 2020-09-18 16:41:12 --> Output Class Initialized
INFO - 2020-09-18 16:41:12 --> Security Class Initialized
DEBUG - 2020-09-18 16:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:41:12 --> Input Class Initialized
INFO - 2020-09-18 16:41:12 --> Language Class Initialized
INFO - 2020-09-18 16:41:12 --> Loader Class Initialized
INFO - 2020-09-18 16:41:12 --> Helper loaded: url_helper
INFO - 2020-09-18 16:41:12 --> Database Driver Class Initialized
INFO - 2020-09-18 16:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:41:12 --> Email Class Initialized
INFO - 2020-09-18 16:41:12 --> Controller Class Initialized
DEBUG - 2020-09-18 16:41:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:41:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:41:12 --> Model Class Initialized
INFO - 2020-09-18 16:41:12 --> Model Class Initialized
INFO - 2020-09-18 16:41:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:41:12 --> Final output sent to browser
DEBUG - 2020-09-18 16:41:12 --> Total execution time: 0.0233
ERROR - 2020-09-18 16:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:41:49 --> Config Class Initialized
INFO - 2020-09-18 16:41:49 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:41:49 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:41:49 --> Utf8 Class Initialized
INFO - 2020-09-18 16:41:49 --> URI Class Initialized
INFO - 2020-09-18 16:41:49 --> Router Class Initialized
INFO - 2020-09-18 16:41:49 --> Output Class Initialized
INFO - 2020-09-18 16:41:49 --> Security Class Initialized
DEBUG - 2020-09-18 16:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:41:49 --> Input Class Initialized
INFO - 2020-09-18 16:41:49 --> Language Class Initialized
INFO - 2020-09-18 16:41:49 --> Loader Class Initialized
INFO - 2020-09-18 16:41:49 --> Helper loaded: url_helper
INFO - 2020-09-18 16:41:49 --> Database Driver Class Initialized
INFO - 2020-09-18 16:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:41:49 --> Email Class Initialized
INFO - 2020-09-18 16:41:49 --> Controller Class Initialized
DEBUG - 2020-09-18 16:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:41:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:41:49 --> Model Class Initialized
INFO - 2020-09-18 16:41:49 --> Model Class Initialized
INFO - 2020-09-18 16:41:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:41:49 --> Final output sent to browser
DEBUG - 2020-09-18 16:41:49 --> Total execution time: 0.0257
ERROR - 2020-09-18 16:42:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:42:11 --> Config Class Initialized
INFO - 2020-09-18 16:42:11 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:42:11 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:42:11 --> Utf8 Class Initialized
INFO - 2020-09-18 16:42:11 --> URI Class Initialized
INFO - 2020-09-18 16:42:11 --> Router Class Initialized
INFO - 2020-09-18 16:42:11 --> Output Class Initialized
INFO - 2020-09-18 16:42:11 --> Security Class Initialized
DEBUG - 2020-09-18 16:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:42:11 --> Input Class Initialized
INFO - 2020-09-18 16:42:11 --> Language Class Initialized
INFO - 2020-09-18 16:42:11 --> Loader Class Initialized
INFO - 2020-09-18 16:42:11 --> Helper loaded: url_helper
INFO - 2020-09-18 16:42:11 --> Database Driver Class Initialized
INFO - 2020-09-18 16:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:42:11 --> Email Class Initialized
INFO - 2020-09-18 16:42:11 --> Controller Class Initialized
DEBUG - 2020-09-18 16:42:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:42:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:42:11 --> Model Class Initialized
INFO - 2020-09-18 16:42:11 --> Model Class Initialized
INFO - 2020-09-18 16:42:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:42:11 --> Final output sent to browser
DEBUG - 2020-09-18 16:42:11 --> Total execution time: 0.0260
ERROR - 2020-09-18 16:42:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:42:50 --> Config Class Initialized
INFO - 2020-09-18 16:42:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:42:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:42:50 --> Utf8 Class Initialized
INFO - 2020-09-18 16:42:50 --> URI Class Initialized
INFO - 2020-09-18 16:42:50 --> Router Class Initialized
INFO - 2020-09-18 16:42:50 --> Output Class Initialized
INFO - 2020-09-18 16:42:50 --> Security Class Initialized
DEBUG - 2020-09-18 16:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:42:50 --> Input Class Initialized
INFO - 2020-09-18 16:42:50 --> Language Class Initialized
INFO - 2020-09-18 16:42:50 --> Loader Class Initialized
INFO - 2020-09-18 16:42:50 --> Helper loaded: url_helper
INFO - 2020-09-18 16:42:50 --> Database Driver Class Initialized
INFO - 2020-09-18 16:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:42:50 --> Email Class Initialized
INFO - 2020-09-18 16:42:50 --> Controller Class Initialized
DEBUG - 2020-09-18 16:42:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:42:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:42:50 --> Model Class Initialized
INFO - 2020-09-18 16:42:50 --> Model Class Initialized
INFO - 2020-09-18 16:42:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:42:50 --> Final output sent to browser
DEBUG - 2020-09-18 16:42:50 --> Total execution time: 0.0323
ERROR - 2020-09-18 16:42:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:42:56 --> Config Class Initialized
INFO - 2020-09-18 16:42:56 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:42:56 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:42:56 --> Utf8 Class Initialized
INFO - 2020-09-18 16:42:56 --> URI Class Initialized
INFO - 2020-09-18 16:42:56 --> Router Class Initialized
INFO - 2020-09-18 16:42:56 --> Output Class Initialized
INFO - 2020-09-18 16:42:56 --> Security Class Initialized
DEBUG - 2020-09-18 16:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:42:56 --> Input Class Initialized
INFO - 2020-09-18 16:42:56 --> Language Class Initialized
INFO - 2020-09-18 16:42:56 --> Loader Class Initialized
INFO - 2020-09-18 16:42:56 --> Helper loaded: url_helper
INFO - 2020-09-18 16:42:56 --> Database Driver Class Initialized
INFO - 2020-09-18 16:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:42:56 --> Email Class Initialized
INFO - 2020-09-18 16:42:56 --> Controller Class Initialized
DEBUG - 2020-09-18 16:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:42:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:42:56 --> Model Class Initialized
INFO - 2020-09-18 16:42:56 --> Model Class Initialized
INFO - 2020-09-18 16:42:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:42:56 --> Final output sent to browser
DEBUG - 2020-09-18 16:42:56 --> Total execution time: 0.0222
ERROR - 2020-09-18 16:43:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:43:06 --> Config Class Initialized
INFO - 2020-09-18 16:43:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:43:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:43:06 --> Utf8 Class Initialized
INFO - 2020-09-18 16:43:06 --> URI Class Initialized
INFO - 2020-09-18 16:43:06 --> Router Class Initialized
INFO - 2020-09-18 16:43:06 --> Output Class Initialized
INFO - 2020-09-18 16:43:06 --> Security Class Initialized
DEBUG - 2020-09-18 16:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:43:06 --> Input Class Initialized
INFO - 2020-09-18 16:43:06 --> Language Class Initialized
INFO - 2020-09-18 16:43:06 --> Loader Class Initialized
INFO - 2020-09-18 16:43:06 --> Helper loaded: url_helper
INFO - 2020-09-18 16:43:06 --> Database Driver Class Initialized
INFO - 2020-09-18 16:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:43:06 --> Email Class Initialized
INFO - 2020-09-18 16:43:06 --> Controller Class Initialized
DEBUG - 2020-09-18 16:43:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:43:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:43:06 --> Model Class Initialized
INFO - 2020-09-18 16:43:06 --> Model Class Initialized
INFO - 2020-09-18 16:43:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:43:06 --> Final output sent to browser
DEBUG - 2020-09-18 16:43:06 --> Total execution time: 0.0248
ERROR - 2020-09-18 16:47:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:47:24 --> Config Class Initialized
INFO - 2020-09-18 16:47:24 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:47:24 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:47:24 --> Utf8 Class Initialized
INFO - 2020-09-18 16:47:24 --> URI Class Initialized
INFO - 2020-09-18 16:47:24 --> Router Class Initialized
INFO - 2020-09-18 16:47:24 --> Output Class Initialized
INFO - 2020-09-18 16:47:24 --> Security Class Initialized
DEBUG - 2020-09-18 16:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:47:24 --> Input Class Initialized
INFO - 2020-09-18 16:47:24 --> Language Class Initialized
INFO - 2020-09-18 16:47:24 --> Loader Class Initialized
INFO - 2020-09-18 16:47:24 --> Helper loaded: url_helper
INFO - 2020-09-18 16:47:24 --> Database Driver Class Initialized
INFO - 2020-09-18 16:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:47:24 --> Email Class Initialized
INFO - 2020-09-18 16:47:24 --> Controller Class Initialized
DEBUG - 2020-09-18 16:47:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:47:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:47:24 --> Model Class Initialized
INFO - 2020-09-18 16:47:24 --> Model Class Initialized
INFO - 2020-09-18 16:47:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:47:24 --> Final output sent to browser
DEBUG - 2020-09-18 16:47:24 --> Total execution time: 0.0256
ERROR - 2020-09-18 16:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:47:27 --> Config Class Initialized
INFO - 2020-09-18 16:47:27 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:47:27 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:47:27 --> Utf8 Class Initialized
INFO - 2020-09-18 16:47:27 --> URI Class Initialized
INFO - 2020-09-18 16:47:27 --> Router Class Initialized
INFO - 2020-09-18 16:47:27 --> Output Class Initialized
INFO - 2020-09-18 16:47:27 --> Security Class Initialized
DEBUG - 2020-09-18 16:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:47:27 --> Input Class Initialized
INFO - 2020-09-18 16:47:27 --> Language Class Initialized
INFO - 2020-09-18 16:47:27 --> Loader Class Initialized
INFO - 2020-09-18 16:47:27 --> Helper loaded: url_helper
INFO - 2020-09-18 16:47:27 --> Database Driver Class Initialized
INFO - 2020-09-18 16:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:47:27 --> Email Class Initialized
INFO - 2020-09-18 16:47:27 --> Controller Class Initialized
DEBUG - 2020-09-18 16:47:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:47:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:47:27 --> Model Class Initialized
INFO - 2020-09-18 16:47:27 --> Model Class Initialized
INFO - 2020-09-18 16:47:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:47:27 --> Final output sent to browser
DEBUG - 2020-09-18 16:47:27 --> Total execution time: 0.0212
ERROR - 2020-09-18 16:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:47:30 --> Config Class Initialized
INFO - 2020-09-18 16:47:30 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:47:30 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:47:30 --> Utf8 Class Initialized
INFO - 2020-09-18 16:47:30 --> URI Class Initialized
INFO - 2020-09-18 16:47:30 --> Router Class Initialized
INFO - 2020-09-18 16:47:30 --> Output Class Initialized
INFO - 2020-09-18 16:47:30 --> Security Class Initialized
DEBUG - 2020-09-18 16:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:47:30 --> Input Class Initialized
INFO - 2020-09-18 16:47:30 --> Language Class Initialized
INFO - 2020-09-18 16:47:30 --> Loader Class Initialized
INFO - 2020-09-18 16:47:30 --> Helper loaded: url_helper
INFO - 2020-09-18 16:47:30 --> Database Driver Class Initialized
INFO - 2020-09-18 16:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:47:30 --> Email Class Initialized
INFO - 2020-09-18 16:47:30 --> Controller Class Initialized
DEBUG - 2020-09-18 16:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:47:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:47:30 --> Model Class Initialized
INFO - 2020-09-18 16:47:30 --> Model Class Initialized
INFO - 2020-09-18 16:47:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:47:30 --> Final output sent to browser
DEBUG - 2020-09-18 16:47:30 --> Total execution time: 0.0210
ERROR - 2020-09-18 16:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:47:32 --> Config Class Initialized
INFO - 2020-09-18 16:47:32 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:47:32 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:47:32 --> Utf8 Class Initialized
INFO - 2020-09-18 16:47:32 --> URI Class Initialized
INFO - 2020-09-18 16:47:32 --> Router Class Initialized
INFO - 2020-09-18 16:47:32 --> Output Class Initialized
INFO - 2020-09-18 16:47:32 --> Security Class Initialized
DEBUG - 2020-09-18 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:47:32 --> Input Class Initialized
INFO - 2020-09-18 16:47:32 --> Language Class Initialized
INFO - 2020-09-18 16:47:32 --> Loader Class Initialized
INFO - 2020-09-18 16:47:32 --> Helper loaded: url_helper
INFO - 2020-09-18 16:47:32 --> Database Driver Class Initialized
INFO - 2020-09-18 16:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:47:32 --> Email Class Initialized
INFO - 2020-09-18 16:47:32 --> Controller Class Initialized
DEBUG - 2020-09-18 16:47:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:47:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:47:32 --> Model Class Initialized
INFO - 2020-09-18 16:47:32 --> Model Class Initialized
INFO - 2020-09-18 16:47:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 16:47:32 --> Final output sent to browser
DEBUG - 2020-09-18 16:47:32 --> Total execution time: 0.0229
ERROR - 2020-09-18 16:47:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 16:47:45 --> Config Class Initialized
INFO - 2020-09-18 16:47:45 --> Hooks Class Initialized
DEBUG - 2020-09-18 16:47:45 --> UTF-8 Support Enabled
INFO - 2020-09-18 16:47:45 --> Utf8 Class Initialized
INFO - 2020-09-18 16:47:45 --> URI Class Initialized
INFO - 2020-09-18 16:47:45 --> Router Class Initialized
INFO - 2020-09-18 16:47:45 --> Output Class Initialized
INFO - 2020-09-18 16:47:45 --> Security Class Initialized
DEBUG - 2020-09-18 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 16:47:45 --> Input Class Initialized
INFO - 2020-09-18 16:47:45 --> Language Class Initialized
INFO - 2020-09-18 16:47:45 --> Loader Class Initialized
INFO - 2020-09-18 16:47:45 --> Helper loaded: url_helper
INFO - 2020-09-18 16:47:45 --> Database Driver Class Initialized
INFO - 2020-09-18 16:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 16:47:45 --> Email Class Initialized
INFO - 2020-09-18 16:47:45 --> Controller Class Initialized
DEBUG - 2020-09-18 16:47:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 16:47:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 16:47:45 --> Model Class Initialized
INFO - 2020-09-18 16:47:45 --> Model Class Initialized
INFO - 2020-09-18 16:47:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 16:47:45 --> Final output sent to browser
DEBUG - 2020-09-18 16:47:45 --> Total execution time: 0.0251
ERROR - 2020-09-18 17:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:02:43 --> Config Class Initialized
INFO - 2020-09-18 17:02:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:02:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:02:43 --> Utf8 Class Initialized
INFO - 2020-09-18 17:02:43 --> URI Class Initialized
INFO - 2020-09-18 17:02:43 --> Router Class Initialized
INFO - 2020-09-18 17:02:43 --> Output Class Initialized
INFO - 2020-09-18 17:02:43 --> Security Class Initialized
DEBUG - 2020-09-18 17:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:02:43 --> Input Class Initialized
INFO - 2020-09-18 17:02:43 --> Language Class Initialized
INFO - 2020-09-18 17:02:43 --> Loader Class Initialized
INFO - 2020-09-18 17:02:43 --> Helper loaded: url_helper
INFO - 2020-09-18 17:02:43 --> Database Driver Class Initialized
INFO - 2020-09-18 17:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:02:43 --> Email Class Initialized
INFO - 2020-09-18 17:02:43 --> Controller Class Initialized
DEBUG - 2020-09-18 17:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:02:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:02:43 --> Model Class Initialized
INFO - 2020-09-18 17:02:43 --> Model Class Initialized
INFO - 2020-09-18 17:02:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:02:43 --> Final output sent to browser
DEBUG - 2020-09-18 17:02:43 --> Total execution time: 0.0265
ERROR - 2020-09-18 17:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:02:46 --> Config Class Initialized
INFO - 2020-09-18 17:02:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:02:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:02:46 --> Utf8 Class Initialized
INFO - 2020-09-18 17:02:46 --> URI Class Initialized
INFO - 2020-09-18 17:02:46 --> Router Class Initialized
INFO - 2020-09-18 17:02:46 --> Output Class Initialized
INFO - 2020-09-18 17:02:46 --> Security Class Initialized
DEBUG - 2020-09-18 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:02:46 --> Input Class Initialized
INFO - 2020-09-18 17:02:46 --> Language Class Initialized
INFO - 2020-09-18 17:02:46 --> Loader Class Initialized
INFO - 2020-09-18 17:02:46 --> Helper loaded: url_helper
INFO - 2020-09-18 17:02:46 --> Database Driver Class Initialized
INFO - 2020-09-18 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:02:46 --> Email Class Initialized
INFO - 2020-09-18 17:02:46 --> Controller Class Initialized
DEBUG - 2020-09-18 17:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:02:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:02:46 --> Model Class Initialized
INFO - 2020-09-18 17:02:46 --> Model Class Initialized
ERROR - 2020-09-18 17:02:46 --> Query error: Unknown column 'p_s_id' in 'where clause' - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:02:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:03:36 --> Config Class Initialized
INFO - 2020-09-18 17:03:36 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:03:36 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:03:36 --> Utf8 Class Initialized
INFO - 2020-09-18 17:03:36 --> URI Class Initialized
INFO - 2020-09-18 17:03:36 --> Router Class Initialized
INFO - 2020-09-18 17:03:36 --> Output Class Initialized
INFO - 2020-09-18 17:03:36 --> Security Class Initialized
DEBUG - 2020-09-18 17:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:03:36 --> Input Class Initialized
INFO - 2020-09-18 17:03:36 --> Language Class Initialized
INFO - 2020-09-18 17:03:36 --> Loader Class Initialized
INFO - 2020-09-18 17:03:36 --> Helper loaded: url_helper
INFO - 2020-09-18 17:03:36 --> Database Driver Class Initialized
INFO - 2020-09-18 17:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:03:36 --> Email Class Initialized
INFO - 2020-09-18 17:03:36 --> Controller Class Initialized
DEBUG - 2020-09-18 17:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:03:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:03:36 --> Model Class Initialized
INFO - 2020-09-18 17:03:36 --> Model Class Initialized
INFO - 2020-09-18 17:03:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:03:36 --> Final output sent to browser
DEBUG - 2020-09-18 17:03:36 --> Total execution time: 0.0270
ERROR - 2020-09-18 17:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:03:39 --> Config Class Initialized
INFO - 2020-09-18 17:03:39 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:03:39 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:03:39 --> Utf8 Class Initialized
INFO - 2020-09-18 17:03:39 --> URI Class Initialized
INFO - 2020-09-18 17:03:39 --> Router Class Initialized
INFO - 2020-09-18 17:03:39 --> Output Class Initialized
INFO - 2020-09-18 17:03:39 --> Security Class Initialized
DEBUG - 2020-09-18 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:03:39 --> Input Class Initialized
INFO - 2020-09-18 17:03:39 --> Language Class Initialized
INFO - 2020-09-18 17:03:39 --> Loader Class Initialized
INFO - 2020-09-18 17:03:39 --> Helper loaded: url_helper
INFO - 2020-09-18 17:03:39 --> Database Driver Class Initialized
INFO - 2020-09-18 17:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:03:39 --> Email Class Initialized
INFO - 2020-09-18 17:03:39 --> Controller Class Initialized
DEBUG - 2020-09-18 17:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:03:39 --> Model Class Initialized
INFO - 2020-09-18 17:03:39 --> Model Class Initialized
ERROR - 2020-09-18 17:03:39 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list; expected 1, got 0 - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:03:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:05:01 --> Config Class Initialized
INFO - 2020-09-18 17:05:01 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:05:01 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:05:01 --> Utf8 Class Initialized
INFO - 2020-09-18 17:05:01 --> URI Class Initialized
INFO - 2020-09-18 17:05:01 --> Router Class Initialized
INFO - 2020-09-18 17:05:01 --> Output Class Initialized
INFO - 2020-09-18 17:05:01 --> Security Class Initialized
DEBUG - 2020-09-18 17:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:05:01 --> Input Class Initialized
INFO - 2020-09-18 17:05:01 --> Language Class Initialized
INFO - 2020-09-18 17:05:01 --> Loader Class Initialized
INFO - 2020-09-18 17:05:01 --> Helper loaded: url_helper
INFO - 2020-09-18 17:05:01 --> Database Driver Class Initialized
INFO - 2020-09-18 17:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:05:01 --> Email Class Initialized
INFO - 2020-09-18 17:05:01 --> Controller Class Initialized
DEBUG - 2020-09-18 17:05:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:05:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:05:01 --> Model Class Initialized
INFO - 2020-09-18 17:05:01 --> Model Class Initialized
INFO - 2020-09-18 17:05:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:05:01 --> Final output sent to browser
DEBUG - 2020-09-18 17:05:01 --> Total execution time: 0.0263
ERROR - 2020-09-18 17:05:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:05:10 --> Config Class Initialized
INFO - 2020-09-18 17:05:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:05:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:05:10 --> Utf8 Class Initialized
INFO - 2020-09-18 17:05:10 --> URI Class Initialized
INFO - 2020-09-18 17:05:10 --> Router Class Initialized
INFO - 2020-09-18 17:05:10 --> Output Class Initialized
INFO - 2020-09-18 17:05:10 --> Security Class Initialized
DEBUG - 2020-09-18 17:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:05:10 --> Input Class Initialized
INFO - 2020-09-18 17:05:10 --> Language Class Initialized
INFO - 2020-09-18 17:05:10 --> Loader Class Initialized
INFO - 2020-09-18 17:05:10 --> Helper loaded: url_helper
INFO - 2020-09-18 17:05:10 --> Database Driver Class Initialized
INFO - 2020-09-18 17:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:05:10 --> Email Class Initialized
INFO - 2020-09-18 17:05:10 --> Controller Class Initialized
DEBUG - 2020-09-18 17:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:05:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:05:10 --> Model Class Initialized
INFO - 2020-09-18 17:05:10 --> Model Class Initialized
INFO - 2020-09-18 17:05:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:05:10 --> Final output sent to browser
DEBUG - 2020-09-18 17:05:10 --> Total execution time: 0.0256
ERROR - 2020-09-18 17:07:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:07:10 --> Config Class Initialized
INFO - 2020-09-18 17:07:10 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:07:10 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:07:10 --> Utf8 Class Initialized
INFO - 2020-09-18 17:07:10 --> URI Class Initialized
INFO - 2020-09-18 17:07:10 --> Router Class Initialized
INFO - 2020-09-18 17:07:10 --> Output Class Initialized
INFO - 2020-09-18 17:07:10 --> Security Class Initialized
DEBUG - 2020-09-18 17:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:07:10 --> Input Class Initialized
INFO - 2020-09-18 17:07:10 --> Language Class Initialized
INFO - 2020-09-18 17:07:10 --> Loader Class Initialized
INFO - 2020-09-18 17:07:10 --> Helper loaded: url_helper
INFO - 2020-09-18 17:07:10 --> Database Driver Class Initialized
INFO - 2020-09-18 17:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:07:10 --> Email Class Initialized
INFO - 2020-09-18 17:07:10 --> Controller Class Initialized
DEBUG - 2020-09-18 17:07:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:07:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:07:10 --> Model Class Initialized
INFO - 2020-09-18 17:07:10 --> Model Class Initialized
INFO - 2020-09-18 17:07:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:07:10 --> Final output sent to browser
DEBUG - 2020-09-18 17:07:10 --> Total execution time: 0.1415
ERROR - 2020-09-18 17:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:08:36 --> Config Class Initialized
INFO - 2020-09-18 17:08:36 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:08:36 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:08:36 --> Utf8 Class Initialized
INFO - 2020-09-18 17:08:36 --> URI Class Initialized
INFO - 2020-09-18 17:08:36 --> Router Class Initialized
INFO - 2020-09-18 17:08:36 --> Output Class Initialized
INFO - 2020-09-18 17:08:36 --> Security Class Initialized
DEBUG - 2020-09-18 17:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:08:36 --> Input Class Initialized
INFO - 2020-09-18 17:08:36 --> Language Class Initialized
INFO - 2020-09-18 17:08:36 --> Loader Class Initialized
INFO - 2020-09-18 17:08:36 --> Helper loaded: url_helper
INFO - 2020-09-18 17:08:36 --> Database Driver Class Initialized
INFO - 2020-09-18 17:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:08:36 --> Email Class Initialized
INFO - 2020-09-18 17:08:36 --> Controller Class Initialized
DEBUG - 2020-09-18 17:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:08:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:08:36 --> Model Class Initialized
INFO - 2020-09-18 17:08:36 --> Model Class Initialized
INFO - 2020-09-18 17:08:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:08:36 --> Final output sent to browser
DEBUG - 2020-09-18 17:08:36 --> Total execution time: 0.0218
ERROR - 2020-09-18 17:08:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:08:44 --> Config Class Initialized
INFO - 2020-09-18 17:08:44 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:08:44 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:08:44 --> Utf8 Class Initialized
INFO - 2020-09-18 17:08:44 --> URI Class Initialized
INFO - 2020-09-18 17:08:44 --> Router Class Initialized
INFO - 2020-09-18 17:08:44 --> Output Class Initialized
INFO - 2020-09-18 17:08:44 --> Security Class Initialized
DEBUG - 2020-09-18 17:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:08:44 --> Input Class Initialized
INFO - 2020-09-18 17:08:44 --> Language Class Initialized
INFO - 2020-09-18 17:08:44 --> Loader Class Initialized
INFO - 2020-09-18 17:08:44 --> Helper loaded: url_helper
INFO - 2020-09-18 17:08:44 --> Database Driver Class Initialized
INFO - 2020-09-18 17:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:08:44 --> Email Class Initialized
INFO - 2020-09-18 17:08:44 --> Controller Class Initialized
DEBUG - 2020-09-18 17:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:08:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:08:44 --> Model Class Initialized
INFO - 2020-09-18 17:08:44 --> Model Class Initialized
INFO - 2020-09-18 17:08:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:08:44 --> Final output sent to browser
DEBUG - 2020-09-18 17:08:44 --> Total execution time: 0.0255
ERROR - 2020-09-18 17:11:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:11:21 --> Config Class Initialized
INFO - 2020-09-18 17:11:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:11:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:11:21 --> Utf8 Class Initialized
INFO - 2020-09-18 17:11:21 --> URI Class Initialized
INFO - 2020-09-18 17:11:21 --> Router Class Initialized
INFO - 2020-09-18 17:11:21 --> Output Class Initialized
INFO - 2020-09-18 17:11:21 --> Security Class Initialized
DEBUG - 2020-09-18 17:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:11:21 --> Input Class Initialized
INFO - 2020-09-18 17:11:21 --> Language Class Initialized
INFO - 2020-09-18 17:11:21 --> Loader Class Initialized
INFO - 2020-09-18 17:11:21 --> Helper loaded: url_helper
INFO - 2020-09-18 17:11:21 --> Database Driver Class Initialized
INFO - 2020-09-18 17:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:11:21 --> Email Class Initialized
INFO - 2020-09-18 17:11:21 --> Controller Class Initialized
DEBUG - 2020-09-18 17:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:11:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:11:21 --> Model Class Initialized
INFO - 2020-09-18 17:11:21 --> Model Class Initialized
ERROR - 2020-09-18 17:11:21 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_details_list; expected 1, got 0 - Invalid query: CALL client_status_details_list()
INFO - 2020-09-18 17:11:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:11:56 --> Config Class Initialized
INFO - 2020-09-18 17:11:56 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:11:56 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:11:56 --> Utf8 Class Initialized
INFO - 2020-09-18 17:11:56 --> URI Class Initialized
INFO - 2020-09-18 17:11:56 --> Router Class Initialized
INFO - 2020-09-18 17:11:56 --> Output Class Initialized
INFO - 2020-09-18 17:11:56 --> Security Class Initialized
DEBUG - 2020-09-18 17:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:11:56 --> Input Class Initialized
INFO - 2020-09-18 17:11:56 --> Language Class Initialized
INFO - 2020-09-18 17:11:56 --> Loader Class Initialized
INFO - 2020-09-18 17:11:56 --> Helper loaded: url_helper
INFO - 2020-09-18 17:11:56 --> Database Driver Class Initialized
INFO - 2020-09-18 17:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:11:56 --> Email Class Initialized
INFO - 2020-09-18 17:11:56 --> Controller Class Initialized
DEBUG - 2020-09-18 17:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:11:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:11:56 --> Model Class Initialized
INFO - 2020-09-18 17:11:56 --> Model Class Initialized
INFO - 2020-09-18 17:11:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:11:56 --> Final output sent to browser
DEBUG - 2020-09-18 17:11:56 --> Total execution time: 0.0229
ERROR - 2020-09-18 17:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:12:17 --> Config Class Initialized
INFO - 2020-09-18 17:12:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:12:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:12:17 --> Utf8 Class Initialized
INFO - 2020-09-18 17:12:17 --> URI Class Initialized
INFO - 2020-09-18 17:12:17 --> Router Class Initialized
INFO - 2020-09-18 17:12:17 --> Output Class Initialized
INFO - 2020-09-18 17:12:17 --> Security Class Initialized
DEBUG - 2020-09-18 17:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:12:17 --> Input Class Initialized
INFO - 2020-09-18 17:12:17 --> Language Class Initialized
INFO - 2020-09-18 17:12:17 --> Loader Class Initialized
INFO - 2020-09-18 17:12:17 --> Helper loaded: url_helper
INFO - 2020-09-18 17:12:17 --> Database Driver Class Initialized
INFO - 2020-09-18 17:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:12:17 --> Email Class Initialized
INFO - 2020-09-18 17:12:17 --> Controller Class Initialized
DEBUG - 2020-09-18 17:12:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:12:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:12:17 --> Model Class Initialized
INFO - 2020-09-18 17:12:17 --> Model Class Initialized
INFO - 2020-09-18 17:12:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:12:17 --> Final output sent to browser
DEBUG - 2020-09-18 17:12:17 --> Total execution time: 0.0244
ERROR - 2020-09-18 17:13:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:13:41 --> Config Class Initialized
INFO - 2020-09-18 17:13:41 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:13:41 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:13:41 --> Utf8 Class Initialized
INFO - 2020-09-18 17:13:41 --> URI Class Initialized
INFO - 2020-09-18 17:13:41 --> Router Class Initialized
INFO - 2020-09-18 17:13:41 --> Output Class Initialized
INFO - 2020-09-18 17:13:41 --> Security Class Initialized
DEBUG - 2020-09-18 17:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:13:41 --> Input Class Initialized
INFO - 2020-09-18 17:13:41 --> Language Class Initialized
INFO - 2020-09-18 17:13:41 --> Loader Class Initialized
INFO - 2020-09-18 17:13:41 --> Helper loaded: url_helper
INFO - 2020-09-18 17:13:41 --> Database Driver Class Initialized
INFO - 2020-09-18 17:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:13:41 --> Email Class Initialized
INFO - 2020-09-18 17:13:41 --> Controller Class Initialized
DEBUG - 2020-09-18 17:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:13:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:13:41 --> Model Class Initialized
INFO - 2020-09-18 17:13:41 --> Model Class Initialized
INFO - 2020-09-18 17:13:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:13:41 --> Final output sent to browser
DEBUG - 2020-09-18 17:13:41 --> Total execution time: 0.0213
ERROR - 2020-09-18 17:13:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:13:47 --> Config Class Initialized
INFO - 2020-09-18 17:13:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:13:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:13:47 --> Utf8 Class Initialized
INFO - 2020-09-18 17:13:47 --> URI Class Initialized
INFO - 2020-09-18 17:13:47 --> Router Class Initialized
INFO - 2020-09-18 17:13:47 --> Output Class Initialized
INFO - 2020-09-18 17:13:47 --> Security Class Initialized
DEBUG - 2020-09-18 17:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:13:47 --> Input Class Initialized
INFO - 2020-09-18 17:13:47 --> Language Class Initialized
INFO - 2020-09-18 17:13:47 --> Loader Class Initialized
INFO - 2020-09-18 17:13:47 --> Helper loaded: url_helper
INFO - 2020-09-18 17:13:47 --> Database Driver Class Initialized
INFO - 2020-09-18 17:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:13:47 --> Email Class Initialized
INFO - 2020-09-18 17:13:47 --> Controller Class Initialized
DEBUG - 2020-09-18 17:13:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:13:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:13:47 --> Model Class Initialized
INFO - 2020-09-18 17:13:47 --> Model Class Initialized
INFO - 2020-09-18 17:13:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:13:47 --> Final output sent to browser
DEBUG - 2020-09-18 17:13:47 --> Total execution time: 0.0346
ERROR - 2020-09-18 17:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:14:18 --> Config Class Initialized
INFO - 2020-09-18 17:14:18 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:14:18 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:14:18 --> Utf8 Class Initialized
INFO - 2020-09-18 17:14:18 --> URI Class Initialized
INFO - 2020-09-18 17:14:18 --> Router Class Initialized
INFO - 2020-09-18 17:14:18 --> Output Class Initialized
INFO - 2020-09-18 17:14:18 --> Security Class Initialized
DEBUG - 2020-09-18 17:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:14:18 --> Input Class Initialized
INFO - 2020-09-18 17:14:18 --> Language Class Initialized
INFO - 2020-09-18 17:14:18 --> Loader Class Initialized
INFO - 2020-09-18 17:14:18 --> Helper loaded: url_helper
INFO - 2020-09-18 17:14:18 --> Database Driver Class Initialized
INFO - 2020-09-18 17:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:14:18 --> Email Class Initialized
INFO - 2020-09-18 17:14:18 --> Controller Class Initialized
DEBUG - 2020-09-18 17:14:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:14:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:14:18 --> Model Class Initialized
INFO - 2020-09-18 17:14:18 --> Model Class Initialized
ERROR - 2020-09-18 17:14:18 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list; expected 1, got 0 - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:14:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:14:28 --> Config Class Initialized
INFO - 2020-09-18 17:14:28 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:14:28 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:14:28 --> Utf8 Class Initialized
INFO - 2020-09-18 17:14:28 --> URI Class Initialized
INFO - 2020-09-18 17:14:28 --> Router Class Initialized
INFO - 2020-09-18 17:14:28 --> Output Class Initialized
INFO - 2020-09-18 17:14:28 --> Security Class Initialized
DEBUG - 2020-09-18 17:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:14:28 --> Input Class Initialized
INFO - 2020-09-18 17:14:28 --> Language Class Initialized
INFO - 2020-09-18 17:14:28 --> Loader Class Initialized
INFO - 2020-09-18 17:14:28 --> Helper loaded: url_helper
INFO - 2020-09-18 17:14:28 --> Database Driver Class Initialized
INFO - 2020-09-18 17:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:14:28 --> Email Class Initialized
INFO - 2020-09-18 17:14:28 --> Controller Class Initialized
DEBUG - 2020-09-18 17:14:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:14:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:14:28 --> Model Class Initialized
INFO - 2020-09-18 17:14:28 --> Model Class Initialized
INFO - 2020-09-18 17:14:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:14:28 --> Final output sent to browser
DEBUG - 2020-09-18 17:14:28 --> Total execution time: 0.0257
ERROR - 2020-09-18 17:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:14:31 --> Config Class Initialized
INFO - 2020-09-18 17:14:31 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:14:31 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:14:31 --> Utf8 Class Initialized
INFO - 2020-09-18 17:14:31 --> URI Class Initialized
INFO - 2020-09-18 17:14:31 --> Router Class Initialized
INFO - 2020-09-18 17:14:31 --> Output Class Initialized
INFO - 2020-09-18 17:14:31 --> Security Class Initialized
DEBUG - 2020-09-18 17:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:14:31 --> Input Class Initialized
INFO - 2020-09-18 17:14:31 --> Language Class Initialized
INFO - 2020-09-18 17:14:31 --> Loader Class Initialized
INFO - 2020-09-18 17:14:31 --> Helper loaded: url_helper
INFO - 2020-09-18 17:14:31 --> Database Driver Class Initialized
INFO - 2020-09-18 17:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:14:31 --> Email Class Initialized
INFO - 2020-09-18 17:14:31 --> Controller Class Initialized
DEBUG - 2020-09-18 17:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:14:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:14:31 --> Model Class Initialized
INFO - 2020-09-18 17:14:31 --> Model Class Initialized
INFO - 2020-09-18 17:14:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:14:31 --> Final output sent to browser
DEBUG - 2020-09-18 17:14:31 --> Total execution time: 0.0227
ERROR - 2020-09-18 17:15:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:15:04 --> Config Class Initialized
INFO - 2020-09-18 17:15:04 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:15:04 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:15:04 --> Utf8 Class Initialized
INFO - 2020-09-18 17:15:04 --> URI Class Initialized
INFO - 2020-09-18 17:15:04 --> Router Class Initialized
INFO - 2020-09-18 17:15:04 --> Output Class Initialized
INFO - 2020-09-18 17:15:04 --> Security Class Initialized
DEBUG - 2020-09-18 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:15:04 --> Input Class Initialized
INFO - 2020-09-18 17:15:04 --> Language Class Initialized
INFO - 2020-09-18 17:15:04 --> Loader Class Initialized
INFO - 2020-09-18 17:15:04 --> Helper loaded: url_helper
INFO - 2020-09-18 17:15:04 --> Database Driver Class Initialized
INFO - 2020-09-18 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:15:04 --> Email Class Initialized
INFO - 2020-09-18 17:15:04 --> Controller Class Initialized
DEBUG - 2020-09-18 17:15:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:15:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:15:04 --> Model Class Initialized
INFO - 2020-09-18 17:15:04 --> Model Class Initialized
INFO - 2020-09-18 17:15:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:15:04 --> Final output sent to browser
DEBUG - 2020-09-18 17:15:04 --> Total execution time: 0.0263
ERROR - 2020-09-18 17:15:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:15:06 --> Config Class Initialized
INFO - 2020-09-18 17:15:06 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:15:06 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:15:06 --> Utf8 Class Initialized
INFO - 2020-09-18 17:15:06 --> URI Class Initialized
INFO - 2020-09-18 17:15:06 --> Router Class Initialized
INFO - 2020-09-18 17:15:06 --> Output Class Initialized
INFO - 2020-09-18 17:15:06 --> Security Class Initialized
DEBUG - 2020-09-18 17:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:15:06 --> Input Class Initialized
INFO - 2020-09-18 17:15:06 --> Language Class Initialized
INFO - 2020-09-18 17:15:06 --> Loader Class Initialized
INFO - 2020-09-18 17:15:06 --> Helper loaded: url_helper
INFO - 2020-09-18 17:15:06 --> Database Driver Class Initialized
INFO - 2020-09-18 17:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:15:06 --> Email Class Initialized
INFO - 2020-09-18 17:15:06 --> Controller Class Initialized
DEBUG - 2020-09-18 17:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:15:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:15:06 --> Model Class Initialized
INFO - 2020-09-18 17:15:06 --> Model Class Initialized
INFO - 2020-09-18 17:15:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:15:06 --> Final output sent to browser
DEBUG - 2020-09-18 17:15:06 --> Total execution time: 0.0258
ERROR - 2020-09-18 17:15:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:15:13 --> Config Class Initialized
INFO - 2020-09-18 17:15:13 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:15:13 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:15:13 --> Utf8 Class Initialized
INFO - 2020-09-18 17:15:13 --> URI Class Initialized
INFO - 2020-09-18 17:15:13 --> Router Class Initialized
INFO - 2020-09-18 17:15:13 --> Output Class Initialized
INFO - 2020-09-18 17:15:13 --> Security Class Initialized
DEBUG - 2020-09-18 17:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:15:13 --> Input Class Initialized
INFO - 2020-09-18 17:15:13 --> Language Class Initialized
INFO - 2020-09-18 17:15:13 --> Loader Class Initialized
INFO - 2020-09-18 17:15:13 --> Helper loaded: url_helper
INFO - 2020-09-18 17:15:13 --> Database Driver Class Initialized
INFO - 2020-09-18 17:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:15:13 --> Email Class Initialized
INFO - 2020-09-18 17:15:13 --> Controller Class Initialized
DEBUG - 2020-09-18 17:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:15:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:15:13 --> Model Class Initialized
INFO - 2020-09-18 17:15:13 --> Model Class Initialized
INFO - 2020-09-18 17:15:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:15:13 --> Final output sent to browser
DEBUG - 2020-09-18 17:15:13 --> Total execution time: 0.0253
ERROR - 2020-09-18 17:15:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:15:15 --> Config Class Initialized
INFO - 2020-09-18 17:15:15 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:15:15 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:15:15 --> Utf8 Class Initialized
INFO - 2020-09-18 17:15:15 --> URI Class Initialized
INFO - 2020-09-18 17:15:15 --> Router Class Initialized
INFO - 2020-09-18 17:15:15 --> Output Class Initialized
INFO - 2020-09-18 17:15:15 --> Security Class Initialized
DEBUG - 2020-09-18 17:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:15:15 --> Input Class Initialized
INFO - 2020-09-18 17:15:15 --> Language Class Initialized
INFO - 2020-09-18 17:15:15 --> Loader Class Initialized
INFO - 2020-09-18 17:15:15 --> Helper loaded: url_helper
INFO - 2020-09-18 17:15:15 --> Database Driver Class Initialized
INFO - 2020-09-18 17:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:15:15 --> Email Class Initialized
INFO - 2020-09-18 17:15:15 --> Controller Class Initialized
DEBUG - 2020-09-18 17:15:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:15:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:15:15 --> Model Class Initialized
INFO - 2020-09-18 17:15:15 --> Model Class Initialized
INFO - 2020-09-18 17:15:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:15:15 --> Final output sent to browser
DEBUG - 2020-09-18 17:15:15 --> Total execution time: 0.0242
ERROR - 2020-09-18 17:15:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:15:43 --> Config Class Initialized
INFO - 2020-09-18 17:15:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:15:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:15:43 --> Utf8 Class Initialized
INFO - 2020-09-18 17:15:43 --> URI Class Initialized
INFO - 2020-09-18 17:15:43 --> Router Class Initialized
INFO - 2020-09-18 17:15:43 --> Output Class Initialized
INFO - 2020-09-18 17:15:43 --> Security Class Initialized
DEBUG - 2020-09-18 17:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:15:43 --> Input Class Initialized
INFO - 2020-09-18 17:15:43 --> Language Class Initialized
INFO - 2020-09-18 17:15:43 --> Loader Class Initialized
INFO - 2020-09-18 17:15:43 --> Helper loaded: url_helper
INFO - 2020-09-18 17:15:43 --> Database Driver Class Initialized
INFO - 2020-09-18 17:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:15:43 --> Email Class Initialized
INFO - 2020-09-18 17:15:43 --> Controller Class Initialized
DEBUG - 2020-09-18 17:15:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:15:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:15:43 --> Model Class Initialized
INFO - 2020-09-18 17:15:43 --> Model Class Initialized
INFO - 2020-09-18 17:15:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:15:43 --> Final output sent to browser
DEBUG - 2020-09-18 17:15:43 --> Total execution time: 0.0269
ERROR - 2020-09-18 17:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:15:46 --> Config Class Initialized
INFO - 2020-09-18 17:15:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:15:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:15:46 --> Utf8 Class Initialized
INFO - 2020-09-18 17:15:46 --> URI Class Initialized
INFO - 2020-09-18 17:15:46 --> Router Class Initialized
INFO - 2020-09-18 17:15:46 --> Output Class Initialized
INFO - 2020-09-18 17:15:46 --> Security Class Initialized
DEBUG - 2020-09-18 17:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:15:46 --> Input Class Initialized
INFO - 2020-09-18 17:15:46 --> Language Class Initialized
INFO - 2020-09-18 17:15:46 --> Loader Class Initialized
INFO - 2020-09-18 17:15:46 --> Helper loaded: url_helper
INFO - 2020-09-18 17:15:46 --> Database Driver Class Initialized
INFO - 2020-09-18 17:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:15:46 --> Email Class Initialized
INFO - 2020-09-18 17:15:46 --> Controller Class Initialized
DEBUG - 2020-09-18 17:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:15:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:15:46 --> Model Class Initialized
INFO - 2020-09-18 17:15:46 --> Model Class Initialized
ERROR - 2020-09-18 17:15:46 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list; expected 1, got 0 - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:15:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:16:15 --> Config Class Initialized
INFO - 2020-09-18 17:16:15 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:16:15 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:16:15 --> Utf8 Class Initialized
INFO - 2020-09-18 17:16:15 --> URI Class Initialized
INFO - 2020-09-18 17:16:15 --> Router Class Initialized
INFO - 2020-09-18 17:16:15 --> Output Class Initialized
INFO - 2020-09-18 17:16:15 --> Security Class Initialized
DEBUG - 2020-09-18 17:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:16:15 --> Input Class Initialized
INFO - 2020-09-18 17:16:15 --> Language Class Initialized
INFO - 2020-09-18 17:16:15 --> Loader Class Initialized
INFO - 2020-09-18 17:16:15 --> Helper loaded: url_helper
INFO - 2020-09-18 17:16:15 --> Database Driver Class Initialized
INFO - 2020-09-18 17:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:16:15 --> Email Class Initialized
INFO - 2020-09-18 17:16:15 --> Controller Class Initialized
DEBUG - 2020-09-18 17:16:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:16:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:16:15 --> Model Class Initialized
INFO - 2020-09-18 17:16:15 --> Model Class Initialized
INFO - 2020-09-18 17:16:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:16:15 --> Final output sent to browser
DEBUG - 2020-09-18 17:16:15 --> Total execution time: 0.0225
ERROR - 2020-09-18 17:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:16:22 --> Config Class Initialized
INFO - 2020-09-18 17:16:22 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:16:22 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:16:22 --> Utf8 Class Initialized
INFO - 2020-09-18 17:16:22 --> URI Class Initialized
INFO - 2020-09-18 17:16:22 --> Router Class Initialized
INFO - 2020-09-18 17:16:22 --> Output Class Initialized
INFO - 2020-09-18 17:16:22 --> Security Class Initialized
DEBUG - 2020-09-18 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:16:22 --> Input Class Initialized
INFO - 2020-09-18 17:16:22 --> Language Class Initialized
INFO - 2020-09-18 17:16:22 --> Loader Class Initialized
INFO - 2020-09-18 17:16:22 --> Helper loaded: url_helper
INFO - 2020-09-18 17:16:22 --> Database Driver Class Initialized
INFO - 2020-09-18 17:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:16:22 --> Email Class Initialized
INFO - 2020-09-18 17:16:22 --> Controller Class Initialized
DEBUG - 2020-09-18 17:16:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:16:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:16:22 --> Model Class Initialized
INFO - 2020-09-18 17:16:22 --> Model Class Initialized
INFO - 2020-09-18 17:16:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:16:22 --> Final output sent to browser
DEBUG - 2020-09-18 17:16:22 --> Total execution time: 0.0272
ERROR - 2020-09-18 17:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:17:43 --> Config Class Initialized
INFO - 2020-09-18 17:17:43 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:17:43 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:17:43 --> Utf8 Class Initialized
INFO - 2020-09-18 17:17:43 --> URI Class Initialized
INFO - 2020-09-18 17:17:43 --> Router Class Initialized
INFO - 2020-09-18 17:17:43 --> Output Class Initialized
INFO - 2020-09-18 17:17:43 --> Security Class Initialized
DEBUG - 2020-09-18 17:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:17:43 --> Input Class Initialized
INFO - 2020-09-18 17:17:43 --> Language Class Initialized
INFO - 2020-09-18 17:17:43 --> Loader Class Initialized
INFO - 2020-09-18 17:17:43 --> Helper loaded: url_helper
INFO - 2020-09-18 17:17:43 --> Database Driver Class Initialized
INFO - 2020-09-18 17:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:17:43 --> Email Class Initialized
INFO - 2020-09-18 17:17:43 --> Controller Class Initialized
DEBUG - 2020-09-18 17:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:17:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:17:43 --> Model Class Initialized
INFO - 2020-09-18 17:17:43 --> Model Class Initialized
INFO - 2020-09-18 17:17:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:17:43 --> Final output sent to browser
DEBUG - 2020-09-18 17:17:43 --> Total execution time: 0.0226
ERROR - 2020-09-18 17:17:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:17:45 --> Config Class Initialized
INFO - 2020-09-18 17:17:45 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:17:45 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:17:45 --> Utf8 Class Initialized
INFO - 2020-09-18 17:17:45 --> URI Class Initialized
INFO - 2020-09-18 17:17:45 --> Router Class Initialized
INFO - 2020-09-18 17:17:45 --> Output Class Initialized
INFO - 2020-09-18 17:17:45 --> Security Class Initialized
DEBUG - 2020-09-18 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:17:45 --> Input Class Initialized
INFO - 2020-09-18 17:17:45 --> Language Class Initialized
INFO - 2020-09-18 17:17:45 --> Loader Class Initialized
INFO - 2020-09-18 17:17:45 --> Helper loaded: url_helper
INFO - 2020-09-18 17:17:45 --> Database Driver Class Initialized
INFO - 2020-09-18 17:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:17:45 --> Email Class Initialized
INFO - 2020-09-18 17:17:45 --> Controller Class Initialized
DEBUG - 2020-09-18 17:17:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:17:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:17:45 --> Model Class Initialized
INFO - 2020-09-18 17:17:45 --> Model Class Initialized
INFO - 2020-09-18 17:17:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:17:45 --> Final output sent to browser
DEBUG - 2020-09-18 17:17:45 --> Total execution time: 0.0316
ERROR - 2020-09-18 17:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:17:59 --> Config Class Initialized
INFO - 2020-09-18 17:17:59 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:17:59 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:17:59 --> Utf8 Class Initialized
INFO - 2020-09-18 17:17:59 --> URI Class Initialized
INFO - 2020-09-18 17:17:59 --> Router Class Initialized
INFO - 2020-09-18 17:17:59 --> Output Class Initialized
INFO - 2020-09-18 17:17:59 --> Security Class Initialized
DEBUG - 2020-09-18 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:17:59 --> Input Class Initialized
INFO - 2020-09-18 17:17:59 --> Language Class Initialized
INFO - 2020-09-18 17:17:59 --> Loader Class Initialized
INFO - 2020-09-18 17:17:59 --> Helper loaded: url_helper
INFO - 2020-09-18 17:17:59 --> Database Driver Class Initialized
INFO - 2020-09-18 17:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:17:59 --> Email Class Initialized
INFO - 2020-09-18 17:17:59 --> Controller Class Initialized
DEBUG - 2020-09-18 17:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:17:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:17:59 --> Model Class Initialized
INFO - 2020-09-18 17:17:59 --> Model Class Initialized
INFO - 2020-09-18 17:17:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:17:59 --> Final output sent to browser
DEBUG - 2020-09-18 17:17:59 --> Total execution time: 0.0217
ERROR - 2020-09-18 17:18:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:18:02 --> Config Class Initialized
INFO - 2020-09-18 17:18:02 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:18:02 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:18:02 --> Utf8 Class Initialized
INFO - 2020-09-18 17:18:02 --> URI Class Initialized
INFO - 2020-09-18 17:18:02 --> Router Class Initialized
INFO - 2020-09-18 17:18:02 --> Output Class Initialized
INFO - 2020-09-18 17:18:02 --> Security Class Initialized
DEBUG - 2020-09-18 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:18:02 --> Input Class Initialized
INFO - 2020-09-18 17:18:02 --> Language Class Initialized
INFO - 2020-09-18 17:18:02 --> Loader Class Initialized
INFO - 2020-09-18 17:18:02 --> Helper loaded: url_helper
INFO - 2020-09-18 17:18:02 --> Database Driver Class Initialized
INFO - 2020-09-18 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:18:02 --> Email Class Initialized
INFO - 2020-09-18 17:18:02 --> Controller Class Initialized
DEBUG - 2020-09-18 17:18:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:18:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:18:02 --> Model Class Initialized
INFO - 2020-09-18 17:18:02 --> Model Class Initialized
INFO - 2020-09-18 17:18:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:18:02 --> Final output sent to browser
DEBUG - 2020-09-18 17:18:02 --> Total execution time: 0.0255
ERROR - 2020-09-18 17:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:19:47 --> Config Class Initialized
INFO - 2020-09-18 17:19:47 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:19:47 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:19:47 --> Utf8 Class Initialized
INFO - 2020-09-18 17:19:47 --> URI Class Initialized
INFO - 2020-09-18 17:19:47 --> Router Class Initialized
INFO - 2020-09-18 17:19:47 --> Output Class Initialized
INFO - 2020-09-18 17:19:47 --> Security Class Initialized
DEBUG - 2020-09-18 17:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:19:47 --> Input Class Initialized
INFO - 2020-09-18 17:19:47 --> Language Class Initialized
INFO - 2020-09-18 17:19:47 --> Loader Class Initialized
INFO - 2020-09-18 17:19:47 --> Helper loaded: url_helper
INFO - 2020-09-18 17:19:47 --> Database Driver Class Initialized
INFO - 2020-09-18 17:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:19:47 --> Email Class Initialized
INFO - 2020-09-18 17:19:47 --> Controller Class Initialized
DEBUG - 2020-09-18 17:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:19:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:19:47 --> Model Class Initialized
INFO - 2020-09-18 17:19:47 --> Model Class Initialized
INFO - 2020-09-18 17:19:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:19:47 --> Final output sent to browser
DEBUG - 2020-09-18 17:19:47 --> Total execution time: 0.0211
ERROR - 2020-09-18 17:19:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:19:48 --> Config Class Initialized
INFO - 2020-09-18 17:19:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:19:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:19:48 --> Utf8 Class Initialized
INFO - 2020-09-18 17:19:48 --> URI Class Initialized
INFO - 2020-09-18 17:19:48 --> Router Class Initialized
INFO - 2020-09-18 17:19:48 --> Output Class Initialized
INFO - 2020-09-18 17:19:48 --> Security Class Initialized
DEBUG - 2020-09-18 17:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:19:48 --> Input Class Initialized
INFO - 2020-09-18 17:19:48 --> Language Class Initialized
INFO - 2020-09-18 17:19:48 --> Loader Class Initialized
INFO - 2020-09-18 17:19:48 --> Helper loaded: url_helper
INFO - 2020-09-18 17:19:48 --> Database Driver Class Initialized
INFO - 2020-09-18 17:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:19:48 --> Email Class Initialized
INFO - 2020-09-18 17:19:48 --> Controller Class Initialized
DEBUG - 2020-09-18 17:19:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:19:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:19:48 --> Model Class Initialized
INFO - 2020-09-18 17:19:48 --> Model Class Initialized
INFO - 2020-09-18 17:19:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:19:48 --> Final output sent to browser
DEBUG - 2020-09-18 17:19:48 --> Total execution time: 0.0242
ERROR - 2020-09-18 17:19:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:19:50 --> Config Class Initialized
INFO - 2020-09-18 17:19:50 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:19:50 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:19:50 --> Utf8 Class Initialized
INFO - 2020-09-18 17:19:50 --> URI Class Initialized
INFO - 2020-09-18 17:19:50 --> Router Class Initialized
INFO - 2020-09-18 17:19:50 --> Output Class Initialized
INFO - 2020-09-18 17:19:50 --> Security Class Initialized
DEBUG - 2020-09-18 17:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:19:50 --> Input Class Initialized
INFO - 2020-09-18 17:19:50 --> Language Class Initialized
INFO - 2020-09-18 17:19:50 --> Loader Class Initialized
INFO - 2020-09-18 17:19:50 --> Helper loaded: url_helper
INFO - 2020-09-18 17:19:50 --> Database Driver Class Initialized
INFO - 2020-09-18 17:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:19:50 --> Email Class Initialized
INFO - 2020-09-18 17:19:50 --> Controller Class Initialized
DEBUG - 2020-09-18 17:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:19:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:19:50 --> Model Class Initialized
INFO - 2020-09-18 17:19:50 --> Model Class Initialized
ERROR - 2020-09-18 17:19:50 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list; expected 1, got 0 - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:19:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:19:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:19:56 --> Config Class Initialized
INFO - 2020-09-18 17:19:56 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:19:56 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:19:56 --> Utf8 Class Initialized
INFO - 2020-09-18 17:19:56 --> URI Class Initialized
INFO - 2020-09-18 17:19:56 --> Router Class Initialized
INFO - 2020-09-18 17:19:56 --> Output Class Initialized
INFO - 2020-09-18 17:19:56 --> Security Class Initialized
DEBUG - 2020-09-18 17:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:19:56 --> Input Class Initialized
INFO - 2020-09-18 17:19:56 --> Language Class Initialized
INFO - 2020-09-18 17:19:56 --> Loader Class Initialized
INFO - 2020-09-18 17:19:56 --> Helper loaded: url_helper
INFO - 2020-09-18 17:19:56 --> Database Driver Class Initialized
INFO - 2020-09-18 17:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:19:56 --> Email Class Initialized
INFO - 2020-09-18 17:19:56 --> Controller Class Initialized
DEBUG - 2020-09-18 17:19:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:19:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:19:56 --> Model Class Initialized
INFO - 2020-09-18 17:19:56 --> Model Class Initialized
INFO - 2020-09-18 17:19:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:19:56 --> Final output sent to browser
DEBUG - 2020-09-18 17:19:56 --> Total execution time: 0.0233
ERROR - 2020-09-18 17:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:20:17 --> Config Class Initialized
INFO - 2020-09-18 17:20:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:20:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:20:17 --> Utf8 Class Initialized
INFO - 2020-09-18 17:20:17 --> URI Class Initialized
INFO - 2020-09-18 17:20:17 --> Router Class Initialized
INFO - 2020-09-18 17:20:17 --> Output Class Initialized
INFO - 2020-09-18 17:20:17 --> Security Class Initialized
DEBUG - 2020-09-18 17:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:20:17 --> Input Class Initialized
INFO - 2020-09-18 17:20:17 --> Language Class Initialized
INFO - 2020-09-18 17:20:17 --> Loader Class Initialized
INFO - 2020-09-18 17:20:17 --> Helper loaded: url_helper
INFO - 2020-09-18 17:20:17 --> Database Driver Class Initialized
INFO - 2020-09-18 17:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:20:17 --> Email Class Initialized
INFO - 2020-09-18 17:20:17 --> Controller Class Initialized
DEBUG - 2020-09-18 17:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:20:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:20:17 --> Model Class Initialized
INFO - 2020-09-18 17:20:17 --> Model Class Initialized
ERROR - 2020-09-18 17:20:17 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list; expected 1, got 0 - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:20:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:20:59 --> Config Class Initialized
INFO - 2020-09-18 17:20:59 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:20:59 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:20:59 --> Utf8 Class Initialized
INFO - 2020-09-18 17:20:59 --> URI Class Initialized
INFO - 2020-09-18 17:20:59 --> Router Class Initialized
INFO - 2020-09-18 17:20:59 --> Output Class Initialized
INFO - 2020-09-18 17:20:59 --> Security Class Initialized
DEBUG - 2020-09-18 17:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:20:59 --> Input Class Initialized
INFO - 2020-09-18 17:20:59 --> Language Class Initialized
INFO - 2020-09-18 17:20:59 --> Loader Class Initialized
INFO - 2020-09-18 17:20:59 --> Helper loaded: url_helper
INFO - 2020-09-18 17:20:59 --> Database Driver Class Initialized
INFO - 2020-09-18 17:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:20:59 --> Email Class Initialized
INFO - 2020-09-18 17:20:59 --> Controller Class Initialized
DEBUG - 2020-09-18 17:20:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:20:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:20:59 --> Model Class Initialized
INFO - 2020-09-18 17:20:59 --> Model Class Initialized
INFO - 2020-09-18 17:20:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:20:59 --> Final output sent to browser
DEBUG - 2020-09-18 17:20:59 --> Total execution time: 0.0262
ERROR - 2020-09-18 17:21:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:21:03 --> Config Class Initialized
INFO - 2020-09-18 17:21:03 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:21:03 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:21:03 --> Utf8 Class Initialized
INFO - 2020-09-18 17:21:03 --> URI Class Initialized
INFO - 2020-09-18 17:21:03 --> Router Class Initialized
INFO - 2020-09-18 17:21:03 --> Output Class Initialized
INFO - 2020-09-18 17:21:03 --> Security Class Initialized
DEBUG - 2020-09-18 17:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:21:03 --> Input Class Initialized
INFO - 2020-09-18 17:21:03 --> Language Class Initialized
INFO - 2020-09-18 17:21:03 --> Loader Class Initialized
INFO - 2020-09-18 17:21:03 --> Helper loaded: url_helper
INFO - 2020-09-18 17:21:03 --> Database Driver Class Initialized
INFO - 2020-09-18 17:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:21:03 --> Email Class Initialized
INFO - 2020-09-18 17:21:03 --> Controller Class Initialized
DEBUG - 2020-09-18 17:21:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:21:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:21:03 --> Model Class Initialized
INFO - 2020-09-18 17:21:03 --> Model Class Initialized
ERROR - 2020-09-18 17:21:03 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list; expected 1, got 0 - Invalid query: CALL status_master_list()
INFO - 2020-09-18 17:21:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:23:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:23:24 --> Config Class Initialized
INFO - 2020-09-18 17:23:24 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:23:24 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:23:24 --> Utf8 Class Initialized
INFO - 2020-09-18 17:23:24 --> URI Class Initialized
INFO - 2020-09-18 17:23:24 --> Router Class Initialized
INFO - 2020-09-18 17:23:24 --> Output Class Initialized
INFO - 2020-09-18 17:23:24 --> Security Class Initialized
DEBUG - 2020-09-18 17:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:23:24 --> Input Class Initialized
INFO - 2020-09-18 17:23:24 --> Language Class Initialized
INFO - 2020-09-18 17:23:24 --> Loader Class Initialized
INFO - 2020-09-18 17:23:24 --> Helper loaded: url_helper
INFO - 2020-09-18 17:23:24 --> Database Driver Class Initialized
INFO - 2020-09-18 17:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:23:24 --> Email Class Initialized
INFO - 2020-09-18 17:23:24 --> Controller Class Initialized
DEBUG - 2020-09-18 17:23:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:23:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:23:24 --> Model Class Initialized
INFO - 2020-09-18 17:23:24 --> Model Class Initialized
ERROR - 2020-09-18 17:23:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: CALL status_master_list(
INFO - 2020-09-18 17:23:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-18 17:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:24:17 --> Config Class Initialized
INFO - 2020-09-18 17:24:17 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:24:17 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:24:17 --> Utf8 Class Initialized
INFO - 2020-09-18 17:24:17 --> URI Class Initialized
INFO - 2020-09-18 17:24:17 --> Router Class Initialized
INFO - 2020-09-18 17:24:17 --> Output Class Initialized
INFO - 2020-09-18 17:24:17 --> Security Class Initialized
DEBUG - 2020-09-18 17:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:24:17 --> Input Class Initialized
INFO - 2020-09-18 17:24:17 --> Language Class Initialized
INFO - 2020-09-18 17:24:17 --> Loader Class Initialized
INFO - 2020-09-18 17:24:17 --> Helper loaded: url_helper
INFO - 2020-09-18 17:24:17 --> Database Driver Class Initialized
INFO - 2020-09-18 17:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:24:17 --> Email Class Initialized
INFO - 2020-09-18 17:24:17 --> Controller Class Initialized
DEBUG - 2020-09-18 17:24:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:24:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:24:17 --> Model Class Initialized
INFO - 2020-09-18 17:24:17 --> Model Class Initialized
INFO - 2020-09-18 17:24:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:24:17 --> Final output sent to browser
DEBUG - 2020-09-18 17:24:17 --> Total execution time: 0.0250
ERROR - 2020-09-18 17:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:24:21 --> Config Class Initialized
INFO - 2020-09-18 17:24:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:24:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:24:21 --> Utf8 Class Initialized
INFO - 2020-09-18 17:24:21 --> URI Class Initialized
INFO - 2020-09-18 17:24:21 --> Router Class Initialized
INFO - 2020-09-18 17:24:21 --> Output Class Initialized
INFO - 2020-09-18 17:24:21 --> Security Class Initialized
DEBUG - 2020-09-18 17:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:24:21 --> Input Class Initialized
INFO - 2020-09-18 17:24:21 --> Language Class Initialized
INFO - 2020-09-18 17:24:21 --> Loader Class Initialized
INFO - 2020-09-18 17:24:21 --> Helper loaded: url_helper
INFO - 2020-09-18 17:24:21 --> Database Driver Class Initialized
INFO - 2020-09-18 17:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:24:21 --> Email Class Initialized
INFO - 2020-09-18 17:24:21 --> Controller Class Initialized
DEBUG - 2020-09-18 17:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:24:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:24:21 --> Model Class Initialized
INFO - 2020-09-18 17:24:21 --> Model Class Initialized
INFO - 2020-09-18 17:24:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:24:21 --> Final output sent to browser
DEBUG - 2020-09-18 17:24:21 --> Total execution time: 0.0272
ERROR - 2020-09-18 17:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:24:23 --> Config Class Initialized
INFO - 2020-09-18 17:24:23 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:24:23 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:24:23 --> Utf8 Class Initialized
INFO - 2020-09-18 17:24:23 --> URI Class Initialized
INFO - 2020-09-18 17:24:23 --> Router Class Initialized
INFO - 2020-09-18 17:24:23 --> Output Class Initialized
INFO - 2020-09-18 17:24:23 --> Security Class Initialized
DEBUG - 2020-09-18 17:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:24:23 --> Input Class Initialized
INFO - 2020-09-18 17:24:23 --> Language Class Initialized
INFO - 2020-09-18 17:24:23 --> Loader Class Initialized
INFO - 2020-09-18 17:24:23 --> Helper loaded: url_helper
INFO - 2020-09-18 17:24:23 --> Database Driver Class Initialized
INFO - 2020-09-18 17:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:24:23 --> Email Class Initialized
INFO - 2020-09-18 17:24:23 --> Controller Class Initialized
DEBUG - 2020-09-18 17:24:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:24:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:24:23 --> Model Class Initialized
INFO - 2020-09-18 17:24:23 --> Model Class Initialized
INFO - 2020-09-18 17:24:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:24:23 --> Final output sent to browser
DEBUG - 2020-09-18 17:24:23 --> Total execution time: 0.0267
ERROR - 2020-09-18 17:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:25:16 --> Config Class Initialized
INFO - 2020-09-18 17:25:16 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:25:16 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:25:16 --> Utf8 Class Initialized
INFO - 2020-09-18 17:25:16 --> URI Class Initialized
INFO - 2020-09-18 17:25:16 --> Router Class Initialized
INFO - 2020-09-18 17:25:16 --> Output Class Initialized
INFO - 2020-09-18 17:25:16 --> Security Class Initialized
DEBUG - 2020-09-18 17:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:25:16 --> Input Class Initialized
INFO - 2020-09-18 17:25:16 --> Language Class Initialized
INFO - 2020-09-18 17:25:16 --> Loader Class Initialized
INFO - 2020-09-18 17:25:16 --> Helper loaded: url_helper
INFO - 2020-09-18 17:25:16 --> Database Driver Class Initialized
INFO - 2020-09-18 17:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:25:16 --> Email Class Initialized
INFO - 2020-09-18 17:25:16 --> Controller Class Initialized
DEBUG - 2020-09-18 17:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:25:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:25:16 --> Model Class Initialized
INFO - 2020-09-18 17:25:16 --> Model Class Initialized
INFO - 2020-09-18 17:25:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:25:16 --> Final output sent to browser
DEBUG - 2020-09-18 17:25:16 --> Total execution time: 0.0321
ERROR - 2020-09-18 17:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:27:57 --> Config Class Initialized
INFO - 2020-09-18 17:27:57 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:27:57 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:27:57 --> Utf8 Class Initialized
INFO - 2020-09-18 17:27:57 --> URI Class Initialized
INFO - 2020-09-18 17:27:57 --> Router Class Initialized
INFO - 2020-09-18 17:27:57 --> Output Class Initialized
INFO - 2020-09-18 17:27:57 --> Security Class Initialized
DEBUG - 2020-09-18 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:27:57 --> Input Class Initialized
INFO - 2020-09-18 17:27:57 --> Language Class Initialized
INFO - 2020-09-18 17:27:57 --> Loader Class Initialized
INFO - 2020-09-18 17:27:57 --> Helper loaded: url_helper
INFO - 2020-09-18 17:27:57 --> Database Driver Class Initialized
INFO - 2020-09-18 17:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:27:57 --> Email Class Initialized
INFO - 2020-09-18 17:27:57 --> Controller Class Initialized
DEBUG - 2020-09-18 17:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:27:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:27:57 --> Model Class Initialized
INFO - 2020-09-18 17:27:57 --> Model Class Initialized
INFO - 2020-09-18 17:27:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:27:57 --> Final output sent to browser
DEBUG - 2020-09-18 17:27:57 --> Total execution time: 0.0237
ERROR - 2020-09-18 17:32:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:32:37 --> Config Class Initialized
INFO - 2020-09-18 17:32:37 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:32:37 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:32:37 --> Utf8 Class Initialized
INFO - 2020-09-18 17:32:37 --> URI Class Initialized
INFO - 2020-09-18 17:32:37 --> Router Class Initialized
INFO - 2020-09-18 17:32:37 --> Output Class Initialized
INFO - 2020-09-18 17:32:37 --> Security Class Initialized
DEBUG - 2020-09-18 17:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:32:37 --> Input Class Initialized
INFO - 2020-09-18 17:32:37 --> Language Class Initialized
INFO - 2020-09-18 17:32:37 --> Loader Class Initialized
INFO - 2020-09-18 17:32:37 --> Helper loaded: url_helper
INFO - 2020-09-18 17:32:37 --> Database Driver Class Initialized
INFO - 2020-09-18 17:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:32:37 --> Email Class Initialized
INFO - 2020-09-18 17:32:37 --> Controller Class Initialized
DEBUG - 2020-09-18 17:32:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:32:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:32:37 --> Model Class Initialized
INFO - 2020-09-18 17:32:37 --> Model Class Initialized
INFO - 2020-09-18 17:32:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:32:37 --> Final output sent to browser
DEBUG - 2020-09-18 17:32:37 --> Total execution time: 0.0274
ERROR - 2020-09-18 17:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:32:42 --> Config Class Initialized
INFO - 2020-09-18 17:32:42 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:32:42 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:32:42 --> Utf8 Class Initialized
INFO - 2020-09-18 17:32:42 --> URI Class Initialized
INFO - 2020-09-18 17:32:42 --> Router Class Initialized
INFO - 2020-09-18 17:32:42 --> Output Class Initialized
INFO - 2020-09-18 17:32:42 --> Security Class Initialized
DEBUG - 2020-09-18 17:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:32:42 --> Input Class Initialized
INFO - 2020-09-18 17:32:42 --> Language Class Initialized
INFO - 2020-09-18 17:32:42 --> Loader Class Initialized
INFO - 2020-09-18 17:32:42 --> Helper loaded: url_helper
INFO - 2020-09-18 17:32:42 --> Database Driver Class Initialized
INFO - 2020-09-18 17:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:32:42 --> Email Class Initialized
INFO - 2020-09-18 17:32:42 --> Controller Class Initialized
DEBUG - 2020-09-18 17:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:32:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:32:42 --> Model Class Initialized
INFO - 2020-09-18 17:32:42 --> Model Class Initialized
INFO - 2020-09-18 17:32:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:32:42 --> Final output sent to browser
DEBUG - 2020-09-18 17:32:42 --> Total execution time: 0.0243
ERROR - 2020-09-18 17:32:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:32:44 --> Config Class Initialized
INFO - 2020-09-18 17:32:44 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:32:44 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:32:44 --> Utf8 Class Initialized
INFO - 2020-09-18 17:32:44 --> URI Class Initialized
INFO - 2020-09-18 17:32:44 --> Router Class Initialized
INFO - 2020-09-18 17:32:44 --> Output Class Initialized
INFO - 2020-09-18 17:32:44 --> Security Class Initialized
DEBUG - 2020-09-18 17:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:32:44 --> Input Class Initialized
INFO - 2020-09-18 17:32:44 --> Language Class Initialized
INFO - 2020-09-18 17:32:44 --> Loader Class Initialized
INFO - 2020-09-18 17:32:44 --> Helper loaded: url_helper
INFO - 2020-09-18 17:32:44 --> Database Driver Class Initialized
INFO - 2020-09-18 17:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:32:44 --> Email Class Initialized
INFO - 2020-09-18 17:32:44 --> Controller Class Initialized
DEBUG - 2020-09-18 17:32:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:32:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:32:44 --> Model Class Initialized
INFO - 2020-09-18 17:32:44 --> Model Class Initialized
INFO - 2020-09-18 17:32:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:32:44 --> Final output sent to browser
DEBUG - 2020-09-18 17:32:44 --> Total execution time: 0.0239
ERROR - 2020-09-18 17:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:33:34 --> Config Class Initialized
INFO - 2020-09-18 17:33:34 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:33:34 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:33:34 --> Utf8 Class Initialized
INFO - 2020-09-18 17:33:34 --> URI Class Initialized
INFO - 2020-09-18 17:33:34 --> Router Class Initialized
INFO - 2020-09-18 17:33:34 --> Output Class Initialized
INFO - 2020-09-18 17:33:34 --> Security Class Initialized
DEBUG - 2020-09-18 17:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:33:34 --> Input Class Initialized
INFO - 2020-09-18 17:33:34 --> Language Class Initialized
INFO - 2020-09-18 17:33:34 --> Loader Class Initialized
INFO - 2020-09-18 17:33:34 --> Helper loaded: url_helper
INFO - 2020-09-18 17:33:34 --> Database Driver Class Initialized
INFO - 2020-09-18 17:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:33:34 --> Email Class Initialized
INFO - 2020-09-18 17:33:34 --> Controller Class Initialized
DEBUG - 2020-09-18 17:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:33:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:33:34 --> Model Class Initialized
INFO - 2020-09-18 17:33:34 --> Model Class Initialized
INFO - 2020-09-18 17:33:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:33:34 --> Final output sent to browser
DEBUG - 2020-09-18 17:33:34 --> Total execution time: 0.0257
ERROR - 2020-09-18 17:33:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:33:46 --> Config Class Initialized
INFO - 2020-09-18 17:33:46 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:33:46 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:33:46 --> Utf8 Class Initialized
INFO - 2020-09-18 17:33:46 --> URI Class Initialized
INFO - 2020-09-18 17:33:46 --> Router Class Initialized
INFO - 2020-09-18 17:33:46 --> Output Class Initialized
INFO - 2020-09-18 17:33:46 --> Security Class Initialized
DEBUG - 2020-09-18 17:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:33:46 --> Input Class Initialized
INFO - 2020-09-18 17:33:46 --> Language Class Initialized
INFO - 2020-09-18 17:33:46 --> Loader Class Initialized
INFO - 2020-09-18 17:33:46 --> Helper loaded: url_helper
INFO - 2020-09-18 17:33:46 --> Database Driver Class Initialized
INFO - 2020-09-18 17:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:33:46 --> Email Class Initialized
INFO - 2020-09-18 17:33:46 --> Controller Class Initialized
DEBUG - 2020-09-18 17:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:33:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:33:46 --> Model Class Initialized
INFO - 2020-09-18 17:33:46 --> Model Class Initialized
INFO - 2020-09-18 17:33:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:33:46 --> Final output sent to browser
DEBUG - 2020-09-18 17:33:46 --> Total execution time: 0.0272
ERROR - 2020-09-18 17:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:33:48 --> Config Class Initialized
INFO - 2020-09-18 17:33:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:33:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:33:48 --> Utf8 Class Initialized
INFO - 2020-09-18 17:33:48 --> URI Class Initialized
INFO - 2020-09-18 17:33:48 --> Router Class Initialized
INFO - 2020-09-18 17:33:48 --> Output Class Initialized
INFO - 2020-09-18 17:33:48 --> Security Class Initialized
DEBUG - 2020-09-18 17:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:33:48 --> Input Class Initialized
INFO - 2020-09-18 17:33:48 --> Language Class Initialized
INFO - 2020-09-18 17:33:48 --> Loader Class Initialized
INFO - 2020-09-18 17:33:48 --> Helper loaded: url_helper
INFO - 2020-09-18 17:33:48 --> Database Driver Class Initialized
INFO - 2020-09-18 17:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:33:48 --> Email Class Initialized
INFO - 2020-09-18 17:33:48 --> Controller Class Initialized
DEBUG - 2020-09-18 17:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:33:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:33:48 --> Model Class Initialized
INFO - 2020-09-18 17:33:48 --> Model Class Initialized
INFO - 2020-09-18 17:33:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:33:48 --> Final output sent to browser
DEBUG - 2020-09-18 17:33:48 --> Total execution time: 0.0288
ERROR - 2020-09-18 17:34:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:34:05 --> Config Class Initialized
INFO - 2020-09-18 17:34:05 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:34:05 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:34:05 --> Utf8 Class Initialized
INFO - 2020-09-18 17:34:05 --> URI Class Initialized
INFO - 2020-09-18 17:34:05 --> Router Class Initialized
INFO - 2020-09-18 17:34:05 --> Output Class Initialized
INFO - 2020-09-18 17:34:05 --> Security Class Initialized
DEBUG - 2020-09-18 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:34:05 --> Input Class Initialized
INFO - 2020-09-18 17:34:05 --> Language Class Initialized
INFO - 2020-09-18 17:34:05 --> Loader Class Initialized
INFO - 2020-09-18 17:34:05 --> Helper loaded: url_helper
INFO - 2020-09-18 17:34:05 --> Database Driver Class Initialized
INFO - 2020-09-18 17:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:34:05 --> Email Class Initialized
INFO - 2020-09-18 17:34:05 --> Controller Class Initialized
DEBUG - 2020-09-18 17:34:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:34:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:34:05 --> Model Class Initialized
INFO - 2020-09-18 17:34:05 --> Model Class Initialized
INFO - 2020-09-18 17:34:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:34:05 --> Final output sent to browser
DEBUG - 2020-09-18 17:34:05 --> Total execution time: 0.0208
ERROR - 2020-09-18 17:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:35:48 --> Config Class Initialized
INFO - 2020-09-18 17:35:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:35:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:35:48 --> Utf8 Class Initialized
INFO - 2020-09-18 17:35:48 --> URI Class Initialized
INFO - 2020-09-18 17:35:48 --> Router Class Initialized
INFO - 2020-09-18 17:35:48 --> Output Class Initialized
INFO - 2020-09-18 17:35:48 --> Security Class Initialized
DEBUG - 2020-09-18 17:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:35:48 --> Input Class Initialized
INFO - 2020-09-18 17:35:48 --> Language Class Initialized
INFO - 2020-09-18 17:35:48 --> Loader Class Initialized
INFO - 2020-09-18 17:35:48 --> Helper loaded: url_helper
INFO - 2020-09-18 17:35:48 --> Database Driver Class Initialized
INFO - 2020-09-18 17:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:35:48 --> Email Class Initialized
INFO - 2020-09-18 17:35:48 --> Controller Class Initialized
DEBUG - 2020-09-18 17:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:35:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:35:48 --> Model Class Initialized
INFO - 2020-09-18 17:35:48 --> Model Class Initialized
INFO - 2020-09-18 17:35:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-18 17:35:48 --> Final output sent to browser
DEBUG - 2020-09-18 17:35:48 --> Total execution time: 0.0181
ERROR - 2020-09-18 17:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:35:52 --> Config Class Initialized
INFO - 2020-09-18 17:35:52 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:35:52 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:35:52 --> Utf8 Class Initialized
INFO - 2020-09-18 17:35:52 --> URI Class Initialized
INFO - 2020-09-18 17:35:52 --> Router Class Initialized
INFO - 2020-09-18 17:35:52 --> Output Class Initialized
INFO - 2020-09-18 17:35:52 --> Security Class Initialized
DEBUG - 2020-09-18 17:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:35:52 --> Input Class Initialized
INFO - 2020-09-18 17:35:52 --> Language Class Initialized
INFO - 2020-09-18 17:35:52 --> Loader Class Initialized
INFO - 2020-09-18 17:35:52 --> Helper loaded: url_helper
INFO - 2020-09-18 17:35:52 --> Database Driver Class Initialized
INFO - 2020-09-18 17:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:35:52 --> Email Class Initialized
INFO - 2020-09-18 17:35:52 --> Controller Class Initialized
DEBUG - 2020-09-18 17:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:35:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:35:52 --> Model Class Initialized
INFO - 2020-09-18 17:35:52 --> Model Class Initialized
INFO - 2020-09-18 17:35:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:35:52 --> Final output sent to browser
DEBUG - 2020-09-18 17:35:52 --> Total execution time: 0.0247
ERROR - 2020-09-18 17:36:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:36:48 --> Config Class Initialized
INFO - 2020-09-18 17:36:48 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:36:48 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:36:48 --> Utf8 Class Initialized
INFO - 2020-09-18 17:36:48 --> URI Class Initialized
INFO - 2020-09-18 17:36:48 --> Router Class Initialized
INFO - 2020-09-18 17:36:48 --> Output Class Initialized
INFO - 2020-09-18 17:36:48 --> Security Class Initialized
DEBUG - 2020-09-18 17:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:36:48 --> Input Class Initialized
INFO - 2020-09-18 17:36:48 --> Language Class Initialized
INFO - 2020-09-18 17:36:48 --> Loader Class Initialized
INFO - 2020-09-18 17:36:48 --> Helper loaded: url_helper
INFO - 2020-09-18 17:36:48 --> Database Driver Class Initialized
INFO - 2020-09-18 17:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:36:48 --> Email Class Initialized
INFO - 2020-09-18 17:36:48 --> Controller Class Initialized
DEBUG - 2020-09-18 17:36:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:36:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:36:48 --> Model Class Initialized
INFO - 2020-09-18 17:36:48 --> Model Class Initialized
INFO - 2020-09-18 17:36:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:36:48 --> Final output sent to browser
DEBUG - 2020-09-18 17:36:48 --> Total execution time: 0.0254
ERROR - 2020-09-18 17:36:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:36:51 --> Config Class Initialized
INFO - 2020-09-18 17:36:51 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:36:51 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:36:51 --> Utf8 Class Initialized
INFO - 2020-09-18 17:36:51 --> URI Class Initialized
INFO - 2020-09-18 17:36:51 --> Router Class Initialized
INFO - 2020-09-18 17:36:51 --> Output Class Initialized
INFO - 2020-09-18 17:36:51 --> Security Class Initialized
DEBUG - 2020-09-18 17:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:36:51 --> Input Class Initialized
INFO - 2020-09-18 17:36:51 --> Language Class Initialized
INFO - 2020-09-18 17:36:51 --> Loader Class Initialized
INFO - 2020-09-18 17:36:51 --> Helper loaded: url_helper
INFO - 2020-09-18 17:36:51 --> Database Driver Class Initialized
INFO - 2020-09-18 17:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:36:51 --> Email Class Initialized
INFO - 2020-09-18 17:36:51 --> Controller Class Initialized
DEBUG - 2020-09-18 17:36:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:36:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:36:51 --> Model Class Initialized
INFO - 2020-09-18 17:36:51 --> Model Class Initialized
INFO - 2020-09-18 17:36:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:36:51 --> Final output sent to browser
DEBUG - 2020-09-18 17:36:51 --> Total execution time: 0.0273
ERROR - 2020-09-18 17:37:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:37:09 --> Config Class Initialized
INFO - 2020-09-18 17:37:09 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:37:09 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:37:09 --> Utf8 Class Initialized
INFO - 2020-09-18 17:37:09 --> URI Class Initialized
INFO - 2020-09-18 17:37:09 --> Router Class Initialized
INFO - 2020-09-18 17:37:09 --> Output Class Initialized
INFO - 2020-09-18 17:37:09 --> Security Class Initialized
DEBUG - 2020-09-18 17:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:37:09 --> Input Class Initialized
INFO - 2020-09-18 17:37:09 --> Language Class Initialized
INFO - 2020-09-18 17:37:09 --> Loader Class Initialized
INFO - 2020-09-18 17:37:09 --> Helper loaded: url_helper
INFO - 2020-09-18 17:37:09 --> Database Driver Class Initialized
INFO - 2020-09-18 17:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:37:09 --> Email Class Initialized
INFO - 2020-09-18 17:37:09 --> Controller Class Initialized
DEBUG - 2020-09-18 17:37:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:37:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:37:09 --> Model Class Initialized
INFO - 2020-09-18 17:37:09 --> Model Class Initialized
INFO - 2020-09-18 17:37:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:37:09 --> Final output sent to browser
DEBUG - 2020-09-18 17:37:09 --> Total execution time: 0.0220
ERROR - 2020-09-18 17:37:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:37:20 --> Config Class Initialized
INFO - 2020-09-18 17:37:20 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:37:20 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:37:20 --> Utf8 Class Initialized
INFO - 2020-09-18 17:37:20 --> URI Class Initialized
INFO - 2020-09-18 17:37:20 --> Router Class Initialized
INFO - 2020-09-18 17:37:20 --> Output Class Initialized
INFO - 2020-09-18 17:37:20 --> Security Class Initialized
DEBUG - 2020-09-18 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:37:20 --> Input Class Initialized
INFO - 2020-09-18 17:37:20 --> Language Class Initialized
INFO - 2020-09-18 17:37:20 --> Loader Class Initialized
INFO - 2020-09-18 17:37:20 --> Helper loaded: url_helper
INFO - 2020-09-18 17:37:20 --> Database Driver Class Initialized
INFO - 2020-09-18 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:37:20 --> Email Class Initialized
INFO - 2020-09-18 17:37:20 --> Controller Class Initialized
DEBUG - 2020-09-18 17:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:37:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:37:20 --> Model Class Initialized
INFO - 2020-09-18 17:37:20 --> Model Class Initialized
INFO - 2020-09-18 17:37:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-18 17:37:20 --> Final output sent to browser
DEBUG - 2020-09-18 17:37:20 --> Total execution time: 0.0247
ERROR - 2020-09-18 17:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:42:21 --> Config Class Initialized
INFO - 2020-09-18 17:42:21 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:42:21 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:42:21 --> Utf8 Class Initialized
INFO - 2020-09-18 17:42:21 --> URI Class Initialized
INFO - 2020-09-18 17:42:21 --> Router Class Initialized
INFO - 2020-09-18 17:42:21 --> Output Class Initialized
INFO - 2020-09-18 17:42:21 --> Security Class Initialized
DEBUG - 2020-09-18 17:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:42:21 --> Input Class Initialized
INFO - 2020-09-18 17:42:21 --> Language Class Initialized
INFO - 2020-09-18 17:42:21 --> Loader Class Initialized
INFO - 2020-09-18 17:42:21 --> Helper loaded: url_helper
INFO - 2020-09-18 17:42:21 --> Database Driver Class Initialized
INFO - 2020-09-18 17:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:42:21 --> Email Class Initialized
INFO - 2020-09-18 17:42:21 --> Controller Class Initialized
DEBUG - 2020-09-18 17:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-18 17:42:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:42:21 --> Model Class Initialized
INFO - 2020-09-18 17:42:21 --> Model Class Initialized
INFO - 2020-09-18 17:42:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-18 17:42:21 --> Final output sent to browser
DEBUG - 2020-09-18 17:42:21 --> Total execution time: 0.0232
ERROR - 2020-09-18 17:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-18 17:42:25 --> Config Class Initialized
INFO - 2020-09-18 17:42:25 --> Hooks Class Initialized
DEBUG - 2020-09-18 17:42:25 --> UTF-8 Support Enabled
INFO - 2020-09-18 17:42:25 --> Utf8 Class Initialized
INFO - 2020-09-18 17:42:25 --> URI Class Initialized
DEBUG - 2020-09-18 17:42:25 --> No URI present. Default controller set.
INFO - 2020-09-18 17:42:25 --> Router Class Initialized
INFO - 2020-09-18 17:42:25 --> Output Class Initialized
INFO - 2020-09-18 17:42:25 --> Security Class Initialized
DEBUG - 2020-09-18 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-18 17:42:25 --> Input Class Initialized
INFO - 2020-09-18 17:42:25 --> Language Class Initialized
INFO - 2020-09-18 17:42:25 --> Loader Class Initialized
INFO - 2020-09-18 17:42:25 --> Helper loaded: url_helper
INFO - 2020-09-18 17:42:25 --> Database Driver Class Initialized
INFO - 2020-09-18 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-18 17:42:25 --> Email Class Initialized
INFO - 2020-09-18 17:42:25 --> Controller Class Initialized
INFO - 2020-09-18 17:42:25 --> Model Class Initialized
INFO - 2020-09-18 17:42:25 --> Model Class Initialized
DEBUG - 2020-09-18 17:42:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-18 17:42:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-18 17:42:25 --> Final output sent to browser
DEBUG - 2020-09-18 17:42:25 --> Total execution time: 0.0193
