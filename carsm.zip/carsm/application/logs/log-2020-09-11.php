<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-11 05:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:07:13 --> Config Class Initialized
INFO - 2020-09-11 05:07:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:07:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:07:13 --> Utf8 Class Initialized
INFO - 2020-09-11 05:07:13 --> URI Class Initialized
DEBUG - 2020-09-11 05:07:13 --> No URI present. Default controller set.
INFO - 2020-09-11 05:07:13 --> Router Class Initialized
INFO - 2020-09-11 05:07:13 --> Output Class Initialized
INFO - 2020-09-11 05:07:13 --> Security Class Initialized
DEBUG - 2020-09-11 05:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:07:13 --> Input Class Initialized
INFO - 2020-09-11 05:07:13 --> Language Class Initialized
INFO - 2020-09-11 05:07:13 --> Loader Class Initialized
INFO - 2020-09-11 05:07:13 --> Helper loaded: url_helper
INFO - 2020-09-11 05:07:13 --> Database Driver Class Initialized
INFO - 2020-09-11 05:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:07:14 --> Email Class Initialized
INFO - 2020-09-11 05:07:14 --> Controller Class Initialized
INFO - 2020-09-11 05:07:14 --> Model Class Initialized
INFO - 2020-09-11 05:07:14 --> Model Class Initialized
DEBUG - 2020-09-11 05:07:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 05:07:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 05:07:14 --> Final output sent to browser
DEBUG - 2020-09-11 05:07:14 --> Total execution time: 0.2780
ERROR - 2020-09-11 05:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:04 --> Config Class Initialized
INFO - 2020-09-11 05:08:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:04 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:04 --> URI Class Initialized
INFO - 2020-09-11 05:08:04 --> Router Class Initialized
INFO - 2020-09-11 05:08:04 --> Output Class Initialized
INFO - 2020-09-11 05:08:04 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:04 --> Input Class Initialized
INFO - 2020-09-11 05:08:04 --> Language Class Initialized
INFO - 2020-09-11 05:08:04 --> Loader Class Initialized
INFO - 2020-09-11 05:08:04 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:04 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:04 --> Session: Class initialized using 'files' driver.
ERROR - 2020-09-11 05:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:04 --> Email Class Initialized
INFO - 2020-09-11 05:08:04 --> Controller Class Initialized
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
INFO - 2020-09-11 05:08:04 --> Config Class Initialized
INFO - 2020-09-11 05:08:04 --> Hooks Class Initialized
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
DEBUG - 2020-09-11 05:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 05:08:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:04 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:04 --> URI Class Initialized
INFO - 2020-09-11 05:08:04 --> Router Class Initialized
INFO - 2020-09-11 05:08:04 --> Output Class Initialized
INFO - 2020-09-11 05:08:04 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:04 --> Input Class Initialized
INFO - 2020-09-11 05:08:04 --> Language Class Initialized
INFO - 2020-09-11 05:08:04 --> Loader Class Initialized
INFO - 2020-09-11 05:08:04 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:04 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:04 --> Email Class Initialized
INFO - 2020-09-11 05:08:04 --> Controller Class Initialized
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
DEBUG - 2020-09-11 05:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 05:08:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
INFO - 2020-09-11 05:08:04 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:04 --> Total execution time: 0.0544
ERROR - 2020-09-11 05:08:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:04 --> Config Class Initialized
INFO - 2020-09-11 05:08:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:04 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:04 --> URI Class Initialized
INFO - 2020-09-11 05:08:04 --> Router Class Initialized
INFO - 2020-09-11 05:08:04 --> Output Class Initialized
INFO - 2020-09-11 05:08:04 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:04 --> Input Class Initialized
INFO - 2020-09-11 05:08:04 --> Language Class Initialized
INFO - 2020-09-11 05:08:04 --> Loader Class Initialized
INFO - 2020-09-11 05:08:04 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:04 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:04 --> Email Class Initialized
INFO - 2020-09-11 05:08:04 --> Controller Class Initialized
DEBUG - 2020-09-11 05:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 05:08:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
INFO - 2020-09-11 05:08:04 --> Model Class Initialized
INFO - 2020-09-11 05:08:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 05:08:04 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:04 --> Total execution time: 0.0808
ERROR - 2020-09-11 05:08:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:17 --> Config Class Initialized
INFO - 2020-09-11 05:08:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:18 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:18 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:18 --> URI Class Initialized
INFO - 2020-09-11 05:08:18 --> Router Class Initialized
INFO - 2020-09-11 05:08:18 --> Output Class Initialized
INFO - 2020-09-11 05:08:18 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:18 --> Input Class Initialized
INFO - 2020-09-11 05:08:18 --> Language Class Initialized
INFO - 2020-09-11 05:08:18 --> Loader Class Initialized
INFO - 2020-09-11 05:08:18 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:18 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:18 --> Email Class Initialized
INFO - 2020-09-11 05:08:18 --> Controller Class Initialized
INFO - 2020-09-11 05:08:18 --> Model Class Initialized
INFO - 2020-09-11 05:08:18 --> Model Class Initialized
INFO - 2020-09-11 05:08:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:08:18 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:18 --> Total execution time: 0.2428
ERROR - 2020-09-11 05:08:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:19 --> Config Class Initialized
INFO - 2020-09-11 05:08:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:19 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:19 --> URI Class Initialized
INFO - 2020-09-11 05:08:19 --> Router Class Initialized
INFO - 2020-09-11 05:08:19 --> Output Class Initialized
INFO - 2020-09-11 05:08:19 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:19 --> Input Class Initialized
INFO - 2020-09-11 05:08:19 --> Language Class Initialized
INFO - 2020-09-11 05:08:19 --> Loader Class Initialized
INFO - 2020-09-11 05:08:19 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:19 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:19 --> Email Class Initialized
INFO - 2020-09-11 05:08:19 --> Controller Class Initialized
INFO - 2020-09-11 05:08:19 --> Model Class Initialized
INFO - 2020-09-11 05:08:19 --> Model Class Initialized
INFO - 2020-09-11 05:08:19 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:19 --> Total execution time: 0.0460
ERROR - 2020-09-11 05:08:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:28 --> Config Class Initialized
INFO - 2020-09-11 05:08:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:28 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:28 --> URI Class Initialized
INFO - 2020-09-11 05:08:28 --> Router Class Initialized
INFO - 2020-09-11 05:08:28 --> Output Class Initialized
INFO - 2020-09-11 05:08:28 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:28 --> Input Class Initialized
INFO - 2020-09-11 05:08:28 --> Language Class Initialized
INFO - 2020-09-11 05:08:28 --> Loader Class Initialized
INFO - 2020-09-11 05:08:28 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:28 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:28 --> Email Class Initialized
INFO - 2020-09-11 05:08:28 --> Controller Class Initialized
INFO - 2020-09-11 05:08:28 --> Model Class Initialized
INFO - 2020-09-11 05:08:28 --> Model Class Initialized
INFO - 2020-09-11 05:08:28 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:28 --> Total execution time: 0.2644
ERROR - 2020-09-11 05:08:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:28 --> Config Class Initialized
INFO - 2020-09-11 05:08:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:28 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:28 --> URI Class Initialized
INFO - 2020-09-11 05:08:28 --> Router Class Initialized
INFO - 2020-09-11 05:08:28 --> Output Class Initialized
INFO - 2020-09-11 05:08:28 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:28 --> Input Class Initialized
INFO - 2020-09-11 05:08:28 --> Language Class Initialized
INFO - 2020-09-11 05:08:28 --> Loader Class Initialized
INFO - 2020-09-11 05:08:28 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:28 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:29 --> Email Class Initialized
INFO - 2020-09-11 05:08:29 --> Controller Class Initialized
INFO - 2020-09-11 05:08:29 --> Model Class Initialized
INFO - 2020-09-11 05:08:29 --> Model Class Initialized
INFO - 2020-09-11 05:08:29 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:29 --> Total execution time: 0.1338
ERROR - 2020-09-11 05:08:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:40 --> Config Class Initialized
INFO - 2020-09-11 05:08:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:40 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:40 --> URI Class Initialized
INFO - 2020-09-11 05:08:40 --> Router Class Initialized
INFO - 2020-09-11 05:08:40 --> Output Class Initialized
INFO - 2020-09-11 05:08:40 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:40 --> Input Class Initialized
INFO - 2020-09-11 05:08:40 --> Language Class Initialized
INFO - 2020-09-11 05:08:40 --> Loader Class Initialized
INFO - 2020-09-11 05:08:40 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:40 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:40 --> Email Class Initialized
INFO - 2020-09-11 05:08:40 --> Controller Class Initialized
INFO - 2020-09-11 05:08:40 --> Model Class Initialized
INFO - 2020-09-11 05:08:40 --> Model Class Initialized
INFO - 2020-09-11 05:08:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:08:40 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:40 --> Total execution time: 0.0929
ERROR - 2020-09-11 05:08:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:08:41 --> Config Class Initialized
INFO - 2020-09-11 05:08:41 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:08:41 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:08:41 --> Utf8 Class Initialized
INFO - 2020-09-11 05:08:41 --> URI Class Initialized
INFO - 2020-09-11 05:08:41 --> Router Class Initialized
INFO - 2020-09-11 05:08:41 --> Output Class Initialized
INFO - 2020-09-11 05:08:41 --> Security Class Initialized
DEBUG - 2020-09-11 05:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:08:41 --> Input Class Initialized
INFO - 2020-09-11 05:08:41 --> Language Class Initialized
INFO - 2020-09-11 05:08:41 --> Loader Class Initialized
INFO - 2020-09-11 05:08:41 --> Helper loaded: url_helper
INFO - 2020-09-11 05:08:41 --> Database Driver Class Initialized
INFO - 2020-09-11 05:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:08:41 --> Email Class Initialized
INFO - 2020-09-11 05:08:41 --> Controller Class Initialized
INFO - 2020-09-11 05:08:41 --> Model Class Initialized
INFO - 2020-09-11 05:08:41 --> Model Class Initialized
INFO - 2020-09-11 05:08:41 --> Final output sent to browser
DEBUG - 2020-09-11 05:08:41 --> Total execution time: 0.0423
ERROR - 2020-09-11 05:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:09:27 --> Config Class Initialized
INFO - 2020-09-11 05:09:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:09:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:09:27 --> Utf8 Class Initialized
INFO - 2020-09-11 05:09:27 --> URI Class Initialized
INFO - 2020-09-11 05:09:27 --> Router Class Initialized
INFO - 2020-09-11 05:09:27 --> Output Class Initialized
INFO - 2020-09-11 05:09:27 --> Security Class Initialized
DEBUG - 2020-09-11 05:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:09:27 --> Input Class Initialized
INFO - 2020-09-11 05:09:27 --> Language Class Initialized
INFO - 2020-09-11 05:09:27 --> Loader Class Initialized
INFO - 2020-09-11 05:09:27 --> Helper loaded: url_helper
INFO - 2020-09-11 05:09:27 --> Database Driver Class Initialized
INFO - 2020-09-11 05:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:09:27 --> Email Class Initialized
INFO - 2020-09-11 05:09:27 --> Controller Class Initialized
INFO - 2020-09-11 05:09:27 --> Model Class Initialized
INFO - 2020-09-11 05:09:27 --> Model Class Initialized
INFO - 2020-09-11 05:09:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:09:27 --> Final output sent to browser
DEBUG - 2020-09-11 05:09:27 --> Total execution time: 0.0977
ERROR - 2020-09-11 05:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:09:27 --> Config Class Initialized
INFO - 2020-09-11 05:09:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:09:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:09:27 --> Utf8 Class Initialized
INFO - 2020-09-11 05:09:27 --> URI Class Initialized
INFO - 2020-09-11 05:09:27 --> Router Class Initialized
INFO - 2020-09-11 05:09:27 --> Output Class Initialized
INFO - 2020-09-11 05:09:27 --> Security Class Initialized
DEBUG - 2020-09-11 05:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:09:27 --> Input Class Initialized
INFO - 2020-09-11 05:09:27 --> Language Class Initialized
INFO - 2020-09-11 05:09:27 --> Loader Class Initialized
INFO - 2020-09-11 05:09:27 --> Helper loaded: url_helper
INFO - 2020-09-11 05:09:27 --> Database Driver Class Initialized
INFO - 2020-09-11 05:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:09:27 --> Email Class Initialized
INFO - 2020-09-11 05:09:27 --> Controller Class Initialized
INFO - 2020-09-11 05:09:27 --> Model Class Initialized
INFO - 2020-09-11 05:09:27 --> Model Class Initialized
INFO - 2020-09-11 05:09:27 --> Final output sent to browser
DEBUG - 2020-09-11 05:09:27 --> Total execution time: 0.0380
ERROR - 2020-09-11 05:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:09:36 --> Config Class Initialized
INFO - 2020-09-11 05:09:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:09:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:09:36 --> Utf8 Class Initialized
INFO - 2020-09-11 05:09:36 --> URI Class Initialized
INFO - 2020-09-11 05:09:36 --> Router Class Initialized
INFO - 2020-09-11 05:09:36 --> Output Class Initialized
INFO - 2020-09-11 05:09:36 --> Security Class Initialized
DEBUG - 2020-09-11 05:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:09:36 --> Input Class Initialized
INFO - 2020-09-11 05:09:36 --> Language Class Initialized
INFO - 2020-09-11 05:09:36 --> Loader Class Initialized
INFO - 2020-09-11 05:09:36 --> Helper loaded: url_helper
INFO - 2020-09-11 05:09:36 --> Database Driver Class Initialized
INFO - 2020-09-11 05:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:09:36 --> Email Class Initialized
INFO - 2020-09-11 05:09:36 --> Controller Class Initialized
INFO - 2020-09-11 05:09:36 --> Model Class Initialized
INFO - 2020-09-11 05:09:36 --> Model Class Initialized
INFO - 2020-09-11 05:09:36 --> Final output sent to browser
DEBUG - 2020-09-11 05:09:36 --> Total execution time: 0.1496
ERROR - 2020-09-11 05:09:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:09:36 --> Config Class Initialized
INFO - 2020-09-11 05:09:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:09:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:09:36 --> Utf8 Class Initialized
INFO - 2020-09-11 05:09:36 --> URI Class Initialized
INFO - 2020-09-11 05:09:36 --> Router Class Initialized
INFO - 2020-09-11 05:09:36 --> Output Class Initialized
INFO - 2020-09-11 05:09:36 --> Security Class Initialized
DEBUG - 2020-09-11 05:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:09:36 --> Input Class Initialized
INFO - 2020-09-11 05:09:36 --> Language Class Initialized
INFO - 2020-09-11 05:09:36 --> Loader Class Initialized
INFO - 2020-09-11 05:09:36 --> Helper loaded: url_helper
INFO - 2020-09-11 05:09:36 --> Database Driver Class Initialized
INFO - 2020-09-11 05:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:09:36 --> Email Class Initialized
INFO - 2020-09-11 05:09:36 --> Controller Class Initialized
INFO - 2020-09-11 05:09:36 --> Model Class Initialized
INFO - 2020-09-11 05:09:36 --> Model Class Initialized
INFO - 2020-09-11 05:09:36 --> Final output sent to browser
DEBUG - 2020-09-11 05:09:36 --> Total execution time: 0.0410
ERROR - 2020-09-11 05:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:10:06 --> Config Class Initialized
INFO - 2020-09-11 05:10:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:10:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:10:06 --> Utf8 Class Initialized
INFO - 2020-09-11 05:10:06 --> URI Class Initialized
INFO - 2020-09-11 05:10:06 --> Router Class Initialized
INFO - 2020-09-11 05:10:06 --> Output Class Initialized
INFO - 2020-09-11 05:10:06 --> Security Class Initialized
DEBUG - 2020-09-11 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:10:06 --> Input Class Initialized
INFO - 2020-09-11 05:10:06 --> Language Class Initialized
INFO - 2020-09-11 05:10:06 --> Loader Class Initialized
INFO - 2020-09-11 05:10:06 --> Helper loaded: url_helper
INFO - 2020-09-11 05:10:06 --> Database Driver Class Initialized
INFO - 2020-09-11 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:10:06 --> Email Class Initialized
INFO - 2020-09-11 05:10:06 --> Controller Class Initialized
INFO - 2020-09-11 05:10:06 --> Model Class Initialized
INFO - 2020-09-11 05:10:06 --> Model Class Initialized
INFO - 2020-09-11 05:10:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:10:06 --> Final output sent to browser
DEBUG - 2020-09-11 05:10:06 --> Total execution time: 0.0326
ERROR - 2020-09-11 05:10:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:10:06 --> Config Class Initialized
INFO - 2020-09-11 05:10:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:10:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:10:06 --> Utf8 Class Initialized
INFO - 2020-09-11 05:10:06 --> URI Class Initialized
INFO - 2020-09-11 05:10:06 --> Router Class Initialized
INFO - 2020-09-11 05:10:06 --> Output Class Initialized
INFO - 2020-09-11 05:10:06 --> Security Class Initialized
DEBUG - 2020-09-11 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:10:06 --> Input Class Initialized
INFO - 2020-09-11 05:10:06 --> Language Class Initialized
INFO - 2020-09-11 05:10:06 --> Loader Class Initialized
INFO - 2020-09-11 05:10:06 --> Helper loaded: url_helper
INFO - 2020-09-11 05:10:06 --> Database Driver Class Initialized
INFO - 2020-09-11 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:10:06 --> Email Class Initialized
INFO - 2020-09-11 05:10:06 --> Controller Class Initialized
INFO - 2020-09-11 05:10:06 --> Model Class Initialized
INFO - 2020-09-11 05:10:06 --> Model Class Initialized
INFO - 2020-09-11 05:10:06 --> Final output sent to browser
DEBUG - 2020-09-11 05:10:06 --> Total execution time: 0.0344
ERROR - 2020-09-11 05:10:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:10:41 --> Config Class Initialized
INFO - 2020-09-11 05:10:41 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:10:41 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:10:41 --> Utf8 Class Initialized
INFO - 2020-09-11 05:10:41 --> URI Class Initialized
INFO - 2020-09-11 05:10:41 --> Router Class Initialized
INFO - 2020-09-11 05:10:41 --> Output Class Initialized
INFO - 2020-09-11 05:10:41 --> Security Class Initialized
DEBUG - 2020-09-11 05:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:10:41 --> Input Class Initialized
INFO - 2020-09-11 05:10:41 --> Language Class Initialized
INFO - 2020-09-11 05:10:41 --> Loader Class Initialized
INFO - 2020-09-11 05:10:41 --> Helper loaded: url_helper
INFO - 2020-09-11 05:10:41 --> Database Driver Class Initialized
INFO - 2020-09-11 05:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:10:41 --> Email Class Initialized
INFO - 2020-09-11 05:10:41 --> Controller Class Initialized
INFO - 2020-09-11 05:10:41 --> Model Class Initialized
INFO - 2020-09-11 05:10:41 --> Model Class Initialized
INFO - 2020-09-11 05:10:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:10:41 --> Final output sent to browser
DEBUG - 2020-09-11 05:10:41 --> Total execution time: 0.0437
ERROR - 2020-09-11 05:10:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:10:42 --> Config Class Initialized
INFO - 2020-09-11 05:10:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:10:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:10:42 --> Utf8 Class Initialized
INFO - 2020-09-11 05:10:42 --> URI Class Initialized
INFO - 2020-09-11 05:10:42 --> Router Class Initialized
INFO - 2020-09-11 05:10:42 --> Output Class Initialized
INFO - 2020-09-11 05:10:42 --> Security Class Initialized
DEBUG - 2020-09-11 05:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:10:42 --> Input Class Initialized
INFO - 2020-09-11 05:10:42 --> Language Class Initialized
INFO - 2020-09-11 05:10:42 --> Loader Class Initialized
INFO - 2020-09-11 05:10:42 --> Helper loaded: url_helper
INFO - 2020-09-11 05:10:42 --> Database Driver Class Initialized
INFO - 2020-09-11 05:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:10:42 --> Email Class Initialized
INFO - 2020-09-11 05:10:42 --> Controller Class Initialized
INFO - 2020-09-11 05:10:42 --> Model Class Initialized
INFO - 2020-09-11 05:10:42 --> Model Class Initialized
INFO - 2020-09-11 05:10:42 --> Final output sent to browser
DEBUG - 2020-09-11 05:10:42 --> Total execution time: 0.4014
ERROR - 2020-09-11 05:25:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:25:11 --> Config Class Initialized
INFO - 2020-09-11 05:25:11 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:25:11 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:25:11 --> Utf8 Class Initialized
INFO - 2020-09-11 05:25:11 --> URI Class Initialized
INFO - 2020-09-11 05:25:11 --> Router Class Initialized
INFO - 2020-09-11 05:25:11 --> Output Class Initialized
INFO - 2020-09-11 05:25:11 --> Security Class Initialized
DEBUG - 2020-09-11 05:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:25:11 --> Input Class Initialized
INFO - 2020-09-11 05:25:11 --> Language Class Initialized
INFO - 2020-09-11 05:25:11 --> Loader Class Initialized
INFO - 2020-09-11 05:25:11 --> Helper loaded: url_helper
INFO - 2020-09-11 05:25:11 --> Database Driver Class Initialized
INFO - 2020-09-11 05:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:25:11 --> Email Class Initialized
INFO - 2020-09-11 05:25:11 --> Controller Class Initialized
INFO - 2020-09-11 05:25:11 --> Model Class Initialized
INFO - 2020-09-11 05:25:11 --> Model Class Initialized
INFO - 2020-09-11 05:25:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:25:11 --> Final output sent to browser
DEBUG - 2020-09-11 05:25:11 --> Total execution time: 0.0703
ERROR - 2020-09-11 05:25:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:25:11 --> Config Class Initialized
INFO - 2020-09-11 05:25:11 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:25:11 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:25:11 --> Utf8 Class Initialized
INFO - 2020-09-11 05:25:11 --> URI Class Initialized
INFO - 2020-09-11 05:25:11 --> Router Class Initialized
INFO - 2020-09-11 05:25:11 --> Output Class Initialized
INFO - 2020-09-11 05:25:11 --> Security Class Initialized
DEBUG - 2020-09-11 05:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:25:11 --> Input Class Initialized
INFO - 2020-09-11 05:25:11 --> Language Class Initialized
INFO - 2020-09-11 05:25:11 --> Loader Class Initialized
INFO - 2020-09-11 05:25:11 --> Helper loaded: url_helper
INFO - 2020-09-11 05:25:11 --> Database Driver Class Initialized
INFO - 2020-09-11 05:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:25:11 --> Email Class Initialized
INFO - 2020-09-11 05:25:11 --> Controller Class Initialized
INFO - 2020-09-11 05:25:11 --> Model Class Initialized
INFO - 2020-09-11 05:25:11 --> Model Class Initialized
INFO - 2020-09-11 05:25:11 --> Final output sent to browser
DEBUG - 2020-09-11 05:25:11 --> Total execution time: 0.0834
ERROR - 2020-09-11 05:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:26:10 --> Config Class Initialized
INFO - 2020-09-11 05:26:10 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:26:10 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:26:10 --> Utf8 Class Initialized
INFO - 2020-09-11 05:26:10 --> URI Class Initialized
INFO - 2020-09-11 05:26:10 --> Router Class Initialized
INFO - 2020-09-11 05:26:10 --> Output Class Initialized
INFO - 2020-09-11 05:26:10 --> Security Class Initialized
DEBUG - 2020-09-11 05:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:26:10 --> Input Class Initialized
INFO - 2020-09-11 05:26:10 --> Language Class Initialized
INFO - 2020-09-11 05:26:10 --> Loader Class Initialized
INFO - 2020-09-11 05:26:10 --> Helper loaded: url_helper
INFO - 2020-09-11 05:26:10 --> Database Driver Class Initialized
INFO - 2020-09-11 05:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:26:10 --> Email Class Initialized
INFO - 2020-09-11 05:26:10 --> Controller Class Initialized
INFO - 2020-09-11 05:26:10 --> Model Class Initialized
INFO - 2020-09-11 05:26:10 --> Model Class Initialized
INFO - 2020-09-11 05:26:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:26:10 --> Final output sent to browser
DEBUG - 2020-09-11 05:26:10 --> Total execution time: 0.0421
ERROR - 2020-09-11 05:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:26:11 --> Config Class Initialized
INFO - 2020-09-11 05:26:11 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:26:11 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:26:11 --> Utf8 Class Initialized
INFO - 2020-09-11 05:26:11 --> URI Class Initialized
INFO - 2020-09-11 05:26:11 --> Router Class Initialized
INFO - 2020-09-11 05:26:11 --> Output Class Initialized
INFO - 2020-09-11 05:26:11 --> Security Class Initialized
DEBUG - 2020-09-11 05:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:26:11 --> Input Class Initialized
INFO - 2020-09-11 05:26:11 --> Language Class Initialized
INFO - 2020-09-11 05:26:11 --> Loader Class Initialized
INFO - 2020-09-11 05:26:11 --> Helper loaded: url_helper
INFO - 2020-09-11 05:26:11 --> Database Driver Class Initialized
INFO - 2020-09-11 05:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:26:11 --> Email Class Initialized
INFO - 2020-09-11 05:26:11 --> Controller Class Initialized
INFO - 2020-09-11 05:26:11 --> Model Class Initialized
INFO - 2020-09-11 05:26:11 --> Model Class Initialized
INFO - 2020-09-11 05:26:11 --> Final output sent to browser
DEBUG - 2020-09-11 05:26:11 --> Total execution time: 0.0391
ERROR - 2020-09-11 05:30:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:30:04 --> Config Class Initialized
INFO - 2020-09-11 05:30:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:04 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:04 --> URI Class Initialized
INFO - 2020-09-11 05:30:04 --> Router Class Initialized
INFO - 2020-09-11 05:30:04 --> Output Class Initialized
INFO - 2020-09-11 05:30:04 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:04 --> Input Class Initialized
INFO - 2020-09-11 05:30:04 --> Language Class Initialized
INFO - 2020-09-11 05:30:04 --> Loader Class Initialized
INFO - 2020-09-11 05:30:04 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:04 --> Database Driver Class Initialized
INFO - 2020-09-11 05:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:04 --> Email Class Initialized
INFO - 2020-09-11 05:30:04 --> Controller Class Initialized
INFO - 2020-09-11 05:30:04 --> Model Class Initialized
INFO - 2020-09-11 05:30:04 --> Model Class Initialized
INFO - 2020-09-11 05:30:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:30:04 --> Final output sent to browser
DEBUG - 2020-09-11 05:30:04 --> Total execution time: 0.0417
ERROR - 2020-09-11 05:30:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:30:04 --> Config Class Initialized
INFO - 2020-09-11 05:30:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:04 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:04 --> URI Class Initialized
INFO - 2020-09-11 05:30:04 --> Router Class Initialized
INFO - 2020-09-11 05:30:04 --> Output Class Initialized
INFO - 2020-09-11 05:30:04 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:04 --> Input Class Initialized
INFO - 2020-09-11 05:30:04 --> Language Class Initialized
INFO - 2020-09-11 05:30:04 --> Loader Class Initialized
INFO - 2020-09-11 05:30:04 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:04 --> Database Driver Class Initialized
INFO - 2020-09-11 05:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:04 --> Email Class Initialized
INFO - 2020-09-11 05:30:04 --> Controller Class Initialized
INFO - 2020-09-11 05:30:04 --> Model Class Initialized
INFO - 2020-09-11 05:30:04 --> Model Class Initialized
INFO - 2020-09-11 05:30:04 --> Final output sent to browser
DEBUG - 2020-09-11 05:30:04 --> Total execution time: 0.0426
ERROR - 2020-09-11 05:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:30:17 --> Config Class Initialized
INFO - 2020-09-11 05:30:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:17 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:17 --> URI Class Initialized
INFO - 2020-09-11 05:30:17 --> Router Class Initialized
INFO - 2020-09-11 05:30:17 --> Output Class Initialized
INFO - 2020-09-11 05:30:17 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:17 --> Input Class Initialized
INFO - 2020-09-11 05:30:17 --> Language Class Initialized
INFO - 2020-09-11 05:30:17 --> Loader Class Initialized
INFO - 2020-09-11 05:30:17 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:17 --> Database Driver Class Initialized
INFO - 2020-09-11 05:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:17 --> Email Class Initialized
INFO - 2020-09-11 05:30:17 --> Controller Class Initialized
INFO - 2020-09-11 05:30:17 --> Model Class Initialized
INFO - 2020-09-11 05:30:17 --> Model Class Initialized
INFO - 2020-09-11 05:30:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 05:30:17 --> Final output sent to browser
DEBUG - 2020-09-11 05:30:17 --> Total execution time: 0.1146
ERROR - 2020-09-11 05:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:30:18 --> Config Class Initialized
INFO - 2020-09-11 05:30:18 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:18 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:18 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:18 --> URI Class Initialized
INFO - 2020-09-11 05:30:18 --> Router Class Initialized
INFO - 2020-09-11 05:30:18 --> Output Class Initialized
INFO - 2020-09-11 05:30:18 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:18 --> Input Class Initialized
INFO - 2020-09-11 05:30:18 --> Language Class Initialized
INFO - 2020-09-11 05:30:18 --> Loader Class Initialized
INFO - 2020-09-11 05:30:18 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:18 --> Database Driver Class Initialized
INFO - 2020-09-11 05:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:18 --> Email Class Initialized
INFO - 2020-09-11 05:30:18 --> Controller Class Initialized
INFO - 2020-09-11 05:30:18 --> Model Class Initialized
INFO - 2020-09-11 05:30:18 --> Model Class Initialized
INFO - 2020-09-11 05:30:18 --> Final output sent to browser
DEBUG - 2020-09-11 05:30:18 --> Total execution time: 0.0448
ERROR - 2020-09-11 05:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:30:55 --> Config Class Initialized
INFO - 2020-09-11 05:30:55 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:55 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:55 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:55 --> URI Class Initialized
INFO - 2020-09-11 05:30:55 --> Router Class Initialized
INFO - 2020-09-11 05:30:55 --> Output Class Initialized
INFO - 2020-09-11 05:30:55 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:55 --> Input Class Initialized
INFO - 2020-09-11 05:30:55 --> Language Class Initialized
INFO - 2020-09-11 05:30:55 --> Loader Class Initialized
INFO - 2020-09-11 05:30:55 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:55 --> Database Driver Class Initialized
INFO - 2020-09-11 05:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:55 --> Email Class Initialized
INFO - 2020-09-11 05:30:55 --> Controller Class Initialized
INFO - 2020-09-11 05:30:55 --> Model Class Initialized
INFO - 2020-09-11 05:30:55 --> Model Class Initialized
INFO - 2020-09-11 05:30:55 --> Final output sent to browser
DEBUG - 2020-09-11 05:30:55 --> Total execution time: 0.1477
ERROR - 2020-09-11 05:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 05:30:55 --> Config Class Initialized
INFO - 2020-09-11 05:30:55 --> Hooks Class Initialized
DEBUG - 2020-09-11 05:30:55 --> UTF-8 Support Enabled
INFO - 2020-09-11 05:30:55 --> Utf8 Class Initialized
INFO - 2020-09-11 05:30:55 --> URI Class Initialized
INFO - 2020-09-11 05:30:55 --> Router Class Initialized
INFO - 2020-09-11 05:30:55 --> Output Class Initialized
INFO - 2020-09-11 05:30:55 --> Security Class Initialized
DEBUG - 2020-09-11 05:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 05:30:55 --> Input Class Initialized
INFO - 2020-09-11 05:30:55 --> Language Class Initialized
INFO - 2020-09-11 05:30:55 --> Loader Class Initialized
INFO - 2020-09-11 05:30:55 --> Helper loaded: url_helper
INFO - 2020-09-11 05:30:55 --> Database Driver Class Initialized
INFO - 2020-09-11 05:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 05:30:55 --> Email Class Initialized
INFO - 2020-09-11 05:30:55 --> Controller Class Initialized
INFO - 2020-09-11 05:30:55 --> Model Class Initialized
INFO - 2020-09-11 05:30:55 --> Model Class Initialized
INFO - 2020-09-11 05:30:55 --> Final output sent to browser
DEBUG - 2020-09-11 05:30:55 --> Total execution time: 0.0408
ERROR - 2020-09-11 06:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:12:15 --> Config Class Initialized
INFO - 2020-09-11 06:12:15 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:12:15 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:12:15 --> Utf8 Class Initialized
INFO - 2020-09-11 06:12:15 --> URI Class Initialized
INFO - 2020-09-11 06:12:15 --> Router Class Initialized
INFO - 2020-09-11 06:12:15 --> Output Class Initialized
INFO - 2020-09-11 06:12:15 --> Security Class Initialized
DEBUG - 2020-09-11 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:12:15 --> Input Class Initialized
INFO - 2020-09-11 06:12:15 --> Language Class Initialized
INFO - 2020-09-11 06:12:15 --> Loader Class Initialized
INFO - 2020-09-11 06:12:15 --> Helper loaded: url_helper
INFO - 2020-09-11 06:12:15 --> Database Driver Class Initialized
INFO - 2020-09-11 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:12:15 --> Email Class Initialized
INFO - 2020-09-11 06:12:15 --> Controller Class Initialized
DEBUG - 2020-09-11 06:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 06:12:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:12:15 --> Model Class Initialized
INFO - 2020-09-11 06:12:15 --> Model Class Initialized
INFO - 2020-09-11 06:12:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 06:12:15 --> Final output sent to browser
DEBUG - 2020-09-11 06:12:15 --> Total execution time: 0.0443
ERROR - 2020-09-11 06:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:36:09 --> Config Class Initialized
INFO - 2020-09-11 06:36:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:36:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:36:09 --> Utf8 Class Initialized
INFO - 2020-09-11 06:36:09 --> URI Class Initialized
INFO - 2020-09-11 06:36:09 --> Router Class Initialized
INFO - 2020-09-11 06:36:09 --> Output Class Initialized
INFO - 2020-09-11 06:36:09 --> Security Class Initialized
DEBUG - 2020-09-11 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:36:09 --> Input Class Initialized
INFO - 2020-09-11 06:36:09 --> Language Class Initialized
INFO - 2020-09-11 06:36:09 --> Loader Class Initialized
INFO - 2020-09-11 06:36:09 --> Helper loaded: url_helper
INFO - 2020-09-11 06:36:09 --> Database Driver Class Initialized
INFO - 2020-09-11 06:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:36:09 --> Email Class Initialized
INFO - 2020-09-11 06:36:09 --> Controller Class Initialized
INFO - 2020-09-11 06:36:09 --> Model Class Initialized
INFO - 2020-09-11 06:36:09 --> Model Class Initialized
INFO - 2020-09-11 06:36:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:36:09 --> Final output sent to browser
DEBUG - 2020-09-11 06:36:09 --> Total execution time: 0.0370
ERROR - 2020-09-11 06:36:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:36:09 --> Config Class Initialized
INFO - 2020-09-11 06:36:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:36:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:36:09 --> Utf8 Class Initialized
INFO - 2020-09-11 06:36:09 --> URI Class Initialized
INFO - 2020-09-11 06:36:09 --> Router Class Initialized
INFO - 2020-09-11 06:36:09 --> Output Class Initialized
INFO - 2020-09-11 06:36:09 --> Security Class Initialized
DEBUG - 2020-09-11 06:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:36:09 --> Input Class Initialized
INFO - 2020-09-11 06:36:09 --> Language Class Initialized
INFO - 2020-09-11 06:36:09 --> Loader Class Initialized
INFO - 2020-09-11 06:36:09 --> Helper loaded: url_helper
INFO - 2020-09-11 06:36:09 --> Database Driver Class Initialized
INFO - 2020-09-11 06:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:36:09 --> Email Class Initialized
INFO - 2020-09-11 06:36:09 --> Controller Class Initialized
INFO - 2020-09-11 06:36:09 --> Model Class Initialized
INFO - 2020-09-11 06:36:09 --> Model Class Initialized
INFO - 2020-09-11 06:36:10 --> Final output sent to browser
DEBUG - 2020-09-11 06:36:10 --> Total execution time: 0.0399
ERROR - 2020-09-11 06:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:36:43 --> Config Class Initialized
INFO - 2020-09-11 06:36:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:36:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:36:43 --> Utf8 Class Initialized
INFO - 2020-09-11 06:36:43 --> URI Class Initialized
INFO - 2020-09-11 06:36:43 --> Router Class Initialized
INFO - 2020-09-11 06:36:43 --> Output Class Initialized
INFO - 2020-09-11 06:36:43 --> Security Class Initialized
DEBUG - 2020-09-11 06:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:36:43 --> Input Class Initialized
INFO - 2020-09-11 06:36:43 --> Language Class Initialized
INFO - 2020-09-11 06:36:43 --> Loader Class Initialized
INFO - 2020-09-11 06:36:43 --> Helper loaded: url_helper
INFO - 2020-09-11 06:36:43 --> Database Driver Class Initialized
INFO - 2020-09-11 06:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:36:43 --> Email Class Initialized
INFO - 2020-09-11 06:36:43 --> Controller Class Initialized
INFO - 2020-09-11 06:36:43 --> Model Class Initialized
INFO - 2020-09-11 06:36:43 --> Model Class Initialized
INFO - 2020-09-11 06:36:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:36:43 --> Final output sent to browser
DEBUG - 2020-09-11 06:36:43 --> Total execution time: 0.0426
ERROR - 2020-09-11 06:36:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:36:44 --> Config Class Initialized
INFO - 2020-09-11 06:36:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:36:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:36:44 --> Utf8 Class Initialized
INFO - 2020-09-11 06:36:44 --> URI Class Initialized
INFO - 2020-09-11 06:36:44 --> Router Class Initialized
INFO - 2020-09-11 06:36:44 --> Output Class Initialized
INFO - 2020-09-11 06:36:44 --> Security Class Initialized
DEBUG - 2020-09-11 06:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:36:44 --> Input Class Initialized
INFO - 2020-09-11 06:36:44 --> Language Class Initialized
INFO - 2020-09-11 06:36:44 --> Loader Class Initialized
INFO - 2020-09-11 06:36:44 --> Helper loaded: url_helper
INFO - 2020-09-11 06:36:44 --> Database Driver Class Initialized
INFO - 2020-09-11 06:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:36:44 --> Email Class Initialized
INFO - 2020-09-11 06:36:44 --> Controller Class Initialized
INFO - 2020-09-11 06:36:44 --> Model Class Initialized
INFO - 2020-09-11 06:36:44 --> Model Class Initialized
INFO - 2020-09-11 06:36:44 --> Final output sent to browser
DEBUG - 2020-09-11 06:36:44 --> Total execution time: 0.0440
ERROR - 2020-09-11 06:36:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:36:53 --> Config Class Initialized
INFO - 2020-09-11 06:36:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:36:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:36:53 --> Utf8 Class Initialized
INFO - 2020-09-11 06:36:53 --> URI Class Initialized
INFO - 2020-09-11 06:36:53 --> Router Class Initialized
INFO - 2020-09-11 06:36:53 --> Output Class Initialized
INFO - 2020-09-11 06:36:53 --> Security Class Initialized
DEBUG - 2020-09-11 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:36:53 --> Input Class Initialized
INFO - 2020-09-11 06:36:53 --> Language Class Initialized
INFO - 2020-09-11 06:36:53 --> Loader Class Initialized
INFO - 2020-09-11 06:36:53 --> Helper loaded: url_helper
INFO - 2020-09-11 06:36:53 --> Database Driver Class Initialized
INFO - 2020-09-11 06:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:36:53 --> Email Class Initialized
INFO - 2020-09-11 06:36:53 --> Controller Class Initialized
INFO - 2020-09-11 06:36:53 --> Model Class Initialized
INFO - 2020-09-11 06:36:53 --> Model Class Initialized
INFO - 2020-09-11 06:36:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:36:53 --> Final output sent to browser
DEBUG - 2020-09-11 06:36:53 --> Total execution time: 0.1192
ERROR - 2020-09-11 06:36:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:36:53 --> Config Class Initialized
INFO - 2020-09-11 06:36:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:36:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:36:53 --> Utf8 Class Initialized
INFO - 2020-09-11 06:36:53 --> URI Class Initialized
INFO - 2020-09-11 06:36:53 --> Router Class Initialized
INFO - 2020-09-11 06:36:53 --> Output Class Initialized
INFO - 2020-09-11 06:36:53 --> Security Class Initialized
DEBUG - 2020-09-11 06:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:36:53 --> Input Class Initialized
INFO - 2020-09-11 06:36:53 --> Language Class Initialized
INFO - 2020-09-11 06:36:53 --> Loader Class Initialized
INFO - 2020-09-11 06:36:53 --> Helper loaded: url_helper
INFO - 2020-09-11 06:36:53 --> Database Driver Class Initialized
INFO - 2020-09-11 06:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:36:53 --> Email Class Initialized
INFO - 2020-09-11 06:36:53 --> Controller Class Initialized
INFO - 2020-09-11 06:36:53 --> Model Class Initialized
INFO - 2020-09-11 06:36:53 --> Model Class Initialized
INFO - 2020-09-11 06:36:53 --> Final output sent to browser
DEBUG - 2020-09-11 06:36:53 --> Total execution time: 0.0419
ERROR - 2020-09-11 06:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:37:19 --> Config Class Initialized
INFO - 2020-09-11 06:37:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:37:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:37:19 --> Utf8 Class Initialized
INFO - 2020-09-11 06:37:19 --> URI Class Initialized
INFO - 2020-09-11 06:37:19 --> Router Class Initialized
INFO - 2020-09-11 06:37:19 --> Output Class Initialized
INFO - 2020-09-11 06:37:19 --> Security Class Initialized
DEBUG - 2020-09-11 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:37:19 --> Input Class Initialized
INFO - 2020-09-11 06:37:19 --> Language Class Initialized
INFO - 2020-09-11 06:37:19 --> Loader Class Initialized
INFO - 2020-09-11 06:37:19 --> Helper loaded: url_helper
INFO - 2020-09-11 06:37:19 --> Database Driver Class Initialized
INFO - 2020-09-11 06:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:37:19 --> Email Class Initialized
INFO - 2020-09-11 06:37:19 --> Controller Class Initialized
DEBUG - 2020-09-11 06:37:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 06:37:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:37:19 --> Model Class Initialized
INFO - 2020-09-11 06:37:19 --> Model Class Initialized
INFO - 2020-09-11 06:37:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 06:37:19 --> Final output sent to browser
DEBUG - 2020-09-11 06:37:19 --> Total execution time: 0.0253
ERROR - 2020-09-11 06:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:37:25 --> Config Class Initialized
INFO - 2020-09-11 06:37:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:37:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:37:25 --> Utf8 Class Initialized
INFO - 2020-09-11 06:37:25 --> URI Class Initialized
INFO - 2020-09-11 06:37:25 --> Router Class Initialized
INFO - 2020-09-11 06:37:25 --> Output Class Initialized
INFO - 2020-09-11 06:37:25 --> Security Class Initialized
DEBUG - 2020-09-11 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:37:25 --> Input Class Initialized
INFO - 2020-09-11 06:37:25 --> Language Class Initialized
INFO - 2020-09-11 06:37:25 --> Loader Class Initialized
INFO - 2020-09-11 06:37:25 --> Helper loaded: url_helper
INFO - 2020-09-11 06:37:25 --> Database Driver Class Initialized
INFO - 2020-09-11 06:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:37:25 --> Email Class Initialized
INFO - 2020-09-11 06:37:25 --> Controller Class Initialized
DEBUG - 2020-09-11 06:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 06:37:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:37:25 --> Model Class Initialized
INFO - 2020-09-11 06:37:25 --> Model Class Initialized
INFO - 2020-09-11 06:37:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 06:37:25 --> Final output sent to browser
DEBUG - 2020-09-11 06:37:25 --> Total execution time: 0.0295
ERROR - 2020-09-11 06:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:37:37 --> Config Class Initialized
INFO - 2020-09-11 06:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:37:37 --> Utf8 Class Initialized
INFO - 2020-09-11 06:37:37 --> URI Class Initialized
INFO - 2020-09-11 06:37:37 --> Router Class Initialized
INFO - 2020-09-11 06:37:37 --> Output Class Initialized
INFO - 2020-09-11 06:37:37 --> Security Class Initialized
DEBUG - 2020-09-11 06:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:37:37 --> Input Class Initialized
INFO - 2020-09-11 06:37:37 --> Language Class Initialized
INFO - 2020-09-11 06:37:37 --> Loader Class Initialized
INFO - 2020-09-11 06:37:37 --> Helper loaded: url_helper
INFO - 2020-09-11 06:37:37 --> Database Driver Class Initialized
INFO - 2020-09-11 06:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:37:37 --> Email Class Initialized
INFO - 2020-09-11 06:37:37 --> Controller Class Initialized
DEBUG - 2020-09-11 06:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 06:37:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:37:37 --> Model Class Initialized
INFO - 2020-09-11 06:37:37 --> Model Class Initialized
INFO - 2020-09-11 06:37:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 06:37:37 --> Final output sent to browser
DEBUG - 2020-09-11 06:37:37 --> Total execution time: 0.0218
ERROR - 2020-09-11 06:37:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:37:54 --> Config Class Initialized
INFO - 2020-09-11 06:37:54 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:37:54 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:37:54 --> Utf8 Class Initialized
INFO - 2020-09-11 06:37:54 --> URI Class Initialized
DEBUG - 2020-09-11 06:37:54 --> No URI present. Default controller set.
INFO - 2020-09-11 06:37:54 --> Router Class Initialized
INFO - 2020-09-11 06:37:54 --> Output Class Initialized
INFO - 2020-09-11 06:37:54 --> Security Class Initialized
DEBUG - 2020-09-11 06:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:37:54 --> Input Class Initialized
INFO - 2020-09-11 06:37:54 --> Language Class Initialized
INFO - 2020-09-11 06:37:54 --> Loader Class Initialized
INFO - 2020-09-11 06:37:54 --> Helper loaded: url_helper
INFO - 2020-09-11 06:37:54 --> Database Driver Class Initialized
INFO - 2020-09-11 06:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:37:54 --> Email Class Initialized
INFO - 2020-09-11 06:37:54 --> Controller Class Initialized
INFO - 2020-09-11 06:37:54 --> Model Class Initialized
INFO - 2020-09-11 06:37:54 --> Model Class Initialized
DEBUG - 2020-09-11 06:37:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:37:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 06:37:54 --> Final output sent to browser
DEBUG - 2020-09-11 06:37:54 --> Total execution time: 0.0208
ERROR - 2020-09-11 06:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:48:37 --> Config Class Initialized
INFO - 2020-09-11 06:48:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:48:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:48:37 --> Utf8 Class Initialized
INFO - 2020-09-11 06:48:37 --> URI Class Initialized
INFO - 2020-09-11 06:48:37 --> Router Class Initialized
INFO - 2020-09-11 06:48:37 --> Output Class Initialized
INFO - 2020-09-11 06:48:37 --> Security Class Initialized
DEBUG - 2020-09-11 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:48:37 --> Input Class Initialized
INFO - 2020-09-11 06:48:37 --> Language Class Initialized
INFO - 2020-09-11 06:48:37 --> Loader Class Initialized
INFO - 2020-09-11 06:48:37 --> Helper loaded: url_helper
INFO - 2020-09-11 06:48:37 --> Database Driver Class Initialized
INFO - 2020-09-11 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:48:37 --> Email Class Initialized
INFO - 2020-09-11 06:48:37 --> Controller Class Initialized
INFO - 2020-09-11 06:48:37 --> Model Class Initialized
INFO - 2020-09-11 06:48:37 --> Model Class Initialized
DEBUG - 2020-09-11 06:48:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 06:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:48:37 --> Config Class Initialized
INFO - 2020-09-11 06:48:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:48:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:48:37 --> Utf8 Class Initialized
INFO - 2020-09-11 06:48:37 --> URI Class Initialized
INFO - 2020-09-11 06:48:37 --> Router Class Initialized
INFO - 2020-09-11 06:48:37 --> Output Class Initialized
INFO - 2020-09-11 06:48:37 --> Security Class Initialized
DEBUG - 2020-09-11 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:48:37 --> Input Class Initialized
INFO - 2020-09-11 06:48:37 --> Language Class Initialized
INFO - 2020-09-11 06:48:37 --> Loader Class Initialized
INFO - 2020-09-11 06:48:37 --> Helper loaded: url_helper
INFO - 2020-09-11 06:48:37 --> Database Driver Class Initialized
INFO - 2020-09-11 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:48:37 --> Email Class Initialized
INFO - 2020-09-11 06:48:37 --> Controller Class Initialized
INFO - 2020-09-11 06:48:37 --> Model Class Initialized
INFO - 2020-09-11 06:48:37 --> Model Class Initialized
DEBUG - 2020-09-11 06:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 06:48:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:48:37 --> Model Class Initialized
INFO - 2020-09-11 06:48:37 --> Final output sent to browser
DEBUG - 2020-09-11 06:48:37 --> Total execution time: 0.0244
ERROR - 2020-09-11 06:48:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:48:38 --> Config Class Initialized
INFO - 2020-09-11 06:48:38 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:48:38 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:48:38 --> Utf8 Class Initialized
INFO - 2020-09-11 06:48:38 --> URI Class Initialized
INFO - 2020-09-11 06:48:38 --> Router Class Initialized
INFO - 2020-09-11 06:48:38 --> Output Class Initialized
INFO - 2020-09-11 06:48:38 --> Security Class Initialized
DEBUG - 2020-09-11 06:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:48:38 --> Input Class Initialized
INFO - 2020-09-11 06:48:38 --> Language Class Initialized
INFO - 2020-09-11 06:48:38 --> Loader Class Initialized
INFO - 2020-09-11 06:48:38 --> Helper loaded: url_helper
INFO - 2020-09-11 06:48:38 --> Database Driver Class Initialized
INFO - 2020-09-11 06:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:48:38 --> Email Class Initialized
INFO - 2020-09-11 06:48:38 --> Controller Class Initialized
DEBUG - 2020-09-11 06:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 06:48:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 06:48:38 --> Model Class Initialized
INFO - 2020-09-11 06:48:38 --> Model Class Initialized
INFO - 2020-09-11 06:48:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 06:48:38 --> Final output sent to browser
DEBUG - 2020-09-11 06:48:38 --> Total execution time: 0.0246
ERROR - 2020-09-11 06:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:48:43 --> Config Class Initialized
INFO - 2020-09-11 06:48:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:48:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:48:43 --> Utf8 Class Initialized
INFO - 2020-09-11 06:48:43 --> URI Class Initialized
INFO - 2020-09-11 06:48:43 --> Router Class Initialized
INFO - 2020-09-11 06:48:43 --> Output Class Initialized
INFO - 2020-09-11 06:48:43 --> Security Class Initialized
DEBUG - 2020-09-11 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:48:43 --> Input Class Initialized
INFO - 2020-09-11 06:48:43 --> Language Class Initialized
INFO - 2020-09-11 06:48:43 --> Loader Class Initialized
INFO - 2020-09-11 06:48:43 --> Helper loaded: url_helper
INFO - 2020-09-11 06:48:43 --> Database Driver Class Initialized
INFO - 2020-09-11 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:48:43 --> Email Class Initialized
INFO - 2020-09-11 06:48:43 --> Controller Class Initialized
INFO - 2020-09-11 06:48:43 --> Model Class Initialized
INFO - 2020-09-11 06:48:43 --> Model Class Initialized
INFO - 2020-09-11 06:48:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:48:43 --> Final output sent to browser
DEBUG - 2020-09-11 06:48:43 --> Total execution time: 0.0430
ERROR - 2020-09-11 06:48:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:48:43 --> Config Class Initialized
INFO - 2020-09-11 06:48:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:48:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:48:43 --> Utf8 Class Initialized
INFO - 2020-09-11 06:48:43 --> URI Class Initialized
INFO - 2020-09-11 06:48:43 --> Router Class Initialized
INFO - 2020-09-11 06:48:43 --> Output Class Initialized
INFO - 2020-09-11 06:48:43 --> Security Class Initialized
DEBUG - 2020-09-11 06:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:48:43 --> Input Class Initialized
INFO - 2020-09-11 06:48:43 --> Language Class Initialized
INFO - 2020-09-11 06:48:43 --> Loader Class Initialized
INFO - 2020-09-11 06:48:43 --> Helper loaded: url_helper
INFO - 2020-09-11 06:48:43 --> Database Driver Class Initialized
INFO - 2020-09-11 06:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:48:43 --> Email Class Initialized
INFO - 2020-09-11 06:48:43 --> Controller Class Initialized
INFO - 2020-09-11 06:48:43 --> Model Class Initialized
INFO - 2020-09-11 06:48:43 --> Model Class Initialized
INFO - 2020-09-11 06:48:43 --> Final output sent to browser
DEBUG - 2020-09-11 06:48:43 --> Total execution time: 0.0449
ERROR - 2020-09-11 06:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:50:03 --> Config Class Initialized
INFO - 2020-09-11 06:50:03 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:03 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:03 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:03 --> URI Class Initialized
INFO - 2020-09-11 06:50:03 --> Router Class Initialized
INFO - 2020-09-11 06:50:03 --> Output Class Initialized
INFO - 2020-09-11 06:50:03 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:03 --> Input Class Initialized
INFO - 2020-09-11 06:50:03 --> Language Class Initialized
INFO - 2020-09-11 06:50:03 --> Loader Class Initialized
INFO - 2020-09-11 06:50:03 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:03 --> Database Driver Class Initialized
INFO - 2020-09-11 06:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:03 --> Email Class Initialized
INFO - 2020-09-11 06:50:03 --> Controller Class Initialized
INFO - 2020-09-11 06:50:03 --> Model Class Initialized
INFO - 2020-09-11 06:50:03 --> Model Class Initialized
INFO - 2020-09-11 06:50:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:50:04 --> Final output sent to browser
DEBUG - 2020-09-11 06:50:04 --> Total execution time: 0.0414
ERROR - 2020-09-11 06:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:50:04 --> Config Class Initialized
INFO - 2020-09-11 06:50:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:04 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:04 --> URI Class Initialized
INFO - 2020-09-11 06:50:04 --> Router Class Initialized
INFO - 2020-09-11 06:50:04 --> Output Class Initialized
INFO - 2020-09-11 06:50:04 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:04 --> Input Class Initialized
INFO - 2020-09-11 06:50:04 --> Language Class Initialized
INFO - 2020-09-11 06:50:04 --> Loader Class Initialized
INFO - 2020-09-11 06:50:04 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:04 --> Database Driver Class Initialized
INFO - 2020-09-11 06:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:04 --> Email Class Initialized
INFO - 2020-09-11 06:50:04 --> Controller Class Initialized
INFO - 2020-09-11 06:50:04 --> Model Class Initialized
INFO - 2020-09-11 06:50:04 --> Model Class Initialized
INFO - 2020-09-11 06:50:04 --> Final output sent to browser
DEBUG - 2020-09-11 06:50:04 --> Total execution time: 0.0447
ERROR - 2020-09-11 06:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:50:10 --> Config Class Initialized
INFO - 2020-09-11 06:50:10 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:50:10 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:50:10 --> Utf8 Class Initialized
INFO - 2020-09-11 06:50:10 --> URI Class Initialized
INFO - 2020-09-11 06:50:10 --> Router Class Initialized
INFO - 2020-09-11 06:50:10 --> Output Class Initialized
INFO - 2020-09-11 06:50:10 --> Security Class Initialized
DEBUG - 2020-09-11 06:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:50:10 --> Input Class Initialized
INFO - 2020-09-11 06:50:10 --> Language Class Initialized
INFO - 2020-09-11 06:50:10 --> Loader Class Initialized
INFO - 2020-09-11 06:50:10 --> Helper loaded: url_helper
INFO - 2020-09-11 06:50:10 --> Database Driver Class Initialized
INFO - 2020-09-11 06:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:50:10 --> Email Class Initialized
INFO - 2020-09-11 06:50:10 --> Controller Class Initialized
INFO - 2020-09-11 06:50:10 --> Model Class Initialized
INFO - 2020-09-11 06:50:10 --> Model Class Initialized
INFO - 2020-09-11 06:50:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-11 06:50:10 --> Final output sent to browser
DEBUG - 2020-09-11 06:50:10 --> Total execution time: 0.1530
ERROR - 2020-09-11 06:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:51:24 --> Config Class Initialized
INFO - 2020-09-11 06:51:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:51:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:51:24 --> Utf8 Class Initialized
INFO - 2020-09-11 06:51:24 --> URI Class Initialized
INFO - 2020-09-11 06:51:24 --> Router Class Initialized
INFO - 2020-09-11 06:51:24 --> Output Class Initialized
INFO - 2020-09-11 06:51:24 --> Security Class Initialized
DEBUG - 2020-09-11 06:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:51:24 --> Input Class Initialized
INFO - 2020-09-11 06:51:24 --> Language Class Initialized
INFO - 2020-09-11 06:51:24 --> Loader Class Initialized
INFO - 2020-09-11 06:51:24 --> Helper loaded: url_helper
INFO - 2020-09-11 06:51:24 --> Database Driver Class Initialized
INFO - 2020-09-11 06:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:51:24 --> Email Class Initialized
INFO - 2020-09-11 06:51:24 --> Controller Class Initialized
INFO - 2020-09-11 06:51:24 --> Model Class Initialized
INFO - 2020-09-11 06:51:24 --> Model Class Initialized
INFO - 2020-09-11 06:51:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-11 06:51:24 --> Final output sent to browser
DEBUG - 2020-09-11 06:51:24 --> Total execution time: 0.1396
ERROR - 2020-09-11 06:51:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:51:29 --> Config Class Initialized
INFO - 2020-09-11 06:51:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:51:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:51:29 --> Utf8 Class Initialized
INFO - 2020-09-11 06:51:29 --> URI Class Initialized
INFO - 2020-09-11 06:51:29 --> Router Class Initialized
INFO - 2020-09-11 06:51:29 --> Output Class Initialized
INFO - 2020-09-11 06:51:29 --> Security Class Initialized
DEBUG - 2020-09-11 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:51:29 --> Input Class Initialized
INFO - 2020-09-11 06:51:29 --> Language Class Initialized
INFO - 2020-09-11 06:51:29 --> Loader Class Initialized
INFO - 2020-09-11 06:51:29 --> Helper loaded: url_helper
INFO - 2020-09-11 06:51:29 --> Database Driver Class Initialized
INFO - 2020-09-11 06:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:51:29 --> Email Class Initialized
INFO - 2020-09-11 06:51:29 --> Controller Class Initialized
INFO - 2020-09-11 06:51:29 --> Model Class Initialized
INFO - 2020-09-11 06:51:29 --> Model Class Initialized
INFO - 2020-09-11 06:51:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-11 06:51:29 --> Final output sent to browser
DEBUG - 2020-09-11 06:51:29 --> Total execution time: 0.2472
ERROR - 2020-09-11 06:53:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:53:13 --> Config Class Initialized
INFO - 2020-09-11 06:53:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:53:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:53:13 --> Utf8 Class Initialized
INFO - 2020-09-11 06:53:13 --> URI Class Initialized
INFO - 2020-09-11 06:53:13 --> Router Class Initialized
INFO - 2020-09-11 06:53:13 --> Output Class Initialized
INFO - 2020-09-11 06:53:13 --> Security Class Initialized
DEBUG - 2020-09-11 06:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:53:13 --> Input Class Initialized
INFO - 2020-09-11 06:53:13 --> Language Class Initialized
INFO - 2020-09-11 06:53:13 --> Loader Class Initialized
INFO - 2020-09-11 06:53:13 --> Helper loaded: url_helper
INFO - 2020-09-11 06:53:13 --> Database Driver Class Initialized
INFO - 2020-09-11 06:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:53:13 --> Email Class Initialized
INFO - 2020-09-11 06:53:13 --> Controller Class Initialized
INFO - 2020-09-11 06:53:13 --> Model Class Initialized
INFO - 2020-09-11 06:53:13 --> Model Class Initialized
INFO - 2020-09-11 06:53:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-11 06:53:13 --> Final output sent to browser
DEBUG - 2020-09-11 06:53:13 --> Total execution time: 0.1317
ERROR - 2020-09-11 06:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:53:36 --> Config Class Initialized
INFO - 2020-09-11 06:53:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:53:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:53:36 --> Utf8 Class Initialized
INFO - 2020-09-11 06:53:36 --> URI Class Initialized
INFO - 2020-09-11 06:53:36 --> Router Class Initialized
INFO - 2020-09-11 06:53:36 --> Output Class Initialized
INFO - 2020-09-11 06:53:36 --> Security Class Initialized
DEBUG - 2020-09-11 06:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:53:36 --> Input Class Initialized
INFO - 2020-09-11 06:53:36 --> Language Class Initialized
INFO - 2020-09-11 06:53:36 --> Loader Class Initialized
INFO - 2020-09-11 06:53:36 --> Helper loaded: url_helper
INFO - 2020-09-11 06:53:36 --> Database Driver Class Initialized
INFO - 2020-09-11 06:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:53:36 --> Email Class Initialized
INFO - 2020-09-11 06:53:36 --> Controller Class Initialized
INFO - 2020-09-11 06:53:36 --> Model Class Initialized
INFO - 2020-09-11 06:53:36 --> Model Class Initialized
INFO - 2020-09-11 06:53:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-11 06:53:37 --> Final output sent to browser
DEBUG - 2020-09-11 06:53:37 --> Total execution time: 0.1400
ERROR - 2020-09-11 06:54:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:54:44 --> Config Class Initialized
INFO - 2020-09-11 06:54:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:54:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:54:44 --> Utf8 Class Initialized
INFO - 2020-09-11 06:54:44 --> URI Class Initialized
INFO - 2020-09-11 06:54:44 --> Router Class Initialized
INFO - 2020-09-11 06:54:44 --> Output Class Initialized
INFO - 2020-09-11 06:54:44 --> Security Class Initialized
DEBUG - 2020-09-11 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:54:44 --> Input Class Initialized
INFO - 2020-09-11 06:54:44 --> Language Class Initialized
INFO - 2020-09-11 06:54:44 --> Loader Class Initialized
INFO - 2020-09-11 06:54:44 --> Helper loaded: url_helper
INFO - 2020-09-11 06:54:44 --> Database Driver Class Initialized
INFO - 2020-09-11 06:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:54:44 --> Email Class Initialized
INFO - 2020-09-11 06:54:44 --> Controller Class Initialized
INFO - 2020-09-11 06:54:44 --> Model Class Initialized
INFO - 2020-09-11 06:54:44 --> Model Class Initialized
INFO - 2020-09-11 06:54:44 --> Final output sent to browser
DEBUG - 2020-09-11 06:54:44 --> Total execution time: 0.1308
ERROR - 2020-09-11 06:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:04 --> Config Class Initialized
INFO - 2020-09-11 06:55:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:04 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:04 --> URI Class Initialized
INFO - 2020-09-11 06:55:04 --> Router Class Initialized
INFO - 2020-09-11 06:55:04 --> Output Class Initialized
INFO - 2020-09-11 06:55:04 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:04 --> Input Class Initialized
INFO - 2020-09-11 06:55:04 --> Language Class Initialized
INFO - 2020-09-11 06:55:04 --> Loader Class Initialized
INFO - 2020-09-11 06:55:04 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:04 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:04 --> Email Class Initialized
INFO - 2020-09-11 06:55:04 --> Controller Class Initialized
INFO - 2020-09-11 06:55:04 --> Model Class Initialized
INFO - 2020-09-11 06:55:04 --> Model Class Initialized
INFO - 2020-09-11 06:55:04 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:04 --> Total execution time: 0.1229
ERROR - 2020-09-11 06:55:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:06 --> Config Class Initialized
INFO - 2020-09-11 06:55:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:06 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:06 --> URI Class Initialized
INFO - 2020-09-11 06:55:06 --> Router Class Initialized
INFO - 2020-09-11 06:55:06 --> Output Class Initialized
INFO - 2020-09-11 06:55:06 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:06 --> Input Class Initialized
INFO - 2020-09-11 06:55:06 --> Language Class Initialized
INFO - 2020-09-11 06:55:06 --> Loader Class Initialized
INFO - 2020-09-11 06:55:06 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:06 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:07 --> Email Class Initialized
INFO - 2020-09-11 06:55:07 --> Controller Class Initialized
INFO - 2020-09-11 06:55:07 --> Model Class Initialized
INFO - 2020-09-11 06:55:07 --> Model Class Initialized
INFO - 2020-09-11 06:55:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:55:07 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:07 --> Total execution time: 0.0384
ERROR - 2020-09-11 06:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:07 --> Config Class Initialized
INFO - 2020-09-11 06:55:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:07 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:07 --> URI Class Initialized
INFO - 2020-09-11 06:55:07 --> Router Class Initialized
INFO - 2020-09-11 06:55:07 --> Output Class Initialized
INFO - 2020-09-11 06:55:07 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:07 --> Input Class Initialized
INFO - 2020-09-11 06:55:07 --> Language Class Initialized
INFO - 2020-09-11 06:55:07 --> Loader Class Initialized
INFO - 2020-09-11 06:55:07 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:07 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:07 --> Email Class Initialized
INFO - 2020-09-11 06:55:07 --> Controller Class Initialized
INFO - 2020-09-11 06:55:07 --> Model Class Initialized
INFO - 2020-09-11 06:55:07 --> Model Class Initialized
INFO - 2020-09-11 06:55:07 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:07 --> Total execution time: 0.0432
ERROR - 2020-09-11 06:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:12 --> Config Class Initialized
INFO - 2020-09-11 06:55:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:12 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:12 --> URI Class Initialized
INFO - 2020-09-11 06:55:12 --> Router Class Initialized
INFO - 2020-09-11 06:55:12 --> Output Class Initialized
INFO - 2020-09-11 06:55:12 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:12 --> Input Class Initialized
INFO - 2020-09-11 06:55:12 --> Language Class Initialized
INFO - 2020-09-11 06:55:12 --> Loader Class Initialized
INFO - 2020-09-11 06:55:12 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:12 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:12 --> Email Class Initialized
INFO - 2020-09-11 06:55:12 --> Controller Class Initialized
INFO - 2020-09-11 06:55:12 --> Model Class Initialized
INFO - 2020-09-11 06:55:12 --> Model Class Initialized
INFO - 2020-09-11 06:55:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:55:12 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:12 --> Total execution time: 0.0958
ERROR - 2020-09-11 06:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:12 --> Config Class Initialized
INFO - 2020-09-11 06:55:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:12 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:12 --> URI Class Initialized
INFO - 2020-09-11 06:55:12 --> Router Class Initialized
INFO - 2020-09-11 06:55:12 --> Output Class Initialized
INFO - 2020-09-11 06:55:12 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:12 --> Input Class Initialized
INFO - 2020-09-11 06:55:12 --> Language Class Initialized
INFO - 2020-09-11 06:55:12 --> Loader Class Initialized
INFO - 2020-09-11 06:55:12 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:12 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:12 --> Email Class Initialized
INFO - 2020-09-11 06:55:12 --> Controller Class Initialized
INFO - 2020-09-11 06:55:12 --> Model Class Initialized
INFO - 2020-09-11 06:55:12 --> Model Class Initialized
INFO - 2020-09-11 06:55:12 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:12 --> Total execution time: 0.0373
ERROR - 2020-09-11 06:55:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:22 --> Config Class Initialized
INFO - 2020-09-11 06:55:22 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:22 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:22 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:22 --> URI Class Initialized
INFO - 2020-09-11 06:55:22 --> Router Class Initialized
INFO - 2020-09-11 06:55:22 --> Output Class Initialized
INFO - 2020-09-11 06:55:22 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:22 --> Input Class Initialized
INFO - 2020-09-11 06:55:22 --> Language Class Initialized
INFO - 2020-09-11 06:55:22 --> Loader Class Initialized
INFO - 2020-09-11 06:55:22 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:22 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:22 --> Email Class Initialized
INFO - 2020-09-11 06:55:22 --> Controller Class Initialized
INFO - 2020-09-11 06:55:22 --> Model Class Initialized
INFO - 2020-09-11 06:55:22 --> Model Class Initialized
INFO - 2020-09-11 06:55:22 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:22 --> Total execution time: 0.1248
ERROR - 2020-09-11 06:55:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:55:23 --> Config Class Initialized
INFO - 2020-09-11 06:55:23 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:55:23 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:55:23 --> Utf8 Class Initialized
INFO - 2020-09-11 06:55:23 --> URI Class Initialized
INFO - 2020-09-11 06:55:23 --> Router Class Initialized
INFO - 2020-09-11 06:55:23 --> Output Class Initialized
INFO - 2020-09-11 06:55:23 --> Security Class Initialized
DEBUG - 2020-09-11 06:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:55:23 --> Input Class Initialized
INFO - 2020-09-11 06:55:23 --> Language Class Initialized
INFO - 2020-09-11 06:55:23 --> Loader Class Initialized
INFO - 2020-09-11 06:55:23 --> Helper loaded: url_helper
INFO - 2020-09-11 06:55:23 --> Database Driver Class Initialized
INFO - 2020-09-11 06:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:55:23 --> Email Class Initialized
INFO - 2020-09-11 06:55:23 --> Controller Class Initialized
INFO - 2020-09-11 06:55:23 --> Model Class Initialized
INFO - 2020-09-11 06:55:23 --> Model Class Initialized
INFO - 2020-09-11 06:55:23 --> Final output sent to browser
DEBUG - 2020-09-11 06:55:23 --> Total execution time: 0.0360
ERROR - 2020-09-11 06:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:58:05 --> Config Class Initialized
INFO - 2020-09-11 06:58:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:58:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:58:05 --> Utf8 Class Initialized
INFO - 2020-09-11 06:58:05 --> URI Class Initialized
INFO - 2020-09-11 06:58:05 --> Router Class Initialized
INFO - 2020-09-11 06:58:05 --> Output Class Initialized
INFO - 2020-09-11 06:58:05 --> Security Class Initialized
DEBUG - 2020-09-11 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:58:05 --> Input Class Initialized
INFO - 2020-09-11 06:58:05 --> Language Class Initialized
INFO - 2020-09-11 06:58:05 --> Loader Class Initialized
INFO - 2020-09-11 06:58:05 --> Helper loaded: url_helper
INFO - 2020-09-11 06:58:05 --> Database Driver Class Initialized
INFO - 2020-09-11 06:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:58:05 --> Email Class Initialized
INFO - 2020-09-11 06:58:05 --> Controller Class Initialized
INFO - 2020-09-11 06:58:05 --> Model Class Initialized
INFO - 2020-09-11 06:58:05 --> Model Class Initialized
INFO - 2020-09-11 06:58:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:58:05 --> Final output sent to browser
DEBUG - 2020-09-11 06:58:05 --> Total execution time: 0.0375
ERROR - 2020-09-11 06:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:58:05 --> Config Class Initialized
INFO - 2020-09-11 06:58:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:58:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:58:05 --> Utf8 Class Initialized
INFO - 2020-09-11 06:58:05 --> URI Class Initialized
INFO - 2020-09-11 06:58:05 --> Router Class Initialized
INFO - 2020-09-11 06:58:05 --> Output Class Initialized
INFO - 2020-09-11 06:58:05 --> Security Class Initialized
DEBUG - 2020-09-11 06:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:58:05 --> Input Class Initialized
INFO - 2020-09-11 06:58:05 --> Language Class Initialized
INFO - 2020-09-11 06:58:05 --> Loader Class Initialized
INFO - 2020-09-11 06:58:05 --> Helper loaded: url_helper
INFO - 2020-09-11 06:58:05 --> Database Driver Class Initialized
INFO - 2020-09-11 06:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:58:05 --> Email Class Initialized
INFO - 2020-09-11 06:58:05 --> Controller Class Initialized
INFO - 2020-09-11 06:58:05 --> Model Class Initialized
INFO - 2020-09-11 06:58:05 --> Model Class Initialized
INFO - 2020-09-11 06:58:05 --> Final output sent to browser
DEBUG - 2020-09-11 06:58:05 --> Total execution time: 0.0424
ERROR - 2020-09-11 06:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:59:05 --> Config Class Initialized
INFO - 2020-09-11 06:59:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:59:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:59:05 --> Utf8 Class Initialized
INFO - 2020-09-11 06:59:05 --> URI Class Initialized
INFO - 2020-09-11 06:59:05 --> Router Class Initialized
INFO - 2020-09-11 06:59:05 --> Output Class Initialized
INFO - 2020-09-11 06:59:05 --> Security Class Initialized
DEBUG - 2020-09-11 06:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:59:05 --> Input Class Initialized
INFO - 2020-09-11 06:59:05 --> Language Class Initialized
INFO - 2020-09-11 06:59:05 --> Loader Class Initialized
INFO - 2020-09-11 06:59:05 --> Helper loaded: url_helper
INFO - 2020-09-11 06:59:05 --> Database Driver Class Initialized
INFO - 2020-09-11 06:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:59:05 --> Email Class Initialized
INFO - 2020-09-11 06:59:05 --> Controller Class Initialized
INFO - 2020-09-11 06:59:05 --> Model Class Initialized
INFO - 2020-09-11 06:59:05 --> Model Class Initialized
INFO - 2020-09-11 06:59:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:59:05 --> Final output sent to browser
DEBUG - 2020-09-11 06:59:05 --> Total execution time: 0.0436
ERROR - 2020-09-11 06:59:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:59:06 --> Config Class Initialized
INFO - 2020-09-11 06:59:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:59:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:59:06 --> Utf8 Class Initialized
INFO - 2020-09-11 06:59:06 --> URI Class Initialized
INFO - 2020-09-11 06:59:06 --> Router Class Initialized
INFO - 2020-09-11 06:59:06 --> Output Class Initialized
INFO - 2020-09-11 06:59:06 --> Security Class Initialized
DEBUG - 2020-09-11 06:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:59:06 --> Input Class Initialized
INFO - 2020-09-11 06:59:06 --> Language Class Initialized
INFO - 2020-09-11 06:59:06 --> Loader Class Initialized
INFO - 2020-09-11 06:59:06 --> Helper loaded: url_helper
INFO - 2020-09-11 06:59:06 --> Database Driver Class Initialized
INFO - 2020-09-11 06:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:59:06 --> Email Class Initialized
INFO - 2020-09-11 06:59:06 --> Controller Class Initialized
INFO - 2020-09-11 06:59:06 --> Model Class Initialized
INFO - 2020-09-11 06:59:06 --> Model Class Initialized
INFO - 2020-09-11 06:59:06 --> Final output sent to browser
DEBUG - 2020-09-11 06:59:06 --> Total execution time: 0.0551
ERROR - 2020-09-11 06:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:59:51 --> Config Class Initialized
INFO - 2020-09-11 06:59:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:59:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:59:51 --> Utf8 Class Initialized
INFO - 2020-09-11 06:59:51 --> URI Class Initialized
INFO - 2020-09-11 06:59:51 --> Router Class Initialized
INFO - 2020-09-11 06:59:51 --> Output Class Initialized
INFO - 2020-09-11 06:59:51 --> Security Class Initialized
DEBUG - 2020-09-11 06:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:59:51 --> Input Class Initialized
INFO - 2020-09-11 06:59:51 --> Language Class Initialized
INFO - 2020-09-11 06:59:51 --> Loader Class Initialized
INFO - 2020-09-11 06:59:51 --> Helper loaded: url_helper
INFO - 2020-09-11 06:59:51 --> Database Driver Class Initialized
INFO - 2020-09-11 06:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:59:51 --> Email Class Initialized
INFO - 2020-09-11 06:59:51 --> Controller Class Initialized
INFO - 2020-09-11 06:59:51 --> Model Class Initialized
INFO - 2020-09-11 06:59:51 --> Model Class Initialized
INFO - 2020-09-11 06:59:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 06:59:51 --> Final output sent to browser
DEBUG - 2020-09-11 06:59:51 --> Total execution time: 0.0365
ERROR - 2020-09-11 06:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 06:59:52 --> Config Class Initialized
INFO - 2020-09-11 06:59:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 06:59:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 06:59:52 --> Utf8 Class Initialized
INFO - 2020-09-11 06:59:52 --> URI Class Initialized
INFO - 2020-09-11 06:59:52 --> Router Class Initialized
INFO - 2020-09-11 06:59:52 --> Output Class Initialized
INFO - 2020-09-11 06:59:52 --> Security Class Initialized
DEBUG - 2020-09-11 06:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 06:59:52 --> Input Class Initialized
INFO - 2020-09-11 06:59:52 --> Language Class Initialized
INFO - 2020-09-11 06:59:52 --> Loader Class Initialized
INFO - 2020-09-11 06:59:52 --> Helper loaded: url_helper
INFO - 2020-09-11 06:59:52 --> Database Driver Class Initialized
INFO - 2020-09-11 06:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 06:59:52 --> Email Class Initialized
INFO - 2020-09-11 06:59:52 --> Controller Class Initialized
INFO - 2020-09-11 06:59:52 --> Model Class Initialized
INFO - 2020-09-11 06:59:52 --> Model Class Initialized
INFO - 2020-09-11 06:59:52 --> Final output sent to browser
DEBUG - 2020-09-11 06:59:52 --> Total execution time: 0.0396
ERROR - 2020-09-11 07:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:00:35 --> Config Class Initialized
INFO - 2020-09-11 07:00:35 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:00:35 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:00:35 --> Utf8 Class Initialized
INFO - 2020-09-11 07:00:35 --> URI Class Initialized
INFO - 2020-09-11 07:00:35 --> Router Class Initialized
INFO - 2020-09-11 07:00:35 --> Output Class Initialized
INFO - 2020-09-11 07:00:35 --> Security Class Initialized
DEBUG - 2020-09-11 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:00:35 --> Input Class Initialized
INFO - 2020-09-11 07:00:35 --> Language Class Initialized
INFO - 2020-09-11 07:00:35 --> Loader Class Initialized
INFO - 2020-09-11 07:00:35 --> Helper loaded: url_helper
INFO - 2020-09-11 07:00:35 --> Database Driver Class Initialized
INFO - 2020-09-11 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:00:35 --> Email Class Initialized
INFO - 2020-09-11 07:00:35 --> Controller Class Initialized
INFO - 2020-09-11 07:00:35 --> Model Class Initialized
INFO - 2020-09-11 07:00:35 --> Model Class Initialized
INFO - 2020-09-11 07:00:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:00:35 --> Final output sent to browser
DEBUG - 2020-09-11 07:00:35 --> Total execution time: 0.0428
ERROR - 2020-09-11 07:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:00:35 --> Config Class Initialized
INFO - 2020-09-11 07:00:35 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:00:35 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:00:35 --> Utf8 Class Initialized
INFO - 2020-09-11 07:00:35 --> URI Class Initialized
INFO - 2020-09-11 07:00:35 --> Router Class Initialized
INFO - 2020-09-11 07:00:35 --> Output Class Initialized
INFO - 2020-09-11 07:00:35 --> Security Class Initialized
DEBUG - 2020-09-11 07:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:00:35 --> Input Class Initialized
INFO - 2020-09-11 07:00:35 --> Language Class Initialized
INFO - 2020-09-11 07:00:35 --> Loader Class Initialized
INFO - 2020-09-11 07:00:35 --> Helper loaded: url_helper
INFO - 2020-09-11 07:00:35 --> Database Driver Class Initialized
INFO - 2020-09-11 07:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:00:35 --> Email Class Initialized
INFO - 2020-09-11 07:00:35 --> Controller Class Initialized
INFO - 2020-09-11 07:00:35 --> Model Class Initialized
INFO - 2020-09-11 07:00:35 --> Model Class Initialized
INFO - 2020-09-11 07:00:35 --> Final output sent to browser
DEBUG - 2020-09-11 07:00:35 --> Total execution time: 0.0427
ERROR - 2020-09-11 07:01:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:01:44 --> Config Class Initialized
INFO - 2020-09-11 07:01:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:01:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:01:44 --> Utf8 Class Initialized
INFO - 2020-09-11 07:01:44 --> URI Class Initialized
INFO - 2020-09-11 07:01:44 --> Router Class Initialized
INFO - 2020-09-11 07:01:44 --> Output Class Initialized
INFO - 2020-09-11 07:01:44 --> Security Class Initialized
DEBUG - 2020-09-11 07:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:01:44 --> Input Class Initialized
INFO - 2020-09-11 07:01:44 --> Language Class Initialized
INFO - 2020-09-11 07:01:44 --> Loader Class Initialized
INFO - 2020-09-11 07:01:44 --> Helper loaded: url_helper
INFO - 2020-09-11 07:01:44 --> Database Driver Class Initialized
INFO - 2020-09-11 07:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:01:44 --> Email Class Initialized
INFO - 2020-09-11 07:01:44 --> Controller Class Initialized
INFO - 2020-09-11 07:01:44 --> Model Class Initialized
INFO - 2020-09-11 07:01:44 --> Model Class Initialized
INFO - 2020-09-11 07:01:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:01:44 --> Final output sent to browser
DEBUG - 2020-09-11 07:01:44 --> Total execution time: 0.0388
ERROR - 2020-09-11 07:01:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:01:44 --> Config Class Initialized
INFO - 2020-09-11 07:01:44 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:01:44 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:01:44 --> Utf8 Class Initialized
INFO - 2020-09-11 07:01:44 --> URI Class Initialized
INFO - 2020-09-11 07:01:44 --> Router Class Initialized
INFO - 2020-09-11 07:01:44 --> Output Class Initialized
INFO - 2020-09-11 07:01:44 --> Security Class Initialized
DEBUG - 2020-09-11 07:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:01:44 --> Input Class Initialized
INFO - 2020-09-11 07:01:44 --> Language Class Initialized
INFO - 2020-09-11 07:01:44 --> Loader Class Initialized
INFO - 2020-09-11 07:01:44 --> Helper loaded: url_helper
INFO - 2020-09-11 07:01:44 --> Database Driver Class Initialized
INFO - 2020-09-11 07:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:01:44 --> Email Class Initialized
INFO - 2020-09-11 07:01:44 --> Controller Class Initialized
INFO - 2020-09-11 07:01:44 --> Model Class Initialized
INFO - 2020-09-11 07:01:44 --> Model Class Initialized
INFO - 2020-09-11 07:01:44 --> Final output sent to browser
DEBUG - 2020-09-11 07:01:44 --> Total execution time: 0.0424
ERROR - 2020-09-11 07:03:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:03:12 --> Config Class Initialized
INFO - 2020-09-11 07:03:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:03:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:03:12 --> Utf8 Class Initialized
INFO - 2020-09-11 07:03:12 --> URI Class Initialized
INFO - 2020-09-11 07:03:12 --> Router Class Initialized
INFO - 2020-09-11 07:03:12 --> Output Class Initialized
INFO - 2020-09-11 07:03:12 --> Security Class Initialized
DEBUG - 2020-09-11 07:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:03:12 --> Input Class Initialized
INFO - 2020-09-11 07:03:12 --> Language Class Initialized
INFO - 2020-09-11 07:03:12 --> Loader Class Initialized
INFO - 2020-09-11 07:03:12 --> Helper loaded: url_helper
INFO - 2020-09-11 07:03:12 --> Database Driver Class Initialized
INFO - 2020-09-11 07:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:03:12 --> Email Class Initialized
INFO - 2020-09-11 07:03:12 --> Controller Class Initialized
INFO - 2020-09-11 07:03:12 --> Model Class Initialized
INFO - 2020-09-11 07:03:12 --> Model Class Initialized
INFO - 2020-09-11 07:03:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:03:12 --> Final output sent to browser
DEBUG - 2020-09-11 07:03:12 --> Total execution time: 0.0404
ERROR - 2020-09-11 07:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:03:13 --> Config Class Initialized
INFO - 2020-09-11 07:03:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:03:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:03:13 --> Utf8 Class Initialized
INFO - 2020-09-11 07:03:13 --> URI Class Initialized
INFO - 2020-09-11 07:03:13 --> Router Class Initialized
INFO - 2020-09-11 07:03:13 --> Output Class Initialized
INFO - 2020-09-11 07:03:13 --> Security Class Initialized
DEBUG - 2020-09-11 07:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:03:13 --> Input Class Initialized
INFO - 2020-09-11 07:03:13 --> Language Class Initialized
INFO - 2020-09-11 07:03:13 --> Loader Class Initialized
INFO - 2020-09-11 07:03:13 --> Helper loaded: url_helper
INFO - 2020-09-11 07:03:13 --> Database Driver Class Initialized
INFO - 2020-09-11 07:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:03:13 --> Email Class Initialized
INFO - 2020-09-11 07:03:13 --> Controller Class Initialized
INFO - 2020-09-11 07:03:13 --> Model Class Initialized
INFO - 2020-09-11 07:03:13 --> Model Class Initialized
INFO - 2020-09-11 07:03:13 --> Final output sent to browser
DEBUG - 2020-09-11 07:03:13 --> Total execution time: 0.0406
ERROR - 2020-09-11 07:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:03:37 --> Config Class Initialized
INFO - 2020-09-11 07:03:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:03:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:03:37 --> Utf8 Class Initialized
INFO - 2020-09-11 07:03:37 --> URI Class Initialized
INFO - 2020-09-11 07:03:37 --> Router Class Initialized
INFO - 2020-09-11 07:03:37 --> Output Class Initialized
INFO - 2020-09-11 07:03:37 --> Security Class Initialized
DEBUG - 2020-09-11 07:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:03:37 --> Input Class Initialized
INFO - 2020-09-11 07:03:37 --> Language Class Initialized
INFO - 2020-09-11 07:03:37 --> Loader Class Initialized
INFO - 2020-09-11 07:03:37 --> Helper loaded: url_helper
INFO - 2020-09-11 07:03:37 --> Database Driver Class Initialized
INFO - 2020-09-11 07:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:03:37 --> Email Class Initialized
INFO - 2020-09-11 07:03:37 --> Controller Class Initialized
INFO - 2020-09-11 07:03:37 --> Model Class Initialized
INFO - 2020-09-11 07:03:37 --> Model Class Initialized
INFO - 2020-09-11 07:03:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:03:37 --> Final output sent to browser
DEBUG - 2020-09-11 07:03:37 --> Total execution time: 0.0456
ERROR - 2020-09-11 07:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:03:38 --> Config Class Initialized
INFO - 2020-09-11 07:03:38 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:03:38 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:03:38 --> Utf8 Class Initialized
INFO - 2020-09-11 07:03:38 --> URI Class Initialized
INFO - 2020-09-11 07:03:38 --> Router Class Initialized
INFO - 2020-09-11 07:03:38 --> Output Class Initialized
INFO - 2020-09-11 07:03:38 --> Security Class Initialized
DEBUG - 2020-09-11 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:03:38 --> Input Class Initialized
INFO - 2020-09-11 07:03:38 --> Language Class Initialized
INFO - 2020-09-11 07:03:38 --> Loader Class Initialized
INFO - 2020-09-11 07:03:38 --> Helper loaded: url_helper
INFO - 2020-09-11 07:03:38 --> Database Driver Class Initialized
INFO - 2020-09-11 07:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:03:38 --> Email Class Initialized
INFO - 2020-09-11 07:03:38 --> Controller Class Initialized
INFO - 2020-09-11 07:03:38 --> Model Class Initialized
INFO - 2020-09-11 07:03:38 --> Model Class Initialized
INFO - 2020-09-11 07:03:38 --> Final output sent to browser
DEBUG - 2020-09-11 07:03:38 --> Total execution time: 0.0451
ERROR - 2020-09-11 07:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:05:14 --> Config Class Initialized
INFO - 2020-09-11 07:05:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:05:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:05:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:05:14 --> URI Class Initialized
INFO - 2020-09-11 07:05:14 --> Router Class Initialized
INFO - 2020-09-11 07:05:14 --> Output Class Initialized
INFO - 2020-09-11 07:05:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:05:14 --> Input Class Initialized
INFO - 2020-09-11 07:05:14 --> Language Class Initialized
INFO - 2020-09-11 07:05:14 --> Loader Class Initialized
INFO - 2020-09-11 07:05:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:05:14 --> Database Driver Class Initialized
INFO - 2020-09-11 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:05:14 --> Email Class Initialized
INFO - 2020-09-11 07:05:14 --> Controller Class Initialized
INFO - 2020-09-11 07:05:14 --> Model Class Initialized
INFO - 2020-09-11 07:05:14 --> Model Class Initialized
INFO - 2020-09-11 07:05:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:05:14 --> Final output sent to browser
DEBUG - 2020-09-11 07:05:14 --> Total execution time: 0.0464
ERROR - 2020-09-11 07:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:05:14 --> Config Class Initialized
INFO - 2020-09-11 07:05:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:05:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:05:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:05:14 --> URI Class Initialized
INFO - 2020-09-11 07:05:14 --> Router Class Initialized
INFO - 2020-09-11 07:05:14 --> Output Class Initialized
INFO - 2020-09-11 07:05:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:05:14 --> Input Class Initialized
INFO - 2020-09-11 07:05:14 --> Language Class Initialized
INFO - 2020-09-11 07:05:14 --> Loader Class Initialized
INFO - 2020-09-11 07:05:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:05:14 --> Database Driver Class Initialized
INFO - 2020-09-11 07:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:05:14 --> Email Class Initialized
INFO - 2020-09-11 07:05:14 --> Controller Class Initialized
INFO - 2020-09-11 07:05:14 --> Model Class Initialized
INFO - 2020-09-11 07:05:14 --> Model Class Initialized
INFO - 2020-09-11 07:05:14 --> Final output sent to browser
DEBUG - 2020-09-11 07:05:14 --> Total execution time: 0.0570
ERROR - 2020-09-11 07:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:05:56 --> Config Class Initialized
INFO - 2020-09-11 07:05:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:05:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:05:56 --> Utf8 Class Initialized
INFO - 2020-09-11 07:05:56 --> URI Class Initialized
INFO - 2020-09-11 07:05:56 --> Router Class Initialized
INFO - 2020-09-11 07:05:56 --> Output Class Initialized
INFO - 2020-09-11 07:05:56 --> Security Class Initialized
DEBUG - 2020-09-11 07:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:05:56 --> Input Class Initialized
INFO - 2020-09-11 07:05:56 --> Language Class Initialized
INFO - 2020-09-11 07:05:56 --> Loader Class Initialized
INFO - 2020-09-11 07:05:56 --> Helper loaded: url_helper
INFO - 2020-09-11 07:05:56 --> Database Driver Class Initialized
INFO - 2020-09-11 07:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:05:56 --> Email Class Initialized
INFO - 2020-09-11 07:05:56 --> Controller Class Initialized
INFO - 2020-09-11 07:05:56 --> Model Class Initialized
INFO - 2020-09-11 07:05:56 --> Model Class Initialized
INFO - 2020-09-11 07:05:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:05:56 --> Final output sent to browser
DEBUG - 2020-09-11 07:05:56 --> Total execution time: 0.0347
ERROR - 2020-09-11 07:05:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:05:57 --> Config Class Initialized
INFO - 2020-09-11 07:05:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:05:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:05:57 --> Utf8 Class Initialized
INFO - 2020-09-11 07:05:57 --> URI Class Initialized
INFO - 2020-09-11 07:05:57 --> Router Class Initialized
INFO - 2020-09-11 07:05:57 --> Output Class Initialized
INFO - 2020-09-11 07:05:57 --> Security Class Initialized
DEBUG - 2020-09-11 07:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:05:57 --> Input Class Initialized
INFO - 2020-09-11 07:05:57 --> Language Class Initialized
INFO - 2020-09-11 07:05:57 --> Loader Class Initialized
INFO - 2020-09-11 07:05:57 --> Helper loaded: url_helper
INFO - 2020-09-11 07:05:57 --> Database Driver Class Initialized
INFO - 2020-09-11 07:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:05:57 --> Email Class Initialized
INFO - 2020-09-11 07:05:57 --> Controller Class Initialized
INFO - 2020-09-11 07:05:57 --> Model Class Initialized
INFO - 2020-09-11 07:05:57 --> Model Class Initialized
INFO - 2020-09-11 07:05:57 --> Final output sent to browser
DEBUG - 2020-09-11 07:05:57 --> Total execution time: 0.0337
ERROR - 2020-09-11 07:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:06:26 --> Config Class Initialized
INFO - 2020-09-11 07:06:26 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:06:26 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:06:26 --> Utf8 Class Initialized
INFO - 2020-09-11 07:06:26 --> URI Class Initialized
INFO - 2020-09-11 07:06:26 --> Router Class Initialized
INFO - 2020-09-11 07:06:26 --> Output Class Initialized
INFO - 2020-09-11 07:06:26 --> Security Class Initialized
DEBUG - 2020-09-11 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:06:26 --> Input Class Initialized
INFO - 2020-09-11 07:06:26 --> Language Class Initialized
INFO - 2020-09-11 07:06:26 --> Loader Class Initialized
INFO - 2020-09-11 07:06:26 --> Helper loaded: url_helper
INFO - 2020-09-11 07:06:26 --> Database Driver Class Initialized
INFO - 2020-09-11 07:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:06:26 --> Email Class Initialized
INFO - 2020-09-11 07:06:26 --> Controller Class Initialized
INFO - 2020-09-11 07:06:26 --> Model Class Initialized
INFO - 2020-09-11 07:06:26 --> Model Class Initialized
INFO - 2020-09-11 07:06:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:06:26 --> Final output sent to browser
DEBUG - 2020-09-11 07:06:26 --> Total execution time: 0.0404
ERROR - 2020-09-11 07:06:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:06:27 --> Config Class Initialized
INFO - 2020-09-11 07:06:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:06:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:06:27 --> Utf8 Class Initialized
INFO - 2020-09-11 07:06:27 --> URI Class Initialized
INFO - 2020-09-11 07:06:27 --> Router Class Initialized
INFO - 2020-09-11 07:06:27 --> Output Class Initialized
INFO - 2020-09-11 07:06:27 --> Security Class Initialized
DEBUG - 2020-09-11 07:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:06:27 --> Input Class Initialized
INFO - 2020-09-11 07:06:27 --> Language Class Initialized
INFO - 2020-09-11 07:06:27 --> Loader Class Initialized
INFO - 2020-09-11 07:06:27 --> Helper loaded: url_helper
INFO - 2020-09-11 07:06:27 --> Database Driver Class Initialized
INFO - 2020-09-11 07:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:06:27 --> Email Class Initialized
INFO - 2020-09-11 07:06:27 --> Controller Class Initialized
INFO - 2020-09-11 07:06:27 --> Model Class Initialized
INFO - 2020-09-11 07:06:27 --> Model Class Initialized
INFO - 2020-09-11 07:06:27 --> Final output sent to browser
DEBUG - 2020-09-11 07:06:27 --> Total execution time: 0.0411
ERROR - 2020-09-11 07:07:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:07:36 --> Config Class Initialized
INFO - 2020-09-11 07:07:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:07:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:07:36 --> Utf8 Class Initialized
INFO - 2020-09-11 07:07:36 --> URI Class Initialized
INFO - 2020-09-11 07:07:36 --> Router Class Initialized
INFO - 2020-09-11 07:07:36 --> Output Class Initialized
INFO - 2020-09-11 07:07:36 --> Security Class Initialized
DEBUG - 2020-09-11 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:07:36 --> Input Class Initialized
INFO - 2020-09-11 07:07:36 --> Language Class Initialized
INFO - 2020-09-11 07:07:36 --> Loader Class Initialized
INFO - 2020-09-11 07:07:36 --> Helper loaded: url_helper
INFO - 2020-09-11 07:07:36 --> Database Driver Class Initialized
INFO - 2020-09-11 07:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:07:36 --> Email Class Initialized
INFO - 2020-09-11 07:07:36 --> Controller Class Initialized
INFO - 2020-09-11 07:07:36 --> Model Class Initialized
INFO - 2020-09-11 07:07:36 --> Model Class Initialized
INFO - 2020-09-11 07:07:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:07:36 --> Final output sent to browser
DEBUG - 2020-09-11 07:07:36 --> Total execution time: 0.0393
ERROR - 2020-09-11 07:07:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:07:37 --> Config Class Initialized
INFO - 2020-09-11 07:07:37 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:07:37 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:07:37 --> Utf8 Class Initialized
INFO - 2020-09-11 07:07:37 --> URI Class Initialized
INFO - 2020-09-11 07:07:37 --> Router Class Initialized
INFO - 2020-09-11 07:07:37 --> Output Class Initialized
INFO - 2020-09-11 07:07:37 --> Security Class Initialized
DEBUG - 2020-09-11 07:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:07:37 --> Input Class Initialized
INFO - 2020-09-11 07:07:37 --> Language Class Initialized
INFO - 2020-09-11 07:07:37 --> Loader Class Initialized
INFO - 2020-09-11 07:07:37 --> Helper loaded: url_helper
INFO - 2020-09-11 07:07:37 --> Database Driver Class Initialized
INFO - 2020-09-11 07:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:07:37 --> Email Class Initialized
INFO - 2020-09-11 07:07:37 --> Controller Class Initialized
INFO - 2020-09-11 07:07:37 --> Model Class Initialized
INFO - 2020-09-11 07:07:37 --> Model Class Initialized
INFO - 2020-09-11 07:07:37 --> Final output sent to browser
DEBUG - 2020-09-11 07:07:37 --> Total execution time: 0.0410
ERROR - 2020-09-11 07:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:08:56 --> Config Class Initialized
INFO - 2020-09-11 07:08:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:08:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:08:56 --> Utf8 Class Initialized
INFO - 2020-09-11 07:08:56 --> URI Class Initialized
INFO - 2020-09-11 07:08:56 --> Router Class Initialized
INFO - 2020-09-11 07:08:56 --> Output Class Initialized
INFO - 2020-09-11 07:08:56 --> Security Class Initialized
DEBUG - 2020-09-11 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:08:56 --> Input Class Initialized
INFO - 2020-09-11 07:08:56 --> Language Class Initialized
INFO - 2020-09-11 07:08:56 --> Loader Class Initialized
INFO - 2020-09-11 07:08:56 --> Helper loaded: url_helper
INFO - 2020-09-11 07:08:56 --> Database Driver Class Initialized
INFO - 2020-09-11 07:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:08:56 --> Email Class Initialized
INFO - 2020-09-11 07:08:56 --> Controller Class Initialized
INFO - 2020-09-11 07:08:56 --> Model Class Initialized
INFO - 2020-09-11 07:08:56 --> Model Class Initialized
INFO - 2020-09-11 07:08:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:08:56 --> Final output sent to browser
DEBUG - 2020-09-11 07:08:56 --> Total execution time: 0.0339
ERROR - 2020-09-11 07:08:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:08:56 --> Config Class Initialized
INFO - 2020-09-11 07:08:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:08:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:08:56 --> Utf8 Class Initialized
INFO - 2020-09-11 07:08:56 --> URI Class Initialized
INFO - 2020-09-11 07:08:56 --> Router Class Initialized
INFO - 2020-09-11 07:08:56 --> Output Class Initialized
INFO - 2020-09-11 07:08:56 --> Security Class Initialized
DEBUG - 2020-09-11 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:08:56 --> Input Class Initialized
INFO - 2020-09-11 07:08:56 --> Language Class Initialized
INFO - 2020-09-11 07:08:56 --> Loader Class Initialized
INFO - 2020-09-11 07:08:56 --> Helper loaded: url_helper
INFO - 2020-09-11 07:08:57 --> Database Driver Class Initialized
INFO - 2020-09-11 07:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:08:57 --> Email Class Initialized
INFO - 2020-09-11 07:08:57 --> Controller Class Initialized
INFO - 2020-09-11 07:08:57 --> Model Class Initialized
INFO - 2020-09-11 07:08:57 --> Model Class Initialized
INFO - 2020-09-11 07:08:57 --> Final output sent to browser
DEBUG - 2020-09-11 07:08:57 --> Total execution time: 0.0352
ERROR - 2020-09-11 07:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:09:14 --> Config Class Initialized
INFO - 2020-09-11 07:09:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:09:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:09:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:09:14 --> URI Class Initialized
INFO - 2020-09-11 07:09:14 --> Router Class Initialized
INFO - 2020-09-11 07:09:14 --> Output Class Initialized
INFO - 2020-09-11 07:09:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:09:14 --> Input Class Initialized
INFO - 2020-09-11 07:09:14 --> Language Class Initialized
INFO - 2020-09-11 07:09:14 --> Loader Class Initialized
INFO - 2020-09-11 07:09:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:09:14 --> Database Driver Class Initialized
INFO - 2020-09-11 07:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:09:14 --> Email Class Initialized
INFO - 2020-09-11 07:09:14 --> Controller Class Initialized
INFO - 2020-09-11 07:09:14 --> Model Class Initialized
INFO - 2020-09-11 07:09:14 --> Model Class Initialized
INFO - 2020-09-11 07:09:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:09:14 --> Final output sent to browser
DEBUG - 2020-09-11 07:09:14 --> Total execution time: 0.1497
ERROR - 2020-09-11 07:09:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:09:14 --> Config Class Initialized
INFO - 2020-09-11 07:09:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:09:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:09:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:09:14 --> URI Class Initialized
INFO - 2020-09-11 07:09:14 --> Router Class Initialized
INFO - 2020-09-11 07:09:14 --> Output Class Initialized
INFO - 2020-09-11 07:09:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:09:14 --> Input Class Initialized
INFO - 2020-09-11 07:09:14 --> Language Class Initialized
INFO - 2020-09-11 07:09:14 --> Loader Class Initialized
INFO - 2020-09-11 07:09:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:09:14 --> Database Driver Class Initialized
INFO - 2020-09-11 07:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:09:14 --> Email Class Initialized
INFO - 2020-09-11 07:09:14 --> Controller Class Initialized
INFO - 2020-09-11 07:09:14 --> Model Class Initialized
INFO - 2020-09-11 07:09:14 --> Model Class Initialized
INFO - 2020-09-11 07:09:14 --> Final output sent to browser
DEBUG - 2020-09-11 07:09:14 --> Total execution time: 0.0454
ERROR - 2020-09-11 07:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:17:25 --> Config Class Initialized
INFO - 2020-09-11 07:17:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:17:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:17:25 --> Utf8 Class Initialized
INFO - 2020-09-11 07:17:25 --> URI Class Initialized
INFO - 2020-09-11 07:17:25 --> Router Class Initialized
INFO - 2020-09-11 07:17:25 --> Output Class Initialized
INFO - 2020-09-11 07:17:25 --> Security Class Initialized
DEBUG - 2020-09-11 07:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:17:25 --> Input Class Initialized
INFO - 2020-09-11 07:17:25 --> Language Class Initialized
INFO - 2020-09-11 07:17:25 --> Loader Class Initialized
INFO - 2020-09-11 07:17:25 --> Helper loaded: url_helper
INFO - 2020-09-11 07:17:25 --> Database Driver Class Initialized
INFO - 2020-09-11 07:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:17:25 --> Email Class Initialized
INFO - 2020-09-11 07:17:25 --> Controller Class Initialized
INFO - 2020-09-11 07:17:25 --> Model Class Initialized
INFO - 2020-09-11 07:17:25 --> Model Class Initialized
INFO - 2020-09-11 07:17:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:17:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:17:25 --> Total execution time: 0.0413
ERROR - 2020-09-11 07:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:17:25 --> Config Class Initialized
INFO - 2020-09-11 07:17:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:17:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:17:25 --> Utf8 Class Initialized
INFO - 2020-09-11 07:17:25 --> URI Class Initialized
INFO - 2020-09-11 07:17:25 --> Router Class Initialized
INFO - 2020-09-11 07:17:25 --> Output Class Initialized
INFO - 2020-09-11 07:17:25 --> Security Class Initialized
DEBUG - 2020-09-11 07:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:17:25 --> Input Class Initialized
INFO - 2020-09-11 07:17:25 --> Language Class Initialized
INFO - 2020-09-11 07:17:25 --> Loader Class Initialized
INFO - 2020-09-11 07:17:25 --> Helper loaded: url_helper
INFO - 2020-09-11 07:17:25 --> Database Driver Class Initialized
INFO - 2020-09-11 07:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:17:25 --> Email Class Initialized
INFO - 2020-09-11 07:17:25 --> Controller Class Initialized
INFO - 2020-09-11 07:17:25 --> Model Class Initialized
INFO - 2020-09-11 07:17:25 --> Model Class Initialized
INFO - 2020-09-11 07:17:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:17:25 --> Total execution time: 0.0398
ERROR - 2020-09-11 07:19:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:19:09 --> Config Class Initialized
INFO - 2020-09-11 07:19:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:19:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:19:09 --> Utf8 Class Initialized
INFO - 2020-09-11 07:19:09 --> URI Class Initialized
INFO - 2020-09-11 07:19:09 --> Router Class Initialized
INFO - 2020-09-11 07:19:09 --> Output Class Initialized
INFO - 2020-09-11 07:19:09 --> Security Class Initialized
DEBUG - 2020-09-11 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:19:09 --> Input Class Initialized
INFO - 2020-09-11 07:19:09 --> Language Class Initialized
INFO - 2020-09-11 07:19:09 --> Loader Class Initialized
INFO - 2020-09-11 07:19:09 --> Helper loaded: url_helper
INFO - 2020-09-11 07:19:09 --> Database Driver Class Initialized
INFO - 2020-09-11 07:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:19:09 --> Email Class Initialized
INFO - 2020-09-11 07:19:09 --> Controller Class Initialized
INFO - 2020-09-11 07:19:09 --> Model Class Initialized
INFO - 2020-09-11 07:19:09 --> Model Class Initialized
INFO - 2020-09-11 07:19:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:19:09 --> Final output sent to browser
DEBUG - 2020-09-11 07:19:09 --> Total execution time: 0.0568
ERROR - 2020-09-11 07:19:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:19:09 --> Config Class Initialized
INFO - 2020-09-11 07:19:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:19:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:19:09 --> Utf8 Class Initialized
INFO - 2020-09-11 07:19:09 --> URI Class Initialized
INFO - 2020-09-11 07:19:09 --> Router Class Initialized
INFO - 2020-09-11 07:19:09 --> Output Class Initialized
INFO - 2020-09-11 07:19:09 --> Security Class Initialized
DEBUG - 2020-09-11 07:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:19:09 --> Input Class Initialized
INFO - 2020-09-11 07:19:09 --> Language Class Initialized
INFO - 2020-09-11 07:19:10 --> Loader Class Initialized
INFO - 2020-09-11 07:19:10 --> Helper loaded: url_helper
INFO - 2020-09-11 07:19:10 --> Database Driver Class Initialized
INFO - 2020-09-11 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:19:10 --> Email Class Initialized
INFO - 2020-09-11 07:19:10 --> Controller Class Initialized
INFO - 2020-09-11 07:19:10 --> Model Class Initialized
INFO - 2020-09-11 07:19:10 --> Model Class Initialized
INFO - 2020-09-11 07:19:10 --> Final output sent to browser
DEBUG - 2020-09-11 07:19:10 --> Total execution time: 0.0409
ERROR - 2020-09-11 07:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:19:24 --> Config Class Initialized
INFO - 2020-09-11 07:19:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:19:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:19:24 --> Utf8 Class Initialized
INFO - 2020-09-11 07:19:24 --> URI Class Initialized
INFO - 2020-09-11 07:19:24 --> Router Class Initialized
INFO - 2020-09-11 07:19:24 --> Output Class Initialized
INFO - 2020-09-11 07:19:24 --> Security Class Initialized
DEBUG - 2020-09-11 07:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:19:24 --> Input Class Initialized
INFO - 2020-09-11 07:19:24 --> Language Class Initialized
INFO - 2020-09-11 07:19:24 --> Loader Class Initialized
INFO - 2020-09-11 07:19:24 --> Helper loaded: url_helper
INFO - 2020-09-11 07:19:24 --> Database Driver Class Initialized
INFO - 2020-09-11 07:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:19:24 --> Email Class Initialized
INFO - 2020-09-11 07:19:24 --> Controller Class Initialized
INFO - 2020-09-11 07:19:24 --> Model Class Initialized
INFO - 2020-09-11 07:19:24 --> Model Class Initialized
INFO - 2020-09-11 07:19:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:19:25 --> Total execution time: 0.1422
ERROR - 2020-09-11 07:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:19:25 --> Config Class Initialized
INFO - 2020-09-11 07:19:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:19:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:19:25 --> Utf8 Class Initialized
INFO - 2020-09-11 07:19:25 --> URI Class Initialized
INFO - 2020-09-11 07:19:25 --> Router Class Initialized
INFO - 2020-09-11 07:19:25 --> Output Class Initialized
INFO - 2020-09-11 07:19:25 --> Security Class Initialized
DEBUG - 2020-09-11 07:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:19:25 --> Input Class Initialized
INFO - 2020-09-11 07:19:25 --> Language Class Initialized
INFO - 2020-09-11 07:19:25 --> Loader Class Initialized
INFO - 2020-09-11 07:19:25 --> Helper loaded: url_helper
INFO - 2020-09-11 07:19:25 --> Database Driver Class Initialized
INFO - 2020-09-11 07:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:19:25 --> Email Class Initialized
INFO - 2020-09-11 07:19:25 --> Controller Class Initialized
INFO - 2020-09-11 07:19:25 --> Model Class Initialized
INFO - 2020-09-11 07:19:25 --> Model Class Initialized
INFO - 2020-09-11 07:19:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:19:25 --> Total execution time: 0.0427
ERROR - 2020-09-11 07:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:19:46 --> Config Class Initialized
INFO - 2020-09-11 07:19:46 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:19:46 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:19:46 --> Utf8 Class Initialized
INFO - 2020-09-11 07:19:46 --> URI Class Initialized
INFO - 2020-09-11 07:19:46 --> Router Class Initialized
INFO - 2020-09-11 07:19:46 --> Output Class Initialized
INFO - 2020-09-11 07:19:46 --> Security Class Initialized
DEBUG - 2020-09-11 07:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:19:46 --> Input Class Initialized
INFO - 2020-09-11 07:19:46 --> Language Class Initialized
INFO - 2020-09-11 07:19:46 --> Loader Class Initialized
INFO - 2020-09-11 07:19:46 --> Helper loaded: url_helper
INFO - 2020-09-11 07:19:46 --> Database Driver Class Initialized
INFO - 2020-09-11 07:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:19:46 --> Email Class Initialized
INFO - 2020-09-11 07:19:46 --> Controller Class Initialized
INFO - 2020-09-11 07:19:46 --> Model Class Initialized
INFO - 2020-09-11 07:19:46 --> Model Class Initialized
INFO - 2020-09-11 07:19:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:19:46 --> Final output sent to browser
DEBUG - 2020-09-11 07:19:46 --> Total execution time: 0.1098
ERROR - 2020-09-11 07:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:19:47 --> Config Class Initialized
INFO - 2020-09-11 07:19:47 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:19:47 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:19:47 --> Utf8 Class Initialized
INFO - 2020-09-11 07:19:47 --> URI Class Initialized
INFO - 2020-09-11 07:19:47 --> Router Class Initialized
INFO - 2020-09-11 07:19:47 --> Output Class Initialized
INFO - 2020-09-11 07:19:47 --> Security Class Initialized
DEBUG - 2020-09-11 07:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:19:47 --> Input Class Initialized
INFO - 2020-09-11 07:19:47 --> Language Class Initialized
INFO - 2020-09-11 07:19:47 --> Loader Class Initialized
INFO - 2020-09-11 07:19:47 --> Helper loaded: url_helper
INFO - 2020-09-11 07:19:47 --> Database Driver Class Initialized
INFO - 2020-09-11 07:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:19:47 --> Email Class Initialized
INFO - 2020-09-11 07:19:47 --> Controller Class Initialized
INFO - 2020-09-11 07:19:47 --> Model Class Initialized
INFO - 2020-09-11 07:19:47 --> Model Class Initialized
INFO - 2020-09-11 07:19:47 --> Final output sent to browser
DEBUG - 2020-09-11 07:19:47 --> Total execution time: 0.0375
ERROR - 2020-09-11 07:23:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:23:00 --> Config Class Initialized
INFO - 2020-09-11 07:23:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:23:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:23:00 --> Utf8 Class Initialized
INFO - 2020-09-11 07:23:00 --> URI Class Initialized
INFO - 2020-09-11 07:23:00 --> Router Class Initialized
INFO - 2020-09-11 07:23:00 --> Output Class Initialized
INFO - 2020-09-11 07:23:00 --> Security Class Initialized
DEBUG - 2020-09-11 07:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:23:00 --> Input Class Initialized
INFO - 2020-09-11 07:23:00 --> Language Class Initialized
INFO - 2020-09-11 07:23:00 --> Loader Class Initialized
INFO - 2020-09-11 07:23:00 --> Helper loaded: url_helper
INFO - 2020-09-11 07:23:00 --> Database Driver Class Initialized
INFO - 2020-09-11 07:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:23:00 --> Email Class Initialized
INFO - 2020-09-11 07:23:00 --> Controller Class Initialized
INFO - 2020-09-11 07:23:00 --> Model Class Initialized
INFO - 2020-09-11 07:23:00 --> Model Class Initialized
INFO - 2020-09-11 07:23:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:23:00 --> Final output sent to browser
DEBUG - 2020-09-11 07:23:00 --> Total execution time: 0.0383
ERROR - 2020-09-11 07:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:23:01 --> Config Class Initialized
INFO - 2020-09-11 07:23:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:23:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:23:01 --> Utf8 Class Initialized
INFO - 2020-09-11 07:23:01 --> URI Class Initialized
INFO - 2020-09-11 07:23:01 --> Router Class Initialized
INFO - 2020-09-11 07:23:01 --> Output Class Initialized
INFO - 2020-09-11 07:23:01 --> Security Class Initialized
DEBUG - 2020-09-11 07:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:23:01 --> Input Class Initialized
INFO - 2020-09-11 07:23:01 --> Language Class Initialized
INFO - 2020-09-11 07:23:01 --> Loader Class Initialized
INFO - 2020-09-11 07:23:01 --> Helper loaded: url_helper
INFO - 2020-09-11 07:23:01 --> Database Driver Class Initialized
INFO - 2020-09-11 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:23:01 --> Email Class Initialized
INFO - 2020-09-11 07:23:01 --> Controller Class Initialized
INFO - 2020-09-11 07:23:01 --> Model Class Initialized
INFO - 2020-09-11 07:23:01 --> Model Class Initialized
INFO - 2020-09-11 07:23:01 --> Final output sent to browser
DEBUG - 2020-09-11 07:23:01 --> Total execution time: 0.0423
ERROR - 2020-09-11 07:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:23:48 --> Config Class Initialized
INFO - 2020-09-11 07:23:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:23:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:23:48 --> Utf8 Class Initialized
INFO - 2020-09-11 07:23:48 --> URI Class Initialized
INFO - 2020-09-11 07:23:48 --> Router Class Initialized
INFO - 2020-09-11 07:23:48 --> Output Class Initialized
INFO - 2020-09-11 07:23:48 --> Security Class Initialized
DEBUG - 2020-09-11 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:23:48 --> Input Class Initialized
INFO - 2020-09-11 07:23:48 --> Language Class Initialized
INFO - 2020-09-11 07:23:48 --> Loader Class Initialized
INFO - 2020-09-11 07:23:48 --> Helper loaded: url_helper
INFO - 2020-09-11 07:23:48 --> Database Driver Class Initialized
INFO - 2020-09-11 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:23:48 --> Email Class Initialized
INFO - 2020-09-11 07:23:48 --> Controller Class Initialized
INFO - 2020-09-11 07:23:48 --> Model Class Initialized
INFO - 2020-09-11 07:23:48 --> Model Class Initialized
INFO - 2020-09-11 07:23:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:23:48 --> Final output sent to browser
DEBUG - 2020-09-11 07:23:48 --> Total execution time: 0.0426
ERROR - 2020-09-11 07:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:23:48 --> Config Class Initialized
INFO - 2020-09-11 07:23:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:23:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:23:48 --> Utf8 Class Initialized
INFO - 2020-09-11 07:23:48 --> URI Class Initialized
INFO - 2020-09-11 07:23:48 --> Router Class Initialized
INFO - 2020-09-11 07:23:48 --> Output Class Initialized
INFO - 2020-09-11 07:23:48 --> Security Class Initialized
DEBUG - 2020-09-11 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:23:48 --> Input Class Initialized
INFO - 2020-09-11 07:23:48 --> Language Class Initialized
INFO - 2020-09-11 07:23:48 --> Loader Class Initialized
INFO - 2020-09-11 07:23:48 --> Helper loaded: url_helper
INFO - 2020-09-11 07:23:48 --> Database Driver Class Initialized
INFO - 2020-09-11 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:23:48 --> Email Class Initialized
INFO - 2020-09-11 07:23:48 --> Controller Class Initialized
INFO - 2020-09-11 07:23:48 --> Model Class Initialized
INFO - 2020-09-11 07:23:48 --> Model Class Initialized
INFO - 2020-09-11 07:23:48 --> Final output sent to browser
DEBUG - 2020-09-11 07:23:48 --> Total execution time: 0.0424
ERROR - 2020-09-11 07:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:24:00 --> Config Class Initialized
INFO - 2020-09-11 07:24:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:24:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:24:00 --> Utf8 Class Initialized
INFO - 2020-09-11 07:24:00 --> URI Class Initialized
INFO - 2020-09-11 07:24:00 --> Router Class Initialized
INFO - 2020-09-11 07:24:00 --> Output Class Initialized
INFO - 2020-09-11 07:24:00 --> Security Class Initialized
DEBUG - 2020-09-11 07:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:24:00 --> Input Class Initialized
INFO - 2020-09-11 07:24:00 --> Language Class Initialized
INFO - 2020-09-11 07:24:00 --> Loader Class Initialized
INFO - 2020-09-11 07:24:00 --> Helper loaded: url_helper
INFO - 2020-09-11 07:24:00 --> Database Driver Class Initialized
INFO - 2020-09-11 07:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:24:00 --> Email Class Initialized
INFO - 2020-09-11 07:24:00 --> Controller Class Initialized
INFO - 2020-09-11 07:24:00 --> Model Class Initialized
INFO - 2020-09-11 07:24:00 --> Model Class Initialized
INFO - 2020-09-11 07:24:00 --> Final output sent to browser
DEBUG - 2020-09-11 07:24:00 --> Total execution time: 0.1477
ERROR - 2020-09-11 07:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:24:01 --> Config Class Initialized
INFO - 2020-09-11 07:24:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:24:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:24:01 --> Utf8 Class Initialized
INFO - 2020-09-11 07:24:01 --> URI Class Initialized
INFO - 2020-09-11 07:24:01 --> Router Class Initialized
INFO - 2020-09-11 07:24:01 --> Output Class Initialized
INFO - 2020-09-11 07:24:01 --> Security Class Initialized
DEBUG - 2020-09-11 07:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:24:01 --> Input Class Initialized
INFO - 2020-09-11 07:24:01 --> Language Class Initialized
INFO - 2020-09-11 07:24:01 --> Loader Class Initialized
INFO - 2020-09-11 07:24:01 --> Helper loaded: url_helper
INFO - 2020-09-11 07:24:01 --> Database Driver Class Initialized
INFO - 2020-09-11 07:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:24:01 --> Email Class Initialized
INFO - 2020-09-11 07:24:01 --> Controller Class Initialized
INFO - 2020-09-11 07:24:01 --> Model Class Initialized
INFO - 2020-09-11 07:24:01 --> Model Class Initialized
INFO - 2020-09-11 07:24:01 --> Final output sent to browser
DEBUG - 2020-09-11 07:24:01 --> Total execution time: 0.0461
ERROR - 2020-09-11 07:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:24:56 --> Config Class Initialized
INFO - 2020-09-11 07:24:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:24:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:24:56 --> Utf8 Class Initialized
INFO - 2020-09-11 07:24:56 --> URI Class Initialized
INFO - 2020-09-11 07:24:56 --> Router Class Initialized
INFO - 2020-09-11 07:24:56 --> Output Class Initialized
INFO - 2020-09-11 07:24:56 --> Security Class Initialized
DEBUG - 2020-09-11 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:24:56 --> Input Class Initialized
INFO - 2020-09-11 07:24:56 --> Language Class Initialized
INFO - 2020-09-11 07:24:56 --> Loader Class Initialized
INFO - 2020-09-11 07:24:56 --> Helper loaded: url_helper
INFO - 2020-09-11 07:24:56 --> Database Driver Class Initialized
INFO - 2020-09-11 07:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:24:56 --> Email Class Initialized
INFO - 2020-09-11 07:24:56 --> Controller Class Initialized
INFO - 2020-09-11 07:24:56 --> Model Class Initialized
INFO - 2020-09-11 07:24:56 --> Model Class Initialized
INFO - 2020-09-11 07:24:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:24:56 --> Final output sent to browser
DEBUG - 2020-09-11 07:24:56 --> Total execution time: 0.0374
ERROR - 2020-09-11 07:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:24:57 --> Config Class Initialized
INFO - 2020-09-11 07:24:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:24:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:24:57 --> Utf8 Class Initialized
INFO - 2020-09-11 07:24:57 --> URI Class Initialized
INFO - 2020-09-11 07:24:57 --> Router Class Initialized
INFO - 2020-09-11 07:24:57 --> Output Class Initialized
INFO - 2020-09-11 07:24:57 --> Security Class Initialized
DEBUG - 2020-09-11 07:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:24:57 --> Input Class Initialized
INFO - 2020-09-11 07:24:57 --> Language Class Initialized
INFO - 2020-09-11 07:24:57 --> Loader Class Initialized
INFO - 2020-09-11 07:24:57 --> Helper loaded: url_helper
INFO - 2020-09-11 07:24:57 --> Database Driver Class Initialized
INFO - 2020-09-11 07:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:24:57 --> Email Class Initialized
INFO - 2020-09-11 07:24:57 --> Controller Class Initialized
INFO - 2020-09-11 07:24:57 --> Model Class Initialized
INFO - 2020-09-11 07:24:57 --> Model Class Initialized
INFO - 2020-09-11 07:24:57 --> Final output sent to browser
DEBUG - 2020-09-11 07:24:57 --> Total execution time: 0.0395
ERROR - 2020-09-11 07:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:25:14 --> Config Class Initialized
INFO - 2020-09-11 07:25:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:25:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:25:14 --> Utf8 Class Initialized
INFO - 2020-09-11 07:25:14 --> URI Class Initialized
INFO - 2020-09-11 07:25:14 --> Router Class Initialized
INFO - 2020-09-11 07:25:14 --> Output Class Initialized
INFO - 2020-09-11 07:25:14 --> Security Class Initialized
DEBUG - 2020-09-11 07:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:25:14 --> Input Class Initialized
INFO - 2020-09-11 07:25:14 --> Language Class Initialized
INFO - 2020-09-11 07:25:14 --> Loader Class Initialized
INFO - 2020-09-11 07:25:14 --> Helper loaded: url_helper
INFO - 2020-09-11 07:25:14 --> Database Driver Class Initialized
INFO - 2020-09-11 07:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:25:14 --> Email Class Initialized
INFO - 2020-09-11 07:25:14 --> Controller Class Initialized
INFO - 2020-09-11 07:25:14 --> Model Class Initialized
INFO - 2020-09-11 07:25:14 --> Model Class Initialized
INFO - 2020-09-11 07:25:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:25:14 --> Final output sent to browser
DEBUG - 2020-09-11 07:25:14 --> Total execution time: 0.0357
ERROR - 2020-09-11 07:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:25:15 --> Config Class Initialized
INFO - 2020-09-11 07:25:15 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:25:15 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:25:15 --> Utf8 Class Initialized
INFO - 2020-09-11 07:25:15 --> URI Class Initialized
INFO - 2020-09-11 07:25:15 --> Router Class Initialized
INFO - 2020-09-11 07:25:15 --> Output Class Initialized
INFO - 2020-09-11 07:25:15 --> Security Class Initialized
DEBUG - 2020-09-11 07:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:25:15 --> Input Class Initialized
INFO - 2020-09-11 07:25:15 --> Language Class Initialized
INFO - 2020-09-11 07:25:15 --> Loader Class Initialized
INFO - 2020-09-11 07:25:15 --> Helper loaded: url_helper
INFO - 2020-09-11 07:25:15 --> Database Driver Class Initialized
INFO - 2020-09-11 07:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:25:15 --> Email Class Initialized
INFO - 2020-09-11 07:25:15 --> Controller Class Initialized
INFO - 2020-09-11 07:25:15 --> Model Class Initialized
INFO - 2020-09-11 07:25:15 --> Model Class Initialized
INFO - 2020-09-11 07:25:15 --> Final output sent to browser
DEBUG - 2020-09-11 07:25:15 --> Total execution time: 0.0382
ERROR - 2020-09-11 07:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:25:24 --> Config Class Initialized
INFO - 2020-09-11 07:25:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:25:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:25:24 --> Utf8 Class Initialized
INFO - 2020-09-11 07:25:24 --> URI Class Initialized
INFO - 2020-09-11 07:25:24 --> Router Class Initialized
INFO - 2020-09-11 07:25:24 --> Output Class Initialized
INFO - 2020-09-11 07:25:24 --> Security Class Initialized
DEBUG - 2020-09-11 07:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:25:24 --> Input Class Initialized
INFO - 2020-09-11 07:25:24 --> Language Class Initialized
INFO - 2020-09-11 07:25:24 --> Loader Class Initialized
INFO - 2020-09-11 07:25:24 --> Helper loaded: url_helper
INFO - 2020-09-11 07:25:24 --> Database Driver Class Initialized
INFO - 2020-09-11 07:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:25:24 --> Email Class Initialized
INFO - 2020-09-11 07:25:24 --> Controller Class Initialized
INFO - 2020-09-11 07:25:24 --> Model Class Initialized
INFO - 2020-09-11 07:25:24 --> Model Class Initialized
INFO - 2020-09-11 07:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:25:24 --> Final output sent to browser
DEBUG - 2020-09-11 07:25:24 --> Total execution time: 0.1087
ERROR - 2020-09-11 07:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:25:25 --> Config Class Initialized
INFO - 2020-09-11 07:25:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:25:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:25:25 --> Utf8 Class Initialized
INFO - 2020-09-11 07:25:25 --> URI Class Initialized
INFO - 2020-09-11 07:25:25 --> Router Class Initialized
INFO - 2020-09-11 07:25:25 --> Output Class Initialized
INFO - 2020-09-11 07:25:25 --> Security Class Initialized
DEBUG - 2020-09-11 07:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:25:25 --> Input Class Initialized
INFO - 2020-09-11 07:25:25 --> Language Class Initialized
INFO - 2020-09-11 07:25:25 --> Loader Class Initialized
INFO - 2020-09-11 07:25:25 --> Helper loaded: url_helper
INFO - 2020-09-11 07:25:25 --> Database Driver Class Initialized
INFO - 2020-09-11 07:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:25:25 --> Email Class Initialized
INFO - 2020-09-11 07:25:25 --> Controller Class Initialized
INFO - 2020-09-11 07:25:25 --> Model Class Initialized
INFO - 2020-09-11 07:25:25 --> Model Class Initialized
INFO - 2020-09-11 07:25:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:25:25 --> Total execution time: 0.0491
ERROR - 2020-09-11 07:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:26:25 --> Config Class Initialized
INFO - 2020-09-11 07:26:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:26:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:26:25 --> Utf8 Class Initialized
INFO - 2020-09-11 07:26:25 --> URI Class Initialized
INFO - 2020-09-11 07:26:25 --> Router Class Initialized
INFO - 2020-09-11 07:26:25 --> Output Class Initialized
INFO - 2020-09-11 07:26:25 --> Security Class Initialized
DEBUG - 2020-09-11 07:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:26:25 --> Input Class Initialized
INFO - 2020-09-11 07:26:25 --> Language Class Initialized
INFO - 2020-09-11 07:26:25 --> Loader Class Initialized
INFO - 2020-09-11 07:26:25 --> Helper loaded: url_helper
INFO - 2020-09-11 07:26:25 --> Database Driver Class Initialized
INFO - 2020-09-11 07:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:26:25 --> Email Class Initialized
INFO - 2020-09-11 07:26:25 --> Controller Class Initialized
INFO - 2020-09-11 07:26:25 --> Model Class Initialized
INFO - 2020-09-11 07:26:25 --> Model Class Initialized
INFO - 2020-09-11 07:26:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:26:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:26:25 --> Total execution time: 0.0453
ERROR - 2020-09-11 07:26:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:26:25 --> Config Class Initialized
INFO - 2020-09-11 07:26:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:26:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:26:25 --> Utf8 Class Initialized
INFO - 2020-09-11 07:26:25 --> URI Class Initialized
INFO - 2020-09-11 07:26:25 --> Router Class Initialized
INFO - 2020-09-11 07:26:25 --> Output Class Initialized
INFO - 2020-09-11 07:26:25 --> Security Class Initialized
DEBUG - 2020-09-11 07:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:26:25 --> Input Class Initialized
INFO - 2020-09-11 07:26:25 --> Language Class Initialized
INFO - 2020-09-11 07:26:25 --> Loader Class Initialized
INFO - 2020-09-11 07:26:25 --> Helper loaded: url_helper
INFO - 2020-09-11 07:26:25 --> Database Driver Class Initialized
INFO - 2020-09-11 07:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:26:25 --> Email Class Initialized
INFO - 2020-09-11 07:26:25 --> Controller Class Initialized
INFO - 2020-09-11 07:26:25 --> Model Class Initialized
INFO - 2020-09-11 07:26:25 --> Model Class Initialized
INFO - 2020-09-11 07:26:25 --> Final output sent to browser
DEBUG - 2020-09-11 07:26:25 --> Total execution time: 0.0408
ERROR - 2020-09-11 07:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:28:05 --> Config Class Initialized
INFO - 2020-09-11 07:28:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:28:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:28:05 --> Utf8 Class Initialized
INFO - 2020-09-11 07:28:05 --> URI Class Initialized
INFO - 2020-09-11 07:28:05 --> Router Class Initialized
INFO - 2020-09-11 07:28:05 --> Output Class Initialized
INFO - 2020-09-11 07:28:05 --> Security Class Initialized
DEBUG - 2020-09-11 07:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:28:05 --> Input Class Initialized
INFO - 2020-09-11 07:28:05 --> Language Class Initialized
INFO - 2020-09-11 07:28:05 --> Loader Class Initialized
INFO - 2020-09-11 07:28:05 --> Helper loaded: url_helper
INFO - 2020-09-11 07:28:05 --> Database Driver Class Initialized
INFO - 2020-09-11 07:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:28:05 --> Email Class Initialized
INFO - 2020-09-11 07:28:05 --> Controller Class Initialized
DEBUG - 2020-09-11 07:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 07:28:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 07:28:05 --> Model Class Initialized
INFO - 2020-09-11 07:28:05 --> Model Class Initialized
INFO - 2020-09-11 07:28:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 07:28:05 --> Final output sent to browser
DEBUG - 2020-09-11 07:28:05 --> Total execution time: 0.0649
ERROR - 2020-09-11 07:34:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:34:36 --> Config Class Initialized
INFO - 2020-09-11 07:34:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:34:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:34:36 --> Utf8 Class Initialized
INFO - 2020-09-11 07:34:36 --> URI Class Initialized
INFO - 2020-09-11 07:34:36 --> Router Class Initialized
INFO - 2020-09-11 07:34:36 --> Output Class Initialized
INFO - 2020-09-11 07:34:36 --> Security Class Initialized
DEBUG - 2020-09-11 07:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:34:36 --> Input Class Initialized
INFO - 2020-09-11 07:34:36 --> Language Class Initialized
INFO - 2020-09-11 07:34:36 --> Loader Class Initialized
INFO - 2020-09-11 07:34:36 --> Helper loaded: url_helper
INFO - 2020-09-11 07:34:36 --> Database Driver Class Initialized
INFO - 2020-09-11 07:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:34:36 --> Email Class Initialized
INFO - 2020-09-11 07:34:36 --> Controller Class Initialized
DEBUG - 2020-09-11 07:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 07:34:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 07:34:36 --> Model Class Initialized
INFO - 2020-09-11 07:34:36 --> Model Class Initialized
INFO - 2020-09-11 07:34:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 07:34:36 --> Final output sent to browser
DEBUG - 2020-09-11 07:34:36 --> Total execution time: 0.0223
ERROR - 2020-09-11 07:34:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:34:56 --> Config Class Initialized
INFO - 2020-09-11 07:34:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:34:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:34:56 --> Utf8 Class Initialized
INFO - 2020-09-11 07:34:56 --> URI Class Initialized
INFO - 2020-09-11 07:34:56 --> Router Class Initialized
INFO - 2020-09-11 07:34:56 --> Output Class Initialized
INFO - 2020-09-11 07:34:56 --> Security Class Initialized
DEBUG - 2020-09-11 07:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:34:56 --> Input Class Initialized
INFO - 2020-09-11 07:34:56 --> Language Class Initialized
INFO - 2020-09-11 07:34:56 --> Loader Class Initialized
INFO - 2020-09-11 07:34:56 --> Helper loaded: url_helper
INFO - 2020-09-11 07:34:56 --> Database Driver Class Initialized
INFO - 2020-09-11 07:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:34:56 --> Email Class Initialized
INFO - 2020-09-11 07:34:56 --> Controller Class Initialized
DEBUG - 2020-09-11 07:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 07:34:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 07:34:56 --> Model Class Initialized
INFO - 2020-09-11 07:34:56 --> Model Class Initialized
INFO - 2020-09-11 07:34:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 07:34:56 --> Final output sent to browser
DEBUG - 2020-09-11 07:34:56 --> Total execution time: 0.0234
ERROR - 2020-09-11 07:36:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:36:06 --> Config Class Initialized
INFO - 2020-09-11 07:36:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:36:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:36:06 --> Utf8 Class Initialized
INFO - 2020-09-11 07:36:06 --> URI Class Initialized
INFO - 2020-09-11 07:36:06 --> Router Class Initialized
INFO - 2020-09-11 07:36:06 --> Output Class Initialized
INFO - 2020-09-11 07:36:06 --> Security Class Initialized
DEBUG - 2020-09-11 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:36:06 --> Input Class Initialized
INFO - 2020-09-11 07:36:06 --> Language Class Initialized
INFO - 2020-09-11 07:36:06 --> Loader Class Initialized
INFO - 2020-09-11 07:36:06 --> Helper loaded: url_helper
INFO - 2020-09-11 07:36:06 --> Database Driver Class Initialized
INFO - 2020-09-11 07:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:36:06 --> Email Class Initialized
INFO - 2020-09-11 07:36:06 --> Controller Class Initialized
INFO - 2020-09-11 07:36:06 --> Model Class Initialized
INFO - 2020-09-11 07:36:06 --> Model Class Initialized
INFO - 2020-09-11 07:36:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:36:06 --> Final output sent to browser
DEBUG - 2020-09-11 07:36:06 --> Total execution time: 0.0431
ERROR - 2020-09-11 07:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:36:07 --> Config Class Initialized
INFO - 2020-09-11 07:36:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:36:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:36:07 --> Utf8 Class Initialized
INFO - 2020-09-11 07:36:07 --> URI Class Initialized
INFO - 2020-09-11 07:36:07 --> Router Class Initialized
INFO - 2020-09-11 07:36:07 --> Output Class Initialized
INFO - 2020-09-11 07:36:07 --> Security Class Initialized
DEBUG - 2020-09-11 07:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:36:07 --> Input Class Initialized
INFO - 2020-09-11 07:36:07 --> Language Class Initialized
INFO - 2020-09-11 07:36:07 --> Loader Class Initialized
INFO - 2020-09-11 07:36:07 --> Helper loaded: url_helper
INFO - 2020-09-11 07:36:07 --> Database Driver Class Initialized
INFO - 2020-09-11 07:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:36:07 --> Email Class Initialized
INFO - 2020-09-11 07:36:07 --> Controller Class Initialized
INFO - 2020-09-11 07:36:07 --> Model Class Initialized
INFO - 2020-09-11 07:36:07 --> Model Class Initialized
INFO - 2020-09-11 07:36:07 --> Final output sent to browser
DEBUG - 2020-09-11 07:36:07 --> Total execution time: 0.0366
ERROR - 2020-09-11 07:42:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:42:50 --> Config Class Initialized
INFO - 2020-09-11 07:42:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:42:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:42:50 --> Utf8 Class Initialized
INFO - 2020-09-11 07:42:50 --> URI Class Initialized
INFO - 2020-09-11 07:42:50 --> Router Class Initialized
INFO - 2020-09-11 07:42:50 --> Output Class Initialized
INFO - 2020-09-11 07:42:50 --> Security Class Initialized
DEBUG - 2020-09-11 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:42:50 --> Input Class Initialized
INFO - 2020-09-11 07:42:50 --> Language Class Initialized
INFO - 2020-09-11 07:42:50 --> Loader Class Initialized
INFO - 2020-09-11 07:42:50 --> Helper loaded: url_helper
INFO - 2020-09-11 07:42:50 --> Database Driver Class Initialized
INFO - 2020-09-11 07:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:42:50 --> Email Class Initialized
INFO - 2020-09-11 07:42:50 --> Controller Class Initialized
INFO - 2020-09-11 07:42:50 --> Model Class Initialized
INFO - 2020-09-11 07:42:50 --> Model Class Initialized
INFO - 2020-09-11 07:42:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:42:50 --> Final output sent to browser
DEBUG - 2020-09-11 07:42:50 --> Total execution time: 0.0363
ERROR - 2020-09-11 07:42:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:42:51 --> Config Class Initialized
INFO - 2020-09-11 07:42:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:42:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:42:51 --> Utf8 Class Initialized
INFO - 2020-09-11 07:42:51 --> URI Class Initialized
INFO - 2020-09-11 07:42:51 --> Router Class Initialized
INFO - 2020-09-11 07:42:51 --> Output Class Initialized
INFO - 2020-09-11 07:42:51 --> Security Class Initialized
DEBUG - 2020-09-11 07:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:42:51 --> Input Class Initialized
INFO - 2020-09-11 07:42:51 --> Language Class Initialized
INFO - 2020-09-11 07:42:51 --> Loader Class Initialized
INFO - 2020-09-11 07:42:51 --> Helper loaded: url_helper
INFO - 2020-09-11 07:42:51 --> Database Driver Class Initialized
INFO - 2020-09-11 07:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:42:51 --> Email Class Initialized
INFO - 2020-09-11 07:42:51 --> Controller Class Initialized
INFO - 2020-09-11 07:42:51 --> Model Class Initialized
INFO - 2020-09-11 07:42:51 --> Model Class Initialized
INFO - 2020-09-11 07:42:51 --> Final output sent to browser
DEBUG - 2020-09-11 07:42:51 --> Total execution time: 0.0436
ERROR - 2020-09-11 07:45:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:45:35 --> Config Class Initialized
INFO - 2020-09-11 07:45:35 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:45:35 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:45:35 --> Utf8 Class Initialized
INFO - 2020-09-11 07:45:35 --> URI Class Initialized
INFO - 2020-09-11 07:45:35 --> Router Class Initialized
INFO - 2020-09-11 07:45:35 --> Output Class Initialized
INFO - 2020-09-11 07:45:35 --> Security Class Initialized
DEBUG - 2020-09-11 07:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:45:35 --> Input Class Initialized
INFO - 2020-09-11 07:45:35 --> Language Class Initialized
INFO - 2020-09-11 07:45:35 --> Loader Class Initialized
INFO - 2020-09-11 07:45:35 --> Helper loaded: url_helper
INFO - 2020-09-11 07:45:35 --> Database Driver Class Initialized
INFO - 2020-09-11 07:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:45:35 --> Email Class Initialized
INFO - 2020-09-11 07:45:35 --> Controller Class Initialized
INFO - 2020-09-11 07:45:35 --> Model Class Initialized
INFO - 2020-09-11 07:45:35 --> Model Class Initialized
INFO - 2020-09-11 07:45:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:45:35 --> Final output sent to browser
DEBUG - 2020-09-11 07:45:35 --> Total execution time: 0.0348
ERROR - 2020-09-11 07:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:45:36 --> Config Class Initialized
INFO - 2020-09-11 07:45:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:45:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:45:36 --> Utf8 Class Initialized
INFO - 2020-09-11 07:45:36 --> URI Class Initialized
INFO - 2020-09-11 07:45:36 --> Router Class Initialized
INFO - 2020-09-11 07:45:36 --> Output Class Initialized
INFO - 2020-09-11 07:45:36 --> Security Class Initialized
DEBUG - 2020-09-11 07:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:45:36 --> Input Class Initialized
INFO - 2020-09-11 07:45:36 --> Language Class Initialized
INFO - 2020-09-11 07:45:36 --> Loader Class Initialized
INFO - 2020-09-11 07:45:36 --> Helper loaded: url_helper
INFO - 2020-09-11 07:45:36 --> Database Driver Class Initialized
INFO - 2020-09-11 07:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:45:36 --> Email Class Initialized
INFO - 2020-09-11 07:45:36 --> Controller Class Initialized
INFO - 2020-09-11 07:45:36 --> Model Class Initialized
INFO - 2020-09-11 07:45:36 --> Model Class Initialized
INFO - 2020-09-11 07:45:36 --> Final output sent to browser
DEBUG - 2020-09-11 07:45:36 --> Total execution time: 0.0372
ERROR - 2020-09-11 07:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:46:19 --> Config Class Initialized
INFO - 2020-09-11 07:46:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:46:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:46:19 --> Utf8 Class Initialized
INFO - 2020-09-11 07:46:19 --> URI Class Initialized
INFO - 2020-09-11 07:46:19 --> Router Class Initialized
INFO - 2020-09-11 07:46:19 --> Output Class Initialized
INFO - 2020-09-11 07:46:19 --> Security Class Initialized
DEBUG - 2020-09-11 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:46:19 --> Input Class Initialized
INFO - 2020-09-11 07:46:19 --> Language Class Initialized
INFO - 2020-09-11 07:46:19 --> Loader Class Initialized
INFO - 2020-09-11 07:46:19 --> Helper loaded: url_helper
INFO - 2020-09-11 07:46:19 --> Database Driver Class Initialized
INFO - 2020-09-11 07:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:46:19 --> Email Class Initialized
INFO - 2020-09-11 07:46:19 --> Controller Class Initialized
INFO - 2020-09-11 07:46:19 --> Model Class Initialized
INFO - 2020-09-11 07:46:19 --> Model Class Initialized
INFO - 2020-09-11 07:46:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:46:19 --> Final output sent to browser
DEBUG - 2020-09-11 07:46:19 --> Total execution time: 0.0441
ERROR - 2020-09-11 07:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:46:20 --> Config Class Initialized
INFO - 2020-09-11 07:46:20 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:46:20 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:46:20 --> Utf8 Class Initialized
INFO - 2020-09-11 07:46:20 --> URI Class Initialized
INFO - 2020-09-11 07:46:20 --> Router Class Initialized
INFO - 2020-09-11 07:46:20 --> Output Class Initialized
INFO - 2020-09-11 07:46:20 --> Security Class Initialized
DEBUG - 2020-09-11 07:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:46:20 --> Input Class Initialized
INFO - 2020-09-11 07:46:20 --> Language Class Initialized
INFO - 2020-09-11 07:46:20 --> Loader Class Initialized
INFO - 2020-09-11 07:46:20 --> Helper loaded: url_helper
INFO - 2020-09-11 07:46:20 --> Database Driver Class Initialized
INFO - 2020-09-11 07:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:46:20 --> Email Class Initialized
INFO - 2020-09-11 07:46:20 --> Controller Class Initialized
INFO - 2020-09-11 07:46:20 --> Model Class Initialized
INFO - 2020-09-11 07:46:20 --> Model Class Initialized
INFO - 2020-09-11 07:46:20 --> Final output sent to browser
DEBUG - 2020-09-11 07:46:20 --> Total execution time: 0.0429
ERROR - 2020-09-11 07:51:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:51:12 --> Config Class Initialized
INFO - 2020-09-11 07:51:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:51:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:51:12 --> Utf8 Class Initialized
INFO - 2020-09-11 07:51:12 --> URI Class Initialized
INFO - 2020-09-11 07:51:12 --> Router Class Initialized
INFO - 2020-09-11 07:51:12 --> Output Class Initialized
INFO - 2020-09-11 07:51:12 --> Security Class Initialized
DEBUG - 2020-09-11 07:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:51:12 --> Input Class Initialized
INFO - 2020-09-11 07:51:12 --> Language Class Initialized
INFO - 2020-09-11 07:51:12 --> Loader Class Initialized
INFO - 2020-09-11 07:51:12 --> Helper loaded: url_helper
INFO - 2020-09-11 07:51:12 --> Database Driver Class Initialized
INFO - 2020-09-11 07:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:51:12 --> Email Class Initialized
INFO - 2020-09-11 07:51:12 --> Controller Class Initialized
INFO - 2020-09-11 07:51:12 --> Model Class Initialized
INFO - 2020-09-11 07:51:12 --> Model Class Initialized
INFO - 2020-09-11 07:51:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:51:12 --> Final output sent to browser
DEBUG - 2020-09-11 07:51:12 --> Total execution time: 0.0390
ERROR - 2020-09-11 07:51:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:51:12 --> Config Class Initialized
INFO - 2020-09-11 07:51:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:51:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:51:12 --> Utf8 Class Initialized
INFO - 2020-09-11 07:51:12 --> URI Class Initialized
INFO - 2020-09-11 07:51:12 --> Router Class Initialized
INFO - 2020-09-11 07:51:12 --> Output Class Initialized
INFO - 2020-09-11 07:51:12 --> Security Class Initialized
DEBUG - 2020-09-11 07:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:51:12 --> Input Class Initialized
INFO - 2020-09-11 07:51:12 --> Language Class Initialized
INFO - 2020-09-11 07:51:12 --> Loader Class Initialized
INFO - 2020-09-11 07:51:12 --> Helper loaded: url_helper
INFO - 2020-09-11 07:51:12 --> Database Driver Class Initialized
INFO - 2020-09-11 07:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:51:12 --> Email Class Initialized
INFO - 2020-09-11 07:51:12 --> Controller Class Initialized
INFO - 2020-09-11 07:51:12 --> Model Class Initialized
INFO - 2020-09-11 07:51:12 --> Model Class Initialized
INFO - 2020-09-11 07:51:12 --> Final output sent to browser
DEBUG - 2020-09-11 07:51:12 --> Total execution time: 0.0381
ERROR - 2020-09-11 07:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:51:33 --> Config Class Initialized
INFO - 2020-09-11 07:51:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:51:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:51:33 --> Utf8 Class Initialized
INFO - 2020-09-11 07:51:33 --> URI Class Initialized
INFO - 2020-09-11 07:51:33 --> Router Class Initialized
INFO - 2020-09-11 07:51:33 --> Output Class Initialized
INFO - 2020-09-11 07:51:33 --> Security Class Initialized
DEBUG - 2020-09-11 07:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:51:33 --> Input Class Initialized
INFO - 2020-09-11 07:51:33 --> Language Class Initialized
INFO - 2020-09-11 07:51:33 --> Loader Class Initialized
INFO - 2020-09-11 07:51:33 --> Helper loaded: url_helper
INFO - 2020-09-11 07:51:33 --> Database Driver Class Initialized
INFO - 2020-09-11 07:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:51:33 --> Email Class Initialized
INFO - 2020-09-11 07:51:33 --> Controller Class Initialized
INFO - 2020-09-11 07:51:33 --> Model Class Initialized
INFO - 2020-09-11 07:51:33 --> Model Class Initialized
INFO - 2020-09-11 07:51:33 --> Final output sent to browser
DEBUG - 2020-09-11 07:51:33 --> Total execution time: 0.1314
ERROR - 2020-09-11 07:51:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:51:34 --> Config Class Initialized
INFO - 2020-09-11 07:51:34 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:51:34 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:51:34 --> Utf8 Class Initialized
INFO - 2020-09-11 07:51:34 --> URI Class Initialized
INFO - 2020-09-11 07:51:34 --> Router Class Initialized
INFO - 2020-09-11 07:51:34 --> Output Class Initialized
INFO - 2020-09-11 07:51:34 --> Security Class Initialized
DEBUG - 2020-09-11 07:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:51:34 --> Input Class Initialized
INFO - 2020-09-11 07:51:34 --> Language Class Initialized
INFO - 2020-09-11 07:51:34 --> Loader Class Initialized
INFO - 2020-09-11 07:51:34 --> Helper loaded: url_helper
INFO - 2020-09-11 07:51:34 --> Database Driver Class Initialized
INFO - 2020-09-11 07:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:51:34 --> Email Class Initialized
INFO - 2020-09-11 07:51:34 --> Controller Class Initialized
INFO - 2020-09-11 07:51:34 --> Model Class Initialized
INFO - 2020-09-11 07:51:34 --> Model Class Initialized
INFO - 2020-09-11 07:51:34 --> Final output sent to browser
DEBUG - 2020-09-11 07:51:34 --> Total execution time: 0.0457
ERROR - 2020-09-11 07:52:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:52:50 --> Config Class Initialized
INFO - 2020-09-11 07:52:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:52:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:52:50 --> Utf8 Class Initialized
INFO - 2020-09-11 07:52:50 --> URI Class Initialized
INFO - 2020-09-11 07:52:50 --> Router Class Initialized
INFO - 2020-09-11 07:52:50 --> Output Class Initialized
INFO - 2020-09-11 07:52:50 --> Security Class Initialized
DEBUG - 2020-09-11 07:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:52:50 --> Input Class Initialized
INFO - 2020-09-11 07:52:50 --> Language Class Initialized
INFO - 2020-09-11 07:52:50 --> Loader Class Initialized
INFO - 2020-09-11 07:52:50 --> Helper loaded: url_helper
INFO - 2020-09-11 07:52:50 --> Database Driver Class Initialized
INFO - 2020-09-11 07:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:52:50 --> Email Class Initialized
INFO - 2020-09-11 07:52:50 --> Controller Class Initialized
INFO - 2020-09-11 07:52:50 --> Model Class Initialized
INFO - 2020-09-11 07:52:50 --> Model Class Initialized
INFO - 2020-09-11 07:52:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:52:50 --> Final output sent to browser
DEBUG - 2020-09-11 07:52:50 --> Total execution time: 0.0379
ERROR - 2020-09-11 07:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:52:52 --> Config Class Initialized
INFO - 2020-09-11 07:52:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:52:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:52:52 --> Utf8 Class Initialized
INFO - 2020-09-11 07:52:52 --> URI Class Initialized
INFO - 2020-09-11 07:52:52 --> Router Class Initialized
INFO - 2020-09-11 07:52:52 --> Output Class Initialized
INFO - 2020-09-11 07:52:52 --> Security Class Initialized
DEBUG - 2020-09-11 07:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:52:52 --> Input Class Initialized
INFO - 2020-09-11 07:52:52 --> Language Class Initialized
INFO - 2020-09-11 07:52:52 --> Loader Class Initialized
INFO - 2020-09-11 07:52:52 --> Helper loaded: url_helper
INFO - 2020-09-11 07:52:52 --> Database Driver Class Initialized
INFO - 2020-09-11 07:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:52:52 --> Email Class Initialized
INFO - 2020-09-11 07:52:52 --> Controller Class Initialized
INFO - 2020-09-11 07:52:52 --> Model Class Initialized
INFO - 2020-09-11 07:52:52 --> Model Class Initialized
INFO - 2020-09-11 07:52:52 --> Final output sent to browser
DEBUG - 2020-09-11 07:52:52 --> Total execution time: 0.0417
ERROR - 2020-09-11 07:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:54:13 --> Config Class Initialized
INFO - 2020-09-11 07:54:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:54:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:54:13 --> Utf8 Class Initialized
INFO - 2020-09-11 07:54:13 --> URI Class Initialized
INFO - 2020-09-11 07:54:13 --> Router Class Initialized
INFO - 2020-09-11 07:54:13 --> Output Class Initialized
INFO - 2020-09-11 07:54:13 --> Security Class Initialized
DEBUG - 2020-09-11 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:54:13 --> Input Class Initialized
INFO - 2020-09-11 07:54:13 --> Language Class Initialized
INFO - 2020-09-11 07:54:13 --> Loader Class Initialized
INFO - 2020-09-11 07:54:13 --> Helper loaded: url_helper
INFO - 2020-09-11 07:54:13 --> Database Driver Class Initialized
INFO - 2020-09-11 07:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:54:13 --> Email Class Initialized
INFO - 2020-09-11 07:54:13 --> Controller Class Initialized
INFO - 2020-09-11 07:54:13 --> Model Class Initialized
INFO - 2020-09-11 07:54:13 --> Model Class Initialized
INFO - 2020-09-11 07:54:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:54:13 --> Final output sent to browser
DEBUG - 2020-09-11 07:54:13 --> Total execution time: 0.0368
ERROR - 2020-09-11 07:54:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:54:13 --> Config Class Initialized
INFO - 2020-09-11 07:54:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:54:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:54:13 --> Utf8 Class Initialized
INFO - 2020-09-11 07:54:13 --> URI Class Initialized
INFO - 2020-09-11 07:54:13 --> Router Class Initialized
INFO - 2020-09-11 07:54:13 --> Output Class Initialized
INFO - 2020-09-11 07:54:13 --> Security Class Initialized
DEBUG - 2020-09-11 07:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:54:13 --> Input Class Initialized
INFO - 2020-09-11 07:54:13 --> Language Class Initialized
INFO - 2020-09-11 07:54:13 --> Loader Class Initialized
INFO - 2020-09-11 07:54:13 --> Helper loaded: url_helper
INFO - 2020-09-11 07:54:13 --> Database Driver Class Initialized
INFO - 2020-09-11 07:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:54:13 --> Email Class Initialized
INFO - 2020-09-11 07:54:13 --> Controller Class Initialized
INFO - 2020-09-11 07:54:13 --> Model Class Initialized
INFO - 2020-09-11 07:54:13 --> Model Class Initialized
INFO - 2020-09-11 07:54:13 --> Final output sent to browser
DEBUG - 2020-09-11 07:54:13 --> Total execution time: 0.0390
ERROR - 2020-09-11 07:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:55:16 --> Config Class Initialized
INFO - 2020-09-11 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:55:16 --> Utf8 Class Initialized
INFO - 2020-09-11 07:55:16 --> URI Class Initialized
INFO - 2020-09-11 07:55:16 --> Router Class Initialized
INFO - 2020-09-11 07:55:16 --> Output Class Initialized
INFO - 2020-09-11 07:55:16 --> Security Class Initialized
DEBUG - 2020-09-11 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:55:16 --> Input Class Initialized
INFO - 2020-09-11 07:55:16 --> Language Class Initialized
INFO - 2020-09-11 07:55:16 --> Loader Class Initialized
INFO - 2020-09-11 07:55:16 --> Helper loaded: url_helper
INFO - 2020-09-11 07:55:16 --> Database Driver Class Initialized
INFO - 2020-09-11 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:55:16 --> Email Class Initialized
INFO - 2020-09-11 07:55:16 --> Controller Class Initialized
INFO - 2020-09-11 07:55:16 --> Model Class Initialized
INFO - 2020-09-11 07:55:16 --> Model Class Initialized
INFO - 2020-09-11 07:55:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:55:16 --> Final output sent to browser
DEBUG - 2020-09-11 07:55:16 --> Total execution time: 0.0387
ERROR - 2020-09-11 07:55:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:55:16 --> Config Class Initialized
INFO - 2020-09-11 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:55:16 --> Utf8 Class Initialized
INFO - 2020-09-11 07:55:16 --> URI Class Initialized
INFO - 2020-09-11 07:55:16 --> Router Class Initialized
INFO - 2020-09-11 07:55:16 --> Output Class Initialized
INFO - 2020-09-11 07:55:16 --> Security Class Initialized
DEBUG - 2020-09-11 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:55:16 --> Input Class Initialized
INFO - 2020-09-11 07:55:16 --> Language Class Initialized
INFO - 2020-09-11 07:55:16 --> Loader Class Initialized
INFO - 2020-09-11 07:55:16 --> Helper loaded: url_helper
INFO - 2020-09-11 07:55:16 --> Database Driver Class Initialized
INFO - 2020-09-11 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:55:16 --> Email Class Initialized
INFO - 2020-09-11 07:55:16 --> Controller Class Initialized
INFO - 2020-09-11 07:55:16 --> Model Class Initialized
INFO - 2020-09-11 07:55:16 --> Model Class Initialized
INFO - 2020-09-11 07:55:16 --> Final output sent to browser
DEBUG - 2020-09-11 07:55:16 --> Total execution time: 0.0414
ERROR - 2020-09-11 07:55:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:55:39 --> Config Class Initialized
INFO - 2020-09-11 07:55:39 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:55:39 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:55:39 --> Utf8 Class Initialized
INFO - 2020-09-11 07:55:39 --> URI Class Initialized
INFO - 2020-09-11 07:55:39 --> Router Class Initialized
INFO - 2020-09-11 07:55:39 --> Output Class Initialized
INFO - 2020-09-11 07:55:39 --> Security Class Initialized
DEBUG - 2020-09-11 07:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:55:39 --> Input Class Initialized
INFO - 2020-09-11 07:55:39 --> Language Class Initialized
INFO - 2020-09-11 07:55:39 --> Loader Class Initialized
INFO - 2020-09-11 07:55:39 --> Helper loaded: url_helper
INFO - 2020-09-11 07:55:39 --> Database Driver Class Initialized
INFO - 2020-09-11 07:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:55:39 --> Email Class Initialized
INFO - 2020-09-11 07:55:39 --> Controller Class Initialized
INFO - 2020-09-11 07:55:39 --> Model Class Initialized
INFO - 2020-09-11 07:55:39 --> Model Class Initialized
INFO - 2020-09-11 07:55:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:55:39 --> Final output sent to browser
DEBUG - 2020-09-11 07:55:39 --> Total execution time: 0.1015
ERROR - 2020-09-11 07:55:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:55:42 --> Config Class Initialized
INFO - 2020-09-11 07:55:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:55:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:55:42 --> Utf8 Class Initialized
INFO - 2020-09-11 07:55:42 --> URI Class Initialized
INFO - 2020-09-11 07:55:42 --> Router Class Initialized
INFO - 2020-09-11 07:55:42 --> Output Class Initialized
INFO - 2020-09-11 07:55:42 --> Security Class Initialized
DEBUG - 2020-09-11 07:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:55:42 --> Input Class Initialized
INFO - 2020-09-11 07:55:42 --> Language Class Initialized
INFO - 2020-09-11 07:55:42 --> Loader Class Initialized
INFO - 2020-09-11 07:55:42 --> Helper loaded: url_helper
INFO - 2020-09-11 07:55:42 --> Database Driver Class Initialized
INFO - 2020-09-11 07:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:55:42 --> Email Class Initialized
INFO - 2020-09-11 07:55:42 --> Controller Class Initialized
INFO - 2020-09-11 07:55:42 --> Model Class Initialized
INFO - 2020-09-11 07:55:42 --> Model Class Initialized
INFO - 2020-09-11 07:55:42 --> Final output sent to browser
DEBUG - 2020-09-11 07:55:42 --> Total execution time: 0.0417
ERROR - 2020-09-11 07:56:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:56:53 --> Config Class Initialized
INFO - 2020-09-11 07:56:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:56:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:56:53 --> Utf8 Class Initialized
INFO - 2020-09-11 07:56:53 --> URI Class Initialized
INFO - 2020-09-11 07:56:53 --> Router Class Initialized
INFO - 2020-09-11 07:56:53 --> Output Class Initialized
INFO - 2020-09-11 07:56:53 --> Security Class Initialized
DEBUG - 2020-09-11 07:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:56:53 --> Input Class Initialized
INFO - 2020-09-11 07:56:53 --> Language Class Initialized
INFO - 2020-09-11 07:56:53 --> Loader Class Initialized
INFO - 2020-09-11 07:56:53 --> Helper loaded: url_helper
INFO - 2020-09-11 07:56:53 --> Database Driver Class Initialized
INFO - 2020-09-11 07:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:56:53 --> Email Class Initialized
INFO - 2020-09-11 07:56:53 --> Controller Class Initialized
INFO - 2020-09-11 07:56:53 --> Model Class Initialized
INFO - 2020-09-11 07:56:53 --> Model Class Initialized
INFO - 2020-09-11 07:56:53 --> Final output sent to browser
DEBUG - 2020-09-11 07:56:53 --> Total execution time: 0.1414
ERROR - 2020-09-11 07:56:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:56:53 --> Config Class Initialized
INFO - 2020-09-11 07:56:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:56:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:56:53 --> Utf8 Class Initialized
INFO - 2020-09-11 07:56:53 --> URI Class Initialized
INFO - 2020-09-11 07:56:53 --> Router Class Initialized
INFO - 2020-09-11 07:56:53 --> Output Class Initialized
INFO - 2020-09-11 07:56:53 --> Security Class Initialized
DEBUG - 2020-09-11 07:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:56:53 --> Input Class Initialized
INFO - 2020-09-11 07:56:53 --> Language Class Initialized
INFO - 2020-09-11 07:56:53 --> Loader Class Initialized
INFO - 2020-09-11 07:56:53 --> Helper loaded: url_helper
INFO - 2020-09-11 07:56:53 --> Database Driver Class Initialized
INFO - 2020-09-11 07:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:56:53 --> Email Class Initialized
INFO - 2020-09-11 07:56:53 --> Controller Class Initialized
INFO - 2020-09-11 07:56:53 --> Model Class Initialized
INFO - 2020-09-11 07:56:53 --> Model Class Initialized
INFO - 2020-09-11 07:56:53 --> Final output sent to browser
DEBUG - 2020-09-11 07:56:53 --> Total execution time: 0.0524
ERROR - 2020-09-11 07:58:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:58:36 --> Config Class Initialized
INFO - 2020-09-11 07:58:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:58:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:58:36 --> Utf8 Class Initialized
INFO - 2020-09-11 07:58:36 --> URI Class Initialized
INFO - 2020-09-11 07:58:36 --> Router Class Initialized
INFO - 2020-09-11 07:58:36 --> Output Class Initialized
INFO - 2020-09-11 07:58:36 --> Security Class Initialized
DEBUG - 2020-09-11 07:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:58:36 --> Input Class Initialized
INFO - 2020-09-11 07:58:36 --> Language Class Initialized
INFO - 2020-09-11 07:58:36 --> Loader Class Initialized
INFO - 2020-09-11 07:58:36 --> Helper loaded: url_helper
INFO - 2020-09-11 07:58:36 --> Database Driver Class Initialized
INFO - 2020-09-11 07:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:58:36 --> Email Class Initialized
INFO - 2020-09-11 07:58:36 --> Controller Class Initialized
INFO - 2020-09-11 07:58:36 --> Model Class Initialized
INFO - 2020-09-11 07:58:36 --> Model Class Initialized
INFO - 2020-09-11 07:58:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:58:36 --> Final output sent to browser
DEBUG - 2020-09-11 07:58:36 --> Total execution time: 0.0373
ERROR - 2020-09-11 07:58:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:58:36 --> Config Class Initialized
INFO - 2020-09-11 07:58:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:58:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:58:36 --> Utf8 Class Initialized
INFO - 2020-09-11 07:58:36 --> URI Class Initialized
INFO - 2020-09-11 07:58:36 --> Router Class Initialized
INFO - 2020-09-11 07:58:36 --> Output Class Initialized
INFO - 2020-09-11 07:58:36 --> Security Class Initialized
DEBUG - 2020-09-11 07:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:58:36 --> Input Class Initialized
INFO - 2020-09-11 07:58:36 --> Language Class Initialized
INFO - 2020-09-11 07:58:36 --> Loader Class Initialized
INFO - 2020-09-11 07:58:36 --> Helper loaded: url_helper
INFO - 2020-09-11 07:58:36 --> Database Driver Class Initialized
INFO - 2020-09-11 07:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:58:36 --> Email Class Initialized
INFO - 2020-09-11 07:58:36 --> Controller Class Initialized
INFO - 2020-09-11 07:58:36 --> Model Class Initialized
INFO - 2020-09-11 07:58:36 --> Model Class Initialized
INFO - 2020-09-11 07:58:37 --> Final output sent to browser
DEBUG - 2020-09-11 07:58:37 --> Total execution time: 0.0401
ERROR - 2020-09-11 07:59:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:59:02 --> Config Class Initialized
INFO - 2020-09-11 07:59:02 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:59:02 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:59:02 --> Utf8 Class Initialized
INFO - 2020-09-11 07:59:02 --> URI Class Initialized
INFO - 2020-09-11 07:59:02 --> Router Class Initialized
INFO - 2020-09-11 07:59:02 --> Output Class Initialized
INFO - 2020-09-11 07:59:02 --> Security Class Initialized
DEBUG - 2020-09-11 07:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:59:02 --> Input Class Initialized
INFO - 2020-09-11 07:59:02 --> Language Class Initialized
INFO - 2020-09-11 07:59:02 --> Loader Class Initialized
INFO - 2020-09-11 07:59:02 --> Helper loaded: url_helper
INFO - 2020-09-11 07:59:02 --> Database Driver Class Initialized
INFO - 2020-09-11 07:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:59:02 --> Email Class Initialized
INFO - 2020-09-11 07:59:02 --> Controller Class Initialized
INFO - 2020-09-11 07:59:02 --> Model Class Initialized
INFO - 2020-09-11 07:59:02 --> Model Class Initialized
INFO - 2020-09-11 07:59:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 07:59:02 --> Final output sent to browser
DEBUG - 2020-09-11 07:59:02 --> Total execution time: 0.1134
ERROR - 2020-09-11 07:59:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 07:59:03 --> Config Class Initialized
INFO - 2020-09-11 07:59:03 --> Hooks Class Initialized
DEBUG - 2020-09-11 07:59:03 --> UTF-8 Support Enabled
INFO - 2020-09-11 07:59:03 --> Utf8 Class Initialized
INFO - 2020-09-11 07:59:03 --> URI Class Initialized
INFO - 2020-09-11 07:59:03 --> Router Class Initialized
INFO - 2020-09-11 07:59:03 --> Output Class Initialized
INFO - 2020-09-11 07:59:03 --> Security Class Initialized
DEBUG - 2020-09-11 07:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 07:59:03 --> Input Class Initialized
INFO - 2020-09-11 07:59:03 --> Language Class Initialized
INFO - 2020-09-11 07:59:03 --> Loader Class Initialized
INFO - 2020-09-11 07:59:03 --> Helper loaded: url_helper
INFO - 2020-09-11 07:59:03 --> Database Driver Class Initialized
INFO - 2020-09-11 07:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 07:59:03 --> Email Class Initialized
INFO - 2020-09-11 07:59:03 --> Controller Class Initialized
INFO - 2020-09-11 07:59:03 --> Model Class Initialized
INFO - 2020-09-11 07:59:03 --> Model Class Initialized
INFO - 2020-09-11 07:59:03 --> Final output sent to browser
DEBUG - 2020-09-11 07:59:03 --> Total execution time: 0.0484
ERROR - 2020-09-11 08:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:07:01 --> Config Class Initialized
INFO - 2020-09-11 08:07:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:07:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:07:01 --> Utf8 Class Initialized
INFO - 2020-09-11 08:07:01 --> URI Class Initialized
INFO - 2020-09-11 08:07:01 --> Router Class Initialized
INFO - 2020-09-11 08:07:01 --> Output Class Initialized
INFO - 2020-09-11 08:07:01 --> Security Class Initialized
DEBUG - 2020-09-11 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:07:01 --> Input Class Initialized
INFO - 2020-09-11 08:07:01 --> Language Class Initialized
INFO - 2020-09-11 08:07:01 --> Loader Class Initialized
INFO - 2020-09-11 08:07:01 --> Helper loaded: url_helper
INFO - 2020-09-11 08:07:01 --> Database Driver Class Initialized
INFO - 2020-09-11 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:07:01 --> Email Class Initialized
INFO - 2020-09-11 08:07:01 --> Controller Class Initialized
INFO - 2020-09-11 08:07:01 --> Model Class Initialized
INFO - 2020-09-11 08:07:01 --> Model Class Initialized
INFO - 2020-09-11 08:07:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 08:07:01 --> Final output sent to browser
DEBUG - 2020-09-11 08:07:01 --> Total execution time: 0.0419
ERROR - 2020-09-11 08:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:07:01 --> Config Class Initialized
INFO - 2020-09-11 08:07:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:07:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:07:01 --> Utf8 Class Initialized
INFO - 2020-09-11 08:07:01 --> URI Class Initialized
INFO - 2020-09-11 08:07:01 --> Router Class Initialized
INFO - 2020-09-11 08:07:01 --> Output Class Initialized
INFO - 2020-09-11 08:07:01 --> Security Class Initialized
DEBUG - 2020-09-11 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:07:01 --> Input Class Initialized
INFO - 2020-09-11 08:07:01 --> Language Class Initialized
INFO - 2020-09-11 08:07:01 --> Loader Class Initialized
INFO - 2020-09-11 08:07:01 --> Helper loaded: url_helper
INFO - 2020-09-11 08:07:01 --> Database Driver Class Initialized
INFO - 2020-09-11 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:07:01 --> Email Class Initialized
INFO - 2020-09-11 08:07:01 --> Controller Class Initialized
INFO - 2020-09-11 08:07:01 --> Model Class Initialized
INFO - 2020-09-11 08:07:01 --> Model Class Initialized
INFO - 2020-09-11 08:07:01 --> Final output sent to browser
DEBUG - 2020-09-11 08:07:01 --> Total execution time: 0.0454
ERROR - 2020-09-11 08:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:07:19 --> Config Class Initialized
INFO - 2020-09-11 08:07:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:07:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:07:19 --> Utf8 Class Initialized
INFO - 2020-09-11 08:07:19 --> URI Class Initialized
INFO - 2020-09-11 08:07:19 --> Router Class Initialized
INFO - 2020-09-11 08:07:19 --> Output Class Initialized
INFO - 2020-09-11 08:07:19 --> Security Class Initialized
DEBUG - 2020-09-11 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:07:19 --> Input Class Initialized
INFO - 2020-09-11 08:07:19 --> Language Class Initialized
INFO - 2020-09-11 08:07:19 --> Loader Class Initialized
INFO - 2020-09-11 08:07:19 --> Helper loaded: url_helper
INFO - 2020-09-11 08:07:19 --> Database Driver Class Initialized
INFO - 2020-09-11 08:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:07:19 --> Email Class Initialized
INFO - 2020-09-11 08:07:19 --> Controller Class Initialized
INFO - 2020-09-11 08:07:19 --> Model Class Initialized
INFO - 2020-09-11 08:07:19 --> Model Class Initialized
INFO - 2020-09-11 08:07:19 --> Final output sent to browser
DEBUG - 2020-09-11 08:07:19 --> Total execution time: 0.1764
ERROR - 2020-09-11 08:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:07:19 --> Config Class Initialized
INFO - 2020-09-11 08:07:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:07:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:07:19 --> Utf8 Class Initialized
INFO - 2020-09-11 08:07:19 --> URI Class Initialized
INFO - 2020-09-11 08:07:19 --> Router Class Initialized
INFO - 2020-09-11 08:07:19 --> Output Class Initialized
INFO - 2020-09-11 08:07:19 --> Security Class Initialized
DEBUG - 2020-09-11 08:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:07:19 --> Input Class Initialized
INFO - 2020-09-11 08:07:19 --> Language Class Initialized
INFO - 2020-09-11 08:07:19 --> Loader Class Initialized
INFO - 2020-09-11 08:07:19 --> Helper loaded: url_helper
INFO - 2020-09-11 08:07:19 --> Database Driver Class Initialized
INFO - 2020-09-11 08:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:07:19 --> Email Class Initialized
INFO - 2020-09-11 08:07:19 --> Controller Class Initialized
INFO - 2020-09-11 08:07:19 --> Model Class Initialized
INFO - 2020-09-11 08:07:19 --> Model Class Initialized
INFO - 2020-09-11 08:07:20 --> Final output sent to browser
DEBUG - 2020-09-11 08:07:20 --> Total execution time: 0.0465
ERROR - 2020-09-11 08:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:09:08 --> Config Class Initialized
INFO - 2020-09-11 08:09:08 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:09:08 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:09:08 --> Utf8 Class Initialized
INFO - 2020-09-11 08:09:08 --> URI Class Initialized
INFO - 2020-09-11 08:09:08 --> Router Class Initialized
INFO - 2020-09-11 08:09:08 --> Output Class Initialized
INFO - 2020-09-11 08:09:08 --> Security Class Initialized
DEBUG - 2020-09-11 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:09:08 --> Input Class Initialized
INFO - 2020-09-11 08:09:08 --> Language Class Initialized
INFO - 2020-09-11 08:09:08 --> Loader Class Initialized
INFO - 2020-09-11 08:09:08 --> Helper loaded: url_helper
INFO - 2020-09-11 08:09:08 --> Database Driver Class Initialized
INFO - 2020-09-11 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:09:08 --> Email Class Initialized
INFO - 2020-09-11 08:09:08 --> Controller Class Initialized
INFO - 2020-09-11 08:09:08 --> Model Class Initialized
INFO - 2020-09-11 08:09:08 --> Model Class Initialized
INFO - 2020-09-11 08:09:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 08:09:08 --> Final output sent to browser
DEBUG - 2020-09-11 08:09:08 --> Total execution time: 0.0376
ERROR - 2020-09-11 08:09:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:09:09 --> Config Class Initialized
INFO - 2020-09-11 08:09:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:09:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:09:09 --> Utf8 Class Initialized
INFO - 2020-09-11 08:09:09 --> URI Class Initialized
INFO - 2020-09-11 08:09:09 --> Router Class Initialized
INFO - 2020-09-11 08:09:09 --> Output Class Initialized
INFO - 2020-09-11 08:09:09 --> Security Class Initialized
DEBUG - 2020-09-11 08:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:09:09 --> Input Class Initialized
INFO - 2020-09-11 08:09:09 --> Language Class Initialized
INFO - 2020-09-11 08:09:09 --> Loader Class Initialized
INFO - 2020-09-11 08:09:09 --> Helper loaded: url_helper
INFO - 2020-09-11 08:09:09 --> Database Driver Class Initialized
INFO - 2020-09-11 08:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:09:09 --> Email Class Initialized
INFO - 2020-09-11 08:09:09 --> Controller Class Initialized
INFO - 2020-09-11 08:09:09 --> Model Class Initialized
INFO - 2020-09-11 08:09:09 --> Model Class Initialized
INFO - 2020-09-11 08:09:09 --> Final output sent to browser
DEBUG - 2020-09-11 08:09:09 --> Total execution time: 0.0349
ERROR - 2020-09-11 08:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:12:22 --> Config Class Initialized
INFO - 2020-09-11 08:12:22 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:12:22 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:12:22 --> Utf8 Class Initialized
INFO - 2020-09-11 08:12:22 --> URI Class Initialized
INFO - 2020-09-11 08:12:22 --> Router Class Initialized
INFO - 2020-09-11 08:12:22 --> Output Class Initialized
INFO - 2020-09-11 08:12:22 --> Security Class Initialized
DEBUG - 2020-09-11 08:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:12:22 --> Input Class Initialized
INFO - 2020-09-11 08:12:22 --> Language Class Initialized
INFO - 2020-09-11 08:12:22 --> Loader Class Initialized
INFO - 2020-09-11 08:12:22 --> Helper loaded: url_helper
INFO - 2020-09-11 08:12:22 --> Database Driver Class Initialized
INFO - 2020-09-11 08:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:12:22 --> Email Class Initialized
INFO - 2020-09-11 08:12:22 --> Controller Class Initialized
INFO - 2020-09-11 08:12:22 --> Model Class Initialized
INFO - 2020-09-11 08:12:22 --> Model Class Initialized
INFO - 2020-09-11 08:12:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 08:12:23 --> Final output sent to browser
DEBUG - 2020-09-11 08:12:23 --> Total execution time: 0.1202
ERROR - 2020-09-11 08:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:12:23 --> Config Class Initialized
INFO - 2020-09-11 08:12:23 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:12:23 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:12:23 --> Utf8 Class Initialized
INFO - 2020-09-11 08:12:23 --> URI Class Initialized
INFO - 2020-09-11 08:12:23 --> Router Class Initialized
INFO - 2020-09-11 08:12:23 --> Output Class Initialized
INFO - 2020-09-11 08:12:23 --> Security Class Initialized
DEBUG - 2020-09-11 08:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:12:24 --> Input Class Initialized
INFO - 2020-09-11 08:12:24 --> Language Class Initialized
INFO - 2020-09-11 08:12:24 --> Loader Class Initialized
INFO - 2020-09-11 08:12:24 --> Helper loaded: url_helper
INFO - 2020-09-11 08:12:24 --> Database Driver Class Initialized
INFO - 2020-09-11 08:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:12:24 --> Email Class Initialized
INFO - 2020-09-11 08:12:24 --> Controller Class Initialized
INFO - 2020-09-11 08:12:24 --> Model Class Initialized
INFO - 2020-09-11 08:12:24 --> Model Class Initialized
INFO - 2020-09-11 08:12:24 --> Final output sent to browser
DEBUG - 2020-09-11 08:12:24 --> Total execution time: 0.0435
ERROR - 2020-09-11 08:12:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:12:39 --> Config Class Initialized
INFO - 2020-09-11 08:12:39 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:12:39 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:12:39 --> Utf8 Class Initialized
INFO - 2020-09-11 08:12:39 --> URI Class Initialized
INFO - 2020-09-11 08:12:39 --> Router Class Initialized
INFO - 2020-09-11 08:12:39 --> Output Class Initialized
INFO - 2020-09-11 08:12:39 --> Security Class Initialized
DEBUG - 2020-09-11 08:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:12:39 --> Input Class Initialized
INFO - 2020-09-11 08:12:39 --> Language Class Initialized
INFO - 2020-09-11 08:12:39 --> Loader Class Initialized
INFO - 2020-09-11 08:12:39 --> Helper loaded: url_helper
INFO - 2020-09-11 08:12:39 --> Database Driver Class Initialized
INFO - 2020-09-11 08:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:12:39 --> Email Class Initialized
INFO - 2020-09-11 08:12:39 --> Controller Class Initialized
DEBUG - 2020-09-11 08:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 08:12:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 08:12:39 --> Model Class Initialized
INFO - 2020-09-11 08:12:39 --> Model Class Initialized
INFO - 2020-09-11 08:12:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 08:12:39 --> Final output sent to browser
DEBUG - 2020-09-11 08:12:39 --> Total execution time: 0.0429
ERROR - 2020-09-11 08:12:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:12:42 --> Config Class Initialized
INFO - 2020-09-11 08:12:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:12:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:12:42 --> Utf8 Class Initialized
INFO - 2020-09-11 08:12:42 --> URI Class Initialized
INFO - 2020-09-11 08:12:42 --> Router Class Initialized
INFO - 2020-09-11 08:12:42 --> Output Class Initialized
INFO - 2020-09-11 08:12:42 --> Security Class Initialized
DEBUG - 2020-09-11 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:12:42 --> Input Class Initialized
INFO - 2020-09-11 08:12:42 --> Language Class Initialized
INFO - 2020-09-11 08:12:42 --> Loader Class Initialized
INFO - 2020-09-11 08:12:42 --> Helper loaded: url_helper
INFO - 2020-09-11 08:12:42 --> Database Driver Class Initialized
INFO - 2020-09-11 08:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:12:42 --> Email Class Initialized
INFO - 2020-09-11 08:12:42 --> Controller Class Initialized
DEBUG - 2020-09-11 08:12:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 08:12:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 08:12:42 --> Model Class Initialized
INFO - 2020-09-11 08:12:42 --> Model Class Initialized
INFO - 2020-09-11 08:12:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 08:12:42 --> Final output sent to browser
DEBUG - 2020-09-11 08:12:42 --> Total execution time: 0.0253
ERROR - 2020-09-11 08:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:13:06 --> Config Class Initialized
INFO - 2020-09-11 08:13:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:13:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:13:06 --> Utf8 Class Initialized
INFO - 2020-09-11 08:13:06 --> URI Class Initialized
INFO - 2020-09-11 08:13:06 --> Router Class Initialized
INFO - 2020-09-11 08:13:06 --> Output Class Initialized
INFO - 2020-09-11 08:13:06 --> Security Class Initialized
DEBUG - 2020-09-11 08:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:13:06 --> Input Class Initialized
INFO - 2020-09-11 08:13:06 --> Language Class Initialized
INFO - 2020-09-11 08:13:06 --> Loader Class Initialized
INFO - 2020-09-11 08:13:06 --> Helper loaded: url_helper
INFO - 2020-09-11 08:13:06 --> Database Driver Class Initialized
INFO - 2020-09-11 08:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:13:06 --> Email Class Initialized
INFO - 2020-09-11 08:13:06 --> Controller Class Initialized
INFO - 2020-09-11 08:13:06 --> Model Class Initialized
INFO - 2020-09-11 08:13:06 --> Model Class Initialized
INFO - 2020-09-11 08:13:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 08:13:06 --> Final output sent to browser
DEBUG - 2020-09-11 08:13:06 --> Total execution time: 0.0464
ERROR - 2020-09-11 08:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:13:06 --> Config Class Initialized
INFO - 2020-09-11 08:13:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:13:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:13:06 --> Utf8 Class Initialized
INFO - 2020-09-11 08:13:06 --> URI Class Initialized
INFO - 2020-09-11 08:13:06 --> Router Class Initialized
INFO - 2020-09-11 08:13:06 --> Output Class Initialized
INFO - 2020-09-11 08:13:06 --> Security Class Initialized
DEBUG - 2020-09-11 08:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:13:06 --> Input Class Initialized
INFO - 2020-09-11 08:13:06 --> Language Class Initialized
INFO - 2020-09-11 08:13:06 --> Loader Class Initialized
INFO - 2020-09-11 08:13:06 --> Helper loaded: url_helper
INFO - 2020-09-11 08:13:06 --> Database Driver Class Initialized
INFO - 2020-09-11 08:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:13:06 --> Email Class Initialized
INFO - 2020-09-11 08:13:06 --> Controller Class Initialized
INFO - 2020-09-11 08:13:06 --> Model Class Initialized
INFO - 2020-09-11 08:13:06 --> Model Class Initialized
INFO - 2020-09-11 08:13:06 --> Final output sent to browser
DEBUG - 2020-09-11 08:13:06 --> Total execution time: 0.0442
ERROR - 2020-09-11 08:13:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:13:40 --> Config Class Initialized
INFO - 2020-09-11 08:13:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:13:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:13:40 --> Utf8 Class Initialized
INFO - 2020-09-11 08:13:40 --> URI Class Initialized
INFO - 2020-09-11 08:13:40 --> Router Class Initialized
INFO - 2020-09-11 08:13:40 --> Output Class Initialized
INFO - 2020-09-11 08:13:40 --> Security Class Initialized
DEBUG - 2020-09-11 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:13:40 --> Input Class Initialized
INFO - 2020-09-11 08:13:40 --> Language Class Initialized
INFO - 2020-09-11 08:13:40 --> Loader Class Initialized
INFO - 2020-09-11 08:13:40 --> Helper loaded: url_helper
INFO - 2020-09-11 08:13:40 --> Database Driver Class Initialized
INFO - 2020-09-11 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:13:40 --> Email Class Initialized
INFO - 2020-09-11 08:13:40 --> Controller Class Initialized
DEBUG - 2020-09-11 08:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 08:13:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 08:13:40 --> Model Class Initialized
INFO - 2020-09-11 08:13:40 --> Model Class Initialized
INFO - 2020-09-11 08:13:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 08:13:40 --> Final output sent to browser
DEBUG - 2020-09-11 08:13:40 --> Total execution time: 0.0300
ERROR - 2020-09-11 08:14:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:14:49 --> Config Class Initialized
INFO - 2020-09-11 08:14:49 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:14:49 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:14:49 --> Utf8 Class Initialized
INFO - 2020-09-11 08:14:49 --> URI Class Initialized
INFO - 2020-09-11 08:14:49 --> Router Class Initialized
INFO - 2020-09-11 08:14:49 --> Output Class Initialized
INFO - 2020-09-11 08:14:49 --> Security Class Initialized
DEBUG - 2020-09-11 08:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:14:49 --> Input Class Initialized
INFO - 2020-09-11 08:14:49 --> Language Class Initialized
INFO - 2020-09-11 08:14:49 --> Loader Class Initialized
INFO - 2020-09-11 08:14:49 --> Helper loaded: url_helper
INFO - 2020-09-11 08:14:49 --> Database Driver Class Initialized
INFO - 2020-09-11 08:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:14:49 --> Email Class Initialized
INFO - 2020-09-11 08:14:49 --> Controller Class Initialized
INFO - 2020-09-11 08:14:49 --> Model Class Initialized
INFO - 2020-09-11 08:14:49 --> Model Class Initialized
INFO - 2020-09-11 08:14:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 08:14:49 --> Final output sent to browser
DEBUG - 2020-09-11 08:14:49 --> Total execution time: 0.0368
ERROR - 2020-09-11 08:14:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 08:14:50 --> Config Class Initialized
INFO - 2020-09-11 08:14:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 08:14:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 08:14:50 --> Utf8 Class Initialized
INFO - 2020-09-11 08:14:50 --> URI Class Initialized
INFO - 2020-09-11 08:14:50 --> Router Class Initialized
INFO - 2020-09-11 08:14:50 --> Output Class Initialized
INFO - 2020-09-11 08:14:50 --> Security Class Initialized
DEBUG - 2020-09-11 08:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 08:14:50 --> Input Class Initialized
INFO - 2020-09-11 08:14:50 --> Language Class Initialized
INFO - 2020-09-11 08:14:50 --> Loader Class Initialized
INFO - 2020-09-11 08:14:50 --> Helper loaded: url_helper
INFO - 2020-09-11 08:14:50 --> Database Driver Class Initialized
INFO - 2020-09-11 08:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 08:14:50 --> Email Class Initialized
INFO - 2020-09-11 08:14:50 --> Controller Class Initialized
INFO - 2020-09-11 08:14:50 --> Model Class Initialized
INFO - 2020-09-11 08:14:50 --> Model Class Initialized
INFO - 2020-09-11 08:14:50 --> Final output sent to browser
DEBUG - 2020-09-11 08:14:50 --> Total execution time: 0.0347
ERROR - 2020-09-11 11:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:16 --> Config Class Initialized
INFO - 2020-09-11 11:16:16 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:16 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:16 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:16 --> URI Class Initialized
DEBUG - 2020-09-11 11:16:16 --> No URI present. Default controller set.
INFO - 2020-09-11 11:16:16 --> Router Class Initialized
INFO - 2020-09-11 11:16:16 --> Output Class Initialized
INFO - 2020-09-11 11:16:16 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:16 --> Input Class Initialized
INFO - 2020-09-11 11:16:16 --> Language Class Initialized
INFO - 2020-09-11 11:16:16 --> Loader Class Initialized
INFO - 2020-09-11 11:16:16 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:16 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:16 --> Email Class Initialized
INFO - 2020-09-11 11:16:16 --> Controller Class Initialized
INFO - 2020-09-11 11:16:16 --> Model Class Initialized
INFO - 2020-09-11 11:16:16 --> Model Class Initialized
DEBUG - 2020-09-11 11:16:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:16:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:16:16 --> Final output sent to browser
DEBUG - 2020-09-11 11:16:16 --> Total execution time: 0.0702
ERROR - 2020-09-11 11:16:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:26 --> Config Class Initialized
INFO - 2020-09-11 11:16:26 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:26 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:26 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:26 --> URI Class Initialized
INFO - 2020-09-11 11:16:26 --> Router Class Initialized
INFO - 2020-09-11 11:16:26 --> Output Class Initialized
INFO - 2020-09-11 11:16:26 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:26 --> Input Class Initialized
INFO - 2020-09-11 11:16:26 --> Language Class Initialized
INFO - 2020-09-11 11:16:26 --> Loader Class Initialized
INFO - 2020-09-11 11:16:26 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:26 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:26 --> Email Class Initialized
INFO - 2020-09-11 11:16:26 --> Controller Class Initialized
INFO - 2020-09-11 11:16:26 --> Model Class Initialized
INFO - 2020-09-11 11:16:26 --> Model Class Initialized
DEBUG - 2020-09-11 11:16:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:16:26 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:16:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:27 --> Config Class Initialized
INFO - 2020-09-11 11:16:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:27 --> URI Class Initialized
INFO - 2020-09-11 11:16:27 --> Router Class Initialized
INFO - 2020-09-11 11:16:27 --> Output Class Initialized
INFO - 2020-09-11 11:16:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:27 --> Input Class Initialized
INFO - 2020-09-11 11:16:27 --> Language Class Initialized
INFO - 2020-09-11 11:16:27 --> Loader Class Initialized
INFO - 2020-09-11 11:16:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:27 --> Email Class Initialized
INFO - 2020-09-11 11:16:27 --> Controller Class Initialized
INFO - 2020-09-11 11:16:27 --> Model Class Initialized
INFO - 2020-09-11 11:16:27 --> Model Class Initialized
DEBUG - 2020-09-11 11:16:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:16:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:27 --> Config Class Initialized
INFO - 2020-09-11 11:16:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:27 --> URI Class Initialized
DEBUG - 2020-09-11 11:16:27 --> No URI present. Default controller set.
INFO - 2020-09-11 11:16:27 --> Router Class Initialized
INFO - 2020-09-11 11:16:27 --> Output Class Initialized
INFO - 2020-09-11 11:16:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:27 --> Input Class Initialized
INFO - 2020-09-11 11:16:27 --> Language Class Initialized
INFO - 2020-09-11 11:16:27 --> Loader Class Initialized
INFO - 2020-09-11 11:16:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:27 --> Email Class Initialized
INFO - 2020-09-11 11:16:27 --> Controller Class Initialized
INFO - 2020-09-11 11:16:27 --> Model Class Initialized
INFO - 2020-09-11 11:16:27 --> Model Class Initialized
DEBUG - 2020-09-11 11:16:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:16:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:16:27 --> Final output sent to browser
DEBUG - 2020-09-11 11:16:27 --> Total execution time: 0.0212
ERROR - 2020-09-11 11:16:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:27 --> Config Class Initialized
INFO - 2020-09-11 11:16:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:27 --> URI Class Initialized
INFO - 2020-09-11 11:16:27 --> Router Class Initialized
INFO - 2020-09-11 11:16:27 --> Output Class Initialized
INFO - 2020-09-11 11:16:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:27 --> Input Class Initialized
INFO - 2020-09-11 11:16:27 --> Language Class Initialized
INFO - 2020-09-11 11:16:27 --> Loader Class Initialized
INFO - 2020-09-11 11:16:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:27 --> Email Class Initialized
INFO - 2020-09-11 11:16:27 --> Controller Class Initialized
DEBUG - 2020-09-11 11:16:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:16:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:16:27 --> Model Class Initialized
INFO - 2020-09-11 11:16:27 --> Model Class Initialized
INFO - 2020-09-11 11:16:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 11:16:27 --> Final output sent to browser
DEBUG - 2020-09-11 11:16:27 --> Total execution time: 0.0272
ERROR - 2020-09-11 11:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:32 --> Config Class Initialized
INFO - 2020-09-11 11:16:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:32 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:32 --> URI Class Initialized
INFO - 2020-09-11 11:16:32 --> Router Class Initialized
INFO - 2020-09-11 11:16:32 --> Output Class Initialized
INFO - 2020-09-11 11:16:32 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:32 --> Input Class Initialized
INFO - 2020-09-11 11:16:32 --> Language Class Initialized
INFO - 2020-09-11 11:16:32 --> Loader Class Initialized
INFO - 2020-09-11 11:16:32 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:32 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:32 --> Email Class Initialized
INFO - 2020-09-11 11:16:32 --> Controller Class Initialized
INFO - 2020-09-11 11:16:32 --> Model Class Initialized
INFO - 2020-09-11 11:16:32 --> Model Class Initialized
INFO - 2020-09-11 11:16:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 11:16:32 --> Final output sent to browser
DEBUG - 2020-09-11 11:16:32 --> Total execution time: 0.0364
ERROR - 2020-09-11 11:16:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:16:33 --> Config Class Initialized
INFO - 2020-09-11 11:16:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:16:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:16:33 --> Utf8 Class Initialized
INFO - 2020-09-11 11:16:33 --> URI Class Initialized
INFO - 2020-09-11 11:16:33 --> Router Class Initialized
INFO - 2020-09-11 11:16:33 --> Output Class Initialized
INFO - 2020-09-11 11:16:33 --> Security Class Initialized
DEBUG - 2020-09-11 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:16:33 --> Input Class Initialized
INFO - 2020-09-11 11:16:33 --> Language Class Initialized
INFO - 2020-09-11 11:16:33 --> Loader Class Initialized
INFO - 2020-09-11 11:16:33 --> Helper loaded: url_helper
INFO - 2020-09-11 11:16:33 --> Database Driver Class Initialized
INFO - 2020-09-11 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:16:33 --> Email Class Initialized
INFO - 2020-09-11 11:16:33 --> Controller Class Initialized
INFO - 2020-09-11 11:16:33 --> Model Class Initialized
INFO - 2020-09-11 11:16:33 --> Model Class Initialized
INFO - 2020-09-11 11:16:33 --> Final output sent to browser
DEBUG - 2020-09-11 11:16:33 --> Total execution time: 0.0500
ERROR - 2020-09-11 11:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:18:27 --> Config Class Initialized
INFO - 2020-09-11 11:18:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:18:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:18:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:18:27 --> URI Class Initialized
INFO - 2020-09-11 11:18:27 --> Router Class Initialized
INFO - 2020-09-11 11:18:27 --> Output Class Initialized
INFO - 2020-09-11 11:18:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:18:27 --> Input Class Initialized
INFO - 2020-09-11 11:18:27 --> Language Class Initialized
INFO - 2020-09-11 11:18:27 --> Loader Class Initialized
INFO - 2020-09-11 11:18:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:18:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:18:27 --> Email Class Initialized
INFO - 2020-09-11 11:18:27 --> Controller Class Initialized
DEBUG - 2020-09-11 11:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:18:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:18:27 --> Model Class Initialized
INFO - 2020-09-11 11:18:27 --> Model Class Initialized
INFO - 2020-09-11 11:18:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 11:18:27 --> Final output sent to browser
DEBUG - 2020-09-11 11:18:27 --> Total execution time: 0.0239
ERROR - 2020-09-11 11:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:18:29 --> Config Class Initialized
INFO - 2020-09-11 11:18:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:18:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:18:29 --> Utf8 Class Initialized
INFO - 2020-09-11 11:18:29 --> URI Class Initialized
INFO - 2020-09-11 11:18:29 --> Router Class Initialized
INFO - 2020-09-11 11:18:29 --> Output Class Initialized
INFO - 2020-09-11 11:18:29 --> Security Class Initialized
DEBUG - 2020-09-11 11:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:18:29 --> Input Class Initialized
INFO - 2020-09-11 11:18:29 --> Language Class Initialized
INFO - 2020-09-11 11:18:29 --> Loader Class Initialized
INFO - 2020-09-11 11:18:29 --> Helper loaded: url_helper
INFO - 2020-09-11 11:18:29 --> Database Driver Class Initialized
INFO - 2020-09-11 11:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:18:29 --> Email Class Initialized
INFO - 2020-09-11 11:18:29 --> Controller Class Initialized
DEBUG - 2020-09-11 11:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:18:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:18:29 --> Model Class Initialized
INFO - 2020-09-11 11:18:29 --> Model Class Initialized
INFO - 2020-09-11 11:18:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 11:18:29 --> Final output sent to browser
DEBUG - 2020-09-11 11:18:29 --> Total execution time: 0.0218
ERROR - 2020-09-11 11:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:18:48 --> Config Class Initialized
INFO - 2020-09-11 11:18:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:18:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:18:48 --> Utf8 Class Initialized
INFO - 2020-09-11 11:18:48 --> URI Class Initialized
INFO - 2020-09-11 11:18:48 --> Router Class Initialized
INFO - 2020-09-11 11:18:48 --> Output Class Initialized
INFO - 2020-09-11 11:18:48 --> Security Class Initialized
DEBUG - 2020-09-11 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:18:48 --> Input Class Initialized
INFO - 2020-09-11 11:18:48 --> Language Class Initialized
INFO - 2020-09-11 11:18:48 --> Loader Class Initialized
INFO - 2020-09-11 11:18:48 --> Helper loaded: url_helper
INFO - 2020-09-11 11:18:48 --> Database Driver Class Initialized
INFO - 2020-09-11 11:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:18:48 --> Email Class Initialized
INFO - 2020-09-11 11:18:48 --> Controller Class Initialized
INFO - 2020-09-11 11:18:48 --> Model Class Initialized
INFO - 2020-09-11 11:18:48 --> Model Class Initialized
INFO - 2020-09-11 11:18:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 11:18:48 --> Final output sent to browser
DEBUG - 2020-09-11 11:18:48 --> Total execution time: 0.0352
ERROR - 2020-09-11 11:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:18:48 --> Config Class Initialized
INFO - 2020-09-11 11:18:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:18:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:18:48 --> Utf8 Class Initialized
INFO - 2020-09-11 11:18:48 --> URI Class Initialized
INFO - 2020-09-11 11:18:48 --> Router Class Initialized
INFO - 2020-09-11 11:18:48 --> Output Class Initialized
INFO - 2020-09-11 11:18:48 --> Security Class Initialized
DEBUG - 2020-09-11 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:18:48 --> Input Class Initialized
INFO - 2020-09-11 11:18:48 --> Language Class Initialized
INFO - 2020-09-11 11:18:48 --> Loader Class Initialized
INFO - 2020-09-11 11:18:48 --> Helper loaded: url_helper
INFO - 2020-09-11 11:18:48 --> Database Driver Class Initialized
INFO - 2020-09-11 11:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:18:48 --> Email Class Initialized
INFO - 2020-09-11 11:18:48 --> Controller Class Initialized
INFO - 2020-09-11 11:18:48 --> Model Class Initialized
INFO - 2020-09-11 11:18:48 --> Model Class Initialized
INFO - 2020-09-11 11:18:48 --> Final output sent to browser
DEBUG - 2020-09-11 11:18:48 --> Total execution time: 0.0370
ERROR - 2020-09-11 11:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:18:57 --> Config Class Initialized
INFO - 2020-09-11 11:18:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:18:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:18:57 --> Utf8 Class Initialized
INFO - 2020-09-11 11:18:57 --> URI Class Initialized
INFO - 2020-09-11 11:18:57 --> Router Class Initialized
INFO - 2020-09-11 11:18:57 --> Output Class Initialized
INFO - 2020-09-11 11:18:57 --> Security Class Initialized
DEBUG - 2020-09-11 11:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:18:57 --> Input Class Initialized
INFO - 2020-09-11 11:18:57 --> Language Class Initialized
INFO - 2020-09-11 11:18:57 --> Loader Class Initialized
INFO - 2020-09-11 11:18:57 --> Helper loaded: url_helper
INFO - 2020-09-11 11:18:57 --> Database Driver Class Initialized
INFO - 2020-09-11 11:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:18:57 --> Email Class Initialized
INFO - 2020-09-11 11:18:57 --> Controller Class Initialized
INFO - 2020-09-11 11:18:57 --> Model Class Initialized
INFO - 2020-09-11 11:18:57 --> Model Class Initialized
INFO - 2020-09-11 11:18:57 --> Final output sent to browser
DEBUG - 2020-09-11 11:18:57 --> Total execution time: 0.1811
ERROR - 2020-09-11 11:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:18:58 --> Config Class Initialized
INFO - 2020-09-11 11:18:58 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:18:58 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:18:58 --> Utf8 Class Initialized
INFO - 2020-09-11 11:18:58 --> URI Class Initialized
INFO - 2020-09-11 11:18:58 --> Router Class Initialized
INFO - 2020-09-11 11:18:58 --> Output Class Initialized
INFO - 2020-09-11 11:18:58 --> Security Class Initialized
DEBUG - 2020-09-11 11:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:18:58 --> Input Class Initialized
INFO - 2020-09-11 11:18:58 --> Language Class Initialized
INFO - 2020-09-11 11:18:58 --> Loader Class Initialized
INFO - 2020-09-11 11:18:58 --> Helper loaded: url_helper
INFO - 2020-09-11 11:18:58 --> Database Driver Class Initialized
INFO - 2020-09-11 11:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:18:58 --> Email Class Initialized
INFO - 2020-09-11 11:18:58 --> Controller Class Initialized
INFO - 2020-09-11 11:18:58 --> Model Class Initialized
INFO - 2020-09-11 11:18:58 --> Model Class Initialized
INFO - 2020-09-11 11:18:58 --> Final output sent to browser
DEBUG - 2020-09-11 11:18:58 --> Total execution time: 0.0408
ERROR - 2020-09-11 11:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:20:05 --> Config Class Initialized
INFO - 2020-09-11 11:20:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:20:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:20:05 --> Utf8 Class Initialized
INFO - 2020-09-11 11:20:05 --> URI Class Initialized
INFO - 2020-09-11 11:20:05 --> Router Class Initialized
INFO - 2020-09-11 11:20:05 --> Output Class Initialized
INFO - 2020-09-11 11:20:05 --> Security Class Initialized
DEBUG - 2020-09-11 11:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:20:05 --> Input Class Initialized
INFO - 2020-09-11 11:20:05 --> Language Class Initialized
INFO - 2020-09-11 11:20:05 --> Loader Class Initialized
INFO - 2020-09-11 11:20:05 --> Helper loaded: url_helper
INFO - 2020-09-11 11:20:05 --> Database Driver Class Initialized
INFO - 2020-09-11 11:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:20:05 --> Email Class Initialized
INFO - 2020-09-11 11:20:05 --> Controller Class Initialized
INFO - 2020-09-11 11:20:05 --> Model Class Initialized
INFO - 2020-09-11 11:20:05 --> Model Class Initialized
INFO - 2020-09-11 11:20:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 11:20:05 --> Final output sent to browser
DEBUG - 2020-09-11 11:20:05 --> Total execution time: 0.1015
ERROR - 2020-09-11 11:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:20:06 --> Config Class Initialized
INFO - 2020-09-11 11:20:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:20:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:20:06 --> Utf8 Class Initialized
INFO - 2020-09-11 11:20:06 --> URI Class Initialized
INFO - 2020-09-11 11:20:06 --> Router Class Initialized
INFO - 2020-09-11 11:20:06 --> Output Class Initialized
INFO - 2020-09-11 11:20:06 --> Security Class Initialized
DEBUG - 2020-09-11 11:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:20:06 --> Input Class Initialized
INFO - 2020-09-11 11:20:06 --> Language Class Initialized
INFO - 2020-09-11 11:20:06 --> Loader Class Initialized
INFO - 2020-09-11 11:20:06 --> Helper loaded: url_helper
INFO - 2020-09-11 11:20:06 --> Database Driver Class Initialized
INFO - 2020-09-11 11:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:20:06 --> Email Class Initialized
INFO - 2020-09-11 11:20:06 --> Controller Class Initialized
INFO - 2020-09-11 11:20:06 --> Model Class Initialized
INFO - 2020-09-11 11:20:06 --> Model Class Initialized
INFO - 2020-09-11 11:20:06 --> Final output sent to browser
DEBUG - 2020-09-11 11:20:06 --> Total execution time: 0.0390
ERROR - 2020-09-11 11:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:20:25 --> Config Class Initialized
INFO - 2020-09-11 11:20:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:20:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:20:25 --> Utf8 Class Initialized
INFO - 2020-09-11 11:20:25 --> URI Class Initialized
INFO - 2020-09-11 11:20:25 --> Router Class Initialized
INFO - 2020-09-11 11:20:25 --> Output Class Initialized
INFO - 2020-09-11 11:20:25 --> Security Class Initialized
DEBUG - 2020-09-11 11:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:20:25 --> Input Class Initialized
INFO - 2020-09-11 11:20:25 --> Language Class Initialized
INFO - 2020-09-11 11:20:25 --> Loader Class Initialized
INFO - 2020-09-11 11:20:25 --> Helper loaded: url_helper
INFO - 2020-09-11 11:20:25 --> Database Driver Class Initialized
INFO - 2020-09-11 11:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:20:25 --> Email Class Initialized
INFO - 2020-09-11 11:20:25 --> Controller Class Initialized
DEBUG - 2020-09-11 11:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:20:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:20:25 --> Model Class Initialized
INFO - 2020-09-11 11:20:25 --> Model Class Initialized
INFO - 2020-09-11 11:20:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 11:20:25 --> Final output sent to browser
DEBUG - 2020-09-11 11:20:25 --> Total execution time: 0.0251
ERROR - 2020-09-11 11:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:20:46 --> Config Class Initialized
INFO - 2020-09-11 11:20:46 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:20:46 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:20:46 --> Utf8 Class Initialized
INFO - 2020-09-11 11:20:46 --> URI Class Initialized
INFO - 2020-09-11 11:20:46 --> Router Class Initialized
INFO - 2020-09-11 11:20:46 --> Output Class Initialized
INFO - 2020-09-11 11:20:46 --> Security Class Initialized
DEBUG - 2020-09-11 11:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:20:46 --> Input Class Initialized
INFO - 2020-09-11 11:20:46 --> Language Class Initialized
INFO - 2020-09-11 11:20:46 --> Loader Class Initialized
INFO - 2020-09-11 11:20:46 --> Helper loaded: url_helper
INFO - 2020-09-11 11:20:46 --> Database Driver Class Initialized
INFO - 2020-09-11 11:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:20:46 --> Email Class Initialized
INFO - 2020-09-11 11:20:46 --> Controller Class Initialized
DEBUG - 2020-09-11 11:20:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:20:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:20:46 --> Model Class Initialized
INFO - 2020-09-11 11:20:46 --> Model Class Initialized
INFO - 2020-09-11 11:20:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 11:20:46 --> Final output sent to browser
DEBUG - 2020-09-11 11:20:46 --> Total execution time: 0.0235
ERROR - 2020-09-11 11:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:20:57 --> Config Class Initialized
INFO - 2020-09-11 11:20:57 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:20:57 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:20:57 --> Utf8 Class Initialized
INFO - 2020-09-11 11:20:57 --> URI Class Initialized
INFO - 2020-09-11 11:20:57 --> Router Class Initialized
INFO - 2020-09-11 11:20:57 --> Output Class Initialized
INFO - 2020-09-11 11:20:57 --> Security Class Initialized
DEBUG - 2020-09-11 11:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:20:57 --> Input Class Initialized
INFO - 2020-09-11 11:20:57 --> Language Class Initialized
INFO - 2020-09-11 11:20:57 --> Loader Class Initialized
INFO - 2020-09-11 11:20:57 --> Helper loaded: url_helper
INFO - 2020-09-11 11:20:57 --> Database Driver Class Initialized
INFO - 2020-09-11 11:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:20:57 --> Email Class Initialized
INFO - 2020-09-11 11:20:57 --> Controller Class Initialized
DEBUG - 2020-09-11 11:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:20:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:20:57 --> Model Class Initialized
INFO - 2020-09-11 11:20:57 --> Model Class Initialized
INFO - 2020-09-11 11:20:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 11:20:57 --> Final output sent to browser
DEBUG - 2020-09-11 11:20:57 --> Total execution time: 0.0280
ERROR - 2020-09-11 11:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:12 --> Config Class Initialized
INFO - 2020-09-11 11:22:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:12 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:12 --> URI Class Initialized
INFO - 2020-09-11 11:22:12 --> Router Class Initialized
INFO - 2020-09-11 11:22:12 --> Output Class Initialized
INFO - 2020-09-11 11:22:12 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:12 --> Input Class Initialized
INFO - 2020-09-11 11:22:12 --> Language Class Initialized
INFO - 2020-09-11 11:22:12 --> Loader Class Initialized
INFO - 2020-09-11 11:22:12 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:12 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:12 --> Email Class Initialized
INFO - 2020-09-11 11:22:12 --> Controller Class Initialized
INFO - 2020-09-11 11:22:12 --> Model Class Initialized
INFO - 2020-09-11 11:22:12 --> Model Class Initialized
INFO - 2020-09-11 11:22:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 11:22:12 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:12 --> Total execution time: 0.0385
ERROR - 2020-09-11 11:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:13 --> Config Class Initialized
INFO - 2020-09-11 11:22:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:13 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:13 --> URI Class Initialized
INFO - 2020-09-11 11:22:13 --> Router Class Initialized
INFO - 2020-09-11 11:22:13 --> Output Class Initialized
INFO - 2020-09-11 11:22:13 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:13 --> Input Class Initialized
INFO - 2020-09-11 11:22:13 --> Language Class Initialized
INFO - 2020-09-11 11:22:13 --> Loader Class Initialized
INFO - 2020-09-11 11:22:13 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:13 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:13 --> Email Class Initialized
INFO - 2020-09-11 11:22:13 --> Controller Class Initialized
INFO - 2020-09-11 11:22:13 --> Model Class Initialized
INFO - 2020-09-11 11:22:13 --> Model Class Initialized
INFO - 2020-09-11 11:22:13 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:13 --> Total execution time: 0.0425
ERROR - 2020-09-11 11:22:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:24 --> Config Class Initialized
INFO - 2020-09-11 11:22:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:24 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:24 --> URI Class Initialized
INFO - 2020-09-11 11:22:24 --> Router Class Initialized
INFO - 2020-09-11 11:22:24 --> Output Class Initialized
INFO - 2020-09-11 11:22:24 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:24 --> Input Class Initialized
INFO - 2020-09-11 11:22:24 --> Language Class Initialized
INFO - 2020-09-11 11:22:24 --> Loader Class Initialized
INFO - 2020-09-11 11:22:24 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:24 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:24 --> Email Class Initialized
INFO - 2020-09-11 11:22:24 --> Controller Class Initialized
INFO - 2020-09-11 11:22:24 --> Model Class Initialized
INFO - 2020-09-11 11:22:24 --> Model Class Initialized
INFO - 2020-09-11 11:22:24 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:24 --> Total execution time: 0.1558
ERROR - 2020-09-11 11:22:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:25 --> Config Class Initialized
INFO - 2020-09-11 11:22:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:25 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:25 --> URI Class Initialized
INFO - 2020-09-11 11:22:25 --> Router Class Initialized
INFO - 2020-09-11 11:22:25 --> Output Class Initialized
INFO - 2020-09-11 11:22:25 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:25 --> Input Class Initialized
INFO - 2020-09-11 11:22:25 --> Language Class Initialized
INFO - 2020-09-11 11:22:25 --> Loader Class Initialized
INFO - 2020-09-11 11:22:25 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:25 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:25 --> Email Class Initialized
INFO - 2020-09-11 11:22:25 --> Controller Class Initialized
INFO - 2020-09-11 11:22:25 --> Model Class Initialized
INFO - 2020-09-11 11:22:25 --> Model Class Initialized
INFO - 2020-09-11 11:22:25 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:25 --> Total execution time: 0.0438
ERROR - 2020-09-11 11:22:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:32 --> Config Class Initialized
INFO - 2020-09-11 11:22:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:32 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:32 --> URI Class Initialized
INFO - 2020-09-11 11:22:32 --> Router Class Initialized
INFO - 2020-09-11 11:22:32 --> Output Class Initialized
INFO - 2020-09-11 11:22:32 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:32 --> Input Class Initialized
INFO - 2020-09-11 11:22:32 --> Language Class Initialized
INFO - 2020-09-11 11:22:32 --> Loader Class Initialized
INFO - 2020-09-11 11:22:32 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:32 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:32 --> Email Class Initialized
INFO - 2020-09-11 11:22:32 --> Controller Class Initialized
INFO - 2020-09-11 11:22:32 --> Model Class Initialized
INFO - 2020-09-11 11:22:32 --> Model Class Initialized
INFO - 2020-09-11 11:22:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 11:22:32 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:32 --> Total execution time: 0.0874
ERROR - 2020-09-11 11:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:33 --> Config Class Initialized
INFO - 2020-09-11 11:22:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:33 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:33 --> URI Class Initialized
INFO - 2020-09-11 11:22:33 --> Router Class Initialized
INFO - 2020-09-11 11:22:33 --> Output Class Initialized
INFO - 2020-09-11 11:22:33 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:33 --> Input Class Initialized
INFO - 2020-09-11 11:22:33 --> Language Class Initialized
INFO - 2020-09-11 11:22:33 --> Loader Class Initialized
INFO - 2020-09-11 11:22:33 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:33 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:33 --> Email Class Initialized
INFO - 2020-09-11 11:22:33 --> Controller Class Initialized
INFO - 2020-09-11 11:22:33 --> Model Class Initialized
INFO - 2020-09-11 11:22:33 --> Model Class Initialized
INFO - 2020-09-11 11:22:33 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:33 --> Total execution time: 0.0455
ERROR - 2020-09-11 11:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:22:55 --> Config Class Initialized
INFO - 2020-09-11 11:22:55 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:22:55 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:22:55 --> Utf8 Class Initialized
INFO - 2020-09-11 11:22:55 --> URI Class Initialized
INFO - 2020-09-11 11:22:55 --> Router Class Initialized
INFO - 2020-09-11 11:22:55 --> Output Class Initialized
INFO - 2020-09-11 11:22:55 --> Security Class Initialized
DEBUG - 2020-09-11 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:22:55 --> Input Class Initialized
INFO - 2020-09-11 11:22:55 --> Language Class Initialized
INFO - 2020-09-11 11:22:55 --> Loader Class Initialized
INFO - 2020-09-11 11:22:55 --> Helper loaded: url_helper
INFO - 2020-09-11 11:22:55 --> Database Driver Class Initialized
INFO - 2020-09-11 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:22:55 --> Email Class Initialized
INFO - 2020-09-11 11:22:55 --> Controller Class Initialized
DEBUG - 2020-09-11 11:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:22:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:22:55 --> Model Class Initialized
INFO - 2020-09-11 11:22:55 --> Model Class Initialized
INFO - 2020-09-11 11:22:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 11:22:55 --> Final output sent to browser
DEBUG - 2020-09-11 11:22:55 --> Total execution time: 0.0215
ERROR - 2020-09-11 11:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:23:32 --> Config Class Initialized
INFO - 2020-09-11 11:23:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:23:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:23:32 --> Utf8 Class Initialized
INFO - 2020-09-11 11:23:32 --> URI Class Initialized
INFO - 2020-09-11 11:23:32 --> Router Class Initialized
INFO - 2020-09-11 11:23:32 --> Output Class Initialized
INFO - 2020-09-11 11:23:32 --> Security Class Initialized
DEBUG - 2020-09-11 11:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:23:32 --> Input Class Initialized
INFO - 2020-09-11 11:23:32 --> Language Class Initialized
INFO - 2020-09-11 11:23:32 --> Loader Class Initialized
INFO - 2020-09-11 11:23:32 --> Helper loaded: url_helper
INFO - 2020-09-11 11:23:32 --> Database Driver Class Initialized
INFO - 2020-09-11 11:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:23:33 --> Email Class Initialized
INFO - 2020-09-11 11:23:33 --> Controller Class Initialized
DEBUG - 2020-09-11 11:23:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:23:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:23:33 --> Model Class Initialized
INFO - 2020-09-11 11:23:33 --> Model Class Initialized
INFO - 2020-09-11 11:23:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 11:23:33 --> Final output sent to browser
DEBUG - 2020-09-11 11:23:33 --> Total execution time: 0.4179
ERROR - 2020-09-11 11:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:23:52 --> Config Class Initialized
INFO - 2020-09-11 11:23:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:23:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:23:52 --> Utf8 Class Initialized
INFO - 2020-09-11 11:23:52 --> URI Class Initialized
INFO - 2020-09-11 11:23:52 --> Router Class Initialized
INFO - 2020-09-11 11:23:52 --> Output Class Initialized
INFO - 2020-09-11 11:23:52 --> Security Class Initialized
DEBUG - 2020-09-11 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:23:52 --> Input Class Initialized
INFO - 2020-09-11 11:23:52 --> Language Class Initialized
INFO - 2020-09-11 11:23:52 --> Loader Class Initialized
INFO - 2020-09-11 11:23:52 --> Helper loaded: url_helper
INFO - 2020-09-11 11:23:52 --> Database Driver Class Initialized
INFO - 2020-09-11 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:23:52 --> Email Class Initialized
INFO - 2020-09-11 11:23:52 --> Controller Class Initialized
DEBUG - 2020-09-11 11:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:23:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:23:52 --> Model Class Initialized
INFO - 2020-09-11 11:23:52 --> Model Class Initialized
INFO - 2020-09-11 11:23:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-11 11:23:52 --> Final output sent to browser
DEBUG - 2020-09-11 11:23:52 --> Total execution time: 0.1488
ERROR - 2020-09-11 11:25:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:25:55 --> Config Class Initialized
INFO - 2020-09-11 11:25:55 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:25:55 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:25:55 --> Utf8 Class Initialized
INFO - 2020-09-11 11:25:55 --> URI Class Initialized
DEBUG - 2020-09-11 11:25:55 --> No URI present. Default controller set.
INFO - 2020-09-11 11:25:55 --> Router Class Initialized
INFO - 2020-09-11 11:25:55 --> Output Class Initialized
INFO - 2020-09-11 11:25:55 --> Security Class Initialized
DEBUG - 2020-09-11 11:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:25:55 --> Input Class Initialized
INFO - 2020-09-11 11:25:55 --> Language Class Initialized
INFO - 2020-09-11 11:25:55 --> Loader Class Initialized
INFO - 2020-09-11 11:25:55 --> Helper loaded: url_helper
INFO - 2020-09-11 11:25:55 --> Database Driver Class Initialized
INFO - 2020-09-11 11:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:25:55 --> Email Class Initialized
INFO - 2020-09-11 11:25:55 --> Controller Class Initialized
INFO - 2020-09-11 11:25:55 --> Model Class Initialized
INFO - 2020-09-11 11:25:55 --> Model Class Initialized
DEBUG - 2020-09-11 11:25:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:25:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:25:55 --> Final output sent to browser
DEBUG - 2020-09-11 11:25:55 --> Total execution time: 0.0176
ERROR - 2020-09-11 11:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:25:56 --> Config Class Initialized
INFO - 2020-09-11 11:25:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:25:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:25:56 --> Utf8 Class Initialized
INFO - 2020-09-11 11:25:56 --> URI Class Initialized
DEBUG - 2020-09-11 11:25:56 --> No URI present. Default controller set.
INFO - 2020-09-11 11:25:56 --> Router Class Initialized
INFO - 2020-09-11 11:25:56 --> Output Class Initialized
INFO - 2020-09-11 11:25:56 --> Security Class Initialized
DEBUG - 2020-09-11 11:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:25:56 --> Input Class Initialized
INFO - 2020-09-11 11:25:56 --> Language Class Initialized
INFO - 2020-09-11 11:25:56 --> Loader Class Initialized
INFO - 2020-09-11 11:25:56 --> Helper loaded: url_helper
INFO - 2020-09-11 11:25:56 --> Database Driver Class Initialized
INFO - 2020-09-11 11:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:25:56 --> Email Class Initialized
INFO - 2020-09-11 11:25:56 --> Controller Class Initialized
INFO - 2020-09-11 11:25:56 --> Model Class Initialized
INFO - 2020-09-11 11:25:56 --> Model Class Initialized
DEBUG - 2020-09-11 11:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:25:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:25:56 --> Final output sent to browser
DEBUG - 2020-09-11 11:25:56 --> Total execution time: 0.0200
ERROR - 2020-09-11 11:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:26:17 --> Config Class Initialized
INFO - 2020-09-11 11:26:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:26:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:26:17 --> Utf8 Class Initialized
INFO - 2020-09-11 11:26:17 --> URI Class Initialized
INFO - 2020-09-11 11:26:17 --> Router Class Initialized
INFO - 2020-09-11 11:26:17 --> Output Class Initialized
INFO - 2020-09-11 11:26:17 --> Security Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:26:17 --> Input Class Initialized
INFO - 2020-09-11 11:26:17 --> Language Class Initialized
INFO - 2020-09-11 11:26:17 --> Loader Class Initialized
INFO - 2020-09-11 11:26:17 --> Helper loaded: url_helper
INFO - 2020-09-11 11:26:17 --> Database Driver Class Initialized
INFO - 2020-09-11 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:26:17 --> Email Class Initialized
INFO - 2020-09-11 11:26:17 --> Controller Class Initialized
INFO - 2020-09-11 11:26:17 --> Model Class Initialized
INFO - 2020-09-11 11:26:17 --> Model Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:26:17 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:26:17 --> Config Class Initialized
INFO - 2020-09-11 11:26:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:26:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:26:17 --> Utf8 Class Initialized
INFO - 2020-09-11 11:26:17 --> URI Class Initialized
INFO - 2020-09-11 11:26:17 --> Router Class Initialized
INFO - 2020-09-11 11:26:17 --> Output Class Initialized
INFO - 2020-09-11 11:26:17 --> Security Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:26:17 --> Input Class Initialized
INFO - 2020-09-11 11:26:17 --> Language Class Initialized
INFO - 2020-09-11 11:26:17 --> Loader Class Initialized
INFO - 2020-09-11 11:26:17 --> Helper loaded: url_helper
INFO - 2020-09-11 11:26:17 --> Database Driver Class Initialized
INFO - 2020-09-11 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:26:17 --> Email Class Initialized
INFO - 2020-09-11 11:26:17 --> Controller Class Initialized
INFO - 2020-09-11 11:26:17 --> Model Class Initialized
INFO - 2020-09-11 11:26:17 --> Model Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:26:17 --> Config Class Initialized
INFO - 2020-09-11 11:26:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:26:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:26:17 --> Utf8 Class Initialized
INFO - 2020-09-11 11:26:17 --> URI Class Initialized
DEBUG - 2020-09-11 11:26:17 --> No URI present. Default controller set.
INFO - 2020-09-11 11:26:17 --> Router Class Initialized
INFO - 2020-09-11 11:26:17 --> Output Class Initialized
INFO - 2020-09-11 11:26:17 --> Security Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:26:17 --> Input Class Initialized
INFO - 2020-09-11 11:26:17 --> Language Class Initialized
INFO - 2020-09-11 11:26:17 --> Loader Class Initialized
INFO - 2020-09-11 11:26:17 --> Helper loaded: url_helper
INFO - 2020-09-11 11:26:17 --> Database Driver Class Initialized
INFO - 2020-09-11 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:26:17 --> Email Class Initialized
INFO - 2020-09-11 11:26:17 --> Controller Class Initialized
INFO - 2020-09-11 11:26:17 --> Model Class Initialized
INFO - 2020-09-11 11:26:17 --> Model Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:26:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:26:17 --> Final output sent to browser
DEBUG - 2020-09-11 11:26:17 --> Total execution time: 0.0222
ERROR - 2020-09-11 11:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:26:17 --> Config Class Initialized
INFO - 2020-09-11 11:26:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:26:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:26:17 --> Utf8 Class Initialized
INFO - 2020-09-11 11:26:17 --> URI Class Initialized
INFO - 2020-09-11 11:26:17 --> Router Class Initialized
INFO - 2020-09-11 11:26:17 --> Output Class Initialized
INFO - 2020-09-11 11:26:17 --> Security Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:26:17 --> Input Class Initialized
INFO - 2020-09-11 11:26:17 --> Language Class Initialized
INFO - 2020-09-11 11:26:17 --> Loader Class Initialized
INFO - 2020-09-11 11:26:17 --> Helper loaded: url_helper
INFO - 2020-09-11 11:26:17 --> Database Driver Class Initialized
INFO - 2020-09-11 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:26:17 --> Email Class Initialized
INFO - 2020-09-11 11:26:17 --> Controller Class Initialized
DEBUG - 2020-09-11 11:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:26:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:26:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 11:26:17 --> Final output sent to browser
DEBUG - 2020-09-11 11:26:17 --> Total execution time: 0.0380
ERROR - 2020-09-11 11:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:26:31 --> Config Class Initialized
INFO - 2020-09-11 11:26:31 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:26:31 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:26:31 --> Utf8 Class Initialized
INFO - 2020-09-11 11:26:31 --> URI Class Initialized
INFO - 2020-09-11 11:26:31 --> Router Class Initialized
INFO - 2020-09-11 11:26:31 --> Output Class Initialized
INFO - 2020-09-11 11:26:31 --> Security Class Initialized
DEBUG - 2020-09-11 11:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:26:31 --> Input Class Initialized
INFO - 2020-09-11 11:26:31 --> Language Class Initialized
INFO - 2020-09-11 11:26:31 --> Loader Class Initialized
INFO - 2020-09-11 11:26:31 --> Helper loaded: url_helper
INFO - 2020-09-11 11:26:31 --> Database Driver Class Initialized
INFO - 2020-09-11 11:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:26:31 --> Email Class Initialized
INFO - 2020-09-11 11:26:31 --> Controller Class Initialized
DEBUG - 2020-09-11 11:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:26:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:26:31 --> Model Class Initialized
INFO - 2020-09-11 11:26:31 --> Model Class Initialized
INFO - 2020-09-11 11:26:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 11:26:31 --> Final output sent to browser
DEBUG - 2020-09-11 11:26:31 --> Total execution time: 0.0461
ERROR - 2020-09-11 11:26:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:26:40 --> Config Class Initialized
INFO - 2020-09-11 11:26:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:26:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:26:40 --> Utf8 Class Initialized
INFO - 2020-09-11 11:26:40 --> URI Class Initialized
INFO - 2020-09-11 11:26:40 --> Router Class Initialized
INFO - 2020-09-11 11:26:40 --> Output Class Initialized
INFO - 2020-09-11 11:26:40 --> Security Class Initialized
DEBUG - 2020-09-11 11:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:26:40 --> Input Class Initialized
INFO - 2020-09-11 11:26:40 --> Language Class Initialized
INFO - 2020-09-11 11:26:40 --> Loader Class Initialized
INFO - 2020-09-11 11:26:40 --> Helper loaded: url_helper
INFO - 2020-09-11 11:26:40 --> Database Driver Class Initialized
INFO - 2020-09-11 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:26:40 --> Email Class Initialized
INFO - 2020-09-11 11:26:40 --> Controller Class Initialized
DEBUG - 2020-09-11 11:26:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:26:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:26:40 --> Model Class Initialized
INFO - 2020-09-11 11:26:40 --> Model Class Initialized
INFO - 2020-09-11 11:26:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-11 11:26:40 --> Final output sent to browser
DEBUG - 2020-09-11 11:26:40 --> Total execution time: 0.0341
ERROR - 2020-09-11 11:27:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:27:56 --> Config Class Initialized
INFO - 2020-09-11 11:27:56 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:27:56 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:27:56 --> Utf8 Class Initialized
INFO - 2020-09-11 11:27:56 --> URI Class Initialized
INFO - 2020-09-11 11:27:56 --> Router Class Initialized
INFO - 2020-09-11 11:27:56 --> Output Class Initialized
INFO - 2020-09-11 11:27:56 --> Security Class Initialized
DEBUG - 2020-09-11 11:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:27:56 --> Input Class Initialized
INFO - 2020-09-11 11:27:56 --> Language Class Initialized
INFO - 2020-09-11 11:27:56 --> Loader Class Initialized
INFO - 2020-09-11 11:27:56 --> Helper loaded: url_helper
INFO - 2020-09-11 11:27:56 --> Database Driver Class Initialized
INFO - 2020-09-11 11:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:27:56 --> Email Class Initialized
INFO - 2020-09-11 11:27:56 --> Controller Class Initialized
DEBUG - 2020-09-11 11:27:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:27:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:27:56 --> Model Class Initialized
INFO - 2020-09-11 11:27:56 --> Model Class Initialized
INFO - 2020-09-11 11:27:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 11:27:56 --> Final output sent to browser
DEBUG - 2020-09-11 11:27:56 --> Total execution time: 0.0229
ERROR - 2020-09-11 11:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:27:58 --> Config Class Initialized
INFO - 2020-09-11 11:27:58 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:27:58 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:27:58 --> Utf8 Class Initialized
INFO - 2020-09-11 11:27:58 --> URI Class Initialized
INFO - 2020-09-11 11:27:58 --> Router Class Initialized
INFO - 2020-09-11 11:27:58 --> Output Class Initialized
INFO - 2020-09-11 11:27:58 --> Security Class Initialized
DEBUG - 2020-09-11 11:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:27:58 --> Input Class Initialized
INFO - 2020-09-11 11:27:58 --> Language Class Initialized
INFO - 2020-09-11 11:27:58 --> Loader Class Initialized
INFO - 2020-09-11 11:27:58 --> Helper loaded: url_helper
INFO - 2020-09-11 11:27:58 --> Database Driver Class Initialized
INFO - 2020-09-11 11:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:27:58 --> Email Class Initialized
INFO - 2020-09-11 11:27:58 --> Controller Class Initialized
DEBUG - 2020-09-11 11:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:27:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:27:58 --> Model Class Initialized
INFO - 2020-09-11 11:27:58 --> Model Class Initialized
INFO - 2020-09-11 11:27:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-11 11:27:58 --> Final output sent to browser
DEBUG - 2020-09-11 11:27:58 --> Total execution time: 0.0371
ERROR - 2020-09-11 11:28:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:28:06 --> Config Class Initialized
INFO - 2020-09-11 11:28:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:28:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:28:06 --> Utf8 Class Initialized
INFO - 2020-09-11 11:28:06 --> URI Class Initialized
INFO - 2020-09-11 11:28:06 --> Router Class Initialized
INFO - 2020-09-11 11:28:06 --> Output Class Initialized
INFO - 2020-09-11 11:28:06 --> Security Class Initialized
DEBUG - 2020-09-11 11:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:28:06 --> Input Class Initialized
INFO - 2020-09-11 11:28:06 --> Language Class Initialized
INFO - 2020-09-11 11:28:06 --> Loader Class Initialized
INFO - 2020-09-11 11:28:06 --> Helper loaded: url_helper
INFO - 2020-09-11 11:28:06 --> Database Driver Class Initialized
INFO - 2020-09-11 11:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:28:06 --> Email Class Initialized
INFO - 2020-09-11 11:28:06 --> Controller Class Initialized
DEBUG - 2020-09-11 11:28:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:28:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:28:06 --> Model Class Initialized
INFO - 2020-09-11 11:28:06 --> Model Class Initialized
INFO - 2020-09-11 11:28:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 11:28:06 --> Final output sent to browser
DEBUG - 2020-09-11 11:28:06 --> Total execution time: 0.0222
ERROR - 2020-09-11 11:28:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:28:14 --> Config Class Initialized
INFO - 2020-09-11 11:28:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:28:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:28:14 --> Utf8 Class Initialized
INFO - 2020-09-11 11:28:14 --> URI Class Initialized
DEBUG - 2020-09-11 11:28:14 --> No URI present. Default controller set.
INFO - 2020-09-11 11:28:14 --> Router Class Initialized
INFO - 2020-09-11 11:28:14 --> Output Class Initialized
INFO - 2020-09-11 11:28:14 --> Security Class Initialized
DEBUG - 2020-09-11 11:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:28:14 --> Input Class Initialized
INFO - 2020-09-11 11:28:14 --> Language Class Initialized
INFO - 2020-09-11 11:28:14 --> Loader Class Initialized
INFO - 2020-09-11 11:28:14 --> Helper loaded: url_helper
INFO - 2020-09-11 11:28:14 --> Database Driver Class Initialized
INFO - 2020-09-11 11:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:28:14 --> Email Class Initialized
INFO - 2020-09-11 11:28:14 --> Controller Class Initialized
INFO - 2020-09-11 11:28:14 --> Model Class Initialized
INFO - 2020-09-11 11:28:14 --> Model Class Initialized
DEBUG - 2020-09-11 11:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:28:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:28:14 --> Final output sent to browser
DEBUG - 2020-09-11 11:28:14 --> Total execution time: 0.0201
ERROR - 2020-09-11 11:29:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:29:05 --> Config Class Initialized
INFO - 2020-09-11 11:29:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:29:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:29:05 --> Utf8 Class Initialized
INFO - 2020-09-11 11:29:05 --> URI Class Initialized
DEBUG - 2020-09-11 11:29:05 --> No URI present. Default controller set.
INFO - 2020-09-11 11:29:05 --> Router Class Initialized
INFO - 2020-09-11 11:29:05 --> Output Class Initialized
INFO - 2020-09-11 11:29:05 --> Security Class Initialized
DEBUG - 2020-09-11 11:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:29:05 --> Input Class Initialized
INFO - 2020-09-11 11:29:05 --> Language Class Initialized
INFO - 2020-09-11 11:29:05 --> Loader Class Initialized
INFO - 2020-09-11 11:29:05 --> Helper loaded: url_helper
INFO - 2020-09-11 11:29:05 --> Database Driver Class Initialized
INFO - 2020-09-11 11:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:29:05 --> Email Class Initialized
INFO - 2020-09-11 11:29:05 --> Controller Class Initialized
INFO - 2020-09-11 11:29:05 --> Model Class Initialized
INFO - 2020-09-11 11:29:05 --> Model Class Initialized
DEBUG - 2020-09-11 11:29:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:29:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:29:05 --> Final output sent to browser
DEBUG - 2020-09-11 11:29:05 --> Total execution time: 0.0175
ERROR - 2020-09-11 11:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:29:50 --> Config Class Initialized
INFO - 2020-09-11 11:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:29:50 --> Utf8 Class Initialized
INFO - 2020-09-11 11:29:50 --> URI Class Initialized
DEBUG - 2020-09-11 11:29:50 --> No URI present. Default controller set.
INFO - 2020-09-11 11:29:50 --> Router Class Initialized
INFO - 2020-09-11 11:29:50 --> Output Class Initialized
INFO - 2020-09-11 11:29:50 --> Security Class Initialized
DEBUG - 2020-09-11 11:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:29:50 --> Input Class Initialized
INFO - 2020-09-11 11:29:50 --> Language Class Initialized
INFO - 2020-09-11 11:29:50 --> Loader Class Initialized
INFO - 2020-09-11 11:29:50 --> Helper loaded: url_helper
INFO - 2020-09-11 11:29:50 --> Database Driver Class Initialized
INFO - 2020-09-11 11:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:29:50 --> Email Class Initialized
INFO - 2020-09-11 11:29:50 --> Controller Class Initialized
INFO - 2020-09-11 11:29:50 --> Model Class Initialized
INFO - 2020-09-11 11:29:50 --> Model Class Initialized
DEBUG - 2020-09-11 11:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:29:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:29:50 --> Final output sent to browser
DEBUG - 2020-09-11 11:29:50 --> Total execution time: 0.0212
ERROR - 2020-09-11 11:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:30:01 --> Config Class Initialized
INFO - 2020-09-11 11:30:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:30:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:30:01 --> Utf8 Class Initialized
INFO - 2020-09-11 11:30:01 --> URI Class Initialized
INFO - 2020-09-11 11:30:01 --> Router Class Initialized
INFO - 2020-09-11 11:30:01 --> Output Class Initialized
INFO - 2020-09-11 11:30:01 --> Security Class Initialized
DEBUG - 2020-09-11 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:30:01 --> Input Class Initialized
INFO - 2020-09-11 11:30:01 --> Language Class Initialized
INFO - 2020-09-11 11:30:01 --> Loader Class Initialized
INFO - 2020-09-11 11:30:01 --> Helper loaded: url_helper
INFO - 2020-09-11 11:30:01 --> Database Driver Class Initialized
INFO - 2020-09-11 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:30:01 --> Email Class Initialized
INFO - 2020-09-11 11:30:01 --> Controller Class Initialized
INFO - 2020-09-11 11:30:01 --> Model Class Initialized
INFO - 2020-09-11 11:30:01 --> Model Class Initialized
DEBUG - 2020-09-11 11:30:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:30:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:30:01 --> Model Class Initialized
INFO - 2020-09-11 11:30:01 --> Final output sent to browser
DEBUG - 2020-09-11 11:30:01 --> Total execution time: 0.0240
ERROR - 2020-09-11 11:30:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:30:01 --> Config Class Initialized
INFO - 2020-09-11 11:30:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:30:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:30:01 --> Utf8 Class Initialized
INFO - 2020-09-11 11:30:01 --> URI Class Initialized
INFO - 2020-09-11 11:30:01 --> Router Class Initialized
INFO - 2020-09-11 11:30:01 --> Output Class Initialized
INFO - 2020-09-11 11:30:01 --> Security Class Initialized
DEBUG - 2020-09-11 11:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:30:01 --> Input Class Initialized
INFO - 2020-09-11 11:30:01 --> Language Class Initialized
INFO - 2020-09-11 11:30:01 --> Loader Class Initialized
INFO - 2020-09-11 11:30:01 --> Helper loaded: url_helper
INFO - 2020-09-11 11:30:01 --> Database Driver Class Initialized
INFO - 2020-09-11 11:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:30:01 --> Email Class Initialized
INFO - 2020-09-11 11:30:01 --> Controller Class Initialized
INFO - 2020-09-11 11:30:01 --> Model Class Initialized
INFO - 2020-09-11 11:30:01 --> Model Class Initialized
DEBUG - 2020-09-11 11:30:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:30:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:30:02 --> Config Class Initialized
INFO - 2020-09-11 11:30:02 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:30:02 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:30:02 --> Utf8 Class Initialized
INFO - 2020-09-11 11:30:02 --> URI Class Initialized
INFO - 2020-09-11 11:30:02 --> Router Class Initialized
INFO - 2020-09-11 11:30:02 --> Output Class Initialized
INFO - 2020-09-11 11:30:02 --> Security Class Initialized
DEBUG - 2020-09-11 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:30:02 --> Input Class Initialized
INFO - 2020-09-11 11:30:02 --> Language Class Initialized
INFO - 2020-09-11 11:30:02 --> Loader Class Initialized
INFO - 2020-09-11 11:30:02 --> Helper loaded: url_helper
INFO - 2020-09-11 11:30:02 --> Database Driver Class Initialized
INFO - 2020-09-11 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:30:02 --> Email Class Initialized
INFO - 2020-09-11 11:30:02 --> Controller Class Initialized
DEBUG - 2020-09-11 11:30:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:30:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:30:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 11:30:02 --> Final output sent to browser
DEBUG - 2020-09-11 11:30:02 --> Total execution time: 0.0329
ERROR - 2020-09-11 11:30:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:30:07 --> Config Class Initialized
INFO - 2020-09-11 11:30:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:30:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:30:07 --> Utf8 Class Initialized
INFO - 2020-09-11 11:30:07 --> URI Class Initialized
INFO - 2020-09-11 11:30:07 --> Router Class Initialized
INFO - 2020-09-11 11:30:07 --> Output Class Initialized
INFO - 2020-09-11 11:30:07 --> Security Class Initialized
DEBUG - 2020-09-11 11:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:30:07 --> Input Class Initialized
INFO - 2020-09-11 11:30:07 --> Language Class Initialized
INFO - 2020-09-11 11:30:07 --> Loader Class Initialized
INFO - 2020-09-11 11:30:07 --> Helper loaded: url_helper
INFO - 2020-09-11 11:30:07 --> Database Driver Class Initialized
INFO - 2020-09-11 11:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:30:07 --> Email Class Initialized
INFO - 2020-09-11 11:30:07 --> Controller Class Initialized
DEBUG - 2020-09-11 11:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:30:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:30:07 --> Model Class Initialized
INFO - 2020-09-11 11:30:07 --> Model Class Initialized
INFO - 2020-09-11 11:30:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 11:30:07 --> Final output sent to browser
DEBUG - 2020-09-11 11:30:07 --> Total execution time: 0.0195
ERROR - 2020-09-11 11:30:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:30:10 --> Config Class Initialized
INFO - 2020-09-11 11:30:10 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:30:10 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:30:10 --> Utf8 Class Initialized
INFO - 2020-09-11 11:30:10 --> URI Class Initialized
INFO - 2020-09-11 11:30:10 --> Router Class Initialized
INFO - 2020-09-11 11:30:10 --> Output Class Initialized
INFO - 2020-09-11 11:30:10 --> Security Class Initialized
DEBUG - 2020-09-11 11:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:30:10 --> Input Class Initialized
INFO - 2020-09-11 11:30:10 --> Language Class Initialized
INFO - 2020-09-11 11:30:10 --> Loader Class Initialized
INFO - 2020-09-11 11:30:10 --> Helper loaded: url_helper
INFO - 2020-09-11 11:30:10 --> Database Driver Class Initialized
INFO - 2020-09-11 11:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:30:10 --> Email Class Initialized
INFO - 2020-09-11 11:30:10 --> Controller Class Initialized
DEBUG - 2020-09-11 11:30:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:30:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:30:10 --> Model Class Initialized
INFO - 2020-09-11 11:30:10 --> Model Class Initialized
INFO - 2020-09-11 11:30:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-11 11:30:10 --> Final output sent to browser
DEBUG - 2020-09-11 11:30:10 --> Total execution time: 0.0187
ERROR - 2020-09-11 11:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:30:33 --> Config Class Initialized
INFO - 2020-09-11 11:30:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:30:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:30:33 --> Utf8 Class Initialized
INFO - 2020-09-11 11:30:33 --> URI Class Initialized
INFO - 2020-09-11 11:30:33 --> Router Class Initialized
INFO - 2020-09-11 11:30:33 --> Output Class Initialized
INFO - 2020-09-11 11:30:33 --> Security Class Initialized
DEBUG - 2020-09-11 11:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:30:33 --> Input Class Initialized
INFO - 2020-09-11 11:30:33 --> Language Class Initialized
INFO - 2020-09-11 11:30:33 --> Loader Class Initialized
INFO - 2020-09-11 11:30:33 --> Helper loaded: url_helper
INFO - 2020-09-11 11:30:33 --> Database Driver Class Initialized
INFO - 2020-09-11 11:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:30:33 --> Email Class Initialized
INFO - 2020-09-11 11:30:33 --> Controller Class Initialized
DEBUG - 2020-09-11 11:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:30:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:30:33 --> Model Class Initialized
INFO - 2020-09-11 11:30:33 --> Model Class Initialized
INFO - 2020-09-11 11:30:33 --> Model Class Initialized
INFO - 2020-09-11 11:30:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 11:30:33 --> Final output sent to browser
DEBUG - 2020-09-11 11:30:33 --> Total execution time: 0.0824
ERROR - 2020-09-11 11:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:07 --> Config Class Initialized
INFO - 2020-09-11 11:31:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:07 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:07 --> URI Class Initialized
INFO - 2020-09-11 11:31:07 --> Router Class Initialized
INFO - 2020-09-11 11:31:07 --> Output Class Initialized
INFO - 2020-09-11 11:31:07 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:07 --> Input Class Initialized
INFO - 2020-09-11 11:31:07 --> Language Class Initialized
INFO - 2020-09-11 11:31:07 --> Loader Class Initialized
INFO - 2020-09-11 11:31:07 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:07 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:07 --> Email Class Initialized
INFO - 2020-09-11 11:31:07 --> Controller Class Initialized
DEBUG - 2020-09-11 11:31:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:07 --> Model Class Initialized
INFO - 2020-09-11 11:31:07 --> Model Class Initialized
INFO - 2020-09-11 11:31:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-11 11:31:07 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:07 --> Total execution time: 0.0244
ERROR - 2020-09-11 11:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:27 --> Config Class Initialized
INFO - 2020-09-11 11:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:27 --> URI Class Initialized
INFO - 2020-09-11 11:31:27 --> Router Class Initialized
INFO - 2020-09-11 11:31:27 --> Output Class Initialized
INFO - 2020-09-11 11:31:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:27 --> Input Class Initialized
INFO - 2020-09-11 11:31:27 --> Language Class Initialized
INFO - 2020-09-11 11:31:27 --> Loader Class Initialized
INFO - 2020-09-11 11:31:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:27 --> Email Class Initialized
INFO - 2020-09-11 11:31:27 --> Controller Class Initialized
INFO - 2020-09-11 11:31:27 --> Model Class Initialized
INFO - 2020-09-11 11:31:27 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:27 --> Config Class Initialized
INFO - 2020-09-11 11:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:27 --> URI Class Initialized
INFO - 2020-09-11 11:31:27 --> Router Class Initialized
INFO - 2020-09-11 11:31:27 --> Output Class Initialized
INFO - 2020-09-11 11:31:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:27 --> Input Class Initialized
INFO - 2020-09-11 11:31:27 --> Language Class Initialized
INFO - 2020-09-11 11:31:27 --> Loader Class Initialized
INFO - 2020-09-11 11:31:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:27 --> Email Class Initialized
INFO - 2020-09-11 11:31:27 --> Controller Class Initialized
INFO - 2020-09-11 11:31:27 --> Model Class Initialized
INFO - 2020-09-11 11:31:27 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:27 --> Model Class Initialized
INFO - 2020-09-11 11:31:27 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:27 --> Total execution time: 0.0298
ERROR - 2020-09-11 11:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:27 --> Config Class Initialized
INFO - 2020-09-11 11:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:27 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:27 --> URI Class Initialized
INFO - 2020-09-11 11:31:27 --> Router Class Initialized
INFO - 2020-09-11 11:31:27 --> Output Class Initialized
INFO - 2020-09-11 11:31:27 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:27 --> Input Class Initialized
INFO - 2020-09-11 11:31:27 --> Language Class Initialized
INFO - 2020-09-11 11:31:27 --> Loader Class Initialized
INFO - 2020-09-11 11:31:27 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:27 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:27 --> Email Class Initialized
INFO - 2020-09-11 11:31:27 --> Controller Class Initialized
DEBUG - 2020-09-11 11:31:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 11:31:27 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:27 --> Total execution time: 0.0214
ERROR - 2020-09-11 11:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:28 --> Config Class Initialized
INFO - 2020-09-11 11:31:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:28 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:28 --> URI Class Initialized
INFO - 2020-09-11 11:31:28 --> Router Class Initialized
INFO - 2020-09-11 11:31:28 --> Output Class Initialized
INFO - 2020-09-11 11:31:28 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:28 --> Input Class Initialized
INFO - 2020-09-11 11:31:28 --> Language Class Initialized
INFO - 2020-09-11 11:31:28 --> Loader Class Initialized
INFO - 2020-09-11 11:31:28 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:28 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:28 --> Email Class Initialized
INFO - 2020-09-11 11:31:28 --> Controller Class Initialized
INFO - 2020-09-11 11:31:28 --> Model Class Initialized
INFO - 2020-09-11 11:31:28 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:28 --> Model Class Initialized
INFO - 2020-09-11 11:31:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-09-11 11:31:28 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:28 --> Total execution time: 0.0317
ERROR - 2020-09-11 11:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:33 --> Config Class Initialized
INFO - 2020-09-11 11:31:33 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:33 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:33 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:33 --> URI Class Initialized
INFO - 2020-09-11 11:31:33 --> Router Class Initialized
INFO - 2020-09-11 11:31:33 --> Output Class Initialized
INFO - 2020-09-11 11:31:33 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:33 --> Input Class Initialized
INFO - 2020-09-11 11:31:33 --> Language Class Initialized
INFO - 2020-09-11 11:31:33 --> Loader Class Initialized
INFO - 2020-09-11 11:31:33 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:33 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:33 --> Email Class Initialized
INFO - 2020-09-11 11:31:33 --> Controller Class Initialized
INFO - 2020-09-11 11:31:33 --> Model Class Initialized
INFO - 2020-09-11 11:31:33 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:33 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:31:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:34 --> Config Class Initialized
INFO - 2020-09-11 11:31:34 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:34 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:34 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:34 --> URI Class Initialized
INFO - 2020-09-11 11:31:34 --> Router Class Initialized
INFO - 2020-09-11 11:31:34 --> Output Class Initialized
INFO - 2020-09-11 11:31:34 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:34 --> Input Class Initialized
INFO - 2020-09-11 11:31:34 --> Language Class Initialized
INFO - 2020-09-11 11:31:34 --> Loader Class Initialized
INFO - 2020-09-11 11:31:34 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:34 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:34 --> Email Class Initialized
INFO - 2020-09-11 11:31:34 --> Controller Class Initialized
INFO - 2020-09-11 11:31:34 --> Model Class Initialized
INFO - 2020-09-11 11:31:34 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:34 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:31:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:34 --> Config Class Initialized
INFO - 2020-09-11 11:31:34 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:34 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:34 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:34 --> URI Class Initialized
DEBUG - 2020-09-11 11:31:34 --> No URI present. Default controller set.
INFO - 2020-09-11 11:31:34 --> Router Class Initialized
INFO - 2020-09-11 11:31:34 --> Output Class Initialized
INFO - 2020-09-11 11:31:34 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:34 --> Input Class Initialized
INFO - 2020-09-11 11:31:34 --> Language Class Initialized
INFO - 2020-09-11 11:31:34 --> Loader Class Initialized
INFO - 2020-09-11 11:31:34 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:34 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:34 --> Email Class Initialized
INFO - 2020-09-11 11:31:34 --> Controller Class Initialized
INFO - 2020-09-11 11:31:34 --> Model Class Initialized
INFO - 2020-09-11 11:31:34 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:31:34 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:34 --> Total execution time: 0.0181
ERROR - 2020-09-11 11:31:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:34 --> Config Class Initialized
INFO - 2020-09-11 11:31:34 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:34 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:34 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:34 --> URI Class Initialized
DEBUG - 2020-09-11 11:31:34 --> No URI present. Default controller set.
INFO - 2020-09-11 11:31:34 --> Router Class Initialized
INFO - 2020-09-11 11:31:34 --> Output Class Initialized
INFO - 2020-09-11 11:31:34 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:34 --> Input Class Initialized
INFO - 2020-09-11 11:31:34 --> Language Class Initialized
INFO - 2020-09-11 11:31:34 --> Loader Class Initialized
INFO - 2020-09-11 11:31:34 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:34 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:34 --> Email Class Initialized
INFO - 2020-09-11 11:31:34 --> Controller Class Initialized
INFO - 2020-09-11 11:31:34 --> Model Class Initialized
INFO - 2020-09-11 11:31:34 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:31:34 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:34 --> Total execution time: 0.0201
ERROR - 2020-09-11 11:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:52 --> Config Class Initialized
INFO - 2020-09-11 11:31:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:52 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:52 --> URI Class Initialized
INFO - 2020-09-11 11:31:52 --> Router Class Initialized
INFO - 2020-09-11 11:31:52 --> Output Class Initialized
INFO - 2020-09-11 11:31:52 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:52 --> Input Class Initialized
INFO - 2020-09-11 11:31:52 --> Language Class Initialized
INFO - 2020-09-11 11:31:52 --> Loader Class Initialized
INFO - 2020-09-11 11:31:52 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:52 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:52 --> Email Class Initialized
INFO - 2020-09-11 11:31:52 --> Controller Class Initialized
INFO - 2020-09-11 11:31:52 --> Model Class Initialized
INFO - 2020-09-11 11:31:52 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:31:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:52 --> Model Class Initialized
ERROR - 2020-09-11 11:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:31:52 --> Config Class Initialized
INFO - 2020-09-11 11:31:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:31:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:31:52 --> Utf8 Class Initialized
INFO - 2020-09-11 11:31:52 --> URI Class Initialized
DEBUG - 2020-09-11 11:31:52 --> No URI present. Default controller set.
INFO - 2020-09-11 11:31:52 --> Router Class Initialized
INFO - 2020-09-11 11:31:52 --> Output Class Initialized
INFO - 2020-09-11 11:31:52 --> Security Class Initialized
DEBUG - 2020-09-11 11:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:31:52 --> Input Class Initialized
INFO - 2020-09-11 11:31:52 --> Language Class Initialized
INFO - 2020-09-11 11:31:52 --> Loader Class Initialized
INFO - 2020-09-11 11:31:52 --> Helper loaded: url_helper
INFO - 2020-09-11 11:31:52 --> Database Driver Class Initialized
INFO - 2020-09-11 11:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:31:52 --> Email Class Initialized
INFO - 2020-09-11 11:31:52 --> Controller Class Initialized
INFO - 2020-09-11 11:31:52 --> Model Class Initialized
INFO - 2020-09-11 11:31:52 --> Model Class Initialized
DEBUG - 2020-09-11 11:31:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:31:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:31:52 --> Final output sent to browser
DEBUG - 2020-09-11 11:31:52 --> Total execution time: 0.0171
ERROR - 2020-09-11 11:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:32:05 --> Config Class Initialized
INFO - 2020-09-11 11:32:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:32:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:32:05 --> Utf8 Class Initialized
INFO - 2020-09-11 11:32:05 --> URI Class Initialized
INFO - 2020-09-11 11:32:05 --> Router Class Initialized
INFO - 2020-09-11 11:32:05 --> Output Class Initialized
INFO - 2020-09-11 11:32:05 --> Security Class Initialized
DEBUG - 2020-09-11 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:32:05 --> Input Class Initialized
INFO - 2020-09-11 11:32:05 --> Language Class Initialized
INFO - 2020-09-11 11:32:05 --> Loader Class Initialized
INFO - 2020-09-11 11:32:05 --> Helper loaded: url_helper
INFO - 2020-09-11 11:32:05 --> Database Driver Class Initialized
INFO - 2020-09-11 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:32:05 --> Email Class Initialized
INFO - 2020-09-11 11:32:05 --> Controller Class Initialized
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
DEBUG - 2020-09-11 11:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:32:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
INFO - 2020-09-11 11:32:05 --> Final output sent to browser
DEBUG - 2020-09-11 11:32:05 --> Total execution time: 0.0216
ERROR - 2020-09-11 11:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:32:05 --> Config Class Initialized
INFO - 2020-09-11 11:32:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:32:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:32:05 --> Utf8 Class Initialized
INFO - 2020-09-11 11:32:05 --> URI Class Initialized
INFO - 2020-09-11 11:32:05 --> Router Class Initialized
INFO - 2020-09-11 11:32:05 --> Output Class Initialized
INFO - 2020-09-11 11:32:05 --> Security Class Initialized
DEBUG - 2020-09-11 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:32:05 --> Input Class Initialized
INFO - 2020-09-11 11:32:05 --> Language Class Initialized
INFO - 2020-09-11 11:32:05 --> Loader Class Initialized
INFO - 2020-09-11 11:32:05 --> Helper loaded: url_helper
INFO - 2020-09-11 11:32:05 --> Database Driver Class Initialized
INFO - 2020-09-11 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:32:05 --> Email Class Initialized
INFO - 2020-09-11 11:32:05 --> Controller Class Initialized
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
DEBUG - 2020-09-11 11:32:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 11:32:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:32:05 --> Config Class Initialized
INFO - 2020-09-11 11:32:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:32:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:32:05 --> Utf8 Class Initialized
INFO - 2020-09-11 11:32:05 --> URI Class Initialized
INFO - 2020-09-11 11:32:05 --> Router Class Initialized
INFO - 2020-09-11 11:32:05 --> Output Class Initialized
INFO - 2020-09-11 11:32:05 --> Security Class Initialized
DEBUG - 2020-09-11 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:32:05 --> Input Class Initialized
INFO - 2020-09-11 11:32:05 --> Language Class Initialized
INFO - 2020-09-11 11:32:05 --> Loader Class Initialized
INFO - 2020-09-11 11:32:05 --> Helper loaded: url_helper
INFO - 2020-09-11 11:32:05 --> Database Driver Class Initialized
INFO - 2020-09-11 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:32:05 --> Email Class Initialized
INFO - 2020-09-11 11:32:05 --> Controller Class Initialized
DEBUG - 2020-09-11 11:32:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:32:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
INFO - 2020-09-11 11:32:05 --> Model Class Initialized
INFO - 2020-09-11 11:32:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 11:32:05 --> Final output sent to browser
DEBUG - 2020-09-11 11:32:05 --> Total execution time: 0.0216
ERROR - 2020-09-11 11:32:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:32:17 --> Config Class Initialized
INFO - 2020-09-11 11:32:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:32:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:32:17 --> Utf8 Class Initialized
INFO - 2020-09-11 11:32:17 --> URI Class Initialized
INFO - 2020-09-11 11:32:17 --> Router Class Initialized
INFO - 2020-09-11 11:32:17 --> Output Class Initialized
INFO - 2020-09-11 11:32:17 --> Security Class Initialized
DEBUG - 2020-09-11 11:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:32:17 --> Input Class Initialized
INFO - 2020-09-11 11:32:17 --> Language Class Initialized
INFO - 2020-09-11 11:32:17 --> Loader Class Initialized
INFO - 2020-09-11 11:32:17 --> Helper loaded: url_helper
INFO - 2020-09-11 11:32:17 --> Database Driver Class Initialized
INFO - 2020-09-11 11:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:32:17 --> Email Class Initialized
INFO - 2020-09-11 11:32:17 --> Controller Class Initialized
DEBUG - 2020-09-11 11:32:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:32:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:32:17 --> Model Class Initialized
INFO - 2020-09-11 11:32:17 --> Model Class Initialized
INFO - 2020-09-11 11:32:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-09-11 11:32:17 --> Final output sent to browser
DEBUG - 2020-09-11 11:32:17 --> Total execution time: 0.0265
ERROR - 2020-09-11 11:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:32:25 --> Config Class Initialized
INFO - 2020-09-11 11:32:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:32:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:32:25 --> Utf8 Class Initialized
INFO - 2020-09-11 11:32:25 --> URI Class Initialized
INFO - 2020-09-11 11:32:25 --> Router Class Initialized
INFO - 2020-09-11 11:32:25 --> Output Class Initialized
INFO - 2020-09-11 11:32:25 --> Security Class Initialized
DEBUG - 2020-09-11 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:32:25 --> Input Class Initialized
INFO - 2020-09-11 11:32:25 --> Language Class Initialized
INFO - 2020-09-11 11:32:25 --> Loader Class Initialized
INFO - 2020-09-11 11:32:25 --> Helper loaded: url_helper
INFO - 2020-09-11 11:32:25 --> Database Driver Class Initialized
INFO - 2020-09-11 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:32:25 --> Email Class Initialized
INFO - 2020-09-11 11:32:25 --> Controller Class Initialized
DEBUG - 2020-09-11 11:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 11:32:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:32:25 --> Model Class Initialized
INFO - 2020-09-11 11:32:25 --> Model Class Initialized
INFO - 2020-09-11 11:32:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 11:32:25 --> Final output sent to browser
DEBUG - 2020-09-11 11:32:25 --> Total execution time: 0.0194
ERROR - 2020-09-11 11:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 11:32:39 --> Config Class Initialized
INFO - 2020-09-11 11:32:39 --> Hooks Class Initialized
DEBUG - 2020-09-11 11:32:39 --> UTF-8 Support Enabled
INFO - 2020-09-11 11:32:39 --> Utf8 Class Initialized
INFO - 2020-09-11 11:32:39 --> URI Class Initialized
DEBUG - 2020-09-11 11:32:39 --> No URI present. Default controller set.
INFO - 2020-09-11 11:32:39 --> Router Class Initialized
INFO - 2020-09-11 11:32:39 --> Output Class Initialized
INFO - 2020-09-11 11:32:39 --> Security Class Initialized
DEBUG - 2020-09-11 11:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 11:32:39 --> Input Class Initialized
INFO - 2020-09-11 11:32:39 --> Language Class Initialized
INFO - 2020-09-11 11:32:39 --> Loader Class Initialized
INFO - 2020-09-11 11:32:39 --> Helper loaded: url_helper
INFO - 2020-09-11 11:32:39 --> Database Driver Class Initialized
INFO - 2020-09-11 11:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 11:32:39 --> Email Class Initialized
INFO - 2020-09-11 11:32:39 --> Controller Class Initialized
INFO - 2020-09-11 11:32:39 --> Model Class Initialized
INFO - 2020-09-11 11:32:39 --> Model Class Initialized
DEBUG - 2020-09-11 11:32:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 11:32:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 11:32:39 --> Final output sent to browser
DEBUG - 2020-09-11 11:32:39 --> Total execution time: 0.0211
ERROR - 2020-09-11 12:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:13:08 --> Config Class Initialized
INFO - 2020-09-11 12:13:08 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:13:08 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:13:08 --> Utf8 Class Initialized
INFO - 2020-09-11 12:13:08 --> URI Class Initialized
DEBUG - 2020-09-11 12:13:08 --> No URI present. Default controller set.
INFO - 2020-09-11 12:13:08 --> Router Class Initialized
INFO - 2020-09-11 12:13:08 --> Output Class Initialized
INFO - 2020-09-11 12:13:08 --> Security Class Initialized
DEBUG - 2020-09-11 12:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:13:08 --> Input Class Initialized
INFO - 2020-09-11 12:13:08 --> Language Class Initialized
INFO - 2020-09-11 12:13:08 --> Loader Class Initialized
INFO - 2020-09-11 12:13:08 --> Helper loaded: url_helper
INFO - 2020-09-11 12:13:08 --> Database Driver Class Initialized
INFO - 2020-09-11 12:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:13:08 --> Email Class Initialized
INFO - 2020-09-11 12:13:08 --> Controller Class Initialized
INFO - 2020-09-11 12:13:08 --> Model Class Initialized
INFO - 2020-09-11 12:13:08 --> Model Class Initialized
DEBUG - 2020-09-11 12:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:13:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 12:13:08 --> Final output sent to browser
DEBUG - 2020-09-11 12:13:08 --> Total execution time: 0.0186
ERROR - 2020-09-11 12:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:24:28 --> Config Class Initialized
INFO - 2020-09-11 12:24:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:24:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:28 --> Utf8 Class Initialized
INFO - 2020-09-11 12:24:28 --> URI Class Initialized
INFO - 2020-09-11 12:24:28 --> Router Class Initialized
INFO - 2020-09-11 12:24:28 --> Output Class Initialized
INFO - 2020-09-11 12:24:28 --> Security Class Initialized
DEBUG - 2020-09-11 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:24:28 --> Input Class Initialized
INFO - 2020-09-11 12:24:28 --> Language Class Initialized
INFO - 2020-09-11 12:24:28 --> Loader Class Initialized
INFO - 2020-09-11 12:24:28 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:28 --> Database Driver Class Initialized
ERROR - 2020-09-11 12:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:24:28 --> Config Class Initialized
INFO - 2020-09-11 12:24:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:24:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:28 --> Utf8 Class Initialized
INFO - 2020-09-11 12:24:28 --> URI Class Initialized
INFO - 2020-09-11 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:28 --> Router Class Initialized
INFO - 2020-09-11 12:24:28 --> Output Class Initialized
INFO - 2020-09-11 12:24:28 --> Email Class Initialized
INFO - 2020-09-11 12:24:28 --> Controller Class Initialized
INFO - 2020-09-11 12:24:28 --> Security Class Initialized
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
DEBUG - 2020-09-11 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 12:24:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:24:28 --> Input Class Initialized
INFO - 2020-09-11 12:24:28 --> Language Class Initialized
INFO - 2020-09-11 12:24:28 --> Loader Class Initialized
INFO - 2020-09-11 12:24:28 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:28 --> Database Driver Class Initialized
INFO - 2020-09-11 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:28 --> Email Class Initialized
INFO - 2020-09-11 12:24:28 --> Controller Class Initialized
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
DEBUG - 2020-09-11 12:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:24:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
INFO - 2020-09-11 12:24:28 --> Final output sent to browser
DEBUG - 2020-09-11 12:24:28 --> Total execution time: 0.0222
ERROR - 2020-09-11 12:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:24:28 --> Config Class Initialized
INFO - 2020-09-11 12:24:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:24:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:28 --> Utf8 Class Initialized
INFO - 2020-09-11 12:24:28 --> URI Class Initialized
INFO - 2020-09-11 12:24:28 --> Router Class Initialized
INFO - 2020-09-11 12:24:28 --> Output Class Initialized
INFO - 2020-09-11 12:24:28 --> Security Class Initialized
DEBUG - 2020-09-11 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:24:28 --> Input Class Initialized
INFO - 2020-09-11 12:24:28 --> Language Class Initialized
INFO - 2020-09-11 12:24:28 --> Loader Class Initialized
INFO - 2020-09-11 12:24:28 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:28 --> Database Driver Class Initialized
INFO - 2020-09-11 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:28 --> Email Class Initialized
INFO - 2020-09-11 12:24:28 --> Controller Class Initialized
DEBUG - 2020-09-11 12:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:24:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
INFO - 2020-09-11 12:24:28 --> Model Class Initialized
INFO - 2020-09-11 12:24:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 12:24:28 --> Final output sent to browser
DEBUG - 2020-09-11 12:24:28 --> Total execution time: 0.0228
ERROR - 2020-09-11 12:24:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:24:35 --> Config Class Initialized
INFO - 2020-09-11 12:24:35 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:24:35 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:35 --> Utf8 Class Initialized
INFO - 2020-09-11 12:24:35 --> URI Class Initialized
DEBUG - 2020-09-11 12:24:35 --> No URI present. Default controller set.
INFO - 2020-09-11 12:24:35 --> Router Class Initialized
INFO - 2020-09-11 12:24:35 --> Output Class Initialized
INFO - 2020-09-11 12:24:35 --> Security Class Initialized
DEBUG - 2020-09-11 12:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:24:35 --> Input Class Initialized
INFO - 2020-09-11 12:24:35 --> Language Class Initialized
INFO - 2020-09-11 12:24:35 --> Loader Class Initialized
INFO - 2020-09-11 12:24:35 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:35 --> Database Driver Class Initialized
INFO - 2020-09-11 12:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:35 --> Email Class Initialized
INFO - 2020-09-11 12:24:35 --> Controller Class Initialized
INFO - 2020-09-11 12:24:35 --> Model Class Initialized
INFO - 2020-09-11 12:24:35 --> Model Class Initialized
DEBUG - 2020-09-11 12:24:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:24:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 12:24:35 --> Final output sent to browser
DEBUG - 2020-09-11 12:24:35 --> Total execution time: 0.0197
ERROR - 2020-09-11 12:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-11 12:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:24:51 --> Config Class Initialized
INFO - 2020-09-11 12:24:51 --> Hooks Class Initialized
INFO - 2020-09-11 12:24:51 --> Config Class Initialized
INFO - 2020-09-11 12:24:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:24:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:51 --> Utf8 Class Initialized
DEBUG - 2020-09-11 12:24:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:51 --> Utf8 Class Initialized
INFO - 2020-09-11 12:24:51 --> URI Class Initialized
INFO - 2020-09-11 12:24:51 --> URI Class Initialized
INFO - 2020-09-11 12:24:51 --> Router Class Initialized
INFO - 2020-09-11 12:24:51 --> Router Class Initialized
INFO - 2020-09-11 12:24:51 --> Output Class Initialized
INFO - 2020-09-11 12:24:51 --> Output Class Initialized
INFO - 2020-09-11 12:24:51 --> Security Class Initialized
INFO - 2020-09-11 12:24:51 --> Security Class Initialized
DEBUG - 2020-09-11 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:24:51 --> Input Class Initialized
DEBUG - 2020-09-11 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:24:51 --> Input Class Initialized
INFO - 2020-09-11 12:24:51 --> Language Class Initialized
INFO - 2020-09-11 12:24:51 --> Language Class Initialized
INFO - 2020-09-11 12:24:51 --> Loader Class Initialized
INFO - 2020-09-11 12:24:51 --> Loader Class Initialized
INFO - 2020-09-11 12:24:51 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:51 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:51 --> Database Driver Class Initialized
INFO - 2020-09-11 12:24:51 --> Database Driver Class Initialized
INFO - 2020-09-11 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:51 --> Email Class Initialized
INFO - 2020-09-11 12:24:51 --> Controller Class Initialized
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
DEBUG - 2020-09-11 12:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:24:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
INFO - 2020-09-11 12:24:51 --> Final output sent to browser
DEBUG - 2020-09-11 12:24:51 --> Total execution time: 0.0207
INFO - 2020-09-11 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:51 --> Email Class Initialized
INFO - 2020-09-11 12:24:51 --> Controller Class Initialized
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
DEBUG - 2020-09-11 12:24:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 12:24:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:24:51 --> Config Class Initialized
INFO - 2020-09-11 12:24:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:24:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:24:51 --> Utf8 Class Initialized
INFO - 2020-09-11 12:24:51 --> URI Class Initialized
INFO - 2020-09-11 12:24:51 --> Router Class Initialized
INFO - 2020-09-11 12:24:51 --> Output Class Initialized
INFO - 2020-09-11 12:24:51 --> Security Class Initialized
DEBUG - 2020-09-11 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:24:51 --> Input Class Initialized
INFO - 2020-09-11 12:24:51 --> Language Class Initialized
INFO - 2020-09-11 12:24:51 --> Loader Class Initialized
INFO - 2020-09-11 12:24:51 --> Helper loaded: url_helper
INFO - 2020-09-11 12:24:51 --> Database Driver Class Initialized
INFO - 2020-09-11 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:24:51 --> Email Class Initialized
INFO - 2020-09-11 12:24:51 --> Controller Class Initialized
DEBUG - 2020-09-11 12:24:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:24:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
INFO - 2020-09-11 12:24:51 --> Model Class Initialized
INFO - 2020-09-11 12:24:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 12:24:51 --> Final output sent to browser
DEBUG - 2020-09-11 12:24:51 --> Total execution time: 0.0239
ERROR - 2020-09-11 12:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:25:05 --> Config Class Initialized
INFO - 2020-09-11 12:25:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:25:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:25:05 --> Utf8 Class Initialized
INFO - 2020-09-11 12:25:05 --> URI Class Initialized
INFO - 2020-09-11 12:25:05 --> Router Class Initialized
INFO - 2020-09-11 12:25:05 --> Output Class Initialized
INFO - 2020-09-11 12:25:05 --> Security Class Initialized
DEBUG - 2020-09-11 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:25:05 --> Input Class Initialized
INFO - 2020-09-11 12:25:05 --> Language Class Initialized
INFO - 2020-09-11 12:25:05 --> Loader Class Initialized
INFO - 2020-09-11 12:25:05 --> Helper loaded: url_helper
INFO - 2020-09-11 12:25:05 --> Database Driver Class Initialized
INFO - 2020-09-11 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:25:05 --> Email Class Initialized
INFO - 2020-09-11 12:25:05 --> Controller Class Initialized
DEBUG - 2020-09-11 12:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:25:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:25:05 --> Model Class Initialized
INFO - 2020-09-11 12:25:05 --> Model Class Initialized
INFO - 2020-09-11 12:25:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 12:25:05 --> Final output sent to browser
DEBUG - 2020-09-11 12:25:05 --> Total execution time: 0.0208
ERROR - 2020-09-11 12:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:25:12 --> Config Class Initialized
INFO - 2020-09-11 12:25:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:25:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:25:12 --> Utf8 Class Initialized
INFO - 2020-09-11 12:25:12 --> URI Class Initialized
INFO - 2020-09-11 12:25:12 --> Router Class Initialized
INFO - 2020-09-11 12:25:12 --> Output Class Initialized
INFO - 2020-09-11 12:25:12 --> Security Class Initialized
DEBUG - 2020-09-11 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:25:12 --> Input Class Initialized
INFO - 2020-09-11 12:25:12 --> Language Class Initialized
INFO - 2020-09-11 12:25:12 --> Loader Class Initialized
INFO - 2020-09-11 12:25:12 --> Helper loaded: url_helper
INFO - 2020-09-11 12:25:12 --> Database Driver Class Initialized
INFO - 2020-09-11 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:25:12 --> Email Class Initialized
INFO - 2020-09-11 12:25:12 --> Controller Class Initialized
INFO - 2020-09-11 12:25:12 --> Model Class Initialized
INFO - 2020-09-11 12:25:12 --> Model Class Initialized
INFO - 2020-09-11 12:25:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 12:25:12 --> Final output sent to browser
DEBUG - 2020-09-11 12:25:12 --> Total execution time: 0.0386
ERROR - 2020-09-11 12:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:25:13 --> Config Class Initialized
INFO - 2020-09-11 12:25:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:25:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:25:13 --> Utf8 Class Initialized
INFO - 2020-09-11 12:25:13 --> URI Class Initialized
INFO - 2020-09-11 12:25:13 --> Router Class Initialized
INFO - 2020-09-11 12:25:13 --> Output Class Initialized
INFO - 2020-09-11 12:25:13 --> Security Class Initialized
DEBUG - 2020-09-11 12:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:25:13 --> Input Class Initialized
INFO - 2020-09-11 12:25:13 --> Language Class Initialized
INFO - 2020-09-11 12:25:13 --> Loader Class Initialized
INFO - 2020-09-11 12:25:13 --> Helper loaded: url_helper
INFO - 2020-09-11 12:25:13 --> Database Driver Class Initialized
INFO - 2020-09-11 12:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:25:13 --> Email Class Initialized
INFO - 2020-09-11 12:25:13 --> Controller Class Initialized
INFO - 2020-09-11 12:25:13 --> Model Class Initialized
INFO - 2020-09-11 12:25:13 --> Model Class Initialized
INFO - 2020-09-11 12:25:13 --> Final output sent to browser
DEBUG - 2020-09-11 12:25:13 --> Total execution time: 0.0420
ERROR - 2020-09-11 12:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:25:24 --> Config Class Initialized
INFO - 2020-09-11 12:25:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:25:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:25:24 --> Utf8 Class Initialized
INFO - 2020-09-11 12:25:24 --> URI Class Initialized
INFO - 2020-09-11 12:25:24 --> Router Class Initialized
INFO - 2020-09-11 12:25:24 --> Output Class Initialized
INFO - 2020-09-11 12:25:24 --> Security Class Initialized
DEBUG - 2020-09-11 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:25:24 --> Input Class Initialized
INFO - 2020-09-11 12:25:24 --> Language Class Initialized
INFO - 2020-09-11 12:25:24 --> Loader Class Initialized
INFO - 2020-09-11 12:25:24 --> Helper loaded: url_helper
INFO - 2020-09-11 12:25:24 --> Database Driver Class Initialized
INFO - 2020-09-11 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:25:24 --> Email Class Initialized
INFO - 2020-09-11 12:25:24 --> Controller Class Initialized
DEBUG - 2020-09-11 12:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:25:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:25:24 --> Model Class Initialized
INFO - 2020-09-11 12:25:24 --> Model Class Initialized
INFO - 2020-09-11 12:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 12:25:24 --> Final output sent to browser
DEBUG - 2020-09-11 12:25:24 --> Total execution time: 0.0213
ERROR - 2020-09-11 12:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:25:40 --> Config Class Initialized
INFO - 2020-09-11 12:25:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:25:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:25:40 --> Utf8 Class Initialized
INFO - 2020-09-11 12:25:40 --> URI Class Initialized
DEBUG - 2020-09-11 12:25:40 --> No URI present. Default controller set.
INFO - 2020-09-11 12:25:40 --> Router Class Initialized
INFO - 2020-09-11 12:25:40 --> Output Class Initialized
INFO - 2020-09-11 12:25:40 --> Security Class Initialized
DEBUG - 2020-09-11 12:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:25:40 --> Input Class Initialized
INFO - 2020-09-11 12:25:40 --> Language Class Initialized
INFO - 2020-09-11 12:25:40 --> Loader Class Initialized
INFO - 2020-09-11 12:25:40 --> Helper loaded: url_helper
INFO - 2020-09-11 12:25:40 --> Database Driver Class Initialized
INFO - 2020-09-11 12:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:25:40 --> Email Class Initialized
INFO - 2020-09-11 12:25:40 --> Controller Class Initialized
INFO - 2020-09-11 12:25:40 --> Model Class Initialized
INFO - 2020-09-11 12:25:40 --> Model Class Initialized
DEBUG - 2020-09-11 12:25:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:25:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 12:25:40 --> Final output sent to browser
DEBUG - 2020-09-11 12:25:40 --> Total execution time: 0.0235
ERROR - 2020-09-11 12:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:06 --> Config Class Initialized
INFO - 2020-09-11 12:26:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:26:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:06 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:06 --> URI Class Initialized
INFO - 2020-09-11 12:26:06 --> Router Class Initialized
INFO - 2020-09-11 12:26:06 --> Output Class Initialized
INFO - 2020-09-11 12:26:06 --> Security Class Initialized
DEBUG - 2020-09-11 12:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:26:06 --> Input Class Initialized
INFO - 2020-09-11 12:26:06 --> Language Class Initialized
INFO - 2020-09-11 12:26:06 --> Loader Class Initialized
INFO - 2020-09-11 12:26:06 --> Helper loaded: url_helper
ERROR - 2020-09-11 12:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:06 --> Config Class Initialized
INFO - 2020-09-11 12:26:06 --> Hooks Class Initialized
INFO - 2020-09-11 12:26:06 --> Database Driver Class Initialized
DEBUG - 2020-09-11 12:26:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:06 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:06 --> URI Class Initialized
INFO - 2020-09-11 12:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:06 --> Router Class Initialized
INFO - 2020-09-11 12:26:06 --> Output Class Initialized
INFO - 2020-09-11 12:26:06 --> Email Class Initialized
INFO - 2020-09-11 12:26:06 --> Controller Class Initialized
INFO - 2020-09-11 12:26:06 --> Model Class Initialized
INFO - 2020-09-11 12:26:06 --> Security Class Initialized
INFO - 2020-09-11 12:26:06 --> Model Class Initialized
DEBUG - 2020-09-11 12:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-11 12:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:06 --> Input Class Initialized
DEBUG - 2020-09-11 12:26:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:06 --> Model Class Initialized
INFO - 2020-09-11 12:26:06 --> Language Class Initialized
INFO - 2020-09-11 12:26:06 --> Loader Class Initialized
INFO - 2020-09-11 12:26:06 --> Final output sent to browser
DEBUG - 2020-09-11 12:26:06 --> Total execution time: 0.0224
INFO - 2020-09-11 12:26:06 --> Helper loaded: url_helper
INFO - 2020-09-11 12:26:06 --> Database Driver Class Initialized
INFO - 2020-09-11 12:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:06 --> Email Class Initialized
INFO - 2020-09-11 12:26:06 --> Controller Class Initialized
INFO - 2020-09-11 12:26:06 --> Model Class Initialized
INFO - 2020-09-11 12:26:06 --> Model Class Initialized
DEBUG - 2020-09-11 12:26:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 12:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:06 --> Config Class Initialized
INFO - 2020-09-11 12:26:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:26:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:06 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:06 --> URI Class Initialized
INFO - 2020-09-11 12:26:06 --> Router Class Initialized
INFO - 2020-09-11 12:26:06 --> Output Class Initialized
INFO - 2020-09-11 12:26:06 --> Security Class Initialized
DEBUG - 2020-09-11 12:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:26:06 --> Input Class Initialized
INFO - 2020-09-11 12:26:06 --> Language Class Initialized
INFO - 2020-09-11 12:26:06 --> Loader Class Initialized
INFO - 2020-09-11 12:26:06 --> Helper loaded: url_helper
INFO - 2020-09-11 12:26:06 --> Database Driver Class Initialized
INFO - 2020-09-11 12:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:06 --> Email Class Initialized
INFO - 2020-09-11 12:26:06 --> Controller Class Initialized
DEBUG - 2020-09-11 12:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:26:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 12:26:06 --> Final output sent to browser
DEBUG - 2020-09-11 12:26:06 --> Total execution time: 0.0201
ERROR - 2020-09-11 12:26:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:19 --> Config Class Initialized
INFO - 2020-09-11 12:26:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:26:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:19 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:19 --> URI Class Initialized
INFO - 2020-09-11 12:26:19 --> Router Class Initialized
INFO - 2020-09-11 12:26:19 --> Output Class Initialized
INFO - 2020-09-11 12:26:19 --> Security Class Initialized
DEBUG - 2020-09-11 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:26:19 --> Input Class Initialized
INFO - 2020-09-11 12:26:19 --> Language Class Initialized
INFO - 2020-09-11 12:26:19 --> Loader Class Initialized
INFO - 2020-09-11 12:26:19 --> Helper loaded: url_helper
INFO - 2020-09-11 12:26:19 --> Database Driver Class Initialized
INFO - 2020-09-11 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:19 --> Email Class Initialized
INFO - 2020-09-11 12:26:19 --> Controller Class Initialized
DEBUG - 2020-09-11 12:26:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:26:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:19 --> Model Class Initialized
INFO - 2020-09-11 12:26:19 --> Model Class Initialized
INFO - 2020-09-11 12:26:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 12:26:19 --> Final output sent to browser
DEBUG - 2020-09-11 12:26:19 --> Total execution time: 0.0232
ERROR - 2020-09-11 12:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:28 --> Config Class Initialized
INFO - 2020-09-11 12:26:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:26:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:28 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:28 --> URI Class Initialized
INFO - 2020-09-11 12:26:28 --> Router Class Initialized
INFO - 2020-09-11 12:26:28 --> Output Class Initialized
INFO - 2020-09-11 12:26:28 --> Security Class Initialized
DEBUG - 2020-09-11 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:26:28 --> Input Class Initialized
INFO - 2020-09-11 12:26:28 --> Language Class Initialized
INFO - 2020-09-11 12:26:28 --> Loader Class Initialized
INFO - 2020-09-11 12:26:28 --> Helper loaded: url_helper
INFO - 2020-09-11 12:26:28 --> Database Driver Class Initialized
INFO - 2020-09-11 12:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:28 --> Email Class Initialized
INFO - 2020-09-11 12:26:28 --> Controller Class Initialized
DEBUG - 2020-09-11 12:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:26:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:28 --> Model Class Initialized
INFO - 2020-09-11 12:26:28 --> Model Class Initialized
INFO - 2020-09-11 12:26:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-11 12:26:28 --> Final output sent to browser
DEBUG - 2020-09-11 12:26:28 --> Total execution time: 0.0215
ERROR - 2020-09-11 12:26:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:47 --> Config Class Initialized
INFO - 2020-09-11 12:26:47 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:26:47 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:47 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:47 --> URI Class Initialized
INFO - 2020-09-11 12:26:47 --> Router Class Initialized
INFO - 2020-09-11 12:26:47 --> Output Class Initialized
INFO - 2020-09-11 12:26:47 --> Security Class Initialized
DEBUG - 2020-09-11 12:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:26:47 --> Input Class Initialized
INFO - 2020-09-11 12:26:47 --> Language Class Initialized
INFO - 2020-09-11 12:26:47 --> Loader Class Initialized
INFO - 2020-09-11 12:26:47 --> Helper loaded: url_helper
INFO - 2020-09-11 12:26:47 --> Database Driver Class Initialized
INFO - 2020-09-11 12:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:47 --> Email Class Initialized
INFO - 2020-09-11 12:26:47 --> Controller Class Initialized
DEBUG - 2020-09-11 12:26:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:26:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:47 --> Model Class Initialized
INFO - 2020-09-11 12:26:47 --> Model Class Initialized
INFO - 2020-09-11 12:26:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 12:26:47 --> Final output sent to browser
DEBUG - 2020-09-11 12:26:47 --> Total execution time: 0.0202
ERROR - 2020-09-11 12:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:26:53 --> Config Class Initialized
INFO - 2020-09-11 12:26:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:26:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:26:53 --> Utf8 Class Initialized
INFO - 2020-09-11 12:26:53 --> URI Class Initialized
DEBUG - 2020-09-11 12:26:53 --> No URI present. Default controller set.
INFO - 2020-09-11 12:26:53 --> Router Class Initialized
INFO - 2020-09-11 12:26:53 --> Output Class Initialized
INFO - 2020-09-11 12:26:53 --> Security Class Initialized
DEBUG - 2020-09-11 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:26:53 --> Input Class Initialized
INFO - 2020-09-11 12:26:53 --> Language Class Initialized
INFO - 2020-09-11 12:26:53 --> Loader Class Initialized
INFO - 2020-09-11 12:26:53 --> Helper loaded: url_helper
INFO - 2020-09-11 12:26:53 --> Database Driver Class Initialized
INFO - 2020-09-11 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:26:53 --> Email Class Initialized
INFO - 2020-09-11 12:26:53 --> Controller Class Initialized
INFO - 2020-09-11 12:26:53 --> Model Class Initialized
INFO - 2020-09-11 12:26:53 --> Model Class Initialized
DEBUG - 2020-09-11 12:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:26:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 12:26:53 --> Final output sent to browser
DEBUG - 2020-09-11 12:26:53 --> Total execution time: 0.0195
ERROR - 2020-09-11 12:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:28:51 --> Config Class Initialized
INFO - 2020-09-11 12:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:28:51 --> Utf8 Class Initialized
INFO - 2020-09-11 12:28:51 --> URI Class Initialized
INFO - 2020-09-11 12:28:51 --> Router Class Initialized
INFO - 2020-09-11 12:28:51 --> Output Class Initialized
INFO - 2020-09-11 12:28:51 --> Security Class Initialized
DEBUG - 2020-09-11 12:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:28:51 --> Input Class Initialized
INFO - 2020-09-11 12:28:51 --> Language Class Initialized
INFO - 2020-09-11 12:28:51 --> Loader Class Initialized
INFO - 2020-09-11 12:28:51 --> Helper loaded: url_helper
ERROR - 2020-09-11 12:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:28:51 --> Config Class Initialized
INFO - 2020-09-11 12:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:28:51 --> Utf8 Class Initialized
INFO - 2020-09-11 12:28:51 --> URI Class Initialized
INFO - 2020-09-11 12:28:51 --> Router Class Initialized
INFO - 2020-09-11 12:28:51 --> Database Driver Class Initialized
INFO - 2020-09-11 12:28:51 --> Output Class Initialized
INFO - 2020-09-11 12:28:51 --> Security Class Initialized
DEBUG - 2020-09-11 12:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:28:51 --> Input Class Initialized
INFO - 2020-09-11 12:28:51 --> Language Class Initialized
INFO - 2020-09-11 12:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:28:51 --> Loader Class Initialized
INFO - 2020-09-11 12:28:51 --> Helper loaded: url_helper
INFO - 2020-09-11 12:28:51 --> Email Class Initialized
INFO - 2020-09-11 12:28:51 --> Controller Class Initialized
INFO - 2020-09-11 12:28:51 --> Model Class Initialized
INFO - 2020-09-11 12:28:51 --> Model Class Initialized
DEBUG - 2020-09-11 12:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:28:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:28:51 --> Model Class Initialized
INFO - 2020-09-11 12:28:51 --> Final output sent to browser
DEBUG - 2020-09-11 12:28:51 --> Total execution time: 0.0224
INFO - 2020-09-11 12:28:51 --> Database Driver Class Initialized
INFO - 2020-09-11 12:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:28:51 --> Email Class Initialized
INFO - 2020-09-11 12:28:51 --> Controller Class Initialized
INFO - 2020-09-11 12:28:51 --> Model Class Initialized
INFO - 2020-09-11 12:28:51 --> Model Class Initialized
DEBUG - 2020-09-11 12:28:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 12:28:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:28:52 --> Config Class Initialized
INFO - 2020-09-11 12:28:52 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:28:52 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:28:52 --> Utf8 Class Initialized
INFO - 2020-09-11 12:28:52 --> URI Class Initialized
INFO - 2020-09-11 12:28:52 --> Router Class Initialized
INFO - 2020-09-11 12:28:52 --> Output Class Initialized
INFO - 2020-09-11 12:28:52 --> Security Class Initialized
DEBUG - 2020-09-11 12:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:28:52 --> Input Class Initialized
INFO - 2020-09-11 12:28:52 --> Language Class Initialized
INFO - 2020-09-11 12:28:52 --> Loader Class Initialized
INFO - 2020-09-11 12:28:52 --> Helper loaded: url_helper
INFO - 2020-09-11 12:28:52 --> Database Driver Class Initialized
INFO - 2020-09-11 12:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:28:52 --> Email Class Initialized
INFO - 2020-09-11 12:28:52 --> Controller Class Initialized
DEBUG - 2020-09-11 12:28:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:28:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:28:52 --> Model Class Initialized
INFO - 2020-09-11 12:28:52 --> Model Class Initialized
INFO - 2020-09-11 12:28:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 12:28:52 --> Final output sent to browser
DEBUG - 2020-09-11 12:28:52 --> Total execution time: 0.0210
ERROR - 2020-09-11 12:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:28:59 --> Config Class Initialized
INFO - 2020-09-11 12:28:59 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:28:59 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:28:59 --> Utf8 Class Initialized
INFO - 2020-09-11 12:28:59 --> URI Class Initialized
INFO - 2020-09-11 12:28:59 --> Router Class Initialized
INFO - 2020-09-11 12:28:59 --> Output Class Initialized
INFO - 2020-09-11 12:28:59 --> Security Class Initialized
DEBUG - 2020-09-11 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:28:59 --> Input Class Initialized
INFO - 2020-09-11 12:28:59 --> Language Class Initialized
INFO - 2020-09-11 12:28:59 --> Loader Class Initialized
INFO - 2020-09-11 12:28:59 --> Helper loaded: url_helper
INFO - 2020-09-11 12:28:59 --> Database Driver Class Initialized
INFO - 2020-09-11 12:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:28:59 --> Email Class Initialized
INFO - 2020-09-11 12:28:59 --> Controller Class Initialized
DEBUG - 2020-09-11 12:28:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:28:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:28:59 --> Model Class Initialized
INFO - 2020-09-11 12:28:59 --> Model Class Initialized
INFO - 2020-09-11 12:28:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 12:28:59 --> Final output sent to browser
DEBUG - 2020-09-11 12:28:59 --> Total execution time: 0.0199
ERROR - 2020-09-11 12:52:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:52:28 --> Config Class Initialized
INFO - 2020-09-11 12:52:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:52:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:52:28 --> Utf8 Class Initialized
INFO - 2020-09-11 12:52:28 --> URI Class Initialized
INFO - 2020-09-11 12:52:28 --> Router Class Initialized
INFO - 2020-09-11 12:52:28 --> Output Class Initialized
INFO - 2020-09-11 12:52:28 --> Security Class Initialized
DEBUG - 2020-09-11 12:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:52:28 --> Input Class Initialized
INFO - 2020-09-11 12:52:28 --> Language Class Initialized
INFO - 2020-09-11 12:52:28 --> Loader Class Initialized
INFO - 2020-09-11 12:52:28 --> Helper loaded: url_helper
INFO - 2020-09-11 12:52:28 --> Database Driver Class Initialized
INFO - 2020-09-11 12:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:52:28 --> Email Class Initialized
INFO - 2020-09-11 12:52:28 --> Controller Class Initialized
DEBUG - 2020-09-11 12:52:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:52:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:52:28 --> Model Class Initialized
INFO - 2020-09-11 12:52:28 --> Model Class Initialized
INFO - 2020-09-11 12:52:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 12:52:28 --> Final output sent to browser
DEBUG - 2020-09-11 12:52:28 --> Total execution time: 0.2681
ERROR - 2020-09-11 12:52:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:52:31 --> Config Class Initialized
INFO - 2020-09-11 12:52:31 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:52:31 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:52:31 --> Utf8 Class Initialized
INFO - 2020-09-11 12:52:31 --> URI Class Initialized
INFO - 2020-09-11 12:52:31 --> Router Class Initialized
INFO - 2020-09-11 12:52:31 --> Output Class Initialized
INFO - 2020-09-11 12:52:31 --> Security Class Initialized
DEBUG - 2020-09-11 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:52:31 --> Input Class Initialized
INFO - 2020-09-11 12:52:31 --> Language Class Initialized
INFO - 2020-09-11 12:52:31 --> Loader Class Initialized
INFO - 2020-09-11 12:52:31 --> Helper loaded: url_helper
INFO - 2020-09-11 12:52:31 --> Database Driver Class Initialized
INFO - 2020-09-11 12:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:52:31 --> Email Class Initialized
INFO - 2020-09-11 12:52:31 --> Controller Class Initialized
INFO - 2020-09-11 12:52:31 --> Model Class Initialized
INFO - 2020-09-11 12:52:31 --> Model Class Initialized
INFO - 2020-09-11 12:52:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-11 12:52:31 --> Final output sent to browser
DEBUG - 2020-09-11 12:52:31 --> Total execution time: 0.0356
ERROR - 2020-09-11 12:52:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:52:32 --> Config Class Initialized
INFO - 2020-09-11 12:52:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:52:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:52:32 --> Utf8 Class Initialized
INFO - 2020-09-11 12:52:32 --> URI Class Initialized
INFO - 2020-09-11 12:52:32 --> Router Class Initialized
INFO - 2020-09-11 12:52:32 --> Output Class Initialized
INFO - 2020-09-11 12:52:32 --> Security Class Initialized
DEBUG - 2020-09-11 12:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:52:32 --> Input Class Initialized
INFO - 2020-09-11 12:52:32 --> Language Class Initialized
INFO - 2020-09-11 12:52:32 --> Loader Class Initialized
INFO - 2020-09-11 12:52:32 --> Helper loaded: url_helper
INFO - 2020-09-11 12:52:32 --> Database Driver Class Initialized
INFO - 2020-09-11 12:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:52:32 --> Email Class Initialized
INFO - 2020-09-11 12:52:32 --> Controller Class Initialized
INFO - 2020-09-11 12:52:32 --> Model Class Initialized
INFO - 2020-09-11 12:52:32 --> Model Class Initialized
INFO - 2020-09-11 12:52:32 --> Final output sent to browser
DEBUG - 2020-09-11 12:52:32 --> Total execution time: 0.0353
ERROR - 2020-09-11 12:55:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 12:55:40 --> Config Class Initialized
INFO - 2020-09-11 12:55:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 12:55:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 12:55:40 --> Utf8 Class Initialized
INFO - 2020-09-11 12:55:40 --> URI Class Initialized
INFO - 2020-09-11 12:55:40 --> Router Class Initialized
INFO - 2020-09-11 12:55:40 --> Output Class Initialized
INFO - 2020-09-11 12:55:40 --> Security Class Initialized
DEBUG - 2020-09-11 12:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 12:55:40 --> Input Class Initialized
INFO - 2020-09-11 12:55:40 --> Language Class Initialized
INFO - 2020-09-11 12:55:40 --> Loader Class Initialized
INFO - 2020-09-11 12:55:40 --> Helper loaded: url_helper
INFO - 2020-09-11 12:55:40 --> Database Driver Class Initialized
INFO - 2020-09-11 12:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 12:55:40 --> Email Class Initialized
INFO - 2020-09-11 12:55:40 --> Controller Class Initialized
DEBUG - 2020-09-11 12:55:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 12:55:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 12:55:40 --> Model Class Initialized
INFO - 2020-09-11 12:55:40 --> Model Class Initialized
INFO - 2020-09-11 12:55:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 12:55:40 --> Final output sent to browser
DEBUG - 2020-09-11 12:55:40 --> Total execution time: 0.0638
ERROR - 2020-09-11 13:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 13:36:07 --> Config Class Initialized
INFO - 2020-09-11 13:36:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:36:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:36:07 --> Utf8 Class Initialized
INFO - 2020-09-11 13:36:07 --> URI Class Initialized
INFO - 2020-09-11 13:36:07 --> Router Class Initialized
INFO - 2020-09-11 13:36:07 --> Output Class Initialized
INFO - 2020-09-11 13:36:07 --> Security Class Initialized
DEBUG - 2020-09-11 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:36:07 --> Input Class Initialized
INFO - 2020-09-11 13:36:07 --> Language Class Initialized
INFO - 2020-09-11 13:36:07 --> Loader Class Initialized
INFO - 2020-09-11 13:36:07 --> Helper loaded: url_helper
INFO - 2020-09-11 13:36:07 --> Database Driver Class Initialized
INFO - 2020-09-11 13:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:36:07 --> Email Class Initialized
INFO - 2020-09-11 13:36:07 --> Controller Class Initialized
DEBUG - 2020-09-11 13:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 13:36:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 13:36:07 --> Model Class Initialized
INFO - 2020-09-11 13:36:07 --> Model Class Initialized
INFO - 2020-09-11 13:36:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 13:36:07 --> Final output sent to browser
DEBUG - 2020-09-11 13:36:07 --> Total execution time: 0.0234
ERROR - 2020-09-11 13:36:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 13:36:15 --> Config Class Initialized
INFO - 2020-09-11 13:36:15 --> Hooks Class Initialized
DEBUG - 2020-09-11 13:36:15 --> UTF-8 Support Enabled
INFO - 2020-09-11 13:36:15 --> Utf8 Class Initialized
INFO - 2020-09-11 13:36:15 --> URI Class Initialized
DEBUG - 2020-09-11 13:36:15 --> No URI present. Default controller set.
INFO - 2020-09-11 13:36:15 --> Router Class Initialized
INFO - 2020-09-11 13:36:15 --> Output Class Initialized
INFO - 2020-09-11 13:36:15 --> Security Class Initialized
DEBUG - 2020-09-11 13:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 13:36:15 --> Input Class Initialized
INFO - 2020-09-11 13:36:15 --> Language Class Initialized
INFO - 2020-09-11 13:36:15 --> Loader Class Initialized
INFO - 2020-09-11 13:36:15 --> Helper loaded: url_helper
INFO - 2020-09-11 13:36:15 --> Database Driver Class Initialized
INFO - 2020-09-11 13:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 13:36:15 --> Email Class Initialized
INFO - 2020-09-11 13:36:15 --> Controller Class Initialized
INFO - 2020-09-11 13:36:15 --> Model Class Initialized
INFO - 2020-09-11 13:36:15 --> Model Class Initialized
DEBUG - 2020-09-11 13:36:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 13:36:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 13:36:15 --> Final output sent to browser
DEBUG - 2020-09-11 13:36:15 --> Total execution time: 0.0176
ERROR - 2020-09-11 14:29:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 14:29:48 --> Config Class Initialized
INFO - 2020-09-11 14:29:48 --> Hooks Class Initialized
DEBUG - 2020-09-11 14:29:48 --> UTF-8 Support Enabled
INFO - 2020-09-11 14:29:48 --> Utf8 Class Initialized
INFO - 2020-09-11 14:29:48 --> URI Class Initialized
DEBUG - 2020-09-11 14:29:48 --> No URI present. Default controller set.
INFO - 2020-09-11 14:29:48 --> Router Class Initialized
INFO - 2020-09-11 14:29:48 --> Output Class Initialized
INFO - 2020-09-11 14:29:48 --> Security Class Initialized
DEBUG - 2020-09-11 14:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 14:29:48 --> Input Class Initialized
INFO - 2020-09-11 14:29:48 --> Language Class Initialized
INFO - 2020-09-11 14:29:48 --> Loader Class Initialized
INFO - 2020-09-11 14:29:48 --> Helper loaded: url_helper
INFO - 2020-09-11 14:29:48 --> Database Driver Class Initialized
INFO - 2020-09-11 14:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 14:29:48 --> Email Class Initialized
INFO - 2020-09-11 14:29:48 --> Controller Class Initialized
INFO - 2020-09-11 14:29:48 --> Model Class Initialized
INFO - 2020-09-11 14:29:48 --> Model Class Initialized
DEBUG - 2020-09-11 14:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 14:29:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 14:29:48 --> Final output sent to browser
DEBUG - 2020-09-11 14:29:48 --> Total execution time: 0.0199
ERROR - 2020-09-11 14:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 14:29:50 --> Config Class Initialized
INFO - 2020-09-11 14:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 14:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 14:29:50 --> Utf8 Class Initialized
INFO - 2020-09-11 14:29:50 --> URI Class Initialized
INFO - 2020-09-11 14:29:50 --> Router Class Initialized
INFO - 2020-09-11 14:29:50 --> Output Class Initialized
INFO - 2020-09-11 14:29:50 --> Security Class Initialized
ERROR - 2020-09-11 14:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2020-09-11 14:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 14:29:50 --> Input Class Initialized
INFO - 2020-09-11 14:29:50 --> Config Class Initialized
INFO - 2020-09-11 14:29:50 --> Hooks Class Initialized
INFO - 2020-09-11 14:29:50 --> Language Class Initialized
DEBUG - 2020-09-11 14:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 14:29:50 --> Utf8 Class Initialized
INFO - 2020-09-11 14:29:50 --> Loader Class Initialized
INFO - 2020-09-11 14:29:50 --> URI Class Initialized
INFO - 2020-09-11 14:29:50 --> Helper loaded: url_helper
INFO - 2020-09-11 14:29:50 --> Router Class Initialized
INFO - 2020-09-11 14:29:50 --> Output Class Initialized
INFO - 2020-09-11 14:29:50 --> Security Class Initialized
DEBUG - 2020-09-11 14:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 14:29:50 --> Input Class Initialized
INFO - 2020-09-11 14:29:50 --> Language Class Initialized
INFO - 2020-09-11 14:29:50 --> Database Driver Class Initialized
INFO - 2020-09-11 14:29:50 --> Loader Class Initialized
INFO - 2020-09-11 14:29:50 --> Helper loaded: url_helper
INFO - 2020-09-11 14:29:50 --> Database Driver Class Initialized
INFO - 2020-09-11 14:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 14:29:51 --> Email Class Initialized
INFO - 2020-09-11 14:29:51 --> Controller Class Initialized
INFO - 2020-09-11 14:29:51 --> Model Class Initialized
INFO - 2020-09-11 14:29:51 --> Model Class Initialized
DEBUG - 2020-09-11 14:29:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 14:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 14:29:51 --> Email Class Initialized
INFO - 2020-09-11 14:29:51 --> Controller Class Initialized
INFO - 2020-09-11 14:29:51 --> Model Class Initialized
INFO - 2020-09-11 14:29:51 --> Model Class Initialized
DEBUG - 2020-09-11 14:29:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 14:29:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 14:29:51 --> Model Class Initialized
INFO - 2020-09-11 14:29:51 --> Final output sent to browser
DEBUG - 2020-09-11 14:29:51 --> Total execution time: 0.3195
ERROR - 2020-09-11 14:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 14:30:06 --> Config Class Initialized
INFO - 2020-09-11 14:30:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 14:30:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 14:30:06 --> Utf8 Class Initialized
INFO - 2020-09-11 14:30:06 --> URI Class Initialized
INFO - 2020-09-11 14:30:06 --> Router Class Initialized
INFO - 2020-09-11 14:30:06 --> Output Class Initialized
INFO - 2020-09-11 14:30:06 --> Security Class Initialized
DEBUG - 2020-09-11 14:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 14:30:06 --> Input Class Initialized
INFO - 2020-09-11 14:30:06 --> Language Class Initialized
INFO - 2020-09-11 14:30:06 --> Loader Class Initialized
INFO - 2020-09-11 14:30:06 --> Helper loaded: url_helper
INFO - 2020-09-11 14:30:06 --> Database Driver Class Initialized
INFO - 2020-09-11 14:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 14:30:06 --> Email Class Initialized
INFO - 2020-09-11 14:30:06 --> Controller Class Initialized
DEBUG - 2020-09-11 14:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 14:30:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 14:30:06 --> Model Class Initialized
INFO - 2020-09-11 14:30:06 --> Model Class Initialized
INFO - 2020-09-11 14:30:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 14:30:06 --> Final output sent to browser
DEBUG - 2020-09-11 14:30:06 --> Total execution time: 0.0289
ERROR - 2020-09-11 17:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:04:42 --> Config Class Initialized
INFO - 2020-09-11 17:04:42 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:04:42 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:04:42 --> Utf8 Class Initialized
INFO - 2020-09-11 17:04:42 --> URI Class Initialized
DEBUG - 2020-09-11 17:04:42 --> No URI present. Default controller set.
INFO - 2020-09-11 17:04:42 --> Router Class Initialized
INFO - 2020-09-11 17:04:42 --> Output Class Initialized
INFO - 2020-09-11 17:04:42 --> Security Class Initialized
DEBUG - 2020-09-11 17:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:04:42 --> Input Class Initialized
INFO - 2020-09-11 17:04:42 --> Language Class Initialized
INFO - 2020-09-11 17:04:42 --> Loader Class Initialized
INFO - 2020-09-11 17:04:42 --> Helper loaded: url_helper
INFO - 2020-09-11 17:04:42 --> Database Driver Class Initialized
INFO - 2020-09-11 17:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:04:42 --> Email Class Initialized
INFO - 2020-09-11 17:04:42 --> Controller Class Initialized
INFO - 2020-09-11 17:04:42 --> Model Class Initialized
INFO - 2020-09-11 17:04:42 --> Model Class Initialized
DEBUG - 2020-09-11 17:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:04:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 17:04:42 --> Final output sent to browser
DEBUG - 2020-09-11 17:04:42 --> Total execution time: 0.0196
ERROR - 2020-09-11 17:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:05:04 --> Config Class Initialized
INFO - 2020-09-11 17:05:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:05:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:05:04 --> Utf8 Class Initialized
INFO - 2020-09-11 17:05:04 --> URI Class Initialized
INFO - 2020-09-11 17:05:04 --> Router Class Initialized
INFO - 2020-09-11 17:05:04 --> Output Class Initialized
INFO - 2020-09-11 17:05:04 --> Security Class Initialized
DEBUG - 2020-09-11 17:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:05:04 --> Input Class Initialized
INFO - 2020-09-11 17:05:04 --> Language Class Initialized
INFO - 2020-09-11 17:05:04 --> Loader Class Initialized
INFO - 2020-09-11 17:05:04 --> Helper loaded: url_helper
INFO - 2020-09-11 17:05:04 --> Database Driver Class Initialized
INFO - 2020-09-11 17:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:05:04 --> Email Class Initialized
INFO - 2020-09-11 17:05:04 --> Controller Class Initialized
INFO - 2020-09-11 17:05:04 --> Model Class Initialized
INFO - 2020-09-11 17:05:04 --> Model Class Initialized
DEBUG - 2020-09-11 17:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:05:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-11 17:05:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:05:05 --> Config Class Initialized
INFO - 2020-09-11 17:05:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:05:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:05:05 --> Utf8 Class Initialized
INFO - 2020-09-11 17:05:05 --> URI Class Initialized
INFO - 2020-09-11 17:05:05 --> Router Class Initialized
INFO - 2020-09-11 17:05:05 --> Output Class Initialized
INFO - 2020-09-11 17:05:05 --> Security Class Initialized
DEBUG - 2020-09-11 17:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:05:05 --> Input Class Initialized
INFO - 2020-09-11 17:05:05 --> Language Class Initialized
INFO - 2020-09-11 17:05:05 --> Loader Class Initialized
INFO - 2020-09-11 17:05:05 --> Helper loaded: url_helper
INFO - 2020-09-11 17:05:05 --> Database Driver Class Initialized
INFO - 2020-09-11 17:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:05:05 --> Email Class Initialized
INFO - 2020-09-11 17:05:05 --> Controller Class Initialized
INFO - 2020-09-11 17:05:05 --> Model Class Initialized
INFO - 2020-09-11 17:05:05 --> Model Class Initialized
DEBUG - 2020-09-11 17:05:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 17:05:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:05:05 --> Config Class Initialized
INFO - 2020-09-11 17:05:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:05:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:05:05 --> Utf8 Class Initialized
INFO - 2020-09-11 17:05:05 --> URI Class Initialized
DEBUG - 2020-09-11 17:05:05 --> No URI present. Default controller set.
INFO - 2020-09-11 17:05:05 --> Router Class Initialized
INFO - 2020-09-11 17:05:05 --> Output Class Initialized
INFO - 2020-09-11 17:05:05 --> Security Class Initialized
DEBUG - 2020-09-11 17:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:05:05 --> Input Class Initialized
INFO - 2020-09-11 17:05:05 --> Language Class Initialized
INFO - 2020-09-11 17:05:05 --> Loader Class Initialized
INFO - 2020-09-11 17:05:05 --> Helper loaded: url_helper
INFO - 2020-09-11 17:05:05 --> Database Driver Class Initialized
INFO - 2020-09-11 17:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:05:05 --> Email Class Initialized
INFO - 2020-09-11 17:05:05 --> Controller Class Initialized
INFO - 2020-09-11 17:05:05 --> Model Class Initialized
INFO - 2020-09-11 17:05:05 --> Model Class Initialized
DEBUG - 2020-09-11 17:05:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:05:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 17:05:05 --> Final output sent to browser
DEBUG - 2020-09-11 17:05:05 --> Total execution time: 0.0215
ERROR - 2020-09-11 17:05:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:05:05 --> Config Class Initialized
INFO - 2020-09-11 17:05:05 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:05:05 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:05:05 --> Utf8 Class Initialized
INFO - 2020-09-11 17:05:05 --> URI Class Initialized
INFO - 2020-09-11 17:05:05 --> Router Class Initialized
INFO - 2020-09-11 17:05:05 --> Output Class Initialized
INFO - 2020-09-11 17:05:05 --> Security Class Initialized
DEBUG - 2020-09-11 17:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:05:05 --> Input Class Initialized
INFO - 2020-09-11 17:05:05 --> Language Class Initialized
INFO - 2020-09-11 17:05:05 --> Loader Class Initialized
INFO - 2020-09-11 17:05:05 --> Helper loaded: url_helper
INFO - 2020-09-11 17:05:05 --> Database Driver Class Initialized
INFO - 2020-09-11 17:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:05:05 --> Email Class Initialized
INFO - 2020-09-11 17:05:05 --> Controller Class Initialized
DEBUG - 2020-09-11 17:05:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:05:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:05:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 17:05:05 --> Final output sent to browser
DEBUG - 2020-09-11 17:05:05 --> Total execution time: 0.0201
ERROR - 2020-09-11 17:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:05:19 --> Config Class Initialized
INFO - 2020-09-11 17:05:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:05:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:05:19 --> Utf8 Class Initialized
INFO - 2020-09-11 17:05:19 --> URI Class Initialized
INFO - 2020-09-11 17:05:19 --> Router Class Initialized
INFO - 2020-09-11 17:05:19 --> Output Class Initialized
INFO - 2020-09-11 17:05:19 --> Security Class Initialized
DEBUG - 2020-09-11 17:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:05:19 --> Input Class Initialized
INFO - 2020-09-11 17:05:19 --> Language Class Initialized
INFO - 2020-09-11 17:05:19 --> Loader Class Initialized
INFO - 2020-09-11 17:05:19 --> Helper loaded: url_helper
INFO - 2020-09-11 17:05:19 --> Database Driver Class Initialized
INFO - 2020-09-11 17:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:05:19 --> Email Class Initialized
INFO - 2020-09-11 17:05:19 --> Controller Class Initialized
DEBUG - 2020-09-11 17:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:05:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:05:19 --> Model Class Initialized
INFO - 2020-09-11 17:05:19 --> Model Class Initialized
INFO - 2020-09-11 17:05:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 17:05:19 --> Final output sent to browser
DEBUG - 2020-09-11 17:05:19 --> Total execution time: 0.0264
ERROR - 2020-09-11 17:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:22:04 --> Config Class Initialized
INFO - 2020-09-11 17:22:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:22:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:22:04 --> Utf8 Class Initialized
INFO - 2020-09-11 17:22:04 --> URI Class Initialized
INFO - 2020-09-11 17:22:04 --> Router Class Initialized
INFO - 2020-09-11 17:22:04 --> Output Class Initialized
INFO - 2020-09-11 17:22:04 --> Security Class Initialized
DEBUG - 2020-09-11 17:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:22:04 --> Input Class Initialized
INFO - 2020-09-11 17:22:04 --> Language Class Initialized
INFO - 2020-09-11 17:22:04 --> Loader Class Initialized
INFO - 2020-09-11 17:22:04 --> Helper loaded: url_helper
INFO - 2020-09-11 17:22:04 --> Database Driver Class Initialized
INFO - 2020-09-11 17:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:22:04 --> Email Class Initialized
INFO - 2020-09-11 17:22:04 --> Controller Class Initialized
DEBUG - 2020-09-11 17:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:22:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:22:04 --> Model Class Initialized
INFO - 2020-09-11 17:22:04 --> Model Class Initialized
INFO - 2020-09-11 17:22:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-11 17:22:04 --> Final output sent to browser
DEBUG - 2020-09-11 17:22:04 --> Total execution time: 0.0235
ERROR - 2020-09-11 17:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:22:14 --> Config Class Initialized
INFO - 2020-09-11 17:22:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:22:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:22:14 --> Utf8 Class Initialized
INFO - 2020-09-11 17:22:14 --> URI Class Initialized
DEBUG - 2020-09-11 17:22:14 --> No URI present. Default controller set.
INFO - 2020-09-11 17:22:14 --> Router Class Initialized
INFO - 2020-09-11 17:22:14 --> Output Class Initialized
INFO - 2020-09-11 17:22:14 --> Security Class Initialized
DEBUG - 2020-09-11 17:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:22:14 --> Input Class Initialized
INFO - 2020-09-11 17:22:14 --> Language Class Initialized
INFO - 2020-09-11 17:22:14 --> Loader Class Initialized
INFO - 2020-09-11 17:22:14 --> Helper loaded: url_helper
INFO - 2020-09-11 17:22:14 --> Database Driver Class Initialized
INFO - 2020-09-11 17:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:22:14 --> Email Class Initialized
INFO - 2020-09-11 17:22:14 --> Controller Class Initialized
INFO - 2020-09-11 17:22:14 --> Model Class Initialized
INFO - 2020-09-11 17:22:14 --> Model Class Initialized
DEBUG - 2020-09-11 17:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:22:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 17:22:14 --> Final output sent to browser
DEBUG - 2020-09-11 17:22:14 --> Total execution time: 0.0181
ERROR - 2020-09-11 17:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:22:35 --> Config Class Initialized
INFO - 2020-09-11 17:22:35 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:22:35 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:22:35 --> Utf8 Class Initialized
INFO - 2020-09-11 17:22:35 --> URI Class Initialized
INFO - 2020-09-11 17:22:35 --> Router Class Initialized
INFO - 2020-09-11 17:22:35 --> Output Class Initialized
INFO - 2020-09-11 17:22:35 --> Security Class Initialized
DEBUG - 2020-09-11 17:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:22:35 --> Input Class Initialized
INFO - 2020-09-11 17:22:35 --> Language Class Initialized
INFO - 2020-09-11 17:22:35 --> Loader Class Initialized
INFO - 2020-09-11 17:22:35 --> Helper loaded: url_helper
INFO - 2020-09-11 17:22:35 --> Database Driver Class Initialized
INFO - 2020-09-11 17:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:22:35 --> Email Class Initialized
INFO - 2020-09-11 17:22:35 --> Controller Class Initialized
INFO - 2020-09-11 17:22:35 --> Model Class Initialized
INFO - 2020-09-11 17:22:35 --> Model Class Initialized
DEBUG - 2020-09-11 17:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:22:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:22:35 --> Model Class Initialized
INFO - 2020-09-11 17:22:35 --> Final output sent to browser
DEBUG - 2020-09-11 17:22:35 --> Total execution time: 0.0222
ERROR - 2020-09-11 17:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:22:36 --> Config Class Initialized
INFO - 2020-09-11 17:22:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:22:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:22:36 --> Utf8 Class Initialized
INFO - 2020-09-11 17:22:36 --> URI Class Initialized
INFO - 2020-09-11 17:22:36 --> Router Class Initialized
INFO - 2020-09-11 17:22:36 --> Output Class Initialized
INFO - 2020-09-11 17:22:36 --> Security Class Initialized
DEBUG - 2020-09-11 17:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:22:36 --> Input Class Initialized
INFO - 2020-09-11 17:22:36 --> Language Class Initialized
INFO - 2020-09-11 17:22:36 --> Loader Class Initialized
INFO - 2020-09-11 17:22:36 --> Helper loaded: url_helper
INFO - 2020-09-11 17:22:36 --> Database Driver Class Initialized
INFO - 2020-09-11 17:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:22:36 --> Email Class Initialized
INFO - 2020-09-11 17:22:36 --> Controller Class Initialized
INFO - 2020-09-11 17:22:36 --> Model Class Initialized
INFO - 2020-09-11 17:22:36 --> Model Class Initialized
DEBUG - 2020-09-11 17:22:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 17:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:22:36 --> Config Class Initialized
INFO - 2020-09-11 17:22:36 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:22:36 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:22:36 --> Utf8 Class Initialized
INFO - 2020-09-11 17:22:36 --> URI Class Initialized
INFO - 2020-09-11 17:22:36 --> Router Class Initialized
INFO - 2020-09-11 17:22:36 --> Output Class Initialized
INFO - 2020-09-11 17:22:36 --> Security Class Initialized
DEBUG - 2020-09-11 17:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:22:36 --> Input Class Initialized
INFO - 2020-09-11 17:22:36 --> Language Class Initialized
INFO - 2020-09-11 17:22:36 --> Loader Class Initialized
INFO - 2020-09-11 17:22:36 --> Helper loaded: url_helper
INFO - 2020-09-11 17:22:36 --> Database Driver Class Initialized
INFO - 2020-09-11 17:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:22:36 --> Email Class Initialized
INFO - 2020-09-11 17:22:36 --> Controller Class Initialized
DEBUG - 2020-09-11 17:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:22:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:22:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 17:22:36 --> Final output sent to browser
DEBUG - 2020-09-11 17:22:36 --> Total execution time: 0.0190
ERROR - 2020-09-11 17:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:22:47 --> Config Class Initialized
INFO - 2020-09-11 17:22:47 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:22:47 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:22:47 --> Utf8 Class Initialized
INFO - 2020-09-11 17:22:47 --> URI Class Initialized
INFO - 2020-09-11 17:22:47 --> Router Class Initialized
INFO - 2020-09-11 17:22:47 --> Output Class Initialized
INFO - 2020-09-11 17:22:47 --> Security Class Initialized
DEBUG - 2020-09-11 17:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:22:47 --> Input Class Initialized
INFO - 2020-09-11 17:22:47 --> Language Class Initialized
INFO - 2020-09-11 17:22:47 --> Loader Class Initialized
INFO - 2020-09-11 17:22:47 --> Helper loaded: url_helper
INFO - 2020-09-11 17:22:47 --> Database Driver Class Initialized
INFO - 2020-09-11 17:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:22:47 --> Email Class Initialized
INFO - 2020-09-11 17:22:47 --> Controller Class Initialized
DEBUG - 2020-09-11 17:22:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:22:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:22:47 --> Model Class Initialized
ERROR - 2020-09-11 17:22:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Loader.php:305) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-11 17:22:47 --> Severity: Error --> Class 'Campain_model' not found /home/purpu1ex/public_html/carsm/system/core/Loader.php 305
ERROR - 2020-09-11 17:23:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:23:32 --> Config Class Initialized
INFO - 2020-09-11 17:23:32 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:23:32 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:23:32 --> Utf8 Class Initialized
INFO - 2020-09-11 17:23:32 --> URI Class Initialized
INFO - 2020-09-11 17:23:32 --> Router Class Initialized
INFO - 2020-09-11 17:23:32 --> Output Class Initialized
INFO - 2020-09-11 17:23:32 --> Security Class Initialized
DEBUG - 2020-09-11 17:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:23:32 --> Input Class Initialized
INFO - 2020-09-11 17:23:32 --> Language Class Initialized
INFO - 2020-09-11 17:23:32 --> Loader Class Initialized
INFO - 2020-09-11 17:23:32 --> Helper loaded: url_helper
INFO - 2020-09-11 17:23:32 --> Database Driver Class Initialized
INFO - 2020-09-11 17:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:23:32 --> Email Class Initialized
INFO - 2020-09-11 17:23:32 --> Controller Class Initialized
DEBUG - 2020-09-11 17:23:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:23:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:23:32 --> Model Class Initialized
INFO - 2020-09-11 17:23:32 --> Model Class Initialized
INFO - 2020-09-11 17:23:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 17:23:32 --> Final output sent to browser
DEBUG - 2020-09-11 17:23:32 --> Total execution time: 0.0208
ERROR - 2020-09-11 17:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:23:59 --> Config Class Initialized
INFO - 2020-09-11 17:23:59 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:23:59 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:23:59 --> Utf8 Class Initialized
INFO - 2020-09-11 17:23:59 --> URI Class Initialized
INFO - 2020-09-11 17:23:59 --> Router Class Initialized
INFO - 2020-09-11 17:23:59 --> Output Class Initialized
INFO - 2020-09-11 17:23:59 --> Security Class Initialized
DEBUG - 2020-09-11 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:23:59 --> Input Class Initialized
INFO - 2020-09-11 17:23:59 --> Language Class Initialized
INFO - 2020-09-11 17:23:59 --> Loader Class Initialized
INFO - 2020-09-11 17:23:59 --> Helper loaded: url_helper
INFO - 2020-09-11 17:23:59 --> Database Driver Class Initialized
INFO - 2020-09-11 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:23:59 --> Email Class Initialized
INFO - 2020-09-11 17:23:59 --> Controller Class Initialized
DEBUG - 2020-09-11 17:23:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:23:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:23:59 --> Model Class Initialized
INFO - 2020-09-11 17:23:59 --> Model Class Initialized
INFO - 2020-09-11 17:23:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 17:23:59 --> Final output sent to browser
DEBUG - 2020-09-11 17:23:59 --> Total execution time: 0.0221
ERROR - 2020-09-11 17:24:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:24:09 --> Config Class Initialized
INFO - 2020-09-11 17:24:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:24:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:24:09 --> Utf8 Class Initialized
INFO - 2020-09-11 17:24:09 --> URI Class Initialized
INFO - 2020-09-11 17:24:09 --> Router Class Initialized
INFO - 2020-09-11 17:24:09 --> Output Class Initialized
INFO - 2020-09-11 17:24:09 --> Security Class Initialized
DEBUG - 2020-09-11 17:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:24:09 --> Input Class Initialized
INFO - 2020-09-11 17:24:09 --> Language Class Initialized
INFO - 2020-09-11 17:24:09 --> Loader Class Initialized
INFO - 2020-09-11 17:24:09 --> Helper loaded: url_helper
INFO - 2020-09-11 17:24:09 --> Database Driver Class Initialized
INFO - 2020-09-11 17:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:24:09 --> Email Class Initialized
INFO - 2020-09-11 17:24:09 --> Controller Class Initialized
DEBUG - 2020-09-11 17:24:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:24:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:24:09 --> Model Class Initialized
INFO - 2020-09-11 17:24:09 --> Model Class Initialized
INFO - 2020-09-11 17:24:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-09-11 17:24:09 --> Final output sent to browser
DEBUG - 2020-09-11 17:24:09 --> Total execution time: 0.0241
ERROR - 2020-09-11 17:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:24:14 --> Config Class Initialized
INFO - 2020-09-11 17:24:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:24:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:24:14 --> Utf8 Class Initialized
INFO - 2020-09-11 17:24:14 --> URI Class Initialized
INFO - 2020-09-11 17:24:14 --> Router Class Initialized
INFO - 2020-09-11 17:24:14 --> Output Class Initialized
INFO - 2020-09-11 17:24:14 --> Security Class Initialized
DEBUG - 2020-09-11 17:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:24:14 --> Input Class Initialized
INFO - 2020-09-11 17:24:14 --> Language Class Initialized
INFO - 2020-09-11 17:24:14 --> Loader Class Initialized
INFO - 2020-09-11 17:24:14 --> Helper loaded: url_helper
INFO - 2020-09-11 17:24:14 --> Database Driver Class Initialized
INFO - 2020-09-11 17:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:24:14 --> Email Class Initialized
INFO - 2020-09-11 17:24:14 --> Controller Class Initialized
DEBUG - 2020-09-11 17:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:24:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:24:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 17:24:14 --> Final output sent to browser
DEBUG - 2020-09-11 17:24:14 --> Total execution time: 0.0209
ERROR - 2020-09-11 17:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:24:21 --> Config Class Initialized
INFO - 2020-09-11 17:24:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:24:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:24:21 --> Utf8 Class Initialized
INFO - 2020-09-11 17:24:21 --> URI Class Initialized
INFO - 2020-09-11 17:24:21 --> Router Class Initialized
INFO - 2020-09-11 17:24:21 --> Output Class Initialized
INFO - 2020-09-11 17:24:21 --> Security Class Initialized
DEBUG - 2020-09-11 17:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:24:21 --> Input Class Initialized
INFO - 2020-09-11 17:24:21 --> Language Class Initialized
INFO - 2020-09-11 17:24:21 --> Loader Class Initialized
INFO - 2020-09-11 17:24:21 --> Helper loaded: url_helper
INFO - 2020-09-11 17:24:21 --> Database Driver Class Initialized
INFO - 2020-09-11 17:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:24:21 --> Email Class Initialized
INFO - 2020-09-11 17:24:21 --> Controller Class Initialized
DEBUG - 2020-09-11 17:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:24:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:24:21 --> Model Class Initialized
INFO - 2020-09-11 17:24:21 --> Model Class Initialized
INFO - 2020-09-11 17:24:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-11 17:24:21 --> Final output sent to browser
DEBUG - 2020-09-11 17:24:21 --> Total execution time: 0.0286
ERROR - 2020-09-11 17:25:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:25:17 --> Config Class Initialized
INFO - 2020-09-11 17:25:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:25:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:25:17 --> Utf8 Class Initialized
INFO - 2020-09-11 17:25:17 --> URI Class Initialized
INFO - 2020-09-11 17:25:17 --> Router Class Initialized
INFO - 2020-09-11 17:25:17 --> Output Class Initialized
INFO - 2020-09-11 17:25:17 --> Security Class Initialized
DEBUG - 2020-09-11 17:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:25:17 --> Input Class Initialized
INFO - 2020-09-11 17:25:17 --> Language Class Initialized
INFO - 2020-09-11 17:25:17 --> Loader Class Initialized
INFO - 2020-09-11 17:25:17 --> Helper loaded: url_helper
INFO - 2020-09-11 17:25:17 --> Database Driver Class Initialized
INFO - 2020-09-11 17:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:25:17 --> Email Class Initialized
INFO - 2020-09-11 17:25:17 --> Controller Class Initialized
DEBUG - 2020-09-11 17:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:25:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:25:17 --> Model Class Initialized
INFO - 2020-09-11 17:25:17 --> Model Class Initialized
INFO - 2020-09-11 17:25:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 17:25:17 --> Final output sent to browser
DEBUG - 2020-09-11 17:25:17 --> Total execution time: 0.0232
ERROR - 2020-09-11 17:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:26:50 --> Config Class Initialized
INFO - 2020-09-11 17:26:50 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:26:50 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:26:50 --> Utf8 Class Initialized
INFO - 2020-09-11 17:26:50 --> URI Class Initialized
DEBUG - 2020-09-11 17:26:50 --> No URI present. Default controller set.
INFO - 2020-09-11 17:26:50 --> Router Class Initialized
INFO - 2020-09-11 17:26:50 --> Output Class Initialized
INFO - 2020-09-11 17:26:50 --> Security Class Initialized
DEBUG - 2020-09-11 17:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:26:50 --> Input Class Initialized
INFO - 2020-09-11 17:26:50 --> Language Class Initialized
INFO - 2020-09-11 17:26:50 --> Loader Class Initialized
INFO - 2020-09-11 17:26:50 --> Helper loaded: url_helper
INFO - 2020-09-11 17:26:50 --> Database Driver Class Initialized
INFO - 2020-09-11 17:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:26:50 --> Email Class Initialized
INFO - 2020-09-11 17:26:50 --> Controller Class Initialized
INFO - 2020-09-11 17:26:50 --> Model Class Initialized
INFO - 2020-09-11 17:26:50 --> Model Class Initialized
DEBUG - 2020-09-11 17:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:26:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 17:26:50 --> Final output sent to browser
DEBUG - 2020-09-11 17:26:50 --> Total execution time: 0.0205
ERROR - 2020-09-11 17:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:26:53 --> Config Class Initialized
INFO - 2020-09-11 17:26:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:26:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:26:53 --> Utf8 Class Initialized
INFO - 2020-09-11 17:26:53 --> URI Class Initialized
INFO - 2020-09-11 17:26:53 --> Router Class Initialized
INFO - 2020-09-11 17:26:53 --> Output Class Initialized
INFO - 2020-09-11 17:26:53 --> Security Class Initialized
DEBUG - 2020-09-11 17:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:26:53 --> Input Class Initialized
INFO - 2020-09-11 17:26:53 --> Language Class Initialized
INFO - 2020-09-11 17:26:53 --> Loader Class Initialized
INFO - 2020-09-11 17:26:53 --> Helper loaded: url_helper
INFO - 2020-09-11 17:26:53 --> Database Driver Class Initialized
INFO - 2020-09-11 17:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:26:53 --> Email Class Initialized
INFO - 2020-09-11 17:26:53 --> Controller Class Initialized
INFO - 2020-09-11 17:26:53 --> Model Class Initialized
INFO - 2020-09-11 17:26:53 --> Model Class Initialized
DEBUG - 2020-09-11 17:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:26:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:26:53 --> Model Class Initialized
INFO - 2020-09-11 17:26:53 --> Final output sent to browser
DEBUG - 2020-09-11 17:26:53 --> Total execution time: 0.0288
ERROR - 2020-09-11 17:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:26:53 --> Config Class Initialized
INFO - 2020-09-11 17:26:53 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:26:53 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:26:53 --> Utf8 Class Initialized
INFO - 2020-09-11 17:26:53 --> URI Class Initialized
INFO - 2020-09-11 17:26:53 --> Router Class Initialized
INFO - 2020-09-11 17:26:53 --> Output Class Initialized
INFO - 2020-09-11 17:26:53 --> Security Class Initialized
DEBUG - 2020-09-11 17:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:26:53 --> Input Class Initialized
INFO - 2020-09-11 17:26:53 --> Language Class Initialized
INFO - 2020-09-11 17:26:53 --> Loader Class Initialized
INFO - 2020-09-11 17:26:53 --> Helper loaded: url_helper
INFO - 2020-09-11 17:26:53 --> Database Driver Class Initialized
INFO - 2020-09-11 17:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:26:53 --> Email Class Initialized
INFO - 2020-09-11 17:26:53 --> Controller Class Initialized
INFO - 2020-09-11 17:26:53 --> Model Class Initialized
INFO - 2020-09-11 17:26:53 --> Model Class Initialized
DEBUG - 2020-09-11 17:26:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 17:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:26:54 --> Config Class Initialized
INFO - 2020-09-11 17:26:54 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:26:54 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:26:54 --> Utf8 Class Initialized
INFO - 2020-09-11 17:26:54 --> URI Class Initialized
INFO - 2020-09-11 17:26:54 --> Router Class Initialized
INFO - 2020-09-11 17:26:54 --> Output Class Initialized
INFO - 2020-09-11 17:26:54 --> Security Class Initialized
DEBUG - 2020-09-11 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:26:54 --> Input Class Initialized
INFO - 2020-09-11 17:26:54 --> Language Class Initialized
INFO - 2020-09-11 17:26:54 --> Loader Class Initialized
INFO - 2020-09-11 17:26:54 --> Helper loaded: url_helper
INFO - 2020-09-11 17:26:54 --> Database Driver Class Initialized
INFO - 2020-09-11 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:26:54 --> Email Class Initialized
INFO - 2020-09-11 17:26:54 --> Controller Class Initialized
DEBUG - 2020-09-11 17:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:26:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:26:54 --> Model Class Initialized
INFO - 2020-09-11 17:26:54 --> Model Class Initialized
INFO - 2020-09-11 17:26:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 17:26:54 --> Final output sent to browser
DEBUG - 2020-09-11 17:26:54 --> Total execution time: 0.0232
ERROR - 2020-09-11 17:31:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:31:11 --> Config Class Initialized
INFO - 2020-09-11 17:31:11 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:31:11 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:31:11 --> Utf8 Class Initialized
INFO - 2020-09-11 17:31:11 --> URI Class Initialized
INFO - 2020-09-11 17:31:11 --> Router Class Initialized
INFO - 2020-09-11 17:31:11 --> Output Class Initialized
INFO - 2020-09-11 17:31:11 --> Security Class Initialized
DEBUG - 2020-09-11 17:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:31:11 --> Input Class Initialized
INFO - 2020-09-11 17:31:11 --> Language Class Initialized
INFO - 2020-09-11 17:31:11 --> Loader Class Initialized
INFO - 2020-09-11 17:31:11 --> Helper loaded: url_helper
INFO - 2020-09-11 17:31:11 --> Database Driver Class Initialized
INFO - 2020-09-11 17:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:31:11 --> Email Class Initialized
INFO - 2020-09-11 17:31:11 --> Controller Class Initialized
DEBUG - 2020-09-11 17:31:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:31:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:31:11 --> Model Class Initialized
INFO - 2020-09-11 17:31:11 --> Model Class Initialized
INFO - 2020-09-11 17:31:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-11 17:31:11 --> Final output sent to browser
DEBUG - 2020-09-11 17:31:11 --> Total execution time: 0.0249
ERROR - 2020-09-11 17:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:31:19 --> Config Class Initialized
INFO - 2020-09-11 17:31:19 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:31:19 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:31:19 --> Utf8 Class Initialized
INFO - 2020-09-11 17:31:19 --> URI Class Initialized
DEBUG - 2020-09-11 17:31:19 --> No URI present. Default controller set.
INFO - 2020-09-11 17:31:19 --> Router Class Initialized
INFO - 2020-09-11 17:31:19 --> Output Class Initialized
INFO - 2020-09-11 17:31:19 --> Security Class Initialized
DEBUG - 2020-09-11 17:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:31:19 --> Input Class Initialized
INFO - 2020-09-11 17:31:19 --> Language Class Initialized
INFO - 2020-09-11 17:31:19 --> Loader Class Initialized
INFO - 2020-09-11 17:31:19 --> Helper loaded: url_helper
INFO - 2020-09-11 17:31:19 --> Database Driver Class Initialized
INFO - 2020-09-11 17:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:31:19 --> Email Class Initialized
INFO - 2020-09-11 17:31:19 --> Controller Class Initialized
INFO - 2020-09-11 17:31:19 --> Model Class Initialized
INFO - 2020-09-11 17:31:19 --> Model Class Initialized
DEBUG - 2020-09-11 17:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:31:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 17:31:19 --> Final output sent to browser
DEBUG - 2020-09-11 17:31:19 --> Total execution time: 0.0184
ERROR - 2020-09-11 17:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:31:40 --> Config Class Initialized
INFO - 2020-09-11 17:31:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:31:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:31:40 --> Utf8 Class Initialized
INFO - 2020-09-11 17:31:40 --> URI Class Initialized
INFO - 2020-09-11 17:31:40 --> Router Class Initialized
INFO - 2020-09-11 17:31:40 --> Output Class Initialized
INFO - 2020-09-11 17:31:40 --> Security Class Initialized
DEBUG - 2020-09-11 17:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:31:40 --> Input Class Initialized
INFO - 2020-09-11 17:31:40 --> Language Class Initialized
INFO - 2020-09-11 17:31:40 --> Loader Class Initialized
INFO - 2020-09-11 17:31:40 --> Helper loaded: url_helper
INFO - 2020-09-11 17:31:40 --> Database Driver Class Initialized
INFO - 2020-09-11 17:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:31:40 --> Email Class Initialized
INFO - 2020-09-11 17:31:40 --> Controller Class Initialized
INFO - 2020-09-11 17:31:40 --> Model Class Initialized
INFO - 2020-09-11 17:31:40 --> Model Class Initialized
DEBUG - 2020-09-11 17:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:31:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:31:40 --> Model Class Initialized
INFO - 2020-09-11 17:31:40 --> Final output sent to browser
DEBUG - 2020-09-11 17:31:40 --> Total execution time: 0.0207
ERROR - 2020-09-11 17:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:31:40 --> Config Class Initialized
INFO - 2020-09-11 17:31:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:31:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:31:40 --> Utf8 Class Initialized
INFO - 2020-09-11 17:31:40 --> URI Class Initialized
INFO - 2020-09-11 17:31:40 --> Router Class Initialized
INFO - 2020-09-11 17:31:40 --> Output Class Initialized
INFO - 2020-09-11 17:31:40 --> Security Class Initialized
DEBUG - 2020-09-11 17:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:31:40 --> Input Class Initialized
INFO - 2020-09-11 17:31:40 --> Language Class Initialized
INFO - 2020-09-11 17:31:40 --> Loader Class Initialized
INFO - 2020-09-11 17:31:40 --> Helper loaded: url_helper
INFO - 2020-09-11 17:31:40 --> Database Driver Class Initialized
INFO - 2020-09-11 17:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:31:40 --> Email Class Initialized
INFO - 2020-09-11 17:31:40 --> Controller Class Initialized
INFO - 2020-09-11 17:31:40 --> Model Class Initialized
INFO - 2020-09-11 17:31:40 --> Model Class Initialized
DEBUG - 2020-09-11 17:31:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-11 17:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:31:40 --> Config Class Initialized
INFO - 2020-09-11 17:31:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:31:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:31:40 --> Utf8 Class Initialized
INFO - 2020-09-11 17:31:40 --> URI Class Initialized
INFO - 2020-09-11 17:31:40 --> Router Class Initialized
INFO - 2020-09-11 17:31:40 --> Output Class Initialized
INFO - 2020-09-11 17:31:40 --> Security Class Initialized
DEBUG - 2020-09-11 17:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:31:40 --> Input Class Initialized
INFO - 2020-09-11 17:31:40 --> Language Class Initialized
INFO - 2020-09-11 17:31:40 --> Loader Class Initialized
INFO - 2020-09-11 17:31:40 --> Helper loaded: url_helper
INFO - 2020-09-11 17:31:40 --> Database Driver Class Initialized
INFO - 2020-09-11 17:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:31:40 --> Email Class Initialized
INFO - 2020-09-11 17:31:40 --> Controller Class Initialized
DEBUG - 2020-09-11 17:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:31:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:31:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 17:31:40 --> Final output sent to browser
DEBUG - 2020-09-11 17:31:40 --> Total execution time: 0.0184
ERROR - 2020-09-11 17:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:32:12 --> Config Class Initialized
INFO - 2020-09-11 17:32:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:32:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:32:12 --> Utf8 Class Initialized
INFO - 2020-09-11 17:32:12 --> URI Class Initialized
INFO - 2020-09-11 17:32:12 --> Router Class Initialized
INFO - 2020-09-11 17:32:12 --> Output Class Initialized
INFO - 2020-09-11 17:32:12 --> Security Class Initialized
DEBUG - 2020-09-11 17:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:32:12 --> Input Class Initialized
INFO - 2020-09-11 17:32:12 --> Language Class Initialized
INFO - 2020-09-11 17:32:12 --> Loader Class Initialized
INFO - 2020-09-11 17:32:12 --> Helper loaded: url_helper
INFO - 2020-09-11 17:32:12 --> Database Driver Class Initialized
INFO - 2020-09-11 17:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:32:12 --> Email Class Initialized
INFO - 2020-09-11 17:32:12 --> Controller Class Initialized
DEBUG - 2020-09-11 17:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:32:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:32:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 17:32:12 --> Final output sent to browser
DEBUG - 2020-09-11 17:32:12 --> Total execution time: 0.0189
ERROR - 2020-09-11 17:32:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:32:16 --> Config Class Initialized
INFO - 2020-09-11 17:32:16 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:32:16 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:32:16 --> Utf8 Class Initialized
INFO - 2020-09-11 17:32:16 --> URI Class Initialized
INFO - 2020-09-11 17:32:16 --> Router Class Initialized
INFO - 2020-09-11 17:32:16 --> Output Class Initialized
INFO - 2020-09-11 17:32:16 --> Security Class Initialized
DEBUG - 2020-09-11 17:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:32:16 --> Input Class Initialized
INFO - 2020-09-11 17:32:16 --> Language Class Initialized
INFO - 2020-09-11 17:32:16 --> Loader Class Initialized
INFO - 2020-09-11 17:32:16 --> Helper loaded: url_helper
INFO - 2020-09-11 17:32:16 --> Database Driver Class Initialized
INFO - 2020-09-11 17:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:32:16 --> Email Class Initialized
INFO - 2020-09-11 17:32:16 --> Controller Class Initialized
DEBUG - 2020-09-11 17:32:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:32:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:32:16 --> Model Class Initialized
INFO - 2020-09-11 17:32:16 --> Model Class Initialized
INFO - 2020-09-11 17:32:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 17:32:16 --> Final output sent to browser
DEBUG - 2020-09-11 17:32:16 --> Total execution time: 0.0221
ERROR - 2020-09-11 17:34:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:34:45 --> Config Class Initialized
INFO - 2020-09-11 17:34:45 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:34:45 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:34:45 --> Utf8 Class Initialized
INFO - 2020-09-11 17:34:45 --> URI Class Initialized
INFO - 2020-09-11 17:34:45 --> Router Class Initialized
INFO - 2020-09-11 17:34:45 --> Output Class Initialized
INFO - 2020-09-11 17:34:45 --> Security Class Initialized
DEBUG - 2020-09-11 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:34:45 --> Input Class Initialized
INFO - 2020-09-11 17:34:45 --> Language Class Initialized
INFO - 2020-09-11 17:34:45 --> Loader Class Initialized
INFO - 2020-09-11 17:34:45 --> Helper loaded: url_helper
INFO - 2020-09-11 17:34:45 --> Database Driver Class Initialized
INFO - 2020-09-11 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:34:45 --> Email Class Initialized
INFO - 2020-09-11 17:34:45 --> Controller Class Initialized
DEBUG - 2020-09-11 17:34:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:34:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:34:45 --> Model Class Initialized
INFO - 2020-09-11 17:34:45 --> Model Class Initialized
INFO - 2020-09-11 17:34:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 17:34:45 --> Final output sent to browser
DEBUG - 2020-09-11 17:34:45 --> Total execution time: 0.0210
ERROR - 2020-09-11 17:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:34:47 --> Config Class Initialized
INFO - 2020-09-11 17:34:47 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:34:47 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:34:47 --> Utf8 Class Initialized
INFO - 2020-09-11 17:34:47 --> URI Class Initialized
INFO - 2020-09-11 17:34:47 --> Router Class Initialized
INFO - 2020-09-11 17:34:47 --> Output Class Initialized
INFO - 2020-09-11 17:34:47 --> Security Class Initialized
DEBUG - 2020-09-11 17:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:34:47 --> Input Class Initialized
INFO - 2020-09-11 17:34:47 --> Language Class Initialized
INFO - 2020-09-11 17:34:47 --> Loader Class Initialized
INFO - 2020-09-11 17:34:47 --> Helper loaded: url_helper
INFO - 2020-09-11 17:34:47 --> Database Driver Class Initialized
INFO - 2020-09-11 17:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:34:47 --> Email Class Initialized
INFO - 2020-09-11 17:34:47 --> Controller Class Initialized
DEBUG - 2020-09-11 17:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:34:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:34:47 --> Model Class Initialized
INFO - 2020-09-11 17:34:47 --> Model Class Initialized
INFO - 2020-09-11 17:34:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:34:47 --> Final output sent to browser
DEBUG - 2020-09-11 17:34:47 --> Total execution time: 0.0174
ERROR - 2020-09-11 17:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:39:22 --> Config Class Initialized
INFO - 2020-09-11 17:39:22 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:39:22 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:39:22 --> Utf8 Class Initialized
INFO - 2020-09-11 17:39:22 --> URI Class Initialized
INFO - 2020-09-11 17:39:22 --> Router Class Initialized
INFO - 2020-09-11 17:39:22 --> Output Class Initialized
INFO - 2020-09-11 17:39:22 --> Security Class Initialized
DEBUG - 2020-09-11 17:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:39:22 --> Input Class Initialized
INFO - 2020-09-11 17:39:22 --> Language Class Initialized
INFO - 2020-09-11 17:39:22 --> Loader Class Initialized
INFO - 2020-09-11 17:39:22 --> Helper loaded: url_helper
INFO - 2020-09-11 17:39:22 --> Database Driver Class Initialized
INFO - 2020-09-11 17:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:39:22 --> Email Class Initialized
INFO - 2020-09-11 17:39:22 --> Controller Class Initialized
DEBUG - 2020-09-11 17:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:39:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:39:22 --> Model Class Initialized
INFO - 2020-09-11 17:39:22 --> Model Class Initialized
INFO - 2020-09-11 17:39:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:39:22 --> Final output sent to browser
DEBUG - 2020-09-11 17:39:22 --> Total execution time: 0.0199
ERROR - 2020-09-11 17:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:40:29 --> Config Class Initialized
INFO - 2020-09-11 17:40:29 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:40:29 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:40:29 --> Utf8 Class Initialized
INFO - 2020-09-11 17:40:29 --> URI Class Initialized
INFO - 2020-09-11 17:40:29 --> Router Class Initialized
INFO - 2020-09-11 17:40:29 --> Output Class Initialized
INFO - 2020-09-11 17:40:29 --> Security Class Initialized
DEBUG - 2020-09-11 17:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:40:29 --> Input Class Initialized
INFO - 2020-09-11 17:40:29 --> Language Class Initialized
INFO - 2020-09-11 17:40:29 --> Loader Class Initialized
INFO - 2020-09-11 17:40:29 --> Helper loaded: url_helper
INFO - 2020-09-11 17:40:29 --> Database Driver Class Initialized
INFO - 2020-09-11 17:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:40:29 --> Email Class Initialized
INFO - 2020-09-11 17:40:29 --> Controller Class Initialized
DEBUG - 2020-09-11 17:40:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:40:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:40:29 --> Model Class Initialized
INFO - 2020-09-11 17:40:29 --> Model Class Initialized
INFO - 2020-09-11 17:40:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:40:29 --> Final output sent to browser
DEBUG - 2020-09-11 17:40:29 --> Total execution time: 0.0191
ERROR - 2020-09-11 17:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:47:09 --> Config Class Initialized
INFO - 2020-09-11 17:47:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:47:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:47:09 --> Utf8 Class Initialized
INFO - 2020-09-11 17:47:09 --> URI Class Initialized
INFO - 2020-09-11 17:47:09 --> Router Class Initialized
INFO - 2020-09-11 17:47:09 --> Output Class Initialized
INFO - 2020-09-11 17:47:09 --> Security Class Initialized
DEBUG - 2020-09-11 17:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:47:09 --> Input Class Initialized
INFO - 2020-09-11 17:47:09 --> Language Class Initialized
INFO - 2020-09-11 17:47:09 --> Loader Class Initialized
INFO - 2020-09-11 17:47:09 --> Helper loaded: url_helper
INFO - 2020-09-11 17:47:09 --> Database Driver Class Initialized
INFO - 2020-09-11 17:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:47:09 --> Email Class Initialized
INFO - 2020-09-11 17:47:09 --> Controller Class Initialized
DEBUG - 2020-09-11 17:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:47:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:47:09 --> Model Class Initialized
INFO - 2020-09-11 17:47:09 --> Model Class Initialized
INFO - 2020-09-11 17:47:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:47:09 --> Final output sent to browser
DEBUG - 2020-09-11 17:47:09 --> Total execution time: 0.0194
ERROR - 2020-09-11 17:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:48:14 --> Config Class Initialized
INFO - 2020-09-11 17:48:14 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:48:14 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:48:14 --> Utf8 Class Initialized
INFO - 2020-09-11 17:48:14 --> URI Class Initialized
INFO - 2020-09-11 17:48:14 --> Router Class Initialized
INFO - 2020-09-11 17:48:14 --> Output Class Initialized
INFO - 2020-09-11 17:48:14 --> Security Class Initialized
DEBUG - 2020-09-11 17:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:48:14 --> Input Class Initialized
INFO - 2020-09-11 17:48:14 --> Language Class Initialized
INFO - 2020-09-11 17:48:14 --> Loader Class Initialized
INFO - 2020-09-11 17:48:14 --> Helper loaded: url_helper
INFO - 2020-09-11 17:48:14 --> Database Driver Class Initialized
INFO - 2020-09-11 17:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:48:14 --> Email Class Initialized
INFO - 2020-09-11 17:48:14 --> Controller Class Initialized
DEBUG - 2020-09-11 17:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:48:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:48:14 --> Model Class Initialized
INFO - 2020-09-11 17:48:14 --> Model Class Initialized
INFO - 2020-09-11 17:48:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:48:14 --> Final output sent to browser
DEBUG - 2020-09-11 17:48:14 --> Total execution time: 0.0241
ERROR - 2020-09-11 17:49:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:49:00 --> Config Class Initialized
INFO - 2020-09-11 17:49:00 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:49:00 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:49:00 --> Utf8 Class Initialized
INFO - 2020-09-11 17:49:00 --> URI Class Initialized
INFO - 2020-09-11 17:49:00 --> Router Class Initialized
INFO - 2020-09-11 17:49:00 --> Output Class Initialized
INFO - 2020-09-11 17:49:00 --> Security Class Initialized
DEBUG - 2020-09-11 17:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:49:00 --> Input Class Initialized
INFO - 2020-09-11 17:49:00 --> Language Class Initialized
INFO - 2020-09-11 17:49:00 --> Loader Class Initialized
INFO - 2020-09-11 17:49:00 --> Helper loaded: url_helper
INFO - 2020-09-11 17:49:00 --> Database Driver Class Initialized
INFO - 2020-09-11 17:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:49:00 --> Email Class Initialized
INFO - 2020-09-11 17:49:00 --> Controller Class Initialized
DEBUG - 2020-09-11 17:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:49:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:49:00 --> Model Class Initialized
INFO - 2020-09-11 17:49:00 --> Model Class Initialized
INFO - 2020-09-11 17:49:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:49:00 --> Final output sent to browser
DEBUG - 2020-09-11 17:49:00 --> Total execution time: 0.0206
ERROR - 2020-09-11 17:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:49:25 --> Config Class Initialized
INFO - 2020-09-11 17:49:25 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:49:25 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:49:25 --> Utf8 Class Initialized
INFO - 2020-09-11 17:49:25 --> URI Class Initialized
INFO - 2020-09-11 17:49:25 --> Router Class Initialized
INFO - 2020-09-11 17:49:25 --> Output Class Initialized
INFO - 2020-09-11 17:49:25 --> Security Class Initialized
DEBUG - 2020-09-11 17:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:49:25 --> Input Class Initialized
INFO - 2020-09-11 17:49:25 --> Language Class Initialized
INFO - 2020-09-11 17:49:25 --> Loader Class Initialized
INFO - 2020-09-11 17:49:25 --> Helper loaded: url_helper
INFO - 2020-09-11 17:49:25 --> Database Driver Class Initialized
INFO - 2020-09-11 17:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:49:25 --> Email Class Initialized
INFO - 2020-09-11 17:49:25 --> Controller Class Initialized
DEBUG - 2020-09-11 17:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:49:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:49:25 --> Model Class Initialized
INFO - 2020-09-11 17:49:25 --> Model Class Initialized
INFO - 2020-09-11 17:49:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 17:49:25 --> Final output sent to browser
DEBUG - 2020-09-11 17:49:25 --> Total execution time: 0.0173
ERROR - 2020-09-11 17:49:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:49:46 --> Config Class Initialized
INFO - 2020-09-11 17:49:46 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:49:46 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:49:46 --> Utf8 Class Initialized
INFO - 2020-09-11 17:49:46 --> URI Class Initialized
INFO - 2020-09-11 17:49:46 --> Router Class Initialized
INFO - 2020-09-11 17:49:46 --> Output Class Initialized
INFO - 2020-09-11 17:49:46 --> Security Class Initialized
DEBUG - 2020-09-11 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:49:46 --> Input Class Initialized
INFO - 2020-09-11 17:49:46 --> Language Class Initialized
INFO - 2020-09-11 17:49:46 --> Loader Class Initialized
INFO - 2020-09-11 17:49:46 --> Helper loaded: url_helper
INFO - 2020-09-11 17:49:46 --> Database Driver Class Initialized
INFO - 2020-09-11 17:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:49:46 --> Email Class Initialized
INFO - 2020-09-11 17:49:46 --> Controller Class Initialized
DEBUG - 2020-09-11 17:49:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:49:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:49:46 --> Model Class Initialized
INFO - 2020-09-11 17:49:46 --> Model Class Initialized
INFO - 2020-09-11 17:49:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 17:49:46 --> Final output sent to browser
DEBUG - 2020-09-11 17:49:46 --> Total execution time: 0.0213
ERROR - 2020-09-11 17:59:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:59:15 --> Config Class Initialized
INFO - 2020-09-11 17:59:15 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:59:15 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:59:15 --> Utf8 Class Initialized
INFO - 2020-09-11 17:59:15 --> URI Class Initialized
INFO - 2020-09-11 17:59:15 --> Router Class Initialized
INFO - 2020-09-11 17:59:15 --> Output Class Initialized
INFO - 2020-09-11 17:59:15 --> Security Class Initialized
DEBUG - 2020-09-11 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:59:15 --> Input Class Initialized
INFO - 2020-09-11 17:59:15 --> Language Class Initialized
INFO - 2020-09-11 17:59:15 --> Loader Class Initialized
INFO - 2020-09-11 17:59:15 --> Helper loaded: url_helper
INFO - 2020-09-11 17:59:15 --> Database Driver Class Initialized
INFO - 2020-09-11 17:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:59:15 --> Email Class Initialized
INFO - 2020-09-11 17:59:15 --> Controller Class Initialized
DEBUG - 2020-09-11 17:59:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:59:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:59:15 --> Model Class Initialized
INFO - 2020-09-11 17:59:15 --> Model Class Initialized
INFO - 2020-09-11 17:59:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 17:59:15 --> Final output sent to browser
DEBUG - 2020-09-11 17:59:15 --> Total execution time: 0.0310
ERROR - 2020-09-11 17:59:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:59:17 --> Config Class Initialized
INFO - 2020-09-11 17:59:17 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:59:17 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:59:17 --> Utf8 Class Initialized
INFO - 2020-09-11 17:59:17 --> URI Class Initialized
INFO - 2020-09-11 17:59:17 --> Router Class Initialized
INFO - 2020-09-11 17:59:17 --> Output Class Initialized
INFO - 2020-09-11 17:59:17 --> Security Class Initialized
DEBUG - 2020-09-11 17:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:59:17 --> Input Class Initialized
INFO - 2020-09-11 17:59:17 --> Language Class Initialized
INFO - 2020-09-11 17:59:17 --> Loader Class Initialized
INFO - 2020-09-11 17:59:17 --> Helper loaded: url_helper
INFO - 2020-09-11 17:59:17 --> Database Driver Class Initialized
INFO - 2020-09-11 17:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:59:17 --> Email Class Initialized
INFO - 2020-09-11 17:59:17 --> Controller Class Initialized
DEBUG - 2020-09-11 17:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:59:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:59:17 --> Model Class Initialized
INFO - 2020-09-11 17:59:17 --> Model Class Initialized
INFO - 2020-09-11 17:59:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-11 17:59:17 --> Final output sent to browser
DEBUG - 2020-09-11 17:59:17 --> Total execution time: 0.0269
ERROR - 2020-09-11 17:59:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 17:59:28 --> Config Class Initialized
INFO - 2020-09-11 17:59:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 17:59:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 17:59:28 --> Utf8 Class Initialized
INFO - 2020-09-11 17:59:28 --> URI Class Initialized
INFO - 2020-09-11 17:59:28 --> Router Class Initialized
INFO - 2020-09-11 17:59:28 --> Output Class Initialized
INFO - 2020-09-11 17:59:28 --> Security Class Initialized
DEBUG - 2020-09-11 17:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 17:59:28 --> Input Class Initialized
INFO - 2020-09-11 17:59:28 --> Language Class Initialized
INFO - 2020-09-11 17:59:28 --> Loader Class Initialized
INFO - 2020-09-11 17:59:28 --> Helper loaded: url_helper
INFO - 2020-09-11 17:59:28 --> Database Driver Class Initialized
INFO - 2020-09-11 17:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 17:59:28 --> Email Class Initialized
INFO - 2020-09-11 17:59:28 --> Controller Class Initialized
DEBUG - 2020-09-11 17:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 17:59:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 17:59:28 --> Model Class Initialized
INFO - 2020-09-11 17:59:28 --> Model Class Initialized
INFO - 2020-09-11 17:59:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 17:59:28 --> Final output sent to browser
DEBUG - 2020-09-11 17:59:28 --> Total execution time: 0.0204
ERROR - 2020-09-11 18:06:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:06:40 --> Config Class Initialized
INFO - 2020-09-11 18:06:40 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:06:40 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:06:40 --> Utf8 Class Initialized
INFO - 2020-09-11 18:06:40 --> URI Class Initialized
INFO - 2020-09-11 18:06:40 --> Router Class Initialized
INFO - 2020-09-11 18:06:40 --> Output Class Initialized
INFO - 2020-09-11 18:06:40 --> Security Class Initialized
DEBUG - 2020-09-11 18:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:06:40 --> Input Class Initialized
INFO - 2020-09-11 18:06:40 --> Language Class Initialized
INFO - 2020-09-11 18:06:40 --> Loader Class Initialized
INFO - 2020-09-11 18:06:40 --> Helper loaded: url_helper
INFO - 2020-09-11 18:06:40 --> Database Driver Class Initialized
INFO - 2020-09-11 18:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:06:40 --> Email Class Initialized
INFO - 2020-09-11 18:06:40 --> Controller Class Initialized
DEBUG - 2020-09-11 18:06:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:06:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:06:40 --> Model Class Initialized
INFO - 2020-09-11 18:06:40 --> Model Class Initialized
INFO - 2020-09-11 18:06:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:06:40 --> Final output sent to browser
DEBUG - 2020-09-11 18:06:40 --> Total execution time: 0.0223
ERROR - 2020-09-11 18:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:06:43 --> Config Class Initialized
INFO - 2020-09-11 18:06:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:06:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:06:43 --> Utf8 Class Initialized
INFO - 2020-09-11 18:06:43 --> URI Class Initialized
INFO - 2020-09-11 18:06:43 --> Router Class Initialized
INFO - 2020-09-11 18:06:43 --> Output Class Initialized
INFO - 2020-09-11 18:06:43 --> Security Class Initialized
DEBUG - 2020-09-11 18:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:06:43 --> Input Class Initialized
INFO - 2020-09-11 18:06:43 --> Language Class Initialized
ERROR - 2020-09-11 18:06:43 --> 404 Page Not Found: Campain/campain_edit
ERROR - 2020-09-11 18:09:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:09:30 --> Config Class Initialized
INFO - 2020-09-11 18:09:30 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:09:30 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:09:30 --> Utf8 Class Initialized
INFO - 2020-09-11 18:09:30 --> URI Class Initialized
INFO - 2020-09-11 18:09:30 --> Router Class Initialized
INFO - 2020-09-11 18:09:30 --> Output Class Initialized
INFO - 2020-09-11 18:09:30 --> Security Class Initialized
DEBUG - 2020-09-11 18:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:09:30 --> Input Class Initialized
INFO - 2020-09-11 18:09:30 --> Language Class Initialized
INFO - 2020-09-11 18:09:30 --> Loader Class Initialized
INFO - 2020-09-11 18:09:30 --> Helper loaded: url_helper
INFO - 2020-09-11 18:09:30 --> Database Driver Class Initialized
INFO - 2020-09-11 18:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:09:30 --> Email Class Initialized
INFO - 2020-09-11 18:09:30 --> Controller Class Initialized
DEBUG - 2020-09-11 18:09:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:09:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:09:30 --> Model Class Initialized
INFO - 2020-09-11 18:09:30 --> Model Class Initialized
INFO - 2020-09-11 18:09:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-11 18:09:30 --> Final output sent to browser
DEBUG - 2020-09-11 18:09:30 --> Total execution time: 0.0242
ERROR - 2020-09-11 18:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:20:12 --> Config Class Initialized
INFO - 2020-09-11 18:20:12 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:20:12 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:20:12 --> Utf8 Class Initialized
INFO - 2020-09-11 18:20:12 --> URI Class Initialized
INFO - 2020-09-11 18:20:12 --> Router Class Initialized
INFO - 2020-09-11 18:20:12 --> Output Class Initialized
INFO - 2020-09-11 18:20:12 --> Security Class Initialized
DEBUG - 2020-09-11 18:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:20:12 --> Input Class Initialized
INFO - 2020-09-11 18:20:12 --> Language Class Initialized
INFO - 2020-09-11 18:20:12 --> Loader Class Initialized
INFO - 2020-09-11 18:20:12 --> Helper loaded: url_helper
INFO - 2020-09-11 18:20:12 --> Database Driver Class Initialized
INFO - 2020-09-11 18:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:20:12 --> Email Class Initialized
INFO - 2020-09-11 18:20:12 --> Controller Class Initialized
DEBUG - 2020-09-11 18:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:20:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:20:12 --> Model Class Initialized
INFO - 2020-09-11 18:20:12 --> Model Class Initialized
INFO - 2020-09-11 18:20:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-11 18:20:12 --> Final output sent to browser
DEBUG - 2020-09-11 18:20:12 --> Total execution time: 0.0226
ERROR - 2020-09-11 18:20:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:20:30 --> Config Class Initialized
INFO - 2020-09-11 18:20:30 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:20:30 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:20:30 --> Utf8 Class Initialized
INFO - 2020-09-11 18:20:30 --> URI Class Initialized
INFO - 2020-09-11 18:20:30 --> Router Class Initialized
INFO - 2020-09-11 18:20:30 --> Output Class Initialized
INFO - 2020-09-11 18:20:30 --> Security Class Initialized
DEBUG - 2020-09-11 18:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:20:30 --> Input Class Initialized
INFO - 2020-09-11 18:20:30 --> Language Class Initialized
INFO - 2020-09-11 18:20:30 --> Loader Class Initialized
INFO - 2020-09-11 18:20:30 --> Helper loaded: url_helper
INFO - 2020-09-11 18:20:30 --> Database Driver Class Initialized
INFO - 2020-09-11 18:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:20:30 --> Email Class Initialized
INFO - 2020-09-11 18:20:30 --> Controller Class Initialized
DEBUG - 2020-09-11 18:20:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:20:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:20:30 --> Model Class Initialized
INFO - 2020-09-11 18:20:30 --> Model Class Initialized
ERROR - 2020-09-11 18:20:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '10,10,10,10,1)' at line 1 - Invalid query: CALL campain_update('loan28',2,,10,10,10,10,1)
INFO - 2020-09-11 18:20:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-11 18:23:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:23:04 --> Config Class Initialized
INFO - 2020-09-11 18:23:04 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:23:04 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:23:04 --> Utf8 Class Initialized
INFO - 2020-09-11 18:23:04 --> URI Class Initialized
INFO - 2020-09-11 18:23:04 --> Router Class Initialized
INFO - 2020-09-11 18:23:04 --> Output Class Initialized
INFO - 2020-09-11 18:23:04 --> Security Class Initialized
DEBUG - 2020-09-11 18:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:23:04 --> Input Class Initialized
INFO - 2020-09-11 18:23:04 --> Language Class Initialized
INFO - 2020-09-11 18:23:04 --> Loader Class Initialized
INFO - 2020-09-11 18:23:04 --> Helper loaded: url_helper
INFO - 2020-09-11 18:23:04 --> Database Driver Class Initialized
INFO - 2020-09-11 18:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:23:04 --> Email Class Initialized
INFO - 2020-09-11 18:23:04 --> Controller Class Initialized
DEBUG - 2020-09-11 18:23:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:23:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:23:04 --> Model Class Initialized
INFO - 2020-09-11 18:23:04 --> Model Class Initialized
INFO - 2020-09-11 18:23:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:23:04 --> Final output sent to browser
DEBUG - 2020-09-11 18:23:04 --> Total execution time: 0.0239
ERROR - 2020-09-11 18:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:23:07 --> Config Class Initialized
INFO - 2020-09-11 18:23:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:23:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:23:07 --> Utf8 Class Initialized
INFO - 2020-09-11 18:23:07 --> URI Class Initialized
INFO - 2020-09-11 18:23:07 --> Router Class Initialized
INFO - 2020-09-11 18:23:07 --> Output Class Initialized
INFO - 2020-09-11 18:23:07 --> Security Class Initialized
DEBUG - 2020-09-11 18:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:23:07 --> Input Class Initialized
INFO - 2020-09-11 18:23:07 --> Language Class Initialized
INFO - 2020-09-11 18:23:07 --> Loader Class Initialized
INFO - 2020-09-11 18:23:07 --> Helper loaded: url_helper
INFO - 2020-09-11 18:23:07 --> Database Driver Class Initialized
INFO - 2020-09-11 18:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:23:07 --> Email Class Initialized
INFO - 2020-09-11 18:23:07 --> Controller Class Initialized
DEBUG - 2020-09-11 18:23:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:23:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:23:07 --> Model Class Initialized
INFO - 2020-09-11 18:23:07 --> Model Class Initialized
INFO - 2020-09-11 18:23:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-11 18:23:07 --> Final output sent to browser
DEBUG - 2020-09-11 18:23:07 --> Total execution time: 0.0232
ERROR - 2020-09-11 18:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:23:18 --> Config Class Initialized
INFO - 2020-09-11 18:23:18 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:23:18 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:23:18 --> Utf8 Class Initialized
INFO - 2020-09-11 18:23:18 --> URI Class Initialized
INFO - 2020-09-11 18:23:18 --> Router Class Initialized
INFO - 2020-09-11 18:23:18 --> Output Class Initialized
INFO - 2020-09-11 18:23:18 --> Security Class Initialized
DEBUG - 2020-09-11 18:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:23:18 --> Input Class Initialized
INFO - 2020-09-11 18:23:18 --> Language Class Initialized
INFO - 2020-09-11 18:23:18 --> Loader Class Initialized
INFO - 2020-09-11 18:23:18 --> Helper loaded: url_helper
INFO - 2020-09-11 18:23:18 --> Database Driver Class Initialized
INFO - 2020-09-11 18:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:23:18 --> Email Class Initialized
INFO - 2020-09-11 18:23:18 --> Controller Class Initialized
DEBUG - 2020-09-11 18:23:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:23:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:23:18 --> Model Class Initialized
INFO - 2020-09-11 18:23:18 --> Model Class Initialized
INFO - 2020-09-11 18:23:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:23:18 --> Final output sent to browser
DEBUG - 2020-09-11 18:23:18 --> Total execution time: 0.0287
ERROR - 2020-09-11 18:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:24:01 --> Config Class Initialized
INFO - 2020-09-11 18:24:01 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:24:01 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:24:01 --> Utf8 Class Initialized
INFO - 2020-09-11 18:24:01 --> URI Class Initialized
INFO - 2020-09-11 18:24:01 --> Router Class Initialized
INFO - 2020-09-11 18:24:01 --> Output Class Initialized
INFO - 2020-09-11 18:24:01 --> Security Class Initialized
DEBUG - 2020-09-11 18:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:24:01 --> Input Class Initialized
INFO - 2020-09-11 18:24:01 --> Language Class Initialized
INFO - 2020-09-11 18:24:01 --> Loader Class Initialized
INFO - 2020-09-11 18:24:01 --> Helper loaded: url_helper
INFO - 2020-09-11 18:24:01 --> Database Driver Class Initialized
INFO - 2020-09-11 18:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:24:01 --> Email Class Initialized
INFO - 2020-09-11 18:24:01 --> Controller Class Initialized
DEBUG - 2020-09-11 18:24:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:24:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:24:01 --> Model Class Initialized
INFO - 2020-09-11 18:24:01 --> Model Class Initialized
INFO - 2020-09-11 18:24:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:24:01 --> Final output sent to browser
DEBUG - 2020-09-11 18:24:01 --> Total execution time: 0.0193
ERROR - 2020-09-11 18:24:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:24:07 --> Config Class Initialized
INFO - 2020-09-11 18:24:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:24:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:24:07 --> Utf8 Class Initialized
INFO - 2020-09-11 18:24:07 --> URI Class Initialized
INFO - 2020-09-11 18:24:07 --> Router Class Initialized
INFO - 2020-09-11 18:24:07 --> Output Class Initialized
INFO - 2020-09-11 18:24:07 --> Security Class Initialized
DEBUG - 2020-09-11 18:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:24:07 --> Input Class Initialized
INFO - 2020-09-11 18:24:07 --> Language Class Initialized
INFO - 2020-09-11 18:24:07 --> Loader Class Initialized
INFO - 2020-09-11 18:24:07 --> Helper loaded: url_helper
INFO - 2020-09-11 18:24:07 --> Database Driver Class Initialized
INFO - 2020-09-11 18:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:24:07 --> Email Class Initialized
INFO - 2020-09-11 18:24:07 --> Controller Class Initialized
DEBUG - 2020-09-11 18:24:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:24:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:24:07 --> Model Class Initialized
INFO - 2020-09-11 18:24:07 --> Model Class Initialized
INFO - 2020-09-11 18:24:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 18:24:07 --> Final output sent to browser
DEBUG - 2020-09-11 18:24:07 --> Total execution time: 0.0177
ERROR - 2020-09-11 18:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:29:07 --> Config Class Initialized
INFO - 2020-09-11 18:29:07 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:29:07 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:29:07 --> Utf8 Class Initialized
INFO - 2020-09-11 18:29:07 --> URI Class Initialized
INFO - 2020-09-11 18:29:07 --> Router Class Initialized
INFO - 2020-09-11 18:29:07 --> Output Class Initialized
INFO - 2020-09-11 18:29:07 --> Security Class Initialized
DEBUG - 2020-09-11 18:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:29:07 --> Input Class Initialized
INFO - 2020-09-11 18:29:07 --> Language Class Initialized
INFO - 2020-09-11 18:29:07 --> Loader Class Initialized
INFO - 2020-09-11 18:29:07 --> Helper loaded: url_helper
INFO - 2020-09-11 18:29:07 --> Database Driver Class Initialized
INFO - 2020-09-11 18:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:29:07 --> Email Class Initialized
INFO - 2020-09-11 18:29:07 --> Controller Class Initialized
DEBUG - 2020-09-11 18:29:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:29:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:29:07 --> Model Class Initialized
INFO - 2020-09-11 18:29:07 --> Model Class Initialized
INFO - 2020-09-11 18:29:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 18:29:07 --> Final output sent to browser
DEBUG - 2020-09-11 18:29:07 --> Total execution time: 0.0258
ERROR - 2020-09-11 18:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:29:21 --> Config Class Initialized
INFO - 2020-09-11 18:29:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:29:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:29:21 --> Utf8 Class Initialized
INFO - 2020-09-11 18:29:21 --> URI Class Initialized
INFO - 2020-09-11 18:29:21 --> Router Class Initialized
INFO - 2020-09-11 18:29:21 --> Output Class Initialized
INFO - 2020-09-11 18:29:21 --> Security Class Initialized
DEBUG - 2020-09-11 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:29:21 --> Input Class Initialized
INFO - 2020-09-11 18:29:21 --> Language Class Initialized
INFO - 2020-09-11 18:29:21 --> Loader Class Initialized
INFO - 2020-09-11 18:29:21 --> Helper loaded: url_helper
INFO - 2020-09-11 18:29:21 --> Database Driver Class Initialized
INFO - 2020-09-11 18:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:29:21 --> Email Class Initialized
INFO - 2020-09-11 18:29:21 --> Controller Class Initialized
DEBUG - 2020-09-11 18:29:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:29:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:29:21 --> Model Class Initialized
INFO - 2020-09-11 18:29:21 --> Model Class Initialized
ERROR - 2020-09-11 18:29:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '33,33,33,33)' at line 1 - Invalid query: CALL campain_reg('vccn',,33,33,33,33)
INFO - 2020-09-11 18:29:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-11 18:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:30:06 --> Config Class Initialized
INFO - 2020-09-11 18:30:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:30:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:30:06 --> Utf8 Class Initialized
INFO - 2020-09-11 18:30:06 --> URI Class Initialized
INFO - 2020-09-11 18:30:06 --> Router Class Initialized
INFO - 2020-09-11 18:30:06 --> Output Class Initialized
INFO - 2020-09-11 18:30:06 --> Security Class Initialized
DEBUG - 2020-09-11 18:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:30:06 --> Input Class Initialized
INFO - 2020-09-11 18:30:06 --> Language Class Initialized
INFO - 2020-09-11 18:30:06 --> Loader Class Initialized
INFO - 2020-09-11 18:30:06 --> Helper loaded: url_helper
INFO - 2020-09-11 18:30:06 --> Database Driver Class Initialized
INFO - 2020-09-11 18:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:30:06 --> Email Class Initialized
INFO - 2020-09-11 18:30:06 --> Controller Class Initialized
DEBUG - 2020-09-11 18:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:30:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:30:06 --> Model Class Initialized
INFO - 2020-09-11 18:30:06 --> Model Class Initialized
INFO - 2020-09-11 18:30:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:30:06 --> Final output sent to browser
DEBUG - 2020-09-11 18:30:06 --> Total execution time: 0.0209
ERROR - 2020-09-11 18:30:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:30:09 --> Config Class Initialized
INFO - 2020-09-11 18:30:09 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:30:09 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:30:09 --> Utf8 Class Initialized
INFO - 2020-09-11 18:30:09 --> URI Class Initialized
INFO - 2020-09-11 18:30:09 --> Router Class Initialized
INFO - 2020-09-11 18:30:09 --> Output Class Initialized
INFO - 2020-09-11 18:30:09 --> Security Class Initialized
DEBUG - 2020-09-11 18:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:30:09 --> Input Class Initialized
INFO - 2020-09-11 18:30:09 --> Language Class Initialized
INFO - 2020-09-11 18:30:09 --> Loader Class Initialized
INFO - 2020-09-11 18:30:09 --> Helper loaded: url_helper
INFO - 2020-09-11 18:30:09 --> Database Driver Class Initialized
INFO - 2020-09-11 18:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:30:09 --> Email Class Initialized
INFO - 2020-09-11 18:30:09 --> Controller Class Initialized
DEBUG - 2020-09-11 18:30:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:30:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:30:09 --> Model Class Initialized
INFO - 2020-09-11 18:30:09 --> Model Class Initialized
INFO - 2020-09-11 18:30:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 18:30:09 --> Final output sent to browser
DEBUG - 2020-09-11 18:30:09 --> Total execution time: 0.0176
ERROR - 2020-09-11 18:30:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:30:21 --> Config Class Initialized
INFO - 2020-09-11 18:30:21 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:30:21 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:30:21 --> Utf8 Class Initialized
INFO - 2020-09-11 18:30:21 --> URI Class Initialized
INFO - 2020-09-11 18:30:21 --> Router Class Initialized
INFO - 2020-09-11 18:30:21 --> Output Class Initialized
INFO - 2020-09-11 18:30:21 --> Security Class Initialized
DEBUG - 2020-09-11 18:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:30:21 --> Input Class Initialized
INFO - 2020-09-11 18:30:21 --> Language Class Initialized
INFO - 2020-09-11 18:30:21 --> Loader Class Initialized
INFO - 2020-09-11 18:30:21 --> Helper loaded: url_helper
INFO - 2020-09-11 18:30:21 --> Database Driver Class Initialized
INFO - 2020-09-11 18:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:30:21 --> Email Class Initialized
INFO - 2020-09-11 18:30:21 --> Controller Class Initialized
DEBUG - 2020-09-11 18:30:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:30:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:30:21 --> Model Class Initialized
INFO - 2020-09-11 18:30:21 --> Model Class Initialized
ERROR - 2020-09-11 18:30:21 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-09-11 18:30:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:30:21 --> Final output sent to browser
DEBUG - 2020-09-11 18:30:21 --> Total execution time: 0.0204
ERROR - 2020-09-11 18:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:32:03 --> Config Class Initialized
INFO - 2020-09-11 18:32:03 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:32:03 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:32:03 --> Utf8 Class Initialized
INFO - 2020-09-11 18:32:03 --> URI Class Initialized
INFO - 2020-09-11 18:32:03 --> Router Class Initialized
INFO - 2020-09-11 18:32:03 --> Output Class Initialized
INFO - 2020-09-11 18:32:03 --> Security Class Initialized
DEBUG - 2020-09-11 18:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:32:03 --> Input Class Initialized
INFO - 2020-09-11 18:32:03 --> Language Class Initialized
INFO - 2020-09-11 18:32:03 --> Loader Class Initialized
INFO - 2020-09-11 18:32:03 --> Helper loaded: url_helper
INFO - 2020-09-11 18:32:03 --> Database Driver Class Initialized
INFO - 2020-09-11 18:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:32:03 --> Email Class Initialized
INFO - 2020-09-11 18:32:03 --> Controller Class Initialized
DEBUG - 2020-09-11 18:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:32:03 --> Model Class Initialized
INFO - 2020-09-11 18:32:03 --> Model Class Initialized
INFO - 2020-09-11 18:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:32:03 --> Final output sent to browser
DEBUG - 2020-09-11 18:32:03 --> Total execution time: 0.0193
ERROR - 2020-09-11 18:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:32:06 --> Config Class Initialized
INFO - 2020-09-11 18:32:06 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:32:06 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:32:06 --> Utf8 Class Initialized
INFO - 2020-09-11 18:32:06 --> URI Class Initialized
INFO - 2020-09-11 18:32:06 --> Router Class Initialized
INFO - 2020-09-11 18:32:06 --> Output Class Initialized
INFO - 2020-09-11 18:32:06 --> Security Class Initialized
DEBUG - 2020-09-11 18:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:32:06 --> Input Class Initialized
INFO - 2020-09-11 18:32:06 --> Language Class Initialized
INFO - 2020-09-11 18:32:06 --> Loader Class Initialized
INFO - 2020-09-11 18:32:06 --> Helper loaded: url_helper
INFO - 2020-09-11 18:32:06 --> Database Driver Class Initialized
INFO - 2020-09-11 18:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:32:06 --> Email Class Initialized
INFO - 2020-09-11 18:32:06 --> Controller Class Initialized
DEBUG - 2020-09-11 18:32:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:32:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:32:06 --> Model Class Initialized
INFO - 2020-09-11 18:32:06 --> Model Class Initialized
INFO - 2020-09-11 18:32:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-11 18:32:06 --> Final output sent to browser
DEBUG - 2020-09-11 18:32:06 --> Total execution time: 0.0171
ERROR - 2020-09-11 18:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:32:24 --> Config Class Initialized
INFO - 2020-09-11 18:32:24 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:32:24 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:32:24 --> Utf8 Class Initialized
INFO - 2020-09-11 18:32:24 --> URI Class Initialized
INFO - 2020-09-11 18:32:24 --> Router Class Initialized
INFO - 2020-09-11 18:32:24 --> Output Class Initialized
INFO - 2020-09-11 18:32:24 --> Security Class Initialized
DEBUG - 2020-09-11 18:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:32:24 --> Input Class Initialized
INFO - 2020-09-11 18:32:24 --> Language Class Initialized
INFO - 2020-09-11 18:32:24 --> Loader Class Initialized
INFO - 2020-09-11 18:32:24 --> Helper loaded: url_helper
INFO - 2020-09-11 18:32:24 --> Database Driver Class Initialized
INFO - 2020-09-11 18:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:32:24 --> Email Class Initialized
INFO - 2020-09-11 18:32:24 --> Controller Class Initialized
DEBUG - 2020-09-11 18:32:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:32:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:32:24 --> Model Class Initialized
INFO - 2020-09-11 18:32:24 --> Model Class Initialized
INFO - 2020-09-11 18:32:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:32:24 --> Final output sent to browser
DEBUG - 2020-09-11 18:32:24 --> Total execution time: 0.0217
ERROR - 2020-09-11 18:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:32:39 --> Config Class Initialized
INFO - 2020-09-11 18:32:39 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:32:39 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:32:39 --> Utf8 Class Initialized
INFO - 2020-09-11 18:32:39 --> URI Class Initialized
INFO - 2020-09-11 18:32:39 --> Router Class Initialized
INFO - 2020-09-11 18:32:39 --> Output Class Initialized
INFO - 2020-09-11 18:32:39 --> Security Class Initialized
DEBUG - 2020-09-11 18:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:32:39 --> Input Class Initialized
INFO - 2020-09-11 18:32:39 --> Language Class Initialized
INFO - 2020-09-11 18:32:39 --> Loader Class Initialized
INFO - 2020-09-11 18:32:39 --> Helper loaded: url_helper
INFO - 2020-09-11 18:32:39 --> Database Driver Class Initialized
INFO - 2020-09-11 18:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:32:39 --> Email Class Initialized
INFO - 2020-09-11 18:32:39 --> Controller Class Initialized
DEBUG - 2020-09-11 18:32:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:32:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:32:39 --> Model Class Initialized
INFO - 2020-09-11 18:32:39 --> Model Class Initialized
INFO - 2020-09-11 18:32:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-11 18:32:39 --> Final output sent to browser
DEBUG - 2020-09-11 18:32:39 --> Total execution time: 0.0177
ERROR - 2020-09-11 18:32:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:32:43 --> Config Class Initialized
INFO - 2020-09-11 18:32:43 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:32:43 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:32:43 --> Utf8 Class Initialized
INFO - 2020-09-11 18:32:43 --> URI Class Initialized
INFO - 2020-09-11 18:32:43 --> Router Class Initialized
INFO - 2020-09-11 18:32:43 --> Output Class Initialized
INFO - 2020-09-11 18:32:43 --> Security Class Initialized
DEBUG - 2020-09-11 18:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:32:43 --> Input Class Initialized
INFO - 2020-09-11 18:32:43 --> Language Class Initialized
INFO - 2020-09-11 18:32:43 --> Loader Class Initialized
INFO - 2020-09-11 18:32:43 --> Helper loaded: url_helper
INFO - 2020-09-11 18:32:43 --> Database Driver Class Initialized
INFO - 2020-09-11 18:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:32:43 --> Email Class Initialized
INFO - 2020-09-11 18:32:43 --> Controller Class Initialized
DEBUG - 2020-09-11 18:32:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:32:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:32:43 --> Model Class Initialized
INFO - 2020-09-11 18:32:43 --> Model Class Initialized
INFO - 2020-09-11 18:32:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:32:43 --> Final output sent to browser
DEBUG - 2020-09-11 18:32:43 --> Total execution time: 0.0197
ERROR - 2020-09-11 18:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:32:45 --> Config Class Initialized
INFO - 2020-09-11 18:32:45 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:32:45 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:32:45 --> Utf8 Class Initialized
INFO - 2020-09-11 18:32:45 --> URI Class Initialized
INFO - 2020-09-11 18:32:45 --> Router Class Initialized
INFO - 2020-09-11 18:32:45 --> Output Class Initialized
INFO - 2020-09-11 18:32:45 --> Security Class Initialized
DEBUG - 2020-09-11 18:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:32:45 --> Input Class Initialized
INFO - 2020-09-11 18:32:45 --> Language Class Initialized
INFO - 2020-09-11 18:32:45 --> Loader Class Initialized
INFO - 2020-09-11 18:32:45 --> Helper loaded: url_helper
INFO - 2020-09-11 18:32:45 --> Database Driver Class Initialized
INFO - 2020-09-11 18:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:32:45 --> Email Class Initialized
INFO - 2020-09-11 18:32:45 --> Controller Class Initialized
DEBUG - 2020-09-11 18:32:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:32:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:32:45 --> Model Class Initialized
INFO - 2020-09-11 18:32:45 --> Model Class Initialized
INFO - 2020-09-11 18:32:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-11 18:32:45 --> Final output sent to browser
DEBUG - 2020-09-11 18:32:45 --> Total execution time: 0.0218
ERROR - 2020-09-11 18:33:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:33:28 --> Config Class Initialized
INFO - 2020-09-11 18:33:28 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:33:28 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:33:28 --> Utf8 Class Initialized
INFO - 2020-09-11 18:33:28 --> URI Class Initialized
INFO - 2020-09-11 18:33:28 --> Router Class Initialized
INFO - 2020-09-11 18:33:28 --> Output Class Initialized
INFO - 2020-09-11 18:33:28 --> Security Class Initialized
DEBUG - 2020-09-11 18:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:33:28 --> Input Class Initialized
INFO - 2020-09-11 18:33:28 --> Language Class Initialized
INFO - 2020-09-11 18:33:28 --> Loader Class Initialized
INFO - 2020-09-11 18:33:28 --> Helper loaded: url_helper
INFO - 2020-09-11 18:33:28 --> Database Driver Class Initialized
INFO - 2020-09-11 18:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:33:28 --> Email Class Initialized
INFO - 2020-09-11 18:33:28 --> Controller Class Initialized
DEBUG - 2020-09-11 18:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:33:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:33:28 --> Model Class Initialized
INFO - 2020-09-11 18:33:28 --> Model Class Initialized
INFO - 2020-09-11 18:33:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-11 18:33:28 --> Final output sent to browser
DEBUG - 2020-09-11 18:33:28 --> Total execution time: 0.0243
ERROR - 2020-09-11 18:33:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:33:34 --> Config Class Initialized
INFO - 2020-09-11 18:33:34 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:33:34 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:33:34 --> Utf8 Class Initialized
INFO - 2020-09-11 18:33:34 --> URI Class Initialized
INFO - 2020-09-11 18:33:34 --> Router Class Initialized
INFO - 2020-09-11 18:33:34 --> Output Class Initialized
INFO - 2020-09-11 18:33:34 --> Security Class Initialized
DEBUG - 2020-09-11 18:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:33:34 --> Input Class Initialized
INFO - 2020-09-11 18:33:34 --> Language Class Initialized
INFO - 2020-09-11 18:33:34 --> Loader Class Initialized
INFO - 2020-09-11 18:33:34 --> Helper loaded: url_helper
INFO - 2020-09-11 18:33:34 --> Database Driver Class Initialized
INFO - 2020-09-11 18:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:33:34 --> Email Class Initialized
INFO - 2020-09-11 18:33:34 --> Controller Class Initialized
DEBUG - 2020-09-11 18:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:33:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:33:34 --> Model Class Initialized
INFO - 2020-09-11 18:33:34 --> Model Class Initialized
INFO - 2020-09-11 18:33:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-11 18:33:34 --> Final output sent to browser
DEBUG - 2020-09-11 18:33:34 --> Total execution time: 0.0175
ERROR - 2020-09-11 18:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:35:13 --> Config Class Initialized
INFO - 2020-09-11 18:35:13 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:35:13 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:35:13 --> Utf8 Class Initialized
INFO - 2020-09-11 18:35:13 --> URI Class Initialized
INFO - 2020-09-11 18:35:13 --> Router Class Initialized
INFO - 2020-09-11 18:35:13 --> Output Class Initialized
INFO - 2020-09-11 18:35:13 --> Security Class Initialized
DEBUG - 2020-09-11 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:35:13 --> Input Class Initialized
INFO - 2020-09-11 18:35:13 --> Language Class Initialized
INFO - 2020-09-11 18:35:13 --> Loader Class Initialized
INFO - 2020-09-11 18:35:13 --> Helper loaded: url_helper
INFO - 2020-09-11 18:35:13 --> Database Driver Class Initialized
INFO - 2020-09-11 18:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:35:13 --> Email Class Initialized
INFO - 2020-09-11 18:35:13 --> Controller Class Initialized
DEBUG - 2020-09-11 18:35:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-11 18:35:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:35:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-11 18:35:13 --> Final output sent to browser
DEBUG - 2020-09-11 18:35:13 --> Total execution time: 0.0179
ERROR - 2020-09-11 18:35:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-11 18:35:18 --> Config Class Initialized
INFO - 2020-09-11 18:35:18 --> Hooks Class Initialized
DEBUG - 2020-09-11 18:35:18 --> UTF-8 Support Enabled
INFO - 2020-09-11 18:35:18 --> Utf8 Class Initialized
INFO - 2020-09-11 18:35:18 --> URI Class Initialized
DEBUG - 2020-09-11 18:35:18 --> No URI present. Default controller set.
INFO - 2020-09-11 18:35:18 --> Router Class Initialized
INFO - 2020-09-11 18:35:18 --> Output Class Initialized
INFO - 2020-09-11 18:35:18 --> Security Class Initialized
DEBUG - 2020-09-11 18:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-11 18:35:18 --> Input Class Initialized
INFO - 2020-09-11 18:35:18 --> Language Class Initialized
INFO - 2020-09-11 18:35:18 --> Loader Class Initialized
INFO - 2020-09-11 18:35:18 --> Helper loaded: url_helper
INFO - 2020-09-11 18:35:18 --> Database Driver Class Initialized
INFO - 2020-09-11 18:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-11 18:35:18 --> Email Class Initialized
INFO - 2020-09-11 18:35:18 --> Controller Class Initialized
INFO - 2020-09-11 18:35:18 --> Model Class Initialized
INFO - 2020-09-11 18:35:18 --> Model Class Initialized
DEBUG - 2020-09-11 18:35:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-11 18:35:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-11 18:35:18 --> Final output sent to browser
DEBUG - 2020-09-11 18:35:18 --> Total execution time: 0.0170
