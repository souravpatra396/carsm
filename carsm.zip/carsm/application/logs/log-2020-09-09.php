<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-09 05:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 05:39:36 --> Config Class Initialized
INFO - 2020-09-09 05:39:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 05:39:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 05:39:36 --> Utf8 Class Initialized
INFO - 2020-09-09 05:39:36 --> URI Class Initialized
DEBUG - 2020-09-09 05:39:36 --> No URI present. Default controller set.
INFO - 2020-09-09 05:39:36 --> Router Class Initialized
INFO - 2020-09-09 05:39:36 --> Output Class Initialized
INFO - 2020-09-09 05:39:36 --> Security Class Initialized
DEBUG - 2020-09-09 05:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 05:39:36 --> Input Class Initialized
INFO - 2020-09-09 05:39:36 --> Language Class Initialized
INFO - 2020-09-09 05:39:36 --> Loader Class Initialized
INFO - 2020-09-09 05:39:36 --> Helper loaded: url_helper
INFO - 2020-09-09 05:39:36 --> Database Driver Class Initialized
INFO - 2020-09-09 05:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 05:39:36 --> Email Class Initialized
INFO - 2020-09-09 05:39:36 --> Controller Class Initialized
INFO - 2020-09-09 05:39:36 --> Model Class Initialized
INFO - 2020-09-09 05:39:36 --> Model Class Initialized
DEBUG - 2020-09-09 05:39:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 05:39:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 05:39:36 --> Final output sent to browser
DEBUG - 2020-09-09 05:39:36 --> Total execution time: 0.1188
ERROR - 2020-09-09 06:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:03:26 --> Config Class Initialized
INFO - 2020-09-09 06:03:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:03:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:03:26 --> Utf8 Class Initialized
INFO - 2020-09-09 06:03:26 --> URI Class Initialized
DEBUG - 2020-09-09 06:03:26 --> No URI present. Default controller set.
INFO - 2020-09-09 06:03:26 --> Router Class Initialized
INFO - 2020-09-09 06:03:26 --> Output Class Initialized
INFO - 2020-09-09 06:03:26 --> Security Class Initialized
DEBUG - 2020-09-09 06:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:03:26 --> Input Class Initialized
INFO - 2020-09-09 06:03:26 --> Language Class Initialized
INFO - 2020-09-09 06:03:26 --> Loader Class Initialized
INFO - 2020-09-09 06:03:26 --> Helper loaded: url_helper
INFO - 2020-09-09 06:03:26 --> Database Driver Class Initialized
INFO - 2020-09-09 06:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:03:26 --> Email Class Initialized
INFO - 2020-09-09 06:03:26 --> Controller Class Initialized
INFO - 2020-09-09 06:03:26 --> Model Class Initialized
INFO - 2020-09-09 06:03:26 --> Model Class Initialized
DEBUG - 2020-09-09 06:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 06:03:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 06:03:26 --> Final output sent to browser
DEBUG - 2020-09-09 06:03:26 --> Total execution time: 0.0208
ERROR - 2020-09-09 06:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:03:29 --> Config Class Initialized
INFO - 2020-09-09 06:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:03:29 --> Utf8 Class Initialized
INFO - 2020-09-09 06:03:29 --> URI Class Initialized
INFO - 2020-09-09 06:03:29 --> Router Class Initialized
INFO - 2020-09-09 06:03:29 --> Output Class Initialized
INFO - 2020-09-09 06:03:29 --> Security Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:03:29 --> Input Class Initialized
INFO - 2020-09-09 06:03:29 --> Language Class Initialized
INFO - 2020-09-09 06:03:29 --> Loader Class Initialized
INFO - 2020-09-09 06:03:29 --> Helper loaded: url_helper
INFO - 2020-09-09 06:03:29 --> Database Driver Class Initialized
INFO - 2020-09-09 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:03:29 --> Email Class Initialized
INFO - 2020-09-09 06:03:29 --> Controller Class Initialized
INFO - 2020-09-09 06:03:29 --> Model Class Initialized
INFO - 2020-09-09 06:03:29 --> Model Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:03:29 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-09 06:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:03:29 --> Config Class Initialized
INFO - 2020-09-09 06:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:03:29 --> Utf8 Class Initialized
INFO - 2020-09-09 06:03:29 --> URI Class Initialized
INFO - 2020-09-09 06:03:29 --> Router Class Initialized
INFO - 2020-09-09 06:03:29 --> Output Class Initialized
INFO - 2020-09-09 06:03:29 --> Security Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:03:29 --> Input Class Initialized
INFO - 2020-09-09 06:03:29 --> Language Class Initialized
INFO - 2020-09-09 06:03:29 --> Loader Class Initialized
INFO - 2020-09-09 06:03:29 --> Helper loaded: url_helper
INFO - 2020-09-09 06:03:29 --> Database Driver Class Initialized
INFO - 2020-09-09 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:03:29 --> Email Class Initialized
INFO - 2020-09-09 06:03:29 --> Controller Class Initialized
INFO - 2020-09-09 06:03:29 --> Model Class Initialized
INFO - 2020-09-09 06:03:29 --> Model Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 06:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:03:29 --> Config Class Initialized
INFO - 2020-09-09 06:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:03:29 --> Utf8 Class Initialized
INFO - 2020-09-09 06:03:29 --> URI Class Initialized
DEBUG - 2020-09-09 06:03:29 --> No URI present. Default controller set.
INFO - 2020-09-09 06:03:29 --> Router Class Initialized
INFO - 2020-09-09 06:03:29 --> Output Class Initialized
INFO - 2020-09-09 06:03:29 --> Security Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:03:29 --> Input Class Initialized
INFO - 2020-09-09 06:03:29 --> Language Class Initialized
INFO - 2020-09-09 06:03:29 --> Loader Class Initialized
INFO - 2020-09-09 06:03:29 --> Helper loaded: url_helper
INFO - 2020-09-09 06:03:29 --> Database Driver Class Initialized
INFO - 2020-09-09 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:03:29 --> Email Class Initialized
INFO - 2020-09-09 06:03:29 --> Controller Class Initialized
INFO - 2020-09-09 06:03:29 --> Model Class Initialized
INFO - 2020-09-09 06:03:29 --> Model Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 06:03:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 06:03:29 --> Final output sent to browser
DEBUG - 2020-09-09 06:03:29 --> Total execution time: 0.0222
ERROR - 2020-09-09 06:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:03:29 --> Config Class Initialized
INFO - 2020-09-09 06:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:03:29 --> Utf8 Class Initialized
INFO - 2020-09-09 06:03:29 --> URI Class Initialized
INFO - 2020-09-09 06:03:29 --> Router Class Initialized
INFO - 2020-09-09 06:03:29 --> Output Class Initialized
INFO - 2020-09-09 06:03:29 --> Security Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:03:29 --> Input Class Initialized
INFO - 2020-09-09 06:03:29 --> Language Class Initialized
INFO - 2020-09-09 06:03:29 --> Loader Class Initialized
INFO - 2020-09-09 06:03:29 --> Helper loaded: url_helper
INFO - 2020-09-09 06:03:29 --> Database Driver Class Initialized
INFO - 2020-09-09 06:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:03:29 --> Email Class Initialized
INFO - 2020-09-09 06:03:29 --> Controller Class Initialized
DEBUG - 2020-09-09 06:03:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 06:03:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 06:03:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 06:03:29 --> Final output sent to browser
DEBUG - 2020-09-09 06:03:29 --> Total execution time: 0.0470
ERROR - 2020-09-09 06:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:04:30 --> Config Class Initialized
INFO - 2020-09-09 06:04:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:04:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:04:30 --> Utf8 Class Initialized
INFO - 2020-09-09 06:04:30 --> URI Class Initialized
INFO - 2020-09-09 06:04:30 --> Router Class Initialized
INFO - 2020-09-09 06:04:30 --> Output Class Initialized
INFO - 2020-09-09 06:04:30 --> Security Class Initialized
DEBUG - 2020-09-09 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:04:30 --> Input Class Initialized
INFO - 2020-09-09 06:04:30 --> Language Class Initialized
ERROR - 2020-09-09 06:04:30 --> 404 Page Not Found: Excle_import/upload_excle
ERROR - 2020-09-09 06:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:05:04 --> Config Class Initialized
INFO - 2020-09-09 06:05:04 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:05:04 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:05:04 --> Utf8 Class Initialized
INFO - 2020-09-09 06:05:04 --> URI Class Initialized
INFO - 2020-09-09 06:05:04 --> Router Class Initialized
INFO - 2020-09-09 06:05:04 --> Output Class Initialized
INFO - 2020-09-09 06:05:04 --> Security Class Initialized
DEBUG - 2020-09-09 06:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:05:04 --> Input Class Initialized
INFO - 2020-09-09 06:05:04 --> Language Class Initialized
ERROR - 2020-09-09 06:05:04 --> 404 Page Not Found: Excel_import/upload_excle
ERROR - 2020-09-09 06:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:05:26 --> Config Class Initialized
INFO - 2020-09-09 06:05:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:05:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:05:26 --> Utf8 Class Initialized
INFO - 2020-09-09 06:05:26 --> URI Class Initialized
INFO - 2020-09-09 06:05:26 --> Router Class Initialized
INFO - 2020-09-09 06:05:26 --> Output Class Initialized
INFO - 2020-09-09 06:05:26 --> Security Class Initialized
DEBUG - 2020-09-09 06:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:05:26 --> Input Class Initialized
INFO - 2020-09-09 06:05:26 --> Language Class Initialized
INFO - 2020-09-09 06:05:26 --> Loader Class Initialized
INFO - 2020-09-09 06:05:26 --> Helper loaded: url_helper
INFO - 2020-09-09 06:05:26 --> Database Driver Class Initialized
INFO - 2020-09-09 06:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:05:26 --> Email Class Initialized
INFO - 2020-09-09 06:05:26 --> Controller Class Initialized
INFO - 2020-09-09 06:05:26 --> Model Class Initialized
INFO - 2020-09-09 06:05:26 --> Model Class Initialized
INFO - 2020-09-09 06:05:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 06:05:27 --> Final output sent to browser
DEBUG - 2020-09-09 06:05:27 --> Total execution time: 0.2050
ERROR - 2020-09-09 06:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:05:28 --> Config Class Initialized
INFO - 2020-09-09 06:05:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:05:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:05:28 --> Utf8 Class Initialized
INFO - 2020-09-09 06:05:28 --> URI Class Initialized
INFO - 2020-09-09 06:05:28 --> Router Class Initialized
INFO - 2020-09-09 06:05:28 --> Output Class Initialized
INFO - 2020-09-09 06:05:28 --> Security Class Initialized
DEBUG - 2020-09-09 06:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:05:28 --> Input Class Initialized
INFO - 2020-09-09 06:05:28 --> Language Class Initialized
INFO - 2020-09-09 06:05:28 --> Loader Class Initialized
INFO - 2020-09-09 06:05:28 --> Helper loaded: url_helper
INFO - 2020-09-09 06:05:28 --> Database Driver Class Initialized
INFO - 2020-09-09 06:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:05:28 --> Email Class Initialized
INFO - 2020-09-09 06:05:28 --> Controller Class Initialized
INFO - 2020-09-09 06:05:28 --> Model Class Initialized
INFO - 2020-09-09 06:05:28 --> Model Class Initialized
ERROR - 2020-09-09 06:05:28 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 06:05:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 06:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:33:23 --> Config Class Initialized
INFO - 2020-09-09 06:33:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:33:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:33:23 --> Utf8 Class Initialized
INFO - 2020-09-09 06:33:23 --> URI Class Initialized
INFO - 2020-09-09 06:33:23 --> Router Class Initialized
INFO - 2020-09-09 06:33:23 --> Output Class Initialized
INFO - 2020-09-09 06:33:23 --> Security Class Initialized
DEBUG - 2020-09-09 06:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:33:23 --> Input Class Initialized
INFO - 2020-09-09 06:33:23 --> Language Class Initialized
INFO - 2020-09-09 06:33:23 --> Loader Class Initialized
INFO - 2020-09-09 06:33:23 --> Helper loaded: url_helper
INFO - 2020-09-09 06:33:23 --> Database Driver Class Initialized
INFO - 2020-09-09 06:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:33:23 --> Email Class Initialized
INFO - 2020-09-09 06:33:23 --> Controller Class Initialized
INFO - 2020-09-09 06:33:23 --> Model Class Initialized
INFO - 2020-09-09 06:33:23 --> Model Class Initialized
INFO - 2020-09-09 06:33:23 --> Final output sent to browser
DEBUG - 2020-09-09 06:33:23 --> Total execution time: 0.2712
ERROR - 2020-09-09 06:33:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 06:33:23 --> Config Class Initialized
INFO - 2020-09-09 06:33:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 06:33:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 06:33:23 --> Utf8 Class Initialized
INFO - 2020-09-09 06:33:23 --> URI Class Initialized
INFO - 2020-09-09 06:33:23 --> Router Class Initialized
INFO - 2020-09-09 06:33:23 --> Output Class Initialized
INFO - 2020-09-09 06:33:23 --> Security Class Initialized
DEBUG - 2020-09-09 06:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 06:33:23 --> Input Class Initialized
INFO - 2020-09-09 06:33:23 --> Language Class Initialized
INFO - 2020-09-09 06:33:23 --> Loader Class Initialized
INFO - 2020-09-09 06:33:23 --> Helper loaded: url_helper
INFO - 2020-09-09 06:33:23 --> Database Driver Class Initialized
INFO - 2020-09-09 06:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 06:33:23 --> Email Class Initialized
INFO - 2020-09-09 06:33:23 --> Controller Class Initialized
INFO - 2020-09-09 06:33:23 --> Model Class Initialized
INFO - 2020-09-09 06:33:23 --> Model Class Initialized
ERROR - 2020-09-09 06:33:23 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 06:33:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 09:13:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:13:05 --> Config Class Initialized
INFO - 2020-09-09 09:13:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:13:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:13:05 --> Utf8 Class Initialized
INFO - 2020-09-09 09:13:05 --> URI Class Initialized
DEBUG - 2020-09-09 09:13:05 --> No URI present. Default controller set.
INFO - 2020-09-09 09:13:05 --> Router Class Initialized
INFO - 2020-09-09 09:13:05 --> Output Class Initialized
INFO - 2020-09-09 09:13:05 --> Security Class Initialized
DEBUG - 2020-09-09 09:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:13:05 --> Input Class Initialized
INFO - 2020-09-09 09:13:05 --> Language Class Initialized
INFO - 2020-09-09 09:13:05 --> Loader Class Initialized
INFO - 2020-09-09 09:13:05 --> Helper loaded: url_helper
INFO - 2020-09-09 09:13:05 --> Database Driver Class Initialized
INFO - 2020-09-09 09:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:13:05 --> Email Class Initialized
INFO - 2020-09-09 09:13:05 --> Controller Class Initialized
INFO - 2020-09-09 09:13:05 --> Model Class Initialized
INFO - 2020-09-09 09:13:05 --> Model Class Initialized
DEBUG - 2020-09-09 09:13:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:13:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 09:13:05 --> Final output sent to browser
DEBUG - 2020-09-09 09:13:05 --> Total execution time: 0.0200
ERROR - 2020-09-09 09:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:13:07 --> Config Class Initialized
INFO - 2020-09-09 09:13:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:13:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:13:07 --> Utf8 Class Initialized
INFO - 2020-09-09 09:13:07 --> URI Class Initialized
INFO - 2020-09-09 09:13:07 --> Router Class Initialized
INFO - 2020-09-09 09:13:07 --> Output Class Initialized
INFO - 2020-09-09 09:13:07 --> Security Class Initialized
DEBUG - 2020-09-09 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:13:07 --> Input Class Initialized
INFO - 2020-09-09 09:13:07 --> Language Class Initialized
INFO - 2020-09-09 09:13:07 --> Loader Class Initialized
INFO - 2020-09-09 09:13:07 --> Helper loaded: url_helper
INFO - 2020-09-09 09:13:07 --> Database Driver Class Initialized
INFO - 2020-09-09 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:13:07 --> Email Class Initialized
INFO - 2020-09-09 09:13:07 --> Controller Class Initialized
INFO - 2020-09-09 09:13:07 --> Model Class Initialized
INFO - 2020-09-09 09:13:07 --> Model Class Initialized
DEBUG - 2020-09-09 09:13:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:13:07 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-09 09:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:13:07 --> Config Class Initialized
INFO - 2020-09-09 09:13:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:13:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:13:07 --> Utf8 Class Initialized
INFO - 2020-09-09 09:13:07 --> URI Class Initialized
INFO - 2020-09-09 09:13:07 --> Router Class Initialized
INFO - 2020-09-09 09:13:07 --> Output Class Initialized
INFO - 2020-09-09 09:13:07 --> Security Class Initialized
DEBUG - 2020-09-09 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:13:07 --> Input Class Initialized
INFO - 2020-09-09 09:13:07 --> Language Class Initialized
INFO - 2020-09-09 09:13:07 --> Loader Class Initialized
INFO - 2020-09-09 09:13:07 --> Helper loaded: url_helper
INFO - 2020-09-09 09:13:07 --> Database Driver Class Initialized
INFO - 2020-09-09 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:13:07 --> Email Class Initialized
INFO - 2020-09-09 09:13:07 --> Controller Class Initialized
INFO - 2020-09-09 09:13:07 --> Model Class Initialized
INFO - 2020-09-09 09:13:07 --> Model Class Initialized
DEBUG - 2020-09-09 09:13:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 09:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:13:07 --> Config Class Initialized
INFO - 2020-09-09 09:13:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:13:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:13:07 --> Utf8 Class Initialized
INFO - 2020-09-09 09:13:07 --> URI Class Initialized
DEBUG - 2020-09-09 09:13:07 --> No URI present. Default controller set.
INFO - 2020-09-09 09:13:07 --> Router Class Initialized
INFO - 2020-09-09 09:13:07 --> Output Class Initialized
INFO - 2020-09-09 09:13:07 --> Security Class Initialized
DEBUG - 2020-09-09 09:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:13:07 --> Input Class Initialized
INFO - 2020-09-09 09:13:07 --> Language Class Initialized
INFO - 2020-09-09 09:13:07 --> Loader Class Initialized
INFO - 2020-09-09 09:13:07 --> Helper loaded: url_helper
INFO - 2020-09-09 09:13:07 --> Database Driver Class Initialized
INFO - 2020-09-09 09:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:13:07 --> Email Class Initialized
INFO - 2020-09-09 09:13:07 --> Controller Class Initialized
INFO - 2020-09-09 09:13:07 --> Model Class Initialized
INFO - 2020-09-09 09:13:07 --> Model Class Initialized
DEBUG - 2020-09-09 09:13:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:13:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 09:13:07 --> Final output sent to browser
DEBUG - 2020-09-09 09:13:07 --> Total execution time: 0.0194
ERROR - 2020-09-09 09:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:13:08 --> Config Class Initialized
INFO - 2020-09-09 09:13:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:13:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:13:08 --> Utf8 Class Initialized
INFO - 2020-09-09 09:13:08 --> URI Class Initialized
INFO - 2020-09-09 09:13:08 --> Router Class Initialized
INFO - 2020-09-09 09:13:08 --> Output Class Initialized
INFO - 2020-09-09 09:13:08 --> Security Class Initialized
DEBUG - 2020-09-09 09:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:13:08 --> Input Class Initialized
INFO - 2020-09-09 09:13:08 --> Language Class Initialized
INFO - 2020-09-09 09:13:08 --> Loader Class Initialized
INFO - 2020-09-09 09:13:08 --> Helper loaded: url_helper
INFO - 2020-09-09 09:13:08 --> Database Driver Class Initialized
INFO - 2020-09-09 09:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:13:08 --> Email Class Initialized
INFO - 2020-09-09 09:13:08 --> Controller Class Initialized
DEBUG - 2020-09-09 09:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:13:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:13:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 09:13:08 --> Final output sent to browser
DEBUG - 2020-09-09 09:13:08 --> Total execution time: 0.0204
ERROR - 2020-09-09 09:15:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:15:14 --> Config Class Initialized
INFO - 2020-09-09 09:15:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:15:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:15:14 --> Utf8 Class Initialized
INFO - 2020-09-09 09:15:14 --> URI Class Initialized
INFO - 2020-09-09 09:15:14 --> Router Class Initialized
INFO - 2020-09-09 09:15:14 --> Output Class Initialized
INFO - 2020-09-09 09:15:14 --> Security Class Initialized
DEBUG - 2020-09-09 09:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:15:14 --> Input Class Initialized
INFO - 2020-09-09 09:15:14 --> Language Class Initialized
ERROR - 2020-09-09 09:15:14 --> 404 Page Not Found: Excle_import/excele_upload
ERROR - 2020-09-09 09:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:15:38 --> Config Class Initialized
INFO - 2020-09-09 09:15:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:15:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:15:38 --> Utf8 Class Initialized
INFO - 2020-09-09 09:15:38 --> URI Class Initialized
INFO - 2020-09-09 09:15:38 --> Router Class Initialized
INFO - 2020-09-09 09:15:38 --> Output Class Initialized
INFO - 2020-09-09 09:15:38 --> Security Class Initialized
DEBUG - 2020-09-09 09:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:15:38 --> Input Class Initialized
INFO - 2020-09-09 09:15:38 --> Language Class Initialized
ERROR - 2020-09-09 09:15:38 --> 404 Page Not Found: Excel_import/excle_upload
ERROR - 2020-09-09 09:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:16:32 --> Config Class Initialized
INFO - 2020-09-09 09:16:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:16:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:16:32 --> Utf8 Class Initialized
INFO - 2020-09-09 09:16:32 --> URI Class Initialized
INFO - 2020-09-09 09:16:32 --> Router Class Initialized
INFO - 2020-09-09 09:16:32 --> Output Class Initialized
INFO - 2020-09-09 09:16:32 --> Security Class Initialized
DEBUG - 2020-09-09 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:16:32 --> Input Class Initialized
INFO - 2020-09-09 09:16:32 --> Language Class Initialized
INFO - 2020-09-09 09:16:32 --> Loader Class Initialized
INFO - 2020-09-09 09:16:32 --> Helper loaded: url_helper
INFO - 2020-09-09 09:16:32 --> Database Driver Class Initialized
INFO - 2020-09-09 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:16:32 --> Email Class Initialized
INFO - 2020-09-09 09:16:32 --> Controller Class Initialized
INFO - 2020-09-09 09:16:32 --> Model Class Initialized
INFO - 2020-09-09 09:16:32 --> Model Class Initialized
INFO - 2020-09-09 09:16:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 09:16:32 --> Final output sent to browser
DEBUG - 2020-09-09 09:16:32 --> Total execution time: 0.0427
ERROR - 2020-09-09 09:16:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:16:32 --> Config Class Initialized
INFO - 2020-09-09 09:16:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:16:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:16:32 --> Utf8 Class Initialized
INFO - 2020-09-09 09:16:32 --> URI Class Initialized
INFO - 2020-09-09 09:16:32 --> Router Class Initialized
INFO - 2020-09-09 09:16:32 --> Output Class Initialized
INFO - 2020-09-09 09:16:32 --> Security Class Initialized
DEBUG - 2020-09-09 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:16:32 --> Input Class Initialized
INFO - 2020-09-09 09:16:32 --> Language Class Initialized
INFO - 2020-09-09 09:16:32 --> Loader Class Initialized
INFO - 2020-09-09 09:16:32 --> Helper loaded: url_helper
INFO - 2020-09-09 09:16:32 --> Database Driver Class Initialized
INFO - 2020-09-09 09:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:16:32 --> Email Class Initialized
INFO - 2020-09-09 09:16:32 --> Controller Class Initialized
INFO - 2020-09-09 09:16:32 --> Model Class Initialized
INFO - 2020-09-09 09:16:32 --> Model Class Initialized
ERROR - 2020-09-09 09:16:32 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 09:16:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 09:17:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:17 --> Config Class Initialized
INFO - 2020-09-09 09:17:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:17 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:17 --> URI Class Initialized
DEBUG - 2020-09-09 09:17:17 --> No URI present. Default controller set.
INFO - 2020-09-09 09:17:17 --> Router Class Initialized
INFO - 2020-09-09 09:17:17 --> Output Class Initialized
INFO - 2020-09-09 09:17:17 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:17 --> Input Class Initialized
INFO - 2020-09-09 09:17:17 --> Language Class Initialized
INFO - 2020-09-09 09:17:17 --> Loader Class Initialized
INFO - 2020-09-09 09:17:17 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:17 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:17 --> Email Class Initialized
INFO - 2020-09-09 09:17:17 --> Controller Class Initialized
INFO - 2020-09-09 09:17:17 --> Model Class Initialized
INFO - 2020-09-09 09:17:17 --> Model Class Initialized
DEBUG - 2020-09-09 09:17:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:17:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 09:17:17 --> Final output sent to browser
DEBUG - 2020-09-09 09:17:17 --> Total execution time: 0.0203
ERROR - 2020-09-09 09:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:20 --> Config Class Initialized
INFO - 2020-09-09 09:17:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:20 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:20 --> URI Class Initialized
INFO - 2020-09-09 09:17:20 --> Router Class Initialized
INFO - 2020-09-09 09:17:20 --> Output Class Initialized
INFO - 2020-09-09 09:17:20 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:20 --> Input Class Initialized
INFO - 2020-09-09 09:17:20 --> Language Class Initialized
INFO - 2020-09-09 09:17:20 --> Loader Class Initialized
INFO - 2020-09-09 09:17:20 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:20 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:20 --> Email Class Initialized
INFO - 2020-09-09 09:17:20 --> Controller Class Initialized
INFO - 2020-09-09 09:17:20 --> Model Class Initialized
INFO - 2020-09-09 09:17:20 --> Model Class Initialized
DEBUG - 2020-09-09 09:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:17:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:17:20 --> Model Class Initialized
INFO - 2020-09-09 09:17:20 --> Final output sent to browser
DEBUG - 2020-09-09 09:17:20 --> Total execution time: 0.0207
ERROR - 2020-09-09 09:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:20 --> Config Class Initialized
INFO - 2020-09-09 09:17:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:20 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:20 --> URI Class Initialized
INFO - 2020-09-09 09:17:20 --> Router Class Initialized
INFO - 2020-09-09 09:17:20 --> Output Class Initialized
INFO - 2020-09-09 09:17:20 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:20 --> Input Class Initialized
INFO - 2020-09-09 09:17:20 --> Language Class Initialized
INFO - 2020-09-09 09:17:20 --> Loader Class Initialized
INFO - 2020-09-09 09:17:20 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:20 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:20 --> Email Class Initialized
INFO - 2020-09-09 09:17:20 --> Controller Class Initialized
INFO - 2020-09-09 09:17:20 --> Model Class Initialized
INFO - 2020-09-09 09:17:20 --> Model Class Initialized
DEBUG - 2020-09-09 09:17:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 09:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:21 --> Config Class Initialized
INFO - 2020-09-09 09:17:21 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:21 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:21 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:21 --> URI Class Initialized
INFO - 2020-09-09 09:17:21 --> Router Class Initialized
INFO - 2020-09-09 09:17:21 --> Output Class Initialized
INFO - 2020-09-09 09:17:21 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:21 --> Input Class Initialized
INFO - 2020-09-09 09:17:21 --> Language Class Initialized
INFO - 2020-09-09 09:17:21 --> Loader Class Initialized
INFO - 2020-09-09 09:17:21 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:21 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:21 --> Email Class Initialized
INFO - 2020-09-09 09:17:21 --> Controller Class Initialized
DEBUG - 2020-09-09 09:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:17:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:17:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 09:17:21 --> Final output sent to browser
DEBUG - 2020-09-09 09:17:21 --> Total execution time: 0.0183
ERROR - 2020-09-09 09:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:25 --> Config Class Initialized
INFO - 2020-09-09 09:17:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:25 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:25 --> URI Class Initialized
INFO - 2020-09-09 09:17:25 --> Router Class Initialized
INFO - 2020-09-09 09:17:25 --> Output Class Initialized
INFO - 2020-09-09 09:17:25 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:25 --> Input Class Initialized
INFO - 2020-09-09 09:17:25 --> Language Class Initialized
INFO - 2020-09-09 09:17:25 --> Loader Class Initialized
INFO - 2020-09-09 09:17:25 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:25 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:25 --> Email Class Initialized
INFO - 2020-09-09 09:17:25 --> Controller Class Initialized
INFO - 2020-09-09 09:17:25 --> Model Class Initialized
INFO - 2020-09-09 09:17:25 --> Model Class Initialized
INFO - 2020-09-09 09:17:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 09:17:25 --> Final output sent to browser
DEBUG - 2020-09-09 09:17:25 --> Total execution time: 0.0378
ERROR - 2020-09-09 09:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:25 --> Config Class Initialized
INFO - 2020-09-09 09:17:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:25 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:25 --> URI Class Initialized
INFO - 2020-09-09 09:17:25 --> Router Class Initialized
INFO - 2020-09-09 09:17:25 --> Output Class Initialized
INFO - 2020-09-09 09:17:25 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:25 --> Input Class Initialized
INFO - 2020-09-09 09:17:25 --> Language Class Initialized
INFO - 2020-09-09 09:17:25 --> Loader Class Initialized
INFO - 2020-09-09 09:17:25 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:25 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:25 --> Email Class Initialized
INFO - 2020-09-09 09:17:25 --> Controller Class Initialized
INFO - 2020-09-09 09:17:25 --> Model Class Initialized
INFO - 2020-09-09 09:17:25 --> Model Class Initialized
ERROR - 2020-09-09 09:17:25 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 09:17:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 09:17:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:17:44 --> Config Class Initialized
INFO - 2020-09-09 09:17:44 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:17:44 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:17:44 --> Utf8 Class Initialized
INFO - 2020-09-09 09:17:44 --> URI Class Initialized
INFO - 2020-09-09 09:17:44 --> Router Class Initialized
INFO - 2020-09-09 09:17:44 --> Output Class Initialized
INFO - 2020-09-09 09:17:44 --> Security Class Initialized
DEBUG - 2020-09-09 09:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:17:44 --> Input Class Initialized
INFO - 2020-09-09 09:17:44 --> Language Class Initialized
INFO - 2020-09-09 09:17:44 --> Loader Class Initialized
INFO - 2020-09-09 09:17:44 --> Helper loaded: url_helper
INFO - 2020-09-09 09:17:44 --> Database Driver Class Initialized
INFO - 2020-09-09 09:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:17:44 --> Email Class Initialized
INFO - 2020-09-09 09:17:44 --> Controller Class Initialized
DEBUG - 2020-09-09 09:17:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:17:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:17:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 09:17:44 --> Final output sent to browser
DEBUG - 2020-09-09 09:17:44 --> Total execution time: 0.0211
ERROR - 2020-09-09 09:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:20:12 --> Config Class Initialized
INFO - 2020-09-09 09:20:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:20:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:20:12 --> Utf8 Class Initialized
INFO - 2020-09-09 09:20:12 --> URI Class Initialized
INFO - 2020-09-09 09:20:12 --> Router Class Initialized
INFO - 2020-09-09 09:20:12 --> Output Class Initialized
INFO - 2020-09-09 09:20:12 --> Security Class Initialized
DEBUG - 2020-09-09 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:20:12 --> Input Class Initialized
INFO - 2020-09-09 09:20:12 --> Language Class Initialized
INFO - 2020-09-09 09:20:12 --> Loader Class Initialized
INFO - 2020-09-09 09:20:12 --> Helper loaded: url_helper
INFO - 2020-09-09 09:20:12 --> Database Driver Class Initialized
INFO - 2020-09-09 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:20:12 --> Email Class Initialized
INFO - 2020-09-09 09:20:12 --> Controller Class Initialized
INFO - 2020-09-09 09:20:12 --> Model Class Initialized
INFO - 2020-09-09 09:20:12 --> Model Class Initialized
INFO - 2020-09-09 09:20:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 09:20:12 --> Final output sent to browser
DEBUG - 2020-09-09 09:20:12 --> Total execution time: 0.0326
ERROR - 2020-09-09 09:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:20:12 --> Config Class Initialized
INFO - 2020-09-09 09:20:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:20:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:20:12 --> Utf8 Class Initialized
INFO - 2020-09-09 09:20:12 --> URI Class Initialized
INFO - 2020-09-09 09:20:12 --> Router Class Initialized
INFO - 2020-09-09 09:20:12 --> Output Class Initialized
INFO - 2020-09-09 09:20:12 --> Security Class Initialized
DEBUG - 2020-09-09 09:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:20:12 --> Input Class Initialized
INFO - 2020-09-09 09:20:12 --> Language Class Initialized
INFO - 2020-09-09 09:20:12 --> Loader Class Initialized
INFO - 2020-09-09 09:20:12 --> Helper loaded: url_helper
INFO - 2020-09-09 09:20:12 --> Database Driver Class Initialized
INFO - 2020-09-09 09:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:20:12 --> Email Class Initialized
INFO - 2020-09-09 09:20:12 --> Controller Class Initialized
INFO - 2020-09-09 09:20:12 --> Model Class Initialized
INFO - 2020-09-09 09:20:12 --> Model Class Initialized
ERROR - 2020-09-09 09:20:12 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 09:20:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 09:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:20:57 --> Config Class Initialized
INFO - 2020-09-09 09:20:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:20:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:20:57 --> Utf8 Class Initialized
INFO - 2020-09-09 09:20:57 --> URI Class Initialized
INFO - 2020-09-09 09:20:57 --> Router Class Initialized
INFO - 2020-09-09 09:20:57 --> Output Class Initialized
INFO - 2020-09-09 09:20:57 --> Security Class Initialized
DEBUG - 2020-09-09 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:20:57 --> Input Class Initialized
INFO - 2020-09-09 09:20:57 --> Language Class Initialized
INFO - 2020-09-09 09:20:57 --> Loader Class Initialized
INFO - 2020-09-09 09:20:57 --> Helper loaded: url_helper
INFO - 2020-09-09 09:20:57 --> Database Driver Class Initialized
INFO - 2020-09-09 09:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:20:57 --> Email Class Initialized
INFO - 2020-09-09 09:20:57 --> Controller Class Initialized
INFO - 2020-09-09 09:20:57 --> Model Class Initialized
INFO - 2020-09-09 09:20:57 --> Model Class Initialized
INFO - 2020-09-09 09:20:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 09:20:57 --> Final output sent to browser
DEBUG - 2020-09-09 09:20:57 --> Total execution time: 0.0414
ERROR - 2020-09-09 09:20:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:20:58 --> Config Class Initialized
INFO - 2020-09-09 09:20:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:20:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:20:58 --> Utf8 Class Initialized
INFO - 2020-09-09 09:20:58 --> URI Class Initialized
INFO - 2020-09-09 09:20:58 --> Router Class Initialized
INFO - 2020-09-09 09:20:58 --> Output Class Initialized
INFO - 2020-09-09 09:20:58 --> Security Class Initialized
DEBUG - 2020-09-09 09:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:20:58 --> Input Class Initialized
INFO - 2020-09-09 09:20:58 --> Language Class Initialized
INFO - 2020-09-09 09:20:58 --> Loader Class Initialized
INFO - 2020-09-09 09:20:58 --> Helper loaded: url_helper
INFO - 2020-09-09 09:20:58 --> Database Driver Class Initialized
INFO - 2020-09-09 09:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:20:58 --> Email Class Initialized
INFO - 2020-09-09 09:20:58 --> Controller Class Initialized
INFO - 2020-09-09 09:20:58 --> Model Class Initialized
INFO - 2020-09-09 09:20:58 --> Model Class Initialized
ERROR - 2020-09-09 09:20:58 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 09:20:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 09:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:48:16 --> Config Class Initialized
INFO - 2020-09-09 09:48:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:48:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:48:16 --> Utf8 Class Initialized
INFO - 2020-09-09 09:48:16 --> URI Class Initialized
DEBUG - 2020-09-09 09:48:16 --> No URI present. Default controller set.
INFO - 2020-09-09 09:48:16 --> Router Class Initialized
INFO - 2020-09-09 09:48:16 --> Output Class Initialized
INFO - 2020-09-09 09:48:16 --> Security Class Initialized
DEBUG - 2020-09-09 09:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:48:16 --> Input Class Initialized
INFO - 2020-09-09 09:48:16 --> Language Class Initialized
INFO - 2020-09-09 09:48:16 --> Loader Class Initialized
INFO - 2020-09-09 09:48:16 --> Helper loaded: url_helper
INFO - 2020-09-09 09:48:16 --> Database Driver Class Initialized
INFO - 2020-09-09 09:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:48:16 --> Email Class Initialized
INFO - 2020-09-09 09:48:16 --> Controller Class Initialized
INFO - 2020-09-09 09:48:16 --> Model Class Initialized
INFO - 2020-09-09 09:48:16 --> Model Class Initialized
DEBUG - 2020-09-09 09:48:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:48:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 09:48:16 --> Final output sent to browser
DEBUG - 2020-09-09 09:48:16 --> Total execution time: 0.0219
ERROR - 2020-09-09 09:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:52:03 --> Config Class Initialized
INFO - 2020-09-09 09:52:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:52:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:52:03 --> Utf8 Class Initialized
INFO - 2020-09-09 09:52:03 --> URI Class Initialized
INFO - 2020-09-09 09:52:03 --> Router Class Initialized
INFO - 2020-09-09 09:52:03 --> Output Class Initialized
INFO - 2020-09-09 09:52:03 --> Security Class Initialized
DEBUG - 2020-09-09 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:52:03 --> Input Class Initialized
INFO - 2020-09-09 09:52:03 --> Language Class Initialized
INFO - 2020-09-09 09:52:03 --> Loader Class Initialized
INFO - 2020-09-09 09:52:03 --> Helper loaded: url_helper
INFO - 2020-09-09 09:52:03 --> Database Driver Class Initialized
INFO - 2020-09-09 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:52:03 --> Email Class Initialized
INFO - 2020-09-09 09:52:03 --> Controller Class Initialized
INFO - 2020-09-09 09:52:03 --> Model Class Initialized
INFO - 2020-09-09 09:52:03 --> Model Class Initialized
DEBUG - 2020-09-09 09:52:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 09:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:52:03 --> Config Class Initialized
INFO - 2020-09-09 09:52:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:52:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:52:03 --> Utf8 Class Initialized
INFO - 2020-09-09 09:52:03 --> URI Class Initialized
INFO - 2020-09-09 09:52:03 --> Router Class Initialized
INFO - 2020-09-09 09:52:03 --> Output Class Initialized
INFO - 2020-09-09 09:52:03 --> Security Class Initialized
DEBUG - 2020-09-09 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:52:03 --> Input Class Initialized
INFO - 2020-09-09 09:52:03 --> Language Class Initialized
INFO - 2020-09-09 09:52:03 --> Loader Class Initialized
INFO - 2020-09-09 09:52:03 --> Helper loaded: url_helper
INFO - 2020-09-09 09:52:03 --> Database Driver Class Initialized
INFO - 2020-09-09 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:52:03 --> Email Class Initialized
INFO - 2020-09-09 09:52:03 --> Controller Class Initialized
INFO - 2020-09-09 09:52:03 --> Model Class Initialized
INFO - 2020-09-09 09:52:03 --> Model Class Initialized
DEBUG - 2020-09-09 09:52:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:52:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:52:03 --> Model Class Initialized
INFO - 2020-09-09 09:52:03 --> Final output sent to browser
DEBUG - 2020-09-09 09:52:03 --> Total execution time: 0.0243
ERROR - 2020-09-09 09:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:52:03 --> Config Class Initialized
INFO - 2020-09-09 09:52:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:52:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:52:03 --> Utf8 Class Initialized
INFO - 2020-09-09 09:52:03 --> URI Class Initialized
INFO - 2020-09-09 09:52:03 --> Router Class Initialized
INFO - 2020-09-09 09:52:03 --> Output Class Initialized
INFO - 2020-09-09 09:52:03 --> Security Class Initialized
DEBUG - 2020-09-09 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:52:03 --> Input Class Initialized
INFO - 2020-09-09 09:52:03 --> Language Class Initialized
INFO - 2020-09-09 09:52:03 --> Loader Class Initialized
INFO - 2020-09-09 09:52:03 --> Helper loaded: url_helper
INFO - 2020-09-09 09:52:03 --> Database Driver Class Initialized
INFO - 2020-09-09 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:52:03 --> Email Class Initialized
INFO - 2020-09-09 09:52:03 --> Controller Class Initialized
DEBUG - 2020-09-09 09:52:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:52:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:52:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 09:52:03 --> Final output sent to browser
DEBUG - 2020-09-09 09:52:03 --> Total execution time: 0.0180
ERROR - 2020-09-09 09:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 09:52:33 --> Config Class Initialized
INFO - 2020-09-09 09:52:33 --> Hooks Class Initialized
DEBUG - 2020-09-09 09:52:33 --> UTF-8 Support Enabled
INFO - 2020-09-09 09:52:33 --> Utf8 Class Initialized
INFO - 2020-09-09 09:52:33 --> URI Class Initialized
INFO - 2020-09-09 09:52:33 --> Router Class Initialized
INFO - 2020-09-09 09:52:33 --> Output Class Initialized
INFO - 2020-09-09 09:52:33 --> Security Class Initialized
DEBUG - 2020-09-09 09:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 09:52:33 --> Input Class Initialized
INFO - 2020-09-09 09:52:33 --> Language Class Initialized
INFO - 2020-09-09 09:52:33 --> Loader Class Initialized
INFO - 2020-09-09 09:52:33 --> Helper loaded: url_helper
INFO - 2020-09-09 09:52:33 --> Database Driver Class Initialized
INFO - 2020-09-09 09:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 09:52:33 --> Email Class Initialized
INFO - 2020-09-09 09:52:33 --> Controller Class Initialized
DEBUG - 2020-09-09 09:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 09:52:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 09:52:33 --> Model Class Initialized
INFO - 2020-09-09 09:52:33 --> Model Class Initialized
INFO - 2020-09-09 09:52:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-09 09:52:33 --> Final output sent to browser
DEBUG - 2020-09-09 09:52:33 --> Total execution time: 0.0339
ERROR - 2020-09-09 10:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:18:17 --> Config Class Initialized
INFO - 2020-09-09 10:18:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:17 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:17 --> URI Class Initialized
DEBUG - 2020-09-09 10:18:17 --> No URI present. Default controller set.
INFO - 2020-09-09 10:18:17 --> Router Class Initialized
INFO - 2020-09-09 10:18:17 --> Output Class Initialized
INFO - 2020-09-09 10:18:17 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:17 --> Input Class Initialized
INFO - 2020-09-09 10:18:17 --> Language Class Initialized
INFO - 2020-09-09 10:18:17 --> Loader Class Initialized
INFO - 2020-09-09 10:18:17 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:17 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:18:17 --> Email Class Initialized
INFO - 2020-09-09 10:18:17 --> Controller Class Initialized
INFO - 2020-09-09 10:18:17 --> Model Class Initialized
INFO - 2020-09-09 10:18:17 --> Model Class Initialized
DEBUG - 2020-09-09 10:18:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:18:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 10:18:17 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:17 --> Total execution time: 0.0214
ERROR - 2020-09-09 10:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:18:30 --> Config Class Initialized
INFO - 2020-09-09 10:18:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:30 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:30 --> URI Class Initialized
INFO - 2020-09-09 10:18:30 --> Router Class Initialized
INFO - 2020-09-09 10:18:30 --> Output Class Initialized
INFO - 2020-09-09 10:18:30 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:30 --> Input Class Initialized
INFO - 2020-09-09 10:18:30 --> Language Class Initialized
INFO - 2020-09-09 10:18:30 --> Loader Class Initialized
INFO - 2020-09-09 10:18:30 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:30 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:18:30 --> Email Class Initialized
INFO - 2020-09-09 10:18:30 --> Controller Class Initialized
INFO - 2020-09-09 10:18:30 --> Model Class Initialized
INFO - 2020-09-09 10:18:30 --> Model Class Initialized
DEBUG - 2020-09-09 10:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:18:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:18:30 --> Model Class Initialized
INFO - 2020-09-09 10:18:30 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:30 --> Total execution time: 0.0215
ERROR - 2020-09-09 10:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:18:30 --> Config Class Initialized
INFO - 2020-09-09 10:18:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:30 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:30 --> URI Class Initialized
INFO - 2020-09-09 10:18:30 --> Router Class Initialized
INFO - 2020-09-09 10:18:30 --> Output Class Initialized
INFO - 2020-09-09 10:18:30 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:30 --> Input Class Initialized
INFO - 2020-09-09 10:18:30 --> Language Class Initialized
INFO - 2020-09-09 10:18:30 --> Loader Class Initialized
INFO - 2020-09-09 10:18:30 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:30 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:18:30 --> Email Class Initialized
INFO - 2020-09-09 10:18:30 --> Controller Class Initialized
INFO - 2020-09-09 10:18:30 --> Model Class Initialized
INFO - 2020-09-09 10:18:30 --> Model Class Initialized
DEBUG - 2020-09-09 10:18:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 10:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:18:31 --> Config Class Initialized
INFO - 2020-09-09 10:18:31 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:31 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:31 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:31 --> URI Class Initialized
INFO - 2020-09-09 10:18:31 --> Router Class Initialized
INFO - 2020-09-09 10:18:31 --> Output Class Initialized
INFO - 2020-09-09 10:18:31 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:31 --> Input Class Initialized
INFO - 2020-09-09 10:18:31 --> Language Class Initialized
INFO - 2020-09-09 10:18:31 --> Loader Class Initialized
INFO - 2020-09-09 10:18:31 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:31 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:18:31 --> Email Class Initialized
INFO - 2020-09-09 10:18:31 --> Controller Class Initialized
DEBUG - 2020-09-09 10:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:18:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:18:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 10:18:31 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:31 --> Total execution time: 0.0170
ERROR - 2020-09-09 10:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:18:54 --> Config Class Initialized
INFO - 2020-09-09 10:18:54 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:54 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:54 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:54 --> URI Class Initialized
INFO - 2020-09-09 10:18:54 --> Router Class Initialized
INFO - 2020-09-09 10:18:54 --> Output Class Initialized
INFO - 2020-09-09 10:18:54 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:54 --> Input Class Initialized
INFO - 2020-09-09 10:18:54 --> Language Class Initialized
INFO - 2020-09-09 10:18:54 --> Loader Class Initialized
INFO - 2020-09-09 10:18:54 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:54 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:18:54 --> Email Class Initialized
INFO - 2020-09-09 10:18:54 --> Controller Class Initialized
DEBUG - 2020-09-09 10:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:18:54 --> Model Class Initialized
INFO - 2020-09-09 10:18:54 --> Model Class Initialized
INFO - 2020-09-09 10:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-09 10:18:54 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:54 --> Total execution time: 0.0235
ERROR - 2020-09-09 10:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:18:57 --> Config Class Initialized
INFO - 2020-09-09 10:18:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:18:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:18:57 --> Utf8 Class Initialized
INFO - 2020-09-09 10:18:57 --> URI Class Initialized
INFO - 2020-09-09 10:18:57 --> Router Class Initialized
INFO - 2020-09-09 10:18:57 --> Output Class Initialized
INFO - 2020-09-09 10:18:57 --> Security Class Initialized
DEBUG - 2020-09-09 10:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:18:57 --> Input Class Initialized
INFO - 2020-09-09 10:18:57 --> Language Class Initialized
INFO - 2020-09-09 10:18:57 --> Loader Class Initialized
INFO - 2020-09-09 10:18:57 --> Helper loaded: url_helper
INFO - 2020-09-09 10:18:57 --> Database Driver Class Initialized
INFO - 2020-09-09 10:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:18:57 --> Email Class Initialized
INFO - 2020-09-09 10:18:57 --> Controller Class Initialized
DEBUG - 2020-09-09 10:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:18:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:18:57 --> Model Class Initialized
INFO - 2020-09-09 10:18:57 --> Model Class Initialized
INFO - 2020-09-09 10:18:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-09 10:18:57 --> Final output sent to browser
DEBUG - 2020-09-09 10:18:57 --> Total execution time: 0.0236
ERROR - 2020-09-09 10:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:19:03 --> Config Class Initialized
INFO - 2020-09-09 10:19:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:19:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:19:03 --> Utf8 Class Initialized
INFO - 2020-09-09 10:19:03 --> URI Class Initialized
INFO - 2020-09-09 10:19:03 --> Router Class Initialized
INFO - 2020-09-09 10:19:03 --> Output Class Initialized
INFO - 2020-09-09 10:19:03 --> Security Class Initialized
DEBUG - 2020-09-09 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:19:03 --> Input Class Initialized
INFO - 2020-09-09 10:19:03 --> Language Class Initialized
INFO - 2020-09-09 10:19:03 --> Loader Class Initialized
INFO - 2020-09-09 10:19:03 --> Helper loaded: url_helper
INFO - 2020-09-09 10:19:03 --> Database Driver Class Initialized
INFO - 2020-09-09 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:19:03 --> Email Class Initialized
INFO - 2020-09-09 10:19:03 --> Controller Class Initialized
DEBUG - 2020-09-09 10:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:19:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:19:03 --> Model Class Initialized
INFO - 2020-09-09 10:19:03 --> Model Class Initialized
INFO - 2020-09-09 10:19:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-09 10:19:03 --> Final output sent to browser
DEBUG - 2020-09-09 10:19:03 --> Total execution time: 0.0258
ERROR - 2020-09-09 10:19:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:19:07 --> Config Class Initialized
INFO - 2020-09-09 10:19:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:19:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:19:07 --> Utf8 Class Initialized
INFO - 2020-09-09 10:19:07 --> URI Class Initialized
INFO - 2020-09-09 10:19:07 --> Router Class Initialized
INFO - 2020-09-09 10:19:07 --> Output Class Initialized
INFO - 2020-09-09 10:19:07 --> Security Class Initialized
DEBUG - 2020-09-09 10:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:19:07 --> Input Class Initialized
INFO - 2020-09-09 10:19:07 --> Language Class Initialized
INFO - 2020-09-09 10:19:07 --> Loader Class Initialized
INFO - 2020-09-09 10:19:07 --> Helper loaded: url_helper
INFO - 2020-09-09 10:19:07 --> Database Driver Class Initialized
INFO - 2020-09-09 10:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:19:07 --> Email Class Initialized
INFO - 2020-09-09 10:19:07 --> Controller Class Initialized
DEBUG - 2020-09-09 10:19:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:19:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:19:07 --> Model Class Initialized
INFO - 2020-09-09 10:19:07 --> Model Class Initialized
INFO - 2020-09-09 10:19:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-09 10:19:07 --> Final output sent to browser
DEBUG - 2020-09-09 10:19:07 --> Total execution time: 0.0229
ERROR - 2020-09-09 10:19:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:19:23 --> Config Class Initialized
INFO - 2020-09-09 10:19:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:19:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:19:23 --> Utf8 Class Initialized
INFO - 2020-09-09 10:19:23 --> URI Class Initialized
INFO - 2020-09-09 10:19:23 --> Router Class Initialized
INFO - 2020-09-09 10:19:23 --> Output Class Initialized
INFO - 2020-09-09 10:19:23 --> Security Class Initialized
DEBUG - 2020-09-09 10:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:19:23 --> Input Class Initialized
INFO - 2020-09-09 10:19:23 --> Language Class Initialized
INFO - 2020-09-09 10:19:23 --> Loader Class Initialized
INFO - 2020-09-09 10:19:23 --> Helper loaded: url_helper
INFO - 2020-09-09 10:19:23 --> Database Driver Class Initialized
INFO - 2020-09-09 10:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:19:23 --> Email Class Initialized
INFO - 2020-09-09 10:19:23 --> Controller Class Initialized
DEBUG - 2020-09-09 10:19:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:19:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:19:23 --> Model Class Initialized
INFO - 2020-09-09 10:19:23 --> Model Class Initialized
INFO - 2020-09-09 10:19:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-09 10:19:23 --> Final output sent to browser
DEBUG - 2020-09-09 10:19:23 --> Total execution time: 0.0219
ERROR - 2020-09-09 10:19:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:19:27 --> Config Class Initialized
INFO - 2020-09-09 10:19:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:19:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:19:27 --> Utf8 Class Initialized
INFO - 2020-09-09 10:19:27 --> URI Class Initialized
INFO - 2020-09-09 10:19:27 --> Router Class Initialized
INFO - 2020-09-09 10:19:27 --> Output Class Initialized
INFO - 2020-09-09 10:19:27 --> Security Class Initialized
DEBUG - 2020-09-09 10:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:19:27 --> Input Class Initialized
INFO - 2020-09-09 10:19:27 --> Language Class Initialized
INFO - 2020-09-09 10:19:27 --> Loader Class Initialized
INFO - 2020-09-09 10:19:27 --> Helper loaded: url_helper
INFO - 2020-09-09 10:19:27 --> Database Driver Class Initialized
INFO - 2020-09-09 10:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:19:27 --> Email Class Initialized
INFO - 2020-09-09 10:19:27 --> Controller Class Initialized
DEBUG - 2020-09-09 10:19:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 10:19:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 10:19:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 10:19:27 --> Final output sent to browser
DEBUG - 2020-09-09 10:19:27 --> Total execution time: 0.0197
ERROR - 2020-09-09 10:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:23:19 --> Config Class Initialized
INFO - 2020-09-09 10:23:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:23:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:23:19 --> Utf8 Class Initialized
INFO - 2020-09-09 10:23:19 --> URI Class Initialized
INFO - 2020-09-09 10:23:19 --> Router Class Initialized
INFO - 2020-09-09 10:23:19 --> Output Class Initialized
INFO - 2020-09-09 10:23:19 --> Security Class Initialized
DEBUG - 2020-09-09 10:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:23:19 --> Input Class Initialized
INFO - 2020-09-09 10:23:19 --> Language Class Initialized
INFO - 2020-09-09 10:23:19 --> Loader Class Initialized
INFO - 2020-09-09 10:23:19 --> Helper loaded: url_helper
INFO - 2020-09-09 10:23:19 --> Database Driver Class Initialized
INFO - 2020-09-09 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:23:19 --> Email Class Initialized
INFO - 2020-09-09 10:23:19 --> Controller Class Initialized
INFO - 2020-09-09 10:23:19 --> Model Class Initialized
INFO - 2020-09-09 10:23:19 --> Model Class Initialized
INFO - 2020-09-09 10:23:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:23:19 --> Final output sent to browser
DEBUG - 2020-09-09 10:23:19 --> Total execution time: 0.0676
ERROR - 2020-09-09 10:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:23:20 --> Config Class Initialized
INFO - 2020-09-09 10:23:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:23:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:23:20 --> Utf8 Class Initialized
INFO - 2020-09-09 10:23:20 --> URI Class Initialized
INFO - 2020-09-09 10:23:20 --> Router Class Initialized
INFO - 2020-09-09 10:23:20 --> Output Class Initialized
INFO - 2020-09-09 10:23:20 --> Security Class Initialized
DEBUG - 2020-09-09 10:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:23:20 --> Input Class Initialized
INFO - 2020-09-09 10:23:20 --> Language Class Initialized
INFO - 2020-09-09 10:23:20 --> Loader Class Initialized
INFO - 2020-09-09 10:23:20 --> Helper loaded: url_helper
INFO - 2020-09-09 10:23:20 --> Database Driver Class Initialized
INFO - 2020-09-09 10:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:23:20 --> Email Class Initialized
INFO - 2020-09-09 10:23:20 --> Controller Class Initialized
INFO - 2020-09-09 10:23:20 --> Model Class Initialized
INFO - 2020-09-09 10:23:20 --> Model Class Initialized
ERROR - 2020-09-09 10:23:20 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 10:23:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:23:28 --> Config Class Initialized
INFO - 2020-09-09 10:23:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:23:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:23:28 --> Utf8 Class Initialized
INFO - 2020-09-09 10:23:28 --> URI Class Initialized
INFO - 2020-09-09 10:23:28 --> Router Class Initialized
INFO - 2020-09-09 10:23:28 --> Output Class Initialized
INFO - 2020-09-09 10:23:28 --> Security Class Initialized
DEBUG - 2020-09-09 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:23:28 --> Input Class Initialized
INFO - 2020-09-09 10:23:28 --> Language Class Initialized
INFO - 2020-09-09 10:23:28 --> Loader Class Initialized
INFO - 2020-09-09 10:23:28 --> Helper loaded: url_helper
INFO - 2020-09-09 10:23:28 --> Database Driver Class Initialized
INFO - 2020-09-09 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:23:28 --> Email Class Initialized
INFO - 2020-09-09 10:23:28 --> Controller Class Initialized
INFO - 2020-09-09 10:23:28 --> Model Class Initialized
INFO - 2020-09-09 10:23:28 --> Model Class Initialized
INFO - 2020-09-09 10:23:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view.php
INFO - 2020-09-09 10:23:28 --> Final output sent to browser
DEBUG - 2020-09-09 10:23:28 --> Total execution time: 0.1014
ERROR - 2020-09-09 10:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:23:29 --> Config Class Initialized
INFO - 2020-09-09 10:23:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:23:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:23:29 --> Utf8 Class Initialized
INFO - 2020-09-09 10:23:29 --> URI Class Initialized
INFO - 2020-09-09 10:23:29 --> Router Class Initialized
INFO - 2020-09-09 10:23:29 --> Output Class Initialized
INFO - 2020-09-09 10:23:29 --> Security Class Initialized
DEBUG - 2020-09-09 10:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:23:29 --> Input Class Initialized
INFO - 2020-09-09 10:23:29 --> Language Class Initialized
INFO - 2020-09-09 10:23:29 --> Loader Class Initialized
INFO - 2020-09-09 10:23:29 --> Helper loaded: url_helper
INFO - 2020-09-09 10:23:29 --> Database Driver Class Initialized
INFO - 2020-09-09 10:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:23:29 --> Email Class Initialized
INFO - 2020-09-09 10:23:29 --> Controller Class Initialized
INFO - 2020-09-09 10:23:29 --> Model Class Initialized
INFO - 2020-09-09 10:23:29 --> Model Class Initialized
ERROR - 2020-09-09 10:23:29 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 10:23:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 10:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:24:31 --> Config Class Initialized
INFO - 2020-09-09 10:24:31 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:24:31 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:24:31 --> Utf8 Class Initialized
INFO - 2020-09-09 10:24:31 --> URI Class Initialized
INFO - 2020-09-09 10:24:31 --> Router Class Initialized
INFO - 2020-09-09 10:24:31 --> Output Class Initialized
INFO - 2020-09-09 10:24:31 --> Security Class Initialized
DEBUG - 2020-09-09 10:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:24:31 --> Input Class Initialized
INFO - 2020-09-09 10:24:31 --> Language Class Initialized
INFO - 2020-09-09 10:24:31 --> Loader Class Initialized
INFO - 2020-09-09 10:24:31 --> Helper loaded: url_helper
INFO - 2020-09-09 10:24:31 --> Database Driver Class Initialized
INFO - 2020-09-09 10:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:24:31 --> Email Class Initialized
INFO - 2020-09-09 10:24:31 --> Controller Class Initialized
INFO - 2020-09-09 10:24:31 --> Model Class Initialized
INFO - 2020-09-09 10:24:31 --> Model Class Initialized
INFO - 2020-09-09 10:24:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view.php
INFO - 2020-09-09 10:24:31 --> Final output sent to browser
DEBUG - 2020-09-09 10:24:31 --> Total execution time: 0.0717
ERROR - 2020-09-09 10:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:24:32 --> Config Class Initialized
INFO - 2020-09-09 10:24:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:24:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:24:32 --> Utf8 Class Initialized
INFO - 2020-09-09 10:24:32 --> URI Class Initialized
INFO - 2020-09-09 10:24:32 --> Router Class Initialized
INFO - 2020-09-09 10:24:32 --> Output Class Initialized
INFO - 2020-09-09 10:24:32 --> Security Class Initialized
DEBUG - 2020-09-09 10:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:24:32 --> Input Class Initialized
INFO - 2020-09-09 10:24:32 --> Language Class Initialized
INFO - 2020-09-09 10:24:32 --> Loader Class Initialized
INFO - 2020-09-09 10:24:32 --> Helper loaded: url_helper
INFO - 2020-09-09 10:24:32 --> Database Driver Class Initialized
INFO - 2020-09-09 10:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:24:32 --> Email Class Initialized
INFO - 2020-09-09 10:24:32 --> Controller Class Initialized
INFO - 2020-09-09 10:24:32 --> Model Class Initialized
INFO - 2020-09-09 10:24:32 --> Model Class Initialized
ERROR - 2020-09-09 10:24:32 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 10:24:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 10:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:24:56 --> Config Class Initialized
INFO - 2020-09-09 10:24:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:24:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:24:56 --> Utf8 Class Initialized
INFO - 2020-09-09 10:24:56 --> URI Class Initialized
INFO - 2020-09-09 10:24:56 --> Router Class Initialized
INFO - 2020-09-09 10:24:56 --> Output Class Initialized
INFO - 2020-09-09 10:24:56 --> Security Class Initialized
DEBUG - 2020-09-09 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:24:56 --> Input Class Initialized
INFO - 2020-09-09 10:24:56 --> Language Class Initialized
INFO - 2020-09-09 10:24:56 --> Loader Class Initialized
INFO - 2020-09-09 10:24:56 --> Helper loaded: url_helper
INFO - 2020-09-09 10:24:56 --> Database Driver Class Initialized
INFO - 2020-09-09 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:24:56 --> Email Class Initialized
INFO - 2020-09-09 10:24:56 --> Controller Class Initialized
INFO - 2020-09-09 10:24:56 --> Model Class Initialized
INFO - 2020-09-09 10:24:56 --> Model Class Initialized
INFO - 2020-09-09 10:24:56 --> Final output sent to browser
DEBUG - 2020-09-09 10:24:56 --> Total execution time: 0.0861
ERROR - 2020-09-09 10:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:24:56 --> Config Class Initialized
INFO - 2020-09-09 10:24:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:24:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:24:56 --> Utf8 Class Initialized
INFO - 2020-09-09 10:24:56 --> URI Class Initialized
INFO - 2020-09-09 10:24:56 --> Router Class Initialized
INFO - 2020-09-09 10:24:56 --> Output Class Initialized
INFO - 2020-09-09 10:24:56 --> Security Class Initialized
DEBUG - 2020-09-09 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:24:56 --> Input Class Initialized
INFO - 2020-09-09 10:24:56 --> Language Class Initialized
INFO - 2020-09-09 10:24:56 --> Loader Class Initialized
INFO - 2020-09-09 10:24:56 --> Helper loaded: url_helper
INFO - 2020-09-09 10:24:56 --> Database Driver Class Initialized
INFO - 2020-09-09 10:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:24:56 --> Email Class Initialized
INFO - 2020-09-09 10:24:56 --> Controller Class Initialized
INFO - 2020-09-09 10:24:56 --> Model Class Initialized
INFO - 2020-09-09 10:24:56 --> Model Class Initialized
ERROR - 2020-09-09 10:24:56 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 10:24:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 10:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:31:26 --> Config Class Initialized
INFO - 2020-09-09 10:31:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:31:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:31:26 --> Utf8 Class Initialized
INFO - 2020-09-09 10:31:26 --> URI Class Initialized
INFO - 2020-09-09 10:31:26 --> Router Class Initialized
INFO - 2020-09-09 10:31:26 --> Output Class Initialized
INFO - 2020-09-09 10:31:26 --> Security Class Initialized
DEBUG - 2020-09-09 10:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:31:26 --> Input Class Initialized
INFO - 2020-09-09 10:31:26 --> Language Class Initialized
INFO - 2020-09-09 10:31:26 --> Loader Class Initialized
INFO - 2020-09-09 10:31:26 --> Helper loaded: url_helper
INFO - 2020-09-09 10:31:26 --> Database Driver Class Initialized
INFO - 2020-09-09 10:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:31:26 --> Email Class Initialized
INFO - 2020-09-09 10:31:26 --> Controller Class Initialized
INFO - 2020-09-09 10:31:26 --> Model Class Initialized
INFO - 2020-09-09 10:31:26 --> Model Class Initialized
INFO - 2020-09-09 10:31:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view.php
INFO - 2020-09-09 10:31:26 --> Final output sent to browser
DEBUG - 2020-09-09 10:31:26 --> Total execution time: 0.0846
ERROR - 2020-09-09 10:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:31:26 --> Config Class Initialized
INFO - 2020-09-09 10:31:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:31:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:31:26 --> Utf8 Class Initialized
INFO - 2020-09-09 10:31:26 --> URI Class Initialized
INFO - 2020-09-09 10:31:26 --> Router Class Initialized
INFO - 2020-09-09 10:31:26 --> Output Class Initialized
INFO - 2020-09-09 10:31:26 --> Security Class Initialized
DEBUG - 2020-09-09 10:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:31:26 --> Input Class Initialized
INFO - 2020-09-09 10:31:26 --> Language Class Initialized
INFO - 2020-09-09 10:31:26 --> Loader Class Initialized
INFO - 2020-09-09 10:31:26 --> Helper loaded: url_helper
INFO - 2020-09-09 10:31:26 --> Database Driver Class Initialized
INFO - 2020-09-09 10:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:31:26 --> Email Class Initialized
INFO - 2020-09-09 10:31:26 --> Controller Class Initialized
INFO - 2020-09-09 10:31:26 --> Model Class Initialized
INFO - 2020-09-09 10:31:26 --> Model Class Initialized
ERROR - 2020-09-09 10:31:26 --> Query error: Unknown column 'CustomerID' in 'order clause' - Invalid query: SELECT *
FROM `tbl_customer`
ORDER BY `CustomerID` DESC
INFO - 2020-09-09 10:31:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-09 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:35:13 --> Config Class Initialized
INFO - 2020-09-09 10:35:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:35:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:35:13 --> Utf8 Class Initialized
INFO - 2020-09-09 10:35:13 --> URI Class Initialized
INFO - 2020-09-09 10:35:13 --> Router Class Initialized
INFO - 2020-09-09 10:35:13 --> Output Class Initialized
INFO - 2020-09-09 10:35:13 --> Security Class Initialized
DEBUG - 2020-09-09 10:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:35:13 --> Input Class Initialized
INFO - 2020-09-09 10:35:13 --> Language Class Initialized
INFO - 2020-09-09 10:35:13 --> Loader Class Initialized
INFO - 2020-09-09 10:35:13 --> Helper loaded: url_helper
INFO - 2020-09-09 10:35:13 --> Database Driver Class Initialized
INFO - 2020-09-09 10:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:35:13 --> Email Class Initialized
INFO - 2020-09-09 10:35:13 --> Controller Class Initialized
INFO - 2020-09-09 10:35:13 --> Model Class Initialized
INFO - 2020-09-09 10:35:13 --> Model Class Initialized
INFO - 2020-09-09 10:35:13 --> Final output sent to browser
DEBUG - 2020-09-09 10:35:13 --> Total execution time: 0.0879
ERROR - 2020-09-09 10:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:35:14 --> Config Class Initialized
INFO - 2020-09-09 10:35:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:35:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:35:14 --> Utf8 Class Initialized
INFO - 2020-09-09 10:35:14 --> URI Class Initialized
INFO - 2020-09-09 10:35:14 --> Router Class Initialized
INFO - 2020-09-09 10:35:14 --> Output Class Initialized
INFO - 2020-09-09 10:35:14 --> Security Class Initialized
DEBUG - 2020-09-09 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:35:14 --> Input Class Initialized
INFO - 2020-09-09 10:35:14 --> Language Class Initialized
INFO - 2020-09-09 10:35:14 --> Loader Class Initialized
INFO - 2020-09-09 10:35:14 --> Helper loaded: url_helper
INFO - 2020-09-09 10:35:14 --> Database Driver Class Initialized
INFO - 2020-09-09 10:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:35:14 --> Email Class Initialized
INFO - 2020-09-09 10:35:14 --> Controller Class Initialized
INFO - 2020-09-09 10:35:14 --> Model Class Initialized
INFO - 2020-09-09 10:35:14 --> Model Class Initialized
INFO - 2020-09-09 10:35:14 --> Final output sent to browser
DEBUG - 2020-09-09 10:35:14 --> Total execution time: 0.0433
ERROR - 2020-09-09 10:41:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:41:07 --> Config Class Initialized
INFO - 2020-09-09 10:41:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:41:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:41:07 --> Utf8 Class Initialized
INFO - 2020-09-09 10:41:07 --> URI Class Initialized
INFO - 2020-09-09 10:41:07 --> Router Class Initialized
INFO - 2020-09-09 10:41:07 --> Output Class Initialized
INFO - 2020-09-09 10:41:07 --> Security Class Initialized
DEBUG - 2020-09-09 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:41:07 --> Input Class Initialized
INFO - 2020-09-09 10:41:07 --> Language Class Initialized
INFO - 2020-09-09 10:41:07 --> Loader Class Initialized
INFO - 2020-09-09 10:41:07 --> Helper loaded: url_helper
INFO - 2020-09-09 10:41:07 --> Database Driver Class Initialized
INFO - 2020-09-09 10:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:41:07 --> Email Class Initialized
INFO - 2020-09-09 10:41:07 --> Controller Class Initialized
INFO - 2020-09-09 10:41:07 --> Model Class Initialized
INFO - 2020-09-09 10:41:07 --> Model Class Initialized
INFO - 2020-09-09 10:41:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:41:07 --> Final output sent to browser
DEBUG - 2020-09-09 10:41:07 --> Total execution time: 0.0377
ERROR - 2020-09-09 10:41:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:41:08 --> Config Class Initialized
INFO - 2020-09-09 10:41:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:41:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:41:08 --> Utf8 Class Initialized
INFO - 2020-09-09 10:41:08 --> URI Class Initialized
INFO - 2020-09-09 10:41:08 --> Router Class Initialized
INFO - 2020-09-09 10:41:08 --> Output Class Initialized
INFO - 2020-09-09 10:41:08 --> Security Class Initialized
DEBUG - 2020-09-09 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:41:08 --> Input Class Initialized
INFO - 2020-09-09 10:41:08 --> Language Class Initialized
INFO - 2020-09-09 10:41:08 --> Loader Class Initialized
INFO - 2020-09-09 10:41:08 --> Helper loaded: url_helper
INFO - 2020-09-09 10:41:08 --> Database Driver Class Initialized
INFO - 2020-09-09 10:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:41:08 --> Email Class Initialized
INFO - 2020-09-09 10:41:08 --> Controller Class Initialized
INFO - 2020-09-09 10:41:08 --> Model Class Initialized
INFO - 2020-09-09 10:41:08 --> Model Class Initialized
INFO - 2020-09-09 10:41:08 --> Final output sent to browser
DEBUG - 2020-09-09 10:41:08 --> Total execution time: 0.0427
ERROR - 2020-09-09 10:42:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:42:59 --> Config Class Initialized
INFO - 2020-09-09 10:42:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:42:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:42:59 --> Utf8 Class Initialized
INFO - 2020-09-09 10:42:59 --> URI Class Initialized
INFO - 2020-09-09 10:42:59 --> Router Class Initialized
INFO - 2020-09-09 10:42:59 --> Output Class Initialized
INFO - 2020-09-09 10:42:59 --> Security Class Initialized
DEBUG - 2020-09-09 10:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:42:59 --> Input Class Initialized
INFO - 2020-09-09 10:42:59 --> Language Class Initialized
INFO - 2020-09-09 10:42:59 --> Loader Class Initialized
INFO - 2020-09-09 10:42:59 --> Helper loaded: url_helper
INFO - 2020-09-09 10:42:59 --> Database Driver Class Initialized
INFO - 2020-09-09 10:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:42:59 --> Email Class Initialized
INFO - 2020-09-09 10:42:59 --> Controller Class Initialized
INFO - 2020-09-09 10:42:59 --> Model Class Initialized
INFO - 2020-09-09 10:42:59 --> Model Class Initialized
INFO - 2020-09-09 10:42:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:42:59 --> Final output sent to browser
DEBUG - 2020-09-09 10:42:59 --> Total execution time: 0.0362
ERROR - 2020-09-09 10:42:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:42:59 --> Config Class Initialized
INFO - 2020-09-09 10:42:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:42:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:42:59 --> Utf8 Class Initialized
INFO - 2020-09-09 10:42:59 --> URI Class Initialized
INFO - 2020-09-09 10:42:59 --> Router Class Initialized
INFO - 2020-09-09 10:42:59 --> Output Class Initialized
INFO - 2020-09-09 10:42:59 --> Security Class Initialized
DEBUG - 2020-09-09 10:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:42:59 --> Input Class Initialized
INFO - 2020-09-09 10:42:59 --> Language Class Initialized
INFO - 2020-09-09 10:42:59 --> Loader Class Initialized
INFO - 2020-09-09 10:42:59 --> Helper loaded: url_helper
INFO - 2020-09-09 10:42:59 --> Database Driver Class Initialized
INFO - 2020-09-09 10:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:42:59 --> Email Class Initialized
INFO - 2020-09-09 10:42:59 --> Controller Class Initialized
INFO - 2020-09-09 10:42:59 --> Model Class Initialized
INFO - 2020-09-09 10:42:59 --> Model Class Initialized
INFO - 2020-09-09 10:42:59 --> Final output sent to browser
DEBUG - 2020-09-09 10:42:59 --> Total execution time: 0.0676
ERROR - 2020-09-09 10:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:43:14 --> Config Class Initialized
INFO - 2020-09-09 10:43:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:43:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:43:14 --> Utf8 Class Initialized
INFO - 2020-09-09 10:43:14 --> URI Class Initialized
INFO - 2020-09-09 10:43:14 --> Router Class Initialized
INFO - 2020-09-09 10:43:14 --> Output Class Initialized
INFO - 2020-09-09 10:43:14 --> Security Class Initialized
DEBUG - 2020-09-09 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:43:14 --> Input Class Initialized
INFO - 2020-09-09 10:43:14 --> Language Class Initialized
INFO - 2020-09-09 10:43:14 --> Loader Class Initialized
INFO - 2020-09-09 10:43:14 --> Helper loaded: url_helper
INFO - 2020-09-09 10:43:14 --> Database Driver Class Initialized
INFO - 2020-09-09 10:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:43:14 --> Email Class Initialized
INFO - 2020-09-09 10:43:14 --> Controller Class Initialized
INFO - 2020-09-09 10:43:14 --> Model Class Initialized
INFO - 2020-09-09 10:43:14 --> Model Class Initialized
INFO - 2020-09-09 10:43:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:43:14 --> Final output sent to browser
DEBUG - 2020-09-09 10:43:14 --> Total execution time: 0.0400
ERROR - 2020-09-09 10:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:43:14 --> Config Class Initialized
INFO - 2020-09-09 10:43:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:43:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:43:14 --> Utf8 Class Initialized
INFO - 2020-09-09 10:43:14 --> URI Class Initialized
INFO - 2020-09-09 10:43:14 --> Router Class Initialized
INFO - 2020-09-09 10:43:14 --> Output Class Initialized
INFO - 2020-09-09 10:43:14 --> Security Class Initialized
DEBUG - 2020-09-09 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:43:14 --> Input Class Initialized
INFO - 2020-09-09 10:43:14 --> Language Class Initialized
INFO - 2020-09-09 10:43:14 --> Loader Class Initialized
INFO - 2020-09-09 10:43:14 --> Helper loaded: url_helper
INFO - 2020-09-09 10:43:14 --> Database Driver Class Initialized
INFO - 2020-09-09 10:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:43:14 --> Email Class Initialized
INFO - 2020-09-09 10:43:14 --> Controller Class Initialized
INFO - 2020-09-09 10:43:14 --> Model Class Initialized
INFO - 2020-09-09 10:43:14 --> Model Class Initialized
INFO - 2020-09-09 10:43:14 --> Final output sent to browser
DEBUG - 2020-09-09 10:43:14 --> Total execution time: 0.0449
ERROR - 2020-09-09 10:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:43:36 --> Config Class Initialized
INFO - 2020-09-09 10:43:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:43:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:43:36 --> Utf8 Class Initialized
INFO - 2020-09-09 10:43:36 --> URI Class Initialized
INFO - 2020-09-09 10:43:36 --> Router Class Initialized
INFO - 2020-09-09 10:43:36 --> Output Class Initialized
INFO - 2020-09-09 10:43:36 --> Security Class Initialized
DEBUG - 2020-09-09 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:43:36 --> Input Class Initialized
INFO - 2020-09-09 10:43:36 --> Language Class Initialized
INFO - 2020-09-09 10:43:36 --> Loader Class Initialized
INFO - 2020-09-09 10:43:36 --> Helper loaded: url_helper
INFO - 2020-09-09 10:43:36 --> Database Driver Class Initialized
INFO - 2020-09-09 10:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:43:36 --> Email Class Initialized
INFO - 2020-09-09 10:43:36 --> Controller Class Initialized
INFO - 2020-09-09 10:43:36 --> Model Class Initialized
INFO - 2020-09-09 10:43:36 --> Model Class Initialized
INFO - 2020-09-09 10:43:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:43:36 --> Final output sent to browser
DEBUG - 2020-09-09 10:43:36 --> Total execution time: 0.0382
ERROR - 2020-09-09 10:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:43:36 --> Config Class Initialized
INFO - 2020-09-09 10:43:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:43:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:43:36 --> Utf8 Class Initialized
INFO - 2020-09-09 10:43:36 --> URI Class Initialized
INFO - 2020-09-09 10:43:36 --> Router Class Initialized
INFO - 2020-09-09 10:43:36 --> Output Class Initialized
INFO - 2020-09-09 10:43:36 --> Security Class Initialized
DEBUG - 2020-09-09 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:43:36 --> Input Class Initialized
INFO - 2020-09-09 10:43:36 --> Language Class Initialized
INFO - 2020-09-09 10:43:36 --> Loader Class Initialized
INFO - 2020-09-09 10:43:36 --> Helper loaded: url_helper
INFO - 2020-09-09 10:43:36 --> Database Driver Class Initialized
INFO - 2020-09-09 10:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:43:37 --> Email Class Initialized
INFO - 2020-09-09 10:43:37 --> Controller Class Initialized
INFO - 2020-09-09 10:43:37 --> Model Class Initialized
INFO - 2020-09-09 10:43:37 --> Model Class Initialized
INFO - 2020-09-09 10:43:37 --> Final output sent to browser
DEBUG - 2020-09-09 10:43:37 --> Total execution time: 0.0431
ERROR - 2020-09-09 10:44:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:44:18 --> Config Class Initialized
INFO - 2020-09-09 10:44:18 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:44:18 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:44:18 --> Utf8 Class Initialized
INFO - 2020-09-09 10:44:18 --> URI Class Initialized
INFO - 2020-09-09 10:44:18 --> Router Class Initialized
INFO - 2020-09-09 10:44:18 --> Output Class Initialized
INFO - 2020-09-09 10:44:18 --> Security Class Initialized
DEBUG - 2020-09-09 10:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:44:18 --> Input Class Initialized
INFO - 2020-09-09 10:44:18 --> Language Class Initialized
INFO - 2020-09-09 10:44:18 --> Loader Class Initialized
INFO - 2020-09-09 10:44:18 --> Helper loaded: url_helper
INFO - 2020-09-09 10:44:18 --> Database Driver Class Initialized
INFO - 2020-09-09 10:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:44:18 --> Email Class Initialized
INFO - 2020-09-09 10:44:18 --> Controller Class Initialized
INFO - 2020-09-09 10:44:18 --> Model Class Initialized
INFO - 2020-09-09 10:44:18 --> Model Class Initialized
INFO - 2020-09-09 10:44:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:44:18 --> Final output sent to browser
DEBUG - 2020-09-09 10:44:18 --> Total execution time: 0.0395
ERROR - 2020-09-09 10:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:44:19 --> Config Class Initialized
INFO - 2020-09-09 10:44:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:44:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:44:19 --> Utf8 Class Initialized
INFO - 2020-09-09 10:44:19 --> URI Class Initialized
INFO - 2020-09-09 10:44:19 --> Router Class Initialized
INFO - 2020-09-09 10:44:19 --> Output Class Initialized
INFO - 2020-09-09 10:44:19 --> Security Class Initialized
DEBUG - 2020-09-09 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:44:19 --> Input Class Initialized
INFO - 2020-09-09 10:44:19 --> Language Class Initialized
INFO - 2020-09-09 10:44:19 --> Loader Class Initialized
INFO - 2020-09-09 10:44:19 --> Helper loaded: url_helper
INFO - 2020-09-09 10:44:19 --> Database Driver Class Initialized
INFO - 2020-09-09 10:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:44:19 --> Email Class Initialized
INFO - 2020-09-09 10:44:19 --> Controller Class Initialized
INFO - 2020-09-09 10:44:19 --> Model Class Initialized
INFO - 2020-09-09 10:44:19 --> Model Class Initialized
INFO - 2020-09-09 10:44:19 --> Final output sent to browser
DEBUG - 2020-09-09 10:44:19 --> Total execution time: 0.0407
ERROR - 2020-09-09 10:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:45:44 --> Config Class Initialized
INFO - 2020-09-09 10:45:44 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:45:44 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:45:44 --> Utf8 Class Initialized
INFO - 2020-09-09 10:45:44 --> URI Class Initialized
INFO - 2020-09-09 10:45:44 --> Router Class Initialized
INFO - 2020-09-09 10:45:44 --> Output Class Initialized
INFO - 2020-09-09 10:45:44 --> Security Class Initialized
DEBUG - 2020-09-09 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:45:44 --> Input Class Initialized
INFO - 2020-09-09 10:45:44 --> Language Class Initialized
INFO - 2020-09-09 10:45:44 --> Loader Class Initialized
INFO - 2020-09-09 10:45:44 --> Helper loaded: url_helper
INFO - 2020-09-09 10:45:44 --> Database Driver Class Initialized
INFO - 2020-09-09 10:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:45:44 --> Email Class Initialized
INFO - 2020-09-09 10:45:44 --> Controller Class Initialized
INFO - 2020-09-09 10:45:44 --> Model Class Initialized
INFO - 2020-09-09 10:45:44 --> Model Class Initialized
INFO - 2020-09-09 10:45:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:45:44 --> Final output sent to browser
DEBUG - 2020-09-09 10:45:44 --> Total execution time: 0.0412
ERROR - 2020-09-09 10:45:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:45:44 --> Config Class Initialized
INFO - 2020-09-09 10:45:44 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:45:44 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:45:44 --> Utf8 Class Initialized
INFO - 2020-09-09 10:45:44 --> URI Class Initialized
INFO - 2020-09-09 10:45:44 --> Router Class Initialized
INFO - 2020-09-09 10:45:44 --> Output Class Initialized
INFO - 2020-09-09 10:45:44 --> Security Class Initialized
DEBUG - 2020-09-09 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:45:44 --> Input Class Initialized
INFO - 2020-09-09 10:45:44 --> Language Class Initialized
INFO - 2020-09-09 10:45:44 --> Loader Class Initialized
INFO - 2020-09-09 10:45:44 --> Helper loaded: url_helper
INFO - 2020-09-09 10:45:44 --> Database Driver Class Initialized
INFO - 2020-09-09 10:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:45:44 --> Email Class Initialized
INFO - 2020-09-09 10:45:44 --> Controller Class Initialized
INFO - 2020-09-09 10:45:44 --> Model Class Initialized
INFO - 2020-09-09 10:45:44 --> Model Class Initialized
INFO - 2020-09-09 10:45:44 --> Final output sent to browser
DEBUG - 2020-09-09 10:45:44 --> Total execution time: 0.0449
ERROR - 2020-09-09 10:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:46:19 --> Config Class Initialized
INFO - 2020-09-09 10:46:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:46:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:46:19 --> Utf8 Class Initialized
INFO - 2020-09-09 10:46:19 --> URI Class Initialized
INFO - 2020-09-09 10:46:19 --> Router Class Initialized
INFO - 2020-09-09 10:46:19 --> Output Class Initialized
INFO - 2020-09-09 10:46:19 --> Security Class Initialized
DEBUG - 2020-09-09 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:46:19 --> Input Class Initialized
INFO - 2020-09-09 10:46:19 --> Language Class Initialized
INFO - 2020-09-09 10:46:19 --> Loader Class Initialized
INFO - 2020-09-09 10:46:19 --> Helper loaded: url_helper
INFO - 2020-09-09 10:46:19 --> Database Driver Class Initialized
INFO - 2020-09-09 10:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:46:19 --> Email Class Initialized
INFO - 2020-09-09 10:46:19 --> Controller Class Initialized
INFO - 2020-09-09 10:46:19 --> Model Class Initialized
INFO - 2020-09-09 10:46:19 --> Model Class Initialized
INFO - 2020-09-09 10:46:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:46:19 --> Final output sent to browser
DEBUG - 2020-09-09 10:46:19 --> Total execution time: 0.0440
ERROR - 2020-09-09 10:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:46:20 --> Config Class Initialized
INFO - 2020-09-09 10:46:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:46:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:46:20 --> Utf8 Class Initialized
INFO - 2020-09-09 10:46:20 --> URI Class Initialized
INFO - 2020-09-09 10:46:20 --> Router Class Initialized
INFO - 2020-09-09 10:46:20 --> Output Class Initialized
INFO - 2020-09-09 10:46:20 --> Security Class Initialized
DEBUG - 2020-09-09 10:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:46:20 --> Input Class Initialized
INFO - 2020-09-09 10:46:20 --> Language Class Initialized
INFO - 2020-09-09 10:46:20 --> Loader Class Initialized
INFO - 2020-09-09 10:46:20 --> Helper loaded: url_helper
INFO - 2020-09-09 10:46:20 --> Database Driver Class Initialized
INFO - 2020-09-09 10:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:46:20 --> Email Class Initialized
INFO - 2020-09-09 10:46:20 --> Controller Class Initialized
INFO - 2020-09-09 10:46:20 --> Model Class Initialized
INFO - 2020-09-09 10:46:20 --> Model Class Initialized
INFO - 2020-09-09 10:46:20 --> Final output sent to browser
DEBUG - 2020-09-09 10:46:20 --> Total execution time: 0.0443
ERROR - 2020-09-09 10:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:50:04 --> Config Class Initialized
INFO - 2020-09-09 10:50:04 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:50:04 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:50:04 --> Utf8 Class Initialized
INFO - 2020-09-09 10:50:04 --> URI Class Initialized
INFO - 2020-09-09 10:50:04 --> Router Class Initialized
INFO - 2020-09-09 10:50:04 --> Output Class Initialized
INFO - 2020-09-09 10:50:04 --> Security Class Initialized
DEBUG - 2020-09-09 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:50:04 --> Input Class Initialized
INFO - 2020-09-09 10:50:04 --> Language Class Initialized
INFO - 2020-09-09 10:50:04 --> Loader Class Initialized
INFO - 2020-09-09 10:50:04 --> Helper loaded: url_helper
INFO - 2020-09-09 10:50:04 --> Database Driver Class Initialized
INFO - 2020-09-09 10:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:50:04 --> Email Class Initialized
INFO - 2020-09-09 10:50:04 --> Controller Class Initialized
INFO - 2020-09-09 10:50:04 --> Model Class Initialized
INFO - 2020-09-09 10:50:04 --> Model Class Initialized
INFO - 2020-09-09 10:50:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:50:04 --> Final output sent to browser
DEBUG - 2020-09-09 10:50:04 --> Total execution time: 0.0381
ERROR - 2020-09-09 10:50:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:50:04 --> Config Class Initialized
INFO - 2020-09-09 10:50:04 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:50:04 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:50:04 --> Utf8 Class Initialized
INFO - 2020-09-09 10:50:04 --> URI Class Initialized
INFO - 2020-09-09 10:50:04 --> Router Class Initialized
INFO - 2020-09-09 10:50:04 --> Output Class Initialized
INFO - 2020-09-09 10:50:04 --> Security Class Initialized
DEBUG - 2020-09-09 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:50:04 --> Input Class Initialized
INFO - 2020-09-09 10:50:04 --> Language Class Initialized
INFO - 2020-09-09 10:50:04 --> Loader Class Initialized
INFO - 2020-09-09 10:50:04 --> Helper loaded: url_helper
INFO - 2020-09-09 10:50:04 --> Database Driver Class Initialized
INFO - 2020-09-09 10:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:50:04 --> Email Class Initialized
INFO - 2020-09-09 10:50:04 --> Controller Class Initialized
INFO - 2020-09-09 10:50:04 --> Model Class Initialized
INFO - 2020-09-09 10:50:04 --> Model Class Initialized
INFO - 2020-09-09 10:50:04 --> Final output sent to browser
DEBUG - 2020-09-09 10:50:04 --> Total execution time: 0.0368
ERROR - 2020-09-09 10:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:54:30 --> Config Class Initialized
INFO - 2020-09-09 10:54:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:54:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:54:30 --> Utf8 Class Initialized
INFO - 2020-09-09 10:54:30 --> URI Class Initialized
INFO - 2020-09-09 10:54:30 --> Router Class Initialized
INFO - 2020-09-09 10:54:30 --> Output Class Initialized
INFO - 2020-09-09 10:54:30 --> Security Class Initialized
DEBUG - 2020-09-09 10:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:54:30 --> Input Class Initialized
INFO - 2020-09-09 10:54:30 --> Language Class Initialized
INFO - 2020-09-09 10:54:30 --> Loader Class Initialized
INFO - 2020-09-09 10:54:30 --> Helper loaded: url_helper
INFO - 2020-09-09 10:54:30 --> Database Driver Class Initialized
INFO - 2020-09-09 10:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:54:30 --> Email Class Initialized
INFO - 2020-09-09 10:54:30 --> Controller Class Initialized
INFO - 2020-09-09 10:54:30 --> Model Class Initialized
INFO - 2020-09-09 10:54:30 --> Model Class Initialized
INFO - 2020-09-09 10:54:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 10:54:30 --> Final output sent to browser
DEBUG - 2020-09-09 10:54:30 --> Total execution time: 0.0536
ERROR - 2020-09-09 10:54:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:54:31 --> Config Class Initialized
INFO - 2020-09-09 10:54:31 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:54:31 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:54:31 --> Utf8 Class Initialized
INFO - 2020-09-09 10:54:31 --> URI Class Initialized
INFO - 2020-09-09 10:54:31 --> Router Class Initialized
INFO - 2020-09-09 10:54:31 --> Output Class Initialized
INFO - 2020-09-09 10:54:31 --> Security Class Initialized
DEBUG - 2020-09-09 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:54:31 --> Input Class Initialized
INFO - 2020-09-09 10:54:31 --> Language Class Initialized
INFO - 2020-09-09 10:54:31 --> Loader Class Initialized
INFO - 2020-09-09 10:54:31 --> Helper loaded: url_helper
INFO - 2020-09-09 10:54:31 --> Database Driver Class Initialized
INFO - 2020-09-09 10:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:54:31 --> Email Class Initialized
INFO - 2020-09-09 10:54:31 --> Controller Class Initialized
INFO - 2020-09-09 10:54:31 --> Model Class Initialized
INFO - 2020-09-09 10:54:31 --> Model Class Initialized
INFO - 2020-09-09 10:54:31 --> Final output sent to browser
DEBUG - 2020-09-09 10:54:31 --> Total execution time: 0.0541
ERROR - 2020-09-09 10:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:54:57 --> Config Class Initialized
INFO - 2020-09-09 10:54:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:54:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:54:57 --> Utf8 Class Initialized
INFO - 2020-09-09 10:54:57 --> URI Class Initialized
INFO - 2020-09-09 10:54:57 --> Router Class Initialized
INFO - 2020-09-09 10:54:57 --> Output Class Initialized
INFO - 2020-09-09 10:54:57 --> Security Class Initialized
DEBUG - 2020-09-09 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:54:57 --> Input Class Initialized
INFO - 2020-09-09 10:54:57 --> Language Class Initialized
INFO - 2020-09-09 10:54:57 --> Loader Class Initialized
INFO - 2020-09-09 10:54:57 --> Helper loaded: url_helper
INFO - 2020-09-09 10:54:57 --> Database Driver Class Initialized
INFO - 2020-09-09 10:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:54:57 --> Email Class Initialized
INFO - 2020-09-09 10:54:57 --> Controller Class Initialized
INFO - 2020-09-09 10:54:57 --> Model Class Initialized
INFO - 2020-09-09 10:54:57 --> Model Class Initialized
INFO - 2020-09-09 10:54:57 --> Final output sent to browser
DEBUG - 2020-09-09 10:54:57 --> Total execution time: 0.0763
ERROR - 2020-09-09 10:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:54:57 --> Config Class Initialized
INFO - 2020-09-09 10:54:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:54:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:54:57 --> Utf8 Class Initialized
INFO - 2020-09-09 10:54:57 --> URI Class Initialized
INFO - 2020-09-09 10:54:57 --> Router Class Initialized
INFO - 2020-09-09 10:54:57 --> Output Class Initialized
INFO - 2020-09-09 10:54:57 --> Security Class Initialized
DEBUG - 2020-09-09 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:54:57 --> Input Class Initialized
INFO - 2020-09-09 10:54:57 --> Language Class Initialized
INFO - 2020-09-09 10:54:57 --> Loader Class Initialized
INFO - 2020-09-09 10:54:57 --> Helper loaded: url_helper
INFO - 2020-09-09 10:54:57 --> Database Driver Class Initialized
INFO - 2020-09-09 10:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:54:57 --> Email Class Initialized
INFO - 2020-09-09 10:54:57 --> Controller Class Initialized
INFO - 2020-09-09 10:54:57 --> Model Class Initialized
INFO - 2020-09-09 10:54:57 --> Model Class Initialized
INFO - 2020-09-09 10:54:57 --> Final output sent to browser
DEBUG - 2020-09-09 10:54:57 --> Total execution time: 0.0412
ERROR - 2020-09-09 10:56:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:56:22 --> Config Class Initialized
INFO - 2020-09-09 10:56:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:56:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:56:22 --> Utf8 Class Initialized
INFO - 2020-09-09 10:56:22 --> URI Class Initialized
INFO - 2020-09-09 10:56:22 --> Router Class Initialized
INFO - 2020-09-09 10:56:22 --> Output Class Initialized
INFO - 2020-09-09 10:56:22 --> Security Class Initialized
DEBUG - 2020-09-09 10:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:56:22 --> Input Class Initialized
INFO - 2020-09-09 10:56:22 --> Language Class Initialized
INFO - 2020-09-09 10:56:22 --> Loader Class Initialized
INFO - 2020-09-09 10:56:22 --> Helper loaded: url_helper
INFO - 2020-09-09 10:56:22 --> Database Driver Class Initialized
INFO - 2020-09-09 10:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:56:22 --> Email Class Initialized
INFO - 2020-09-09 10:56:22 --> Controller Class Initialized
INFO - 2020-09-09 10:56:22 --> Model Class Initialized
INFO - 2020-09-09 10:56:22 --> Model Class Initialized
INFO - 2020-09-09 10:56:22 --> Final output sent to browser
DEBUG - 2020-09-09 10:56:22 --> Total execution time: 0.0760
ERROR - 2020-09-09 10:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 10:56:23 --> Config Class Initialized
INFO - 2020-09-09 10:56:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 10:56:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 10:56:23 --> Utf8 Class Initialized
INFO - 2020-09-09 10:56:23 --> URI Class Initialized
INFO - 2020-09-09 10:56:23 --> Router Class Initialized
INFO - 2020-09-09 10:56:23 --> Output Class Initialized
INFO - 2020-09-09 10:56:23 --> Security Class Initialized
DEBUG - 2020-09-09 10:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 10:56:23 --> Input Class Initialized
INFO - 2020-09-09 10:56:23 --> Language Class Initialized
INFO - 2020-09-09 10:56:23 --> Loader Class Initialized
INFO - 2020-09-09 10:56:23 --> Helper loaded: url_helper
INFO - 2020-09-09 10:56:23 --> Database Driver Class Initialized
INFO - 2020-09-09 10:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 10:56:23 --> Email Class Initialized
INFO - 2020-09-09 10:56:23 --> Controller Class Initialized
INFO - 2020-09-09 10:56:23 --> Model Class Initialized
INFO - 2020-09-09 10:56:23 --> Model Class Initialized
INFO - 2020-09-09 10:56:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view.php
INFO - 2020-09-09 10:56:23 --> Final output sent to browser
DEBUG - 2020-09-09 10:56:23 --> Total execution time: 0.0381
ERROR - 2020-09-09 11:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:00:37 --> Config Class Initialized
INFO - 2020-09-09 11:00:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:00:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:00:37 --> Utf8 Class Initialized
INFO - 2020-09-09 11:00:37 --> URI Class Initialized
INFO - 2020-09-09 11:00:37 --> Router Class Initialized
INFO - 2020-09-09 11:00:37 --> Output Class Initialized
INFO - 2020-09-09 11:00:37 --> Security Class Initialized
DEBUG - 2020-09-09 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:00:37 --> Input Class Initialized
INFO - 2020-09-09 11:00:37 --> Language Class Initialized
INFO - 2020-09-09 11:00:37 --> Loader Class Initialized
INFO - 2020-09-09 11:00:37 --> Helper loaded: url_helper
INFO - 2020-09-09 11:00:37 --> Database Driver Class Initialized
INFO - 2020-09-09 11:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:00:37 --> Email Class Initialized
INFO - 2020-09-09 11:00:37 --> Controller Class Initialized
INFO - 2020-09-09 11:00:37 --> Model Class Initialized
INFO - 2020-09-09 11:00:37 --> Model Class Initialized
INFO - 2020-09-09 11:00:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:00:37 --> Final output sent to browser
DEBUG - 2020-09-09 11:00:37 --> Total execution time: 0.0422
ERROR - 2020-09-09 11:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:00:38 --> Config Class Initialized
INFO - 2020-09-09 11:00:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:00:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:00:38 --> Utf8 Class Initialized
INFO - 2020-09-09 11:00:38 --> URI Class Initialized
INFO - 2020-09-09 11:00:38 --> Router Class Initialized
INFO - 2020-09-09 11:00:38 --> Output Class Initialized
INFO - 2020-09-09 11:00:38 --> Security Class Initialized
DEBUG - 2020-09-09 11:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:00:38 --> Input Class Initialized
INFO - 2020-09-09 11:00:38 --> Language Class Initialized
INFO - 2020-09-09 11:00:38 --> Loader Class Initialized
INFO - 2020-09-09 11:00:38 --> Helper loaded: url_helper
INFO - 2020-09-09 11:00:38 --> Database Driver Class Initialized
INFO - 2020-09-09 11:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:00:38 --> Email Class Initialized
INFO - 2020-09-09 11:00:38 --> Controller Class Initialized
INFO - 2020-09-09 11:00:38 --> Model Class Initialized
INFO - 2020-09-09 11:00:38 --> Model Class Initialized
INFO - 2020-09-09 11:00:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-09 11:00:38 --> Final output sent to browser
DEBUG - 2020-09-09 11:00:38 --> Total execution time: 0.0442
ERROR - 2020-09-09 11:01:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:01:02 --> Config Class Initialized
INFO - 2020-09-09 11:01:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:01:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:01:02 --> Utf8 Class Initialized
INFO - 2020-09-09 11:01:02 --> URI Class Initialized
INFO - 2020-09-09 11:01:02 --> Router Class Initialized
INFO - 2020-09-09 11:01:02 --> Output Class Initialized
INFO - 2020-09-09 11:01:02 --> Security Class Initialized
DEBUG - 2020-09-09 11:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:01:02 --> Input Class Initialized
INFO - 2020-09-09 11:01:02 --> Language Class Initialized
INFO - 2020-09-09 11:01:02 --> Loader Class Initialized
INFO - 2020-09-09 11:01:02 --> Helper loaded: url_helper
INFO - 2020-09-09 11:01:02 --> Database Driver Class Initialized
INFO - 2020-09-09 11:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:01:02 --> Email Class Initialized
INFO - 2020-09-09 11:01:02 --> Controller Class Initialized
INFO - 2020-09-09 11:01:02 --> Model Class Initialized
INFO - 2020-09-09 11:01:02 --> Model Class Initialized
INFO - 2020-09-09 11:01:02 --> Final output sent to browser
DEBUG - 2020-09-09 11:01:02 --> Total execution time: 0.0856
ERROR - 2020-09-09 11:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:01:03 --> Config Class Initialized
INFO - 2020-09-09 11:01:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:01:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:01:03 --> Utf8 Class Initialized
INFO - 2020-09-09 11:01:03 --> URI Class Initialized
INFO - 2020-09-09 11:01:03 --> Router Class Initialized
INFO - 2020-09-09 11:01:03 --> Output Class Initialized
INFO - 2020-09-09 11:01:03 --> Security Class Initialized
DEBUG - 2020-09-09 11:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:01:03 --> Input Class Initialized
INFO - 2020-09-09 11:01:03 --> Language Class Initialized
INFO - 2020-09-09 11:01:03 --> Loader Class Initialized
INFO - 2020-09-09 11:01:03 --> Helper loaded: url_helper
INFO - 2020-09-09 11:01:03 --> Database Driver Class Initialized
INFO - 2020-09-09 11:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:01:03 --> Email Class Initialized
INFO - 2020-09-09 11:01:03 --> Controller Class Initialized
INFO - 2020-09-09 11:01:03 --> Model Class Initialized
INFO - 2020-09-09 11:01:03 --> Model Class Initialized
INFO - 2020-09-09 11:01:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-09 11:01:03 --> Final output sent to browser
DEBUG - 2020-09-09 11:01:03 --> Total execution time: 0.0469
ERROR - 2020-09-09 11:02:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:02:36 --> Config Class Initialized
INFO - 2020-09-09 11:02:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:02:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:02:36 --> Utf8 Class Initialized
INFO - 2020-09-09 11:02:36 --> URI Class Initialized
INFO - 2020-09-09 11:02:36 --> Router Class Initialized
INFO - 2020-09-09 11:02:36 --> Output Class Initialized
INFO - 2020-09-09 11:02:36 --> Security Class Initialized
DEBUG - 2020-09-09 11:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:02:36 --> Input Class Initialized
INFO - 2020-09-09 11:02:36 --> Language Class Initialized
INFO - 2020-09-09 11:02:36 --> Loader Class Initialized
INFO - 2020-09-09 11:02:36 --> Helper loaded: url_helper
INFO - 2020-09-09 11:02:36 --> Database Driver Class Initialized
INFO - 2020-09-09 11:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:02:36 --> Email Class Initialized
INFO - 2020-09-09 11:02:36 --> Controller Class Initialized
INFO - 2020-09-09 11:02:36 --> Model Class Initialized
INFO - 2020-09-09 11:02:36 --> Model Class Initialized
INFO - 2020-09-09 11:02:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:02:36 --> Final output sent to browser
DEBUG - 2020-09-09 11:02:36 --> Total execution time: 0.0365
ERROR - 2020-09-09 11:02:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:02:36 --> Config Class Initialized
INFO - 2020-09-09 11:02:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:02:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:02:36 --> Utf8 Class Initialized
INFO - 2020-09-09 11:02:36 --> URI Class Initialized
INFO - 2020-09-09 11:02:36 --> Router Class Initialized
INFO - 2020-09-09 11:02:36 --> Output Class Initialized
INFO - 2020-09-09 11:02:36 --> Security Class Initialized
DEBUG - 2020-09-09 11:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:02:36 --> Input Class Initialized
INFO - 2020-09-09 11:02:36 --> Language Class Initialized
INFO - 2020-09-09 11:02:36 --> Loader Class Initialized
INFO - 2020-09-09 11:02:36 --> Helper loaded: url_helper
INFO - 2020-09-09 11:02:36 --> Database Driver Class Initialized
INFO - 2020-09-09 11:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:02:36 --> Email Class Initialized
INFO - 2020-09-09 11:02:36 --> Controller Class Initialized
INFO - 2020-09-09 11:02:36 --> Model Class Initialized
INFO - 2020-09-09 11:02:36 --> Model Class Initialized
INFO - 2020-09-09 11:02:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-09 11:02:36 --> Final output sent to browser
DEBUG - 2020-09-09 11:02:36 --> Total execution time: 0.0439
ERROR - 2020-09-09 11:02:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:02:45 --> Config Class Initialized
INFO - 2020-09-09 11:02:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:02:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:02:45 --> Utf8 Class Initialized
INFO - 2020-09-09 11:02:45 --> URI Class Initialized
INFO - 2020-09-09 11:02:45 --> Router Class Initialized
INFO - 2020-09-09 11:02:45 --> Output Class Initialized
INFO - 2020-09-09 11:02:45 --> Security Class Initialized
DEBUG - 2020-09-09 11:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:02:45 --> Input Class Initialized
INFO - 2020-09-09 11:02:45 --> Language Class Initialized
INFO - 2020-09-09 11:02:45 --> Loader Class Initialized
INFO - 2020-09-09 11:02:45 --> Helper loaded: url_helper
INFO - 2020-09-09 11:02:45 --> Database Driver Class Initialized
INFO - 2020-09-09 11:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:02:45 --> Email Class Initialized
INFO - 2020-09-09 11:02:45 --> Controller Class Initialized
INFO - 2020-09-09 11:02:45 --> Model Class Initialized
INFO - 2020-09-09 11:02:45 --> Model Class Initialized
INFO - 2020-09-09 11:02:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:02:45 --> Final output sent to browser
DEBUG - 2020-09-09 11:02:45 --> Total execution time: 0.0422
ERROR - 2020-09-09 11:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:02:46 --> Config Class Initialized
INFO - 2020-09-09 11:02:46 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:02:46 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:02:46 --> Utf8 Class Initialized
INFO - 2020-09-09 11:02:46 --> URI Class Initialized
INFO - 2020-09-09 11:02:46 --> Router Class Initialized
INFO - 2020-09-09 11:02:46 --> Output Class Initialized
INFO - 2020-09-09 11:02:46 --> Security Class Initialized
DEBUG - 2020-09-09 11:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:02:46 --> Input Class Initialized
INFO - 2020-09-09 11:02:46 --> Language Class Initialized
INFO - 2020-09-09 11:02:46 --> Loader Class Initialized
INFO - 2020-09-09 11:02:46 --> Helper loaded: url_helper
INFO - 2020-09-09 11:02:46 --> Database Driver Class Initialized
INFO - 2020-09-09 11:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:02:46 --> Email Class Initialized
INFO - 2020-09-09 11:02:46 --> Controller Class Initialized
INFO - 2020-09-09 11:02:46 --> Model Class Initialized
INFO - 2020-09-09 11:02:46 --> Model Class Initialized
INFO - 2020-09-09 11:02:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_data_view2.php
INFO - 2020-09-09 11:02:46 --> Final output sent to browser
DEBUG - 2020-09-09 11:02:46 --> Total execution time: 0.0450
ERROR - 2020-09-09 11:04:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:04:08 --> Config Class Initialized
INFO - 2020-09-09 11:04:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:04:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:04:08 --> Utf8 Class Initialized
INFO - 2020-09-09 11:04:08 --> URI Class Initialized
INFO - 2020-09-09 11:04:08 --> Router Class Initialized
INFO - 2020-09-09 11:04:08 --> Output Class Initialized
INFO - 2020-09-09 11:04:08 --> Security Class Initialized
DEBUG - 2020-09-09 11:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:04:08 --> Input Class Initialized
INFO - 2020-09-09 11:04:08 --> Language Class Initialized
INFO - 2020-09-09 11:04:08 --> Loader Class Initialized
INFO - 2020-09-09 11:04:08 --> Helper loaded: url_helper
INFO - 2020-09-09 11:04:08 --> Database Driver Class Initialized
INFO - 2020-09-09 11:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:04:08 --> Email Class Initialized
INFO - 2020-09-09 11:04:08 --> Controller Class Initialized
INFO - 2020-09-09 11:04:08 --> Model Class Initialized
INFO - 2020-09-09 11:04:08 --> Model Class Initialized
INFO - 2020-09-09 11:04:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:04:08 --> Final output sent to browser
DEBUG - 2020-09-09 11:04:08 --> Total execution time: 0.0498
ERROR - 2020-09-09 11:04:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:04:08 --> Config Class Initialized
INFO - 2020-09-09 11:04:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:04:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:04:08 --> Utf8 Class Initialized
INFO - 2020-09-09 11:04:08 --> URI Class Initialized
INFO - 2020-09-09 11:04:08 --> Router Class Initialized
INFO - 2020-09-09 11:04:08 --> Output Class Initialized
INFO - 2020-09-09 11:04:08 --> Security Class Initialized
DEBUG - 2020-09-09 11:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:04:08 --> Input Class Initialized
INFO - 2020-09-09 11:04:08 --> Language Class Initialized
INFO - 2020-09-09 11:04:08 --> Loader Class Initialized
INFO - 2020-09-09 11:04:08 --> Helper loaded: url_helper
INFO - 2020-09-09 11:04:08 --> Database Driver Class Initialized
INFO - 2020-09-09 11:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:04:08 --> Email Class Initialized
INFO - 2020-09-09 11:04:08 --> Controller Class Initialized
INFO - 2020-09-09 11:04:08 --> Model Class Initialized
INFO - 2020-09-09 11:04:08 --> Model Class Initialized
INFO - 2020-09-09 11:04:08 --> Final output sent to browser
DEBUG - 2020-09-09 11:04:08 --> Total execution time: 0.0454
ERROR - 2020-09-09 11:04:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:04:55 --> Config Class Initialized
INFO - 2020-09-09 11:04:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:04:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:04:55 --> Utf8 Class Initialized
INFO - 2020-09-09 11:04:55 --> URI Class Initialized
INFO - 2020-09-09 11:04:55 --> Router Class Initialized
INFO - 2020-09-09 11:04:55 --> Output Class Initialized
INFO - 2020-09-09 11:04:55 --> Security Class Initialized
DEBUG - 2020-09-09 11:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:04:55 --> Input Class Initialized
INFO - 2020-09-09 11:04:55 --> Language Class Initialized
INFO - 2020-09-09 11:04:55 --> Loader Class Initialized
INFO - 2020-09-09 11:04:55 --> Helper loaded: url_helper
INFO - 2020-09-09 11:04:55 --> Database Driver Class Initialized
INFO - 2020-09-09 11:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:04:55 --> Email Class Initialized
INFO - 2020-09-09 11:04:55 --> Controller Class Initialized
INFO - 2020-09-09 11:04:55 --> Model Class Initialized
INFO - 2020-09-09 11:04:55 --> Model Class Initialized
INFO - 2020-09-09 11:04:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:04:55 --> Final output sent to browser
DEBUG - 2020-09-09 11:04:55 --> Total execution time: 0.0374
ERROR - 2020-09-09 11:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:04:56 --> Config Class Initialized
INFO - 2020-09-09 11:04:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:04:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:04:56 --> Utf8 Class Initialized
INFO - 2020-09-09 11:04:56 --> URI Class Initialized
INFO - 2020-09-09 11:04:56 --> Router Class Initialized
INFO - 2020-09-09 11:04:56 --> Output Class Initialized
INFO - 2020-09-09 11:04:56 --> Security Class Initialized
DEBUG - 2020-09-09 11:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:04:56 --> Input Class Initialized
INFO - 2020-09-09 11:04:56 --> Language Class Initialized
INFO - 2020-09-09 11:04:56 --> Loader Class Initialized
INFO - 2020-09-09 11:04:56 --> Helper loaded: url_helper
INFO - 2020-09-09 11:04:56 --> Database Driver Class Initialized
INFO - 2020-09-09 11:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:04:56 --> Email Class Initialized
INFO - 2020-09-09 11:04:56 --> Controller Class Initialized
INFO - 2020-09-09 11:04:56 --> Model Class Initialized
INFO - 2020-09-09 11:04:56 --> Model Class Initialized
INFO - 2020-09-09 11:04:56 --> Final output sent to browser
DEBUG - 2020-09-09 11:04:56 --> Total execution time: 0.0436
ERROR - 2020-09-09 11:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:06:33 --> Config Class Initialized
INFO - 2020-09-09 11:06:33 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:06:33 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:06:33 --> Utf8 Class Initialized
INFO - 2020-09-09 11:06:33 --> URI Class Initialized
INFO - 2020-09-09 11:06:33 --> Router Class Initialized
INFO - 2020-09-09 11:06:33 --> Output Class Initialized
INFO - 2020-09-09 11:06:33 --> Security Class Initialized
DEBUG - 2020-09-09 11:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:06:33 --> Input Class Initialized
INFO - 2020-09-09 11:06:33 --> Language Class Initialized
INFO - 2020-09-09 11:06:33 --> Loader Class Initialized
INFO - 2020-09-09 11:06:33 --> Helper loaded: url_helper
INFO - 2020-09-09 11:06:33 --> Database Driver Class Initialized
INFO - 2020-09-09 11:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:06:33 --> Email Class Initialized
INFO - 2020-09-09 11:06:33 --> Controller Class Initialized
INFO - 2020-09-09 11:06:33 --> Model Class Initialized
INFO - 2020-09-09 11:06:33 --> Model Class Initialized
INFO - 2020-09-09 11:06:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:06:33 --> Final output sent to browser
DEBUG - 2020-09-09 11:06:33 --> Total execution time: 0.0402
ERROR - 2020-09-09 11:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:06:33 --> Config Class Initialized
INFO - 2020-09-09 11:06:33 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:06:33 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:06:33 --> Utf8 Class Initialized
INFO - 2020-09-09 11:06:33 --> URI Class Initialized
INFO - 2020-09-09 11:06:33 --> Router Class Initialized
INFO - 2020-09-09 11:06:33 --> Output Class Initialized
INFO - 2020-09-09 11:06:33 --> Security Class Initialized
DEBUG - 2020-09-09 11:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:06:33 --> Input Class Initialized
INFO - 2020-09-09 11:06:33 --> Language Class Initialized
INFO - 2020-09-09 11:06:33 --> Loader Class Initialized
INFO - 2020-09-09 11:06:33 --> Helper loaded: url_helper
INFO - 2020-09-09 11:06:33 --> Database Driver Class Initialized
INFO - 2020-09-09 11:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:06:33 --> Email Class Initialized
INFO - 2020-09-09 11:06:33 --> Controller Class Initialized
INFO - 2020-09-09 11:06:33 --> Model Class Initialized
INFO - 2020-09-09 11:06:33 --> Model Class Initialized
INFO - 2020-09-09 11:06:33 --> Final output sent to browser
DEBUG - 2020-09-09 11:06:33 --> Total execution time: 0.0412
ERROR - 2020-09-09 11:06:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:06:49 --> Config Class Initialized
INFO - 2020-09-09 11:06:49 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:06:49 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:06:49 --> Utf8 Class Initialized
INFO - 2020-09-09 11:06:49 --> URI Class Initialized
INFO - 2020-09-09 11:06:49 --> Router Class Initialized
INFO - 2020-09-09 11:06:49 --> Output Class Initialized
INFO - 2020-09-09 11:06:49 --> Security Class Initialized
DEBUG - 2020-09-09 11:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:06:49 --> Input Class Initialized
INFO - 2020-09-09 11:06:49 --> Language Class Initialized
INFO - 2020-09-09 11:06:49 --> Loader Class Initialized
INFO - 2020-09-09 11:06:49 --> Helper loaded: url_helper
INFO - 2020-09-09 11:06:49 --> Database Driver Class Initialized
INFO - 2020-09-09 11:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:06:49 --> Email Class Initialized
INFO - 2020-09-09 11:06:49 --> Controller Class Initialized
INFO - 2020-09-09 11:06:49 --> Model Class Initialized
INFO - 2020-09-09 11:06:49 --> Model Class Initialized
INFO - 2020-09-09 11:06:49 --> Final output sent to browser
DEBUG - 2020-09-09 11:06:49 --> Total execution time: 0.0750
ERROR - 2020-09-09 11:06:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:06:50 --> Config Class Initialized
INFO - 2020-09-09 11:06:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:06:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:06:50 --> Utf8 Class Initialized
INFO - 2020-09-09 11:06:50 --> URI Class Initialized
INFO - 2020-09-09 11:06:50 --> Router Class Initialized
INFO - 2020-09-09 11:06:50 --> Output Class Initialized
INFO - 2020-09-09 11:06:50 --> Security Class Initialized
DEBUG - 2020-09-09 11:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:06:50 --> Input Class Initialized
INFO - 2020-09-09 11:06:50 --> Language Class Initialized
INFO - 2020-09-09 11:06:50 --> Loader Class Initialized
INFO - 2020-09-09 11:06:50 --> Helper loaded: url_helper
INFO - 2020-09-09 11:06:50 --> Database Driver Class Initialized
INFO - 2020-09-09 11:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:06:50 --> Email Class Initialized
INFO - 2020-09-09 11:06:50 --> Controller Class Initialized
INFO - 2020-09-09 11:06:50 --> Model Class Initialized
INFO - 2020-09-09 11:06:50 --> Model Class Initialized
INFO - 2020-09-09 11:06:51 --> Final output sent to browser
DEBUG - 2020-09-09 11:06:51 --> Total execution time: 0.0414
ERROR - 2020-09-09 11:08:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:08:11 --> Config Class Initialized
INFO - 2020-09-09 11:08:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:08:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:08:11 --> Utf8 Class Initialized
INFO - 2020-09-09 11:08:11 --> URI Class Initialized
INFO - 2020-09-09 11:08:11 --> Router Class Initialized
INFO - 2020-09-09 11:08:11 --> Output Class Initialized
INFO - 2020-09-09 11:08:11 --> Security Class Initialized
DEBUG - 2020-09-09 11:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:08:11 --> Input Class Initialized
INFO - 2020-09-09 11:08:11 --> Language Class Initialized
INFO - 2020-09-09 11:08:11 --> Loader Class Initialized
INFO - 2020-09-09 11:08:11 --> Helper loaded: url_helper
INFO - 2020-09-09 11:08:11 --> Database Driver Class Initialized
INFO - 2020-09-09 11:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:08:11 --> Email Class Initialized
INFO - 2020-09-09 11:08:11 --> Controller Class Initialized
INFO - 2020-09-09 11:08:11 --> Model Class Initialized
INFO - 2020-09-09 11:08:11 --> Model Class Initialized
INFO - 2020-09-09 11:08:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:08:11 --> Final output sent to browser
DEBUG - 2020-09-09 11:08:11 --> Total execution time: 0.0383
ERROR - 2020-09-09 11:08:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:08:11 --> Config Class Initialized
INFO - 2020-09-09 11:08:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:08:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:08:11 --> Utf8 Class Initialized
INFO - 2020-09-09 11:08:11 --> URI Class Initialized
INFO - 2020-09-09 11:08:11 --> Router Class Initialized
INFO - 2020-09-09 11:08:11 --> Output Class Initialized
INFO - 2020-09-09 11:08:11 --> Security Class Initialized
DEBUG - 2020-09-09 11:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:08:11 --> Input Class Initialized
INFO - 2020-09-09 11:08:11 --> Language Class Initialized
INFO - 2020-09-09 11:08:11 --> Loader Class Initialized
INFO - 2020-09-09 11:08:11 --> Helper loaded: url_helper
INFO - 2020-09-09 11:08:11 --> Database Driver Class Initialized
INFO - 2020-09-09 11:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:08:11 --> Email Class Initialized
INFO - 2020-09-09 11:08:11 --> Controller Class Initialized
INFO - 2020-09-09 11:08:11 --> Model Class Initialized
INFO - 2020-09-09 11:08:11 --> Model Class Initialized
INFO - 2020-09-09 11:08:11 --> Final output sent to browser
DEBUG - 2020-09-09 11:08:11 --> Total execution time: 0.0397
ERROR - 2020-09-09 11:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:10:21 --> Config Class Initialized
INFO - 2020-09-09 11:10:21 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:10:21 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:10:21 --> Utf8 Class Initialized
INFO - 2020-09-09 11:10:21 --> URI Class Initialized
INFO - 2020-09-09 11:10:21 --> Router Class Initialized
INFO - 2020-09-09 11:10:21 --> Output Class Initialized
INFO - 2020-09-09 11:10:21 --> Security Class Initialized
DEBUG - 2020-09-09 11:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:10:21 --> Input Class Initialized
INFO - 2020-09-09 11:10:21 --> Language Class Initialized
INFO - 2020-09-09 11:10:21 --> Loader Class Initialized
INFO - 2020-09-09 11:10:21 --> Helper loaded: url_helper
INFO - 2020-09-09 11:10:21 --> Database Driver Class Initialized
INFO - 2020-09-09 11:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:10:21 --> Email Class Initialized
INFO - 2020-09-09 11:10:21 --> Controller Class Initialized
INFO - 2020-09-09 11:10:21 --> Model Class Initialized
INFO - 2020-09-09 11:10:21 --> Model Class Initialized
INFO - 2020-09-09 11:10:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:10:21 --> Final output sent to browser
DEBUG - 2020-09-09 11:10:21 --> Total execution time: 0.0418
ERROR - 2020-09-09 11:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:10:22 --> Config Class Initialized
INFO - 2020-09-09 11:10:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:10:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:10:22 --> Utf8 Class Initialized
INFO - 2020-09-09 11:10:22 --> URI Class Initialized
INFO - 2020-09-09 11:10:22 --> Router Class Initialized
INFO - 2020-09-09 11:10:22 --> Output Class Initialized
INFO - 2020-09-09 11:10:22 --> Security Class Initialized
DEBUG - 2020-09-09 11:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:10:22 --> Input Class Initialized
INFO - 2020-09-09 11:10:22 --> Language Class Initialized
INFO - 2020-09-09 11:10:22 --> Loader Class Initialized
INFO - 2020-09-09 11:10:22 --> Helper loaded: url_helper
INFO - 2020-09-09 11:10:22 --> Database Driver Class Initialized
INFO - 2020-09-09 11:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:10:22 --> Email Class Initialized
INFO - 2020-09-09 11:10:22 --> Controller Class Initialized
INFO - 2020-09-09 11:10:22 --> Model Class Initialized
INFO - 2020-09-09 11:10:22 --> Model Class Initialized
INFO - 2020-09-09 11:10:22 --> Final output sent to browser
DEBUG - 2020-09-09 11:10:22 --> Total execution time: 0.0386
ERROR - 2020-09-09 11:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:11:29 --> Config Class Initialized
INFO - 2020-09-09 11:11:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:11:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:11:29 --> Utf8 Class Initialized
INFO - 2020-09-09 11:11:29 --> URI Class Initialized
INFO - 2020-09-09 11:11:29 --> Router Class Initialized
INFO - 2020-09-09 11:11:29 --> Output Class Initialized
INFO - 2020-09-09 11:11:29 --> Security Class Initialized
DEBUG - 2020-09-09 11:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:11:29 --> Input Class Initialized
INFO - 2020-09-09 11:11:29 --> Language Class Initialized
INFO - 2020-09-09 11:11:29 --> Loader Class Initialized
INFO - 2020-09-09 11:11:29 --> Helper loaded: url_helper
INFO - 2020-09-09 11:11:29 --> Database Driver Class Initialized
INFO - 2020-09-09 11:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:11:29 --> Email Class Initialized
INFO - 2020-09-09 11:11:29 --> Controller Class Initialized
INFO - 2020-09-09 11:11:29 --> Model Class Initialized
INFO - 2020-09-09 11:11:29 --> Model Class Initialized
INFO - 2020-09-09 11:11:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:11:29 --> Final output sent to browser
DEBUG - 2020-09-09 11:11:29 --> Total execution time: 0.0376
ERROR - 2020-09-09 11:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:11:29 --> Config Class Initialized
INFO - 2020-09-09 11:11:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:11:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:11:29 --> Utf8 Class Initialized
INFO - 2020-09-09 11:11:29 --> URI Class Initialized
INFO - 2020-09-09 11:11:29 --> Router Class Initialized
INFO - 2020-09-09 11:11:29 --> Output Class Initialized
INFO - 2020-09-09 11:11:29 --> Security Class Initialized
DEBUG - 2020-09-09 11:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:11:29 --> Input Class Initialized
INFO - 2020-09-09 11:11:29 --> Language Class Initialized
INFO - 2020-09-09 11:11:29 --> Loader Class Initialized
INFO - 2020-09-09 11:11:29 --> Helper loaded: url_helper
INFO - 2020-09-09 11:11:29 --> Database Driver Class Initialized
INFO - 2020-09-09 11:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:11:29 --> Email Class Initialized
INFO - 2020-09-09 11:11:29 --> Controller Class Initialized
INFO - 2020-09-09 11:11:29 --> Model Class Initialized
INFO - 2020-09-09 11:11:29 --> Model Class Initialized
INFO - 2020-09-09 11:11:29 --> Final output sent to browser
DEBUG - 2020-09-09 11:11:29 --> Total execution time: 0.0431
ERROR - 2020-09-09 11:15:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:15:17 --> Config Class Initialized
INFO - 2020-09-09 11:15:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:15:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:15:17 --> Utf8 Class Initialized
INFO - 2020-09-09 11:15:17 --> URI Class Initialized
INFO - 2020-09-09 11:15:17 --> Router Class Initialized
INFO - 2020-09-09 11:15:17 --> Output Class Initialized
INFO - 2020-09-09 11:15:17 --> Security Class Initialized
DEBUG - 2020-09-09 11:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:15:17 --> Input Class Initialized
INFO - 2020-09-09 11:15:17 --> Language Class Initialized
INFO - 2020-09-09 11:15:17 --> Loader Class Initialized
INFO - 2020-09-09 11:15:17 --> Helper loaded: url_helper
INFO - 2020-09-09 11:15:17 --> Database Driver Class Initialized
INFO - 2020-09-09 11:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:15:17 --> Email Class Initialized
INFO - 2020-09-09 11:15:17 --> Controller Class Initialized
INFO - 2020-09-09 11:15:17 --> Model Class Initialized
INFO - 2020-09-09 11:15:17 --> Model Class Initialized
INFO - 2020-09-09 11:15:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:15:17 --> Final output sent to browser
DEBUG - 2020-09-09 11:15:17 --> Total execution time: 0.0437
ERROR - 2020-09-09 11:15:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:15:18 --> Config Class Initialized
INFO - 2020-09-09 11:15:18 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:15:18 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:15:18 --> Utf8 Class Initialized
INFO - 2020-09-09 11:15:18 --> URI Class Initialized
INFO - 2020-09-09 11:15:18 --> Router Class Initialized
INFO - 2020-09-09 11:15:18 --> Output Class Initialized
INFO - 2020-09-09 11:15:18 --> Security Class Initialized
DEBUG - 2020-09-09 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:15:18 --> Input Class Initialized
INFO - 2020-09-09 11:15:18 --> Language Class Initialized
INFO - 2020-09-09 11:15:18 --> Loader Class Initialized
INFO - 2020-09-09 11:15:18 --> Helper loaded: url_helper
INFO - 2020-09-09 11:15:18 --> Database Driver Class Initialized
INFO - 2020-09-09 11:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:15:18 --> Email Class Initialized
INFO - 2020-09-09 11:15:18 --> Controller Class Initialized
INFO - 2020-09-09 11:15:18 --> Model Class Initialized
INFO - 2020-09-09 11:15:18 --> Model Class Initialized
INFO - 2020-09-09 11:15:18 --> Final output sent to browser
DEBUG - 2020-09-09 11:15:18 --> Total execution time: 0.0405
ERROR - 2020-09-09 11:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:16:50 --> Config Class Initialized
INFO - 2020-09-09 11:16:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:16:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:16:50 --> Utf8 Class Initialized
INFO - 2020-09-09 11:16:50 --> URI Class Initialized
INFO - 2020-09-09 11:16:50 --> Router Class Initialized
INFO - 2020-09-09 11:16:50 --> Output Class Initialized
INFO - 2020-09-09 11:16:50 --> Security Class Initialized
DEBUG - 2020-09-09 11:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:16:50 --> Input Class Initialized
INFO - 2020-09-09 11:16:50 --> Language Class Initialized
INFO - 2020-09-09 11:16:50 --> Loader Class Initialized
INFO - 2020-09-09 11:16:50 --> Helper loaded: url_helper
INFO - 2020-09-09 11:16:50 --> Database Driver Class Initialized
INFO - 2020-09-09 11:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:16:50 --> Email Class Initialized
INFO - 2020-09-09 11:16:50 --> Controller Class Initialized
INFO - 2020-09-09 11:16:50 --> Model Class Initialized
INFO - 2020-09-09 11:16:50 --> Model Class Initialized
INFO - 2020-09-09 11:16:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:16:50 --> Final output sent to browser
DEBUG - 2020-09-09 11:16:50 --> Total execution time: 0.0340
ERROR - 2020-09-09 11:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:16:50 --> Config Class Initialized
INFO - 2020-09-09 11:16:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:16:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:16:50 --> Utf8 Class Initialized
INFO - 2020-09-09 11:16:50 --> URI Class Initialized
INFO - 2020-09-09 11:16:50 --> Router Class Initialized
INFO - 2020-09-09 11:16:50 --> Output Class Initialized
INFO - 2020-09-09 11:16:50 --> Security Class Initialized
DEBUG - 2020-09-09 11:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:16:50 --> Input Class Initialized
INFO - 2020-09-09 11:16:50 --> Language Class Initialized
INFO - 2020-09-09 11:16:50 --> Loader Class Initialized
INFO - 2020-09-09 11:16:50 --> Helper loaded: url_helper
INFO - 2020-09-09 11:16:50 --> Database Driver Class Initialized
INFO - 2020-09-09 11:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:16:50 --> Email Class Initialized
INFO - 2020-09-09 11:16:50 --> Controller Class Initialized
INFO - 2020-09-09 11:16:50 --> Model Class Initialized
INFO - 2020-09-09 11:16:50 --> Model Class Initialized
INFO - 2020-09-09 11:16:50 --> Final output sent to browser
DEBUG - 2020-09-09 11:16:50 --> Total execution time: 0.0367
ERROR - 2020-09-09 11:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:17:47 --> Config Class Initialized
INFO - 2020-09-09 11:17:47 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:17:47 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:17:47 --> Utf8 Class Initialized
INFO - 2020-09-09 11:17:47 --> URI Class Initialized
INFO - 2020-09-09 11:17:47 --> Router Class Initialized
INFO - 2020-09-09 11:17:47 --> Output Class Initialized
INFO - 2020-09-09 11:17:47 --> Security Class Initialized
DEBUG - 2020-09-09 11:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:17:47 --> Input Class Initialized
INFO - 2020-09-09 11:17:47 --> Language Class Initialized
INFO - 2020-09-09 11:17:47 --> Loader Class Initialized
INFO - 2020-09-09 11:17:47 --> Helper loaded: url_helper
INFO - 2020-09-09 11:17:47 --> Database Driver Class Initialized
INFO - 2020-09-09 11:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:17:47 --> Email Class Initialized
INFO - 2020-09-09 11:17:47 --> Controller Class Initialized
INFO - 2020-09-09 11:17:47 --> Model Class Initialized
INFO - 2020-09-09 11:17:47 --> Model Class Initialized
INFO - 2020-09-09 11:17:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:17:47 --> Final output sent to browser
DEBUG - 2020-09-09 11:17:47 --> Total execution time: 0.0421
ERROR - 2020-09-09 11:17:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:17:47 --> Config Class Initialized
INFO - 2020-09-09 11:17:47 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:17:47 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:17:47 --> Utf8 Class Initialized
INFO - 2020-09-09 11:17:47 --> URI Class Initialized
INFO - 2020-09-09 11:17:47 --> Router Class Initialized
INFO - 2020-09-09 11:17:47 --> Output Class Initialized
INFO - 2020-09-09 11:17:47 --> Security Class Initialized
DEBUG - 2020-09-09 11:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:17:47 --> Input Class Initialized
INFO - 2020-09-09 11:17:47 --> Language Class Initialized
INFO - 2020-09-09 11:17:47 --> Loader Class Initialized
INFO - 2020-09-09 11:17:47 --> Helper loaded: url_helper
INFO - 2020-09-09 11:17:47 --> Database Driver Class Initialized
INFO - 2020-09-09 11:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:17:47 --> Email Class Initialized
INFO - 2020-09-09 11:17:47 --> Controller Class Initialized
INFO - 2020-09-09 11:17:47 --> Model Class Initialized
INFO - 2020-09-09 11:17:47 --> Model Class Initialized
INFO - 2020-09-09 11:17:47 --> Final output sent to browser
DEBUG - 2020-09-09 11:17:47 --> Total execution time: 0.0382
ERROR - 2020-09-09 11:18:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:18:35 --> Config Class Initialized
INFO - 2020-09-09 11:18:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:18:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:18:35 --> Utf8 Class Initialized
INFO - 2020-09-09 11:18:35 --> URI Class Initialized
INFO - 2020-09-09 11:18:35 --> Router Class Initialized
INFO - 2020-09-09 11:18:35 --> Output Class Initialized
INFO - 2020-09-09 11:18:35 --> Security Class Initialized
DEBUG - 2020-09-09 11:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:18:35 --> Input Class Initialized
INFO - 2020-09-09 11:18:35 --> Language Class Initialized
INFO - 2020-09-09 11:18:35 --> Loader Class Initialized
INFO - 2020-09-09 11:18:35 --> Helper loaded: url_helper
INFO - 2020-09-09 11:18:35 --> Database Driver Class Initialized
INFO - 2020-09-09 11:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:18:35 --> Email Class Initialized
INFO - 2020-09-09 11:18:35 --> Controller Class Initialized
INFO - 2020-09-09 11:18:35 --> Model Class Initialized
INFO - 2020-09-09 11:18:35 --> Model Class Initialized
INFO - 2020-09-09 11:18:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:18:35 --> Final output sent to browser
DEBUG - 2020-09-09 11:18:35 --> Total execution time: 0.0354
ERROR - 2020-09-09 11:18:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:18:36 --> Config Class Initialized
INFO - 2020-09-09 11:18:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:18:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:18:36 --> Utf8 Class Initialized
INFO - 2020-09-09 11:18:36 --> URI Class Initialized
INFO - 2020-09-09 11:18:36 --> Router Class Initialized
INFO - 2020-09-09 11:18:36 --> Output Class Initialized
INFO - 2020-09-09 11:18:36 --> Security Class Initialized
DEBUG - 2020-09-09 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:18:36 --> Input Class Initialized
INFO - 2020-09-09 11:18:36 --> Language Class Initialized
INFO - 2020-09-09 11:18:36 --> Loader Class Initialized
INFO - 2020-09-09 11:18:36 --> Helper loaded: url_helper
INFO - 2020-09-09 11:18:36 --> Database Driver Class Initialized
INFO - 2020-09-09 11:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:18:36 --> Email Class Initialized
INFO - 2020-09-09 11:18:36 --> Controller Class Initialized
INFO - 2020-09-09 11:18:36 --> Model Class Initialized
INFO - 2020-09-09 11:18:36 --> Model Class Initialized
INFO - 2020-09-09 11:18:36 --> Final output sent to browser
DEBUG - 2020-09-09 11:18:36 --> Total execution time: 0.0478
ERROR - 2020-09-09 11:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:18:54 --> Config Class Initialized
INFO - 2020-09-09 11:18:54 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:18:54 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:18:54 --> Utf8 Class Initialized
INFO - 2020-09-09 11:18:54 --> URI Class Initialized
INFO - 2020-09-09 11:18:54 --> Router Class Initialized
INFO - 2020-09-09 11:18:54 --> Output Class Initialized
INFO - 2020-09-09 11:18:54 --> Security Class Initialized
DEBUG - 2020-09-09 11:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:18:54 --> Input Class Initialized
INFO - 2020-09-09 11:18:54 --> Language Class Initialized
INFO - 2020-09-09 11:18:54 --> Loader Class Initialized
INFO - 2020-09-09 11:18:54 --> Helper loaded: url_helper
INFO - 2020-09-09 11:18:54 --> Database Driver Class Initialized
INFO - 2020-09-09 11:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:18:54 --> Email Class Initialized
INFO - 2020-09-09 11:18:54 --> Controller Class Initialized
INFO - 2020-09-09 11:18:54 --> Model Class Initialized
INFO - 2020-09-09 11:18:54 --> Model Class Initialized
INFO - 2020-09-09 11:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:18:54 --> Final output sent to browser
DEBUG - 2020-09-09 11:18:54 --> Total execution time: 0.0409
ERROR - 2020-09-09 11:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:18:55 --> Config Class Initialized
INFO - 2020-09-09 11:18:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:18:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:18:55 --> Utf8 Class Initialized
INFO - 2020-09-09 11:18:55 --> URI Class Initialized
INFO - 2020-09-09 11:18:55 --> Router Class Initialized
INFO - 2020-09-09 11:18:55 --> Output Class Initialized
INFO - 2020-09-09 11:18:55 --> Security Class Initialized
DEBUG - 2020-09-09 11:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:18:55 --> Input Class Initialized
INFO - 2020-09-09 11:18:55 --> Language Class Initialized
INFO - 2020-09-09 11:18:55 --> Loader Class Initialized
INFO - 2020-09-09 11:18:55 --> Helper loaded: url_helper
INFO - 2020-09-09 11:18:55 --> Database Driver Class Initialized
INFO - 2020-09-09 11:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:18:55 --> Email Class Initialized
INFO - 2020-09-09 11:18:55 --> Controller Class Initialized
INFO - 2020-09-09 11:18:55 --> Model Class Initialized
INFO - 2020-09-09 11:18:55 --> Model Class Initialized
INFO - 2020-09-09 11:18:55 --> Final output sent to browser
DEBUG - 2020-09-09 11:18:55 --> Total execution time: 0.0383
ERROR - 2020-09-09 11:24:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:24:01 --> Config Class Initialized
INFO - 2020-09-09 11:24:01 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:24:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:24:01 --> Utf8 Class Initialized
INFO - 2020-09-09 11:24:01 --> URI Class Initialized
INFO - 2020-09-09 11:24:01 --> Router Class Initialized
INFO - 2020-09-09 11:24:01 --> Output Class Initialized
INFO - 2020-09-09 11:24:01 --> Security Class Initialized
DEBUG - 2020-09-09 11:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:24:01 --> Input Class Initialized
INFO - 2020-09-09 11:24:01 --> Language Class Initialized
INFO - 2020-09-09 11:24:01 --> Loader Class Initialized
INFO - 2020-09-09 11:24:01 --> Helper loaded: url_helper
INFO - 2020-09-09 11:24:01 --> Database Driver Class Initialized
INFO - 2020-09-09 11:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:24:01 --> Email Class Initialized
INFO - 2020-09-09 11:24:01 --> Controller Class Initialized
INFO - 2020-09-09 11:24:01 --> Model Class Initialized
INFO - 2020-09-09 11:24:01 --> Model Class Initialized
INFO - 2020-09-09 11:24:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:24:01 --> Final output sent to browser
DEBUG - 2020-09-09 11:24:01 --> Total execution time: 0.0468
ERROR - 2020-09-09 11:24:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:24:02 --> Config Class Initialized
INFO - 2020-09-09 11:24:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:24:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:24:02 --> Utf8 Class Initialized
INFO - 2020-09-09 11:24:02 --> URI Class Initialized
INFO - 2020-09-09 11:24:02 --> Router Class Initialized
INFO - 2020-09-09 11:24:02 --> Output Class Initialized
INFO - 2020-09-09 11:24:02 --> Security Class Initialized
DEBUG - 2020-09-09 11:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:24:02 --> Input Class Initialized
INFO - 2020-09-09 11:24:02 --> Language Class Initialized
INFO - 2020-09-09 11:24:02 --> Loader Class Initialized
INFO - 2020-09-09 11:24:02 --> Helper loaded: url_helper
INFO - 2020-09-09 11:24:02 --> Database Driver Class Initialized
INFO - 2020-09-09 11:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:24:02 --> Email Class Initialized
INFO - 2020-09-09 11:24:02 --> Controller Class Initialized
INFO - 2020-09-09 11:24:02 --> Model Class Initialized
INFO - 2020-09-09 11:24:02 --> Model Class Initialized
INFO - 2020-09-09 11:24:02 --> Final output sent to browser
DEBUG - 2020-09-09 11:24:02 --> Total execution time: 0.0460
ERROR - 2020-09-09 11:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:24:22 --> Config Class Initialized
INFO - 2020-09-09 11:24:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:24:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:24:22 --> Utf8 Class Initialized
INFO - 2020-09-09 11:24:22 --> URI Class Initialized
INFO - 2020-09-09 11:24:22 --> Router Class Initialized
INFO - 2020-09-09 11:24:22 --> Output Class Initialized
INFO - 2020-09-09 11:24:22 --> Security Class Initialized
DEBUG - 2020-09-09 11:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:24:23 --> Input Class Initialized
INFO - 2020-09-09 11:24:23 --> Language Class Initialized
INFO - 2020-09-09 11:24:23 --> Loader Class Initialized
INFO - 2020-09-09 11:24:23 --> Helper loaded: url_helper
INFO - 2020-09-09 11:24:23 --> Database Driver Class Initialized
INFO - 2020-09-09 11:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:24:23 --> Email Class Initialized
INFO - 2020-09-09 11:24:23 --> Controller Class Initialized
INFO - 2020-09-09 11:24:23 --> Model Class Initialized
INFO - 2020-09-09 11:24:23 --> Model Class Initialized
INFO - 2020-09-09 11:24:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:24:23 --> Final output sent to browser
DEBUG - 2020-09-09 11:24:23 --> Total execution time: 0.0413
ERROR - 2020-09-09 11:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:24:23 --> Config Class Initialized
INFO - 2020-09-09 11:24:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:24:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:24:23 --> Utf8 Class Initialized
INFO - 2020-09-09 11:24:23 --> URI Class Initialized
INFO - 2020-09-09 11:24:23 --> Router Class Initialized
INFO - 2020-09-09 11:24:23 --> Output Class Initialized
INFO - 2020-09-09 11:24:23 --> Security Class Initialized
DEBUG - 2020-09-09 11:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:24:23 --> Input Class Initialized
INFO - 2020-09-09 11:24:23 --> Language Class Initialized
INFO - 2020-09-09 11:24:23 --> Loader Class Initialized
INFO - 2020-09-09 11:24:23 --> Helper loaded: url_helper
INFO - 2020-09-09 11:24:23 --> Database Driver Class Initialized
INFO - 2020-09-09 11:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:24:23 --> Email Class Initialized
INFO - 2020-09-09 11:24:23 --> Controller Class Initialized
INFO - 2020-09-09 11:24:23 --> Model Class Initialized
INFO - 2020-09-09 11:24:23 --> Model Class Initialized
INFO - 2020-09-09 11:24:23 --> Final output sent to browser
DEBUG - 2020-09-09 11:24:23 --> Total execution time: 0.0438
ERROR - 2020-09-09 11:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:24:40 --> Config Class Initialized
INFO - 2020-09-09 11:24:40 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:24:40 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:24:40 --> Utf8 Class Initialized
INFO - 2020-09-09 11:24:40 --> URI Class Initialized
INFO - 2020-09-09 11:24:40 --> Router Class Initialized
INFO - 2020-09-09 11:24:40 --> Output Class Initialized
INFO - 2020-09-09 11:24:40 --> Security Class Initialized
DEBUG - 2020-09-09 11:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:24:40 --> Input Class Initialized
INFO - 2020-09-09 11:24:40 --> Language Class Initialized
INFO - 2020-09-09 11:24:40 --> Loader Class Initialized
INFO - 2020-09-09 11:24:40 --> Helper loaded: url_helper
INFO - 2020-09-09 11:24:40 --> Database Driver Class Initialized
INFO - 2020-09-09 11:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:24:40 --> Email Class Initialized
INFO - 2020-09-09 11:24:40 --> Controller Class Initialized
INFO - 2020-09-09 11:24:40 --> Model Class Initialized
INFO - 2020-09-09 11:24:40 --> Model Class Initialized
INFO - 2020-09-09 11:24:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:24:40 --> Final output sent to browser
DEBUG - 2020-09-09 11:24:40 --> Total execution time: 0.0351
ERROR - 2020-09-09 11:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:24:40 --> Config Class Initialized
INFO - 2020-09-09 11:24:40 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:24:40 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:24:40 --> Utf8 Class Initialized
INFO - 2020-09-09 11:24:40 --> URI Class Initialized
INFO - 2020-09-09 11:24:40 --> Router Class Initialized
INFO - 2020-09-09 11:24:40 --> Output Class Initialized
INFO - 2020-09-09 11:24:40 --> Security Class Initialized
DEBUG - 2020-09-09 11:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:24:40 --> Input Class Initialized
INFO - 2020-09-09 11:24:40 --> Language Class Initialized
INFO - 2020-09-09 11:24:40 --> Loader Class Initialized
INFO - 2020-09-09 11:24:40 --> Helper loaded: url_helper
INFO - 2020-09-09 11:24:40 --> Database Driver Class Initialized
INFO - 2020-09-09 11:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:24:40 --> Email Class Initialized
INFO - 2020-09-09 11:24:40 --> Controller Class Initialized
INFO - 2020-09-09 11:24:40 --> Model Class Initialized
INFO - 2020-09-09 11:24:40 --> Model Class Initialized
INFO - 2020-09-09 11:24:40 --> Final output sent to browser
DEBUG - 2020-09-09 11:24:40 --> Total execution time: 0.0422
ERROR - 2020-09-09 11:26:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:26:19 --> Config Class Initialized
INFO - 2020-09-09 11:26:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:26:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:26:19 --> Utf8 Class Initialized
INFO - 2020-09-09 11:26:19 --> URI Class Initialized
INFO - 2020-09-09 11:26:19 --> Router Class Initialized
INFO - 2020-09-09 11:26:19 --> Output Class Initialized
INFO - 2020-09-09 11:26:19 --> Security Class Initialized
DEBUG - 2020-09-09 11:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:26:19 --> Input Class Initialized
INFO - 2020-09-09 11:26:19 --> Language Class Initialized
INFO - 2020-09-09 11:26:19 --> Loader Class Initialized
INFO - 2020-09-09 11:26:19 --> Helper loaded: url_helper
INFO - 2020-09-09 11:26:19 --> Database Driver Class Initialized
INFO - 2020-09-09 11:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:26:19 --> Email Class Initialized
INFO - 2020-09-09 11:26:19 --> Controller Class Initialized
INFO - 2020-09-09 11:26:19 --> Model Class Initialized
INFO - 2020-09-09 11:26:19 --> Model Class Initialized
INFO - 2020-09-09 11:26:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:26:19 --> Final output sent to browser
DEBUG - 2020-09-09 11:26:19 --> Total execution time: 0.0424
ERROR - 2020-09-09 11:26:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:26:20 --> Config Class Initialized
INFO - 2020-09-09 11:26:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:26:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:26:20 --> Utf8 Class Initialized
INFO - 2020-09-09 11:26:20 --> URI Class Initialized
INFO - 2020-09-09 11:26:20 --> Router Class Initialized
INFO - 2020-09-09 11:26:20 --> Output Class Initialized
INFO - 2020-09-09 11:26:20 --> Security Class Initialized
DEBUG - 2020-09-09 11:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:26:20 --> Input Class Initialized
INFO - 2020-09-09 11:26:20 --> Language Class Initialized
INFO - 2020-09-09 11:26:20 --> Loader Class Initialized
INFO - 2020-09-09 11:26:20 --> Helper loaded: url_helper
INFO - 2020-09-09 11:26:20 --> Database Driver Class Initialized
INFO - 2020-09-09 11:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:26:20 --> Email Class Initialized
INFO - 2020-09-09 11:26:20 --> Controller Class Initialized
INFO - 2020-09-09 11:26:20 --> Model Class Initialized
INFO - 2020-09-09 11:26:20 --> Model Class Initialized
INFO - 2020-09-09 11:26:20 --> Final output sent to browser
DEBUG - 2020-09-09 11:26:20 --> Total execution time: 0.0382
ERROR - 2020-09-09 11:26:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:26:54 --> Config Class Initialized
INFO - 2020-09-09 11:26:54 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:26:54 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:26:54 --> Utf8 Class Initialized
INFO - 2020-09-09 11:26:54 --> URI Class Initialized
INFO - 2020-09-09 11:26:54 --> Router Class Initialized
INFO - 2020-09-09 11:26:54 --> Output Class Initialized
INFO - 2020-09-09 11:26:54 --> Security Class Initialized
DEBUG - 2020-09-09 11:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:26:54 --> Input Class Initialized
INFO - 2020-09-09 11:26:54 --> Language Class Initialized
INFO - 2020-09-09 11:26:54 --> Loader Class Initialized
INFO - 2020-09-09 11:26:54 --> Helper loaded: url_helper
INFO - 2020-09-09 11:26:54 --> Database Driver Class Initialized
INFO - 2020-09-09 11:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:26:54 --> Email Class Initialized
INFO - 2020-09-09 11:26:54 --> Controller Class Initialized
DEBUG - 2020-09-09 11:26:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 11:26:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 11:26:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 11:26:54 --> Final output sent to browser
DEBUG - 2020-09-09 11:26:54 --> Total execution time: 0.0201
ERROR - 2020-09-09 11:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:27:08 --> Config Class Initialized
INFO - 2020-09-09 11:27:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:27:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:27:08 --> Utf8 Class Initialized
INFO - 2020-09-09 11:27:08 --> URI Class Initialized
INFO - 2020-09-09 11:27:08 --> Router Class Initialized
INFO - 2020-09-09 11:27:08 --> Output Class Initialized
INFO - 2020-09-09 11:27:08 --> Security Class Initialized
DEBUG - 2020-09-09 11:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:27:08 --> Input Class Initialized
INFO - 2020-09-09 11:27:08 --> Language Class Initialized
INFO - 2020-09-09 11:27:08 --> Loader Class Initialized
INFO - 2020-09-09 11:27:08 --> Helper loaded: url_helper
INFO - 2020-09-09 11:27:08 --> Database Driver Class Initialized
INFO - 2020-09-09 11:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:27:08 --> Email Class Initialized
INFO - 2020-09-09 11:27:08 --> Controller Class Initialized
INFO - 2020-09-09 11:27:08 --> Model Class Initialized
INFO - 2020-09-09 11:27:08 --> Model Class Initialized
INFO - 2020-09-09 11:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:27:08 --> Final output sent to browser
DEBUG - 2020-09-09 11:27:08 --> Total execution time: 0.0394
ERROR - 2020-09-09 11:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:27:08 --> Config Class Initialized
INFO - 2020-09-09 11:27:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:27:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:27:08 --> Utf8 Class Initialized
INFO - 2020-09-09 11:27:08 --> URI Class Initialized
INFO - 2020-09-09 11:27:08 --> Router Class Initialized
INFO - 2020-09-09 11:27:08 --> Output Class Initialized
INFO - 2020-09-09 11:27:08 --> Security Class Initialized
DEBUG - 2020-09-09 11:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:27:08 --> Input Class Initialized
INFO - 2020-09-09 11:27:08 --> Language Class Initialized
INFO - 2020-09-09 11:27:08 --> Loader Class Initialized
INFO - 2020-09-09 11:27:08 --> Helper loaded: url_helper
INFO - 2020-09-09 11:27:08 --> Database Driver Class Initialized
INFO - 2020-09-09 11:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:27:08 --> Email Class Initialized
INFO - 2020-09-09 11:27:08 --> Controller Class Initialized
INFO - 2020-09-09 11:27:08 --> Model Class Initialized
INFO - 2020-09-09 11:27:08 --> Model Class Initialized
INFO - 2020-09-09 11:27:08 --> Final output sent to browser
DEBUG - 2020-09-09 11:27:08 --> Total execution time: 0.0410
ERROR - 2020-09-09 11:27:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:27:11 --> Config Class Initialized
INFO - 2020-09-09 11:27:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:27:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:27:11 --> Utf8 Class Initialized
INFO - 2020-09-09 11:27:11 --> URI Class Initialized
INFO - 2020-09-09 11:27:11 --> Router Class Initialized
INFO - 2020-09-09 11:27:11 --> Output Class Initialized
INFO - 2020-09-09 11:27:11 --> Security Class Initialized
DEBUG - 2020-09-09 11:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:27:11 --> Input Class Initialized
INFO - 2020-09-09 11:27:11 --> Language Class Initialized
INFO - 2020-09-09 11:27:11 --> Loader Class Initialized
INFO - 2020-09-09 11:27:11 --> Helper loaded: url_helper
INFO - 2020-09-09 11:27:11 --> Database Driver Class Initialized
INFO - 2020-09-09 11:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:27:11 --> Email Class Initialized
INFO - 2020-09-09 11:27:11 --> Controller Class Initialized
DEBUG - 2020-09-09 11:27:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 11:27:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 11:27:11 --> Model Class Initialized
INFO - 2020-09-09 11:27:11 --> Model Class Initialized
INFO - 2020-09-09 11:27:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-09 11:27:11 --> Final output sent to browser
DEBUG - 2020-09-09 11:27:11 --> Total execution time: 0.0198
ERROR - 2020-09-09 11:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:30:06 --> Config Class Initialized
INFO - 2020-09-09 11:30:06 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:30:06 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:30:06 --> Utf8 Class Initialized
INFO - 2020-09-09 11:30:06 --> URI Class Initialized
INFO - 2020-09-09 11:30:06 --> Router Class Initialized
INFO - 2020-09-09 11:30:06 --> Output Class Initialized
INFO - 2020-09-09 11:30:06 --> Security Class Initialized
DEBUG - 2020-09-09 11:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:30:06 --> Input Class Initialized
INFO - 2020-09-09 11:30:06 --> Language Class Initialized
INFO - 2020-09-09 11:30:06 --> Loader Class Initialized
INFO - 2020-09-09 11:30:06 --> Helper loaded: url_helper
INFO - 2020-09-09 11:30:06 --> Database Driver Class Initialized
INFO - 2020-09-09 11:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:30:06 --> Email Class Initialized
INFO - 2020-09-09 11:30:06 --> Controller Class Initialized
DEBUG - 2020-09-09 11:30:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 11:30:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 11:30:06 --> Model Class Initialized
INFO - 2020-09-09 11:30:06 --> Model Class Initialized
INFO - 2020-09-09 11:30:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-09 11:30:06 --> Final output sent to browser
DEBUG - 2020-09-09 11:30:06 --> Total execution time: 0.0206
ERROR - 2020-09-09 11:30:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:30:32 --> Config Class Initialized
INFO - 2020-09-09 11:30:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:30:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:30:32 --> Utf8 Class Initialized
INFO - 2020-09-09 11:30:32 --> URI Class Initialized
INFO - 2020-09-09 11:30:32 --> Router Class Initialized
INFO - 2020-09-09 11:30:32 --> Output Class Initialized
INFO - 2020-09-09 11:30:32 --> Security Class Initialized
DEBUG - 2020-09-09 11:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:30:32 --> Input Class Initialized
INFO - 2020-09-09 11:30:32 --> Language Class Initialized
INFO - 2020-09-09 11:30:32 --> Loader Class Initialized
INFO - 2020-09-09 11:30:32 --> Helper loaded: url_helper
INFO - 2020-09-09 11:30:32 --> Database Driver Class Initialized
INFO - 2020-09-09 11:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:30:32 --> Email Class Initialized
INFO - 2020-09-09 11:30:32 --> Controller Class Initialized
DEBUG - 2020-09-09 11:30:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 11:30:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 11:30:32 --> Model Class Initialized
INFO - 2020-09-09 11:30:32 --> Model Class Initialized
INFO - 2020-09-09 11:30:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-09 11:30:32 --> Final output sent to browser
DEBUG - 2020-09-09 11:30:32 --> Total execution time: 0.0247
ERROR - 2020-09-09 11:30:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:30:45 --> Config Class Initialized
INFO - 2020-09-09 11:30:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:30:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:30:45 --> Utf8 Class Initialized
INFO - 2020-09-09 11:30:45 --> URI Class Initialized
INFO - 2020-09-09 11:30:45 --> Router Class Initialized
INFO - 2020-09-09 11:30:45 --> Output Class Initialized
INFO - 2020-09-09 11:30:45 --> Security Class Initialized
DEBUG - 2020-09-09 11:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:30:45 --> Input Class Initialized
INFO - 2020-09-09 11:30:45 --> Language Class Initialized
INFO - 2020-09-09 11:30:45 --> Loader Class Initialized
INFO - 2020-09-09 11:30:45 --> Helper loaded: url_helper
INFO - 2020-09-09 11:30:45 --> Database Driver Class Initialized
INFO - 2020-09-09 11:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:30:45 --> Email Class Initialized
INFO - 2020-09-09 11:30:45 --> Controller Class Initialized
INFO - 2020-09-09 11:30:45 --> Model Class Initialized
INFO - 2020-09-09 11:30:45 --> Model Class Initialized
INFO - 2020-09-09 11:30:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 11:30:45 --> Final output sent to browser
DEBUG - 2020-09-09 11:30:45 --> Total execution time: 0.0425
ERROR - 2020-09-09 11:30:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 11:30:46 --> Config Class Initialized
INFO - 2020-09-09 11:30:46 --> Hooks Class Initialized
DEBUG - 2020-09-09 11:30:46 --> UTF-8 Support Enabled
INFO - 2020-09-09 11:30:46 --> Utf8 Class Initialized
INFO - 2020-09-09 11:30:46 --> URI Class Initialized
INFO - 2020-09-09 11:30:46 --> Router Class Initialized
INFO - 2020-09-09 11:30:46 --> Output Class Initialized
INFO - 2020-09-09 11:30:46 --> Security Class Initialized
DEBUG - 2020-09-09 11:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 11:30:46 --> Input Class Initialized
INFO - 2020-09-09 11:30:46 --> Language Class Initialized
INFO - 2020-09-09 11:30:46 --> Loader Class Initialized
INFO - 2020-09-09 11:30:46 --> Helper loaded: url_helper
INFO - 2020-09-09 11:30:46 --> Database Driver Class Initialized
INFO - 2020-09-09 11:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 11:30:46 --> Email Class Initialized
INFO - 2020-09-09 11:30:46 --> Controller Class Initialized
INFO - 2020-09-09 11:30:46 --> Model Class Initialized
INFO - 2020-09-09 11:30:46 --> Model Class Initialized
INFO - 2020-09-09 11:30:46 --> Final output sent to browser
DEBUG - 2020-09-09 11:30:46 --> Total execution time: 0.0336
ERROR - 2020-09-09 14:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:15:33 --> Config Class Initialized
INFO - 2020-09-09 14:15:33 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:15:33 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:15:33 --> Utf8 Class Initialized
INFO - 2020-09-09 14:15:33 --> URI Class Initialized
DEBUG - 2020-09-09 14:15:33 --> No URI present. Default controller set.
INFO - 2020-09-09 14:15:33 --> Router Class Initialized
INFO - 2020-09-09 14:15:33 --> Output Class Initialized
INFO - 2020-09-09 14:15:33 --> Security Class Initialized
DEBUG - 2020-09-09 14:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:15:33 --> Input Class Initialized
INFO - 2020-09-09 14:15:33 --> Language Class Initialized
INFO - 2020-09-09 14:15:33 --> Loader Class Initialized
INFO - 2020-09-09 14:15:33 --> Helper loaded: url_helper
INFO - 2020-09-09 14:15:33 --> Database Driver Class Initialized
INFO - 2020-09-09 14:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:15:33 --> Email Class Initialized
INFO - 2020-09-09 14:15:33 --> Controller Class Initialized
INFO - 2020-09-09 14:15:33 --> Model Class Initialized
INFO - 2020-09-09 14:15:33 --> Model Class Initialized
DEBUG - 2020-09-09 14:15:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:15:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 14:15:33 --> Final output sent to browser
DEBUG - 2020-09-09 14:15:33 --> Total execution time: 0.0179
ERROR - 2020-09-09 14:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-09 14:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:15:36 --> Config Class Initialized
INFO - 2020-09-09 14:15:36 --> Config Class Initialized
INFO - 2020-09-09 14:15:36 --> Hooks Class Initialized
INFO - 2020-09-09 14:15:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:15:36 --> UTF-8 Support Enabled
DEBUG - 2020-09-09 14:15:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:15:36 --> Utf8 Class Initialized
INFO - 2020-09-09 14:15:36 --> Utf8 Class Initialized
INFO - 2020-09-09 14:15:36 --> URI Class Initialized
INFO - 2020-09-09 14:15:36 --> URI Class Initialized
INFO - 2020-09-09 14:15:36 --> Router Class Initialized
INFO - 2020-09-09 14:15:36 --> Router Class Initialized
INFO - 2020-09-09 14:15:36 --> Output Class Initialized
INFO - 2020-09-09 14:15:36 --> Output Class Initialized
INFO - 2020-09-09 14:15:36 --> Security Class Initialized
INFO - 2020-09-09 14:15:36 --> Security Class Initialized
DEBUG - 2020-09-09 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:15:36 --> Input Class Initialized
DEBUG - 2020-09-09 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:15:36 --> Input Class Initialized
INFO - 2020-09-09 14:15:36 --> Language Class Initialized
INFO - 2020-09-09 14:15:36 --> Language Class Initialized
INFO - 2020-09-09 14:15:36 --> Loader Class Initialized
INFO - 2020-09-09 14:15:36 --> Loader Class Initialized
INFO - 2020-09-09 14:15:36 --> Helper loaded: url_helper
INFO - 2020-09-09 14:15:36 --> Helper loaded: url_helper
INFO - 2020-09-09 14:15:36 --> Database Driver Class Initialized
INFO - 2020-09-09 14:15:36 --> Database Driver Class Initialized
INFO - 2020-09-09 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:15:36 --> Email Class Initialized
INFO - 2020-09-09 14:15:36 --> Controller Class Initialized
INFO - 2020-09-09 14:15:36 --> Model Class Initialized
INFO - 2020-09-09 14:15:36 --> Model Class Initialized
DEBUG - 2020-09-09 14:15:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 14:15:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:15:36 --> Email Class Initialized
INFO - 2020-09-09 14:15:36 --> Controller Class Initialized
INFO - 2020-09-09 14:15:36 --> Model Class Initialized
INFO - 2020-09-09 14:15:36 --> Model Class Initialized
DEBUG - 2020-09-09 14:15:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 14:15:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:15:36 --> Config Class Initialized
INFO - 2020-09-09 14:15:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:15:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:15:36 --> Utf8 Class Initialized
INFO - 2020-09-09 14:15:36 --> URI Class Initialized
DEBUG - 2020-09-09 14:15:36 --> No URI present. Default controller set.
INFO - 2020-09-09 14:15:36 --> Router Class Initialized
INFO - 2020-09-09 14:15:36 --> Output Class Initialized
INFO - 2020-09-09 14:15:36 --> Security Class Initialized
DEBUG - 2020-09-09 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:15:36 --> Input Class Initialized
INFO - 2020-09-09 14:15:36 --> Language Class Initialized
INFO - 2020-09-09 14:15:36 --> Loader Class Initialized
INFO - 2020-09-09 14:15:36 --> Helper loaded: url_helper
INFO - 2020-09-09 14:15:36 --> Database Driver Class Initialized
INFO - 2020-09-09 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:15:36 --> Email Class Initialized
INFO - 2020-09-09 14:15:36 --> Controller Class Initialized
INFO - 2020-09-09 14:15:36 --> Model Class Initialized
INFO - 2020-09-09 14:15:36 --> Model Class Initialized
DEBUG - 2020-09-09 14:15:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:15:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 14:15:36 --> Final output sent to browser
DEBUG - 2020-09-09 14:15:36 --> Total execution time: 0.0175
ERROR - 2020-09-09 14:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:15:38 --> Config Class Initialized
INFO - 2020-09-09 14:15:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:15:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:15:38 --> Utf8 Class Initialized
INFO - 2020-09-09 14:15:38 --> URI Class Initialized
INFO - 2020-09-09 14:15:38 --> Router Class Initialized
INFO - 2020-09-09 14:15:38 --> Output Class Initialized
INFO - 2020-09-09 14:15:38 --> Security Class Initialized
DEBUG - 2020-09-09 14:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:15:38 --> Input Class Initialized
INFO - 2020-09-09 14:15:38 --> Language Class Initialized
INFO - 2020-09-09 14:15:38 --> Loader Class Initialized
INFO - 2020-09-09 14:15:38 --> Helper loaded: url_helper
INFO - 2020-09-09 14:15:38 --> Database Driver Class Initialized
INFO - 2020-09-09 14:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:15:38 --> Email Class Initialized
INFO - 2020-09-09 14:15:38 --> Controller Class Initialized
DEBUG - 2020-09-09 14:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 14:15:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:15:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 14:15:38 --> Final output sent to browser
DEBUG - 2020-09-09 14:15:38 --> Total execution time: 0.0166
ERROR - 2020-09-09 14:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:08 --> Config Class Initialized
INFO - 2020-09-09 14:50:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:08 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:08 --> URI Class Initialized
DEBUG - 2020-09-09 14:50:08 --> No URI present. Default controller set.
INFO - 2020-09-09 14:50:08 --> Router Class Initialized
INFO - 2020-09-09 14:50:08 --> Output Class Initialized
INFO - 2020-09-09 14:50:08 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:08 --> Input Class Initialized
INFO - 2020-09-09 14:50:08 --> Language Class Initialized
INFO - 2020-09-09 14:50:08 --> Loader Class Initialized
INFO - 2020-09-09 14:50:08 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:08 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:08 --> Email Class Initialized
INFO - 2020-09-09 14:50:08 --> Controller Class Initialized
INFO - 2020-09-09 14:50:08 --> Model Class Initialized
INFO - 2020-09-09 14:50:08 --> Model Class Initialized
DEBUG - 2020-09-09 14:50:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:50:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 14:50:08 --> Final output sent to browser
DEBUG - 2020-09-09 14:50:08 --> Total execution time: 0.0171
ERROR - 2020-09-09 14:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:17 --> Config Class Initialized
INFO - 2020-09-09 14:50:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:17 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:17 --> URI Class Initialized
INFO - 2020-09-09 14:50:17 --> Router Class Initialized
INFO - 2020-09-09 14:50:17 --> Output Class Initialized
INFO - 2020-09-09 14:50:17 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:17 --> Input Class Initialized
INFO - 2020-09-09 14:50:17 --> Language Class Initialized
INFO - 2020-09-09 14:50:17 --> Loader Class Initialized
INFO - 2020-09-09 14:50:17 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:17 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:17 --> Email Class Initialized
INFO - 2020-09-09 14:50:17 --> Controller Class Initialized
INFO - 2020-09-09 14:50:17 --> Model Class Initialized
INFO - 2020-09-09 14:50:17 --> Model Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 14:50:17 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-09 14:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:17 --> Config Class Initialized
INFO - 2020-09-09 14:50:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:17 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:17 --> URI Class Initialized
INFO - 2020-09-09 14:50:17 --> Router Class Initialized
INFO - 2020-09-09 14:50:17 --> Output Class Initialized
INFO - 2020-09-09 14:50:17 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:17 --> Input Class Initialized
INFO - 2020-09-09 14:50:17 --> Language Class Initialized
INFO - 2020-09-09 14:50:17 --> Loader Class Initialized
INFO - 2020-09-09 14:50:17 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:17 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:17 --> Email Class Initialized
INFO - 2020-09-09 14:50:17 --> Controller Class Initialized
INFO - 2020-09-09 14:50:17 --> Model Class Initialized
INFO - 2020-09-09 14:50:17 --> Model Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 14:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:17 --> Config Class Initialized
INFO - 2020-09-09 14:50:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:17 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:17 --> URI Class Initialized
DEBUG - 2020-09-09 14:50:17 --> No URI present. Default controller set.
INFO - 2020-09-09 14:50:17 --> Router Class Initialized
INFO - 2020-09-09 14:50:17 --> Output Class Initialized
INFO - 2020-09-09 14:50:17 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:17 --> Input Class Initialized
INFO - 2020-09-09 14:50:17 --> Language Class Initialized
INFO - 2020-09-09 14:50:17 --> Loader Class Initialized
INFO - 2020-09-09 14:50:17 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:17 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:17 --> Email Class Initialized
INFO - 2020-09-09 14:50:17 --> Controller Class Initialized
INFO - 2020-09-09 14:50:17 --> Model Class Initialized
INFO - 2020-09-09 14:50:17 --> Model Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:50:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 14:50:17 --> Final output sent to browser
DEBUG - 2020-09-09 14:50:17 --> Total execution time: 0.0190
ERROR - 2020-09-09 14:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:17 --> Config Class Initialized
INFO - 2020-09-09 14:50:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:17 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:17 --> URI Class Initialized
INFO - 2020-09-09 14:50:17 --> Router Class Initialized
INFO - 2020-09-09 14:50:17 --> Output Class Initialized
INFO - 2020-09-09 14:50:17 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:17 --> Input Class Initialized
INFO - 2020-09-09 14:50:17 --> Language Class Initialized
INFO - 2020-09-09 14:50:17 --> Loader Class Initialized
INFO - 2020-09-09 14:50:17 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:17 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:17 --> Email Class Initialized
INFO - 2020-09-09 14:50:17 --> Controller Class Initialized
DEBUG - 2020-09-09 14:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 14:50:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:50:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 14:50:17 --> Final output sent to browser
DEBUG - 2020-09-09 14:50:17 --> Total execution time: 0.0193
ERROR - 2020-09-09 14:50:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:20 --> Config Class Initialized
INFO - 2020-09-09 14:50:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:20 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:20 --> URI Class Initialized
INFO - 2020-09-09 14:50:20 --> Router Class Initialized
INFO - 2020-09-09 14:50:20 --> Output Class Initialized
INFO - 2020-09-09 14:50:20 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:20 --> Input Class Initialized
INFO - 2020-09-09 14:50:20 --> Language Class Initialized
ERROR - 2020-09-09 14:50:20 --> 404 Page Not Found: Dealer/dash.html
ERROR - 2020-09-09 14:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:27 --> Config Class Initialized
INFO - 2020-09-09 14:50:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:27 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:27 --> URI Class Initialized
INFO - 2020-09-09 14:50:27 --> Router Class Initialized
INFO - 2020-09-09 14:50:27 --> Output Class Initialized
INFO - 2020-09-09 14:50:27 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:27 --> Input Class Initialized
INFO - 2020-09-09 14:50:27 --> Language Class Initialized
INFO - 2020-09-09 14:50:27 --> Loader Class Initialized
INFO - 2020-09-09 14:50:27 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:27 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:27 --> Email Class Initialized
INFO - 2020-09-09 14:50:27 --> Controller Class Initialized
DEBUG - 2020-09-09 14:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 14:50:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 14:50:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 14:50:27 --> Final output sent to browser
DEBUG - 2020-09-09 14:50:27 --> Total execution time: 0.0248
ERROR - 2020-09-09 14:50:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:35 --> Config Class Initialized
INFO - 2020-09-09 14:50:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:35 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:35 --> URI Class Initialized
INFO - 2020-09-09 14:50:35 --> Router Class Initialized
INFO - 2020-09-09 14:50:35 --> Output Class Initialized
INFO - 2020-09-09 14:50:35 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:35 --> Input Class Initialized
INFO - 2020-09-09 14:50:35 --> Language Class Initialized
INFO - 2020-09-09 14:50:35 --> Loader Class Initialized
INFO - 2020-09-09 14:50:35 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:35 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:35 --> Email Class Initialized
INFO - 2020-09-09 14:50:35 --> Controller Class Initialized
INFO - 2020-09-09 14:50:35 --> Model Class Initialized
INFO - 2020-09-09 14:50:35 --> Model Class Initialized
INFO - 2020-09-09 14:50:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 14:50:35 --> Final output sent to browser
DEBUG - 2020-09-09 14:50:35 --> Total execution time: 0.0329
ERROR - 2020-09-09 14:50:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:37 --> Config Class Initialized
INFO - 2020-09-09 14:50:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:37 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:37 --> URI Class Initialized
INFO - 2020-09-09 14:50:37 --> Router Class Initialized
INFO - 2020-09-09 14:50:37 --> Output Class Initialized
INFO - 2020-09-09 14:50:37 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:37 --> Input Class Initialized
INFO - 2020-09-09 14:50:37 --> Language Class Initialized
INFO - 2020-09-09 14:50:37 --> Loader Class Initialized
INFO - 2020-09-09 14:50:37 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:37 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:37 --> Email Class Initialized
INFO - 2020-09-09 14:50:37 --> Controller Class Initialized
INFO - 2020-09-09 14:50:37 --> Model Class Initialized
INFO - 2020-09-09 14:50:37 --> Model Class Initialized
INFO - 2020-09-09 14:50:37 --> Final output sent to browser
DEBUG - 2020-09-09 14:50:37 --> Total execution time: 0.0346
ERROR - 2020-09-09 14:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:50:59 --> Config Class Initialized
INFO - 2020-09-09 14:50:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:50:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:50:59 --> Utf8 Class Initialized
INFO - 2020-09-09 14:50:59 --> URI Class Initialized
INFO - 2020-09-09 14:50:59 --> Router Class Initialized
INFO - 2020-09-09 14:50:59 --> Output Class Initialized
INFO - 2020-09-09 14:50:59 --> Security Class Initialized
DEBUG - 2020-09-09 14:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:50:59 --> Input Class Initialized
INFO - 2020-09-09 14:50:59 --> Language Class Initialized
INFO - 2020-09-09 14:50:59 --> Loader Class Initialized
INFO - 2020-09-09 14:50:59 --> Helper loaded: url_helper
INFO - 2020-09-09 14:50:59 --> Database Driver Class Initialized
INFO - 2020-09-09 14:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:50:59 --> Email Class Initialized
INFO - 2020-09-09 14:50:59 --> Controller Class Initialized
INFO - 2020-09-09 14:50:59 --> Model Class Initialized
INFO - 2020-09-09 14:50:59 --> Model Class Initialized
INFO - 2020-09-09 14:51:00 --> Final output sent to browser
DEBUG - 2020-09-09 14:51:00 --> Total execution time: 0.1344
ERROR - 2020-09-09 14:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 14:51:00 --> Config Class Initialized
INFO - 2020-09-09 14:51:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 14:51:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 14:51:00 --> Utf8 Class Initialized
INFO - 2020-09-09 14:51:00 --> URI Class Initialized
INFO - 2020-09-09 14:51:00 --> Router Class Initialized
INFO - 2020-09-09 14:51:00 --> Output Class Initialized
INFO - 2020-09-09 14:51:00 --> Security Class Initialized
DEBUG - 2020-09-09 14:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 14:51:00 --> Input Class Initialized
INFO - 2020-09-09 14:51:00 --> Language Class Initialized
INFO - 2020-09-09 14:51:00 --> Loader Class Initialized
INFO - 2020-09-09 14:51:00 --> Helper loaded: url_helper
INFO - 2020-09-09 14:51:00 --> Database Driver Class Initialized
INFO - 2020-09-09 14:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 14:51:00 --> Email Class Initialized
INFO - 2020-09-09 14:51:00 --> Controller Class Initialized
INFO - 2020-09-09 14:51:00 --> Model Class Initialized
INFO - 2020-09-09 14:51:00 --> Model Class Initialized
INFO - 2020-09-09 14:51:00 --> Final output sent to browser
DEBUG - 2020-09-09 14:51:00 --> Total execution time: 0.0373
ERROR - 2020-09-09 15:35:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:35:53 --> Config Class Initialized
INFO - 2020-09-09 15:35:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:35:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:35:53 --> Utf8 Class Initialized
INFO - 2020-09-09 15:35:53 --> URI Class Initialized
DEBUG - 2020-09-09 15:35:53 --> No URI present. Default controller set.
INFO - 2020-09-09 15:35:53 --> Router Class Initialized
INFO - 2020-09-09 15:35:53 --> Output Class Initialized
INFO - 2020-09-09 15:35:53 --> Security Class Initialized
DEBUG - 2020-09-09 15:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:35:53 --> Input Class Initialized
INFO - 2020-09-09 15:35:53 --> Language Class Initialized
INFO - 2020-09-09 15:35:53 --> Loader Class Initialized
INFO - 2020-09-09 15:35:53 --> Helper loaded: url_helper
INFO - 2020-09-09 15:35:53 --> Database Driver Class Initialized
INFO - 2020-09-09 15:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:35:53 --> Email Class Initialized
INFO - 2020-09-09 15:35:53 --> Controller Class Initialized
INFO - 2020-09-09 15:35:53 --> Model Class Initialized
INFO - 2020-09-09 15:35:53 --> Model Class Initialized
DEBUG - 2020-09-09 15:35:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 15:35:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 15:35:53 --> Final output sent to browser
DEBUG - 2020-09-09 15:35:53 --> Total execution time: 0.0185
ERROR - 2020-09-09 15:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:02 --> Config Class Initialized
INFO - 2020-09-09 15:36:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:02 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:02 --> URI Class Initialized
INFO - 2020-09-09 15:36:02 --> Router Class Initialized
INFO - 2020-09-09 15:36:02 --> Output Class Initialized
INFO - 2020-09-09 15:36:02 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:02 --> Input Class Initialized
INFO - 2020-09-09 15:36:02 --> Language Class Initialized
INFO - 2020-09-09 15:36:02 --> Loader Class Initialized
INFO - 2020-09-09 15:36:02 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:02 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:02 --> Email Class Initialized
INFO - 2020-09-09 15:36:02 --> Controller Class Initialized
INFO - 2020-09-09 15:36:02 --> Model Class Initialized
INFO - 2020-09-09 15:36:02 --> Model Class Initialized
DEBUG - 2020-09-09 15:36:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 15:36:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 15:36:02 --> Model Class Initialized
INFO - 2020-09-09 15:36:02 --> Final output sent to browser
DEBUG - 2020-09-09 15:36:02 --> Total execution time: 0.0224
ERROR - 2020-09-09 15:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:02 --> Config Class Initialized
INFO - 2020-09-09 15:36:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:02 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:02 --> URI Class Initialized
INFO - 2020-09-09 15:36:02 --> Router Class Initialized
INFO - 2020-09-09 15:36:02 --> Output Class Initialized
INFO - 2020-09-09 15:36:02 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:02 --> Input Class Initialized
INFO - 2020-09-09 15:36:02 --> Language Class Initialized
INFO - 2020-09-09 15:36:02 --> Loader Class Initialized
INFO - 2020-09-09 15:36:02 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:02 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:02 --> Email Class Initialized
INFO - 2020-09-09 15:36:02 --> Controller Class Initialized
INFO - 2020-09-09 15:36:02 --> Model Class Initialized
INFO - 2020-09-09 15:36:02 --> Model Class Initialized
DEBUG - 2020-09-09 15:36:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-09 15:36:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:03 --> Config Class Initialized
INFO - 2020-09-09 15:36:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:03 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:03 --> URI Class Initialized
INFO - 2020-09-09 15:36:03 --> Router Class Initialized
INFO - 2020-09-09 15:36:03 --> Output Class Initialized
INFO - 2020-09-09 15:36:03 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:03 --> Input Class Initialized
INFO - 2020-09-09 15:36:03 --> Language Class Initialized
INFO - 2020-09-09 15:36:03 --> Loader Class Initialized
INFO - 2020-09-09 15:36:03 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:03 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:03 --> Email Class Initialized
INFO - 2020-09-09 15:36:03 --> Controller Class Initialized
DEBUG - 2020-09-09 15:36:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 15:36:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 15:36:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 15:36:03 --> Final output sent to browser
DEBUG - 2020-09-09 15:36:03 --> Total execution time: 0.0196
ERROR - 2020-09-09 15:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:07 --> Config Class Initialized
INFO - 2020-09-09 15:36:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:07 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:07 --> URI Class Initialized
INFO - 2020-09-09 15:36:07 --> Router Class Initialized
INFO - 2020-09-09 15:36:07 --> Output Class Initialized
INFO - 2020-09-09 15:36:07 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:07 --> Input Class Initialized
INFO - 2020-09-09 15:36:07 --> Language Class Initialized
INFO - 2020-09-09 15:36:07 --> Loader Class Initialized
INFO - 2020-09-09 15:36:07 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:07 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:07 --> Email Class Initialized
INFO - 2020-09-09 15:36:07 --> Controller Class Initialized
INFO - 2020-09-09 15:36:07 --> Model Class Initialized
INFO - 2020-09-09 15:36:07 --> Model Class Initialized
INFO - 2020-09-09 15:36:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:36:07 --> Final output sent to browser
DEBUG - 2020-09-09 15:36:07 --> Total execution time: 0.0412
ERROR - 2020-09-09 15:36:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:08 --> Config Class Initialized
INFO - 2020-09-09 15:36:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:08 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:08 --> URI Class Initialized
INFO - 2020-09-09 15:36:08 --> Router Class Initialized
INFO - 2020-09-09 15:36:08 --> Output Class Initialized
INFO - 2020-09-09 15:36:08 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:08 --> Input Class Initialized
INFO - 2020-09-09 15:36:08 --> Language Class Initialized
INFO - 2020-09-09 15:36:08 --> Loader Class Initialized
INFO - 2020-09-09 15:36:08 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:08 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:08 --> Email Class Initialized
INFO - 2020-09-09 15:36:08 --> Controller Class Initialized
INFO - 2020-09-09 15:36:08 --> Model Class Initialized
INFO - 2020-09-09 15:36:08 --> Model Class Initialized
INFO - 2020-09-09 15:36:08 --> Final output sent to browser
DEBUG - 2020-09-09 15:36:08 --> Total execution time: 0.0436
ERROR - 2020-09-09 15:36:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:12 --> Config Class Initialized
INFO - 2020-09-09 15:36:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:12 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:12 --> URI Class Initialized
INFO - 2020-09-09 15:36:12 --> Router Class Initialized
INFO - 2020-09-09 15:36:12 --> Output Class Initialized
INFO - 2020-09-09 15:36:12 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:12 --> Input Class Initialized
INFO - 2020-09-09 15:36:12 --> Language Class Initialized
INFO - 2020-09-09 15:36:12 --> Loader Class Initialized
INFO - 2020-09-09 15:36:12 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:12 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:12 --> Email Class Initialized
INFO - 2020-09-09 15:36:12 --> Controller Class Initialized
INFO - 2020-09-09 15:36:12 --> Model Class Initialized
INFO - 2020-09-09 15:36:12 --> Model Class Initialized
ERROR - 2020-09-09 15:36:12 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-09-09 15:36:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:36:12 --> Final output sent to browser
DEBUG - 2020-09-09 15:36:12 --> Total execution time: 0.0530
ERROR - 2020-09-09 15:36:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:36:13 --> Config Class Initialized
INFO - 2020-09-09 15:36:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:36:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:36:13 --> Utf8 Class Initialized
INFO - 2020-09-09 15:36:13 --> URI Class Initialized
INFO - 2020-09-09 15:36:13 --> Router Class Initialized
INFO - 2020-09-09 15:36:13 --> Output Class Initialized
INFO - 2020-09-09 15:36:13 --> Security Class Initialized
DEBUG - 2020-09-09 15:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:36:13 --> Input Class Initialized
INFO - 2020-09-09 15:36:13 --> Language Class Initialized
INFO - 2020-09-09 15:36:13 --> Loader Class Initialized
INFO - 2020-09-09 15:36:13 --> Helper loaded: url_helper
INFO - 2020-09-09 15:36:13 --> Database Driver Class Initialized
INFO - 2020-09-09 15:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:36:13 --> Email Class Initialized
INFO - 2020-09-09 15:36:13 --> Controller Class Initialized
INFO - 2020-09-09 15:36:13 --> Model Class Initialized
INFO - 2020-09-09 15:36:13 --> Model Class Initialized
INFO - 2020-09-09 15:36:13 --> Final output sent to browser
DEBUG - 2020-09-09 15:36:13 --> Total execution time: 0.0382
ERROR - 2020-09-09 15:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:37:32 --> Config Class Initialized
INFO - 2020-09-09 15:37:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:37:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:37:32 --> Utf8 Class Initialized
INFO - 2020-09-09 15:37:32 --> URI Class Initialized
INFO - 2020-09-09 15:37:32 --> Router Class Initialized
INFO - 2020-09-09 15:37:32 --> Output Class Initialized
INFO - 2020-09-09 15:37:32 --> Security Class Initialized
DEBUG - 2020-09-09 15:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:37:32 --> Input Class Initialized
INFO - 2020-09-09 15:37:32 --> Language Class Initialized
INFO - 2020-09-09 15:37:32 --> Loader Class Initialized
INFO - 2020-09-09 15:37:32 --> Helper loaded: url_helper
INFO - 2020-09-09 15:37:32 --> Database Driver Class Initialized
INFO - 2020-09-09 15:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:37:32 --> Email Class Initialized
INFO - 2020-09-09 15:37:32 --> Controller Class Initialized
INFO - 2020-09-09 15:37:32 --> Model Class Initialized
INFO - 2020-09-09 15:37:32 --> Model Class Initialized
INFO - 2020-09-09 15:37:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:37:32 --> Final output sent to browser
DEBUG - 2020-09-09 15:37:32 --> Total execution time: 0.0454
ERROR - 2020-09-09 15:37:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:37:33 --> Config Class Initialized
INFO - 2020-09-09 15:37:33 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:37:33 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:37:33 --> Utf8 Class Initialized
INFO - 2020-09-09 15:37:33 --> URI Class Initialized
INFO - 2020-09-09 15:37:33 --> Router Class Initialized
INFO - 2020-09-09 15:37:33 --> Output Class Initialized
INFO - 2020-09-09 15:37:33 --> Security Class Initialized
DEBUG - 2020-09-09 15:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:37:33 --> Input Class Initialized
INFO - 2020-09-09 15:37:33 --> Language Class Initialized
INFO - 2020-09-09 15:37:33 --> Loader Class Initialized
INFO - 2020-09-09 15:37:33 --> Helper loaded: url_helper
INFO - 2020-09-09 15:37:33 --> Database Driver Class Initialized
INFO - 2020-09-09 15:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:37:33 --> Email Class Initialized
INFO - 2020-09-09 15:37:33 --> Controller Class Initialized
INFO - 2020-09-09 15:37:33 --> Model Class Initialized
INFO - 2020-09-09 15:37:33 --> Model Class Initialized
INFO - 2020-09-09 15:37:33 --> Final output sent to browser
DEBUG - 2020-09-09 15:37:33 --> Total execution time: 0.0355
ERROR - 2020-09-09 15:37:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:37:59 --> Config Class Initialized
INFO - 2020-09-09 15:37:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:37:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:37:59 --> Utf8 Class Initialized
INFO - 2020-09-09 15:37:59 --> URI Class Initialized
INFO - 2020-09-09 15:37:59 --> Router Class Initialized
INFO - 2020-09-09 15:37:59 --> Output Class Initialized
INFO - 2020-09-09 15:37:59 --> Security Class Initialized
DEBUG - 2020-09-09 15:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:37:59 --> Input Class Initialized
INFO - 2020-09-09 15:37:59 --> Language Class Initialized
INFO - 2020-09-09 15:37:59 --> Loader Class Initialized
INFO - 2020-09-09 15:37:59 --> Helper loaded: url_helper
INFO - 2020-09-09 15:37:59 --> Database Driver Class Initialized
INFO - 2020-09-09 15:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:37:59 --> Email Class Initialized
INFO - 2020-09-09 15:37:59 --> Controller Class Initialized
INFO - 2020-09-09 15:37:59 --> Model Class Initialized
INFO - 2020-09-09 15:37:59 --> Model Class Initialized
INFO - 2020-09-09 15:37:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:37:59 --> Final output sent to browser
DEBUG - 2020-09-09 15:37:59 --> Total execution time: 0.0454
ERROR - 2020-09-09 15:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:38:00 --> Config Class Initialized
INFO - 2020-09-09 15:38:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:38:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:38:00 --> Utf8 Class Initialized
INFO - 2020-09-09 15:38:00 --> URI Class Initialized
INFO - 2020-09-09 15:38:00 --> Router Class Initialized
INFO - 2020-09-09 15:38:00 --> Output Class Initialized
INFO - 2020-09-09 15:38:00 --> Security Class Initialized
DEBUG - 2020-09-09 15:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:38:00 --> Input Class Initialized
INFO - 2020-09-09 15:38:00 --> Language Class Initialized
INFO - 2020-09-09 15:38:00 --> Loader Class Initialized
INFO - 2020-09-09 15:38:00 --> Helper loaded: url_helper
INFO - 2020-09-09 15:38:00 --> Database Driver Class Initialized
INFO - 2020-09-09 15:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:38:00 --> Email Class Initialized
INFO - 2020-09-09 15:38:00 --> Controller Class Initialized
INFO - 2020-09-09 15:38:00 --> Model Class Initialized
INFO - 2020-09-09 15:38:00 --> Model Class Initialized
INFO - 2020-09-09 15:38:00 --> Final output sent to browser
DEBUG - 2020-09-09 15:38:00 --> Total execution time: 0.0415
ERROR - 2020-09-09 15:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:48:39 --> Config Class Initialized
INFO - 2020-09-09 15:48:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:48:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:48:39 --> Utf8 Class Initialized
INFO - 2020-09-09 15:48:39 --> URI Class Initialized
INFO - 2020-09-09 15:48:39 --> Router Class Initialized
INFO - 2020-09-09 15:48:39 --> Output Class Initialized
INFO - 2020-09-09 15:48:39 --> Security Class Initialized
DEBUG - 2020-09-09 15:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:48:39 --> Input Class Initialized
INFO - 2020-09-09 15:48:39 --> Language Class Initialized
INFO - 2020-09-09 15:48:39 --> Loader Class Initialized
INFO - 2020-09-09 15:48:39 --> Helper loaded: url_helper
INFO - 2020-09-09 15:48:39 --> Database Driver Class Initialized
INFO - 2020-09-09 15:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:48:39 --> Email Class Initialized
INFO - 2020-09-09 15:48:39 --> Controller Class Initialized
INFO - 2020-09-09 15:48:39 --> Model Class Initialized
INFO - 2020-09-09 15:48:39 --> Model Class Initialized
INFO - 2020-09-09 15:48:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:48:39 --> Final output sent to browser
DEBUG - 2020-09-09 15:48:39 --> Total execution time: 0.0426
ERROR - 2020-09-09 15:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:48:39 --> Config Class Initialized
INFO - 2020-09-09 15:48:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:48:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:48:39 --> Utf8 Class Initialized
INFO - 2020-09-09 15:48:39 --> URI Class Initialized
INFO - 2020-09-09 15:48:39 --> Router Class Initialized
INFO - 2020-09-09 15:48:39 --> Output Class Initialized
INFO - 2020-09-09 15:48:39 --> Security Class Initialized
DEBUG - 2020-09-09 15:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:48:39 --> Input Class Initialized
INFO - 2020-09-09 15:48:39 --> Language Class Initialized
INFO - 2020-09-09 15:48:39 --> Loader Class Initialized
INFO - 2020-09-09 15:48:39 --> Helper loaded: url_helper
INFO - 2020-09-09 15:48:39 --> Database Driver Class Initialized
INFO - 2020-09-09 15:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:48:39 --> Email Class Initialized
INFO - 2020-09-09 15:48:39 --> Controller Class Initialized
INFO - 2020-09-09 15:48:39 --> Model Class Initialized
INFO - 2020-09-09 15:48:39 --> Model Class Initialized
INFO - 2020-09-09 15:48:39 --> Final output sent to browser
DEBUG - 2020-09-09 15:48:39 --> Total execution time: 0.0421
ERROR - 2020-09-09 15:49:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:49:56 --> Config Class Initialized
INFO - 2020-09-09 15:49:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:49:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:49:56 --> Utf8 Class Initialized
INFO - 2020-09-09 15:49:56 --> URI Class Initialized
INFO - 2020-09-09 15:49:56 --> Router Class Initialized
INFO - 2020-09-09 15:49:56 --> Output Class Initialized
INFO - 2020-09-09 15:49:56 --> Security Class Initialized
DEBUG - 2020-09-09 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:49:56 --> Input Class Initialized
INFO - 2020-09-09 15:49:56 --> Language Class Initialized
INFO - 2020-09-09 15:49:56 --> Loader Class Initialized
INFO - 2020-09-09 15:49:56 --> Helper loaded: url_helper
INFO - 2020-09-09 15:49:56 --> Database Driver Class Initialized
INFO - 2020-09-09 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:49:56 --> Email Class Initialized
INFO - 2020-09-09 15:49:56 --> Controller Class Initialized
INFO - 2020-09-09 15:49:56 --> Model Class Initialized
INFO - 2020-09-09 15:49:56 --> Model Class Initialized
INFO - 2020-09-09 15:49:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:49:56 --> Final output sent to browser
DEBUG - 2020-09-09 15:49:56 --> Total execution time: 0.0434
ERROR - 2020-09-09 15:49:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:49:56 --> Config Class Initialized
INFO - 2020-09-09 15:49:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:49:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:49:56 --> Utf8 Class Initialized
INFO - 2020-09-09 15:49:56 --> URI Class Initialized
INFO - 2020-09-09 15:49:56 --> Router Class Initialized
INFO - 2020-09-09 15:49:56 --> Output Class Initialized
INFO - 2020-09-09 15:49:56 --> Security Class Initialized
DEBUG - 2020-09-09 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:49:56 --> Input Class Initialized
INFO - 2020-09-09 15:49:56 --> Language Class Initialized
INFO - 2020-09-09 15:49:56 --> Loader Class Initialized
INFO - 2020-09-09 15:49:56 --> Helper loaded: url_helper
INFO - 2020-09-09 15:49:56 --> Database Driver Class Initialized
INFO - 2020-09-09 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:49:57 --> Email Class Initialized
INFO - 2020-09-09 15:49:57 --> Controller Class Initialized
INFO - 2020-09-09 15:49:57 --> Model Class Initialized
INFO - 2020-09-09 15:49:57 --> Model Class Initialized
INFO - 2020-09-09 15:49:57 --> Final output sent to browser
DEBUG - 2020-09-09 15:49:57 --> Total execution time: 0.0418
ERROR - 2020-09-09 15:50:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:50:00 --> Config Class Initialized
INFO - 2020-09-09 15:50:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:50:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:50:00 --> Utf8 Class Initialized
INFO - 2020-09-09 15:50:00 --> URI Class Initialized
INFO - 2020-09-09 15:50:00 --> Router Class Initialized
INFO - 2020-09-09 15:50:00 --> Output Class Initialized
INFO - 2020-09-09 15:50:00 --> Security Class Initialized
DEBUG - 2020-09-09 15:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:50:00 --> Input Class Initialized
INFO - 2020-09-09 15:50:00 --> Language Class Initialized
INFO - 2020-09-09 15:50:00 --> Loader Class Initialized
INFO - 2020-09-09 15:50:00 --> Helper loaded: url_helper
INFO - 2020-09-09 15:50:00 --> Database Driver Class Initialized
INFO - 2020-09-09 15:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:50:00 --> Email Class Initialized
INFO - 2020-09-09 15:50:00 --> Controller Class Initialized
INFO - 2020-09-09 15:50:00 --> Model Class Initialized
INFO - 2020-09-09 15:50:00 --> Model Class Initialized
INFO - 2020-09-09 15:50:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:50:00 --> Final output sent to browser
DEBUG - 2020-09-09 15:50:00 --> Total execution time: 0.1204
ERROR - 2020-09-09 15:50:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:50:00 --> Config Class Initialized
INFO - 2020-09-09 15:50:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:50:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:50:00 --> Utf8 Class Initialized
INFO - 2020-09-09 15:50:00 --> URI Class Initialized
INFO - 2020-09-09 15:50:00 --> Router Class Initialized
INFO - 2020-09-09 15:50:00 --> Output Class Initialized
INFO - 2020-09-09 15:50:00 --> Security Class Initialized
DEBUG - 2020-09-09 15:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:50:00 --> Input Class Initialized
INFO - 2020-09-09 15:50:00 --> Language Class Initialized
INFO - 2020-09-09 15:50:00 --> Loader Class Initialized
INFO - 2020-09-09 15:50:00 --> Helper loaded: url_helper
INFO - 2020-09-09 15:50:00 --> Database Driver Class Initialized
INFO - 2020-09-09 15:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:50:00 --> Email Class Initialized
INFO - 2020-09-09 15:50:00 --> Controller Class Initialized
INFO - 2020-09-09 15:50:00 --> Model Class Initialized
INFO - 2020-09-09 15:50:00 --> Model Class Initialized
INFO - 2020-09-09 15:50:00 --> Final output sent to browser
DEBUG - 2020-09-09 15:50:00 --> Total execution time: 0.0373
ERROR - 2020-09-09 15:51:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:01 --> Config Class Initialized
INFO - 2020-09-09 15:51:01 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:01 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:01 --> URI Class Initialized
INFO - 2020-09-09 15:51:01 --> Router Class Initialized
INFO - 2020-09-09 15:51:01 --> Output Class Initialized
INFO - 2020-09-09 15:51:01 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:01 --> Input Class Initialized
INFO - 2020-09-09 15:51:01 --> Language Class Initialized
INFO - 2020-09-09 15:51:01 --> Loader Class Initialized
INFO - 2020-09-09 15:51:01 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:01 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:01 --> Email Class Initialized
INFO - 2020-09-09 15:51:01 --> Controller Class Initialized
INFO - 2020-09-09 15:51:01 --> Model Class Initialized
INFO - 2020-09-09 15:51:01 --> Model Class Initialized
INFO - 2020-09-09 15:51:01 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:01 --> Total execution time: 0.1685
ERROR - 2020-09-09 15:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:02 --> Config Class Initialized
INFO - 2020-09-09 15:51:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:02 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:02 --> URI Class Initialized
INFO - 2020-09-09 15:51:02 --> Router Class Initialized
INFO - 2020-09-09 15:51:02 --> Output Class Initialized
INFO - 2020-09-09 15:51:02 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:02 --> Input Class Initialized
INFO - 2020-09-09 15:51:02 --> Language Class Initialized
INFO - 2020-09-09 15:51:02 --> Loader Class Initialized
INFO - 2020-09-09 15:51:02 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:02 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:02 --> Email Class Initialized
INFO - 2020-09-09 15:51:02 --> Controller Class Initialized
INFO - 2020-09-09 15:51:02 --> Model Class Initialized
INFO - 2020-09-09 15:51:02 --> Model Class Initialized
INFO - 2020-09-09 15:51:02 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:02 --> Total execution time: 0.0421
ERROR - 2020-09-09 15:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:07 --> Config Class Initialized
INFO - 2020-09-09 15:51:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:07 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:07 --> URI Class Initialized
INFO - 2020-09-09 15:51:07 --> Router Class Initialized
INFO - 2020-09-09 15:51:07 --> Output Class Initialized
INFO - 2020-09-09 15:51:07 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:07 --> Input Class Initialized
INFO - 2020-09-09 15:51:07 --> Language Class Initialized
INFO - 2020-09-09 15:51:07 --> Loader Class Initialized
INFO - 2020-09-09 15:51:07 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:07 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:07 --> Email Class Initialized
INFO - 2020-09-09 15:51:07 --> Controller Class Initialized
INFO - 2020-09-09 15:51:07 --> Model Class Initialized
INFO - 2020-09-09 15:51:07 --> Model Class Initialized
INFO - 2020-09-09 15:51:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:51:07 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:07 --> Total execution time: 0.0924
ERROR - 2020-09-09 15:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:08 --> Config Class Initialized
INFO - 2020-09-09 15:51:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:08 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:08 --> URI Class Initialized
INFO - 2020-09-09 15:51:08 --> Router Class Initialized
INFO - 2020-09-09 15:51:08 --> Output Class Initialized
INFO - 2020-09-09 15:51:08 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:08 --> Input Class Initialized
INFO - 2020-09-09 15:51:08 --> Language Class Initialized
INFO - 2020-09-09 15:51:08 --> Loader Class Initialized
INFO - 2020-09-09 15:51:08 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:08 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:08 --> Email Class Initialized
INFO - 2020-09-09 15:51:08 --> Controller Class Initialized
INFO - 2020-09-09 15:51:08 --> Model Class Initialized
INFO - 2020-09-09 15:51:08 --> Model Class Initialized
INFO - 2020-09-09 15:51:08 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:08 --> Total execution time: 0.0440
ERROR - 2020-09-09 15:51:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:21 --> Config Class Initialized
INFO - 2020-09-09 15:51:21 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:21 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:21 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:21 --> URI Class Initialized
INFO - 2020-09-09 15:51:21 --> Router Class Initialized
INFO - 2020-09-09 15:51:21 --> Output Class Initialized
INFO - 2020-09-09 15:51:21 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:21 --> Input Class Initialized
INFO - 2020-09-09 15:51:21 --> Language Class Initialized
INFO - 2020-09-09 15:51:21 --> Loader Class Initialized
INFO - 2020-09-09 15:51:21 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:21 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:21 --> Email Class Initialized
INFO - 2020-09-09 15:51:21 --> Controller Class Initialized
INFO - 2020-09-09 15:51:21 --> Model Class Initialized
INFO - 2020-09-09 15:51:21 --> Model Class Initialized
INFO - 2020-09-09 15:51:22 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:22 --> Total execution time: 0.1211
ERROR - 2020-09-09 15:51:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:22 --> Config Class Initialized
INFO - 2020-09-09 15:51:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:22 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:22 --> URI Class Initialized
INFO - 2020-09-09 15:51:22 --> Router Class Initialized
INFO - 2020-09-09 15:51:22 --> Output Class Initialized
INFO - 2020-09-09 15:51:22 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:22 --> Input Class Initialized
INFO - 2020-09-09 15:51:22 --> Language Class Initialized
INFO - 2020-09-09 15:51:22 --> Loader Class Initialized
INFO - 2020-09-09 15:51:22 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:22 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:22 --> Email Class Initialized
INFO - 2020-09-09 15:51:22 --> Controller Class Initialized
INFO - 2020-09-09 15:51:22 --> Model Class Initialized
INFO - 2020-09-09 15:51:22 --> Model Class Initialized
INFO - 2020-09-09 15:51:22 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:22 --> Total execution time: 0.0402
ERROR - 2020-09-09 15:51:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:58 --> Config Class Initialized
INFO - 2020-09-09 15:51:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:58 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:58 --> URI Class Initialized
INFO - 2020-09-09 15:51:58 --> Router Class Initialized
INFO - 2020-09-09 15:51:58 --> Output Class Initialized
INFO - 2020-09-09 15:51:58 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:58 --> Input Class Initialized
INFO - 2020-09-09 15:51:58 --> Language Class Initialized
INFO - 2020-09-09 15:51:58 --> Loader Class Initialized
INFO - 2020-09-09 15:51:58 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:58 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:58 --> Email Class Initialized
INFO - 2020-09-09 15:51:58 --> Controller Class Initialized
INFO - 2020-09-09 15:51:58 --> Model Class Initialized
INFO - 2020-09-09 15:51:58 --> Model Class Initialized
INFO - 2020-09-09 15:51:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:51:58 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:58 --> Total execution time: 0.0576
ERROR - 2020-09-09 15:51:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:51:59 --> Config Class Initialized
INFO - 2020-09-09 15:51:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:51:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:51:59 --> Utf8 Class Initialized
INFO - 2020-09-09 15:51:59 --> URI Class Initialized
INFO - 2020-09-09 15:51:59 --> Router Class Initialized
INFO - 2020-09-09 15:51:59 --> Output Class Initialized
INFO - 2020-09-09 15:51:59 --> Security Class Initialized
DEBUG - 2020-09-09 15:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:51:59 --> Input Class Initialized
INFO - 2020-09-09 15:51:59 --> Language Class Initialized
INFO - 2020-09-09 15:51:59 --> Loader Class Initialized
INFO - 2020-09-09 15:51:59 --> Helper loaded: url_helper
INFO - 2020-09-09 15:51:59 --> Database Driver Class Initialized
INFO - 2020-09-09 15:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:51:59 --> Email Class Initialized
INFO - 2020-09-09 15:51:59 --> Controller Class Initialized
INFO - 2020-09-09 15:51:59 --> Model Class Initialized
INFO - 2020-09-09 15:51:59 --> Model Class Initialized
INFO - 2020-09-09 15:51:59 --> Final output sent to browser
DEBUG - 2020-09-09 15:51:59 --> Total execution time: 0.0451
ERROR - 2020-09-09 15:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:52:48 --> Config Class Initialized
INFO - 2020-09-09 15:52:48 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:52:48 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:52:48 --> Utf8 Class Initialized
INFO - 2020-09-09 15:52:48 --> URI Class Initialized
INFO - 2020-09-09 15:52:48 --> Router Class Initialized
INFO - 2020-09-09 15:52:48 --> Output Class Initialized
INFO - 2020-09-09 15:52:48 --> Security Class Initialized
DEBUG - 2020-09-09 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:52:48 --> Input Class Initialized
INFO - 2020-09-09 15:52:48 --> Language Class Initialized
INFO - 2020-09-09 15:52:48 --> Loader Class Initialized
INFO - 2020-09-09 15:52:48 --> Helper loaded: url_helper
INFO - 2020-09-09 15:52:48 --> Database Driver Class Initialized
INFO - 2020-09-09 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:52:48 --> Email Class Initialized
INFO - 2020-09-09 15:52:48 --> Controller Class Initialized
INFO - 2020-09-09 15:52:48 --> Model Class Initialized
INFO - 2020-09-09 15:52:48 --> Model Class Initialized
INFO - 2020-09-09 15:52:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:52:48 --> Final output sent to browser
DEBUG - 2020-09-09 15:52:48 --> Total execution time: 0.1026
ERROR - 2020-09-09 15:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:52:49 --> Config Class Initialized
INFO - 2020-09-09 15:52:49 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:52:49 --> Utf8 Class Initialized
INFO - 2020-09-09 15:52:49 --> URI Class Initialized
INFO - 2020-09-09 15:52:49 --> Router Class Initialized
INFO - 2020-09-09 15:52:49 --> Output Class Initialized
INFO - 2020-09-09 15:52:49 --> Security Class Initialized
DEBUG - 2020-09-09 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:52:49 --> Input Class Initialized
INFO - 2020-09-09 15:52:49 --> Language Class Initialized
INFO - 2020-09-09 15:52:49 --> Loader Class Initialized
INFO - 2020-09-09 15:52:49 --> Helper loaded: url_helper
INFO - 2020-09-09 15:52:49 --> Database Driver Class Initialized
INFO - 2020-09-09 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:52:49 --> Email Class Initialized
INFO - 2020-09-09 15:52:49 --> Controller Class Initialized
INFO - 2020-09-09 15:52:49 --> Model Class Initialized
INFO - 2020-09-09 15:52:49 --> Model Class Initialized
INFO - 2020-09-09 15:52:49 --> Final output sent to browser
DEBUG - 2020-09-09 15:52:49 --> Total execution time: 0.0429
ERROR - 2020-09-09 15:53:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:53:03 --> Config Class Initialized
INFO - 2020-09-09 15:53:03 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:53:03 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:53:03 --> Utf8 Class Initialized
INFO - 2020-09-09 15:53:03 --> URI Class Initialized
INFO - 2020-09-09 15:53:03 --> Router Class Initialized
INFO - 2020-09-09 15:53:03 --> Output Class Initialized
INFO - 2020-09-09 15:53:03 --> Security Class Initialized
DEBUG - 2020-09-09 15:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:53:03 --> Input Class Initialized
INFO - 2020-09-09 15:53:03 --> Language Class Initialized
INFO - 2020-09-09 15:53:03 --> Loader Class Initialized
INFO - 2020-09-09 15:53:03 --> Helper loaded: url_helper
INFO - 2020-09-09 15:53:03 --> Database Driver Class Initialized
INFO - 2020-09-09 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:53:03 --> Email Class Initialized
INFO - 2020-09-09 15:53:03 --> Controller Class Initialized
INFO - 2020-09-09 15:53:03 --> Model Class Initialized
INFO - 2020-09-09 15:53:03 --> Model Class Initialized
INFO - 2020-09-09 15:53:03 --> Final output sent to browser
DEBUG - 2020-09-09 15:53:03 --> Total execution time: 0.1431
ERROR - 2020-09-09 15:53:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:53:04 --> Config Class Initialized
INFO - 2020-09-09 15:53:04 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:53:04 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:53:04 --> Utf8 Class Initialized
INFO - 2020-09-09 15:53:04 --> URI Class Initialized
INFO - 2020-09-09 15:53:04 --> Router Class Initialized
INFO - 2020-09-09 15:53:04 --> Output Class Initialized
INFO - 2020-09-09 15:53:04 --> Security Class Initialized
DEBUG - 2020-09-09 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:53:04 --> Input Class Initialized
INFO - 2020-09-09 15:53:04 --> Language Class Initialized
INFO - 2020-09-09 15:53:04 --> Loader Class Initialized
INFO - 2020-09-09 15:53:04 --> Helper loaded: url_helper
INFO - 2020-09-09 15:53:04 --> Database Driver Class Initialized
INFO - 2020-09-09 15:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:53:04 --> Email Class Initialized
INFO - 2020-09-09 15:53:04 --> Controller Class Initialized
INFO - 2020-09-09 15:53:04 --> Model Class Initialized
INFO - 2020-09-09 15:53:04 --> Model Class Initialized
INFO - 2020-09-09 15:53:04 --> Final output sent to browser
DEBUG - 2020-09-09 15:53:04 --> Total execution time: 0.0399
ERROR - 2020-09-09 15:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:53:22 --> Config Class Initialized
INFO - 2020-09-09 15:53:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:53:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:53:22 --> Utf8 Class Initialized
INFO - 2020-09-09 15:53:22 --> URI Class Initialized
INFO - 2020-09-09 15:53:22 --> Router Class Initialized
INFO - 2020-09-09 15:53:22 --> Output Class Initialized
INFO - 2020-09-09 15:53:22 --> Security Class Initialized
DEBUG - 2020-09-09 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:53:22 --> Input Class Initialized
INFO - 2020-09-09 15:53:22 --> Language Class Initialized
INFO - 2020-09-09 15:53:22 --> Loader Class Initialized
INFO - 2020-09-09 15:53:22 --> Helper loaded: url_helper
INFO - 2020-09-09 15:53:22 --> Database Driver Class Initialized
INFO - 2020-09-09 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:53:22 --> Email Class Initialized
INFO - 2020-09-09 15:53:22 --> Controller Class Initialized
INFO - 2020-09-09 15:53:22 --> Model Class Initialized
INFO - 2020-09-09 15:53:22 --> Model Class Initialized
INFO - 2020-09-09 15:53:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 15:53:22 --> Final output sent to browser
DEBUG - 2020-09-09 15:53:22 --> Total execution time: 0.0438
ERROR - 2020-09-09 15:53:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:53:22 --> Config Class Initialized
INFO - 2020-09-09 15:53:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:53:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:53:22 --> Utf8 Class Initialized
INFO - 2020-09-09 15:53:22 --> URI Class Initialized
INFO - 2020-09-09 15:53:22 --> Router Class Initialized
INFO - 2020-09-09 15:53:22 --> Output Class Initialized
INFO - 2020-09-09 15:53:22 --> Security Class Initialized
DEBUG - 2020-09-09 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:53:22 --> Input Class Initialized
INFO - 2020-09-09 15:53:22 --> Language Class Initialized
INFO - 2020-09-09 15:53:22 --> Loader Class Initialized
INFO - 2020-09-09 15:53:22 --> Helper loaded: url_helper
INFO - 2020-09-09 15:53:22 --> Database Driver Class Initialized
INFO - 2020-09-09 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:53:22 --> Email Class Initialized
INFO - 2020-09-09 15:53:22 --> Controller Class Initialized
INFO - 2020-09-09 15:53:22 --> Model Class Initialized
INFO - 2020-09-09 15:53:22 --> Model Class Initialized
INFO - 2020-09-09 15:53:22 --> Final output sent to browser
DEBUG - 2020-09-09 15:53:22 --> Total execution time: 0.0431
ERROR - 2020-09-09 15:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:53:41 --> Config Class Initialized
INFO - 2020-09-09 15:53:41 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:53:41 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:53:41 --> Utf8 Class Initialized
INFO - 2020-09-09 15:53:41 --> URI Class Initialized
INFO - 2020-09-09 15:53:41 --> Router Class Initialized
INFO - 2020-09-09 15:53:41 --> Output Class Initialized
INFO - 2020-09-09 15:53:41 --> Security Class Initialized
DEBUG - 2020-09-09 15:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:53:41 --> Input Class Initialized
INFO - 2020-09-09 15:53:41 --> Language Class Initialized
INFO - 2020-09-09 15:53:41 --> Loader Class Initialized
INFO - 2020-09-09 15:53:41 --> Helper loaded: url_helper
INFO - 2020-09-09 15:53:41 --> Database Driver Class Initialized
INFO - 2020-09-09 15:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:53:41 --> Email Class Initialized
INFO - 2020-09-09 15:53:41 --> Controller Class Initialized
INFO - 2020-09-09 15:53:41 --> Model Class Initialized
INFO - 2020-09-09 15:53:41 --> Model Class Initialized
INFO - 2020-09-09 15:53:41 --> Final output sent to browser
DEBUG - 2020-09-09 15:53:41 --> Total execution time: 0.1425
ERROR - 2020-09-09 15:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 15:53:41 --> Config Class Initialized
INFO - 2020-09-09 15:53:41 --> Hooks Class Initialized
DEBUG - 2020-09-09 15:53:41 --> UTF-8 Support Enabled
INFO - 2020-09-09 15:53:41 --> Utf8 Class Initialized
INFO - 2020-09-09 15:53:41 --> URI Class Initialized
INFO - 2020-09-09 15:53:41 --> Router Class Initialized
INFO - 2020-09-09 15:53:41 --> Output Class Initialized
INFO - 2020-09-09 15:53:41 --> Security Class Initialized
DEBUG - 2020-09-09 15:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 15:53:41 --> Input Class Initialized
INFO - 2020-09-09 15:53:41 --> Language Class Initialized
INFO - 2020-09-09 15:53:41 --> Loader Class Initialized
INFO - 2020-09-09 15:53:41 --> Helper loaded: url_helper
INFO - 2020-09-09 15:53:41 --> Database Driver Class Initialized
INFO - 2020-09-09 15:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 15:53:41 --> Email Class Initialized
INFO - 2020-09-09 15:53:41 --> Controller Class Initialized
INFO - 2020-09-09 15:53:41 --> Model Class Initialized
INFO - 2020-09-09 15:53:41 --> Model Class Initialized
INFO - 2020-09-09 15:53:41 --> Final output sent to browser
DEBUG - 2020-09-09 15:53:41 --> Total execution time: 0.0429
ERROR - 2020-09-09 16:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:31:27 --> Config Class Initialized
INFO - 2020-09-09 16:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:31:27 --> Utf8 Class Initialized
INFO - 2020-09-09 16:31:27 --> URI Class Initialized
INFO - 2020-09-09 16:31:27 --> Router Class Initialized
INFO - 2020-09-09 16:31:27 --> Output Class Initialized
INFO - 2020-09-09 16:31:27 --> Security Class Initialized
DEBUG - 2020-09-09 16:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:31:27 --> Input Class Initialized
INFO - 2020-09-09 16:31:27 --> Language Class Initialized
INFO - 2020-09-09 16:31:27 --> Loader Class Initialized
INFO - 2020-09-09 16:31:27 --> Helper loaded: url_helper
INFO - 2020-09-09 16:31:27 --> Database Driver Class Initialized
INFO - 2020-09-09 16:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:31:27 --> Email Class Initialized
INFO - 2020-09-09 16:31:27 --> Controller Class Initialized
INFO - 2020-09-09 16:31:27 --> Model Class Initialized
INFO - 2020-09-09 16:31:27 --> Model Class Initialized
INFO - 2020-09-09 16:31:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:31:27 --> Final output sent to browser
DEBUG - 2020-09-09 16:31:27 --> Total execution time: 0.0448
ERROR - 2020-09-09 16:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:31:28 --> Config Class Initialized
INFO - 2020-09-09 16:31:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:31:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:31:28 --> Utf8 Class Initialized
INFO - 2020-09-09 16:31:28 --> URI Class Initialized
INFO - 2020-09-09 16:31:28 --> Router Class Initialized
INFO - 2020-09-09 16:31:28 --> Output Class Initialized
INFO - 2020-09-09 16:31:28 --> Security Class Initialized
DEBUG - 2020-09-09 16:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:31:28 --> Input Class Initialized
INFO - 2020-09-09 16:31:28 --> Language Class Initialized
INFO - 2020-09-09 16:31:28 --> Loader Class Initialized
INFO - 2020-09-09 16:31:28 --> Helper loaded: url_helper
INFO - 2020-09-09 16:31:28 --> Database Driver Class Initialized
INFO - 2020-09-09 16:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:31:28 --> Email Class Initialized
INFO - 2020-09-09 16:31:28 --> Controller Class Initialized
INFO - 2020-09-09 16:31:28 --> Model Class Initialized
INFO - 2020-09-09 16:31:28 --> Model Class Initialized
INFO - 2020-09-09 16:31:28 --> Final output sent to browser
DEBUG - 2020-09-09 16:31:28 --> Total execution time: 0.0407
ERROR - 2020-09-09 16:33:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:33:55 --> Config Class Initialized
INFO - 2020-09-09 16:33:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:33:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:33:55 --> Utf8 Class Initialized
INFO - 2020-09-09 16:33:55 --> URI Class Initialized
INFO - 2020-09-09 16:33:55 --> Router Class Initialized
INFO - 2020-09-09 16:33:55 --> Output Class Initialized
INFO - 2020-09-09 16:33:55 --> Security Class Initialized
DEBUG - 2020-09-09 16:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:33:55 --> Input Class Initialized
INFO - 2020-09-09 16:33:55 --> Language Class Initialized
INFO - 2020-09-09 16:33:55 --> Loader Class Initialized
INFO - 2020-09-09 16:33:55 --> Helper loaded: url_helper
INFO - 2020-09-09 16:33:55 --> Database Driver Class Initialized
INFO - 2020-09-09 16:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:33:55 --> Email Class Initialized
INFO - 2020-09-09 16:33:55 --> Controller Class Initialized
INFO - 2020-09-09 16:33:55 --> Model Class Initialized
INFO - 2020-09-09 16:33:55 --> Model Class Initialized
INFO - 2020-09-09 16:33:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:33:55 --> Final output sent to browser
DEBUG - 2020-09-09 16:33:55 --> Total execution time: 0.0482
ERROR - 2020-09-09 16:33:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:33:56 --> Config Class Initialized
INFO - 2020-09-09 16:33:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:33:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:33:56 --> Utf8 Class Initialized
INFO - 2020-09-09 16:33:56 --> URI Class Initialized
INFO - 2020-09-09 16:33:56 --> Router Class Initialized
INFO - 2020-09-09 16:33:56 --> Output Class Initialized
INFO - 2020-09-09 16:33:56 --> Security Class Initialized
DEBUG - 2020-09-09 16:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:33:56 --> Input Class Initialized
INFO - 2020-09-09 16:33:56 --> Language Class Initialized
INFO - 2020-09-09 16:33:56 --> Loader Class Initialized
INFO - 2020-09-09 16:33:56 --> Helper loaded: url_helper
INFO - 2020-09-09 16:33:56 --> Database Driver Class Initialized
INFO - 2020-09-09 16:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:33:56 --> Email Class Initialized
INFO - 2020-09-09 16:33:56 --> Controller Class Initialized
INFO - 2020-09-09 16:33:56 --> Model Class Initialized
INFO - 2020-09-09 16:33:56 --> Model Class Initialized
INFO - 2020-09-09 16:33:56 --> Final output sent to browser
DEBUG - 2020-09-09 16:33:56 --> Total execution time: 0.0446
ERROR - 2020-09-09 16:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:35:40 --> Config Class Initialized
INFO - 2020-09-09 16:35:40 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:35:40 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:35:40 --> Utf8 Class Initialized
INFO - 2020-09-09 16:35:40 --> URI Class Initialized
INFO - 2020-09-09 16:35:40 --> Router Class Initialized
INFO - 2020-09-09 16:35:40 --> Output Class Initialized
INFO - 2020-09-09 16:35:40 --> Security Class Initialized
DEBUG - 2020-09-09 16:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:35:40 --> Input Class Initialized
INFO - 2020-09-09 16:35:40 --> Language Class Initialized
INFO - 2020-09-09 16:35:40 --> Loader Class Initialized
INFO - 2020-09-09 16:35:40 --> Helper loaded: url_helper
INFO - 2020-09-09 16:35:40 --> Database Driver Class Initialized
INFO - 2020-09-09 16:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:35:40 --> Email Class Initialized
INFO - 2020-09-09 16:35:40 --> Controller Class Initialized
INFO - 2020-09-09 16:35:40 --> Model Class Initialized
INFO - 2020-09-09 16:35:40 --> Model Class Initialized
INFO - 2020-09-09 16:35:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:35:40 --> Final output sent to browser
DEBUG - 2020-09-09 16:35:40 --> Total execution time: 0.0408
ERROR - 2020-09-09 16:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:35:41 --> Config Class Initialized
INFO - 2020-09-09 16:35:41 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:35:41 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:35:41 --> Utf8 Class Initialized
INFO - 2020-09-09 16:35:41 --> URI Class Initialized
INFO - 2020-09-09 16:35:41 --> Router Class Initialized
INFO - 2020-09-09 16:35:41 --> Output Class Initialized
INFO - 2020-09-09 16:35:41 --> Security Class Initialized
DEBUG - 2020-09-09 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:35:41 --> Input Class Initialized
INFO - 2020-09-09 16:35:41 --> Language Class Initialized
INFO - 2020-09-09 16:35:41 --> Loader Class Initialized
INFO - 2020-09-09 16:35:41 --> Helper loaded: url_helper
INFO - 2020-09-09 16:35:41 --> Database Driver Class Initialized
INFO - 2020-09-09 16:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:35:41 --> Email Class Initialized
INFO - 2020-09-09 16:35:41 --> Controller Class Initialized
INFO - 2020-09-09 16:35:41 --> Model Class Initialized
INFO - 2020-09-09 16:35:41 --> Model Class Initialized
INFO - 2020-09-09 16:35:41 --> Final output sent to browser
DEBUG - 2020-09-09 16:35:41 --> Total execution time: 0.0362
ERROR - 2020-09-09 16:36:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:36:28 --> Config Class Initialized
INFO - 2020-09-09 16:36:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:36:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:36:28 --> Utf8 Class Initialized
INFO - 2020-09-09 16:36:28 --> URI Class Initialized
INFO - 2020-09-09 16:36:28 --> Router Class Initialized
INFO - 2020-09-09 16:36:28 --> Output Class Initialized
INFO - 2020-09-09 16:36:28 --> Security Class Initialized
DEBUG - 2020-09-09 16:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:36:28 --> Input Class Initialized
INFO - 2020-09-09 16:36:28 --> Language Class Initialized
INFO - 2020-09-09 16:36:28 --> Loader Class Initialized
INFO - 2020-09-09 16:36:28 --> Helper loaded: url_helper
INFO - 2020-09-09 16:36:28 --> Database Driver Class Initialized
INFO - 2020-09-09 16:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:36:28 --> Email Class Initialized
INFO - 2020-09-09 16:36:28 --> Controller Class Initialized
INFO - 2020-09-09 16:36:28 --> Model Class Initialized
INFO - 2020-09-09 16:36:28 --> Model Class Initialized
INFO - 2020-09-09 16:36:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:36:28 --> Final output sent to browser
DEBUG - 2020-09-09 16:36:28 --> Total execution time: 0.0382
ERROR - 2020-09-09 16:36:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:36:29 --> Config Class Initialized
INFO - 2020-09-09 16:36:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:36:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:36:29 --> Utf8 Class Initialized
INFO - 2020-09-09 16:36:29 --> URI Class Initialized
INFO - 2020-09-09 16:36:29 --> Router Class Initialized
INFO - 2020-09-09 16:36:29 --> Output Class Initialized
INFO - 2020-09-09 16:36:29 --> Security Class Initialized
DEBUG - 2020-09-09 16:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:36:29 --> Input Class Initialized
INFO - 2020-09-09 16:36:29 --> Language Class Initialized
INFO - 2020-09-09 16:36:29 --> Loader Class Initialized
INFO - 2020-09-09 16:36:29 --> Helper loaded: url_helper
INFO - 2020-09-09 16:36:29 --> Database Driver Class Initialized
INFO - 2020-09-09 16:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:36:29 --> Email Class Initialized
INFO - 2020-09-09 16:36:29 --> Controller Class Initialized
INFO - 2020-09-09 16:36:29 --> Model Class Initialized
INFO - 2020-09-09 16:36:29 --> Model Class Initialized
INFO - 2020-09-09 16:36:29 --> Final output sent to browser
DEBUG - 2020-09-09 16:36:29 --> Total execution time: 0.0362
ERROR - 2020-09-09 16:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:41:59 --> Config Class Initialized
INFO - 2020-09-09 16:41:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:41:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:41:59 --> Utf8 Class Initialized
INFO - 2020-09-09 16:41:59 --> URI Class Initialized
INFO - 2020-09-09 16:41:59 --> Router Class Initialized
INFO - 2020-09-09 16:41:59 --> Output Class Initialized
INFO - 2020-09-09 16:41:59 --> Security Class Initialized
DEBUG - 2020-09-09 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:41:59 --> Input Class Initialized
INFO - 2020-09-09 16:41:59 --> Language Class Initialized
INFO - 2020-09-09 16:41:59 --> Loader Class Initialized
INFO - 2020-09-09 16:41:59 --> Helper loaded: url_helper
INFO - 2020-09-09 16:41:59 --> Database Driver Class Initialized
INFO - 2020-09-09 16:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:41:59 --> Email Class Initialized
INFO - 2020-09-09 16:41:59 --> Controller Class Initialized
INFO - 2020-09-09 16:41:59 --> Model Class Initialized
INFO - 2020-09-09 16:41:59 --> Model Class Initialized
INFO - 2020-09-09 16:41:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:41:59 --> Final output sent to browser
DEBUG - 2020-09-09 16:41:59 --> Total execution time: 0.0442
ERROR - 2020-09-09 16:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:42:00 --> Config Class Initialized
INFO - 2020-09-09 16:42:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:42:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:42:00 --> Utf8 Class Initialized
INFO - 2020-09-09 16:42:00 --> URI Class Initialized
INFO - 2020-09-09 16:42:00 --> Router Class Initialized
INFO - 2020-09-09 16:42:00 --> Output Class Initialized
INFO - 2020-09-09 16:42:00 --> Security Class Initialized
DEBUG - 2020-09-09 16:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:42:00 --> Input Class Initialized
INFO - 2020-09-09 16:42:00 --> Language Class Initialized
INFO - 2020-09-09 16:42:00 --> Loader Class Initialized
INFO - 2020-09-09 16:42:00 --> Helper loaded: url_helper
INFO - 2020-09-09 16:42:00 --> Database Driver Class Initialized
INFO - 2020-09-09 16:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:42:00 --> Email Class Initialized
INFO - 2020-09-09 16:42:00 --> Controller Class Initialized
INFO - 2020-09-09 16:42:00 --> Model Class Initialized
INFO - 2020-09-09 16:42:00 --> Model Class Initialized
INFO - 2020-09-09 16:42:00 --> Final output sent to browser
DEBUG - 2020-09-09 16:42:00 --> Total execution time: 0.0591
ERROR - 2020-09-09 16:43:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:43:19 --> Config Class Initialized
INFO - 2020-09-09 16:43:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:43:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:43:19 --> Utf8 Class Initialized
INFO - 2020-09-09 16:43:19 --> URI Class Initialized
INFO - 2020-09-09 16:43:20 --> Router Class Initialized
INFO - 2020-09-09 16:43:20 --> Output Class Initialized
INFO - 2020-09-09 16:43:20 --> Security Class Initialized
DEBUG - 2020-09-09 16:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:43:20 --> Input Class Initialized
INFO - 2020-09-09 16:43:20 --> Language Class Initialized
INFO - 2020-09-09 16:43:20 --> Loader Class Initialized
INFO - 2020-09-09 16:43:20 --> Helper loaded: url_helper
INFO - 2020-09-09 16:43:20 --> Database Driver Class Initialized
INFO - 2020-09-09 16:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:43:20 --> Email Class Initialized
INFO - 2020-09-09 16:43:20 --> Controller Class Initialized
INFO - 2020-09-09 16:43:20 --> Model Class Initialized
INFO - 2020-09-09 16:43:20 --> Model Class Initialized
INFO - 2020-09-09 16:43:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:43:20 --> Final output sent to browser
DEBUG - 2020-09-09 16:43:20 --> Total execution time: 0.1233
ERROR - 2020-09-09 16:43:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:43:20 --> Config Class Initialized
INFO - 2020-09-09 16:43:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:43:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:43:20 --> Utf8 Class Initialized
INFO - 2020-09-09 16:43:20 --> URI Class Initialized
INFO - 2020-09-09 16:43:20 --> Router Class Initialized
INFO - 2020-09-09 16:43:20 --> Output Class Initialized
INFO - 2020-09-09 16:43:20 --> Security Class Initialized
DEBUG - 2020-09-09 16:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:43:20 --> Input Class Initialized
INFO - 2020-09-09 16:43:20 --> Language Class Initialized
INFO - 2020-09-09 16:43:20 --> Loader Class Initialized
INFO - 2020-09-09 16:43:20 --> Helper loaded: url_helper
INFO - 2020-09-09 16:43:20 --> Database Driver Class Initialized
INFO - 2020-09-09 16:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:43:20 --> Email Class Initialized
INFO - 2020-09-09 16:43:20 --> Controller Class Initialized
INFO - 2020-09-09 16:43:20 --> Model Class Initialized
INFO - 2020-09-09 16:43:20 --> Model Class Initialized
INFO - 2020-09-09 16:43:20 --> Final output sent to browser
DEBUG - 2020-09-09 16:43:20 --> Total execution time: 0.0406
ERROR - 2020-09-09 16:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:51:57 --> Config Class Initialized
INFO - 2020-09-09 16:51:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:51:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:51:57 --> Utf8 Class Initialized
INFO - 2020-09-09 16:51:57 --> URI Class Initialized
INFO - 2020-09-09 16:51:57 --> Router Class Initialized
INFO - 2020-09-09 16:51:57 --> Output Class Initialized
INFO - 2020-09-09 16:51:57 --> Security Class Initialized
DEBUG - 2020-09-09 16:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:51:57 --> Input Class Initialized
INFO - 2020-09-09 16:51:57 --> Language Class Initialized
INFO - 2020-09-09 16:51:57 --> Loader Class Initialized
INFO - 2020-09-09 16:51:57 --> Helper loaded: url_helper
INFO - 2020-09-09 16:51:57 --> Database Driver Class Initialized
INFO - 2020-09-09 16:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:51:57 --> Email Class Initialized
INFO - 2020-09-09 16:51:57 --> Controller Class Initialized
INFO - 2020-09-09 16:51:57 --> Model Class Initialized
INFO - 2020-09-09 16:51:57 --> Model Class Initialized
INFO - 2020-09-09 16:51:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:51:57 --> Final output sent to browser
DEBUG - 2020-09-09 16:51:57 --> Total execution time: 0.1280
ERROR - 2020-09-09 16:51:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:51:58 --> Config Class Initialized
INFO - 2020-09-09 16:51:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:51:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:51:58 --> Utf8 Class Initialized
INFO - 2020-09-09 16:51:58 --> URI Class Initialized
INFO - 2020-09-09 16:51:58 --> Router Class Initialized
INFO - 2020-09-09 16:51:58 --> Output Class Initialized
INFO - 2020-09-09 16:51:58 --> Security Class Initialized
DEBUG - 2020-09-09 16:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:51:58 --> Input Class Initialized
INFO - 2020-09-09 16:51:58 --> Language Class Initialized
INFO - 2020-09-09 16:51:58 --> Loader Class Initialized
INFO - 2020-09-09 16:51:58 --> Helper loaded: url_helper
INFO - 2020-09-09 16:51:58 --> Database Driver Class Initialized
INFO - 2020-09-09 16:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:51:58 --> Email Class Initialized
INFO - 2020-09-09 16:51:58 --> Controller Class Initialized
INFO - 2020-09-09 16:51:58 --> Model Class Initialized
INFO - 2020-09-09 16:51:58 --> Model Class Initialized
INFO - 2020-09-09 16:51:58 --> Final output sent to browser
DEBUG - 2020-09-09 16:51:58 --> Total execution time: 0.0507
ERROR - 2020-09-09 16:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:52:05 --> Config Class Initialized
INFO - 2020-09-09 16:52:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:52:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:52:05 --> Utf8 Class Initialized
INFO - 2020-09-09 16:52:05 --> URI Class Initialized
INFO - 2020-09-09 16:52:05 --> Router Class Initialized
INFO - 2020-09-09 16:52:05 --> Output Class Initialized
INFO - 2020-09-09 16:52:05 --> Security Class Initialized
DEBUG - 2020-09-09 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:52:05 --> Input Class Initialized
INFO - 2020-09-09 16:52:05 --> Language Class Initialized
INFO - 2020-09-09 16:52:05 --> Loader Class Initialized
INFO - 2020-09-09 16:52:05 --> Helper loaded: url_helper
INFO - 2020-09-09 16:52:05 --> Database Driver Class Initialized
INFO - 2020-09-09 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:52:05 --> Email Class Initialized
INFO - 2020-09-09 16:52:05 --> Controller Class Initialized
INFO - 2020-09-09 16:52:05 --> Model Class Initialized
INFO - 2020-09-09 16:52:05 --> Model Class Initialized
INFO - 2020-09-09 16:52:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:52:05 --> Final output sent to browser
DEBUG - 2020-09-09 16:52:05 --> Total execution time: 0.0971
ERROR - 2020-09-09 16:52:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:52:05 --> Config Class Initialized
INFO - 2020-09-09 16:52:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:52:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:52:05 --> Utf8 Class Initialized
INFO - 2020-09-09 16:52:05 --> URI Class Initialized
INFO - 2020-09-09 16:52:05 --> Router Class Initialized
INFO - 2020-09-09 16:52:05 --> Output Class Initialized
INFO - 2020-09-09 16:52:05 --> Security Class Initialized
DEBUG - 2020-09-09 16:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:52:05 --> Input Class Initialized
INFO - 2020-09-09 16:52:05 --> Language Class Initialized
INFO - 2020-09-09 16:52:05 --> Loader Class Initialized
INFO - 2020-09-09 16:52:05 --> Helper loaded: url_helper
INFO - 2020-09-09 16:52:05 --> Database Driver Class Initialized
INFO - 2020-09-09 16:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:52:05 --> Email Class Initialized
INFO - 2020-09-09 16:52:05 --> Controller Class Initialized
INFO - 2020-09-09 16:52:05 --> Model Class Initialized
INFO - 2020-09-09 16:52:05 --> Model Class Initialized
INFO - 2020-09-09 16:52:05 --> Final output sent to browser
DEBUG - 2020-09-09 16:52:05 --> Total execution time: 0.0426
ERROR - 2020-09-09 16:52:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:52:10 --> Config Class Initialized
INFO - 2020-09-09 16:52:10 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:52:10 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:52:10 --> Utf8 Class Initialized
INFO - 2020-09-09 16:52:10 --> URI Class Initialized
INFO - 2020-09-09 16:52:10 --> Router Class Initialized
INFO - 2020-09-09 16:52:10 --> Output Class Initialized
INFO - 2020-09-09 16:52:10 --> Security Class Initialized
DEBUG - 2020-09-09 16:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:52:10 --> Input Class Initialized
INFO - 2020-09-09 16:52:10 --> Language Class Initialized
INFO - 2020-09-09 16:52:10 --> Loader Class Initialized
INFO - 2020-09-09 16:52:10 --> Helper loaded: url_helper
INFO - 2020-09-09 16:52:10 --> Database Driver Class Initialized
INFO - 2020-09-09 16:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:52:10 --> Email Class Initialized
INFO - 2020-09-09 16:52:10 --> Controller Class Initialized
INFO - 2020-09-09 16:52:10 --> Model Class Initialized
INFO - 2020-09-09 16:52:10 --> Model Class Initialized
INFO - 2020-09-09 16:52:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:52:10 --> Final output sent to browser
DEBUG - 2020-09-09 16:52:10 --> Total execution time: 0.0424
ERROR - 2020-09-09 16:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:52:11 --> Config Class Initialized
INFO - 2020-09-09 16:52:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:52:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:52:11 --> Utf8 Class Initialized
INFO - 2020-09-09 16:52:11 --> URI Class Initialized
INFO - 2020-09-09 16:52:11 --> Router Class Initialized
INFO - 2020-09-09 16:52:11 --> Output Class Initialized
INFO - 2020-09-09 16:52:11 --> Security Class Initialized
DEBUG - 2020-09-09 16:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:52:11 --> Input Class Initialized
INFO - 2020-09-09 16:52:11 --> Language Class Initialized
INFO - 2020-09-09 16:52:11 --> Loader Class Initialized
INFO - 2020-09-09 16:52:11 --> Helper loaded: url_helper
INFO - 2020-09-09 16:52:11 --> Database Driver Class Initialized
INFO - 2020-09-09 16:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:52:11 --> Email Class Initialized
INFO - 2020-09-09 16:52:11 --> Controller Class Initialized
INFO - 2020-09-09 16:52:11 --> Model Class Initialized
INFO - 2020-09-09 16:52:11 --> Model Class Initialized
INFO - 2020-09-09 16:52:11 --> Final output sent to browser
DEBUG - 2020-09-09 16:52:11 --> Total execution time: 0.0448
ERROR - 2020-09-09 16:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:53:06 --> Config Class Initialized
INFO - 2020-09-09 16:53:06 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:53:06 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:53:06 --> Utf8 Class Initialized
INFO - 2020-09-09 16:53:06 --> URI Class Initialized
INFO - 2020-09-09 16:53:06 --> Router Class Initialized
INFO - 2020-09-09 16:53:06 --> Output Class Initialized
INFO - 2020-09-09 16:53:06 --> Security Class Initialized
DEBUG - 2020-09-09 16:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:53:06 --> Input Class Initialized
INFO - 2020-09-09 16:53:06 --> Language Class Initialized
INFO - 2020-09-09 16:53:06 --> Loader Class Initialized
INFO - 2020-09-09 16:53:06 --> Helper loaded: url_helper
INFO - 2020-09-09 16:53:06 --> Database Driver Class Initialized
INFO - 2020-09-09 16:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:53:06 --> Email Class Initialized
INFO - 2020-09-09 16:53:06 --> Controller Class Initialized
INFO - 2020-09-09 16:53:06 --> Model Class Initialized
INFO - 2020-09-09 16:53:06 --> Model Class Initialized
INFO - 2020-09-09 16:53:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:53:06 --> Final output sent to browser
DEBUG - 2020-09-09 16:53:06 --> Total execution time: 0.0390
ERROR - 2020-09-09 16:53:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:53:07 --> Config Class Initialized
INFO - 2020-09-09 16:53:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:53:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:53:07 --> Utf8 Class Initialized
INFO - 2020-09-09 16:53:07 --> URI Class Initialized
INFO - 2020-09-09 16:53:07 --> Router Class Initialized
INFO - 2020-09-09 16:53:07 --> Output Class Initialized
INFO - 2020-09-09 16:53:07 --> Security Class Initialized
DEBUG - 2020-09-09 16:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:53:07 --> Input Class Initialized
INFO - 2020-09-09 16:53:07 --> Language Class Initialized
INFO - 2020-09-09 16:53:07 --> Loader Class Initialized
INFO - 2020-09-09 16:53:07 --> Helper loaded: url_helper
INFO - 2020-09-09 16:53:07 --> Database Driver Class Initialized
INFO - 2020-09-09 16:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:53:07 --> Email Class Initialized
INFO - 2020-09-09 16:53:07 --> Controller Class Initialized
INFO - 2020-09-09 16:53:07 --> Model Class Initialized
INFO - 2020-09-09 16:53:07 --> Model Class Initialized
INFO - 2020-09-09 16:53:07 --> Final output sent to browser
DEBUG - 2020-09-09 16:53:07 --> Total execution time: 0.0468
ERROR - 2020-09-09 16:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:53:09 --> Config Class Initialized
INFO - 2020-09-09 16:53:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:53:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:53:09 --> Utf8 Class Initialized
INFO - 2020-09-09 16:53:09 --> URI Class Initialized
INFO - 2020-09-09 16:53:09 --> Router Class Initialized
INFO - 2020-09-09 16:53:09 --> Output Class Initialized
INFO - 2020-09-09 16:53:09 --> Security Class Initialized
DEBUG - 2020-09-09 16:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:53:09 --> Input Class Initialized
INFO - 2020-09-09 16:53:09 --> Language Class Initialized
INFO - 2020-09-09 16:53:09 --> Loader Class Initialized
INFO - 2020-09-09 16:53:09 --> Helper loaded: url_helper
INFO - 2020-09-09 16:53:09 --> Database Driver Class Initialized
INFO - 2020-09-09 16:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:53:09 --> Email Class Initialized
INFO - 2020-09-09 16:53:09 --> Controller Class Initialized
INFO - 2020-09-09 16:53:09 --> Model Class Initialized
INFO - 2020-09-09 16:53:09 --> Model Class Initialized
INFO - 2020-09-09 16:53:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:53:09 --> Final output sent to browser
DEBUG - 2020-09-09 16:53:09 --> Total execution time: 0.0428
ERROR - 2020-09-09 16:53:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:53:10 --> Config Class Initialized
INFO - 2020-09-09 16:53:10 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:53:10 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:53:10 --> Utf8 Class Initialized
INFO - 2020-09-09 16:53:10 --> URI Class Initialized
INFO - 2020-09-09 16:53:10 --> Router Class Initialized
INFO - 2020-09-09 16:53:10 --> Output Class Initialized
INFO - 2020-09-09 16:53:10 --> Security Class Initialized
DEBUG - 2020-09-09 16:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:53:10 --> Input Class Initialized
INFO - 2020-09-09 16:53:10 --> Language Class Initialized
INFO - 2020-09-09 16:53:10 --> Loader Class Initialized
INFO - 2020-09-09 16:53:10 --> Helper loaded: url_helper
INFO - 2020-09-09 16:53:10 --> Database Driver Class Initialized
INFO - 2020-09-09 16:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:53:10 --> Email Class Initialized
INFO - 2020-09-09 16:53:10 --> Controller Class Initialized
INFO - 2020-09-09 16:53:10 --> Model Class Initialized
INFO - 2020-09-09 16:53:10 --> Model Class Initialized
INFO - 2020-09-09 16:53:10 --> Final output sent to browser
DEBUG - 2020-09-09 16:53:10 --> Total execution time: 0.0405
ERROR - 2020-09-09 16:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:53:25 --> Config Class Initialized
INFO - 2020-09-09 16:53:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:53:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:53:25 --> Utf8 Class Initialized
INFO - 2020-09-09 16:53:25 --> URI Class Initialized
INFO - 2020-09-09 16:53:25 --> Router Class Initialized
INFO - 2020-09-09 16:53:25 --> Output Class Initialized
INFO - 2020-09-09 16:53:25 --> Security Class Initialized
DEBUG - 2020-09-09 16:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:53:25 --> Input Class Initialized
INFO - 2020-09-09 16:53:25 --> Language Class Initialized
INFO - 2020-09-09 16:53:25 --> Loader Class Initialized
INFO - 2020-09-09 16:53:25 --> Helper loaded: url_helper
INFO - 2020-09-09 16:53:25 --> Database Driver Class Initialized
INFO - 2020-09-09 16:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:53:25 --> Email Class Initialized
INFO - 2020-09-09 16:53:25 --> Controller Class Initialized
INFO - 2020-09-09 16:53:25 --> Model Class Initialized
INFO - 2020-09-09 16:53:25 --> Model Class Initialized
INFO - 2020-09-09 16:53:25 --> Final output sent to browser
DEBUG - 2020-09-09 16:53:25 --> Total execution time: 0.1348
ERROR - 2020-09-09 16:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:53:25 --> Config Class Initialized
INFO - 2020-09-09 16:53:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:53:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:53:25 --> Utf8 Class Initialized
INFO - 2020-09-09 16:53:25 --> URI Class Initialized
INFO - 2020-09-09 16:53:25 --> Router Class Initialized
INFO - 2020-09-09 16:53:25 --> Output Class Initialized
INFO - 2020-09-09 16:53:25 --> Security Class Initialized
DEBUG - 2020-09-09 16:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:53:25 --> Input Class Initialized
INFO - 2020-09-09 16:53:25 --> Language Class Initialized
INFO - 2020-09-09 16:53:25 --> Loader Class Initialized
INFO - 2020-09-09 16:53:25 --> Helper loaded: url_helper
INFO - 2020-09-09 16:53:25 --> Database Driver Class Initialized
INFO - 2020-09-09 16:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:53:26 --> Email Class Initialized
INFO - 2020-09-09 16:53:26 --> Controller Class Initialized
INFO - 2020-09-09 16:53:26 --> Model Class Initialized
INFO - 2020-09-09 16:53:26 --> Model Class Initialized
INFO - 2020-09-09 16:53:26 --> Final output sent to browser
DEBUG - 2020-09-09 16:53:26 --> Total execution time: 0.0445
ERROR - 2020-09-09 16:54:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:54:11 --> Config Class Initialized
INFO - 2020-09-09 16:54:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:54:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:54:11 --> Utf8 Class Initialized
INFO - 2020-09-09 16:54:11 --> URI Class Initialized
INFO - 2020-09-09 16:54:11 --> Router Class Initialized
INFO - 2020-09-09 16:54:11 --> Output Class Initialized
INFO - 2020-09-09 16:54:11 --> Security Class Initialized
DEBUG - 2020-09-09 16:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:54:11 --> Input Class Initialized
INFO - 2020-09-09 16:54:11 --> Language Class Initialized
INFO - 2020-09-09 16:54:11 --> Loader Class Initialized
INFO - 2020-09-09 16:54:11 --> Helper loaded: url_helper
INFO - 2020-09-09 16:54:11 --> Database Driver Class Initialized
INFO - 2020-09-09 16:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:54:11 --> Email Class Initialized
INFO - 2020-09-09 16:54:11 --> Controller Class Initialized
INFO - 2020-09-09 16:54:11 --> Model Class Initialized
INFO - 2020-09-09 16:54:11 --> Model Class Initialized
INFO - 2020-09-09 16:54:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:54:11 --> Final output sent to browser
DEBUG - 2020-09-09 16:54:11 --> Total execution time: 0.0382
ERROR - 2020-09-09 16:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:54:12 --> Config Class Initialized
INFO - 2020-09-09 16:54:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:54:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:54:12 --> Utf8 Class Initialized
INFO - 2020-09-09 16:54:12 --> URI Class Initialized
INFO - 2020-09-09 16:54:12 --> Router Class Initialized
INFO - 2020-09-09 16:54:12 --> Output Class Initialized
INFO - 2020-09-09 16:54:12 --> Security Class Initialized
DEBUG - 2020-09-09 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:54:12 --> Input Class Initialized
INFO - 2020-09-09 16:54:12 --> Language Class Initialized
INFO - 2020-09-09 16:54:12 --> Loader Class Initialized
INFO - 2020-09-09 16:54:12 --> Helper loaded: url_helper
INFO - 2020-09-09 16:54:12 --> Database Driver Class Initialized
INFO - 2020-09-09 16:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:54:12 --> Email Class Initialized
INFO - 2020-09-09 16:54:12 --> Controller Class Initialized
INFO - 2020-09-09 16:54:12 --> Model Class Initialized
INFO - 2020-09-09 16:54:12 --> Model Class Initialized
INFO - 2020-09-09 16:54:12 --> Final output sent to browser
DEBUG - 2020-09-09 16:54:12 --> Total execution time: 0.0400
ERROR - 2020-09-09 16:54:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:54:26 --> Config Class Initialized
INFO - 2020-09-09 16:54:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:54:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:54:26 --> Utf8 Class Initialized
INFO - 2020-09-09 16:54:26 --> URI Class Initialized
INFO - 2020-09-09 16:54:26 --> Router Class Initialized
INFO - 2020-09-09 16:54:26 --> Output Class Initialized
INFO - 2020-09-09 16:54:26 --> Security Class Initialized
DEBUG - 2020-09-09 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:54:26 --> Input Class Initialized
INFO - 2020-09-09 16:54:26 --> Language Class Initialized
INFO - 2020-09-09 16:54:26 --> Loader Class Initialized
INFO - 2020-09-09 16:54:26 --> Helper loaded: url_helper
INFO - 2020-09-09 16:54:26 --> Database Driver Class Initialized
INFO - 2020-09-09 16:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:54:26 --> Email Class Initialized
INFO - 2020-09-09 16:54:26 --> Controller Class Initialized
INFO - 2020-09-09 16:54:26 --> Model Class Initialized
INFO - 2020-09-09 16:54:26 --> Model Class Initialized
INFO - 2020-09-09 16:54:26 --> Final output sent to browser
DEBUG - 2020-09-09 16:54:26 --> Total execution time: 0.1594
ERROR - 2020-09-09 16:54:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:54:26 --> Config Class Initialized
INFO - 2020-09-09 16:54:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:54:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:54:26 --> Utf8 Class Initialized
INFO - 2020-09-09 16:54:26 --> URI Class Initialized
INFO - 2020-09-09 16:54:26 --> Router Class Initialized
INFO - 2020-09-09 16:54:26 --> Output Class Initialized
INFO - 2020-09-09 16:54:26 --> Security Class Initialized
DEBUG - 2020-09-09 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:54:26 --> Input Class Initialized
INFO - 2020-09-09 16:54:26 --> Language Class Initialized
INFO - 2020-09-09 16:54:26 --> Loader Class Initialized
INFO - 2020-09-09 16:54:26 --> Helper loaded: url_helper
INFO - 2020-09-09 16:54:26 --> Database Driver Class Initialized
INFO - 2020-09-09 16:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:54:26 --> Email Class Initialized
INFO - 2020-09-09 16:54:26 --> Controller Class Initialized
INFO - 2020-09-09 16:54:26 --> Model Class Initialized
INFO - 2020-09-09 16:54:26 --> Model Class Initialized
INFO - 2020-09-09 16:54:26 --> Final output sent to browser
DEBUG - 2020-09-09 16:54:26 --> Total execution time: 0.0478
ERROR - 2020-09-09 16:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:55:27 --> Config Class Initialized
INFO - 2020-09-09 16:55:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:55:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:55:27 --> Utf8 Class Initialized
INFO - 2020-09-09 16:55:27 --> URI Class Initialized
INFO - 2020-09-09 16:55:27 --> Router Class Initialized
INFO - 2020-09-09 16:55:27 --> Output Class Initialized
INFO - 2020-09-09 16:55:27 --> Security Class Initialized
DEBUG - 2020-09-09 16:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:55:27 --> Input Class Initialized
INFO - 2020-09-09 16:55:27 --> Language Class Initialized
INFO - 2020-09-09 16:55:27 --> Loader Class Initialized
INFO - 2020-09-09 16:55:27 --> Helper loaded: url_helper
INFO - 2020-09-09 16:55:27 --> Database Driver Class Initialized
INFO - 2020-09-09 16:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:55:27 --> Email Class Initialized
INFO - 2020-09-09 16:55:27 --> Controller Class Initialized
INFO - 2020-09-09 16:55:27 --> Model Class Initialized
INFO - 2020-09-09 16:55:27 --> Model Class Initialized
INFO - 2020-09-09 16:55:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:55:27 --> Final output sent to browser
DEBUG - 2020-09-09 16:55:27 --> Total execution time: 0.0385
ERROR - 2020-09-09 16:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:55:28 --> Config Class Initialized
INFO - 2020-09-09 16:55:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:55:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:55:28 --> Utf8 Class Initialized
INFO - 2020-09-09 16:55:28 --> URI Class Initialized
INFO - 2020-09-09 16:55:28 --> Router Class Initialized
INFO - 2020-09-09 16:55:28 --> Output Class Initialized
INFO - 2020-09-09 16:55:28 --> Security Class Initialized
DEBUG - 2020-09-09 16:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:55:28 --> Input Class Initialized
INFO - 2020-09-09 16:55:28 --> Language Class Initialized
INFO - 2020-09-09 16:55:28 --> Loader Class Initialized
INFO - 2020-09-09 16:55:28 --> Helper loaded: url_helper
INFO - 2020-09-09 16:55:28 --> Database Driver Class Initialized
INFO - 2020-09-09 16:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:55:28 --> Email Class Initialized
INFO - 2020-09-09 16:55:28 --> Controller Class Initialized
INFO - 2020-09-09 16:55:28 --> Model Class Initialized
INFO - 2020-09-09 16:55:28 --> Model Class Initialized
INFO - 2020-09-09 16:55:28 --> Final output sent to browser
DEBUG - 2020-09-09 16:55:28 --> Total execution time: 0.0336
ERROR - 2020-09-09 16:55:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:55:34 --> Config Class Initialized
INFO - 2020-09-09 16:55:34 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:55:34 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:55:34 --> Utf8 Class Initialized
INFO - 2020-09-09 16:55:34 --> URI Class Initialized
INFO - 2020-09-09 16:55:34 --> Router Class Initialized
INFO - 2020-09-09 16:55:34 --> Output Class Initialized
INFO - 2020-09-09 16:55:34 --> Security Class Initialized
DEBUG - 2020-09-09 16:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:55:34 --> Input Class Initialized
INFO - 2020-09-09 16:55:34 --> Language Class Initialized
INFO - 2020-09-09 16:55:34 --> Loader Class Initialized
INFO - 2020-09-09 16:55:34 --> Helper loaded: url_helper
INFO - 2020-09-09 16:55:34 --> Database Driver Class Initialized
INFO - 2020-09-09 16:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:55:34 --> Email Class Initialized
INFO - 2020-09-09 16:55:34 --> Controller Class Initialized
INFO - 2020-09-09 16:55:34 --> Model Class Initialized
INFO - 2020-09-09 16:55:34 --> Model Class Initialized
INFO - 2020-09-09 16:55:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:55:34 --> Final output sent to browser
DEBUG - 2020-09-09 16:55:34 --> Total execution time: 0.0370
ERROR - 2020-09-09 16:55:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:55:34 --> Config Class Initialized
INFO - 2020-09-09 16:55:34 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:55:34 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:55:34 --> Utf8 Class Initialized
INFO - 2020-09-09 16:55:34 --> URI Class Initialized
INFO - 2020-09-09 16:55:34 --> Router Class Initialized
INFO - 2020-09-09 16:55:34 --> Output Class Initialized
INFO - 2020-09-09 16:55:34 --> Security Class Initialized
DEBUG - 2020-09-09 16:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:55:34 --> Input Class Initialized
INFO - 2020-09-09 16:55:34 --> Language Class Initialized
INFO - 2020-09-09 16:55:34 --> Loader Class Initialized
INFO - 2020-09-09 16:55:34 --> Helper loaded: url_helper
INFO - 2020-09-09 16:55:34 --> Database Driver Class Initialized
INFO - 2020-09-09 16:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:55:34 --> Email Class Initialized
INFO - 2020-09-09 16:55:34 --> Controller Class Initialized
INFO - 2020-09-09 16:55:34 --> Model Class Initialized
INFO - 2020-09-09 16:55:34 --> Model Class Initialized
INFO - 2020-09-09 16:55:34 --> Final output sent to browser
DEBUG - 2020-09-09 16:55:34 --> Total execution time: 0.0401
ERROR - 2020-09-09 16:55:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:55:37 --> Config Class Initialized
INFO - 2020-09-09 16:55:37 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:55:37 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:55:37 --> Utf8 Class Initialized
INFO - 2020-09-09 16:55:37 --> URI Class Initialized
INFO - 2020-09-09 16:55:37 --> Router Class Initialized
INFO - 2020-09-09 16:55:37 --> Output Class Initialized
INFO - 2020-09-09 16:55:37 --> Security Class Initialized
DEBUG - 2020-09-09 16:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:55:37 --> Input Class Initialized
INFO - 2020-09-09 16:55:37 --> Language Class Initialized
INFO - 2020-09-09 16:55:37 --> Loader Class Initialized
INFO - 2020-09-09 16:55:37 --> Helper loaded: url_helper
INFO - 2020-09-09 16:55:37 --> Database Driver Class Initialized
INFO - 2020-09-09 16:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:55:37 --> Email Class Initialized
INFO - 2020-09-09 16:55:37 --> Controller Class Initialized
INFO - 2020-09-09 16:55:37 --> Model Class Initialized
INFO - 2020-09-09 16:55:37 --> Model Class Initialized
INFO - 2020-09-09 16:55:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:55:37 --> Final output sent to browser
DEBUG - 2020-09-09 16:55:37 --> Total execution time: 0.0385
ERROR - 2020-09-09 16:55:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:55:38 --> Config Class Initialized
INFO - 2020-09-09 16:55:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:55:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:55:38 --> Utf8 Class Initialized
INFO - 2020-09-09 16:55:38 --> URI Class Initialized
INFO - 2020-09-09 16:55:38 --> Router Class Initialized
INFO - 2020-09-09 16:55:38 --> Output Class Initialized
INFO - 2020-09-09 16:55:38 --> Security Class Initialized
DEBUG - 2020-09-09 16:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:55:38 --> Input Class Initialized
INFO - 2020-09-09 16:55:38 --> Language Class Initialized
INFO - 2020-09-09 16:55:38 --> Loader Class Initialized
INFO - 2020-09-09 16:55:38 --> Helper loaded: url_helper
INFO - 2020-09-09 16:55:38 --> Database Driver Class Initialized
INFO - 2020-09-09 16:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:55:38 --> Email Class Initialized
INFO - 2020-09-09 16:55:38 --> Controller Class Initialized
INFO - 2020-09-09 16:55:38 --> Model Class Initialized
INFO - 2020-09-09 16:55:38 --> Model Class Initialized
INFO - 2020-09-09 16:55:38 --> Final output sent to browser
DEBUG - 2020-09-09 16:55:38 --> Total execution time: 0.0454
ERROR - 2020-09-09 16:57:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:57:30 --> Config Class Initialized
INFO - 2020-09-09 16:57:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:57:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:57:30 --> Utf8 Class Initialized
INFO - 2020-09-09 16:57:30 --> URI Class Initialized
INFO - 2020-09-09 16:57:30 --> Router Class Initialized
INFO - 2020-09-09 16:57:30 --> Output Class Initialized
INFO - 2020-09-09 16:57:30 --> Security Class Initialized
DEBUG - 2020-09-09 16:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:57:30 --> Input Class Initialized
INFO - 2020-09-09 16:57:30 --> Language Class Initialized
INFO - 2020-09-09 16:57:30 --> Loader Class Initialized
INFO - 2020-09-09 16:57:30 --> Helper loaded: url_helper
INFO - 2020-09-09 16:57:30 --> Database Driver Class Initialized
INFO - 2020-09-09 16:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:57:30 --> Email Class Initialized
INFO - 2020-09-09 16:57:30 --> Controller Class Initialized
INFO - 2020-09-09 16:57:30 --> Model Class Initialized
INFO - 2020-09-09 16:57:30 --> Model Class Initialized
INFO - 2020-09-09 16:57:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:57:30 --> Final output sent to browser
DEBUG - 2020-09-09 16:57:30 --> Total execution time: 0.0837
ERROR - 2020-09-09 16:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:57:32 --> Config Class Initialized
INFO - 2020-09-09 16:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:57:32 --> Utf8 Class Initialized
INFO - 2020-09-09 16:57:32 --> URI Class Initialized
INFO - 2020-09-09 16:57:32 --> Router Class Initialized
INFO - 2020-09-09 16:57:32 --> Output Class Initialized
INFO - 2020-09-09 16:57:32 --> Security Class Initialized
DEBUG - 2020-09-09 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:57:32 --> Input Class Initialized
INFO - 2020-09-09 16:57:32 --> Language Class Initialized
INFO - 2020-09-09 16:57:32 --> Loader Class Initialized
INFO - 2020-09-09 16:57:32 --> Helper loaded: url_helper
INFO - 2020-09-09 16:57:32 --> Database Driver Class Initialized
INFO - 2020-09-09 16:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:57:32 --> Email Class Initialized
INFO - 2020-09-09 16:57:32 --> Controller Class Initialized
INFO - 2020-09-09 16:57:32 --> Model Class Initialized
INFO - 2020-09-09 16:57:32 --> Model Class Initialized
INFO - 2020-09-09 16:57:32 --> Final output sent to browser
DEBUG - 2020-09-09 16:57:32 --> Total execution time: 0.0412
ERROR - 2020-09-09 16:58:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:58:57 --> Config Class Initialized
INFO - 2020-09-09 16:58:57 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:58:57 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:58:57 --> Utf8 Class Initialized
INFO - 2020-09-09 16:58:57 --> URI Class Initialized
INFO - 2020-09-09 16:58:57 --> Router Class Initialized
INFO - 2020-09-09 16:58:57 --> Output Class Initialized
INFO - 2020-09-09 16:58:57 --> Security Class Initialized
DEBUG - 2020-09-09 16:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:58:57 --> Input Class Initialized
INFO - 2020-09-09 16:58:57 --> Language Class Initialized
INFO - 2020-09-09 16:58:57 --> Loader Class Initialized
INFO - 2020-09-09 16:58:57 --> Helper loaded: url_helper
INFO - 2020-09-09 16:58:57 --> Database Driver Class Initialized
INFO - 2020-09-09 16:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:58:57 --> Email Class Initialized
INFO - 2020-09-09 16:58:57 --> Controller Class Initialized
INFO - 2020-09-09 16:58:57 --> Model Class Initialized
INFO - 2020-09-09 16:58:57 --> Model Class Initialized
INFO - 2020-09-09 16:58:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:58:57 --> Final output sent to browser
DEBUG - 2020-09-09 16:58:57 --> Total execution time: 0.0394
ERROR - 2020-09-09 16:58:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:58:58 --> Config Class Initialized
INFO - 2020-09-09 16:58:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:58:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:58:58 --> Utf8 Class Initialized
INFO - 2020-09-09 16:58:58 --> URI Class Initialized
INFO - 2020-09-09 16:58:58 --> Router Class Initialized
INFO - 2020-09-09 16:58:58 --> Output Class Initialized
INFO - 2020-09-09 16:58:58 --> Security Class Initialized
DEBUG - 2020-09-09 16:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:58:58 --> Input Class Initialized
INFO - 2020-09-09 16:58:58 --> Language Class Initialized
INFO - 2020-09-09 16:58:58 --> Loader Class Initialized
INFO - 2020-09-09 16:58:58 --> Helper loaded: url_helper
INFO - 2020-09-09 16:58:58 --> Database Driver Class Initialized
INFO - 2020-09-09 16:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:58:58 --> Email Class Initialized
INFO - 2020-09-09 16:58:58 --> Controller Class Initialized
INFO - 2020-09-09 16:58:58 --> Model Class Initialized
INFO - 2020-09-09 16:58:58 --> Model Class Initialized
INFO - 2020-09-09 16:58:58 --> Final output sent to browser
DEBUG - 2020-09-09 16:58:58 --> Total execution time: 0.0432
ERROR - 2020-09-09 16:59:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:59:00 --> Config Class Initialized
INFO - 2020-09-09 16:59:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:59:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:59:00 --> Utf8 Class Initialized
INFO - 2020-09-09 16:59:00 --> URI Class Initialized
INFO - 2020-09-09 16:59:00 --> Router Class Initialized
INFO - 2020-09-09 16:59:00 --> Output Class Initialized
INFO - 2020-09-09 16:59:00 --> Security Class Initialized
DEBUG - 2020-09-09 16:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:59:00 --> Input Class Initialized
INFO - 2020-09-09 16:59:00 --> Language Class Initialized
INFO - 2020-09-09 16:59:00 --> Loader Class Initialized
INFO - 2020-09-09 16:59:00 --> Helper loaded: url_helper
INFO - 2020-09-09 16:59:00 --> Database Driver Class Initialized
INFO - 2020-09-09 16:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:59:00 --> Email Class Initialized
INFO - 2020-09-09 16:59:00 --> Controller Class Initialized
INFO - 2020-09-09 16:59:00 --> Model Class Initialized
INFO - 2020-09-09 16:59:00 --> Model Class Initialized
INFO - 2020-09-09 16:59:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:59:00 --> Final output sent to browser
DEBUG - 2020-09-09 16:59:00 --> Total execution time: 0.0368
ERROR - 2020-09-09 16:59:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:59:01 --> Config Class Initialized
INFO - 2020-09-09 16:59:01 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:59:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:59:01 --> Utf8 Class Initialized
INFO - 2020-09-09 16:59:01 --> URI Class Initialized
INFO - 2020-09-09 16:59:01 --> Router Class Initialized
INFO - 2020-09-09 16:59:01 --> Output Class Initialized
INFO - 2020-09-09 16:59:01 --> Security Class Initialized
DEBUG - 2020-09-09 16:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:59:01 --> Input Class Initialized
INFO - 2020-09-09 16:59:01 --> Language Class Initialized
INFO - 2020-09-09 16:59:01 --> Loader Class Initialized
INFO - 2020-09-09 16:59:01 --> Helper loaded: url_helper
INFO - 2020-09-09 16:59:01 --> Database Driver Class Initialized
INFO - 2020-09-09 16:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:59:01 --> Email Class Initialized
INFO - 2020-09-09 16:59:01 --> Controller Class Initialized
INFO - 2020-09-09 16:59:01 --> Model Class Initialized
INFO - 2020-09-09 16:59:01 --> Model Class Initialized
INFO - 2020-09-09 16:59:01 --> Final output sent to browser
DEBUG - 2020-09-09 16:59:01 --> Total execution time: 0.0409
ERROR - 2020-09-09 16:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:59:05 --> Config Class Initialized
INFO - 2020-09-09 16:59:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:59:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:59:05 --> Utf8 Class Initialized
INFO - 2020-09-09 16:59:05 --> URI Class Initialized
INFO - 2020-09-09 16:59:05 --> Router Class Initialized
INFO - 2020-09-09 16:59:05 --> Output Class Initialized
INFO - 2020-09-09 16:59:05 --> Security Class Initialized
DEBUG - 2020-09-09 16:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:59:05 --> Input Class Initialized
INFO - 2020-09-09 16:59:05 --> Language Class Initialized
INFO - 2020-09-09 16:59:05 --> Loader Class Initialized
INFO - 2020-09-09 16:59:05 --> Helper loaded: url_helper
INFO - 2020-09-09 16:59:05 --> Database Driver Class Initialized
INFO - 2020-09-09 16:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:59:05 --> Email Class Initialized
INFO - 2020-09-09 16:59:05 --> Controller Class Initialized
INFO - 2020-09-09 16:59:05 --> Model Class Initialized
INFO - 2020-09-09 16:59:05 --> Model Class Initialized
INFO - 2020-09-09 16:59:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 16:59:05 --> Final output sent to browser
DEBUG - 2020-09-09 16:59:05 --> Total execution time: 0.0334
ERROR - 2020-09-09 16:59:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:59:05 --> Config Class Initialized
INFO - 2020-09-09 16:59:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:59:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:59:05 --> Utf8 Class Initialized
INFO - 2020-09-09 16:59:05 --> URI Class Initialized
INFO - 2020-09-09 16:59:05 --> Router Class Initialized
INFO - 2020-09-09 16:59:05 --> Output Class Initialized
INFO - 2020-09-09 16:59:05 --> Security Class Initialized
DEBUG - 2020-09-09 16:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:59:05 --> Input Class Initialized
INFO - 2020-09-09 16:59:05 --> Language Class Initialized
INFO - 2020-09-09 16:59:05 --> Loader Class Initialized
INFO - 2020-09-09 16:59:05 --> Helper loaded: url_helper
INFO - 2020-09-09 16:59:05 --> Database Driver Class Initialized
INFO - 2020-09-09 16:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:59:05 --> Email Class Initialized
INFO - 2020-09-09 16:59:05 --> Controller Class Initialized
INFO - 2020-09-09 16:59:05 --> Model Class Initialized
INFO - 2020-09-09 16:59:05 --> Model Class Initialized
INFO - 2020-09-09 16:59:05 --> Final output sent to browser
DEBUG - 2020-09-09 16:59:05 --> Total execution time: 0.0364
ERROR - 2020-09-09 16:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:59:12 --> Config Class Initialized
INFO - 2020-09-09 16:59:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:59:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:59:12 --> Utf8 Class Initialized
INFO - 2020-09-09 16:59:12 --> URI Class Initialized
INFO - 2020-09-09 16:59:12 --> Router Class Initialized
INFO - 2020-09-09 16:59:12 --> Output Class Initialized
INFO - 2020-09-09 16:59:12 --> Security Class Initialized
DEBUG - 2020-09-09 16:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:59:12 --> Input Class Initialized
INFO - 2020-09-09 16:59:12 --> Language Class Initialized
INFO - 2020-09-09 16:59:12 --> Loader Class Initialized
INFO - 2020-09-09 16:59:12 --> Helper loaded: url_helper
INFO - 2020-09-09 16:59:12 --> Database Driver Class Initialized
INFO - 2020-09-09 16:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:59:12 --> Email Class Initialized
INFO - 2020-09-09 16:59:12 --> Controller Class Initialized
INFO - 2020-09-09 16:59:12 --> Model Class Initialized
INFO - 2020-09-09 16:59:12 --> Model Class Initialized
INFO - 2020-09-09 16:59:13 --> Final output sent to browser
DEBUG - 2020-09-09 16:59:13 --> Total execution time: 0.1714
ERROR - 2020-09-09 16:59:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 16:59:13 --> Config Class Initialized
INFO - 2020-09-09 16:59:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 16:59:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 16:59:13 --> Utf8 Class Initialized
INFO - 2020-09-09 16:59:13 --> URI Class Initialized
INFO - 2020-09-09 16:59:13 --> Router Class Initialized
INFO - 2020-09-09 16:59:13 --> Output Class Initialized
INFO - 2020-09-09 16:59:13 --> Security Class Initialized
DEBUG - 2020-09-09 16:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 16:59:13 --> Input Class Initialized
INFO - 2020-09-09 16:59:13 --> Language Class Initialized
INFO - 2020-09-09 16:59:13 --> Loader Class Initialized
INFO - 2020-09-09 16:59:13 --> Helper loaded: url_helper
INFO - 2020-09-09 16:59:13 --> Database Driver Class Initialized
INFO - 2020-09-09 16:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 16:59:13 --> Email Class Initialized
INFO - 2020-09-09 16:59:13 --> Controller Class Initialized
INFO - 2020-09-09 16:59:13 --> Model Class Initialized
INFO - 2020-09-09 16:59:13 --> Model Class Initialized
INFO - 2020-09-09 16:59:13 --> Final output sent to browser
DEBUG - 2020-09-09 16:59:13 --> Total execution time: 0.0427
ERROR - 2020-09-09 17:00:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:00:26 --> Config Class Initialized
INFO - 2020-09-09 17:00:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:00:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:00:26 --> Utf8 Class Initialized
INFO - 2020-09-09 17:00:26 --> URI Class Initialized
INFO - 2020-09-09 17:00:26 --> Router Class Initialized
INFO - 2020-09-09 17:00:26 --> Output Class Initialized
INFO - 2020-09-09 17:00:26 --> Security Class Initialized
DEBUG - 2020-09-09 17:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:00:26 --> Input Class Initialized
INFO - 2020-09-09 17:00:26 --> Language Class Initialized
INFO - 2020-09-09 17:00:26 --> Loader Class Initialized
INFO - 2020-09-09 17:00:26 --> Helper loaded: url_helper
INFO - 2020-09-09 17:00:26 --> Database Driver Class Initialized
INFO - 2020-09-09 17:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:00:26 --> Email Class Initialized
INFO - 2020-09-09 17:00:26 --> Controller Class Initialized
INFO - 2020-09-09 17:00:26 --> Model Class Initialized
INFO - 2020-09-09 17:00:26 --> Model Class Initialized
INFO - 2020-09-09 17:00:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:00:26 --> Final output sent to browser
DEBUG - 2020-09-09 17:00:26 --> Total execution time: 0.0416
ERROR - 2020-09-09 17:00:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:00:27 --> Config Class Initialized
INFO - 2020-09-09 17:00:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:00:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:00:27 --> Utf8 Class Initialized
INFO - 2020-09-09 17:00:27 --> URI Class Initialized
INFO - 2020-09-09 17:00:27 --> Router Class Initialized
INFO - 2020-09-09 17:00:27 --> Output Class Initialized
INFO - 2020-09-09 17:00:27 --> Security Class Initialized
DEBUG - 2020-09-09 17:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:00:27 --> Input Class Initialized
INFO - 2020-09-09 17:00:27 --> Language Class Initialized
INFO - 2020-09-09 17:00:27 --> Loader Class Initialized
INFO - 2020-09-09 17:00:27 --> Helper loaded: url_helper
INFO - 2020-09-09 17:00:27 --> Database Driver Class Initialized
INFO - 2020-09-09 17:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:00:27 --> Email Class Initialized
INFO - 2020-09-09 17:00:27 --> Controller Class Initialized
INFO - 2020-09-09 17:00:27 --> Model Class Initialized
INFO - 2020-09-09 17:00:27 --> Model Class Initialized
ERROR - 2020-09-09 17:00:27 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /home/purpu1ex/public_html/carsm/application/controllers/Excel_import.php 174
INFO - 2020-09-09 17:00:27 --> Final output sent to browser
DEBUG - 2020-09-09 17:00:27 --> Total execution time: 0.0371
ERROR - 2020-09-09 17:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:00:55 --> Config Class Initialized
INFO - 2020-09-09 17:00:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:00:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:00:55 --> Utf8 Class Initialized
INFO - 2020-09-09 17:00:55 --> URI Class Initialized
INFO - 2020-09-09 17:00:55 --> Router Class Initialized
INFO - 2020-09-09 17:00:55 --> Output Class Initialized
INFO - 2020-09-09 17:00:55 --> Security Class Initialized
DEBUG - 2020-09-09 17:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:00:55 --> Input Class Initialized
INFO - 2020-09-09 17:00:55 --> Language Class Initialized
INFO - 2020-09-09 17:00:55 --> Loader Class Initialized
INFO - 2020-09-09 17:00:55 --> Helper loaded: url_helper
INFO - 2020-09-09 17:00:55 --> Database Driver Class Initialized
INFO - 2020-09-09 17:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:00:55 --> Email Class Initialized
INFO - 2020-09-09 17:00:55 --> Controller Class Initialized
INFO - 2020-09-09 17:00:55 --> Model Class Initialized
INFO - 2020-09-09 17:00:55 --> Model Class Initialized
INFO - 2020-09-09 17:00:55 --> Final output sent to browser
DEBUG - 2020-09-09 17:00:55 --> Total execution time: 0.1169
ERROR - 2020-09-09 17:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:00:55 --> Config Class Initialized
INFO - 2020-09-09 17:00:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:00:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:00:55 --> Utf8 Class Initialized
INFO - 2020-09-09 17:00:55 --> URI Class Initialized
INFO - 2020-09-09 17:00:55 --> Router Class Initialized
INFO - 2020-09-09 17:00:55 --> Output Class Initialized
INFO - 2020-09-09 17:00:55 --> Security Class Initialized
DEBUG - 2020-09-09 17:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:00:55 --> Input Class Initialized
INFO - 2020-09-09 17:00:55 --> Language Class Initialized
INFO - 2020-09-09 17:00:55 --> Loader Class Initialized
INFO - 2020-09-09 17:00:55 --> Helper loaded: url_helper
INFO - 2020-09-09 17:00:55 --> Database Driver Class Initialized
INFO - 2020-09-09 17:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:00:55 --> Email Class Initialized
INFO - 2020-09-09 17:00:55 --> Controller Class Initialized
INFO - 2020-09-09 17:00:55 --> Model Class Initialized
INFO - 2020-09-09 17:00:55 --> Model Class Initialized
ERROR - 2020-09-09 17:00:55 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string /home/purpu1ex/public_html/carsm/application/controllers/Excel_import.php 174
INFO - 2020-09-09 17:00:55 --> Final output sent to browser
DEBUG - 2020-09-09 17:00:55 --> Total execution time: 0.0402
ERROR - 2020-09-09 17:01:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:01:59 --> Config Class Initialized
INFO - 2020-09-09 17:01:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:01:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:01:59 --> Utf8 Class Initialized
INFO - 2020-09-09 17:01:59 --> URI Class Initialized
INFO - 2020-09-09 17:01:59 --> Router Class Initialized
INFO - 2020-09-09 17:01:59 --> Output Class Initialized
INFO - 2020-09-09 17:01:59 --> Security Class Initialized
DEBUG - 2020-09-09 17:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:01:59 --> Input Class Initialized
INFO - 2020-09-09 17:01:59 --> Language Class Initialized
INFO - 2020-09-09 17:01:59 --> Loader Class Initialized
INFO - 2020-09-09 17:01:59 --> Helper loaded: url_helper
INFO - 2020-09-09 17:01:59 --> Database Driver Class Initialized
INFO - 2020-09-09 17:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:01:59 --> Email Class Initialized
INFO - 2020-09-09 17:01:59 --> Controller Class Initialized
INFO - 2020-09-09 17:01:59 --> Model Class Initialized
INFO - 2020-09-09 17:01:59 --> Model Class Initialized
INFO - 2020-09-09 17:01:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:01:59 --> Final output sent to browser
DEBUG - 2020-09-09 17:01:59 --> Total execution time: 0.0371
ERROR - 2020-09-09 17:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:02:00 --> Config Class Initialized
INFO - 2020-09-09 17:02:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:02:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:02:00 --> Utf8 Class Initialized
INFO - 2020-09-09 17:02:00 --> URI Class Initialized
INFO - 2020-09-09 17:02:00 --> Router Class Initialized
INFO - 2020-09-09 17:02:00 --> Output Class Initialized
INFO - 2020-09-09 17:02:00 --> Security Class Initialized
DEBUG - 2020-09-09 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:02:00 --> Input Class Initialized
INFO - 2020-09-09 17:02:00 --> Language Class Initialized
INFO - 2020-09-09 17:02:00 --> Loader Class Initialized
INFO - 2020-09-09 17:02:00 --> Helper loaded: url_helper
INFO - 2020-09-09 17:02:00 --> Database Driver Class Initialized
INFO - 2020-09-09 17:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:02:00 --> Email Class Initialized
INFO - 2020-09-09 17:02:00 --> Controller Class Initialized
INFO - 2020-09-09 17:02:00 --> Model Class Initialized
INFO - 2020-09-09 17:02:00 --> Model Class Initialized
INFO - 2020-09-09 17:02:00 --> Final output sent to browser
DEBUG - 2020-09-09 17:02:00 --> Total execution time: 0.0403
ERROR - 2020-09-09 17:02:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:02:11 --> Config Class Initialized
INFO - 2020-09-09 17:02:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:02:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:02:11 --> Utf8 Class Initialized
INFO - 2020-09-09 17:02:11 --> URI Class Initialized
INFO - 2020-09-09 17:02:11 --> Router Class Initialized
INFO - 2020-09-09 17:02:11 --> Output Class Initialized
INFO - 2020-09-09 17:02:11 --> Security Class Initialized
DEBUG - 2020-09-09 17:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:02:11 --> Input Class Initialized
INFO - 2020-09-09 17:02:11 --> Language Class Initialized
INFO - 2020-09-09 17:02:11 --> Loader Class Initialized
INFO - 2020-09-09 17:02:11 --> Helper loaded: url_helper
INFO - 2020-09-09 17:02:11 --> Database Driver Class Initialized
INFO - 2020-09-09 17:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:02:11 --> Email Class Initialized
INFO - 2020-09-09 17:02:11 --> Controller Class Initialized
INFO - 2020-09-09 17:02:11 --> Model Class Initialized
INFO - 2020-09-09 17:02:11 --> Model Class Initialized
INFO - 2020-09-09 17:02:11 --> Final output sent to browser
DEBUG - 2020-09-09 17:02:11 --> Total execution time: 0.1166
ERROR - 2020-09-09 17:02:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:02:12 --> Config Class Initialized
INFO - 2020-09-09 17:02:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:02:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:02:12 --> Utf8 Class Initialized
INFO - 2020-09-09 17:02:12 --> URI Class Initialized
INFO - 2020-09-09 17:02:12 --> Router Class Initialized
INFO - 2020-09-09 17:02:12 --> Output Class Initialized
INFO - 2020-09-09 17:02:12 --> Security Class Initialized
DEBUG - 2020-09-09 17:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:02:12 --> Input Class Initialized
INFO - 2020-09-09 17:02:12 --> Language Class Initialized
INFO - 2020-09-09 17:02:12 --> Loader Class Initialized
INFO - 2020-09-09 17:02:12 --> Helper loaded: url_helper
INFO - 2020-09-09 17:02:12 --> Database Driver Class Initialized
INFO - 2020-09-09 17:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:02:12 --> Email Class Initialized
INFO - 2020-09-09 17:02:12 --> Controller Class Initialized
INFO - 2020-09-09 17:02:12 --> Model Class Initialized
INFO - 2020-09-09 17:02:12 --> Model Class Initialized
INFO - 2020-09-09 17:02:12 --> Final output sent to browser
DEBUG - 2020-09-09 17:02:12 --> Total execution time: 0.0373
ERROR - 2020-09-09 17:04:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:04:05 --> Config Class Initialized
INFO - 2020-09-09 17:04:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:04:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:04:05 --> Utf8 Class Initialized
INFO - 2020-09-09 17:04:05 --> URI Class Initialized
INFO - 2020-09-09 17:04:05 --> Router Class Initialized
INFO - 2020-09-09 17:04:05 --> Output Class Initialized
INFO - 2020-09-09 17:04:05 --> Security Class Initialized
DEBUG - 2020-09-09 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:04:05 --> Input Class Initialized
INFO - 2020-09-09 17:04:05 --> Language Class Initialized
INFO - 2020-09-09 17:04:05 --> Loader Class Initialized
INFO - 2020-09-09 17:04:05 --> Helper loaded: url_helper
INFO - 2020-09-09 17:04:05 --> Database Driver Class Initialized
INFO - 2020-09-09 17:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:04:05 --> Email Class Initialized
INFO - 2020-09-09 17:04:05 --> Controller Class Initialized
INFO - 2020-09-09 17:04:05 --> Model Class Initialized
INFO - 2020-09-09 17:04:05 --> Model Class Initialized
INFO - 2020-09-09 17:04:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:04:05 --> Final output sent to browser
DEBUG - 2020-09-09 17:04:05 --> Total execution time: 0.0409
ERROR - 2020-09-09 17:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:04:06 --> Config Class Initialized
INFO - 2020-09-09 17:04:06 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:04:06 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:04:06 --> Utf8 Class Initialized
INFO - 2020-09-09 17:04:06 --> URI Class Initialized
INFO - 2020-09-09 17:04:06 --> Router Class Initialized
INFO - 2020-09-09 17:04:06 --> Output Class Initialized
INFO - 2020-09-09 17:04:06 --> Security Class Initialized
DEBUG - 2020-09-09 17:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:04:06 --> Input Class Initialized
INFO - 2020-09-09 17:04:06 --> Language Class Initialized
INFO - 2020-09-09 17:04:06 --> Loader Class Initialized
INFO - 2020-09-09 17:04:06 --> Helper loaded: url_helper
INFO - 2020-09-09 17:04:06 --> Database Driver Class Initialized
INFO - 2020-09-09 17:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:04:06 --> Email Class Initialized
INFO - 2020-09-09 17:04:06 --> Controller Class Initialized
INFO - 2020-09-09 17:04:06 --> Model Class Initialized
INFO - 2020-09-09 17:04:06 --> Model Class Initialized
INFO - 2020-09-09 17:04:06 --> Final output sent to browser
DEBUG - 2020-09-09 17:04:06 --> Total execution time: 0.0362
ERROR - 2020-09-09 17:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:04:13 --> Config Class Initialized
INFO - 2020-09-09 17:04:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:04:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:04:13 --> Utf8 Class Initialized
INFO - 2020-09-09 17:04:13 --> URI Class Initialized
INFO - 2020-09-09 17:04:13 --> Router Class Initialized
INFO - 2020-09-09 17:04:13 --> Output Class Initialized
INFO - 2020-09-09 17:04:13 --> Security Class Initialized
DEBUG - 2020-09-09 17:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:04:13 --> Input Class Initialized
INFO - 2020-09-09 17:04:13 --> Language Class Initialized
INFO - 2020-09-09 17:04:13 --> Loader Class Initialized
INFO - 2020-09-09 17:04:13 --> Helper loaded: url_helper
INFO - 2020-09-09 17:04:13 --> Database Driver Class Initialized
INFO - 2020-09-09 17:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:04:13 --> Email Class Initialized
INFO - 2020-09-09 17:04:13 --> Controller Class Initialized
INFO - 2020-09-09 17:04:13 --> Model Class Initialized
INFO - 2020-09-09 17:04:13 --> Model Class Initialized
INFO - 2020-09-09 17:04:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:04:13 --> Final output sent to browser
DEBUG - 2020-09-09 17:04:13 --> Total execution time: 0.1059
ERROR - 2020-09-09 17:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:04:14 --> Config Class Initialized
INFO - 2020-09-09 17:04:14 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:04:14 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:04:14 --> Utf8 Class Initialized
INFO - 2020-09-09 17:04:14 --> URI Class Initialized
INFO - 2020-09-09 17:04:14 --> Router Class Initialized
INFO - 2020-09-09 17:04:14 --> Output Class Initialized
INFO - 2020-09-09 17:04:14 --> Security Class Initialized
DEBUG - 2020-09-09 17:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:04:14 --> Input Class Initialized
INFO - 2020-09-09 17:04:14 --> Language Class Initialized
INFO - 2020-09-09 17:04:14 --> Loader Class Initialized
INFO - 2020-09-09 17:04:14 --> Helper loaded: url_helper
INFO - 2020-09-09 17:04:14 --> Database Driver Class Initialized
INFO - 2020-09-09 17:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:04:14 --> Email Class Initialized
INFO - 2020-09-09 17:04:14 --> Controller Class Initialized
INFO - 2020-09-09 17:04:14 --> Model Class Initialized
INFO - 2020-09-09 17:04:14 --> Model Class Initialized
INFO - 2020-09-09 17:04:14 --> Final output sent to browser
DEBUG - 2020-09-09 17:04:14 --> Total execution time: 0.0411
ERROR - 2020-09-09 17:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:05:08 --> Config Class Initialized
INFO - 2020-09-09 17:05:08 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:05:08 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:05:08 --> Utf8 Class Initialized
INFO - 2020-09-09 17:05:08 --> URI Class Initialized
INFO - 2020-09-09 17:05:08 --> Router Class Initialized
INFO - 2020-09-09 17:05:08 --> Output Class Initialized
INFO - 2020-09-09 17:05:08 --> Security Class Initialized
DEBUG - 2020-09-09 17:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:05:08 --> Input Class Initialized
INFO - 2020-09-09 17:05:08 --> Language Class Initialized
INFO - 2020-09-09 17:05:08 --> Loader Class Initialized
INFO - 2020-09-09 17:05:08 --> Helper loaded: url_helper
INFO - 2020-09-09 17:05:08 --> Database Driver Class Initialized
INFO - 2020-09-09 17:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:05:08 --> Email Class Initialized
INFO - 2020-09-09 17:05:08 --> Controller Class Initialized
INFO - 2020-09-09 17:05:08 --> Model Class Initialized
INFO - 2020-09-09 17:05:08 --> Model Class Initialized
INFO - 2020-09-09 17:05:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:05:08 --> Final output sent to browser
DEBUG - 2020-09-09 17:05:08 --> Total execution time: 0.1081
ERROR - 2020-09-09 17:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:05:09 --> Config Class Initialized
INFO - 2020-09-09 17:05:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:05:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:05:09 --> Utf8 Class Initialized
INFO - 2020-09-09 17:05:09 --> URI Class Initialized
INFO - 2020-09-09 17:05:09 --> Router Class Initialized
INFO - 2020-09-09 17:05:09 --> Output Class Initialized
INFO - 2020-09-09 17:05:09 --> Security Class Initialized
DEBUG - 2020-09-09 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:05:09 --> Input Class Initialized
INFO - 2020-09-09 17:05:09 --> Language Class Initialized
INFO - 2020-09-09 17:05:09 --> Loader Class Initialized
INFO - 2020-09-09 17:05:09 --> Helper loaded: url_helper
INFO - 2020-09-09 17:05:09 --> Database Driver Class Initialized
INFO - 2020-09-09 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:05:09 --> Email Class Initialized
INFO - 2020-09-09 17:05:09 --> Controller Class Initialized
INFO - 2020-09-09 17:05:09 --> Model Class Initialized
INFO - 2020-09-09 17:05:09 --> Model Class Initialized
INFO - 2020-09-09 17:05:09 --> Final output sent to browser
DEBUG - 2020-09-09 17:05:09 --> Total execution time: 0.0485
ERROR - 2020-09-09 17:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:05:19 --> Config Class Initialized
INFO - 2020-09-09 17:05:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:05:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:05:19 --> Utf8 Class Initialized
INFO - 2020-09-09 17:05:19 --> URI Class Initialized
INFO - 2020-09-09 17:05:19 --> Router Class Initialized
INFO - 2020-09-09 17:05:19 --> Output Class Initialized
INFO - 2020-09-09 17:05:19 --> Security Class Initialized
DEBUG - 2020-09-09 17:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:05:19 --> Input Class Initialized
INFO - 2020-09-09 17:05:19 --> Language Class Initialized
INFO - 2020-09-09 17:05:19 --> Loader Class Initialized
INFO - 2020-09-09 17:05:19 --> Helper loaded: url_helper
INFO - 2020-09-09 17:05:19 --> Database Driver Class Initialized
INFO - 2020-09-09 17:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:05:19 --> Email Class Initialized
INFO - 2020-09-09 17:05:19 --> Controller Class Initialized
INFO - 2020-09-09 17:05:19 --> Model Class Initialized
INFO - 2020-09-09 17:05:19 --> Model Class Initialized
INFO - 2020-09-09 17:05:19 --> Final output sent to browser
DEBUG - 2020-09-09 17:05:19 --> Total execution time: 0.1302
ERROR - 2020-09-09 17:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:05:19 --> Config Class Initialized
INFO - 2020-09-09 17:05:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:05:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:05:19 --> Utf8 Class Initialized
INFO - 2020-09-09 17:05:19 --> URI Class Initialized
INFO - 2020-09-09 17:05:19 --> Router Class Initialized
INFO - 2020-09-09 17:05:19 --> Output Class Initialized
INFO - 2020-09-09 17:05:19 --> Security Class Initialized
DEBUG - 2020-09-09 17:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:05:19 --> Input Class Initialized
INFO - 2020-09-09 17:05:19 --> Language Class Initialized
INFO - 2020-09-09 17:05:19 --> Loader Class Initialized
INFO - 2020-09-09 17:05:19 --> Helper loaded: url_helper
INFO - 2020-09-09 17:05:19 --> Database Driver Class Initialized
INFO - 2020-09-09 17:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:05:20 --> Email Class Initialized
INFO - 2020-09-09 17:05:20 --> Controller Class Initialized
INFO - 2020-09-09 17:05:20 --> Model Class Initialized
INFO - 2020-09-09 17:05:20 --> Model Class Initialized
INFO - 2020-09-09 17:05:20 --> Final output sent to browser
DEBUG - 2020-09-09 17:05:20 --> Total execution time: 0.0412
ERROR - 2020-09-09 17:06:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:06:33 --> Config Class Initialized
INFO - 2020-09-09 17:06:33 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:06:33 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:06:33 --> Utf8 Class Initialized
INFO - 2020-09-09 17:06:33 --> URI Class Initialized
INFO - 2020-09-09 17:06:33 --> Router Class Initialized
INFO - 2020-09-09 17:06:33 --> Output Class Initialized
INFO - 2020-09-09 17:06:33 --> Security Class Initialized
DEBUG - 2020-09-09 17:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:06:33 --> Input Class Initialized
INFO - 2020-09-09 17:06:33 --> Language Class Initialized
INFO - 2020-09-09 17:06:33 --> Loader Class Initialized
INFO - 2020-09-09 17:06:33 --> Helper loaded: url_helper
INFO - 2020-09-09 17:06:33 --> Database Driver Class Initialized
INFO - 2020-09-09 17:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:06:33 --> Email Class Initialized
INFO - 2020-09-09 17:06:33 --> Controller Class Initialized
INFO - 2020-09-09 17:06:33 --> Model Class Initialized
INFO - 2020-09-09 17:06:33 --> Model Class Initialized
INFO - 2020-09-09 17:06:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:06:33 --> Final output sent to browser
DEBUG - 2020-09-09 17:06:33 --> Total execution time: 0.0838
ERROR - 2020-09-09 17:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:06:35 --> Config Class Initialized
INFO - 2020-09-09 17:06:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:06:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:06:35 --> Utf8 Class Initialized
INFO - 2020-09-09 17:06:35 --> URI Class Initialized
INFO - 2020-09-09 17:06:35 --> Router Class Initialized
INFO - 2020-09-09 17:06:35 --> Output Class Initialized
INFO - 2020-09-09 17:06:35 --> Security Class Initialized
DEBUG - 2020-09-09 17:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:06:35 --> Input Class Initialized
INFO - 2020-09-09 17:06:35 --> Language Class Initialized
INFO - 2020-09-09 17:06:35 --> Loader Class Initialized
INFO - 2020-09-09 17:06:35 --> Helper loaded: url_helper
INFO - 2020-09-09 17:06:35 --> Database Driver Class Initialized
INFO - 2020-09-09 17:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:06:35 --> Email Class Initialized
INFO - 2020-09-09 17:06:35 --> Controller Class Initialized
INFO - 2020-09-09 17:06:35 --> Model Class Initialized
INFO - 2020-09-09 17:06:35 --> Model Class Initialized
INFO - 2020-09-09 17:06:35 --> Final output sent to browser
DEBUG - 2020-09-09 17:06:35 --> Total execution time: 0.0431
ERROR - 2020-09-09 17:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:06:52 --> Config Class Initialized
INFO - 2020-09-09 17:06:52 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:06:52 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:06:52 --> Utf8 Class Initialized
INFO - 2020-09-09 17:06:52 --> URI Class Initialized
INFO - 2020-09-09 17:06:52 --> Router Class Initialized
INFO - 2020-09-09 17:06:52 --> Output Class Initialized
INFO - 2020-09-09 17:06:52 --> Security Class Initialized
DEBUG - 2020-09-09 17:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:06:52 --> Input Class Initialized
INFO - 2020-09-09 17:06:52 --> Language Class Initialized
INFO - 2020-09-09 17:06:52 --> Loader Class Initialized
INFO - 2020-09-09 17:06:52 --> Helper loaded: url_helper
INFO - 2020-09-09 17:06:52 --> Database Driver Class Initialized
INFO - 2020-09-09 17:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:06:52 --> Email Class Initialized
INFO - 2020-09-09 17:06:52 --> Controller Class Initialized
INFO - 2020-09-09 17:06:52 --> Model Class Initialized
INFO - 2020-09-09 17:06:52 --> Model Class Initialized
INFO - 2020-09-09 17:06:52 --> Final output sent to browser
DEBUG - 2020-09-09 17:06:52 --> Total execution time: 0.1367
ERROR - 2020-09-09 17:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:06:53 --> Config Class Initialized
INFO - 2020-09-09 17:06:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:06:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:06:53 --> Utf8 Class Initialized
INFO - 2020-09-09 17:06:53 --> URI Class Initialized
INFO - 2020-09-09 17:06:53 --> Router Class Initialized
INFO - 2020-09-09 17:06:53 --> Output Class Initialized
INFO - 2020-09-09 17:06:53 --> Security Class Initialized
DEBUG - 2020-09-09 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:06:53 --> Input Class Initialized
INFO - 2020-09-09 17:06:53 --> Language Class Initialized
INFO - 2020-09-09 17:06:53 --> Loader Class Initialized
INFO - 2020-09-09 17:06:53 --> Helper loaded: url_helper
INFO - 2020-09-09 17:06:53 --> Database Driver Class Initialized
INFO - 2020-09-09 17:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:06:53 --> Email Class Initialized
INFO - 2020-09-09 17:06:53 --> Controller Class Initialized
INFO - 2020-09-09 17:06:53 --> Model Class Initialized
INFO - 2020-09-09 17:06:53 --> Model Class Initialized
INFO - 2020-09-09 17:06:53 --> Final output sent to browser
DEBUG - 2020-09-09 17:06:53 --> Total execution time: 0.1097
ERROR - 2020-09-09 17:08:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:08:24 --> Config Class Initialized
INFO - 2020-09-09 17:08:24 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:08:24 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:08:24 --> Utf8 Class Initialized
INFO - 2020-09-09 17:08:24 --> URI Class Initialized
INFO - 2020-09-09 17:08:24 --> Router Class Initialized
INFO - 2020-09-09 17:08:24 --> Output Class Initialized
INFO - 2020-09-09 17:08:24 --> Security Class Initialized
DEBUG - 2020-09-09 17:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:08:24 --> Input Class Initialized
INFO - 2020-09-09 17:08:24 --> Language Class Initialized
INFO - 2020-09-09 17:08:24 --> Loader Class Initialized
INFO - 2020-09-09 17:08:24 --> Helper loaded: url_helper
INFO - 2020-09-09 17:08:24 --> Database Driver Class Initialized
INFO - 2020-09-09 17:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:08:24 --> Email Class Initialized
INFO - 2020-09-09 17:08:24 --> Controller Class Initialized
INFO - 2020-09-09 17:08:24 --> Model Class Initialized
INFO - 2020-09-09 17:08:24 --> Model Class Initialized
INFO - 2020-09-09 17:08:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:08:24 --> Final output sent to browser
DEBUG - 2020-09-09 17:08:24 --> Total execution time: 0.0818
ERROR - 2020-09-09 17:08:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:08:25 --> Config Class Initialized
INFO - 2020-09-09 17:08:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:08:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:08:25 --> Utf8 Class Initialized
INFO - 2020-09-09 17:08:25 --> URI Class Initialized
INFO - 2020-09-09 17:08:25 --> Router Class Initialized
INFO - 2020-09-09 17:08:25 --> Output Class Initialized
INFO - 2020-09-09 17:08:25 --> Security Class Initialized
DEBUG - 2020-09-09 17:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:08:25 --> Input Class Initialized
INFO - 2020-09-09 17:08:25 --> Language Class Initialized
INFO - 2020-09-09 17:08:25 --> Loader Class Initialized
INFO - 2020-09-09 17:08:25 --> Helper loaded: url_helper
INFO - 2020-09-09 17:08:25 --> Database Driver Class Initialized
INFO - 2020-09-09 17:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:08:25 --> Email Class Initialized
INFO - 2020-09-09 17:08:25 --> Controller Class Initialized
INFO - 2020-09-09 17:08:25 --> Model Class Initialized
INFO - 2020-09-09 17:08:25 --> Model Class Initialized
INFO - 2020-09-09 17:08:25 --> Final output sent to browser
DEBUG - 2020-09-09 17:08:25 --> Total execution time: 0.0445
ERROR - 2020-09-09 17:08:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:08:45 --> Config Class Initialized
INFO - 2020-09-09 17:08:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:08:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:08:45 --> Utf8 Class Initialized
INFO - 2020-09-09 17:08:45 --> URI Class Initialized
INFO - 2020-09-09 17:08:45 --> Router Class Initialized
INFO - 2020-09-09 17:08:45 --> Output Class Initialized
INFO - 2020-09-09 17:08:45 --> Security Class Initialized
DEBUG - 2020-09-09 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:08:45 --> Input Class Initialized
INFO - 2020-09-09 17:08:45 --> Language Class Initialized
INFO - 2020-09-09 17:08:45 --> Loader Class Initialized
INFO - 2020-09-09 17:08:45 --> Helper loaded: url_helper
INFO - 2020-09-09 17:08:45 --> Database Driver Class Initialized
INFO - 2020-09-09 17:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:08:45 --> Email Class Initialized
INFO - 2020-09-09 17:08:45 --> Controller Class Initialized
INFO - 2020-09-09 17:08:45 --> Model Class Initialized
INFO - 2020-09-09 17:08:45 --> Model Class Initialized
INFO - 2020-09-09 17:08:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:08:45 --> Final output sent to browser
DEBUG - 2020-09-09 17:08:45 --> Total execution time: 0.1179
ERROR - 2020-09-09 17:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:08:46 --> Config Class Initialized
INFO - 2020-09-09 17:08:46 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:08:46 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:08:46 --> Utf8 Class Initialized
INFO - 2020-09-09 17:08:46 --> URI Class Initialized
INFO - 2020-09-09 17:08:46 --> Router Class Initialized
INFO - 2020-09-09 17:08:46 --> Output Class Initialized
INFO - 2020-09-09 17:08:46 --> Security Class Initialized
DEBUG - 2020-09-09 17:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:08:46 --> Input Class Initialized
INFO - 2020-09-09 17:08:46 --> Language Class Initialized
INFO - 2020-09-09 17:08:46 --> Loader Class Initialized
INFO - 2020-09-09 17:08:46 --> Helper loaded: url_helper
INFO - 2020-09-09 17:08:46 --> Database Driver Class Initialized
INFO - 2020-09-09 17:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:08:46 --> Email Class Initialized
INFO - 2020-09-09 17:08:46 --> Controller Class Initialized
INFO - 2020-09-09 17:08:46 --> Model Class Initialized
INFO - 2020-09-09 17:08:46 --> Model Class Initialized
INFO - 2020-09-09 17:08:46 --> Final output sent to browser
DEBUG - 2020-09-09 17:08:46 --> Total execution time: 0.0381
ERROR - 2020-09-09 17:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:10:19 --> Config Class Initialized
INFO - 2020-09-09 17:10:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:10:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:10:19 --> Utf8 Class Initialized
INFO - 2020-09-09 17:10:19 --> URI Class Initialized
INFO - 2020-09-09 17:10:19 --> Router Class Initialized
INFO - 2020-09-09 17:10:19 --> Output Class Initialized
INFO - 2020-09-09 17:10:19 --> Security Class Initialized
DEBUG - 2020-09-09 17:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:10:19 --> Input Class Initialized
INFO - 2020-09-09 17:10:19 --> Language Class Initialized
INFO - 2020-09-09 17:10:19 --> Loader Class Initialized
INFO - 2020-09-09 17:10:19 --> Helper loaded: url_helper
INFO - 2020-09-09 17:10:19 --> Database Driver Class Initialized
INFO - 2020-09-09 17:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:10:19 --> Email Class Initialized
INFO - 2020-09-09 17:10:19 --> Controller Class Initialized
INFO - 2020-09-09 17:10:19 --> Model Class Initialized
INFO - 2020-09-09 17:10:19 --> Model Class Initialized
INFO - 2020-09-09 17:10:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:10:19 --> Final output sent to browser
DEBUG - 2020-09-09 17:10:19 --> Total execution time: 0.0411
ERROR - 2020-09-09 17:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:10:20 --> Config Class Initialized
INFO - 2020-09-09 17:10:20 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:10:20 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:10:20 --> Utf8 Class Initialized
INFO - 2020-09-09 17:10:20 --> URI Class Initialized
INFO - 2020-09-09 17:10:20 --> Router Class Initialized
INFO - 2020-09-09 17:10:20 --> Output Class Initialized
INFO - 2020-09-09 17:10:20 --> Security Class Initialized
DEBUG - 2020-09-09 17:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:10:20 --> Input Class Initialized
INFO - 2020-09-09 17:10:20 --> Language Class Initialized
INFO - 2020-09-09 17:10:20 --> Loader Class Initialized
INFO - 2020-09-09 17:10:20 --> Helper loaded: url_helper
INFO - 2020-09-09 17:10:20 --> Database Driver Class Initialized
INFO - 2020-09-09 17:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:10:20 --> Email Class Initialized
INFO - 2020-09-09 17:10:20 --> Controller Class Initialized
INFO - 2020-09-09 17:10:20 --> Model Class Initialized
INFO - 2020-09-09 17:10:20 --> Model Class Initialized
INFO - 2020-09-09 17:10:20 --> Final output sent to browser
DEBUG - 2020-09-09 17:10:20 --> Total execution time: 0.0380
ERROR - 2020-09-09 17:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:17:24 --> Config Class Initialized
INFO - 2020-09-09 17:17:24 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:17:24 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:17:24 --> Utf8 Class Initialized
INFO - 2020-09-09 17:17:24 --> URI Class Initialized
INFO - 2020-09-09 17:17:24 --> Router Class Initialized
INFO - 2020-09-09 17:17:24 --> Output Class Initialized
INFO - 2020-09-09 17:17:24 --> Security Class Initialized
DEBUG - 2020-09-09 17:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:17:24 --> Input Class Initialized
INFO - 2020-09-09 17:17:24 --> Language Class Initialized
INFO - 2020-09-09 17:17:24 --> Loader Class Initialized
INFO - 2020-09-09 17:17:24 --> Helper loaded: url_helper
INFO - 2020-09-09 17:17:24 --> Database Driver Class Initialized
INFO - 2020-09-09 17:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:17:24 --> Email Class Initialized
INFO - 2020-09-09 17:17:24 --> Controller Class Initialized
INFO - 2020-09-09 17:17:24 --> Model Class Initialized
INFO - 2020-09-09 17:17:24 --> Model Class Initialized
INFO - 2020-09-09 17:17:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:17:24 --> Final output sent to browser
DEBUG - 2020-09-09 17:17:24 --> Total execution time: 0.0402
ERROR - 2020-09-09 17:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:17:26 --> Config Class Initialized
INFO - 2020-09-09 17:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:17:26 --> Utf8 Class Initialized
INFO - 2020-09-09 17:17:26 --> URI Class Initialized
INFO - 2020-09-09 17:17:26 --> Router Class Initialized
INFO - 2020-09-09 17:17:26 --> Output Class Initialized
INFO - 2020-09-09 17:17:26 --> Security Class Initialized
DEBUG - 2020-09-09 17:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:17:26 --> Input Class Initialized
INFO - 2020-09-09 17:17:26 --> Language Class Initialized
INFO - 2020-09-09 17:17:26 --> Loader Class Initialized
INFO - 2020-09-09 17:17:26 --> Helper loaded: url_helper
INFO - 2020-09-09 17:17:26 --> Database Driver Class Initialized
INFO - 2020-09-09 17:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:17:26 --> Email Class Initialized
INFO - 2020-09-09 17:17:26 --> Controller Class Initialized
INFO - 2020-09-09 17:17:26 --> Model Class Initialized
INFO - 2020-09-09 17:17:26 --> Model Class Initialized
INFO - 2020-09-09 17:17:26 --> Final output sent to browser
DEBUG - 2020-09-09 17:17:26 --> Total execution time: 0.0423
ERROR - 2020-09-09 17:23:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:21 --> Config Class Initialized
INFO - 2020-09-09 17:23:21 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:21 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:21 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:21 --> URI Class Initialized
INFO - 2020-09-09 17:23:21 --> Router Class Initialized
INFO - 2020-09-09 17:23:21 --> Output Class Initialized
INFO - 2020-09-09 17:23:21 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:21 --> Input Class Initialized
INFO - 2020-09-09 17:23:21 --> Language Class Initialized
INFO - 2020-09-09 17:23:21 --> Loader Class Initialized
INFO - 2020-09-09 17:23:21 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:21 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:21 --> Email Class Initialized
INFO - 2020-09-09 17:23:21 --> Controller Class Initialized
INFO - 2020-09-09 17:23:21 --> Model Class Initialized
INFO - 2020-09-09 17:23:21 --> Model Class Initialized
INFO - 2020-09-09 17:23:21 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:21 --> Total execution time: 0.1665
ERROR - 2020-09-09 17:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:22 --> Config Class Initialized
INFO - 2020-09-09 17:23:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:22 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:22 --> URI Class Initialized
INFO - 2020-09-09 17:23:22 --> Router Class Initialized
INFO - 2020-09-09 17:23:22 --> Output Class Initialized
INFO - 2020-09-09 17:23:22 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:22 --> Input Class Initialized
INFO - 2020-09-09 17:23:22 --> Language Class Initialized
INFO - 2020-09-09 17:23:22 --> Loader Class Initialized
INFO - 2020-09-09 17:23:22 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:22 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:22 --> Email Class Initialized
INFO - 2020-09-09 17:23:22 --> Controller Class Initialized
INFO - 2020-09-09 17:23:22 --> Model Class Initialized
INFO - 2020-09-09 17:23:22 --> Model Class Initialized
INFO - 2020-09-09 17:23:22 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:22 --> Total execution time: 0.0561
ERROR - 2020-09-09 17:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:28 --> Config Class Initialized
INFO - 2020-09-09 17:23:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:28 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:28 --> URI Class Initialized
INFO - 2020-09-09 17:23:28 --> Router Class Initialized
INFO - 2020-09-09 17:23:28 --> Output Class Initialized
INFO - 2020-09-09 17:23:28 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:28 --> Input Class Initialized
INFO - 2020-09-09 17:23:28 --> Language Class Initialized
INFO - 2020-09-09 17:23:28 --> Loader Class Initialized
INFO - 2020-09-09 17:23:28 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:28 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:28 --> Email Class Initialized
INFO - 2020-09-09 17:23:28 --> Controller Class Initialized
INFO - 2020-09-09 17:23:28 --> Model Class Initialized
INFO - 2020-09-09 17:23:28 --> Model Class Initialized
INFO - 2020-09-09 17:23:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:23:28 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:28 --> Total execution time: 0.0394
ERROR - 2020-09-09 17:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:29 --> Config Class Initialized
INFO - 2020-09-09 17:23:29 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:29 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:29 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:29 --> URI Class Initialized
INFO - 2020-09-09 17:23:29 --> Router Class Initialized
INFO - 2020-09-09 17:23:29 --> Output Class Initialized
INFO - 2020-09-09 17:23:29 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:29 --> Input Class Initialized
INFO - 2020-09-09 17:23:29 --> Language Class Initialized
INFO - 2020-09-09 17:23:29 --> Loader Class Initialized
INFO - 2020-09-09 17:23:29 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:29 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:29 --> Email Class Initialized
INFO - 2020-09-09 17:23:29 --> Controller Class Initialized
INFO - 2020-09-09 17:23:29 --> Model Class Initialized
INFO - 2020-09-09 17:23:29 --> Model Class Initialized
INFO - 2020-09-09 17:23:29 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:29 --> Total execution time: 0.0454
ERROR - 2020-09-09 17:23:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:41 --> Config Class Initialized
INFO - 2020-09-09 17:23:41 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:41 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:41 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:41 --> URI Class Initialized
INFO - 2020-09-09 17:23:41 --> Router Class Initialized
INFO - 2020-09-09 17:23:41 --> Output Class Initialized
INFO - 2020-09-09 17:23:41 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:41 --> Input Class Initialized
INFO - 2020-09-09 17:23:41 --> Language Class Initialized
INFO - 2020-09-09 17:23:41 --> Loader Class Initialized
INFO - 2020-09-09 17:23:41 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:41 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:41 --> Email Class Initialized
INFO - 2020-09-09 17:23:41 --> Controller Class Initialized
INFO - 2020-09-09 17:23:41 --> Model Class Initialized
INFO - 2020-09-09 17:23:41 --> Model Class Initialized
INFO - 2020-09-09 17:23:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:23:41 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:41 --> Total execution time: 0.0947
ERROR - 2020-09-09 17:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:42 --> Config Class Initialized
INFO - 2020-09-09 17:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:42 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:42 --> URI Class Initialized
INFO - 2020-09-09 17:23:42 --> Router Class Initialized
INFO - 2020-09-09 17:23:42 --> Output Class Initialized
INFO - 2020-09-09 17:23:42 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:42 --> Input Class Initialized
INFO - 2020-09-09 17:23:42 --> Language Class Initialized
INFO - 2020-09-09 17:23:42 --> Loader Class Initialized
INFO - 2020-09-09 17:23:42 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:42 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:42 --> Email Class Initialized
INFO - 2020-09-09 17:23:42 --> Controller Class Initialized
INFO - 2020-09-09 17:23:42 --> Model Class Initialized
INFO - 2020-09-09 17:23:42 --> Model Class Initialized
INFO - 2020-09-09 17:23:42 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:42 --> Total execution time: 0.0384
ERROR - 2020-09-09 17:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:53 --> Config Class Initialized
INFO - 2020-09-09 17:23:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:53 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:53 --> URI Class Initialized
INFO - 2020-09-09 17:23:53 --> Router Class Initialized
INFO - 2020-09-09 17:23:53 --> Output Class Initialized
INFO - 2020-09-09 17:23:53 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:53 --> Input Class Initialized
INFO - 2020-09-09 17:23:53 --> Language Class Initialized
INFO - 2020-09-09 17:23:53 --> Loader Class Initialized
INFO - 2020-09-09 17:23:53 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:53 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:53 --> Email Class Initialized
INFO - 2020-09-09 17:23:53 --> Controller Class Initialized
INFO - 2020-09-09 17:23:53 --> Model Class Initialized
INFO - 2020-09-09 17:23:53 --> Model Class Initialized
INFO - 2020-09-09 17:23:53 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:53 --> Total execution time: 0.1187
ERROR - 2020-09-09 17:23:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:23:53 --> Config Class Initialized
INFO - 2020-09-09 17:23:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:23:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:23:53 --> Utf8 Class Initialized
INFO - 2020-09-09 17:23:53 --> URI Class Initialized
INFO - 2020-09-09 17:23:53 --> Router Class Initialized
INFO - 2020-09-09 17:23:53 --> Output Class Initialized
INFO - 2020-09-09 17:23:53 --> Security Class Initialized
DEBUG - 2020-09-09 17:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:23:53 --> Input Class Initialized
INFO - 2020-09-09 17:23:53 --> Language Class Initialized
INFO - 2020-09-09 17:23:53 --> Loader Class Initialized
INFO - 2020-09-09 17:23:53 --> Helper loaded: url_helper
INFO - 2020-09-09 17:23:53 --> Database Driver Class Initialized
INFO - 2020-09-09 17:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:23:53 --> Email Class Initialized
INFO - 2020-09-09 17:23:53 --> Controller Class Initialized
INFO - 2020-09-09 17:23:53 --> Model Class Initialized
INFO - 2020-09-09 17:23:53 --> Model Class Initialized
INFO - 2020-09-09 17:23:53 --> Final output sent to browser
DEBUG - 2020-09-09 17:23:53 --> Total execution time: 0.0350
ERROR - 2020-09-09 17:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:24:00 --> Config Class Initialized
INFO - 2020-09-09 17:24:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:24:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:24:00 --> Utf8 Class Initialized
INFO - 2020-09-09 17:24:00 --> URI Class Initialized
INFO - 2020-09-09 17:24:00 --> Router Class Initialized
INFO - 2020-09-09 17:24:00 --> Output Class Initialized
INFO - 2020-09-09 17:24:00 --> Security Class Initialized
DEBUG - 2020-09-09 17:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:24:00 --> Input Class Initialized
INFO - 2020-09-09 17:24:00 --> Language Class Initialized
INFO - 2020-09-09 17:24:00 --> Loader Class Initialized
INFO - 2020-09-09 17:24:00 --> Helper loaded: url_helper
INFO - 2020-09-09 17:24:00 --> Database Driver Class Initialized
INFO - 2020-09-09 17:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:24:00 --> Email Class Initialized
INFO - 2020-09-09 17:24:00 --> Controller Class Initialized
INFO - 2020-09-09 17:24:00 --> Model Class Initialized
INFO - 2020-09-09 17:24:00 --> Model Class Initialized
INFO - 2020-09-09 17:24:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:24:00 --> Final output sent to browser
DEBUG - 2020-09-09 17:24:00 --> Total execution time: 0.0436
ERROR - 2020-09-09 17:24:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:24:00 --> Config Class Initialized
INFO - 2020-09-09 17:24:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:24:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:24:01 --> Utf8 Class Initialized
INFO - 2020-09-09 17:24:01 --> URI Class Initialized
INFO - 2020-09-09 17:24:01 --> Router Class Initialized
INFO - 2020-09-09 17:24:01 --> Output Class Initialized
INFO - 2020-09-09 17:24:01 --> Security Class Initialized
DEBUG - 2020-09-09 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:24:01 --> Input Class Initialized
INFO - 2020-09-09 17:24:01 --> Language Class Initialized
INFO - 2020-09-09 17:24:01 --> Loader Class Initialized
INFO - 2020-09-09 17:24:01 --> Helper loaded: url_helper
INFO - 2020-09-09 17:24:01 --> Database Driver Class Initialized
INFO - 2020-09-09 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:24:01 --> Email Class Initialized
INFO - 2020-09-09 17:24:01 --> Controller Class Initialized
INFO - 2020-09-09 17:24:01 --> Model Class Initialized
INFO - 2020-09-09 17:24:01 --> Model Class Initialized
INFO - 2020-09-09 17:24:01 --> Final output sent to browser
DEBUG - 2020-09-09 17:24:01 --> Total execution time: 0.0441
ERROR - 2020-09-09 17:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:24:06 --> Config Class Initialized
INFO - 2020-09-09 17:24:06 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:24:06 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:24:06 --> Utf8 Class Initialized
INFO - 2020-09-09 17:24:06 --> URI Class Initialized
INFO - 2020-09-09 17:24:06 --> Router Class Initialized
INFO - 2020-09-09 17:24:06 --> Output Class Initialized
INFO - 2020-09-09 17:24:06 --> Security Class Initialized
DEBUG - 2020-09-09 17:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:24:06 --> Input Class Initialized
INFO - 2020-09-09 17:24:06 --> Language Class Initialized
INFO - 2020-09-09 17:24:06 --> Loader Class Initialized
INFO - 2020-09-09 17:24:06 --> Helper loaded: url_helper
INFO - 2020-09-09 17:24:06 --> Database Driver Class Initialized
INFO - 2020-09-09 17:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:24:06 --> Email Class Initialized
INFO - 2020-09-09 17:24:06 --> Controller Class Initialized
INFO - 2020-09-09 17:24:06 --> Model Class Initialized
INFO - 2020-09-09 17:24:06 --> Model Class Initialized
INFO - 2020-09-09 17:24:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:24:06 --> Final output sent to browser
DEBUG - 2020-09-09 17:24:06 --> Total execution time: 0.0955
ERROR - 2020-09-09 17:24:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:24:07 --> Config Class Initialized
INFO - 2020-09-09 17:24:07 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:24:07 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:24:07 --> Utf8 Class Initialized
INFO - 2020-09-09 17:24:07 --> URI Class Initialized
INFO - 2020-09-09 17:24:07 --> Router Class Initialized
INFO - 2020-09-09 17:24:07 --> Output Class Initialized
INFO - 2020-09-09 17:24:07 --> Security Class Initialized
DEBUG - 2020-09-09 17:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:24:07 --> Input Class Initialized
INFO - 2020-09-09 17:24:07 --> Language Class Initialized
INFO - 2020-09-09 17:24:07 --> Loader Class Initialized
INFO - 2020-09-09 17:24:07 --> Helper loaded: url_helper
INFO - 2020-09-09 17:24:07 --> Database Driver Class Initialized
INFO - 2020-09-09 17:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:24:07 --> Email Class Initialized
INFO - 2020-09-09 17:24:07 --> Controller Class Initialized
INFO - 2020-09-09 17:24:07 --> Model Class Initialized
INFO - 2020-09-09 17:24:07 --> Model Class Initialized
INFO - 2020-09-09 17:24:07 --> Final output sent to browser
DEBUG - 2020-09-09 17:24:07 --> Total execution time: 0.0565
ERROR - 2020-09-09 17:24:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:24:16 --> Config Class Initialized
INFO - 2020-09-09 17:24:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:24:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:24:16 --> Utf8 Class Initialized
INFO - 2020-09-09 17:24:16 --> URI Class Initialized
INFO - 2020-09-09 17:24:16 --> Router Class Initialized
INFO - 2020-09-09 17:24:16 --> Output Class Initialized
INFO - 2020-09-09 17:24:16 --> Security Class Initialized
DEBUG - 2020-09-09 17:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:24:16 --> Input Class Initialized
INFO - 2020-09-09 17:24:16 --> Language Class Initialized
INFO - 2020-09-09 17:24:16 --> Loader Class Initialized
INFO - 2020-09-09 17:24:16 --> Helper loaded: url_helper
INFO - 2020-09-09 17:24:16 --> Database Driver Class Initialized
INFO - 2020-09-09 17:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:24:16 --> Email Class Initialized
INFO - 2020-09-09 17:24:16 --> Controller Class Initialized
INFO - 2020-09-09 17:24:16 --> Model Class Initialized
INFO - 2020-09-09 17:24:16 --> Model Class Initialized
INFO - 2020-09-09 17:24:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:24:16 --> Final output sent to browser
DEBUG - 2020-09-09 17:24:16 --> Total execution time: 0.0616
ERROR - 2020-09-09 17:24:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:24:17 --> Config Class Initialized
INFO - 2020-09-09 17:24:17 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:24:17 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:24:17 --> Utf8 Class Initialized
INFO - 2020-09-09 17:24:17 --> URI Class Initialized
INFO - 2020-09-09 17:24:17 --> Router Class Initialized
INFO - 2020-09-09 17:24:17 --> Output Class Initialized
INFO - 2020-09-09 17:24:17 --> Security Class Initialized
DEBUG - 2020-09-09 17:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:24:17 --> Input Class Initialized
INFO - 2020-09-09 17:24:17 --> Language Class Initialized
INFO - 2020-09-09 17:24:17 --> Loader Class Initialized
INFO - 2020-09-09 17:24:17 --> Helper loaded: url_helper
INFO - 2020-09-09 17:24:17 --> Database Driver Class Initialized
INFO - 2020-09-09 17:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:24:17 --> Email Class Initialized
INFO - 2020-09-09 17:24:17 --> Controller Class Initialized
INFO - 2020-09-09 17:24:17 --> Model Class Initialized
INFO - 2020-09-09 17:24:17 --> Model Class Initialized
INFO - 2020-09-09 17:24:17 --> Final output sent to browser
DEBUG - 2020-09-09 17:24:17 --> Total execution time: 0.0461
ERROR - 2020-09-09 17:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:16 --> Config Class Initialized
INFO - 2020-09-09 17:25:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:16 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:16 --> URI Class Initialized
INFO - 2020-09-09 17:25:16 --> Router Class Initialized
INFO - 2020-09-09 17:25:16 --> Output Class Initialized
INFO - 2020-09-09 17:25:16 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:16 --> Input Class Initialized
INFO - 2020-09-09 17:25:16 --> Language Class Initialized
INFO - 2020-09-09 17:25:16 --> Loader Class Initialized
INFO - 2020-09-09 17:25:16 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:16 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:16 --> Email Class Initialized
INFO - 2020-09-09 17:25:16 --> Controller Class Initialized
INFO - 2020-09-09 17:25:16 --> Model Class Initialized
INFO - 2020-09-09 17:25:16 --> Model Class Initialized
INFO - 2020-09-09 17:25:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:25:16 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:16 --> Total execution time: 0.0392
ERROR - 2020-09-09 17:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:16 --> Config Class Initialized
INFO - 2020-09-09 17:25:16 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:16 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:16 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:16 --> URI Class Initialized
INFO - 2020-09-09 17:25:16 --> Router Class Initialized
INFO - 2020-09-09 17:25:16 --> Output Class Initialized
INFO - 2020-09-09 17:25:16 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:16 --> Input Class Initialized
INFO - 2020-09-09 17:25:16 --> Language Class Initialized
INFO - 2020-09-09 17:25:16 --> Loader Class Initialized
INFO - 2020-09-09 17:25:16 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:16 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:16 --> Email Class Initialized
INFO - 2020-09-09 17:25:16 --> Controller Class Initialized
INFO - 2020-09-09 17:25:16 --> Model Class Initialized
INFO - 2020-09-09 17:25:16 --> Model Class Initialized
INFO - 2020-09-09 17:25:16 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:16 --> Total execution time: 0.0425
ERROR - 2020-09-09 17:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:22 --> Config Class Initialized
INFO - 2020-09-09 17:25:22 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:22 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:22 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:22 --> URI Class Initialized
INFO - 2020-09-09 17:25:22 --> Router Class Initialized
INFO - 2020-09-09 17:25:22 --> Output Class Initialized
INFO - 2020-09-09 17:25:22 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:22 --> Input Class Initialized
INFO - 2020-09-09 17:25:22 --> Language Class Initialized
INFO - 2020-09-09 17:25:22 --> Loader Class Initialized
INFO - 2020-09-09 17:25:22 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:22 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:22 --> Email Class Initialized
INFO - 2020-09-09 17:25:22 --> Controller Class Initialized
INFO - 2020-09-09 17:25:22 --> Model Class Initialized
INFO - 2020-09-09 17:25:22 --> Model Class Initialized
INFO - 2020-09-09 17:25:22 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:22 --> Total execution time: 0.1290
ERROR - 2020-09-09 17:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:23 --> Config Class Initialized
INFO - 2020-09-09 17:25:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:23 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:23 --> URI Class Initialized
INFO - 2020-09-09 17:25:23 --> Router Class Initialized
INFO - 2020-09-09 17:25:23 --> Output Class Initialized
INFO - 2020-09-09 17:25:23 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:23 --> Input Class Initialized
INFO - 2020-09-09 17:25:23 --> Language Class Initialized
INFO - 2020-09-09 17:25:23 --> Loader Class Initialized
INFO - 2020-09-09 17:25:23 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:23 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:23 --> Email Class Initialized
INFO - 2020-09-09 17:25:23 --> Controller Class Initialized
INFO - 2020-09-09 17:25:23 --> Model Class Initialized
INFO - 2020-09-09 17:25:23 --> Model Class Initialized
INFO - 2020-09-09 17:25:23 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:23 --> Total execution time: 0.0476
ERROR - 2020-09-09 17:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:27 --> Config Class Initialized
INFO - 2020-09-09 17:25:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:27 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:27 --> URI Class Initialized
INFO - 2020-09-09 17:25:27 --> Router Class Initialized
INFO - 2020-09-09 17:25:27 --> Output Class Initialized
INFO - 2020-09-09 17:25:27 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:27 --> Input Class Initialized
INFO - 2020-09-09 17:25:27 --> Language Class Initialized
INFO - 2020-09-09 17:25:27 --> Loader Class Initialized
INFO - 2020-09-09 17:25:27 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:27 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:27 --> Email Class Initialized
INFO - 2020-09-09 17:25:27 --> Controller Class Initialized
INFO - 2020-09-09 17:25:27 --> Model Class Initialized
INFO - 2020-09-09 17:25:27 --> Model Class Initialized
INFO - 2020-09-09 17:25:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:25:27 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:27 --> Total execution time: 0.0366
ERROR - 2020-09-09 17:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:28 --> Config Class Initialized
INFO - 2020-09-09 17:25:28 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:28 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:28 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:28 --> URI Class Initialized
INFO - 2020-09-09 17:25:28 --> Router Class Initialized
INFO - 2020-09-09 17:25:28 --> Output Class Initialized
INFO - 2020-09-09 17:25:28 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:28 --> Input Class Initialized
INFO - 2020-09-09 17:25:28 --> Language Class Initialized
INFO - 2020-09-09 17:25:28 --> Loader Class Initialized
INFO - 2020-09-09 17:25:28 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:28 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:28 --> Email Class Initialized
INFO - 2020-09-09 17:25:28 --> Controller Class Initialized
INFO - 2020-09-09 17:25:28 --> Model Class Initialized
INFO - 2020-09-09 17:25:28 --> Model Class Initialized
INFO - 2020-09-09 17:25:28 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:28 --> Total execution time: 0.0412
ERROR - 2020-09-09 17:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:32 --> Config Class Initialized
INFO - 2020-09-09 17:25:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:32 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:32 --> URI Class Initialized
INFO - 2020-09-09 17:25:32 --> Router Class Initialized
INFO - 2020-09-09 17:25:32 --> Output Class Initialized
INFO - 2020-09-09 17:25:32 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:32 --> Input Class Initialized
INFO - 2020-09-09 17:25:32 --> Language Class Initialized
INFO - 2020-09-09 17:25:32 --> Loader Class Initialized
INFO - 2020-09-09 17:25:32 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:32 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:32 --> Email Class Initialized
INFO - 2020-09-09 17:25:32 --> Controller Class Initialized
INFO - 2020-09-09 17:25:32 --> Model Class Initialized
INFO - 2020-09-09 17:25:32 --> Model Class Initialized
INFO - 2020-09-09 17:25:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:25:32 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:32 --> Total execution time: 0.0428
ERROR - 2020-09-09 17:25:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:32 --> Config Class Initialized
INFO - 2020-09-09 17:25:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:32 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:32 --> URI Class Initialized
INFO - 2020-09-09 17:25:32 --> Router Class Initialized
INFO - 2020-09-09 17:25:32 --> Output Class Initialized
INFO - 2020-09-09 17:25:32 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:32 --> Input Class Initialized
INFO - 2020-09-09 17:25:32 --> Language Class Initialized
INFO - 2020-09-09 17:25:32 --> Loader Class Initialized
INFO - 2020-09-09 17:25:32 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:32 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:32 --> Email Class Initialized
INFO - 2020-09-09 17:25:32 --> Controller Class Initialized
INFO - 2020-09-09 17:25:32 --> Model Class Initialized
INFO - 2020-09-09 17:25:32 --> Model Class Initialized
INFO - 2020-09-09 17:25:32 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:32 --> Total execution time: 0.0385
ERROR - 2020-09-09 17:25:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:35 --> Config Class Initialized
INFO - 2020-09-09 17:25:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:35 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:35 --> URI Class Initialized
INFO - 2020-09-09 17:25:35 --> Router Class Initialized
INFO - 2020-09-09 17:25:35 --> Output Class Initialized
INFO - 2020-09-09 17:25:35 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:35 --> Input Class Initialized
INFO - 2020-09-09 17:25:35 --> Language Class Initialized
INFO - 2020-09-09 17:25:35 --> Loader Class Initialized
INFO - 2020-09-09 17:25:35 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:35 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:35 --> Email Class Initialized
INFO - 2020-09-09 17:25:35 --> Controller Class Initialized
INFO - 2020-09-09 17:25:35 --> Model Class Initialized
INFO - 2020-09-09 17:25:35 --> Model Class Initialized
INFO - 2020-09-09 17:25:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:25:35 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:35 --> Total execution time: 0.1007
ERROR - 2020-09-09 17:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:36 --> Config Class Initialized
INFO - 2020-09-09 17:25:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:36 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:36 --> URI Class Initialized
INFO - 2020-09-09 17:25:36 --> Router Class Initialized
INFO - 2020-09-09 17:25:36 --> Output Class Initialized
INFO - 2020-09-09 17:25:36 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:36 --> Input Class Initialized
INFO - 2020-09-09 17:25:36 --> Language Class Initialized
INFO - 2020-09-09 17:25:36 --> Loader Class Initialized
INFO - 2020-09-09 17:25:36 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:36 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:36 --> Email Class Initialized
INFO - 2020-09-09 17:25:36 --> Controller Class Initialized
INFO - 2020-09-09 17:25:36 --> Model Class Initialized
INFO - 2020-09-09 17:25:36 --> Model Class Initialized
INFO - 2020-09-09 17:25:36 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:36 --> Total execution time: 0.0414
ERROR - 2020-09-09 17:25:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:44 --> Config Class Initialized
INFO - 2020-09-09 17:25:44 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:44 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:44 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:44 --> URI Class Initialized
INFO - 2020-09-09 17:25:44 --> Router Class Initialized
INFO - 2020-09-09 17:25:44 --> Output Class Initialized
INFO - 2020-09-09 17:25:44 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:44 --> Input Class Initialized
INFO - 2020-09-09 17:25:44 --> Language Class Initialized
INFO - 2020-09-09 17:25:44 --> Loader Class Initialized
INFO - 2020-09-09 17:25:44 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:44 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:44 --> Email Class Initialized
INFO - 2020-09-09 17:25:44 --> Controller Class Initialized
INFO - 2020-09-09 17:25:44 --> Model Class Initialized
INFO - 2020-09-09 17:25:44 --> Model Class Initialized
INFO - 2020-09-09 17:25:44 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:44 --> Total execution time: 0.1345
ERROR - 2020-09-09 17:25:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:45 --> Config Class Initialized
INFO - 2020-09-09 17:25:45 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:45 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:45 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:45 --> URI Class Initialized
INFO - 2020-09-09 17:25:45 --> Router Class Initialized
INFO - 2020-09-09 17:25:45 --> Output Class Initialized
INFO - 2020-09-09 17:25:45 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:45 --> Input Class Initialized
INFO - 2020-09-09 17:25:45 --> Language Class Initialized
INFO - 2020-09-09 17:25:45 --> Loader Class Initialized
INFO - 2020-09-09 17:25:45 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:45 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:45 --> Email Class Initialized
INFO - 2020-09-09 17:25:45 --> Controller Class Initialized
INFO - 2020-09-09 17:25:45 --> Model Class Initialized
INFO - 2020-09-09 17:25:45 --> Model Class Initialized
INFO - 2020-09-09 17:25:45 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:45 --> Total execution time: 0.0421
ERROR - 2020-09-09 17:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:50 --> Config Class Initialized
INFO - 2020-09-09 17:25:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:50 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:50 --> URI Class Initialized
INFO - 2020-09-09 17:25:50 --> Router Class Initialized
INFO - 2020-09-09 17:25:50 --> Output Class Initialized
INFO - 2020-09-09 17:25:50 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:50 --> Input Class Initialized
INFO - 2020-09-09 17:25:50 --> Language Class Initialized
INFO - 2020-09-09 17:25:50 --> Loader Class Initialized
INFO - 2020-09-09 17:25:50 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:50 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:50 --> Email Class Initialized
INFO - 2020-09-09 17:25:50 --> Controller Class Initialized
INFO - 2020-09-09 17:25:50 --> Model Class Initialized
INFO - 2020-09-09 17:25:50 --> Model Class Initialized
INFO - 2020-09-09 17:25:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:25:50 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:50 --> Total execution time: 0.0424
ERROR - 2020-09-09 17:25:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:25:51 --> Config Class Initialized
INFO - 2020-09-09 17:25:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:25:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:25:51 --> Utf8 Class Initialized
INFO - 2020-09-09 17:25:51 --> URI Class Initialized
INFO - 2020-09-09 17:25:51 --> Router Class Initialized
INFO - 2020-09-09 17:25:51 --> Output Class Initialized
INFO - 2020-09-09 17:25:51 --> Security Class Initialized
DEBUG - 2020-09-09 17:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:25:51 --> Input Class Initialized
INFO - 2020-09-09 17:25:51 --> Language Class Initialized
INFO - 2020-09-09 17:25:51 --> Loader Class Initialized
INFO - 2020-09-09 17:25:51 --> Helper loaded: url_helper
INFO - 2020-09-09 17:25:51 --> Database Driver Class Initialized
INFO - 2020-09-09 17:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:25:51 --> Email Class Initialized
INFO - 2020-09-09 17:25:51 --> Controller Class Initialized
INFO - 2020-09-09 17:25:51 --> Model Class Initialized
INFO - 2020-09-09 17:25:51 --> Model Class Initialized
INFO - 2020-09-09 17:25:51 --> Final output sent to browser
DEBUG - 2020-09-09 17:25:51 --> Total execution time: 0.0556
ERROR - 2020-09-09 17:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:26:59 --> Config Class Initialized
INFO - 2020-09-09 17:26:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:26:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:26:59 --> Utf8 Class Initialized
INFO - 2020-09-09 17:26:59 --> URI Class Initialized
INFO - 2020-09-09 17:26:59 --> Router Class Initialized
INFO - 2020-09-09 17:26:59 --> Output Class Initialized
INFO - 2020-09-09 17:26:59 --> Security Class Initialized
DEBUG - 2020-09-09 17:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:26:59 --> Input Class Initialized
INFO - 2020-09-09 17:26:59 --> Language Class Initialized
INFO - 2020-09-09 17:26:59 --> Loader Class Initialized
INFO - 2020-09-09 17:26:59 --> Helper loaded: url_helper
INFO - 2020-09-09 17:26:59 --> Database Driver Class Initialized
INFO - 2020-09-09 17:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:26:59 --> Email Class Initialized
INFO - 2020-09-09 17:26:59 --> Controller Class Initialized
INFO - 2020-09-09 17:26:59 --> Model Class Initialized
INFO - 2020-09-09 17:26:59 --> Model Class Initialized
INFO - 2020-09-09 17:26:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:26:59 --> Final output sent to browser
DEBUG - 2020-09-09 17:26:59 --> Total execution time: 0.0432
ERROR - 2020-09-09 17:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:26:59 --> Config Class Initialized
INFO - 2020-09-09 17:26:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:26:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:26:59 --> Utf8 Class Initialized
INFO - 2020-09-09 17:26:59 --> URI Class Initialized
INFO - 2020-09-09 17:26:59 --> Router Class Initialized
INFO - 2020-09-09 17:26:59 --> Output Class Initialized
INFO - 2020-09-09 17:26:59 --> Security Class Initialized
DEBUG - 2020-09-09 17:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:26:59 --> Input Class Initialized
INFO - 2020-09-09 17:26:59 --> Language Class Initialized
INFO - 2020-09-09 17:26:59 --> Loader Class Initialized
INFO - 2020-09-09 17:26:59 --> Helper loaded: url_helper
INFO - 2020-09-09 17:26:59 --> Database Driver Class Initialized
INFO - 2020-09-09 17:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:26:59 --> Email Class Initialized
INFO - 2020-09-09 17:26:59 --> Controller Class Initialized
INFO - 2020-09-09 17:26:59 --> Model Class Initialized
INFO - 2020-09-09 17:26:59 --> Model Class Initialized
INFO - 2020-09-09 17:26:59 --> Final output sent to browser
DEBUG - 2020-09-09 17:26:59 --> Total execution time: 0.0383
ERROR - 2020-09-09 17:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:27:12 --> Config Class Initialized
INFO - 2020-09-09 17:27:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:27:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:27:12 --> Utf8 Class Initialized
INFO - 2020-09-09 17:27:12 --> URI Class Initialized
INFO - 2020-09-09 17:27:12 --> Router Class Initialized
INFO - 2020-09-09 17:27:12 --> Output Class Initialized
INFO - 2020-09-09 17:27:12 --> Security Class Initialized
DEBUG - 2020-09-09 17:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:27:12 --> Input Class Initialized
INFO - 2020-09-09 17:27:12 --> Language Class Initialized
INFO - 2020-09-09 17:27:12 --> Loader Class Initialized
INFO - 2020-09-09 17:27:12 --> Helper loaded: url_helper
INFO - 2020-09-09 17:27:12 --> Database Driver Class Initialized
INFO - 2020-09-09 17:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:27:12 --> Email Class Initialized
INFO - 2020-09-09 17:27:12 --> Controller Class Initialized
INFO - 2020-09-09 17:27:12 --> Model Class Initialized
INFO - 2020-09-09 17:27:12 --> Model Class Initialized
INFO - 2020-09-09 17:27:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:27:12 --> Final output sent to browser
DEBUG - 2020-09-09 17:27:12 --> Total execution time: 0.0373
ERROR - 2020-09-09 17:27:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:27:13 --> Config Class Initialized
INFO - 2020-09-09 17:27:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:27:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:27:13 --> Utf8 Class Initialized
INFO - 2020-09-09 17:27:13 --> URI Class Initialized
INFO - 2020-09-09 17:27:13 --> Router Class Initialized
INFO - 2020-09-09 17:27:13 --> Output Class Initialized
INFO - 2020-09-09 17:27:13 --> Security Class Initialized
DEBUG - 2020-09-09 17:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:27:13 --> Input Class Initialized
INFO - 2020-09-09 17:27:13 --> Language Class Initialized
INFO - 2020-09-09 17:27:13 --> Loader Class Initialized
INFO - 2020-09-09 17:27:13 --> Helper loaded: url_helper
INFO - 2020-09-09 17:27:13 --> Database Driver Class Initialized
INFO - 2020-09-09 17:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:27:13 --> Email Class Initialized
INFO - 2020-09-09 17:27:13 --> Controller Class Initialized
INFO - 2020-09-09 17:27:13 --> Model Class Initialized
INFO - 2020-09-09 17:27:13 --> Model Class Initialized
INFO - 2020-09-09 17:27:13 --> Final output sent to browser
DEBUG - 2020-09-09 17:27:13 --> Total execution time: 0.0357
ERROR - 2020-09-09 17:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:02 --> Config Class Initialized
INFO - 2020-09-09 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:02 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:02 --> URI Class Initialized
INFO - 2020-09-09 17:28:02 --> Router Class Initialized
INFO - 2020-09-09 17:28:02 --> Output Class Initialized
INFO - 2020-09-09 17:28:02 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:02 --> Input Class Initialized
INFO - 2020-09-09 17:28:02 --> Language Class Initialized
INFO - 2020-09-09 17:28:02 --> Loader Class Initialized
INFO - 2020-09-09 17:28:02 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:02 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:02 --> Email Class Initialized
INFO - 2020-09-09 17:28:02 --> Controller Class Initialized
INFO - 2020-09-09 17:28:02 --> Model Class Initialized
INFO - 2020-09-09 17:28:02 --> Model Class Initialized
INFO - 2020-09-09 17:28:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:28:02 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:02 --> Total execution time: 0.0421
ERROR - 2020-09-09 17:28:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:02 --> Config Class Initialized
INFO - 2020-09-09 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:02 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:02 --> URI Class Initialized
INFO - 2020-09-09 17:28:02 --> Router Class Initialized
INFO - 2020-09-09 17:28:02 --> Output Class Initialized
INFO - 2020-09-09 17:28:02 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:02 --> Input Class Initialized
INFO - 2020-09-09 17:28:02 --> Language Class Initialized
INFO - 2020-09-09 17:28:02 --> Loader Class Initialized
INFO - 2020-09-09 17:28:02 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:02 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:02 --> Email Class Initialized
INFO - 2020-09-09 17:28:02 --> Controller Class Initialized
INFO - 2020-09-09 17:28:02 --> Model Class Initialized
INFO - 2020-09-09 17:28:02 --> Model Class Initialized
INFO - 2020-09-09 17:28:02 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:02 --> Total execution time: 0.0395
ERROR - 2020-09-09 17:28:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:12 --> Config Class Initialized
INFO - 2020-09-09 17:28:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:12 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:12 --> URI Class Initialized
INFO - 2020-09-09 17:28:12 --> Router Class Initialized
INFO - 2020-09-09 17:28:12 --> Output Class Initialized
INFO - 2020-09-09 17:28:12 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:12 --> Input Class Initialized
INFO - 2020-09-09 17:28:12 --> Language Class Initialized
INFO - 2020-09-09 17:28:12 --> Loader Class Initialized
INFO - 2020-09-09 17:28:12 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:12 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:12 --> Email Class Initialized
INFO - 2020-09-09 17:28:12 --> Controller Class Initialized
INFO - 2020-09-09 17:28:12 --> Model Class Initialized
INFO - 2020-09-09 17:28:12 --> Model Class Initialized
INFO - 2020-09-09 17:28:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:28:12 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:12 --> Total execution time: 0.0511
ERROR - 2020-09-09 17:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:13 --> Config Class Initialized
INFO - 2020-09-09 17:28:13 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:13 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:13 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:13 --> URI Class Initialized
INFO - 2020-09-09 17:28:13 --> Router Class Initialized
INFO - 2020-09-09 17:28:13 --> Output Class Initialized
INFO - 2020-09-09 17:28:13 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:13 --> Input Class Initialized
INFO - 2020-09-09 17:28:13 --> Language Class Initialized
INFO - 2020-09-09 17:28:13 --> Loader Class Initialized
INFO - 2020-09-09 17:28:13 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:13 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:13 --> Email Class Initialized
INFO - 2020-09-09 17:28:13 --> Controller Class Initialized
INFO - 2020-09-09 17:28:13 --> Model Class Initialized
INFO - 2020-09-09 17:28:13 --> Model Class Initialized
INFO - 2020-09-09 17:28:13 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:13 --> Total execution time: 0.0551
ERROR - 2020-09-09 17:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:38 --> Config Class Initialized
INFO - 2020-09-09 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:38 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:38 --> URI Class Initialized
INFO - 2020-09-09 17:28:38 --> Router Class Initialized
INFO - 2020-09-09 17:28:38 --> Output Class Initialized
INFO - 2020-09-09 17:28:38 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:38 --> Input Class Initialized
INFO - 2020-09-09 17:28:38 --> Language Class Initialized
INFO - 2020-09-09 17:28:38 --> Loader Class Initialized
INFO - 2020-09-09 17:28:38 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:38 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:38 --> Email Class Initialized
INFO - 2020-09-09 17:28:38 --> Controller Class Initialized
INFO - 2020-09-09 17:28:38 --> Model Class Initialized
INFO - 2020-09-09 17:28:38 --> Model Class Initialized
INFO - 2020-09-09 17:28:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:28:38 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:38 --> Total execution time: 0.0445
ERROR - 2020-09-09 17:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:38 --> Config Class Initialized
INFO - 2020-09-09 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:38 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:38 --> URI Class Initialized
INFO - 2020-09-09 17:28:38 --> Router Class Initialized
INFO - 2020-09-09 17:28:38 --> Output Class Initialized
INFO - 2020-09-09 17:28:38 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:38 --> Input Class Initialized
INFO - 2020-09-09 17:28:38 --> Language Class Initialized
INFO - 2020-09-09 17:28:38 --> Loader Class Initialized
INFO - 2020-09-09 17:28:38 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:38 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:38 --> Email Class Initialized
INFO - 2020-09-09 17:28:38 --> Controller Class Initialized
INFO - 2020-09-09 17:28:38 --> Model Class Initialized
INFO - 2020-09-09 17:28:38 --> Model Class Initialized
INFO - 2020-09-09 17:28:38 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:38 --> Total execution time: 0.0523
ERROR - 2020-09-09 17:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:50 --> Config Class Initialized
INFO - 2020-09-09 17:28:50 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:50 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:50 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:50 --> URI Class Initialized
INFO - 2020-09-09 17:28:50 --> Router Class Initialized
INFO - 2020-09-09 17:28:50 --> Output Class Initialized
INFO - 2020-09-09 17:28:50 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:50 --> Input Class Initialized
INFO - 2020-09-09 17:28:50 --> Language Class Initialized
INFO - 2020-09-09 17:28:50 --> Loader Class Initialized
INFO - 2020-09-09 17:28:50 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:50 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:50 --> Email Class Initialized
INFO - 2020-09-09 17:28:50 --> Controller Class Initialized
INFO - 2020-09-09 17:28:50 --> Model Class Initialized
INFO - 2020-09-09 17:28:50 --> Model Class Initialized
INFO - 2020-09-09 17:28:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:28:50 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:50 --> Total execution time: 0.0396
ERROR - 2020-09-09 17:28:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:28:51 --> Config Class Initialized
INFO - 2020-09-09 17:28:51 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:28:51 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:28:51 --> Utf8 Class Initialized
INFO - 2020-09-09 17:28:51 --> URI Class Initialized
INFO - 2020-09-09 17:28:51 --> Router Class Initialized
INFO - 2020-09-09 17:28:51 --> Output Class Initialized
INFO - 2020-09-09 17:28:51 --> Security Class Initialized
DEBUG - 2020-09-09 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:28:51 --> Input Class Initialized
INFO - 2020-09-09 17:28:51 --> Language Class Initialized
INFO - 2020-09-09 17:28:51 --> Loader Class Initialized
INFO - 2020-09-09 17:28:51 --> Helper loaded: url_helper
INFO - 2020-09-09 17:28:51 --> Database Driver Class Initialized
INFO - 2020-09-09 17:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:28:51 --> Email Class Initialized
INFO - 2020-09-09 17:28:51 --> Controller Class Initialized
INFO - 2020-09-09 17:28:51 --> Model Class Initialized
INFO - 2020-09-09 17:28:51 --> Model Class Initialized
INFO - 2020-09-09 17:28:51 --> Final output sent to browser
DEBUG - 2020-09-09 17:28:51 --> Total execution time: 0.0438
ERROR - 2020-09-09 17:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:30:53 --> Config Class Initialized
INFO - 2020-09-09 17:30:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:30:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:30:53 --> Utf8 Class Initialized
INFO - 2020-09-09 17:30:53 --> URI Class Initialized
INFO - 2020-09-09 17:30:53 --> Router Class Initialized
INFO - 2020-09-09 17:30:53 --> Output Class Initialized
INFO - 2020-09-09 17:30:53 --> Security Class Initialized
DEBUG - 2020-09-09 17:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:30:53 --> Input Class Initialized
INFO - 2020-09-09 17:30:53 --> Language Class Initialized
INFO - 2020-09-09 17:30:53 --> Loader Class Initialized
INFO - 2020-09-09 17:30:53 --> Helper loaded: url_helper
INFO - 2020-09-09 17:30:53 --> Database Driver Class Initialized
INFO - 2020-09-09 17:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:30:53 --> Email Class Initialized
INFO - 2020-09-09 17:30:53 --> Controller Class Initialized
INFO - 2020-09-09 17:30:53 --> Model Class Initialized
INFO - 2020-09-09 17:30:53 --> Model Class Initialized
INFO - 2020-09-09 17:30:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:30:53 --> Final output sent to browser
DEBUG - 2020-09-09 17:30:53 --> Total execution time: 0.0329
ERROR - 2020-09-09 17:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:30:54 --> Config Class Initialized
INFO - 2020-09-09 17:30:54 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:30:54 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:30:54 --> Utf8 Class Initialized
INFO - 2020-09-09 17:30:54 --> URI Class Initialized
INFO - 2020-09-09 17:30:54 --> Router Class Initialized
INFO - 2020-09-09 17:30:54 --> Output Class Initialized
INFO - 2020-09-09 17:30:54 --> Security Class Initialized
DEBUG - 2020-09-09 17:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:30:54 --> Input Class Initialized
INFO - 2020-09-09 17:30:54 --> Language Class Initialized
INFO - 2020-09-09 17:30:54 --> Loader Class Initialized
INFO - 2020-09-09 17:30:54 --> Helper loaded: url_helper
INFO - 2020-09-09 17:30:54 --> Database Driver Class Initialized
INFO - 2020-09-09 17:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:30:54 --> Email Class Initialized
INFO - 2020-09-09 17:30:54 --> Controller Class Initialized
INFO - 2020-09-09 17:30:54 --> Model Class Initialized
INFO - 2020-09-09 17:30:54 --> Model Class Initialized
INFO - 2020-09-09 17:30:54 --> Final output sent to browser
DEBUG - 2020-09-09 17:30:54 --> Total execution time: 0.0432
ERROR - 2020-09-09 17:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:31:19 --> Config Class Initialized
INFO - 2020-09-09 17:31:19 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:31:19 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:31:19 --> Utf8 Class Initialized
INFO - 2020-09-09 17:31:19 --> URI Class Initialized
INFO - 2020-09-09 17:31:19 --> Router Class Initialized
INFO - 2020-09-09 17:31:19 --> Output Class Initialized
INFO - 2020-09-09 17:31:19 --> Security Class Initialized
DEBUG - 2020-09-09 17:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:31:19 --> Input Class Initialized
INFO - 2020-09-09 17:31:19 --> Language Class Initialized
INFO - 2020-09-09 17:31:19 --> Loader Class Initialized
INFO - 2020-09-09 17:31:19 --> Helper loaded: url_helper
INFO - 2020-09-09 17:31:19 --> Database Driver Class Initialized
INFO - 2020-09-09 17:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:31:19 --> Email Class Initialized
INFO - 2020-09-09 17:31:19 --> Controller Class Initialized
DEBUG - 2020-09-09 17:31:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 17:31:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 17:31:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 17:31:19 --> Final output sent to browser
DEBUG - 2020-09-09 17:31:19 --> Total execution time: 0.0196
ERROR - 2020-09-09 17:31:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:31:35 --> Config Class Initialized
INFO - 2020-09-09 17:31:35 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:31:35 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:31:35 --> Utf8 Class Initialized
INFO - 2020-09-09 17:31:35 --> URI Class Initialized
INFO - 2020-09-09 17:31:35 --> Router Class Initialized
INFO - 2020-09-09 17:31:35 --> Output Class Initialized
INFO - 2020-09-09 17:31:35 --> Security Class Initialized
DEBUG - 2020-09-09 17:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:31:35 --> Input Class Initialized
INFO - 2020-09-09 17:31:35 --> Language Class Initialized
INFO - 2020-09-09 17:31:35 --> Loader Class Initialized
INFO - 2020-09-09 17:31:35 --> Helper loaded: url_helper
INFO - 2020-09-09 17:31:35 --> Database Driver Class Initialized
INFO - 2020-09-09 17:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:31:35 --> Email Class Initialized
INFO - 2020-09-09 17:31:35 --> Controller Class Initialized
INFO - 2020-09-09 17:31:35 --> Model Class Initialized
INFO - 2020-09-09 17:31:35 --> Model Class Initialized
INFO - 2020-09-09 17:31:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:31:35 --> Final output sent to browser
DEBUG - 2020-09-09 17:31:35 --> Total execution time: 0.0375
ERROR - 2020-09-09 17:31:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:31:36 --> Config Class Initialized
INFO - 2020-09-09 17:31:36 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:31:36 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:31:36 --> Utf8 Class Initialized
INFO - 2020-09-09 17:31:36 --> URI Class Initialized
INFO - 2020-09-09 17:31:36 --> Router Class Initialized
INFO - 2020-09-09 17:31:36 --> Output Class Initialized
INFO - 2020-09-09 17:31:36 --> Security Class Initialized
DEBUG - 2020-09-09 17:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:31:36 --> Input Class Initialized
INFO - 2020-09-09 17:31:36 --> Language Class Initialized
INFO - 2020-09-09 17:31:36 --> Loader Class Initialized
INFO - 2020-09-09 17:31:36 --> Helper loaded: url_helper
INFO - 2020-09-09 17:31:36 --> Database Driver Class Initialized
INFO - 2020-09-09 17:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:31:36 --> Email Class Initialized
INFO - 2020-09-09 17:31:36 --> Controller Class Initialized
INFO - 2020-09-09 17:31:36 --> Model Class Initialized
INFO - 2020-09-09 17:31:36 --> Model Class Initialized
INFO - 2020-09-09 17:31:36 --> Final output sent to browser
DEBUG - 2020-09-09 17:31:36 --> Total execution time: 0.0372
ERROR - 2020-09-09 17:32:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:32:23 --> Config Class Initialized
INFO - 2020-09-09 17:32:23 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:32:23 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:32:23 --> Utf8 Class Initialized
INFO - 2020-09-09 17:32:23 --> URI Class Initialized
INFO - 2020-09-09 17:32:23 --> Router Class Initialized
INFO - 2020-09-09 17:32:23 --> Output Class Initialized
INFO - 2020-09-09 17:32:23 --> Security Class Initialized
DEBUG - 2020-09-09 17:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:32:23 --> Input Class Initialized
INFO - 2020-09-09 17:32:23 --> Language Class Initialized
INFO - 2020-09-09 17:32:23 --> Loader Class Initialized
INFO - 2020-09-09 17:32:23 --> Helper loaded: url_helper
INFO - 2020-09-09 17:32:23 --> Database Driver Class Initialized
INFO - 2020-09-09 17:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:32:23 --> Email Class Initialized
INFO - 2020-09-09 17:32:23 --> Controller Class Initialized
INFO - 2020-09-09 17:32:23 --> Model Class Initialized
INFO - 2020-09-09 17:32:23 --> Model Class Initialized
INFO - 2020-09-09 17:32:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:32:23 --> Final output sent to browser
DEBUG - 2020-09-09 17:32:23 --> Total execution time: 0.0953
ERROR - 2020-09-09 17:32:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:32:24 --> Config Class Initialized
INFO - 2020-09-09 17:32:24 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:32:24 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:32:24 --> Utf8 Class Initialized
INFO - 2020-09-09 17:32:24 --> URI Class Initialized
INFO - 2020-09-09 17:32:24 --> Router Class Initialized
INFO - 2020-09-09 17:32:24 --> Output Class Initialized
INFO - 2020-09-09 17:32:24 --> Security Class Initialized
DEBUG - 2020-09-09 17:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:32:24 --> Input Class Initialized
INFO - 2020-09-09 17:32:24 --> Language Class Initialized
INFO - 2020-09-09 17:32:24 --> Loader Class Initialized
INFO - 2020-09-09 17:32:24 --> Helper loaded: url_helper
INFO - 2020-09-09 17:32:24 --> Database Driver Class Initialized
INFO - 2020-09-09 17:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:32:24 --> Email Class Initialized
INFO - 2020-09-09 17:32:24 --> Controller Class Initialized
INFO - 2020-09-09 17:32:24 --> Model Class Initialized
INFO - 2020-09-09 17:32:24 --> Model Class Initialized
INFO - 2020-09-09 17:32:24 --> Final output sent to browser
DEBUG - 2020-09-09 17:32:24 --> Total execution time: 0.0369
ERROR - 2020-09-09 17:33:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:33:09 --> Config Class Initialized
INFO - 2020-09-09 17:33:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:33:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:33:09 --> Utf8 Class Initialized
INFO - 2020-09-09 17:33:09 --> URI Class Initialized
INFO - 2020-09-09 17:33:09 --> Router Class Initialized
INFO - 2020-09-09 17:33:09 --> Output Class Initialized
INFO - 2020-09-09 17:33:09 --> Security Class Initialized
DEBUG - 2020-09-09 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:33:09 --> Input Class Initialized
INFO - 2020-09-09 17:33:09 --> Language Class Initialized
INFO - 2020-09-09 17:33:09 --> Loader Class Initialized
INFO - 2020-09-09 17:33:09 --> Helper loaded: url_helper
INFO - 2020-09-09 17:33:09 --> Database Driver Class Initialized
INFO - 2020-09-09 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:33:09 --> Email Class Initialized
INFO - 2020-09-09 17:33:09 --> Controller Class Initialized
INFO - 2020-09-09 17:33:09 --> Model Class Initialized
INFO - 2020-09-09 17:33:09 --> Model Class Initialized
INFO - 2020-09-09 17:33:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:33:09 --> Final output sent to browser
DEBUG - 2020-09-09 17:33:09 --> Total execution time: 0.0338
ERROR - 2020-09-09 17:33:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:33:09 --> Config Class Initialized
INFO - 2020-09-09 17:33:09 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:33:09 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:33:09 --> Utf8 Class Initialized
INFO - 2020-09-09 17:33:09 --> URI Class Initialized
INFO - 2020-09-09 17:33:09 --> Router Class Initialized
INFO - 2020-09-09 17:33:09 --> Output Class Initialized
INFO - 2020-09-09 17:33:09 --> Security Class Initialized
DEBUG - 2020-09-09 17:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:33:09 --> Input Class Initialized
INFO - 2020-09-09 17:33:09 --> Language Class Initialized
INFO - 2020-09-09 17:33:09 --> Loader Class Initialized
INFO - 2020-09-09 17:33:09 --> Helper loaded: url_helper
INFO - 2020-09-09 17:33:09 --> Database Driver Class Initialized
INFO - 2020-09-09 17:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:33:09 --> Email Class Initialized
INFO - 2020-09-09 17:33:09 --> Controller Class Initialized
INFO - 2020-09-09 17:33:09 --> Model Class Initialized
INFO - 2020-09-09 17:33:09 --> Model Class Initialized
INFO - 2020-09-09 17:33:09 --> Final output sent to browser
DEBUG - 2020-09-09 17:33:09 --> Total execution time: 0.0376
ERROR - 2020-09-09 17:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:55:00 --> Config Class Initialized
INFO - 2020-09-09 17:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:55:00 --> Utf8 Class Initialized
INFO - 2020-09-09 17:55:00 --> URI Class Initialized
INFO - 2020-09-09 17:55:00 --> Router Class Initialized
INFO - 2020-09-09 17:55:00 --> Output Class Initialized
INFO - 2020-09-09 17:55:00 --> Security Class Initialized
DEBUG - 2020-09-09 17:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:55:00 --> Input Class Initialized
INFO - 2020-09-09 17:55:00 --> Language Class Initialized
INFO - 2020-09-09 17:55:00 --> Loader Class Initialized
INFO - 2020-09-09 17:55:00 --> Helper loaded: url_helper
INFO - 2020-09-09 17:55:00 --> Database Driver Class Initialized
INFO - 2020-09-09 17:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:55:00 --> Email Class Initialized
INFO - 2020-09-09 17:55:00 --> Controller Class Initialized
INFO - 2020-09-09 17:55:00 --> Model Class Initialized
INFO - 2020-09-09 17:55:00 --> Model Class Initialized
INFO - 2020-09-09 17:55:00 --> Final output sent to browser
DEBUG - 2020-09-09 17:55:00 --> Total execution time: 0.1597
ERROR - 2020-09-09 17:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:55:00 --> Config Class Initialized
INFO - 2020-09-09 17:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:55:00 --> Utf8 Class Initialized
INFO - 2020-09-09 17:55:00 --> URI Class Initialized
INFO - 2020-09-09 17:55:00 --> Router Class Initialized
INFO - 2020-09-09 17:55:00 --> Output Class Initialized
INFO - 2020-09-09 17:55:00 --> Security Class Initialized
DEBUG - 2020-09-09 17:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:55:00 --> Input Class Initialized
INFO - 2020-09-09 17:55:00 --> Language Class Initialized
INFO - 2020-09-09 17:55:00 --> Loader Class Initialized
INFO - 2020-09-09 17:55:00 --> Helper loaded: url_helper
INFO - 2020-09-09 17:55:00 --> Database Driver Class Initialized
INFO - 2020-09-09 17:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:55:00 --> Email Class Initialized
INFO - 2020-09-09 17:55:00 --> Controller Class Initialized
INFO - 2020-09-09 17:55:00 --> Model Class Initialized
INFO - 2020-09-09 17:55:00 --> Model Class Initialized
INFO - 2020-09-09 17:55:00 --> Final output sent to browser
DEBUG - 2020-09-09 17:55:00 --> Total execution time: 0.0420
ERROR - 2020-09-09 17:55:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:55:55 --> Config Class Initialized
INFO - 2020-09-09 17:55:55 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:55:55 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:55:55 --> Utf8 Class Initialized
INFO - 2020-09-09 17:55:55 --> URI Class Initialized
INFO - 2020-09-09 17:55:55 --> Router Class Initialized
INFO - 2020-09-09 17:55:55 --> Output Class Initialized
INFO - 2020-09-09 17:55:55 --> Security Class Initialized
DEBUG - 2020-09-09 17:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:55:55 --> Input Class Initialized
INFO - 2020-09-09 17:55:55 --> Language Class Initialized
INFO - 2020-09-09 17:55:55 --> Loader Class Initialized
INFO - 2020-09-09 17:55:55 --> Helper loaded: url_helper
INFO - 2020-09-09 17:55:55 --> Database Driver Class Initialized
INFO - 2020-09-09 17:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:55:55 --> Email Class Initialized
INFO - 2020-09-09 17:55:55 --> Controller Class Initialized
INFO - 2020-09-09 17:55:55 --> Model Class Initialized
INFO - 2020-09-09 17:55:55 --> Model Class Initialized
INFO - 2020-09-09 17:55:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:55:55 --> Final output sent to browser
DEBUG - 2020-09-09 17:55:55 --> Total execution time: 0.0386
ERROR - 2020-09-09 17:55:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:55:56 --> Config Class Initialized
INFO - 2020-09-09 17:55:56 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:55:56 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:55:56 --> Utf8 Class Initialized
INFO - 2020-09-09 17:55:56 --> URI Class Initialized
INFO - 2020-09-09 17:55:56 --> Router Class Initialized
INFO - 2020-09-09 17:55:56 --> Output Class Initialized
INFO - 2020-09-09 17:55:56 --> Security Class Initialized
DEBUG - 2020-09-09 17:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:55:56 --> Input Class Initialized
INFO - 2020-09-09 17:55:56 --> Language Class Initialized
INFO - 2020-09-09 17:55:56 --> Loader Class Initialized
INFO - 2020-09-09 17:55:56 --> Helper loaded: url_helper
INFO - 2020-09-09 17:55:56 --> Database Driver Class Initialized
INFO - 2020-09-09 17:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:55:56 --> Email Class Initialized
INFO - 2020-09-09 17:55:56 --> Controller Class Initialized
INFO - 2020-09-09 17:55:56 --> Model Class Initialized
INFO - 2020-09-09 17:55:56 --> Model Class Initialized
INFO - 2020-09-09 17:55:56 --> Final output sent to browser
DEBUG - 2020-09-09 17:55:56 --> Total execution time: 0.0413
ERROR - 2020-09-09 17:56:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:56:39 --> Config Class Initialized
INFO - 2020-09-09 17:56:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:56:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:56:39 --> Utf8 Class Initialized
INFO - 2020-09-09 17:56:39 --> URI Class Initialized
INFO - 2020-09-09 17:56:39 --> Router Class Initialized
INFO - 2020-09-09 17:56:39 --> Output Class Initialized
INFO - 2020-09-09 17:56:39 --> Security Class Initialized
DEBUG - 2020-09-09 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:56:39 --> Input Class Initialized
INFO - 2020-09-09 17:56:39 --> Language Class Initialized
INFO - 2020-09-09 17:56:39 --> Loader Class Initialized
INFO - 2020-09-09 17:56:39 --> Helper loaded: url_helper
INFO - 2020-09-09 17:56:39 --> Database Driver Class Initialized
INFO - 2020-09-09 17:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:56:39 --> Email Class Initialized
INFO - 2020-09-09 17:56:39 --> Controller Class Initialized
INFO - 2020-09-09 17:56:39 --> Model Class Initialized
INFO - 2020-09-09 17:56:39 --> Model Class Initialized
INFO - 2020-09-09 17:56:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:56:39 --> Final output sent to browser
DEBUG - 2020-09-09 17:56:39 --> Total execution time: 0.0400
ERROR - 2020-09-09 17:56:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:56:39 --> Config Class Initialized
INFO - 2020-09-09 17:56:39 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:56:39 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:56:39 --> Utf8 Class Initialized
INFO - 2020-09-09 17:56:39 --> URI Class Initialized
INFO - 2020-09-09 17:56:39 --> Router Class Initialized
INFO - 2020-09-09 17:56:39 --> Output Class Initialized
INFO - 2020-09-09 17:56:39 --> Security Class Initialized
DEBUG - 2020-09-09 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:56:39 --> Input Class Initialized
INFO - 2020-09-09 17:56:39 --> Language Class Initialized
INFO - 2020-09-09 17:56:39 --> Loader Class Initialized
INFO - 2020-09-09 17:56:39 --> Helper loaded: url_helper
INFO - 2020-09-09 17:56:39 --> Database Driver Class Initialized
INFO - 2020-09-09 17:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:56:39 --> Email Class Initialized
INFO - 2020-09-09 17:56:39 --> Controller Class Initialized
INFO - 2020-09-09 17:56:39 --> Model Class Initialized
INFO - 2020-09-09 17:56:39 --> Model Class Initialized
INFO - 2020-09-09 17:56:39 --> Final output sent to browser
DEBUG - 2020-09-09 17:56:39 --> Total execution time: 0.0410
ERROR - 2020-09-09 17:57:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:57:31 --> Config Class Initialized
INFO - 2020-09-09 17:57:31 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:57:31 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:57:31 --> Utf8 Class Initialized
INFO - 2020-09-09 17:57:31 --> URI Class Initialized
INFO - 2020-09-09 17:57:31 --> Router Class Initialized
INFO - 2020-09-09 17:57:31 --> Output Class Initialized
INFO - 2020-09-09 17:57:31 --> Security Class Initialized
DEBUG - 2020-09-09 17:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:57:31 --> Input Class Initialized
INFO - 2020-09-09 17:57:31 --> Language Class Initialized
INFO - 2020-09-09 17:57:31 --> Loader Class Initialized
INFO - 2020-09-09 17:57:31 --> Helper loaded: url_helper
INFO - 2020-09-09 17:57:31 --> Database Driver Class Initialized
INFO - 2020-09-09 17:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:57:31 --> Email Class Initialized
INFO - 2020-09-09 17:57:31 --> Controller Class Initialized
INFO - 2020-09-09 17:57:31 --> Model Class Initialized
INFO - 2020-09-09 17:57:31 --> Model Class Initialized
INFO - 2020-09-09 17:57:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:57:31 --> Final output sent to browser
DEBUG - 2020-09-09 17:57:31 --> Total execution time: 0.0397
ERROR - 2020-09-09 17:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:57:32 --> Config Class Initialized
INFO - 2020-09-09 17:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:57:32 --> Utf8 Class Initialized
INFO - 2020-09-09 17:57:32 --> URI Class Initialized
INFO - 2020-09-09 17:57:32 --> Router Class Initialized
INFO - 2020-09-09 17:57:32 --> Output Class Initialized
INFO - 2020-09-09 17:57:32 --> Security Class Initialized
DEBUG - 2020-09-09 17:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:57:32 --> Input Class Initialized
INFO - 2020-09-09 17:57:32 --> Language Class Initialized
INFO - 2020-09-09 17:57:32 --> Loader Class Initialized
INFO - 2020-09-09 17:57:32 --> Helper loaded: url_helper
INFO - 2020-09-09 17:57:32 --> Database Driver Class Initialized
INFO - 2020-09-09 17:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:57:32 --> Email Class Initialized
INFO - 2020-09-09 17:57:32 --> Controller Class Initialized
INFO - 2020-09-09 17:57:32 --> Model Class Initialized
INFO - 2020-09-09 17:57:32 --> Model Class Initialized
INFO - 2020-09-09 17:57:32 --> Final output sent to browser
DEBUG - 2020-09-09 17:57:32 --> Total execution time: 0.0371
ERROR - 2020-09-09 17:59:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:59:27 --> Config Class Initialized
INFO - 2020-09-09 17:59:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:59:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:59:27 --> Utf8 Class Initialized
INFO - 2020-09-09 17:59:27 --> URI Class Initialized
INFO - 2020-09-09 17:59:27 --> Router Class Initialized
INFO - 2020-09-09 17:59:27 --> Output Class Initialized
INFO - 2020-09-09 17:59:27 --> Security Class Initialized
DEBUG - 2020-09-09 17:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:59:27 --> Input Class Initialized
INFO - 2020-09-09 17:59:27 --> Language Class Initialized
INFO - 2020-09-09 17:59:27 --> Loader Class Initialized
INFO - 2020-09-09 17:59:27 --> Helper loaded: url_helper
INFO - 2020-09-09 17:59:27 --> Database Driver Class Initialized
INFO - 2020-09-09 17:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:59:27 --> Email Class Initialized
INFO - 2020-09-09 17:59:27 --> Controller Class Initialized
INFO - 2020-09-09 17:59:27 --> Model Class Initialized
INFO - 2020-09-09 17:59:27 --> Model Class Initialized
INFO - 2020-09-09 17:59:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 17:59:27 --> Final output sent to browser
DEBUG - 2020-09-09 17:59:27 --> Total execution time: 0.0417
ERROR - 2020-09-09 17:59:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 17:59:27 --> Config Class Initialized
INFO - 2020-09-09 17:59:27 --> Hooks Class Initialized
DEBUG - 2020-09-09 17:59:27 --> UTF-8 Support Enabled
INFO - 2020-09-09 17:59:27 --> Utf8 Class Initialized
INFO - 2020-09-09 17:59:27 --> URI Class Initialized
INFO - 2020-09-09 17:59:27 --> Router Class Initialized
INFO - 2020-09-09 17:59:27 --> Output Class Initialized
INFO - 2020-09-09 17:59:27 --> Security Class Initialized
DEBUG - 2020-09-09 17:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 17:59:27 --> Input Class Initialized
INFO - 2020-09-09 17:59:27 --> Language Class Initialized
INFO - 2020-09-09 17:59:27 --> Loader Class Initialized
INFO - 2020-09-09 17:59:27 --> Helper loaded: url_helper
INFO - 2020-09-09 17:59:27 --> Database Driver Class Initialized
INFO - 2020-09-09 17:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 17:59:27 --> Email Class Initialized
INFO - 2020-09-09 17:59:27 --> Controller Class Initialized
INFO - 2020-09-09 17:59:27 --> Model Class Initialized
INFO - 2020-09-09 17:59:27 --> Model Class Initialized
INFO - 2020-09-09 17:59:28 --> Final output sent to browser
DEBUG - 2020-09-09 17:59:28 --> Total execution time: 0.0394
ERROR - 2020-09-09 18:00:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:00:10 --> Config Class Initialized
INFO - 2020-09-09 18:00:10 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:00:10 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:00:10 --> Utf8 Class Initialized
INFO - 2020-09-09 18:00:10 --> URI Class Initialized
INFO - 2020-09-09 18:00:10 --> Router Class Initialized
INFO - 2020-09-09 18:00:10 --> Output Class Initialized
INFO - 2020-09-09 18:00:10 --> Security Class Initialized
DEBUG - 2020-09-09 18:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:00:10 --> Input Class Initialized
INFO - 2020-09-09 18:00:10 --> Language Class Initialized
INFO - 2020-09-09 18:00:10 --> Loader Class Initialized
INFO - 2020-09-09 18:00:10 --> Helper loaded: url_helper
INFO - 2020-09-09 18:00:10 --> Database Driver Class Initialized
INFO - 2020-09-09 18:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:00:10 --> Email Class Initialized
INFO - 2020-09-09 18:00:10 --> Controller Class Initialized
INFO - 2020-09-09 18:00:10 --> Model Class Initialized
INFO - 2020-09-09 18:00:10 --> Model Class Initialized
INFO - 2020-09-09 18:00:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:00:10 --> Final output sent to browser
DEBUG - 2020-09-09 18:00:10 --> Total execution time: 0.0393
ERROR - 2020-09-09 18:00:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:00:11 --> Config Class Initialized
INFO - 2020-09-09 18:00:11 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:00:11 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:00:11 --> Utf8 Class Initialized
INFO - 2020-09-09 18:00:11 --> URI Class Initialized
INFO - 2020-09-09 18:00:11 --> Router Class Initialized
INFO - 2020-09-09 18:00:11 --> Output Class Initialized
INFO - 2020-09-09 18:00:11 --> Security Class Initialized
DEBUG - 2020-09-09 18:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:00:11 --> Input Class Initialized
INFO - 2020-09-09 18:00:11 --> Language Class Initialized
INFO - 2020-09-09 18:00:11 --> Loader Class Initialized
INFO - 2020-09-09 18:00:11 --> Helper loaded: url_helper
INFO - 2020-09-09 18:00:11 --> Database Driver Class Initialized
INFO - 2020-09-09 18:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:00:11 --> Email Class Initialized
INFO - 2020-09-09 18:00:11 --> Controller Class Initialized
INFO - 2020-09-09 18:00:11 --> Model Class Initialized
INFO - 2020-09-09 18:00:11 --> Model Class Initialized
INFO - 2020-09-09 18:00:11 --> Final output sent to browser
DEBUG - 2020-09-09 18:00:11 --> Total execution time: 0.0426
ERROR - 2020-09-09 18:00:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:00:24 --> Config Class Initialized
INFO - 2020-09-09 18:00:24 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:00:24 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:00:24 --> Utf8 Class Initialized
INFO - 2020-09-09 18:00:24 --> URI Class Initialized
INFO - 2020-09-09 18:00:24 --> Router Class Initialized
INFO - 2020-09-09 18:00:24 --> Output Class Initialized
INFO - 2020-09-09 18:00:24 --> Security Class Initialized
DEBUG - 2020-09-09 18:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:00:24 --> Input Class Initialized
INFO - 2020-09-09 18:00:24 --> Language Class Initialized
INFO - 2020-09-09 18:00:24 --> Loader Class Initialized
INFO - 2020-09-09 18:00:24 --> Helper loaded: url_helper
INFO - 2020-09-09 18:00:24 --> Database Driver Class Initialized
INFO - 2020-09-09 18:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:00:24 --> Email Class Initialized
INFO - 2020-09-09 18:00:24 --> Controller Class Initialized
INFO - 2020-09-09 18:00:24 --> Model Class Initialized
INFO - 2020-09-09 18:00:24 --> Model Class Initialized
INFO - 2020-09-09 18:00:25 --> Final output sent to browser
DEBUG - 2020-09-09 18:00:25 --> Total execution time: 0.1574
ERROR - 2020-09-09 18:00:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:00:25 --> Config Class Initialized
INFO - 2020-09-09 18:00:25 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:00:25 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:00:25 --> Utf8 Class Initialized
INFO - 2020-09-09 18:00:25 --> URI Class Initialized
INFO - 2020-09-09 18:00:25 --> Router Class Initialized
INFO - 2020-09-09 18:00:25 --> Output Class Initialized
INFO - 2020-09-09 18:00:25 --> Security Class Initialized
DEBUG - 2020-09-09 18:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:00:25 --> Input Class Initialized
INFO - 2020-09-09 18:00:25 --> Language Class Initialized
INFO - 2020-09-09 18:00:25 --> Loader Class Initialized
INFO - 2020-09-09 18:00:25 --> Helper loaded: url_helper
INFO - 2020-09-09 18:00:25 --> Database Driver Class Initialized
INFO - 2020-09-09 18:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:00:25 --> Email Class Initialized
INFO - 2020-09-09 18:00:25 --> Controller Class Initialized
INFO - 2020-09-09 18:00:25 --> Model Class Initialized
INFO - 2020-09-09 18:00:25 --> Model Class Initialized
INFO - 2020-09-09 18:00:25 --> Final output sent to browser
DEBUG - 2020-09-09 18:00:25 --> Total execution time: 0.0376
ERROR - 2020-09-09 18:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:00:58 --> Config Class Initialized
INFO - 2020-09-09 18:00:58 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:00:58 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:00:58 --> Utf8 Class Initialized
INFO - 2020-09-09 18:00:58 --> URI Class Initialized
INFO - 2020-09-09 18:00:58 --> Router Class Initialized
INFO - 2020-09-09 18:00:58 --> Output Class Initialized
INFO - 2020-09-09 18:00:58 --> Security Class Initialized
DEBUG - 2020-09-09 18:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:00:58 --> Input Class Initialized
INFO - 2020-09-09 18:00:58 --> Language Class Initialized
INFO - 2020-09-09 18:00:58 --> Loader Class Initialized
INFO - 2020-09-09 18:00:58 --> Helper loaded: url_helper
INFO - 2020-09-09 18:00:58 --> Database Driver Class Initialized
INFO - 2020-09-09 18:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:00:58 --> Email Class Initialized
INFO - 2020-09-09 18:00:58 --> Controller Class Initialized
INFO - 2020-09-09 18:00:58 --> Model Class Initialized
INFO - 2020-09-09 18:00:58 --> Model Class Initialized
INFO - 2020-09-09 18:00:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:00:58 --> Final output sent to browser
DEBUG - 2020-09-09 18:00:58 --> Total execution time: 0.0410
ERROR - 2020-09-09 18:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:00:59 --> Config Class Initialized
INFO - 2020-09-09 18:00:59 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:00:59 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:00:59 --> Utf8 Class Initialized
INFO - 2020-09-09 18:00:59 --> URI Class Initialized
INFO - 2020-09-09 18:00:59 --> Router Class Initialized
INFO - 2020-09-09 18:00:59 --> Output Class Initialized
INFO - 2020-09-09 18:00:59 --> Security Class Initialized
DEBUG - 2020-09-09 18:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:00:59 --> Input Class Initialized
INFO - 2020-09-09 18:00:59 --> Language Class Initialized
INFO - 2020-09-09 18:00:59 --> Loader Class Initialized
INFO - 2020-09-09 18:00:59 --> Helper loaded: url_helper
INFO - 2020-09-09 18:00:59 --> Database Driver Class Initialized
INFO - 2020-09-09 18:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:00:59 --> Email Class Initialized
INFO - 2020-09-09 18:00:59 --> Controller Class Initialized
INFO - 2020-09-09 18:00:59 --> Model Class Initialized
INFO - 2020-09-09 18:00:59 --> Model Class Initialized
INFO - 2020-09-09 18:00:59 --> Final output sent to browser
DEBUG - 2020-09-09 18:00:59 --> Total execution time: 0.0420
ERROR - 2020-09-09 18:01:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:01:30 --> Config Class Initialized
INFO - 2020-09-09 18:01:30 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:01:30 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:01:30 --> Utf8 Class Initialized
INFO - 2020-09-09 18:01:30 --> URI Class Initialized
INFO - 2020-09-09 18:01:30 --> Router Class Initialized
INFO - 2020-09-09 18:01:30 --> Output Class Initialized
INFO - 2020-09-09 18:01:30 --> Security Class Initialized
DEBUG - 2020-09-09 18:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:01:30 --> Input Class Initialized
INFO - 2020-09-09 18:01:30 --> Language Class Initialized
INFO - 2020-09-09 18:01:30 --> Loader Class Initialized
INFO - 2020-09-09 18:01:30 --> Helper loaded: url_helper
INFO - 2020-09-09 18:01:30 --> Database Driver Class Initialized
INFO - 2020-09-09 18:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:01:30 --> Email Class Initialized
INFO - 2020-09-09 18:01:30 --> Controller Class Initialized
INFO - 2020-09-09 18:01:30 --> Model Class Initialized
INFO - 2020-09-09 18:01:30 --> Model Class Initialized
INFO - 2020-09-09 18:01:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:01:30 --> Final output sent to browser
DEBUG - 2020-09-09 18:01:30 --> Total execution time: 0.0401
ERROR - 2020-09-09 18:01:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:01:31 --> Config Class Initialized
INFO - 2020-09-09 18:01:31 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:01:31 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:01:31 --> Utf8 Class Initialized
INFO - 2020-09-09 18:01:31 --> URI Class Initialized
INFO - 2020-09-09 18:01:31 --> Router Class Initialized
INFO - 2020-09-09 18:01:31 --> Output Class Initialized
INFO - 2020-09-09 18:01:31 --> Security Class Initialized
DEBUG - 2020-09-09 18:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:01:31 --> Input Class Initialized
INFO - 2020-09-09 18:01:31 --> Language Class Initialized
INFO - 2020-09-09 18:01:31 --> Loader Class Initialized
INFO - 2020-09-09 18:01:31 --> Helper loaded: url_helper
INFO - 2020-09-09 18:01:31 --> Database Driver Class Initialized
INFO - 2020-09-09 18:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:01:31 --> Email Class Initialized
INFO - 2020-09-09 18:01:31 --> Controller Class Initialized
INFO - 2020-09-09 18:01:31 --> Model Class Initialized
INFO - 2020-09-09 18:01:31 --> Model Class Initialized
INFO - 2020-09-09 18:01:31 --> Final output sent to browser
DEBUG - 2020-09-09 18:01:31 --> Total execution time: 0.0437
ERROR - 2020-09-09 18:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:02:47 --> Config Class Initialized
INFO - 2020-09-09 18:02:47 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:02:47 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:02:47 --> Utf8 Class Initialized
INFO - 2020-09-09 18:02:47 --> URI Class Initialized
INFO - 2020-09-09 18:02:47 --> Router Class Initialized
INFO - 2020-09-09 18:02:47 --> Output Class Initialized
INFO - 2020-09-09 18:02:47 --> Security Class Initialized
DEBUG - 2020-09-09 18:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:02:47 --> Input Class Initialized
INFO - 2020-09-09 18:02:47 --> Language Class Initialized
INFO - 2020-09-09 18:02:47 --> Loader Class Initialized
INFO - 2020-09-09 18:02:47 --> Helper loaded: url_helper
INFO - 2020-09-09 18:02:47 --> Database Driver Class Initialized
INFO - 2020-09-09 18:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:02:47 --> Email Class Initialized
INFO - 2020-09-09 18:02:47 --> Controller Class Initialized
INFO - 2020-09-09 18:02:47 --> Model Class Initialized
INFO - 2020-09-09 18:02:47 --> Model Class Initialized
INFO - 2020-09-09 18:02:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:02:47 --> Final output sent to browser
DEBUG - 2020-09-09 18:02:47 --> Total execution time: 0.0342
ERROR - 2020-09-09 18:02:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:02:48 --> Config Class Initialized
INFO - 2020-09-09 18:02:48 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:02:48 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:02:48 --> Utf8 Class Initialized
INFO - 2020-09-09 18:02:48 --> URI Class Initialized
INFO - 2020-09-09 18:02:48 --> Router Class Initialized
INFO - 2020-09-09 18:02:48 --> Output Class Initialized
INFO - 2020-09-09 18:02:48 --> Security Class Initialized
DEBUG - 2020-09-09 18:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:02:48 --> Input Class Initialized
INFO - 2020-09-09 18:02:48 --> Language Class Initialized
INFO - 2020-09-09 18:02:48 --> Loader Class Initialized
INFO - 2020-09-09 18:02:48 --> Helper loaded: url_helper
INFO - 2020-09-09 18:02:48 --> Database Driver Class Initialized
INFO - 2020-09-09 18:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:02:48 --> Email Class Initialized
INFO - 2020-09-09 18:02:48 --> Controller Class Initialized
INFO - 2020-09-09 18:02:48 --> Model Class Initialized
INFO - 2020-09-09 18:02:48 --> Model Class Initialized
INFO - 2020-09-09 18:02:48 --> Final output sent to browser
DEBUG - 2020-09-09 18:02:48 --> Total execution time: 0.0409
ERROR - 2020-09-09 18:04:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:04:04 --> Config Class Initialized
INFO - 2020-09-09 18:04:04 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:04:04 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:04:04 --> Utf8 Class Initialized
INFO - 2020-09-09 18:04:04 --> URI Class Initialized
INFO - 2020-09-09 18:04:04 --> Router Class Initialized
INFO - 2020-09-09 18:04:04 --> Output Class Initialized
INFO - 2020-09-09 18:04:04 --> Security Class Initialized
DEBUG - 2020-09-09 18:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:04:04 --> Input Class Initialized
INFO - 2020-09-09 18:04:04 --> Language Class Initialized
INFO - 2020-09-09 18:04:04 --> Loader Class Initialized
INFO - 2020-09-09 18:04:04 --> Helper loaded: url_helper
INFO - 2020-09-09 18:04:04 --> Database Driver Class Initialized
INFO - 2020-09-09 18:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:04:04 --> Email Class Initialized
INFO - 2020-09-09 18:04:04 --> Controller Class Initialized
INFO - 2020-09-09 18:04:04 --> Model Class Initialized
INFO - 2020-09-09 18:04:04 --> Model Class Initialized
INFO - 2020-09-09 18:04:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:04:04 --> Final output sent to browser
DEBUG - 2020-09-09 18:04:04 --> Total execution time: 0.0340
ERROR - 2020-09-09 18:04:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:04:05 --> Config Class Initialized
INFO - 2020-09-09 18:04:05 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:04:05 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:04:05 --> Utf8 Class Initialized
INFO - 2020-09-09 18:04:05 --> URI Class Initialized
INFO - 2020-09-09 18:04:05 --> Router Class Initialized
INFO - 2020-09-09 18:04:05 --> Output Class Initialized
INFO - 2020-09-09 18:04:05 --> Security Class Initialized
DEBUG - 2020-09-09 18:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:04:05 --> Input Class Initialized
INFO - 2020-09-09 18:04:05 --> Language Class Initialized
INFO - 2020-09-09 18:04:05 --> Loader Class Initialized
INFO - 2020-09-09 18:04:05 --> Helper loaded: url_helper
INFO - 2020-09-09 18:04:05 --> Database Driver Class Initialized
INFO - 2020-09-09 18:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:04:05 --> Email Class Initialized
INFO - 2020-09-09 18:04:05 --> Controller Class Initialized
INFO - 2020-09-09 18:04:05 --> Model Class Initialized
INFO - 2020-09-09 18:04:05 --> Model Class Initialized
INFO - 2020-09-09 18:04:05 --> Final output sent to browser
DEBUG - 2020-09-09 18:04:05 --> Total execution time: 0.0354
ERROR - 2020-09-09 18:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:04:52 --> Config Class Initialized
INFO - 2020-09-09 18:04:52 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:04:52 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:04:52 --> Utf8 Class Initialized
INFO - 2020-09-09 18:04:52 --> URI Class Initialized
INFO - 2020-09-09 18:04:52 --> Router Class Initialized
INFO - 2020-09-09 18:04:52 --> Output Class Initialized
INFO - 2020-09-09 18:04:52 --> Security Class Initialized
DEBUG - 2020-09-09 18:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:04:52 --> Input Class Initialized
INFO - 2020-09-09 18:04:52 --> Language Class Initialized
INFO - 2020-09-09 18:04:52 --> Loader Class Initialized
INFO - 2020-09-09 18:04:52 --> Helper loaded: url_helper
INFO - 2020-09-09 18:04:52 --> Database Driver Class Initialized
INFO - 2020-09-09 18:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:04:52 --> Email Class Initialized
INFO - 2020-09-09 18:04:52 --> Controller Class Initialized
INFO - 2020-09-09 18:04:52 --> Model Class Initialized
INFO - 2020-09-09 18:04:52 --> Model Class Initialized
INFO - 2020-09-09 18:04:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:04:52 --> Final output sent to browser
DEBUG - 2020-09-09 18:04:52 --> Total execution time: 0.0407
ERROR - 2020-09-09 18:04:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:04:53 --> Config Class Initialized
INFO - 2020-09-09 18:04:53 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:04:53 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:04:53 --> Utf8 Class Initialized
INFO - 2020-09-09 18:04:53 --> URI Class Initialized
INFO - 2020-09-09 18:04:53 --> Router Class Initialized
INFO - 2020-09-09 18:04:53 --> Output Class Initialized
INFO - 2020-09-09 18:04:53 --> Security Class Initialized
DEBUG - 2020-09-09 18:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:04:53 --> Input Class Initialized
INFO - 2020-09-09 18:04:53 --> Language Class Initialized
INFO - 2020-09-09 18:04:53 --> Loader Class Initialized
INFO - 2020-09-09 18:04:53 --> Helper loaded: url_helper
INFO - 2020-09-09 18:04:53 --> Database Driver Class Initialized
INFO - 2020-09-09 18:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:04:53 --> Email Class Initialized
INFO - 2020-09-09 18:04:53 --> Controller Class Initialized
INFO - 2020-09-09 18:04:53 --> Model Class Initialized
INFO - 2020-09-09 18:04:53 --> Model Class Initialized
INFO - 2020-09-09 18:04:53 --> Final output sent to browser
DEBUG - 2020-09-09 18:04:53 --> Total execution time: 0.0425
ERROR - 2020-09-09 18:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:05:01 --> Config Class Initialized
INFO - 2020-09-09 18:05:01 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:05:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:05:01 --> Utf8 Class Initialized
INFO - 2020-09-09 18:05:01 --> URI Class Initialized
INFO - 2020-09-09 18:05:01 --> Router Class Initialized
INFO - 2020-09-09 18:05:01 --> Output Class Initialized
INFO - 2020-09-09 18:05:01 --> Security Class Initialized
DEBUG - 2020-09-09 18:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:05:01 --> Input Class Initialized
INFO - 2020-09-09 18:05:01 --> Language Class Initialized
INFO - 2020-09-09 18:05:01 --> Loader Class Initialized
INFO - 2020-09-09 18:05:01 --> Helper loaded: url_helper
INFO - 2020-09-09 18:05:01 --> Database Driver Class Initialized
INFO - 2020-09-09 18:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:05:01 --> Email Class Initialized
INFO - 2020-09-09 18:05:01 --> Controller Class Initialized
INFO - 2020-09-09 18:05:01 --> Model Class Initialized
INFO - 2020-09-09 18:05:01 --> Model Class Initialized
INFO - 2020-09-09 18:05:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-09 18:05:01 --> Final output sent to browser
DEBUG - 2020-09-09 18:05:01 --> Total execution time: 0.1025
ERROR - 2020-09-09 18:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:05:01 --> Config Class Initialized
INFO - 2020-09-09 18:05:01 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:05:01 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:05:01 --> Utf8 Class Initialized
INFO - 2020-09-09 18:05:01 --> URI Class Initialized
INFO - 2020-09-09 18:05:01 --> Router Class Initialized
INFO - 2020-09-09 18:05:01 --> Output Class Initialized
INFO - 2020-09-09 18:05:01 --> Security Class Initialized
DEBUG - 2020-09-09 18:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:05:01 --> Input Class Initialized
INFO - 2020-09-09 18:05:01 --> Language Class Initialized
INFO - 2020-09-09 18:05:01 --> Loader Class Initialized
INFO - 2020-09-09 18:05:01 --> Helper loaded: url_helper
INFO - 2020-09-09 18:05:01 --> Database Driver Class Initialized
INFO - 2020-09-09 18:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:05:01 --> Email Class Initialized
INFO - 2020-09-09 18:05:01 --> Controller Class Initialized
INFO - 2020-09-09 18:05:01 --> Model Class Initialized
INFO - 2020-09-09 18:05:01 --> Model Class Initialized
INFO - 2020-09-09 18:05:01 --> Final output sent to browser
DEBUG - 2020-09-09 18:05:01 --> Total execution time: 0.0380
ERROR - 2020-09-09 18:07:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:07:06 --> Config Class Initialized
INFO - 2020-09-09 18:07:06 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:07:06 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:07:06 --> Utf8 Class Initialized
INFO - 2020-09-09 18:07:06 --> URI Class Initialized
INFO - 2020-09-09 18:07:06 --> Router Class Initialized
INFO - 2020-09-09 18:07:06 --> Output Class Initialized
INFO - 2020-09-09 18:07:06 --> Security Class Initialized
DEBUG - 2020-09-09 18:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:07:06 --> Input Class Initialized
INFO - 2020-09-09 18:07:06 --> Language Class Initialized
INFO - 2020-09-09 18:07:06 --> Loader Class Initialized
INFO - 2020-09-09 18:07:06 --> Helper loaded: url_helper
INFO - 2020-09-09 18:07:06 --> Database Driver Class Initialized
INFO - 2020-09-09 18:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:07:06 --> Email Class Initialized
INFO - 2020-09-09 18:07:06 --> Controller Class Initialized
DEBUG - 2020-09-09 18:07:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-09 18:07:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-09 18:07:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-09 18:07:06 --> Final output sent to browser
DEBUG - 2020-09-09 18:07:06 --> Total execution time: 0.0222
ERROR - 2020-09-09 18:07:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-09 18:07:12 --> Config Class Initialized
INFO - 2020-09-09 18:07:12 --> Hooks Class Initialized
DEBUG - 2020-09-09 18:07:12 --> UTF-8 Support Enabled
INFO - 2020-09-09 18:07:12 --> Utf8 Class Initialized
INFO - 2020-09-09 18:07:12 --> URI Class Initialized
DEBUG - 2020-09-09 18:07:12 --> No URI present. Default controller set.
INFO - 2020-09-09 18:07:12 --> Router Class Initialized
INFO - 2020-09-09 18:07:12 --> Output Class Initialized
INFO - 2020-09-09 18:07:12 --> Security Class Initialized
DEBUG - 2020-09-09 18:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-09 18:07:12 --> Input Class Initialized
INFO - 2020-09-09 18:07:12 --> Language Class Initialized
INFO - 2020-09-09 18:07:12 --> Loader Class Initialized
INFO - 2020-09-09 18:07:12 --> Helper loaded: url_helper
INFO - 2020-09-09 18:07:12 --> Database Driver Class Initialized
INFO - 2020-09-09 18:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-09 18:07:12 --> Email Class Initialized
INFO - 2020-09-09 18:07:12 --> Controller Class Initialized
INFO - 2020-09-09 18:07:12 --> Model Class Initialized
INFO - 2020-09-09 18:07:12 --> Model Class Initialized
DEBUG - 2020-09-09 18:07:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-09 18:07:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-09 18:07:12 --> Final output sent to browser
DEBUG - 2020-09-09 18:07:12 --> Total execution time: 0.0206
