<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-28 08:14:38 --> Config Class Initialized
INFO - 2020-07-28 08:14:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:14:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:14:38 --> Utf8 Class Initialized
INFO - 2020-07-28 08:14:38 --> URI Class Initialized
DEBUG - 2020-07-28 08:14:38 --> No URI present. Default controller set.
INFO - 2020-07-28 08:14:38 --> Router Class Initialized
INFO - 2020-07-28 08:14:38 --> Output Class Initialized
INFO - 2020-07-28 08:14:38 --> Security Class Initialized
DEBUG - 2020-07-28 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:14:38 --> Input Class Initialized
INFO - 2020-07-28 08:14:38 --> Language Class Initialized
INFO - 2020-07-28 08:14:38 --> Loader Class Initialized
INFO - 2020-07-28 08:14:38 --> Helper loaded: url_helper
INFO - 2020-07-28 08:14:38 --> Helper loaded: file_helper
INFO - 2020-07-28 08:14:38 --> Database Driver Class Initialized
INFO - 2020-07-28 08:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:14:38 --> Controller Class Initialized
INFO - 2020-07-28 08:14:38 --> Model Class Initialized
INFO - 2020-07-28 08:14:38 --> Model Class Initialized
DEBUG - 2020-07-28 08:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:14:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:14:38 --> Final output sent to browser
DEBUG - 2020-07-28 08:14:38 --> Total execution time: 0.1881
INFO - 2020-07-28 08:14:42 --> Config Class Initialized
INFO - 2020-07-28 08:14:42 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:14:42 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:14:42 --> Utf8 Class Initialized
INFO - 2020-07-28 08:14:42 --> URI Class Initialized
DEBUG - 2020-07-28 08:14:42 --> No URI present. Default controller set.
INFO - 2020-07-28 08:14:42 --> Router Class Initialized
INFO - 2020-07-28 08:14:42 --> Output Class Initialized
INFO - 2020-07-28 08:14:42 --> Security Class Initialized
DEBUG - 2020-07-28 08:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:14:42 --> Input Class Initialized
INFO - 2020-07-28 08:14:42 --> Language Class Initialized
INFO - 2020-07-28 08:14:42 --> Loader Class Initialized
INFO - 2020-07-28 08:14:42 --> Helper loaded: url_helper
INFO - 2020-07-28 08:14:42 --> Helper loaded: file_helper
INFO - 2020-07-28 08:14:42 --> Database Driver Class Initialized
INFO - 2020-07-28 08:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:14:42 --> Controller Class Initialized
INFO - 2020-07-28 08:14:42 --> Model Class Initialized
INFO - 2020-07-28 08:14:42 --> Model Class Initialized
DEBUG - 2020-07-28 08:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:14:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:14:42 --> Final output sent to browser
DEBUG - 2020-07-28 08:14:42 --> Total execution time: 0.0214
INFO - 2020-07-28 08:14:45 --> Config Class Initialized
INFO - 2020-07-28 08:14:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:14:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:14:45 --> Utf8 Class Initialized
INFO - 2020-07-28 08:14:45 --> URI Class Initialized
INFO - 2020-07-28 08:14:45 --> Router Class Initialized
INFO - 2020-07-28 08:14:45 --> Output Class Initialized
INFO - 2020-07-28 08:14:45 --> Security Class Initialized
DEBUG - 2020-07-28 08:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:14:45 --> Input Class Initialized
INFO - 2020-07-28 08:14:45 --> Language Class Initialized
INFO - 2020-07-28 08:14:45 --> Loader Class Initialized
INFO - 2020-07-28 08:14:45 --> Helper loaded: url_helper
INFO - 2020-07-28 08:14:45 --> Helper loaded: file_helper
INFO - 2020-07-28 08:14:45 --> Database Driver Class Initialized
INFO - 2020-07-28 08:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:14:45 --> Controller Class Initialized
INFO - 2020-07-28 08:14:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 08:14:45 --> Final output sent to browser
DEBUG - 2020-07-28 08:14:45 --> Total execution time: 0.0514
INFO - 2020-07-28 08:19:30 --> Config Class Initialized
INFO - 2020-07-28 08:19:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:19:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:19:30 --> Utf8 Class Initialized
INFO - 2020-07-28 08:19:30 --> URI Class Initialized
DEBUG - 2020-07-28 08:19:30 --> No URI present. Default controller set.
INFO - 2020-07-28 08:19:30 --> Router Class Initialized
INFO - 2020-07-28 08:19:30 --> Output Class Initialized
INFO - 2020-07-28 08:19:30 --> Security Class Initialized
DEBUG - 2020-07-28 08:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:19:30 --> Input Class Initialized
INFO - 2020-07-28 08:19:30 --> Language Class Initialized
INFO - 2020-07-28 08:19:30 --> Loader Class Initialized
INFO - 2020-07-28 08:19:30 --> Helper loaded: url_helper
INFO - 2020-07-28 08:19:30 --> Helper loaded: file_helper
INFO - 2020-07-28 08:19:30 --> Database Driver Class Initialized
INFO - 2020-07-28 08:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:19:30 --> Controller Class Initialized
INFO - 2020-07-28 08:19:30 --> Model Class Initialized
INFO - 2020-07-28 08:19:30 --> Model Class Initialized
DEBUG - 2020-07-28 08:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:19:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:19:30 --> Final output sent to browser
DEBUG - 2020-07-28 08:19:30 --> Total execution time: 0.0247
INFO - 2020-07-28 08:19:33 --> Config Class Initialized
INFO - 2020-07-28 08:19:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:19:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:19:33 --> Utf8 Class Initialized
INFO - 2020-07-28 08:19:33 --> URI Class Initialized
INFO - 2020-07-28 08:19:33 --> Router Class Initialized
INFO - 2020-07-28 08:19:33 --> Output Class Initialized
INFO - 2020-07-28 08:19:33 --> Security Class Initialized
DEBUG - 2020-07-28 08:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:19:33 --> Input Class Initialized
INFO - 2020-07-28 08:19:33 --> Language Class Initialized
INFO - 2020-07-28 08:19:33 --> Loader Class Initialized
INFO - 2020-07-28 08:19:33 --> Helper loaded: url_helper
INFO - 2020-07-28 08:19:33 --> Helper loaded: file_helper
INFO - 2020-07-28 08:19:33 --> Database Driver Class Initialized
INFO - 2020-07-28 08:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:19:33 --> Controller Class Initialized
INFO - 2020-07-28 08:19:33 --> Model Class Initialized
INFO - 2020-07-28 08:19:33 --> Model Class Initialized
DEBUG - 2020-07-28 08:19:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:19:33 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:19:33 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:19:33 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:19:33 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:19:33 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:19:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:20:44 --> Config Class Initialized
INFO - 2020-07-28 08:20:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:20:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:20:44 --> Utf8 Class Initialized
INFO - 2020-07-28 08:20:44 --> URI Class Initialized
INFO - 2020-07-28 08:20:44 --> Router Class Initialized
INFO - 2020-07-28 08:20:44 --> Output Class Initialized
INFO - 2020-07-28 08:20:44 --> Security Class Initialized
DEBUG - 2020-07-28 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:20:44 --> Input Class Initialized
INFO - 2020-07-28 08:20:44 --> Language Class Initialized
INFO - 2020-07-28 08:20:44 --> Loader Class Initialized
INFO - 2020-07-28 08:20:44 --> Helper loaded: url_helper
INFO - 2020-07-28 08:20:44 --> Helper loaded: file_helper
INFO - 2020-07-28 08:20:44 --> Database Driver Class Initialized
INFO - 2020-07-28 08:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:20:44 --> Controller Class Initialized
INFO - 2020-07-28 08:20:44 --> Model Class Initialized
INFO - 2020-07-28 08:20:44 --> Model Class Initialized
DEBUG - 2020-07-28 08:20:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:20:44 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:20:44 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:20:44 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:20:44 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:20:44 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:20:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:20:47 --> Config Class Initialized
INFO - 2020-07-28 08:20:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:20:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:20:47 --> Utf8 Class Initialized
INFO - 2020-07-28 08:20:47 --> URI Class Initialized
DEBUG - 2020-07-28 08:20:47 --> No URI present. Default controller set.
INFO - 2020-07-28 08:20:47 --> Router Class Initialized
INFO - 2020-07-28 08:20:47 --> Output Class Initialized
INFO - 2020-07-28 08:20:47 --> Security Class Initialized
DEBUG - 2020-07-28 08:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:20:47 --> Input Class Initialized
INFO - 2020-07-28 08:20:47 --> Language Class Initialized
INFO - 2020-07-28 08:20:47 --> Loader Class Initialized
INFO - 2020-07-28 08:20:47 --> Helper loaded: url_helper
INFO - 2020-07-28 08:20:47 --> Helper loaded: file_helper
INFO - 2020-07-28 08:20:47 --> Database Driver Class Initialized
INFO - 2020-07-28 08:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:20:47 --> Controller Class Initialized
INFO - 2020-07-28 08:20:47 --> Model Class Initialized
INFO - 2020-07-28 08:20:47 --> Model Class Initialized
DEBUG - 2020-07-28 08:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:20:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:20:47 --> Final output sent to browser
DEBUG - 2020-07-28 08:20:47 --> Total execution time: 0.0212
INFO - 2020-07-28 08:20:51 --> Config Class Initialized
INFO - 2020-07-28 08:20:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:20:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:20:51 --> Utf8 Class Initialized
INFO - 2020-07-28 08:20:51 --> URI Class Initialized
DEBUG - 2020-07-28 08:20:51 --> No URI present. Default controller set.
INFO - 2020-07-28 08:20:51 --> Router Class Initialized
INFO - 2020-07-28 08:20:51 --> Output Class Initialized
INFO - 2020-07-28 08:20:51 --> Security Class Initialized
DEBUG - 2020-07-28 08:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:20:51 --> Input Class Initialized
INFO - 2020-07-28 08:20:51 --> Language Class Initialized
INFO - 2020-07-28 08:20:51 --> Loader Class Initialized
INFO - 2020-07-28 08:20:51 --> Helper loaded: url_helper
INFO - 2020-07-28 08:20:51 --> Helper loaded: file_helper
INFO - 2020-07-28 08:20:51 --> Database Driver Class Initialized
INFO - 2020-07-28 08:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:20:51 --> Controller Class Initialized
INFO - 2020-07-28 08:20:51 --> Model Class Initialized
INFO - 2020-07-28 08:20:51 --> Model Class Initialized
DEBUG - 2020-07-28 08:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:20:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:20:51 --> Final output sent to browser
DEBUG - 2020-07-28 08:20:51 --> Total execution time: 0.0228
INFO - 2020-07-28 08:20:53 --> Config Class Initialized
INFO - 2020-07-28 08:20:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:20:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:20:53 --> Utf8 Class Initialized
INFO - 2020-07-28 08:20:53 --> URI Class Initialized
INFO - 2020-07-28 08:20:53 --> Router Class Initialized
INFO - 2020-07-28 08:20:53 --> Output Class Initialized
INFO - 2020-07-28 08:20:53 --> Security Class Initialized
DEBUG - 2020-07-28 08:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:20:53 --> Input Class Initialized
INFO - 2020-07-28 08:20:53 --> Language Class Initialized
INFO - 2020-07-28 08:20:53 --> Loader Class Initialized
INFO - 2020-07-28 08:20:53 --> Helper loaded: url_helper
INFO - 2020-07-28 08:20:53 --> Helper loaded: file_helper
INFO - 2020-07-28 08:20:53 --> Database Driver Class Initialized
INFO - 2020-07-28 08:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:20:53 --> Controller Class Initialized
INFO - 2020-07-28 08:20:53 --> Model Class Initialized
INFO - 2020-07-28 08:20:53 --> Model Class Initialized
DEBUG - 2020-07-28 08:20:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:20:53 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:20:53 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:20:53 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:20:53 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:20:53 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:20:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:26:26 --> Config Class Initialized
INFO - 2020-07-28 08:26:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:26:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:26:26 --> Utf8 Class Initialized
INFO - 2020-07-28 08:26:26 --> URI Class Initialized
INFO - 2020-07-28 08:26:26 --> Router Class Initialized
INFO - 2020-07-28 08:26:26 --> Output Class Initialized
INFO - 2020-07-28 08:26:26 --> Security Class Initialized
DEBUG - 2020-07-28 08:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:26:26 --> Input Class Initialized
INFO - 2020-07-28 08:26:26 --> Language Class Initialized
INFO - 2020-07-28 08:26:26 --> Loader Class Initialized
INFO - 2020-07-28 08:26:26 --> Helper loaded: url_helper
INFO - 2020-07-28 08:26:26 --> Helper loaded: file_helper
INFO - 2020-07-28 08:26:26 --> Database Driver Class Initialized
INFO - 2020-07-28 08:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:26:26 --> Email Class Initialized
INFO - 2020-07-28 08:26:26 --> Controller Class Initialized
INFO - 2020-07-28 08:26:26 --> Model Class Initialized
INFO - 2020-07-28 08:26:26 --> Model Class Initialized
DEBUG - 2020-07-28 08:26:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:26:26 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:26:26 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:26:26 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:26:26 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:26:26 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:26:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:26:47 --> Config Class Initialized
INFO - 2020-07-28 08:26:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:26:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:26:47 --> Utf8 Class Initialized
INFO - 2020-07-28 08:26:47 --> URI Class Initialized
DEBUG - 2020-07-28 08:26:47 --> No URI present. Default controller set.
INFO - 2020-07-28 08:26:47 --> Router Class Initialized
INFO - 2020-07-28 08:26:47 --> Output Class Initialized
INFO - 2020-07-28 08:26:47 --> Security Class Initialized
DEBUG - 2020-07-28 08:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:26:47 --> Input Class Initialized
INFO - 2020-07-28 08:26:47 --> Language Class Initialized
INFO - 2020-07-28 08:26:47 --> Loader Class Initialized
INFO - 2020-07-28 08:26:47 --> Helper loaded: url_helper
INFO - 2020-07-28 08:26:47 --> Helper loaded: file_helper
INFO - 2020-07-28 08:26:47 --> Database Driver Class Initialized
INFO - 2020-07-28 08:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:26:47 --> Email Class Initialized
INFO - 2020-07-28 08:26:47 --> Controller Class Initialized
INFO - 2020-07-28 08:26:47 --> Model Class Initialized
INFO - 2020-07-28 08:26:47 --> Model Class Initialized
DEBUG - 2020-07-28 08:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:26:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:26:47 --> Final output sent to browser
DEBUG - 2020-07-28 08:26:47 --> Total execution time: 0.0454
INFO - 2020-07-28 08:26:52 --> Config Class Initialized
INFO - 2020-07-28 08:26:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:26:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:26:52 --> Utf8 Class Initialized
INFO - 2020-07-28 08:26:52 --> URI Class Initialized
DEBUG - 2020-07-28 08:26:52 --> No URI present. Default controller set.
INFO - 2020-07-28 08:26:52 --> Router Class Initialized
INFO - 2020-07-28 08:26:52 --> Output Class Initialized
INFO - 2020-07-28 08:26:52 --> Security Class Initialized
DEBUG - 2020-07-28 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:26:52 --> Input Class Initialized
INFO - 2020-07-28 08:26:52 --> Language Class Initialized
INFO - 2020-07-28 08:26:52 --> Loader Class Initialized
INFO - 2020-07-28 08:26:52 --> Helper loaded: url_helper
INFO - 2020-07-28 08:26:52 --> Helper loaded: file_helper
INFO - 2020-07-28 08:26:52 --> Database Driver Class Initialized
INFO - 2020-07-28 08:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:26:52 --> Email Class Initialized
INFO - 2020-07-28 08:26:52 --> Controller Class Initialized
INFO - 2020-07-28 08:26:52 --> Model Class Initialized
INFO - 2020-07-28 08:26:52 --> Model Class Initialized
DEBUG - 2020-07-28 08:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:26:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:26:52 --> Final output sent to browser
DEBUG - 2020-07-28 08:26:52 --> Total execution time: 0.0234
INFO - 2020-07-28 08:27:04 --> Config Class Initialized
INFO - 2020-07-28 08:27:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:27:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:27:04 --> Utf8 Class Initialized
INFO - 2020-07-28 08:27:04 --> URI Class Initialized
INFO - 2020-07-28 08:27:04 --> Router Class Initialized
INFO - 2020-07-28 08:27:04 --> Output Class Initialized
INFO - 2020-07-28 08:27:04 --> Security Class Initialized
DEBUG - 2020-07-28 08:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:27:04 --> Input Class Initialized
INFO - 2020-07-28 08:27:04 --> Language Class Initialized
INFO - 2020-07-28 08:27:04 --> Loader Class Initialized
INFO - 2020-07-28 08:27:04 --> Helper loaded: url_helper
INFO - 2020-07-28 08:27:04 --> Helper loaded: file_helper
INFO - 2020-07-28 08:27:04 --> Database Driver Class Initialized
INFO - 2020-07-28 08:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:27:04 --> Email Class Initialized
INFO - 2020-07-28 08:27:04 --> Controller Class Initialized
INFO - 2020-07-28 08:27:04 --> Model Class Initialized
INFO - 2020-07-28 08:27:04 --> Model Class Initialized
DEBUG - 2020-07-28 08:27:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:27:04 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:27:04 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:27:04 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:27:04 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:27:04 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:27:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:34:32 --> Config Class Initialized
INFO - 2020-07-28 08:34:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:34:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:34:32 --> Utf8 Class Initialized
INFO - 2020-07-28 08:34:32 --> URI Class Initialized
INFO - 2020-07-28 08:34:32 --> Router Class Initialized
INFO - 2020-07-28 08:34:32 --> Output Class Initialized
INFO - 2020-07-28 08:34:32 --> Security Class Initialized
DEBUG - 2020-07-28 08:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:34:32 --> Input Class Initialized
INFO - 2020-07-28 08:34:32 --> Language Class Initialized
INFO - 2020-07-28 08:34:32 --> Loader Class Initialized
INFO - 2020-07-28 08:34:32 --> Helper loaded: url_helper
INFO - 2020-07-28 08:34:32 --> Helper loaded: file_helper
INFO - 2020-07-28 08:34:32 --> Database Driver Class Initialized
INFO - 2020-07-28 08:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:34:32 --> Email Class Initialized
INFO - 2020-07-28 08:34:32 --> Controller Class Initialized
INFO - 2020-07-28 08:34:32 --> Model Class Initialized
INFO - 2020-07-28 08:34:32 --> Model Class Initialized
DEBUG - 2020-07-28 08:34:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:34:32 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:34:32 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:34:32 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:34:32 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:34:32 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:34:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:35:56 --> Config Class Initialized
INFO - 2020-07-28 08:35:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:35:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:35:56 --> Utf8 Class Initialized
INFO - 2020-07-28 08:35:56 --> URI Class Initialized
INFO - 2020-07-28 08:35:56 --> Router Class Initialized
INFO - 2020-07-28 08:35:56 --> Output Class Initialized
INFO - 2020-07-28 08:35:56 --> Security Class Initialized
DEBUG - 2020-07-28 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:35:56 --> Input Class Initialized
INFO - 2020-07-28 08:35:56 --> Language Class Initialized
INFO - 2020-07-28 08:35:56 --> Loader Class Initialized
INFO - 2020-07-28 08:35:56 --> Helper loaded: url_helper
INFO - 2020-07-28 08:35:56 --> Helper loaded: file_helper
INFO - 2020-07-28 08:35:56 --> Database Driver Class Initialized
INFO - 2020-07-28 08:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:35:56 --> Email Class Initialized
INFO - 2020-07-28 08:35:56 --> Controller Class Initialized
INFO - 2020-07-28 08:35:56 --> Model Class Initialized
INFO - 2020-07-28 08:35:56 --> Model Class Initialized
DEBUG - 2020-07-28 08:35:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:35:56 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:35:56 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:35:56 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:35:56 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:35:56 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:35:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:35:58 --> Config Class Initialized
INFO - 2020-07-28 08:35:58 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:35:58 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:35:58 --> Utf8 Class Initialized
INFO - 2020-07-28 08:35:58 --> URI Class Initialized
DEBUG - 2020-07-28 08:35:58 --> No URI present. Default controller set.
INFO - 2020-07-28 08:35:58 --> Router Class Initialized
INFO - 2020-07-28 08:35:58 --> Output Class Initialized
INFO - 2020-07-28 08:35:58 --> Security Class Initialized
DEBUG - 2020-07-28 08:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:35:58 --> Input Class Initialized
INFO - 2020-07-28 08:35:58 --> Language Class Initialized
INFO - 2020-07-28 08:35:58 --> Loader Class Initialized
INFO - 2020-07-28 08:35:58 --> Helper loaded: url_helper
INFO - 2020-07-28 08:35:58 --> Helper loaded: file_helper
INFO - 2020-07-28 08:35:58 --> Database Driver Class Initialized
INFO - 2020-07-28 08:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:35:58 --> Email Class Initialized
INFO - 2020-07-28 08:35:58 --> Controller Class Initialized
INFO - 2020-07-28 08:35:58 --> Model Class Initialized
INFO - 2020-07-28 08:35:58 --> Model Class Initialized
DEBUG - 2020-07-28 08:35:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:35:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:35:58 --> Final output sent to browser
DEBUG - 2020-07-28 08:35:58 --> Total execution time: 0.0235
INFO - 2020-07-28 08:36:14 --> Config Class Initialized
INFO - 2020-07-28 08:36:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:36:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:36:14 --> Utf8 Class Initialized
INFO - 2020-07-28 08:36:14 --> URI Class Initialized
DEBUG - 2020-07-28 08:36:14 --> No URI present. Default controller set.
INFO - 2020-07-28 08:36:14 --> Router Class Initialized
INFO - 2020-07-28 08:36:14 --> Output Class Initialized
INFO - 2020-07-28 08:36:14 --> Security Class Initialized
DEBUG - 2020-07-28 08:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:36:14 --> Input Class Initialized
INFO - 2020-07-28 08:36:14 --> Language Class Initialized
INFO - 2020-07-28 08:36:14 --> Loader Class Initialized
INFO - 2020-07-28 08:36:14 --> Helper loaded: url_helper
INFO - 2020-07-28 08:36:14 --> Helper loaded: file_helper
INFO - 2020-07-28 08:36:14 --> Database Driver Class Initialized
INFO - 2020-07-28 08:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:36:14 --> Email Class Initialized
INFO - 2020-07-28 08:36:14 --> Controller Class Initialized
INFO - 2020-07-28 08:36:14 --> Model Class Initialized
INFO - 2020-07-28 08:36:14 --> Model Class Initialized
DEBUG - 2020-07-28 08:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:36:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:36:14 --> Final output sent to browser
DEBUG - 2020-07-28 08:36:14 --> Total execution time: 0.0232
INFO - 2020-07-28 08:36:20 --> Config Class Initialized
INFO - 2020-07-28 08:36:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:36:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:36:20 --> Utf8 Class Initialized
INFO - 2020-07-28 08:36:20 --> URI Class Initialized
INFO - 2020-07-28 08:36:20 --> Router Class Initialized
INFO - 2020-07-28 08:36:20 --> Output Class Initialized
INFO - 2020-07-28 08:36:20 --> Security Class Initialized
DEBUG - 2020-07-28 08:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:36:20 --> Input Class Initialized
INFO - 2020-07-28 08:36:20 --> Language Class Initialized
INFO - 2020-07-28 08:36:20 --> Loader Class Initialized
INFO - 2020-07-28 08:36:20 --> Helper loaded: url_helper
INFO - 2020-07-28 08:36:20 --> Helper loaded: file_helper
INFO - 2020-07-28 08:36:20 --> Database Driver Class Initialized
INFO - 2020-07-28 08:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:36:20 --> Email Class Initialized
INFO - 2020-07-28 08:36:20 --> Controller Class Initialized
INFO - 2020-07-28 08:36:20 --> Model Class Initialized
INFO - 2020-07-28 08:36:20 --> Model Class Initialized
DEBUG - 2020-07-28 08:36:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:36:20 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:36:20 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:36:20 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:36:20 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:36:20 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:36:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:37:03 --> Config Class Initialized
INFO - 2020-07-28 08:37:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:37:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:37:03 --> Utf8 Class Initialized
INFO - 2020-07-28 08:37:03 --> URI Class Initialized
DEBUG - 2020-07-28 08:37:03 --> No URI present. Default controller set.
INFO - 2020-07-28 08:37:03 --> Router Class Initialized
INFO - 2020-07-28 08:37:03 --> Output Class Initialized
INFO - 2020-07-28 08:37:03 --> Security Class Initialized
DEBUG - 2020-07-28 08:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:37:03 --> Input Class Initialized
INFO - 2020-07-28 08:37:03 --> Language Class Initialized
INFO - 2020-07-28 08:37:03 --> Loader Class Initialized
INFO - 2020-07-28 08:37:03 --> Helper loaded: url_helper
INFO - 2020-07-28 08:37:03 --> Helper loaded: file_helper
INFO - 2020-07-28 08:37:03 --> Database Driver Class Initialized
INFO - 2020-07-28 08:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:37:03 --> Email Class Initialized
INFO - 2020-07-28 08:37:03 --> Controller Class Initialized
INFO - 2020-07-28 08:37:03 --> Model Class Initialized
INFO - 2020-07-28 08:37:03 --> Model Class Initialized
DEBUG - 2020-07-28 08:37:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:37:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:37:03 --> Final output sent to browser
DEBUG - 2020-07-28 08:37:03 --> Total execution time: 0.0245
INFO - 2020-07-28 08:37:08 --> Config Class Initialized
INFO - 2020-07-28 08:37:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:37:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:37:08 --> Utf8 Class Initialized
INFO - 2020-07-28 08:37:08 --> URI Class Initialized
INFO - 2020-07-28 08:37:08 --> Router Class Initialized
INFO - 2020-07-28 08:37:08 --> Output Class Initialized
INFO - 2020-07-28 08:37:08 --> Security Class Initialized
DEBUG - 2020-07-28 08:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:37:08 --> Input Class Initialized
INFO - 2020-07-28 08:37:08 --> Language Class Initialized
INFO - 2020-07-28 08:37:08 --> Loader Class Initialized
INFO - 2020-07-28 08:37:08 --> Helper loaded: url_helper
INFO - 2020-07-28 08:37:08 --> Helper loaded: file_helper
INFO - 2020-07-28 08:37:08 --> Database Driver Class Initialized
INFO - 2020-07-28 08:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:37:08 --> Email Class Initialized
INFO - 2020-07-28 08:37:08 --> Controller Class Initialized
INFO - 2020-07-28 08:37:08 --> Model Class Initialized
INFO - 2020-07-28 08:37:08 --> Model Class Initialized
DEBUG - 2020-07-28 08:37:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:37:08 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:37:08 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:37:08 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:37:08 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:37:08 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:37:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:39:17 --> Config Class Initialized
INFO - 2020-07-28 08:39:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:39:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:39:17 --> Utf8 Class Initialized
INFO - 2020-07-28 08:39:17 --> URI Class Initialized
INFO - 2020-07-28 08:39:17 --> Router Class Initialized
INFO - 2020-07-28 08:39:17 --> Output Class Initialized
INFO - 2020-07-28 08:39:17 --> Security Class Initialized
DEBUG - 2020-07-28 08:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:39:17 --> Input Class Initialized
INFO - 2020-07-28 08:39:17 --> Language Class Initialized
INFO - 2020-07-28 08:39:17 --> Loader Class Initialized
INFO - 2020-07-28 08:39:17 --> Helper loaded: url_helper
INFO - 2020-07-28 08:39:17 --> Helper loaded: file_helper
INFO - 2020-07-28 08:39:17 --> Database Driver Class Initialized
INFO - 2020-07-28 08:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:39:17 --> Email Class Initialized
INFO - 2020-07-28 08:39:17 --> Controller Class Initialized
INFO - 2020-07-28 08:39:17 --> Model Class Initialized
INFO - 2020-07-28 08:39:17 --> Model Class Initialized
DEBUG - 2020-07-28 08:39:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:39:17 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:39:17 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:39:17 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:39:17 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:39:17 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:39:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:39:20 --> Config Class Initialized
INFO - 2020-07-28 08:39:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:39:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:39:20 --> Utf8 Class Initialized
INFO - 2020-07-28 08:39:20 --> URI Class Initialized
INFO - 2020-07-28 08:39:20 --> Router Class Initialized
INFO - 2020-07-28 08:39:20 --> Output Class Initialized
INFO - 2020-07-28 08:39:20 --> Security Class Initialized
DEBUG - 2020-07-28 08:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:39:20 --> Input Class Initialized
INFO - 2020-07-28 08:39:20 --> Language Class Initialized
INFO - 2020-07-28 08:39:20 --> Loader Class Initialized
INFO - 2020-07-28 08:39:20 --> Helper loaded: url_helper
INFO - 2020-07-28 08:39:20 --> Helper loaded: file_helper
INFO - 2020-07-28 08:39:20 --> Database Driver Class Initialized
INFO - 2020-07-28 08:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:39:20 --> Email Class Initialized
INFO - 2020-07-28 08:39:20 --> Controller Class Initialized
INFO - 2020-07-28 08:39:20 --> Model Class Initialized
INFO - 2020-07-28 08:39:20 --> Model Class Initialized
DEBUG - 2020-07-28 08:39:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:39:20 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:39:20 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:39:20 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:39:20 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:39:20 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:39:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:39:21 --> Config Class Initialized
INFO - 2020-07-28 08:39:21 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:39:21 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:39:21 --> Utf8 Class Initialized
INFO - 2020-07-28 08:39:21 --> URI Class Initialized
DEBUG - 2020-07-28 08:39:21 --> No URI present. Default controller set.
INFO - 2020-07-28 08:39:21 --> Router Class Initialized
INFO - 2020-07-28 08:39:21 --> Output Class Initialized
INFO - 2020-07-28 08:39:21 --> Security Class Initialized
DEBUG - 2020-07-28 08:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:39:21 --> Input Class Initialized
INFO - 2020-07-28 08:39:21 --> Language Class Initialized
INFO - 2020-07-28 08:39:21 --> Loader Class Initialized
INFO - 2020-07-28 08:39:21 --> Helper loaded: url_helper
INFO - 2020-07-28 08:39:21 --> Helper loaded: file_helper
INFO - 2020-07-28 08:39:21 --> Database Driver Class Initialized
INFO - 2020-07-28 08:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:39:21 --> Email Class Initialized
INFO - 2020-07-28 08:39:21 --> Controller Class Initialized
INFO - 2020-07-28 08:39:21 --> Model Class Initialized
INFO - 2020-07-28 08:39:21 --> Model Class Initialized
DEBUG - 2020-07-28 08:39:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 08:39:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 08:39:21 --> Final output sent to browser
DEBUG - 2020-07-28 08:39:21 --> Total execution time: 0.0234
INFO - 2020-07-28 08:39:24 --> Config Class Initialized
INFO - 2020-07-28 08:39:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:39:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:39:24 --> Utf8 Class Initialized
INFO - 2020-07-28 08:39:24 --> URI Class Initialized
INFO - 2020-07-28 08:39:24 --> Router Class Initialized
INFO - 2020-07-28 08:39:24 --> Output Class Initialized
INFO - 2020-07-28 08:39:24 --> Security Class Initialized
DEBUG - 2020-07-28 08:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:39:24 --> Input Class Initialized
INFO - 2020-07-28 08:39:24 --> Language Class Initialized
INFO - 2020-07-28 08:39:24 --> Loader Class Initialized
INFO - 2020-07-28 08:39:24 --> Helper loaded: url_helper
INFO - 2020-07-28 08:39:24 --> Helper loaded: file_helper
INFO - 2020-07-28 08:39:24 --> Database Driver Class Initialized
INFO - 2020-07-28 08:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:39:24 --> Email Class Initialized
INFO - 2020-07-28 08:39:24 --> Controller Class Initialized
INFO - 2020-07-28 08:39:24 --> Model Class Initialized
INFO - 2020-07-28 08:39:24 --> Model Class Initialized
DEBUG - 2020-07-28 08:39:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:39:24 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 23
ERROR - 2020-07-28 08:39:24 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:39:24 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:39:24 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:39:24 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:39:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:39:53 --> Config Class Initialized
INFO - 2020-07-28 08:39:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:39:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:39:53 --> Utf8 Class Initialized
INFO - 2020-07-28 08:39:53 --> URI Class Initialized
INFO - 2020-07-28 08:39:53 --> Router Class Initialized
INFO - 2020-07-28 08:39:53 --> Output Class Initialized
INFO - 2020-07-28 08:39:53 --> Security Class Initialized
DEBUG - 2020-07-28 08:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:39:53 --> Input Class Initialized
INFO - 2020-07-28 08:39:53 --> Language Class Initialized
INFO - 2020-07-28 08:39:53 --> Loader Class Initialized
INFO - 2020-07-28 08:39:53 --> Helper loaded: url_helper
INFO - 2020-07-28 08:39:53 --> Helper loaded: file_helper
INFO - 2020-07-28 08:39:53 --> Database Driver Class Initialized
INFO - 2020-07-28 08:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:39:53 --> Email Class Initialized
INFO - 2020-07-28 08:39:53 --> Controller Class Initialized
INFO - 2020-07-28 08:39:53 --> Model Class Initialized
INFO - 2020-07-28 08:39:53 --> Model Class Initialized
DEBUG - 2020-07-28 08:39:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:39:53 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 26
ERROR - 2020-07-28 08:39:53 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:39:53 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 41
ERROR - 2020-07-28 08:39:53 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 96
ERROR - 2020-07-28 08:39:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:40:55 --> Config Class Initialized
INFO - 2020-07-28 08:40:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:40:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:40:55 --> Utf8 Class Initialized
INFO - 2020-07-28 08:40:55 --> URI Class Initialized
INFO - 2020-07-28 08:40:55 --> Router Class Initialized
INFO - 2020-07-28 08:40:55 --> Output Class Initialized
INFO - 2020-07-28 08:40:55 --> Security Class Initialized
DEBUG - 2020-07-28 08:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:40:55 --> Input Class Initialized
INFO - 2020-07-28 08:40:55 --> Language Class Initialized
INFO - 2020-07-28 08:40:55 --> Loader Class Initialized
INFO - 2020-07-28 08:40:55 --> Helper loaded: url_helper
INFO - 2020-07-28 08:40:55 --> Helper loaded: file_helper
INFO - 2020-07-28 08:40:55 --> Database Driver Class Initialized
INFO - 2020-07-28 08:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:40:55 --> Email Class Initialized
INFO - 2020-07-28 08:40:55 --> Controller Class Initialized
INFO - 2020-07-28 08:40:55 --> Model Class Initialized
INFO - 2020-07-28 08:40:55 --> Model Class Initialized
DEBUG - 2020-07-28 08:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 08:40:55 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:40:55 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 24
ERROR - 2020-07-28 08:40:55 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:40:55 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 28
ERROR - 2020-07-28 08:40:55 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 42
ERROR - 2020-07-28 08:40:55 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 97
ERROR - 2020-07-28 08:40:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:41:16 --> Config Class Initialized
INFO - 2020-07-28 08:41:16 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:41:16 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:41:16 --> Utf8 Class Initialized
INFO - 2020-07-28 08:41:16 --> URI Class Initialized
INFO - 2020-07-28 08:41:16 --> Router Class Initialized
INFO - 2020-07-28 08:41:16 --> Output Class Initialized
INFO - 2020-07-28 08:41:16 --> Security Class Initialized
DEBUG - 2020-07-28 08:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:41:16 --> Input Class Initialized
INFO - 2020-07-28 08:41:16 --> Language Class Initialized
INFO - 2020-07-28 08:41:16 --> Loader Class Initialized
INFO - 2020-07-28 08:41:16 --> Helper loaded: url_helper
INFO - 2020-07-28 08:41:16 --> Helper loaded: file_helper
INFO - 2020-07-28 08:41:16 --> Database Driver Class Initialized
INFO - 2020-07-28 08:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:41:16 --> Email Class Initialized
INFO - 2020-07-28 08:41:16 --> Controller Class Initialized
INFO - 2020-07-28 08:41:16 --> Model Class Initialized
INFO - 2020-07-28 08:41:16 --> Model Class Initialized
DEBUG - 2020-07-28 08:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 08:41:16 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:41:16 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 24
ERROR - 2020-07-28 08:41:16 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:41:16 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 28
ERROR - 2020-07-28 08:41:16 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 42
ERROR - 2020-07-28 08:41:16 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 97
ERROR - 2020-07-28 08:41:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 08:58:31 --> Config Class Initialized
INFO - 2020-07-28 08:58:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 08:58:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 08:58:31 --> Utf8 Class Initialized
INFO - 2020-07-28 08:58:31 --> URI Class Initialized
INFO - 2020-07-28 08:58:31 --> Router Class Initialized
INFO - 2020-07-28 08:58:31 --> Output Class Initialized
INFO - 2020-07-28 08:58:31 --> Security Class Initialized
DEBUG - 2020-07-28 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 08:58:31 --> Input Class Initialized
INFO - 2020-07-28 08:58:31 --> Language Class Initialized
INFO - 2020-07-28 08:58:31 --> Loader Class Initialized
INFO - 2020-07-28 08:58:31 --> Helper loaded: url_helper
INFO - 2020-07-28 08:58:31 --> Helper loaded: file_helper
INFO - 2020-07-28 08:58:31 --> Database Driver Class Initialized
INFO - 2020-07-28 08:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 08:58:31 --> Email Class Initialized
INFO - 2020-07-28 08:58:31 --> Controller Class Initialized
INFO - 2020-07-28 08:58:31 --> Model Class Initialized
INFO - 2020-07-28 08:58:31 --> Model Class Initialized
DEBUG - 2020-07-28 08:58:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 08:58:31 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 08:58:31 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 24
ERROR - 2020-07-28 08:58:31 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-28 08:58:31 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 28
ERROR - 2020-07-28 08:58:31 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 42
ERROR - 2020-07-28 08:58:31 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 97
ERROR - 2020-07-28 08:58:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:03:39 --> Config Class Initialized
INFO - 2020-07-28 09:03:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:39 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:39 --> URI Class Initialized
INFO - 2020-07-28 09:03:39 --> Router Class Initialized
INFO - 2020-07-28 09:03:39 --> Output Class Initialized
INFO - 2020-07-28 09:03:39 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:39 --> Input Class Initialized
INFO - 2020-07-28 09:03:39 --> Language Class Initialized
INFO - 2020-07-28 09:03:39 --> Loader Class Initialized
INFO - 2020-07-28 09:03:39 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:39 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:39 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:39 --> Email Class Initialized
INFO - 2020-07-28 09:03:39 --> Controller Class Initialized
INFO - 2020-07-28 09:03:39 --> Model Class Initialized
INFO - 2020-07-28 09:03:39 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:39 --> Config Class Initialized
INFO - 2020-07-28 09:03:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:39 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:39 --> URI Class Initialized
DEBUG - 2020-07-28 09:03:39 --> No URI present. Default controller set.
INFO - 2020-07-28 09:03:39 --> Router Class Initialized
INFO - 2020-07-28 09:03:39 --> Output Class Initialized
INFO - 2020-07-28 09:03:39 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:39 --> Input Class Initialized
INFO - 2020-07-28 09:03:39 --> Language Class Initialized
INFO - 2020-07-28 09:03:39 --> Loader Class Initialized
INFO - 2020-07-28 09:03:39 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:39 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:39 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:39 --> Email Class Initialized
INFO - 2020-07-28 09:03:39 --> Controller Class Initialized
INFO - 2020-07-28 09:03:39 --> Model Class Initialized
INFO - 2020-07-28 09:03:39 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:03:39 --> Final output sent to browser
DEBUG - 2020-07-28 09:03:39 --> Total execution time: 0.0219
INFO - 2020-07-28 09:03:43 --> Config Class Initialized
INFO - 2020-07-28 09:03:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:43 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:43 --> URI Class Initialized
INFO - 2020-07-28 09:03:43 --> Router Class Initialized
INFO - 2020-07-28 09:03:43 --> Output Class Initialized
INFO - 2020-07-28 09:03:43 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:43 --> Input Class Initialized
INFO - 2020-07-28 09:03:43 --> Language Class Initialized
INFO - 2020-07-28 09:03:43 --> Loader Class Initialized
INFO - 2020-07-28 09:03:43 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:43 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:43 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:43 --> Email Class Initialized
INFO - 2020-07-28 09:03:43 --> Controller Class Initialized
INFO - 2020-07-28 09:03:43 --> Model Class Initialized
INFO - 2020-07-28 09:03:43 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:44 --> Config Class Initialized
INFO - 2020-07-28 09:03:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:44 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:44 --> URI Class Initialized
DEBUG - 2020-07-28 09:03:44 --> No URI present. Default controller set.
INFO - 2020-07-28 09:03:44 --> Router Class Initialized
INFO - 2020-07-28 09:03:44 --> Output Class Initialized
INFO - 2020-07-28 09:03:44 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:44 --> Input Class Initialized
INFO - 2020-07-28 09:03:44 --> Language Class Initialized
INFO - 2020-07-28 09:03:44 --> Loader Class Initialized
INFO - 2020-07-28 09:03:44 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:44 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:44 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:44 --> Email Class Initialized
INFO - 2020-07-28 09:03:44 --> Controller Class Initialized
INFO - 2020-07-28 09:03:44 --> Model Class Initialized
INFO - 2020-07-28 09:03:44 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:03:44 --> Final output sent to browser
DEBUG - 2020-07-28 09:03:44 --> Total execution time: 0.0231
INFO - 2020-07-28 09:03:46 --> Config Class Initialized
INFO - 2020-07-28 09:03:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:46 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:46 --> URI Class Initialized
INFO - 2020-07-28 09:03:46 --> Router Class Initialized
INFO - 2020-07-28 09:03:46 --> Output Class Initialized
INFO - 2020-07-28 09:03:46 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:46 --> Input Class Initialized
INFO - 2020-07-28 09:03:46 --> Language Class Initialized
INFO - 2020-07-28 09:03:46 --> Loader Class Initialized
INFO - 2020-07-28 09:03:46 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:46 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:46 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:46 --> Email Class Initialized
INFO - 2020-07-28 09:03:46 --> Controller Class Initialized
INFO - 2020-07-28 09:03:46 --> Model Class Initialized
INFO - 2020-07-28 09:03:46 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:47 --> Config Class Initialized
INFO - 2020-07-28 09:03:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:47 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:47 --> URI Class Initialized
DEBUG - 2020-07-28 09:03:47 --> No URI present. Default controller set.
INFO - 2020-07-28 09:03:47 --> Router Class Initialized
INFO - 2020-07-28 09:03:47 --> Output Class Initialized
INFO - 2020-07-28 09:03:47 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:47 --> Input Class Initialized
INFO - 2020-07-28 09:03:47 --> Language Class Initialized
INFO - 2020-07-28 09:03:47 --> Loader Class Initialized
INFO - 2020-07-28 09:03:47 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:47 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:47 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:47 --> Email Class Initialized
INFO - 2020-07-28 09:03:47 --> Controller Class Initialized
INFO - 2020-07-28 09:03:47 --> Model Class Initialized
INFO - 2020-07-28 09:03:47 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:03:47 --> Final output sent to browser
DEBUG - 2020-07-28 09:03:47 --> Total execution time: 0.0261
INFO - 2020-07-28 09:03:55 --> Config Class Initialized
INFO - 2020-07-28 09:03:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:55 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:55 --> URI Class Initialized
INFO - 2020-07-28 09:03:55 --> Router Class Initialized
INFO - 2020-07-28 09:03:55 --> Output Class Initialized
INFO - 2020-07-28 09:03:55 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:55 --> Input Class Initialized
INFO - 2020-07-28 09:03:55 --> Language Class Initialized
INFO - 2020-07-28 09:03:55 --> Loader Class Initialized
INFO - 2020-07-28 09:03:55 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:55 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:55 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:55 --> Email Class Initialized
INFO - 2020-07-28 09:03:55 --> Controller Class Initialized
INFO - 2020-07-28 09:03:55 --> Model Class Initialized
INFO - 2020-07-28 09:03:55 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:55 --> Config Class Initialized
INFO - 2020-07-28 09:03:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:03:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:03:55 --> Utf8 Class Initialized
INFO - 2020-07-28 09:03:55 --> URI Class Initialized
DEBUG - 2020-07-28 09:03:55 --> No URI present. Default controller set.
INFO - 2020-07-28 09:03:55 --> Router Class Initialized
INFO - 2020-07-28 09:03:55 --> Output Class Initialized
INFO - 2020-07-28 09:03:55 --> Security Class Initialized
DEBUG - 2020-07-28 09:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:03:55 --> Input Class Initialized
INFO - 2020-07-28 09:03:55 --> Language Class Initialized
INFO - 2020-07-28 09:03:55 --> Loader Class Initialized
INFO - 2020-07-28 09:03:55 --> Helper loaded: url_helper
INFO - 2020-07-28 09:03:55 --> Helper loaded: file_helper
INFO - 2020-07-28 09:03:55 --> Database Driver Class Initialized
INFO - 2020-07-28 09:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:03:55 --> Email Class Initialized
INFO - 2020-07-28 09:03:55 --> Controller Class Initialized
INFO - 2020-07-28 09:03:55 --> Model Class Initialized
INFO - 2020-07-28 09:03:55 --> Model Class Initialized
DEBUG - 2020-07-28 09:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:03:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:03:55 --> Final output sent to browser
DEBUG - 2020-07-28 09:03:55 --> Total execution time: 0.0217
INFO - 2020-07-28 09:04:03 --> Config Class Initialized
INFO - 2020-07-28 09:04:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:03 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:03 --> URI Class Initialized
INFO - 2020-07-28 09:04:03 --> Router Class Initialized
INFO - 2020-07-28 09:04:03 --> Output Class Initialized
INFO - 2020-07-28 09:04:03 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:03 --> Input Class Initialized
INFO - 2020-07-28 09:04:03 --> Language Class Initialized
INFO - 2020-07-28 09:04:03 --> Loader Class Initialized
INFO - 2020-07-28 09:04:03 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:03 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:03 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:03 --> Email Class Initialized
INFO - 2020-07-28 09:04:03 --> Controller Class Initialized
INFO - 2020-07-28 09:04:03 --> Model Class Initialized
INFO - 2020-07-28 09:04:03 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:04 --> Config Class Initialized
INFO - 2020-07-28 09:04:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:04 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:04 --> URI Class Initialized
DEBUG - 2020-07-28 09:04:04 --> No URI present. Default controller set.
INFO - 2020-07-28 09:04:04 --> Router Class Initialized
INFO - 2020-07-28 09:04:04 --> Output Class Initialized
INFO - 2020-07-28 09:04:04 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:04 --> Input Class Initialized
INFO - 2020-07-28 09:04:04 --> Language Class Initialized
INFO - 2020-07-28 09:04:04 --> Loader Class Initialized
INFO - 2020-07-28 09:04:04 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:04 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:04 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:04 --> Email Class Initialized
INFO - 2020-07-28 09:04:04 --> Controller Class Initialized
INFO - 2020-07-28 09:04:04 --> Model Class Initialized
INFO - 2020-07-28 09:04:04 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:04:04 --> Final output sent to browser
DEBUG - 2020-07-28 09:04:04 --> Total execution time: 0.0224
INFO - 2020-07-28 09:04:26 --> Config Class Initialized
INFO - 2020-07-28 09:04:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:26 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:26 --> URI Class Initialized
DEBUG - 2020-07-28 09:04:26 --> No URI present. Default controller set.
INFO - 2020-07-28 09:04:26 --> Router Class Initialized
INFO - 2020-07-28 09:04:26 --> Output Class Initialized
INFO - 2020-07-28 09:04:26 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:26 --> Input Class Initialized
INFO - 2020-07-28 09:04:26 --> Language Class Initialized
INFO - 2020-07-28 09:04:26 --> Loader Class Initialized
INFO - 2020-07-28 09:04:26 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:26 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:26 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:26 --> Email Class Initialized
INFO - 2020-07-28 09:04:26 --> Controller Class Initialized
INFO - 2020-07-28 09:04:26 --> Model Class Initialized
INFO - 2020-07-28 09:04:26 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:04:26 --> Final output sent to browser
DEBUG - 2020-07-28 09:04:26 --> Total execution time: 0.0213
INFO - 2020-07-28 09:04:28 --> Config Class Initialized
INFO - 2020-07-28 09:04:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:28 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:28 --> URI Class Initialized
INFO - 2020-07-28 09:04:28 --> Router Class Initialized
INFO - 2020-07-28 09:04:28 --> Output Class Initialized
INFO - 2020-07-28 09:04:28 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:28 --> Input Class Initialized
INFO - 2020-07-28 09:04:28 --> Language Class Initialized
INFO - 2020-07-28 09:04:28 --> Loader Class Initialized
INFO - 2020-07-28 09:04:28 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:28 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:28 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:28 --> Email Class Initialized
INFO - 2020-07-28 09:04:28 --> Controller Class Initialized
INFO - 2020-07-28 09:04:28 --> Model Class Initialized
INFO - 2020-07-28 09:04:28 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:28 --> Config Class Initialized
INFO - 2020-07-28 09:04:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:28 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:28 --> URI Class Initialized
DEBUG - 2020-07-28 09:04:28 --> No URI present. Default controller set.
INFO - 2020-07-28 09:04:28 --> Router Class Initialized
INFO - 2020-07-28 09:04:28 --> Output Class Initialized
INFO - 2020-07-28 09:04:28 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:28 --> Input Class Initialized
INFO - 2020-07-28 09:04:28 --> Language Class Initialized
INFO - 2020-07-28 09:04:28 --> Loader Class Initialized
INFO - 2020-07-28 09:04:28 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:28 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:28 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:29 --> Email Class Initialized
INFO - 2020-07-28 09:04:29 --> Controller Class Initialized
INFO - 2020-07-28 09:04:29 --> Model Class Initialized
INFO - 2020-07-28 09:04:29 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:04:29 --> Final output sent to browser
DEBUG - 2020-07-28 09:04:29 --> Total execution time: 0.0225
INFO - 2020-07-28 09:04:31 --> Config Class Initialized
INFO - 2020-07-28 09:04:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:31 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:31 --> URI Class Initialized
INFO - 2020-07-28 09:04:31 --> Router Class Initialized
INFO - 2020-07-28 09:04:31 --> Output Class Initialized
INFO - 2020-07-28 09:04:31 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:31 --> Input Class Initialized
INFO - 2020-07-28 09:04:31 --> Language Class Initialized
INFO - 2020-07-28 09:04:31 --> Loader Class Initialized
INFO - 2020-07-28 09:04:31 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:31 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:31 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:31 --> Email Class Initialized
INFO - 2020-07-28 09:04:31 --> Controller Class Initialized
INFO - 2020-07-28 09:04:31 --> Model Class Initialized
INFO - 2020-07-28 09:04:31 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:31 --> Config Class Initialized
INFO - 2020-07-28 09:04:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:31 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:31 --> URI Class Initialized
DEBUG - 2020-07-28 09:04:31 --> No URI present. Default controller set.
INFO - 2020-07-28 09:04:31 --> Router Class Initialized
INFO - 2020-07-28 09:04:31 --> Output Class Initialized
INFO - 2020-07-28 09:04:31 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:31 --> Input Class Initialized
INFO - 2020-07-28 09:04:31 --> Language Class Initialized
INFO - 2020-07-28 09:04:31 --> Loader Class Initialized
INFO - 2020-07-28 09:04:31 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:31 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:31 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:31 --> Email Class Initialized
INFO - 2020-07-28 09:04:31 --> Controller Class Initialized
INFO - 2020-07-28 09:04:31 --> Model Class Initialized
INFO - 2020-07-28 09:04:31 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:04:31 --> Final output sent to browser
DEBUG - 2020-07-28 09:04:31 --> Total execution time: 0.0232
INFO - 2020-07-28 09:04:34 --> Config Class Initialized
INFO - 2020-07-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:34 --> URI Class Initialized
INFO - 2020-07-28 09:04:34 --> Router Class Initialized
INFO - 2020-07-28 09:04:34 --> Output Class Initialized
INFO - 2020-07-28 09:04:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:34 --> Input Class Initialized
INFO - 2020-07-28 09:04:34 --> Language Class Initialized
INFO - 2020-07-28 09:04:34 --> Loader Class Initialized
INFO - 2020-07-28 09:04:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:34 --> Email Class Initialized
INFO - 2020-07-28 09:04:34 --> Controller Class Initialized
INFO - 2020-07-28 09:04:34 --> Model Class Initialized
INFO - 2020-07-28 09:04:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:34 --> Config Class Initialized
INFO - 2020-07-28 09:04:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:04:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:04:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:04:34 --> URI Class Initialized
DEBUG - 2020-07-28 09:04:34 --> No URI present. Default controller set.
INFO - 2020-07-28 09:04:34 --> Router Class Initialized
INFO - 2020-07-28 09:04:34 --> Output Class Initialized
INFO - 2020-07-28 09:04:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:04:34 --> Input Class Initialized
INFO - 2020-07-28 09:04:34 --> Language Class Initialized
INFO - 2020-07-28 09:04:34 --> Loader Class Initialized
INFO - 2020-07-28 09:04:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:04:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:04:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:04:34 --> Email Class Initialized
INFO - 2020-07-28 09:04:34 --> Controller Class Initialized
INFO - 2020-07-28 09:04:34 --> Model Class Initialized
INFO - 2020-07-28 09:04:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:04:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:04:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:04:34 --> Final output sent to browser
DEBUG - 2020-07-28 09:04:34 --> Total execution time: 0.0224
INFO - 2020-07-28 09:05:38 --> Config Class Initialized
INFO - 2020-07-28 09:05:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:05:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:05:38 --> Utf8 Class Initialized
INFO - 2020-07-28 09:05:38 --> URI Class Initialized
DEBUG - 2020-07-28 09:05:38 --> No URI present. Default controller set.
INFO - 2020-07-28 09:05:38 --> Router Class Initialized
INFO - 2020-07-28 09:05:38 --> Output Class Initialized
INFO - 2020-07-28 09:05:38 --> Security Class Initialized
DEBUG - 2020-07-28 09:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:05:38 --> Input Class Initialized
INFO - 2020-07-28 09:05:38 --> Language Class Initialized
INFO - 2020-07-28 09:05:38 --> Loader Class Initialized
INFO - 2020-07-28 09:05:38 --> Helper loaded: url_helper
INFO - 2020-07-28 09:05:38 --> Helper loaded: file_helper
INFO - 2020-07-28 09:05:38 --> Database Driver Class Initialized
INFO - 2020-07-28 09:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:05:38 --> Email Class Initialized
INFO - 2020-07-28 09:05:38 --> Controller Class Initialized
INFO - 2020-07-28 09:05:38 --> Model Class Initialized
INFO - 2020-07-28 09:05:38 --> Model Class Initialized
DEBUG - 2020-07-28 09:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:05:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:05:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:05:38 --> Final output sent to browser
DEBUG - 2020-07-28 09:05:38 --> Total execution time: 0.0268
INFO - 2020-07-28 09:05:38 --> Config Class Initialized
INFO - 2020-07-28 09:05:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:05:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:05:38 --> Utf8 Class Initialized
INFO - 2020-07-28 09:05:38 --> URI Class Initialized
DEBUG - 2020-07-28 09:05:38 --> No URI present. Default controller set.
INFO - 2020-07-28 09:05:38 --> Router Class Initialized
INFO - 2020-07-28 09:05:38 --> Output Class Initialized
INFO - 2020-07-28 09:05:38 --> Security Class Initialized
DEBUG - 2020-07-28 09:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:05:38 --> Input Class Initialized
INFO - 2020-07-28 09:05:38 --> Language Class Initialized
INFO - 2020-07-28 09:05:38 --> Loader Class Initialized
INFO - 2020-07-28 09:05:38 --> Helper loaded: url_helper
INFO - 2020-07-28 09:05:38 --> Helper loaded: file_helper
INFO - 2020-07-28 09:05:38 --> Database Driver Class Initialized
INFO - 2020-07-28 09:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:05:38 --> Email Class Initialized
INFO - 2020-07-28 09:05:38 --> Controller Class Initialized
INFO - 2020-07-28 09:05:38 --> Model Class Initialized
INFO - 2020-07-28 09:05:38 --> Model Class Initialized
DEBUG - 2020-07-28 09:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:05:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:05:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:05:38 --> Final output sent to browser
DEBUG - 2020-07-28 09:05:38 --> Total execution time: 0.0252
INFO - 2020-07-28 09:05:44 --> Config Class Initialized
INFO - 2020-07-28 09:05:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:05:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:05:44 --> Utf8 Class Initialized
INFO - 2020-07-28 09:05:44 --> URI Class Initialized
INFO - 2020-07-28 09:05:44 --> Router Class Initialized
INFO - 2020-07-28 09:05:44 --> Output Class Initialized
INFO - 2020-07-28 09:05:44 --> Security Class Initialized
DEBUG - 2020-07-28 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:05:44 --> Input Class Initialized
INFO - 2020-07-28 09:05:44 --> Language Class Initialized
INFO - 2020-07-28 09:05:44 --> Loader Class Initialized
INFO - 2020-07-28 09:05:44 --> Helper loaded: url_helper
INFO - 2020-07-28 09:05:44 --> Helper loaded: file_helper
INFO - 2020-07-28 09:05:44 --> Database Driver Class Initialized
INFO - 2020-07-28 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:05:44 --> Email Class Initialized
INFO - 2020-07-28 09:05:44 --> Controller Class Initialized
INFO - 2020-07-28 09:05:44 --> Model Class Initialized
INFO - 2020-07-28 09:05:44 --> Model Class Initialized
DEBUG - 2020-07-28 09:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:05:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:05:44 --> Config Class Initialized
INFO - 2020-07-28 09:05:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:05:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:05:44 --> Utf8 Class Initialized
INFO - 2020-07-28 09:05:44 --> URI Class Initialized
DEBUG - 2020-07-28 09:05:44 --> No URI present. Default controller set.
INFO - 2020-07-28 09:05:44 --> Router Class Initialized
INFO - 2020-07-28 09:05:44 --> Output Class Initialized
INFO - 2020-07-28 09:05:44 --> Security Class Initialized
DEBUG - 2020-07-28 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:05:44 --> Input Class Initialized
INFO - 2020-07-28 09:05:44 --> Language Class Initialized
INFO - 2020-07-28 09:05:44 --> Loader Class Initialized
INFO - 2020-07-28 09:05:44 --> Helper loaded: url_helper
INFO - 2020-07-28 09:05:44 --> Helper loaded: file_helper
INFO - 2020-07-28 09:05:44 --> Database Driver Class Initialized
INFO - 2020-07-28 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:05:44 --> Email Class Initialized
INFO - 2020-07-28 09:05:44 --> Controller Class Initialized
INFO - 2020-07-28 09:05:44 --> Model Class Initialized
INFO - 2020-07-28 09:05:44 --> Model Class Initialized
DEBUG - 2020-07-28 09:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:05:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:05:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:05:44 --> Final output sent to browser
DEBUG - 2020-07-28 09:05:44 --> Total execution time: 0.0216
INFO - 2020-07-28 09:08:27 --> Config Class Initialized
INFO - 2020-07-28 09:08:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:08:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:08:27 --> Utf8 Class Initialized
INFO - 2020-07-28 09:08:27 --> URI Class Initialized
DEBUG - 2020-07-28 09:08:27 --> No URI present. Default controller set.
INFO - 2020-07-28 09:08:27 --> Router Class Initialized
INFO - 2020-07-28 09:08:27 --> Output Class Initialized
INFO - 2020-07-28 09:08:27 --> Security Class Initialized
DEBUG - 2020-07-28 09:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:08:27 --> Input Class Initialized
INFO - 2020-07-28 09:08:27 --> Language Class Initialized
INFO - 2020-07-28 09:08:27 --> Loader Class Initialized
INFO - 2020-07-28 09:08:27 --> Helper loaded: url_helper
INFO - 2020-07-28 09:08:27 --> Helper loaded: file_helper
INFO - 2020-07-28 09:08:27 --> Database Driver Class Initialized
INFO - 2020-07-28 09:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:08:27 --> Email Class Initialized
INFO - 2020-07-28 09:08:27 --> Controller Class Initialized
INFO - 2020-07-28 09:08:27 --> Model Class Initialized
INFO - 2020-07-28 09:08:27 --> Model Class Initialized
DEBUG - 2020-07-28 09:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:08:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:08:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:08:27 --> Final output sent to browser
DEBUG - 2020-07-28 09:08:27 --> Total execution time: 0.0260
INFO - 2020-07-28 09:08:29 --> Config Class Initialized
INFO - 2020-07-28 09:08:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:08:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:08:29 --> Utf8 Class Initialized
INFO - 2020-07-28 09:08:29 --> URI Class Initialized
INFO - 2020-07-28 09:08:29 --> Router Class Initialized
INFO - 2020-07-28 09:08:29 --> Output Class Initialized
INFO - 2020-07-28 09:08:29 --> Security Class Initialized
DEBUG - 2020-07-28 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:08:29 --> Input Class Initialized
INFO - 2020-07-28 09:08:29 --> Language Class Initialized
INFO - 2020-07-28 09:08:29 --> Loader Class Initialized
INFO - 2020-07-28 09:08:29 --> Helper loaded: url_helper
INFO - 2020-07-28 09:08:29 --> Helper loaded: file_helper
INFO - 2020-07-28 09:08:29 --> Database Driver Class Initialized
INFO - 2020-07-28 09:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:08:29 --> Email Class Initialized
INFO - 2020-07-28 09:08:29 --> Controller Class Initialized
INFO - 2020-07-28 09:08:29 --> Model Class Initialized
INFO - 2020-07-28 09:08:29 --> Model Class Initialized
DEBUG - 2020-07-28 09:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:08:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:08:29 --> Config Class Initialized
INFO - 2020-07-28 09:08:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:08:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:08:29 --> Utf8 Class Initialized
INFO - 2020-07-28 09:08:29 --> URI Class Initialized
DEBUG - 2020-07-28 09:08:29 --> No URI present. Default controller set.
INFO - 2020-07-28 09:08:29 --> Router Class Initialized
INFO - 2020-07-28 09:08:29 --> Output Class Initialized
INFO - 2020-07-28 09:08:29 --> Security Class Initialized
DEBUG - 2020-07-28 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:08:29 --> Input Class Initialized
INFO - 2020-07-28 09:08:29 --> Language Class Initialized
INFO - 2020-07-28 09:08:29 --> Loader Class Initialized
INFO - 2020-07-28 09:08:29 --> Helper loaded: url_helper
INFO - 2020-07-28 09:08:29 --> Helper loaded: file_helper
INFO - 2020-07-28 09:08:29 --> Database Driver Class Initialized
INFO - 2020-07-28 09:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:08:29 --> Email Class Initialized
INFO - 2020-07-28 09:08:29 --> Controller Class Initialized
INFO - 2020-07-28 09:08:29 --> Model Class Initialized
INFO - 2020-07-28 09:08:29 --> Model Class Initialized
DEBUG - 2020-07-28 09:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:08:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:08:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:08:29 --> Final output sent to browser
DEBUG - 2020-07-28 09:08:29 --> Total execution time: 0.0229
INFO - 2020-07-28 09:08:32 --> Config Class Initialized
INFO - 2020-07-28 09:08:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:08:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:08:32 --> Utf8 Class Initialized
INFO - 2020-07-28 09:08:32 --> URI Class Initialized
INFO - 2020-07-28 09:08:32 --> Router Class Initialized
INFO - 2020-07-28 09:08:32 --> Output Class Initialized
INFO - 2020-07-28 09:08:32 --> Security Class Initialized
DEBUG - 2020-07-28 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:08:32 --> Input Class Initialized
INFO - 2020-07-28 09:08:32 --> Language Class Initialized
INFO - 2020-07-28 09:08:32 --> Loader Class Initialized
INFO - 2020-07-28 09:08:32 --> Helper loaded: url_helper
INFO - 2020-07-28 09:08:32 --> Helper loaded: file_helper
INFO - 2020-07-28 09:08:32 --> Database Driver Class Initialized
INFO - 2020-07-28 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:08:32 --> Email Class Initialized
INFO - 2020-07-28 09:08:32 --> Controller Class Initialized
INFO - 2020-07-28 09:08:32 --> Model Class Initialized
INFO - 2020-07-28 09:08:32 --> Model Class Initialized
DEBUG - 2020-07-28 09:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:08:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:08:32 --> Config Class Initialized
INFO - 2020-07-28 09:08:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:08:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:08:32 --> Utf8 Class Initialized
INFO - 2020-07-28 09:08:32 --> URI Class Initialized
DEBUG - 2020-07-28 09:08:32 --> No URI present. Default controller set.
INFO - 2020-07-28 09:08:32 --> Router Class Initialized
INFO - 2020-07-28 09:08:32 --> Output Class Initialized
INFO - 2020-07-28 09:08:32 --> Security Class Initialized
DEBUG - 2020-07-28 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:08:32 --> Input Class Initialized
INFO - 2020-07-28 09:08:32 --> Language Class Initialized
INFO - 2020-07-28 09:08:32 --> Loader Class Initialized
INFO - 2020-07-28 09:08:32 --> Helper loaded: url_helper
INFO - 2020-07-28 09:08:32 --> Helper loaded: file_helper
INFO - 2020-07-28 09:08:32 --> Database Driver Class Initialized
INFO - 2020-07-28 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:08:32 --> Email Class Initialized
INFO - 2020-07-28 09:08:32 --> Controller Class Initialized
INFO - 2020-07-28 09:08:32 --> Model Class Initialized
INFO - 2020-07-28 09:08:32 --> Model Class Initialized
DEBUG - 2020-07-28 09:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:08:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:08:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:08:32 --> Final output sent to browser
DEBUG - 2020-07-28 09:08:32 --> Total execution time: 0.0271
INFO - 2020-07-28 09:09:30 --> Config Class Initialized
INFO - 2020-07-28 09:09:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:09:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:09:30 --> Utf8 Class Initialized
INFO - 2020-07-28 09:09:30 --> URI Class Initialized
INFO - 2020-07-28 09:09:30 --> Router Class Initialized
INFO - 2020-07-28 09:09:30 --> Output Class Initialized
INFO - 2020-07-28 09:09:30 --> Security Class Initialized
DEBUG - 2020-07-28 09:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:09:30 --> Input Class Initialized
INFO - 2020-07-28 09:09:30 --> Language Class Initialized
INFO - 2020-07-28 09:09:30 --> Loader Class Initialized
INFO - 2020-07-28 09:09:30 --> Helper loaded: url_helper
INFO - 2020-07-28 09:09:30 --> Helper loaded: file_helper
INFO - 2020-07-28 09:09:30 --> Database Driver Class Initialized
INFO - 2020-07-28 09:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:09:30 --> Email Class Initialized
INFO - 2020-07-28 09:09:30 --> Controller Class Initialized
INFO - 2020-07-28 09:09:30 --> Model Class Initialized
INFO - 2020-07-28 09:09:30 --> Model Class Initialized
DEBUG - 2020-07-28 09:09:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:09:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:09:30 --> Config Class Initialized
INFO - 2020-07-28 09:09:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:09:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:09:30 --> Utf8 Class Initialized
INFO - 2020-07-28 09:09:30 --> URI Class Initialized
DEBUG - 2020-07-28 09:09:30 --> No URI present. Default controller set.
INFO - 2020-07-28 09:09:30 --> Router Class Initialized
INFO - 2020-07-28 09:09:30 --> Output Class Initialized
INFO - 2020-07-28 09:09:30 --> Security Class Initialized
DEBUG - 2020-07-28 09:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:09:30 --> Input Class Initialized
INFO - 2020-07-28 09:09:30 --> Language Class Initialized
INFO - 2020-07-28 09:09:30 --> Loader Class Initialized
INFO - 2020-07-28 09:09:30 --> Helper loaded: url_helper
INFO - 2020-07-28 09:09:30 --> Helper loaded: file_helper
INFO - 2020-07-28 09:09:30 --> Database Driver Class Initialized
INFO - 2020-07-28 09:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:09:30 --> Email Class Initialized
INFO - 2020-07-28 09:09:30 --> Controller Class Initialized
INFO - 2020-07-28 09:09:30 --> Model Class Initialized
INFO - 2020-07-28 09:09:30 --> Model Class Initialized
DEBUG - 2020-07-28 09:09:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:09:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:09:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:09:30 --> Final output sent to browser
DEBUG - 2020-07-28 09:09:30 --> Total execution time: 0.0258
INFO - 2020-07-28 09:09:50 --> Config Class Initialized
INFO - 2020-07-28 09:09:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:09:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:09:50 --> Utf8 Class Initialized
INFO - 2020-07-28 09:09:50 --> URI Class Initialized
INFO - 2020-07-28 09:09:50 --> Router Class Initialized
INFO - 2020-07-28 09:09:50 --> Output Class Initialized
INFO - 2020-07-28 09:09:50 --> Security Class Initialized
DEBUG - 2020-07-28 09:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:09:50 --> Input Class Initialized
INFO - 2020-07-28 09:09:50 --> Language Class Initialized
INFO - 2020-07-28 09:09:50 --> Loader Class Initialized
INFO - 2020-07-28 09:09:50 --> Helper loaded: url_helper
INFO - 2020-07-28 09:09:50 --> Helper loaded: file_helper
INFO - 2020-07-28 09:09:50 --> Database Driver Class Initialized
INFO - 2020-07-28 09:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:09:50 --> Email Class Initialized
INFO - 2020-07-28 09:09:50 --> Controller Class Initialized
INFO - 2020-07-28 09:09:50 --> Model Class Initialized
INFO - 2020-07-28 09:09:50 --> Model Class Initialized
DEBUG - 2020-07-28 09:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:09:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:09:50 --> Config Class Initialized
INFO - 2020-07-28 09:09:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:09:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:09:50 --> Utf8 Class Initialized
INFO - 2020-07-28 09:09:50 --> URI Class Initialized
DEBUG - 2020-07-28 09:09:50 --> No URI present. Default controller set.
INFO - 2020-07-28 09:09:50 --> Router Class Initialized
INFO - 2020-07-28 09:09:50 --> Output Class Initialized
INFO - 2020-07-28 09:09:50 --> Security Class Initialized
DEBUG - 2020-07-28 09:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:09:50 --> Input Class Initialized
INFO - 2020-07-28 09:09:50 --> Language Class Initialized
INFO - 2020-07-28 09:09:50 --> Loader Class Initialized
INFO - 2020-07-28 09:09:50 --> Helper loaded: url_helper
INFO - 2020-07-28 09:09:50 --> Helper loaded: file_helper
INFO - 2020-07-28 09:09:50 --> Database Driver Class Initialized
INFO - 2020-07-28 09:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:09:50 --> Email Class Initialized
INFO - 2020-07-28 09:09:50 --> Controller Class Initialized
INFO - 2020-07-28 09:09:50 --> Model Class Initialized
INFO - 2020-07-28 09:09:50 --> Model Class Initialized
DEBUG - 2020-07-28 09:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:09:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:09:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:09:50 --> Final output sent to browser
DEBUG - 2020-07-28 09:09:50 --> Total execution time: 0.0227
INFO - 2020-07-28 09:09:52 --> Config Class Initialized
INFO - 2020-07-28 09:09:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:09:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:09:52 --> Utf8 Class Initialized
INFO - 2020-07-28 09:09:52 --> URI Class Initialized
INFO - 2020-07-28 09:09:52 --> Router Class Initialized
INFO - 2020-07-28 09:09:52 --> Output Class Initialized
INFO - 2020-07-28 09:09:52 --> Security Class Initialized
DEBUG - 2020-07-28 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:09:52 --> Input Class Initialized
INFO - 2020-07-28 09:09:52 --> Language Class Initialized
INFO - 2020-07-28 09:09:52 --> Loader Class Initialized
INFO - 2020-07-28 09:09:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:09:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:09:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:09:53 --> Email Class Initialized
INFO - 2020-07-28 09:09:53 --> Controller Class Initialized
INFO - 2020-07-28 09:09:53 --> Model Class Initialized
INFO - 2020-07-28 09:09:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:09:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:09:53 --> Config Class Initialized
INFO - 2020-07-28 09:09:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:09:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:09:53 --> Utf8 Class Initialized
INFO - 2020-07-28 09:09:53 --> URI Class Initialized
DEBUG - 2020-07-28 09:09:53 --> No URI present. Default controller set.
INFO - 2020-07-28 09:09:53 --> Router Class Initialized
INFO - 2020-07-28 09:09:53 --> Output Class Initialized
INFO - 2020-07-28 09:09:53 --> Security Class Initialized
DEBUG - 2020-07-28 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:09:53 --> Input Class Initialized
INFO - 2020-07-28 09:09:53 --> Language Class Initialized
INFO - 2020-07-28 09:09:53 --> Loader Class Initialized
INFO - 2020-07-28 09:09:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:09:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:09:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:09:53 --> Email Class Initialized
INFO - 2020-07-28 09:09:53 --> Controller Class Initialized
INFO - 2020-07-28 09:09:53 --> Model Class Initialized
INFO - 2020-07-28 09:09:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:09:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:09:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:09:53 --> Final output sent to browser
DEBUG - 2020-07-28 09:09:53 --> Total execution time: 0.0204
INFO - 2020-07-28 09:10:02 --> Config Class Initialized
INFO - 2020-07-28 09:10:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:10:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:10:02 --> Utf8 Class Initialized
INFO - 2020-07-28 09:10:02 --> URI Class Initialized
INFO - 2020-07-28 09:10:02 --> Router Class Initialized
INFO - 2020-07-28 09:10:02 --> Output Class Initialized
INFO - 2020-07-28 09:10:02 --> Security Class Initialized
DEBUG - 2020-07-28 09:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:10:02 --> Input Class Initialized
INFO - 2020-07-28 09:10:02 --> Language Class Initialized
INFO - 2020-07-28 09:10:02 --> Loader Class Initialized
INFO - 2020-07-28 09:10:02 --> Helper loaded: url_helper
INFO - 2020-07-28 09:10:02 --> Helper loaded: file_helper
INFO - 2020-07-28 09:10:02 --> Database Driver Class Initialized
INFO - 2020-07-28 09:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:10:02 --> Email Class Initialized
INFO - 2020-07-28 09:10:02 --> Controller Class Initialized
INFO - 2020-07-28 09:10:02 --> Model Class Initialized
INFO - 2020-07-28 09:10:02 --> Model Class Initialized
DEBUG - 2020-07-28 09:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:10:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:10:02 --> Config Class Initialized
INFO - 2020-07-28 09:10:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:10:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:10:02 --> Utf8 Class Initialized
INFO - 2020-07-28 09:10:02 --> URI Class Initialized
DEBUG - 2020-07-28 09:10:02 --> No URI present. Default controller set.
INFO - 2020-07-28 09:10:02 --> Router Class Initialized
INFO - 2020-07-28 09:10:02 --> Output Class Initialized
INFO - 2020-07-28 09:10:02 --> Security Class Initialized
DEBUG - 2020-07-28 09:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:10:02 --> Input Class Initialized
INFO - 2020-07-28 09:10:02 --> Language Class Initialized
INFO - 2020-07-28 09:10:02 --> Loader Class Initialized
INFO - 2020-07-28 09:10:02 --> Helper loaded: url_helper
INFO - 2020-07-28 09:10:02 --> Helper loaded: file_helper
INFO - 2020-07-28 09:10:02 --> Database Driver Class Initialized
INFO - 2020-07-28 09:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:10:02 --> Email Class Initialized
INFO - 2020-07-28 09:10:02 --> Controller Class Initialized
INFO - 2020-07-28 09:10:02 --> Model Class Initialized
INFO - 2020-07-28 09:10:02 --> Model Class Initialized
DEBUG - 2020-07-28 09:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:10:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:10:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:10:02 --> Final output sent to browser
DEBUG - 2020-07-28 09:10:02 --> Total execution time: 0.0214
INFO - 2020-07-28 09:10:27 --> Config Class Initialized
INFO - 2020-07-28 09:10:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:10:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:10:27 --> Utf8 Class Initialized
INFO - 2020-07-28 09:10:27 --> URI Class Initialized
INFO - 2020-07-28 09:10:27 --> Router Class Initialized
INFO - 2020-07-28 09:10:27 --> Output Class Initialized
INFO - 2020-07-28 09:10:27 --> Security Class Initialized
DEBUG - 2020-07-28 09:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:10:27 --> Input Class Initialized
INFO - 2020-07-28 09:10:27 --> Language Class Initialized
INFO - 2020-07-28 09:10:27 --> Loader Class Initialized
INFO - 2020-07-28 09:10:27 --> Helper loaded: url_helper
INFO - 2020-07-28 09:10:27 --> Helper loaded: file_helper
INFO - 2020-07-28 09:10:27 --> Database Driver Class Initialized
INFO - 2020-07-28 09:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:10:27 --> Email Class Initialized
INFO - 2020-07-28 09:10:27 --> Controller Class Initialized
INFO - 2020-07-28 09:10:27 --> Model Class Initialized
INFO - 2020-07-28 09:10:27 --> Model Class Initialized
DEBUG - 2020-07-28 09:10:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:10:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:10:28 --> Config Class Initialized
INFO - 2020-07-28 09:10:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:10:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:10:28 --> Utf8 Class Initialized
INFO - 2020-07-28 09:10:28 --> URI Class Initialized
DEBUG - 2020-07-28 09:10:28 --> No URI present. Default controller set.
INFO - 2020-07-28 09:10:28 --> Router Class Initialized
INFO - 2020-07-28 09:10:28 --> Output Class Initialized
INFO - 2020-07-28 09:10:28 --> Security Class Initialized
DEBUG - 2020-07-28 09:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:10:28 --> Input Class Initialized
INFO - 2020-07-28 09:10:28 --> Language Class Initialized
INFO - 2020-07-28 09:10:28 --> Loader Class Initialized
INFO - 2020-07-28 09:10:28 --> Helper loaded: url_helper
INFO - 2020-07-28 09:10:28 --> Helper loaded: file_helper
INFO - 2020-07-28 09:10:28 --> Database Driver Class Initialized
INFO - 2020-07-28 09:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:10:28 --> Email Class Initialized
INFO - 2020-07-28 09:10:28 --> Controller Class Initialized
INFO - 2020-07-28 09:10:28 --> Model Class Initialized
INFO - 2020-07-28 09:10:28 --> Model Class Initialized
DEBUG - 2020-07-28 09:10:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:10:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:10:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:10:28 --> Final output sent to browser
DEBUG - 2020-07-28 09:10:28 --> Total execution time: 0.0254
INFO - 2020-07-28 09:11:08 --> Config Class Initialized
INFO - 2020-07-28 09:11:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:11:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:11:08 --> Utf8 Class Initialized
INFO - 2020-07-28 09:11:08 --> URI Class Initialized
DEBUG - 2020-07-28 09:11:08 --> No URI present. Default controller set.
INFO - 2020-07-28 09:11:08 --> Router Class Initialized
INFO - 2020-07-28 09:11:08 --> Output Class Initialized
INFO - 2020-07-28 09:11:08 --> Security Class Initialized
DEBUG - 2020-07-28 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:11:08 --> Input Class Initialized
INFO - 2020-07-28 09:11:08 --> Language Class Initialized
INFO - 2020-07-28 09:11:08 --> Loader Class Initialized
INFO - 2020-07-28 09:11:08 --> Helper loaded: url_helper
INFO - 2020-07-28 09:11:08 --> Helper loaded: file_helper
INFO - 2020-07-28 09:11:08 --> Database Driver Class Initialized
INFO - 2020-07-28 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:11:08 --> Email Class Initialized
INFO - 2020-07-28 09:11:08 --> Controller Class Initialized
INFO - 2020-07-28 09:11:08 --> Model Class Initialized
INFO - 2020-07-28 09:11:08 --> Model Class Initialized
DEBUG - 2020-07-28 09:11:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:11:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:11:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:11:08 --> Final output sent to browser
DEBUG - 2020-07-28 09:11:08 --> Total execution time: 0.0251
INFO - 2020-07-28 09:11:28 --> Config Class Initialized
INFO - 2020-07-28 09:11:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:11:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:11:28 --> Utf8 Class Initialized
INFO - 2020-07-28 09:11:28 --> URI Class Initialized
DEBUG - 2020-07-28 09:11:28 --> No URI present. Default controller set.
INFO - 2020-07-28 09:11:28 --> Router Class Initialized
INFO - 2020-07-28 09:11:28 --> Output Class Initialized
INFO - 2020-07-28 09:11:28 --> Security Class Initialized
DEBUG - 2020-07-28 09:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:11:28 --> Input Class Initialized
INFO - 2020-07-28 09:11:28 --> Language Class Initialized
INFO - 2020-07-28 09:11:28 --> Loader Class Initialized
INFO - 2020-07-28 09:11:28 --> Helper loaded: url_helper
INFO - 2020-07-28 09:11:28 --> Helper loaded: file_helper
INFO - 2020-07-28 09:11:28 --> Database Driver Class Initialized
INFO - 2020-07-28 09:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:11:28 --> Email Class Initialized
INFO - 2020-07-28 09:11:28 --> Controller Class Initialized
INFO - 2020-07-28 09:11:28 --> Model Class Initialized
INFO - 2020-07-28 09:11:28 --> Model Class Initialized
DEBUG - 2020-07-28 09:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:11:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:11:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:11:28 --> Final output sent to browser
DEBUG - 2020-07-28 09:11:28 --> Total execution time: 0.0218
INFO - 2020-07-28 09:11:31 --> Config Class Initialized
INFO - 2020-07-28 09:11:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:11:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:11:31 --> Utf8 Class Initialized
INFO - 2020-07-28 09:11:31 --> URI Class Initialized
INFO - 2020-07-28 09:11:31 --> Router Class Initialized
INFO - 2020-07-28 09:11:31 --> Output Class Initialized
INFO - 2020-07-28 09:11:31 --> Security Class Initialized
DEBUG - 2020-07-28 09:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:11:31 --> Input Class Initialized
INFO - 2020-07-28 09:11:31 --> Language Class Initialized
INFO - 2020-07-28 09:11:31 --> Loader Class Initialized
INFO - 2020-07-28 09:11:31 --> Helper loaded: url_helper
INFO - 2020-07-28 09:11:31 --> Helper loaded: file_helper
INFO - 2020-07-28 09:11:31 --> Database Driver Class Initialized
INFO - 2020-07-28 09:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:11:31 --> Email Class Initialized
INFO - 2020-07-28 09:11:31 --> Controller Class Initialized
INFO - 2020-07-28 09:11:31 --> Model Class Initialized
INFO - 2020-07-28 09:11:31 --> Model Class Initialized
DEBUG - 2020-07-28 09:11:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:11:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:11:31 --> Config Class Initialized
INFO - 2020-07-28 09:11:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:11:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:11:31 --> Utf8 Class Initialized
INFO - 2020-07-28 09:11:31 --> URI Class Initialized
DEBUG - 2020-07-28 09:11:31 --> No URI present. Default controller set.
INFO - 2020-07-28 09:11:31 --> Router Class Initialized
INFO - 2020-07-28 09:11:31 --> Output Class Initialized
INFO - 2020-07-28 09:11:31 --> Security Class Initialized
DEBUG - 2020-07-28 09:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:11:31 --> Input Class Initialized
INFO - 2020-07-28 09:11:31 --> Language Class Initialized
INFO - 2020-07-28 09:11:31 --> Loader Class Initialized
INFO - 2020-07-28 09:11:31 --> Helper loaded: url_helper
INFO - 2020-07-28 09:11:31 --> Helper loaded: file_helper
INFO - 2020-07-28 09:11:31 --> Database Driver Class Initialized
INFO - 2020-07-28 09:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:11:31 --> Email Class Initialized
INFO - 2020-07-28 09:11:31 --> Controller Class Initialized
INFO - 2020-07-28 09:11:31 --> Model Class Initialized
INFO - 2020-07-28 09:11:31 --> Model Class Initialized
DEBUG - 2020-07-28 09:11:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:11:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:11:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:11:31 --> Final output sent to browser
DEBUG - 2020-07-28 09:11:31 --> Total execution time: 0.0241
INFO - 2020-07-28 09:11:33 --> Config Class Initialized
INFO - 2020-07-28 09:11:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:11:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:11:33 --> Utf8 Class Initialized
INFO - 2020-07-28 09:11:33 --> URI Class Initialized
INFO - 2020-07-28 09:11:33 --> Router Class Initialized
INFO - 2020-07-28 09:11:33 --> Output Class Initialized
INFO - 2020-07-28 09:11:33 --> Security Class Initialized
DEBUG - 2020-07-28 09:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:11:33 --> Input Class Initialized
INFO - 2020-07-28 09:11:33 --> Language Class Initialized
INFO - 2020-07-28 09:11:33 --> Loader Class Initialized
INFO - 2020-07-28 09:11:33 --> Helper loaded: url_helper
INFO - 2020-07-28 09:11:33 --> Helper loaded: file_helper
INFO - 2020-07-28 09:11:33 --> Database Driver Class Initialized
INFO - 2020-07-28 09:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:11:33 --> Email Class Initialized
INFO - 2020-07-28 09:11:33 --> Controller Class Initialized
INFO - 2020-07-28 09:11:33 --> Model Class Initialized
INFO - 2020-07-28 09:11:33 --> Model Class Initialized
DEBUG - 2020-07-28 09:11:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:11:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:11:34 --> Config Class Initialized
INFO - 2020-07-28 09:11:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:11:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:11:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:11:34 --> URI Class Initialized
DEBUG - 2020-07-28 09:11:34 --> No URI present. Default controller set.
INFO - 2020-07-28 09:11:34 --> Router Class Initialized
INFO - 2020-07-28 09:11:34 --> Output Class Initialized
INFO - 2020-07-28 09:11:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:11:34 --> Input Class Initialized
INFO - 2020-07-28 09:11:34 --> Language Class Initialized
INFO - 2020-07-28 09:11:34 --> Loader Class Initialized
INFO - 2020-07-28 09:11:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:11:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:11:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:11:34 --> Email Class Initialized
INFO - 2020-07-28 09:11:34 --> Controller Class Initialized
INFO - 2020-07-28 09:11:34 --> Model Class Initialized
INFO - 2020-07-28 09:11:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:11:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:11:34 --> Final output sent to browser
DEBUG - 2020-07-28 09:11:34 --> Total execution time: 0.0225
INFO - 2020-07-28 09:12:24 --> Config Class Initialized
INFO - 2020-07-28 09:12:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:12:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:12:24 --> Utf8 Class Initialized
INFO - 2020-07-28 09:12:24 --> URI Class Initialized
DEBUG - 2020-07-28 09:12:24 --> No URI present. Default controller set.
INFO - 2020-07-28 09:12:24 --> Router Class Initialized
INFO - 2020-07-28 09:12:24 --> Output Class Initialized
INFO - 2020-07-28 09:12:24 --> Security Class Initialized
DEBUG - 2020-07-28 09:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:12:24 --> Input Class Initialized
INFO - 2020-07-28 09:12:24 --> Language Class Initialized
INFO - 2020-07-28 09:12:24 --> Loader Class Initialized
INFO - 2020-07-28 09:12:24 --> Helper loaded: url_helper
INFO - 2020-07-28 09:12:24 --> Helper loaded: file_helper
INFO - 2020-07-28 09:12:24 --> Database Driver Class Initialized
INFO - 2020-07-28 09:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:12:24 --> Email Class Initialized
INFO - 2020-07-28 09:12:24 --> Controller Class Initialized
INFO - 2020-07-28 09:12:24 --> Model Class Initialized
INFO - 2020-07-28 09:12:24 --> Model Class Initialized
DEBUG - 2020-07-28 09:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:12:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:12:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:12:24 --> Final output sent to browser
DEBUG - 2020-07-28 09:12:24 --> Total execution time: 0.0208
INFO - 2020-07-28 09:12:28 --> Config Class Initialized
INFO - 2020-07-28 09:12:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:12:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:12:28 --> Utf8 Class Initialized
INFO - 2020-07-28 09:12:28 --> URI Class Initialized
DEBUG - 2020-07-28 09:12:28 --> No URI present. Default controller set.
INFO - 2020-07-28 09:12:28 --> Router Class Initialized
INFO - 2020-07-28 09:12:28 --> Output Class Initialized
INFO - 2020-07-28 09:12:28 --> Security Class Initialized
DEBUG - 2020-07-28 09:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:12:28 --> Input Class Initialized
INFO - 2020-07-28 09:12:28 --> Language Class Initialized
INFO - 2020-07-28 09:12:28 --> Loader Class Initialized
INFO - 2020-07-28 09:12:28 --> Helper loaded: url_helper
INFO - 2020-07-28 09:12:28 --> Helper loaded: file_helper
INFO - 2020-07-28 09:12:28 --> Database Driver Class Initialized
INFO - 2020-07-28 09:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:12:28 --> Email Class Initialized
INFO - 2020-07-28 09:12:28 --> Controller Class Initialized
INFO - 2020-07-28 09:12:28 --> Model Class Initialized
INFO - 2020-07-28 09:12:28 --> Model Class Initialized
DEBUG - 2020-07-28 09:12:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:12:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:12:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:12:28 --> Final output sent to browser
DEBUG - 2020-07-28 09:12:28 --> Total execution time: 0.0247
INFO - 2020-07-28 09:12:29 --> Config Class Initialized
INFO - 2020-07-28 09:12:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:12:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:12:29 --> Utf8 Class Initialized
INFO - 2020-07-28 09:12:29 --> URI Class Initialized
DEBUG - 2020-07-28 09:12:29 --> No URI present. Default controller set.
INFO - 2020-07-28 09:12:29 --> Router Class Initialized
INFO - 2020-07-28 09:12:29 --> Output Class Initialized
INFO - 2020-07-28 09:12:29 --> Security Class Initialized
DEBUG - 2020-07-28 09:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:12:29 --> Input Class Initialized
INFO - 2020-07-28 09:12:29 --> Language Class Initialized
INFO - 2020-07-28 09:12:29 --> Loader Class Initialized
INFO - 2020-07-28 09:12:29 --> Helper loaded: url_helper
INFO - 2020-07-28 09:12:29 --> Helper loaded: file_helper
INFO - 2020-07-28 09:12:29 --> Database Driver Class Initialized
INFO - 2020-07-28 09:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:12:29 --> Email Class Initialized
INFO - 2020-07-28 09:12:29 --> Controller Class Initialized
INFO - 2020-07-28 09:12:29 --> Model Class Initialized
INFO - 2020-07-28 09:12:29 --> Model Class Initialized
DEBUG - 2020-07-28 09:12:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:12:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:12:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:12:29 --> Final output sent to browser
DEBUG - 2020-07-28 09:12:29 --> Total execution time: 0.0196
INFO - 2020-07-28 09:12:32 --> Config Class Initialized
INFO - 2020-07-28 09:12:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:12:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:12:32 --> Utf8 Class Initialized
INFO - 2020-07-28 09:12:32 --> URI Class Initialized
INFO - 2020-07-28 09:12:32 --> Router Class Initialized
INFO - 2020-07-28 09:12:32 --> Output Class Initialized
INFO - 2020-07-28 09:12:32 --> Security Class Initialized
DEBUG - 2020-07-28 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:12:32 --> Input Class Initialized
INFO - 2020-07-28 09:12:32 --> Language Class Initialized
INFO - 2020-07-28 09:12:32 --> Loader Class Initialized
INFO - 2020-07-28 09:12:32 --> Helper loaded: url_helper
INFO - 2020-07-28 09:12:32 --> Helper loaded: file_helper
INFO - 2020-07-28 09:12:32 --> Database Driver Class Initialized
INFO - 2020-07-28 09:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:12:32 --> Email Class Initialized
INFO - 2020-07-28 09:12:32 --> Controller Class Initialized
INFO - 2020-07-28 09:12:32 --> Model Class Initialized
INFO - 2020-07-28 09:12:32 --> Model Class Initialized
DEBUG - 2020-07-28 09:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:12:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:12:32 --> Config Class Initialized
INFO - 2020-07-28 09:12:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:12:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:12:32 --> Utf8 Class Initialized
INFO - 2020-07-28 09:12:32 --> URI Class Initialized
DEBUG - 2020-07-28 09:12:32 --> No URI present. Default controller set.
INFO - 2020-07-28 09:12:32 --> Router Class Initialized
INFO - 2020-07-28 09:12:32 --> Output Class Initialized
INFO - 2020-07-28 09:12:32 --> Security Class Initialized
DEBUG - 2020-07-28 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:12:32 --> Input Class Initialized
INFO - 2020-07-28 09:12:32 --> Language Class Initialized
INFO - 2020-07-28 09:12:32 --> Loader Class Initialized
INFO - 2020-07-28 09:12:32 --> Helper loaded: url_helper
INFO - 2020-07-28 09:12:32 --> Helper loaded: file_helper
INFO - 2020-07-28 09:12:32 --> Database Driver Class Initialized
INFO - 2020-07-28 09:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:12:32 --> Email Class Initialized
INFO - 2020-07-28 09:12:32 --> Controller Class Initialized
INFO - 2020-07-28 09:12:32 --> Model Class Initialized
INFO - 2020-07-28 09:12:32 --> Model Class Initialized
DEBUG - 2020-07-28 09:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:12:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:12:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:12:32 --> Final output sent to browser
DEBUG - 2020-07-28 09:12:32 --> Total execution time: 0.0229
INFO - 2020-07-28 09:17:47 --> Config Class Initialized
INFO - 2020-07-28 09:17:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:47 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:47 --> URI Class Initialized
DEBUG - 2020-07-28 09:17:47 --> No URI present. Default controller set.
INFO - 2020-07-28 09:17:47 --> Router Class Initialized
INFO - 2020-07-28 09:17:47 --> Output Class Initialized
INFO - 2020-07-28 09:17:47 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:47 --> Input Class Initialized
INFO - 2020-07-28 09:17:47 --> Language Class Initialized
INFO - 2020-07-28 09:17:47 --> Loader Class Initialized
INFO - 2020-07-28 09:17:47 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:47 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:47 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:47 --> Email Class Initialized
INFO - 2020-07-28 09:17:47 --> Controller Class Initialized
INFO - 2020-07-28 09:17:47 --> Model Class Initialized
INFO - 2020-07-28 09:17:47 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:17:47 --> Final output sent to browser
DEBUG - 2020-07-28 09:17:47 --> Total execution time: 0.0220
INFO - 2020-07-28 09:17:50 --> Config Class Initialized
INFO - 2020-07-28 09:17:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:50 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:50 --> URI Class Initialized
INFO - 2020-07-28 09:17:50 --> Router Class Initialized
INFO - 2020-07-28 09:17:50 --> Output Class Initialized
INFO - 2020-07-28 09:17:50 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:50 --> Input Class Initialized
INFO - 2020-07-28 09:17:50 --> Language Class Initialized
INFO - 2020-07-28 09:17:50 --> Loader Class Initialized
INFO - 2020-07-28 09:17:50 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:50 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:50 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:50 --> Email Class Initialized
INFO - 2020-07-28 09:17:50 --> Controller Class Initialized
INFO - 2020-07-28 09:17:50 --> Model Class Initialized
INFO - 2020-07-28 09:17:50 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:50 --> Config Class Initialized
INFO - 2020-07-28 09:17:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:50 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:50 --> URI Class Initialized
DEBUG - 2020-07-28 09:17:50 --> No URI present. Default controller set.
INFO - 2020-07-28 09:17:50 --> Router Class Initialized
INFO - 2020-07-28 09:17:50 --> Output Class Initialized
INFO - 2020-07-28 09:17:50 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:50 --> Input Class Initialized
INFO - 2020-07-28 09:17:50 --> Language Class Initialized
INFO - 2020-07-28 09:17:50 --> Loader Class Initialized
INFO - 2020-07-28 09:17:50 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:50 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:50 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:50 --> Email Class Initialized
INFO - 2020-07-28 09:17:50 --> Controller Class Initialized
INFO - 2020-07-28 09:17:50 --> Model Class Initialized
INFO - 2020-07-28 09:17:50 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:17:50 --> Final output sent to browser
DEBUG - 2020-07-28 09:17:50 --> Total execution time: 0.0225
INFO - 2020-07-28 09:17:53 --> Config Class Initialized
INFO - 2020-07-28 09:17:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:53 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:53 --> URI Class Initialized
INFO - 2020-07-28 09:17:53 --> Router Class Initialized
INFO - 2020-07-28 09:17:53 --> Output Class Initialized
INFO - 2020-07-28 09:17:53 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:53 --> Input Class Initialized
INFO - 2020-07-28 09:17:53 --> Language Class Initialized
INFO - 2020-07-28 09:17:53 --> Loader Class Initialized
INFO - 2020-07-28 09:17:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:53 --> Email Class Initialized
INFO - 2020-07-28 09:17:53 --> Controller Class Initialized
INFO - 2020-07-28 09:17:53 --> Model Class Initialized
INFO - 2020-07-28 09:17:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:53 --> Config Class Initialized
INFO - 2020-07-28 09:17:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:53 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:53 --> URI Class Initialized
DEBUG - 2020-07-28 09:17:53 --> No URI present. Default controller set.
INFO - 2020-07-28 09:17:53 --> Router Class Initialized
INFO - 2020-07-28 09:17:53 --> Output Class Initialized
INFO - 2020-07-28 09:17:53 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:53 --> Input Class Initialized
INFO - 2020-07-28 09:17:53 --> Language Class Initialized
INFO - 2020-07-28 09:17:53 --> Loader Class Initialized
INFO - 2020-07-28 09:17:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:53 --> Email Class Initialized
INFO - 2020-07-28 09:17:53 --> Controller Class Initialized
INFO - 2020-07-28 09:17:53 --> Model Class Initialized
INFO - 2020-07-28 09:17:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:17:53 --> Final output sent to browser
DEBUG - 2020-07-28 09:17:53 --> Total execution time: 0.0223
INFO - 2020-07-28 09:17:56 --> Config Class Initialized
INFO - 2020-07-28 09:17:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:56 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:56 --> URI Class Initialized
INFO - 2020-07-28 09:17:56 --> Router Class Initialized
INFO - 2020-07-28 09:17:56 --> Output Class Initialized
INFO - 2020-07-28 09:17:56 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:56 --> Input Class Initialized
INFO - 2020-07-28 09:17:56 --> Language Class Initialized
INFO - 2020-07-28 09:17:56 --> Loader Class Initialized
INFO - 2020-07-28 09:17:56 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:56 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:56 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:56 --> Email Class Initialized
INFO - 2020-07-28 09:17:56 --> Controller Class Initialized
INFO - 2020-07-28 09:17:56 --> Model Class Initialized
INFO - 2020-07-28 09:17:56 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:56 --> Config Class Initialized
INFO - 2020-07-28 09:17:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:17:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:17:56 --> Utf8 Class Initialized
INFO - 2020-07-28 09:17:56 --> URI Class Initialized
DEBUG - 2020-07-28 09:17:56 --> No URI present. Default controller set.
INFO - 2020-07-28 09:17:56 --> Router Class Initialized
INFO - 2020-07-28 09:17:56 --> Output Class Initialized
INFO - 2020-07-28 09:17:56 --> Security Class Initialized
DEBUG - 2020-07-28 09:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:17:56 --> Input Class Initialized
INFO - 2020-07-28 09:17:56 --> Language Class Initialized
INFO - 2020-07-28 09:17:56 --> Loader Class Initialized
INFO - 2020-07-28 09:17:56 --> Helper loaded: url_helper
INFO - 2020-07-28 09:17:56 --> Helper loaded: file_helper
INFO - 2020-07-28 09:17:56 --> Database Driver Class Initialized
INFO - 2020-07-28 09:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:17:56 --> Email Class Initialized
INFO - 2020-07-28 09:17:56 --> Controller Class Initialized
INFO - 2020-07-28 09:17:56 --> Model Class Initialized
INFO - 2020-07-28 09:17:56 --> Model Class Initialized
DEBUG - 2020-07-28 09:17:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:17:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:17:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:17:56 --> Final output sent to browser
DEBUG - 2020-07-28 09:17:56 --> Total execution time: 0.3549
INFO - 2020-07-28 09:18:40 --> Config Class Initialized
INFO - 2020-07-28 09:18:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:18:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:18:40 --> Utf8 Class Initialized
INFO - 2020-07-28 09:18:40 --> URI Class Initialized
INFO - 2020-07-28 09:18:40 --> Router Class Initialized
INFO - 2020-07-28 09:18:40 --> Output Class Initialized
INFO - 2020-07-28 09:18:40 --> Security Class Initialized
DEBUG - 2020-07-28 09:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:18:40 --> Input Class Initialized
INFO - 2020-07-28 09:18:40 --> Language Class Initialized
INFO - 2020-07-28 09:18:40 --> Loader Class Initialized
INFO - 2020-07-28 09:18:40 --> Helper loaded: url_helper
INFO - 2020-07-28 09:18:40 --> Helper loaded: file_helper
INFO - 2020-07-28 09:18:40 --> Database Driver Class Initialized
INFO - 2020-07-28 09:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:18:40 --> Email Class Initialized
INFO - 2020-07-28 09:18:40 --> Controller Class Initialized
INFO - 2020-07-28 09:18:40 --> Model Class Initialized
INFO - 2020-07-28 09:18:40 --> Model Class Initialized
DEBUG - 2020-07-28 09:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:18:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:18:40 --> Config Class Initialized
INFO - 2020-07-28 09:18:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:18:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:18:40 --> Utf8 Class Initialized
INFO - 2020-07-28 09:18:40 --> URI Class Initialized
DEBUG - 2020-07-28 09:18:40 --> No URI present. Default controller set.
INFO - 2020-07-28 09:18:40 --> Router Class Initialized
INFO - 2020-07-28 09:18:40 --> Output Class Initialized
INFO - 2020-07-28 09:18:40 --> Security Class Initialized
DEBUG - 2020-07-28 09:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:18:40 --> Input Class Initialized
INFO - 2020-07-28 09:18:40 --> Language Class Initialized
INFO - 2020-07-28 09:18:40 --> Loader Class Initialized
INFO - 2020-07-28 09:18:40 --> Helper loaded: url_helper
INFO - 2020-07-28 09:18:40 --> Helper loaded: file_helper
INFO - 2020-07-28 09:18:40 --> Database Driver Class Initialized
INFO - 2020-07-28 09:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:18:40 --> Email Class Initialized
INFO - 2020-07-28 09:18:40 --> Controller Class Initialized
INFO - 2020-07-28 09:18:40 --> Model Class Initialized
INFO - 2020-07-28 09:18:40 --> Model Class Initialized
DEBUG - 2020-07-28 09:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:18:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:18:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:18:40 --> Final output sent to browser
DEBUG - 2020-07-28 09:18:40 --> Total execution time: 0.0229
INFO - 2020-07-28 09:18:48 --> Config Class Initialized
INFO - 2020-07-28 09:18:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:18:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:18:48 --> Utf8 Class Initialized
INFO - 2020-07-28 09:18:48 --> URI Class Initialized
DEBUG - 2020-07-28 09:18:48 --> No URI present. Default controller set.
INFO - 2020-07-28 09:18:48 --> Router Class Initialized
INFO - 2020-07-28 09:18:48 --> Output Class Initialized
INFO - 2020-07-28 09:18:48 --> Security Class Initialized
DEBUG - 2020-07-28 09:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:18:48 --> Input Class Initialized
INFO - 2020-07-28 09:18:48 --> Language Class Initialized
INFO - 2020-07-28 09:18:48 --> Loader Class Initialized
INFO - 2020-07-28 09:18:48 --> Helper loaded: url_helper
INFO - 2020-07-28 09:18:48 --> Helper loaded: file_helper
INFO - 2020-07-28 09:18:48 --> Database Driver Class Initialized
INFO - 2020-07-28 09:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:18:48 --> Email Class Initialized
INFO - 2020-07-28 09:18:48 --> Controller Class Initialized
INFO - 2020-07-28 09:18:48 --> Model Class Initialized
INFO - 2020-07-28 09:18:48 --> Model Class Initialized
DEBUG - 2020-07-28 09:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:18:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:18:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:18:48 --> Final output sent to browser
DEBUG - 2020-07-28 09:18:48 --> Total execution time: 0.0252
INFO - 2020-07-28 09:18:49 --> Config Class Initialized
INFO - 2020-07-28 09:18:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:18:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:18:49 --> Utf8 Class Initialized
INFO - 2020-07-28 09:18:49 --> URI Class Initialized
DEBUG - 2020-07-28 09:18:49 --> No URI present. Default controller set.
INFO - 2020-07-28 09:18:49 --> Router Class Initialized
INFO - 2020-07-28 09:18:49 --> Output Class Initialized
INFO - 2020-07-28 09:18:49 --> Security Class Initialized
DEBUG - 2020-07-28 09:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:18:49 --> Input Class Initialized
INFO - 2020-07-28 09:18:49 --> Language Class Initialized
INFO - 2020-07-28 09:18:49 --> Loader Class Initialized
INFO - 2020-07-28 09:18:49 --> Helper loaded: url_helper
INFO - 2020-07-28 09:18:49 --> Helper loaded: file_helper
INFO - 2020-07-28 09:18:49 --> Database Driver Class Initialized
INFO - 2020-07-28 09:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:18:49 --> Email Class Initialized
INFO - 2020-07-28 09:18:49 --> Controller Class Initialized
INFO - 2020-07-28 09:18:49 --> Model Class Initialized
INFO - 2020-07-28 09:18:49 --> Model Class Initialized
DEBUG - 2020-07-28 09:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:18:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:18:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:18:49 --> Final output sent to browser
DEBUG - 2020-07-28 09:18:49 --> Total execution time: 0.0223
INFO - 2020-07-28 09:18:54 --> Config Class Initialized
INFO - 2020-07-28 09:18:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:18:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:18:54 --> Utf8 Class Initialized
INFO - 2020-07-28 09:18:54 --> URI Class Initialized
INFO - 2020-07-28 09:18:54 --> Router Class Initialized
INFO - 2020-07-28 09:18:54 --> Output Class Initialized
INFO - 2020-07-28 09:18:54 --> Security Class Initialized
DEBUG - 2020-07-28 09:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:18:54 --> Input Class Initialized
INFO - 2020-07-28 09:18:54 --> Language Class Initialized
INFO - 2020-07-28 09:18:54 --> Loader Class Initialized
INFO - 2020-07-28 09:18:54 --> Helper loaded: url_helper
INFO - 2020-07-28 09:18:54 --> Helper loaded: file_helper
INFO - 2020-07-28 09:18:54 --> Database Driver Class Initialized
INFO - 2020-07-28 09:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:18:54 --> Email Class Initialized
INFO - 2020-07-28 09:18:54 --> Controller Class Initialized
INFO - 2020-07-28 09:18:54 --> Model Class Initialized
INFO - 2020-07-28 09:18:54 --> Model Class Initialized
DEBUG - 2020-07-28 09:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:18:55 --> Config Class Initialized
INFO - 2020-07-28 09:18:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:18:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:18:55 --> Utf8 Class Initialized
INFO - 2020-07-28 09:18:55 --> URI Class Initialized
DEBUG - 2020-07-28 09:18:55 --> No URI present. Default controller set.
INFO - 2020-07-28 09:18:55 --> Router Class Initialized
INFO - 2020-07-28 09:18:55 --> Output Class Initialized
INFO - 2020-07-28 09:18:55 --> Security Class Initialized
DEBUG - 2020-07-28 09:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:18:55 --> Input Class Initialized
INFO - 2020-07-28 09:18:55 --> Language Class Initialized
INFO - 2020-07-28 09:18:55 --> Loader Class Initialized
INFO - 2020-07-28 09:18:55 --> Helper loaded: url_helper
INFO - 2020-07-28 09:18:55 --> Helper loaded: file_helper
INFO - 2020-07-28 09:18:55 --> Database Driver Class Initialized
INFO - 2020-07-28 09:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:18:55 --> Email Class Initialized
INFO - 2020-07-28 09:18:55 --> Controller Class Initialized
INFO - 2020-07-28 09:18:55 --> Model Class Initialized
INFO - 2020-07-28 09:18:55 --> Model Class Initialized
DEBUG - 2020-07-28 09:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:18:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:18:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:18:55 --> Final output sent to browser
DEBUG - 2020-07-28 09:18:55 --> Total execution time: 0.0224
INFO - 2020-07-28 09:19:01 --> Config Class Initialized
INFO - 2020-07-28 09:19:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:19:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:19:01 --> Utf8 Class Initialized
INFO - 2020-07-28 09:19:01 --> URI Class Initialized
INFO - 2020-07-28 09:19:01 --> Router Class Initialized
INFO - 2020-07-28 09:19:01 --> Output Class Initialized
INFO - 2020-07-28 09:19:01 --> Security Class Initialized
DEBUG - 2020-07-28 09:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:19:01 --> Input Class Initialized
INFO - 2020-07-28 09:19:02 --> Language Class Initialized
INFO - 2020-07-28 09:19:02 --> Loader Class Initialized
INFO - 2020-07-28 09:19:02 --> Helper loaded: url_helper
INFO - 2020-07-28 09:19:02 --> Helper loaded: file_helper
INFO - 2020-07-28 09:19:02 --> Database Driver Class Initialized
INFO - 2020-07-28 09:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:19:02 --> Email Class Initialized
INFO - 2020-07-28 09:19:02 --> Controller Class Initialized
INFO - 2020-07-28 09:19:02 --> Model Class Initialized
INFO - 2020-07-28 09:19:02 --> Model Class Initialized
DEBUG - 2020-07-28 09:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:19:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:19:02 --> Config Class Initialized
INFO - 2020-07-28 09:19:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:19:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:19:02 --> Utf8 Class Initialized
INFO - 2020-07-28 09:19:02 --> URI Class Initialized
DEBUG - 2020-07-28 09:19:02 --> No URI present. Default controller set.
INFO - 2020-07-28 09:19:02 --> Router Class Initialized
INFO - 2020-07-28 09:19:02 --> Output Class Initialized
INFO - 2020-07-28 09:19:02 --> Security Class Initialized
DEBUG - 2020-07-28 09:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:19:02 --> Input Class Initialized
INFO - 2020-07-28 09:19:02 --> Language Class Initialized
INFO - 2020-07-28 09:19:02 --> Loader Class Initialized
INFO - 2020-07-28 09:19:02 --> Helper loaded: url_helper
INFO - 2020-07-28 09:19:02 --> Helper loaded: file_helper
INFO - 2020-07-28 09:19:02 --> Database Driver Class Initialized
INFO - 2020-07-28 09:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:19:02 --> Email Class Initialized
INFO - 2020-07-28 09:19:02 --> Controller Class Initialized
INFO - 2020-07-28 09:19:02 --> Model Class Initialized
INFO - 2020-07-28 09:19:02 --> Model Class Initialized
DEBUG - 2020-07-28 09:19:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:19:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:19:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:19:02 --> Final output sent to browser
DEBUG - 2020-07-28 09:19:02 --> Total execution time: 0.0256
INFO - 2020-07-28 09:24:53 --> Config Class Initialized
INFO - 2020-07-28 09:24:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:24:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:24:53 --> Utf8 Class Initialized
INFO - 2020-07-28 09:24:53 --> URI Class Initialized
DEBUG - 2020-07-28 09:24:53 --> No URI present. Default controller set.
INFO - 2020-07-28 09:24:53 --> Router Class Initialized
INFO - 2020-07-28 09:24:53 --> Output Class Initialized
INFO - 2020-07-28 09:24:53 --> Security Class Initialized
DEBUG - 2020-07-28 09:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:24:53 --> Input Class Initialized
INFO - 2020-07-28 09:24:53 --> Language Class Initialized
INFO - 2020-07-28 09:24:53 --> Loader Class Initialized
INFO - 2020-07-28 09:24:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:24:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:24:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:24:53 --> Email Class Initialized
INFO - 2020-07-28 09:24:53 --> Controller Class Initialized
INFO - 2020-07-28 09:24:53 --> Model Class Initialized
INFO - 2020-07-28 09:24:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:24:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:24:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:24:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:24:53 --> Final output sent to browser
DEBUG - 2020-07-28 09:24:53 --> Total execution time: 0.4075
INFO - 2020-07-28 09:25:02 --> Config Class Initialized
INFO - 2020-07-28 09:25:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:25:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:25:02 --> Utf8 Class Initialized
INFO - 2020-07-28 09:25:02 --> URI Class Initialized
DEBUG - 2020-07-28 09:25:02 --> No URI present. Default controller set.
INFO - 2020-07-28 09:25:02 --> Router Class Initialized
INFO - 2020-07-28 09:25:02 --> Output Class Initialized
INFO - 2020-07-28 09:25:02 --> Security Class Initialized
DEBUG - 2020-07-28 09:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:25:02 --> Input Class Initialized
INFO - 2020-07-28 09:25:02 --> Language Class Initialized
INFO - 2020-07-28 09:25:02 --> Loader Class Initialized
INFO - 2020-07-28 09:25:02 --> Helper loaded: url_helper
INFO - 2020-07-28 09:25:02 --> Helper loaded: file_helper
INFO - 2020-07-28 09:25:02 --> Database Driver Class Initialized
INFO - 2020-07-28 09:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:25:02 --> Email Class Initialized
INFO - 2020-07-28 09:25:02 --> Controller Class Initialized
INFO - 2020-07-28 09:25:02 --> Model Class Initialized
INFO - 2020-07-28 09:25:02 --> Model Class Initialized
DEBUG - 2020-07-28 09:25:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:25:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:25:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:25:02 --> Final output sent to browser
DEBUG - 2020-07-28 09:25:02 --> Total execution time: 0.0255
INFO - 2020-07-28 09:25:05 --> Config Class Initialized
INFO - 2020-07-28 09:25:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:25:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:25:05 --> Utf8 Class Initialized
INFO - 2020-07-28 09:25:05 --> URI Class Initialized
DEBUG - 2020-07-28 09:25:05 --> No URI present. Default controller set.
INFO - 2020-07-28 09:25:05 --> Router Class Initialized
INFO - 2020-07-28 09:25:05 --> Output Class Initialized
INFO - 2020-07-28 09:25:05 --> Security Class Initialized
DEBUG - 2020-07-28 09:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:25:05 --> Input Class Initialized
INFO - 2020-07-28 09:25:05 --> Language Class Initialized
INFO - 2020-07-28 09:25:05 --> Loader Class Initialized
INFO - 2020-07-28 09:25:05 --> Helper loaded: url_helper
INFO - 2020-07-28 09:25:05 --> Helper loaded: file_helper
INFO - 2020-07-28 09:25:05 --> Database Driver Class Initialized
INFO - 2020-07-28 09:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:25:05 --> Email Class Initialized
INFO - 2020-07-28 09:25:05 --> Controller Class Initialized
INFO - 2020-07-28 09:25:05 --> Model Class Initialized
INFO - 2020-07-28 09:25:05 --> Model Class Initialized
DEBUG - 2020-07-28 09:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:25:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:25:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:25:05 --> Final output sent to browser
DEBUG - 2020-07-28 09:25:05 --> Total execution time: 0.0216
INFO - 2020-07-28 09:25:39 --> Config Class Initialized
INFO - 2020-07-28 09:25:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:25:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:25:39 --> Utf8 Class Initialized
INFO - 2020-07-28 09:25:39 --> URI Class Initialized
INFO - 2020-07-28 09:25:39 --> Router Class Initialized
INFO - 2020-07-28 09:25:39 --> Output Class Initialized
INFO - 2020-07-28 09:25:39 --> Security Class Initialized
DEBUG - 2020-07-28 09:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:25:39 --> Input Class Initialized
INFO - 2020-07-28 09:25:39 --> Language Class Initialized
INFO - 2020-07-28 09:25:39 --> Loader Class Initialized
INFO - 2020-07-28 09:25:39 --> Helper loaded: url_helper
INFO - 2020-07-28 09:25:39 --> Helper loaded: file_helper
INFO - 2020-07-28 09:25:39 --> Database Driver Class Initialized
INFO - 2020-07-28 09:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:25:39 --> Email Class Initialized
INFO - 2020-07-28 09:25:39 --> Controller Class Initialized
INFO - 2020-07-28 09:25:39 --> Model Class Initialized
INFO - 2020-07-28 09:25:39 --> Model Class Initialized
DEBUG - 2020-07-28 09:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:25:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:25:39 --> Config Class Initialized
INFO - 2020-07-28 09:25:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:25:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:25:39 --> Utf8 Class Initialized
INFO - 2020-07-28 09:25:39 --> URI Class Initialized
DEBUG - 2020-07-28 09:25:39 --> No URI present. Default controller set.
INFO - 2020-07-28 09:25:39 --> Router Class Initialized
INFO - 2020-07-28 09:25:39 --> Output Class Initialized
INFO - 2020-07-28 09:25:39 --> Security Class Initialized
DEBUG - 2020-07-28 09:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:25:39 --> Input Class Initialized
INFO - 2020-07-28 09:25:39 --> Language Class Initialized
INFO - 2020-07-28 09:25:39 --> Loader Class Initialized
INFO - 2020-07-28 09:25:39 --> Helper loaded: url_helper
INFO - 2020-07-28 09:25:39 --> Helper loaded: file_helper
INFO - 2020-07-28 09:25:39 --> Database Driver Class Initialized
INFO - 2020-07-28 09:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:25:39 --> Email Class Initialized
INFO - 2020-07-28 09:25:39 --> Controller Class Initialized
INFO - 2020-07-28 09:25:39 --> Model Class Initialized
INFO - 2020-07-28 09:25:39 --> Model Class Initialized
DEBUG - 2020-07-28 09:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:25:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:25:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:25:39 --> Final output sent to browser
DEBUG - 2020-07-28 09:25:39 --> Total execution time: 0.0220
INFO - 2020-07-28 09:27:17 --> Config Class Initialized
INFO - 2020-07-28 09:27:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:27:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:27:17 --> Utf8 Class Initialized
INFO - 2020-07-28 09:27:17 --> URI Class Initialized
DEBUG - 2020-07-28 09:27:17 --> No URI present. Default controller set.
INFO - 2020-07-28 09:27:17 --> Router Class Initialized
INFO - 2020-07-28 09:27:17 --> Output Class Initialized
INFO - 2020-07-28 09:27:17 --> Security Class Initialized
DEBUG - 2020-07-28 09:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:27:17 --> Input Class Initialized
INFO - 2020-07-28 09:27:17 --> Language Class Initialized
INFO - 2020-07-28 09:27:17 --> Loader Class Initialized
INFO - 2020-07-28 09:27:17 --> Helper loaded: url_helper
INFO - 2020-07-28 09:27:17 --> Helper loaded: file_helper
INFO - 2020-07-28 09:27:17 --> Database Driver Class Initialized
INFO - 2020-07-28 09:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:27:17 --> Email Class Initialized
INFO - 2020-07-28 09:27:17 --> Controller Class Initialized
INFO - 2020-07-28 09:27:17 --> Model Class Initialized
INFO - 2020-07-28 09:27:17 --> Model Class Initialized
DEBUG - 2020-07-28 09:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:27:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:27:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:27:17 --> Final output sent to browser
DEBUG - 2020-07-28 09:27:17 --> Total execution time: 0.0221
INFO - 2020-07-28 09:27:19 --> Config Class Initialized
INFO - 2020-07-28 09:27:19 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:27:19 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:27:19 --> Utf8 Class Initialized
INFO - 2020-07-28 09:27:19 --> URI Class Initialized
DEBUG - 2020-07-28 09:27:19 --> No URI present. Default controller set.
INFO - 2020-07-28 09:27:19 --> Router Class Initialized
INFO - 2020-07-28 09:27:19 --> Output Class Initialized
INFO - 2020-07-28 09:27:19 --> Security Class Initialized
DEBUG - 2020-07-28 09:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:27:19 --> Input Class Initialized
INFO - 2020-07-28 09:27:19 --> Language Class Initialized
INFO - 2020-07-28 09:27:19 --> Loader Class Initialized
INFO - 2020-07-28 09:27:19 --> Helper loaded: url_helper
INFO - 2020-07-28 09:27:19 --> Helper loaded: file_helper
INFO - 2020-07-28 09:27:19 --> Database Driver Class Initialized
INFO - 2020-07-28 09:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:27:19 --> Email Class Initialized
INFO - 2020-07-28 09:27:19 --> Controller Class Initialized
INFO - 2020-07-28 09:27:19 --> Model Class Initialized
INFO - 2020-07-28 09:27:19 --> Model Class Initialized
DEBUG - 2020-07-28 09:27:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:27:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:27:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:27:19 --> Final output sent to browser
DEBUG - 2020-07-28 09:27:19 --> Total execution time: 0.0247
INFO - 2020-07-28 09:27:22 --> Config Class Initialized
INFO - 2020-07-28 09:27:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:27:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:27:22 --> Utf8 Class Initialized
INFO - 2020-07-28 09:27:22 --> URI Class Initialized
INFO - 2020-07-28 09:27:22 --> Router Class Initialized
INFO - 2020-07-28 09:27:22 --> Output Class Initialized
INFO - 2020-07-28 09:27:22 --> Security Class Initialized
DEBUG - 2020-07-28 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:27:22 --> Input Class Initialized
INFO - 2020-07-28 09:27:22 --> Language Class Initialized
INFO - 2020-07-28 09:27:22 --> Loader Class Initialized
INFO - 2020-07-28 09:27:22 --> Helper loaded: url_helper
INFO - 2020-07-28 09:27:22 --> Helper loaded: file_helper
INFO - 2020-07-28 09:27:22 --> Database Driver Class Initialized
INFO - 2020-07-28 09:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:27:22 --> Email Class Initialized
INFO - 2020-07-28 09:27:22 --> Controller Class Initialized
INFO - 2020-07-28 09:27:22 --> Model Class Initialized
INFO - 2020-07-28 09:27:22 --> Model Class Initialized
DEBUG - 2020-07-28 09:27:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:27:22 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:27:22 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 29
ERROR - 2020-07-28 09:27:22 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 32
ERROR - 2020-07-28 09:27:22 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 33
ERROR - 2020-07-28 09:27:22 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 47
ERROR - 2020-07-28 09:27:22 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 102
ERROR - 2020-07-28 09:27:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:27:57 --> Config Class Initialized
INFO - 2020-07-28 09:27:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:27:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:27:57 --> Utf8 Class Initialized
INFO - 2020-07-28 09:27:57 --> URI Class Initialized
INFO - 2020-07-28 09:27:57 --> Router Class Initialized
INFO - 2020-07-28 09:27:57 --> Output Class Initialized
INFO - 2020-07-28 09:27:57 --> Security Class Initialized
DEBUG - 2020-07-28 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:27:57 --> Input Class Initialized
INFO - 2020-07-28 09:27:57 --> Language Class Initialized
INFO - 2020-07-28 09:27:57 --> Loader Class Initialized
INFO - 2020-07-28 09:27:57 --> Helper loaded: url_helper
INFO - 2020-07-28 09:27:57 --> Helper loaded: file_helper
INFO - 2020-07-28 09:27:57 --> Database Driver Class Initialized
INFO - 2020-07-28 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:27:57 --> Email Class Initialized
INFO - 2020-07-28 09:27:57 --> Controller Class Initialized
INFO - 2020-07-28 09:27:57 --> Model Class Initialized
INFO - 2020-07-28 09:27:57 --> Model Class Initialized
DEBUG - 2020-07-28 09:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:27:57 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:27:57 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 29
ERROR - 2020-07-28 09:27:57 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 32
ERROR - 2020-07-28 09:27:57 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 33
ERROR - 2020-07-28 09:27:57 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 47
ERROR - 2020-07-28 09:27:57 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 102
ERROR - 2020-07-28 09:27:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:27:59 --> Config Class Initialized
INFO - 2020-07-28 09:27:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:27:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:27:59 --> Utf8 Class Initialized
INFO - 2020-07-28 09:27:59 --> URI Class Initialized
INFO - 2020-07-28 09:27:59 --> Router Class Initialized
INFO - 2020-07-28 09:27:59 --> Output Class Initialized
INFO - 2020-07-28 09:27:59 --> Security Class Initialized
DEBUG - 2020-07-28 09:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:27:59 --> Input Class Initialized
INFO - 2020-07-28 09:27:59 --> Language Class Initialized
INFO - 2020-07-28 09:27:59 --> Loader Class Initialized
INFO - 2020-07-28 09:27:59 --> Helper loaded: url_helper
INFO - 2020-07-28 09:27:59 --> Helper loaded: file_helper
INFO - 2020-07-28 09:27:59 --> Database Driver Class Initialized
INFO - 2020-07-28 09:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:27:59 --> Email Class Initialized
INFO - 2020-07-28 09:27:59 --> Controller Class Initialized
INFO - 2020-07-28 09:27:59 --> Model Class Initialized
INFO - 2020-07-28 09:27:59 --> Model Class Initialized
DEBUG - 2020-07-28 09:27:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:27:59 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:27:59 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 29
ERROR - 2020-07-28 09:27:59 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 32
ERROR - 2020-07-28 09:27:59 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 33
ERROR - 2020-07-28 09:27:59 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 47
ERROR - 2020-07-28 09:27:59 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 102
ERROR - 2020-07-28 09:27:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:28:02 --> Config Class Initialized
INFO - 2020-07-28 09:28:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:28:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:28:02 --> Utf8 Class Initialized
INFO - 2020-07-28 09:28:02 --> URI Class Initialized
DEBUG - 2020-07-28 09:28:02 --> No URI present. Default controller set.
INFO - 2020-07-28 09:28:02 --> Router Class Initialized
INFO - 2020-07-28 09:28:02 --> Output Class Initialized
INFO - 2020-07-28 09:28:02 --> Security Class Initialized
DEBUG - 2020-07-28 09:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:28:02 --> Input Class Initialized
INFO - 2020-07-28 09:28:02 --> Language Class Initialized
INFO - 2020-07-28 09:28:02 --> Loader Class Initialized
INFO - 2020-07-28 09:28:02 --> Helper loaded: url_helper
INFO - 2020-07-28 09:28:02 --> Helper loaded: file_helper
INFO - 2020-07-28 09:28:02 --> Database Driver Class Initialized
INFO - 2020-07-28 09:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:28:02 --> Email Class Initialized
INFO - 2020-07-28 09:28:02 --> Controller Class Initialized
INFO - 2020-07-28 09:28:02 --> Model Class Initialized
INFO - 2020-07-28 09:28:02 --> Model Class Initialized
DEBUG - 2020-07-28 09:28:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:28:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:28:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:28:02 --> Final output sent to browser
DEBUG - 2020-07-28 09:28:02 --> Total execution time: 0.0257
INFO - 2020-07-28 09:28:04 --> Config Class Initialized
INFO - 2020-07-28 09:28:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:28:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:28:04 --> Utf8 Class Initialized
INFO - 2020-07-28 09:28:04 --> URI Class Initialized
INFO - 2020-07-28 09:28:04 --> Router Class Initialized
INFO - 2020-07-28 09:28:04 --> Output Class Initialized
INFO - 2020-07-28 09:28:04 --> Security Class Initialized
DEBUG - 2020-07-28 09:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:28:04 --> Input Class Initialized
INFO - 2020-07-28 09:28:04 --> Language Class Initialized
INFO - 2020-07-28 09:28:04 --> Loader Class Initialized
INFO - 2020-07-28 09:28:04 --> Helper loaded: url_helper
INFO - 2020-07-28 09:28:04 --> Helper loaded: file_helper
INFO - 2020-07-28 09:28:04 --> Database Driver Class Initialized
INFO - 2020-07-28 09:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:28:04 --> Email Class Initialized
INFO - 2020-07-28 09:28:04 --> Controller Class Initialized
INFO - 2020-07-28 09:28:04 --> Model Class Initialized
INFO - 2020-07-28 09:28:04 --> Model Class Initialized
DEBUG - 2020-07-28 09:28:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:28:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:28:04 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 29
ERROR - 2020-07-28 09:28:04 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 32
ERROR - 2020-07-28 09:28:04 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 33
ERROR - 2020-07-28 09:28:04 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 47
ERROR - 2020-07-28 09:28:04 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 102
ERROR - 2020-07-28 09:28:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:30:08 --> Config Class Initialized
INFO - 2020-07-28 09:30:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:30:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:30:08 --> Utf8 Class Initialized
INFO - 2020-07-28 09:30:08 --> URI Class Initialized
INFO - 2020-07-28 09:30:08 --> Router Class Initialized
INFO - 2020-07-28 09:30:08 --> Output Class Initialized
INFO - 2020-07-28 09:30:08 --> Security Class Initialized
DEBUG - 2020-07-28 09:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:30:08 --> Input Class Initialized
INFO - 2020-07-28 09:30:08 --> Language Class Initialized
INFO - 2020-07-28 09:30:08 --> Loader Class Initialized
INFO - 2020-07-28 09:30:08 --> Helper loaded: url_helper
INFO - 2020-07-28 09:30:08 --> Helper loaded: file_helper
INFO - 2020-07-28 09:30:08 --> Database Driver Class Initialized
INFO - 2020-07-28 09:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:30:08 --> Email Class Initialized
INFO - 2020-07-28 09:30:08 --> Controller Class Initialized
INFO - 2020-07-28 09:30:08 --> Model Class Initialized
INFO - 2020-07-28 09:30:08 --> Model Class Initialized
DEBUG - 2020-07-28 09:30:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:30:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:30:09 --> Config Class Initialized
INFO - 2020-07-28 09:30:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:30:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:30:09 --> Utf8 Class Initialized
INFO - 2020-07-28 09:30:09 --> URI Class Initialized
DEBUG - 2020-07-28 09:30:09 --> No URI present. Default controller set.
INFO - 2020-07-28 09:30:09 --> Router Class Initialized
INFO - 2020-07-28 09:30:09 --> Output Class Initialized
INFO - 2020-07-28 09:30:09 --> Security Class Initialized
DEBUG - 2020-07-28 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:30:09 --> Input Class Initialized
INFO - 2020-07-28 09:30:09 --> Language Class Initialized
INFO - 2020-07-28 09:30:09 --> Loader Class Initialized
INFO - 2020-07-28 09:30:09 --> Helper loaded: url_helper
INFO - 2020-07-28 09:30:09 --> Helper loaded: file_helper
INFO - 2020-07-28 09:30:09 --> Database Driver Class Initialized
INFO - 2020-07-28 09:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:30:09 --> Email Class Initialized
INFO - 2020-07-28 09:30:09 --> Controller Class Initialized
INFO - 2020-07-28 09:30:09 --> Model Class Initialized
INFO - 2020-07-28 09:30:09 --> Model Class Initialized
DEBUG - 2020-07-28 09:30:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:30:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:30:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:30:09 --> Final output sent to browser
DEBUG - 2020-07-28 09:30:09 --> Total execution time: 0.0238
INFO - 2020-07-28 09:30:12 --> Config Class Initialized
INFO - 2020-07-28 09:30:12 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:30:12 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:30:12 --> Utf8 Class Initialized
INFO - 2020-07-28 09:30:12 --> URI Class Initialized
INFO - 2020-07-28 09:30:12 --> Router Class Initialized
INFO - 2020-07-28 09:30:12 --> Output Class Initialized
INFO - 2020-07-28 09:30:12 --> Security Class Initialized
DEBUG - 2020-07-28 09:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:30:12 --> Input Class Initialized
INFO - 2020-07-28 09:30:12 --> Language Class Initialized
INFO - 2020-07-28 09:30:12 --> Loader Class Initialized
INFO - 2020-07-28 09:30:12 --> Helper loaded: url_helper
INFO - 2020-07-28 09:30:12 --> Helper loaded: file_helper
INFO - 2020-07-28 09:30:12 --> Database Driver Class Initialized
INFO - 2020-07-28 09:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:30:13 --> Email Class Initialized
INFO - 2020-07-28 09:30:13 --> Controller Class Initialized
INFO - 2020-07-28 09:30:13 --> Model Class Initialized
INFO - 2020-07-28 09:30:13 --> Model Class Initialized
DEBUG - 2020-07-28 09:30:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:30:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:30:13 --> Config Class Initialized
INFO - 2020-07-28 09:30:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:30:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:30:13 --> Utf8 Class Initialized
INFO - 2020-07-28 09:30:13 --> URI Class Initialized
DEBUG - 2020-07-28 09:30:13 --> No URI present. Default controller set.
INFO - 2020-07-28 09:30:13 --> Router Class Initialized
INFO - 2020-07-28 09:30:13 --> Output Class Initialized
INFO - 2020-07-28 09:30:13 --> Security Class Initialized
DEBUG - 2020-07-28 09:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:30:13 --> Input Class Initialized
INFO - 2020-07-28 09:30:13 --> Language Class Initialized
INFO - 2020-07-28 09:30:13 --> Loader Class Initialized
INFO - 2020-07-28 09:30:13 --> Helper loaded: url_helper
INFO - 2020-07-28 09:30:13 --> Helper loaded: file_helper
INFO - 2020-07-28 09:30:13 --> Database Driver Class Initialized
INFO - 2020-07-28 09:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:30:13 --> Email Class Initialized
INFO - 2020-07-28 09:30:13 --> Controller Class Initialized
INFO - 2020-07-28 09:30:13 --> Model Class Initialized
INFO - 2020-07-28 09:30:13 --> Model Class Initialized
DEBUG - 2020-07-28 09:30:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:30:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:30:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:30:13 --> Final output sent to browser
DEBUG - 2020-07-28 09:30:13 --> Total execution time: 0.0215
INFO - 2020-07-28 09:30:43 --> Config Class Initialized
INFO - 2020-07-28 09:30:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:30:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:30:43 --> Utf8 Class Initialized
INFO - 2020-07-28 09:30:43 --> URI Class Initialized
INFO - 2020-07-28 09:30:43 --> Router Class Initialized
INFO - 2020-07-28 09:30:43 --> Output Class Initialized
INFO - 2020-07-28 09:30:43 --> Security Class Initialized
DEBUG - 2020-07-28 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:30:43 --> Input Class Initialized
INFO - 2020-07-28 09:30:43 --> Language Class Initialized
INFO - 2020-07-28 09:30:43 --> Loader Class Initialized
INFO - 2020-07-28 09:30:43 --> Helper loaded: url_helper
INFO - 2020-07-28 09:30:43 --> Helper loaded: file_helper
INFO - 2020-07-28 09:30:43 --> Database Driver Class Initialized
INFO - 2020-07-28 09:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:30:43 --> Email Class Initialized
INFO - 2020-07-28 09:30:43 --> Controller Class Initialized
INFO - 2020-07-28 09:30:43 --> Model Class Initialized
INFO - 2020-07-28 09:30:43 --> Model Class Initialized
DEBUG - 2020-07-28 09:30:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:30:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:30:43 --> Config Class Initialized
INFO - 2020-07-28 09:30:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:30:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:30:43 --> Utf8 Class Initialized
INFO - 2020-07-28 09:30:43 --> URI Class Initialized
DEBUG - 2020-07-28 09:30:43 --> No URI present. Default controller set.
INFO - 2020-07-28 09:30:43 --> Router Class Initialized
INFO - 2020-07-28 09:30:43 --> Output Class Initialized
INFO - 2020-07-28 09:30:43 --> Security Class Initialized
DEBUG - 2020-07-28 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:30:43 --> Input Class Initialized
INFO - 2020-07-28 09:30:43 --> Language Class Initialized
INFO - 2020-07-28 09:30:43 --> Loader Class Initialized
INFO - 2020-07-28 09:30:43 --> Helper loaded: url_helper
INFO - 2020-07-28 09:30:43 --> Helper loaded: file_helper
INFO - 2020-07-28 09:30:43 --> Database Driver Class Initialized
INFO - 2020-07-28 09:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:30:43 --> Email Class Initialized
INFO - 2020-07-28 09:30:43 --> Controller Class Initialized
INFO - 2020-07-28 09:30:43 --> Model Class Initialized
INFO - 2020-07-28 09:30:43 --> Model Class Initialized
DEBUG - 2020-07-28 09:30:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:30:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:30:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:30:43 --> Final output sent to browser
DEBUG - 2020-07-28 09:30:43 --> Total execution time: 0.0210
INFO - 2020-07-28 09:32:33 --> Config Class Initialized
INFO - 2020-07-28 09:32:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:32:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:32:33 --> Utf8 Class Initialized
INFO - 2020-07-28 09:32:33 --> URI Class Initialized
INFO - 2020-07-28 09:32:33 --> Router Class Initialized
INFO - 2020-07-28 09:32:33 --> Output Class Initialized
INFO - 2020-07-28 09:32:33 --> Security Class Initialized
DEBUG - 2020-07-28 09:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:32:33 --> Input Class Initialized
INFO - 2020-07-28 09:32:33 --> Language Class Initialized
INFO - 2020-07-28 09:32:33 --> Loader Class Initialized
INFO - 2020-07-28 09:32:33 --> Helper loaded: url_helper
INFO - 2020-07-28 09:32:33 --> Helper loaded: file_helper
INFO - 2020-07-28 09:32:33 --> Database Driver Class Initialized
INFO - 2020-07-28 09:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:32:33 --> Email Class Initialized
INFO - 2020-07-28 09:32:33 --> Controller Class Initialized
INFO - 2020-07-28 09:32:33 --> Model Class Initialized
INFO - 2020-07-28 09:32:33 --> Model Class Initialized
DEBUG - 2020-07-28 09:32:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:32:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:32:34 --> Config Class Initialized
INFO - 2020-07-28 09:32:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:32:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:32:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:32:34 --> URI Class Initialized
DEBUG - 2020-07-28 09:32:34 --> No URI present. Default controller set.
INFO - 2020-07-28 09:32:34 --> Router Class Initialized
INFO - 2020-07-28 09:32:34 --> Output Class Initialized
INFO - 2020-07-28 09:32:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:32:34 --> Input Class Initialized
INFO - 2020-07-28 09:32:34 --> Language Class Initialized
INFO - 2020-07-28 09:32:34 --> Loader Class Initialized
INFO - 2020-07-28 09:32:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:32:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:32:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:32:34 --> Email Class Initialized
INFO - 2020-07-28 09:32:34 --> Controller Class Initialized
INFO - 2020-07-28 09:32:34 --> Model Class Initialized
INFO - 2020-07-28 09:32:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:32:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:32:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:32:34 --> Final output sent to browser
DEBUG - 2020-07-28 09:32:34 --> Total execution time: 0.0228
INFO - 2020-07-28 09:36:24 --> Config Class Initialized
INFO - 2020-07-28 09:36:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:36:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:36:24 --> Utf8 Class Initialized
INFO - 2020-07-28 09:36:24 --> URI Class Initialized
INFO - 2020-07-28 09:36:24 --> Router Class Initialized
INFO - 2020-07-28 09:36:24 --> Output Class Initialized
INFO - 2020-07-28 09:36:24 --> Security Class Initialized
DEBUG - 2020-07-28 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:36:24 --> Input Class Initialized
INFO - 2020-07-28 09:36:24 --> Language Class Initialized
INFO - 2020-07-28 09:36:24 --> Loader Class Initialized
INFO - 2020-07-28 09:36:24 --> Helper loaded: url_helper
INFO - 2020-07-28 09:36:24 --> Helper loaded: file_helper
INFO - 2020-07-28 09:36:24 --> Database Driver Class Initialized
INFO - 2020-07-28 09:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:36:24 --> Email Class Initialized
INFO - 2020-07-28 09:36:24 --> Controller Class Initialized
INFO - 2020-07-28 09:36:24 --> Model Class Initialized
INFO - 2020-07-28 09:36:24 --> Model Class Initialized
DEBUG - 2020-07-28 09:36:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:36:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:36:25 --> Config Class Initialized
INFO - 2020-07-28 09:36:25 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:36:25 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:36:25 --> Utf8 Class Initialized
INFO - 2020-07-28 09:36:25 --> URI Class Initialized
DEBUG - 2020-07-28 09:36:25 --> No URI present. Default controller set.
INFO - 2020-07-28 09:36:25 --> Router Class Initialized
INFO - 2020-07-28 09:36:25 --> Output Class Initialized
INFO - 2020-07-28 09:36:25 --> Security Class Initialized
DEBUG - 2020-07-28 09:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:36:25 --> Input Class Initialized
INFO - 2020-07-28 09:36:25 --> Language Class Initialized
INFO - 2020-07-28 09:36:25 --> Loader Class Initialized
INFO - 2020-07-28 09:36:25 --> Helper loaded: url_helper
INFO - 2020-07-28 09:36:25 --> Helper loaded: file_helper
INFO - 2020-07-28 09:36:25 --> Database Driver Class Initialized
INFO - 2020-07-28 09:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:36:25 --> Email Class Initialized
INFO - 2020-07-28 09:36:25 --> Controller Class Initialized
INFO - 2020-07-28 09:36:25 --> Model Class Initialized
INFO - 2020-07-28 09:36:25 --> Model Class Initialized
DEBUG - 2020-07-28 09:36:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:36:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:36:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:36:25 --> Final output sent to browser
DEBUG - 2020-07-28 09:36:25 --> Total execution time: 0.0255
INFO - 2020-07-28 09:36:57 --> Config Class Initialized
INFO - 2020-07-28 09:36:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:36:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:36:57 --> Utf8 Class Initialized
INFO - 2020-07-28 09:36:57 --> URI Class Initialized
DEBUG - 2020-07-28 09:36:57 --> No URI present. Default controller set.
INFO - 2020-07-28 09:36:57 --> Router Class Initialized
INFO - 2020-07-28 09:36:57 --> Output Class Initialized
INFO - 2020-07-28 09:36:57 --> Security Class Initialized
DEBUG - 2020-07-28 09:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:36:57 --> Input Class Initialized
INFO - 2020-07-28 09:36:57 --> Language Class Initialized
INFO - 2020-07-28 09:36:57 --> Loader Class Initialized
INFO - 2020-07-28 09:36:57 --> Helper loaded: url_helper
INFO - 2020-07-28 09:36:57 --> Helper loaded: file_helper
INFO - 2020-07-28 09:36:57 --> Database Driver Class Initialized
INFO - 2020-07-28 09:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:36:57 --> Email Class Initialized
INFO - 2020-07-28 09:36:57 --> Controller Class Initialized
INFO - 2020-07-28 09:36:57 --> Model Class Initialized
INFO - 2020-07-28 09:36:57 --> Model Class Initialized
DEBUG - 2020-07-28 09:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:36:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:36:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:36:57 --> Final output sent to browser
DEBUG - 2020-07-28 09:36:57 --> Total execution time: 0.0241
INFO - 2020-07-28 09:36:59 --> Config Class Initialized
INFO - 2020-07-28 09:36:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:36:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:36:59 --> Utf8 Class Initialized
INFO - 2020-07-28 09:36:59 --> URI Class Initialized
INFO - 2020-07-28 09:36:59 --> Router Class Initialized
INFO - 2020-07-28 09:36:59 --> Output Class Initialized
INFO - 2020-07-28 09:36:59 --> Security Class Initialized
DEBUG - 2020-07-28 09:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:36:59 --> Input Class Initialized
INFO - 2020-07-28 09:36:59 --> Language Class Initialized
INFO - 2020-07-28 09:36:59 --> Loader Class Initialized
INFO - 2020-07-28 09:36:59 --> Helper loaded: url_helper
INFO - 2020-07-28 09:36:59 --> Helper loaded: file_helper
INFO - 2020-07-28 09:36:59 --> Database Driver Class Initialized
INFO - 2020-07-28 09:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:36:59 --> Email Class Initialized
INFO - 2020-07-28 09:36:59 --> Controller Class Initialized
INFO - 2020-07-28 09:36:59 --> Model Class Initialized
INFO - 2020-07-28 09:36:59 --> Model Class Initialized
DEBUG - 2020-07-28 09:36:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:36:59 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:36:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:40:56 --> Config Class Initialized
INFO - 2020-07-28 09:40:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:40:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:40:56 --> Utf8 Class Initialized
INFO - 2020-07-28 09:40:56 --> URI Class Initialized
INFO - 2020-07-28 09:40:56 --> Router Class Initialized
INFO - 2020-07-28 09:40:56 --> Output Class Initialized
INFO - 2020-07-28 09:40:56 --> Security Class Initialized
DEBUG - 2020-07-28 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:40:56 --> Input Class Initialized
INFO - 2020-07-28 09:40:56 --> Language Class Initialized
INFO - 2020-07-28 09:40:56 --> Loader Class Initialized
INFO - 2020-07-28 09:40:56 --> Helper loaded: url_helper
INFO - 2020-07-28 09:40:56 --> Helper loaded: file_helper
INFO - 2020-07-28 09:40:56 --> Database Driver Class Initialized
INFO - 2020-07-28 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:40:56 --> Email Class Initialized
INFO - 2020-07-28 09:40:56 --> Controller Class Initialized
INFO - 2020-07-28 09:40:56 --> Model Class Initialized
INFO - 2020-07-28 09:40:56 --> Model Class Initialized
DEBUG - 2020-07-28 09:40:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:40:56 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:40:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:40:59 --> Config Class Initialized
INFO - 2020-07-28 09:40:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:40:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:40:59 --> Utf8 Class Initialized
INFO - 2020-07-28 09:40:59 --> URI Class Initialized
DEBUG - 2020-07-28 09:40:59 --> No URI present. Default controller set.
INFO - 2020-07-28 09:40:59 --> Router Class Initialized
INFO - 2020-07-28 09:40:59 --> Output Class Initialized
INFO - 2020-07-28 09:40:59 --> Security Class Initialized
DEBUG - 2020-07-28 09:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:40:59 --> Input Class Initialized
INFO - 2020-07-28 09:40:59 --> Language Class Initialized
INFO - 2020-07-28 09:40:59 --> Loader Class Initialized
INFO - 2020-07-28 09:40:59 --> Helper loaded: url_helper
INFO - 2020-07-28 09:40:59 --> Helper loaded: file_helper
INFO - 2020-07-28 09:40:59 --> Database Driver Class Initialized
INFO - 2020-07-28 09:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:40:59 --> Email Class Initialized
INFO - 2020-07-28 09:40:59 --> Controller Class Initialized
INFO - 2020-07-28 09:40:59 --> Model Class Initialized
INFO - 2020-07-28 09:40:59 --> Model Class Initialized
DEBUG - 2020-07-28 09:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:40:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:40:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:40:59 --> Final output sent to browser
DEBUG - 2020-07-28 09:40:59 --> Total execution time: 0.0251
INFO - 2020-07-28 09:41:01 --> Config Class Initialized
INFO - 2020-07-28 09:41:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:41:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:41:01 --> Utf8 Class Initialized
INFO - 2020-07-28 09:41:01 --> URI Class Initialized
INFO - 2020-07-28 09:41:01 --> Router Class Initialized
INFO - 2020-07-28 09:41:01 --> Output Class Initialized
INFO - 2020-07-28 09:41:01 --> Security Class Initialized
DEBUG - 2020-07-28 09:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:41:01 --> Input Class Initialized
INFO - 2020-07-28 09:41:01 --> Language Class Initialized
INFO - 2020-07-28 09:41:01 --> Loader Class Initialized
INFO - 2020-07-28 09:41:01 --> Helper loaded: url_helper
INFO - 2020-07-28 09:41:01 --> Helper loaded: file_helper
INFO - 2020-07-28 09:41:01 --> Database Driver Class Initialized
INFO - 2020-07-28 09:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:41:01 --> Email Class Initialized
INFO - 2020-07-28 09:41:01 --> Controller Class Initialized
INFO - 2020-07-28 09:41:01 --> Model Class Initialized
INFO - 2020-07-28 09:41:01 --> Model Class Initialized
DEBUG - 2020-07-28 09:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:41:01 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:41:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:42:14 --> Config Class Initialized
INFO - 2020-07-28 09:42:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:42:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:42:14 --> Utf8 Class Initialized
INFO - 2020-07-28 09:42:14 --> URI Class Initialized
INFO - 2020-07-28 09:42:14 --> Router Class Initialized
INFO - 2020-07-28 09:42:14 --> Output Class Initialized
INFO - 2020-07-28 09:42:14 --> Security Class Initialized
DEBUG - 2020-07-28 09:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:42:14 --> Input Class Initialized
INFO - 2020-07-28 09:42:14 --> Language Class Initialized
INFO - 2020-07-28 09:42:14 --> Loader Class Initialized
INFO - 2020-07-28 09:42:14 --> Helper loaded: url_helper
INFO - 2020-07-28 09:42:14 --> Helper loaded: file_helper
INFO - 2020-07-28 09:42:14 --> Database Driver Class Initialized
INFO - 2020-07-28 09:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:42:14 --> Email Class Initialized
INFO - 2020-07-28 09:42:14 --> Controller Class Initialized
INFO - 2020-07-28 09:42:14 --> Model Class Initialized
INFO - 2020-07-28 09:42:14 --> Model Class Initialized
DEBUG - 2020-07-28 09:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:42:14 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:42:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:42:16 --> Config Class Initialized
INFO - 2020-07-28 09:42:16 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:42:16 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:42:16 --> Utf8 Class Initialized
INFO - 2020-07-28 09:42:16 --> URI Class Initialized
DEBUG - 2020-07-28 09:42:16 --> No URI present. Default controller set.
INFO - 2020-07-28 09:42:16 --> Router Class Initialized
INFO - 2020-07-28 09:42:16 --> Output Class Initialized
INFO - 2020-07-28 09:42:16 --> Security Class Initialized
DEBUG - 2020-07-28 09:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:42:16 --> Input Class Initialized
INFO - 2020-07-28 09:42:16 --> Language Class Initialized
INFO - 2020-07-28 09:42:16 --> Loader Class Initialized
INFO - 2020-07-28 09:42:16 --> Helper loaded: url_helper
INFO - 2020-07-28 09:42:16 --> Helper loaded: file_helper
INFO - 2020-07-28 09:42:16 --> Database Driver Class Initialized
INFO - 2020-07-28 09:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:42:16 --> Email Class Initialized
INFO - 2020-07-28 09:42:16 --> Controller Class Initialized
INFO - 2020-07-28 09:42:16 --> Model Class Initialized
INFO - 2020-07-28 09:42:16 --> Model Class Initialized
DEBUG - 2020-07-28 09:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:42:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:42:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:42:16 --> Final output sent to browser
DEBUG - 2020-07-28 09:42:16 --> Total execution time: 0.0222
INFO - 2020-07-28 09:42:19 --> Config Class Initialized
INFO - 2020-07-28 09:42:19 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:42:19 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:42:19 --> Utf8 Class Initialized
INFO - 2020-07-28 09:42:19 --> URI Class Initialized
INFO - 2020-07-28 09:42:19 --> Router Class Initialized
INFO - 2020-07-28 09:42:19 --> Output Class Initialized
INFO - 2020-07-28 09:42:19 --> Security Class Initialized
DEBUG - 2020-07-28 09:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:42:19 --> Input Class Initialized
INFO - 2020-07-28 09:42:19 --> Language Class Initialized
INFO - 2020-07-28 09:42:19 --> Loader Class Initialized
INFO - 2020-07-28 09:42:19 --> Helper loaded: url_helper
INFO - 2020-07-28 09:42:19 --> Helper loaded: file_helper
INFO - 2020-07-28 09:42:19 --> Database Driver Class Initialized
INFO - 2020-07-28 09:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:42:19 --> Email Class Initialized
INFO - 2020-07-28 09:42:19 --> Controller Class Initialized
INFO - 2020-07-28 09:42:19 --> Model Class Initialized
INFO - 2020-07-28 09:42:19 --> Model Class Initialized
DEBUG - 2020-07-28 09:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:42:19 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:42:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:43:29 --> Config Class Initialized
INFO - 2020-07-28 09:43:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:43:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:43:29 --> Utf8 Class Initialized
INFO - 2020-07-28 09:43:29 --> URI Class Initialized
INFO - 2020-07-28 09:43:29 --> Router Class Initialized
INFO - 2020-07-28 09:43:29 --> Output Class Initialized
INFO - 2020-07-28 09:43:29 --> Security Class Initialized
DEBUG - 2020-07-28 09:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:43:29 --> Input Class Initialized
INFO - 2020-07-28 09:43:29 --> Language Class Initialized
INFO - 2020-07-28 09:43:29 --> Loader Class Initialized
INFO - 2020-07-28 09:43:29 --> Helper loaded: url_helper
INFO - 2020-07-28 09:43:29 --> Helper loaded: file_helper
INFO - 2020-07-28 09:43:29 --> Database Driver Class Initialized
INFO - 2020-07-28 09:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:43:29 --> Email Class Initialized
INFO - 2020-07-28 09:43:29 --> Controller Class Initialized
INFO - 2020-07-28 09:43:29 --> Model Class Initialized
INFO - 2020-07-28 09:43:29 --> Model Class Initialized
DEBUG - 2020-07-28 09:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:43:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:43:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 09:43:29 --> Final output sent to browser
DEBUG - 2020-07-28 09:43:29 --> Total execution time: 0.0362
INFO - 2020-07-28 09:43:36 --> Config Class Initialized
INFO - 2020-07-28 09:43:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:43:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:43:36 --> Utf8 Class Initialized
INFO - 2020-07-28 09:43:36 --> URI Class Initialized
INFO - 2020-07-28 09:43:36 --> Router Class Initialized
INFO - 2020-07-28 09:43:36 --> Output Class Initialized
INFO - 2020-07-28 09:43:36 --> Security Class Initialized
DEBUG - 2020-07-28 09:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:43:36 --> Input Class Initialized
INFO - 2020-07-28 09:43:36 --> Language Class Initialized
INFO - 2020-07-28 09:43:36 --> Loader Class Initialized
INFO - 2020-07-28 09:43:36 --> Helper loaded: url_helper
INFO - 2020-07-28 09:43:36 --> Helper loaded: file_helper
INFO - 2020-07-28 09:43:36 --> Database Driver Class Initialized
INFO - 2020-07-28 09:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:43:36 --> Email Class Initialized
INFO - 2020-07-28 09:43:36 --> Controller Class Initialized
INFO - 2020-07-28 09:43:36 --> Model Class Initialized
INFO - 2020-07-28 09:43:36 --> Model Class Initialized
DEBUG - 2020-07-28 09:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:43:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:43:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 09:43:36 --> Final output sent to browser
DEBUG - 2020-07-28 09:43:36 --> Total execution time: 0.0293
INFO - 2020-07-28 09:43:41 --> Config Class Initialized
INFO - 2020-07-28 09:43:41 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:43:41 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:43:41 --> Utf8 Class Initialized
INFO - 2020-07-28 09:43:41 --> URI Class Initialized
DEBUG - 2020-07-28 09:43:41 --> No URI present. Default controller set.
INFO - 2020-07-28 09:43:41 --> Router Class Initialized
INFO - 2020-07-28 09:43:41 --> Output Class Initialized
INFO - 2020-07-28 09:43:41 --> Security Class Initialized
DEBUG - 2020-07-28 09:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:43:41 --> Input Class Initialized
INFO - 2020-07-28 09:43:41 --> Language Class Initialized
INFO - 2020-07-28 09:43:41 --> Loader Class Initialized
INFO - 2020-07-28 09:43:41 --> Helper loaded: url_helper
INFO - 2020-07-28 09:43:41 --> Helper loaded: file_helper
INFO - 2020-07-28 09:43:41 --> Database Driver Class Initialized
INFO - 2020-07-28 09:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:43:41 --> Email Class Initialized
INFO - 2020-07-28 09:43:41 --> Controller Class Initialized
INFO - 2020-07-28 09:43:41 --> Model Class Initialized
INFO - 2020-07-28 09:43:41 --> Model Class Initialized
DEBUG - 2020-07-28 09:43:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:43:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:43:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:43:41 --> Final output sent to browser
DEBUG - 2020-07-28 09:43:41 --> Total execution time: 0.0196
INFO - 2020-07-28 09:43:45 --> Config Class Initialized
INFO - 2020-07-28 09:43:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:43:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:43:45 --> Utf8 Class Initialized
INFO - 2020-07-28 09:43:45 --> URI Class Initialized
INFO - 2020-07-28 09:43:45 --> Router Class Initialized
INFO - 2020-07-28 09:43:45 --> Output Class Initialized
INFO - 2020-07-28 09:43:45 --> Security Class Initialized
DEBUG - 2020-07-28 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:43:45 --> Input Class Initialized
INFO - 2020-07-28 09:43:45 --> Language Class Initialized
INFO - 2020-07-28 09:43:45 --> Loader Class Initialized
INFO - 2020-07-28 09:43:45 --> Helper loaded: url_helper
INFO - 2020-07-28 09:43:45 --> Helper loaded: file_helper
INFO - 2020-07-28 09:43:45 --> Database Driver Class Initialized
INFO - 2020-07-28 09:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:43:45 --> Email Class Initialized
INFO - 2020-07-28 09:43:45 --> Controller Class Initialized
INFO - 2020-07-28 09:43:45 --> Model Class Initialized
INFO - 2020-07-28 09:43:45 --> Model Class Initialized
DEBUG - 2020-07-28 09:43:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:43:45 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:43:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:44:49 --> Config Class Initialized
INFO - 2020-07-28 09:44:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:49 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:49 --> URI Class Initialized
INFO - 2020-07-28 09:44:49 --> Router Class Initialized
INFO - 2020-07-28 09:44:49 --> Output Class Initialized
INFO - 2020-07-28 09:44:49 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:49 --> Input Class Initialized
INFO - 2020-07-28 09:44:49 --> Language Class Initialized
INFO - 2020-07-28 09:44:49 --> Loader Class Initialized
INFO - 2020-07-28 09:44:49 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:49 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:49 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:49 --> Email Class Initialized
INFO - 2020-07-28 09:44:49 --> Controller Class Initialized
INFO - 2020-07-28 09:44:49 --> Model Class Initialized
INFO - 2020-07-28 09:44:49 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:49 --> Config Class Initialized
INFO - 2020-07-28 09:44:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:49 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:49 --> URI Class Initialized
DEBUG - 2020-07-28 09:44:49 --> No URI present. Default controller set.
INFO - 2020-07-28 09:44:49 --> Router Class Initialized
INFO - 2020-07-28 09:44:49 --> Output Class Initialized
INFO - 2020-07-28 09:44:49 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:49 --> Input Class Initialized
INFO - 2020-07-28 09:44:49 --> Language Class Initialized
INFO - 2020-07-28 09:44:49 --> Loader Class Initialized
INFO - 2020-07-28 09:44:49 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:49 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:49 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:49 --> Email Class Initialized
INFO - 2020-07-28 09:44:49 --> Controller Class Initialized
INFO - 2020-07-28 09:44:49 --> Model Class Initialized
INFO - 2020-07-28 09:44:50 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:44:50 --> Final output sent to browser
DEBUG - 2020-07-28 09:44:50 --> Total execution time: 0.0297
INFO - 2020-07-28 09:44:53 --> Config Class Initialized
INFO - 2020-07-28 09:44:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:53 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:53 --> URI Class Initialized
INFO - 2020-07-28 09:44:53 --> Router Class Initialized
INFO - 2020-07-28 09:44:53 --> Output Class Initialized
INFO - 2020-07-28 09:44:53 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:53 --> Input Class Initialized
INFO - 2020-07-28 09:44:53 --> Language Class Initialized
INFO - 2020-07-28 09:44:53 --> Loader Class Initialized
INFO - 2020-07-28 09:44:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:53 --> Email Class Initialized
INFO - 2020-07-28 09:44:53 --> Controller Class Initialized
INFO - 2020-07-28 09:44:53 --> Model Class Initialized
INFO - 2020-07-28 09:44:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:53 --> Config Class Initialized
INFO - 2020-07-28 09:44:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:53 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:53 --> URI Class Initialized
DEBUG - 2020-07-28 09:44:53 --> No URI present. Default controller set.
INFO - 2020-07-28 09:44:53 --> Router Class Initialized
INFO - 2020-07-28 09:44:53 --> Output Class Initialized
INFO - 2020-07-28 09:44:53 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:53 --> Input Class Initialized
INFO - 2020-07-28 09:44:53 --> Language Class Initialized
INFO - 2020-07-28 09:44:53 --> Loader Class Initialized
INFO - 2020-07-28 09:44:53 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:53 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:53 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:53 --> Email Class Initialized
INFO - 2020-07-28 09:44:53 --> Controller Class Initialized
INFO - 2020-07-28 09:44:53 --> Model Class Initialized
INFO - 2020-07-28 09:44:53 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:44:53 --> Final output sent to browser
DEBUG - 2020-07-28 09:44:53 --> Total execution time: 0.0232
INFO - 2020-07-28 09:44:56 --> Config Class Initialized
INFO - 2020-07-28 09:44:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:56 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:56 --> URI Class Initialized
INFO - 2020-07-28 09:44:56 --> Router Class Initialized
INFO - 2020-07-28 09:44:56 --> Output Class Initialized
INFO - 2020-07-28 09:44:56 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:56 --> Input Class Initialized
INFO - 2020-07-28 09:44:56 --> Language Class Initialized
INFO - 2020-07-28 09:44:56 --> Loader Class Initialized
INFO - 2020-07-28 09:44:56 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:56 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:56 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:56 --> Email Class Initialized
INFO - 2020-07-28 09:44:56 --> Controller Class Initialized
INFO - 2020-07-28 09:44:56 --> Model Class Initialized
INFO - 2020-07-28 09:44:56 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:56 --> Config Class Initialized
INFO - 2020-07-28 09:44:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:56 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:56 --> URI Class Initialized
DEBUG - 2020-07-28 09:44:56 --> No URI present. Default controller set.
INFO - 2020-07-28 09:44:56 --> Router Class Initialized
INFO - 2020-07-28 09:44:56 --> Output Class Initialized
INFO - 2020-07-28 09:44:56 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:56 --> Input Class Initialized
INFO - 2020-07-28 09:44:56 --> Language Class Initialized
INFO - 2020-07-28 09:44:56 --> Loader Class Initialized
INFO - 2020-07-28 09:44:56 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:56 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:56 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:56 --> Email Class Initialized
INFO - 2020-07-28 09:44:56 --> Controller Class Initialized
INFO - 2020-07-28 09:44:56 --> Model Class Initialized
INFO - 2020-07-28 09:44:56 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:44:56 --> Final output sent to browser
DEBUG - 2020-07-28 09:44:56 --> Total execution time: 0.0214
INFO - 2020-07-28 09:44:59 --> Config Class Initialized
INFO - 2020-07-28 09:44:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:59 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:59 --> URI Class Initialized
INFO - 2020-07-28 09:44:59 --> Router Class Initialized
INFO - 2020-07-28 09:44:59 --> Output Class Initialized
INFO - 2020-07-28 09:44:59 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:59 --> Input Class Initialized
INFO - 2020-07-28 09:44:59 --> Language Class Initialized
INFO - 2020-07-28 09:44:59 --> Loader Class Initialized
INFO - 2020-07-28 09:44:59 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:59 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:59 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:59 --> Email Class Initialized
INFO - 2020-07-28 09:44:59 --> Controller Class Initialized
INFO - 2020-07-28 09:44:59 --> Model Class Initialized
INFO - 2020-07-28 09:44:59 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:59 --> Config Class Initialized
INFO - 2020-07-28 09:44:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:44:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:44:59 --> Utf8 Class Initialized
INFO - 2020-07-28 09:44:59 --> URI Class Initialized
DEBUG - 2020-07-28 09:44:59 --> No URI present. Default controller set.
INFO - 2020-07-28 09:44:59 --> Router Class Initialized
INFO - 2020-07-28 09:44:59 --> Output Class Initialized
INFO - 2020-07-28 09:44:59 --> Security Class Initialized
DEBUG - 2020-07-28 09:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:44:59 --> Input Class Initialized
INFO - 2020-07-28 09:44:59 --> Language Class Initialized
INFO - 2020-07-28 09:44:59 --> Loader Class Initialized
INFO - 2020-07-28 09:44:59 --> Helper loaded: url_helper
INFO - 2020-07-28 09:44:59 --> Helper loaded: file_helper
INFO - 2020-07-28 09:44:59 --> Database Driver Class Initialized
INFO - 2020-07-28 09:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:44:59 --> Email Class Initialized
INFO - 2020-07-28 09:44:59 --> Controller Class Initialized
INFO - 2020-07-28 09:44:59 --> Model Class Initialized
INFO - 2020-07-28 09:44:59 --> Model Class Initialized
DEBUG - 2020-07-28 09:44:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:44:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:44:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:44:59 --> Final output sent to browser
DEBUG - 2020-07-28 09:44:59 --> Total execution time: 0.0224
INFO - 2020-07-28 09:45:34 --> Config Class Initialized
INFO - 2020-07-28 09:45:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:45:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:45:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:45:34 --> URI Class Initialized
DEBUG - 2020-07-28 09:45:34 --> No URI present. Default controller set.
INFO - 2020-07-28 09:45:34 --> Router Class Initialized
INFO - 2020-07-28 09:45:34 --> Output Class Initialized
INFO - 2020-07-28 09:45:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:45:34 --> Input Class Initialized
INFO - 2020-07-28 09:45:34 --> Language Class Initialized
INFO - 2020-07-28 09:45:34 --> Loader Class Initialized
INFO - 2020-07-28 09:45:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:45:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:45:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:45:34 --> Email Class Initialized
INFO - 2020-07-28 09:45:34 --> Controller Class Initialized
INFO - 2020-07-28 09:45:34 --> Model Class Initialized
INFO - 2020-07-28 09:45:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:45:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:45:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:45:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:45:34 --> Final output sent to browser
DEBUG - 2020-07-28 09:45:34 --> Total execution time: 0.0258
INFO - 2020-07-28 09:45:34 --> Config Class Initialized
INFO - 2020-07-28 09:45:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:45:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:45:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:45:34 --> URI Class Initialized
DEBUG - 2020-07-28 09:45:34 --> No URI present. Default controller set.
INFO - 2020-07-28 09:45:34 --> Router Class Initialized
INFO - 2020-07-28 09:45:34 --> Output Class Initialized
INFO - 2020-07-28 09:45:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:45:34 --> Input Class Initialized
INFO - 2020-07-28 09:45:34 --> Language Class Initialized
INFO - 2020-07-28 09:45:34 --> Loader Class Initialized
INFO - 2020-07-28 09:45:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:45:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:45:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:45:34 --> Email Class Initialized
INFO - 2020-07-28 09:45:34 --> Controller Class Initialized
INFO - 2020-07-28 09:45:34 --> Model Class Initialized
INFO - 2020-07-28 09:45:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:45:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:45:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:45:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:45:34 --> Final output sent to browser
DEBUG - 2020-07-28 09:45:34 --> Total execution time: 0.0235
INFO - 2020-07-28 09:45:42 --> Config Class Initialized
INFO - 2020-07-28 09:45:42 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:45:42 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:45:42 --> Utf8 Class Initialized
INFO - 2020-07-28 09:45:42 --> URI Class Initialized
INFO - 2020-07-28 09:45:42 --> Router Class Initialized
INFO - 2020-07-28 09:45:42 --> Output Class Initialized
INFO - 2020-07-28 09:45:42 --> Security Class Initialized
DEBUG - 2020-07-28 09:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:45:42 --> Input Class Initialized
INFO - 2020-07-28 09:45:42 --> Language Class Initialized
INFO - 2020-07-28 09:45:42 --> Loader Class Initialized
INFO - 2020-07-28 09:45:42 --> Helper loaded: url_helper
INFO - 2020-07-28 09:45:42 --> Helper loaded: file_helper
INFO - 2020-07-28 09:45:42 --> Database Driver Class Initialized
INFO - 2020-07-28 09:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:45:42 --> Email Class Initialized
INFO - 2020-07-28 09:45:42 --> Controller Class Initialized
INFO - 2020-07-28 09:45:42 --> Model Class Initialized
INFO - 2020-07-28 09:45:42 --> Model Class Initialized
DEBUG - 2020-07-28 09:45:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:45:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:45:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 09:45:42 --> Final output sent to browser
DEBUG - 2020-07-28 09:45:42 --> Total execution time: 0.0220
INFO - 2020-07-28 09:45:52 --> Config Class Initialized
INFO - 2020-07-28 09:45:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:45:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:45:52 --> Utf8 Class Initialized
INFO - 2020-07-28 09:45:52 --> URI Class Initialized
INFO - 2020-07-28 09:45:52 --> Router Class Initialized
INFO - 2020-07-28 09:45:52 --> Output Class Initialized
INFO - 2020-07-28 09:45:52 --> Security Class Initialized
DEBUG - 2020-07-28 09:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:45:52 --> Input Class Initialized
INFO - 2020-07-28 09:45:52 --> Language Class Initialized
INFO - 2020-07-28 09:45:52 --> Loader Class Initialized
INFO - 2020-07-28 09:45:52 --> Helper loaded: url_helper
INFO - 2020-07-28 09:45:52 --> Helper loaded: file_helper
INFO - 2020-07-28 09:45:52 --> Database Driver Class Initialized
INFO - 2020-07-28 09:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:45:52 --> Email Class Initialized
INFO - 2020-07-28 09:45:52 --> Controller Class Initialized
INFO - 2020-07-28 09:45:52 --> Model Class Initialized
INFO - 2020-07-28 09:45:52 --> Model Class Initialized
DEBUG - 2020-07-28 09:45:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:45:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:45:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 09:45:52 --> Final output sent to browser
DEBUG - 2020-07-28 09:45:52 --> Total execution time: 0.0401
INFO - 2020-07-28 09:46:28 --> Config Class Initialized
INFO - 2020-07-28 09:46:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:46:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:46:28 --> Utf8 Class Initialized
INFO - 2020-07-28 09:46:28 --> URI Class Initialized
DEBUG - 2020-07-28 09:46:28 --> No URI present. Default controller set.
INFO - 2020-07-28 09:46:28 --> Router Class Initialized
INFO - 2020-07-28 09:46:28 --> Output Class Initialized
INFO - 2020-07-28 09:46:28 --> Security Class Initialized
DEBUG - 2020-07-28 09:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:46:28 --> Input Class Initialized
INFO - 2020-07-28 09:46:28 --> Language Class Initialized
INFO - 2020-07-28 09:46:28 --> Loader Class Initialized
INFO - 2020-07-28 09:46:28 --> Helper loaded: url_helper
INFO - 2020-07-28 09:46:28 --> Helper loaded: file_helper
INFO - 2020-07-28 09:46:28 --> Database Driver Class Initialized
INFO - 2020-07-28 09:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:46:28 --> Email Class Initialized
INFO - 2020-07-28 09:46:28 --> Controller Class Initialized
INFO - 2020-07-28 09:46:28 --> Model Class Initialized
INFO - 2020-07-28 09:46:28 --> Model Class Initialized
DEBUG - 2020-07-28 09:46:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:46:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:46:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:46:28 --> Final output sent to browser
DEBUG - 2020-07-28 09:46:28 --> Total execution time: 0.0214
INFO - 2020-07-28 09:46:33 --> Config Class Initialized
INFO - 2020-07-28 09:46:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:46:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:46:33 --> Utf8 Class Initialized
INFO - 2020-07-28 09:46:33 --> URI Class Initialized
INFO - 2020-07-28 09:46:33 --> Router Class Initialized
INFO - 2020-07-28 09:46:33 --> Output Class Initialized
INFO - 2020-07-28 09:46:33 --> Security Class Initialized
DEBUG - 2020-07-28 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:46:33 --> Input Class Initialized
INFO - 2020-07-28 09:46:33 --> Language Class Initialized
INFO - 2020-07-28 09:46:33 --> Loader Class Initialized
INFO - 2020-07-28 09:46:33 --> Helper loaded: url_helper
INFO - 2020-07-28 09:46:33 --> Helper loaded: file_helper
INFO - 2020-07-28 09:46:33 --> Database Driver Class Initialized
INFO - 2020-07-28 09:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:46:33 --> Email Class Initialized
INFO - 2020-07-28 09:46:33 --> Controller Class Initialized
INFO - 2020-07-28 09:46:33 --> Model Class Initialized
INFO - 2020-07-28 09:46:33 --> Model Class Initialized
DEBUG - 2020-07-28 09:46:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:46:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:46:34 --> Config Class Initialized
INFO - 2020-07-28 09:46:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:46:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:46:34 --> Utf8 Class Initialized
INFO - 2020-07-28 09:46:34 --> URI Class Initialized
DEBUG - 2020-07-28 09:46:34 --> No URI present. Default controller set.
INFO - 2020-07-28 09:46:34 --> Router Class Initialized
INFO - 2020-07-28 09:46:34 --> Output Class Initialized
INFO - 2020-07-28 09:46:34 --> Security Class Initialized
DEBUG - 2020-07-28 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:46:34 --> Input Class Initialized
INFO - 2020-07-28 09:46:34 --> Language Class Initialized
INFO - 2020-07-28 09:46:34 --> Loader Class Initialized
INFO - 2020-07-28 09:46:34 --> Helper loaded: url_helper
INFO - 2020-07-28 09:46:34 --> Helper loaded: file_helper
INFO - 2020-07-28 09:46:34 --> Database Driver Class Initialized
INFO - 2020-07-28 09:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:46:34 --> Email Class Initialized
INFO - 2020-07-28 09:46:34 --> Controller Class Initialized
INFO - 2020-07-28 09:46:34 --> Model Class Initialized
INFO - 2020-07-28 09:46:34 --> Model Class Initialized
DEBUG - 2020-07-28 09:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:46:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:46:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:46:34 --> Final output sent to browser
DEBUG - 2020-07-28 09:46:34 --> Total execution time: 0.0237
INFO - 2020-07-28 09:47:00 --> Config Class Initialized
INFO - 2020-07-28 09:47:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:47:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:47:00 --> Utf8 Class Initialized
INFO - 2020-07-28 09:47:00 --> URI Class Initialized
INFO - 2020-07-28 09:47:00 --> Router Class Initialized
INFO - 2020-07-28 09:47:00 --> Output Class Initialized
INFO - 2020-07-28 09:47:00 --> Security Class Initialized
DEBUG - 2020-07-28 09:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:47:00 --> Input Class Initialized
INFO - 2020-07-28 09:47:00 --> Language Class Initialized
INFO - 2020-07-28 09:47:00 --> Loader Class Initialized
INFO - 2020-07-28 09:47:00 --> Helper loaded: url_helper
INFO - 2020-07-28 09:47:00 --> Helper loaded: file_helper
INFO - 2020-07-28 09:47:00 --> Database Driver Class Initialized
INFO - 2020-07-28 09:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:47:00 --> Email Class Initialized
INFO - 2020-07-28 09:47:00 --> Controller Class Initialized
INFO - 2020-07-28 09:47:00 --> Model Class Initialized
INFO - 2020-07-28 09:47:00 --> Model Class Initialized
DEBUG - 2020-07-28 09:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:47:00 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:47:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:51:26 --> Config Class Initialized
INFO - 2020-07-28 09:51:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:51:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:51:26 --> Utf8 Class Initialized
INFO - 2020-07-28 09:51:26 --> URI Class Initialized
INFO - 2020-07-28 09:51:26 --> Router Class Initialized
INFO - 2020-07-28 09:51:26 --> Output Class Initialized
INFO - 2020-07-28 09:51:26 --> Security Class Initialized
DEBUG - 2020-07-28 09:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:51:26 --> Input Class Initialized
INFO - 2020-07-28 09:51:26 --> Language Class Initialized
INFO - 2020-07-28 09:51:26 --> Loader Class Initialized
INFO - 2020-07-28 09:51:26 --> Helper loaded: url_helper
INFO - 2020-07-28 09:51:26 --> Database Driver Class Initialized
INFO - 2020-07-28 09:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:51:26 --> Email Class Initialized
INFO - 2020-07-28 09:51:26 --> Controller Class Initialized
INFO - 2020-07-28 09:51:26 --> Model Class Initialized
INFO - 2020-07-28 09:51:26 --> Model Class Initialized
DEBUG - 2020-07-28 09:51:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:51:26 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:51:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:55:20 --> Config Class Initialized
INFO - 2020-07-28 09:55:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:55:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:55:20 --> Utf8 Class Initialized
INFO - 2020-07-28 09:55:20 --> URI Class Initialized
INFO - 2020-07-28 09:55:20 --> Router Class Initialized
INFO - 2020-07-28 09:55:20 --> Output Class Initialized
INFO - 2020-07-28 09:55:20 --> Security Class Initialized
DEBUG - 2020-07-28 09:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:55:20 --> Input Class Initialized
INFO - 2020-07-28 09:55:20 --> Language Class Initialized
INFO - 2020-07-28 09:55:20 --> Loader Class Initialized
INFO - 2020-07-28 09:55:20 --> Helper loaded: url_helper
INFO - 2020-07-28 09:55:20 --> Database Driver Class Initialized
INFO - 2020-07-28 09:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:55:20 --> Email Class Initialized
INFO - 2020-07-28 09:55:20 --> Controller Class Initialized
INFO - 2020-07-28 09:55:20 --> Model Class Initialized
INFO - 2020-07-28 09:55:20 --> Model Class Initialized
DEBUG - 2020-07-28 09:55:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:55:20 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 09:55:22 --> Config Class Initialized
INFO - 2020-07-28 09:55:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:55:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:55:22 --> Utf8 Class Initialized
INFO - 2020-07-28 09:55:22 --> URI Class Initialized
DEBUG - 2020-07-28 09:55:22 --> No URI present. Default controller set.
INFO - 2020-07-28 09:55:22 --> Router Class Initialized
INFO - 2020-07-28 09:55:22 --> Output Class Initialized
INFO - 2020-07-28 09:55:22 --> Security Class Initialized
DEBUG - 2020-07-28 09:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:55:22 --> Input Class Initialized
INFO - 2020-07-28 09:55:22 --> Language Class Initialized
INFO - 2020-07-28 09:55:22 --> Loader Class Initialized
INFO - 2020-07-28 09:55:22 --> Helper loaded: url_helper
INFO - 2020-07-28 09:55:22 --> Database Driver Class Initialized
INFO - 2020-07-28 09:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:55:22 --> Email Class Initialized
INFO - 2020-07-28 09:55:22 --> Controller Class Initialized
INFO - 2020-07-28 09:55:22 --> Model Class Initialized
INFO - 2020-07-28 09:55:22 --> Model Class Initialized
DEBUG - 2020-07-28 09:55:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:55:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 09:55:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 09:55:22 --> Final output sent to browser
DEBUG - 2020-07-28 09:55:22 --> Total execution time: 0.0248
INFO - 2020-07-28 09:55:26 --> Config Class Initialized
INFO - 2020-07-28 09:55:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 09:55:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 09:55:26 --> Utf8 Class Initialized
INFO - 2020-07-28 09:55:26 --> URI Class Initialized
INFO - 2020-07-28 09:55:26 --> Router Class Initialized
INFO - 2020-07-28 09:55:26 --> Output Class Initialized
INFO - 2020-07-28 09:55:26 --> Security Class Initialized
DEBUG - 2020-07-28 09:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 09:55:26 --> Input Class Initialized
INFO - 2020-07-28 09:55:26 --> Language Class Initialized
INFO - 2020-07-28 09:55:26 --> Loader Class Initialized
INFO - 2020-07-28 09:55:26 --> Helper loaded: url_helper
INFO - 2020-07-28 09:55:26 --> Database Driver Class Initialized
INFO - 2020-07-28 09:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 09:55:26 --> Email Class Initialized
INFO - 2020-07-28 09:55:26 --> Controller Class Initialized
INFO - 2020-07-28 09:55:26 --> Model Class Initialized
INFO - 2020-07-28 09:55:26 --> Model Class Initialized
DEBUG - 2020-07-28 09:55:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 09:55:26 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 09:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:00:43 --> Config Class Initialized
INFO - 2020-07-28 10:00:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:00:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:00:43 --> Utf8 Class Initialized
INFO - 2020-07-28 10:00:43 --> URI Class Initialized
INFO - 2020-07-28 10:00:43 --> Router Class Initialized
INFO - 2020-07-28 10:00:43 --> Output Class Initialized
INFO - 2020-07-28 10:00:43 --> Security Class Initialized
DEBUG - 2020-07-28 10:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:00:43 --> Input Class Initialized
INFO - 2020-07-28 10:00:43 --> Language Class Initialized
INFO - 2020-07-28 10:00:43 --> Loader Class Initialized
INFO - 2020-07-28 10:00:43 --> Helper loaded: url_helper
INFO - 2020-07-28 10:00:43 --> Database Driver Class Initialized
INFO - 2020-07-28 10:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:00:43 --> Email Class Initialized
INFO - 2020-07-28 10:00:43 --> Controller Class Initialized
INFO - 2020-07-28 10:00:43 --> Model Class Initialized
INFO - 2020-07-28 10:00:43 --> Model Class Initialized
DEBUG - 2020-07-28 10:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:00:43 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:00:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:02:14 --> Config Class Initialized
INFO - 2020-07-28 10:02:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:02:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:02:14 --> Utf8 Class Initialized
INFO - 2020-07-28 10:02:14 --> URI Class Initialized
INFO - 2020-07-28 10:02:14 --> Router Class Initialized
INFO - 2020-07-28 10:02:14 --> Output Class Initialized
INFO - 2020-07-28 10:02:14 --> Security Class Initialized
DEBUG - 2020-07-28 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:02:14 --> Input Class Initialized
INFO - 2020-07-28 10:02:14 --> Language Class Initialized
INFO - 2020-07-28 10:02:14 --> Loader Class Initialized
INFO - 2020-07-28 10:02:14 --> Helper loaded: url_helper
INFO - 2020-07-28 10:02:14 --> Database Driver Class Initialized
INFO - 2020-07-28 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:02:14 --> Email Class Initialized
INFO - 2020-07-28 10:02:14 --> Controller Class Initialized
INFO - 2020-07-28 10:02:14 --> Model Class Initialized
INFO - 2020-07-28 10:02:14 --> Model Class Initialized
DEBUG - 2020-07-28 10:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:02:14 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:02:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:02:16 --> Config Class Initialized
INFO - 2020-07-28 10:02:16 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:02:16 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:02:16 --> Utf8 Class Initialized
INFO - 2020-07-28 10:02:16 --> URI Class Initialized
DEBUG - 2020-07-28 10:02:16 --> No URI present. Default controller set.
INFO - 2020-07-28 10:02:16 --> Router Class Initialized
INFO - 2020-07-28 10:02:16 --> Output Class Initialized
INFO - 2020-07-28 10:02:16 --> Security Class Initialized
DEBUG - 2020-07-28 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:02:16 --> Input Class Initialized
INFO - 2020-07-28 10:02:16 --> Language Class Initialized
INFO - 2020-07-28 10:02:16 --> Loader Class Initialized
INFO - 2020-07-28 10:02:16 --> Helper loaded: url_helper
INFO - 2020-07-28 10:02:16 --> Database Driver Class Initialized
INFO - 2020-07-28 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:02:16 --> Email Class Initialized
INFO - 2020-07-28 10:02:16 --> Controller Class Initialized
INFO - 2020-07-28 10:02:16 --> Model Class Initialized
INFO - 2020-07-28 10:02:16 --> Model Class Initialized
DEBUG - 2020-07-28 10:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:02:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:02:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:02:16 --> Final output sent to browser
DEBUG - 2020-07-28 10:02:16 --> Total execution time: 0.0229
INFO - 2020-07-28 10:02:20 --> Config Class Initialized
INFO - 2020-07-28 10:02:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:02:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:02:20 --> Utf8 Class Initialized
INFO - 2020-07-28 10:02:20 --> URI Class Initialized
INFO - 2020-07-28 10:02:20 --> Router Class Initialized
INFO - 2020-07-28 10:02:20 --> Output Class Initialized
INFO - 2020-07-28 10:02:20 --> Security Class Initialized
DEBUG - 2020-07-28 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:02:20 --> Input Class Initialized
INFO - 2020-07-28 10:02:20 --> Language Class Initialized
INFO - 2020-07-28 10:02:20 --> Loader Class Initialized
INFO - 2020-07-28 10:02:20 --> Helper loaded: url_helper
INFO - 2020-07-28 10:02:20 --> Database Driver Class Initialized
INFO - 2020-07-28 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:02:20 --> Email Class Initialized
INFO - 2020-07-28 10:02:20 --> Controller Class Initialized
INFO - 2020-07-28 10:02:20 --> Model Class Initialized
INFO - 2020-07-28 10:02:20 --> Model Class Initialized
DEBUG - 2020-07-28 10:02:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:02:20 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:02:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:03:15 --> Config Class Initialized
INFO - 2020-07-28 10:03:15 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:15 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:15 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:15 --> URI Class Initialized
INFO - 2020-07-28 10:03:15 --> Router Class Initialized
INFO - 2020-07-28 10:03:15 --> Output Class Initialized
INFO - 2020-07-28 10:03:15 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:15 --> Input Class Initialized
INFO - 2020-07-28 10:03:15 --> Language Class Initialized
INFO - 2020-07-28 10:03:15 --> Loader Class Initialized
INFO - 2020-07-28 10:03:15 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:15 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:15 --> Email Class Initialized
INFO - 2020-07-28 10:03:15 --> Controller Class Initialized
INFO - 2020-07-28 10:03:15 --> Model Class Initialized
INFO - 2020-07-28 10:03:15 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:15 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:03:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:03:17 --> Config Class Initialized
INFO - 2020-07-28 10:03:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:17 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:17 --> URI Class Initialized
DEBUG - 2020-07-28 10:03:17 --> No URI present. Default controller set.
INFO - 2020-07-28 10:03:17 --> Router Class Initialized
INFO - 2020-07-28 10:03:17 --> Output Class Initialized
INFO - 2020-07-28 10:03:17 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:17 --> Input Class Initialized
INFO - 2020-07-28 10:03:17 --> Language Class Initialized
INFO - 2020-07-28 10:03:17 --> Loader Class Initialized
INFO - 2020-07-28 10:03:17 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:17 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:17 --> Email Class Initialized
INFO - 2020-07-28 10:03:17 --> Controller Class Initialized
INFO - 2020-07-28 10:03:17 --> Model Class Initialized
INFO - 2020-07-28 10:03:17 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:03:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:03:17 --> Final output sent to browser
DEBUG - 2020-07-28 10:03:17 --> Total execution time: 0.0238
INFO - 2020-07-28 10:03:20 --> Config Class Initialized
INFO - 2020-07-28 10:03:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:20 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:20 --> URI Class Initialized
INFO - 2020-07-28 10:03:20 --> Router Class Initialized
INFO - 2020-07-28 10:03:20 --> Output Class Initialized
INFO - 2020-07-28 10:03:20 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:20 --> Input Class Initialized
INFO - 2020-07-28 10:03:20 --> Language Class Initialized
INFO - 2020-07-28 10:03:20 --> Loader Class Initialized
INFO - 2020-07-28 10:03:20 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:20 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:20 --> Email Class Initialized
INFO - 2020-07-28 10:03:20 --> Controller Class Initialized
INFO - 2020-07-28 10:03:20 --> Model Class Initialized
INFO - 2020-07-28 10:03:20 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:20 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:03:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:03:26 --> Config Class Initialized
INFO - 2020-07-28 10:03:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:26 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:26 --> URI Class Initialized
DEBUG - 2020-07-28 10:03:26 --> No URI present. Default controller set.
INFO - 2020-07-28 10:03:26 --> Router Class Initialized
INFO - 2020-07-28 10:03:26 --> Output Class Initialized
INFO - 2020-07-28 10:03:26 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:26 --> Input Class Initialized
INFO - 2020-07-28 10:03:26 --> Language Class Initialized
INFO - 2020-07-28 10:03:26 --> Loader Class Initialized
INFO - 2020-07-28 10:03:26 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:26 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:26 --> Email Class Initialized
INFO - 2020-07-28 10:03:26 --> Controller Class Initialized
INFO - 2020-07-28 10:03:26 --> Model Class Initialized
INFO - 2020-07-28 10:03:26 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:03:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:03:26 --> Final output sent to browser
DEBUG - 2020-07-28 10:03:26 --> Total execution time: 0.0227
INFO - 2020-07-28 10:03:30 --> Config Class Initialized
INFO - 2020-07-28 10:03:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:30 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:30 --> URI Class Initialized
INFO - 2020-07-28 10:03:30 --> Router Class Initialized
INFO - 2020-07-28 10:03:30 --> Output Class Initialized
INFO - 2020-07-28 10:03:30 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:30 --> Input Class Initialized
INFO - 2020-07-28 10:03:30 --> Language Class Initialized
INFO - 2020-07-28 10:03:30 --> Loader Class Initialized
INFO - 2020-07-28 10:03:30 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:30 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:30 --> Email Class Initialized
INFO - 2020-07-28 10:03:30 --> Controller Class Initialized
INFO - 2020-07-28 10:03:30 --> Model Class Initialized
INFO - 2020-07-28 10:03:30 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:30 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:03:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:03:33 --> Config Class Initialized
INFO - 2020-07-28 10:03:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:33 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:33 --> URI Class Initialized
DEBUG - 2020-07-28 10:03:33 --> No URI present. Default controller set.
INFO - 2020-07-28 10:03:33 --> Router Class Initialized
INFO - 2020-07-28 10:03:33 --> Output Class Initialized
INFO - 2020-07-28 10:03:33 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:33 --> Input Class Initialized
INFO - 2020-07-28 10:03:33 --> Language Class Initialized
INFO - 2020-07-28 10:03:33 --> Loader Class Initialized
INFO - 2020-07-28 10:03:33 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:33 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:33 --> Email Class Initialized
INFO - 2020-07-28 10:03:33 --> Controller Class Initialized
INFO - 2020-07-28 10:03:33 --> Model Class Initialized
INFO - 2020-07-28 10:03:33 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:03:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:03:33 --> Final output sent to browser
DEBUG - 2020-07-28 10:03:33 --> Total execution time: 0.0225
INFO - 2020-07-28 10:03:35 --> Config Class Initialized
INFO - 2020-07-28 10:03:35 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:35 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:35 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:35 --> URI Class Initialized
DEBUG - 2020-07-28 10:03:35 --> No URI present. Default controller set.
INFO - 2020-07-28 10:03:35 --> Router Class Initialized
INFO - 2020-07-28 10:03:35 --> Output Class Initialized
INFO - 2020-07-28 10:03:35 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:35 --> Input Class Initialized
INFO - 2020-07-28 10:03:35 --> Language Class Initialized
INFO - 2020-07-28 10:03:35 --> Loader Class Initialized
INFO - 2020-07-28 10:03:35 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:35 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:35 --> Email Class Initialized
INFO - 2020-07-28 10:03:35 --> Controller Class Initialized
INFO - 2020-07-28 10:03:35 --> Model Class Initialized
INFO - 2020-07-28 10:03:35 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:03:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:03:35 --> Final output sent to browser
DEBUG - 2020-07-28 10:03:35 --> Total execution time: 0.0227
INFO - 2020-07-28 10:03:39 --> Config Class Initialized
INFO - 2020-07-28 10:03:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:03:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:03:39 --> Utf8 Class Initialized
INFO - 2020-07-28 10:03:39 --> URI Class Initialized
INFO - 2020-07-28 10:03:39 --> Router Class Initialized
INFO - 2020-07-28 10:03:39 --> Output Class Initialized
INFO - 2020-07-28 10:03:39 --> Security Class Initialized
DEBUG - 2020-07-28 10:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:03:39 --> Input Class Initialized
INFO - 2020-07-28 10:03:39 --> Language Class Initialized
INFO - 2020-07-28 10:03:39 --> Loader Class Initialized
INFO - 2020-07-28 10:03:39 --> Helper loaded: url_helper
INFO - 2020-07-28 10:03:39 --> Database Driver Class Initialized
INFO - 2020-07-28 10:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:03:39 --> Email Class Initialized
INFO - 2020-07-28 10:03:39 --> Controller Class Initialized
INFO - 2020-07-28 10:03:39 --> Model Class Initialized
INFO - 2020-07-28 10:03:39 --> Model Class Initialized
DEBUG - 2020-07-28 10:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:03:39 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:03:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:09:00 --> Config Class Initialized
INFO - 2020-07-28 10:09:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:09:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:09:00 --> Utf8 Class Initialized
INFO - 2020-07-28 10:09:00 --> URI Class Initialized
INFO - 2020-07-28 10:09:00 --> Router Class Initialized
INFO - 2020-07-28 10:09:00 --> Output Class Initialized
INFO - 2020-07-28 10:09:00 --> Security Class Initialized
DEBUG - 2020-07-28 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:09:00 --> Input Class Initialized
INFO - 2020-07-28 10:09:00 --> Language Class Initialized
INFO - 2020-07-28 10:09:00 --> Loader Class Initialized
INFO - 2020-07-28 10:09:00 --> Helper loaded: url_helper
INFO - 2020-07-28 10:09:00 --> Database Driver Class Initialized
INFO - 2020-07-28 10:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:09:00 --> Email Class Initialized
INFO - 2020-07-28 10:09:00 --> Controller Class Initialized
INFO - 2020-07-28 10:09:00 --> Model Class Initialized
INFO - 2020-07-28 10:09:00 --> Model Class Initialized
DEBUG - 2020-07-28 10:09:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:09:00 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:09:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:09:02 --> Config Class Initialized
INFO - 2020-07-28 10:09:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:09:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:09:02 --> Utf8 Class Initialized
INFO - 2020-07-28 10:09:02 --> URI Class Initialized
DEBUG - 2020-07-28 10:09:02 --> No URI present. Default controller set.
INFO - 2020-07-28 10:09:02 --> Router Class Initialized
INFO - 2020-07-28 10:09:02 --> Output Class Initialized
INFO - 2020-07-28 10:09:02 --> Security Class Initialized
DEBUG - 2020-07-28 10:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:09:02 --> Input Class Initialized
INFO - 2020-07-28 10:09:02 --> Language Class Initialized
INFO - 2020-07-28 10:09:02 --> Loader Class Initialized
INFO - 2020-07-28 10:09:02 --> Helper loaded: url_helper
INFO - 2020-07-28 10:09:02 --> Database Driver Class Initialized
INFO - 2020-07-28 10:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:09:02 --> Email Class Initialized
INFO - 2020-07-28 10:09:02 --> Controller Class Initialized
INFO - 2020-07-28 10:09:02 --> Model Class Initialized
INFO - 2020-07-28 10:09:02 --> Model Class Initialized
DEBUG - 2020-07-28 10:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:09:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:09:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:09:02 --> Final output sent to browser
DEBUG - 2020-07-28 10:09:02 --> Total execution time: 0.0232
INFO - 2020-07-28 10:09:04 --> Config Class Initialized
INFO - 2020-07-28 10:09:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:09:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:09:04 --> Utf8 Class Initialized
INFO - 2020-07-28 10:09:04 --> URI Class Initialized
INFO - 2020-07-28 10:09:04 --> Router Class Initialized
INFO - 2020-07-28 10:09:04 --> Output Class Initialized
INFO - 2020-07-28 10:09:04 --> Security Class Initialized
DEBUG - 2020-07-28 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:09:04 --> Input Class Initialized
INFO - 2020-07-28 10:09:04 --> Language Class Initialized
INFO - 2020-07-28 10:09:04 --> Loader Class Initialized
INFO - 2020-07-28 10:09:04 --> Helper loaded: url_helper
INFO - 2020-07-28 10:09:04 --> Database Driver Class Initialized
INFO - 2020-07-28 10:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:09:04 --> Email Class Initialized
INFO - 2020-07-28 10:09:04 --> Controller Class Initialized
INFO - 2020-07-28 10:09:04 --> Model Class Initialized
INFO - 2020-07-28 10:09:04 --> Model Class Initialized
DEBUG - 2020-07-28 10:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:09:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:09:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:11:02 --> Config Class Initialized
INFO - 2020-07-28 10:11:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:02 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:02 --> URI Class Initialized
INFO - 2020-07-28 10:11:02 --> Router Class Initialized
INFO - 2020-07-28 10:11:02 --> Output Class Initialized
INFO - 2020-07-28 10:11:02 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:02 --> Input Class Initialized
INFO - 2020-07-28 10:11:02 --> Language Class Initialized
INFO - 2020-07-28 10:11:02 --> Loader Class Initialized
INFO - 2020-07-28 10:11:02 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:02 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:02 --> Email Class Initialized
INFO - 2020-07-28 10:11:02 --> Controller Class Initialized
INFO - 2020-07-28 10:11:02 --> Model Class Initialized
INFO - 2020-07-28 10:11:02 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:02 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:11:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:11:04 --> Config Class Initialized
INFO - 2020-07-28 10:11:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:04 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:04 --> URI Class Initialized
DEBUG - 2020-07-28 10:11:04 --> No URI present. Default controller set.
INFO - 2020-07-28 10:11:04 --> Router Class Initialized
INFO - 2020-07-28 10:11:04 --> Output Class Initialized
INFO - 2020-07-28 10:11:04 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:04 --> Input Class Initialized
INFO - 2020-07-28 10:11:04 --> Language Class Initialized
INFO - 2020-07-28 10:11:04 --> Loader Class Initialized
INFO - 2020-07-28 10:11:04 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:04 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:04 --> Email Class Initialized
INFO - 2020-07-28 10:11:04 --> Controller Class Initialized
INFO - 2020-07-28 10:11:04 --> Model Class Initialized
INFO - 2020-07-28 10:11:04 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:11:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:11:04 --> Final output sent to browser
DEBUG - 2020-07-28 10:11:04 --> Total execution time: 0.0214
INFO - 2020-07-28 10:11:06 --> Config Class Initialized
INFO - 2020-07-28 10:11:06 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:06 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:06 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:06 --> URI Class Initialized
INFO - 2020-07-28 10:11:06 --> Router Class Initialized
INFO - 2020-07-28 10:11:06 --> Output Class Initialized
INFO - 2020-07-28 10:11:06 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:06 --> Input Class Initialized
INFO - 2020-07-28 10:11:06 --> Language Class Initialized
INFO - 2020-07-28 10:11:06 --> Loader Class Initialized
INFO - 2020-07-28 10:11:06 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:06 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:06 --> Email Class Initialized
INFO - 2020-07-28 10:11:06 --> Controller Class Initialized
INFO - 2020-07-28 10:11:06 --> Model Class Initialized
INFO - 2020-07-28 10:11:06 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:06 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:11:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:11:26 --> Config Class Initialized
INFO - 2020-07-28 10:11:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:26 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:26 --> URI Class Initialized
INFO - 2020-07-28 10:11:26 --> Router Class Initialized
INFO - 2020-07-28 10:11:26 --> Output Class Initialized
INFO - 2020-07-28 10:11:26 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:26 --> Input Class Initialized
INFO - 2020-07-28 10:11:26 --> Language Class Initialized
INFO - 2020-07-28 10:11:26 --> Loader Class Initialized
INFO - 2020-07-28 10:11:26 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:26 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:26 --> Email Class Initialized
INFO - 2020-07-28 10:11:26 --> Controller Class Initialized
INFO - 2020-07-28 10:11:26 --> Model Class Initialized
INFO - 2020-07-28 10:11:26 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:26 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:11:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:11:28 --> Config Class Initialized
INFO - 2020-07-28 10:11:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:28 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:28 --> URI Class Initialized
DEBUG - 2020-07-28 10:11:28 --> No URI present. Default controller set.
INFO - 2020-07-28 10:11:28 --> Router Class Initialized
INFO - 2020-07-28 10:11:28 --> Output Class Initialized
INFO - 2020-07-28 10:11:28 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:28 --> Input Class Initialized
INFO - 2020-07-28 10:11:28 --> Language Class Initialized
INFO - 2020-07-28 10:11:28 --> Loader Class Initialized
INFO - 2020-07-28 10:11:28 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:28 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:28 --> Email Class Initialized
INFO - 2020-07-28 10:11:28 --> Controller Class Initialized
INFO - 2020-07-28 10:11:28 --> Model Class Initialized
INFO - 2020-07-28 10:11:28 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:11:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:11:28 --> Final output sent to browser
DEBUG - 2020-07-28 10:11:28 --> Total execution time: 0.0247
INFO - 2020-07-28 10:11:31 --> Config Class Initialized
INFO - 2020-07-28 10:11:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:31 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:31 --> URI Class Initialized
INFO - 2020-07-28 10:11:31 --> Router Class Initialized
INFO - 2020-07-28 10:11:31 --> Output Class Initialized
INFO - 2020-07-28 10:11:31 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:31 --> Input Class Initialized
INFO - 2020-07-28 10:11:31 --> Language Class Initialized
INFO - 2020-07-28 10:11:31 --> Loader Class Initialized
INFO - 2020-07-28 10:11:31 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:31 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:31 --> Email Class Initialized
INFO - 2020-07-28 10:11:31 --> Controller Class Initialized
INFO - 2020-07-28 10:11:31 --> Model Class Initialized
INFO - 2020-07-28 10:11:31 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:31 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:11:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:11:34 --> Config Class Initialized
INFO - 2020-07-28 10:11:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:34 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:34 --> URI Class Initialized
INFO - 2020-07-28 10:11:34 --> Router Class Initialized
INFO - 2020-07-28 10:11:34 --> Output Class Initialized
INFO - 2020-07-28 10:11:34 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:34 --> Input Class Initialized
INFO - 2020-07-28 10:11:34 --> Language Class Initialized
INFO - 2020-07-28 10:11:34 --> Loader Class Initialized
INFO - 2020-07-28 10:11:34 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:34 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:34 --> Email Class Initialized
INFO - 2020-07-28 10:11:34 --> Controller Class Initialized
INFO - 2020-07-28 10:11:34 --> Model Class Initialized
INFO - 2020-07-28 10:11:34 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:34 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:11:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:11:36 --> Config Class Initialized
INFO - 2020-07-28 10:11:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:36 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:36 --> URI Class Initialized
DEBUG - 2020-07-28 10:11:36 --> No URI present. Default controller set.
INFO - 2020-07-28 10:11:36 --> Router Class Initialized
INFO - 2020-07-28 10:11:36 --> Output Class Initialized
INFO - 2020-07-28 10:11:36 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:36 --> Input Class Initialized
INFO - 2020-07-28 10:11:36 --> Language Class Initialized
INFO - 2020-07-28 10:11:36 --> Loader Class Initialized
INFO - 2020-07-28 10:11:36 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:36 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:36 --> Email Class Initialized
INFO - 2020-07-28 10:11:36 --> Controller Class Initialized
INFO - 2020-07-28 10:11:36 --> Model Class Initialized
INFO - 2020-07-28 10:11:36 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:11:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:11:36 --> Final output sent to browser
DEBUG - 2020-07-28 10:11:36 --> Total execution time: 0.0225
INFO - 2020-07-28 10:11:44 --> Config Class Initialized
INFO - 2020-07-28 10:11:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:44 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:44 --> URI Class Initialized
DEBUG - 2020-07-28 10:11:44 --> No URI present. Default controller set.
INFO - 2020-07-28 10:11:44 --> Router Class Initialized
INFO - 2020-07-28 10:11:44 --> Output Class Initialized
INFO - 2020-07-28 10:11:44 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:44 --> Input Class Initialized
INFO - 2020-07-28 10:11:44 --> Language Class Initialized
INFO - 2020-07-28 10:11:44 --> Loader Class Initialized
INFO - 2020-07-28 10:11:44 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:44 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:44 --> Email Class Initialized
INFO - 2020-07-28 10:11:44 --> Controller Class Initialized
INFO - 2020-07-28 10:11:44 --> Model Class Initialized
INFO - 2020-07-28 10:11:44 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:11:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:11:44 --> Final output sent to browser
DEBUG - 2020-07-28 10:11:44 --> Total execution time: 0.0234
INFO - 2020-07-28 10:11:47 --> Config Class Initialized
INFO - 2020-07-28 10:11:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:11:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:11:47 --> Utf8 Class Initialized
INFO - 2020-07-28 10:11:47 --> URI Class Initialized
INFO - 2020-07-28 10:11:47 --> Router Class Initialized
INFO - 2020-07-28 10:11:47 --> Output Class Initialized
INFO - 2020-07-28 10:11:47 --> Security Class Initialized
DEBUG - 2020-07-28 10:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:11:47 --> Input Class Initialized
INFO - 2020-07-28 10:11:47 --> Language Class Initialized
INFO - 2020-07-28 10:11:47 --> Loader Class Initialized
INFO - 2020-07-28 10:11:47 --> Helper loaded: url_helper
INFO - 2020-07-28 10:11:47 --> Database Driver Class Initialized
INFO - 2020-07-28 10:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:11:47 --> Email Class Initialized
INFO - 2020-07-28 10:11:47 --> Controller Class Initialized
INFO - 2020-07-28 10:11:47 --> Model Class Initialized
INFO - 2020-07-28 10:11:47 --> Model Class Initialized
DEBUG - 2020-07-28 10:11:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:11:47 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:11:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:36) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:12:09 --> Config Class Initialized
INFO - 2020-07-28 10:12:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:12:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:12:09 --> Utf8 Class Initialized
INFO - 2020-07-28 10:12:09 --> URI Class Initialized
DEBUG - 2020-07-28 10:12:09 --> No URI present. Default controller set.
INFO - 2020-07-28 10:12:09 --> Router Class Initialized
INFO - 2020-07-28 10:12:09 --> Output Class Initialized
INFO - 2020-07-28 10:12:09 --> Security Class Initialized
DEBUG - 2020-07-28 10:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:12:09 --> Input Class Initialized
INFO - 2020-07-28 10:12:09 --> Language Class Initialized
INFO - 2020-07-28 10:12:09 --> Loader Class Initialized
INFO - 2020-07-28 10:12:09 --> Helper loaded: url_helper
INFO - 2020-07-28 10:12:09 --> Database Driver Class Initialized
INFO - 2020-07-28 10:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:12:09 --> Email Class Initialized
INFO - 2020-07-28 10:12:09 --> Controller Class Initialized
INFO - 2020-07-28 10:12:09 --> Model Class Initialized
INFO - 2020-07-28 10:12:09 --> Model Class Initialized
DEBUG - 2020-07-28 10:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:12:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:12:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:12:09 --> Final output sent to browser
DEBUG - 2020-07-28 10:12:09 --> Total execution time: 0.0235
INFO - 2020-07-28 10:12:12 --> Config Class Initialized
INFO - 2020-07-28 10:12:12 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:12:12 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:12:12 --> Utf8 Class Initialized
INFO - 2020-07-28 10:12:12 --> URI Class Initialized
INFO - 2020-07-28 10:12:12 --> Router Class Initialized
INFO - 2020-07-28 10:12:12 --> Output Class Initialized
INFO - 2020-07-28 10:12:12 --> Security Class Initialized
DEBUG - 2020-07-28 10:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:12:12 --> Input Class Initialized
INFO - 2020-07-28 10:12:12 --> Language Class Initialized
INFO - 2020-07-28 10:12:12 --> Loader Class Initialized
INFO - 2020-07-28 10:12:12 --> Helper loaded: url_helper
INFO - 2020-07-28 10:12:12 --> Database Driver Class Initialized
INFO - 2020-07-28 10:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:12:12 --> Email Class Initialized
INFO - 2020-07-28 10:12:12 --> Controller Class Initialized
INFO - 2020-07-28 10:12:12 --> Model Class Initialized
INFO - 2020-07-28 10:12:12 --> Model Class Initialized
DEBUG - 2020-07-28 10:12:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:12:12 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:12:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:12:21 --> Config Class Initialized
INFO - 2020-07-28 10:12:21 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:12:21 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:12:21 --> Utf8 Class Initialized
INFO - 2020-07-28 10:12:21 --> URI Class Initialized
INFO - 2020-07-28 10:12:21 --> Router Class Initialized
INFO - 2020-07-28 10:12:21 --> Output Class Initialized
INFO - 2020-07-28 10:12:21 --> Security Class Initialized
DEBUG - 2020-07-28 10:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:12:21 --> Input Class Initialized
INFO - 2020-07-28 10:12:21 --> Language Class Initialized
INFO - 2020-07-28 10:12:21 --> Loader Class Initialized
INFO - 2020-07-28 10:12:21 --> Helper loaded: url_helper
INFO - 2020-07-28 10:12:21 --> Database Driver Class Initialized
INFO - 2020-07-28 10:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:12:21 --> Email Class Initialized
INFO - 2020-07-28 10:12:21 --> Controller Class Initialized
INFO - 2020-07-28 10:12:21 --> Model Class Initialized
INFO - 2020-07-28 10:12:21 --> Model Class Initialized
DEBUG - 2020-07-28 10:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:12:21 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 10:12:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 10:12:23 --> Config Class Initialized
INFO - 2020-07-28 10:12:23 --> Hooks Class Initialized
DEBUG - 2020-07-28 10:12:23 --> UTF-8 Support Enabled
INFO - 2020-07-28 10:12:23 --> Utf8 Class Initialized
INFO - 2020-07-28 10:12:23 --> URI Class Initialized
DEBUG - 2020-07-28 10:12:23 --> No URI present. Default controller set.
INFO - 2020-07-28 10:12:23 --> Router Class Initialized
INFO - 2020-07-28 10:12:23 --> Output Class Initialized
INFO - 2020-07-28 10:12:23 --> Security Class Initialized
DEBUG - 2020-07-28 10:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 10:12:23 --> Input Class Initialized
INFO - 2020-07-28 10:12:23 --> Language Class Initialized
INFO - 2020-07-28 10:12:23 --> Loader Class Initialized
INFO - 2020-07-28 10:12:23 --> Helper loaded: url_helper
INFO - 2020-07-28 10:12:23 --> Database Driver Class Initialized
INFO - 2020-07-28 10:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 10:12:23 --> Email Class Initialized
INFO - 2020-07-28 10:12:23 --> Controller Class Initialized
INFO - 2020-07-28 10:12:23 --> Model Class Initialized
INFO - 2020-07-28 10:12:23 --> Model Class Initialized
DEBUG - 2020-07-28 10:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 10:12:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 10:12:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 10:12:23 --> Final output sent to browser
DEBUG - 2020-07-28 10:12:23 --> Total execution time: 0.0231
INFO - 2020-07-28 16:03:08 --> Config Class Initialized
INFO - 2020-07-28 16:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:03:08 --> Utf8 Class Initialized
INFO - 2020-07-28 16:03:08 --> URI Class Initialized
DEBUG - 2020-07-28 16:03:08 --> No URI present. Default controller set.
INFO - 2020-07-28 16:03:08 --> Router Class Initialized
INFO - 2020-07-28 16:03:08 --> Output Class Initialized
INFO - 2020-07-28 16:03:08 --> Security Class Initialized
DEBUG - 2020-07-28 16:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:03:08 --> Input Class Initialized
INFO - 2020-07-28 16:03:08 --> Language Class Initialized
INFO - 2020-07-28 16:03:08 --> Loader Class Initialized
INFO - 2020-07-28 16:03:08 --> Helper loaded: url_helper
INFO - 2020-07-28 16:03:08 --> Database Driver Class Initialized
INFO - 2020-07-28 16:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:03:08 --> Email Class Initialized
INFO - 2020-07-28 16:03:08 --> Controller Class Initialized
INFO - 2020-07-28 16:03:08 --> Model Class Initialized
INFO - 2020-07-28 16:03:08 --> Model Class Initialized
DEBUG - 2020-07-28 16:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:03:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:03:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:03:08 --> Final output sent to browser
DEBUG - 2020-07-28 16:03:08 --> Total execution time: 0.0195
INFO - 2020-07-28 16:03:11 --> Config Class Initialized
INFO - 2020-07-28 16:03:11 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:03:11 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:03:11 --> Utf8 Class Initialized
INFO - 2020-07-28 16:03:11 --> URI Class Initialized
INFO - 2020-07-28 16:03:11 --> Router Class Initialized
INFO - 2020-07-28 16:03:11 --> Output Class Initialized
INFO - 2020-07-28 16:03:11 --> Security Class Initialized
DEBUG - 2020-07-28 16:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:03:11 --> Input Class Initialized
INFO - 2020-07-28 16:03:11 --> Language Class Initialized
INFO - 2020-07-28 16:03:11 --> Loader Class Initialized
INFO - 2020-07-28 16:03:11 --> Helper loaded: url_helper
INFO - 2020-07-28 16:03:11 --> Database Driver Class Initialized
INFO - 2020-07-28 16:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:03:11 --> Email Class Initialized
INFO - 2020-07-28 16:03:11 --> Controller Class Initialized
INFO - 2020-07-28 16:03:11 --> Model Class Initialized
INFO - 2020-07-28 16:03:11 --> Model Class Initialized
DEBUG - 2020-07-28 16:03:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:03:11 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:03:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:07:43 --> Config Class Initialized
INFO - 2020-07-28 16:07:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:07:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:07:43 --> Utf8 Class Initialized
INFO - 2020-07-28 16:07:43 --> URI Class Initialized
DEBUG - 2020-07-28 16:07:43 --> No URI present. Default controller set.
INFO - 2020-07-28 16:07:43 --> Router Class Initialized
INFO - 2020-07-28 16:07:43 --> Output Class Initialized
INFO - 2020-07-28 16:07:43 --> Security Class Initialized
DEBUG - 2020-07-28 16:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:07:43 --> Input Class Initialized
INFO - 2020-07-28 16:07:43 --> Language Class Initialized
INFO - 2020-07-28 16:07:43 --> Loader Class Initialized
INFO - 2020-07-28 16:07:43 --> Helper loaded: url_helper
INFO - 2020-07-28 16:07:43 --> Database Driver Class Initialized
INFO - 2020-07-28 16:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:07:43 --> Email Class Initialized
INFO - 2020-07-28 16:07:43 --> Controller Class Initialized
INFO - 2020-07-28 16:07:43 --> Model Class Initialized
INFO - 2020-07-28 16:07:43 --> Model Class Initialized
DEBUG - 2020-07-28 16:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:07:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:07:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:07:43 --> Final output sent to browser
DEBUG - 2020-07-28 16:07:43 --> Total execution time: 0.0277
INFO - 2020-07-28 16:07:45 --> Config Class Initialized
INFO - 2020-07-28 16:07:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:07:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:07:45 --> Utf8 Class Initialized
INFO - 2020-07-28 16:07:45 --> URI Class Initialized
INFO - 2020-07-28 16:07:45 --> Router Class Initialized
INFO - 2020-07-28 16:07:45 --> Output Class Initialized
INFO - 2020-07-28 16:07:45 --> Security Class Initialized
DEBUG - 2020-07-28 16:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:07:45 --> Input Class Initialized
INFO - 2020-07-28 16:07:45 --> Language Class Initialized
INFO - 2020-07-28 16:07:45 --> Loader Class Initialized
INFO - 2020-07-28 16:07:45 --> Helper loaded: url_helper
INFO - 2020-07-28 16:07:45 --> Database Driver Class Initialized
INFO - 2020-07-28 16:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:07:45 --> Email Class Initialized
INFO - 2020-07-28 16:07:45 --> Controller Class Initialized
INFO - 2020-07-28 16:07:45 --> Model Class Initialized
INFO - 2020-07-28 16:07:45 --> Model Class Initialized
DEBUG - 2020-07-28 16:07:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:07:45 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:07:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:07:49 --> Config Class Initialized
INFO - 2020-07-28 16:07:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:07:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:07:49 --> Utf8 Class Initialized
INFO - 2020-07-28 16:07:49 --> URI Class Initialized
INFO - 2020-07-28 16:07:49 --> Router Class Initialized
INFO - 2020-07-28 16:07:49 --> Output Class Initialized
INFO - 2020-07-28 16:07:49 --> Security Class Initialized
DEBUG - 2020-07-28 16:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:07:49 --> Input Class Initialized
INFO - 2020-07-28 16:07:49 --> Language Class Initialized
INFO - 2020-07-28 16:07:49 --> Loader Class Initialized
INFO - 2020-07-28 16:07:49 --> Helper loaded: url_helper
INFO - 2020-07-28 16:07:49 --> Database Driver Class Initialized
INFO - 2020-07-28 16:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:07:49 --> Email Class Initialized
INFO - 2020-07-28 16:07:49 --> Controller Class Initialized
INFO - 2020-07-28 16:07:49 --> Model Class Initialized
INFO - 2020-07-28 16:07:49 --> Model Class Initialized
DEBUG - 2020-07-28 16:07:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:07:49 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:07:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:11:10 --> Config Class Initialized
INFO - 2020-07-28 16:11:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:11:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:11:10 --> Utf8 Class Initialized
INFO - 2020-07-28 16:11:10 --> URI Class Initialized
INFO - 2020-07-28 16:11:10 --> Router Class Initialized
INFO - 2020-07-28 16:11:10 --> Output Class Initialized
INFO - 2020-07-28 16:11:10 --> Security Class Initialized
DEBUG - 2020-07-28 16:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:11:10 --> Input Class Initialized
INFO - 2020-07-28 16:11:10 --> Language Class Initialized
INFO - 2020-07-28 16:11:10 --> Loader Class Initialized
INFO - 2020-07-28 16:11:10 --> Helper loaded: url_helper
INFO - 2020-07-28 16:11:10 --> Database Driver Class Initialized
INFO - 2020-07-28 16:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:11:10 --> Email Class Initialized
INFO - 2020-07-28 16:11:10 --> Controller Class Initialized
INFO - 2020-07-28 16:11:10 --> Model Class Initialized
INFO - 2020-07-28 16:11:10 --> Model Class Initialized
DEBUG - 2020-07-28 16:11:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:11:10 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:11:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:11:13 --> Config Class Initialized
INFO - 2020-07-28 16:11:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:11:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:11:13 --> Utf8 Class Initialized
INFO - 2020-07-28 16:11:13 --> URI Class Initialized
DEBUG - 2020-07-28 16:11:13 --> No URI present. Default controller set.
INFO - 2020-07-28 16:11:13 --> Router Class Initialized
INFO - 2020-07-28 16:11:13 --> Output Class Initialized
INFO - 2020-07-28 16:11:13 --> Security Class Initialized
DEBUG - 2020-07-28 16:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:11:13 --> Input Class Initialized
INFO - 2020-07-28 16:11:13 --> Language Class Initialized
INFO - 2020-07-28 16:11:13 --> Loader Class Initialized
INFO - 2020-07-28 16:11:13 --> Helper loaded: url_helper
INFO - 2020-07-28 16:11:13 --> Database Driver Class Initialized
INFO - 2020-07-28 16:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:11:13 --> Email Class Initialized
INFO - 2020-07-28 16:11:13 --> Controller Class Initialized
INFO - 2020-07-28 16:11:13 --> Model Class Initialized
INFO - 2020-07-28 16:11:13 --> Model Class Initialized
DEBUG - 2020-07-28 16:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:11:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:11:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:11:13 --> Final output sent to browser
DEBUG - 2020-07-28 16:11:13 --> Total execution time: 0.0211
INFO - 2020-07-28 16:11:15 --> Config Class Initialized
INFO - 2020-07-28 16:11:15 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:11:15 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:11:15 --> Utf8 Class Initialized
INFO - 2020-07-28 16:11:15 --> URI Class Initialized
INFO - 2020-07-28 16:11:15 --> Router Class Initialized
INFO - 2020-07-28 16:11:15 --> Output Class Initialized
INFO - 2020-07-28 16:11:15 --> Security Class Initialized
DEBUG - 2020-07-28 16:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:11:15 --> Input Class Initialized
INFO - 2020-07-28 16:11:15 --> Language Class Initialized
INFO - 2020-07-28 16:11:15 --> Loader Class Initialized
INFO - 2020-07-28 16:11:15 --> Helper loaded: url_helper
INFO - 2020-07-28 16:11:15 --> Database Driver Class Initialized
INFO - 2020-07-28 16:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:11:15 --> Email Class Initialized
INFO - 2020-07-28 16:11:15 --> Controller Class Initialized
INFO - 2020-07-28 16:11:15 --> Model Class Initialized
INFO - 2020-07-28 16:11:15 --> Model Class Initialized
DEBUG - 2020-07-28 16:11:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:11:15 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:11:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:12:39 --> Config Class Initialized
INFO - 2020-07-28 16:12:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:12:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:12:39 --> Utf8 Class Initialized
INFO - 2020-07-28 16:12:39 --> URI Class Initialized
INFO - 2020-07-28 16:12:39 --> Router Class Initialized
INFO - 2020-07-28 16:12:39 --> Output Class Initialized
INFO - 2020-07-28 16:12:39 --> Security Class Initialized
DEBUG - 2020-07-28 16:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:12:39 --> Input Class Initialized
INFO - 2020-07-28 16:12:39 --> Language Class Initialized
INFO - 2020-07-28 16:12:39 --> Loader Class Initialized
INFO - 2020-07-28 16:12:39 --> Helper loaded: url_helper
INFO - 2020-07-28 16:12:39 --> Database Driver Class Initialized
INFO - 2020-07-28 16:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:12:39 --> Email Class Initialized
INFO - 2020-07-28 16:12:39 --> Controller Class Initialized
INFO - 2020-07-28 16:12:39 --> Model Class Initialized
INFO - 2020-07-28 16:12:39 --> Model Class Initialized
DEBUG - 2020-07-28 16:12:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:12:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:12:40 --> Config Class Initialized
INFO - 2020-07-28 16:12:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:12:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:12:40 --> Utf8 Class Initialized
INFO - 2020-07-28 16:12:40 --> URI Class Initialized
DEBUG - 2020-07-28 16:12:40 --> No URI present. Default controller set.
INFO - 2020-07-28 16:12:40 --> Router Class Initialized
INFO - 2020-07-28 16:12:40 --> Output Class Initialized
INFO - 2020-07-28 16:12:40 --> Security Class Initialized
DEBUG - 2020-07-28 16:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:12:40 --> Input Class Initialized
INFO - 2020-07-28 16:12:40 --> Language Class Initialized
INFO - 2020-07-28 16:12:40 --> Loader Class Initialized
INFO - 2020-07-28 16:12:40 --> Helper loaded: url_helper
INFO - 2020-07-28 16:12:40 --> Database Driver Class Initialized
INFO - 2020-07-28 16:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:12:40 --> Email Class Initialized
INFO - 2020-07-28 16:12:40 --> Controller Class Initialized
INFO - 2020-07-28 16:12:40 --> Model Class Initialized
INFO - 2020-07-28 16:12:40 --> Model Class Initialized
DEBUG - 2020-07-28 16:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:12:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:12:40 --> Final output sent to browser
DEBUG - 2020-07-28 16:12:40 --> Total execution time: 0.0260
INFO - 2020-07-28 16:12:43 --> Config Class Initialized
INFO - 2020-07-28 16:12:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:12:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:12:43 --> Utf8 Class Initialized
INFO - 2020-07-28 16:12:43 --> URI Class Initialized
INFO - 2020-07-28 16:12:43 --> Router Class Initialized
INFO - 2020-07-28 16:12:43 --> Output Class Initialized
INFO - 2020-07-28 16:12:43 --> Security Class Initialized
DEBUG - 2020-07-28 16:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:12:43 --> Input Class Initialized
INFO - 2020-07-28 16:12:43 --> Language Class Initialized
INFO - 2020-07-28 16:12:43 --> Loader Class Initialized
INFO - 2020-07-28 16:12:43 --> Helper loaded: url_helper
INFO - 2020-07-28 16:12:43 --> Database Driver Class Initialized
INFO - 2020-07-28 16:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:12:43 --> Email Class Initialized
INFO - 2020-07-28 16:12:43 --> Controller Class Initialized
INFO - 2020-07-28 16:12:43 --> Model Class Initialized
INFO - 2020-07-28 16:12:43 --> Model Class Initialized
DEBUG - 2020-07-28 16:12:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:12:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:13:32 --> Config Class Initialized
INFO - 2020-07-28 16:13:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:13:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:13:32 --> Utf8 Class Initialized
INFO - 2020-07-28 16:13:32 --> URI Class Initialized
INFO - 2020-07-28 16:13:32 --> Router Class Initialized
INFO - 2020-07-28 16:13:32 --> Output Class Initialized
INFO - 2020-07-28 16:13:32 --> Security Class Initialized
DEBUG - 2020-07-28 16:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:13:32 --> Input Class Initialized
INFO - 2020-07-28 16:13:32 --> Language Class Initialized
INFO - 2020-07-28 16:13:32 --> Loader Class Initialized
INFO - 2020-07-28 16:13:32 --> Helper loaded: url_helper
INFO - 2020-07-28 16:13:32 --> Database Driver Class Initialized
INFO - 2020-07-28 16:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:13:32 --> Email Class Initialized
INFO - 2020-07-28 16:13:32 --> Controller Class Initialized
INFO - 2020-07-28 16:13:32 --> Model Class Initialized
INFO - 2020-07-28 16:13:32 --> Model Class Initialized
DEBUG - 2020-07-28 16:13:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:13:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:13:36 --> Config Class Initialized
INFO - 2020-07-28 16:13:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:13:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:13:36 --> Utf8 Class Initialized
INFO - 2020-07-28 16:13:36 --> URI Class Initialized
INFO - 2020-07-28 16:13:36 --> Router Class Initialized
INFO - 2020-07-28 16:13:36 --> Output Class Initialized
INFO - 2020-07-28 16:13:36 --> Security Class Initialized
DEBUG - 2020-07-28 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:13:36 --> Input Class Initialized
INFO - 2020-07-28 16:13:36 --> Language Class Initialized
INFO - 2020-07-28 16:13:36 --> Loader Class Initialized
INFO - 2020-07-28 16:13:36 --> Helper loaded: url_helper
INFO - 2020-07-28 16:13:36 --> Database Driver Class Initialized
INFO - 2020-07-28 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:13:36 --> Email Class Initialized
INFO - 2020-07-28 16:13:36 --> Controller Class Initialized
INFO - 2020-07-28 16:13:36 --> Model Class Initialized
INFO - 2020-07-28 16:13:36 --> Model Class Initialized
DEBUG - 2020-07-28 16:13:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:13:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:13:38 --> Config Class Initialized
INFO - 2020-07-28 16:13:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:13:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:13:38 --> Utf8 Class Initialized
INFO - 2020-07-28 16:13:38 --> URI Class Initialized
DEBUG - 2020-07-28 16:13:38 --> No URI present. Default controller set.
INFO - 2020-07-28 16:13:38 --> Router Class Initialized
INFO - 2020-07-28 16:13:38 --> Output Class Initialized
INFO - 2020-07-28 16:13:38 --> Security Class Initialized
DEBUG - 2020-07-28 16:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:13:38 --> Input Class Initialized
INFO - 2020-07-28 16:13:38 --> Language Class Initialized
INFO - 2020-07-28 16:13:38 --> Loader Class Initialized
INFO - 2020-07-28 16:13:38 --> Helper loaded: url_helper
INFO - 2020-07-28 16:13:38 --> Database Driver Class Initialized
INFO - 2020-07-28 16:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:13:38 --> Email Class Initialized
INFO - 2020-07-28 16:13:38 --> Controller Class Initialized
INFO - 2020-07-28 16:13:38 --> Model Class Initialized
INFO - 2020-07-28 16:13:38 --> Model Class Initialized
DEBUG - 2020-07-28 16:13:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:13:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:13:38 --> Final output sent to browser
DEBUG - 2020-07-28 16:13:38 --> Total execution time: 0.0201
INFO - 2020-07-28 16:13:41 --> Config Class Initialized
INFO - 2020-07-28 16:13:41 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:13:41 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:13:41 --> Utf8 Class Initialized
INFO - 2020-07-28 16:13:41 --> URI Class Initialized
INFO - 2020-07-28 16:13:41 --> Router Class Initialized
INFO - 2020-07-28 16:13:41 --> Output Class Initialized
INFO - 2020-07-28 16:13:41 --> Security Class Initialized
DEBUG - 2020-07-28 16:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:13:41 --> Input Class Initialized
INFO - 2020-07-28 16:13:41 --> Language Class Initialized
INFO - 2020-07-28 16:13:41 --> Loader Class Initialized
INFO - 2020-07-28 16:13:41 --> Helper loaded: url_helper
INFO - 2020-07-28 16:13:41 --> Database Driver Class Initialized
INFO - 2020-07-28 16:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:13:41 --> Email Class Initialized
INFO - 2020-07-28 16:13:41 --> Controller Class Initialized
INFO - 2020-07-28 16:13:41 --> Model Class Initialized
INFO - 2020-07-28 16:13:41 --> Model Class Initialized
DEBUG - 2020-07-28 16:13:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:13:44 --> Config Class Initialized
INFO - 2020-07-28 16:13:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:13:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:13:44 --> Utf8 Class Initialized
INFO - 2020-07-28 16:13:44 --> URI Class Initialized
DEBUG - 2020-07-28 16:13:44 --> No URI present. Default controller set.
INFO - 2020-07-28 16:13:44 --> Router Class Initialized
INFO - 2020-07-28 16:13:44 --> Output Class Initialized
INFO - 2020-07-28 16:13:44 --> Security Class Initialized
DEBUG - 2020-07-28 16:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:13:44 --> Input Class Initialized
INFO - 2020-07-28 16:13:44 --> Language Class Initialized
INFO - 2020-07-28 16:13:44 --> Loader Class Initialized
INFO - 2020-07-28 16:13:44 --> Helper loaded: url_helper
INFO - 2020-07-28 16:13:44 --> Database Driver Class Initialized
INFO - 2020-07-28 16:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:13:44 --> Email Class Initialized
INFO - 2020-07-28 16:13:44 --> Controller Class Initialized
INFO - 2020-07-28 16:13:44 --> Model Class Initialized
INFO - 2020-07-28 16:13:44 --> Model Class Initialized
DEBUG - 2020-07-28 16:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:13:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:13:44 --> Final output sent to browser
DEBUG - 2020-07-28 16:13:44 --> Total execution time: 0.0216
INFO - 2020-07-28 16:13:56 --> Config Class Initialized
INFO - 2020-07-28 16:13:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:13:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:13:56 --> Utf8 Class Initialized
INFO - 2020-07-28 16:13:56 --> URI Class Initialized
INFO - 2020-07-28 16:13:56 --> Router Class Initialized
INFO - 2020-07-28 16:13:56 --> Output Class Initialized
INFO - 2020-07-28 16:13:56 --> Security Class Initialized
DEBUG - 2020-07-28 16:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:13:56 --> Input Class Initialized
INFO - 2020-07-28 16:13:56 --> Language Class Initialized
INFO - 2020-07-28 16:13:56 --> Loader Class Initialized
INFO - 2020-07-28 16:13:56 --> Helper loaded: url_helper
INFO - 2020-07-28 16:13:56 --> Database Driver Class Initialized
INFO - 2020-07-28 16:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:13:56 --> Email Class Initialized
INFO - 2020-07-28 16:13:56 --> Controller Class Initialized
INFO - 2020-07-28 16:13:56 --> Model Class Initialized
INFO - 2020-07-28 16:13:56 --> Model Class Initialized
DEBUG - 2020-07-28 16:13:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:13:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:15:10 --> Config Class Initialized
INFO - 2020-07-28 16:15:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:10 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:10 --> URI Class Initialized
INFO - 2020-07-28 16:15:10 --> Router Class Initialized
INFO - 2020-07-28 16:15:10 --> Output Class Initialized
INFO - 2020-07-28 16:15:10 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:10 --> Input Class Initialized
INFO - 2020-07-28 16:15:10 --> Language Class Initialized
INFO - 2020-07-28 16:15:10 --> Loader Class Initialized
INFO - 2020-07-28 16:15:10 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:10 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:10 --> Email Class Initialized
INFO - 2020-07-28 16:15:10 --> Controller Class Initialized
INFO - 2020-07-28 16:15:10 --> Model Class Initialized
INFO - 2020-07-28 16:15:10 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:10 --> Config Class Initialized
INFO - 2020-07-28 16:15:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:10 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:10 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:10 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:10 --> Router Class Initialized
INFO - 2020-07-28 16:15:10 --> Output Class Initialized
INFO - 2020-07-28 16:15:10 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:10 --> Input Class Initialized
INFO - 2020-07-28 16:15:10 --> Language Class Initialized
INFO - 2020-07-28 16:15:10 --> Loader Class Initialized
INFO - 2020-07-28 16:15:10 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:10 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:10 --> Email Class Initialized
INFO - 2020-07-28 16:15:10 --> Controller Class Initialized
INFO - 2020-07-28 16:15:10 --> Model Class Initialized
INFO - 2020-07-28 16:15:10 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:10 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:10 --> Total execution time: 0.0222
INFO - 2020-07-28 16:15:13 --> Config Class Initialized
INFO - 2020-07-28 16:15:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:13 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:13 --> URI Class Initialized
INFO - 2020-07-28 16:15:13 --> Router Class Initialized
INFO - 2020-07-28 16:15:13 --> Output Class Initialized
INFO - 2020-07-28 16:15:13 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:13 --> Input Class Initialized
INFO - 2020-07-28 16:15:13 --> Language Class Initialized
INFO - 2020-07-28 16:15:13 --> Loader Class Initialized
INFO - 2020-07-28 16:15:13 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:13 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:13 --> Email Class Initialized
INFO - 2020-07-28 16:15:13 --> Controller Class Initialized
INFO - 2020-07-28 16:15:13 --> Model Class Initialized
INFO - 2020-07-28 16:15:13 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:13 --> Config Class Initialized
INFO - 2020-07-28 16:15:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:13 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:13 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:13 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:13 --> Router Class Initialized
INFO - 2020-07-28 16:15:13 --> Output Class Initialized
INFO - 2020-07-28 16:15:13 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:13 --> Input Class Initialized
INFO - 2020-07-28 16:15:13 --> Language Class Initialized
INFO - 2020-07-28 16:15:13 --> Loader Class Initialized
INFO - 2020-07-28 16:15:13 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:13 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:13 --> Email Class Initialized
INFO - 2020-07-28 16:15:13 --> Controller Class Initialized
INFO - 2020-07-28 16:15:13 --> Model Class Initialized
INFO - 2020-07-28 16:15:13 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:13 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:13 --> Total execution time: 0.0234
INFO - 2020-07-28 16:15:15 --> Config Class Initialized
INFO - 2020-07-28 16:15:15 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:15 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:15 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:15 --> URI Class Initialized
INFO - 2020-07-28 16:15:15 --> Router Class Initialized
INFO - 2020-07-28 16:15:15 --> Output Class Initialized
INFO - 2020-07-28 16:15:15 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:15 --> Input Class Initialized
INFO - 2020-07-28 16:15:15 --> Language Class Initialized
INFO - 2020-07-28 16:15:15 --> Loader Class Initialized
INFO - 2020-07-28 16:15:15 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:15 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:15 --> Email Class Initialized
INFO - 2020-07-28 16:15:15 --> Controller Class Initialized
INFO - 2020-07-28 16:15:15 --> Model Class Initialized
INFO - 2020-07-28 16:15:15 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:16 --> Config Class Initialized
INFO - 2020-07-28 16:15:16 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:16 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:16 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:16 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:16 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:16 --> Router Class Initialized
INFO - 2020-07-28 16:15:16 --> Output Class Initialized
INFO - 2020-07-28 16:15:16 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:16 --> Input Class Initialized
INFO - 2020-07-28 16:15:16 --> Language Class Initialized
INFO - 2020-07-28 16:15:16 --> Loader Class Initialized
INFO - 2020-07-28 16:15:16 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:16 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:16 --> Email Class Initialized
INFO - 2020-07-28 16:15:16 --> Controller Class Initialized
INFO - 2020-07-28 16:15:16 --> Model Class Initialized
INFO - 2020-07-28 16:15:16 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:16 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:16 --> Total execution time: 0.0221
INFO - 2020-07-28 16:15:18 --> Config Class Initialized
INFO - 2020-07-28 16:15:18 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:18 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:18 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:18 --> URI Class Initialized
INFO - 2020-07-28 16:15:18 --> Router Class Initialized
INFO - 2020-07-28 16:15:18 --> Output Class Initialized
INFO - 2020-07-28 16:15:18 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:18 --> Input Class Initialized
INFO - 2020-07-28 16:15:18 --> Language Class Initialized
INFO - 2020-07-28 16:15:18 --> Loader Class Initialized
INFO - 2020-07-28 16:15:18 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:18 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:18 --> Email Class Initialized
INFO - 2020-07-28 16:15:18 --> Controller Class Initialized
INFO - 2020-07-28 16:15:18 --> Model Class Initialized
INFO - 2020-07-28 16:15:18 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:18 --> Config Class Initialized
INFO - 2020-07-28 16:15:18 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:18 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:18 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:18 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:18 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:18 --> Router Class Initialized
INFO - 2020-07-28 16:15:18 --> Output Class Initialized
INFO - 2020-07-28 16:15:18 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:18 --> Input Class Initialized
INFO - 2020-07-28 16:15:18 --> Language Class Initialized
INFO - 2020-07-28 16:15:18 --> Loader Class Initialized
INFO - 2020-07-28 16:15:18 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:18 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:18 --> Email Class Initialized
INFO - 2020-07-28 16:15:18 --> Controller Class Initialized
INFO - 2020-07-28 16:15:18 --> Model Class Initialized
INFO - 2020-07-28 16:15:18 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:18 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:18 --> Total execution time: 0.0225
INFO - 2020-07-28 16:15:22 --> Config Class Initialized
INFO - 2020-07-28 16:15:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:22 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:22 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:22 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:22 --> Router Class Initialized
INFO - 2020-07-28 16:15:22 --> Output Class Initialized
INFO - 2020-07-28 16:15:22 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:22 --> Input Class Initialized
INFO - 2020-07-28 16:15:22 --> Language Class Initialized
INFO - 2020-07-28 16:15:22 --> Loader Class Initialized
INFO - 2020-07-28 16:15:22 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:22 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:22 --> Email Class Initialized
INFO - 2020-07-28 16:15:22 --> Controller Class Initialized
INFO - 2020-07-28 16:15:22 --> Model Class Initialized
INFO - 2020-07-28 16:15:22 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:22 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:22 --> Total execution time: 0.0276
INFO - 2020-07-28 16:15:29 --> Config Class Initialized
INFO - 2020-07-28 16:15:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:29 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:29 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:29 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:29 --> Router Class Initialized
INFO - 2020-07-28 16:15:29 --> Output Class Initialized
INFO - 2020-07-28 16:15:29 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:29 --> Input Class Initialized
INFO - 2020-07-28 16:15:29 --> Language Class Initialized
INFO - 2020-07-28 16:15:29 --> Loader Class Initialized
INFO - 2020-07-28 16:15:29 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:29 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:29 --> Email Class Initialized
INFO - 2020-07-28 16:15:29 --> Controller Class Initialized
INFO - 2020-07-28 16:15:29 --> Model Class Initialized
INFO - 2020-07-28 16:15:29 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:29 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:29 --> Total execution time: 0.0231
INFO - 2020-07-28 16:15:30 --> Config Class Initialized
INFO - 2020-07-28 16:15:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:30 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:30 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:30 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:30 --> Router Class Initialized
INFO - 2020-07-28 16:15:30 --> Output Class Initialized
INFO - 2020-07-28 16:15:30 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:30 --> Input Class Initialized
INFO - 2020-07-28 16:15:30 --> Language Class Initialized
INFO - 2020-07-28 16:15:30 --> Loader Class Initialized
INFO - 2020-07-28 16:15:30 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:30 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:30 --> Email Class Initialized
INFO - 2020-07-28 16:15:30 --> Controller Class Initialized
INFO - 2020-07-28 16:15:30 --> Model Class Initialized
INFO - 2020-07-28 16:15:30 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:30 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:30 --> Total execution time: 0.0210
INFO - 2020-07-28 16:15:32 --> Config Class Initialized
INFO - 2020-07-28 16:15:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:32 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:32 --> URI Class Initialized
INFO - 2020-07-28 16:15:32 --> Router Class Initialized
INFO - 2020-07-28 16:15:32 --> Output Class Initialized
INFO - 2020-07-28 16:15:32 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:32 --> Input Class Initialized
INFO - 2020-07-28 16:15:32 --> Language Class Initialized
INFO - 2020-07-28 16:15:32 --> Loader Class Initialized
INFO - 2020-07-28 16:15:32 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:32 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:32 --> Email Class Initialized
INFO - 2020-07-28 16:15:32 --> Controller Class Initialized
INFO - 2020-07-28 16:15:32 --> Model Class Initialized
INFO - 2020-07-28 16:15:32 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:32 --> Config Class Initialized
INFO - 2020-07-28 16:15:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:15:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:15:32 --> Utf8 Class Initialized
INFO - 2020-07-28 16:15:32 --> URI Class Initialized
DEBUG - 2020-07-28 16:15:32 --> No URI present. Default controller set.
INFO - 2020-07-28 16:15:32 --> Router Class Initialized
INFO - 2020-07-28 16:15:32 --> Output Class Initialized
INFO - 2020-07-28 16:15:32 --> Security Class Initialized
DEBUG - 2020-07-28 16:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:15:32 --> Input Class Initialized
INFO - 2020-07-28 16:15:32 --> Language Class Initialized
INFO - 2020-07-28 16:15:32 --> Loader Class Initialized
INFO - 2020-07-28 16:15:32 --> Helper loaded: url_helper
INFO - 2020-07-28 16:15:32 --> Database Driver Class Initialized
INFO - 2020-07-28 16:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:15:32 --> Email Class Initialized
INFO - 2020-07-28 16:15:32 --> Controller Class Initialized
INFO - 2020-07-28 16:15:32 --> Model Class Initialized
INFO - 2020-07-28 16:15:32 --> Model Class Initialized
DEBUG - 2020-07-28 16:15:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:15:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:15:32 --> Final output sent to browser
DEBUG - 2020-07-28 16:15:32 --> Total execution time: 0.0235
INFO - 2020-07-28 16:18:50 --> Config Class Initialized
INFO - 2020-07-28 16:18:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:18:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:18:50 --> Utf8 Class Initialized
INFO - 2020-07-28 16:18:50 --> URI Class Initialized
DEBUG - 2020-07-28 16:18:50 --> No URI present. Default controller set.
INFO - 2020-07-28 16:18:50 --> Router Class Initialized
INFO - 2020-07-28 16:18:50 --> Output Class Initialized
INFO - 2020-07-28 16:18:50 --> Security Class Initialized
DEBUG - 2020-07-28 16:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:18:50 --> Input Class Initialized
INFO - 2020-07-28 16:18:50 --> Language Class Initialized
INFO - 2020-07-28 16:18:50 --> Loader Class Initialized
INFO - 2020-07-28 16:18:50 --> Helper loaded: url_helper
INFO - 2020-07-28 16:18:50 --> Database Driver Class Initialized
INFO - 2020-07-28 16:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:18:50 --> Email Class Initialized
INFO - 2020-07-28 16:18:50 --> Controller Class Initialized
INFO - 2020-07-28 16:18:50 --> Model Class Initialized
INFO - 2020-07-28 16:18:50 --> Model Class Initialized
DEBUG - 2020-07-28 16:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:18:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:18:50 --> Final output sent to browser
DEBUG - 2020-07-28 16:18:50 --> Total execution time: 0.0217
INFO - 2020-07-28 16:18:52 --> Config Class Initialized
INFO - 2020-07-28 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:18:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:18:52 --> Utf8 Class Initialized
INFO - 2020-07-28 16:18:52 --> URI Class Initialized
INFO - 2020-07-28 16:18:52 --> Router Class Initialized
INFO - 2020-07-28 16:18:52 --> Output Class Initialized
INFO - 2020-07-28 16:18:52 --> Security Class Initialized
DEBUG - 2020-07-28 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:18:52 --> Input Class Initialized
INFO - 2020-07-28 16:18:52 --> Language Class Initialized
INFO - 2020-07-28 16:18:52 --> Loader Class Initialized
INFO - 2020-07-28 16:18:52 --> Helper loaded: url_helper
INFO - 2020-07-28 16:18:52 --> Database Driver Class Initialized
INFO - 2020-07-28 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:18:52 --> Email Class Initialized
INFO - 2020-07-28 16:18:52 --> Controller Class Initialized
INFO - 2020-07-28 16:18:52 --> Model Class Initialized
INFO - 2020-07-28 16:18:52 --> Model Class Initialized
DEBUG - 2020-07-28 16:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:18:52 --> Config Class Initialized
INFO - 2020-07-28 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:18:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:18:52 --> Utf8 Class Initialized
INFO - 2020-07-28 16:18:52 --> URI Class Initialized
DEBUG - 2020-07-28 16:18:52 --> No URI present. Default controller set.
INFO - 2020-07-28 16:18:52 --> Router Class Initialized
INFO - 2020-07-28 16:18:52 --> Output Class Initialized
INFO - 2020-07-28 16:18:52 --> Security Class Initialized
DEBUG - 2020-07-28 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:18:52 --> Input Class Initialized
INFO - 2020-07-28 16:18:52 --> Language Class Initialized
INFO - 2020-07-28 16:18:52 --> Loader Class Initialized
INFO - 2020-07-28 16:18:52 --> Helper loaded: url_helper
INFO - 2020-07-28 16:18:52 --> Database Driver Class Initialized
INFO - 2020-07-28 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:18:52 --> Email Class Initialized
INFO - 2020-07-28 16:18:52 --> Controller Class Initialized
INFO - 2020-07-28 16:18:52 --> Model Class Initialized
INFO - 2020-07-28 16:18:52 --> Model Class Initialized
DEBUG - 2020-07-28 16:18:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:18:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:18:52 --> Final output sent to browser
DEBUG - 2020-07-28 16:18:52 --> Total execution time: 0.0277
INFO - 2020-07-28 16:19:35 --> Config Class Initialized
INFO - 2020-07-28 16:19:35 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:35 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:35 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:35 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:35 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:35 --> Router Class Initialized
INFO - 2020-07-28 16:19:35 --> Output Class Initialized
INFO - 2020-07-28 16:19:35 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:35 --> Input Class Initialized
INFO - 2020-07-28 16:19:35 --> Language Class Initialized
INFO - 2020-07-28 16:19:35 --> Loader Class Initialized
INFO - 2020-07-28 16:19:35 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:35 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:35 --> Email Class Initialized
INFO - 2020-07-28 16:19:35 --> Controller Class Initialized
INFO - 2020-07-28 16:19:35 --> Model Class Initialized
INFO - 2020-07-28 16:19:35 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:35 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:35 --> Total execution time: 0.0260
INFO - 2020-07-28 16:19:37 --> Config Class Initialized
INFO - 2020-07-28 16:19:37 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:37 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:37 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:37 --> URI Class Initialized
INFO - 2020-07-28 16:19:37 --> Router Class Initialized
INFO - 2020-07-28 16:19:37 --> Output Class Initialized
INFO - 2020-07-28 16:19:37 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:37 --> Input Class Initialized
INFO - 2020-07-28 16:19:37 --> Language Class Initialized
INFO - 2020-07-28 16:19:37 --> Loader Class Initialized
INFO - 2020-07-28 16:19:37 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:37 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:37 --> Email Class Initialized
INFO - 2020-07-28 16:19:37 --> Controller Class Initialized
INFO - 2020-07-28 16:19:37 --> Model Class Initialized
INFO - 2020-07-28 16:19:37 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:37 --> Config Class Initialized
INFO - 2020-07-28 16:19:37 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:37 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:37 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:37 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:37 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:37 --> Router Class Initialized
INFO - 2020-07-28 16:19:37 --> Output Class Initialized
INFO - 2020-07-28 16:19:37 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:37 --> Input Class Initialized
INFO - 2020-07-28 16:19:37 --> Language Class Initialized
INFO - 2020-07-28 16:19:37 --> Loader Class Initialized
INFO - 2020-07-28 16:19:37 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:37 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:37 --> Email Class Initialized
INFO - 2020-07-28 16:19:37 --> Controller Class Initialized
INFO - 2020-07-28 16:19:37 --> Model Class Initialized
INFO - 2020-07-28 16:19:37 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:37 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:37 --> Total execution time: 0.0250
INFO - 2020-07-28 16:19:40 --> Config Class Initialized
INFO - 2020-07-28 16:19:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:40 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:40 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:40 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:40 --> Router Class Initialized
INFO - 2020-07-28 16:19:40 --> Output Class Initialized
INFO - 2020-07-28 16:19:40 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:40 --> Input Class Initialized
INFO - 2020-07-28 16:19:40 --> Language Class Initialized
INFO - 2020-07-28 16:19:40 --> Loader Class Initialized
INFO - 2020-07-28 16:19:40 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:40 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:40 --> Email Class Initialized
INFO - 2020-07-28 16:19:40 --> Controller Class Initialized
INFO - 2020-07-28 16:19:40 --> Model Class Initialized
INFO - 2020-07-28 16:19:40 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:40 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:40 --> Total execution time: 0.0218
INFO - 2020-07-28 16:19:44 --> Config Class Initialized
INFO - 2020-07-28 16:19:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:44 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:44 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:44 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:44 --> Router Class Initialized
INFO - 2020-07-28 16:19:44 --> Output Class Initialized
INFO - 2020-07-28 16:19:44 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:44 --> Input Class Initialized
INFO - 2020-07-28 16:19:44 --> Language Class Initialized
INFO - 2020-07-28 16:19:44 --> Loader Class Initialized
INFO - 2020-07-28 16:19:44 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:44 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:44 --> Email Class Initialized
INFO - 2020-07-28 16:19:44 --> Controller Class Initialized
INFO - 2020-07-28 16:19:44 --> Model Class Initialized
INFO - 2020-07-28 16:19:44 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:44 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:44 --> Total execution time: 0.0243
INFO - 2020-07-28 16:19:45 --> Config Class Initialized
INFO - 2020-07-28 16:19:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:45 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:45 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:45 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:45 --> Router Class Initialized
INFO - 2020-07-28 16:19:45 --> Output Class Initialized
INFO - 2020-07-28 16:19:45 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:45 --> Input Class Initialized
INFO - 2020-07-28 16:19:45 --> Language Class Initialized
INFO - 2020-07-28 16:19:45 --> Loader Class Initialized
INFO - 2020-07-28 16:19:45 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:45 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:45 --> Email Class Initialized
INFO - 2020-07-28 16:19:45 --> Controller Class Initialized
INFO - 2020-07-28 16:19:45 --> Model Class Initialized
INFO - 2020-07-28 16:19:45 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:45 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:45 --> Total execution time: 0.0253
INFO - 2020-07-28 16:19:47 --> Config Class Initialized
INFO - 2020-07-28 16:19:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:47 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:47 --> URI Class Initialized
INFO - 2020-07-28 16:19:47 --> Router Class Initialized
INFO - 2020-07-28 16:19:47 --> Output Class Initialized
INFO - 2020-07-28 16:19:47 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:47 --> Input Class Initialized
INFO - 2020-07-28 16:19:47 --> Language Class Initialized
INFO - 2020-07-28 16:19:47 --> Loader Class Initialized
INFO - 2020-07-28 16:19:47 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:47 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:47 --> Email Class Initialized
INFO - 2020-07-28 16:19:47 --> Controller Class Initialized
INFO - 2020-07-28 16:19:47 --> Model Class Initialized
INFO - 2020-07-28 16:19:47 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:47 --> Config Class Initialized
INFO - 2020-07-28 16:19:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:47 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:47 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:47 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:47 --> Router Class Initialized
INFO - 2020-07-28 16:19:47 --> Output Class Initialized
INFO - 2020-07-28 16:19:47 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:47 --> Input Class Initialized
INFO - 2020-07-28 16:19:47 --> Language Class Initialized
INFO - 2020-07-28 16:19:47 --> Loader Class Initialized
INFO - 2020-07-28 16:19:47 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:47 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:47 --> Email Class Initialized
INFO - 2020-07-28 16:19:47 --> Controller Class Initialized
INFO - 2020-07-28 16:19:47 --> Model Class Initialized
INFO - 2020-07-28 16:19:47 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:47 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:47 --> Total execution time: 0.0219
INFO - 2020-07-28 16:19:50 --> Config Class Initialized
INFO - 2020-07-28 16:19:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:50 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:50 --> URI Class Initialized
INFO - 2020-07-28 16:19:50 --> Router Class Initialized
INFO - 2020-07-28 16:19:50 --> Output Class Initialized
INFO - 2020-07-28 16:19:50 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:50 --> Input Class Initialized
INFO - 2020-07-28 16:19:50 --> Language Class Initialized
INFO - 2020-07-28 16:19:50 --> Loader Class Initialized
INFO - 2020-07-28 16:19:50 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:50 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:50 --> Email Class Initialized
INFO - 2020-07-28 16:19:50 --> Controller Class Initialized
INFO - 2020-07-28 16:19:50 --> Model Class Initialized
INFO - 2020-07-28 16:19:50 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:50 --> Config Class Initialized
INFO - 2020-07-28 16:19:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:19:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:19:50 --> Utf8 Class Initialized
INFO - 2020-07-28 16:19:50 --> URI Class Initialized
DEBUG - 2020-07-28 16:19:50 --> No URI present. Default controller set.
INFO - 2020-07-28 16:19:50 --> Router Class Initialized
INFO - 2020-07-28 16:19:50 --> Output Class Initialized
INFO - 2020-07-28 16:19:50 --> Security Class Initialized
DEBUG - 2020-07-28 16:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:19:50 --> Input Class Initialized
INFO - 2020-07-28 16:19:50 --> Language Class Initialized
INFO - 2020-07-28 16:19:50 --> Loader Class Initialized
INFO - 2020-07-28 16:19:50 --> Helper loaded: url_helper
INFO - 2020-07-28 16:19:50 --> Database Driver Class Initialized
INFO - 2020-07-28 16:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:19:50 --> Email Class Initialized
INFO - 2020-07-28 16:19:50 --> Controller Class Initialized
INFO - 2020-07-28 16:19:50 --> Model Class Initialized
INFO - 2020-07-28 16:19:50 --> Model Class Initialized
DEBUG - 2020-07-28 16:19:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:19:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:19:50 --> Final output sent to browser
DEBUG - 2020-07-28 16:19:50 --> Total execution time: 0.0221
INFO - 2020-07-28 16:20:06 --> Config Class Initialized
INFO - 2020-07-28 16:20:06 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:20:06 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:20:06 --> Utf8 Class Initialized
INFO - 2020-07-28 16:20:06 --> URI Class Initialized
DEBUG - 2020-07-28 16:20:06 --> No URI present. Default controller set.
INFO - 2020-07-28 16:20:06 --> Router Class Initialized
INFO - 2020-07-28 16:20:06 --> Output Class Initialized
INFO - 2020-07-28 16:20:06 --> Security Class Initialized
DEBUG - 2020-07-28 16:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:20:06 --> Input Class Initialized
INFO - 2020-07-28 16:20:06 --> Language Class Initialized
INFO - 2020-07-28 16:20:06 --> Loader Class Initialized
INFO - 2020-07-28 16:20:06 --> Helper loaded: url_helper
INFO - 2020-07-28 16:20:06 --> Database Driver Class Initialized
INFO - 2020-07-28 16:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:20:06 --> Email Class Initialized
INFO - 2020-07-28 16:20:06 --> Controller Class Initialized
INFO - 2020-07-28 16:20:06 --> Model Class Initialized
INFO - 2020-07-28 16:20:06 --> Model Class Initialized
DEBUG - 2020-07-28 16:20:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:20:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:20:06 --> Final output sent to browser
DEBUG - 2020-07-28 16:20:06 --> Total execution time: 0.0244
INFO - 2020-07-28 16:20:10 --> Config Class Initialized
INFO - 2020-07-28 16:20:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:20:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:20:10 --> Utf8 Class Initialized
INFO - 2020-07-28 16:20:10 --> URI Class Initialized
DEBUG - 2020-07-28 16:20:10 --> No URI present. Default controller set.
INFO - 2020-07-28 16:20:10 --> Router Class Initialized
INFO - 2020-07-28 16:20:10 --> Output Class Initialized
INFO - 2020-07-28 16:20:10 --> Security Class Initialized
DEBUG - 2020-07-28 16:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:20:10 --> Input Class Initialized
INFO - 2020-07-28 16:20:10 --> Language Class Initialized
INFO - 2020-07-28 16:20:10 --> Loader Class Initialized
INFO - 2020-07-28 16:20:10 --> Helper loaded: url_helper
INFO - 2020-07-28 16:20:10 --> Database Driver Class Initialized
INFO - 2020-07-28 16:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:20:10 --> Email Class Initialized
INFO - 2020-07-28 16:20:10 --> Controller Class Initialized
INFO - 2020-07-28 16:20:10 --> Model Class Initialized
INFO - 2020-07-28 16:20:10 --> Model Class Initialized
DEBUG - 2020-07-28 16:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:20:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:20:10 --> Final output sent to browser
DEBUG - 2020-07-28 16:20:10 --> Total execution time: 0.0242
INFO - 2020-07-28 16:20:12 --> Config Class Initialized
INFO - 2020-07-28 16:20:12 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:20:12 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:20:12 --> Utf8 Class Initialized
INFO - 2020-07-28 16:20:12 --> URI Class Initialized
INFO - 2020-07-28 16:20:12 --> Router Class Initialized
INFO - 2020-07-28 16:20:12 --> Output Class Initialized
INFO - 2020-07-28 16:20:12 --> Security Class Initialized
DEBUG - 2020-07-28 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:20:12 --> Input Class Initialized
INFO - 2020-07-28 16:20:12 --> Language Class Initialized
INFO - 2020-07-28 16:20:12 --> Loader Class Initialized
INFO - 2020-07-28 16:20:12 --> Helper loaded: url_helper
INFO - 2020-07-28 16:20:12 --> Database Driver Class Initialized
INFO - 2020-07-28 16:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:20:12 --> Email Class Initialized
INFO - 2020-07-28 16:20:12 --> Controller Class Initialized
INFO - 2020-07-28 16:20:12 --> Model Class Initialized
INFO - 2020-07-28 16:20:12 --> Model Class Initialized
DEBUG - 2020-07-28 16:20:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:20:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:53) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:22:55 --> Config Class Initialized
INFO - 2020-07-28 16:22:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:22:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:22:55 --> Utf8 Class Initialized
INFO - 2020-07-28 16:22:55 --> URI Class Initialized
INFO - 2020-07-28 16:22:55 --> Router Class Initialized
INFO - 2020-07-28 16:22:55 --> Output Class Initialized
INFO - 2020-07-28 16:22:55 --> Security Class Initialized
DEBUG - 2020-07-28 16:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:22:55 --> Input Class Initialized
INFO - 2020-07-28 16:22:55 --> Language Class Initialized
INFO - 2020-07-28 16:22:55 --> Loader Class Initialized
INFO - 2020-07-28 16:22:55 --> Helper loaded: url_helper
INFO - 2020-07-28 16:22:55 --> Database Driver Class Initialized
INFO - 2020-07-28 16:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:22:55 --> Email Class Initialized
INFO - 2020-07-28 16:22:55 --> Controller Class Initialized
INFO - 2020-07-28 16:22:55 --> Model Class Initialized
INFO - 2020-07-28 16:22:55 --> Model Class Initialized
DEBUG - 2020-07-28 16:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:22:55 --> Config Class Initialized
INFO - 2020-07-28 16:22:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:22:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:22:55 --> Utf8 Class Initialized
INFO - 2020-07-28 16:22:55 --> URI Class Initialized
DEBUG - 2020-07-28 16:22:55 --> No URI present. Default controller set.
INFO - 2020-07-28 16:22:55 --> Router Class Initialized
INFO - 2020-07-28 16:22:55 --> Output Class Initialized
INFO - 2020-07-28 16:22:55 --> Security Class Initialized
DEBUG - 2020-07-28 16:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:22:55 --> Input Class Initialized
INFO - 2020-07-28 16:22:55 --> Language Class Initialized
INFO - 2020-07-28 16:22:55 --> Loader Class Initialized
INFO - 2020-07-28 16:22:55 --> Helper loaded: url_helper
INFO - 2020-07-28 16:22:55 --> Database Driver Class Initialized
INFO - 2020-07-28 16:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:22:55 --> Email Class Initialized
INFO - 2020-07-28 16:22:55 --> Controller Class Initialized
INFO - 2020-07-28 16:22:55 --> Model Class Initialized
INFO - 2020-07-28 16:22:55 --> Model Class Initialized
DEBUG - 2020-07-28 16:22:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:22:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:22:55 --> Final output sent to browser
DEBUG - 2020-07-28 16:22:55 --> Total execution time: 0.0246
INFO - 2020-07-28 16:22:58 --> Config Class Initialized
INFO - 2020-07-28 16:22:58 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:22:58 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:22:58 --> Utf8 Class Initialized
INFO - 2020-07-28 16:22:58 --> URI Class Initialized
INFO - 2020-07-28 16:22:58 --> Router Class Initialized
INFO - 2020-07-28 16:22:58 --> Output Class Initialized
INFO - 2020-07-28 16:22:58 --> Security Class Initialized
DEBUG - 2020-07-28 16:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:22:58 --> Input Class Initialized
INFO - 2020-07-28 16:22:58 --> Language Class Initialized
INFO - 2020-07-28 16:22:58 --> Loader Class Initialized
INFO - 2020-07-28 16:22:58 --> Helper loaded: url_helper
INFO - 2020-07-28 16:22:58 --> Database Driver Class Initialized
INFO - 2020-07-28 16:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:22:58 --> Email Class Initialized
INFO - 2020-07-28 16:22:58 --> Controller Class Initialized
INFO - 2020-07-28 16:22:58 --> Model Class Initialized
INFO - 2020-07-28 16:22:58 --> Model Class Initialized
DEBUG - 2020-07-28 16:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:22:58 --> Config Class Initialized
INFO - 2020-07-28 16:22:58 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:22:58 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:22:58 --> Utf8 Class Initialized
INFO - 2020-07-28 16:22:58 --> URI Class Initialized
DEBUG - 2020-07-28 16:22:58 --> No URI present. Default controller set.
INFO - 2020-07-28 16:22:58 --> Router Class Initialized
INFO - 2020-07-28 16:22:58 --> Output Class Initialized
INFO - 2020-07-28 16:22:58 --> Security Class Initialized
DEBUG - 2020-07-28 16:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:22:58 --> Input Class Initialized
INFO - 2020-07-28 16:22:58 --> Language Class Initialized
INFO - 2020-07-28 16:22:58 --> Loader Class Initialized
INFO - 2020-07-28 16:22:58 --> Helper loaded: url_helper
INFO - 2020-07-28 16:22:58 --> Database Driver Class Initialized
INFO - 2020-07-28 16:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:22:58 --> Email Class Initialized
INFO - 2020-07-28 16:22:58 --> Controller Class Initialized
INFO - 2020-07-28 16:22:58 --> Model Class Initialized
INFO - 2020-07-28 16:22:58 --> Model Class Initialized
DEBUG - 2020-07-28 16:22:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:22:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:22:58 --> Final output sent to browser
DEBUG - 2020-07-28 16:22:58 --> Total execution time: 0.0204
INFO - 2020-07-28 16:23:00 --> Config Class Initialized
INFO - 2020-07-28 16:23:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:00 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:00 --> URI Class Initialized
INFO - 2020-07-28 16:23:00 --> Router Class Initialized
INFO - 2020-07-28 16:23:00 --> Output Class Initialized
INFO - 2020-07-28 16:23:00 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:00 --> Input Class Initialized
INFO - 2020-07-28 16:23:00 --> Language Class Initialized
INFO - 2020-07-28 16:23:00 --> Loader Class Initialized
INFO - 2020-07-28 16:23:00 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:00 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:00 --> Email Class Initialized
INFO - 2020-07-28 16:23:00 --> Controller Class Initialized
INFO - 2020-07-28 16:23:00 --> Model Class Initialized
INFO - 2020-07-28 16:23:00 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:00 --> Config Class Initialized
INFO - 2020-07-28 16:23:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:00 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:00 --> URI Class Initialized
DEBUG - 2020-07-28 16:23:00 --> No URI present. Default controller set.
INFO - 2020-07-28 16:23:00 --> Router Class Initialized
INFO - 2020-07-28 16:23:00 --> Output Class Initialized
INFO - 2020-07-28 16:23:00 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:00 --> Input Class Initialized
INFO - 2020-07-28 16:23:00 --> Language Class Initialized
INFO - 2020-07-28 16:23:00 --> Loader Class Initialized
INFO - 2020-07-28 16:23:00 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:00 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:01 --> Email Class Initialized
INFO - 2020-07-28 16:23:01 --> Controller Class Initialized
INFO - 2020-07-28 16:23:01 --> Model Class Initialized
INFO - 2020-07-28 16:23:01 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:23:01 --> Final output sent to browser
DEBUG - 2020-07-28 16:23:01 --> Total execution time: 0.0884
INFO - 2020-07-28 16:23:03 --> Config Class Initialized
INFO - 2020-07-28 16:23:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:03 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:03 --> URI Class Initialized
DEBUG - 2020-07-28 16:23:03 --> No URI present. Default controller set.
INFO - 2020-07-28 16:23:03 --> Router Class Initialized
INFO - 2020-07-28 16:23:03 --> Output Class Initialized
INFO - 2020-07-28 16:23:03 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:03 --> Input Class Initialized
INFO - 2020-07-28 16:23:03 --> Language Class Initialized
INFO - 2020-07-28 16:23:03 --> Loader Class Initialized
INFO - 2020-07-28 16:23:03 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:03 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:03 --> Email Class Initialized
INFO - 2020-07-28 16:23:03 --> Controller Class Initialized
INFO - 2020-07-28 16:23:03 --> Model Class Initialized
INFO - 2020-07-28 16:23:03 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:23:03 --> Final output sent to browser
DEBUG - 2020-07-28 16:23:03 --> Total execution time: 0.0223
INFO - 2020-07-28 16:23:10 --> Config Class Initialized
INFO - 2020-07-28 16:23:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:10 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:10 --> URI Class Initialized
DEBUG - 2020-07-28 16:23:10 --> No URI present. Default controller set.
INFO - 2020-07-28 16:23:10 --> Router Class Initialized
INFO - 2020-07-28 16:23:10 --> Output Class Initialized
INFO - 2020-07-28 16:23:10 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:10 --> Input Class Initialized
INFO - 2020-07-28 16:23:10 --> Language Class Initialized
INFO - 2020-07-28 16:23:10 --> Loader Class Initialized
INFO - 2020-07-28 16:23:10 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:10 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:10 --> Email Class Initialized
INFO - 2020-07-28 16:23:10 --> Controller Class Initialized
INFO - 2020-07-28 16:23:10 --> Model Class Initialized
INFO - 2020-07-28 16:23:10 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:23:10 --> Final output sent to browser
DEBUG - 2020-07-28 16:23:10 --> Total execution time: 0.0236
INFO - 2020-07-28 16:23:12 --> Config Class Initialized
INFO - 2020-07-28 16:23:12 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:12 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:12 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:12 --> URI Class Initialized
INFO - 2020-07-28 16:23:12 --> Router Class Initialized
INFO - 2020-07-28 16:23:12 --> Output Class Initialized
INFO - 2020-07-28 16:23:12 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:12 --> Input Class Initialized
INFO - 2020-07-28 16:23:12 --> Language Class Initialized
INFO - 2020-07-28 16:23:12 --> Loader Class Initialized
INFO - 2020-07-28 16:23:12 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:12 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:12 --> Email Class Initialized
INFO - 2020-07-28 16:23:12 --> Controller Class Initialized
INFO - 2020-07-28 16:23:12 --> Model Class Initialized
INFO - 2020-07-28 16:23:12 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:13 --> Config Class Initialized
INFO - 2020-07-28 16:23:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:13 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:13 --> URI Class Initialized
DEBUG - 2020-07-28 16:23:13 --> No URI present. Default controller set.
INFO - 2020-07-28 16:23:13 --> Router Class Initialized
INFO - 2020-07-28 16:23:13 --> Output Class Initialized
INFO - 2020-07-28 16:23:13 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:13 --> Input Class Initialized
INFO - 2020-07-28 16:23:13 --> Language Class Initialized
INFO - 2020-07-28 16:23:13 --> Loader Class Initialized
INFO - 2020-07-28 16:23:13 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:13 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:13 --> Email Class Initialized
INFO - 2020-07-28 16:23:13 --> Controller Class Initialized
INFO - 2020-07-28 16:23:13 --> Model Class Initialized
INFO - 2020-07-28 16:23:13 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:23:13 --> Final output sent to browser
DEBUG - 2020-07-28 16:23:13 --> Total execution time: 0.0229
INFO - 2020-07-28 16:23:47 --> Config Class Initialized
INFO - 2020-07-28 16:23:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:47 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:47 --> URI Class Initialized
DEBUG - 2020-07-28 16:23:47 --> No URI present. Default controller set.
INFO - 2020-07-28 16:23:47 --> Router Class Initialized
INFO - 2020-07-28 16:23:47 --> Output Class Initialized
INFO - 2020-07-28 16:23:47 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:47 --> Input Class Initialized
INFO - 2020-07-28 16:23:47 --> Language Class Initialized
INFO - 2020-07-28 16:23:47 --> Loader Class Initialized
INFO - 2020-07-28 16:23:47 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:47 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:47 --> Email Class Initialized
INFO - 2020-07-28 16:23:47 --> Controller Class Initialized
INFO - 2020-07-28 16:23:47 --> Model Class Initialized
INFO - 2020-07-28 16:23:47 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:23:47 --> Final output sent to browser
DEBUG - 2020-07-28 16:23:47 --> Total execution time: 0.0330
INFO - 2020-07-28 16:23:50 --> Config Class Initialized
INFO - 2020-07-28 16:23:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:50 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:50 --> URI Class Initialized
DEBUG - 2020-07-28 16:23:50 --> No URI present. Default controller set.
INFO - 2020-07-28 16:23:50 --> Router Class Initialized
INFO - 2020-07-28 16:23:50 --> Output Class Initialized
INFO - 2020-07-28 16:23:50 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:50 --> Input Class Initialized
INFO - 2020-07-28 16:23:50 --> Language Class Initialized
INFO - 2020-07-28 16:23:50 --> Loader Class Initialized
INFO - 2020-07-28 16:23:50 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:50 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:50 --> Email Class Initialized
INFO - 2020-07-28 16:23:50 --> Controller Class Initialized
INFO - 2020-07-28 16:23:50 --> Model Class Initialized
INFO - 2020-07-28 16:23:50 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:23:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:23:50 --> Final output sent to browser
DEBUG - 2020-07-28 16:23:50 --> Total execution time: 0.0218
INFO - 2020-07-28 16:23:52 --> Config Class Initialized
INFO - 2020-07-28 16:23:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:23:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:23:52 --> Utf8 Class Initialized
INFO - 2020-07-28 16:23:52 --> URI Class Initialized
INFO - 2020-07-28 16:23:52 --> Router Class Initialized
INFO - 2020-07-28 16:23:52 --> Output Class Initialized
INFO - 2020-07-28 16:23:52 --> Security Class Initialized
DEBUG - 2020-07-28 16:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:23:52 --> Input Class Initialized
INFO - 2020-07-28 16:23:52 --> Language Class Initialized
INFO - 2020-07-28 16:23:52 --> Loader Class Initialized
INFO - 2020-07-28 16:23:52 --> Helper loaded: url_helper
INFO - 2020-07-28 16:23:52 --> Database Driver Class Initialized
INFO - 2020-07-28 16:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:23:52 --> Email Class Initialized
INFO - 2020-07-28 16:23:52 --> Controller Class Initialized
INFO - 2020-07-28 16:23:52 --> Model Class Initialized
INFO - 2020-07-28 16:23:52 --> Model Class Initialized
DEBUG - 2020-07-28 16:23:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:23:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:27:44 --> Config Class Initialized
INFO - 2020-07-28 16:27:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:27:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:27:44 --> Utf8 Class Initialized
INFO - 2020-07-28 16:27:44 --> URI Class Initialized
INFO - 2020-07-28 16:27:44 --> Router Class Initialized
INFO - 2020-07-28 16:27:44 --> Output Class Initialized
INFO - 2020-07-28 16:27:44 --> Security Class Initialized
DEBUG - 2020-07-28 16:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:27:44 --> Input Class Initialized
INFO - 2020-07-28 16:27:44 --> Language Class Initialized
INFO - 2020-07-28 16:27:44 --> Loader Class Initialized
INFO - 2020-07-28 16:27:44 --> Helper loaded: url_helper
INFO - 2020-07-28 16:27:44 --> Database Driver Class Initialized
INFO - 2020-07-28 16:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:27:44 --> Email Class Initialized
INFO - 2020-07-28 16:27:44 --> Controller Class Initialized
INFO - 2020-07-28 16:27:44 --> Model Class Initialized
INFO - 2020-07-28 16:27:44 --> Model Class Initialized
DEBUG - 2020-07-28 16:27:44 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:27:46 --> Config Class Initialized
INFO - 2020-07-28 16:27:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:27:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:27:46 --> Utf8 Class Initialized
INFO - 2020-07-28 16:27:46 --> URI Class Initialized
DEBUG - 2020-07-28 16:27:46 --> No URI present. Default controller set.
INFO - 2020-07-28 16:27:46 --> Router Class Initialized
INFO - 2020-07-28 16:27:46 --> Output Class Initialized
INFO - 2020-07-28 16:27:46 --> Security Class Initialized
DEBUG - 2020-07-28 16:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:27:46 --> Input Class Initialized
INFO - 2020-07-28 16:27:46 --> Language Class Initialized
INFO - 2020-07-28 16:27:46 --> Loader Class Initialized
INFO - 2020-07-28 16:27:46 --> Helper loaded: url_helper
INFO - 2020-07-28 16:27:46 --> Database Driver Class Initialized
INFO - 2020-07-28 16:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:27:46 --> Email Class Initialized
INFO - 2020-07-28 16:27:46 --> Controller Class Initialized
INFO - 2020-07-28 16:27:46 --> Model Class Initialized
INFO - 2020-07-28 16:27:46 --> Model Class Initialized
DEBUG - 2020-07-28 16:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:27:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:27:46 --> Final output sent to browser
DEBUG - 2020-07-28 16:27:46 --> Total execution time: 0.0226
INFO - 2020-07-28 16:27:48 --> Config Class Initialized
INFO - 2020-07-28 16:27:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:27:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:27:48 --> Utf8 Class Initialized
INFO - 2020-07-28 16:27:48 --> URI Class Initialized
INFO - 2020-07-28 16:27:48 --> Router Class Initialized
INFO - 2020-07-28 16:27:48 --> Output Class Initialized
INFO - 2020-07-28 16:27:48 --> Security Class Initialized
DEBUG - 2020-07-28 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:27:48 --> Input Class Initialized
INFO - 2020-07-28 16:27:48 --> Language Class Initialized
INFO - 2020-07-28 16:27:48 --> Loader Class Initialized
INFO - 2020-07-28 16:27:48 --> Helper loaded: url_helper
INFO - 2020-07-28 16:27:48 --> Database Driver Class Initialized
INFO - 2020-07-28 16:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:27:48 --> Email Class Initialized
INFO - 2020-07-28 16:27:48 --> Controller Class Initialized
INFO - 2020-07-28 16:27:48 --> Model Class Initialized
INFO - 2020-07-28 16:27:48 --> Model Class Initialized
DEBUG - 2020-07-28 16:27:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:29:36 --> Config Class Initialized
INFO - 2020-07-28 16:29:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:29:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:29:36 --> Utf8 Class Initialized
INFO - 2020-07-28 16:29:36 --> URI Class Initialized
DEBUG - 2020-07-28 16:29:36 --> No URI present. Default controller set.
INFO - 2020-07-28 16:29:36 --> Router Class Initialized
INFO - 2020-07-28 16:29:36 --> Output Class Initialized
INFO - 2020-07-28 16:29:36 --> Security Class Initialized
DEBUG - 2020-07-28 16:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:29:36 --> Input Class Initialized
INFO - 2020-07-28 16:29:36 --> Language Class Initialized
INFO - 2020-07-28 16:29:36 --> Loader Class Initialized
INFO - 2020-07-28 16:29:36 --> Helper loaded: url_helper
INFO - 2020-07-28 16:29:36 --> Database Driver Class Initialized
INFO - 2020-07-28 16:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:29:36 --> Email Class Initialized
INFO - 2020-07-28 16:29:36 --> Controller Class Initialized
INFO - 2020-07-28 16:29:36 --> Model Class Initialized
INFO - 2020-07-28 16:29:36 --> Model Class Initialized
DEBUG - 2020-07-28 16:29:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:29:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:29:36 --> Final output sent to browser
DEBUG - 2020-07-28 16:29:36 --> Total execution time: 0.0283
INFO - 2020-07-28 16:30:17 --> Config Class Initialized
INFO - 2020-07-28 16:30:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:30:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:30:17 --> Utf8 Class Initialized
INFO - 2020-07-28 16:30:17 --> URI Class Initialized
INFO - 2020-07-28 16:30:17 --> Router Class Initialized
INFO - 2020-07-28 16:30:17 --> Output Class Initialized
INFO - 2020-07-28 16:30:17 --> Security Class Initialized
DEBUG - 2020-07-28 16:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:30:17 --> Input Class Initialized
INFO - 2020-07-28 16:30:17 --> Language Class Initialized
INFO - 2020-07-28 16:30:17 --> Loader Class Initialized
INFO - 2020-07-28 16:30:17 --> Helper loaded: url_helper
INFO - 2020-07-28 16:30:17 --> Database Driver Class Initialized
INFO - 2020-07-28 16:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:30:17 --> Email Class Initialized
INFO - 2020-07-28 16:30:17 --> Controller Class Initialized
INFO - 2020-07-28 16:30:17 --> Model Class Initialized
INFO - 2020-07-28 16:30:17 --> Model Class Initialized
DEBUG - 2020-07-28 16:30:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:30:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:30:22 --> Config Class Initialized
INFO - 2020-07-28 16:30:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:30:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:30:22 --> Utf8 Class Initialized
INFO - 2020-07-28 16:30:22 --> URI Class Initialized
DEBUG - 2020-07-28 16:30:22 --> No URI present. Default controller set.
INFO - 2020-07-28 16:30:22 --> Router Class Initialized
INFO - 2020-07-28 16:30:22 --> Output Class Initialized
INFO - 2020-07-28 16:30:22 --> Security Class Initialized
DEBUG - 2020-07-28 16:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:30:22 --> Input Class Initialized
INFO - 2020-07-28 16:30:22 --> Language Class Initialized
INFO - 2020-07-28 16:30:22 --> Loader Class Initialized
INFO - 2020-07-28 16:30:22 --> Helper loaded: url_helper
INFO - 2020-07-28 16:30:22 --> Database Driver Class Initialized
INFO - 2020-07-28 16:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:30:22 --> Email Class Initialized
INFO - 2020-07-28 16:30:22 --> Controller Class Initialized
INFO - 2020-07-28 16:30:22 --> Model Class Initialized
INFO - 2020-07-28 16:30:22 --> Model Class Initialized
DEBUG - 2020-07-28 16:30:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:30:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:30:22 --> Final output sent to browser
DEBUG - 2020-07-28 16:30:22 --> Total execution time: 0.0241
INFO - 2020-07-28 16:32:01 --> Config Class Initialized
INFO - 2020-07-28 16:32:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:32:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:32:01 --> Utf8 Class Initialized
INFO - 2020-07-28 16:32:01 --> URI Class Initialized
DEBUG - 2020-07-28 16:32:01 --> No URI present. Default controller set.
INFO - 2020-07-28 16:32:01 --> Router Class Initialized
INFO - 2020-07-28 16:32:01 --> Output Class Initialized
INFO - 2020-07-28 16:32:01 --> Security Class Initialized
DEBUG - 2020-07-28 16:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:32:01 --> Input Class Initialized
INFO - 2020-07-28 16:32:01 --> Language Class Initialized
INFO - 2020-07-28 16:32:01 --> Loader Class Initialized
INFO - 2020-07-28 16:32:01 --> Helper loaded: url_helper
INFO - 2020-07-28 16:32:01 --> Database Driver Class Initialized
INFO - 2020-07-28 16:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:32:01 --> Email Class Initialized
INFO - 2020-07-28 16:32:01 --> Controller Class Initialized
INFO - 2020-07-28 16:32:01 --> Model Class Initialized
INFO - 2020-07-28 16:32:01 --> Model Class Initialized
DEBUG - 2020-07-28 16:32:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:32:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:32:01 --> Final output sent to browser
DEBUG - 2020-07-28 16:32:01 --> Total execution time: 0.0229
INFO - 2020-07-28 16:32:20 --> Config Class Initialized
INFO - 2020-07-28 16:32:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:32:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:32:20 --> Utf8 Class Initialized
INFO - 2020-07-28 16:32:20 --> URI Class Initialized
DEBUG - 2020-07-28 16:32:20 --> No URI present. Default controller set.
INFO - 2020-07-28 16:32:20 --> Router Class Initialized
INFO - 2020-07-28 16:32:20 --> Output Class Initialized
INFO - 2020-07-28 16:32:20 --> Security Class Initialized
DEBUG - 2020-07-28 16:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:32:20 --> Input Class Initialized
INFO - 2020-07-28 16:32:20 --> Language Class Initialized
INFO - 2020-07-28 16:32:20 --> Loader Class Initialized
INFO - 2020-07-28 16:32:20 --> Helper loaded: url_helper
INFO - 2020-07-28 16:32:20 --> Database Driver Class Initialized
INFO - 2020-07-28 16:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:32:20 --> Email Class Initialized
INFO - 2020-07-28 16:32:20 --> Controller Class Initialized
INFO - 2020-07-28 16:32:20 --> Model Class Initialized
INFO - 2020-07-28 16:32:20 --> Model Class Initialized
DEBUG - 2020-07-28 16:32:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:32:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:32:20 --> Final output sent to browser
DEBUG - 2020-07-28 16:32:20 --> Total execution time: 0.0236
INFO - 2020-07-28 16:32:22 --> Config Class Initialized
INFO - 2020-07-28 16:32:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:32:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:32:22 --> Utf8 Class Initialized
INFO - 2020-07-28 16:32:22 --> URI Class Initialized
INFO - 2020-07-28 16:32:22 --> Router Class Initialized
INFO - 2020-07-28 16:32:22 --> Output Class Initialized
INFO - 2020-07-28 16:32:22 --> Security Class Initialized
DEBUG - 2020-07-28 16:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:32:22 --> Input Class Initialized
INFO - 2020-07-28 16:32:22 --> Language Class Initialized
INFO - 2020-07-28 16:32:22 --> Loader Class Initialized
INFO - 2020-07-28 16:32:22 --> Helper loaded: url_helper
INFO - 2020-07-28 16:32:22 --> Database Driver Class Initialized
INFO - 2020-07-28 16:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:32:22 --> Email Class Initialized
INFO - 2020-07-28 16:32:22 --> Controller Class Initialized
INFO - 2020-07-28 16:32:22 --> Model Class Initialized
INFO - 2020-07-28 16:32:22 --> Model Class Initialized
DEBUG - 2020-07-28 16:32:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:32:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:32:38 --> Config Class Initialized
INFO - 2020-07-28 16:32:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:32:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:32:38 --> Utf8 Class Initialized
INFO - 2020-07-28 16:32:38 --> URI Class Initialized
INFO - 2020-07-28 16:32:38 --> Router Class Initialized
INFO - 2020-07-28 16:32:38 --> Output Class Initialized
INFO - 2020-07-28 16:32:38 --> Security Class Initialized
DEBUG - 2020-07-28 16:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:32:38 --> Input Class Initialized
INFO - 2020-07-28 16:32:38 --> Language Class Initialized
INFO - 2020-07-28 16:32:38 --> Loader Class Initialized
INFO - 2020-07-28 16:32:38 --> Helper loaded: url_helper
INFO - 2020-07-28 16:32:38 --> Database Driver Class Initialized
INFO - 2020-07-28 16:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:32:38 --> Email Class Initialized
INFO - 2020-07-28 16:32:38 --> Controller Class Initialized
INFO - 2020-07-28 16:32:38 --> Model Class Initialized
INFO - 2020-07-28 16:32:38 --> Model Class Initialized
DEBUG - 2020-07-28 16:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:32:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:32:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 16:32:38 --> Final output sent to browser
DEBUG - 2020-07-28 16:32:38 --> Total execution time: 0.0223
INFO - 2020-07-28 16:33:40 --> Config Class Initialized
INFO - 2020-07-28 16:33:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:33:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:33:40 --> Utf8 Class Initialized
INFO - 2020-07-28 16:33:40 --> URI Class Initialized
INFO - 2020-07-28 16:33:40 --> Router Class Initialized
INFO - 2020-07-28 16:33:40 --> Output Class Initialized
INFO - 2020-07-28 16:33:40 --> Security Class Initialized
DEBUG - 2020-07-28 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:33:40 --> Input Class Initialized
INFO - 2020-07-28 16:33:40 --> Language Class Initialized
INFO - 2020-07-28 16:33:40 --> Loader Class Initialized
INFO - 2020-07-28 16:33:40 --> Helper loaded: url_helper
INFO - 2020-07-28 16:33:40 --> Database Driver Class Initialized
INFO - 2020-07-28 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:33:40 --> Email Class Initialized
INFO - 2020-07-28 16:33:40 --> Controller Class Initialized
INFO - 2020-07-28 16:33:40 --> Model Class Initialized
INFO - 2020-07-28 16:33:40 --> Model Class Initialized
DEBUG - 2020-07-28 16:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:33:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:33:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 16:33:40 --> Final output sent to browser
DEBUG - 2020-07-28 16:33:40 --> Total execution time: 0.0261
INFO - 2020-07-28 16:33:41 --> Config Class Initialized
INFO - 2020-07-28 16:33:41 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:33:41 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:33:41 --> Utf8 Class Initialized
INFO - 2020-07-28 16:33:41 --> URI Class Initialized
DEBUG - 2020-07-28 16:33:41 --> No URI present. Default controller set.
INFO - 2020-07-28 16:33:41 --> Router Class Initialized
INFO - 2020-07-28 16:33:41 --> Output Class Initialized
INFO - 2020-07-28 16:33:41 --> Security Class Initialized
DEBUG - 2020-07-28 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:33:41 --> Input Class Initialized
INFO - 2020-07-28 16:33:41 --> Language Class Initialized
INFO - 2020-07-28 16:33:41 --> Loader Class Initialized
INFO - 2020-07-28 16:33:41 --> Helper loaded: url_helper
INFO - 2020-07-28 16:33:41 --> Database Driver Class Initialized
INFO - 2020-07-28 16:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:33:41 --> Email Class Initialized
INFO - 2020-07-28 16:33:41 --> Controller Class Initialized
INFO - 2020-07-28 16:33:41 --> Model Class Initialized
INFO - 2020-07-28 16:33:41 --> Model Class Initialized
DEBUG - 2020-07-28 16:33:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:33:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:33:41 --> Final output sent to browser
DEBUG - 2020-07-28 16:33:41 --> Total execution time: 0.0221
INFO - 2020-07-28 16:33:44 --> Config Class Initialized
INFO - 2020-07-28 16:33:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:33:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:33:44 --> Utf8 Class Initialized
INFO - 2020-07-28 16:33:44 --> URI Class Initialized
INFO - 2020-07-28 16:33:44 --> Router Class Initialized
INFO - 2020-07-28 16:33:44 --> Output Class Initialized
INFO - 2020-07-28 16:33:44 --> Security Class Initialized
DEBUG - 2020-07-28 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:33:44 --> Input Class Initialized
INFO - 2020-07-28 16:33:44 --> Language Class Initialized
INFO - 2020-07-28 16:33:44 --> Loader Class Initialized
INFO - 2020-07-28 16:33:44 --> Helper loaded: url_helper
INFO - 2020-07-28 16:33:44 --> Database Driver Class Initialized
INFO - 2020-07-28 16:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:33:44 --> Email Class Initialized
INFO - 2020-07-28 16:33:44 --> Controller Class Initialized
INFO - 2020-07-28 16:33:44 --> Model Class Initialized
INFO - 2020-07-28 16:33:44 --> Model Class Initialized
DEBUG - 2020-07-28 16:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:33:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:33:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 16:33:44 --> Final output sent to browser
DEBUG - 2020-07-28 16:33:44 --> Total execution time: 0.0212
INFO - 2020-07-28 16:34:00 --> Config Class Initialized
INFO - 2020-07-28 16:34:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:34:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:34:00 --> Utf8 Class Initialized
INFO - 2020-07-28 16:34:00 --> URI Class Initialized
INFO - 2020-07-28 16:34:00 --> Router Class Initialized
INFO - 2020-07-28 16:34:00 --> Output Class Initialized
INFO - 2020-07-28 16:34:00 --> Security Class Initialized
DEBUG - 2020-07-28 16:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:34:00 --> Input Class Initialized
INFO - 2020-07-28 16:34:00 --> Language Class Initialized
INFO - 2020-07-28 16:34:00 --> Loader Class Initialized
INFO - 2020-07-28 16:34:00 --> Helper loaded: url_helper
INFO - 2020-07-28 16:34:00 --> Database Driver Class Initialized
INFO - 2020-07-28 16:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:34:00 --> Email Class Initialized
INFO - 2020-07-28 16:34:00 --> Controller Class Initialized
INFO - 2020-07-28 16:34:00 --> Model Class Initialized
INFO - 2020-07-28 16:34:00 --> Model Class Initialized
DEBUG - 2020-07-28 16:34:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:34:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:34:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 16:34:00 --> Final output sent to browser
DEBUG - 2020-07-28 16:34:00 --> Total execution time: 0.0260
INFO - 2020-07-28 16:34:09 --> Config Class Initialized
INFO - 2020-07-28 16:34:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:34:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:34:09 --> Utf8 Class Initialized
INFO - 2020-07-28 16:34:09 --> URI Class Initialized
INFO - 2020-07-28 16:34:09 --> Router Class Initialized
INFO - 2020-07-28 16:34:09 --> Output Class Initialized
INFO - 2020-07-28 16:34:09 --> Security Class Initialized
DEBUG - 2020-07-28 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:34:09 --> Input Class Initialized
INFO - 2020-07-28 16:34:09 --> Language Class Initialized
INFO - 2020-07-28 16:34:09 --> Loader Class Initialized
INFO - 2020-07-28 16:34:09 --> Helper loaded: url_helper
INFO - 2020-07-28 16:34:09 --> Database Driver Class Initialized
INFO - 2020-07-28 16:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:34:09 --> Email Class Initialized
INFO - 2020-07-28 16:34:09 --> Controller Class Initialized
INFO - 2020-07-28 16:34:09 --> Model Class Initialized
INFO - 2020-07-28 16:34:09 --> Model Class Initialized
DEBUG - 2020-07-28 16:34:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:34:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:34:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 16:34:09 --> Final output sent to browser
DEBUG - 2020-07-28 16:34:09 --> Total execution time: 0.0337
INFO - 2020-07-28 16:39:07 --> Config Class Initialized
INFO - 2020-07-28 16:39:07 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:39:07 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:39:07 --> Utf8 Class Initialized
INFO - 2020-07-28 16:39:07 --> URI Class Initialized
DEBUG - 2020-07-28 16:39:07 --> No URI present. Default controller set.
INFO - 2020-07-28 16:39:07 --> Router Class Initialized
INFO - 2020-07-28 16:39:07 --> Output Class Initialized
INFO - 2020-07-28 16:39:07 --> Security Class Initialized
DEBUG - 2020-07-28 16:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:39:07 --> Input Class Initialized
INFO - 2020-07-28 16:39:07 --> Language Class Initialized
INFO - 2020-07-28 16:39:07 --> Loader Class Initialized
INFO - 2020-07-28 16:39:07 --> Helper loaded: url_helper
INFO - 2020-07-28 16:39:07 --> Database Driver Class Initialized
INFO - 2020-07-28 16:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:39:07 --> Email Class Initialized
INFO - 2020-07-28 16:39:07 --> Controller Class Initialized
INFO - 2020-07-28 16:39:07 --> Model Class Initialized
INFO - 2020-07-28 16:39:07 --> Model Class Initialized
DEBUG - 2020-07-28 16:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:39:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:39:07 --> Final output sent to browser
DEBUG - 2020-07-28 16:39:07 --> Total execution time: 0.0229
INFO - 2020-07-28 16:39:09 --> Config Class Initialized
INFO - 2020-07-28 16:39:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:39:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:39:09 --> Utf8 Class Initialized
INFO - 2020-07-28 16:39:09 --> URI Class Initialized
INFO - 2020-07-28 16:39:09 --> Router Class Initialized
INFO - 2020-07-28 16:39:09 --> Output Class Initialized
INFO - 2020-07-28 16:39:09 --> Security Class Initialized
DEBUG - 2020-07-28 16:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:39:09 --> Input Class Initialized
INFO - 2020-07-28 16:39:09 --> Language Class Initialized
INFO - 2020-07-28 16:39:09 --> Loader Class Initialized
INFO - 2020-07-28 16:39:09 --> Helper loaded: url_helper
INFO - 2020-07-28 16:39:09 --> Database Driver Class Initialized
INFO - 2020-07-28 16:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:39:09 --> Email Class Initialized
INFO - 2020-07-28 16:39:09 --> Controller Class Initialized
INFO - 2020-07-28 16:39:09 --> Model Class Initialized
INFO - 2020-07-28 16:39:09 --> Model Class Initialized
DEBUG - 2020-07-28 16:39:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 16:39:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:39:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 16:39:09 --> Final output sent to browser
DEBUG - 2020-07-28 16:39:09 --> Total execution time: 0.0252
INFO - 2020-07-28 16:39:27 --> Config Class Initialized
INFO - 2020-07-28 16:39:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:39:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:39:27 --> Utf8 Class Initialized
INFO - 2020-07-28 16:39:27 --> URI Class Initialized
DEBUG - 2020-07-28 16:39:27 --> No URI present. Default controller set.
INFO - 2020-07-28 16:39:27 --> Router Class Initialized
INFO - 2020-07-28 16:39:27 --> Output Class Initialized
INFO - 2020-07-28 16:39:27 --> Security Class Initialized
DEBUG - 2020-07-28 16:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:39:27 --> Input Class Initialized
INFO - 2020-07-28 16:39:27 --> Language Class Initialized
INFO - 2020-07-28 16:39:27 --> Loader Class Initialized
INFO - 2020-07-28 16:39:27 --> Helper loaded: url_helper
INFO - 2020-07-28 16:39:27 --> Database Driver Class Initialized
INFO - 2020-07-28 16:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:39:27 --> Email Class Initialized
INFO - 2020-07-28 16:39:27 --> Controller Class Initialized
INFO - 2020-07-28 16:39:27 --> Model Class Initialized
INFO - 2020-07-28 16:39:27 --> Model Class Initialized
DEBUG - 2020-07-28 16:39:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:39:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:39:27 --> Final output sent to browser
DEBUG - 2020-07-28 16:39:27 --> Total execution time: 0.0223
INFO - 2020-07-28 16:39:29 --> Config Class Initialized
INFO - 2020-07-28 16:39:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:39:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:39:29 --> Utf8 Class Initialized
INFO - 2020-07-28 16:39:29 --> URI Class Initialized
INFO - 2020-07-28 16:39:29 --> Router Class Initialized
INFO - 2020-07-28 16:39:29 --> Output Class Initialized
INFO - 2020-07-28 16:39:29 --> Security Class Initialized
DEBUG - 2020-07-28 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:39:29 --> Input Class Initialized
INFO - 2020-07-28 16:39:29 --> Language Class Initialized
INFO - 2020-07-28 16:39:29 --> Loader Class Initialized
INFO - 2020-07-28 16:39:29 --> Helper loaded: url_helper
INFO - 2020-07-28 16:39:29 --> Database Driver Class Initialized
INFO - 2020-07-28 16:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:39:29 --> Email Class Initialized
INFO - 2020-07-28 16:39:29 --> Controller Class Initialized
INFO - 2020-07-28 16:39:29 --> Model Class Initialized
INFO - 2020-07-28 16:39:29 --> Model Class Initialized
DEBUG - 2020-07-28 16:39:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:39:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:42:10 --> Config Class Initialized
INFO - 2020-07-28 16:42:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:42:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:42:10 --> Utf8 Class Initialized
INFO - 2020-07-28 16:42:10 --> URI Class Initialized
INFO - 2020-07-28 16:42:10 --> Router Class Initialized
INFO - 2020-07-28 16:42:10 --> Output Class Initialized
INFO - 2020-07-28 16:42:10 --> Security Class Initialized
DEBUG - 2020-07-28 16:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:42:10 --> Input Class Initialized
INFO - 2020-07-28 16:42:10 --> Language Class Initialized
INFO - 2020-07-28 16:42:10 --> Loader Class Initialized
INFO - 2020-07-28 16:42:10 --> Helper loaded: url_helper
INFO - 2020-07-28 16:42:10 --> Database Driver Class Initialized
INFO - 2020-07-28 16:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:42:10 --> Email Class Initialized
INFO - 2020-07-28 16:42:10 --> Controller Class Initialized
INFO - 2020-07-28 16:42:10 --> Model Class Initialized
INFO - 2020-07-28 16:42:10 --> Model Class Initialized
DEBUG - 2020-07-28 16:42:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:42:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:42:31 --> Config Class Initialized
INFO - 2020-07-28 16:42:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:42:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:42:31 --> Utf8 Class Initialized
INFO - 2020-07-28 16:42:31 --> URI Class Initialized
INFO - 2020-07-28 16:42:31 --> Router Class Initialized
INFO - 2020-07-28 16:42:31 --> Output Class Initialized
INFO - 2020-07-28 16:42:31 --> Security Class Initialized
DEBUG - 2020-07-28 16:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:42:31 --> Input Class Initialized
INFO - 2020-07-28 16:42:31 --> Language Class Initialized
INFO - 2020-07-28 16:42:31 --> Loader Class Initialized
INFO - 2020-07-28 16:42:31 --> Helper loaded: url_helper
INFO - 2020-07-28 16:42:31 --> Database Driver Class Initialized
INFO - 2020-07-28 16:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:42:31 --> Email Class Initialized
INFO - 2020-07-28 16:42:31 --> Controller Class Initialized
INFO - 2020-07-28 16:42:31 --> Model Class Initialized
INFO - 2020-07-28 16:42:31 --> Model Class Initialized
DEBUG - 2020-07-28 16:42:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:42:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:42:34 --> Config Class Initialized
INFO - 2020-07-28 16:42:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:42:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:42:34 --> Utf8 Class Initialized
INFO - 2020-07-28 16:42:34 --> URI Class Initialized
INFO - 2020-07-28 16:42:34 --> Router Class Initialized
INFO - 2020-07-28 16:42:34 --> Output Class Initialized
INFO - 2020-07-28 16:42:34 --> Security Class Initialized
DEBUG - 2020-07-28 16:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:42:34 --> Input Class Initialized
INFO - 2020-07-28 16:42:34 --> Language Class Initialized
INFO - 2020-07-28 16:42:34 --> Loader Class Initialized
INFO - 2020-07-28 16:42:34 --> Helper loaded: url_helper
INFO - 2020-07-28 16:42:34 --> Database Driver Class Initialized
INFO - 2020-07-28 16:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:42:34 --> Email Class Initialized
INFO - 2020-07-28 16:42:34 --> Controller Class Initialized
INFO - 2020-07-28 16:42:34 --> Model Class Initialized
INFO - 2020-07-28 16:42:34 --> Model Class Initialized
DEBUG - 2020-07-28 16:42:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:42:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:42:35 --> Config Class Initialized
INFO - 2020-07-28 16:42:35 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:42:35 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:42:35 --> Utf8 Class Initialized
INFO - 2020-07-28 16:42:35 --> URI Class Initialized
INFO - 2020-07-28 16:42:35 --> Router Class Initialized
INFO - 2020-07-28 16:42:35 --> Output Class Initialized
INFO - 2020-07-28 16:42:35 --> Security Class Initialized
DEBUG - 2020-07-28 16:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:42:35 --> Input Class Initialized
INFO - 2020-07-28 16:42:35 --> Language Class Initialized
INFO - 2020-07-28 16:42:35 --> Loader Class Initialized
INFO - 2020-07-28 16:42:35 --> Helper loaded: url_helper
INFO - 2020-07-28 16:42:35 --> Database Driver Class Initialized
INFO - 2020-07-28 16:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:42:35 --> Email Class Initialized
INFO - 2020-07-28 16:42:35 --> Controller Class Initialized
INFO - 2020-07-28 16:42:35 --> Model Class Initialized
INFO - 2020-07-28 16:42:35 --> Model Class Initialized
DEBUG - 2020-07-28 16:42:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:42:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:42:38 --> Config Class Initialized
INFO - 2020-07-28 16:42:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:42:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:42:38 --> Utf8 Class Initialized
INFO - 2020-07-28 16:42:38 --> URI Class Initialized
INFO - 2020-07-28 16:42:38 --> Router Class Initialized
INFO - 2020-07-28 16:42:38 --> Output Class Initialized
INFO - 2020-07-28 16:42:38 --> Security Class Initialized
DEBUG - 2020-07-28 16:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:42:38 --> Input Class Initialized
INFO - 2020-07-28 16:42:38 --> Language Class Initialized
INFO - 2020-07-28 16:42:38 --> Loader Class Initialized
INFO - 2020-07-28 16:42:38 --> Helper loaded: url_helper
INFO - 2020-07-28 16:42:38 --> Database Driver Class Initialized
INFO - 2020-07-28 16:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:42:38 --> Email Class Initialized
INFO - 2020-07-28 16:42:38 --> Controller Class Initialized
INFO - 2020-07-28 16:42:38 --> Model Class Initialized
INFO - 2020-07-28 16:42:38 --> Model Class Initialized
DEBUG - 2020-07-28 16:42:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:42:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:43:02 --> Config Class Initialized
INFO - 2020-07-28 16:43:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:43:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:43:02 --> Utf8 Class Initialized
INFO - 2020-07-28 16:43:02 --> URI Class Initialized
INFO - 2020-07-28 16:43:02 --> Router Class Initialized
INFO - 2020-07-28 16:43:02 --> Output Class Initialized
INFO - 2020-07-28 16:43:02 --> Security Class Initialized
DEBUG - 2020-07-28 16:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:43:02 --> Input Class Initialized
INFO - 2020-07-28 16:43:02 --> Language Class Initialized
INFO - 2020-07-28 16:43:02 --> Loader Class Initialized
INFO - 2020-07-28 16:43:02 --> Helper loaded: url_helper
INFO - 2020-07-28 16:43:02 --> Database Driver Class Initialized
INFO - 2020-07-28 16:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:43:02 --> Email Class Initialized
INFO - 2020-07-28 16:43:02 --> Controller Class Initialized
INFO - 2020-07-28 16:43:02 --> Model Class Initialized
INFO - 2020-07-28 16:43:02 --> Model Class Initialized
DEBUG - 2020-07-28 16:43:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:43:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:50) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:43:59 --> Config Class Initialized
INFO - 2020-07-28 16:43:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:43:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:43:59 --> Utf8 Class Initialized
INFO - 2020-07-28 16:43:59 --> URI Class Initialized
INFO - 2020-07-28 16:43:59 --> Router Class Initialized
INFO - 2020-07-28 16:43:59 --> Output Class Initialized
INFO - 2020-07-28 16:43:59 --> Security Class Initialized
DEBUG - 2020-07-28 16:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:43:59 --> Input Class Initialized
INFO - 2020-07-28 16:43:59 --> Language Class Initialized
INFO - 2020-07-28 16:43:59 --> Loader Class Initialized
INFO - 2020-07-28 16:43:59 --> Helper loaded: url_helper
INFO - 2020-07-28 16:43:59 --> Database Driver Class Initialized
INFO - 2020-07-28 16:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:43:59 --> Email Class Initialized
INFO - 2020-07-28 16:43:59 --> Controller Class Initialized
INFO - 2020-07-28 16:43:59 --> Model Class Initialized
INFO - 2020-07-28 16:43:59 --> Model Class Initialized
DEBUG - 2020-07-28 16:43:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:43:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:44:59 --> Config Class Initialized
INFO - 2020-07-28 16:44:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:44:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:44:59 --> Utf8 Class Initialized
INFO - 2020-07-28 16:44:59 --> URI Class Initialized
INFO - 2020-07-28 16:44:59 --> Router Class Initialized
INFO - 2020-07-28 16:44:59 --> Output Class Initialized
INFO - 2020-07-28 16:44:59 --> Security Class Initialized
DEBUG - 2020-07-28 16:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:44:59 --> Input Class Initialized
INFO - 2020-07-28 16:44:59 --> Language Class Initialized
INFO - 2020-07-28 16:44:59 --> Loader Class Initialized
INFO - 2020-07-28 16:44:59 --> Helper loaded: url_helper
INFO - 2020-07-28 16:44:59 --> Database Driver Class Initialized
INFO - 2020-07-28 16:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:44:59 --> Email Class Initialized
INFO - 2020-07-28 16:44:59 --> Controller Class Initialized
INFO - 2020-07-28 16:44:59 --> Model Class Initialized
INFO - 2020-07-28 16:44:59 --> Model Class Initialized
DEBUG - 2020-07-28 16:44:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:44:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-28 16:45:05 --> Config Class Initialized
INFO - 2020-07-28 16:45:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:45:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:45:05 --> Utf8 Class Initialized
INFO - 2020-07-28 16:45:05 --> URI Class Initialized
INFO - 2020-07-28 16:45:05 --> Router Class Initialized
INFO - 2020-07-28 16:45:05 --> Output Class Initialized
INFO - 2020-07-28 16:45:05 --> Security Class Initialized
DEBUG - 2020-07-28 16:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:45:05 --> Input Class Initialized
INFO - 2020-07-28 16:45:05 --> Language Class Initialized
INFO - 2020-07-28 16:45:05 --> Loader Class Initialized
INFO - 2020-07-28 16:45:05 --> Helper loaded: url_helper
INFO - 2020-07-28 16:45:05 --> Database Driver Class Initialized
INFO - 2020-07-28 16:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:45:05 --> Email Class Initialized
INFO - 2020-07-28 16:45:05 --> Controller Class Initialized
INFO - 2020-07-28 16:45:05 --> Model Class Initialized
INFO - 2020-07-28 16:45:05 --> Model Class Initialized
DEBUG - 2020-07-28 16:45:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:45:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-28 16:46:13 --> Config Class Initialized
INFO - 2020-07-28 16:46:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:46:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:46:13 --> Utf8 Class Initialized
INFO - 2020-07-28 16:46:13 --> URI Class Initialized
INFO - 2020-07-28 16:46:13 --> Router Class Initialized
INFO - 2020-07-28 16:46:13 --> Output Class Initialized
INFO - 2020-07-28 16:46:13 --> Security Class Initialized
DEBUG - 2020-07-28 16:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:46:13 --> Input Class Initialized
INFO - 2020-07-28 16:46:13 --> Language Class Initialized
INFO - 2020-07-28 16:46:13 --> Loader Class Initialized
INFO - 2020-07-28 16:46:13 --> Helper loaded: url_helper
INFO - 2020-07-28 16:46:13 --> Database Driver Class Initialized
INFO - 2020-07-28 16:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:46:13 --> Email Class Initialized
INFO - 2020-07-28 16:46:13 --> Controller Class Initialized
INFO - 2020-07-28 16:46:13 --> Model Class Initialized
INFO - 2020-07-28 16:46:13 --> Model Class Initialized
DEBUG - 2020-07-28 16:46:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:46:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:47:25 --> Config Class Initialized
INFO - 2020-07-28 16:47:25 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:47:25 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:47:25 --> Utf8 Class Initialized
INFO - 2020-07-28 16:47:25 --> URI Class Initialized
INFO - 2020-07-28 16:47:25 --> Router Class Initialized
INFO - 2020-07-28 16:47:25 --> Output Class Initialized
INFO - 2020-07-28 16:47:25 --> Security Class Initialized
DEBUG - 2020-07-28 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:47:25 --> Input Class Initialized
INFO - 2020-07-28 16:47:25 --> Language Class Initialized
INFO - 2020-07-28 16:47:25 --> Loader Class Initialized
INFO - 2020-07-28 16:47:25 --> Helper loaded: url_helper
INFO - 2020-07-28 16:47:25 --> Database Driver Class Initialized
INFO - 2020-07-28 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:47:25 --> Email Class Initialized
INFO - 2020-07-28 16:47:25 --> Controller Class Initialized
INFO - 2020-07-28 16:47:25 --> Model Class Initialized
INFO - 2020-07-28 16:47:25 --> Model Class Initialized
DEBUG - 2020-07-28 16:47:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:47:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:47:27 --> Config Class Initialized
INFO - 2020-07-28 16:47:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:47:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:47:27 --> Utf8 Class Initialized
INFO - 2020-07-28 16:47:27 --> URI Class Initialized
INFO - 2020-07-28 16:47:27 --> Router Class Initialized
INFO - 2020-07-28 16:47:27 --> Output Class Initialized
INFO - 2020-07-28 16:47:27 --> Security Class Initialized
DEBUG - 2020-07-28 16:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:47:27 --> Input Class Initialized
INFO - 2020-07-28 16:47:27 --> Language Class Initialized
INFO - 2020-07-28 16:47:27 --> Loader Class Initialized
INFO - 2020-07-28 16:47:27 --> Helper loaded: url_helper
INFO - 2020-07-28 16:47:27 --> Database Driver Class Initialized
INFO - 2020-07-28 16:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:47:27 --> Email Class Initialized
INFO - 2020-07-28 16:47:27 --> Controller Class Initialized
INFO - 2020-07-28 16:47:27 --> Model Class Initialized
INFO - 2020-07-28 16:47:27 --> Model Class Initialized
DEBUG - 2020-07-28 16:47:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:47:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 16:47:29 --> Config Class Initialized
INFO - 2020-07-28 16:47:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:47:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:47:29 --> Utf8 Class Initialized
INFO - 2020-07-28 16:47:29 --> URI Class Initialized
DEBUG - 2020-07-28 16:47:29 --> No URI present. Default controller set.
INFO - 2020-07-28 16:47:29 --> Router Class Initialized
INFO - 2020-07-28 16:47:29 --> Output Class Initialized
INFO - 2020-07-28 16:47:29 --> Security Class Initialized
DEBUG - 2020-07-28 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:47:29 --> Input Class Initialized
INFO - 2020-07-28 16:47:29 --> Language Class Initialized
INFO - 2020-07-28 16:47:29 --> Loader Class Initialized
INFO - 2020-07-28 16:47:29 --> Helper loaded: url_helper
INFO - 2020-07-28 16:47:29 --> Database Driver Class Initialized
INFO - 2020-07-28 16:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:47:29 --> Email Class Initialized
INFO - 2020-07-28 16:47:29 --> Controller Class Initialized
INFO - 2020-07-28 16:47:29 --> Model Class Initialized
INFO - 2020-07-28 16:47:29 --> Model Class Initialized
DEBUG - 2020-07-28 16:47:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 16:47:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 16:47:29 --> Final output sent to browser
DEBUG - 2020-07-28 16:47:29 --> Total execution time: 0.0239
INFO - 2020-07-28 16:47:32 --> Config Class Initialized
INFO - 2020-07-28 16:47:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 16:47:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 16:47:32 --> Utf8 Class Initialized
INFO - 2020-07-28 16:47:32 --> URI Class Initialized
INFO - 2020-07-28 16:47:32 --> Router Class Initialized
INFO - 2020-07-28 16:47:32 --> Output Class Initialized
INFO - 2020-07-28 16:47:32 --> Security Class Initialized
DEBUG - 2020-07-28 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 16:47:32 --> Input Class Initialized
INFO - 2020-07-28 16:47:32 --> Language Class Initialized
INFO - 2020-07-28 16:47:32 --> Loader Class Initialized
INFO - 2020-07-28 16:47:32 --> Helper loaded: url_helper
INFO - 2020-07-28 16:47:32 --> Database Driver Class Initialized
INFO - 2020-07-28 16:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 16:47:32 --> Email Class Initialized
INFO - 2020-07-28 16:47:32 --> Controller Class Initialized
INFO - 2020-07-28 16:47:32 --> Model Class Initialized
INFO - 2020-07-28 16:47:32 --> Model Class Initialized
DEBUG - 2020-07-28 16:47:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 16:47:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:00:05 --> Config Class Initialized
INFO - 2020-07-28 17:00:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:00:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:00:05 --> Utf8 Class Initialized
INFO - 2020-07-28 17:00:05 --> URI Class Initialized
INFO - 2020-07-28 17:00:05 --> Router Class Initialized
INFO - 2020-07-28 17:00:05 --> Output Class Initialized
INFO - 2020-07-28 17:00:05 --> Security Class Initialized
DEBUG - 2020-07-28 17:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:00:05 --> Input Class Initialized
INFO - 2020-07-28 17:00:05 --> Language Class Initialized
INFO - 2020-07-28 17:00:05 --> Loader Class Initialized
INFO - 2020-07-28 17:00:05 --> Helper loaded: url_helper
INFO - 2020-07-28 17:00:05 --> Database Driver Class Initialized
INFO - 2020-07-28 17:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:00:05 --> Email Class Initialized
INFO - 2020-07-28 17:00:05 --> Controller Class Initialized
INFO - 2020-07-28 17:00:05 --> Model Class Initialized
INFO - 2020-07-28 17:00:05 --> Model Class Initialized
DEBUG - 2020-07-28 17:00:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:00:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:18) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 17:00:05 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 18
INFO - 2020-07-28 17:00:13 --> Config Class Initialized
INFO - 2020-07-28 17:00:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:00:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:00:13 --> Utf8 Class Initialized
INFO - 2020-07-28 17:00:13 --> URI Class Initialized
DEBUG - 2020-07-28 17:00:13 --> No URI present. Default controller set.
INFO - 2020-07-28 17:00:13 --> Router Class Initialized
INFO - 2020-07-28 17:00:13 --> Output Class Initialized
INFO - 2020-07-28 17:00:13 --> Security Class Initialized
DEBUG - 2020-07-28 17:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:00:13 --> Input Class Initialized
INFO - 2020-07-28 17:00:13 --> Language Class Initialized
INFO - 2020-07-28 17:00:13 --> Loader Class Initialized
INFO - 2020-07-28 17:00:13 --> Helper loaded: url_helper
INFO - 2020-07-28 17:00:13 --> Database Driver Class Initialized
INFO - 2020-07-28 17:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:00:13 --> Email Class Initialized
INFO - 2020-07-28 17:00:13 --> Controller Class Initialized
INFO - 2020-07-28 17:00:13 --> Model Class Initialized
INFO - 2020-07-28 17:00:13 --> Model Class Initialized
DEBUG - 2020-07-28 17:00:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:00:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:00:13 --> Final output sent to browser
DEBUG - 2020-07-28 17:00:13 --> Total execution time: 0.0239
INFO - 2020-07-28 17:00:16 --> Config Class Initialized
INFO - 2020-07-28 17:00:16 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:00:16 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:00:16 --> Utf8 Class Initialized
INFO - 2020-07-28 17:00:16 --> URI Class Initialized
INFO - 2020-07-28 17:00:16 --> Router Class Initialized
INFO - 2020-07-28 17:00:16 --> Output Class Initialized
INFO - 2020-07-28 17:00:16 --> Security Class Initialized
DEBUG - 2020-07-28 17:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:00:16 --> Input Class Initialized
INFO - 2020-07-28 17:00:16 --> Language Class Initialized
INFO - 2020-07-28 17:00:16 --> Loader Class Initialized
INFO - 2020-07-28 17:00:16 --> Helper loaded: url_helper
INFO - 2020-07-28 17:00:16 --> Database Driver Class Initialized
INFO - 2020-07-28 17:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:00:16 --> Email Class Initialized
INFO - 2020-07-28 17:00:16 --> Controller Class Initialized
INFO - 2020-07-28 17:00:16 --> Model Class Initialized
INFO - 2020-07-28 17:00:16 --> Model Class Initialized
DEBUG - 2020-07-28 17:00:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:00:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:18) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 17:00:16 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/User.php 18
INFO - 2020-07-28 17:00:27 --> Config Class Initialized
INFO - 2020-07-28 17:00:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:00:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:00:27 --> Utf8 Class Initialized
INFO - 2020-07-28 17:00:27 --> URI Class Initialized
INFO - 2020-07-28 17:00:27 --> Router Class Initialized
INFO - 2020-07-28 17:00:27 --> Output Class Initialized
INFO - 2020-07-28 17:00:27 --> Security Class Initialized
DEBUG - 2020-07-28 17:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:00:27 --> Input Class Initialized
INFO - 2020-07-28 17:00:27 --> Language Class Initialized
INFO - 2020-07-28 17:00:27 --> Loader Class Initialized
INFO - 2020-07-28 17:00:27 --> Helper loaded: url_helper
INFO - 2020-07-28 17:00:27 --> Database Driver Class Initialized
INFO - 2020-07-28 17:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:00:27 --> Email Class Initialized
INFO - 2020-07-28 17:00:27 --> Controller Class Initialized
INFO - 2020-07-28 17:00:27 --> Model Class Initialized
INFO - 2020-07-28 17:00:27 --> Model Class Initialized
DEBUG - 2020-07-28 17:00:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:00:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:43) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:02:17 --> Config Class Initialized
INFO - 2020-07-28 17:02:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:02:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:02:17 --> Utf8 Class Initialized
INFO - 2020-07-28 17:02:17 --> URI Class Initialized
DEBUG - 2020-07-28 17:02:17 --> No URI present. Default controller set.
INFO - 2020-07-28 17:02:17 --> Router Class Initialized
INFO - 2020-07-28 17:02:17 --> Output Class Initialized
INFO - 2020-07-28 17:02:17 --> Security Class Initialized
DEBUG - 2020-07-28 17:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:02:17 --> Input Class Initialized
INFO - 2020-07-28 17:02:17 --> Language Class Initialized
INFO - 2020-07-28 17:02:17 --> Loader Class Initialized
INFO - 2020-07-28 17:02:17 --> Helper loaded: url_helper
INFO - 2020-07-28 17:02:17 --> Database Driver Class Initialized
INFO - 2020-07-28 17:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:02:17 --> Email Class Initialized
INFO - 2020-07-28 17:02:17 --> Controller Class Initialized
INFO - 2020-07-28 17:02:17 --> Model Class Initialized
INFO - 2020-07-28 17:02:17 --> Model Class Initialized
DEBUG - 2020-07-28 17:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:02:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:02:17 --> Final output sent to browser
DEBUG - 2020-07-28 17:02:17 --> Total execution time: 0.0226
INFO - 2020-07-28 17:02:20 --> Config Class Initialized
INFO - 2020-07-28 17:02:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:02:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:02:20 --> Utf8 Class Initialized
INFO - 2020-07-28 17:02:20 --> URI Class Initialized
DEBUG - 2020-07-28 17:02:20 --> No URI present. Default controller set.
INFO - 2020-07-28 17:02:20 --> Router Class Initialized
INFO - 2020-07-28 17:02:20 --> Output Class Initialized
INFO - 2020-07-28 17:02:20 --> Security Class Initialized
DEBUG - 2020-07-28 17:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:02:20 --> Input Class Initialized
INFO - 2020-07-28 17:02:20 --> Language Class Initialized
INFO - 2020-07-28 17:02:20 --> Loader Class Initialized
INFO - 2020-07-28 17:02:20 --> Helper loaded: url_helper
INFO - 2020-07-28 17:02:20 --> Database Driver Class Initialized
INFO - 2020-07-28 17:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:02:20 --> Email Class Initialized
INFO - 2020-07-28 17:02:20 --> Controller Class Initialized
INFO - 2020-07-28 17:02:20 --> Model Class Initialized
INFO - 2020-07-28 17:02:20 --> Model Class Initialized
DEBUG - 2020-07-28 17:02:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:02:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:02:20 --> Final output sent to browser
DEBUG - 2020-07-28 17:02:20 --> Total execution time: 0.0198
INFO - 2020-07-28 17:02:22 --> Config Class Initialized
INFO - 2020-07-28 17:02:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:02:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:02:22 --> Utf8 Class Initialized
INFO - 2020-07-28 17:02:22 --> URI Class Initialized
INFO - 2020-07-28 17:02:22 --> Router Class Initialized
INFO - 2020-07-28 17:02:22 --> Output Class Initialized
INFO - 2020-07-28 17:02:22 --> Security Class Initialized
DEBUG - 2020-07-28 17:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:02:22 --> Input Class Initialized
INFO - 2020-07-28 17:02:22 --> Language Class Initialized
INFO - 2020-07-28 17:02:22 --> Loader Class Initialized
INFO - 2020-07-28 17:02:22 --> Helper loaded: url_helper
INFO - 2020-07-28 17:02:22 --> Database Driver Class Initialized
INFO - 2020-07-28 17:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:02:22 --> Email Class Initialized
INFO - 2020-07-28 17:02:22 --> Controller Class Initialized
INFO - 2020-07-28 17:02:22 --> Model Class Initialized
INFO - 2020-07-28 17:02:22 --> Model Class Initialized
DEBUG - 2020-07-28 17:02:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:02:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:14) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:03:03 --> Config Class Initialized
INFO - 2020-07-28 17:03:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:03:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:03:03 --> Utf8 Class Initialized
INFO - 2020-07-28 17:03:03 --> URI Class Initialized
DEBUG - 2020-07-28 17:03:03 --> No URI present. Default controller set.
INFO - 2020-07-28 17:03:03 --> Router Class Initialized
INFO - 2020-07-28 17:03:03 --> Output Class Initialized
INFO - 2020-07-28 17:03:03 --> Security Class Initialized
DEBUG - 2020-07-28 17:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:03:03 --> Input Class Initialized
INFO - 2020-07-28 17:03:03 --> Language Class Initialized
INFO - 2020-07-28 17:03:03 --> Loader Class Initialized
INFO - 2020-07-28 17:03:03 --> Helper loaded: url_helper
INFO - 2020-07-28 17:03:03 --> Database Driver Class Initialized
INFO - 2020-07-28 17:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:03:03 --> Email Class Initialized
INFO - 2020-07-28 17:03:03 --> Controller Class Initialized
INFO - 2020-07-28 17:03:03 --> Model Class Initialized
INFO - 2020-07-28 17:03:03 --> Model Class Initialized
DEBUG - 2020-07-28 17:03:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:03:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:03:03 --> Final output sent to browser
DEBUG - 2020-07-28 17:03:03 --> Total execution time: 0.0242
INFO - 2020-07-28 17:03:59 --> Config Class Initialized
INFO - 2020-07-28 17:03:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:03:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:03:59 --> Utf8 Class Initialized
INFO - 2020-07-28 17:03:59 --> URI Class Initialized
DEBUG - 2020-07-28 17:03:59 --> No URI present. Default controller set.
INFO - 2020-07-28 17:03:59 --> Router Class Initialized
INFO - 2020-07-28 17:03:59 --> Output Class Initialized
INFO - 2020-07-28 17:03:59 --> Security Class Initialized
DEBUG - 2020-07-28 17:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:03:59 --> Input Class Initialized
INFO - 2020-07-28 17:03:59 --> Language Class Initialized
INFO - 2020-07-28 17:03:59 --> Loader Class Initialized
INFO - 2020-07-28 17:03:59 --> Helper loaded: url_helper
INFO - 2020-07-28 17:03:59 --> Database Driver Class Initialized
INFO - 2020-07-28 17:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:03:59 --> Email Class Initialized
INFO - 2020-07-28 17:03:59 --> Controller Class Initialized
INFO - 2020-07-28 17:03:59 --> Model Class Initialized
INFO - 2020-07-28 17:03:59 --> Model Class Initialized
DEBUG - 2020-07-28 17:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:03:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:03:59 --> Final output sent to browser
DEBUG - 2020-07-28 17:03:59 --> Total execution time: 0.0228
INFO - 2020-07-28 17:04:02 --> Config Class Initialized
INFO - 2020-07-28 17:04:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:04:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:04:02 --> Utf8 Class Initialized
INFO - 2020-07-28 17:04:02 --> URI Class Initialized
INFO - 2020-07-28 17:04:02 --> Router Class Initialized
INFO - 2020-07-28 17:04:02 --> Output Class Initialized
INFO - 2020-07-28 17:04:02 --> Security Class Initialized
DEBUG - 2020-07-28 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:04:02 --> Input Class Initialized
INFO - 2020-07-28 17:04:02 --> Language Class Initialized
INFO - 2020-07-28 17:04:02 --> Loader Class Initialized
INFO - 2020-07-28 17:04:02 --> Helper loaded: url_helper
INFO - 2020-07-28 17:04:02 --> Database Driver Class Initialized
INFO - 2020-07-28 17:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:04:02 --> Email Class Initialized
INFO - 2020-07-28 17:04:02 --> Controller Class Initialized
INFO - 2020-07-28 17:04:02 --> Model Class Initialized
INFO - 2020-07-28 17:04:02 --> Model Class Initialized
DEBUG - 2020-07-28 17:04:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:04:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:14) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:06:47 --> Config Class Initialized
INFO - 2020-07-28 17:06:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:06:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:06:47 --> Utf8 Class Initialized
INFO - 2020-07-28 17:06:47 --> URI Class Initialized
DEBUG - 2020-07-28 17:06:47 --> No URI present. Default controller set.
INFO - 2020-07-28 17:06:47 --> Router Class Initialized
INFO - 2020-07-28 17:06:47 --> Output Class Initialized
INFO - 2020-07-28 17:06:47 --> Security Class Initialized
DEBUG - 2020-07-28 17:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:06:47 --> Input Class Initialized
INFO - 2020-07-28 17:06:47 --> Language Class Initialized
INFO - 2020-07-28 17:06:47 --> Loader Class Initialized
INFO - 2020-07-28 17:06:47 --> Helper loaded: url_helper
INFO - 2020-07-28 17:06:47 --> Database Driver Class Initialized
INFO - 2020-07-28 17:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:06:47 --> Email Class Initialized
INFO - 2020-07-28 17:06:47 --> Controller Class Initialized
INFO - 2020-07-28 17:06:47 --> Model Class Initialized
INFO - 2020-07-28 17:06:47 --> Model Class Initialized
DEBUG - 2020-07-28 17:06:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:06:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:06:47 --> Final output sent to browser
DEBUG - 2020-07-28 17:06:47 --> Total execution time: 0.0222
INFO - 2020-07-28 17:06:51 --> Config Class Initialized
INFO - 2020-07-28 17:06:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:06:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:06:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:06:51 --> URI Class Initialized
DEBUG - 2020-07-28 17:06:51 --> No URI present. Default controller set.
INFO - 2020-07-28 17:06:51 --> Router Class Initialized
INFO - 2020-07-28 17:06:51 --> Output Class Initialized
INFO - 2020-07-28 17:06:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:06:51 --> Input Class Initialized
INFO - 2020-07-28 17:06:51 --> Language Class Initialized
INFO - 2020-07-28 17:06:51 --> Loader Class Initialized
INFO - 2020-07-28 17:06:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:06:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:06:51 --> Email Class Initialized
INFO - 2020-07-28 17:06:51 --> Controller Class Initialized
INFO - 2020-07-28 17:06:51 --> Model Class Initialized
INFO - 2020-07-28 17:06:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:06:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:06:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:06:51 --> Final output sent to browser
DEBUG - 2020-07-28 17:06:51 --> Total execution time: 0.0193
INFO - 2020-07-28 17:06:53 --> Config Class Initialized
INFO - 2020-07-28 17:06:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:06:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:06:53 --> Utf8 Class Initialized
INFO - 2020-07-28 17:06:53 --> URI Class Initialized
INFO - 2020-07-28 17:06:53 --> Router Class Initialized
INFO - 2020-07-28 17:06:53 --> Output Class Initialized
INFO - 2020-07-28 17:06:53 --> Security Class Initialized
DEBUG - 2020-07-28 17:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:06:53 --> Input Class Initialized
INFO - 2020-07-28 17:06:53 --> Language Class Initialized
INFO - 2020-07-28 17:06:53 --> Loader Class Initialized
INFO - 2020-07-28 17:06:53 --> Helper loaded: url_helper
INFO - 2020-07-28 17:06:53 --> Database Driver Class Initialized
INFO - 2020-07-28 17:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:06:53 --> Email Class Initialized
INFO - 2020-07-28 17:06:53 --> Controller Class Initialized
INFO - 2020-07-28 17:06:53 --> Model Class Initialized
INFO - 2020-07-28 17:06:53 --> Model Class Initialized
DEBUG - 2020-07-28 17:06:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:06:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:33) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:10:07 --> Config Class Initialized
INFO - 2020-07-28 17:10:07 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:10:07 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:10:07 --> Utf8 Class Initialized
INFO - 2020-07-28 17:10:07 --> URI Class Initialized
DEBUG - 2020-07-28 17:10:07 --> No URI present. Default controller set.
INFO - 2020-07-28 17:10:07 --> Router Class Initialized
INFO - 2020-07-28 17:10:07 --> Output Class Initialized
INFO - 2020-07-28 17:10:07 --> Security Class Initialized
DEBUG - 2020-07-28 17:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:10:07 --> Input Class Initialized
INFO - 2020-07-28 17:10:07 --> Language Class Initialized
INFO - 2020-07-28 17:10:07 --> Loader Class Initialized
INFO - 2020-07-28 17:10:07 --> Helper loaded: url_helper
INFO - 2020-07-28 17:10:07 --> Database Driver Class Initialized
INFO - 2020-07-28 17:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:10:07 --> Email Class Initialized
INFO - 2020-07-28 17:10:07 --> Controller Class Initialized
INFO - 2020-07-28 17:10:07 --> Model Class Initialized
INFO - 2020-07-28 17:10:07 --> Model Class Initialized
DEBUG - 2020-07-28 17:10:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:10:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:10:07 --> Final output sent to browser
DEBUG - 2020-07-28 17:10:07 --> Total execution time: 0.0279
INFO - 2020-07-28 17:10:13 --> Config Class Initialized
INFO - 2020-07-28 17:10:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:10:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:10:13 --> Utf8 Class Initialized
INFO - 2020-07-28 17:10:13 --> URI Class Initialized
INFO - 2020-07-28 17:10:13 --> Router Class Initialized
INFO - 2020-07-28 17:10:13 --> Output Class Initialized
INFO - 2020-07-28 17:10:13 --> Security Class Initialized
DEBUG - 2020-07-28 17:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:10:13 --> Input Class Initialized
INFO - 2020-07-28 17:10:13 --> Language Class Initialized
INFO - 2020-07-28 17:10:13 --> Loader Class Initialized
INFO - 2020-07-28 17:10:13 --> Helper loaded: url_helper
INFO - 2020-07-28 17:10:13 --> Database Driver Class Initialized
INFO - 2020-07-28 17:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:10:13 --> Email Class Initialized
INFO - 2020-07-28 17:10:13 --> Controller Class Initialized
INFO - 2020-07-28 17:10:13 --> Model Class Initialized
INFO - 2020-07-28 17:10:13 --> Model Class Initialized
DEBUG - 2020-07-28 17:10:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:10:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:33) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:12:26 --> Config Class Initialized
INFO - 2020-07-28 17:12:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:12:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:12:26 --> Utf8 Class Initialized
INFO - 2020-07-28 17:12:26 --> URI Class Initialized
DEBUG - 2020-07-28 17:12:26 --> No URI present. Default controller set.
INFO - 2020-07-28 17:12:26 --> Router Class Initialized
INFO - 2020-07-28 17:12:26 --> Output Class Initialized
INFO - 2020-07-28 17:12:26 --> Security Class Initialized
DEBUG - 2020-07-28 17:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:12:26 --> Input Class Initialized
INFO - 2020-07-28 17:12:26 --> Language Class Initialized
INFO - 2020-07-28 17:12:26 --> Loader Class Initialized
INFO - 2020-07-28 17:12:26 --> Helper loaded: url_helper
INFO - 2020-07-28 17:12:26 --> Database Driver Class Initialized
INFO - 2020-07-28 17:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:12:26 --> Email Class Initialized
INFO - 2020-07-28 17:12:26 --> Controller Class Initialized
INFO - 2020-07-28 17:12:26 --> Model Class Initialized
INFO - 2020-07-28 17:12:26 --> Model Class Initialized
DEBUG - 2020-07-28 17:12:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:12:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:12:26 --> Final output sent to browser
DEBUG - 2020-07-28 17:12:26 --> Total execution time: 0.0204
INFO - 2020-07-28 17:12:29 --> Config Class Initialized
INFO - 2020-07-28 17:12:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:12:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:12:29 --> Utf8 Class Initialized
INFO - 2020-07-28 17:12:29 --> URI Class Initialized
INFO - 2020-07-28 17:12:29 --> Router Class Initialized
INFO - 2020-07-28 17:12:29 --> Output Class Initialized
INFO - 2020-07-28 17:12:29 --> Security Class Initialized
DEBUG - 2020-07-28 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:12:29 --> Input Class Initialized
INFO - 2020-07-28 17:12:29 --> Language Class Initialized
INFO - 2020-07-28 17:12:29 --> Loader Class Initialized
INFO - 2020-07-28 17:12:29 --> Helper loaded: url_helper
INFO - 2020-07-28 17:12:29 --> Database Driver Class Initialized
INFO - 2020-07-28 17:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:12:29 --> Email Class Initialized
INFO - 2020-07-28 17:12:29 --> Controller Class Initialized
INFO - 2020-07-28 17:12:29 --> Model Class Initialized
INFO - 2020-07-28 17:12:29 --> Model Class Initialized
DEBUG - 2020-07-28 17:12:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:12:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:33) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:13:25 --> Config Class Initialized
INFO - 2020-07-28 17:13:25 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:13:25 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:13:25 --> Utf8 Class Initialized
INFO - 2020-07-28 17:13:25 --> URI Class Initialized
INFO - 2020-07-28 17:13:25 --> Router Class Initialized
INFO - 2020-07-28 17:13:25 --> Output Class Initialized
INFO - 2020-07-28 17:13:25 --> Security Class Initialized
DEBUG - 2020-07-28 17:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:13:25 --> Input Class Initialized
INFO - 2020-07-28 17:13:25 --> Language Class Initialized
INFO - 2020-07-28 17:13:25 --> Loader Class Initialized
INFO - 2020-07-28 17:13:25 --> Helper loaded: url_helper
INFO - 2020-07-28 17:13:25 --> Database Driver Class Initialized
INFO - 2020-07-28 17:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:13:25 --> Email Class Initialized
INFO - 2020-07-28 17:13:25 --> Controller Class Initialized
INFO - 2020-07-28 17:13:25 --> Model Class Initialized
INFO - 2020-07-28 17:13:25 --> Model Class Initialized
DEBUG - 2020-07-28 17:13:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:13:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:33) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:14:26 --> Config Class Initialized
INFO - 2020-07-28 17:14:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:14:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:14:26 --> Utf8 Class Initialized
INFO - 2020-07-28 17:14:26 --> URI Class Initialized
INFO - 2020-07-28 17:14:26 --> Router Class Initialized
INFO - 2020-07-28 17:14:26 --> Output Class Initialized
INFO - 2020-07-28 17:14:26 --> Security Class Initialized
DEBUG - 2020-07-28 17:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:14:26 --> Input Class Initialized
INFO - 2020-07-28 17:14:26 --> Language Class Initialized
INFO - 2020-07-28 17:14:26 --> Loader Class Initialized
INFO - 2020-07-28 17:14:26 --> Helper loaded: url_helper
INFO - 2020-07-28 17:14:26 --> Database Driver Class Initialized
INFO - 2020-07-28 17:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:14:26 --> Email Class Initialized
INFO - 2020-07-28 17:14:26 --> Controller Class Initialized
INFO - 2020-07-28 17:14:26 --> Model Class Initialized
INFO - 2020-07-28 17:14:26 --> Model Class Initialized
DEBUG - 2020-07-28 17:14:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:14:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:14) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:15:33 --> Config Class Initialized
INFO - 2020-07-28 17:15:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:15:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:15:33 --> Utf8 Class Initialized
INFO - 2020-07-28 17:15:33 --> URI Class Initialized
INFO - 2020-07-28 17:15:33 --> Router Class Initialized
INFO - 2020-07-28 17:15:33 --> Output Class Initialized
INFO - 2020-07-28 17:15:33 --> Security Class Initialized
DEBUG - 2020-07-28 17:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:15:33 --> Input Class Initialized
INFO - 2020-07-28 17:15:33 --> Language Class Initialized
INFO - 2020-07-28 17:15:33 --> Loader Class Initialized
INFO - 2020-07-28 17:15:33 --> Helper loaded: url_helper
INFO - 2020-07-28 17:15:33 --> Database Driver Class Initialized
INFO - 2020-07-28 17:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:15:33 --> Email Class Initialized
INFO - 2020-07-28 17:15:33 --> Controller Class Initialized
INFO - 2020-07-28 17:15:33 --> Model Class Initialized
INFO - 2020-07-28 17:15:33 --> Model Class Initialized
DEBUG - 2020-07-28 17:15:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:15:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:14) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:16:11 --> Config Class Initialized
INFO - 2020-07-28 17:16:11 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:16:11 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:16:11 --> Utf8 Class Initialized
INFO - 2020-07-28 17:16:11 --> URI Class Initialized
INFO - 2020-07-28 17:16:11 --> Router Class Initialized
INFO - 2020-07-28 17:16:11 --> Output Class Initialized
INFO - 2020-07-28 17:16:11 --> Security Class Initialized
DEBUG - 2020-07-28 17:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:16:11 --> Input Class Initialized
INFO - 2020-07-28 17:16:11 --> Language Class Initialized
INFO - 2020-07-28 17:16:11 --> Loader Class Initialized
INFO - 2020-07-28 17:16:11 --> Helper loaded: url_helper
INFO - 2020-07-28 17:16:11 --> Database Driver Class Initialized
INFO - 2020-07-28 17:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:16:11 --> Email Class Initialized
INFO - 2020-07-28 17:16:11 --> Controller Class Initialized
INFO - 2020-07-28 17:16:11 --> Model Class Initialized
INFO - 2020-07-28 17:16:11 --> Model Class Initialized
DEBUG - 2020-07-28 17:16:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:16:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:54) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:17:11 --> Config Class Initialized
INFO - 2020-07-28 17:17:11 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:11 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:11 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:11 --> URI Class Initialized
INFO - 2020-07-28 17:17:11 --> Router Class Initialized
INFO - 2020-07-28 17:17:11 --> Output Class Initialized
INFO - 2020-07-28 17:17:11 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:11 --> Input Class Initialized
INFO - 2020-07-28 17:17:11 --> Language Class Initialized
INFO - 2020-07-28 17:17:11 --> Loader Class Initialized
INFO - 2020-07-28 17:17:11 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:11 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:11 --> Email Class Initialized
INFO - 2020-07-28 17:17:11 --> Controller Class Initialized
INFO - 2020-07-28 17:17:11 --> Model Class Initialized
INFO - 2020-07-28 17:17:11 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:61) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:17:26 --> Config Class Initialized
INFO - 2020-07-28 17:17:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:26 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:26 --> URI Class Initialized
INFO - 2020-07-28 17:17:26 --> Router Class Initialized
INFO - 2020-07-28 17:17:26 --> Output Class Initialized
INFO - 2020-07-28 17:17:26 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:26 --> Input Class Initialized
INFO - 2020-07-28 17:17:26 --> Language Class Initialized
INFO - 2020-07-28 17:17:26 --> Loader Class Initialized
INFO - 2020-07-28 17:17:26 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:26 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:26 --> Email Class Initialized
INFO - 2020-07-28 17:17:26 --> Controller Class Initialized
INFO - 2020-07-28 17:17:26 --> Model Class Initialized
INFO - 2020-07-28 17:17:26 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-28 17:17:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php:84) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-28 17:17:39 --> Config Class Initialized
INFO - 2020-07-28 17:17:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:39 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:39 --> URI Class Initialized
INFO - 2020-07-28 17:17:39 --> Router Class Initialized
INFO - 2020-07-28 17:17:39 --> Output Class Initialized
INFO - 2020-07-28 17:17:39 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:39 --> Input Class Initialized
INFO - 2020-07-28 17:17:39 --> Language Class Initialized
INFO - 2020-07-28 17:17:39 --> Loader Class Initialized
INFO - 2020-07-28 17:17:39 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:39 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:39 --> Email Class Initialized
INFO - 2020-07-28 17:17:39 --> Controller Class Initialized
INFO - 2020-07-28 17:17:39 --> Model Class Initialized
INFO - 2020-07-28 17:17:39 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:17:40 --> Config Class Initialized
INFO - 2020-07-28 17:17:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:40 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:40 --> URI Class Initialized
INFO - 2020-07-28 17:17:40 --> Router Class Initialized
INFO - 2020-07-28 17:17:40 --> Output Class Initialized
INFO - 2020-07-28 17:17:40 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:40 --> Input Class Initialized
INFO - 2020-07-28 17:17:40 --> Language Class Initialized
INFO - 2020-07-28 17:17:40 --> Loader Class Initialized
INFO - 2020-07-28 17:17:40 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:40 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:40 --> Email Class Initialized
INFO - 2020-07-28 17:17:40 --> Controller Class Initialized
INFO - 2020-07-28 17:17:40 --> Model Class Initialized
INFO - 2020-07-28 17:17:40 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:17:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:17:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:17:40 --> Final output sent to browser
DEBUG - 2020-07-28 17:17:40 --> Total execution time: 0.0229
INFO - 2020-07-28 17:17:48 --> Config Class Initialized
INFO - 2020-07-28 17:17:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:48 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:48 --> URI Class Initialized
DEBUG - 2020-07-28 17:17:48 --> No URI present. Default controller set.
INFO - 2020-07-28 17:17:48 --> Router Class Initialized
INFO - 2020-07-28 17:17:48 --> Output Class Initialized
INFO - 2020-07-28 17:17:48 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:48 --> Input Class Initialized
INFO - 2020-07-28 17:17:48 --> Language Class Initialized
INFO - 2020-07-28 17:17:48 --> Loader Class Initialized
INFO - 2020-07-28 17:17:48 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:48 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:48 --> Email Class Initialized
INFO - 2020-07-28 17:17:48 --> Controller Class Initialized
INFO - 2020-07-28 17:17:48 --> Model Class Initialized
INFO - 2020-07-28 17:17:48 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:17:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:17:48 --> Final output sent to browser
DEBUG - 2020-07-28 17:17:48 --> Total execution time: 0.0224
INFO - 2020-07-28 17:17:51 --> Config Class Initialized
INFO - 2020-07-28 17:17:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:51 --> URI Class Initialized
INFO - 2020-07-28 17:17:51 --> Router Class Initialized
INFO - 2020-07-28 17:17:51 --> Output Class Initialized
INFO - 2020-07-28 17:17:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:51 --> Input Class Initialized
INFO - 2020-07-28 17:17:51 --> Language Class Initialized
INFO - 2020-07-28 17:17:51 --> Loader Class Initialized
INFO - 2020-07-28 17:17:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:51 --> Email Class Initialized
INFO - 2020-07-28 17:17:51 --> Controller Class Initialized
INFO - 2020-07-28 17:17:51 --> Model Class Initialized
INFO - 2020-07-28 17:17:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:17:51 --> Config Class Initialized
INFO - 2020-07-28 17:17:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:17:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:17:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:17:51 --> URI Class Initialized
INFO - 2020-07-28 17:17:51 --> Router Class Initialized
INFO - 2020-07-28 17:17:51 --> Output Class Initialized
INFO - 2020-07-28 17:17:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:17:51 --> Input Class Initialized
INFO - 2020-07-28 17:17:51 --> Language Class Initialized
INFO - 2020-07-28 17:17:51 --> Loader Class Initialized
INFO - 2020-07-28 17:17:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:17:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:17:51 --> Email Class Initialized
INFO - 2020-07-28 17:17:51 --> Controller Class Initialized
INFO - 2020-07-28 17:17:51 --> Model Class Initialized
INFO - 2020-07-28 17:17:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:17:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:17:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:17:51 --> Final output sent to browser
DEBUG - 2020-07-28 17:17:51 --> Total execution time: 0.0259
INFO - 2020-07-28 17:18:19 --> Config Class Initialized
INFO - 2020-07-28 17:18:19 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:18:19 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:18:19 --> Utf8 Class Initialized
INFO - 2020-07-28 17:18:19 --> URI Class Initialized
DEBUG - 2020-07-28 17:18:19 --> No URI present. Default controller set.
INFO - 2020-07-28 17:18:19 --> Router Class Initialized
INFO - 2020-07-28 17:18:19 --> Output Class Initialized
INFO - 2020-07-28 17:18:19 --> Security Class Initialized
DEBUG - 2020-07-28 17:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:18:19 --> Input Class Initialized
INFO - 2020-07-28 17:18:19 --> Language Class Initialized
INFO - 2020-07-28 17:18:19 --> Loader Class Initialized
INFO - 2020-07-28 17:18:19 --> Helper loaded: url_helper
INFO - 2020-07-28 17:18:19 --> Database Driver Class Initialized
INFO - 2020-07-28 17:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:18:19 --> Email Class Initialized
INFO - 2020-07-28 17:18:19 --> Controller Class Initialized
INFO - 2020-07-28 17:18:19 --> Model Class Initialized
INFO - 2020-07-28 17:18:19 --> Model Class Initialized
DEBUG - 2020-07-28 17:18:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:18:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:18:19 --> Final output sent to browser
DEBUG - 2020-07-28 17:18:19 --> Total execution time: 0.0264
INFO - 2020-07-28 17:18:25 --> Config Class Initialized
INFO - 2020-07-28 17:18:25 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:18:25 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:18:25 --> Utf8 Class Initialized
INFO - 2020-07-28 17:18:25 --> URI Class Initialized
INFO - 2020-07-28 17:18:25 --> Router Class Initialized
INFO - 2020-07-28 17:18:25 --> Output Class Initialized
INFO - 2020-07-28 17:18:25 --> Security Class Initialized
DEBUG - 2020-07-28 17:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:18:25 --> Input Class Initialized
INFO - 2020-07-28 17:18:25 --> Language Class Initialized
INFO - 2020-07-28 17:18:25 --> Loader Class Initialized
INFO - 2020-07-28 17:18:25 --> Helper loaded: url_helper
INFO - 2020-07-28 17:18:25 --> Database Driver Class Initialized
INFO - 2020-07-28 17:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:18:25 --> Email Class Initialized
INFO - 2020-07-28 17:18:25 --> Controller Class Initialized
INFO - 2020-07-28 17:18:25 --> Model Class Initialized
INFO - 2020-07-28 17:18:25 --> Model Class Initialized
DEBUG - 2020-07-28 17:18:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:18:26 --> Config Class Initialized
INFO - 2020-07-28 17:18:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:18:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:18:26 --> Utf8 Class Initialized
INFO - 2020-07-28 17:18:26 --> URI Class Initialized
INFO - 2020-07-28 17:18:26 --> Router Class Initialized
INFO - 2020-07-28 17:18:26 --> Output Class Initialized
INFO - 2020-07-28 17:18:26 --> Security Class Initialized
DEBUG - 2020-07-28 17:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:18:26 --> Input Class Initialized
INFO - 2020-07-28 17:18:26 --> Language Class Initialized
INFO - 2020-07-28 17:18:26 --> Loader Class Initialized
INFO - 2020-07-28 17:18:26 --> Helper loaded: url_helper
INFO - 2020-07-28 17:18:26 --> Database Driver Class Initialized
INFO - 2020-07-28 17:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:18:26 --> Email Class Initialized
INFO - 2020-07-28 17:18:26 --> Controller Class Initialized
INFO - 2020-07-28 17:18:26 --> Model Class Initialized
INFO - 2020-07-28 17:18:26 --> Model Class Initialized
DEBUG - 2020-07-28 17:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:18:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:18:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:18:26 --> Final output sent to browser
DEBUG - 2020-07-28 17:18:26 --> Total execution time: 0.0241
INFO - 2020-07-28 17:18:39 --> Config Class Initialized
INFO - 2020-07-28 17:18:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:18:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:18:39 --> Utf8 Class Initialized
INFO - 2020-07-28 17:18:39 --> URI Class Initialized
DEBUG - 2020-07-28 17:18:39 --> No URI present. Default controller set.
INFO - 2020-07-28 17:18:39 --> Router Class Initialized
INFO - 2020-07-28 17:18:39 --> Output Class Initialized
INFO - 2020-07-28 17:18:39 --> Security Class Initialized
DEBUG - 2020-07-28 17:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:18:39 --> Input Class Initialized
INFO - 2020-07-28 17:18:39 --> Language Class Initialized
INFO - 2020-07-28 17:18:39 --> Loader Class Initialized
INFO - 2020-07-28 17:18:39 --> Helper loaded: url_helper
INFO - 2020-07-28 17:18:39 --> Database Driver Class Initialized
INFO - 2020-07-28 17:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:18:39 --> Email Class Initialized
INFO - 2020-07-28 17:18:39 --> Controller Class Initialized
INFO - 2020-07-28 17:18:39 --> Model Class Initialized
INFO - 2020-07-28 17:18:39 --> Model Class Initialized
DEBUG - 2020-07-28 17:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:18:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:18:39 --> Final output sent to browser
DEBUG - 2020-07-28 17:18:39 --> Total execution time: 0.0320
INFO - 2020-07-28 17:21:54 --> Config Class Initialized
INFO - 2020-07-28 17:21:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:21:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:21:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:21:54 --> URI Class Initialized
INFO - 2020-07-28 17:21:54 --> Router Class Initialized
INFO - 2020-07-28 17:21:54 --> Output Class Initialized
INFO - 2020-07-28 17:21:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:21:54 --> Input Class Initialized
INFO - 2020-07-28 17:21:54 --> Language Class Initialized
INFO - 2020-07-28 17:21:54 --> Loader Class Initialized
INFO - 2020-07-28 17:21:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:21:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:21:54 --> Email Class Initialized
INFO - 2020-07-28 17:21:54 --> Controller Class Initialized
INFO - 2020-07-28 17:21:54 --> Model Class Initialized
INFO - 2020-07-28 17:21:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:21:54 --> Config Class Initialized
INFO - 2020-07-28 17:21:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:21:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:21:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:21:54 --> URI Class Initialized
INFO - 2020-07-28 17:21:54 --> Router Class Initialized
INFO - 2020-07-28 17:21:54 --> Output Class Initialized
INFO - 2020-07-28 17:21:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:21:54 --> Input Class Initialized
INFO - 2020-07-28 17:21:54 --> Language Class Initialized
INFO - 2020-07-28 17:21:54 --> Loader Class Initialized
INFO - 2020-07-28 17:21:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:21:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:21:54 --> Email Class Initialized
INFO - 2020-07-28 17:21:54 --> Controller Class Initialized
INFO - 2020-07-28 17:21:54 --> Model Class Initialized
INFO - 2020-07-28 17:21:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:21:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:21:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:21:54 --> Final output sent to browser
DEBUG - 2020-07-28 17:21:54 --> Total execution time: 0.0215
INFO - 2020-07-28 17:22:14 --> Config Class Initialized
INFO - 2020-07-28 17:22:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:14 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:14 --> URI Class Initialized
DEBUG - 2020-07-28 17:22:14 --> No URI present. Default controller set.
INFO - 2020-07-28 17:22:14 --> Router Class Initialized
INFO - 2020-07-28 17:22:14 --> Output Class Initialized
INFO - 2020-07-28 17:22:14 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:14 --> Input Class Initialized
INFO - 2020-07-28 17:22:14 --> Language Class Initialized
INFO - 2020-07-28 17:22:14 --> Loader Class Initialized
INFO - 2020-07-28 17:22:14 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:14 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:14 --> Email Class Initialized
INFO - 2020-07-28 17:22:14 --> Controller Class Initialized
INFO - 2020-07-28 17:22:14 --> Model Class Initialized
INFO - 2020-07-28 17:22:14 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:22:14 --> Final output sent to browser
DEBUG - 2020-07-28 17:22:14 --> Total execution time: 0.0233
INFO - 2020-07-28 17:22:17 --> Config Class Initialized
INFO - 2020-07-28 17:22:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:17 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:17 --> URI Class Initialized
INFO - 2020-07-28 17:22:17 --> Router Class Initialized
INFO - 2020-07-28 17:22:17 --> Output Class Initialized
INFO - 2020-07-28 17:22:17 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:17 --> Input Class Initialized
INFO - 2020-07-28 17:22:17 --> Language Class Initialized
INFO - 2020-07-28 17:22:17 --> Loader Class Initialized
INFO - 2020-07-28 17:22:17 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:17 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:17 --> Email Class Initialized
INFO - 2020-07-28 17:22:17 --> Controller Class Initialized
INFO - 2020-07-28 17:22:17 --> Model Class Initialized
INFO - 2020-07-28 17:22:17 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:17 --> Config Class Initialized
INFO - 2020-07-28 17:22:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:17 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:17 --> URI Class Initialized
DEBUG - 2020-07-28 17:22:17 --> No URI present. Default controller set.
INFO - 2020-07-28 17:22:17 --> Router Class Initialized
INFO - 2020-07-28 17:22:17 --> Output Class Initialized
INFO - 2020-07-28 17:22:17 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:17 --> Input Class Initialized
INFO - 2020-07-28 17:22:17 --> Language Class Initialized
INFO - 2020-07-28 17:22:17 --> Loader Class Initialized
INFO - 2020-07-28 17:22:17 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:17 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:17 --> Email Class Initialized
INFO - 2020-07-28 17:22:17 --> Controller Class Initialized
INFO - 2020-07-28 17:22:17 --> Model Class Initialized
INFO - 2020-07-28 17:22:17 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:22:17 --> Final output sent to browser
DEBUG - 2020-07-28 17:22:17 --> Total execution time: 0.0222
INFO - 2020-07-28 17:22:20 --> Config Class Initialized
INFO - 2020-07-28 17:22:20 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:20 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:20 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:20 --> URI Class Initialized
INFO - 2020-07-28 17:22:20 --> Router Class Initialized
INFO - 2020-07-28 17:22:20 --> Output Class Initialized
INFO - 2020-07-28 17:22:20 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:20 --> Input Class Initialized
INFO - 2020-07-28 17:22:20 --> Language Class Initialized
INFO - 2020-07-28 17:22:20 --> Loader Class Initialized
INFO - 2020-07-28 17:22:20 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:20 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:20 --> Email Class Initialized
INFO - 2020-07-28 17:22:20 --> Controller Class Initialized
INFO - 2020-07-28 17:22:20 --> Model Class Initialized
INFO - 2020-07-28 17:22:20 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:21 --> Config Class Initialized
INFO - 2020-07-28 17:22:21 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:21 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:21 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:21 --> URI Class Initialized
DEBUG - 2020-07-28 17:22:21 --> No URI present. Default controller set.
INFO - 2020-07-28 17:22:21 --> Router Class Initialized
INFO - 2020-07-28 17:22:21 --> Output Class Initialized
INFO - 2020-07-28 17:22:21 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:21 --> Input Class Initialized
INFO - 2020-07-28 17:22:21 --> Language Class Initialized
INFO - 2020-07-28 17:22:21 --> Loader Class Initialized
INFO - 2020-07-28 17:22:21 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:21 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:21 --> Email Class Initialized
INFO - 2020-07-28 17:22:21 --> Controller Class Initialized
INFO - 2020-07-28 17:22:21 --> Model Class Initialized
INFO - 2020-07-28 17:22:21 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:22:21 --> Final output sent to browser
DEBUG - 2020-07-28 17:22:21 --> Total execution time: 0.0254
INFO - 2020-07-28 17:22:23 --> Config Class Initialized
INFO - 2020-07-28 17:22:23 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:23 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:23 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:23 --> URI Class Initialized
INFO - 2020-07-28 17:22:23 --> Router Class Initialized
INFO - 2020-07-28 17:22:23 --> Output Class Initialized
INFO - 2020-07-28 17:22:23 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:23 --> Input Class Initialized
INFO - 2020-07-28 17:22:23 --> Language Class Initialized
INFO - 2020-07-28 17:22:23 --> Loader Class Initialized
INFO - 2020-07-28 17:22:23 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:23 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:23 --> Email Class Initialized
INFO - 2020-07-28 17:22:23 --> Controller Class Initialized
INFO - 2020-07-28 17:22:23 --> Model Class Initialized
INFO - 2020-07-28 17:22:23 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:24 --> Config Class Initialized
INFO - 2020-07-28 17:22:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:22:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:22:24 --> Utf8 Class Initialized
INFO - 2020-07-28 17:22:24 --> URI Class Initialized
DEBUG - 2020-07-28 17:22:24 --> No URI present. Default controller set.
INFO - 2020-07-28 17:22:24 --> Router Class Initialized
INFO - 2020-07-28 17:22:24 --> Output Class Initialized
INFO - 2020-07-28 17:22:24 --> Security Class Initialized
DEBUG - 2020-07-28 17:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:22:24 --> Input Class Initialized
INFO - 2020-07-28 17:22:24 --> Language Class Initialized
INFO - 2020-07-28 17:22:24 --> Loader Class Initialized
INFO - 2020-07-28 17:22:24 --> Helper loaded: url_helper
INFO - 2020-07-28 17:22:24 --> Database Driver Class Initialized
INFO - 2020-07-28 17:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:22:24 --> Email Class Initialized
INFO - 2020-07-28 17:22:24 --> Controller Class Initialized
INFO - 2020-07-28 17:22:24 --> Model Class Initialized
INFO - 2020-07-28 17:22:24 --> Model Class Initialized
DEBUG - 2020-07-28 17:22:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:22:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:22:24 --> Final output sent to browser
DEBUG - 2020-07-28 17:22:24 --> Total execution time: 0.0234
INFO - 2020-07-28 17:26:38 --> Config Class Initialized
INFO - 2020-07-28 17:26:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:38 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:38 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:38 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:38 --> Router Class Initialized
INFO - 2020-07-28 17:26:38 --> Output Class Initialized
INFO - 2020-07-28 17:26:38 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:38 --> Input Class Initialized
INFO - 2020-07-28 17:26:38 --> Language Class Initialized
INFO - 2020-07-28 17:26:38 --> Loader Class Initialized
INFO - 2020-07-28 17:26:38 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:38 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:38 --> Email Class Initialized
INFO - 2020-07-28 17:26:38 --> Controller Class Initialized
INFO - 2020-07-28 17:26:38 --> Model Class Initialized
INFO - 2020-07-28 17:26:38 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:38 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:38 --> Total execution time: 0.0231
INFO - 2020-07-28 17:26:39 --> Config Class Initialized
INFO - 2020-07-28 17:26:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:39 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:39 --> URI Class Initialized
INFO - 2020-07-28 17:26:39 --> Router Class Initialized
INFO - 2020-07-28 17:26:39 --> Output Class Initialized
INFO - 2020-07-28 17:26:39 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:39 --> Input Class Initialized
INFO - 2020-07-28 17:26:39 --> Language Class Initialized
INFO - 2020-07-28 17:26:39 --> Loader Class Initialized
INFO - 2020-07-28 17:26:39 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:39 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:39 --> Email Class Initialized
INFO - 2020-07-28 17:26:39 --> Controller Class Initialized
INFO - 2020-07-28 17:26:39 --> Model Class Initialized
INFO - 2020-07-28 17:26:39 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:39 --> Config Class Initialized
INFO - 2020-07-28 17:26:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:39 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:39 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:39 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:39 --> Router Class Initialized
INFO - 2020-07-28 17:26:39 --> Output Class Initialized
INFO - 2020-07-28 17:26:39 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:39 --> Input Class Initialized
INFO - 2020-07-28 17:26:39 --> Language Class Initialized
INFO - 2020-07-28 17:26:39 --> Loader Class Initialized
INFO - 2020-07-28 17:26:39 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:39 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:39 --> Email Class Initialized
INFO - 2020-07-28 17:26:39 --> Controller Class Initialized
INFO - 2020-07-28 17:26:39 --> Model Class Initialized
INFO - 2020-07-28 17:26:39 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:39 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:39 --> Total execution time: 0.0205
INFO - 2020-07-28 17:26:40 --> Config Class Initialized
INFO - 2020-07-28 17:26:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:40 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:40 --> URI Class Initialized
INFO - 2020-07-28 17:26:40 --> Router Class Initialized
INFO - 2020-07-28 17:26:40 --> Output Class Initialized
INFO - 2020-07-28 17:26:40 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:40 --> Input Class Initialized
INFO - 2020-07-28 17:26:40 --> Language Class Initialized
INFO - 2020-07-28 17:26:40 --> Loader Class Initialized
INFO - 2020-07-28 17:26:40 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:40 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:40 --> Email Class Initialized
INFO - 2020-07-28 17:26:40 --> Controller Class Initialized
INFO - 2020-07-28 17:26:40 --> Model Class Initialized
INFO - 2020-07-28 17:26:40 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:40 --> Config Class Initialized
INFO - 2020-07-28 17:26:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:40 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:40 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:40 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:40 --> Router Class Initialized
INFO - 2020-07-28 17:26:40 --> Output Class Initialized
INFO - 2020-07-28 17:26:40 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:40 --> Input Class Initialized
INFO - 2020-07-28 17:26:40 --> Language Class Initialized
INFO - 2020-07-28 17:26:40 --> Loader Class Initialized
INFO - 2020-07-28 17:26:40 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:40 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:40 --> Email Class Initialized
INFO - 2020-07-28 17:26:40 --> Controller Class Initialized
INFO - 2020-07-28 17:26:40 --> Model Class Initialized
INFO - 2020-07-28 17:26:40 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:40 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:40 --> Total execution time: 0.0226
INFO - 2020-07-28 17:26:40 --> Config Class Initialized
INFO - 2020-07-28 17:26:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:40 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:40 --> URI Class Initialized
INFO - 2020-07-28 17:26:40 --> Router Class Initialized
INFO - 2020-07-28 17:26:40 --> Output Class Initialized
INFO - 2020-07-28 17:26:40 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:40 --> Input Class Initialized
INFO - 2020-07-28 17:26:40 --> Language Class Initialized
INFO - 2020-07-28 17:26:40 --> Loader Class Initialized
INFO - 2020-07-28 17:26:40 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:40 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:40 --> Email Class Initialized
INFO - 2020-07-28 17:26:40 --> Controller Class Initialized
INFO - 2020-07-28 17:26:40 --> Model Class Initialized
INFO - 2020-07-28 17:26:40 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:41 --> Config Class Initialized
INFO - 2020-07-28 17:26:41 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:41 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:41 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:41 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:41 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:41 --> Router Class Initialized
INFO - 2020-07-28 17:26:41 --> Output Class Initialized
INFO - 2020-07-28 17:26:41 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:41 --> Input Class Initialized
INFO - 2020-07-28 17:26:41 --> Language Class Initialized
INFO - 2020-07-28 17:26:41 --> Loader Class Initialized
INFO - 2020-07-28 17:26:41 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:41 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:41 --> Email Class Initialized
INFO - 2020-07-28 17:26:41 --> Controller Class Initialized
INFO - 2020-07-28 17:26:41 --> Model Class Initialized
INFO - 2020-07-28 17:26:41 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:41 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:41 --> Total execution time: 0.0382
INFO - 2020-07-28 17:26:42 --> Config Class Initialized
INFO - 2020-07-28 17:26:42 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:42 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:42 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:42 --> URI Class Initialized
INFO - 2020-07-28 17:26:42 --> Router Class Initialized
INFO - 2020-07-28 17:26:42 --> Output Class Initialized
INFO - 2020-07-28 17:26:42 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:42 --> Input Class Initialized
INFO - 2020-07-28 17:26:42 --> Language Class Initialized
INFO - 2020-07-28 17:26:42 --> Loader Class Initialized
INFO - 2020-07-28 17:26:42 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:42 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:42 --> Email Class Initialized
INFO - 2020-07-28 17:26:42 --> Controller Class Initialized
INFO - 2020-07-28 17:26:42 --> Model Class Initialized
INFO - 2020-07-28 17:26:42 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:42 --> Config Class Initialized
INFO - 2020-07-28 17:26:42 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:42 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:42 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:42 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:42 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:42 --> Router Class Initialized
INFO - 2020-07-28 17:26:42 --> Output Class Initialized
INFO - 2020-07-28 17:26:42 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:42 --> Input Class Initialized
INFO - 2020-07-28 17:26:42 --> Language Class Initialized
INFO - 2020-07-28 17:26:42 --> Loader Class Initialized
INFO - 2020-07-28 17:26:42 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:42 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:42 --> Email Class Initialized
INFO - 2020-07-28 17:26:42 --> Controller Class Initialized
INFO - 2020-07-28 17:26:42 --> Model Class Initialized
INFO - 2020-07-28 17:26:42 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:42 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:42 --> Total execution time: 0.0250
INFO - 2020-07-28 17:26:43 --> Config Class Initialized
INFO - 2020-07-28 17:26:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:43 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:43 --> URI Class Initialized
INFO - 2020-07-28 17:26:43 --> Router Class Initialized
INFO - 2020-07-28 17:26:43 --> Output Class Initialized
INFO - 2020-07-28 17:26:43 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:43 --> Input Class Initialized
INFO - 2020-07-28 17:26:43 --> Language Class Initialized
INFO - 2020-07-28 17:26:43 --> Loader Class Initialized
INFO - 2020-07-28 17:26:43 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:43 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:43 --> Email Class Initialized
INFO - 2020-07-28 17:26:43 --> Controller Class Initialized
INFO - 2020-07-28 17:26:43 --> Model Class Initialized
INFO - 2020-07-28 17:26:43 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:43 --> Config Class Initialized
INFO - 2020-07-28 17:26:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:43 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:43 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:43 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:43 --> Router Class Initialized
INFO - 2020-07-28 17:26:43 --> Output Class Initialized
INFO - 2020-07-28 17:26:43 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:43 --> Input Class Initialized
INFO - 2020-07-28 17:26:43 --> Language Class Initialized
INFO - 2020-07-28 17:26:43 --> Loader Class Initialized
INFO - 2020-07-28 17:26:43 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:43 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:43 --> Email Class Initialized
INFO - 2020-07-28 17:26:43 --> Controller Class Initialized
INFO - 2020-07-28 17:26:43 --> Model Class Initialized
INFO - 2020-07-28 17:26:43 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:43 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:43 --> Total execution time: 0.0203
INFO - 2020-07-28 17:26:44 --> Config Class Initialized
INFO - 2020-07-28 17:26:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:44 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:44 --> URI Class Initialized
INFO - 2020-07-28 17:26:44 --> Router Class Initialized
INFO - 2020-07-28 17:26:44 --> Output Class Initialized
INFO - 2020-07-28 17:26:44 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:44 --> Input Class Initialized
INFO - 2020-07-28 17:26:44 --> Language Class Initialized
INFO - 2020-07-28 17:26:44 --> Loader Class Initialized
INFO - 2020-07-28 17:26:44 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:44 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:44 --> Email Class Initialized
INFO - 2020-07-28 17:26:44 --> Controller Class Initialized
INFO - 2020-07-28 17:26:44 --> Model Class Initialized
INFO - 2020-07-28 17:26:44 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:44 --> Config Class Initialized
INFO - 2020-07-28 17:26:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:44 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:44 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:44 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:44 --> Router Class Initialized
INFO - 2020-07-28 17:26:44 --> Output Class Initialized
INFO - 2020-07-28 17:26:44 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:44 --> Input Class Initialized
INFO - 2020-07-28 17:26:44 --> Language Class Initialized
INFO - 2020-07-28 17:26:44 --> Loader Class Initialized
INFO - 2020-07-28 17:26:44 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:44 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:45 --> Email Class Initialized
INFO - 2020-07-28 17:26:45 --> Controller Class Initialized
INFO - 2020-07-28 17:26:45 --> Model Class Initialized
INFO - 2020-07-28 17:26:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:45 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:45 --> Total execution time: 0.0550
INFO - 2020-07-28 17:26:45 --> Config Class Initialized
INFO - 2020-07-28 17:26:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:45 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:45 --> URI Class Initialized
INFO - 2020-07-28 17:26:45 --> Router Class Initialized
INFO - 2020-07-28 17:26:45 --> Output Class Initialized
INFO - 2020-07-28 17:26:45 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:45 --> Input Class Initialized
INFO - 2020-07-28 17:26:45 --> Language Class Initialized
INFO - 2020-07-28 17:26:45 --> Loader Class Initialized
INFO - 2020-07-28 17:26:45 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:45 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:45 --> Email Class Initialized
INFO - 2020-07-28 17:26:45 --> Controller Class Initialized
INFO - 2020-07-28 17:26:45 --> Model Class Initialized
INFO - 2020-07-28 17:26:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:45 --> Config Class Initialized
INFO - 2020-07-28 17:26:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:45 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:45 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:45 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:45 --> Router Class Initialized
INFO - 2020-07-28 17:26:45 --> Output Class Initialized
INFO - 2020-07-28 17:26:45 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:45 --> Input Class Initialized
INFO - 2020-07-28 17:26:45 --> Language Class Initialized
INFO - 2020-07-28 17:26:45 --> Loader Class Initialized
INFO - 2020-07-28 17:26:45 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:45 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:45 --> Email Class Initialized
INFO - 2020-07-28 17:26:45 --> Controller Class Initialized
INFO - 2020-07-28 17:26:45 --> Model Class Initialized
INFO - 2020-07-28 17:26:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:45 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:45 --> Total execution time: 0.0228
INFO - 2020-07-28 17:26:46 --> Config Class Initialized
INFO - 2020-07-28 17:26:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:46 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:46 --> URI Class Initialized
INFO - 2020-07-28 17:26:46 --> Router Class Initialized
INFO - 2020-07-28 17:26:46 --> Output Class Initialized
INFO - 2020-07-28 17:26:46 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:46 --> Input Class Initialized
INFO - 2020-07-28 17:26:46 --> Language Class Initialized
INFO - 2020-07-28 17:26:46 --> Loader Class Initialized
INFO - 2020-07-28 17:26:46 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:46 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:46 --> Email Class Initialized
INFO - 2020-07-28 17:26:46 --> Controller Class Initialized
INFO - 2020-07-28 17:26:46 --> Model Class Initialized
INFO - 2020-07-28 17:26:46 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:46 --> Config Class Initialized
INFO - 2020-07-28 17:26:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:46 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:46 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:46 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:46 --> Router Class Initialized
INFO - 2020-07-28 17:26:46 --> Output Class Initialized
INFO - 2020-07-28 17:26:46 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:46 --> Input Class Initialized
INFO - 2020-07-28 17:26:46 --> Language Class Initialized
INFO - 2020-07-28 17:26:46 --> Loader Class Initialized
INFO - 2020-07-28 17:26:46 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:46 --> Config Class Initialized
INFO - 2020-07-28 17:26:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:46 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:46 --> URI Class Initialized
INFO - 2020-07-28 17:26:46 --> Database Driver Class Initialized
DEBUG - 2020-07-28 17:26:46 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:46 --> Router Class Initialized
INFO - 2020-07-28 17:26:46 --> Output Class Initialized
INFO - 2020-07-28 17:26:46 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:46 --> Input Class Initialized
INFO - 2020-07-28 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:46 --> Language Class Initialized
INFO - 2020-07-28 17:26:46 --> Loader Class Initialized
INFO - 2020-07-28 17:26:46 --> Email Class Initialized
INFO - 2020-07-28 17:26:46 --> Controller Class Initialized
INFO - 2020-07-28 17:26:46 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:46 --> Model Class Initialized
INFO - 2020-07-28 17:26:46 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:46 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:46 --> Total execution time: 0.0260
INFO - 2020-07-28 17:26:46 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:46 --> Email Class Initialized
INFO - 2020-07-28 17:26:46 --> Controller Class Initialized
INFO - 2020-07-28 17:26:46 --> Model Class Initialized
INFO - 2020-07-28 17:26:46 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:46 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:46 --> Total execution time: 0.0278
INFO - 2020-07-28 17:26:47 --> Config Class Initialized
INFO - 2020-07-28 17:26:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:47 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:47 --> URI Class Initialized
INFO - 2020-07-28 17:26:47 --> Router Class Initialized
INFO - 2020-07-28 17:26:47 --> Output Class Initialized
INFO - 2020-07-28 17:26:47 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:47 --> Input Class Initialized
INFO - 2020-07-28 17:26:47 --> Language Class Initialized
INFO - 2020-07-28 17:26:47 --> Loader Class Initialized
INFO - 2020-07-28 17:26:47 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:47 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:47 --> Email Class Initialized
INFO - 2020-07-28 17:26:47 --> Controller Class Initialized
INFO - 2020-07-28 17:26:47 --> Model Class Initialized
INFO - 2020-07-28 17:26:47 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:47 --> Config Class Initialized
INFO - 2020-07-28 17:26:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:47 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:47 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:47 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:47 --> Router Class Initialized
INFO - 2020-07-28 17:26:47 --> Output Class Initialized
INFO - 2020-07-28 17:26:47 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:47 --> Input Class Initialized
INFO - 2020-07-28 17:26:47 --> Language Class Initialized
INFO - 2020-07-28 17:26:47 --> Loader Class Initialized
INFO - 2020-07-28 17:26:47 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:47 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:47 --> Email Class Initialized
INFO - 2020-07-28 17:26:47 --> Controller Class Initialized
INFO - 2020-07-28 17:26:47 --> Model Class Initialized
INFO - 2020-07-28 17:26:47 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:47 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:47 --> Total execution time: 0.0466
INFO - 2020-07-28 17:26:48 --> Config Class Initialized
INFO - 2020-07-28 17:26:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:48 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:48 --> URI Class Initialized
INFO - 2020-07-28 17:26:48 --> Router Class Initialized
INFO - 2020-07-28 17:26:48 --> Output Class Initialized
INFO - 2020-07-28 17:26:48 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:48 --> Input Class Initialized
INFO - 2020-07-28 17:26:48 --> Language Class Initialized
INFO - 2020-07-28 17:26:48 --> Loader Class Initialized
INFO - 2020-07-28 17:26:48 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:48 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:48 --> Email Class Initialized
INFO - 2020-07-28 17:26:48 --> Controller Class Initialized
INFO - 2020-07-28 17:26:48 --> Model Class Initialized
INFO - 2020-07-28 17:26:48 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:48 --> Config Class Initialized
INFO - 2020-07-28 17:26:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:48 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:48 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:48 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:48 --> Router Class Initialized
INFO - 2020-07-28 17:26:48 --> Output Class Initialized
INFO - 2020-07-28 17:26:48 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:48 --> Input Class Initialized
INFO - 2020-07-28 17:26:48 --> Language Class Initialized
INFO - 2020-07-28 17:26:48 --> Loader Class Initialized
INFO - 2020-07-28 17:26:48 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:48 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:48 --> Email Class Initialized
INFO - 2020-07-28 17:26:48 --> Controller Class Initialized
INFO - 2020-07-28 17:26:48 --> Model Class Initialized
INFO - 2020-07-28 17:26:48 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:48 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:48 --> Total execution time: 0.0214
INFO - 2020-07-28 17:26:49 --> Config Class Initialized
INFO - 2020-07-28 17:26:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:49 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:49 --> URI Class Initialized
INFO - 2020-07-28 17:26:49 --> Router Class Initialized
INFO - 2020-07-28 17:26:49 --> Output Class Initialized
INFO - 2020-07-28 17:26:49 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:49 --> Input Class Initialized
INFO - 2020-07-28 17:26:49 --> Language Class Initialized
INFO - 2020-07-28 17:26:49 --> Loader Class Initialized
INFO - 2020-07-28 17:26:49 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:49 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:49 --> Email Class Initialized
INFO - 2020-07-28 17:26:49 --> Controller Class Initialized
INFO - 2020-07-28 17:26:49 --> Model Class Initialized
INFO - 2020-07-28 17:26:49 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:49 --> Config Class Initialized
INFO - 2020-07-28 17:26:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:49 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:49 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:49 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:49 --> Router Class Initialized
INFO - 2020-07-28 17:26:49 --> Output Class Initialized
INFO - 2020-07-28 17:26:49 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:49 --> Input Class Initialized
INFO - 2020-07-28 17:26:49 --> Language Class Initialized
INFO - 2020-07-28 17:26:49 --> Loader Class Initialized
INFO - 2020-07-28 17:26:49 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:49 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:49 --> Email Class Initialized
INFO - 2020-07-28 17:26:49 --> Controller Class Initialized
INFO - 2020-07-28 17:26:49 --> Model Class Initialized
INFO - 2020-07-28 17:26:49 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:49 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:49 --> Total execution time: 0.0282
INFO - 2020-07-28 17:26:50 --> Config Class Initialized
INFO - 2020-07-28 17:26:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:50 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:50 --> URI Class Initialized
INFO - 2020-07-28 17:26:50 --> Router Class Initialized
INFO - 2020-07-28 17:26:50 --> Output Class Initialized
INFO - 2020-07-28 17:26:50 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:50 --> Input Class Initialized
INFO - 2020-07-28 17:26:50 --> Language Class Initialized
INFO - 2020-07-28 17:26:50 --> Loader Class Initialized
INFO - 2020-07-28 17:26:50 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:50 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:50 --> Email Class Initialized
INFO - 2020-07-28 17:26:50 --> Controller Class Initialized
INFO - 2020-07-28 17:26:50 --> Model Class Initialized
INFO - 2020-07-28 17:26:50 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:51 --> Config Class Initialized
INFO - 2020-07-28 17:26:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:51 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:51 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:51 --> Router Class Initialized
INFO - 2020-07-28 17:26:51 --> Output Class Initialized
INFO - 2020-07-28 17:26:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:51 --> Input Class Initialized
INFO - 2020-07-28 17:26:51 --> Language Class Initialized
INFO - 2020-07-28 17:26:51 --> Loader Class Initialized
INFO - 2020-07-28 17:26:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:51 --> Email Class Initialized
INFO - 2020-07-28 17:26:51 --> Controller Class Initialized
INFO - 2020-07-28 17:26:51 --> Model Class Initialized
INFO - 2020-07-28 17:26:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:51 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:51 --> Total execution time: 0.0233
INFO - 2020-07-28 17:26:51 --> Config Class Initialized
INFO - 2020-07-28 17:26:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:51 --> URI Class Initialized
INFO - 2020-07-28 17:26:51 --> Router Class Initialized
INFO - 2020-07-28 17:26:51 --> Output Class Initialized
INFO - 2020-07-28 17:26:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:51 --> Input Class Initialized
INFO - 2020-07-28 17:26:51 --> Language Class Initialized
INFO - 2020-07-28 17:26:51 --> Loader Class Initialized
INFO - 2020-07-28 17:26:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:51 --> Email Class Initialized
INFO - 2020-07-28 17:26:51 --> Controller Class Initialized
INFO - 2020-07-28 17:26:51 --> Model Class Initialized
INFO - 2020-07-28 17:26:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:52 --> Config Class Initialized
INFO - 2020-07-28 17:26:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:52 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:52 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:52 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:52 --> Router Class Initialized
INFO - 2020-07-28 17:26:52 --> Output Class Initialized
INFO - 2020-07-28 17:26:52 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:52 --> Input Class Initialized
INFO - 2020-07-28 17:26:52 --> Language Class Initialized
INFO - 2020-07-28 17:26:52 --> Loader Class Initialized
INFO - 2020-07-28 17:26:52 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:52 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:52 --> Email Class Initialized
INFO - 2020-07-28 17:26:52 --> Controller Class Initialized
INFO - 2020-07-28 17:26:52 --> Model Class Initialized
INFO - 2020-07-28 17:26:52 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:52 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:52 --> Total execution time: 0.0337
INFO - 2020-07-28 17:26:52 --> Config Class Initialized
INFO - 2020-07-28 17:26:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:52 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:52 --> URI Class Initialized
INFO - 2020-07-28 17:26:52 --> Router Class Initialized
INFO - 2020-07-28 17:26:52 --> Output Class Initialized
INFO - 2020-07-28 17:26:52 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:52 --> Input Class Initialized
INFO - 2020-07-28 17:26:52 --> Language Class Initialized
INFO - 2020-07-28 17:26:52 --> Loader Class Initialized
INFO - 2020-07-28 17:26:52 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:52 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:52 --> Email Class Initialized
INFO - 2020-07-28 17:26:52 --> Controller Class Initialized
INFO - 2020-07-28 17:26:52 --> Model Class Initialized
INFO - 2020-07-28 17:26:52 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:53 --> Config Class Initialized
INFO - 2020-07-28 17:26:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:53 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:53 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:53 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:53 --> Router Class Initialized
INFO - 2020-07-28 17:26:53 --> Output Class Initialized
INFO - 2020-07-28 17:26:53 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:53 --> Input Class Initialized
INFO - 2020-07-28 17:26:53 --> Language Class Initialized
INFO - 2020-07-28 17:26:53 --> Loader Class Initialized
INFO - 2020-07-28 17:26:53 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:53 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:53 --> Email Class Initialized
INFO - 2020-07-28 17:26:53 --> Controller Class Initialized
INFO - 2020-07-28 17:26:53 --> Model Class Initialized
INFO - 2020-07-28 17:26:53 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:53 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:53 --> Total execution time: 0.0278
INFO - 2020-07-28 17:26:54 --> Config Class Initialized
INFO - 2020-07-28 17:26:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:54 --> URI Class Initialized
INFO - 2020-07-28 17:26:54 --> Router Class Initialized
INFO - 2020-07-28 17:26:54 --> Output Class Initialized
INFO - 2020-07-28 17:26:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:54 --> Input Class Initialized
INFO - 2020-07-28 17:26:54 --> Language Class Initialized
INFO - 2020-07-28 17:26:54 --> Loader Class Initialized
INFO - 2020-07-28 17:26:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:54 --> Email Class Initialized
INFO - 2020-07-28 17:26:54 --> Controller Class Initialized
INFO - 2020-07-28 17:26:54 --> Model Class Initialized
INFO - 2020-07-28 17:26:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:54 --> Config Class Initialized
INFO - 2020-07-28 17:26:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:54 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:54 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:54 --> Router Class Initialized
INFO - 2020-07-28 17:26:54 --> Output Class Initialized
INFO - 2020-07-28 17:26:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:54 --> Input Class Initialized
INFO - 2020-07-28 17:26:54 --> Language Class Initialized
INFO - 2020-07-28 17:26:54 --> Loader Class Initialized
INFO - 2020-07-28 17:26:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:54 --> Email Class Initialized
INFO - 2020-07-28 17:26:54 --> Controller Class Initialized
INFO - 2020-07-28 17:26:54 --> Model Class Initialized
INFO - 2020-07-28 17:26:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:54 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:54 --> Total execution time: 0.0239
INFO - 2020-07-28 17:26:55 --> Config Class Initialized
INFO - 2020-07-28 17:26:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:55 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:55 --> URI Class Initialized
INFO - 2020-07-28 17:26:55 --> Router Class Initialized
INFO - 2020-07-28 17:26:55 --> Output Class Initialized
INFO - 2020-07-28 17:26:55 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:55 --> Input Class Initialized
INFO - 2020-07-28 17:26:55 --> Language Class Initialized
INFO - 2020-07-28 17:26:55 --> Loader Class Initialized
INFO - 2020-07-28 17:26:55 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:55 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:55 --> Email Class Initialized
INFO - 2020-07-28 17:26:55 --> Controller Class Initialized
INFO - 2020-07-28 17:26:55 --> Model Class Initialized
INFO - 2020-07-28 17:26:55 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:55 --> Config Class Initialized
INFO - 2020-07-28 17:26:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:55 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:55 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:55 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:55 --> Router Class Initialized
INFO - 2020-07-28 17:26:55 --> Output Class Initialized
INFO - 2020-07-28 17:26:55 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:55 --> Input Class Initialized
INFO - 2020-07-28 17:26:55 --> Language Class Initialized
INFO - 2020-07-28 17:26:55 --> Loader Class Initialized
INFO - 2020-07-28 17:26:55 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:55 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:55 --> Email Class Initialized
INFO - 2020-07-28 17:26:55 --> Controller Class Initialized
INFO - 2020-07-28 17:26:55 --> Model Class Initialized
INFO - 2020-07-28 17:26:55 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:55 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:55 --> Total execution time: 0.0231
INFO - 2020-07-28 17:26:56 --> Config Class Initialized
INFO - 2020-07-28 17:26:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:56 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:56 --> URI Class Initialized
INFO - 2020-07-28 17:26:56 --> Router Class Initialized
INFO - 2020-07-28 17:26:56 --> Output Class Initialized
INFO - 2020-07-28 17:26:56 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:56 --> Input Class Initialized
INFO - 2020-07-28 17:26:56 --> Language Class Initialized
INFO - 2020-07-28 17:26:56 --> Loader Class Initialized
INFO - 2020-07-28 17:26:56 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:56 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:56 --> Email Class Initialized
INFO - 2020-07-28 17:26:56 --> Controller Class Initialized
INFO - 2020-07-28 17:26:56 --> Model Class Initialized
INFO - 2020-07-28 17:26:56 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:57 --> Config Class Initialized
INFO - 2020-07-28 17:26:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:57 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:57 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:57 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:57 --> Router Class Initialized
INFO - 2020-07-28 17:26:57 --> Output Class Initialized
INFO - 2020-07-28 17:26:57 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:57 --> Input Class Initialized
INFO - 2020-07-28 17:26:57 --> Language Class Initialized
INFO - 2020-07-28 17:26:57 --> Loader Class Initialized
INFO - 2020-07-28 17:26:57 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:57 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:57 --> Email Class Initialized
INFO - 2020-07-28 17:26:57 --> Controller Class Initialized
INFO - 2020-07-28 17:26:57 --> Model Class Initialized
INFO - 2020-07-28 17:26:57 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:57 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:57 --> Total execution time: 0.0391
INFO - 2020-07-28 17:26:57 --> Config Class Initialized
INFO - 2020-07-28 17:26:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:57 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:57 --> URI Class Initialized
INFO - 2020-07-28 17:26:57 --> Router Class Initialized
INFO - 2020-07-28 17:26:57 --> Output Class Initialized
INFO - 2020-07-28 17:26:57 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:57 --> Input Class Initialized
INFO - 2020-07-28 17:26:57 --> Language Class Initialized
INFO - 2020-07-28 17:26:57 --> Loader Class Initialized
INFO - 2020-07-28 17:26:57 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:57 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:57 --> Email Class Initialized
INFO - 2020-07-28 17:26:57 --> Controller Class Initialized
INFO - 2020-07-28 17:26:57 --> Model Class Initialized
INFO - 2020-07-28 17:26:57 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:58 --> Config Class Initialized
INFO - 2020-07-28 17:26:58 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:58 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:58 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:58 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:58 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:58 --> Router Class Initialized
INFO - 2020-07-28 17:26:58 --> Output Class Initialized
INFO - 2020-07-28 17:26:58 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:58 --> Input Class Initialized
INFO - 2020-07-28 17:26:58 --> Language Class Initialized
INFO - 2020-07-28 17:26:58 --> Loader Class Initialized
INFO - 2020-07-28 17:26:58 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:58 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:58 --> Email Class Initialized
INFO - 2020-07-28 17:26:58 --> Controller Class Initialized
INFO - 2020-07-28 17:26:58 --> Model Class Initialized
INFO - 2020-07-28 17:26:58 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:58 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:58 --> Total execution time: 0.0228
INFO - 2020-07-28 17:26:59 --> Config Class Initialized
INFO - 2020-07-28 17:26:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:59 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:59 --> URI Class Initialized
INFO - 2020-07-28 17:26:59 --> Router Class Initialized
INFO - 2020-07-28 17:26:59 --> Output Class Initialized
INFO - 2020-07-28 17:26:59 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:59 --> Input Class Initialized
INFO - 2020-07-28 17:26:59 --> Language Class Initialized
INFO - 2020-07-28 17:26:59 --> Loader Class Initialized
INFO - 2020-07-28 17:26:59 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:59 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:59 --> Email Class Initialized
INFO - 2020-07-28 17:26:59 --> Controller Class Initialized
INFO - 2020-07-28 17:26:59 --> Model Class Initialized
INFO - 2020-07-28 17:26:59 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:59 --> Config Class Initialized
INFO - 2020-07-28 17:26:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:26:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:26:59 --> Utf8 Class Initialized
INFO - 2020-07-28 17:26:59 --> URI Class Initialized
DEBUG - 2020-07-28 17:26:59 --> No URI present. Default controller set.
INFO - 2020-07-28 17:26:59 --> Router Class Initialized
INFO - 2020-07-28 17:26:59 --> Output Class Initialized
INFO - 2020-07-28 17:26:59 --> Security Class Initialized
DEBUG - 2020-07-28 17:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:26:59 --> Input Class Initialized
INFO - 2020-07-28 17:26:59 --> Language Class Initialized
INFO - 2020-07-28 17:26:59 --> Loader Class Initialized
INFO - 2020-07-28 17:26:59 --> Helper loaded: url_helper
INFO - 2020-07-28 17:26:59 --> Database Driver Class Initialized
INFO - 2020-07-28 17:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:26:59 --> Email Class Initialized
INFO - 2020-07-28 17:26:59 --> Controller Class Initialized
INFO - 2020-07-28 17:26:59 --> Model Class Initialized
INFO - 2020-07-28 17:26:59 --> Model Class Initialized
DEBUG - 2020-07-28 17:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:26:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:26:59 --> Final output sent to browser
DEBUG - 2020-07-28 17:26:59 --> Total execution time: 0.0330
INFO - 2020-07-28 17:27:00 --> Config Class Initialized
INFO - 2020-07-28 17:27:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:00 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:00 --> URI Class Initialized
INFO - 2020-07-28 17:27:00 --> Router Class Initialized
INFO - 2020-07-28 17:27:00 --> Output Class Initialized
INFO - 2020-07-28 17:27:00 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:00 --> Input Class Initialized
INFO - 2020-07-28 17:27:00 --> Language Class Initialized
INFO - 2020-07-28 17:27:00 --> Loader Class Initialized
INFO - 2020-07-28 17:27:00 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:00 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:00 --> Email Class Initialized
INFO - 2020-07-28 17:27:00 --> Controller Class Initialized
INFO - 2020-07-28 17:27:00 --> Model Class Initialized
INFO - 2020-07-28 17:27:00 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:00 --> Config Class Initialized
INFO - 2020-07-28 17:27:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:00 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:00 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:00 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:00 --> Router Class Initialized
INFO - 2020-07-28 17:27:00 --> Output Class Initialized
INFO - 2020-07-28 17:27:00 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:00 --> Input Class Initialized
INFO - 2020-07-28 17:27:00 --> Language Class Initialized
INFO - 2020-07-28 17:27:00 --> Loader Class Initialized
INFO - 2020-07-28 17:27:00 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:00 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:00 --> Email Class Initialized
INFO - 2020-07-28 17:27:00 --> Controller Class Initialized
INFO - 2020-07-28 17:27:00 --> Model Class Initialized
INFO - 2020-07-28 17:27:00 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:00 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:00 --> Total execution time: 0.0250
INFO - 2020-07-28 17:27:01 --> Config Class Initialized
INFO - 2020-07-28 17:27:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:01 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:01 --> URI Class Initialized
INFO - 2020-07-28 17:27:01 --> Router Class Initialized
INFO - 2020-07-28 17:27:01 --> Output Class Initialized
INFO - 2020-07-28 17:27:01 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:01 --> Input Class Initialized
INFO - 2020-07-28 17:27:01 --> Language Class Initialized
INFO - 2020-07-28 17:27:01 --> Loader Class Initialized
INFO - 2020-07-28 17:27:01 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:01 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:01 --> Email Class Initialized
INFO - 2020-07-28 17:27:01 --> Controller Class Initialized
INFO - 2020-07-28 17:27:01 --> Model Class Initialized
INFO - 2020-07-28 17:27:01 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:01 --> Config Class Initialized
INFO - 2020-07-28 17:27:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:01 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:01 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:01 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:01 --> Router Class Initialized
INFO - 2020-07-28 17:27:01 --> Output Class Initialized
INFO - 2020-07-28 17:27:01 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:01 --> Input Class Initialized
INFO - 2020-07-28 17:27:01 --> Language Class Initialized
INFO - 2020-07-28 17:27:01 --> Loader Class Initialized
INFO - 2020-07-28 17:27:01 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:01 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:01 --> Email Class Initialized
INFO - 2020-07-28 17:27:01 --> Controller Class Initialized
INFO - 2020-07-28 17:27:01 --> Model Class Initialized
INFO - 2020-07-28 17:27:01 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:01 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:01 --> Total execution time: 0.0219
INFO - 2020-07-28 17:27:02 --> Config Class Initialized
INFO - 2020-07-28 17:27:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:02 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:02 --> URI Class Initialized
INFO - 2020-07-28 17:27:02 --> Router Class Initialized
INFO - 2020-07-28 17:27:02 --> Output Class Initialized
INFO - 2020-07-28 17:27:02 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:02 --> Input Class Initialized
INFO - 2020-07-28 17:27:02 --> Language Class Initialized
INFO - 2020-07-28 17:27:02 --> Loader Class Initialized
INFO - 2020-07-28 17:27:02 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:02 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:02 --> Email Class Initialized
INFO - 2020-07-28 17:27:02 --> Controller Class Initialized
INFO - 2020-07-28 17:27:02 --> Model Class Initialized
INFO - 2020-07-28 17:27:02 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:02 --> Config Class Initialized
INFO - 2020-07-28 17:27:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:02 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:02 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:02 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:02 --> Router Class Initialized
INFO - 2020-07-28 17:27:02 --> Output Class Initialized
INFO - 2020-07-28 17:27:02 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:02 --> Input Class Initialized
INFO - 2020-07-28 17:27:02 --> Language Class Initialized
INFO - 2020-07-28 17:27:02 --> Loader Class Initialized
INFO - 2020-07-28 17:27:02 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:02 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:02 --> Email Class Initialized
INFO - 2020-07-28 17:27:02 --> Controller Class Initialized
INFO - 2020-07-28 17:27:02 --> Model Class Initialized
INFO - 2020-07-28 17:27:02 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:02 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:02 --> Total execution time: 0.0238
INFO - 2020-07-28 17:27:03 --> Config Class Initialized
INFO - 2020-07-28 17:27:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:03 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:03 --> URI Class Initialized
INFO - 2020-07-28 17:27:03 --> Router Class Initialized
INFO - 2020-07-28 17:27:03 --> Output Class Initialized
INFO - 2020-07-28 17:27:03 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:03 --> Input Class Initialized
INFO - 2020-07-28 17:27:03 --> Language Class Initialized
INFO - 2020-07-28 17:27:03 --> Loader Class Initialized
INFO - 2020-07-28 17:27:03 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:03 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:03 --> Email Class Initialized
INFO - 2020-07-28 17:27:03 --> Controller Class Initialized
INFO - 2020-07-28 17:27:03 --> Model Class Initialized
INFO - 2020-07-28 17:27:03 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:03 --> Config Class Initialized
INFO - 2020-07-28 17:27:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:03 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:03 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:03 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:03 --> Router Class Initialized
INFO - 2020-07-28 17:27:03 --> Output Class Initialized
INFO - 2020-07-28 17:27:03 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:03 --> Input Class Initialized
INFO - 2020-07-28 17:27:03 --> Language Class Initialized
INFO - 2020-07-28 17:27:03 --> Loader Class Initialized
INFO - 2020-07-28 17:27:03 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:03 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:03 --> Email Class Initialized
INFO - 2020-07-28 17:27:03 --> Controller Class Initialized
INFO - 2020-07-28 17:27:03 --> Model Class Initialized
INFO - 2020-07-28 17:27:03 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:03 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:03 --> Total execution time: 0.0333
INFO - 2020-07-28 17:27:04 --> Config Class Initialized
INFO - 2020-07-28 17:27:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:04 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:04 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:04 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:04 --> Router Class Initialized
INFO - 2020-07-28 17:27:04 --> Output Class Initialized
INFO - 2020-07-28 17:27:04 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:04 --> Input Class Initialized
INFO - 2020-07-28 17:27:04 --> Language Class Initialized
INFO - 2020-07-28 17:27:04 --> Loader Class Initialized
INFO - 2020-07-28 17:27:04 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:04 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:04 --> Email Class Initialized
INFO - 2020-07-28 17:27:04 --> Controller Class Initialized
INFO - 2020-07-28 17:27:04 --> Model Class Initialized
INFO - 2020-07-28 17:27:04 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:04 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:04 --> Total execution time: 0.0221
INFO - 2020-07-28 17:27:05 --> Config Class Initialized
INFO - 2020-07-28 17:27:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:05 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:05 --> URI Class Initialized
INFO - 2020-07-28 17:27:05 --> Router Class Initialized
INFO - 2020-07-28 17:27:05 --> Output Class Initialized
INFO - 2020-07-28 17:27:05 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:05 --> Input Class Initialized
INFO - 2020-07-28 17:27:05 --> Language Class Initialized
INFO - 2020-07-28 17:27:05 --> Loader Class Initialized
INFO - 2020-07-28 17:27:05 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:05 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:05 --> Email Class Initialized
INFO - 2020-07-28 17:27:05 --> Controller Class Initialized
INFO - 2020-07-28 17:27:05 --> Model Class Initialized
INFO - 2020-07-28 17:27:05 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:05 --> Config Class Initialized
INFO - 2020-07-28 17:27:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:05 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:05 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:05 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:05 --> Router Class Initialized
INFO - 2020-07-28 17:27:05 --> Output Class Initialized
INFO - 2020-07-28 17:27:05 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:05 --> Input Class Initialized
INFO - 2020-07-28 17:27:05 --> Language Class Initialized
INFO - 2020-07-28 17:27:05 --> Loader Class Initialized
INFO - 2020-07-28 17:27:05 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:05 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:05 --> Email Class Initialized
INFO - 2020-07-28 17:27:05 --> Controller Class Initialized
INFO - 2020-07-28 17:27:05 --> Model Class Initialized
INFO - 2020-07-28 17:27:05 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:05 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:05 --> Total execution time: 0.0205
INFO - 2020-07-28 17:27:06 --> Config Class Initialized
INFO - 2020-07-28 17:27:06 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:06 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:06 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:06 --> URI Class Initialized
INFO - 2020-07-28 17:27:06 --> Router Class Initialized
INFO - 2020-07-28 17:27:06 --> Output Class Initialized
INFO - 2020-07-28 17:27:06 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:06 --> Input Class Initialized
INFO - 2020-07-28 17:27:06 --> Language Class Initialized
INFO - 2020-07-28 17:27:06 --> Loader Class Initialized
INFO - 2020-07-28 17:27:06 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:06 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:06 --> Email Class Initialized
INFO - 2020-07-28 17:27:06 --> Controller Class Initialized
INFO - 2020-07-28 17:27:06 --> Model Class Initialized
INFO - 2020-07-28 17:27:06 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:06 --> Config Class Initialized
INFO - 2020-07-28 17:27:06 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:06 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:06 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:06 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:06 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:06 --> Router Class Initialized
INFO - 2020-07-28 17:27:06 --> Output Class Initialized
INFO - 2020-07-28 17:27:06 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:06 --> Input Class Initialized
INFO - 2020-07-28 17:27:06 --> Language Class Initialized
INFO - 2020-07-28 17:27:06 --> Loader Class Initialized
INFO - 2020-07-28 17:27:06 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:06 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:06 --> Email Class Initialized
INFO - 2020-07-28 17:27:06 --> Controller Class Initialized
INFO - 2020-07-28 17:27:06 --> Model Class Initialized
INFO - 2020-07-28 17:27:06 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:06 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:06 --> Total execution time: 0.0214
INFO - 2020-07-28 17:27:07 --> Config Class Initialized
INFO - 2020-07-28 17:27:07 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:07 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:07 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:07 --> URI Class Initialized
INFO - 2020-07-28 17:27:07 --> Router Class Initialized
INFO - 2020-07-28 17:27:07 --> Output Class Initialized
INFO - 2020-07-28 17:27:07 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:07 --> Input Class Initialized
INFO - 2020-07-28 17:27:07 --> Language Class Initialized
INFO - 2020-07-28 17:27:07 --> Loader Class Initialized
INFO - 2020-07-28 17:27:07 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:07 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:07 --> Email Class Initialized
INFO - 2020-07-28 17:27:07 --> Controller Class Initialized
INFO - 2020-07-28 17:27:07 --> Model Class Initialized
INFO - 2020-07-28 17:27:07 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:08 --> Config Class Initialized
INFO - 2020-07-28 17:27:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:08 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:08 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:08 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:08 --> Router Class Initialized
INFO - 2020-07-28 17:27:08 --> Output Class Initialized
INFO - 2020-07-28 17:27:08 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:08 --> Input Class Initialized
INFO - 2020-07-28 17:27:08 --> Language Class Initialized
INFO - 2020-07-28 17:27:08 --> Loader Class Initialized
INFO - 2020-07-28 17:27:08 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:08 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:08 --> Email Class Initialized
INFO - 2020-07-28 17:27:08 --> Controller Class Initialized
INFO - 2020-07-28 17:27:08 --> Model Class Initialized
INFO - 2020-07-28 17:27:08 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:08 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:08 --> Total execution time: 0.0215
INFO - 2020-07-28 17:27:08 --> Config Class Initialized
INFO - 2020-07-28 17:27:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:08 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:08 --> URI Class Initialized
INFO - 2020-07-28 17:27:08 --> Router Class Initialized
INFO - 2020-07-28 17:27:08 --> Output Class Initialized
INFO - 2020-07-28 17:27:08 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:08 --> Input Class Initialized
INFO - 2020-07-28 17:27:08 --> Language Class Initialized
INFO - 2020-07-28 17:27:08 --> Loader Class Initialized
INFO - 2020-07-28 17:27:08 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:08 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:08 --> Email Class Initialized
INFO - 2020-07-28 17:27:08 --> Controller Class Initialized
INFO - 2020-07-28 17:27:08 --> Model Class Initialized
INFO - 2020-07-28 17:27:08 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:09 --> Config Class Initialized
INFO - 2020-07-28 17:27:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:09 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:09 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:09 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:09 --> Router Class Initialized
INFO - 2020-07-28 17:27:09 --> Output Class Initialized
INFO - 2020-07-28 17:27:09 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:09 --> Input Class Initialized
INFO - 2020-07-28 17:27:09 --> Language Class Initialized
INFO - 2020-07-28 17:27:09 --> Loader Class Initialized
INFO - 2020-07-28 17:27:09 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:09 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:09 --> Email Class Initialized
INFO - 2020-07-28 17:27:09 --> Controller Class Initialized
INFO - 2020-07-28 17:27:09 --> Model Class Initialized
INFO - 2020-07-28 17:27:09 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:09 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:09 --> Total execution time: 0.0233
INFO - 2020-07-28 17:27:09 --> Config Class Initialized
INFO - 2020-07-28 17:27:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:09 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:09 --> URI Class Initialized
INFO - 2020-07-28 17:27:09 --> Router Class Initialized
INFO - 2020-07-28 17:27:09 --> Output Class Initialized
INFO - 2020-07-28 17:27:09 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:09 --> Input Class Initialized
INFO - 2020-07-28 17:27:09 --> Language Class Initialized
INFO - 2020-07-28 17:27:09 --> Loader Class Initialized
INFO - 2020-07-28 17:27:09 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:09 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:09 --> Email Class Initialized
INFO - 2020-07-28 17:27:09 --> Controller Class Initialized
INFO - 2020-07-28 17:27:09 --> Model Class Initialized
INFO - 2020-07-28 17:27:09 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:10 --> Config Class Initialized
INFO - 2020-07-28 17:27:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:10 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:10 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:10 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:10 --> Router Class Initialized
INFO - 2020-07-28 17:27:10 --> Output Class Initialized
INFO - 2020-07-28 17:27:10 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:10 --> Input Class Initialized
INFO - 2020-07-28 17:27:10 --> Language Class Initialized
INFO - 2020-07-28 17:27:10 --> Loader Class Initialized
INFO - 2020-07-28 17:27:10 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:10 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:10 --> Email Class Initialized
INFO - 2020-07-28 17:27:10 --> Controller Class Initialized
INFO - 2020-07-28 17:27:10 --> Model Class Initialized
INFO - 2020-07-28 17:27:10 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:10 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:10 --> Total execution time: 0.0193
INFO - 2020-07-28 17:27:22 --> Config Class Initialized
INFO - 2020-07-28 17:27:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:22 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:22 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:22 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:22 --> Router Class Initialized
INFO - 2020-07-28 17:27:22 --> Output Class Initialized
INFO - 2020-07-28 17:27:22 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:22 --> Input Class Initialized
INFO - 2020-07-28 17:27:22 --> Language Class Initialized
INFO - 2020-07-28 17:27:22 --> Loader Class Initialized
INFO - 2020-07-28 17:27:22 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:22 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:22 --> Email Class Initialized
INFO - 2020-07-28 17:27:22 --> Controller Class Initialized
INFO - 2020-07-28 17:27:22 --> Model Class Initialized
INFO - 2020-07-28 17:27:22 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:22 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:22 --> Total execution time: 0.0347
INFO - 2020-07-28 17:27:22 --> Config Class Initialized
INFO - 2020-07-28 17:27:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:22 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:22 --> URI Class Initialized
INFO - 2020-07-28 17:27:22 --> Router Class Initialized
INFO - 2020-07-28 17:27:22 --> Output Class Initialized
INFO - 2020-07-28 17:27:22 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:22 --> Input Class Initialized
INFO - 2020-07-28 17:27:22 --> Language Class Initialized
INFO - 2020-07-28 17:27:22 --> Loader Class Initialized
INFO - 2020-07-28 17:27:22 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:22 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:22 --> Email Class Initialized
INFO - 2020-07-28 17:27:22 --> Controller Class Initialized
INFO - 2020-07-28 17:27:22 --> Model Class Initialized
INFO - 2020-07-28 17:27:22 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:23 --> Config Class Initialized
INFO - 2020-07-28 17:27:23 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:23 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:23 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:23 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:23 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:23 --> Router Class Initialized
INFO - 2020-07-28 17:27:23 --> Output Class Initialized
INFO - 2020-07-28 17:27:23 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:23 --> Input Class Initialized
INFO - 2020-07-28 17:27:23 --> Language Class Initialized
INFO - 2020-07-28 17:27:23 --> Loader Class Initialized
INFO - 2020-07-28 17:27:23 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:23 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:23 --> Email Class Initialized
INFO - 2020-07-28 17:27:23 --> Controller Class Initialized
INFO - 2020-07-28 17:27:23 --> Model Class Initialized
INFO - 2020-07-28 17:27:23 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:23 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:23 --> Total execution time: 0.0254
INFO - 2020-07-28 17:27:24 --> Config Class Initialized
INFO - 2020-07-28 17:27:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:24 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:24 --> URI Class Initialized
INFO - 2020-07-28 17:27:24 --> Router Class Initialized
INFO - 2020-07-28 17:27:24 --> Output Class Initialized
INFO - 2020-07-28 17:27:24 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:24 --> Input Class Initialized
INFO - 2020-07-28 17:27:24 --> Language Class Initialized
INFO - 2020-07-28 17:27:24 --> Loader Class Initialized
INFO - 2020-07-28 17:27:24 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:24 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:24 --> Email Class Initialized
INFO - 2020-07-28 17:27:24 --> Controller Class Initialized
INFO - 2020-07-28 17:27:24 --> Model Class Initialized
INFO - 2020-07-28 17:27:24 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:24 --> Config Class Initialized
INFO - 2020-07-28 17:27:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:24 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:24 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:24 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:24 --> Router Class Initialized
INFO - 2020-07-28 17:27:24 --> Output Class Initialized
INFO - 2020-07-28 17:27:24 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:24 --> Input Class Initialized
INFO - 2020-07-28 17:27:24 --> Language Class Initialized
INFO - 2020-07-28 17:27:24 --> Loader Class Initialized
INFO - 2020-07-28 17:27:24 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:24 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:24 --> Email Class Initialized
INFO - 2020-07-28 17:27:24 --> Controller Class Initialized
INFO - 2020-07-28 17:27:24 --> Model Class Initialized
INFO - 2020-07-28 17:27:24 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:24 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:24 --> Total execution time: 0.0258
INFO - 2020-07-28 17:27:25 --> Config Class Initialized
INFO - 2020-07-28 17:27:25 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:25 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:25 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:25 --> URI Class Initialized
INFO - 2020-07-28 17:27:25 --> Router Class Initialized
INFO - 2020-07-28 17:27:25 --> Output Class Initialized
INFO - 2020-07-28 17:27:25 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:25 --> Input Class Initialized
INFO - 2020-07-28 17:27:25 --> Language Class Initialized
INFO - 2020-07-28 17:27:25 --> Loader Class Initialized
INFO - 2020-07-28 17:27:25 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:25 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:25 --> Email Class Initialized
INFO - 2020-07-28 17:27:25 --> Controller Class Initialized
INFO - 2020-07-28 17:27:25 --> Model Class Initialized
INFO - 2020-07-28 17:27:25 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:25 --> Config Class Initialized
INFO - 2020-07-28 17:27:25 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:25 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:25 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:25 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:25 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:25 --> Router Class Initialized
INFO - 2020-07-28 17:27:25 --> Output Class Initialized
INFO - 2020-07-28 17:27:25 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:25 --> Input Class Initialized
INFO - 2020-07-28 17:27:25 --> Language Class Initialized
INFO - 2020-07-28 17:27:25 --> Loader Class Initialized
INFO - 2020-07-28 17:27:25 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:25 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:25 --> Email Class Initialized
INFO - 2020-07-28 17:27:25 --> Controller Class Initialized
INFO - 2020-07-28 17:27:25 --> Model Class Initialized
INFO - 2020-07-28 17:27:25 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:25 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:25 --> Total execution time: 0.0239
INFO - 2020-07-28 17:27:26 --> Config Class Initialized
INFO - 2020-07-28 17:27:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:26 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:26 --> URI Class Initialized
INFO - 2020-07-28 17:27:26 --> Router Class Initialized
INFO - 2020-07-28 17:27:26 --> Output Class Initialized
INFO - 2020-07-28 17:27:26 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:26 --> Input Class Initialized
INFO - 2020-07-28 17:27:26 --> Language Class Initialized
INFO - 2020-07-28 17:27:26 --> Loader Class Initialized
INFO - 2020-07-28 17:27:26 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:26 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:26 --> Email Class Initialized
INFO - 2020-07-28 17:27:26 --> Controller Class Initialized
INFO - 2020-07-28 17:27:26 --> Model Class Initialized
INFO - 2020-07-28 17:27:26 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:26 --> Config Class Initialized
INFO - 2020-07-28 17:27:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:26 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:26 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:26 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:26 --> Router Class Initialized
INFO - 2020-07-28 17:27:26 --> Output Class Initialized
INFO - 2020-07-28 17:27:26 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:26 --> Input Class Initialized
INFO - 2020-07-28 17:27:26 --> Language Class Initialized
INFO - 2020-07-28 17:27:26 --> Loader Class Initialized
INFO - 2020-07-28 17:27:26 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:26 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:26 --> Email Class Initialized
INFO - 2020-07-28 17:27:26 --> Controller Class Initialized
INFO - 2020-07-28 17:27:26 --> Model Class Initialized
INFO - 2020-07-28 17:27:26 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:26 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:26 --> Total execution time: 0.0233
INFO - 2020-07-28 17:27:27 --> Config Class Initialized
INFO - 2020-07-28 17:27:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:27 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:27 --> URI Class Initialized
INFO - 2020-07-28 17:27:27 --> Router Class Initialized
INFO - 2020-07-28 17:27:27 --> Output Class Initialized
INFO - 2020-07-28 17:27:27 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:27 --> Input Class Initialized
INFO - 2020-07-28 17:27:27 --> Language Class Initialized
INFO - 2020-07-28 17:27:27 --> Loader Class Initialized
INFO - 2020-07-28 17:27:27 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:27 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:27 --> Email Class Initialized
INFO - 2020-07-28 17:27:27 --> Controller Class Initialized
INFO - 2020-07-28 17:27:27 --> Model Class Initialized
INFO - 2020-07-28 17:27:27 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:28 --> Config Class Initialized
INFO - 2020-07-28 17:27:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:28 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:28 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:28 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:28 --> Router Class Initialized
INFO - 2020-07-28 17:27:28 --> Output Class Initialized
INFO - 2020-07-28 17:27:28 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:28 --> Input Class Initialized
INFO - 2020-07-28 17:27:28 --> Language Class Initialized
INFO - 2020-07-28 17:27:28 --> Loader Class Initialized
INFO - 2020-07-28 17:27:28 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:28 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:28 --> Email Class Initialized
INFO - 2020-07-28 17:27:28 --> Controller Class Initialized
INFO - 2020-07-28 17:27:28 --> Model Class Initialized
INFO - 2020-07-28 17:27:28 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:28 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:28 --> Total execution time: 0.0234
INFO - 2020-07-28 17:27:28 --> Config Class Initialized
INFO - 2020-07-28 17:27:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:28 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:28 --> URI Class Initialized
INFO - 2020-07-28 17:27:28 --> Router Class Initialized
INFO - 2020-07-28 17:27:28 --> Output Class Initialized
INFO - 2020-07-28 17:27:28 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:28 --> Input Class Initialized
INFO - 2020-07-28 17:27:28 --> Language Class Initialized
INFO - 2020-07-28 17:27:28 --> Loader Class Initialized
INFO - 2020-07-28 17:27:28 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:28 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:28 --> Email Class Initialized
INFO - 2020-07-28 17:27:28 --> Controller Class Initialized
INFO - 2020-07-28 17:27:28 --> Model Class Initialized
INFO - 2020-07-28 17:27:28 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:29 --> Config Class Initialized
INFO - 2020-07-28 17:27:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:29 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:29 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:29 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:29 --> Router Class Initialized
INFO - 2020-07-28 17:27:29 --> Output Class Initialized
INFO - 2020-07-28 17:27:29 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:29 --> Input Class Initialized
INFO - 2020-07-28 17:27:29 --> Language Class Initialized
INFO - 2020-07-28 17:27:29 --> Loader Class Initialized
INFO - 2020-07-28 17:27:29 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:29 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:29 --> Email Class Initialized
INFO - 2020-07-28 17:27:29 --> Controller Class Initialized
INFO - 2020-07-28 17:27:29 --> Model Class Initialized
INFO - 2020-07-28 17:27:29 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:29 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:29 --> Total execution time: 0.0238
INFO - 2020-07-28 17:27:30 --> Config Class Initialized
INFO - 2020-07-28 17:27:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:30 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:30 --> URI Class Initialized
INFO - 2020-07-28 17:27:30 --> Router Class Initialized
INFO - 2020-07-28 17:27:30 --> Output Class Initialized
INFO - 2020-07-28 17:27:30 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:30 --> Input Class Initialized
INFO - 2020-07-28 17:27:30 --> Language Class Initialized
INFO - 2020-07-28 17:27:30 --> Loader Class Initialized
INFO - 2020-07-28 17:27:30 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:30 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:30 --> Email Class Initialized
INFO - 2020-07-28 17:27:30 --> Controller Class Initialized
INFO - 2020-07-28 17:27:30 --> Model Class Initialized
INFO - 2020-07-28 17:27:30 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:30 --> Config Class Initialized
INFO - 2020-07-28 17:27:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:30 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:30 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:30 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:30 --> Router Class Initialized
INFO - 2020-07-28 17:27:30 --> Output Class Initialized
INFO - 2020-07-28 17:27:30 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:30 --> Input Class Initialized
INFO - 2020-07-28 17:27:30 --> Language Class Initialized
INFO - 2020-07-28 17:27:30 --> Loader Class Initialized
INFO - 2020-07-28 17:27:30 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:30 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:30 --> Email Class Initialized
INFO - 2020-07-28 17:27:30 --> Controller Class Initialized
INFO - 2020-07-28 17:27:30 --> Model Class Initialized
INFO - 2020-07-28 17:27:30 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:30 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:30 --> Total execution time: 0.0243
INFO - 2020-07-28 17:27:31 --> Config Class Initialized
INFO - 2020-07-28 17:27:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:31 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:31 --> URI Class Initialized
INFO - 2020-07-28 17:27:31 --> Router Class Initialized
INFO - 2020-07-28 17:27:31 --> Output Class Initialized
INFO - 2020-07-28 17:27:31 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:31 --> Input Class Initialized
INFO - 2020-07-28 17:27:31 --> Language Class Initialized
INFO - 2020-07-28 17:27:31 --> Loader Class Initialized
INFO - 2020-07-28 17:27:31 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:31 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:31 --> Email Class Initialized
INFO - 2020-07-28 17:27:31 --> Controller Class Initialized
INFO - 2020-07-28 17:27:31 --> Model Class Initialized
INFO - 2020-07-28 17:27:31 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:32 --> Config Class Initialized
INFO - 2020-07-28 17:27:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:32 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:32 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:32 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:32 --> Router Class Initialized
INFO - 2020-07-28 17:27:32 --> Output Class Initialized
INFO - 2020-07-28 17:27:32 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:32 --> Input Class Initialized
INFO - 2020-07-28 17:27:32 --> Language Class Initialized
INFO - 2020-07-28 17:27:32 --> Loader Class Initialized
INFO - 2020-07-28 17:27:32 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:32 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:32 --> Email Class Initialized
INFO - 2020-07-28 17:27:32 --> Controller Class Initialized
INFO - 2020-07-28 17:27:32 --> Model Class Initialized
INFO - 2020-07-28 17:27:32 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:32 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:32 --> Total execution time: 0.0193
INFO - 2020-07-28 17:27:32 --> Config Class Initialized
INFO - 2020-07-28 17:27:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:32 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:32 --> URI Class Initialized
INFO - 2020-07-28 17:27:32 --> Router Class Initialized
INFO - 2020-07-28 17:27:32 --> Output Class Initialized
INFO - 2020-07-28 17:27:32 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:32 --> Input Class Initialized
INFO - 2020-07-28 17:27:32 --> Language Class Initialized
INFO - 2020-07-28 17:27:32 --> Loader Class Initialized
INFO - 2020-07-28 17:27:32 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:32 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:32 --> Email Class Initialized
INFO - 2020-07-28 17:27:32 --> Controller Class Initialized
INFO - 2020-07-28 17:27:32 --> Model Class Initialized
INFO - 2020-07-28 17:27:32 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:33 --> Config Class Initialized
INFO - 2020-07-28 17:27:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:33 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:33 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:33 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:33 --> Router Class Initialized
INFO - 2020-07-28 17:27:33 --> Output Class Initialized
INFO - 2020-07-28 17:27:33 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:33 --> Input Class Initialized
INFO - 2020-07-28 17:27:33 --> Language Class Initialized
INFO - 2020-07-28 17:27:33 --> Loader Class Initialized
INFO - 2020-07-28 17:27:33 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:33 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:33 --> Email Class Initialized
INFO - 2020-07-28 17:27:33 --> Controller Class Initialized
INFO - 2020-07-28 17:27:33 --> Model Class Initialized
INFO - 2020-07-28 17:27:33 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:33 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:33 --> Total execution time: 0.0215
INFO - 2020-07-28 17:27:33 --> Config Class Initialized
INFO - 2020-07-28 17:27:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:33 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:33 --> URI Class Initialized
INFO - 2020-07-28 17:27:33 --> Router Class Initialized
INFO - 2020-07-28 17:27:33 --> Output Class Initialized
INFO - 2020-07-28 17:27:33 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:33 --> Input Class Initialized
INFO - 2020-07-28 17:27:33 --> Language Class Initialized
INFO - 2020-07-28 17:27:33 --> Loader Class Initialized
INFO - 2020-07-28 17:27:33 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:33 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:33 --> Email Class Initialized
INFO - 2020-07-28 17:27:33 --> Controller Class Initialized
INFO - 2020-07-28 17:27:33 --> Model Class Initialized
INFO - 2020-07-28 17:27:33 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:34 --> Config Class Initialized
INFO - 2020-07-28 17:27:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:34 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:34 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:34 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:34 --> Router Class Initialized
INFO - 2020-07-28 17:27:34 --> Output Class Initialized
INFO - 2020-07-28 17:27:34 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:34 --> Input Class Initialized
INFO - 2020-07-28 17:27:34 --> Language Class Initialized
INFO - 2020-07-28 17:27:34 --> Loader Class Initialized
INFO - 2020-07-28 17:27:34 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:34 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:34 --> Email Class Initialized
INFO - 2020-07-28 17:27:34 --> Controller Class Initialized
INFO - 2020-07-28 17:27:34 --> Model Class Initialized
INFO - 2020-07-28 17:27:34 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:34 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:34 --> Total execution time: 0.0256
INFO - 2020-07-28 17:27:34 --> Config Class Initialized
INFO - 2020-07-28 17:27:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:34 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:34 --> URI Class Initialized
INFO - 2020-07-28 17:27:34 --> Router Class Initialized
INFO - 2020-07-28 17:27:34 --> Output Class Initialized
INFO - 2020-07-28 17:27:34 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:34 --> Input Class Initialized
INFO - 2020-07-28 17:27:34 --> Language Class Initialized
INFO - 2020-07-28 17:27:34 --> Loader Class Initialized
INFO - 2020-07-28 17:27:34 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:34 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:34 --> Email Class Initialized
INFO - 2020-07-28 17:27:34 --> Controller Class Initialized
INFO - 2020-07-28 17:27:34 --> Model Class Initialized
INFO - 2020-07-28 17:27:34 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:35 --> Config Class Initialized
INFO - 2020-07-28 17:27:35 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:35 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:35 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:35 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:35 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:35 --> Router Class Initialized
INFO - 2020-07-28 17:27:35 --> Output Class Initialized
INFO - 2020-07-28 17:27:35 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:35 --> Input Class Initialized
INFO - 2020-07-28 17:27:35 --> Language Class Initialized
INFO - 2020-07-28 17:27:35 --> Loader Class Initialized
INFO - 2020-07-28 17:27:35 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:35 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:35 --> Email Class Initialized
INFO - 2020-07-28 17:27:35 --> Controller Class Initialized
INFO - 2020-07-28 17:27:35 --> Model Class Initialized
INFO - 2020-07-28 17:27:35 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:35 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:35 --> Total execution time: 0.0235
INFO - 2020-07-28 17:27:36 --> Config Class Initialized
INFO - 2020-07-28 17:27:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:36 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:36 --> URI Class Initialized
INFO - 2020-07-28 17:27:36 --> Router Class Initialized
INFO - 2020-07-28 17:27:36 --> Output Class Initialized
INFO - 2020-07-28 17:27:36 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:36 --> Input Class Initialized
INFO - 2020-07-28 17:27:36 --> Language Class Initialized
INFO - 2020-07-28 17:27:36 --> Loader Class Initialized
INFO - 2020-07-28 17:27:36 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:36 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:36 --> Email Class Initialized
INFO - 2020-07-28 17:27:36 --> Controller Class Initialized
INFO - 2020-07-28 17:27:36 --> Model Class Initialized
INFO - 2020-07-28 17:27:36 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:36 --> Config Class Initialized
INFO - 2020-07-28 17:27:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:36 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:36 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:36 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:36 --> Router Class Initialized
INFO - 2020-07-28 17:27:36 --> Output Class Initialized
INFO - 2020-07-28 17:27:36 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:36 --> Input Class Initialized
INFO - 2020-07-28 17:27:36 --> Language Class Initialized
INFO - 2020-07-28 17:27:36 --> Loader Class Initialized
INFO - 2020-07-28 17:27:36 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:36 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:36 --> Email Class Initialized
INFO - 2020-07-28 17:27:36 --> Controller Class Initialized
INFO - 2020-07-28 17:27:36 --> Model Class Initialized
INFO - 2020-07-28 17:27:36 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:36 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:36 --> Total execution time: 0.0201
INFO - 2020-07-28 17:27:37 --> Config Class Initialized
INFO - 2020-07-28 17:27:37 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:37 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:37 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:37 --> URI Class Initialized
INFO - 2020-07-28 17:27:37 --> Router Class Initialized
INFO - 2020-07-28 17:27:37 --> Output Class Initialized
INFO - 2020-07-28 17:27:37 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:37 --> Input Class Initialized
INFO - 2020-07-28 17:27:37 --> Language Class Initialized
INFO - 2020-07-28 17:27:37 --> Loader Class Initialized
INFO - 2020-07-28 17:27:37 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:37 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:37 --> Email Class Initialized
INFO - 2020-07-28 17:27:37 --> Controller Class Initialized
INFO - 2020-07-28 17:27:37 --> Model Class Initialized
INFO - 2020-07-28 17:27:37 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:37 --> Config Class Initialized
INFO - 2020-07-28 17:27:37 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:37 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:37 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:37 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:37 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:37 --> Router Class Initialized
INFO - 2020-07-28 17:27:37 --> Output Class Initialized
INFO - 2020-07-28 17:27:37 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:37 --> Input Class Initialized
INFO - 2020-07-28 17:27:37 --> Language Class Initialized
INFO - 2020-07-28 17:27:37 --> Loader Class Initialized
INFO - 2020-07-28 17:27:37 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:37 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:37 --> Email Class Initialized
INFO - 2020-07-28 17:27:37 --> Controller Class Initialized
INFO - 2020-07-28 17:27:37 --> Model Class Initialized
INFO - 2020-07-28 17:27:37 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:37 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:37 --> Total execution time: 0.0270
INFO - 2020-07-28 17:27:38 --> Config Class Initialized
INFO - 2020-07-28 17:27:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:38 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:38 --> URI Class Initialized
INFO - 2020-07-28 17:27:38 --> Router Class Initialized
INFO - 2020-07-28 17:27:38 --> Output Class Initialized
INFO - 2020-07-28 17:27:38 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:38 --> Input Class Initialized
INFO - 2020-07-28 17:27:38 --> Language Class Initialized
INFO - 2020-07-28 17:27:38 --> Loader Class Initialized
INFO - 2020-07-28 17:27:38 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:38 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:38 --> Email Class Initialized
INFO - 2020-07-28 17:27:38 --> Controller Class Initialized
INFO - 2020-07-28 17:27:38 --> Model Class Initialized
INFO - 2020-07-28 17:27:38 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:38 --> Config Class Initialized
INFO - 2020-07-28 17:27:38 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:38 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:38 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:38 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:38 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:38 --> Router Class Initialized
INFO - 2020-07-28 17:27:38 --> Output Class Initialized
INFO - 2020-07-28 17:27:38 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:38 --> Input Class Initialized
INFO - 2020-07-28 17:27:38 --> Language Class Initialized
INFO - 2020-07-28 17:27:38 --> Loader Class Initialized
INFO - 2020-07-28 17:27:38 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:38 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:38 --> Email Class Initialized
INFO - 2020-07-28 17:27:38 --> Controller Class Initialized
INFO - 2020-07-28 17:27:38 --> Model Class Initialized
INFO - 2020-07-28 17:27:38 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:38 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:38 --> Total execution time: 0.0227
INFO - 2020-07-28 17:27:39 --> Config Class Initialized
INFO - 2020-07-28 17:27:39 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:39 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:39 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:39 --> URI Class Initialized
INFO - 2020-07-28 17:27:39 --> Router Class Initialized
INFO - 2020-07-28 17:27:39 --> Output Class Initialized
INFO - 2020-07-28 17:27:39 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:39 --> Input Class Initialized
INFO - 2020-07-28 17:27:39 --> Language Class Initialized
INFO - 2020-07-28 17:27:39 --> Loader Class Initialized
INFO - 2020-07-28 17:27:39 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:39 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:39 --> Email Class Initialized
INFO - 2020-07-28 17:27:39 --> Controller Class Initialized
INFO - 2020-07-28 17:27:39 --> Model Class Initialized
INFO - 2020-07-28 17:27:39 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:40 --> Config Class Initialized
INFO - 2020-07-28 17:27:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:40 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:40 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:40 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:40 --> Router Class Initialized
INFO - 2020-07-28 17:27:40 --> Output Class Initialized
INFO - 2020-07-28 17:27:40 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:40 --> Input Class Initialized
INFO - 2020-07-28 17:27:40 --> Language Class Initialized
INFO - 2020-07-28 17:27:40 --> Loader Class Initialized
INFO - 2020-07-28 17:27:40 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:40 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:40 --> Email Class Initialized
INFO - 2020-07-28 17:27:40 --> Controller Class Initialized
INFO - 2020-07-28 17:27:40 --> Model Class Initialized
INFO - 2020-07-28 17:27:40 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:40 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:40 --> Total execution time: 0.0241
INFO - 2020-07-28 17:27:40 --> Config Class Initialized
INFO - 2020-07-28 17:27:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:40 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:40 --> URI Class Initialized
INFO - 2020-07-28 17:27:40 --> Router Class Initialized
INFO - 2020-07-28 17:27:40 --> Output Class Initialized
INFO - 2020-07-28 17:27:40 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:40 --> Input Class Initialized
INFO - 2020-07-28 17:27:40 --> Language Class Initialized
INFO - 2020-07-28 17:27:40 --> Loader Class Initialized
INFO - 2020-07-28 17:27:40 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:40 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:40 --> Email Class Initialized
INFO - 2020-07-28 17:27:40 --> Controller Class Initialized
INFO - 2020-07-28 17:27:40 --> Model Class Initialized
INFO - 2020-07-28 17:27:40 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:41 --> Config Class Initialized
INFO - 2020-07-28 17:27:41 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:41 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:41 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:41 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:41 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:41 --> Router Class Initialized
INFO - 2020-07-28 17:27:41 --> Output Class Initialized
INFO - 2020-07-28 17:27:41 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:41 --> Input Class Initialized
INFO - 2020-07-28 17:27:41 --> Language Class Initialized
INFO - 2020-07-28 17:27:41 --> Loader Class Initialized
INFO - 2020-07-28 17:27:41 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:41 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:41 --> Email Class Initialized
INFO - 2020-07-28 17:27:41 --> Controller Class Initialized
INFO - 2020-07-28 17:27:41 --> Model Class Initialized
INFO - 2020-07-28 17:27:41 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:41 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:41 --> Total execution time: 0.0229
INFO - 2020-07-28 17:27:41 --> Config Class Initialized
INFO - 2020-07-28 17:27:41 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:41 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:41 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:41 --> URI Class Initialized
INFO - 2020-07-28 17:27:41 --> Router Class Initialized
INFO - 2020-07-28 17:27:42 --> Output Class Initialized
INFO - 2020-07-28 17:27:42 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:42 --> Input Class Initialized
INFO - 2020-07-28 17:27:42 --> Language Class Initialized
INFO - 2020-07-28 17:27:42 --> Loader Class Initialized
INFO - 2020-07-28 17:27:42 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:42 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:42 --> Email Class Initialized
INFO - 2020-07-28 17:27:42 --> Controller Class Initialized
INFO - 2020-07-28 17:27:42 --> Model Class Initialized
INFO - 2020-07-28 17:27:42 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:42 --> Config Class Initialized
INFO - 2020-07-28 17:27:42 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:42 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:42 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:42 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:42 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:42 --> Router Class Initialized
INFO - 2020-07-28 17:27:42 --> Output Class Initialized
INFO - 2020-07-28 17:27:42 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:42 --> Input Class Initialized
INFO - 2020-07-28 17:27:42 --> Language Class Initialized
INFO - 2020-07-28 17:27:42 --> Loader Class Initialized
INFO - 2020-07-28 17:27:42 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:42 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:42 --> Email Class Initialized
INFO - 2020-07-28 17:27:42 --> Controller Class Initialized
INFO - 2020-07-28 17:27:42 --> Model Class Initialized
INFO - 2020-07-28 17:27:42 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:42 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:42 --> Total execution time: 0.0230
INFO - 2020-07-28 17:27:43 --> Config Class Initialized
INFO - 2020-07-28 17:27:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:43 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:43 --> URI Class Initialized
INFO - 2020-07-28 17:27:43 --> Router Class Initialized
INFO - 2020-07-28 17:27:43 --> Output Class Initialized
INFO - 2020-07-28 17:27:43 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:43 --> Input Class Initialized
INFO - 2020-07-28 17:27:43 --> Language Class Initialized
INFO - 2020-07-28 17:27:43 --> Loader Class Initialized
INFO - 2020-07-28 17:27:43 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:43 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:43 --> Email Class Initialized
INFO - 2020-07-28 17:27:43 --> Controller Class Initialized
INFO - 2020-07-28 17:27:43 --> Model Class Initialized
INFO - 2020-07-28 17:27:43 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:43 --> Config Class Initialized
INFO - 2020-07-28 17:27:43 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:43 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:43 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:43 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:43 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:43 --> Router Class Initialized
INFO - 2020-07-28 17:27:43 --> Output Class Initialized
INFO - 2020-07-28 17:27:43 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:43 --> Input Class Initialized
INFO - 2020-07-28 17:27:43 --> Language Class Initialized
INFO - 2020-07-28 17:27:43 --> Loader Class Initialized
INFO - 2020-07-28 17:27:43 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:43 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:43 --> Email Class Initialized
INFO - 2020-07-28 17:27:43 --> Controller Class Initialized
INFO - 2020-07-28 17:27:43 --> Model Class Initialized
INFO - 2020-07-28 17:27:43 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:43 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:43 --> Total execution time: 0.0208
INFO - 2020-07-28 17:27:44 --> Config Class Initialized
INFO - 2020-07-28 17:27:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:44 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:44 --> URI Class Initialized
INFO - 2020-07-28 17:27:44 --> Router Class Initialized
INFO - 2020-07-28 17:27:44 --> Output Class Initialized
INFO - 2020-07-28 17:27:44 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:44 --> Input Class Initialized
INFO - 2020-07-28 17:27:44 --> Language Class Initialized
INFO - 2020-07-28 17:27:44 --> Loader Class Initialized
INFO - 2020-07-28 17:27:44 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:44 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:44 --> Email Class Initialized
INFO - 2020-07-28 17:27:44 --> Controller Class Initialized
INFO - 2020-07-28 17:27:44 --> Model Class Initialized
INFO - 2020-07-28 17:27:44 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:45 --> Config Class Initialized
INFO - 2020-07-28 17:27:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:45 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:45 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:45 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:45 --> Router Class Initialized
INFO - 2020-07-28 17:27:45 --> Output Class Initialized
INFO - 2020-07-28 17:27:45 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:45 --> Input Class Initialized
INFO - 2020-07-28 17:27:45 --> Language Class Initialized
INFO - 2020-07-28 17:27:45 --> Loader Class Initialized
INFO - 2020-07-28 17:27:45 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:45 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:45 --> Email Class Initialized
INFO - 2020-07-28 17:27:45 --> Controller Class Initialized
INFO - 2020-07-28 17:27:45 --> Model Class Initialized
INFO - 2020-07-28 17:27:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:45 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:45 --> Total execution time: 0.0225
INFO - 2020-07-28 17:27:45 --> Config Class Initialized
INFO - 2020-07-28 17:27:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:45 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:45 --> URI Class Initialized
INFO - 2020-07-28 17:27:45 --> Router Class Initialized
INFO - 2020-07-28 17:27:45 --> Output Class Initialized
INFO - 2020-07-28 17:27:45 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:45 --> Input Class Initialized
INFO - 2020-07-28 17:27:45 --> Language Class Initialized
INFO - 2020-07-28 17:27:45 --> Loader Class Initialized
INFO - 2020-07-28 17:27:45 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:45 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:45 --> Email Class Initialized
INFO - 2020-07-28 17:27:45 --> Controller Class Initialized
INFO - 2020-07-28 17:27:45 --> Model Class Initialized
INFO - 2020-07-28 17:27:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:46 --> Config Class Initialized
INFO - 2020-07-28 17:27:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:46 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:46 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:46 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:46 --> Router Class Initialized
INFO - 2020-07-28 17:27:46 --> Output Class Initialized
INFO - 2020-07-28 17:27:46 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:46 --> Input Class Initialized
INFO - 2020-07-28 17:27:46 --> Language Class Initialized
INFO - 2020-07-28 17:27:46 --> Loader Class Initialized
INFO - 2020-07-28 17:27:46 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:46 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:46 --> Email Class Initialized
INFO - 2020-07-28 17:27:46 --> Controller Class Initialized
INFO - 2020-07-28 17:27:46 --> Model Class Initialized
INFO - 2020-07-28 17:27:46 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:46 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:46 --> Total execution time: 0.0232
INFO - 2020-07-28 17:27:47 --> Config Class Initialized
INFO - 2020-07-28 17:27:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:47 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:47 --> URI Class Initialized
INFO - 2020-07-28 17:27:47 --> Router Class Initialized
INFO - 2020-07-28 17:27:47 --> Output Class Initialized
INFO - 2020-07-28 17:27:47 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:47 --> Input Class Initialized
INFO - 2020-07-28 17:27:47 --> Language Class Initialized
INFO - 2020-07-28 17:27:47 --> Loader Class Initialized
INFO - 2020-07-28 17:27:47 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:47 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:47 --> Email Class Initialized
INFO - 2020-07-28 17:27:47 --> Controller Class Initialized
INFO - 2020-07-28 17:27:47 --> Model Class Initialized
INFO - 2020-07-28 17:27:47 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:47 --> Config Class Initialized
INFO - 2020-07-28 17:27:47 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:47 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:47 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:47 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:47 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:47 --> Router Class Initialized
INFO - 2020-07-28 17:27:47 --> Output Class Initialized
INFO - 2020-07-28 17:27:47 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:47 --> Input Class Initialized
INFO - 2020-07-28 17:27:47 --> Language Class Initialized
INFO - 2020-07-28 17:27:47 --> Loader Class Initialized
INFO - 2020-07-28 17:27:47 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:47 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:47 --> Email Class Initialized
INFO - 2020-07-28 17:27:47 --> Controller Class Initialized
INFO - 2020-07-28 17:27:47 --> Model Class Initialized
INFO - 2020-07-28 17:27:47 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:47 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:47 --> Total execution time: 0.0237
INFO - 2020-07-28 17:27:48 --> Config Class Initialized
INFO - 2020-07-28 17:27:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:48 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:48 --> URI Class Initialized
INFO - 2020-07-28 17:27:48 --> Router Class Initialized
INFO - 2020-07-28 17:27:48 --> Output Class Initialized
INFO - 2020-07-28 17:27:48 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:48 --> Input Class Initialized
INFO - 2020-07-28 17:27:48 --> Language Class Initialized
INFO - 2020-07-28 17:27:48 --> Loader Class Initialized
INFO - 2020-07-28 17:27:48 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:48 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:48 --> Email Class Initialized
INFO - 2020-07-28 17:27:48 --> Controller Class Initialized
INFO - 2020-07-28 17:27:48 --> Model Class Initialized
INFO - 2020-07-28 17:27:48 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:48 --> Config Class Initialized
INFO - 2020-07-28 17:27:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:48 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:48 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:48 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:48 --> Router Class Initialized
INFO - 2020-07-28 17:27:48 --> Output Class Initialized
INFO - 2020-07-28 17:27:48 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:48 --> Input Class Initialized
INFO - 2020-07-28 17:27:48 --> Language Class Initialized
INFO - 2020-07-28 17:27:48 --> Loader Class Initialized
INFO - 2020-07-28 17:27:48 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:48 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:48 --> Email Class Initialized
INFO - 2020-07-28 17:27:48 --> Controller Class Initialized
INFO - 2020-07-28 17:27:48 --> Model Class Initialized
INFO - 2020-07-28 17:27:48 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:48 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:48 --> Total execution time: 0.0268
INFO - 2020-07-28 17:27:49 --> Config Class Initialized
INFO - 2020-07-28 17:27:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:49 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:49 --> URI Class Initialized
INFO - 2020-07-28 17:27:49 --> Router Class Initialized
INFO - 2020-07-28 17:27:49 --> Output Class Initialized
INFO - 2020-07-28 17:27:49 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:49 --> Input Class Initialized
INFO - 2020-07-28 17:27:49 --> Language Class Initialized
INFO - 2020-07-28 17:27:49 --> Loader Class Initialized
INFO - 2020-07-28 17:27:49 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:49 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:49 --> Email Class Initialized
INFO - 2020-07-28 17:27:49 --> Controller Class Initialized
INFO - 2020-07-28 17:27:49 --> Model Class Initialized
INFO - 2020-07-28 17:27:49 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:49 --> Config Class Initialized
INFO - 2020-07-28 17:27:49 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:49 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:49 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:49 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:49 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:49 --> Router Class Initialized
INFO - 2020-07-28 17:27:49 --> Output Class Initialized
INFO - 2020-07-28 17:27:49 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:49 --> Input Class Initialized
INFO - 2020-07-28 17:27:49 --> Language Class Initialized
INFO - 2020-07-28 17:27:49 --> Loader Class Initialized
INFO - 2020-07-28 17:27:49 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:49 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:49 --> Email Class Initialized
INFO - 2020-07-28 17:27:49 --> Controller Class Initialized
INFO - 2020-07-28 17:27:49 --> Model Class Initialized
INFO - 2020-07-28 17:27:49 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:49 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:49 --> Total execution time: 0.0231
INFO - 2020-07-28 17:27:50 --> Config Class Initialized
INFO - 2020-07-28 17:27:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:50 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:50 --> URI Class Initialized
INFO - 2020-07-28 17:27:50 --> Router Class Initialized
INFO - 2020-07-28 17:27:50 --> Output Class Initialized
INFO - 2020-07-28 17:27:50 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:50 --> Input Class Initialized
INFO - 2020-07-28 17:27:50 --> Language Class Initialized
INFO - 2020-07-28 17:27:50 --> Loader Class Initialized
INFO - 2020-07-28 17:27:50 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:50 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:50 --> Email Class Initialized
INFO - 2020-07-28 17:27:50 --> Controller Class Initialized
INFO - 2020-07-28 17:27:50 --> Model Class Initialized
INFO - 2020-07-28 17:27:50 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:51 --> Config Class Initialized
INFO - 2020-07-28 17:27:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:51 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:51 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:51 --> Router Class Initialized
INFO - 2020-07-28 17:27:51 --> Output Class Initialized
INFO - 2020-07-28 17:27:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:51 --> Input Class Initialized
INFO - 2020-07-28 17:27:51 --> Language Class Initialized
INFO - 2020-07-28 17:27:51 --> Loader Class Initialized
INFO - 2020-07-28 17:27:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:51 --> Email Class Initialized
INFO - 2020-07-28 17:27:51 --> Controller Class Initialized
INFO - 2020-07-28 17:27:51 --> Model Class Initialized
INFO - 2020-07-28 17:27:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:51 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:51 --> Total execution time: 0.0263
INFO - 2020-07-28 17:27:51 --> Config Class Initialized
INFO - 2020-07-28 17:27:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:51 --> URI Class Initialized
INFO - 2020-07-28 17:27:51 --> Router Class Initialized
INFO - 2020-07-28 17:27:51 --> Output Class Initialized
INFO - 2020-07-28 17:27:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:51 --> Input Class Initialized
INFO - 2020-07-28 17:27:51 --> Language Class Initialized
INFO - 2020-07-28 17:27:51 --> Loader Class Initialized
INFO - 2020-07-28 17:27:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:52 --> Email Class Initialized
INFO - 2020-07-28 17:27:52 --> Controller Class Initialized
INFO - 2020-07-28 17:27:52 --> Model Class Initialized
INFO - 2020-07-28 17:27:52 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:52 --> Config Class Initialized
INFO - 2020-07-28 17:27:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:52 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:52 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:52 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:52 --> Router Class Initialized
INFO - 2020-07-28 17:27:52 --> Output Class Initialized
INFO - 2020-07-28 17:27:52 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:52 --> Input Class Initialized
INFO - 2020-07-28 17:27:52 --> Language Class Initialized
INFO - 2020-07-28 17:27:52 --> Loader Class Initialized
INFO - 2020-07-28 17:27:52 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:52 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:52 --> Email Class Initialized
INFO - 2020-07-28 17:27:52 --> Controller Class Initialized
INFO - 2020-07-28 17:27:52 --> Model Class Initialized
INFO - 2020-07-28 17:27:52 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:52 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:52 --> Total execution time: 0.0270
INFO - 2020-07-28 17:27:53 --> Config Class Initialized
INFO - 2020-07-28 17:27:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:53 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:53 --> URI Class Initialized
INFO - 2020-07-28 17:27:53 --> Router Class Initialized
INFO - 2020-07-28 17:27:53 --> Output Class Initialized
INFO - 2020-07-28 17:27:53 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:53 --> Input Class Initialized
INFO - 2020-07-28 17:27:53 --> Language Class Initialized
INFO - 2020-07-28 17:27:53 --> Loader Class Initialized
INFO - 2020-07-28 17:27:53 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:53 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:53 --> Email Class Initialized
INFO - 2020-07-28 17:27:53 --> Controller Class Initialized
INFO - 2020-07-28 17:27:53 --> Model Class Initialized
INFO - 2020-07-28 17:27:53 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:53 --> Config Class Initialized
INFO - 2020-07-28 17:27:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:53 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:53 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:53 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:53 --> Router Class Initialized
INFO - 2020-07-28 17:27:53 --> Output Class Initialized
INFO - 2020-07-28 17:27:53 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:53 --> Input Class Initialized
INFO - 2020-07-28 17:27:53 --> Language Class Initialized
INFO - 2020-07-28 17:27:53 --> Loader Class Initialized
INFO - 2020-07-28 17:27:53 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:53 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:53 --> Email Class Initialized
INFO - 2020-07-28 17:27:53 --> Controller Class Initialized
INFO - 2020-07-28 17:27:53 --> Model Class Initialized
INFO - 2020-07-28 17:27:53 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:53 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:53 --> Total execution time: 0.0225
INFO - 2020-07-28 17:27:54 --> Config Class Initialized
INFO - 2020-07-28 17:27:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:54 --> URI Class Initialized
INFO - 2020-07-28 17:27:54 --> Router Class Initialized
INFO - 2020-07-28 17:27:54 --> Output Class Initialized
INFO - 2020-07-28 17:27:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:54 --> Input Class Initialized
INFO - 2020-07-28 17:27:54 --> Language Class Initialized
INFO - 2020-07-28 17:27:54 --> Loader Class Initialized
INFO - 2020-07-28 17:27:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:54 --> Email Class Initialized
INFO - 2020-07-28 17:27:54 --> Controller Class Initialized
INFO - 2020-07-28 17:27:54 --> Model Class Initialized
INFO - 2020-07-28 17:27:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:54 --> Config Class Initialized
INFO - 2020-07-28 17:27:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:54 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:54 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:54 --> Router Class Initialized
INFO - 2020-07-28 17:27:54 --> Output Class Initialized
INFO - 2020-07-28 17:27:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:54 --> Input Class Initialized
INFO - 2020-07-28 17:27:54 --> Language Class Initialized
INFO - 2020-07-28 17:27:54 --> Loader Class Initialized
INFO - 2020-07-28 17:27:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:54 --> Email Class Initialized
INFO - 2020-07-28 17:27:54 --> Controller Class Initialized
INFO - 2020-07-28 17:27:54 --> Model Class Initialized
INFO - 2020-07-28 17:27:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:54 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:54 --> Total execution time: 0.0221
INFO - 2020-07-28 17:27:55 --> Config Class Initialized
INFO - 2020-07-28 17:27:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:55 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:55 --> URI Class Initialized
INFO - 2020-07-28 17:27:55 --> Router Class Initialized
INFO - 2020-07-28 17:27:55 --> Output Class Initialized
INFO - 2020-07-28 17:27:55 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:55 --> Input Class Initialized
INFO - 2020-07-28 17:27:55 --> Language Class Initialized
INFO - 2020-07-28 17:27:55 --> Loader Class Initialized
INFO - 2020-07-28 17:27:55 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:55 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:55 --> Email Class Initialized
INFO - 2020-07-28 17:27:55 --> Controller Class Initialized
INFO - 2020-07-28 17:27:55 --> Model Class Initialized
INFO - 2020-07-28 17:27:55 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:55 --> Config Class Initialized
INFO - 2020-07-28 17:27:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:56 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:56 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:56 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:56 --> Router Class Initialized
INFO - 2020-07-28 17:27:56 --> Output Class Initialized
INFO - 2020-07-28 17:27:56 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:56 --> Input Class Initialized
INFO - 2020-07-28 17:27:56 --> Language Class Initialized
INFO - 2020-07-28 17:27:56 --> Loader Class Initialized
INFO - 2020-07-28 17:27:56 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:56 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:56 --> Email Class Initialized
INFO - 2020-07-28 17:27:56 --> Controller Class Initialized
INFO - 2020-07-28 17:27:56 --> Model Class Initialized
INFO - 2020-07-28 17:27:56 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:56 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:56 --> Total execution time: 0.0240
INFO - 2020-07-28 17:27:56 --> Config Class Initialized
INFO - 2020-07-28 17:27:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:56 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:56 --> URI Class Initialized
INFO - 2020-07-28 17:27:56 --> Router Class Initialized
INFO - 2020-07-28 17:27:56 --> Output Class Initialized
INFO - 2020-07-28 17:27:56 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:56 --> Input Class Initialized
INFO - 2020-07-28 17:27:56 --> Language Class Initialized
INFO - 2020-07-28 17:27:56 --> Loader Class Initialized
INFO - 2020-07-28 17:27:56 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:56 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:56 --> Email Class Initialized
INFO - 2020-07-28 17:27:56 --> Controller Class Initialized
INFO - 2020-07-28 17:27:56 --> Model Class Initialized
INFO - 2020-07-28 17:27:56 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:57 --> Config Class Initialized
INFO - 2020-07-28 17:27:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:57 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:57 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:57 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:57 --> Router Class Initialized
INFO - 2020-07-28 17:27:57 --> Output Class Initialized
INFO - 2020-07-28 17:27:57 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:57 --> Input Class Initialized
INFO - 2020-07-28 17:27:57 --> Language Class Initialized
INFO - 2020-07-28 17:27:57 --> Loader Class Initialized
INFO - 2020-07-28 17:27:57 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:57 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:57 --> Email Class Initialized
INFO - 2020-07-28 17:27:57 --> Controller Class Initialized
INFO - 2020-07-28 17:27:57 --> Model Class Initialized
INFO - 2020-07-28 17:27:57 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:57 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:57 --> Total execution time: 0.0244
INFO - 2020-07-28 17:27:57 --> Config Class Initialized
INFO - 2020-07-28 17:27:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:57 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:57 --> URI Class Initialized
INFO - 2020-07-28 17:27:57 --> Router Class Initialized
INFO - 2020-07-28 17:27:57 --> Output Class Initialized
INFO - 2020-07-28 17:27:57 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:57 --> Input Class Initialized
INFO - 2020-07-28 17:27:57 --> Language Class Initialized
INFO - 2020-07-28 17:27:57 --> Loader Class Initialized
INFO - 2020-07-28 17:27:57 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:57 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:57 --> Email Class Initialized
INFO - 2020-07-28 17:27:57 --> Controller Class Initialized
INFO - 2020-07-28 17:27:57 --> Model Class Initialized
INFO - 2020-07-28 17:27:57 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:58 --> Config Class Initialized
INFO - 2020-07-28 17:27:58 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:58 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:58 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:58 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:58 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:58 --> Router Class Initialized
INFO - 2020-07-28 17:27:58 --> Output Class Initialized
INFO - 2020-07-28 17:27:58 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:58 --> Input Class Initialized
INFO - 2020-07-28 17:27:58 --> Language Class Initialized
INFO - 2020-07-28 17:27:58 --> Loader Class Initialized
INFO - 2020-07-28 17:27:58 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:58 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:58 --> Email Class Initialized
INFO - 2020-07-28 17:27:58 --> Controller Class Initialized
INFO - 2020-07-28 17:27:58 --> Model Class Initialized
INFO - 2020-07-28 17:27:58 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:58 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:58 --> Total execution time: 0.0245
INFO - 2020-07-28 17:27:59 --> Config Class Initialized
INFO - 2020-07-28 17:27:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:59 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:59 --> URI Class Initialized
INFO - 2020-07-28 17:27:59 --> Router Class Initialized
INFO - 2020-07-28 17:27:59 --> Output Class Initialized
INFO - 2020-07-28 17:27:59 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:59 --> Input Class Initialized
INFO - 2020-07-28 17:27:59 --> Language Class Initialized
INFO - 2020-07-28 17:27:59 --> Loader Class Initialized
INFO - 2020-07-28 17:27:59 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:59 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:59 --> Email Class Initialized
INFO - 2020-07-28 17:27:59 --> Controller Class Initialized
INFO - 2020-07-28 17:27:59 --> Model Class Initialized
INFO - 2020-07-28 17:27:59 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:59 --> Config Class Initialized
INFO - 2020-07-28 17:27:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:27:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:27:59 --> Utf8 Class Initialized
INFO - 2020-07-28 17:27:59 --> URI Class Initialized
DEBUG - 2020-07-28 17:27:59 --> No URI present. Default controller set.
INFO - 2020-07-28 17:27:59 --> Router Class Initialized
INFO - 2020-07-28 17:27:59 --> Output Class Initialized
INFO - 2020-07-28 17:27:59 --> Security Class Initialized
DEBUG - 2020-07-28 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:27:59 --> Input Class Initialized
INFO - 2020-07-28 17:27:59 --> Language Class Initialized
INFO - 2020-07-28 17:27:59 --> Loader Class Initialized
INFO - 2020-07-28 17:27:59 --> Helper loaded: url_helper
INFO - 2020-07-28 17:27:59 --> Database Driver Class Initialized
INFO - 2020-07-28 17:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:27:59 --> Email Class Initialized
INFO - 2020-07-28 17:27:59 --> Controller Class Initialized
INFO - 2020-07-28 17:27:59 --> Model Class Initialized
INFO - 2020-07-28 17:27:59 --> Model Class Initialized
DEBUG - 2020-07-28 17:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:27:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:27:59 --> Final output sent to browser
DEBUG - 2020-07-28 17:27:59 --> Total execution time: 0.0217
INFO - 2020-07-28 17:28:00 --> Config Class Initialized
INFO - 2020-07-28 17:28:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:00 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:00 --> URI Class Initialized
INFO - 2020-07-28 17:28:00 --> Router Class Initialized
INFO - 2020-07-28 17:28:00 --> Output Class Initialized
INFO - 2020-07-28 17:28:00 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:00 --> Input Class Initialized
INFO - 2020-07-28 17:28:00 --> Language Class Initialized
INFO - 2020-07-28 17:28:00 --> Loader Class Initialized
INFO - 2020-07-28 17:28:00 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:00 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:00 --> Email Class Initialized
INFO - 2020-07-28 17:28:00 --> Controller Class Initialized
INFO - 2020-07-28 17:28:00 --> Model Class Initialized
INFO - 2020-07-28 17:28:00 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:00 --> Config Class Initialized
INFO - 2020-07-28 17:28:00 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:00 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:00 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:00 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:00 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:00 --> Router Class Initialized
INFO - 2020-07-28 17:28:00 --> Output Class Initialized
INFO - 2020-07-28 17:28:00 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:00 --> Input Class Initialized
INFO - 2020-07-28 17:28:00 --> Language Class Initialized
INFO - 2020-07-28 17:28:00 --> Loader Class Initialized
INFO - 2020-07-28 17:28:00 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:00 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:00 --> Email Class Initialized
INFO - 2020-07-28 17:28:00 --> Controller Class Initialized
INFO - 2020-07-28 17:28:00 --> Model Class Initialized
INFO - 2020-07-28 17:28:00 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:00 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:00 --> Total execution time: 0.0237
INFO - 2020-07-28 17:28:01 --> Config Class Initialized
INFO - 2020-07-28 17:28:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:01 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:01 --> URI Class Initialized
INFO - 2020-07-28 17:28:01 --> Router Class Initialized
INFO - 2020-07-28 17:28:01 --> Output Class Initialized
INFO - 2020-07-28 17:28:01 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:01 --> Input Class Initialized
INFO - 2020-07-28 17:28:01 --> Language Class Initialized
INFO - 2020-07-28 17:28:01 --> Loader Class Initialized
INFO - 2020-07-28 17:28:01 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:01 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:01 --> Email Class Initialized
INFO - 2020-07-28 17:28:01 --> Controller Class Initialized
INFO - 2020-07-28 17:28:01 --> Model Class Initialized
INFO - 2020-07-28 17:28:01 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:02 --> Config Class Initialized
INFO - 2020-07-28 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:02 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:02 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:02 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:02 --> Router Class Initialized
INFO - 2020-07-28 17:28:02 --> Output Class Initialized
INFO - 2020-07-28 17:28:02 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:02 --> Input Class Initialized
INFO - 2020-07-28 17:28:02 --> Language Class Initialized
INFO - 2020-07-28 17:28:02 --> Loader Class Initialized
INFO - 2020-07-28 17:28:02 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:02 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:02 --> Email Class Initialized
INFO - 2020-07-28 17:28:02 --> Controller Class Initialized
INFO - 2020-07-28 17:28:02 --> Model Class Initialized
INFO - 2020-07-28 17:28:02 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:02 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:02 --> Total execution time: 0.0243
INFO - 2020-07-28 17:28:02 --> Config Class Initialized
INFO - 2020-07-28 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:02 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:02 --> URI Class Initialized
INFO - 2020-07-28 17:28:02 --> Router Class Initialized
INFO - 2020-07-28 17:28:02 --> Output Class Initialized
INFO - 2020-07-28 17:28:02 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:02 --> Input Class Initialized
INFO - 2020-07-28 17:28:02 --> Language Class Initialized
INFO - 2020-07-28 17:28:02 --> Loader Class Initialized
INFO - 2020-07-28 17:28:02 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:02 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:02 --> Email Class Initialized
INFO - 2020-07-28 17:28:02 --> Controller Class Initialized
INFO - 2020-07-28 17:28:02 --> Model Class Initialized
INFO - 2020-07-28 17:28:02 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:03 --> Config Class Initialized
INFO - 2020-07-28 17:28:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:03 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:03 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:03 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:03 --> Router Class Initialized
INFO - 2020-07-28 17:28:03 --> Output Class Initialized
INFO - 2020-07-28 17:28:03 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:03 --> Input Class Initialized
INFO - 2020-07-28 17:28:03 --> Language Class Initialized
INFO - 2020-07-28 17:28:03 --> Loader Class Initialized
INFO - 2020-07-28 17:28:03 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:03 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:03 --> Email Class Initialized
INFO - 2020-07-28 17:28:03 --> Controller Class Initialized
INFO - 2020-07-28 17:28:03 --> Model Class Initialized
INFO - 2020-07-28 17:28:03 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:03 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:03 --> Total execution time: 0.0235
INFO - 2020-07-28 17:28:03 --> Config Class Initialized
INFO - 2020-07-28 17:28:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:03 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:03 --> URI Class Initialized
INFO - 2020-07-28 17:28:03 --> Router Class Initialized
INFO - 2020-07-28 17:28:03 --> Output Class Initialized
INFO - 2020-07-28 17:28:03 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:03 --> Input Class Initialized
INFO - 2020-07-28 17:28:03 --> Language Class Initialized
INFO - 2020-07-28 17:28:03 --> Loader Class Initialized
INFO - 2020-07-28 17:28:03 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:03 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:03 --> Email Class Initialized
INFO - 2020-07-28 17:28:03 --> Controller Class Initialized
INFO - 2020-07-28 17:28:03 --> Model Class Initialized
INFO - 2020-07-28 17:28:03 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:04 --> Config Class Initialized
INFO - 2020-07-28 17:28:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:04 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:04 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:04 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:04 --> Router Class Initialized
INFO - 2020-07-28 17:28:04 --> Output Class Initialized
INFO - 2020-07-28 17:28:04 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:04 --> Input Class Initialized
INFO - 2020-07-28 17:28:04 --> Language Class Initialized
INFO - 2020-07-28 17:28:04 --> Loader Class Initialized
INFO - 2020-07-28 17:28:04 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:04 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:04 --> Email Class Initialized
INFO - 2020-07-28 17:28:04 --> Controller Class Initialized
INFO - 2020-07-28 17:28:04 --> Model Class Initialized
INFO - 2020-07-28 17:28:04 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:04 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:04 --> Total execution time: 0.0307
INFO - 2020-07-28 17:28:05 --> Config Class Initialized
INFO - 2020-07-28 17:28:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:05 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:05 --> URI Class Initialized
INFO - 2020-07-28 17:28:05 --> Router Class Initialized
INFO - 2020-07-28 17:28:05 --> Output Class Initialized
INFO - 2020-07-28 17:28:05 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:05 --> Input Class Initialized
INFO - 2020-07-28 17:28:05 --> Language Class Initialized
INFO - 2020-07-28 17:28:05 --> Loader Class Initialized
INFO - 2020-07-28 17:28:05 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:05 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:05 --> Email Class Initialized
INFO - 2020-07-28 17:28:05 --> Controller Class Initialized
INFO - 2020-07-28 17:28:05 --> Model Class Initialized
INFO - 2020-07-28 17:28:05 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:05 --> Config Class Initialized
INFO - 2020-07-28 17:28:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:05 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:05 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:05 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:05 --> Router Class Initialized
INFO - 2020-07-28 17:28:05 --> Output Class Initialized
INFO - 2020-07-28 17:28:05 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:05 --> Input Class Initialized
INFO - 2020-07-28 17:28:05 --> Language Class Initialized
INFO - 2020-07-28 17:28:05 --> Loader Class Initialized
INFO - 2020-07-28 17:28:05 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:05 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:05 --> Email Class Initialized
INFO - 2020-07-28 17:28:05 --> Controller Class Initialized
INFO - 2020-07-28 17:28:05 --> Model Class Initialized
INFO - 2020-07-28 17:28:05 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:05 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:05 --> Total execution time: 0.0268
INFO - 2020-07-28 17:28:06 --> Config Class Initialized
INFO - 2020-07-28 17:28:06 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:06 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:06 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:06 --> URI Class Initialized
INFO - 2020-07-28 17:28:06 --> Router Class Initialized
INFO - 2020-07-28 17:28:06 --> Output Class Initialized
INFO - 2020-07-28 17:28:06 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:06 --> Input Class Initialized
INFO - 2020-07-28 17:28:06 --> Language Class Initialized
INFO - 2020-07-28 17:28:06 --> Loader Class Initialized
INFO - 2020-07-28 17:28:06 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:06 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:06 --> Email Class Initialized
INFO - 2020-07-28 17:28:06 --> Controller Class Initialized
INFO - 2020-07-28 17:28:06 --> Model Class Initialized
INFO - 2020-07-28 17:28:06 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:06 --> Config Class Initialized
INFO - 2020-07-28 17:28:06 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:06 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:06 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:06 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:06 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:06 --> Router Class Initialized
INFO - 2020-07-28 17:28:06 --> Output Class Initialized
INFO - 2020-07-28 17:28:06 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:06 --> Input Class Initialized
INFO - 2020-07-28 17:28:06 --> Language Class Initialized
INFO - 2020-07-28 17:28:06 --> Loader Class Initialized
INFO - 2020-07-28 17:28:06 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:06 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:06 --> Email Class Initialized
INFO - 2020-07-28 17:28:06 --> Controller Class Initialized
INFO - 2020-07-28 17:28:06 --> Model Class Initialized
INFO - 2020-07-28 17:28:06 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:06 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:06 --> Total execution time: 0.0217
INFO - 2020-07-28 17:28:07 --> Config Class Initialized
INFO - 2020-07-28 17:28:07 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:07 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:07 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:07 --> URI Class Initialized
INFO - 2020-07-28 17:28:07 --> Router Class Initialized
INFO - 2020-07-28 17:28:07 --> Output Class Initialized
INFO - 2020-07-28 17:28:07 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:07 --> Input Class Initialized
INFO - 2020-07-28 17:28:07 --> Language Class Initialized
INFO - 2020-07-28 17:28:07 --> Loader Class Initialized
INFO - 2020-07-28 17:28:07 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:07 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:07 --> Email Class Initialized
INFO - 2020-07-28 17:28:07 --> Controller Class Initialized
INFO - 2020-07-28 17:28:07 --> Model Class Initialized
INFO - 2020-07-28 17:28:07 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:08 --> Config Class Initialized
INFO - 2020-07-28 17:28:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:08 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:08 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:08 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:08 --> Router Class Initialized
INFO - 2020-07-28 17:28:08 --> Output Class Initialized
INFO - 2020-07-28 17:28:08 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:08 --> Input Class Initialized
INFO - 2020-07-28 17:28:08 --> Language Class Initialized
INFO - 2020-07-28 17:28:08 --> Loader Class Initialized
INFO - 2020-07-28 17:28:08 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:08 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:08 --> Email Class Initialized
INFO - 2020-07-28 17:28:08 --> Controller Class Initialized
INFO - 2020-07-28 17:28:08 --> Model Class Initialized
INFO - 2020-07-28 17:28:08 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:08 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:08 --> Total execution time: 0.0243
INFO - 2020-07-28 17:28:08 --> Config Class Initialized
INFO - 2020-07-28 17:28:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:08 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:08 --> URI Class Initialized
INFO - 2020-07-28 17:28:08 --> Router Class Initialized
INFO - 2020-07-28 17:28:08 --> Output Class Initialized
INFO - 2020-07-28 17:28:08 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:08 --> Input Class Initialized
INFO - 2020-07-28 17:28:08 --> Language Class Initialized
INFO - 2020-07-28 17:28:08 --> Loader Class Initialized
INFO - 2020-07-28 17:28:08 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:08 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:08 --> Email Class Initialized
INFO - 2020-07-28 17:28:08 --> Controller Class Initialized
INFO - 2020-07-28 17:28:08 --> Model Class Initialized
INFO - 2020-07-28 17:28:08 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:09 --> Config Class Initialized
INFO - 2020-07-28 17:28:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:09 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:09 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:09 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:09 --> Router Class Initialized
INFO - 2020-07-28 17:28:09 --> Output Class Initialized
INFO - 2020-07-28 17:28:09 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:09 --> Input Class Initialized
INFO - 2020-07-28 17:28:09 --> Language Class Initialized
INFO - 2020-07-28 17:28:09 --> Loader Class Initialized
INFO - 2020-07-28 17:28:09 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:09 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:09 --> Email Class Initialized
INFO - 2020-07-28 17:28:09 --> Controller Class Initialized
INFO - 2020-07-28 17:28:09 --> Model Class Initialized
INFO - 2020-07-28 17:28:09 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:09 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:09 --> Total execution time: 0.0655
INFO - 2020-07-28 17:28:09 --> Config Class Initialized
INFO - 2020-07-28 17:28:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:09 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:09 --> URI Class Initialized
INFO - 2020-07-28 17:28:09 --> Router Class Initialized
INFO - 2020-07-28 17:28:09 --> Output Class Initialized
INFO - 2020-07-28 17:28:09 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:09 --> Input Class Initialized
INFO - 2020-07-28 17:28:09 --> Language Class Initialized
INFO - 2020-07-28 17:28:09 --> Loader Class Initialized
INFO - 2020-07-28 17:28:09 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:09 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:09 --> Email Class Initialized
INFO - 2020-07-28 17:28:09 --> Controller Class Initialized
INFO - 2020-07-28 17:28:09 --> Model Class Initialized
INFO - 2020-07-28 17:28:09 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:10 --> Config Class Initialized
INFO - 2020-07-28 17:28:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:10 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:10 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:10 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:10 --> Router Class Initialized
INFO - 2020-07-28 17:28:10 --> Output Class Initialized
INFO - 2020-07-28 17:28:10 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:10 --> Input Class Initialized
INFO - 2020-07-28 17:28:10 --> Language Class Initialized
INFO - 2020-07-28 17:28:10 --> Loader Class Initialized
INFO - 2020-07-28 17:28:10 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:10 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:10 --> Email Class Initialized
INFO - 2020-07-28 17:28:10 --> Controller Class Initialized
INFO - 2020-07-28 17:28:10 --> Model Class Initialized
INFO - 2020-07-28 17:28:10 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:10 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:10 --> Total execution time: 0.0270
INFO - 2020-07-28 17:28:13 --> Config Class Initialized
INFO - 2020-07-28 17:28:13 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:13 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:13 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:13 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:13 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:13 --> Router Class Initialized
INFO - 2020-07-28 17:28:13 --> Output Class Initialized
INFO - 2020-07-28 17:28:13 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:13 --> Input Class Initialized
INFO - 2020-07-28 17:28:13 --> Language Class Initialized
INFO - 2020-07-28 17:28:13 --> Loader Class Initialized
INFO - 2020-07-28 17:28:13 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:13 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:13 --> Email Class Initialized
INFO - 2020-07-28 17:28:13 --> Controller Class Initialized
INFO - 2020-07-28 17:28:13 --> Model Class Initialized
INFO - 2020-07-28 17:28:13 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:13 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:13 --> Total execution time: 0.0252
INFO - 2020-07-28 17:28:28 --> Config Class Initialized
INFO - 2020-07-28 17:28:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:28 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:28 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:28 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:28 --> Router Class Initialized
INFO - 2020-07-28 17:28:28 --> Output Class Initialized
INFO - 2020-07-28 17:28:28 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:28 --> Input Class Initialized
INFO - 2020-07-28 17:28:28 --> Language Class Initialized
INFO - 2020-07-28 17:28:28 --> Loader Class Initialized
INFO - 2020-07-28 17:28:28 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:28 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:28 --> Email Class Initialized
INFO - 2020-07-28 17:28:28 --> Controller Class Initialized
INFO - 2020-07-28 17:28:28 --> Model Class Initialized
INFO - 2020-07-28 17:28:28 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:28 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:28 --> Total execution time: 0.0222
INFO - 2020-07-28 17:28:28 --> Config Class Initialized
INFO - 2020-07-28 17:28:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:28 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:28 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:28 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:28 --> Router Class Initialized
INFO - 2020-07-28 17:28:28 --> Output Class Initialized
INFO - 2020-07-28 17:28:28 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:28 --> Input Class Initialized
INFO - 2020-07-28 17:28:28 --> Language Class Initialized
INFO - 2020-07-28 17:28:28 --> Loader Class Initialized
INFO - 2020-07-28 17:28:28 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:28 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:28 --> Email Class Initialized
INFO - 2020-07-28 17:28:28 --> Controller Class Initialized
INFO - 2020-07-28 17:28:28 --> Model Class Initialized
INFO - 2020-07-28 17:28:28 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:28 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:28 --> Total execution time: 0.0252
INFO - 2020-07-28 17:28:31 --> Config Class Initialized
INFO - 2020-07-28 17:28:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:31 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:31 --> URI Class Initialized
INFO - 2020-07-28 17:28:31 --> Router Class Initialized
INFO - 2020-07-28 17:28:31 --> Output Class Initialized
INFO - 2020-07-28 17:28:31 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:31 --> Input Class Initialized
INFO - 2020-07-28 17:28:31 --> Language Class Initialized
INFO - 2020-07-28 17:28:31 --> Loader Class Initialized
INFO - 2020-07-28 17:28:31 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:31 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:31 --> Email Class Initialized
INFO - 2020-07-28 17:28:31 --> Controller Class Initialized
INFO - 2020-07-28 17:28:31 --> Model Class Initialized
INFO - 2020-07-28 17:28:31 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:31 --> Config Class Initialized
INFO - 2020-07-28 17:28:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:31 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:31 --> URI Class Initialized
INFO - 2020-07-28 17:28:31 --> Router Class Initialized
INFO - 2020-07-28 17:28:31 --> Output Class Initialized
INFO - 2020-07-28 17:28:31 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:31 --> Input Class Initialized
INFO - 2020-07-28 17:28:31 --> Language Class Initialized
INFO - 2020-07-28 17:28:31 --> Loader Class Initialized
INFO - 2020-07-28 17:28:31 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:31 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:31 --> Email Class Initialized
INFO - 2020-07-28 17:28:31 --> Controller Class Initialized
INFO - 2020-07-28 17:28:31 --> Model Class Initialized
INFO - 2020-07-28 17:28:31 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:28:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:28:31 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:31 --> Total execution time: 0.0252
INFO - 2020-07-28 17:28:44 --> Config Class Initialized
INFO - 2020-07-28 17:28:44 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:44 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:44 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:44 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:44 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:44 --> Router Class Initialized
INFO - 2020-07-28 17:28:44 --> Output Class Initialized
INFO - 2020-07-28 17:28:44 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:44 --> Input Class Initialized
INFO - 2020-07-28 17:28:44 --> Language Class Initialized
INFO - 2020-07-28 17:28:44 --> Loader Class Initialized
INFO - 2020-07-28 17:28:44 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:44 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:44 --> Email Class Initialized
INFO - 2020-07-28 17:28:44 --> Controller Class Initialized
INFO - 2020-07-28 17:28:44 --> Model Class Initialized
INFO - 2020-07-28 17:28:44 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:44 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:44 --> Total execution time: 0.0204
INFO - 2020-07-28 17:28:50 --> Config Class Initialized
INFO - 2020-07-28 17:28:50 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:50 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:50 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:50 --> URI Class Initialized
INFO - 2020-07-28 17:28:50 --> Router Class Initialized
INFO - 2020-07-28 17:28:50 --> Output Class Initialized
INFO - 2020-07-28 17:28:50 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:50 --> Input Class Initialized
INFO - 2020-07-28 17:28:50 --> Language Class Initialized
INFO - 2020-07-28 17:28:50 --> Loader Class Initialized
INFO - 2020-07-28 17:28:50 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:50 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:50 --> Email Class Initialized
INFO - 2020-07-28 17:28:50 --> Controller Class Initialized
INFO - 2020-07-28 17:28:50 --> Model Class Initialized
INFO - 2020-07-28 17:28:50 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:51 --> Config Class Initialized
INFO - 2020-07-28 17:28:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:51 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:51 --> URI Class Initialized
DEBUG - 2020-07-28 17:28:51 --> No URI present. Default controller set.
INFO - 2020-07-28 17:28:51 --> Router Class Initialized
INFO - 2020-07-28 17:28:51 --> Output Class Initialized
INFO - 2020-07-28 17:28:51 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:51 --> Input Class Initialized
INFO - 2020-07-28 17:28:51 --> Language Class Initialized
INFO - 2020-07-28 17:28:51 --> Loader Class Initialized
INFO - 2020-07-28 17:28:51 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:51 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:51 --> Email Class Initialized
INFO - 2020-07-28 17:28:51 --> Controller Class Initialized
INFO - 2020-07-28 17:28:51 --> Model Class Initialized
INFO - 2020-07-28 17:28:51 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:28:51 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:51 --> Total execution time: 0.0234
INFO - 2020-07-28 17:28:54 --> Config Class Initialized
INFO - 2020-07-28 17:28:54 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:54 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:54 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:54 --> URI Class Initialized
INFO - 2020-07-28 17:28:54 --> Router Class Initialized
INFO - 2020-07-28 17:28:54 --> Output Class Initialized
INFO - 2020-07-28 17:28:54 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:54 --> Input Class Initialized
INFO - 2020-07-28 17:28:54 --> Language Class Initialized
INFO - 2020-07-28 17:28:54 --> Loader Class Initialized
INFO - 2020-07-28 17:28:54 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:54 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:54 --> Email Class Initialized
INFO - 2020-07-28 17:28:54 --> Controller Class Initialized
INFO - 2020-07-28 17:28:54 --> Model Class Initialized
INFO - 2020-07-28 17:28:54 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:55 --> Config Class Initialized
INFO - 2020-07-28 17:28:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:28:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:28:55 --> Utf8 Class Initialized
INFO - 2020-07-28 17:28:55 --> URI Class Initialized
INFO - 2020-07-28 17:28:55 --> Router Class Initialized
INFO - 2020-07-28 17:28:55 --> Output Class Initialized
INFO - 2020-07-28 17:28:55 --> Security Class Initialized
DEBUG - 2020-07-28 17:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:28:55 --> Input Class Initialized
INFO - 2020-07-28 17:28:55 --> Language Class Initialized
INFO - 2020-07-28 17:28:55 --> Loader Class Initialized
INFO - 2020-07-28 17:28:55 --> Helper loaded: url_helper
INFO - 2020-07-28 17:28:55 --> Database Driver Class Initialized
INFO - 2020-07-28 17:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:28:55 --> Email Class Initialized
INFO - 2020-07-28 17:28:55 --> Controller Class Initialized
INFO - 2020-07-28 17:28:55 --> Model Class Initialized
INFO - 2020-07-28 17:28:55 --> Model Class Initialized
DEBUG - 2020-07-28 17:28:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:28:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:28:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:28:55 --> Final output sent to browser
DEBUG - 2020-07-28 17:28:55 --> Total execution time: 0.0245
INFO - 2020-07-28 17:30:12 --> Config Class Initialized
INFO - 2020-07-28 17:30:12 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:30:12 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:30:12 --> Utf8 Class Initialized
INFO - 2020-07-28 17:30:12 --> URI Class Initialized
DEBUG - 2020-07-28 17:30:12 --> No URI present. Default controller set.
INFO - 2020-07-28 17:30:12 --> Router Class Initialized
INFO - 2020-07-28 17:30:12 --> Output Class Initialized
INFO - 2020-07-28 17:30:12 --> Security Class Initialized
DEBUG - 2020-07-28 17:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:30:12 --> Input Class Initialized
INFO - 2020-07-28 17:30:12 --> Language Class Initialized
INFO - 2020-07-28 17:30:12 --> Loader Class Initialized
INFO - 2020-07-28 17:30:12 --> Helper loaded: url_helper
INFO - 2020-07-28 17:30:12 --> Database Driver Class Initialized
INFO - 2020-07-28 17:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:30:12 --> Email Class Initialized
INFO - 2020-07-28 17:30:12 --> Controller Class Initialized
INFO - 2020-07-28 17:30:12 --> Model Class Initialized
INFO - 2020-07-28 17:30:12 --> Model Class Initialized
DEBUG - 2020-07-28 17:30:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:30:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:30:12 --> Final output sent to browser
DEBUG - 2020-07-28 17:30:12 --> Total execution time: 0.0236
INFO - 2020-07-28 17:30:15 --> Config Class Initialized
INFO - 2020-07-28 17:30:15 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:30:15 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:30:15 --> Utf8 Class Initialized
INFO - 2020-07-28 17:30:15 --> URI Class Initialized
INFO - 2020-07-28 17:30:15 --> Router Class Initialized
INFO - 2020-07-28 17:30:15 --> Output Class Initialized
INFO - 2020-07-28 17:30:15 --> Security Class Initialized
DEBUG - 2020-07-28 17:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:30:15 --> Input Class Initialized
INFO - 2020-07-28 17:30:15 --> Language Class Initialized
INFO - 2020-07-28 17:30:15 --> Loader Class Initialized
INFO - 2020-07-28 17:30:15 --> Helper loaded: url_helper
INFO - 2020-07-28 17:30:15 --> Database Driver Class Initialized
INFO - 2020-07-28 17:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:30:15 --> Email Class Initialized
INFO - 2020-07-28 17:30:15 --> Controller Class Initialized
INFO - 2020-07-28 17:30:15 --> Model Class Initialized
INFO - 2020-07-28 17:30:15 --> Model Class Initialized
DEBUG - 2020-07-28 17:30:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:30:16 --> Config Class Initialized
INFO - 2020-07-28 17:30:16 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:30:16 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:30:16 --> Utf8 Class Initialized
INFO - 2020-07-28 17:30:16 --> URI Class Initialized
INFO - 2020-07-28 17:30:16 --> Router Class Initialized
INFO - 2020-07-28 17:30:16 --> Output Class Initialized
INFO - 2020-07-28 17:30:16 --> Security Class Initialized
DEBUG - 2020-07-28 17:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:30:16 --> Input Class Initialized
INFO - 2020-07-28 17:30:16 --> Language Class Initialized
INFO - 2020-07-28 17:30:16 --> Loader Class Initialized
INFO - 2020-07-28 17:30:16 --> Helper loaded: url_helper
INFO - 2020-07-28 17:30:16 --> Database Driver Class Initialized
INFO - 2020-07-28 17:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:30:16 --> Email Class Initialized
INFO - 2020-07-28 17:30:16 --> Controller Class Initialized
INFO - 2020-07-28 17:30:16 --> Model Class Initialized
INFO - 2020-07-28 17:30:16 --> Model Class Initialized
DEBUG - 2020-07-28 17:30:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:30:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:30:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:30:16 --> Final output sent to browser
DEBUG - 2020-07-28 17:30:16 --> Total execution time: 0.0242
INFO - 2020-07-28 17:31:28 --> Config Class Initialized
INFO - 2020-07-28 17:31:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:31:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:31:28 --> Utf8 Class Initialized
INFO - 2020-07-28 17:31:28 --> URI Class Initialized
DEBUG - 2020-07-28 17:31:28 --> No URI present. Default controller set.
INFO - 2020-07-28 17:31:28 --> Router Class Initialized
INFO - 2020-07-28 17:31:28 --> Output Class Initialized
INFO - 2020-07-28 17:31:28 --> Security Class Initialized
DEBUG - 2020-07-28 17:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:31:28 --> Input Class Initialized
INFO - 2020-07-28 17:31:28 --> Language Class Initialized
INFO - 2020-07-28 17:31:28 --> Loader Class Initialized
INFO - 2020-07-28 17:31:28 --> Helper loaded: url_helper
INFO - 2020-07-28 17:31:28 --> Database Driver Class Initialized
INFO - 2020-07-28 17:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:31:28 --> Email Class Initialized
INFO - 2020-07-28 17:31:28 --> Controller Class Initialized
INFO - 2020-07-28 17:31:28 --> Model Class Initialized
INFO - 2020-07-28 17:31:28 --> Model Class Initialized
DEBUG - 2020-07-28 17:31:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:31:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 17:31:28 --> Final output sent to browser
DEBUG - 2020-07-28 17:31:28 --> Total execution time: 0.0215
INFO - 2020-07-28 17:31:45 --> Config Class Initialized
INFO - 2020-07-28 17:31:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:31:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:31:45 --> Utf8 Class Initialized
INFO - 2020-07-28 17:31:45 --> URI Class Initialized
INFO - 2020-07-28 17:31:45 --> Router Class Initialized
INFO - 2020-07-28 17:31:45 --> Output Class Initialized
INFO - 2020-07-28 17:31:45 --> Security Class Initialized
DEBUG - 2020-07-28 17:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:31:45 --> Input Class Initialized
INFO - 2020-07-28 17:31:45 --> Language Class Initialized
INFO - 2020-07-28 17:31:45 --> Loader Class Initialized
INFO - 2020-07-28 17:31:45 --> Helper loaded: url_helper
INFO - 2020-07-28 17:31:45 --> Database Driver Class Initialized
INFO - 2020-07-28 17:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:31:45 --> Email Class Initialized
INFO - 2020-07-28 17:31:45 --> Controller Class Initialized
INFO - 2020-07-28 17:31:45 --> Model Class Initialized
INFO - 2020-07-28 17:31:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:31:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:31:45 --> Config Class Initialized
INFO - 2020-07-28 17:31:45 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:31:45 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:31:45 --> Utf8 Class Initialized
INFO - 2020-07-28 17:31:45 --> URI Class Initialized
INFO - 2020-07-28 17:31:45 --> Router Class Initialized
INFO - 2020-07-28 17:31:45 --> Output Class Initialized
INFO - 2020-07-28 17:31:45 --> Security Class Initialized
DEBUG - 2020-07-28 17:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:31:45 --> Input Class Initialized
INFO - 2020-07-28 17:31:45 --> Language Class Initialized
INFO - 2020-07-28 17:31:45 --> Loader Class Initialized
INFO - 2020-07-28 17:31:45 --> Helper loaded: url_helper
INFO - 2020-07-28 17:31:45 --> Database Driver Class Initialized
INFO - 2020-07-28 17:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:31:45 --> Email Class Initialized
INFO - 2020-07-28 17:31:45 --> Controller Class Initialized
INFO - 2020-07-28 17:31:45 --> Model Class Initialized
INFO - 2020-07-28 17:31:45 --> Model Class Initialized
DEBUG - 2020-07-28 17:31:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:31:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:31:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 17:31:45 --> Final output sent to browser
DEBUG - 2020-07-28 17:31:45 --> Total execution time: 0.0235
INFO - 2020-07-28 17:33:10 --> Config Class Initialized
INFO - 2020-07-28 17:33:10 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:33:10 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:33:10 --> Utf8 Class Initialized
INFO - 2020-07-28 17:33:10 --> URI Class Initialized
INFO - 2020-07-28 17:33:10 --> Router Class Initialized
INFO - 2020-07-28 17:33:10 --> Output Class Initialized
INFO - 2020-07-28 17:33:10 --> Security Class Initialized
DEBUG - 2020-07-28 17:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:33:10 --> Input Class Initialized
INFO - 2020-07-28 17:33:10 --> Language Class Initialized
INFO - 2020-07-28 17:33:10 --> Loader Class Initialized
INFO - 2020-07-28 17:33:11 --> Helper loaded: url_helper
INFO - 2020-07-28 17:33:11 --> Database Driver Class Initialized
INFO - 2020-07-28 17:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:33:11 --> Email Class Initialized
INFO - 2020-07-28 17:33:11 --> Controller Class Initialized
INFO - 2020-07-28 17:33:11 --> Model Class Initialized
INFO - 2020-07-28 17:33:11 --> Model Class Initialized
DEBUG - 2020-07-28 17:33:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:33:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:33:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 17:33:11 --> Final output sent to browser
DEBUG - 2020-07-28 17:33:11 --> Total execution time: 0.0317
INFO - 2020-07-28 17:33:14 --> Config Class Initialized
INFO - 2020-07-28 17:33:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 17:33:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 17:33:14 --> Utf8 Class Initialized
INFO - 2020-07-28 17:33:14 --> URI Class Initialized
INFO - 2020-07-28 17:33:14 --> Router Class Initialized
INFO - 2020-07-28 17:33:14 --> Output Class Initialized
INFO - 2020-07-28 17:33:14 --> Security Class Initialized
DEBUG - 2020-07-28 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 17:33:14 --> Input Class Initialized
INFO - 2020-07-28 17:33:14 --> Language Class Initialized
INFO - 2020-07-28 17:33:14 --> Loader Class Initialized
INFO - 2020-07-28 17:33:14 --> Helper loaded: url_helper
INFO - 2020-07-28 17:33:14 --> Database Driver Class Initialized
INFO - 2020-07-28 17:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 17:33:14 --> Email Class Initialized
INFO - 2020-07-28 17:33:14 --> Controller Class Initialized
INFO - 2020-07-28 17:33:14 --> Model Class Initialized
INFO - 2020-07-28 17:33:14 --> Model Class Initialized
DEBUG - 2020-07-28 17:33:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 17:33:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 17:33:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 17:33:14 --> Final output sent to browser
DEBUG - 2020-07-28 17:33:14 --> Total execution time: 0.0196
INFO - 2020-07-28 18:28:34 --> Config Class Initialized
INFO - 2020-07-28 18:28:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:28:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:28:34 --> Utf8 Class Initialized
INFO - 2020-07-28 18:28:34 --> URI Class Initialized
INFO - 2020-07-28 18:28:34 --> Router Class Initialized
INFO - 2020-07-28 18:28:34 --> Output Class Initialized
INFO - 2020-07-28 18:28:34 --> Security Class Initialized
DEBUG - 2020-07-28 18:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:28:34 --> Input Class Initialized
INFO - 2020-07-28 18:28:34 --> Language Class Initialized
INFO - 2020-07-28 18:28:34 --> Loader Class Initialized
INFO - 2020-07-28 18:28:34 --> Helper loaded: url_helper
INFO - 2020-07-28 18:28:35 --> Database Driver Class Initialized
INFO - 2020-07-28 18:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:28:35 --> Email Class Initialized
INFO - 2020-07-28 18:28:35 --> Controller Class Initialized
INFO - 2020-07-28 18:28:35 --> Model Class Initialized
INFO - 2020-07-28 18:28:35 --> Model Class Initialized
DEBUG - 2020-07-28 18:28:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:28:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:28:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:28:35 --> Final output sent to browser
DEBUG - 2020-07-28 18:28:35 --> Total execution time: 0.0336
INFO - 2020-07-28 18:34:05 --> Config Class Initialized
INFO - 2020-07-28 18:34:05 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:34:05 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:34:05 --> Utf8 Class Initialized
INFO - 2020-07-28 18:34:05 --> URI Class Initialized
INFO - 2020-07-28 18:34:05 --> Router Class Initialized
INFO - 2020-07-28 18:34:05 --> Output Class Initialized
INFO - 2020-07-28 18:34:05 --> Security Class Initialized
DEBUG - 2020-07-28 18:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:34:05 --> Input Class Initialized
INFO - 2020-07-28 18:34:05 --> Language Class Initialized
INFO - 2020-07-28 18:34:05 --> Loader Class Initialized
INFO - 2020-07-28 18:34:05 --> Helper loaded: url_helper
INFO - 2020-07-28 18:34:05 --> Database Driver Class Initialized
INFO - 2020-07-28 18:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:34:05 --> Email Class Initialized
INFO - 2020-07-28 18:34:05 --> Controller Class Initialized
INFO - 2020-07-28 18:34:05 --> Model Class Initialized
INFO - 2020-07-28 18:34:05 --> Model Class Initialized
DEBUG - 2020-07-28 18:34:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:34:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:34:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:34:05 --> Final output sent to browser
DEBUG - 2020-07-28 18:34:05 --> Total execution time: 0.0225
INFO - 2020-07-28 18:34:36 --> Config Class Initialized
INFO - 2020-07-28 18:34:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:34:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:34:36 --> Utf8 Class Initialized
INFO - 2020-07-28 18:34:36 --> URI Class Initialized
INFO - 2020-07-28 18:34:36 --> Router Class Initialized
INFO - 2020-07-28 18:34:36 --> Output Class Initialized
INFO - 2020-07-28 18:34:36 --> Security Class Initialized
DEBUG - 2020-07-28 18:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:34:36 --> Input Class Initialized
INFO - 2020-07-28 18:34:36 --> Language Class Initialized
INFO - 2020-07-28 18:34:36 --> Loader Class Initialized
INFO - 2020-07-28 18:34:36 --> Helper loaded: url_helper
INFO - 2020-07-28 18:34:36 --> Database Driver Class Initialized
INFO - 2020-07-28 18:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:34:36 --> Email Class Initialized
INFO - 2020-07-28 18:34:36 --> Controller Class Initialized
INFO - 2020-07-28 18:34:36 --> Model Class Initialized
INFO - 2020-07-28 18:34:36 --> Model Class Initialized
DEBUG - 2020-07-28 18:34:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:34:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:34:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 18:34:36 --> Final output sent to browser
DEBUG - 2020-07-28 18:34:36 --> Total execution time: 0.0243
INFO - 2020-07-28 18:34:51 --> Config Class Initialized
INFO - 2020-07-28 18:34:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:34:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:34:51 --> Utf8 Class Initialized
INFO - 2020-07-28 18:34:51 --> URI Class Initialized
INFO - 2020-07-28 18:34:51 --> Router Class Initialized
INFO - 2020-07-28 18:34:51 --> Output Class Initialized
INFO - 2020-07-28 18:34:51 --> Security Class Initialized
DEBUG - 2020-07-28 18:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:34:51 --> Input Class Initialized
INFO - 2020-07-28 18:34:51 --> Language Class Initialized
INFO - 2020-07-28 18:34:51 --> Loader Class Initialized
INFO - 2020-07-28 18:34:51 --> Helper loaded: url_helper
INFO - 2020-07-28 18:34:51 --> Database Driver Class Initialized
INFO - 2020-07-28 18:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:34:51 --> Email Class Initialized
INFO - 2020-07-28 18:34:51 --> Controller Class Initialized
INFO - 2020-07-28 18:34:51 --> Model Class Initialized
INFO - 2020-07-28 18:34:51 --> Model Class Initialized
DEBUG - 2020-07-28 18:34:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:34:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:34:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:34:51 --> Final output sent to browser
DEBUG - 2020-07-28 18:34:51 --> Total execution time: 0.0250
INFO - 2020-07-28 18:35:33 --> Config Class Initialized
INFO - 2020-07-28 18:35:33 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:35:33 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:35:33 --> Utf8 Class Initialized
INFO - 2020-07-28 18:35:33 --> URI Class Initialized
INFO - 2020-07-28 18:35:33 --> Router Class Initialized
INFO - 2020-07-28 18:35:33 --> Output Class Initialized
INFO - 2020-07-28 18:35:33 --> Security Class Initialized
DEBUG - 2020-07-28 18:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:35:33 --> Input Class Initialized
INFO - 2020-07-28 18:35:33 --> Language Class Initialized
INFO - 2020-07-28 18:35:33 --> Loader Class Initialized
INFO - 2020-07-28 18:35:33 --> Helper loaded: url_helper
INFO - 2020-07-28 18:35:33 --> Database Driver Class Initialized
INFO - 2020-07-28 18:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:35:33 --> Email Class Initialized
INFO - 2020-07-28 18:35:33 --> Controller Class Initialized
INFO - 2020-07-28 18:35:33 --> Model Class Initialized
INFO - 2020-07-28 18:35:33 --> Model Class Initialized
DEBUG - 2020-07-28 18:35:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:35:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:35:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:35:33 --> Final output sent to browser
DEBUG - 2020-07-28 18:35:33 --> Total execution time: 0.0216
INFO - 2020-07-28 18:36:40 --> Config Class Initialized
INFO - 2020-07-28 18:36:40 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:36:40 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:36:40 --> Utf8 Class Initialized
INFO - 2020-07-28 18:36:40 --> URI Class Initialized
INFO - 2020-07-28 18:36:40 --> Router Class Initialized
INFO - 2020-07-28 18:36:40 --> Output Class Initialized
INFO - 2020-07-28 18:36:40 --> Security Class Initialized
DEBUG - 2020-07-28 18:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:36:40 --> Input Class Initialized
INFO - 2020-07-28 18:36:40 --> Language Class Initialized
INFO - 2020-07-28 18:36:40 --> Loader Class Initialized
INFO - 2020-07-28 18:36:40 --> Helper loaded: url_helper
INFO - 2020-07-28 18:36:40 --> Database Driver Class Initialized
INFO - 2020-07-28 18:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:36:40 --> Email Class Initialized
INFO - 2020-07-28 18:36:40 --> Controller Class Initialized
INFO - 2020-07-28 18:36:40 --> Model Class Initialized
INFO - 2020-07-28 18:36:40 --> Model Class Initialized
DEBUG - 2020-07-28 18:36:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:36:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:36:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:36:40 --> Final output sent to browser
DEBUG - 2020-07-28 18:36:40 --> Total execution time: 0.0237
INFO - 2020-07-28 18:37:14 --> Config Class Initialized
INFO - 2020-07-28 18:37:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:37:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:37:14 --> Utf8 Class Initialized
INFO - 2020-07-28 18:37:14 --> URI Class Initialized
INFO - 2020-07-28 18:37:14 --> Router Class Initialized
INFO - 2020-07-28 18:37:14 --> Output Class Initialized
INFO - 2020-07-28 18:37:14 --> Security Class Initialized
DEBUG - 2020-07-28 18:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:37:14 --> Input Class Initialized
INFO - 2020-07-28 18:37:14 --> Language Class Initialized
INFO - 2020-07-28 18:37:14 --> Loader Class Initialized
INFO - 2020-07-28 18:37:14 --> Helper loaded: url_helper
INFO - 2020-07-28 18:37:14 --> Database Driver Class Initialized
INFO - 2020-07-28 18:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:37:14 --> Email Class Initialized
INFO - 2020-07-28 18:37:14 --> Controller Class Initialized
INFO - 2020-07-28 18:37:14 --> Model Class Initialized
INFO - 2020-07-28 18:37:14 --> Model Class Initialized
DEBUG - 2020-07-28 18:37:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:37:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:37:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:37:14 --> Final output sent to browser
DEBUG - 2020-07-28 18:37:14 --> Total execution time: 0.0247
INFO - 2020-07-28 18:37:42 --> Config Class Initialized
INFO - 2020-07-28 18:37:42 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:37:42 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:37:42 --> Utf8 Class Initialized
INFO - 2020-07-28 18:37:42 --> URI Class Initialized
INFO - 2020-07-28 18:37:42 --> Router Class Initialized
INFO - 2020-07-28 18:37:42 --> Output Class Initialized
INFO - 2020-07-28 18:37:42 --> Security Class Initialized
DEBUG - 2020-07-28 18:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:37:42 --> Input Class Initialized
INFO - 2020-07-28 18:37:42 --> Language Class Initialized
ERROR - 2020-07-28 18:37:42 --> 404 Page Not Found: Admin/Admin
INFO - 2020-07-28 18:38:29 --> Config Class Initialized
INFO - 2020-07-28 18:38:29 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:38:29 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:38:29 --> Utf8 Class Initialized
INFO - 2020-07-28 18:38:29 --> URI Class Initialized
INFO - 2020-07-28 18:38:29 --> Router Class Initialized
INFO - 2020-07-28 18:38:29 --> Output Class Initialized
INFO - 2020-07-28 18:38:29 --> Security Class Initialized
DEBUG - 2020-07-28 18:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:38:29 --> Input Class Initialized
INFO - 2020-07-28 18:38:29 --> Language Class Initialized
INFO - 2020-07-28 18:38:29 --> Loader Class Initialized
INFO - 2020-07-28 18:38:29 --> Helper loaded: url_helper
INFO - 2020-07-28 18:38:29 --> Database Driver Class Initialized
INFO - 2020-07-28 18:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:38:29 --> Email Class Initialized
INFO - 2020-07-28 18:38:29 --> Controller Class Initialized
INFO - 2020-07-28 18:38:29 --> Model Class Initialized
INFO - 2020-07-28 18:38:29 --> Model Class Initialized
DEBUG - 2020-07-28 18:38:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:38:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:40:08 --> Config Class Initialized
INFO - 2020-07-28 18:40:08 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:40:08 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:40:08 --> Utf8 Class Initialized
INFO - 2020-07-28 18:40:08 --> URI Class Initialized
INFO - 2020-07-28 18:40:08 --> Router Class Initialized
INFO - 2020-07-28 18:40:08 --> Output Class Initialized
INFO - 2020-07-28 18:40:08 --> Security Class Initialized
DEBUG - 2020-07-28 18:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:40:08 --> Input Class Initialized
INFO - 2020-07-28 18:40:08 --> Language Class Initialized
INFO - 2020-07-28 18:40:08 --> Loader Class Initialized
INFO - 2020-07-28 18:40:08 --> Helper loaded: url_helper
INFO - 2020-07-28 18:40:08 --> Database Driver Class Initialized
INFO - 2020-07-28 18:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:40:08 --> Email Class Initialized
INFO - 2020-07-28 18:40:08 --> Controller Class Initialized
INFO - 2020-07-28 18:40:08 --> Model Class Initialized
INFO - 2020-07-28 18:40:48 --> Config Class Initialized
INFO - 2020-07-28 18:40:48 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:40:48 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:40:48 --> Utf8 Class Initialized
INFO - 2020-07-28 18:40:48 --> URI Class Initialized
INFO - 2020-07-28 18:40:48 --> Router Class Initialized
INFO - 2020-07-28 18:40:48 --> Output Class Initialized
INFO - 2020-07-28 18:40:48 --> Security Class Initialized
DEBUG - 2020-07-28 18:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:40:48 --> Input Class Initialized
INFO - 2020-07-28 18:40:48 --> Language Class Initialized
INFO - 2020-07-28 18:40:48 --> Loader Class Initialized
INFO - 2020-07-28 18:40:48 --> Helper loaded: url_helper
INFO - 2020-07-28 18:40:48 --> Database Driver Class Initialized
INFO - 2020-07-28 18:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:40:48 --> Email Class Initialized
INFO - 2020-07-28 18:40:48 --> Controller Class Initialized
INFO - 2020-07-28 18:40:48 --> Model Class Initialized
INFO - 2020-07-28 18:41:01 --> Config Class Initialized
INFO - 2020-07-28 18:41:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:41:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:41:01 --> Utf8 Class Initialized
INFO - 2020-07-28 18:41:01 --> URI Class Initialized
DEBUG - 2020-07-28 18:41:01 --> No URI present. Default controller set.
INFO - 2020-07-28 18:41:01 --> Router Class Initialized
INFO - 2020-07-28 18:41:01 --> Output Class Initialized
INFO - 2020-07-28 18:41:01 --> Security Class Initialized
DEBUG - 2020-07-28 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:41:01 --> Input Class Initialized
INFO - 2020-07-28 18:41:01 --> Language Class Initialized
INFO - 2020-07-28 18:41:01 --> Loader Class Initialized
INFO - 2020-07-28 18:41:01 --> Helper loaded: url_helper
INFO - 2020-07-28 18:41:01 --> Database Driver Class Initialized
INFO - 2020-07-28 18:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:41:01 --> Email Class Initialized
INFO - 2020-07-28 18:41:01 --> Controller Class Initialized
INFO - 2020-07-28 18:41:01 --> Model Class Initialized
INFO - 2020-07-28 18:41:01 --> Model Class Initialized
DEBUG - 2020-07-28 18:41:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:41:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 18:41:01 --> Final output sent to browser
DEBUG - 2020-07-28 18:41:01 --> Total execution time: 0.0233
INFO - 2020-07-28 18:41:02 --> Config Class Initialized
INFO - 2020-07-28 18:41:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:41:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:41:02 --> Utf8 Class Initialized
INFO - 2020-07-28 18:41:02 --> URI Class Initialized
INFO - 2020-07-28 18:41:02 --> Router Class Initialized
INFO - 2020-07-28 18:41:02 --> Output Class Initialized
INFO - 2020-07-28 18:41:02 --> Security Class Initialized
DEBUG - 2020-07-28 18:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:41:02 --> Input Class Initialized
INFO - 2020-07-28 18:41:02 --> Language Class Initialized
INFO - 2020-07-28 18:41:02 --> Loader Class Initialized
INFO - 2020-07-28 18:41:02 --> Helper loaded: url_helper
INFO - 2020-07-28 18:41:03 --> Database Driver Class Initialized
INFO - 2020-07-28 18:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:41:03 --> Email Class Initialized
INFO - 2020-07-28 18:41:03 --> Controller Class Initialized
INFO - 2020-07-28 18:41:03 --> Model Class Initialized
INFO - 2020-07-28 18:41:03 --> Model Class Initialized
DEBUG - 2020-07-28 18:41:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:41:03 --> Config Class Initialized
INFO - 2020-07-28 18:41:03 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:41:03 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:41:03 --> Utf8 Class Initialized
INFO - 2020-07-28 18:41:03 --> URI Class Initialized
INFO - 2020-07-28 18:41:03 --> Router Class Initialized
INFO - 2020-07-28 18:41:03 --> Output Class Initialized
INFO - 2020-07-28 18:41:03 --> Security Class Initialized
DEBUG - 2020-07-28 18:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:41:03 --> Input Class Initialized
INFO - 2020-07-28 18:41:03 --> Language Class Initialized
INFO - 2020-07-28 18:41:03 --> Loader Class Initialized
INFO - 2020-07-28 18:41:03 --> Helper loaded: url_helper
INFO - 2020-07-28 18:41:03 --> Database Driver Class Initialized
INFO - 2020-07-28 18:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:41:03 --> Email Class Initialized
INFO - 2020-07-28 18:41:03 --> Controller Class Initialized
INFO - 2020-07-28 18:41:03 --> Model Class Initialized
INFO - 2020-07-28 18:41:24 --> Config Class Initialized
INFO - 2020-07-28 18:41:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:41:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:41:24 --> Utf8 Class Initialized
INFO - 2020-07-28 18:41:24 --> URI Class Initialized
DEBUG - 2020-07-28 18:41:24 --> No URI present. Default controller set.
INFO - 2020-07-28 18:41:24 --> Router Class Initialized
INFO - 2020-07-28 18:41:24 --> Output Class Initialized
INFO - 2020-07-28 18:41:24 --> Security Class Initialized
DEBUG - 2020-07-28 18:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:41:24 --> Input Class Initialized
INFO - 2020-07-28 18:41:24 --> Language Class Initialized
INFO - 2020-07-28 18:41:24 --> Loader Class Initialized
INFO - 2020-07-28 18:41:24 --> Helper loaded: url_helper
INFO - 2020-07-28 18:41:24 --> Database Driver Class Initialized
INFO - 2020-07-28 18:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:41:24 --> Email Class Initialized
INFO - 2020-07-28 18:41:24 --> Controller Class Initialized
INFO - 2020-07-28 18:41:24 --> Model Class Initialized
INFO - 2020-07-28 18:41:24 --> Model Class Initialized
DEBUG - 2020-07-28 18:41:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:41:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 18:41:24 --> Final output sent to browser
DEBUG - 2020-07-28 18:41:24 --> Total execution time: 0.0202
INFO - 2020-07-28 18:41:28 --> Config Class Initialized
INFO - 2020-07-28 18:41:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:41:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:41:28 --> Utf8 Class Initialized
INFO - 2020-07-28 18:41:28 --> URI Class Initialized
INFO - 2020-07-28 18:41:28 --> Router Class Initialized
INFO - 2020-07-28 18:41:28 --> Output Class Initialized
INFO - 2020-07-28 18:41:28 --> Security Class Initialized
DEBUG - 2020-07-28 18:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:41:28 --> Input Class Initialized
INFO - 2020-07-28 18:41:28 --> Language Class Initialized
INFO - 2020-07-28 18:41:28 --> Loader Class Initialized
INFO - 2020-07-28 18:41:28 --> Helper loaded: url_helper
INFO - 2020-07-28 18:41:28 --> Database Driver Class Initialized
INFO - 2020-07-28 18:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:41:28 --> Email Class Initialized
INFO - 2020-07-28 18:41:28 --> Controller Class Initialized
INFO - 2020-07-28 18:41:28 --> Model Class Initialized
INFO - 2020-07-28 18:41:28 --> Model Class Initialized
DEBUG - 2020-07-28 18:41:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:41:28 --> Config Class Initialized
INFO - 2020-07-28 18:41:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:41:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:41:28 --> Utf8 Class Initialized
INFO - 2020-07-28 18:41:28 --> URI Class Initialized
INFO - 2020-07-28 18:41:28 --> Router Class Initialized
INFO - 2020-07-28 18:41:28 --> Output Class Initialized
INFO - 2020-07-28 18:41:28 --> Security Class Initialized
DEBUG - 2020-07-28 18:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:41:28 --> Input Class Initialized
INFO - 2020-07-28 18:41:28 --> Language Class Initialized
INFO - 2020-07-28 18:41:28 --> Loader Class Initialized
INFO - 2020-07-28 18:41:28 --> Helper loaded: url_helper
INFO - 2020-07-28 18:41:28 --> Database Driver Class Initialized
INFO - 2020-07-28 18:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:41:28 --> Email Class Initialized
INFO - 2020-07-28 18:41:28 --> Controller Class Initialized
INFO - 2020-07-28 18:41:28 --> Model Class Initialized
INFO - 2020-07-28 18:44:19 --> Config Class Initialized
INFO - 2020-07-28 18:44:19 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:44:19 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:44:19 --> Utf8 Class Initialized
INFO - 2020-07-28 18:44:19 --> URI Class Initialized
INFO - 2020-07-28 18:44:19 --> Router Class Initialized
INFO - 2020-07-28 18:44:19 --> Output Class Initialized
INFO - 2020-07-28 18:44:19 --> Security Class Initialized
DEBUG - 2020-07-28 18:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:44:19 --> Input Class Initialized
INFO - 2020-07-28 18:44:19 --> Language Class Initialized
INFO - 2020-07-28 18:44:19 --> Loader Class Initialized
INFO - 2020-07-28 18:44:19 --> Helper loaded: url_helper
INFO - 2020-07-28 18:44:19 --> Database Driver Class Initialized
INFO - 2020-07-28 18:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:44:19 --> Email Class Initialized
INFO - 2020-07-28 18:44:19 --> Controller Class Initialized
DEBUG - 2020-07-28 18:44:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:44:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:44:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 18:44:19 --> Final output sent to browser
DEBUG - 2020-07-28 18:44:19 --> Total execution time: 0.0214
INFO - 2020-07-28 18:44:24 --> Config Class Initialized
INFO - 2020-07-28 18:44:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:44:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:44:24 --> Utf8 Class Initialized
INFO - 2020-07-28 18:44:24 --> URI Class Initialized
INFO - 2020-07-28 18:44:24 --> Router Class Initialized
INFO - 2020-07-28 18:44:24 --> Output Class Initialized
INFO - 2020-07-28 18:44:24 --> Security Class Initialized
DEBUG - 2020-07-28 18:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:44:24 --> Input Class Initialized
INFO - 2020-07-28 18:44:24 --> Language Class Initialized
INFO - 2020-07-28 18:44:24 --> Loader Class Initialized
INFO - 2020-07-28 18:44:24 --> Helper loaded: url_helper
INFO - 2020-07-28 18:44:24 --> Database Driver Class Initialized
INFO - 2020-07-28 18:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:44:24 --> Email Class Initialized
INFO - 2020-07-28 18:44:24 --> Controller Class Initialized
DEBUG - 2020-07-28 18:44:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:44:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:44:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 18:44:24 --> Final output sent to browser
DEBUG - 2020-07-28 18:44:24 --> Total execution time: 0.0220
INFO - 2020-07-28 18:44:26 --> Config Class Initialized
INFO - 2020-07-28 18:44:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:44:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:44:26 --> Utf8 Class Initialized
INFO - 2020-07-28 18:44:26 --> URI Class Initialized
INFO - 2020-07-28 18:44:26 --> Router Class Initialized
INFO - 2020-07-28 18:44:26 --> Output Class Initialized
INFO - 2020-07-28 18:44:26 --> Security Class Initialized
DEBUG - 2020-07-28 18:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:44:26 --> Input Class Initialized
INFO - 2020-07-28 18:44:26 --> Language Class Initialized
INFO - 2020-07-28 18:44:26 --> Loader Class Initialized
INFO - 2020-07-28 18:44:26 --> Helper loaded: url_helper
INFO - 2020-07-28 18:44:26 --> Database Driver Class Initialized
INFO - 2020-07-28 18:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:44:26 --> Email Class Initialized
INFO - 2020-07-28 18:44:26 --> Controller Class Initialized
DEBUG - 2020-07-28 18:44:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:44:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:44:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:44:26 --> Final output sent to browser
DEBUG - 2020-07-28 18:44:26 --> Total execution time: 0.0227
INFO - 2020-07-28 18:44:46 --> Config Class Initialized
INFO - 2020-07-28 18:44:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:44:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:44:46 --> Utf8 Class Initialized
INFO - 2020-07-28 18:44:46 --> URI Class Initialized
INFO - 2020-07-28 18:44:46 --> Router Class Initialized
INFO - 2020-07-28 18:44:46 --> Output Class Initialized
INFO - 2020-07-28 18:44:46 --> Security Class Initialized
DEBUG - 2020-07-28 18:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:44:46 --> Input Class Initialized
INFO - 2020-07-28 18:44:46 --> Language Class Initialized
ERROR - 2020-07-28 18:44:46 --> 404 Page Not Found: Admin/Admin
INFO - 2020-07-28 18:45:57 --> Config Class Initialized
INFO - 2020-07-28 18:45:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:45:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:45:57 --> Utf8 Class Initialized
INFO - 2020-07-28 18:45:57 --> URI Class Initialized
INFO - 2020-07-28 18:45:57 --> Router Class Initialized
INFO - 2020-07-28 18:45:57 --> Output Class Initialized
INFO - 2020-07-28 18:45:57 --> Security Class Initialized
DEBUG - 2020-07-28 18:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:45:57 --> Input Class Initialized
INFO - 2020-07-28 18:45:57 --> Language Class Initialized
INFO - 2020-07-28 18:45:57 --> Loader Class Initialized
INFO - 2020-07-28 18:45:57 --> Helper loaded: url_helper
INFO - 2020-07-28 18:45:57 --> Database Driver Class Initialized
INFO - 2020-07-28 18:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:45:57 --> Email Class Initialized
INFO - 2020-07-28 18:45:57 --> Controller Class Initialized
DEBUG - 2020-07-28 18:45:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:45:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:45:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:45:57 --> Final output sent to browser
DEBUG - 2020-07-28 18:45:57 --> Total execution time: 0.0196
INFO - 2020-07-28 18:46:01 --> Config Class Initialized
INFO - 2020-07-28 18:46:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:46:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:46:01 --> Utf8 Class Initialized
INFO - 2020-07-28 18:46:01 --> URI Class Initialized
INFO - 2020-07-28 18:46:01 --> Router Class Initialized
INFO - 2020-07-28 18:46:01 --> Output Class Initialized
INFO - 2020-07-28 18:46:01 --> Security Class Initialized
DEBUG - 2020-07-28 18:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:46:01 --> Input Class Initialized
INFO - 2020-07-28 18:46:01 --> Language Class Initialized
INFO - 2020-07-28 18:46:01 --> Loader Class Initialized
INFO - 2020-07-28 18:46:01 --> Helper loaded: url_helper
INFO - 2020-07-28 18:46:01 --> Database Driver Class Initialized
INFO - 2020-07-28 18:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:46:01 --> Email Class Initialized
INFO - 2020-07-28 18:46:01 --> Controller Class Initialized
DEBUG - 2020-07-28 18:46:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:46:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:46:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:46:01 --> Final output sent to browser
DEBUG - 2020-07-28 18:46:01 --> Total execution time: 0.0217
INFO - 2020-07-28 18:46:26 --> Config Class Initialized
INFO - 2020-07-28 18:46:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:46:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:46:26 --> Utf8 Class Initialized
INFO - 2020-07-28 18:46:26 --> URI Class Initialized
INFO - 2020-07-28 18:46:26 --> Router Class Initialized
INFO - 2020-07-28 18:46:26 --> Output Class Initialized
INFO - 2020-07-28 18:46:26 --> Security Class Initialized
DEBUG - 2020-07-28 18:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:46:26 --> Input Class Initialized
INFO - 2020-07-28 18:46:26 --> Language Class Initialized
INFO - 2020-07-28 18:46:26 --> Loader Class Initialized
INFO - 2020-07-28 18:46:26 --> Helper loaded: url_helper
INFO - 2020-07-28 18:46:26 --> Database Driver Class Initialized
INFO - 2020-07-28 18:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:46:26 --> Email Class Initialized
INFO - 2020-07-28 18:46:26 --> Controller Class Initialized
DEBUG - 2020-07-28 18:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:46:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:46:26 --> Model Class Initialized
INFO - 2020-07-28 18:46:55 --> Config Class Initialized
INFO - 2020-07-28 18:46:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:46:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:46:55 --> Utf8 Class Initialized
INFO - 2020-07-28 18:46:55 --> URI Class Initialized
INFO - 2020-07-28 18:46:55 --> Router Class Initialized
INFO - 2020-07-28 18:46:55 --> Output Class Initialized
INFO - 2020-07-28 18:46:55 --> Security Class Initialized
DEBUG - 2020-07-28 18:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:46:55 --> Input Class Initialized
INFO - 2020-07-28 18:46:55 --> Language Class Initialized
INFO - 2020-07-28 18:46:55 --> Loader Class Initialized
INFO - 2020-07-28 18:46:55 --> Helper loaded: url_helper
INFO - 2020-07-28 18:46:55 --> Database Driver Class Initialized
INFO - 2020-07-28 18:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:46:55 --> Email Class Initialized
INFO - 2020-07-28 18:46:55 --> Controller Class Initialized
DEBUG - 2020-07-28 18:46:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:46:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:46:55 --> Model Class Initialized
INFO - 2020-07-28 18:48:24 --> Config Class Initialized
INFO - 2020-07-28 18:48:24 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:48:24 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:48:24 --> Utf8 Class Initialized
INFO - 2020-07-28 18:48:24 --> URI Class Initialized
INFO - 2020-07-28 18:48:24 --> Router Class Initialized
INFO - 2020-07-28 18:48:24 --> Output Class Initialized
INFO - 2020-07-28 18:48:24 --> Security Class Initialized
DEBUG - 2020-07-28 18:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:48:24 --> Input Class Initialized
INFO - 2020-07-28 18:48:24 --> Language Class Initialized
INFO - 2020-07-28 18:48:24 --> Loader Class Initialized
INFO - 2020-07-28 18:48:24 --> Helper loaded: url_helper
INFO - 2020-07-28 18:48:24 --> Database Driver Class Initialized
INFO - 2020-07-28 18:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:48:24 --> Email Class Initialized
INFO - 2020-07-28 18:48:24 --> Controller Class Initialized
DEBUG - 2020-07-28 18:48:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:48:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:48:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:48:24 --> Final output sent to browser
DEBUG - 2020-07-28 18:48:24 --> Total execution time: 0.0210
INFO - 2020-07-28 18:48:27 --> Config Class Initialized
INFO - 2020-07-28 18:48:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:48:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:48:27 --> Utf8 Class Initialized
INFO - 2020-07-28 18:48:27 --> URI Class Initialized
INFO - 2020-07-28 18:48:27 --> Router Class Initialized
INFO - 2020-07-28 18:48:27 --> Output Class Initialized
INFO - 2020-07-28 18:48:27 --> Security Class Initialized
DEBUG - 2020-07-28 18:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:48:27 --> Input Class Initialized
INFO - 2020-07-28 18:48:27 --> Language Class Initialized
INFO - 2020-07-28 18:48:27 --> Loader Class Initialized
INFO - 2020-07-28 18:48:27 --> Helper loaded: url_helper
INFO - 2020-07-28 18:48:27 --> Database Driver Class Initialized
INFO - 2020-07-28 18:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:48:27 --> Email Class Initialized
INFO - 2020-07-28 18:48:27 --> Controller Class Initialized
DEBUG - 2020-07-28 18:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:48:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:48:27 --> Model Class Initialized
INFO - 2020-07-28 18:48:30 --> Config Class Initialized
INFO - 2020-07-28 18:48:30 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:48:30 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:48:30 --> Utf8 Class Initialized
INFO - 2020-07-28 18:48:30 --> URI Class Initialized
INFO - 2020-07-28 18:48:30 --> Router Class Initialized
INFO - 2020-07-28 18:48:30 --> Output Class Initialized
INFO - 2020-07-28 18:48:30 --> Security Class Initialized
DEBUG - 2020-07-28 18:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:48:30 --> Input Class Initialized
INFO - 2020-07-28 18:48:30 --> Language Class Initialized
INFO - 2020-07-28 18:48:30 --> Loader Class Initialized
INFO - 2020-07-28 18:48:30 --> Helper loaded: url_helper
INFO - 2020-07-28 18:48:30 --> Database Driver Class Initialized
INFO - 2020-07-28 18:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:48:30 --> Email Class Initialized
INFO - 2020-07-28 18:48:30 --> Controller Class Initialized
DEBUG - 2020-07-28 18:48:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:48:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:48:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:48:30 --> Final output sent to browser
DEBUG - 2020-07-28 18:48:30 --> Total execution time: 0.0236
INFO - 2020-07-28 18:48:31 --> Config Class Initialized
INFO - 2020-07-28 18:48:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:48:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:48:31 --> Utf8 Class Initialized
INFO - 2020-07-28 18:48:31 --> URI Class Initialized
INFO - 2020-07-28 18:48:31 --> Router Class Initialized
INFO - 2020-07-28 18:48:31 --> Output Class Initialized
INFO - 2020-07-28 18:48:31 --> Security Class Initialized
DEBUG - 2020-07-28 18:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:48:31 --> Input Class Initialized
INFO - 2020-07-28 18:48:31 --> Language Class Initialized
INFO - 2020-07-28 18:48:31 --> Loader Class Initialized
INFO - 2020-07-28 18:48:31 --> Helper loaded: url_helper
INFO - 2020-07-28 18:48:31 --> Database Driver Class Initialized
INFO - 2020-07-28 18:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:48:31 --> Email Class Initialized
INFO - 2020-07-28 18:48:31 --> Controller Class Initialized
DEBUG - 2020-07-28 18:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:48:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:48:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:48:31 --> Final output sent to browser
DEBUG - 2020-07-28 18:48:31 --> Total execution time: 0.0225
INFO - 2020-07-28 18:48:52 --> Config Class Initialized
INFO - 2020-07-28 18:48:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:48:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:48:52 --> Utf8 Class Initialized
INFO - 2020-07-28 18:48:52 --> URI Class Initialized
INFO - 2020-07-28 18:48:52 --> Router Class Initialized
INFO - 2020-07-28 18:48:52 --> Output Class Initialized
INFO - 2020-07-28 18:48:52 --> Security Class Initialized
DEBUG - 2020-07-28 18:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:48:52 --> Input Class Initialized
INFO - 2020-07-28 18:48:52 --> Language Class Initialized
INFO - 2020-07-28 18:48:52 --> Loader Class Initialized
INFO - 2020-07-28 18:48:52 --> Helper loaded: url_helper
INFO - 2020-07-28 18:48:52 --> Database Driver Class Initialized
INFO - 2020-07-28 18:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:48:52 --> Email Class Initialized
INFO - 2020-07-28 18:48:52 --> Controller Class Initialized
DEBUG - 2020-07-28 18:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:48:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:48:52 --> Model Class Initialized
INFO - 2020-07-28 18:51:52 --> Config Class Initialized
INFO - 2020-07-28 18:51:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:51:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:51:52 --> Utf8 Class Initialized
INFO - 2020-07-28 18:51:52 --> URI Class Initialized
INFO - 2020-07-28 18:51:52 --> Router Class Initialized
INFO - 2020-07-28 18:51:52 --> Output Class Initialized
INFO - 2020-07-28 18:51:52 --> Security Class Initialized
DEBUG - 2020-07-28 18:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:51:52 --> Input Class Initialized
INFO - 2020-07-28 18:51:52 --> Language Class Initialized
INFO - 2020-07-28 18:51:52 --> Loader Class Initialized
INFO - 2020-07-28 18:51:52 --> Helper loaded: url_helper
INFO - 2020-07-28 18:51:52 --> Database Driver Class Initialized
INFO - 2020-07-28 18:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:51:52 --> Email Class Initialized
INFO - 2020-07-28 18:51:52 --> Controller Class Initialized
INFO - 2020-07-28 18:51:52 --> Model Class Initialized
INFO - 2020-07-28 18:51:56 --> Config Class Initialized
INFO - 2020-07-28 18:51:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:51:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:51:56 --> Utf8 Class Initialized
INFO - 2020-07-28 18:51:56 --> URI Class Initialized
INFO - 2020-07-28 18:51:56 --> Router Class Initialized
INFO - 2020-07-28 18:51:56 --> Output Class Initialized
INFO - 2020-07-28 18:51:56 --> Security Class Initialized
DEBUG - 2020-07-28 18:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:51:56 --> Input Class Initialized
INFO - 2020-07-28 18:51:56 --> Language Class Initialized
INFO - 2020-07-28 18:51:56 --> Loader Class Initialized
INFO - 2020-07-28 18:51:56 --> Helper loaded: url_helper
INFO - 2020-07-28 18:51:56 --> Database Driver Class Initialized
INFO - 2020-07-28 18:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:51:56 --> Email Class Initialized
INFO - 2020-07-28 18:51:56 --> Controller Class Initialized
INFO - 2020-07-28 18:51:56 --> Model Class Initialized
INFO - 2020-07-28 18:51:59 --> Config Class Initialized
INFO - 2020-07-28 18:51:59 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:51:59 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:51:59 --> Utf8 Class Initialized
INFO - 2020-07-28 18:51:59 --> URI Class Initialized
INFO - 2020-07-28 18:51:59 --> Router Class Initialized
INFO - 2020-07-28 18:51:59 --> Output Class Initialized
INFO - 2020-07-28 18:51:59 --> Security Class Initialized
DEBUG - 2020-07-28 18:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:51:59 --> Input Class Initialized
INFO - 2020-07-28 18:51:59 --> Language Class Initialized
INFO - 2020-07-28 18:51:59 --> Loader Class Initialized
INFO - 2020-07-28 18:51:59 --> Helper loaded: url_helper
INFO - 2020-07-28 18:51:59 --> Database Driver Class Initialized
INFO - 2020-07-28 18:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:51:59 --> Email Class Initialized
INFO - 2020-07-28 18:51:59 --> Controller Class Initialized
INFO - 2020-07-28 18:51:59 --> Model Class Initialized
INFO - 2020-07-28 18:52:02 --> Config Class Initialized
INFO - 2020-07-28 18:52:02 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:52:02 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:52:02 --> Utf8 Class Initialized
INFO - 2020-07-28 18:52:02 --> URI Class Initialized
INFO - 2020-07-28 18:52:02 --> Router Class Initialized
INFO - 2020-07-28 18:52:02 --> Output Class Initialized
INFO - 2020-07-28 18:52:02 --> Security Class Initialized
DEBUG - 2020-07-28 18:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:52:02 --> Input Class Initialized
INFO - 2020-07-28 18:52:02 --> Language Class Initialized
INFO - 2020-07-28 18:52:02 --> Loader Class Initialized
INFO - 2020-07-28 18:52:02 --> Helper loaded: url_helper
INFO - 2020-07-28 18:52:02 --> Database Driver Class Initialized
INFO - 2020-07-28 18:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:52:02 --> Email Class Initialized
INFO - 2020-07-28 18:52:02 --> Controller Class Initialized
INFO - 2020-07-28 18:52:02 --> Model Class Initialized
INFO - 2020-07-28 18:52:12 --> Config Class Initialized
INFO - 2020-07-28 18:52:12 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:52:12 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:52:12 --> Utf8 Class Initialized
INFO - 2020-07-28 18:52:12 --> URI Class Initialized
DEBUG - 2020-07-28 18:52:12 --> No URI present. Default controller set.
INFO - 2020-07-28 18:52:12 --> Router Class Initialized
INFO - 2020-07-28 18:52:12 --> Output Class Initialized
INFO - 2020-07-28 18:52:12 --> Security Class Initialized
DEBUG - 2020-07-28 18:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:52:12 --> Input Class Initialized
INFO - 2020-07-28 18:52:12 --> Language Class Initialized
INFO - 2020-07-28 18:52:12 --> Loader Class Initialized
INFO - 2020-07-28 18:52:12 --> Helper loaded: url_helper
INFO - 2020-07-28 18:52:12 --> Database Driver Class Initialized
INFO - 2020-07-28 18:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:52:12 --> Email Class Initialized
INFO - 2020-07-28 18:52:12 --> Controller Class Initialized
INFO - 2020-07-28 18:52:12 --> Model Class Initialized
INFO - 2020-07-28 18:52:12 --> Model Class Initialized
DEBUG - 2020-07-28 18:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:52:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 18:52:12 --> Final output sent to browser
DEBUG - 2020-07-28 18:52:12 --> Total execution time: 0.0222
INFO - 2020-07-28 18:52:14 --> Config Class Initialized
INFO - 2020-07-28 18:52:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:52:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:52:14 --> Utf8 Class Initialized
INFO - 2020-07-28 18:52:14 --> URI Class Initialized
INFO - 2020-07-28 18:52:14 --> Router Class Initialized
INFO - 2020-07-28 18:52:14 --> Output Class Initialized
INFO - 2020-07-28 18:52:14 --> Security Class Initialized
DEBUG - 2020-07-28 18:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:52:14 --> Input Class Initialized
INFO - 2020-07-28 18:52:14 --> Language Class Initialized
INFO - 2020-07-28 18:52:14 --> Loader Class Initialized
INFO - 2020-07-28 18:52:14 --> Helper loaded: url_helper
INFO - 2020-07-28 18:52:14 --> Database Driver Class Initialized
INFO - 2020-07-28 18:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:52:14 --> Email Class Initialized
INFO - 2020-07-28 18:52:14 --> Controller Class Initialized
INFO - 2020-07-28 18:52:14 --> Model Class Initialized
INFO - 2020-07-28 18:52:14 --> Model Class Initialized
DEBUG - 2020-07-28 18:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:52:14 --> Config Class Initialized
INFO - 2020-07-28 18:52:14 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:52:14 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:52:14 --> Utf8 Class Initialized
INFO - 2020-07-28 18:52:14 --> URI Class Initialized
INFO - 2020-07-28 18:52:14 --> Router Class Initialized
INFO - 2020-07-28 18:52:14 --> Output Class Initialized
INFO - 2020-07-28 18:52:14 --> Security Class Initialized
DEBUG - 2020-07-28 18:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:52:14 --> Input Class Initialized
INFO - 2020-07-28 18:52:14 --> Language Class Initialized
INFO - 2020-07-28 18:52:14 --> Loader Class Initialized
INFO - 2020-07-28 18:52:14 --> Helper loaded: url_helper
INFO - 2020-07-28 18:52:15 --> Database Driver Class Initialized
INFO - 2020-07-28 18:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:52:15 --> Email Class Initialized
INFO - 2020-07-28 18:52:15 --> Controller Class Initialized
INFO - 2020-07-28 18:52:15 --> Model Class Initialized
INFO - 2020-07-28 18:52:37 --> Config Class Initialized
INFO - 2020-07-28 18:52:37 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:52:37 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:52:37 --> Utf8 Class Initialized
INFO - 2020-07-28 18:52:37 --> URI Class Initialized
INFO - 2020-07-28 18:52:37 --> Router Class Initialized
INFO - 2020-07-28 18:52:37 --> Output Class Initialized
INFO - 2020-07-28 18:52:37 --> Security Class Initialized
DEBUG - 2020-07-28 18:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:52:37 --> Input Class Initialized
INFO - 2020-07-28 18:52:37 --> Language Class Initialized
INFO - 2020-07-28 18:52:37 --> Loader Class Initialized
INFO - 2020-07-28 18:52:37 --> Helper loaded: url_helper
INFO - 2020-07-28 18:52:37 --> Database Driver Class Initialized
INFO - 2020-07-28 18:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:52:37 --> Email Class Initialized
INFO - 2020-07-28 18:52:37 --> Controller Class Initialized
DEBUG - 2020-07-28 18:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:52:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:52:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 18:52:37 --> Final output sent to browser
DEBUG - 2020-07-28 18:52:37 --> Total execution time: 0.0232
INFO - 2020-07-28 18:54:34 --> Config Class Initialized
INFO - 2020-07-28 18:54:34 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:54:34 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:54:34 --> Utf8 Class Initialized
INFO - 2020-07-28 18:54:34 --> URI Class Initialized
INFO - 2020-07-28 18:54:34 --> Router Class Initialized
INFO - 2020-07-28 18:54:34 --> Output Class Initialized
INFO - 2020-07-28 18:54:34 --> Security Class Initialized
DEBUG - 2020-07-28 18:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:54:34 --> Input Class Initialized
INFO - 2020-07-28 18:54:34 --> Language Class Initialized
INFO - 2020-07-28 18:54:34 --> Loader Class Initialized
INFO - 2020-07-28 18:54:34 --> Helper loaded: url_helper
INFO - 2020-07-28 18:54:34 --> Database Driver Class Initialized
INFO - 2020-07-28 18:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:54:34 --> Email Class Initialized
INFO - 2020-07-28 18:54:34 --> Controller Class Initialized
DEBUG - 2020-07-28 18:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:54:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:54:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 18:54:34 --> Final output sent to browser
DEBUG - 2020-07-28 18:54:34 --> Total execution time: 0.0184
INFO - 2020-07-28 18:54:35 --> Config Class Initialized
INFO - 2020-07-28 18:54:35 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:54:35 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:54:35 --> Utf8 Class Initialized
INFO - 2020-07-28 18:54:35 --> URI Class Initialized
INFO - 2020-07-28 18:54:35 --> Router Class Initialized
INFO - 2020-07-28 18:54:35 --> Output Class Initialized
INFO - 2020-07-28 18:54:35 --> Security Class Initialized
DEBUG - 2020-07-28 18:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:54:35 --> Input Class Initialized
INFO - 2020-07-28 18:54:35 --> Language Class Initialized
INFO - 2020-07-28 18:54:35 --> Loader Class Initialized
INFO - 2020-07-28 18:54:35 --> Helper loaded: url_helper
INFO - 2020-07-28 18:54:35 --> Database Driver Class Initialized
INFO - 2020-07-28 18:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:54:35 --> Email Class Initialized
INFO - 2020-07-28 18:54:35 --> Controller Class Initialized
DEBUG - 2020-07-28 18:54:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:54:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:54:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:54:35 --> Final output sent to browser
DEBUG - 2020-07-28 18:54:35 --> Total execution time: 0.0270
INFO - 2020-07-28 18:54:57 --> Config Class Initialized
INFO - 2020-07-28 18:54:57 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:54:57 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:54:57 --> Utf8 Class Initialized
INFO - 2020-07-28 18:54:57 --> URI Class Initialized
INFO - 2020-07-28 18:54:57 --> Router Class Initialized
INFO - 2020-07-28 18:54:57 --> Output Class Initialized
INFO - 2020-07-28 18:54:57 --> Security Class Initialized
DEBUG - 2020-07-28 18:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:54:57 --> Input Class Initialized
INFO - 2020-07-28 18:54:57 --> Language Class Initialized
INFO - 2020-07-28 18:54:57 --> Loader Class Initialized
INFO - 2020-07-28 18:54:57 --> Helper loaded: url_helper
INFO - 2020-07-28 18:54:57 --> Database Driver Class Initialized
INFO - 2020-07-28 18:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:54:57 --> Email Class Initialized
INFO - 2020-07-28 18:54:57 --> Controller Class Initialized
DEBUG - 2020-07-28 18:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:54:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:54:57 --> Model Class Initialized
INFO - 2020-07-28 18:54:57 --> Model Class Initialized
ERROR - 2020-07-28 18:54:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.'bcxbcv','bccvb','dz@weq','bcvbcv')' at line 1 - Invalid query: CALL dealer_reg('cxzvzxv','zvxzxv','vxzvxcv','xcvxvxc','4','1','cbxcb'.'bcxbcv','bccvb','dz@weq','bcvbcv')
INFO - 2020-07-28 18:54:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-28 18:54:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:60) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-28 18:57:01 --> Config Class Initialized
INFO - 2020-07-28 18:57:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:57:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:57:01 --> Utf8 Class Initialized
INFO - 2020-07-28 18:57:01 --> URI Class Initialized
INFO - 2020-07-28 18:57:01 --> Router Class Initialized
INFO - 2020-07-28 18:57:01 --> Output Class Initialized
INFO - 2020-07-28 18:57:01 --> Security Class Initialized
DEBUG - 2020-07-28 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:57:01 --> Input Class Initialized
INFO - 2020-07-28 18:57:01 --> Language Class Initialized
INFO - 2020-07-28 18:57:01 --> Loader Class Initialized
INFO - 2020-07-28 18:57:01 --> Helper loaded: url_helper
INFO - 2020-07-28 18:57:01 --> Database Driver Class Initialized
INFO - 2020-07-28 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:57:01 --> Email Class Initialized
INFO - 2020-07-28 18:57:01 --> Controller Class Initialized
DEBUG - 2020-07-28 18:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:57:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:57:01 --> Model Class Initialized
INFO - 2020-07-28 18:57:01 --> Model Class Initialized
ERROR - 2020-07-28 18:57:01 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 18:57:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:60) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 18:57:01 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 18:57:28 --> Config Class Initialized
INFO - 2020-07-28 18:57:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:57:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:57:28 --> Utf8 Class Initialized
INFO - 2020-07-28 18:57:28 --> URI Class Initialized
INFO - 2020-07-28 18:57:28 --> Router Class Initialized
INFO - 2020-07-28 18:57:28 --> Output Class Initialized
INFO - 2020-07-28 18:57:28 --> Security Class Initialized
DEBUG - 2020-07-28 18:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:57:28 --> Input Class Initialized
INFO - 2020-07-28 18:57:28 --> Language Class Initialized
INFO - 2020-07-28 18:57:28 --> Loader Class Initialized
INFO - 2020-07-28 18:57:28 --> Helper loaded: url_helper
INFO - 2020-07-28 18:57:28 --> Database Driver Class Initialized
INFO - 2020-07-28 18:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:57:28 --> Email Class Initialized
INFO - 2020-07-28 18:57:28 --> Controller Class Initialized
DEBUG - 2020-07-28 18:57:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:57:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:57:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 18:57:28 --> Final output sent to browser
DEBUG - 2020-07-28 18:57:28 --> Total execution time: 0.0203
INFO - 2020-07-28 18:57:31 --> Config Class Initialized
INFO - 2020-07-28 18:57:31 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:57:31 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:57:31 --> Utf8 Class Initialized
INFO - 2020-07-28 18:57:31 --> URI Class Initialized
INFO - 2020-07-28 18:57:31 --> Router Class Initialized
INFO - 2020-07-28 18:57:31 --> Output Class Initialized
INFO - 2020-07-28 18:57:31 --> Security Class Initialized
DEBUG - 2020-07-28 18:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:57:31 --> Input Class Initialized
INFO - 2020-07-28 18:57:31 --> Language Class Initialized
INFO - 2020-07-28 18:57:31 --> Loader Class Initialized
INFO - 2020-07-28 18:57:31 --> Helper loaded: url_helper
INFO - 2020-07-28 18:57:31 --> Database Driver Class Initialized
INFO - 2020-07-28 18:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:57:31 --> Email Class Initialized
INFO - 2020-07-28 18:57:31 --> Controller Class Initialized
DEBUG - 2020-07-28 18:57:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:57:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:57:31 --> Model Class Initialized
INFO - 2020-07-28 18:57:31 --> Model Class Initialized
ERROR - 2020-07-28 18:57:31 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 18:57:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:60) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 18:57:31 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 18:58:17 --> Config Class Initialized
INFO - 2020-07-28 18:58:17 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:58:17 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:58:17 --> Utf8 Class Initialized
INFO - 2020-07-28 18:58:17 --> URI Class Initialized
INFO - 2020-07-28 18:58:17 --> Router Class Initialized
INFO - 2020-07-28 18:58:17 --> Output Class Initialized
INFO - 2020-07-28 18:58:17 --> Security Class Initialized
DEBUG - 2020-07-28 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:58:17 --> Input Class Initialized
INFO - 2020-07-28 18:58:17 --> Language Class Initialized
INFO - 2020-07-28 18:58:17 --> Loader Class Initialized
INFO - 2020-07-28 18:58:17 --> Helper loaded: url_helper
INFO - 2020-07-28 18:58:17 --> Database Driver Class Initialized
INFO - 2020-07-28 18:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:58:17 --> Email Class Initialized
INFO - 2020-07-28 18:58:17 --> Controller Class Initialized
DEBUG - 2020-07-28 18:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:58:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:58:17 --> Model Class Initialized
INFO - 2020-07-28 18:58:17 --> Model Class Initialized
ERROR - 2020-07-28 18:58:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 18:58:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:60) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 18:58:17 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 18:58:22 --> Config Class Initialized
INFO - 2020-07-28 18:58:22 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:58:22 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:58:22 --> Utf8 Class Initialized
INFO - 2020-07-28 18:58:22 --> URI Class Initialized
INFO - 2020-07-28 18:58:22 --> Router Class Initialized
INFO - 2020-07-28 18:58:22 --> Output Class Initialized
INFO - 2020-07-28 18:58:22 --> Security Class Initialized
DEBUG - 2020-07-28 18:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:58:22 --> Input Class Initialized
INFO - 2020-07-28 18:58:22 --> Language Class Initialized
INFO - 2020-07-28 18:58:22 --> Loader Class Initialized
INFO - 2020-07-28 18:58:22 --> Helper loaded: url_helper
INFO - 2020-07-28 18:58:22 --> Database Driver Class Initialized
INFO - 2020-07-28 18:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:58:22 --> Email Class Initialized
INFO - 2020-07-28 18:58:22 --> Controller Class Initialized
DEBUG - 2020-07-28 18:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:58:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:58:22 --> Model Class Initialized
INFO - 2020-07-28 18:58:22 --> Model Class Initialized
ERROR - 2020-07-28 18:58:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 18:58:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:60) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 18:58:22 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 18:58:37 --> Config Class Initialized
INFO - 2020-07-28 18:58:37 --> Hooks Class Initialized
DEBUG - 2020-07-28 18:58:37 --> UTF-8 Support Enabled
INFO - 2020-07-28 18:58:37 --> Utf8 Class Initialized
INFO - 2020-07-28 18:58:37 --> URI Class Initialized
INFO - 2020-07-28 18:58:37 --> Router Class Initialized
INFO - 2020-07-28 18:58:37 --> Output Class Initialized
INFO - 2020-07-28 18:58:37 --> Security Class Initialized
DEBUG - 2020-07-28 18:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 18:58:37 --> Input Class Initialized
INFO - 2020-07-28 18:58:37 --> Language Class Initialized
INFO - 2020-07-28 18:58:37 --> Loader Class Initialized
INFO - 2020-07-28 18:58:37 --> Helper loaded: url_helper
INFO - 2020-07-28 18:58:37 --> Database Driver Class Initialized
INFO - 2020-07-28 18:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 18:58:37 --> Email Class Initialized
INFO - 2020-07-28 18:58:37 --> Controller Class Initialized
DEBUG - 2020-07-28 18:58:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 18:58:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 18:58:37 --> Model Class Initialized
INFO - 2020-07-28 18:58:37 --> Model Class Initialized
ERROR - 2020-07-28 18:58:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 18:58:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Admin.php:60) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 18:58:37 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 19:01:18 --> Config Class Initialized
INFO - 2020-07-28 19:01:18 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:01:18 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:01:18 --> Utf8 Class Initialized
INFO - 2020-07-28 19:01:18 --> URI Class Initialized
INFO - 2020-07-28 19:01:18 --> Router Class Initialized
INFO - 2020-07-28 19:01:18 --> Output Class Initialized
INFO - 2020-07-28 19:01:18 --> Security Class Initialized
DEBUG - 2020-07-28 19:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:01:18 --> Input Class Initialized
INFO - 2020-07-28 19:01:18 --> Language Class Initialized
INFO - 2020-07-28 19:01:18 --> Loader Class Initialized
INFO - 2020-07-28 19:01:18 --> Helper loaded: url_helper
INFO - 2020-07-28 19:01:18 --> Database Driver Class Initialized
INFO - 2020-07-28 19:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:01:18 --> Email Class Initialized
INFO - 2020-07-28 19:01:18 --> Controller Class Initialized
DEBUG - 2020-07-28 19:01:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:01:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:01:18 --> Model Class Initialized
INFO - 2020-07-28 19:01:18 --> Model Class Initialized
ERROR - 2020-07-28 19:01:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 19:01:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 19:01:18 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 19:03:55 --> Config Class Initialized
INFO - 2020-07-28 19:03:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:03:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:03:55 --> Utf8 Class Initialized
INFO - 2020-07-28 19:03:55 --> URI Class Initialized
INFO - 2020-07-28 19:03:55 --> Router Class Initialized
INFO - 2020-07-28 19:03:55 --> Output Class Initialized
INFO - 2020-07-28 19:03:55 --> Security Class Initialized
DEBUG - 2020-07-28 19:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:03:55 --> Input Class Initialized
INFO - 2020-07-28 19:03:55 --> Language Class Initialized
INFO - 2020-07-28 19:03:55 --> Loader Class Initialized
INFO - 2020-07-28 19:03:55 --> Helper loaded: url_helper
INFO - 2020-07-28 19:03:55 --> Database Driver Class Initialized
INFO - 2020-07-28 19:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:03:55 --> Email Class Initialized
INFO - 2020-07-28 19:03:55 --> Controller Class Initialized
DEBUG - 2020-07-28 19:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:03:55 --> Model Class Initialized
INFO - 2020-07-28 19:03:55 --> Model Class Initialized
ERROR - 2020-07-28 19:03:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:16) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 19:03:55 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 16
INFO - 2020-07-28 19:05:52 --> Config Class Initialized
INFO - 2020-07-28 19:05:52 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:05:52 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:05:52 --> Utf8 Class Initialized
INFO - 2020-07-28 19:05:52 --> URI Class Initialized
INFO - 2020-07-28 19:05:52 --> Router Class Initialized
INFO - 2020-07-28 19:05:52 --> Output Class Initialized
INFO - 2020-07-28 19:05:52 --> Security Class Initialized
DEBUG - 2020-07-28 19:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:05:52 --> Input Class Initialized
INFO - 2020-07-28 19:05:52 --> Language Class Initialized
INFO - 2020-07-28 19:05:52 --> Loader Class Initialized
INFO - 2020-07-28 19:05:52 --> Helper loaded: url_helper
INFO - 2020-07-28 19:05:52 --> Database Driver Class Initialized
INFO - 2020-07-28 19:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:05:52 --> Email Class Initialized
INFO - 2020-07-28 19:05:52 --> Controller Class Initialized
DEBUG - 2020-07-28 19:05:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:05:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:05:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 19:05:52 --> Final output sent to browser
DEBUG - 2020-07-28 19:05:52 --> Total execution time: 0.0237
INFO - 2020-07-28 19:06:27 --> Config Class Initialized
INFO - 2020-07-28 19:06:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:06:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:06:27 --> Utf8 Class Initialized
INFO - 2020-07-28 19:06:27 --> URI Class Initialized
INFO - 2020-07-28 19:06:27 --> Router Class Initialized
INFO - 2020-07-28 19:06:27 --> Output Class Initialized
INFO - 2020-07-28 19:06:27 --> Security Class Initialized
DEBUG - 2020-07-28 19:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:06:27 --> Input Class Initialized
INFO - 2020-07-28 19:06:27 --> Language Class Initialized
INFO - 2020-07-28 19:06:27 --> Loader Class Initialized
INFO - 2020-07-28 19:06:27 --> Helper loaded: url_helper
INFO - 2020-07-28 19:06:27 --> Database Driver Class Initialized
INFO - 2020-07-28 19:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:06:27 --> Email Class Initialized
INFO - 2020-07-28 19:06:27 --> Controller Class Initialized
DEBUG - 2020-07-28 19:06:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:06:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:06:27 --> Model Class Initialized
INFO - 2020-07-28 19:06:27 --> Model Class Initialized
ERROR - 2020-07-28 19:06:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 19:06:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 19:06:27 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 19:08:28 --> Config Class Initialized
INFO - 2020-07-28 19:08:28 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:08:28 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:08:28 --> Utf8 Class Initialized
INFO - 2020-07-28 19:08:28 --> URI Class Initialized
INFO - 2020-07-28 19:08:28 --> Router Class Initialized
INFO - 2020-07-28 19:08:28 --> Output Class Initialized
INFO - 2020-07-28 19:08:28 --> Security Class Initialized
DEBUG - 2020-07-28 19:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:08:28 --> Input Class Initialized
INFO - 2020-07-28 19:08:28 --> Language Class Initialized
INFO - 2020-07-28 19:08:28 --> Loader Class Initialized
INFO - 2020-07-28 19:08:28 --> Helper loaded: url_helper
INFO - 2020-07-28 19:08:28 --> Database Driver Class Initialized
INFO - 2020-07-28 19:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:08:28 --> Email Class Initialized
INFO - 2020-07-28 19:08:28 --> Controller Class Initialized
DEBUG - 2020-07-28 19:08:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:08:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:08:28 --> Model Class Initialized
INFO - 2020-07-28 19:08:28 --> Model Class Initialized
ERROR - 2020-07-28 19:08:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2020-07-28 19:08:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-28 19:08:28 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 25
INFO - 2020-07-28 19:08:46 --> Config Class Initialized
INFO - 2020-07-28 19:08:46 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:08:46 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:08:46 --> Utf8 Class Initialized
INFO - 2020-07-28 19:08:46 --> URI Class Initialized
INFO - 2020-07-28 19:08:46 --> Router Class Initialized
INFO - 2020-07-28 19:08:46 --> Output Class Initialized
INFO - 2020-07-28 19:08:46 --> Security Class Initialized
DEBUG - 2020-07-28 19:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:08:46 --> Input Class Initialized
INFO - 2020-07-28 19:08:46 --> Language Class Initialized
INFO - 2020-07-28 19:08:46 --> Loader Class Initialized
INFO - 2020-07-28 19:08:46 --> Helper loaded: url_helper
INFO - 2020-07-28 19:08:46 --> Database Driver Class Initialized
INFO - 2020-07-28 19:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:08:46 --> Email Class Initialized
INFO - 2020-07-28 19:08:46 --> Controller Class Initialized
DEBUG - 2020-07-28 19:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:08:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:08:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 19:08:46 --> Final output sent to browser
DEBUG - 2020-07-28 19:08:46 --> Total execution time: 0.0227
INFO - 2020-07-28 19:08:51 --> Config Class Initialized
INFO - 2020-07-28 19:08:51 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:08:51 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:08:51 --> Utf8 Class Initialized
INFO - 2020-07-28 19:08:51 --> URI Class Initialized
INFO - 2020-07-28 19:08:51 --> Router Class Initialized
INFO - 2020-07-28 19:08:51 --> Output Class Initialized
INFO - 2020-07-28 19:08:51 --> Security Class Initialized
DEBUG - 2020-07-28 19:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:08:51 --> Input Class Initialized
INFO - 2020-07-28 19:08:51 --> Language Class Initialized
INFO - 2020-07-28 19:08:51 --> Loader Class Initialized
INFO - 2020-07-28 19:08:51 --> Helper loaded: url_helper
INFO - 2020-07-28 19:08:51 --> Database Driver Class Initialized
INFO - 2020-07-28 19:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:08:51 --> Email Class Initialized
INFO - 2020-07-28 19:08:51 --> Controller Class Initialized
DEBUG - 2020-07-28 19:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:08:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:08:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 19:08:51 --> Final output sent to browser
DEBUG - 2020-07-28 19:08:51 --> Total execution time: 0.0190
INFO - 2020-07-28 19:08:53 --> Config Class Initialized
INFO - 2020-07-28 19:08:53 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:08:53 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:08:53 --> Utf8 Class Initialized
INFO - 2020-07-28 19:08:53 --> URI Class Initialized
DEBUG - 2020-07-28 19:08:53 --> No URI present. Default controller set.
INFO - 2020-07-28 19:08:53 --> Router Class Initialized
INFO - 2020-07-28 19:08:53 --> Output Class Initialized
INFO - 2020-07-28 19:08:53 --> Security Class Initialized
DEBUG - 2020-07-28 19:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:08:53 --> Input Class Initialized
INFO - 2020-07-28 19:08:53 --> Language Class Initialized
INFO - 2020-07-28 19:08:53 --> Loader Class Initialized
INFO - 2020-07-28 19:08:53 --> Helper loaded: url_helper
INFO - 2020-07-28 19:08:53 --> Database Driver Class Initialized
INFO - 2020-07-28 19:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:08:53 --> Email Class Initialized
INFO - 2020-07-28 19:08:53 --> Controller Class Initialized
INFO - 2020-07-28 19:08:53 --> Model Class Initialized
INFO - 2020-07-28 19:08:53 --> Model Class Initialized
DEBUG - 2020-07-28 19:08:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:08:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 19:08:53 --> Final output sent to browser
DEBUG - 2020-07-28 19:08:53 --> Total execution time: 0.0217
INFO - 2020-07-28 19:08:55 --> Config Class Initialized
INFO - 2020-07-28 19:08:55 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:08:55 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:08:55 --> Utf8 Class Initialized
INFO - 2020-07-28 19:08:55 --> URI Class Initialized
INFO - 2020-07-28 19:08:55 --> Router Class Initialized
INFO - 2020-07-28 19:08:55 --> Output Class Initialized
INFO - 2020-07-28 19:08:55 --> Security Class Initialized
DEBUG - 2020-07-28 19:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:08:55 --> Input Class Initialized
INFO - 2020-07-28 19:08:55 --> Language Class Initialized
INFO - 2020-07-28 19:08:55 --> Loader Class Initialized
INFO - 2020-07-28 19:08:55 --> Helper loaded: url_helper
INFO - 2020-07-28 19:08:55 --> Database Driver Class Initialized
INFO - 2020-07-28 19:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:08:55 --> Email Class Initialized
INFO - 2020-07-28 19:08:55 --> Controller Class Initialized
INFO - 2020-07-28 19:08:55 --> Model Class Initialized
INFO - 2020-07-28 19:08:55 --> Model Class Initialized
DEBUG - 2020-07-28 19:08:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:08:56 --> Config Class Initialized
INFO - 2020-07-28 19:08:56 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:08:56 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:08:56 --> Utf8 Class Initialized
INFO - 2020-07-28 19:08:56 --> URI Class Initialized
INFO - 2020-07-28 19:08:56 --> Router Class Initialized
INFO - 2020-07-28 19:08:56 --> Output Class Initialized
INFO - 2020-07-28 19:08:56 --> Security Class Initialized
DEBUG - 2020-07-28 19:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:08:56 --> Input Class Initialized
INFO - 2020-07-28 19:08:56 --> Language Class Initialized
INFO - 2020-07-28 19:08:56 --> Loader Class Initialized
INFO - 2020-07-28 19:08:56 --> Helper loaded: url_helper
INFO - 2020-07-28 19:08:56 --> Database Driver Class Initialized
INFO - 2020-07-28 19:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:08:56 --> Email Class Initialized
INFO - 2020-07-28 19:08:56 --> Controller Class Initialized
DEBUG - 2020-07-28 19:08:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:08:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:08:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 19:08:56 --> Final output sent to browser
DEBUG - 2020-07-28 19:08:56 --> Total execution time: 0.0215
INFO - 2020-07-28 19:09:01 --> Config Class Initialized
INFO - 2020-07-28 19:09:01 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:01 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:01 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:01 --> URI Class Initialized
DEBUG - 2020-07-28 19:09:01 --> No URI present. Default controller set.
INFO - 2020-07-28 19:09:01 --> Router Class Initialized
INFO - 2020-07-28 19:09:01 --> Output Class Initialized
INFO - 2020-07-28 19:09:01 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:01 --> Input Class Initialized
INFO - 2020-07-28 19:09:01 --> Language Class Initialized
INFO - 2020-07-28 19:09:01 --> Loader Class Initialized
INFO - 2020-07-28 19:09:01 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:01 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:01 --> Email Class Initialized
INFO - 2020-07-28 19:09:01 --> Controller Class Initialized
INFO - 2020-07-28 19:09:01 --> Model Class Initialized
INFO - 2020-07-28 19:09:01 --> Model Class Initialized
DEBUG - 2020-07-28 19:09:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 19:09:01 --> Final output sent to browser
DEBUG - 2020-07-28 19:09:01 --> Total execution time: 0.0222
INFO - 2020-07-28 19:09:04 --> Config Class Initialized
INFO - 2020-07-28 19:09:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:04 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:04 --> URI Class Initialized
INFO - 2020-07-28 19:09:04 --> Router Class Initialized
INFO - 2020-07-28 19:09:04 --> Output Class Initialized
INFO - 2020-07-28 19:09:04 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:04 --> Input Class Initialized
INFO - 2020-07-28 19:09:04 --> Language Class Initialized
INFO - 2020-07-28 19:09:04 --> Loader Class Initialized
INFO - 2020-07-28 19:09:04 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:04 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:04 --> Email Class Initialized
INFO - 2020-07-28 19:09:04 --> Controller Class Initialized
INFO - 2020-07-28 19:09:04 --> Model Class Initialized
INFO - 2020-07-28 19:09:04 --> Model Class Initialized
DEBUG - 2020-07-28 19:09:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:04 --> Config Class Initialized
INFO - 2020-07-28 19:09:04 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:04 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:04 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:04 --> URI Class Initialized
INFO - 2020-07-28 19:09:04 --> Router Class Initialized
INFO - 2020-07-28 19:09:04 --> Output Class Initialized
INFO - 2020-07-28 19:09:04 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:04 --> Input Class Initialized
INFO - 2020-07-28 19:09:04 --> Language Class Initialized
INFO - 2020-07-28 19:09:04 --> Loader Class Initialized
INFO - 2020-07-28 19:09:04 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:04 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:04 --> Email Class Initialized
INFO - 2020-07-28 19:09:04 --> Controller Class Initialized
DEBUG - 2020-07-28 19:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:09:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 19:09:04 --> Final output sent to browser
DEBUG - 2020-07-28 19:09:04 --> Total execution time: 0.0208
INFO - 2020-07-28 19:09:09 --> Config Class Initialized
INFO - 2020-07-28 19:09:09 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:09 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:09 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:09 --> URI Class Initialized
DEBUG - 2020-07-28 19:09:09 --> No URI present. Default controller set.
INFO - 2020-07-28 19:09:09 --> Router Class Initialized
INFO - 2020-07-28 19:09:09 --> Output Class Initialized
INFO - 2020-07-28 19:09:09 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:09 --> Input Class Initialized
INFO - 2020-07-28 19:09:09 --> Language Class Initialized
INFO - 2020-07-28 19:09:09 --> Loader Class Initialized
INFO - 2020-07-28 19:09:09 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:09 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:09 --> Email Class Initialized
INFO - 2020-07-28 19:09:09 --> Controller Class Initialized
INFO - 2020-07-28 19:09:09 --> Model Class Initialized
INFO - 2020-07-28 19:09:09 --> Model Class Initialized
DEBUG - 2020-07-28 19:09:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-28 19:09:09 --> Final output sent to browser
DEBUG - 2020-07-28 19:09:09 --> Total execution time: 0.0227
INFO - 2020-07-28 19:09:26 --> Config Class Initialized
INFO - 2020-07-28 19:09:26 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:26 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:26 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:26 --> URI Class Initialized
INFO - 2020-07-28 19:09:26 --> Router Class Initialized
INFO - 2020-07-28 19:09:26 --> Output Class Initialized
INFO - 2020-07-28 19:09:26 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:26 --> Input Class Initialized
INFO - 2020-07-28 19:09:26 --> Language Class Initialized
INFO - 2020-07-28 19:09:26 --> Loader Class Initialized
INFO - 2020-07-28 19:09:26 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:26 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:26 --> Email Class Initialized
INFO - 2020-07-28 19:09:26 --> Controller Class Initialized
INFO - 2020-07-28 19:09:26 --> Model Class Initialized
INFO - 2020-07-28 19:09:26 --> Model Class Initialized
DEBUG - 2020-07-28 19:09:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:27 --> Config Class Initialized
INFO - 2020-07-28 19:09:27 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:27 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:27 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:27 --> URI Class Initialized
INFO - 2020-07-28 19:09:27 --> Router Class Initialized
INFO - 2020-07-28 19:09:27 --> Output Class Initialized
INFO - 2020-07-28 19:09:27 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:27 --> Input Class Initialized
INFO - 2020-07-28 19:09:27 --> Language Class Initialized
INFO - 2020-07-28 19:09:27 --> Loader Class Initialized
INFO - 2020-07-28 19:09:27 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:27 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:27 --> Email Class Initialized
INFO - 2020-07-28 19:09:27 --> Controller Class Initialized
DEBUG - 2020-07-28 19:09:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:09:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-28 19:09:27 --> Final output sent to browser
DEBUG - 2020-07-28 19:09:27 --> Total execution time: 0.0186
INFO - 2020-07-28 19:09:32 --> Config Class Initialized
INFO - 2020-07-28 19:09:32 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:32 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:32 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:32 --> URI Class Initialized
INFO - 2020-07-28 19:09:32 --> Router Class Initialized
INFO - 2020-07-28 19:09:32 --> Output Class Initialized
INFO - 2020-07-28 19:09:32 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:32 --> Input Class Initialized
INFO - 2020-07-28 19:09:32 --> Language Class Initialized
INFO - 2020-07-28 19:09:32 --> Loader Class Initialized
INFO - 2020-07-28 19:09:32 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:32 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:32 --> Email Class Initialized
INFO - 2020-07-28 19:09:32 --> Controller Class Initialized
DEBUG - 2020-07-28 19:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:09:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-28 19:09:32 --> Final output sent to browser
DEBUG - 2020-07-28 19:09:32 --> Total execution time: 0.0217
INFO - 2020-07-28 19:09:36 --> Config Class Initialized
INFO - 2020-07-28 19:09:36 --> Hooks Class Initialized
DEBUG - 2020-07-28 19:09:36 --> UTF-8 Support Enabled
INFO - 2020-07-28 19:09:36 --> Utf8 Class Initialized
INFO - 2020-07-28 19:09:36 --> URI Class Initialized
INFO - 2020-07-28 19:09:36 --> Router Class Initialized
INFO - 2020-07-28 19:09:36 --> Output Class Initialized
INFO - 2020-07-28 19:09:36 --> Security Class Initialized
DEBUG - 2020-07-28 19:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-28 19:09:36 --> Input Class Initialized
INFO - 2020-07-28 19:09:36 --> Language Class Initialized
INFO - 2020-07-28 19:09:36 --> Loader Class Initialized
INFO - 2020-07-28 19:09:36 --> Helper loaded: url_helper
INFO - 2020-07-28 19:09:36 --> Database Driver Class Initialized
INFO - 2020-07-28 19:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-28 19:09:36 --> Email Class Initialized
INFO - 2020-07-28 19:09:36 --> Controller Class Initialized
DEBUG - 2020-07-28 19:09:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-28 19:09:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-28 19:09:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-28 19:09:36 --> Final output sent to browser
DEBUG - 2020-07-28 19:09:36 --> Total execution time: 0.0210
