<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-17 15:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-17 15:30:58 --> Config Class Initialized
INFO - 2020-10-17 15:30:58 --> Hooks Class Initialized
DEBUG - 2020-10-17 15:30:58 --> UTF-8 Support Enabled
INFO - 2020-10-17 15:30:58 --> Utf8 Class Initialized
INFO - 2020-10-17 15:30:58 --> URI Class Initialized
DEBUG - 2020-10-17 15:30:58 --> No URI present. Default controller set.
INFO - 2020-10-17 15:30:58 --> Router Class Initialized
INFO - 2020-10-17 15:30:58 --> Output Class Initialized
INFO - 2020-10-17 15:30:58 --> Security Class Initialized
DEBUG - 2020-10-17 15:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-17 15:30:58 --> Input Class Initialized
INFO - 2020-10-17 15:30:58 --> Language Class Initialized
INFO - 2020-10-17 15:30:58 --> Loader Class Initialized
INFO - 2020-10-17 15:30:58 --> Helper loaded: url_helper
INFO - 2020-10-17 15:30:58 --> Database Driver Class Initialized
INFO - 2020-10-17 15:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-17 15:30:58 --> Email Class Initialized
INFO - 2020-10-17 15:30:58 --> Controller Class Initialized
INFO - 2020-10-17 15:30:58 --> Model Class Initialized
INFO - 2020-10-17 15:30:58 --> Model Class Initialized
DEBUG - 2020-10-17 15:30:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-17 15:30:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-17 15:30:58 --> Final output sent to browser
DEBUG - 2020-10-17 15:30:58 --> Total execution time: 0.1421
