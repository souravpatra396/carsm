<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-01 09:04:27 --> Config Class Initialized
INFO - 2020-08-01 09:04:27 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:04:27 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:04:27 --> Utf8 Class Initialized
INFO - 2020-08-01 09:04:27 --> URI Class Initialized
DEBUG - 2020-08-01 09:04:27 --> No URI present. Default controller set.
INFO - 2020-08-01 09:04:27 --> Router Class Initialized
INFO - 2020-08-01 09:04:27 --> Output Class Initialized
INFO - 2020-08-01 09:04:27 --> Security Class Initialized
DEBUG - 2020-08-01 09:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:04:27 --> Input Class Initialized
INFO - 2020-08-01 09:04:27 --> Language Class Initialized
INFO - 2020-08-01 09:04:27 --> Loader Class Initialized
INFO - 2020-08-01 09:04:27 --> Helper loaded: url_helper
INFO - 2020-08-01 09:04:27 --> Database Driver Class Initialized
INFO - 2020-08-01 09:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:04:27 --> Email Class Initialized
INFO - 2020-08-01 09:04:27 --> Controller Class Initialized
INFO - 2020-08-01 09:04:27 --> Model Class Initialized
INFO - 2020-08-01 09:04:27 --> Model Class Initialized
DEBUG - 2020-08-01 09:04:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:04:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:04:27 --> Final output sent to browser
DEBUG - 2020-08-01 09:04:27 --> Total execution time: 0.2503
INFO - 2020-08-01 09:21:51 --> Config Class Initialized
INFO - 2020-08-01 09:21:51 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:21:51 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:21:51 --> Utf8 Class Initialized
INFO - 2020-08-01 09:21:51 --> URI Class Initialized
INFO - 2020-08-01 09:21:51 --> Router Class Initialized
INFO - 2020-08-01 09:21:51 --> Output Class Initialized
INFO - 2020-08-01 09:21:51 --> Security Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:21:51 --> Input Class Initialized
INFO - 2020-08-01 09:21:51 --> Language Class Initialized
INFO - 2020-08-01 09:21:51 --> Loader Class Initialized
INFO - 2020-08-01 09:21:51 --> Helper loaded: url_helper
INFO - 2020-08-01 09:21:51 --> Database Driver Class Initialized
INFO - 2020-08-01 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:21:51 --> Email Class Initialized
INFO - 2020-08-01 09:21:51 --> Controller Class Initialized
INFO - 2020-08-01 09:21:51 --> Model Class Initialized
INFO - 2020-08-01 09:21:51 --> Model Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:21:51 --> Config Class Initialized
INFO - 2020-08-01 09:21:51 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:21:51 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:21:51 --> Utf8 Class Initialized
INFO - 2020-08-01 09:21:51 --> URI Class Initialized
INFO - 2020-08-01 09:21:51 --> Router Class Initialized
INFO - 2020-08-01 09:21:51 --> Output Class Initialized
INFO - 2020-08-01 09:21:51 --> Security Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:21:51 --> Input Class Initialized
INFO - 2020-08-01 09:21:51 --> Language Class Initialized
INFO - 2020-08-01 09:21:51 --> Loader Class Initialized
INFO - 2020-08-01 09:21:51 --> Helper loaded: url_helper
INFO - 2020-08-01 09:21:51 --> Database Driver Class Initialized
INFO - 2020-08-01 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:21:51 --> Email Class Initialized
INFO - 2020-08-01 09:21:51 --> Controller Class Initialized
INFO - 2020-08-01 09:21:51 --> Model Class Initialized
INFO - 2020-08-01 09:21:51 --> Model Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:21:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:21:51 --> Config Class Initialized
INFO - 2020-08-01 09:21:51 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:21:51 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:21:51 --> Utf8 Class Initialized
INFO - 2020-08-01 09:21:51 --> URI Class Initialized
INFO - 2020-08-01 09:21:51 --> Router Class Initialized
INFO - 2020-08-01 09:21:51 --> Output Class Initialized
INFO - 2020-08-01 09:21:51 --> Security Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:21:51 --> Input Class Initialized
INFO - 2020-08-01 09:21:51 --> Language Class Initialized
INFO - 2020-08-01 09:21:51 --> Loader Class Initialized
INFO - 2020-08-01 09:21:51 --> Helper loaded: url_helper
INFO - 2020-08-01 09:21:51 --> Database Driver Class Initialized
INFO - 2020-08-01 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:21:51 --> Email Class Initialized
INFO - 2020-08-01 09:21:51 --> Controller Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:21:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:21:51 --> Config Class Initialized
INFO - 2020-08-01 09:21:51 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:21:51 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:21:51 --> Utf8 Class Initialized
INFO - 2020-08-01 09:21:51 --> URI Class Initialized
DEBUG - 2020-08-01 09:21:51 --> No URI present. Default controller set.
INFO - 2020-08-01 09:21:51 --> Router Class Initialized
INFO - 2020-08-01 09:21:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:21:51 --> Final output sent to browser
DEBUG - 2020-08-01 09:21:51 --> Total execution time: 0.0396
INFO - 2020-08-01 09:21:51 --> Output Class Initialized
INFO - 2020-08-01 09:21:51 --> Security Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:21:51 --> Input Class Initialized
INFO - 2020-08-01 09:21:51 --> Language Class Initialized
INFO - 2020-08-01 09:21:51 --> Loader Class Initialized
INFO - 2020-08-01 09:21:51 --> Helper loaded: url_helper
INFO - 2020-08-01 09:21:51 --> Database Driver Class Initialized
INFO - 2020-08-01 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:21:51 --> Email Class Initialized
INFO - 2020-08-01 09:21:51 --> Controller Class Initialized
INFO - 2020-08-01 09:21:51 --> Model Class Initialized
INFO - 2020-08-01 09:21:51 --> Model Class Initialized
DEBUG - 2020-08-01 09:21:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:21:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:21:51 --> Final output sent to browser
DEBUG - 2020-08-01 09:21:51 --> Total execution time: 0.0232
INFO - 2020-08-01 09:21:55 --> Config Class Initialized
INFO - 2020-08-01 09:21:55 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:21:55 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:21:55 --> Utf8 Class Initialized
INFO - 2020-08-01 09:21:55 --> URI Class Initialized
INFO - 2020-08-01 09:21:55 --> Router Class Initialized
INFO - 2020-08-01 09:21:55 --> Output Class Initialized
INFO - 2020-08-01 09:21:55 --> Security Class Initialized
DEBUG - 2020-08-01 09:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:21:55 --> Input Class Initialized
INFO - 2020-08-01 09:21:55 --> Language Class Initialized
INFO - 2020-08-01 09:21:55 --> Loader Class Initialized
INFO - 2020-08-01 09:21:55 --> Helper loaded: url_helper
INFO - 2020-08-01 09:21:55 --> Database Driver Class Initialized
INFO - 2020-08-01 09:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:21:55 --> Email Class Initialized
INFO - 2020-08-01 09:21:55 --> Controller Class Initialized
DEBUG - 2020-08-01 09:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:21:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:21:56 --> Config Class Initialized
INFO - 2020-08-01 09:21:56 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:21:56 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:21:56 --> Utf8 Class Initialized
INFO - 2020-08-01 09:21:56 --> URI Class Initialized
DEBUG - 2020-08-01 09:21:56 --> No URI present. Default controller set.
INFO - 2020-08-01 09:21:56 --> Router Class Initialized
INFO - 2020-08-01 09:21:56 --> Output Class Initialized
INFO - 2020-08-01 09:21:56 --> Security Class Initialized
DEBUG - 2020-08-01 09:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:21:56 --> Input Class Initialized
INFO - 2020-08-01 09:21:56 --> Language Class Initialized
INFO - 2020-08-01 09:21:56 --> Loader Class Initialized
INFO - 2020-08-01 09:21:56 --> Helper loaded: url_helper
INFO - 2020-08-01 09:21:56 --> Database Driver Class Initialized
INFO - 2020-08-01 09:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:21:56 --> Email Class Initialized
INFO - 2020-08-01 09:21:56 --> Controller Class Initialized
INFO - 2020-08-01 09:21:56 --> Model Class Initialized
INFO - 2020-08-01 09:21:56 --> Model Class Initialized
DEBUG - 2020-08-01 09:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:21:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:21:56 --> Final output sent to browser
DEBUG - 2020-08-01 09:21:56 --> Total execution time: 0.0228
INFO - 2020-08-01 09:22:00 --> Config Class Initialized
INFO - 2020-08-01 09:22:00 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:00 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:00 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:00 --> URI Class Initialized
INFO - 2020-08-01 09:22:00 --> Router Class Initialized
INFO - 2020-08-01 09:22:00 --> Output Class Initialized
INFO - 2020-08-01 09:22:00 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:00 --> Input Class Initialized
INFO - 2020-08-01 09:22:00 --> Language Class Initialized
INFO - 2020-08-01 09:22:00 --> Loader Class Initialized
INFO - 2020-08-01 09:22:00 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:00 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:00 --> Email Class Initialized
INFO - 2020-08-01 09:22:00 --> Controller Class Initialized
INFO - 2020-08-01 09:22:00 --> Model Class Initialized
INFO - 2020-08-01 09:22:00 --> Model Class Initialized
DEBUG - 2020-08-01 09:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:00 --> Config Class Initialized
INFO - 2020-08-01 09:22:00 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:00 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:00 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:00 --> URI Class Initialized
INFO - 2020-08-01 09:22:00 --> Router Class Initialized
INFO - 2020-08-01 09:22:00 --> Output Class Initialized
INFO - 2020-08-01 09:22:00 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:00 --> Input Class Initialized
INFO - 2020-08-01 09:22:00 --> Language Class Initialized
INFO - 2020-08-01 09:22:00 --> Loader Class Initialized
INFO - 2020-08-01 09:22:00 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:00 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:00 --> Email Class Initialized
INFO - 2020-08-01 09:22:00 --> Controller Class Initialized
INFO - 2020-08-01 09:22:00 --> Model Class Initialized
INFO - 2020-08-01 09:22:00 --> Model Class Initialized
DEBUG - 2020-08-01 09:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:22:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:00 --> Model Class Initialized
INFO - 2020-08-01 09:22:00 --> Final output sent to browser
DEBUG - 2020-08-01 09:22:00 --> Total execution time: 0.0226
INFO - 2020-08-01 09:22:00 --> Config Class Initialized
INFO - 2020-08-01 09:22:00 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:00 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:00 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:00 --> URI Class Initialized
INFO - 2020-08-01 09:22:00 --> Router Class Initialized
INFO - 2020-08-01 09:22:00 --> Output Class Initialized
INFO - 2020-08-01 09:22:00 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:00 --> Input Class Initialized
INFO - 2020-08-01 09:22:00 --> Language Class Initialized
INFO - 2020-08-01 09:22:00 --> Loader Class Initialized
INFO - 2020-08-01 09:22:00 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:00 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:00 --> Email Class Initialized
INFO - 2020-08-01 09:22:00 --> Controller Class Initialized
DEBUG - 2020-08-01 09:22:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:22:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:22:00 --> Final output sent to browser
DEBUG - 2020-08-01 09:22:00 --> Total execution time: 0.0222
INFO - 2020-08-01 09:22:03 --> Config Class Initialized
INFO - 2020-08-01 09:22:03 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:03 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:03 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:03 --> URI Class Initialized
INFO - 2020-08-01 09:22:03 --> Router Class Initialized
INFO - 2020-08-01 09:22:03 --> Output Class Initialized
INFO - 2020-08-01 09:22:03 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:03 --> Input Class Initialized
INFO - 2020-08-01 09:22:03 --> Language Class Initialized
INFO - 2020-08-01 09:22:03 --> Loader Class Initialized
INFO - 2020-08-01 09:22:03 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:03 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:03 --> Email Class Initialized
INFO - 2020-08-01 09:22:03 --> Controller Class Initialized
DEBUG - 2020-08-01 09:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:22:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:03 --> Model Class Initialized
INFO - 2020-08-01 09:22:03 --> Model Class Initialized
INFO - 2020-08-01 09:22:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:22:03 --> Final output sent to browser
DEBUG - 2020-08-01 09:22:03 --> Total execution time: 0.0611
INFO - 2020-08-01 09:22:06 --> Config Class Initialized
INFO - 2020-08-01 09:22:06 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:06 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:06 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:06 --> URI Class Initialized
INFO - 2020-08-01 09:22:06 --> Router Class Initialized
INFO - 2020-08-01 09:22:06 --> Output Class Initialized
INFO - 2020-08-01 09:22:06 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:06 --> Input Class Initialized
INFO - 2020-08-01 09:22:06 --> Language Class Initialized
INFO - 2020-08-01 09:22:06 --> Loader Class Initialized
INFO - 2020-08-01 09:22:06 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:06 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:06 --> Email Class Initialized
INFO - 2020-08-01 09:22:06 --> Controller Class Initialized
DEBUG - 2020-08-01 09:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:22:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:06 --> Model Class Initialized
INFO - 2020-08-01 09:22:06 --> Model Class Initialized
INFO - 2020-08-01 09:22:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-01 09:22:06 --> Final output sent to browser
DEBUG - 2020-08-01 09:22:06 --> Total execution time: 0.0300
INFO - 2020-08-01 09:22:29 --> Config Class Initialized
INFO - 2020-08-01 09:22:29 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:29 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:29 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:29 --> URI Class Initialized
INFO - 2020-08-01 09:22:29 --> Router Class Initialized
INFO - 2020-08-01 09:22:29 --> Output Class Initialized
INFO - 2020-08-01 09:22:29 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:29 --> Input Class Initialized
INFO - 2020-08-01 09:22:29 --> Language Class Initialized
INFO - 2020-08-01 09:22:29 --> Loader Class Initialized
INFO - 2020-08-01 09:22:29 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:29 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:29 --> Email Class Initialized
INFO - 2020-08-01 09:22:29 --> Controller Class Initialized
DEBUG - 2020-08-01 09:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:22:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:29 --> Model Class Initialized
INFO - 2020-08-01 09:22:29 --> Model Class Initialized
INFO - 2020-08-01 09:22:29 --> Model Class Initialized
ERROR - 2020-08-01 09:22:29 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL user_registration('s@gmail.com','sourav','1122222222','jhg','d176468b',6)
INFO - 2020-08-01 09:22:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-08-01 09:22:36 --> Config Class Initialized
INFO - 2020-08-01 09:22:36 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:22:36 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:22:36 --> Utf8 Class Initialized
INFO - 2020-08-01 09:22:36 --> URI Class Initialized
INFO - 2020-08-01 09:22:36 --> Router Class Initialized
INFO - 2020-08-01 09:22:36 --> Output Class Initialized
INFO - 2020-08-01 09:22:36 --> Security Class Initialized
DEBUG - 2020-08-01 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:22:36 --> Input Class Initialized
INFO - 2020-08-01 09:22:36 --> Language Class Initialized
INFO - 2020-08-01 09:22:36 --> Loader Class Initialized
INFO - 2020-08-01 09:22:36 --> Helper loaded: url_helper
INFO - 2020-08-01 09:22:36 --> Database Driver Class Initialized
INFO - 2020-08-01 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:22:36 --> Email Class Initialized
INFO - 2020-08-01 09:22:36 --> Controller Class Initialized
DEBUG - 2020-08-01 09:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:22:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:22:36 --> Model Class Initialized
INFO - 2020-08-01 09:22:36 --> Model Class Initialized
INFO - 2020-08-01 09:22:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:22:36 --> Final output sent to browser
DEBUG - 2020-08-01 09:22:36 --> Total execution time: 0.0259
INFO - 2020-08-01 09:28:45 --> Config Class Initialized
INFO - 2020-08-01 09:28:45 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:28:45 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:28:45 --> Utf8 Class Initialized
INFO - 2020-08-01 09:28:45 --> URI Class Initialized
INFO - 2020-08-01 09:28:45 --> Router Class Initialized
INFO - 2020-08-01 09:28:45 --> Output Class Initialized
INFO - 2020-08-01 09:28:45 --> Security Class Initialized
DEBUG - 2020-08-01 09:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:28:45 --> Input Class Initialized
INFO - 2020-08-01 09:28:45 --> Language Class Initialized
INFO - 2020-08-01 09:28:45 --> Loader Class Initialized
INFO - 2020-08-01 09:28:45 --> Helper loaded: url_helper
INFO - 2020-08-01 09:28:45 --> Database Driver Class Initialized
INFO - 2020-08-01 09:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:28:45 --> Email Class Initialized
INFO - 2020-08-01 09:28:45 --> Controller Class Initialized
DEBUG - 2020-08-01 09:28:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:28:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:28:45 --> Model Class Initialized
INFO - 2020-08-01 09:28:45 --> Model Class Initialized
INFO - 2020-08-01 09:28:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:28:45 --> Final output sent to browser
DEBUG - 2020-08-01 09:28:45 --> Total execution time: 0.0589
INFO - 2020-08-01 09:28:47 --> Config Class Initialized
INFO - 2020-08-01 09:28:47 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:28:47 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:28:47 --> Utf8 Class Initialized
INFO - 2020-08-01 09:28:47 --> URI Class Initialized
INFO - 2020-08-01 09:28:47 --> Router Class Initialized
INFO - 2020-08-01 09:28:47 --> Output Class Initialized
INFO - 2020-08-01 09:28:47 --> Security Class Initialized
DEBUG - 2020-08-01 09:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:28:47 --> Input Class Initialized
INFO - 2020-08-01 09:28:47 --> Language Class Initialized
INFO - 2020-08-01 09:28:47 --> Loader Class Initialized
INFO - 2020-08-01 09:28:47 --> Helper loaded: url_helper
INFO - 2020-08-01 09:28:47 --> Database Driver Class Initialized
INFO - 2020-08-01 09:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:28:47 --> Email Class Initialized
INFO - 2020-08-01 09:28:47 --> Controller Class Initialized
DEBUG - 2020-08-01 09:28:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:28:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:28:47 --> Model Class Initialized
INFO - 2020-08-01 09:28:47 --> Model Class Initialized
INFO - 2020-08-01 09:28:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-01 09:28:47 --> Final output sent to browser
DEBUG - 2020-08-01 09:28:47 --> Total execution time: 0.0208
INFO - 2020-08-01 09:29:04 --> Config Class Initialized
INFO - 2020-08-01 09:29:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:29:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:29:04 --> Utf8 Class Initialized
INFO - 2020-08-01 09:29:04 --> URI Class Initialized
INFO - 2020-08-01 09:29:04 --> Router Class Initialized
INFO - 2020-08-01 09:29:04 --> Output Class Initialized
INFO - 2020-08-01 09:29:04 --> Security Class Initialized
DEBUG - 2020-08-01 09:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:29:04 --> Input Class Initialized
INFO - 2020-08-01 09:29:04 --> Language Class Initialized
INFO - 2020-08-01 09:29:04 --> Loader Class Initialized
INFO - 2020-08-01 09:29:04 --> Helper loaded: url_helper
INFO - 2020-08-01 09:29:04 --> Database Driver Class Initialized
INFO - 2020-08-01 09:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:29:04 --> Email Class Initialized
INFO - 2020-08-01 09:29:04 --> Controller Class Initialized
DEBUG - 2020-08-01 09:29:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:29:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:29:04 --> Model Class Initialized
INFO - 2020-08-01 09:29:04 --> Model Class Initialized
INFO - 2020-08-01 09:29:04 --> Model Class Initialized
INFO - 2020-08-01 09:29:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:29:04 --> Final output sent to browser
DEBUG - 2020-08-01 09:29:04 --> Total execution time: 0.0619
INFO - 2020-08-01 09:31:35 --> Config Class Initialized
INFO - 2020-08-01 09:31:35 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:31:35 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:31:35 --> Utf8 Class Initialized
INFO - 2020-08-01 09:31:35 --> URI Class Initialized
INFO - 2020-08-01 09:31:35 --> Router Class Initialized
INFO - 2020-08-01 09:31:35 --> Output Class Initialized
INFO - 2020-08-01 09:31:35 --> Security Class Initialized
DEBUG - 2020-08-01 09:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:31:35 --> Input Class Initialized
INFO - 2020-08-01 09:31:35 --> Language Class Initialized
INFO - 2020-08-01 09:31:35 --> Loader Class Initialized
INFO - 2020-08-01 09:31:35 --> Helper loaded: url_helper
INFO - 2020-08-01 09:31:35 --> Database Driver Class Initialized
INFO - 2020-08-01 09:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:31:35 --> Email Class Initialized
INFO - 2020-08-01 09:31:35 --> Controller Class Initialized
DEBUG - 2020-08-01 09:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:31:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:31:35 --> Model Class Initialized
INFO - 2020-08-01 09:31:35 --> Model Class Initialized
INFO - 2020-08-01 09:31:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:31:35 --> Final output sent to browser
DEBUG - 2020-08-01 09:31:35 --> Total execution time: 0.0632
INFO - 2020-08-01 09:31:41 --> Config Class Initialized
INFO - 2020-08-01 09:31:41 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:31:41 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:31:41 --> Utf8 Class Initialized
INFO - 2020-08-01 09:31:41 --> URI Class Initialized
INFO - 2020-08-01 09:31:41 --> Router Class Initialized
INFO - 2020-08-01 09:31:41 --> Output Class Initialized
INFO - 2020-08-01 09:31:41 --> Security Class Initialized
DEBUG - 2020-08-01 09:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:31:41 --> Input Class Initialized
INFO - 2020-08-01 09:31:41 --> Language Class Initialized
INFO - 2020-08-01 09:31:41 --> Loader Class Initialized
INFO - 2020-08-01 09:31:41 --> Helper loaded: url_helper
INFO - 2020-08-01 09:31:41 --> Database Driver Class Initialized
INFO - 2020-08-01 09:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:31:42 --> Email Class Initialized
INFO - 2020-08-01 09:31:42 --> Controller Class Initialized
DEBUG - 2020-08-01 09:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:31:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:31:42 --> Model Class Initialized
INFO - 2020-08-01 09:31:42 --> Model Class Initialized
ERROR - 2020-08-01 09:31:42 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:31:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:31:42 --> Final output sent to browser
DEBUG - 2020-08-01 09:31:42 --> Total execution time: 0.0291
INFO - 2020-08-01 09:32:56 --> Config Class Initialized
INFO - 2020-08-01 09:32:56 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:32:56 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:32:56 --> Utf8 Class Initialized
INFO - 2020-08-01 09:32:56 --> URI Class Initialized
DEBUG - 2020-08-01 09:32:56 --> No URI present. Default controller set.
INFO - 2020-08-01 09:32:56 --> Router Class Initialized
INFO - 2020-08-01 09:32:56 --> Output Class Initialized
INFO - 2020-08-01 09:32:56 --> Security Class Initialized
DEBUG - 2020-08-01 09:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:32:56 --> Input Class Initialized
INFO - 2020-08-01 09:32:56 --> Language Class Initialized
INFO - 2020-08-01 09:32:56 --> Loader Class Initialized
INFO - 2020-08-01 09:32:56 --> Helper loaded: url_helper
INFO - 2020-08-01 09:32:56 --> Database Driver Class Initialized
INFO - 2020-08-01 09:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:32:56 --> Email Class Initialized
INFO - 2020-08-01 09:32:56 --> Controller Class Initialized
INFO - 2020-08-01 09:32:56 --> Model Class Initialized
INFO - 2020-08-01 09:32:56 --> Model Class Initialized
DEBUG - 2020-08-01 09:32:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:32:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:32:56 --> Final output sent to browser
DEBUG - 2020-08-01 09:32:56 --> Total execution time: 0.0224
INFO - 2020-08-01 09:32:58 --> Config Class Initialized
INFO - 2020-08-01 09:32:58 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:32:58 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:32:58 --> Utf8 Class Initialized
INFO - 2020-08-01 09:32:58 --> URI Class Initialized
INFO - 2020-08-01 09:32:58 --> Router Class Initialized
INFO - 2020-08-01 09:32:58 --> Output Class Initialized
INFO - 2020-08-01 09:32:58 --> Security Class Initialized
DEBUG - 2020-08-01 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:32:58 --> Input Class Initialized
INFO - 2020-08-01 09:32:58 --> Language Class Initialized
INFO - 2020-08-01 09:32:58 --> Loader Class Initialized
INFO - 2020-08-01 09:32:58 --> Helper loaded: url_helper
INFO - 2020-08-01 09:32:58 --> Database Driver Class Initialized
INFO - 2020-08-01 09:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:32:58 --> Email Class Initialized
INFO - 2020-08-01 09:32:58 --> Controller Class Initialized
INFO - 2020-08-01 09:32:58 --> Model Class Initialized
INFO - 2020-08-01 09:32:58 --> Model Class Initialized
DEBUG - 2020-08-01 09:32:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:32:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:32:58 --> Model Class Initialized
INFO - 2020-08-01 09:32:58 --> Final output sent to browser
DEBUG - 2020-08-01 09:32:58 --> Total execution time: 0.0242
INFO - 2020-08-01 09:32:58 --> Config Class Initialized
INFO - 2020-08-01 09:32:58 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:32:58 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:32:58 --> Utf8 Class Initialized
INFO - 2020-08-01 09:32:58 --> URI Class Initialized
INFO - 2020-08-01 09:32:58 --> Router Class Initialized
INFO - 2020-08-01 09:32:58 --> Output Class Initialized
INFO - 2020-08-01 09:32:58 --> Security Class Initialized
DEBUG - 2020-08-01 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:32:58 --> Input Class Initialized
INFO - 2020-08-01 09:32:58 --> Language Class Initialized
INFO - 2020-08-01 09:32:58 --> Loader Class Initialized
INFO - 2020-08-01 09:32:58 --> Helper loaded: url_helper
INFO - 2020-08-01 09:32:58 --> Database Driver Class Initialized
INFO - 2020-08-01 09:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:32:58 --> Email Class Initialized
INFO - 2020-08-01 09:32:58 --> Controller Class Initialized
INFO - 2020-08-01 09:32:58 --> Model Class Initialized
INFO - 2020-08-01 09:32:58 --> Model Class Initialized
DEBUG - 2020-08-01 09:32:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:32:58 --> Config Class Initialized
INFO - 2020-08-01 09:32:58 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:32:58 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:32:58 --> Utf8 Class Initialized
INFO - 2020-08-01 09:32:58 --> URI Class Initialized
INFO - 2020-08-01 09:32:58 --> Router Class Initialized
INFO - 2020-08-01 09:32:58 --> Output Class Initialized
INFO - 2020-08-01 09:32:58 --> Security Class Initialized
DEBUG - 2020-08-01 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:32:58 --> Input Class Initialized
INFO - 2020-08-01 09:32:58 --> Language Class Initialized
INFO - 2020-08-01 09:32:58 --> Loader Class Initialized
INFO - 2020-08-01 09:32:58 --> Helper loaded: url_helper
INFO - 2020-08-01 09:32:58 --> Database Driver Class Initialized
INFO - 2020-08-01 09:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:32:58 --> Email Class Initialized
INFO - 2020-08-01 09:32:58 --> Controller Class Initialized
DEBUG - 2020-08-01 09:32:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:32:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:32:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:32:58 --> Final output sent to browser
DEBUG - 2020-08-01 09:32:58 --> Total execution time: 0.0217
INFO - 2020-08-01 09:33:01 --> Config Class Initialized
INFO - 2020-08-01 09:33:01 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:33:01 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:33:01 --> Utf8 Class Initialized
INFO - 2020-08-01 09:33:01 --> URI Class Initialized
INFO - 2020-08-01 09:33:01 --> Router Class Initialized
INFO - 2020-08-01 09:33:01 --> Output Class Initialized
INFO - 2020-08-01 09:33:01 --> Security Class Initialized
DEBUG - 2020-08-01 09:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:33:01 --> Input Class Initialized
INFO - 2020-08-01 09:33:01 --> Language Class Initialized
INFO - 2020-08-01 09:33:01 --> Loader Class Initialized
INFO - 2020-08-01 09:33:01 --> Helper loaded: url_helper
INFO - 2020-08-01 09:33:01 --> Database Driver Class Initialized
INFO - 2020-08-01 09:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:33:01 --> Email Class Initialized
INFO - 2020-08-01 09:33:01 --> Controller Class Initialized
DEBUG - 2020-08-01 09:33:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:33:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:33:01 --> Model Class Initialized
INFO - 2020-08-01 09:33:01 --> Model Class Initialized
INFO - 2020-08-01 09:33:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:33:01 --> Final output sent to browser
DEBUG - 2020-08-01 09:33:01 --> Total execution time: 0.0366
INFO - 2020-08-01 09:33:04 --> Config Class Initialized
INFO - 2020-08-01 09:33:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:33:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:33:04 --> Utf8 Class Initialized
INFO - 2020-08-01 09:33:04 --> URI Class Initialized
INFO - 2020-08-01 09:33:04 --> Router Class Initialized
INFO - 2020-08-01 09:33:04 --> Output Class Initialized
INFO - 2020-08-01 09:33:04 --> Security Class Initialized
DEBUG - 2020-08-01 09:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:33:04 --> Input Class Initialized
INFO - 2020-08-01 09:33:04 --> Language Class Initialized
INFO - 2020-08-01 09:33:04 --> Loader Class Initialized
INFO - 2020-08-01 09:33:04 --> Helper loaded: url_helper
INFO - 2020-08-01 09:33:04 --> Database Driver Class Initialized
INFO - 2020-08-01 09:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:33:04 --> Email Class Initialized
INFO - 2020-08-01 09:33:04 --> Controller Class Initialized
DEBUG - 2020-08-01 09:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:33:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:33:04 --> Model Class Initialized
INFO - 2020-08-01 09:33:04 --> Model Class Initialized
INFO - 2020-08-01 09:33:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:33:04 --> Final output sent to browser
DEBUG - 2020-08-01 09:33:04 --> Total execution time: 0.0338
INFO - 2020-08-01 09:33:07 --> Config Class Initialized
INFO - 2020-08-01 09:33:07 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:33:07 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:33:07 --> Utf8 Class Initialized
INFO - 2020-08-01 09:33:07 --> URI Class Initialized
INFO - 2020-08-01 09:33:07 --> Router Class Initialized
INFO - 2020-08-01 09:33:07 --> Output Class Initialized
INFO - 2020-08-01 09:33:07 --> Security Class Initialized
DEBUG - 2020-08-01 09:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:33:07 --> Input Class Initialized
INFO - 2020-08-01 09:33:07 --> Language Class Initialized
INFO - 2020-08-01 09:33:07 --> Loader Class Initialized
INFO - 2020-08-01 09:33:07 --> Helper loaded: url_helper
INFO - 2020-08-01 09:33:07 --> Database Driver Class Initialized
INFO - 2020-08-01 09:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:33:07 --> Email Class Initialized
INFO - 2020-08-01 09:33:07 --> Controller Class Initialized
DEBUG - 2020-08-01 09:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:33:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:33:07 --> Model Class Initialized
INFO - 2020-08-01 09:33:07 --> Model Class Initialized
ERROR - 2020-08-01 09:33:07 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:33:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:33:07 --> Final output sent to browser
DEBUG - 2020-08-01 09:33:07 --> Total execution time: 0.0270
INFO - 2020-08-01 09:35:09 --> Config Class Initialized
INFO - 2020-08-01 09:35:09 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:09 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:09 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:09 --> URI Class Initialized
DEBUG - 2020-08-01 09:35:09 --> No URI present. Default controller set.
INFO - 2020-08-01 09:35:09 --> Router Class Initialized
INFO - 2020-08-01 09:35:09 --> Output Class Initialized
INFO - 2020-08-01 09:35:09 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:09 --> Input Class Initialized
INFO - 2020-08-01 09:35:09 --> Language Class Initialized
INFO - 2020-08-01 09:35:09 --> Loader Class Initialized
INFO - 2020-08-01 09:35:09 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:09 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:09 --> Email Class Initialized
INFO - 2020-08-01 09:35:09 --> Controller Class Initialized
INFO - 2020-08-01 09:35:09 --> Model Class Initialized
INFO - 2020-08-01 09:35:09 --> Model Class Initialized
DEBUG - 2020-08-01 09:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:35:09 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:09 --> Total execution time: 0.0316
INFO - 2020-08-01 09:35:11 --> Config Class Initialized
INFO - 2020-08-01 09:35:11 --> Hooks Class Initialized
INFO - 2020-08-01 09:35:11 --> Config Class Initialized
INFO - 2020-08-01 09:35:11 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:11 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:11 --> Utf8 Class Initialized
DEBUG - 2020-08-01 09:35:11 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:11 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:11 --> URI Class Initialized
INFO - 2020-08-01 09:35:11 --> URI Class Initialized
INFO - 2020-08-01 09:35:11 --> Router Class Initialized
INFO - 2020-08-01 09:35:11 --> Router Class Initialized
INFO - 2020-08-01 09:35:11 --> Output Class Initialized
INFO - 2020-08-01 09:35:11 --> Output Class Initialized
INFO - 2020-08-01 09:35:11 --> Security Class Initialized
INFO - 2020-08-01 09:35:11 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:11 --> Input Class Initialized
DEBUG - 2020-08-01 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:11 --> Input Class Initialized
INFO - 2020-08-01 09:35:11 --> Language Class Initialized
INFO - 2020-08-01 09:35:11 --> Language Class Initialized
INFO - 2020-08-01 09:35:11 --> Loader Class Initialized
INFO - 2020-08-01 09:35:11 --> Loader Class Initialized
INFO - 2020-08-01 09:35:11 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:11 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:11 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:11 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:11 --> Email Class Initialized
INFO - 2020-08-01 09:35:11 --> Controller Class Initialized
INFO - 2020-08-01 09:35:11 --> Model Class Initialized
INFO - 2020-08-01 09:35:11 --> Model Class Initialized
DEBUG - 2020-08-01 09:35:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:11 --> Email Class Initialized
INFO - 2020-08-01 09:35:11 --> Controller Class Initialized
INFO - 2020-08-01 09:35:11 --> Model Class Initialized
INFO - 2020-08-01 09:35:11 --> Model Class Initialized
DEBUG - 2020-08-01 09:35:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:11 --> Model Class Initialized
INFO - 2020-08-01 09:35:11 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:11 --> Total execution time: 0.0273
INFO - 2020-08-01 09:35:12 --> Config Class Initialized
INFO - 2020-08-01 09:35:12 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:12 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:12 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:12 --> URI Class Initialized
INFO - 2020-08-01 09:35:12 --> Router Class Initialized
INFO - 2020-08-01 09:35:12 --> Output Class Initialized
INFO - 2020-08-01 09:35:12 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:12 --> Input Class Initialized
INFO - 2020-08-01 09:35:12 --> Language Class Initialized
INFO - 2020-08-01 09:35:12 --> Loader Class Initialized
INFO - 2020-08-01 09:35:12 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:12 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:12 --> Email Class Initialized
INFO - 2020-08-01 09:35:12 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:35:12 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:12 --> Total execution time: 0.0194
INFO - 2020-08-01 09:35:15 --> Config Class Initialized
INFO - 2020-08-01 09:35:15 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:15 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:15 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:15 --> URI Class Initialized
INFO - 2020-08-01 09:35:15 --> Router Class Initialized
INFO - 2020-08-01 09:35:15 --> Output Class Initialized
INFO - 2020-08-01 09:35:15 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:15 --> Input Class Initialized
INFO - 2020-08-01 09:35:15 --> Language Class Initialized
INFO - 2020-08-01 09:35:15 --> Loader Class Initialized
INFO - 2020-08-01 09:35:15 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:15 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:15 --> Email Class Initialized
INFO - 2020-08-01 09:35:15 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:15 --> Model Class Initialized
INFO - 2020-08-01 09:35:15 --> Model Class Initialized
INFO - 2020-08-01 09:35:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:35:15 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:15 --> Total execution time: 0.0240
INFO - 2020-08-01 09:35:16 --> Config Class Initialized
INFO - 2020-08-01 09:35:16 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:16 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:16 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:16 --> URI Class Initialized
INFO - 2020-08-01 09:35:16 --> Router Class Initialized
INFO - 2020-08-01 09:35:16 --> Output Class Initialized
INFO - 2020-08-01 09:35:16 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:16 --> Input Class Initialized
INFO - 2020-08-01 09:35:16 --> Language Class Initialized
INFO - 2020-08-01 09:35:16 --> Loader Class Initialized
INFO - 2020-08-01 09:35:16 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:16 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:16 --> Email Class Initialized
INFO - 2020-08-01 09:35:16 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:16 --> Model Class Initialized
INFO - 2020-08-01 09:35:16 --> Model Class Initialized
INFO - 2020-08-01 09:35:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-01 09:35:16 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:16 --> Total execution time: 0.0232
INFO - 2020-08-01 09:35:20 --> Config Class Initialized
INFO - 2020-08-01 09:35:20 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:20 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:20 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:20 --> URI Class Initialized
INFO - 2020-08-01 09:35:20 --> Router Class Initialized
INFO - 2020-08-01 09:35:20 --> Output Class Initialized
INFO - 2020-08-01 09:35:20 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:20 --> Input Class Initialized
INFO - 2020-08-01 09:35:20 --> Language Class Initialized
INFO - 2020-08-01 09:35:20 --> Loader Class Initialized
INFO - 2020-08-01 09:35:20 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:20 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:20 --> Email Class Initialized
INFO - 2020-08-01 09:35:20 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:20 --> Model Class Initialized
INFO - 2020-08-01 09:35:20 --> Model Class Initialized
INFO - 2020-08-01 09:35:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:35:20 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:20 --> Total execution time: 0.0264
INFO - 2020-08-01 09:35:22 --> Config Class Initialized
INFO - 2020-08-01 09:35:22 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:22 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:22 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:22 --> URI Class Initialized
INFO - 2020-08-01 09:35:22 --> Router Class Initialized
INFO - 2020-08-01 09:35:22 --> Output Class Initialized
INFO - 2020-08-01 09:35:22 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:22 --> Input Class Initialized
INFO - 2020-08-01 09:35:22 --> Language Class Initialized
INFO - 2020-08-01 09:35:22 --> Loader Class Initialized
INFO - 2020-08-01 09:35:22 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:22 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:22 --> Email Class Initialized
INFO - 2020-08-01 09:35:22 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:22 --> Model Class Initialized
INFO - 2020-08-01 09:35:22 --> Model Class Initialized
INFO - 2020-08-01 09:35:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-01 09:35:22 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:22 --> Total execution time: 0.0355
INFO - 2020-08-01 09:35:24 --> Config Class Initialized
INFO - 2020-08-01 09:35:24 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:24 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:24 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:24 --> URI Class Initialized
INFO - 2020-08-01 09:35:24 --> Router Class Initialized
INFO - 2020-08-01 09:35:24 --> Output Class Initialized
INFO - 2020-08-01 09:35:24 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:24 --> Input Class Initialized
INFO - 2020-08-01 09:35:24 --> Language Class Initialized
INFO - 2020-08-01 09:35:24 --> Loader Class Initialized
INFO - 2020-08-01 09:35:24 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:24 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:24 --> Email Class Initialized
INFO - 2020-08-01 09:35:24 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:24 --> Model Class Initialized
INFO - 2020-08-01 09:35:24 --> Model Class Initialized
INFO - 2020-08-01 09:35:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:35:24 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:24 --> Total execution time: 0.0257
INFO - 2020-08-01 09:35:26 --> Config Class Initialized
INFO - 2020-08-01 09:35:26 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:26 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:26 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:26 --> URI Class Initialized
INFO - 2020-08-01 09:35:26 --> Router Class Initialized
INFO - 2020-08-01 09:35:26 --> Output Class Initialized
INFO - 2020-08-01 09:35:26 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:26 --> Input Class Initialized
INFO - 2020-08-01 09:35:26 --> Language Class Initialized
INFO - 2020-08-01 09:35:26 --> Loader Class Initialized
INFO - 2020-08-01 09:35:26 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:26 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:26 --> Email Class Initialized
INFO - 2020-08-01 09:35:26 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:26 --> Model Class Initialized
INFO - 2020-08-01 09:35:26 --> Model Class Initialized
INFO - 2020-08-01 09:35:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:35:26 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:26 --> Total execution time: 0.0249
INFO - 2020-08-01 09:35:28 --> Config Class Initialized
INFO - 2020-08-01 09:35:28 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:35:28 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:35:28 --> Utf8 Class Initialized
INFO - 2020-08-01 09:35:28 --> URI Class Initialized
INFO - 2020-08-01 09:35:28 --> Router Class Initialized
INFO - 2020-08-01 09:35:28 --> Output Class Initialized
INFO - 2020-08-01 09:35:28 --> Security Class Initialized
DEBUG - 2020-08-01 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:35:28 --> Input Class Initialized
INFO - 2020-08-01 09:35:28 --> Language Class Initialized
INFO - 2020-08-01 09:35:28 --> Loader Class Initialized
INFO - 2020-08-01 09:35:28 --> Helper loaded: url_helper
INFO - 2020-08-01 09:35:28 --> Database Driver Class Initialized
INFO - 2020-08-01 09:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:35:28 --> Email Class Initialized
INFO - 2020-08-01 09:35:28 --> Controller Class Initialized
DEBUG - 2020-08-01 09:35:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:35:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:35:28 --> Model Class Initialized
INFO - 2020-08-01 09:35:28 --> Model Class Initialized
ERROR - 2020-08-01 09:35:28 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:35:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:35:28 --> Final output sent to browser
DEBUG - 2020-08-01 09:35:28 --> Total execution time: 0.0262
INFO - 2020-08-01 09:40:07 --> Config Class Initialized
INFO - 2020-08-01 09:40:07 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:07 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:07 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:07 --> URI Class Initialized
DEBUG - 2020-08-01 09:40:07 --> No URI present. Default controller set.
INFO - 2020-08-01 09:40:07 --> Router Class Initialized
INFO - 2020-08-01 09:40:07 --> Output Class Initialized
INFO - 2020-08-01 09:40:07 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:07 --> Input Class Initialized
INFO - 2020-08-01 09:40:07 --> Language Class Initialized
INFO - 2020-08-01 09:40:07 --> Loader Class Initialized
INFO - 2020-08-01 09:40:07 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:07 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:07 --> Email Class Initialized
INFO - 2020-08-01 09:40:07 --> Controller Class Initialized
INFO - 2020-08-01 09:40:07 --> Model Class Initialized
INFO - 2020-08-01 09:40:07 --> Model Class Initialized
DEBUG - 2020-08-01 09:40:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:40:07 --> Final output sent to browser
DEBUG - 2020-08-01 09:40:07 --> Total execution time: 0.0243
INFO - 2020-08-01 09:40:10 --> Config Class Initialized
INFO - 2020-08-01 09:40:10 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:10 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:10 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:10 --> URI Class Initialized
INFO - 2020-08-01 09:40:10 --> Router Class Initialized
INFO - 2020-08-01 09:40:10 --> Output Class Initialized
INFO - 2020-08-01 09:40:10 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:10 --> Input Class Initialized
INFO - 2020-08-01 09:40:10 --> Language Class Initialized
INFO - 2020-08-01 09:40:10 --> Loader Class Initialized
INFO - 2020-08-01 09:40:10 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:10 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:10 --> Email Class Initialized
INFO - 2020-08-01 09:40:10 --> Controller Class Initialized
INFO - 2020-08-01 09:40:10 --> Model Class Initialized
INFO - 2020-08-01 09:40:10 --> Model Class Initialized
DEBUG - 2020-08-01 09:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:40:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:10 --> Model Class Initialized
INFO - 2020-08-01 09:40:10 --> Final output sent to browser
DEBUG - 2020-08-01 09:40:10 --> Total execution time: 0.0260
INFO - 2020-08-01 09:40:10 --> Config Class Initialized
INFO - 2020-08-01 09:40:10 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:10 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:10 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:10 --> URI Class Initialized
INFO - 2020-08-01 09:40:10 --> Router Class Initialized
INFO - 2020-08-01 09:40:10 --> Output Class Initialized
INFO - 2020-08-01 09:40:10 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:10 --> Input Class Initialized
INFO - 2020-08-01 09:40:10 --> Language Class Initialized
INFO - 2020-08-01 09:40:10 --> Loader Class Initialized
INFO - 2020-08-01 09:40:10 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:10 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:10 --> Email Class Initialized
INFO - 2020-08-01 09:40:10 --> Controller Class Initialized
INFO - 2020-08-01 09:40:10 --> Model Class Initialized
INFO - 2020-08-01 09:40:10 --> Model Class Initialized
DEBUG - 2020-08-01 09:40:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:10 --> Config Class Initialized
INFO - 2020-08-01 09:40:10 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:10 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:10 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:10 --> URI Class Initialized
INFO - 2020-08-01 09:40:10 --> Router Class Initialized
INFO - 2020-08-01 09:40:10 --> Output Class Initialized
INFO - 2020-08-01 09:40:10 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:10 --> Input Class Initialized
INFO - 2020-08-01 09:40:10 --> Language Class Initialized
INFO - 2020-08-01 09:40:10 --> Loader Class Initialized
INFO - 2020-08-01 09:40:10 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:10 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:10 --> Email Class Initialized
INFO - 2020-08-01 09:40:10 --> Controller Class Initialized
DEBUG - 2020-08-01 09:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:40:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:40:10 --> Final output sent to browser
DEBUG - 2020-08-01 09:40:10 --> Total execution time: 0.0238
INFO - 2020-08-01 09:40:13 --> Config Class Initialized
INFO - 2020-08-01 09:40:13 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:13 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:13 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:13 --> URI Class Initialized
INFO - 2020-08-01 09:40:13 --> Router Class Initialized
INFO - 2020-08-01 09:40:13 --> Output Class Initialized
INFO - 2020-08-01 09:40:13 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:13 --> Input Class Initialized
INFO - 2020-08-01 09:40:13 --> Language Class Initialized
INFO - 2020-08-01 09:40:13 --> Loader Class Initialized
INFO - 2020-08-01 09:40:13 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:13 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:13 --> Email Class Initialized
INFO - 2020-08-01 09:40:13 --> Controller Class Initialized
DEBUG - 2020-08-01 09:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:40:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:13 --> Model Class Initialized
INFO - 2020-08-01 09:40:13 --> Model Class Initialized
INFO - 2020-08-01 09:40:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:40:13 --> Final output sent to browser
DEBUG - 2020-08-01 09:40:13 --> Total execution time: 0.0349
INFO - 2020-08-01 09:40:16 --> Config Class Initialized
INFO - 2020-08-01 09:40:16 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:16 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:16 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:16 --> URI Class Initialized
INFO - 2020-08-01 09:40:16 --> Router Class Initialized
INFO - 2020-08-01 09:40:16 --> Output Class Initialized
INFO - 2020-08-01 09:40:16 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:16 --> Input Class Initialized
INFO - 2020-08-01 09:40:16 --> Language Class Initialized
INFO - 2020-08-01 09:40:16 --> Loader Class Initialized
INFO - 2020-08-01 09:40:16 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:16 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:16 --> Email Class Initialized
INFO - 2020-08-01 09:40:16 --> Controller Class Initialized
DEBUG - 2020-08-01 09:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:40:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:16 --> Model Class Initialized
INFO - 2020-08-01 09:40:16 --> Model Class Initialized
INFO - 2020-08-01 09:40:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:40:16 --> Final output sent to browser
DEBUG - 2020-08-01 09:40:16 --> Total execution time: 0.0223
INFO - 2020-08-01 09:40:18 --> Config Class Initialized
INFO - 2020-08-01 09:40:18 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:40:18 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:40:18 --> Utf8 Class Initialized
INFO - 2020-08-01 09:40:18 --> URI Class Initialized
INFO - 2020-08-01 09:40:18 --> Router Class Initialized
INFO - 2020-08-01 09:40:18 --> Output Class Initialized
INFO - 2020-08-01 09:40:18 --> Security Class Initialized
DEBUG - 2020-08-01 09:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:40:18 --> Input Class Initialized
INFO - 2020-08-01 09:40:18 --> Language Class Initialized
INFO - 2020-08-01 09:40:18 --> Loader Class Initialized
INFO - 2020-08-01 09:40:18 --> Helper loaded: url_helper
INFO - 2020-08-01 09:40:18 --> Database Driver Class Initialized
INFO - 2020-08-01 09:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:40:18 --> Email Class Initialized
INFO - 2020-08-01 09:40:18 --> Controller Class Initialized
DEBUG - 2020-08-01 09:40:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:40:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:40:18 --> Model Class Initialized
INFO - 2020-08-01 09:40:18 --> Model Class Initialized
ERROR - 2020-08-01 09:40:18 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:40:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:40:18 --> Final output sent to browser
DEBUG - 2020-08-01 09:40:18 --> Total execution time: 0.0286
INFO - 2020-08-01 09:41:18 --> Config Class Initialized
INFO - 2020-08-01 09:41:18 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:41:18 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:41:18 --> Utf8 Class Initialized
INFO - 2020-08-01 09:41:18 --> URI Class Initialized
INFO - 2020-08-01 09:41:18 --> Router Class Initialized
INFO - 2020-08-01 09:41:18 --> Output Class Initialized
INFO - 2020-08-01 09:41:18 --> Security Class Initialized
DEBUG - 2020-08-01 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:41:18 --> Input Class Initialized
INFO - 2020-08-01 09:41:18 --> Language Class Initialized
INFO - 2020-08-01 09:41:18 --> Loader Class Initialized
INFO - 2020-08-01 09:41:18 --> Helper loaded: url_helper
INFO - 2020-08-01 09:41:18 --> Database Driver Class Initialized
INFO - 2020-08-01 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:41:18 --> Email Class Initialized
INFO - 2020-08-01 09:41:18 --> Controller Class Initialized
DEBUG - 2020-08-01 09:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:41:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:41:18 --> Model Class Initialized
INFO - 2020-08-01 09:41:18 --> Model Class Initialized
INFO - 2020-08-01 09:41:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:41:18 --> Final output sent to browser
DEBUG - 2020-08-01 09:41:18 --> Total execution time: 0.0278
INFO - 2020-08-01 09:41:21 --> Config Class Initialized
INFO - 2020-08-01 09:41:21 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:41:21 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:41:21 --> Utf8 Class Initialized
INFO - 2020-08-01 09:41:21 --> URI Class Initialized
INFO - 2020-08-01 09:41:21 --> Router Class Initialized
INFO - 2020-08-01 09:41:21 --> Output Class Initialized
INFO - 2020-08-01 09:41:21 --> Security Class Initialized
DEBUG - 2020-08-01 09:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:41:21 --> Input Class Initialized
INFO - 2020-08-01 09:41:21 --> Language Class Initialized
INFO - 2020-08-01 09:41:21 --> Loader Class Initialized
INFO - 2020-08-01 09:41:21 --> Helper loaded: url_helper
INFO - 2020-08-01 09:41:21 --> Database Driver Class Initialized
INFO - 2020-08-01 09:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:41:21 --> Email Class Initialized
INFO - 2020-08-01 09:41:21 --> Controller Class Initialized
DEBUG - 2020-08-01 09:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:41:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:41:21 --> Model Class Initialized
INFO - 2020-08-01 09:41:21 --> Model Class Initialized
INFO - 2020-08-01 09:41:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:41:21 --> Final output sent to browser
DEBUG - 2020-08-01 09:41:21 --> Total execution time: 0.0238
INFO - 2020-08-01 09:41:23 --> Config Class Initialized
INFO - 2020-08-01 09:41:23 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:41:23 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:41:23 --> Utf8 Class Initialized
INFO - 2020-08-01 09:41:23 --> URI Class Initialized
INFO - 2020-08-01 09:41:23 --> Router Class Initialized
INFO - 2020-08-01 09:41:23 --> Output Class Initialized
INFO - 2020-08-01 09:41:23 --> Security Class Initialized
DEBUG - 2020-08-01 09:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:41:23 --> Input Class Initialized
INFO - 2020-08-01 09:41:23 --> Language Class Initialized
INFO - 2020-08-01 09:41:23 --> Loader Class Initialized
INFO - 2020-08-01 09:41:23 --> Helper loaded: url_helper
INFO - 2020-08-01 09:41:23 --> Database Driver Class Initialized
INFO - 2020-08-01 09:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:41:23 --> Email Class Initialized
INFO - 2020-08-01 09:41:23 --> Controller Class Initialized
DEBUG - 2020-08-01 09:41:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:41:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:41:23 --> Model Class Initialized
INFO - 2020-08-01 09:41:23 --> Model Class Initialized
ERROR - 2020-08-01 09:41:23 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:41:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:41:23 --> Final output sent to browser
DEBUG - 2020-08-01 09:41:23 --> Total execution time: 0.0249
INFO - 2020-08-01 09:42:26 --> Config Class Initialized
INFO - 2020-08-01 09:42:26 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:42:26 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:42:26 --> Utf8 Class Initialized
INFO - 2020-08-01 09:42:26 --> URI Class Initialized
INFO - 2020-08-01 09:42:26 --> Router Class Initialized
INFO - 2020-08-01 09:42:26 --> Output Class Initialized
INFO - 2020-08-01 09:42:26 --> Security Class Initialized
DEBUG - 2020-08-01 09:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:42:26 --> Input Class Initialized
INFO - 2020-08-01 09:42:26 --> Language Class Initialized
INFO - 2020-08-01 09:42:26 --> Loader Class Initialized
INFO - 2020-08-01 09:42:26 --> Helper loaded: url_helper
INFO - 2020-08-01 09:42:26 --> Database Driver Class Initialized
INFO - 2020-08-01 09:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:42:26 --> Email Class Initialized
INFO - 2020-08-01 09:42:26 --> Controller Class Initialized
DEBUG - 2020-08-01 09:42:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:42:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:42:26 --> Model Class Initialized
INFO - 2020-08-01 09:42:26 --> Model Class Initialized
INFO - 2020-08-01 09:42:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-01 09:42:26 --> Final output sent to browser
DEBUG - 2020-08-01 09:42:26 --> Total execution time: 0.0213
INFO - 2020-08-01 09:42:43 --> Config Class Initialized
INFO - 2020-08-01 09:42:43 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:42:43 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:42:43 --> Utf8 Class Initialized
INFO - 2020-08-01 09:42:43 --> URI Class Initialized
INFO - 2020-08-01 09:42:43 --> Router Class Initialized
INFO - 2020-08-01 09:42:43 --> Output Class Initialized
INFO - 2020-08-01 09:42:43 --> Security Class Initialized
DEBUG - 2020-08-01 09:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:42:43 --> Input Class Initialized
INFO - 2020-08-01 09:42:43 --> Language Class Initialized
INFO - 2020-08-01 09:42:43 --> Loader Class Initialized
INFO - 2020-08-01 09:42:43 --> Helper loaded: url_helper
INFO - 2020-08-01 09:42:43 --> Database Driver Class Initialized
INFO - 2020-08-01 09:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:42:43 --> Email Class Initialized
INFO - 2020-08-01 09:42:43 --> Controller Class Initialized
DEBUG - 2020-08-01 09:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:42:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:42:43 --> Model Class Initialized
INFO - 2020-08-01 09:42:43 --> Model Class Initialized
INFO - 2020-08-01 09:42:43 --> Model Class Initialized
INFO - 2020-08-01 09:42:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:42:43 --> Final output sent to browser
DEBUG - 2020-08-01 09:42:43 --> Total execution time: 0.0764
INFO - 2020-08-01 09:44:13 --> Config Class Initialized
INFO - 2020-08-01 09:44:13 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:44:13 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:44:13 --> Utf8 Class Initialized
INFO - 2020-08-01 09:44:13 --> URI Class Initialized
INFO - 2020-08-01 09:44:13 --> Router Class Initialized
INFO - 2020-08-01 09:44:13 --> Output Class Initialized
INFO - 2020-08-01 09:44:13 --> Config Class Initialized
INFO - 2020-08-01 09:44:13 --> Hooks Class Initialized
INFO - 2020-08-01 09:44:13 --> Security Class Initialized
DEBUG - 2020-08-01 09:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:44:13 --> Input Class Initialized
INFO - 2020-08-01 09:44:13 --> Language Class Initialized
DEBUG - 2020-08-01 09:44:13 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:44:13 --> Utf8 Class Initialized
INFO - 2020-08-01 09:44:13 --> URI Class Initialized
INFO - 2020-08-01 09:44:13 --> Loader Class Initialized
INFO - 2020-08-01 09:44:13 --> Router Class Initialized
INFO - 2020-08-01 09:44:13 --> Helper loaded: url_helper
INFO - 2020-08-01 09:44:13 --> Output Class Initialized
INFO - 2020-08-01 09:44:13 --> Security Class Initialized
DEBUG - 2020-08-01 09:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:44:13 --> Input Class Initialized
INFO - 2020-08-01 09:44:13 --> Language Class Initialized
INFO - 2020-08-01 09:44:13 --> Database Driver Class Initialized
INFO - 2020-08-01 09:44:13 --> Loader Class Initialized
INFO - 2020-08-01 09:44:13 --> Helper loaded: url_helper
INFO - 2020-08-01 09:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:44:13 --> Email Class Initialized
INFO - 2020-08-01 09:44:13 --> Controller Class Initialized
DEBUG - 2020-08-01 09:44:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:44:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:44:13 --> Model Class Initialized
INFO - 2020-08-01 09:44:13 --> Model Class Initialized
INFO - 2020-08-01 09:44:13 --> Database Driver Class Initialized
INFO - 2020-08-01 09:44:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:44:13 --> Final output sent to browser
DEBUG - 2020-08-01 09:44:13 --> Total execution time: 0.0312
INFO - 2020-08-01 09:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:44:13 --> Email Class Initialized
INFO - 2020-08-01 09:44:13 --> Controller Class Initialized
DEBUG - 2020-08-01 09:44:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:44:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:44:13 --> Model Class Initialized
INFO - 2020-08-01 09:44:13 --> Model Class Initialized
INFO - 2020-08-01 09:44:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:44:13 --> Final output sent to browser
DEBUG - 2020-08-01 09:44:13 --> Total execution time: 0.0355
INFO - 2020-08-01 09:44:15 --> Config Class Initialized
INFO - 2020-08-01 09:44:15 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:44:15 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:44:15 --> Utf8 Class Initialized
INFO - 2020-08-01 09:44:15 --> URI Class Initialized
INFO - 2020-08-01 09:44:15 --> Router Class Initialized
INFO - 2020-08-01 09:44:15 --> Output Class Initialized
INFO - 2020-08-01 09:44:15 --> Security Class Initialized
DEBUG - 2020-08-01 09:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:44:15 --> Input Class Initialized
INFO - 2020-08-01 09:44:15 --> Language Class Initialized
INFO - 2020-08-01 09:44:15 --> Loader Class Initialized
INFO - 2020-08-01 09:44:15 --> Helper loaded: url_helper
INFO - 2020-08-01 09:44:15 --> Database Driver Class Initialized
INFO - 2020-08-01 09:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:44:15 --> Email Class Initialized
INFO - 2020-08-01 09:44:15 --> Controller Class Initialized
DEBUG - 2020-08-01 09:44:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:44:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:44:15 --> Model Class Initialized
INFO - 2020-08-01 09:44:15 --> Model Class Initialized
ERROR - 2020-08-01 09:44:15 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:44:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:44:15 --> Final output sent to browser
DEBUG - 2020-08-01 09:44:15 --> Total execution time: 0.0282
INFO - 2020-08-01 09:45:54 --> Config Class Initialized
INFO - 2020-08-01 09:45:54 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:45:54 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:45:54 --> Utf8 Class Initialized
INFO - 2020-08-01 09:45:54 --> URI Class Initialized
INFO - 2020-08-01 09:45:54 --> Router Class Initialized
INFO - 2020-08-01 09:45:54 --> Output Class Initialized
INFO - 2020-08-01 09:45:54 --> Security Class Initialized
DEBUG - 2020-08-01 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:45:54 --> Input Class Initialized
INFO - 2020-08-01 09:45:54 --> Language Class Initialized
INFO - 2020-08-01 09:45:54 --> Loader Class Initialized
INFO - 2020-08-01 09:45:54 --> Helper loaded: url_helper
INFO - 2020-08-01 09:45:54 --> Database Driver Class Initialized
INFO - 2020-08-01 09:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:45:54 --> Email Class Initialized
INFO - 2020-08-01 09:45:54 --> Controller Class Initialized
DEBUG - 2020-08-01 09:45:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:45:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:45:54 --> Model Class Initialized
INFO - 2020-08-01 09:45:54 --> Model Class Initialized
INFO - 2020-08-01 09:45:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:45:54 --> Final output sent to browser
DEBUG - 2020-08-01 09:45:54 --> Total execution time: 0.0268
INFO - 2020-08-01 09:45:57 --> Config Class Initialized
INFO - 2020-08-01 09:45:57 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:45:57 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:45:57 --> Utf8 Class Initialized
INFO - 2020-08-01 09:45:57 --> URI Class Initialized
INFO - 2020-08-01 09:45:57 --> Router Class Initialized
INFO - 2020-08-01 09:45:57 --> Output Class Initialized
INFO - 2020-08-01 09:45:57 --> Security Class Initialized
DEBUG - 2020-08-01 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:45:57 --> Input Class Initialized
INFO - 2020-08-01 09:45:57 --> Language Class Initialized
INFO - 2020-08-01 09:45:57 --> Loader Class Initialized
INFO - 2020-08-01 09:45:57 --> Helper loaded: url_helper
INFO - 2020-08-01 09:45:57 --> Database Driver Class Initialized
INFO - 2020-08-01 09:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:45:57 --> Email Class Initialized
INFO - 2020-08-01 09:45:57 --> Controller Class Initialized
DEBUG - 2020-08-01 09:45:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:45:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:45:57 --> Model Class Initialized
INFO - 2020-08-01 09:45:57 --> Model Class Initialized
INFO - 2020-08-01 09:45:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:45:57 --> Final output sent to browser
DEBUG - 2020-08-01 09:45:57 --> Total execution time: 0.0226
INFO - 2020-08-01 09:45:59 --> Config Class Initialized
INFO - 2020-08-01 09:45:59 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:45:59 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:45:59 --> Utf8 Class Initialized
INFO - 2020-08-01 09:45:59 --> URI Class Initialized
INFO - 2020-08-01 09:45:59 --> Router Class Initialized
INFO - 2020-08-01 09:45:59 --> Output Class Initialized
INFO - 2020-08-01 09:45:59 --> Security Class Initialized
DEBUG - 2020-08-01 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:45:59 --> Input Class Initialized
INFO - 2020-08-01 09:45:59 --> Language Class Initialized
INFO - 2020-08-01 09:45:59 --> Loader Class Initialized
INFO - 2020-08-01 09:45:59 --> Helper loaded: url_helper
INFO - 2020-08-01 09:45:59 --> Database Driver Class Initialized
INFO - 2020-08-01 09:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:45:59 --> Email Class Initialized
INFO - 2020-08-01 09:45:59 --> Controller Class Initialized
DEBUG - 2020-08-01 09:45:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:45:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:45:59 --> Model Class Initialized
INFO - 2020-08-01 09:45:59 --> Model Class Initialized
ERROR - 2020-08-01 09:45:59 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:45:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:45:59 --> Final output sent to browser
DEBUG - 2020-08-01 09:45:59 --> Total execution time: 0.0255
INFO - 2020-08-01 09:46:04 --> Config Class Initialized
INFO - 2020-08-01 09:46:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:46:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:46:04 --> Utf8 Class Initialized
INFO - 2020-08-01 09:46:04 --> URI Class Initialized
INFO - 2020-08-01 09:46:04 --> Router Class Initialized
INFO - 2020-08-01 09:46:04 --> Output Class Initialized
INFO - 2020-08-01 09:46:04 --> Security Class Initialized
DEBUG - 2020-08-01 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:46:04 --> Input Class Initialized
INFO - 2020-08-01 09:46:04 --> Language Class Initialized
INFO - 2020-08-01 09:46:04 --> Loader Class Initialized
INFO - 2020-08-01 09:46:04 --> Helper loaded: url_helper
INFO - 2020-08-01 09:46:04 --> Database Driver Class Initialized
INFO - 2020-08-01 09:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:46:04 --> Email Class Initialized
INFO - 2020-08-01 09:46:04 --> Controller Class Initialized
DEBUG - 2020-08-01 09:46:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:46:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:46:04 --> Model Class Initialized
INFO - 2020-08-01 09:46:04 --> Model Class Initialized
INFO - 2020-08-01 09:46:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-01 09:46:04 --> Final output sent to browser
DEBUG - 2020-08-01 09:46:04 --> Total execution time: 0.0220
INFO - 2020-08-01 09:46:26 --> Config Class Initialized
INFO - 2020-08-01 09:46:26 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:46:26 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:46:26 --> Utf8 Class Initialized
INFO - 2020-08-01 09:46:26 --> URI Class Initialized
INFO - 2020-08-01 09:46:26 --> Router Class Initialized
INFO - 2020-08-01 09:46:26 --> Output Class Initialized
INFO - 2020-08-01 09:46:26 --> Security Class Initialized
DEBUG - 2020-08-01 09:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:46:26 --> Input Class Initialized
INFO - 2020-08-01 09:46:26 --> Language Class Initialized
INFO - 2020-08-01 09:46:26 --> Loader Class Initialized
INFO - 2020-08-01 09:46:26 --> Helper loaded: url_helper
INFO - 2020-08-01 09:46:26 --> Database Driver Class Initialized
INFO - 2020-08-01 09:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:46:26 --> Email Class Initialized
INFO - 2020-08-01 09:46:26 --> Controller Class Initialized
DEBUG - 2020-08-01 09:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:46:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:46:26 --> Model Class Initialized
INFO - 2020-08-01 09:46:26 --> Model Class Initialized
INFO - 2020-08-01 09:46:26 --> Model Class Initialized
INFO - 2020-08-01 09:46:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:46:26 --> Final output sent to browser
DEBUG - 2020-08-01 09:46:26 --> Total execution time: 0.0757
INFO - 2020-08-01 09:47:36 --> Config Class Initialized
INFO - 2020-08-01 09:47:36 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:47:36 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:47:36 --> Utf8 Class Initialized
INFO - 2020-08-01 09:47:36 --> URI Class Initialized
INFO - 2020-08-01 09:47:36 --> Router Class Initialized
INFO - 2020-08-01 09:47:36 --> Output Class Initialized
INFO - 2020-08-01 09:47:36 --> Security Class Initialized
DEBUG - 2020-08-01 09:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:47:36 --> Input Class Initialized
INFO - 2020-08-01 09:47:36 --> Language Class Initialized
INFO - 2020-08-01 09:47:36 --> Loader Class Initialized
INFO - 2020-08-01 09:47:36 --> Helper loaded: url_helper
INFO - 2020-08-01 09:47:36 --> Database Driver Class Initialized
INFO - 2020-08-01 09:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:47:36 --> Email Class Initialized
INFO - 2020-08-01 09:47:36 --> Controller Class Initialized
DEBUG - 2020-08-01 09:47:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:47:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:47:36 --> Model Class Initialized
INFO - 2020-08-01 09:47:36 --> Model Class Initialized
INFO - 2020-08-01 09:47:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:47:36 --> Final output sent to browser
DEBUG - 2020-08-01 09:47:36 --> Total execution time: 0.0260
INFO - 2020-08-01 09:47:38 --> Config Class Initialized
INFO - 2020-08-01 09:47:38 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:47:38 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:47:38 --> Utf8 Class Initialized
INFO - 2020-08-01 09:47:38 --> URI Class Initialized
INFO - 2020-08-01 09:47:38 --> Router Class Initialized
INFO - 2020-08-01 09:47:38 --> Output Class Initialized
INFO - 2020-08-01 09:47:38 --> Security Class Initialized
DEBUG - 2020-08-01 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:47:38 --> Input Class Initialized
INFO - 2020-08-01 09:47:38 --> Language Class Initialized
INFO - 2020-08-01 09:47:38 --> Loader Class Initialized
INFO - 2020-08-01 09:47:38 --> Helper loaded: url_helper
INFO - 2020-08-01 09:47:38 --> Database Driver Class Initialized
INFO - 2020-08-01 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:47:38 --> Email Class Initialized
INFO - 2020-08-01 09:47:38 --> Controller Class Initialized
DEBUG - 2020-08-01 09:47:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:47:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:47:38 --> Model Class Initialized
INFO - 2020-08-01 09:47:38 --> Model Class Initialized
ERROR - 2020-08-01 09:47:38 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-01 09:47:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:47:38 --> Final output sent to browser
DEBUG - 2020-08-01 09:47:38 --> Total execution time: 0.0272
INFO - 2020-08-01 09:48:19 --> Config Class Initialized
INFO - 2020-08-01 09:48:19 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:48:19 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:48:19 --> Utf8 Class Initialized
INFO - 2020-08-01 09:48:19 --> URI Class Initialized
INFO - 2020-08-01 09:48:19 --> Router Class Initialized
INFO - 2020-08-01 09:48:19 --> Output Class Initialized
INFO - 2020-08-01 09:48:19 --> Security Class Initialized
DEBUG - 2020-08-01 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:48:19 --> Input Class Initialized
INFO - 2020-08-01 09:48:19 --> Language Class Initialized
INFO - 2020-08-01 09:48:19 --> Loader Class Initialized
INFO - 2020-08-01 09:48:19 --> Helper loaded: url_helper
INFO - 2020-08-01 09:48:19 --> Database Driver Class Initialized
INFO - 2020-08-01 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:48:19 --> Email Class Initialized
INFO - 2020-08-01 09:48:19 --> Controller Class Initialized
DEBUG - 2020-08-01 09:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:48:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:48:19 --> Model Class Initialized
INFO - 2020-08-01 09:48:19 --> Model Class Initialized
INFO - 2020-08-01 09:48:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:48:19 --> Final output sent to browser
DEBUG - 2020-08-01 09:48:19 --> Total execution time: 0.0254
INFO - 2020-08-01 09:48:22 --> Config Class Initialized
INFO - 2020-08-01 09:48:22 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:48:22 --> Utf8 Class Initialized
INFO - 2020-08-01 09:48:22 --> URI Class Initialized
INFO - 2020-08-01 09:48:22 --> Router Class Initialized
INFO - 2020-08-01 09:48:22 --> Output Class Initialized
INFO - 2020-08-01 09:48:22 --> Security Class Initialized
DEBUG - 2020-08-01 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:48:22 --> Input Class Initialized
INFO - 2020-08-01 09:48:22 --> Language Class Initialized
INFO - 2020-08-01 09:48:22 --> Loader Class Initialized
INFO - 2020-08-01 09:48:22 --> Helper loaded: url_helper
INFO - 2020-08-01 09:48:22 --> Database Driver Class Initialized
INFO - 2020-08-01 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:48:22 --> Email Class Initialized
INFO - 2020-08-01 09:48:22 --> Controller Class Initialized
DEBUG - 2020-08-01 09:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:48:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:48:22 --> Model Class Initialized
INFO - 2020-08-01 09:48:22 --> Model Class Initialized
INFO - 2020-08-01 09:48:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:48:22 --> Final output sent to browser
DEBUG - 2020-08-01 09:48:22 --> Total execution time: 0.0257
INFO - 2020-08-01 09:48:24 --> Config Class Initialized
INFO - 2020-08-01 09:48:24 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:48:24 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:48:24 --> Utf8 Class Initialized
INFO - 2020-08-01 09:48:24 --> URI Class Initialized
INFO - 2020-08-01 09:48:24 --> Router Class Initialized
INFO - 2020-08-01 09:48:24 --> Output Class Initialized
INFO - 2020-08-01 09:48:24 --> Security Class Initialized
DEBUG - 2020-08-01 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:48:24 --> Input Class Initialized
INFO - 2020-08-01 09:48:24 --> Language Class Initialized
INFO - 2020-08-01 09:48:24 --> Loader Class Initialized
INFO - 2020-08-01 09:48:24 --> Helper loaded: url_helper
INFO - 2020-08-01 09:48:24 --> Database Driver Class Initialized
INFO - 2020-08-01 09:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:48:24 --> Email Class Initialized
INFO - 2020-08-01 09:48:24 --> Controller Class Initialized
DEBUG - 2020-08-01 09:48:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:48:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:48:24 --> Model Class Initialized
INFO - 2020-08-01 09:48:24 --> Model Class Initialized
INFO - 2020-08-01 09:48:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:48:24 --> Final output sent to browser
DEBUG - 2020-08-01 09:48:24 --> Total execution time: 0.0244
INFO - 2020-08-01 09:48:27 --> Config Class Initialized
INFO - 2020-08-01 09:48:27 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:48:27 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:48:27 --> Utf8 Class Initialized
INFO - 2020-08-01 09:48:27 --> URI Class Initialized
INFO - 2020-08-01 09:48:27 --> Router Class Initialized
INFO - 2020-08-01 09:48:27 --> Output Class Initialized
INFO - 2020-08-01 09:48:27 --> Security Class Initialized
DEBUG - 2020-08-01 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:48:27 --> Input Class Initialized
INFO - 2020-08-01 09:48:27 --> Language Class Initialized
INFO - 2020-08-01 09:48:27 --> Loader Class Initialized
INFO - 2020-08-01 09:48:27 --> Helper loaded: url_helper
INFO - 2020-08-01 09:48:27 --> Database Driver Class Initialized
INFO - 2020-08-01 09:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:48:27 --> Email Class Initialized
INFO - 2020-08-01 09:48:27 --> Controller Class Initialized
DEBUG - 2020-08-01 09:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:48:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:48:27 --> Model Class Initialized
INFO - 2020-08-01 09:48:27 --> Model Class Initialized
INFO - 2020-08-01 09:48:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:48:27 --> Final output sent to browser
DEBUG - 2020-08-01 09:48:27 --> Total execution time: 0.0229
INFO - 2020-08-01 09:48:29 --> Config Class Initialized
INFO - 2020-08-01 09:48:29 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:48:29 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:48:29 --> Utf8 Class Initialized
INFO - 2020-08-01 09:48:29 --> URI Class Initialized
INFO - 2020-08-01 09:48:29 --> Router Class Initialized
INFO - 2020-08-01 09:48:29 --> Output Class Initialized
INFO - 2020-08-01 09:48:29 --> Security Class Initialized
DEBUG - 2020-08-01 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:48:29 --> Input Class Initialized
INFO - 2020-08-01 09:48:29 --> Language Class Initialized
INFO - 2020-08-01 09:48:29 --> Loader Class Initialized
INFO - 2020-08-01 09:48:29 --> Helper loaded: url_helper
INFO - 2020-08-01 09:48:29 --> Database Driver Class Initialized
INFO - 2020-08-01 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:48:29 --> Email Class Initialized
INFO - 2020-08-01 09:48:29 --> Controller Class Initialized
DEBUG - 2020-08-01 09:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:48:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:48:29 --> Model Class Initialized
INFO - 2020-08-01 09:48:29 --> Model Class Initialized
INFO - 2020-08-01 09:48:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:48:29 --> Final output sent to browser
DEBUG - 2020-08-01 09:48:29 --> Total execution time: 0.0218
INFO - 2020-08-01 09:52:15 --> Config Class Initialized
INFO - 2020-08-01 09:52:15 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:52:15 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:52:15 --> Utf8 Class Initialized
INFO - 2020-08-01 09:52:15 --> URI Class Initialized
DEBUG - 2020-08-01 09:52:15 --> No URI present. Default controller set.
INFO - 2020-08-01 09:52:15 --> Router Class Initialized
INFO - 2020-08-01 09:52:15 --> Output Class Initialized
INFO - 2020-08-01 09:52:15 --> Security Class Initialized
DEBUG - 2020-08-01 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:52:15 --> Input Class Initialized
INFO - 2020-08-01 09:52:15 --> Language Class Initialized
INFO - 2020-08-01 09:52:15 --> Loader Class Initialized
INFO - 2020-08-01 09:52:15 --> Helper loaded: url_helper
INFO - 2020-08-01 09:52:15 --> Database Driver Class Initialized
INFO - 2020-08-01 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:52:15 --> Email Class Initialized
INFO - 2020-08-01 09:52:15 --> Controller Class Initialized
INFO - 2020-08-01 09:52:15 --> Model Class Initialized
INFO - 2020-08-01 09:52:15 --> Model Class Initialized
DEBUG - 2020-08-01 09:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:52:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:52:15 --> Final output sent to browser
DEBUG - 2020-08-01 09:52:15 --> Total execution time: 0.0226
INFO - 2020-08-01 09:52:18 --> Config Class Initialized
INFO - 2020-08-01 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:52:18 --> Utf8 Class Initialized
INFO - 2020-08-01 09:52:18 --> URI Class Initialized
INFO - 2020-08-01 09:52:18 --> Router Class Initialized
INFO - 2020-08-01 09:52:18 --> Output Class Initialized
INFO - 2020-08-01 09:52:18 --> Security Class Initialized
DEBUG - 2020-08-01 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:52:18 --> Input Class Initialized
INFO - 2020-08-01 09:52:18 --> Language Class Initialized
INFO - 2020-08-01 09:52:18 --> Loader Class Initialized
INFO - 2020-08-01 09:52:18 --> Helper loaded: url_helper
INFO - 2020-08-01 09:52:18 --> Database Driver Class Initialized
INFO - 2020-08-01 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:52:18 --> Email Class Initialized
INFO - 2020-08-01 09:52:18 --> Controller Class Initialized
INFO - 2020-08-01 09:52:18 --> Model Class Initialized
INFO - 2020-08-01 09:52:18 --> Model Class Initialized
DEBUG - 2020-08-01 09:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:52:18 --> Config Class Initialized
INFO - 2020-08-01 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:52:18 --> Utf8 Class Initialized
INFO - 2020-08-01 09:52:18 --> URI Class Initialized
INFO - 2020-08-01 09:52:18 --> Router Class Initialized
INFO - 2020-08-01 09:52:18 --> Output Class Initialized
INFO - 2020-08-01 09:52:18 --> Security Class Initialized
DEBUG - 2020-08-01 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:52:18 --> Input Class Initialized
INFO - 2020-08-01 09:52:18 --> Language Class Initialized
INFO - 2020-08-01 09:52:18 --> Loader Class Initialized
INFO - 2020-08-01 09:52:18 --> Helper loaded: url_helper
INFO - 2020-08-01 09:52:18 --> Database Driver Class Initialized
INFO - 2020-08-01 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:52:18 --> Email Class Initialized
INFO - 2020-08-01 09:52:18 --> Controller Class Initialized
INFO - 2020-08-01 09:52:18 --> Model Class Initialized
INFO - 2020-08-01 09:52:18 --> Model Class Initialized
DEBUG - 2020-08-01 09:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:52:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:52:18 --> Model Class Initialized
INFO - 2020-08-01 09:52:18 --> Final output sent to browser
DEBUG - 2020-08-01 09:52:18 --> Total execution time: 0.0266
INFO - 2020-08-01 09:52:19 --> Config Class Initialized
INFO - 2020-08-01 09:52:19 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:52:19 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:52:19 --> Utf8 Class Initialized
INFO - 2020-08-01 09:52:19 --> URI Class Initialized
INFO - 2020-08-01 09:52:19 --> Router Class Initialized
INFO - 2020-08-01 09:52:19 --> Output Class Initialized
INFO - 2020-08-01 09:52:19 --> Security Class Initialized
DEBUG - 2020-08-01 09:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:52:19 --> Input Class Initialized
INFO - 2020-08-01 09:52:19 --> Language Class Initialized
INFO - 2020-08-01 09:52:19 --> Loader Class Initialized
INFO - 2020-08-01 09:52:19 --> Helper loaded: url_helper
INFO - 2020-08-01 09:52:19 --> Database Driver Class Initialized
INFO - 2020-08-01 09:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:52:19 --> Email Class Initialized
INFO - 2020-08-01 09:52:19 --> Controller Class Initialized
DEBUG - 2020-08-01 09:52:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:52:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:52:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:52:19 --> Final output sent to browser
DEBUG - 2020-08-01 09:52:19 --> Total execution time: 0.0213
INFO - 2020-08-01 09:52:22 --> Config Class Initialized
INFO - 2020-08-01 09:52:22 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:52:22 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:52:22 --> Utf8 Class Initialized
INFO - 2020-08-01 09:52:22 --> URI Class Initialized
INFO - 2020-08-01 09:52:22 --> Router Class Initialized
INFO - 2020-08-01 09:52:22 --> Output Class Initialized
INFO - 2020-08-01 09:52:22 --> Security Class Initialized
DEBUG - 2020-08-01 09:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:52:22 --> Input Class Initialized
INFO - 2020-08-01 09:52:22 --> Language Class Initialized
INFO - 2020-08-01 09:52:22 --> Loader Class Initialized
INFO - 2020-08-01 09:52:22 --> Helper loaded: url_helper
INFO - 2020-08-01 09:52:22 --> Database Driver Class Initialized
INFO - 2020-08-01 09:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:52:22 --> Email Class Initialized
INFO - 2020-08-01 09:52:22 --> Controller Class Initialized
DEBUG - 2020-08-01 09:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:52:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:52:22 --> Model Class Initialized
INFO - 2020-08-01 09:52:22 --> Model Class Initialized
INFO - 2020-08-01 09:52:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:52:22 --> Final output sent to browser
DEBUG - 2020-08-01 09:52:22 --> Total execution time: 0.0252
INFO - 2020-08-01 09:52:24 --> Config Class Initialized
INFO - 2020-08-01 09:52:24 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:52:24 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:52:24 --> Utf8 Class Initialized
INFO - 2020-08-01 09:52:24 --> URI Class Initialized
INFO - 2020-08-01 09:52:24 --> Router Class Initialized
INFO - 2020-08-01 09:52:24 --> Output Class Initialized
INFO - 2020-08-01 09:52:24 --> Security Class Initialized
DEBUG - 2020-08-01 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:52:24 --> Input Class Initialized
INFO - 2020-08-01 09:52:24 --> Language Class Initialized
INFO - 2020-08-01 09:52:24 --> Loader Class Initialized
INFO - 2020-08-01 09:52:24 --> Helper loaded: url_helper
INFO - 2020-08-01 09:52:24 --> Database Driver Class Initialized
INFO - 2020-08-01 09:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:52:24 --> Email Class Initialized
INFO - 2020-08-01 09:52:24 --> Controller Class Initialized
DEBUG - 2020-08-01 09:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:52:24 --> Model Class Initialized
INFO - 2020-08-01 09:52:24 --> Model Class Initialized
INFO - 2020-08-01 09:52:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-01 09:52:24 --> Final output sent to browser
DEBUG - 2020-08-01 09:52:24 --> Total execution time: 0.0230
INFO - 2020-08-01 09:53:10 --> Config Class Initialized
INFO - 2020-08-01 09:53:10 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:53:10 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:53:10 --> Utf8 Class Initialized
INFO - 2020-08-01 09:53:10 --> URI Class Initialized
INFO - 2020-08-01 09:53:10 --> Router Class Initialized
INFO - 2020-08-01 09:53:10 --> Output Class Initialized
INFO - 2020-08-01 09:53:10 --> Security Class Initialized
DEBUG - 2020-08-01 09:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:53:10 --> Input Class Initialized
INFO - 2020-08-01 09:53:10 --> Language Class Initialized
INFO - 2020-08-01 09:53:10 --> Loader Class Initialized
INFO - 2020-08-01 09:53:10 --> Helper loaded: url_helper
INFO - 2020-08-01 09:53:10 --> Database Driver Class Initialized
INFO - 2020-08-01 09:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:53:10 --> Email Class Initialized
INFO - 2020-08-01 09:53:10 --> Controller Class Initialized
DEBUG - 2020-08-01 09:53:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:53:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:53:10 --> Model Class Initialized
INFO - 2020-08-01 09:53:10 --> Model Class Initialized
INFO - 2020-08-01 09:53:10 --> Model Class Initialized
INFO - 2020-08-01 09:53:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:53:10 --> Final output sent to browser
DEBUG - 2020-08-01 09:53:10 --> Total execution time: 0.0739
INFO - 2020-08-01 09:53:41 --> Config Class Initialized
INFO - 2020-08-01 09:53:41 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:53:41 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:53:41 --> Utf8 Class Initialized
INFO - 2020-08-01 09:53:41 --> URI Class Initialized
DEBUG - 2020-08-01 09:53:41 --> No URI present. Default controller set.
INFO - 2020-08-01 09:53:41 --> Router Class Initialized
INFO - 2020-08-01 09:53:41 --> Output Class Initialized
INFO - 2020-08-01 09:53:41 --> Security Class Initialized
DEBUG - 2020-08-01 09:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:53:41 --> Input Class Initialized
INFO - 2020-08-01 09:53:41 --> Language Class Initialized
INFO - 2020-08-01 09:53:41 --> Loader Class Initialized
INFO - 2020-08-01 09:53:41 --> Helper loaded: url_helper
INFO - 2020-08-01 09:53:41 --> Database Driver Class Initialized
INFO - 2020-08-01 09:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:53:41 --> Email Class Initialized
INFO - 2020-08-01 09:53:41 --> Controller Class Initialized
INFO - 2020-08-01 09:53:41 --> Model Class Initialized
INFO - 2020-08-01 09:53:41 --> Model Class Initialized
DEBUG - 2020-08-01 09:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:53:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:53:41 --> Final output sent to browser
DEBUG - 2020-08-01 09:53:41 --> Total execution time: 0.0212
INFO - 2020-08-01 09:53:47 --> Config Class Initialized
INFO - 2020-08-01 09:53:47 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:53:47 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:53:47 --> Utf8 Class Initialized
INFO - 2020-08-01 09:53:47 --> URI Class Initialized
INFO - 2020-08-01 09:53:47 --> Router Class Initialized
INFO - 2020-08-01 09:53:47 --> Output Class Initialized
INFO - 2020-08-01 09:53:47 --> Security Class Initialized
DEBUG - 2020-08-01 09:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:53:47 --> Input Class Initialized
INFO - 2020-08-01 09:53:47 --> Language Class Initialized
INFO - 2020-08-01 09:53:47 --> Loader Class Initialized
INFO - 2020-08-01 09:53:47 --> Helper loaded: url_helper
INFO - 2020-08-01 09:53:47 --> Database Driver Class Initialized
INFO - 2020-08-01 09:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:53:47 --> Email Class Initialized
INFO - 2020-08-01 09:53:47 --> Controller Class Initialized
INFO - 2020-08-01 09:53:47 --> Model Class Initialized
INFO - 2020-08-01 09:53:47 --> Model Class Initialized
DEBUG - 2020-08-01 09:53:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:53:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:53:47 --> Model Class Initialized
INFO - 2020-08-01 09:53:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-08-01 09:53:47 --> Final output sent to browser
DEBUG - 2020-08-01 09:53:47 --> Total execution time: 0.0367
INFO - 2020-08-01 09:53:52 --> Config Class Initialized
INFO - 2020-08-01 09:53:52 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:53:52 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:53:52 --> Utf8 Class Initialized
INFO - 2020-08-01 09:53:52 --> URI Class Initialized
INFO - 2020-08-01 09:53:52 --> Router Class Initialized
INFO - 2020-08-01 09:53:52 --> Output Class Initialized
INFO - 2020-08-01 09:53:52 --> Security Class Initialized
DEBUG - 2020-08-01 09:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:53:52 --> Input Class Initialized
INFO - 2020-08-01 09:53:52 --> Language Class Initialized
INFO - 2020-08-01 09:53:52 --> Loader Class Initialized
INFO - 2020-08-01 09:53:52 --> Helper loaded: url_helper
INFO - 2020-08-01 09:53:52 --> Database Driver Class Initialized
INFO - 2020-08-01 09:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:53:52 --> Email Class Initialized
INFO - 2020-08-01 09:53:52 --> Controller Class Initialized
INFO - 2020-08-01 09:53:52 --> Model Class Initialized
INFO - 2020-08-01 09:53:52 --> Model Class Initialized
DEBUG - 2020-08-01 09:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:53:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:53:52 --> Config Class Initialized
INFO - 2020-08-01 09:53:52 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:53:52 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:53:52 --> Utf8 Class Initialized
INFO - 2020-08-01 09:53:52 --> URI Class Initialized
DEBUG - 2020-08-01 09:53:52 --> No URI present. Default controller set.
INFO - 2020-08-01 09:53:52 --> Router Class Initialized
INFO - 2020-08-01 09:53:52 --> Output Class Initialized
INFO - 2020-08-01 09:53:52 --> Security Class Initialized
DEBUG - 2020-08-01 09:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:53:52 --> Input Class Initialized
INFO - 2020-08-01 09:53:52 --> Language Class Initialized
INFO - 2020-08-01 09:53:52 --> Loader Class Initialized
INFO - 2020-08-01 09:53:52 --> Helper loaded: url_helper
INFO - 2020-08-01 09:53:52 --> Database Driver Class Initialized
INFO - 2020-08-01 09:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:53:52 --> Email Class Initialized
INFO - 2020-08-01 09:53:52 --> Controller Class Initialized
INFO - 2020-08-01 09:53:52 --> Model Class Initialized
INFO - 2020-08-01 09:53:52 --> Model Class Initialized
DEBUG - 2020-08-01 09:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:53:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:53:52 --> Final output sent to browser
DEBUG - 2020-08-01 09:53:52 --> Total execution time: 0.0237
INFO - 2020-08-01 09:54:08 --> Config Class Initialized
INFO - 2020-08-01 09:54:08 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:08 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:08 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:08 --> URI Class Initialized
INFO - 2020-08-01 09:54:08 --> Router Class Initialized
INFO - 2020-08-01 09:54:08 --> Output Class Initialized
INFO - 2020-08-01 09:54:08 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:08 --> Input Class Initialized
INFO - 2020-08-01 09:54:08 --> Language Class Initialized
INFO - 2020-08-01 09:54:08 --> Loader Class Initialized
INFO - 2020-08-01 09:54:08 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:08 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:08 --> Email Class Initialized
INFO - 2020-08-01 09:54:08 --> Controller Class Initialized
INFO - 2020-08-01 09:54:08 --> Model Class Initialized
INFO - 2020-08-01 09:54:08 --> Model Class Initialized
DEBUG - 2020-08-01 09:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:54:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:08 --> Model Class Initialized
INFO - 2020-08-01 09:54:09 --> Config Class Initialized
INFO - 2020-08-01 09:54:09 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:09 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:09 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:09 --> URI Class Initialized
DEBUG - 2020-08-01 09:54:09 --> No URI present. Default controller set.
INFO - 2020-08-01 09:54:09 --> Router Class Initialized
INFO - 2020-08-01 09:54:09 --> Output Class Initialized
INFO - 2020-08-01 09:54:09 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:09 --> Input Class Initialized
INFO - 2020-08-01 09:54:09 --> Language Class Initialized
INFO - 2020-08-01 09:54:09 --> Loader Class Initialized
INFO - 2020-08-01 09:54:09 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:09 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:09 --> Email Class Initialized
INFO - 2020-08-01 09:54:09 --> Controller Class Initialized
INFO - 2020-08-01 09:54:09 --> Model Class Initialized
INFO - 2020-08-01 09:54:09 --> Model Class Initialized
DEBUG - 2020-08-01 09:54:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:54:09 --> Final output sent to browser
DEBUG - 2020-08-01 09:54:09 --> Total execution time: 0.0240
INFO - 2020-08-01 09:54:37 --> Config Class Initialized
INFO - 2020-08-01 09:54:37 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:37 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:37 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:37 --> URI Class Initialized
INFO - 2020-08-01 09:54:37 --> Router Class Initialized
INFO - 2020-08-01 09:54:37 --> Output Class Initialized
INFO - 2020-08-01 09:54:37 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:37 --> Input Class Initialized
INFO - 2020-08-01 09:54:37 --> Language Class Initialized
INFO - 2020-08-01 09:54:37 --> Loader Class Initialized
INFO - 2020-08-01 09:54:37 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:37 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:37 --> Email Class Initialized
INFO - 2020-08-01 09:54:37 --> Controller Class Initialized
INFO - 2020-08-01 09:54:37 --> Model Class Initialized
INFO - 2020-08-01 09:54:37 --> Model Class Initialized
DEBUG - 2020-08-01 09:54:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:54:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:37 --> Model Class Initialized
INFO - 2020-08-01 09:54:37 --> Final output sent to browser
DEBUG - 2020-08-01 09:54:37 --> Total execution time: 0.0293
INFO - 2020-08-01 09:54:37 --> Config Class Initialized
INFO - 2020-08-01 09:54:37 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:37 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:37 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:37 --> URI Class Initialized
INFO - 2020-08-01 09:54:37 --> Router Class Initialized
INFO - 2020-08-01 09:54:37 --> Output Class Initialized
INFO - 2020-08-01 09:54:37 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:37 --> Input Class Initialized
INFO - 2020-08-01 09:54:37 --> Language Class Initialized
INFO - 2020-08-01 09:54:37 --> Loader Class Initialized
INFO - 2020-08-01 09:54:37 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:37 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:37 --> Email Class Initialized
INFO - 2020-08-01 09:54:37 --> Controller Class Initialized
INFO - 2020-08-01 09:54:37 --> Model Class Initialized
INFO - 2020-08-01 09:54:37 --> Model Class Initialized
DEBUG - 2020-08-01 09:54:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:38 --> Config Class Initialized
INFO - 2020-08-01 09:54:38 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:38 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:38 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:38 --> URI Class Initialized
INFO - 2020-08-01 09:54:38 --> Router Class Initialized
INFO - 2020-08-01 09:54:38 --> Output Class Initialized
INFO - 2020-08-01 09:54:38 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:38 --> Input Class Initialized
INFO - 2020-08-01 09:54:38 --> Language Class Initialized
INFO - 2020-08-01 09:54:38 --> Loader Class Initialized
INFO - 2020-08-01 09:54:38 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:38 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:38 --> Email Class Initialized
INFO - 2020-08-01 09:54:38 --> Controller Class Initialized
DEBUG - 2020-08-01 09:54:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:54:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:54:38 --> Final output sent to browser
DEBUG - 2020-08-01 09:54:38 --> Total execution time: 0.0245
INFO - 2020-08-01 09:54:46 --> Config Class Initialized
INFO - 2020-08-01 09:54:46 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:46 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:46 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:46 --> URI Class Initialized
DEBUG - 2020-08-01 09:54:46 --> No URI present. Default controller set.
INFO - 2020-08-01 09:54:46 --> Router Class Initialized
INFO - 2020-08-01 09:54:46 --> Output Class Initialized
INFO - 2020-08-01 09:54:46 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:46 --> Input Class Initialized
INFO - 2020-08-01 09:54:46 --> Language Class Initialized
INFO - 2020-08-01 09:54:46 --> Loader Class Initialized
INFO - 2020-08-01 09:54:46 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:46 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:46 --> Email Class Initialized
INFO - 2020-08-01 09:54:46 --> Controller Class Initialized
INFO - 2020-08-01 09:54:46 --> Model Class Initialized
INFO - 2020-08-01 09:54:46 --> Model Class Initialized
DEBUG - 2020-08-01 09:54:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:54:46 --> Final output sent to browser
DEBUG - 2020-08-01 09:54:46 --> Total execution time: 0.0232
INFO - 2020-08-01 09:54:51 --> Config Class Initialized
INFO - 2020-08-01 09:54:51 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:54:51 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:54:51 --> Utf8 Class Initialized
INFO - 2020-08-01 09:54:51 --> URI Class Initialized
INFO - 2020-08-01 09:54:52 --> Router Class Initialized
INFO - 2020-08-01 09:54:52 --> Output Class Initialized
INFO - 2020-08-01 09:54:52 --> Security Class Initialized
DEBUG - 2020-08-01 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:54:52 --> Input Class Initialized
INFO - 2020-08-01 09:54:52 --> Language Class Initialized
INFO - 2020-08-01 09:54:52 --> Loader Class Initialized
INFO - 2020-08-01 09:54:52 --> Helper loaded: url_helper
INFO - 2020-08-01 09:54:52 --> Database Driver Class Initialized
INFO - 2020-08-01 09:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:54:52 --> Email Class Initialized
INFO - 2020-08-01 09:54:52 --> Controller Class Initialized
INFO - 2020-08-01 09:54:52 --> Model Class Initialized
INFO - 2020-08-01 09:54:52 --> Model Class Initialized
DEBUG - 2020-08-01 09:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:54:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:54:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-01 09:54:52 --> Final output sent to browser
DEBUG - 2020-08-01 09:54:52 --> Total execution time: 0.0292
INFO - 2020-08-01 09:55:02 --> Config Class Initialized
INFO - 2020-08-01 09:55:02 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:55:02 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:55:02 --> Utf8 Class Initialized
INFO - 2020-08-01 09:55:02 --> URI Class Initialized
INFO - 2020-08-01 09:55:02 --> Router Class Initialized
INFO - 2020-08-01 09:55:02 --> Output Class Initialized
INFO - 2020-08-01 09:55:02 --> Security Class Initialized
DEBUG - 2020-08-01 09:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:55:02 --> Input Class Initialized
INFO - 2020-08-01 09:55:02 --> Language Class Initialized
INFO - 2020-08-01 09:55:02 --> Loader Class Initialized
INFO - 2020-08-01 09:55:02 --> Helper loaded: url_helper
INFO - 2020-08-01 09:55:02 --> Database Driver Class Initialized
INFO - 2020-08-01 09:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:55:02 --> Email Class Initialized
INFO - 2020-08-01 09:55:02 --> Controller Class Initialized
INFO - 2020-08-01 09:55:02 --> Model Class Initialized
INFO - 2020-08-01 09:55:02 --> Model Class Initialized
DEBUG - 2020-08-01 09:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:55:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:55:02 --> Model Class Initialized
INFO - 2020-08-01 09:55:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-01 09:55:02 --> Final output sent to browser
DEBUG - 2020-08-01 09:55:02 --> Total execution time: 0.0711
INFO - 2020-08-01 09:55:05 --> Config Class Initialized
INFO - 2020-08-01 09:55:05 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:55:05 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:55:05 --> Utf8 Class Initialized
INFO - 2020-08-01 09:55:05 --> URI Class Initialized
DEBUG - 2020-08-01 09:55:05 --> No URI present. Default controller set.
INFO - 2020-08-01 09:55:05 --> Router Class Initialized
INFO - 2020-08-01 09:55:05 --> Output Class Initialized
INFO - 2020-08-01 09:55:05 --> Security Class Initialized
DEBUG - 2020-08-01 09:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:55:05 --> Input Class Initialized
INFO - 2020-08-01 09:55:05 --> Language Class Initialized
INFO - 2020-08-01 09:55:05 --> Loader Class Initialized
INFO - 2020-08-01 09:55:05 --> Helper loaded: url_helper
INFO - 2020-08-01 09:55:05 --> Database Driver Class Initialized
INFO - 2020-08-01 09:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:55:05 --> Email Class Initialized
INFO - 2020-08-01 09:55:05 --> Controller Class Initialized
INFO - 2020-08-01 09:55:05 --> Model Class Initialized
INFO - 2020-08-01 09:55:05 --> Model Class Initialized
DEBUG - 2020-08-01 09:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:55:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:55:05 --> Final output sent to browser
DEBUG - 2020-08-01 09:55:05 --> Total execution time: 0.0235
INFO - 2020-08-01 09:55:17 --> Config Class Initialized
INFO - 2020-08-01 09:55:17 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:55:17 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:55:17 --> Utf8 Class Initialized
INFO - 2020-08-01 09:55:17 --> URI Class Initialized
INFO - 2020-08-01 09:55:17 --> Router Class Initialized
INFO - 2020-08-01 09:55:17 --> Output Class Initialized
INFO - 2020-08-01 09:55:17 --> Security Class Initialized
DEBUG - 2020-08-01 09:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:55:17 --> Input Class Initialized
INFO - 2020-08-01 09:55:17 --> Language Class Initialized
INFO - 2020-08-01 09:55:17 --> Loader Class Initialized
INFO - 2020-08-01 09:55:17 --> Helper loaded: url_helper
INFO - 2020-08-01 09:55:17 --> Database Driver Class Initialized
INFO - 2020-08-01 09:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:55:17 --> Email Class Initialized
INFO - 2020-08-01 09:55:17 --> Controller Class Initialized
INFO - 2020-08-01 09:55:17 --> Model Class Initialized
INFO - 2020-08-01 09:55:17 --> Model Class Initialized
DEBUG - 2020-08-01 09:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:55:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:55:17 --> Model Class Initialized
INFO - 2020-08-01 09:55:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-08-01 09:55:17 --> Final output sent to browser
DEBUG - 2020-08-01 09:55:17 --> Total execution time: 0.0271
INFO - 2020-08-01 09:55:42 --> Config Class Initialized
INFO - 2020-08-01 09:55:42 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:55:42 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:55:42 --> Utf8 Class Initialized
INFO - 2020-08-01 09:55:42 --> URI Class Initialized
INFO - 2020-08-01 09:55:42 --> Router Class Initialized
INFO - 2020-08-01 09:55:42 --> Output Class Initialized
INFO - 2020-08-01 09:55:42 --> Security Class Initialized
DEBUG - 2020-08-01 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:55:42 --> Input Class Initialized
INFO - 2020-08-01 09:55:42 --> Language Class Initialized
INFO - 2020-08-01 09:55:42 --> Loader Class Initialized
INFO - 2020-08-01 09:55:42 --> Helper loaded: url_helper
INFO - 2020-08-01 09:55:42 --> Database Driver Class Initialized
INFO - 2020-08-01 09:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:55:42 --> Email Class Initialized
INFO - 2020-08-01 09:55:42 --> Controller Class Initialized
INFO - 2020-08-01 09:55:42 --> Model Class Initialized
INFO - 2020-08-01 09:55:42 --> Model Class Initialized
DEBUG - 2020-08-01 09:55:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:55:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:55:42 --> Model Class Initialized
INFO - 2020-08-01 09:55:42 --> Config Class Initialized
INFO - 2020-08-01 09:55:42 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:55:42 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:55:42 --> Utf8 Class Initialized
INFO - 2020-08-01 09:55:42 --> URI Class Initialized
DEBUG - 2020-08-01 09:55:42 --> No URI present. Default controller set.
INFO - 2020-08-01 09:55:42 --> Router Class Initialized
INFO - 2020-08-01 09:55:42 --> Output Class Initialized
INFO - 2020-08-01 09:55:42 --> Security Class Initialized
DEBUG - 2020-08-01 09:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:55:42 --> Input Class Initialized
INFO - 2020-08-01 09:55:42 --> Language Class Initialized
INFO - 2020-08-01 09:55:42 --> Loader Class Initialized
INFO - 2020-08-01 09:55:42 --> Helper loaded: url_helper
INFO - 2020-08-01 09:55:42 --> Database Driver Class Initialized
INFO - 2020-08-01 09:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:55:42 --> Email Class Initialized
INFO - 2020-08-01 09:55:42 --> Controller Class Initialized
INFO - 2020-08-01 09:55:42 --> Model Class Initialized
INFO - 2020-08-01 09:55:42 --> Model Class Initialized
DEBUG - 2020-08-01 09:55:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:55:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:55:42 --> Final output sent to browser
DEBUG - 2020-08-01 09:55:42 --> Total execution time: 0.0246
INFO - 2020-08-01 09:56:32 --> Config Class Initialized
INFO - 2020-08-01 09:56:32 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:56:32 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:56:32 --> Utf8 Class Initialized
INFO - 2020-08-01 09:56:32 --> URI Class Initialized
INFO - 2020-08-01 09:56:32 --> Router Class Initialized
INFO - 2020-08-01 09:56:32 --> Output Class Initialized
INFO - 2020-08-01 09:56:32 --> Security Class Initialized
DEBUG - 2020-08-01 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:56:32 --> Input Class Initialized
INFO - 2020-08-01 09:56:32 --> Language Class Initialized
INFO - 2020-08-01 09:56:32 --> Loader Class Initialized
INFO - 2020-08-01 09:56:32 --> Helper loaded: url_helper
INFO - 2020-08-01 09:56:32 --> Database Driver Class Initialized
INFO - 2020-08-01 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:56:32 --> Email Class Initialized
INFO - 2020-08-01 09:56:32 --> Controller Class Initialized
INFO - 2020-08-01 09:56:32 --> Model Class Initialized
INFO - 2020-08-01 09:56:32 --> Model Class Initialized
DEBUG - 2020-08-01 09:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:56:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:56:32 --> Model Class Initialized
INFO - 2020-08-01 09:56:32 --> Final output sent to browser
DEBUG - 2020-08-01 09:56:32 --> Total execution time: 0.0546
INFO - 2020-08-01 09:56:32 --> Config Class Initialized
INFO - 2020-08-01 09:56:32 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:56:32 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:56:32 --> Utf8 Class Initialized
INFO - 2020-08-01 09:56:32 --> URI Class Initialized
INFO - 2020-08-01 09:56:32 --> Router Class Initialized
INFO - 2020-08-01 09:56:32 --> Output Class Initialized
INFO - 2020-08-01 09:56:32 --> Security Class Initialized
DEBUG - 2020-08-01 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:56:32 --> Input Class Initialized
INFO - 2020-08-01 09:56:32 --> Language Class Initialized
INFO - 2020-08-01 09:56:32 --> Loader Class Initialized
INFO - 2020-08-01 09:56:32 --> Helper loaded: url_helper
INFO - 2020-08-01 09:56:32 --> Database Driver Class Initialized
INFO - 2020-08-01 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:56:32 --> Email Class Initialized
INFO - 2020-08-01 09:56:32 --> Controller Class Initialized
INFO - 2020-08-01 09:56:32 --> Model Class Initialized
INFO - 2020-08-01 09:56:32 --> Model Class Initialized
DEBUG - 2020-08-01 09:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:56:32 --> Config Class Initialized
INFO - 2020-08-01 09:56:32 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:56:32 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:56:32 --> Utf8 Class Initialized
INFO - 2020-08-01 09:56:32 --> URI Class Initialized
INFO - 2020-08-01 09:56:32 --> Router Class Initialized
INFO - 2020-08-01 09:56:32 --> Output Class Initialized
INFO - 2020-08-01 09:56:32 --> Security Class Initialized
DEBUG - 2020-08-01 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:56:32 --> Input Class Initialized
INFO - 2020-08-01 09:56:32 --> Language Class Initialized
INFO - 2020-08-01 09:56:32 --> Loader Class Initialized
INFO - 2020-08-01 09:56:32 --> Helper loaded: url_helper
INFO - 2020-08-01 09:56:32 --> Database Driver Class Initialized
INFO - 2020-08-01 09:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:56:32 --> Email Class Initialized
INFO - 2020-08-01 09:56:32 --> Controller Class Initialized
DEBUG - 2020-08-01 09:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:56:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:56:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:56:32 --> Final output sent to browser
DEBUG - 2020-08-01 09:56:32 --> Total execution time: 0.0272
INFO - 2020-08-01 09:56:37 --> Config Class Initialized
INFO - 2020-08-01 09:56:37 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:56:37 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:56:37 --> Utf8 Class Initialized
INFO - 2020-08-01 09:56:37 --> URI Class Initialized
INFO - 2020-08-01 09:56:37 --> Router Class Initialized
INFO - 2020-08-01 09:56:37 --> Output Class Initialized
INFO - 2020-08-01 09:56:37 --> Security Class Initialized
DEBUG - 2020-08-01 09:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:56:37 --> Input Class Initialized
INFO - 2020-08-01 09:56:37 --> Language Class Initialized
INFO - 2020-08-01 09:56:37 --> Loader Class Initialized
INFO - 2020-08-01 09:56:37 --> Helper loaded: url_helper
INFO - 2020-08-01 09:56:37 --> Database Driver Class Initialized
INFO - 2020-08-01 09:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:56:37 --> Email Class Initialized
INFO - 2020-08-01 09:56:37 --> Controller Class Initialized
DEBUG - 2020-08-01 09:56:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:56:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:56:37 --> Model Class Initialized
INFO - 2020-08-01 09:56:37 --> Model Class Initialized
INFO - 2020-08-01 09:56:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:56:37 --> Final output sent to browser
DEBUG - 2020-08-01 09:56:37 --> Total execution time: 0.0239
INFO - 2020-08-01 09:56:45 --> Config Class Initialized
INFO - 2020-08-01 09:56:45 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:56:45 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:56:45 --> Utf8 Class Initialized
INFO - 2020-08-01 09:56:45 --> URI Class Initialized
INFO - 2020-08-01 09:56:45 --> Router Class Initialized
INFO - 2020-08-01 09:56:45 --> Output Class Initialized
INFO - 2020-08-01 09:56:45 --> Security Class Initialized
DEBUG - 2020-08-01 09:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:56:45 --> Input Class Initialized
INFO - 2020-08-01 09:56:45 --> Language Class Initialized
INFO - 2020-08-01 09:56:45 --> Loader Class Initialized
INFO - 2020-08-01 09:56:45 --> Helper loaded: url_helper
INFO - 2020-08-01 09:56:45 --> Database Driver Class Initialized
INFO - 2020-08-01 09:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:56:45 --> Email Class Initialized
INFO - 2020-08-01 09:56:45 --> Controller Class Initialized
DEBUG - 2020-08-01 09:56:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:56:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:56:45 --> Model Class Initialized
INFO - 2020-08-01 09:56:45 --> Model Class Initialized
INFO - 2020-08-01 09:56:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 09:56:45 --> Final output sent to browser
DEBUG - 2020-08-01 09:56:45 --> Total execution time: 0.0232
INFO - 2020-08-01 09:57:01 --> Config Class Initialized
INFO - 2020-08-01 09:57:01 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:57:01 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:57:01 --> Utf8 Class Initialized
INFO - 2020-08-01 09:57:01 --> URI Class Initialized
INFO - 2020-08-01 09:57:01 --> Router Class Initialized
INFO - 2020-08-01 09:57:01 --> Output Class Initialized
INFO - 2020-08-01 09:57:01 --> Security Class Initialized
DEBUG - 2020-08-01 09:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:57:01 --> Input Class Initialized
INFO - 2020-08-01 09:57:01 --> Language Class Initialized
INFO - 2020-08-01 09:57:01 --> Loader Class Initialized
INFO - 2020-08-01 09:57:01 --> Helper loaded: url_helper
INFO - 2020-08-01 09:57:01 --> Database Driver Class Initialized
INFO - 2020-08-01 09:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:57:01 --> Email Class Initialized
INFO - 2020-08-01 09:57:01 --> Controller Class Initialized
DEBUG - 2020-08-01 09:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:57:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:57:01 --> Model Class Initialized
INFO - 2020-08-01 09:57:01 --> Model Class Initialized
INFO - 2020-08-01 09:57:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:57:01 --> Final output sent to browser
DEBUG - 2020-08-01 09:57:01 --> Total execution time: 0.0304
INFO - 2020-08-01 09:57:04 --> Config Class Initialized
INFO - 2020-08-01 09:57:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:57:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:57:04 --> Utf8 Class Initialized
INFO - 2020-08-01 09:57:04 --> URI Class Initialized
INFO - 2020-08-01 09:57:04 --> Router Class Initialized
INFO - 2020-08-01 09:57:04 --> Output Class Initialized
INFO - 2020-08-01 09:57:04 --> Security Class Initialized
DEBUG - 2020-08-01 09:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:57:04 --> Input Class Initialized
INFO - 2020-08-01 09:57:04 --> Language Class Initialized
INFO - 2020-08-01 09:57:04 --> Loader Class Initialized
INFO - 2020-08-01 09:57:04 --> Helper loaded: url_helper
INFO - 2020-08-01 09:57:04 --> Database Driver Class Initialized
INFO - 2020-08-01 09:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:57:04 --> Email Class Initialized
INFO - 2020-08-01 09:57:04 --> Controller Class Initialized
DEBUG - 2020-08-01 09:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:57:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:57:04 --> Model Class Initialized
INFO - 2020-08-01 09:57:04 --> Model Class Initialized
INFO - 2020-08-01 09:57:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-01 09:57:04 --> Final output sent to browser
DEBUG - 2020-08-01 09:57:04 --> Total execution time: 0.0274
INFO - 2020-08-01 09:57:07 --> Config Class Initialized
INFO - 2020-08-01 09:57:07 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:57:07 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:57:07 --> Utf8 Class Initialized
INFO - 2020-08-01 09:57:07 --> URI Class Initialized
INFO - 2020-08-01 09:57:07 --> Router Class Initialized
INFO - 2020-08-01 09:57:07 --> Output Class Initialized
INFO - 2020-08-01 09:57:07 --> Security Class Initialized
DEBUG - 2020-08-01 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:57:07 --> Input Class Initialized
INFO - 2020-08-01 09:57:07 --> Language Class Initialized
INFO - 2020-08-01 09:57:07 --> Loader Class Initialized
INFO - 2020-08-01 09:57:07 --> Helper loaded: url_helper
INFO - 2020-08-01 09:57:07 --> Database Driver Class Initialized
INFO - 2020-08-01 09:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:57:07 --> Email Class Initialized
INFO - 2020-08-01 09:57:07 --> Controller Class Initialized
DEBUG - 2020-08-01 09:57:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:57:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:57:07 --> Model Class Initialized
INFO - 2020-08-01 09:57:07 --> Model Class Initialized
INFO - 2020-08-01 09:57:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 09:57:07 --> Final output sent to browser
DEBUG - 2020-08-01 09:57:07 --> Total execution time: 0.0265
INFO - 2020-08-01 09:57:17 --> Config Class Initialized
INFO - 2020-08-01 09:57:17 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:57:17 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:57:17 --> Utf8 Class Initialized
INFO - 2020-08-01 09:57:17 --> URI Class Initialized
INFO - 2020-08-01 09:57:17 --> Router Class Initialized
INFO - 2020-08-01 09:57:17 --> Output Class Initialized
INFO - 2020-08-01 09:57:17 --> Security Class Initialized
DEBUG - 2020-08-01 09:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:57:17 --> Input Class Initialized
INFO - 2020-08-01 09:57:17 --> Language Class Initialized
INFO - 2020-08-01 09:57:17 --> Loader Class Initialized
INFO - 2020-08-01 09:57:17 --> Helper loaded: url_helper
INFO - 2020-08-01 09:57:17 --> Database Driver Class Initialized
INFO - 2020-08-01 09:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:57:17 --> Email Class Initialized
INFO - 2020-08-01 09:57:17 --> Controller Class Initialized
DEBUG - 2020-08-01 09:57:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 09:57:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:57:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 09:57:17 --> Final output sent to browser
DEBUG - 2020-08-01 09:57:17 --> Total execution time: 0.0217
INFO - 2020-08-01 09:57:19 --> Config Class Initialized
INFO - 2020-08-01 09:57:19 --> Hooks Class Initialized
DEBUG - 2020-08-01 09:57:19 --> UTF-8 Support Enabled
INFO - 2020-08-01 09:57:19 --> Utf8 Class Initialized
INFO - 2020-08-01 09:57:19 --> URI Class Initialized
DEBUG - 2020-08-01 09:57:19 --> No URI present. Default controller set.
INFO - 2020-08-01 09:57:19 --> Router Class Initialized
INFO - 2020-08-01 09:57:19 --> Output Class Initialized
INFO - 2020-08-01 09:57:19 --> Security Class Initialized
DEBUG - 2020-08-01 09:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 09:57:19 --> Input Class Initialized
INFO - 2020-08-01 09:57:19 --> Language Class Initialized
INFO - 2020-08-01 09:57:19 --> Loader Class Initialized
INFO - 2020-08-01 09:57:19 --> Helper loaded: url_helper
INFO - 2020-08-01 09:57:19 --> Database Driver Class Initialized
INFO - 2020-08-01 09:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 09:57:19 --> Email Class Initialized
INFO - 2020-08-01 09:57:19 --> Controller Class Initialized
INFO - 2020-08-01 09:57:19 --> Model Class Initialized
INFO - 2020-08-01 09:57:19 --> Model Class Initialized
DEBUG - 2020-08-01 09:57:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 09:57:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 09:57:19 --> Final output sent to browser
DEBUG - 2020-08-01 09:57:19 --> Total execution time: 0.0196
INFO - 2020-08-01 10:01:28 --> Config Class Initialized
INFO - 2020-08-01 10:01:28 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:01:28 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:01:28 --> Utf8 Class Initialized
INFO - 2020-08-01 10:01:28 --> URI Class Initialized
DEBUG - 2020-08-01 10:01:28 --> No URI present. Default controller set.
INFO - 2020-08-01 10:01:28 --> Router Class Initialized
INFO - 2020-08-01 10:01:28 --> Output Class Initialized
INFO - 2020-08-01 10:01:28 --> Security Class Initialized
DEBUG - 2020-08-01 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:01:28 --> Input Class Initialized
INFO - 2020-08-01 10:01:28 --> Language Class Initialized
INFO - 2020-08-01 10:01:28 --> Loader Class Initialized
INFO - 2020-08-01 10:01:28 --> Helper loaded: url_helper
INFO - 2020-08-01 10:01:28 --> Database Driver Class Initialized
INFO - 2020-08-01 10:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:01:28 --> Email Class Initialized
INFO - 2020-08-01 10:01:28 --> Controller Class Initialized
INFO - 2020-08-01 10:01:28 --> Model Class Initialized
INFO - 2020-08-01 10:01:28 --> Model Class Initialized
DEBUG - 2020-08-01 10:01:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:01:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 10:01:28 --> Final output sent to browser
DEBUG - 2020-08-01 10:01:28 --> Total execution time: 0.0342
INFO - 2020-08-01 10:02:06 --> Config Class Initialized
INFO - 2020-08-01 10:02:06 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:02:06 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:02:06 --> Utf8 Class Initialized
INFO - 2020-08-01 10:02:06 --> URI Class Initialized
DEBUG - 2020-08-01 10:02:06 --> No URI present. Default controller set.
INFO - 2020-08-01 10:02:06 --> Router Class Initialized
INFO - 2020-08-01 10:02:06 --> Output Class Initialized
INFO - 2020-08-01 10:02:06 --> Security Class Initialized
DEBUG - 2020-08-01 10:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:02:06 --> Input Class Initialized
INFO - 2020-08-01 10:02:06 --> Language Class Initialized
INFO - 2020-08-01 10:02:06 --> Loader Class Initialized
INFO - 2020-08-01 10:02:06 --> Helper loaded: url_helper
INFO - 2020-08-01 10:02:06 --> Database Driver Class Initialized
INFO - 2020-08-01 10:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:02:06 --> Email Class Initialized
INFO - 2020-08-01 10:02:06 --> Controller Class Initialized
INFO - 2020-08-01 10:02:06 --> Model Class Initialized
INFO - 2020-08-01 10:02:06 --> Model Class Initialized
DEBUG - 2020-08-01 10:02:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:02:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 10:02:06 --> Final output sent to browser
DEBUG - 2020-08-01 10:02:06 --> Total execution time: 0.0214
INFO - 2020-08-01 10:02:12 --> Config Class Initialized
INFO - 2020-08-01 10:02:12 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:02:12 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:02:12 --> Utf8 Class Initialized
INFO - 2020-08-01 10:02:12 --> URI Class Initialized
INFO - 2020-08-01 10:02:12 --> Router Class Initialized
INFO - 2020-08-01 10:02:12 --> Output Class Initialized
INFO - 2020-08-01 10:02:12 --> Security Class Initialized
DEBUG - 2020-08-01 10:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:02:12 --> Input Class Initialized
INFO - 2020-08-01 10:02:12 --> Language Class Initialized
INFO - 2020-08-01 10:02:12 --> Loader Class Initialized
INFO - 2020-08-01 10:02:12 --> Helper loaded: url_helper
INFO - 2020-08-01 10:02:12 --> Database Driver Class Initialized
INFO - 2020-08-01 10:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:02:12 --> Email Class Initialized
INFO - 2020-08-01 10:02:12 --> Controller Class Initialized
INFO - 2020-08-01 10:02:12 --> Model Class Initialized
INFO - 2020-08-01 10:02:12 --> Model Class Initialized
DEBUG - 2020-08-01 10:02:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:02:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:02:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-01 10:02:12 --> Final output sent to browser
DEBUG - 2020-08-01 10:02:12 --> Total execution time: 0.0199
INFO - 2020-08-01 10:02:15 --> Config Class Initialized
INFO - 2020-08-01 10:02:15 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:02:15 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:02:15 --> Utf8 Class Initialized
INFO - 2020-08-01 10:02:15 --> URI Class Initialized
DEBUG - 2020-08-01 10:02:15 --> No URI present. Default controller set.
INFO - 2020-08-01 10:02:15 --> Router Class Initialized
INFO - 2020-08-01 10:02:15 --> Output Class Initialized
INFO - 2020-08-01 10:02:15 --> Security Class Initialized
DEBUG - 2020-08-01 10:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:02:15 --> Input Class Initialized
INFO - 2020-08-01 10:02:15 --> Language Class Initialized
INFO - 2020-08-01 10:02:15 --> Loader Class Initialized
INFO - 2020-08-01 10:02:15 --> Helper loaded: url_helper
INFO - 2020-08-01 10:02:15 --> Database Driver Class Initialized
INFO - 2020-08-01 10:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:02:15 --> Email Class Initialized
INFO - 2020-08-01 10:02:15 --> Controller Class Initialized
INFO - 2020-08-01 10:02:15 --> Model Class Initialized
INFO - 2020-08-01 10:02:15 --> Model Class Initialized
DEBUG - 2020-08-01 10:02:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:02:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 10:02:15 --> Final output sent to browser
DEBUG - 2020-08-01 10:02:15 --> Total execution time: 0.0240
INFO - 2020-08-01 10:04:04 --> Config Class Initialized
INFO - 2020-08-01 10:04:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:04 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:04 --> URI Class Initialized
INFO - 2020-08-01 10:04:04 --> Router Class Initialized
INFO - 2020-08-01 10:04:04 --> Output Class Initialized
INFO - 2020-08-01 10:04:04 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:04 --> Input Class Initialized
INFO - 2020-08-01 10:04:04 --> Language Class Initialized
INFO - 2020-08-01 10:04:04 --> Loader Class Initialized
INFO - 2020-08-01 10:04:04 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:04 --> Config Class Initialized
INFO - 2020-08-01 10:04:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:04 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:04 --> URI Class Initialized
INFO - 2020-08-01 10:04:04 --> Router Class Initialized
INFO - 2020-08-01 10:04:04 --> Output Class Initialized
INFO - 2020-08-01 10:04:04 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:04 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:04 --> Input Class Initialized
INFO - 2020-08-01 10:04:04 --> Language Class Initialized
INFO - 2020-08-01 10:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:04 --> Loader Class Initialized
INFO - 2020-08-01 10:04:04 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:04 --> Email Class Initialized
INFO - 2020-08-01 10:04:04 --> Controller Class Initialized
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
DEBUG - 2020-08-01 10:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
INFO - 2020-08-01 10:04:04 --> Final output sent to browser
DEBUG - 2020-08-01 10:04:04 --> Total execution time: 0.0280
INFO - 2020-08-01 10:04:04 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:04 --> Email Class Initialized
INFO - 2020-08-01 10:04:04 --> Controller Class Initialized
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
DEBUG - 2020-08-01 10:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:04 --> Config Class Initialized
INFO - 2020-08-01 10:04:04 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:04 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:04 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:04 --> URI Class Initialized
DEBUG - 2020-08-01 10:04:04 --> No URI present. Default controller set.
INFO - 2020-08-01 10:04:04 --> Router Class Initialized
INFO - 2020-08-01 10:04:04 --> Output Class Initialized
INFO - 2020-08-01 10:04:04 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:04 --> Input Class Initialized
INFO - 2020-08-01 10:04:04 --> Language Class Initialized
INFO - 2020-08-01 10:04:04 --> Loader Class Initialized
INFO - 2020-08-01 10:04:04 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:04 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:04 --> Email Class Initialized
INFO - 2020-08-01 10:04:04 --> Controller Class Initialized
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
INFO - 2020-08-01 10:04:04 --> Model Class Initialized
DEBUG - 2020-08-01 10:04:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 10:04:04 --> Final output sent to browser
DEBUG - 2020-08-01 10:04:04 --> Total execution time: 0.0215
INFO - 2020-08-01 10:04:48 --> Config Class Initialized
INFO - 2020-08-01 10:04:48 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:48 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:48 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:48 --> URI Class Initialized
INFO - 2020-08-01 10:04:48 --> Router Class Initialized
INFO - 2020-08-01 10:04:48 --> Output Class Initialized
INFO - 2020-08-01 10:04:48 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:48 --> Input Class Initialized
INFO - 2020-08-01 10:04:48 --> Language Class Initialized
INFO - 2020-08-01 10:04:48 --> Loader Class Initialized
INFO - 2020-08-01 10:04:48 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:48 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:48 --> Email Class Initialized
INFO - 2020-08-01 10:04:48 --> Controller Class Initialized
INFO - 2020-08-01 10:04:48 --> Model Class Initialized
INFO - 2020-08-01 10:04:48 --> Model Class Initialized
DEBUG - 2020-08-01 10:04:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:04:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:48 --> Model Class Initialized
INFO - 2020-08-01 10:04:48 --> Final output sent to browser
DEBUG - 2020-08-01 10:04:48 --> Total execution time: 0.0325
INFO - 2020-08-01 10:04:48 --> Config Class Initialized
INFO - 2020-08-01 10:04:48 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:48 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:48 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:48 --> URI Class Initialized
INFO - 2020-08-01 10:04:48 --> Router Class Initialized
INFO - 2020-08-01 10:04:48 --> Output Class Initialized
INFO - 2020-08-01 10:04:48 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:48 --> Input Class Initialized
INFO - 2020-08-01 10:04:48 --> Language Class Initialized
INFO - 2020-08-01 10:04:48 --> Loader Class Initialized
INFO - 2020-08-01 10:04:48 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:48 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:48 --> Email Class Initialized
INFO - 2020-08-01 10:04:48 --> Controller Class Initialized
INFO - 2020-08-01 10:04:48 --> Model Class Initialized
INFO - 2020-08-01 10:04:48 --> Model Class Initialized
DEBUG - 2020-08-01 10:04:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:48 --> Config Class Initialized
INFO - 2020-08-01 10:04:48 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:48 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:48 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:48 --> URI Class Initialized
INFO - 2020-08-01 10:04:48 --> Router Class Initialized
INFO - 2020-08-01 10:04:48 --> Output Class Initialized
INFO - 2020-08-01 10:04:48 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:48 --> Input Class Initialized
INFO - 2020-08-01 10:04:48 --> Language Class Initialized
INFO - 2020-08-01 10:04:48 --> Loader Class Initialized
INFO - 2020-08-01 10:04:48 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:48 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:48 --> Email Class Initialized
INFO - 2020-08-01 10:04:48 --> Controller Class Initialized
DEBUG - 2020-08-01 10:04:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:04:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 10:04:48 --> Final output sent to browser
DEBUG - 2020-08-01 10:04:48 --> Total execution time: 0.0237
INFO - 2020-08-01 10:04:58 --> Config Class Initialized
INFO - 2020-08-01 10:04:58 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:04:58 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:04:58 --> Utf8 Class Initialized
INFO - 2020-08-01 10:04:58 --> URI Class Initialized
INFO - 2020-08-01 10:04:58 --> Router Class Initialized
INFO - 2020-08-01 10:04:58 --> Output Class Initialized
INFO - 2020-08-01 10:04:58 --> Security Class Initialized
DEBUG - 2020-08-01 10:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:04:58 --> Input Class Initialized
INFO - 2020-08-01 10:04:58 --> Language Class Initialized
INFO - 2020-08-01 10:04:58 --> Loader Class Initialized
INFO - 2020-08-01 10:04:58 --> Helper loaded: url_helper
INFO - 2020-08-01 10:04:58 --> Database Driver Class Initialized
INFO - 2020-08-01 10:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:04:58 --> Email Class Initialized
INFO - 2020-08-01 10:04:58 --> Controller Class Initialized
DEBUG - 2020-08-01 10:04:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:04:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:04:58 --> Model Class Initialized
INFO - 2020-08-01 10:04:58 --> Model Class Initialized
INFO - 2020-08-01 10:04:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 10:04:58 --> Final output sent to browser
DEBUG - 2020-08-01 10:04:58 --> Total execution time: 0.0244
INFO - 2020-08-01 10:05:07 --> Config Class Initialized
INFO - 2020-08-01 10:05:07 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:05:07 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:05:07 --> Utf8 Class Initialized
INFO - 2020-08-01 10:05:07 --> URI Class Initialized
INFO - 2020-08-01 10:05:07 --> Router Class Initialized
INFO - 2020-08-01 10:05:07 --> Output Class Initialized
INFO - 2020-08-01 10:05:07 --> Security Class Initialized
DEBUG - 2020-08-01 10:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:05:07 --> Input Class Initialized
INFO - 2020-08-01 10:05:07 --> Language Class Initialized
INFO - 2020-08-01 10:05:07 --> Loader Class Initialized
INFO - 2020-08-01 10:05:07 --> Helper loaded: url_helper
INFO - 2020-08-01 10:05:07 --> Database Driver Class Initialized
INFO - 2020-08-01 10:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:05:07 --> Email Class Initialized
INFO - 2020-08-01 10:05:07 --> Controller Class Initialized
DEBUG - 2020-08-01 10:05:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:05:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:05:07 --> Model Class Initialized
INFO - 2020-08-01 10:05:07 --> Model Class Initialized
INFO - 2020-08-01 10:05:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-01 10:05:07 --> Final output sent to browser
DEBUG - 2020-08-01 10:05:07 --> Total execution time: 0.0277
INFO - 2020-08-01 10:05:10 --> Config Class Initialized
INFO - 2020-08-01 10:05:10 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:05:10 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:05:10 --> Utf8 Class Initialized
INFO - 2020-08-01 10:05:10 --> URI Class Initialized
INFO - 2020-08-01 10:05:10 --> Router Class Initialized
INFO - 2020-08-01 10:05:10 --> Output Class Initialized
INFO - 2020-08-01 10:05:10 --> Security Class Initialized
DEBUG - 2020-08-01 10:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:05:10 --> Input Class Initialized
INFO - 2020-08-01 10:05:10 --> Language Class Initialized
INFO - 2020-08-01 10:05:10 --> Loader Class Initialized
INFO - 2020-08-01 10:05:10 --> Helper loaded: url_helper
INFO - 2020-08-01 10:05:10 --> Database Driver Class Initialized
INFO - 2020-08-01 10:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:05:10 --> Email Class Initialized
INFO - 2020-08-01 10:05:10 --> Controller Class Initialized
DEBUG - 2020-08-01 10:05:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:05:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:05:10 --> Model Class Initialized
INFO - 2020-08-01 10:05:10 --> Model Class Initialized
INFO - 2020-08-01 10:05:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 10:05:10 --> Final output sent to browser
DEBUG - 2020-08-01 10:05:10 --> Total execution time: 0.0261
INFO - 2020-08-01 10:05:18 --> Config Class Initialized
INFO - 2020-08-01 10:05:18 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:05:18 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:05:18 --> Utf8 Class Initialized
INFO - 2020-08-01 10:05:18 --> URI Class Initialized
DEBUG - 2020-08-01 10:05:18 --> No URI present. Default controller set.
INFO - 2020-08-01 10:05:18 --> Router Class Initialized
INFO - 2020-08-01 10:05:18 --> Output Class Initialized
INFO - 2020-08-01 10:05:18 --> Security Class Initialized
DEBUG - 2020-08-01 10:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:05:18 --> Input Class Initialized
INFO - 2020-08-01 10:05:18 --> Language Class Initialized
INFO - 2020-08-01 10:05:18 --> Loader Class Initialized
INFO - 2020-08-01 10:05:18 --> Helper loaded: url_helper
INFO - 2020-08-01 10:05:18 --> Database Driver Class Initialized
INFO - 2020-08-01 10:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:05:18 --> Email Class Initialized
INFO - 2020-08-01 10:05:18 --> Controller Class Initialized
INFO - 2020-08-01 10:05:18 --> Model Class Initialized
INFO - 2020-08-01 10:05:18 --> Model Class Initialized
DEBUG - 2020-08-01 10:05:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:05:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 10:05:18 --> Final output sent to browser
DEBUG - 2020-08-01 10:05:18 --> Total execution time: 0.0243
INFO - 2020-08-01 10:07:31 --> Config Class Initialized
INFO - 2020-08-01 10:07:31 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:07:31 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:07:31 --> Utf8 Class Initialized
INFO - 2020-08-01 10:07:31 --> URI Class Initialized
INFO - 2020-08-01 10:07:31 --> Router Class Initialized
INFO - 2020-08-01 10:07:31 --> Output Class Initialized
INFO - 2020-08-01 10:07:31 --> Config Class Initialized
INFO - 2020-08-01 10:07:31 --> Hooks Class Initialized
INFO - 2020-08-01 10:07:31 --> Security Class Initialized
DEBUG - 2020-08-01 10:07:31 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:07:31 --> Utf8 Class Initialized
DEBUG - 2020-08-01 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:07:31 --> Input Class Initialized
INFO - 2020-08-01 10:07:31 --> Language Class Initialized
INFO - 2020-08-01 10:07:31 --> URI Class Initialized
INFO - 2020-08-01 10:07:31 --> Router Class Initialized
INFO - 2020-08-01 10:07:31 --> Loader Class Initialized
INFO - 2020-08-01 10:07:31 --> Output Class Initialized
INFO - 2020-08-01 10:07:31 --> Helper loaded: url_helper
INFO - 2020-08-01 10:07:31 --> Security Class Initialized
DEBUG - 2020-08-01 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:07:31 --> Input Class Initialized
INFO - 2020-08-01 10:07:31 --> Language Class Initialized
INFO - 2020-08-01 10:07:31 --> Loader Class Initialized
INFO - 2020-08-01 10:07:31 --> Database Driver Class Initialized
INFO - 2020-08-01 10:07:31 --> Helper loaded: url_helper
INFO - 2020-08-01 10:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:07:31 --> Database Driver Class Initialized
INFO - 2020-08-01 10:07:31 --> Email Class Initialized
INFO - 2020-08-01 10:07:31 --> Controller Class Initialized
INFO - 2020-08-01 10:07:31 --> Model Class Initialized
INFO - 2020-08-01 10:07:31 --> Model Class Initialized
DEBUG - 2020-08-01 10:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:07:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:07:31 --> Model Class Initialized
INFO - 2020-08-01 10:07:31 --> Final output sent to browser
DEBUG - 2020-08-01 10:07:31 --> Total execution time: 0.0281
INFO - 2020-08-01 10:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:07:31 --> Email Class Initialized
INFO - 2020-08-01 10:07:31 --> Controller Class Initialized
INFO - 2020-08-01 10:07:31 --> Model Class Initialized
INFO - 2020-08-01 10:07:31 --> Model Class Initialized
DEBUG - 2020-08-01 10:07:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:07:31 --> Config Class Initialized
INFO - 2020-08-01 10:07:31 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:07:31 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:07:31 --> Utf8 Class Initialized
INFO - 2020-08-01 10:07:31 --> URI Class Initialized
INFO - 2020-08-01 10:07:31 --> Router Class Initialized
INFO - 2020-08-01 10:07:31 --> Output Class Initialized
INFO - 2020-08-01 10:07:31 --> Security Class Initialized
DEBUG - 2020-08-01 10:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:07:31 --> Input Class Initialized
INFO - 2020-08-01 10:07:31 --> Language Class Initialized
INFO - 2020-08-01 10:07:31 --> Loader Class Initialized
INFO - 2020-08-01 10:07:31 --> Helper loaded: url_helper
INFO - 2020-08-01 10:07:31 --> Database Driver Class Initialized
INFO - 2020-08-01 10:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:07:31 --> Email Class Initialized
INFO - 2020-08-01 10:07:31 --> Controller Class Initialized
DEBUG - 2020-08-01 10:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:07:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:07:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 10:07:31 --> Final output sent to browser
DEBUG - 2020-08-01 10:07:31 --> Total execution time: 0.0281
INFO - 2020-08-01 10:48:18 --> Config Class Initialized
INFO - 2020-08-01 10:48:18 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:48:18 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:48:18 --> Utf8 Class Initialized
INFO - 2020-08-01 10:48:18 --> URI Class Initialized
INFO - 2020-08-01 10:48:18 --> Router Class Initialized
INFO - 2020-08-01 10:48:18 --> Output Class Initialized
INFO - 2020-08-01 10:48:18 --> Security Class Initialized
DEBUG - 2020-08-01 10:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:48:18 --> Input Class Initialized
INFO - 2020-08-01 10:48:18 --> Language Class Initialized
INFO - 2020-08-01 10:48:18 --> Loader Class Initialized
INFO - 2020-08-01 10:48:18 --> Helper loaded: url_helper
INFO - 2020-08-01 10:48:18 --> Database Driver Class Initialized
INFO - 2020-08-01 10:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:48:18 --> Email Class Initialized
INFO - 2020-08-01 10:48:18 --> Controller Class Initialized
INFO - 2020-08-01 10:48:18 --> Model Class Initialized
INFO - 2020-08-01 10:48:18 --> Model Class Initialized
DEBUG - 2020-08-01 10:48:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 10:48:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:48:19 --> Config Class Initialized
INFO - 2020-08-01 10:48:19 --> Hooks Class Initialized
DEBUG - 2020-08-01 10:48:19 --> UTF-8 Support Enabled
INFO - 2020-08-01 10:48:19 --> Utf8 Class Initialized
INFO - 2020-08-01 10:48:19 --> URI Class Initialized
DEBUG - 2020-08-01 10:48:19 --> No URI present. Default controller set.
INFO - 2020-08-01 10:48:19 --> Router Class Initialized
INFO - 2020-08-01 10:48:19 --> Output Class Initialized
INFO - 2020-08-01 10:48:19 --> Security Class Initialized
DEBUG - 2020-08-01 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 10:48:19 --> Input Class Initialized
INFO - 2020-08-01 10:48:19 --> Language Class Initialized
INFO - 2020-08-01 10:48:19 --> Loader Class Initialized
INFO - 2020-08-01 10:48:19 --> Helper loaded: url_helper
INFO - 2020-08-01 10:48:19 --> Database Driver Class Initialized
INFO - 2020-08-01 10:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 10:48:19 --> Email Class Initialized
INFO - 2020-08-01 10:48:19 --> Controller Class Initialized
INFO - 2020-08-01 10:48:19 --> Model Class Initialized
INFO - 2020-08-01 10:48:19 --> Model Class Initialized
DEBUG - 2020-08-01 10:48:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 10:48:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 10:48:19 --> Final output sent to browser
DEBUG - 2020-08-01 10:48:19 --> Total execution time: 0.0319
INFO - 2020-08-01 16:41:52 --> Config Class Initialized
INFO - 2020-08-01 16:41:52 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:41:52 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:41:52 --> Utf8 Class Initialized
INFO - 2020-08-01 16:41:52 --> URI Class Initialized
DEBUG - 2020-08-01 16:41:52 --> No URI present. Default controller set.
INFO - 2020-08-01 16:41:52 --> Router Class Initialized
INFO - 2020-08-01 16:41:52 --> Output Class Initialized
INFO - 2020-08-01 16:41:52 --> Security Class Initialized
DEBUG - 2020-08-01 16:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:41:52 --> Input Class Initialized
INFO - 2020-08-01 16:41:52 --> Language Class Initialized
INFO - 2020-08-01 16:41:52 --> Loader Class Initialized
INFO - 2020-08-01 16:41:52 --> Helper loaded: url_helper
INFO - 2020-08-01 16:41:52 --> Database Driver Class Initialized
INFO - 2020-08-01 16:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:41:52 --> Email Class Initialized
INFO - 2020-08-01 16:41:52 --> Controller Class Initialized
INFO - 2020-08-01 16:41:52 --> Model Class Initialized
INFO - 2020-08-01 16:41:52 --> Model Class Initialized
DEBUG - 2020-08-01 16:41:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:41:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:41:52 --> Final output sent to browser
DEBUG - 2020-08-01 16:41:52 --> Total execution time: 0.0239
INFO - 2020-08-01 16:41:53 --> Config Class Initialized
INFO - 2020-08-01 16:41:53 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:41:53 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:41:53 --> Utf8 Class Initialized
INFO - 2020-08-01 16:41:53 --> URI Class Initialized
DEBUG - 2020-08-01 16:41:53 --> No URI present. Default controller set.
INFO - 2020-08-01 16:41:53 --> Router Class Initialized
INFO - 2020-08-01 16:41:53 --> Output Class Initialized
INFO - 2020-08-01 16:41:53 --> Security Class Initialized
DEBUG - 2020-08-01 16:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:41:53 --> Input Class Initialized
INFO - 2020-08-01 16:41:53 --> Language Class Initialized
INFO - 2020-08-01 16:41:53 --> Loader Class Initialized
INFO - 2020-08-01 16:41:53 --> Helper loaded: url_helper
INFO - 2020-08-01 16:41:53 --> Database Driver Class Initialized
INFO - 2020-08-01 16:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:41:53 --> Email Class Initialized
INFO - 2020-08-01 16:41:53 --> Controller Class Initialized
INFO - 2020-08-01 16:41:53 --> Model Class Initialized
INFO - 2020-08-01 16:41:53 --> Model Class Initialized
DEBUG - 2020-08-01 16:41:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:41:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:41:53 --> Final output sent to browser
DEBUG - 2020-08-01 16:41:53 --> Total execution time: 0.0252
INFO - 2020-08-01 16:42:43 --> Config Class Initialized
INFO - 2020-08-01 16:42:43 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:42:43 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:42:43 --> Utf8 Class Initialized
INFO - 2020-08-01 16:42:43 --> URI Class Initialized
INFO - 2020-08-01 16:42:43 --> Router Class Initialized
INFO - 2020-08-01 16:42:43 --> Output Class Initialized
INFO - 2020-08-01 16:42:43 --> Security Class Initialized
DEBUG - 2020-08-01 16:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:42:43 --> Input Class Initialized
INFO - 2020-08-01 16:42:43 --> Language Class Initialized
INFO - 2020-08-01 16:42:43 --> Loader Class Initialized
INFO - 2020-08-01 16:42:43 --> Helper loaded: url_helper
INFO - 2020-08-01 16:42:43 --> Database Driver Class Initialized
INFO - 2020-08-01 16:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:42:43 --> Email Class Initialized
INFO - 2020-08-01 16:42:43 --> Controller Class Initialized
INFO - 2020-08-01 16:42:43 --> Model Class Initialized
INFO - 2020-08-01 16:42:43 --> Model Class Initialized
DEBUG - 2020-08-01 16:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:42:43 --> Config Class Initialized
INFO - 2020-08-01 16:42:43 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:42:43 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:42:43 --> Utf8 Class Initialized
INFO - 2020-08-01 16:42:43 --> URI Class Initialized
INFO - 2020-08-01 16:42:43 --> Router Class Initialized
INFO - 2020-08-01 16:42:43 --> Output Class Initialized
INFO - 2020-08-01 16:42:43 --> Security Class Initialized
DEBUG - 2020-08-01 16:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:42:43 --> Input Class Initialized
INFO - 2020-08-01 16:42:43 --> Language Class Initialized
INFO - 2020-08-01 16:42:43 --> Loader Class Initialized
INFO - 2020-08-01 16:42:43 --> Helper loaded: url_helper
INFO - 2020-08-01 16:42:43 --> Database Driver Class Initialized
INFO - 2020-08-01 16:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:42:43 --> Email Class Initialized
INFO - 2020-08-01 16:42:43 --> Controller Class Initialized
INFO - 2020-08-01 16:42:43 --> Model Class Initialized
INFO - 2020-08-01 16:42:43 --> Model Class Initialized
DEBUG - 2020-08-01 16:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:42:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:42:44 --> Config Class Initialized
INFO - 2020-08-01 16:42:44 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:42:44 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:42:44 --> Utf8 Class Initialized
INFO - 2020-08-01 16:42:44 --> URI Class Initialized
DEBUG - 2020-08-01 16:42:44 --> No URI present. Default controller set.
INFO - 2020-08-01 16:42:44 --> Router Class Initialized
INFO - 2020-08-01 16:42:44 --> Output Class Initialized
INFO - 2020-08-01 16:42:44 --> Security Class Initialized
DEBUG - 2020-08-01 16:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:42:44 --> Input Class Initialized
INFO - 2020-08-01 16:42:44 --> Language Class Initialized
INFO - 2020-08-01 16:42:44 --> Loader Class Initialized
INFO - 2020-08-01 16:42:44 --> Helper loaded: url_helper
INFO - 2020-08-01 16:42:44 --> Database Driver Class Initialized
INFO - 2020-08-01 16:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:42:44 --> Email Class Initialized
INFO - 2020-08-01 16:42:44 --> Controller Class Initialized
INFO - 2020-08-01 16:42:44 --> Model Class Initialized
INFO - 2020-08-01 16:42:44 --> Model Class Initialized
DEBUG - 2020-08-01 16:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:42:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:42:44 --> Final output sent to browser
DEBUG - 2020-08-01 16:42:44 --> Total execution time: 0.0239
INFO - 2020-08-01 16:42:46 --> Config Class Initialized
INFO - 2020-08-01 16:42:46 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:42:46 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:42:46 --> Utf8 Class Initialized
INFO - 2020-08-01 16:42:46 --> URI Class Initialized
DEBUG - 2020-08-01 16:42:46 --> No URI present. Default controller set.
INFO - 2020-08-01 16:42:46 --> Router Class Initialized
INFO - 2020-08-01 16:42:46 --> Output Class Initialized
INFO - 2020-08-01 16:42:46 --> Security Class Initialized
DEBUG - 2020-08-01 16:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:42:46 --> Input Class Initialized
INFO - 2020-08-01 16:42:46 --> Language Class Initialized
INFO - 2020-08-01 16:42:46 --> Loader Class Initialized
INFO - 2020-08-01 16:42:46 --> Helper loaded: url_helper
INFO - 2020-08-01 16:42:46 --> Database Driver Class Initialized
INFO - 2020-08-01 16:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:42:46 --> Email Class Initialized
INFO - 2020-08-01 16:42:46 --> Controller Class Initialized
INFO - 2020-08-01 16:42:46 --> Model Class Initialized
INFO - 2020-08-01 16:42:46 --> Model Class Initialized
DEBUG - 2020-08-01 16:42:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:42:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:42:46 --> Final output sent to browser
DEBUG - 2020-08-01 16:42:46 --> Total execution time: 0.0220
INFO - 2020-08-01 16:43:29 --> Config Class Initialized
INFO - 2020-08-01 16:43:29 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:43:29 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:43:29 --> Utf8 Class Initialized
INFO - 2020-08-01 16:43:29 --> URI Class Initialized
INFO - 2020-08-01 16:43:29 --> Router Class Initialized
INFO - 2020-08-01 16:43:29 --> Output Class Initialized
INFO - 2020-08-01 16:43:29 --> Security Class Initialized
DEBUG - 2020-08-01 16:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:43:29 --> Input Class Initialized
INFO - 2020-08-01 16:43:29 --> Language Class Initialized
INFO - 2020-08-01 16:43:29 --> Loader Class Initialized
INFO - 2020-08-01 16:43:29 --> Helper loaded: url_helper
INFO - 2020-08-01 16:43:29 --> Database Driver Class Initialized
INFO - 2020-08-01 16:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:43:29 --> Email Class Initialized
INFO - 2020-08-01 16:43:29 --> Controller Class Initialized
INFO - 2020-08-01 16:43:29 --> Model Class Initialized
INFO - 2020-08-01 16:43:29 --> Model Class Initialized
DEBUG - 2020-08-01 16:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:43:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:43:29 --> Config Class Initialized
INFO - 2020-08-01 16:43:29 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:43:29 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:43:29 --> Utf8 Class Initialized
INFO - 2020-08-01 16:43:29 --> URI Class Initialized
INFO - 2020-08-01 16:43:29 --> Router Class Initialized
INFO - 2020-08-01 16:43:29 --> Output Class Initialized
INFO - 2020-08-01 16:43:29 --> Security Class Initialized
DEBUG - 2020-08-01 16:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:43:29 --> Input Class Initialized
INFO - 2020-08-01 16:43:29 --> Language Class Initialized
INFO - 2020-08-01 16:43:29 --> Loader Class Initialized
INFO - 2020-08-01 16:43:29 --> Helper loaded: url_helper
INFO - 2020-08-01 16:43:29 --> Database Driver Class Initialized
INFO - 2020-08-01 16:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:43:29 --> Email Class Initialized
INFO - 2020-08-01 16:43:29 --> Controller Class Initialized
INFO - 2020-08-01 16:43:29 --> Model Class Initialized
INFO - 2020-08-01 16:43:29 --> Model Class Initialized
DEBUG - 2020-08-01 16:43:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:43:30 --> Config Class Initialized
INFO - 2020-08-01 16:43:30 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:43:30 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:43:30 --> Utf8 Class Initialized
INFO - 2020-08-01 16:43:30 --> URI Class Initialized
DEBUG - 2020-08-01 16:43:30 --> No URI present. Default controller set.
INFO - 2020-08-01 16:43:30 --> Router Class Initialized
INFO - 2020-08-01 16:43:30 --> Output Class Initialized
INFO - 2020-08-01 16:43:30 --> Security Class Initialized
DEBUG - 2020-08-01 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:43:30 --> Input Class Initialized
INFO - 2020-08-01 16:43:30 --> Language Class Initialized
INFO - 2020-08-01 16:43:30 --> Loader Class Initialized
INFO - 2020-08-01 16:43:30 --> Helper loaded: url_helper
INFO - 2020-08-01 16:43:30 --> Database Driver Class Initialized
INFO - 2020-08-01 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:43:30 --> Email Class Initialized
INFO - 2020-08-01 16:43:30 --> Controller Class Initialized
INFO - 2020-08-01 16:43:30 --> Model Class Initialized
INFO - 2020-08-01 16:43:30 --> Model Class Initialized
DEBUG - 2020-08-01 16:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:43:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:43:30 --> Final output sent to browser
DEBUG - 2020-08-01 16:43:30 --> Total execution time: 0.0259
INFO - 2020-08-01 16:43:30 --> Config Class Initialized
INFO - 2020-08-01 16:43:30 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:43:30 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:43:30 --> Utf8 Class Initialized
INFO - 2020-08-01 16:43:30 --> URI Class Initialized
INFO - 2020-08-01 16:43:30 --> Router Class Initialized
INFO - 2020-08-01 16:43:30 --> Output Class Initialized
INFO - 2020-08-01 16:43:30 --> Security Class Initialized
DEBUG - 2020-08-01 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:43:30 --> Input Class Initialized
INFO - 2020-08-01 16:43:30 --> Language Class Initialized
INFO - 2020-08-01 16:43:30 --> Loader Class Initialized
INFO - 2020-08-01 16:43:30 --> Helper loaded: url_helper
INFO - 2020-08-01 16:43:30 --> Database Driver Class Initialized
INFO - 2020-08-01 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:43:30 --> Email Class Initialized
INFO - 2020-08-01 16:43:30 --> Controller Class Initialized
DEBUG - 2020-08-01 16:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:43:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:43:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-01 16:43:30 --> Final output sent to browser
DEBUG - 2020-08-01 16:43:30 --> Total execution time: 0.0352
INFO - 2020-08-01 16:43:55 --> Config Class Initialized
INFO - 2020-08-01 16:43:55 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:43:55 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:43:55 --> Utf8 Class Initialized
INFO - 2020-08-01 16:43:55 --> URI Class Initialized
INFO - 2020-08-01 16:43:55 --> Router Class Initialized
INFO - 2020-08-01 16:43:55 --> Output Class Initialized
INFO - 2020-08-01 16:43:55 --> Security Class Initialized
DEBUG - 2020-08-01 16:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:43:55 --> Input Class Initialized
INFO - 2020-08-01 16:43:55 --> Language Class Initialized
INFO - 2020-08-01 16:43:55 --> Loader Class Initialized
INFO - 2020-08-01 16:43:55 --> Helper loaded: url_helper
INFO - 2020-08-01 16:43:55 --> Database Driver Class Initialized
INFO - 2020-08-01 16:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:43:55 --> Email Class Initialized
INFO - 2020-08-01 16:43:55 --> Controller Class Initialized
DEBUG - 2020-08-01 16:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:43:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:43:55 --> Model Class Initialized
INFO - 2020-08-01 16:43:55 --> Model Class Initialized
INFO - 2020-08-01 16:43:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 16:43:55 --> Final output sent to browser
DEBUG - 2020-08-01 16:43:55 --> Total execution time: 0.0350
INFO - 2020-08-01 16:44:08 --> Config Class Initialized
INFO - 2020-08-01 16:44:08 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:44:08 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:44:08 --> Utf8 Class Initialized
INFO - 2020-08-01 16:44:08 --> URI Class Initialized
INFO - 2020-08-01 16:44:08 --> Router Class Initialized
INFO - 2020-08-01 16:44:08 --> Output Class Initialized
INFO - 2020-08-01 16:44:08 --> Security Class Initialized
DEBUG - 2020-08-01 16:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:44:08 --> Input Class Initialized
INFO - 2020-08-01 16:44:08 --> Language Class Initialized
INFO - 2020-08-01 16:44:08 --> Loader Class Initialized
INFO - 2020-08-01 16:44:08 --> Helper loaded: url_helper
INFO - 2020-08-01 16:44:08 --> Database Driver Class Initialized
INFO - 2020-08-01 16:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:44:08 --> Email Class Initialized
INFO - 2020-08-01 16:44:08 --> Controller Class Initialized
DEBUG - 2020-08-01 16:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:44:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:44:08 --> Model Class Initialized
INFO - 2020-08-01 16:44:08 --> Model Class Initialized
INFO - 2020-08-01 16:44:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-01 16:44:08 --> Final output sent to browser
DEBUG - 2020-08-01 16:44:08 --> Total execution time: 0.0254
INFO - 2020-08-01 16:44:16 --> Config Class Initialized
INFO - 2020-08-01 16:44:16 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:44:16 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:44:16 --> Utf8 Class Initialized
INFO - 2020-08-01 16:44:16 --> URI Class Initialized
INFO - 2020-08-01 16:44:16 --> Router Class Initialized
INFO - 2020-08-01 16:44:16 --> Output Class Initialized
INFO - 2020-08-01 16:44:16 --> Security Class Initialized
DEBUG - 2020-08-01 16:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:44:16 --> Input Class Initialized
INFO - 2020-08-01 16:44:16 --> Language Class Initialized
INFO - 2020-08-01 16:44:16 --> Loader Class Initialized
INFO - 2020-08-01 16:44:16 --> Helper loaded: url_helper
INFO - 2020-08-01 16:44:16 --> Database Driver Class Initialized
INFO - 2020-08-01 16:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:44:16 --> Email Class Initialized
INFO - 2020-08-01 16:44:16 --> Controller Class Initialized
DEBUG - 2020-08-01 16:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:44:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:44:16 --> Model Class Initialized
INFO - 2020-08-01 16:44:16 --> Model Class Initialized
INFO - 2020-08-01 16:44:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 16:44:16 --> Final output sent to browser
DEBUG - 2020-08-01 16:44:16 --> Total execution time: 0.0241
INFO - 2020-08-01 16:44:22 --> Config Class Initialized
INFO - 2020-08-01 16:44:22 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:44:22 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:44:22 --> Utf8 Class Initialized
INFO - 2020-08-01 16:44:22 --> URI Class Initialized
INFO - 2020-08-01 16:44:22 --> Router Class Initialized
INFO - 2020-08-01 16:44:22 --> Output Class Initialized
INFO - 2020-08-01 16:44:22 --> Security Class Initialized
DEBUG - 2020-08-01 16:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:44:22 --> Input Class Initialized
INFO - 2020-08-01 16:44:22 --> Language Class Initialized
INFO - 2020-08-01 16:44:22 --> Loader Class Initialized
INFO - 2020-08-01 16:44:22 --> Helper loaded: url_helper
INFO - 2020-08-01 16:44:22 --> Database Driver Class Initialized
INFO - 2020-08-01 16:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:44:22 --> Email Class Initialized
INFO - 2020-08-01 16:44:22 --> Controller Class Initialized
DEBUG - 2020-08-01 16:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:44:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:44:22 --> Model Class Initialized
INFO - 2020-08-01 16:44:22 --> Model Class Initialized
INFO - 2020-08-01 16:44:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-01 16:44:22 --> Final output sent to browser
DEBUG - 2020-08-01 16:44:22 --> Total execution time: 0.0234
INFO - 2020-08-01 16:44:29 --> Config Class Initialized
INFO - 2020-08-01 16:44:29 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:44:29 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:44:29 --> Utf8 Class Initialized
INFO - 2020-08-01 16:44:29 --> URI Class Initialized
INFO - 2020-08-01 16:44:29 --> Router Class Initialized
INFO - 2020-08-01 16:44:29 --> Output Class Initialized
INFO - 2020-08-01 16:44:29 --> Security Class Initialized
DEBUG - 2020-08-01 16:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:44:29 --> Input Class Initialized
INFO - 2020-08-01 16:44:29 --> Language Class Initialized
INFO - 2020-08-01 16:44:29 --> Loader Class Initialized
INFO - 2020-08-01 16:44:29 --> Helper loaded: url_helper
INFO - 2020-08-01 16:44:29 --> Database Driver Class Initialized
INFO - 2020-08-01 16:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:44:29 --> Email Class Initialized
INFO - 2020-08-01 16:44:29 --> Controller Class Initialized
DEBUG - 2020-08-01 16:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:44:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:44:29 --> Model Class Initialized
INFO - 2020-08-01 16:44:29 --> Model Class Initialized
INFO - 2020-08-01 16:44:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-01 16:44:29 --> Final output sent to browser
DEBUG - 2020-08-01 16:44:29 --> Total execution time: 0.0242
INFO - 2020-08-01 16:50:24 --> Config Class Initialized
INFO - 2020-08-01 16:50:24 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:50:24 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:50:24 --> Utf8 Class Initialized
INFO - 2020-08-01 16:50:24 --> URI Class Initialized
DEBUG - 2020-08-01 16:50:24 --> No URI present. Default controller set.
INFO - 2020-08-01 16:50:24 --> Router Class Initialized
INFO - 2020-08-01 16:50:24 --> Output Class Initialized
INFO - 2020-08-01 16:50:24 --> Security Class Initialized
DEBUG - 2020-08-01 16:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:50:24 --> Input Class Initialized
INFO - 2020-08-01 16:50:24 --> Language Class Initialized
INFO - 2020-08-01 16:50:24 --> Loader Class Initialized
INFO - 2020-08-01 16:50:24 --> Helper loaded: url_helper
INFO - 2020-08-01 16:50:24 --> Database Driver Class Initialized
INFO - 2020-08-01 16:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:50:24 --> Email Class Initialized
INFO - 2020-08-01 16:50:24 --> Controller Class Initialized
INFO - 2020-08-01 16:50:24 --> Model Class Initialized
INFO - 2020-08-01 16:50:24 --> Model Class Initialized
DEBUG - 2020-08-01 16:50:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:50:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:50:24 --> Final output sent to browser
DEBUG - 2020-08-01 16:50:24 --> Total execution time: 0.0250
INFO - 2020-08-01 16:50:25 --> Config Class Initialized
INFO - 2020-08-01 16:50:25 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:50:25 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:50:25 --> Utf8 Class Initialized
INFO - 2020-08-01 16:50:25 --> URI Class Initialized
DEBUG - 2020-08-01 16:50:25 --> No URI present. Default controller set.
INFO - 2020-08-01 16:50:25 --> Router Class Initialized
INFO - 2020-08-01 16:50:25 --> Output Class Initialized
INFO - 2020-08-01 16:50:25 --> Security Class Initialized
DEBUG - 2020-08-01 16:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:50:25 --> Input Class Initialized
INFO - 2020-08-01 16:50:25 --> Language Class Initialized
INFO - 2020-08-01 16:50:25 --> Loader Class Initialized
INFO - 2020-08-01 16:50:25 --> Helper loaded: url_helper
INFO - 2020-08-01 16:50:25 --> Database Driver Class Initialized
INFO - 2020-08-01 16:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:50:25 --> Email Class Initialized
INFO - 2020-08-01 16:50:25 --> Controller Class Initialized
INFO - 2020-08-01 16:50:25 --> Model Class Initialized
INFO - 2020-08-01 16:50:25 --> Model Class Initialized
DEBUG - 2020-08-01 16:50:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:50:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:50:25 --> Final output sent to browser
DEBUG - 2020-08-01 16:50:25 --> Total execution time: 0.0241
INFO - 2020-08-01 16:56:33 --> Config Class Initialized
INFO - 2020-08-01 16:56:33 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:56:33 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:56:33 --> Utf8 Class Initialized
INFO - 2020-08-01 16:56:33 --> URI Class Initialized
INFO - 2020-08-01 16:56:33 --> Router Class Initialized
INFO - 2020-08-01 16:56:33 --> Output Class Initialized
INFO - 2020-08-01 16:56:33 --> Security Class Initialized
DEBUG - 2020-08-01 16:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:56:33 --> Input Class Initialized
INFO - 2020-08-01 16:56:33 --> Language Class Initialized
INFO - 2020-08-01 16:56:33 --> Loader Class Initialized
INFO - 2020-08-01 16:56:33 --> Helper loaded: url_helper
INFO - 2020-08-01 16:56:33 --> Database Driver Class Initialized
INFO - 2020-08-01 16:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:56:33 --> Email Class Initialized
INFO - 2020-08-01 16:56:33 --> Controller Class Initialized
INFO - 2020-08-01 16:56:33 --> Model Class Initialized
INFO - 2020-08-01 16:56:33 --> Model Class Initialized
DEBUG - 2020-08-01 16:56:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-01 16:56:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:56:34 --> Config Class Initialized
INFO - 2020-08-01 16:56:34 --> Hooks Class Initialized
DEBUG - 2020-08-01 16:56:34 --> UTF-8 Support Enabled
INFO - 2020-08-01 16:56:34 --> Utf8 Class Initialized
INFO - 2020-08-01 16:56:34 --> URI Class Initialized
DEBUG - 2020-08-01 16:56:34 --> No URI present. Default controller set.
INFO - 2020-08-01 16:56:34 --> Router Class Initialized
INFO - 2020-08-01 16:56:34 --> Output Class Initialized
INFO - 2020-08-01 16:56:34 --> Security Class Initialized
DEBUG - 2020-08-01 16:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-01 16:56:34 --> Input Class Initialized
INFO - 2020-08-01 16:56:34 --> Language Class Initialized
INFO - 2020-08-01 16:56:34 --> Loader Class Initialized
INFO - 2020-08-01 16:56:34 --> Helper loaded: url_helper
INFO - 2020-08-01 16:56:34 --> Database Driver Class Initialized
INFO - 2020-08-01 16:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-01 16:56:34 --> Email Class Initialized
INFO - 2020-08-01 16:56:34 --> Controller Class Initialized
INFO - 2020-08-01 16:56:34 --> Model Class Initialized
INFO - 2020-08-01 16:56:34 --> Model Class Initialized
DEBUG - 2020-08-01 16:56:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-01 16:56:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-01 16:56:34 --> Final output sent to browser
DEBUG - 2020-08-01 16:56:34 --> Total execution time: 0.0205
