<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-11 16:55:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:55:05 --> Config Class Initialized
INFO - 2020-11-11 16:55:05 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:55:05 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:55:05 --> Utf8 Class Initialized
INFO - 2020-11-11 16:55:05 --> URI Class Initialized
DEBUG - 2020-11-11 16:55:05 --> No URI present. Default controller set.
INFO - 2020-11-11 16:55:05 --> Router Class Initialized
INFO - 2020-11-11 16:55:05 --> Output Class Initialized
INFO - 2020-11-11 16:55:05 --> Security Class Initialized
DEBUG - 2020-11-11 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:55:05 --> Input Class Initialized
INFO - 2020-11-11 16:55:05 --> Language Class Initialized
INFO - 2020-11-11 16:55:05 --> Loader Class Initialized
INFO - 2020-11-11 16:55:05 --> Helper loaded: url_helper
INFO - 2020-11-11 16:55:05 --> Database Driver Class Initialized
INFO - 2020-11-11 16:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:55:05 --> Email Class Initialized
INFO - 2020-11-11 16:55:05 --> Controller Class Initialized
INFO - 2020-11-11 16:55:05 --> Model Class Initialized
INFO - 2020-11-11 16:55:05 --> Model Class Initialized
DEBUG - 2020-11-11 16:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:55:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-11 16:55:05 --> Final output sent to browser
DEBUG - 2020-11-11 16:55:05 --> Total execution time: 0.1454
ERROR - 2020-11-11 16:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:55:27 --> Config Class Initialized
INFO - 2020-11-11 16:55:27 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:55:27 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:55:27 --> Utf8 Class Initialized
INFO - 2020-11-11 16:55:27 --> URI Class Initialized
INFO - 2020-11-11 16:55:27 --> Router Class Initialized
INFO - 2020-11-11 16:55:27 --> Output Class Initialized
INFO - 2020-11-11 16:55:27 --> Security Class Initialized
DEBUG - 2020-11-11 16:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:55:27 --> Input Class Initialized
INFO - 2020-11-11 16:55:27 --> Language Class Initialized
INFO - 2020-11-11 16:55:27 --> Loader Class Initialized
INFO - 2020-11-11 16:55:27 --> Helper loaded: url_helper
INFO - 2020-11-11 16:55:27 --> Database Driver Class Initialized
INFO - 2020-11-11 16:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:55:27 --> Email Class Initialized
INFO - 2020-11-11 16:55:27 --> Controller Class Initialized
INFO - 2020-11-11 16:55:27 --> Model Class Initialized
INFO - 2020-11-11 16:55:27 --> Model Class Initialized
DEBUG - 2020-11-11 16:55:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-11 16:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:55:27 --> Config Class Initialized
INFO - 2020-11-11 16:55:27 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:55:27 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:55:27 --> Utf8 Class Initialized
INFO - 2020-11-11 16:55:27 --> URI Class Initialized
INFO - 2020-11-11 16:55:27 --> Router Class Initialized
INFO - 2020-11-11 16:55:27 --> Output Class Initialized
INFO - 2020-11-11 16:55:27 --> Security Class Initialized
DEBUG - 2020-11-11 16:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:55:27 --> Input Class Initialized
INFO - 2020-11-11 16:55:27 --> Language Class Initialized
INFO - 2020-11-11 16:55:27 --> Loader Class Initialized
INFO - 2020-11-11 16:55:27 --> Helper loaded: url_helper
INFO - 2020-11-11 16:55:27 --> Database Driver Class Initialized
INFO - 2020-11-11 16:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:55:27 --> Email Class Initialized
INFO - 2020-11-11 16:55:27 --> Controller Class Initialized
INFO - 2020-11-11 16:55:27 --> Model Class Initialized
INFO - 2020-11-11 16:55:27 --> Model Class Initialized
DEBUG - 2020-11-11 16:55:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:55:27 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-11 16:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:55:28 --> Config Class Initialized
INFO - 2020-11-11 16:55:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:55:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:55:28 --> Utf8 Class Initialized
INFO - 2020-11-11 16:55:28 --> URI Class Initialized
DEBUG - 2020-11-11 16:55:28 --> No URI present. Default controller set.
INFO - 2020-11-11 16:55:28 --> Router Class Initialized
INFO - 2020-11-11 16:55:28 --> Output Class Initialized
INFO - 2020-11-11 16:55:28 --> Security Class Initialized
DEBUG - 2020-11-11 16:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:55:28 --> Input Class Initialized
INFO - 2020-11-11 16:55:28 --> Language Class Initialized
INFO - 2020-11-11 16:55:28 --> Loader Class Initialized
INFO - 2020-11-11 16:55:28 --> Helper loaded: url_helper
INFO - 2020-11-11 16:55:28 --> Database Driver Class Initialized
INFO - 2020-11-11 16:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:55:28 --> Email Class Initialized
INFO - 2020-11-11 16:55:28 --> Controller Class Initialized
INFO - 2020-11-11 16:55:28 --> Model Class Initialized
INFO - 2020-11-11 16:55:28 --> Model Class Initialized
DEBUG - 2020-11-11 16:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:55:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-11 16:55:28 --> Final output sent to browser
DEBUG - 2020-11-11 16:55:28 --> Total execution time: 0.0207
ERROR - 2020-11-11 16:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:55:28 --> Config Class Initialized
INFO - 2020-11-11 16:55:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:55:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:55:28 --> Utf8 Class Initialized
INFO - 2020-11-11 16:55:28 --> URI Class Initialized
DEBUG - 2020-11-11 16:55:28 --> No URI present. Default controller set.
INFO - 2020-11-11 16:55:28 --> Router Class Initialized
INFO - 2020-11-11 16:55:28 --> Output Class Initialized
INFO - 2020-11-11 16:55:28 --> Security Class Initialized
DEBUG - 2020-11-11 16:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:55:28 --> Input Class Initialized
INFO - 2020-11-11 16:55:28 --> Language Class Initialized
INFO - 2020-11-11 16:55:28 --> Loader Class Initialized
INFO - 2020-11-11 16:55:28 --> Helper loaded: url_helper
INFO - 2020-11-11 16:55:28 --> Database Driver Class Initialized
INFO - 2020-11-11 16:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:55:28 --> Email Class Initialized
INFO - 2020-11-11 16:55:28 --> Controller Class Initialized
INFO - 2020-11-11 16:55:28 --> Model Class Initialized
INFO - 2020-11-11 16:55:28 --> Model Class Initialized
DEBUG - 2020-11-11 16:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:55:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-11 16:55:28 --> Final output sent to browser
DEBUG - 2020-11-11 16:55:28 --> Total execution time: 0.0174
ERROR - 2020-11-11 16:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:58:05 --> Config Class Initialized
INFO - 2020-11-11 16:58:05 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:58:05 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:58:05 --> Utf8 Class Initialized
INFO - 2020-11-11 16:58:05 --> URI Class Initialized
INFO - 2020-11-11 16:58:05 --> Router Class Initialized
INFO - 2020-11-11 16:58:05 --> Output Class Initialized
INFO - 2020-11-11 16:58:05 --> Security Class Initialized
DEBUG - 2020-11-11 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:58:05 --> Input Class Initialized
INFO - 2020-11-11 16:58:05 --> Language Class Initialized
INFO - 2020-11-11 16:58:05 --> Loader Class Initialized
INFO - 2020-11-11 16:58:05 --> Helper loaded: url_helper
INFO - 2020-11-11 16:58:05 --> Database Driver Class Initialized
INFO - 2020-11-11 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:58:05 --> Email Class Initialized
INFO - 2020-11-11 16:58:05 --> Controller Class Initialized
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
DEBUG - 2020-11-11 16:58:05 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-11 16:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:58:05 --> Config Class Initialized
INFO - 2020-11-11 16:58:05 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:58:05 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:58:05 --> Utf8 Class Initialized
INFO - 2020-11-11 16:58:05 --> URI Class Initialized
INFO - 2020-11-11 16:58:05 --> Router Class Initialized
INFO - 2020-11-11 16:58:05 --> Output Class Initialized
INFO - 2020-11-11 16:58:05 --> Security Class Initialized
DEBUG - 2020-11-11 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:58:05 --> Input Class Initialized
INFO - 2020-11-11 16:58:05 --> Language Class Initialized
INFO - 2020-11-11 16:58:05 --> Loader Class Initialized
INFO - 2020-11-11 16:58:05 --> Helper loaded: url_helper
INFO - 2020-11-11 16:58:05 --> Database Driver Class Initialized
INFO - 2020-11-11 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:58:05 --> Email Class Initialized
INFO - 2020-11-11 16:58:05 --> Controller Class Initialized
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
DEBUG - 2020-11-11 16:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:58:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
INFO - 2020-11-11 16:58:05 --> Final output sent to browser
DEBUG - 2020-11-11 16:58:05 --> Total execution time: 0.0243
ERROR - 2020-11-11 16:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:58:05 --> Config Class Initialized
INFO - 2020-11-11 16:58:05 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:58:05 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:58:05 --> Utf8 Class Initialized
INFO - 2020-11-11 16:58:05 --> URI Class Initialized
INFO - 2020-11-11 16:58:05 --> Router Class Initialized
INFO - 2020-11-11 16:58:05 --> Output Class Initialized
INFO - 2020-11-11 16:58:05 --> Security Class Initialized
DEBUG - 2020-11-11 16:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:58:05 --> Input Class Initialized
INFO - 2020-11-11 16:58:05 --> Language Class Initialized
INFO - 2020-11-11 16:58:05 --> Loader Class Initialized
INFO - 2020-11-11 16:58:05 --> Helper loaded: url_helper
INFO - 2020-11-11 16:58:05 --> Database Driver Class Initialized
INFO - 2020-11-11 16:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:58:05 --> Email Class Initialized
INFO - 2020-11-11 16:58:05 --> Controller Class Initialized
DEBUG - 2020-11-11 16:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:58:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
INFO - 2020-11-11 16:58:05 --> Model Class Initialized
INFO - 2020-11-11 16:58:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-11 16:58:05 --> Final output sent to browser
DEBUG - 2020-11-11 16:58:05 --> Total execution time: 0.0953
ERROR - 2020-11-11 16:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:58:15 --> Config Class Initialized
INFO - 2020-11-11 16:58:15 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:58:15 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:58:15 --> Utf8 Class Initialized
INFO - 2020-11-11 16:58:15 --> URI Class Initialized
INFO - 2020-11-11 16:58:15 --> Router Class Initialized
INFO - 2020-11-11 16:58:15 --> Output Class Initialized
INFO - 2020-11-11 16:58:15 --> Security Class Initialized
DEBUG - 2020-11-11 16:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:58:15 --> Input Class Initialized
INFO - 2020-11-11 16:58:15 --> Language Class Initialized
INFO - 2020-11-11 16:58:15 --> Loader Class Initialized
INFO - 2020-11-11 16:58:15 --> Helper loaded: url_helper
INFO - 2020-11-11 16:58:15 --> Database Driver Class Initialized
INFO - 2020-11-11 16:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:58:15 --> Email Class Initialized
INFO - 2020-11-11 16:58:15 --> Controller Class Initialized
DEBUG - 2020-11-11 16:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:58:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:58:15 --> Model Class Initialized
INFO - 2020-11-11 16:58:15 --> Model Class Initialized
INFO - 2020-11-11 16:58:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-11 16:58:15 --> Final output sent to browser
DEBUG - 2020-11-11 16:58:15 --> Total execution time: 0.0526
ERROR - 2020-11-11 16:58:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:58:22 --> Config Class Initialized
INFO - 2020-11-11 16:58:22 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:58:22 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:58:22 --> Utf8 Class Initialized
INFO - 2020-11-11 16:58:22 --> URI Class Initialized
INFO - 2020-11-11 16:58:22 --> Router Class Initialized
INFO - 2020-11-11 16:58:22 --> Output Class Initialized
INFO - 2020-11-11 16:58:22 --> Security Class Initialized
DEBUG - 2020-11-11 16:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:58:22 --> Input Class Initialized
INFO - 2020-11-11 16:58:22 --> Language Class Initialized
INFO - 2020-11-11 16:58:22 --> Loader Class Initialized
INFO - 2020-11-11 16:58:22 --> Helper loaded: url_helper
INFO - 2020-11-11 16:58:22 --> Database Driver Class Initialized
INFO - 2020-11-11 16:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:58:22 --> Email Class Initialized
INFO - 2020-11-11 16:58:22 --> Controller Class Initialized
DEBUG - 2020-11-11 16:58:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:58:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:58:22 --> Model Class Initialized
INFO - 2020-11-11 16:58:22 --> Model Class Initialized
INFO - 2020-11-11 16:58:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-11 16:58:22 --> Final output sent to browser
DEBUG - 2020-11-11 16:58:22 --> Total execution time: 0.0556
ERROR - 2020-11-11 16:58:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:58:30 --> Config Class Initialized
INFO - 2020-11-11 16:58:30 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:58:30 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:58:30 --> Utf8 Class Initialized
INFO - 2020-11-11 16:58:30 --> URI Class Initialized
INFO - 2020-11-11 16:58:30 --> Router Class Initialized
INFO - 2020-11-11 16:58:30 --> Output Class Initialized
INFO - 2020-11-11 16:58:30 --> Security Class Initialized
DEBUG - 2020-11-11 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:58:30 --> Input Class Initialized
INFO - 2020-11-11 16:58:30 --> Language Class Initialized
INFO - 2020-11-11 16:58:30 --> Loader Class Initialized
INFO - 2020-11-11 16:58:30 --> Helper loaded: url_helper
INFO - 2020-11-11 16:58:30 --> Database Driver Class Initialized
INFO - 2020-11-11 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:58:30 --> Email Class Initialized
INFO - 2020-11-11 16:58:30 --> Controller Class Initialized
DEBUG - 2020-11-11 16:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:58:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:58:30 --> Model Class Initialized
INFO - 2020-11-11 16:58:30 --> Model Class Initialized
INFO - 2020-11-11 16:58:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-11 16:58:30 --> Final output sent to browser
DEBUG - 2020-11-11 16:58:30 --> Total execution time: 0.0245
ERROR - 2020-11-11 16:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 16:59:42 --> Config Class Initialized
INFO - 2020-11-11 16:59:42 --> Hooks Class Initialized
DEBUG - 2020-11-11 16:59:42 --> UTF-8 Support Enabled
INFO - 2020-11-11 16:59:42 --> Utf8 Class Initialized
INFO - 2020-11-11 16:59:42 --> URI Class Initialized
INFO - 2020-11-11 16:59:42 --> Router Class Initialized
INFO - 2020-11-11 16:59:42 --> Output Class Initialized
INFO - 2020-11-11 16:59:42 --> Security Class Initialized
DEBUG - 2020-11-11 16:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 16:59:42 --> Input Class Initialized
INFO - 2020-11-11 16:59:42 --> Language Class Initialized
INFO - 2020-11-11 16:59:42 --> Loader Class Initialized
INFO - 2020-11-11 16:59:42 --> Helper loaded: url_helper
INFO - 2020-11-11 16:59:42 --> Database Driver Class Initialized
INFO - 2020-11-11 16:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 16:59:42 --> Email Class Initialized
INFO - 2020-11-11 16:59:42 --> Controller Class Initialized
DEBUG - 2020-11-11 16:59:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 16:59:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 16:59:42 --> Model Class Initialized
INFO - 2020-11-11 16:59:42 --> Model Class Initialized
INFO - 2020-11-11 16:59:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-11 16:59:42 --> Final output sent to browser
DEBUG - 2020-11-11 16:59:42 --> Total execution time: 0.0217
ERROR - 2020-11-11 17:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:02:41 --> Config Class Initialized
INFO - 2020-11-11 17:02:41 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:02:41 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:02:41 --> Utf8 Class Initialized
INFO - 2020-11-11 17:02:41 --> URI Class Initialized
INFO - 2020-11-11 17:02:41 --> Router Class Initialized
INFO - 2020-11-11 17:02:41 --> Output Class Initialized
INFO - 2020-11-11 17:02:41 --> Security Class Initialized
DEBUG - 2020-11-11 17:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:02:41 --> Input Class Initialized
INFO - 2020-11-11 17:02:41 --> Language Class Initialized
INFO - 2020-11-11 17:02:41 --> Loader Class Initialized
INFO - 2020-11-11 17:02:41 --> Helper loaded: url_helper
INFO - 2020-11-11 17:02:41 --> Database Driver Class Initialized
INFO - 2020-11-11 17:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:02:41 --> Email Class Initialized
INFO - 2020-11-11 17:02:41 --> Controller Class Initialized
DEBUG - 2020-11-11 17:02:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:02:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:02:41 --> Model Class Initialized
INFO - 2020-11-11 17:02:41 --> Model Class Initialized
INFO - 2020-11-11 17:02:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-11-11 17:02:41 --> Final output sent to browser
DEBUG - 2020-11-11 17:02:41 --> Total execution time: 0.0439
ERROR - 2020-11-11 17:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:02:43 --> Config Class Initialized
INFO - 2020-11-11 17:02:43 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:02:43 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:02:43 --> Utf8 Class Initialized
INFO - 2020-11-11 17:02:43 --> URI Class Initialized
INFO - 2020-11-11 17:02:43 --> Router Class Initialized
INFO - 2020-11-11 17:02:43 --> Output Class Initialized
INFO - 2020-11-11 17:02:43 --> Security Class Initialized
DEBUG - 2020-11-11 17:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:02:43 --> Input Class Initialized
INFO - 2020-11-11 17:02:43 --> Language Class Initialized
ERROR - 2020-11-11 17:02:43 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-11-11 17:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:02:54 --> Config Class Initialized
INFO - 2020-11-11 17:02:54 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:02:54 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:02:54 --> Utf8 Class Initialized
INFO - 2020-11-11 17:02:54 --> URI Class Initialized
INFO - 2020-11-11 17:02:54 --> Router Class Initialized
INFO - 2020-11-11 17:02:54 --> Output Class Initialized
INFO - 2020-11-11 17:02:54 --> Security Class Initialized
DEBUG - 2020-11-11 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:02:54 --> Input Class Initialized
INFO - 2020-11-11 17:02:54 --> Language Class Initialized
INFO - 2020-11-11 17:02:54 --> Loader Class Initialized
INFO - 2020-11-11 17:02:54 --> Helper loaded: url_helper
INFO - 2020-11-11 17:02:54 --> Database Driver Class Initialized
INFO - 2020-11-11 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:02:54 --> Email Class Initialized
INFO - 2020-11-11 17:02:54 --> Controller Class Initialized
DEBUG - 2020-11-11 17:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:02:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:02:54 --> Model Class Initialized
INFO - 2020-11-11 17:02:54 --> Model Class Initialized
INFO - 2020-11-11 17:02:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-11 17:02:54 --> Final output sent to browser
DEBUG - 2020-11-11 17:02:54 --> Total execution time: 0.0195
ERROR - 2020-11-11 17:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:03:26 --> Config Class Initialized
INFO - 2020-11-11 17:03:26 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:03:26 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:03:26 --> Utf8 Class Initialized
INFO - 2020-11-11 17:03:26 --> URI Class Initialized
INFO - 2020-11-11 17:03:26 --> Router Class Initialized
INFO - 2020-11-11 17:03:26 --> Output Class Initialized
INFO - 2020-11-11 17:03:26 --> Security Class Initialized
DEBUG - 2020-11-11 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:03:26 --> Input Class Initialized
INFO - 2020-11-11 17:03:26 --> Language Class Initialized
INFO - 2020-11-11 17:03:26 --> Loader Class Initialized
INFO - 2020-11-11 17:03:26 --> Helper loaded: url_helper
INFO - 2020-11-11 17:03:26 --> Database Driver Class Initialized
INFO - 2020-11-11 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:03:26 --> Email Class Initialized
INFO - 2020-11-11 17:03:26 --> Controller Class Initialized
DEBUG - 2020-11-11 17:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:03:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:03:26 --> Model Class Initialized
INFO - 2020-11-11 17:03:26 --> Model Class Initialized
INFO - 2020-11-11 17:03:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-11-11 17:03:26 --> Final output sent to browser
DEBUG - 2020-11-11 17:03:26 --> Total execution time: 0.0472
ERROR - 2020-11-11 17:03:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:03:28 --> Config Class Initialized
INFO - 2020-11-11 17:03:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:03:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:03:28 --> Utf8 Class Initialized
INFO - 2020-11-11 17:03:28 --> URI Class Initialized
INFO - 2020-11-11 17:03:28 --> Router Class Initialized
INFO - 2020-11-11 17:03:28 --> Output Class Initialized
INFO - 2020-11-11 17:03:28 --> Security Class Initialized
DEBUG - 2020-11-11 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:03:28 --> Input Class Initialized
INFO - 2020-11-11 17:03:28 --> Language Class Initialized
INFO - 2020-11-11 17:03:28 --> Loader Class Initialized
INFO - 2020-11-11 17:03:28 --> Helper loaded: url_helper
INFO - 2020-11-11 17:03:28 --> Database Driver Class Initialized
INFO - 2020-11-11 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:03:28 --> Email Class Initialized
INFO - 2020-11-11 17:03:28 --> Controller Class Initialized
DEBUG - 2020-11-11 17:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:03:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:03:28 --> Model Class Initialized
INFO - 2020-11-11 17:03:28 --> Model Class Initialized
INFO - 2020-11-11 17:03:28 --> Final output sent to browser
DEBUG - 2020-11-11 17:03:28 --> Total execution time: 0.0255
ERROR - 2020-11-11 17:03:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:03:53 --> Config Class Initialized
INFO - 2020-11-11 17:03:53 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:03:53 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:03:53 --> Utf8 Class Initialized
INFO - 2020-11-11 17:03:53 --> URI Class Initialized
INFO - 2020-11-11 17:03:53 --> Router Class Initialized
INFO - 2020-11-11 17:03:53 --> Output Class Initialized
INFO - 2020-11-11 17:03:53 --> Security Class Initialized
DEBUG - 2020-11-11 17:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:03:53 --> Input Class Initialized
INFO - 2020-11-11 17:03:53 --> Language Class Initialized
INFO - 2020-11-11 17:03:53 --> Loader Class Initialized
INFO - 2020-11-11 17:03:53 --> Helper loaded: url_helper
INFO - 2020-11-11 17:03:53 --> Database Driver Class Initialized
INFO - 2020-11-11 17:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:03:53 --> Email Class Initialized
INFO - 2020-11-11 17:03:53 --> Controller Class Initialized
DEBUG - 2020-11-11 17:03:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:03:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:03:53 --> Model Class Initialized
INFO - 2020-11-11 17:03:53 --> Model Class Initialized
INFO - 2020-11-11 17:03:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-11 17:03:53 --> Final output sent to browser
DEBUG - 2020-11-11 17:03:53 --> Total execution time: 0.0206
ERROR - 2020-11-11 17:04:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:04:10 --> Config Class Initialized
INFO - 2020-11-11 17:04:10 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:04:10 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:04:10 --> Utf8 Class Initialized
INFO - 2020-11-11 17:04:10 --> URI Class Initialized
INFO - 2020-11-11 17:04:10 --> Router Class Initialized
INFO - 2020-11-11 17:04:10 --> Output Class Initialized
INFO - 2020-11-11 17:04:10 --> Security Class Initialized
DEBUG - 2020-11-11 17:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:04:10 --> Input Class Initialized
INFO - 2020-11-11 17:04:10 --> Language Class Initialized
INFO - 2020-11-11 17:04:10 --> Loader Class Initialized
INFO - 2020-11-11 17:04:10 --> Helper loaded: url_helper
INFO - 2020-11-11 17:04:10 --> Database Driver Class Initialized
INFO - 2020-11-11 17:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:04:10 --> Email Class Initialized
INFO - 2020-11-11 17:04:10 --> Controller Class Initialized
DEBUG - 2020-11-11 17:04:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:04:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:04:10 --> Model Class Initialized
INFO - 2020-11-11 17:04:10 --> Model Class Initialized
INFO - 2020-11-11 17:04:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-11-11 17:04:10 --> Final output sent to browser
DEBUG - 2020-11-11 17:04:10 --> Total execution time: 0.0250
ERROR - 2020-11-11 17:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:04:11 --> Config Class Initialized
INFO - 2020-11-11 17:04:11 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:04:11 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:04:11 --> Utf8 Class Initialized
INFO - 2020-11-11 17:04:11 --> URI Class Initialized
INFO - 2020-11-11 17:04:11 --> Router Class Initialized
INFO - 2020-11-11 17:04:11 --> Output Class Initialized
INFO - 2020-11-11 17:04:11 --> Security Class Initialized
DEBUG - 2020-11-11 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:04:11 --> Input Class Initialized
INFO - 2020-11-11 17:04:11 --> Language Class Initialized
INFO - 2020-11-11 17:04:11 --> Loader Class Initialized
INFO - 2020-11-11 17:04:11 --> Helper loaded: url_helper
INFO - 2020-11-11 17:04:11 --> Database Driver Class Initialized
INFO - 2020-11-11 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:04:11 --> Email Class Initialized
INFO - 2020-11-11 17:04:11 --> Controller Class Initialized
DEBUG - 2020-11-11 17:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:04:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:04:11 --> Model Class Initialized
INFO - 2020-11-11 17:04:11 --> Model Class Initialized
INFO - 2020-11-11 17:04:11 --> Final output sent to browser
DEBUG - 2020-11-11 17:04:11 --> Total execution time: 0.0253
ERROR - 2020-11-11 17:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:04:16 --> Config Class Initialized
INFO - 2020-11-11 17:04:16 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:04:16 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:04:16 --> Utf8 Class Initialized
INFO - 2020-11-11 17:04:16 --> URI Class Initialized
INFO - 2020-11-11 17:04:16 --> Router Class Initialized
INFO - 2020-11-11 17:04:16 --> Output Class Initialized
INFO - 2020-11-11 17:04:16 --> Security Class Initialized
DEBUG - 2020-11-11 17:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:04:16 --> Input Class Initialized
INFO - 2020-11-11 17:04:16 --> Language Class Initialized
INFO - 2020-11-11 17:04:16 --> Loader Class Initialized
INFO - 2020-11-11 17:04:16 --> Helper loaded: url_helper
INFO - 2020-11-11 17:04:16 --> Database Driver Class Initialized
INFO - 2020-11-11 17:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:04:16 --> Email Class Initialized
INFO - 2020-11-11 17:04:16 --> Controller Class Initialized
DEBUG - 2020-11-11 17:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:04:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:04:16 --> Model Class Initialized
INFO - 2020-11-11 17:04:16 --> Model Class Initialized
INFO - 2020-11-11 17:04:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-11 17:04:16 --> Final output sent to browser
DEBUG - 2020-11-11 17:04:16 --> Total execution time: 0.0261
ERROR - 2020-11-11 17:04:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:04:20 --> Config Class Initialized
INFO - 2020-11-11 17:04:20 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:04:20 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:04:20 --> Utf8 Class Initialized
INFO - 2020-11-11 17:04:20 --> URI Class Initialized
INFO - 2020-11-11 17:04:20 --> Router Class Initialized
INFO - 2020-11-11 17:04:20 --> Output Class Initialized
INFO - 2020-11-11 17:04:20 --> Security Class Initialized
DEBUG - 2020-11-11 17:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:04:20 --> Input Class Initialized
INFO - 2020-11-11 17:04:20 --> Language Class Initialized
INFO - 2020-11-11 17:04:20 --> Loader Class Initialized
INFO - 2020-11-11 17:04:20 --> Helper loaded: url_helper
INFO - 2020-11-11 17:04:20 --> Database Driver Class Initialized
INFO - 2020-11-11 17:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:04:20 --> Email Class Initialized
INFO - 2020-11-11 17:04:20 --> Controller Class Initialized
DEBUG - 2020-11-11 17:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-11 17:04:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:04:20 --> Model Class Initialized
INFO - 2020-11-11 17:04:20 --> Model Class Initialized
INFO - 2020-11-11 17:04:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-11 17:04:20 --> Final output sent to browser
DEBUG - 2020-11-11 17:04:20 --> Total execution time: 0.0293
ERROR - 2020-11-11 17:05:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-11 17:05:23 --> Config Class Initialized
INFO - 2020-11-11 17:05:23 --> Hooks Class Initialized
DEBUG - 2020-11-11 17:05:23 --> UTF-8 Support Enabled
INFO - 2020-11-11 17:05:23 --> Utf8 Class Initialized
INFO - 2020-11-11 17:05:23 --> URI Class Initialized
DEBUG - 2020-11-11 17:05:23 --> No URI present. Default controller set.
INFO - 2020-11-11 17:05:23 --> Router Class Initialized
INFO - 2020-11-11 17:05:23 --> Output Class Initialized
INFO - 2020-11-11 17:05:23 --> Security Class Initialized
DEBUG - 2020-11-11 17:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 17:05:23 --> Input Class Initialized
INFO - 2020-11-11 17:05:23 --> Language Class Initialized
INFO - 2020-11-11 17:05:23 --> Loader Class Initialized
INFO - 2020-11-11 17:05:23 --> Helper loaded: url_helper
INFO - 2020-11-11 17:05:23 --> Database Driver Class Initialized
INFO - 2020-11-11 17:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 17:05:23 --> Email Class Initialized
INFO - 2020-11-11 17:05:23 --> Controller Class Initialized
INFO - 2020-11-11 17:05:23 --> Model Class Initialized
INFO - 2020-11-11 17:05:23 --> Model Class Initialized
DEBUG - 2020-11-11 17:05:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-11 17:05:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-11 17:05:23 --> Final output sent to browser
DEBUG - 2020-11-11 17:05:23 --> Total execution time: 0.0183
