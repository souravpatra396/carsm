<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-31 00:30:14 --> Config Class Initialized
INFO - 2020-07-31 00:30:14 --> Hooks Class Initialized
DEBUG - 2020-07-31 00:30:14 --> UTF-8 Support Enabled
INFO - 2020-07-31 00:30:14 --> Utf8 Class Initialized
INFO - 2020-07-31 00:30:14 --> URI Class Initialized
INFO - 2020-07-31 00:30:14 --> Router Class Initialized
INFO - 2020-07-31 00:30:14 --> Output Class Initialized
INFO - 2020-07-31 00:30:14 --> Security Class Initialized
DEBUG - 2020-07-31 00:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 00:30:14 --> Input Class Initialized
INFO - 2020-07-31 00:30:14 --> Language Class Initialized
INFO - 2020-07-31 00:30:14 --> Loader Class Initialized
INFO - 2020-07-31 00:30:14 --> Helper loaded: url_helper
INFO - 2020-07-31 00:30:14 --> Database Driver Class Initialized
INFO - 2020-07-31 00:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 00:30:14 --> Email Class Initialized
INFO - 2020-07-31 00:30:14 --> Controller Class Initialized
INFO - 2020-07-31 00:30:14 --> Model Class Initialized
INFO - 2020-07-31 00:30:14 --> Model Class Initialized
DEBUG - 2020-07-31 00:30:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 00:30:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 00:30:14 --> Config Class Initialized
INFO - 2020-07-31 00:30:14 --> Hooks Class Initialized
DEBUG - 2020-07-31 00:30:14 --> UTF-8 Support Enabled
INFO - 2020-07-31 00:30:14 --> Utf8 Class Initialized
INFO - 2020-07-31 00:30:14 --> URI Class Initialized
DEBUG - 2020-07-31 00:30:14 --> No URI present. Default controller set.
INFO - 2020-07-31 00:30:14 --> Router Class Initialized
INFO - 2020-07-31 00:30:14 --> Output Class Initialized
INFO - 2020-07-31 00:30:14 --> Security Class Initialized
DEBUG - 2020-07-31 00:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 00:30:14 --> Input Class Initialized
INFO - 2020-07-31 00:30:14 --> Language Class Initialized
INFO - 2020-07-31 00:30:14 --> Loader Class Initialized
INFO - 2020-07-31 00:30:14 --> Helper loaded: url_helper
INFO - 2020-07-31 00:30:14 --> Database Driver Class Initialized
INFO - 2020-07-31 00:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 00:30:14 --> Email Class Initialized
INFO - 2020-07-31 00:30:14 --> Controller Class Initialized
INFO - 2020-07-31 00:30:14 --> Model Class Initialized
INFO - 2020-07-31 00:30:14 --> Model Class Initialized
DEBUG - 2020-07-31 00:30:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 00:30:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 00:30:14 --> Final output sent to browser
DEBUG - 2020-07-31 00:30:14 --> Total execution time: 0.0194
INFO - 2020-07-31 05:44:40 --> Config Class Initialized
INFO - 2020-07-31 05:44:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:44:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:44:40 --> Utf8 Class Initialized
INFO - 2020-07-31 05:44:40 --> URI Class Initialized
DEBUG - 2020-07-31 05:44:40 --> No URI present. Default controller set.
INFO - 2020-07-31 05:44:40 --> Router Class Initialized
INFO - 2020-07-31 05:44:40 --> Output Class Initialized
INFO - 2020-07-31 05:44:40 --> Security Class Initialized
DEBUG - 2020-07-31 05:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:44:40 --> Input Class Initialized
INFO - 2020-07-31 05:44:40 --> Language Class Initialized
INFO - 2020-07-31 05:44:40 --> Loader Class Initialized
INFO - 2020-07-31 05:44:40 --> Helper loaded: url_helper
INFO - 2020-07-31 05:44:40 --> Database Driver Class Initialized
INFO - 2020-07-31 05:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:44:40 --> Email Class Initialized
INFO - 2020-07-31 05:44:40 --> Controller Class Initialized
INFO - 2020-07-31 05:44:40 --> Model Class Initialized
INFO - 2020-07-31 05:44:40 --> Model Class Initialized
DEBUG - 2020-07-31 05:44:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:44:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 05:44:40 --> Final output sent to browser
DEBUG - 2020-07-31 05:44:40 --> Total execution time: 0.0246
INFO - 2020-07-31 05:57:59 --> Config Class Initialized
INFO - 2020-07-31 05:57:59 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:57:59 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:57:59 --> Utf8 Class Initialized
INFO - 2020-07-31 05:57:59 --> URI Class Initialized
INFO - 2020-07-31 05:57:59 --> Router Class Initialized
INFO - 2020-07-31 05:57:59 --> Output Class Initialized
INFO - 2020-07-31 05:57:59 --> Security Class Initialized
DEBUG - 2020-07-31 05:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:57:59 --> Input Class Initialized
INFO - 2020-07-31 05:57:59 --> Language Class Initialized
INFO - 2020-07-31 05:57:59 --> Loader Class Initialized
INFO - 2020-07-31 05:57:59 --> Helper loaded: url_helper
INFO - 2020-07-31 05:57:59 --> Database Driver Class Initialized
INFO - 2020-07-31 05:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:57:59 --> Email Class Initialized
INFO - 2020-07-31 05:57:59 --> Controller Class Initialized
INFO - 2020-07-31 05:57:59 --> Model Class Initialized
INFO - 2020-07-31 05:57:59 --> Model Class Initialized
DEBUG - 2020-07-31 05:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:58:00 --> Config Class Initialized
INFO - 2020-07-31 05:58:00 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:58:00 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:58:00 --> Utf8 Class Initialized
INFO - 2020-07-31 05:58:00 --> URI Class Initialized
DEBUG - 2020-07-31 05:58:00 --> No URI present. Default controller set.
INFO - 2020-07-31 05:58:00 --> Router Class Initialized
INFO - 2020-07-31 05:58:00 --> Output Class Initialized
INFO - 2020-07-31 05:58:00 --> Security Class Initialized
DEBUG - 2020-07-31 05:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:58:00 --> Input Class Initialized
INFO - 2020-07-31 05:58:00 --> Language Class Initialized
INFO - 2020-07-31 05:58:00 --> Loader Class Initialized
INFO - 2020-07-31 05:58:00 --> Helper loaded: url_helper
INFO - 2020-07-31 05:58:00 --> Database Driver Class Initialized
INFO - 2020-07-31 05:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:58:00 --> Email Class Initialized
INFO - 2020-07-31 05:58:00 --> Controller Class Initialized
INFO - 2020-07-31 05:58:00 --> Model Class Initialized
INFO - 2020-07-31 05:58:00 --> Model Class Initialized
DEBUG - 2020-07-31 05:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:58:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 05:58:00 --> Final output sent to browser
DEBUG - 2020-07-31 05:58:00 --> Total execution time: 0.0219
INFO - 2020-07-31 05:59:34 --> Config Class Initialized
INFO - 2020-07-31 05:59:34 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:59:34 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:59:34 --> Utf8 Class Initialized
INFO - 2020-07-31 05:59:34 --> URI Class Initialized
INFO - 2020-07-31 05:59:34 --> Router Class Initialized
INFO - 2020-07-31 05:59:34 --> Output Class Initialized
INFO - 2020-07-31 05:59:34 --> Security Class Initialized
DEBUG - 2020-07-31 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:59:34 --> Input Class Initialized
INFO - 2020-07-31 05:59:34 --> Language Class Initialized
INFO - 2020-07-31 05:59:34 --> Loader Class Initialized
INFO - 2020-07-31 05:59:34 --> Helper loaded: url_helper
INFO - 2020-07-31 05:59:34 --> Database Driver Class Initialized
INFO - 2020-07-31 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:59:34 --> Email Class Initialized
INFO - 2020-07-31 05:59:34 --> Controller Class Initialized
INFO - 2020-07-31 05:59:34 --> Model Class Initialized
INFO - 2020-07-31 05:59:34 --> Model Class Initialized
DEBUG - 2020-07-31 05:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:59:34 --> Config Class Initialized
INFO - 2020-07-31 05:59:34 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:59:34 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:59:34 --> Utf8 Class Initialized
INFO - 2020-07-31 05:59:34 --> URI Class Initialized
DEBUG - 2020-07-31 05:59:34 --> No URI present. Default controller set.
INFO - 2020-07-31 05:59:34 --> Router Class Initialized
INFO - 2020-07-31 05:59:34 --> Output Class Initialized
INFO - 2020-07-31 05:59:34 --> Security Class Initialized
DEBUG - 2020-07-31 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:59:34 --> Input Class Initialized
INFO - 2020-07-31 05:59:34 --> Language Class Initialized
INFO - 2020-07-31 05:59:34 --> Loader Class Initialized
INFO - 2020-07-31 05:59:34 --> Helper loaded: url_helper
INFO - 2020-07-31 05:59:34 --> Database Driver Class Initialized
INFO - 2020-07-31 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:59:34 --> Email Class Initialized
INFO - 2020-07-31 05:59:34 --> Controller Class Initialized
INFO - 2020-07-31 05:59:34 --> Model Class Initialized
INFO - 2020-07-31 05:59:34 --> Model Class Initialized
DEBUG - 2020-07-31 05:59:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:59:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 05:59:34 --> Final output sent to browser
DEBUG - 2020-07-31 05:59:34 --> Total execution time: 0.0245
INFO - 2020-07-31 05:59:43 --> Config Class Initialized
INFO - 2020-07-31 05:59:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:59:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:59:43 --> Utf8 Class Initialized
INFO - 2020-07-31 05:59:43 --> URI Class Initialized
INFO - 2020-07-31 05:59:43 --> Router Class Initialized
INFO - 2020-07-31 05:59:43 --> Output Class Initialized
INFO - 2020-07-31 05:59:43 --> Security Class Initialized
DEBUG - 2020-07-31 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:59:43 --> Input Class Initialized
INFO - 2020-07-31 05:59:43 --> Language Class Initialized
INFO - 2020-07-31 05:59:43 --> Loader Class Initialized
INFO - 2020-07-31 05:59:43 --> Helper loaded: url_helper
INFO - 2020-07-31 05:59:43 --> Database Driver Class Initialized
INFO - 2020-07-31 05:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:59:43 --> Email Class Initialized
INFO - 2020-07-31 05:59:43 --> Controller Class Initialized
INFO - 2020-07-31 05:59:43 --> Model Class Initialized
INFO - 2020-07-31 05:59:43 --> Model Class Initialized
DEBUG - 2020-07-31 05:59:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:59:44 --> Config Class Initialized
INFO - 2020-07-31 05:59:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 05:59:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 05:59:44 --> Utf8 Class Initialized
INFO - 2020-07-31 05:59:44 --> URI Class Initialized
DEBUG - 2020-07-31 05:59:44 --> No URI present. Default controller set.
INFO - 2020-07-31 05:59:44 --> Router Class Initialized
INFO - 2020-07-31 05:59:44 --> Output Class Initialized
INFO - 2020-07-31 05:59:44 --> Security Class Initialized
DEBUG - 2020-07-31 05:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 05:59:44 --> Input Class Initialized
INFO - 2020-07-31 05:59:44 --> Language Class Initialized
INFO - 2020-07-31 05:59:44 --> Loader Class Initialized
INFO - 2020-07-31 05:59:44 --> Helper loaded: url_helper
INFO - 2020-07-31 05:59:44 --> Database Driver Class Initialized
INFO - 2020-07-31 05:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 05:59:44 --> Email Class Initialized
INFO - 2020-07-31 05:59:44 --> Controller Class Initialized
INFO - 2020-07-31 05:59:44 --> Model Class Initialized
INFO - 2020-07-31 05:59:44 --> Model Class Initialized
DEBUG - 2020-07-31 05:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 05:59:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 05:59:44 --> Final output sent to browser
DEBUG - 2020-07-31 05:59:44 --> Total execution time: 0.0224
INFO - 2020-07-31 06:00:52 --> Config Class Initialized
INFO - 2020-07-31 06:00:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:00:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:00:52 --> Utf8 Class Initialized
INFO - 2020-07-31 06:00:52 --> URI Class Initialized
INFO - 2020-07-31 06:00:52 --> Router Class Initialized
INFO - 2020-07-31 06:00:52 --> Output Class Initialized
INFO - 2020-07-31 06:00:52 --> Security Class Initialized
DEBUG - 2020-07-31 06:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:00:52 --> Input Class Initialized
INFO - 2020-07-31 06:00:52 --> Language Class Initialized
INFO - 2020-07-31 06:00:52 --> Loader Class Initialized
INFO - 2020-07-31 06:00:52 --> Helper loaded: url_helper
INFO - 2020-07-31 06:00:52 --> Database Driver Class Initialized
INFO - 2020-07-31 06:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:00:52 --> Email Class Initialized
INFO - 2020-07-31 06:00:52 --> Controller Class Initialized
INFO - 2020-07-31 06:00:52 --> Model Class Initialized
INFO - 2020-07-31 06:00:52 --> Model Class Initialized
DEBUG - 2020-07-31 06:00:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:00:53 --> Config Class Initialized
INFO - 2020-07-31 06:00:53 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:00:53 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:00:53 --> Utf8 Class Initialized
INFO - 2020-07-31 06:00:53 --> URI Class Initialized
DEBUG - 2020-07-31 06:00:53 --> No URI present. Default controller set.
INFO - 2020-07-31 06:00:53 --> Router Class Initialized
INFO - 2020-07-31 06:00:53 --> Output Class Initialized
INFO - 2020-07-31 06:00:53 --> Security Class Initialized
DEBUG - 2020-07-31 06:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:00:53 --> Input Class Initialized
INFO - 2020-07-31 06:00:53 --> Language Class Initialized
INFO - 2020-07-31 06:00:53 --> Loader Class Initialized
INFO - 2020-07-31 06:00:53 --> Helper loaded: url_helper
INFO - 2020-07-31 06:00:53 --> Database Driver Class Initialized
INFO - 2020-07-31 06:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:00:53 --> Email Class Initialized
INFO - 2020-07-31 06:00:53 --> Controller Class Initialized
INFO - 2020-07-31 06:00:53 --> Model Class Initialized
INFO - 2020-07-31 06:00:53 --> Model Class Initialized
DEBUG - 2020-07-31 06:00:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:00:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:00:53 --> Final output sent to browser
DEBUG - 2020-07-31 06:00:53 --> Total execution time: 0.0217
INFO - 2020-07-31 06:01:45 --> Config Class Initialized
INFO - 2020-07-31 06:01:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:01:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:01:45 --> Utf8 Class Initialized
INFO - 2020-07-31 06:01:45 --> URI Class Initialized
INFO - 2020-07-31 06:01:45 --> Router Class Initialized
INFO - 2020-07-31 06:01:45 --> Output Class Initialized
INFO - 2020-07-31 06:01:45 --> Security Class Initialized
DEBUG - 2020-07-31 06:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:01:45 --> Input Class Initialized
INFO - 2020-07-31 06:01:45 --> Language Class Initialized
INFO - 2020-07-31 06:01:45 --> Loader Class Initialized
INFO - 2020-07-31 06:01:45 --> Helper loaded: url_helper
INFO - 2020-07-31 06:01:45 --> Database Driver Class Initialized
INFO - 2020-07-31 06:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:01:45 --> Email Class Initialized
INFO - 2020-07-31 06:01:45 --> Controller Class Initialized
INFO - 2020-07-31 06:01:45 --> Model Class Initialized
INFO - 2020-07-31 06:01:45 --> Model Class Initialized
DEBUG - 2020-07-31 06:01:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:01:45 --> Config Class Initialized
INFO - 2020-07-31 06:01:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:01:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:01:45 --> Utf8 Class Initialized
INFO - 2020-07-31 06:01:45 --> URI Class Initialized
INFO - 2020-07-31 06:01:45 --> Router Class Initialized
INFO - 2020-07-31 06:01:45 --> Output Class Initialized
INFO - 2020-07-31 06:01:45 --> Security Class Initialized
DEBUG - 2020-07-31 06:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:01:45 --> Input Class Initialized
INFO - 2020-07-31 06:01:45 --> Language Class Initialized
INFO - 2020-07-31 06:01:45 --> Loader Class Initialized
INFO - 2020-07-31 06:01:45 --> Helper loaded: url_helper
INFO - 2020-07-31 06:01:45 --> Database Driver Class Initialized
INFO - 2020-07-31 06:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:01:45 --> Email Class Initialized
INFO - 2020-07-31 06:01:45 --> Controller Class Initialized
DEBUG - 2020-07-31 06:01:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:01:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:01:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:01:45 --> Final output sent to browser
DEBUG - 2020-07-31 06:01:45 --> Total execution time: 0.0233
INFO - 2020-07-31 06:03:02 --> Config Class Initialized
INFO - 2020-07-31 06:03:02 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:03:02 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:03:02 --> Utf8 Class Initialized
INFO - 2020-07-31 06:03:02 --> URI Class Initialized
DEBUG - 2020-07-31 06:03:02 --> No URI present. Default controller set.
INFO - 2020-07-31 06:03:02 --> Router Class Initialized
INFO - 2020-07-31 06:03:02 --> Output Class Initialized
INFO - 2020-07-31 06:03:02 --> Security Class Initialized
DEBUG - 2020-07-31 06:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:03:02 --> Input Class Initialized
INFO - 2020-07-31 06:03:02 --> Language Class Initialized
INFO - 2020-07-31 06:03:02 --> Loader Class Initialized
INFO - 2020-07-31 06:03:02 --> Helper loaded: url_helper
INFO - 2020-07-31 06:03:02 --> Database Driver Class Initialized
INFO - 2020-07-31 06:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:03:02 --> Email Class Initialized
INFO - 2020-07-31 06:03:02 --> Controller Class Initialized
INFO - 2020-07-31 06:03:02 --> Model Class Initialized
INFO - 2020-07-31 06:03:02 --> Model Class Initialized
DEBUG - 2020-07-31 06:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:03:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:03:02 --> Final output sent to browser
DEBUG - 2020-07-31 06:03:02 --> Total execution time: 0.0341
INFO - 2020-07-31 06:03:08 --> Config Class Initialized
INFO - 2020-07-31 06:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:03:08 --> Utf8 Class Initialized
INFO - 2020-07-31 06:03:08 --> URI Class Initialized
INFO - 2020-07-31 06:03:08 --> Router Class Initialized
INFO - 2020-07-31 06:03:08 --> Output Class Initialized
INFO - 2020-07-31 06:03:08 --> Security Class Initialized
DEBUG - 2020-07-31 06:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:03:08 --> Input Class Initialized
INFO - 2020-07-31 06:03:08 --> Language Class Initialized
INFO - 2020-07-31 06:03:08 --> Loader Class Initialized
INFO - 2020-07-31 06:03:08 --> Helper loaded: url_helper
INFO - 2020-07-31 06:03:08 --> Database Driver Class Initialized
INFO - 2020-07-31 06:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:03:08 --> Email Class Initialized
INFO - 2020-07-31 06:03:08 --> Controller Class Initialized
INFO - 2020-07-31 06:03:08 --> Model Class Initialized
INFO - 2020-07-31 06:03:08 --> Model Class Initialized
DEBUG - 2020-07-31 06:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:03:08 --> Config Class Initialized
INFO - 2020-07-31 06:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:03:08 --> Utf8 Class Initialized
INFO - 2020-07-31 06:03:08 --> URI Class Initialized
DEBUG - 2020-07-31 06:03:08 --> No URI present. Default controller set.
INFO - 2020-07-31 06:03:08 --> Router Class Initialized
INFO - 2020-07-31 06:03:08 --> Output Class Initialized
INFO - 2020-07-31 06:03:08 --> Security Class Initialized
DEBUG - 2020-07-31 06:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:03:08 --> Input Class Initialized
INFO - 2020-07-31 06:03:08 --> Language Class Initialized
INFO - 2020-07-31 06:03:08 --> Loader Class Initialized
INFO - 2020-07-31 06:03:08 --> Helper loaded: url_helper
INFO - 2020-07-31 06:03:08 --> Database Driver Class Initialized
INFO - 2020-07-31 06:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:03:08 --> Email Class Initialized
INFO - 2020-07-31 06:03:08 --> Controller Class Initialized
INFO - 2020-07-31 06:03:08 --> Model Class Initialized
INFO - 2020-07-31 06:03:08 --> Model Class Initialized
DEBUG - 2020-07-31 06:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:03:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:03:08 --> Final output sent to browser
DEBUG - 2020-07-31 06:03:08 --> Total execution time: 0.0226
INFO - 2020-07-31 06:16:37 --> Config Class Initialized
INFO - 2020-07-31 06:16:37 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:16:37 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:16:37 --> Utf8 Class Initialized
INFO - 2020-07-31 06:16:37 --> URI Class Initialized
DEBUG - 2020-07-31 06:16:37 --> No URI present. Default controller set.
INFO - 2020-07-31 06:16:37 --> Router Class Initialized
INFO - 2020-07-31 06:16:37 --> Output Class Initialized
INFO - 2020-07-31 06:16:37 --> Security Class Initialized
DEBUG - 2020-07-31 06:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:16:37 --> Input Class Initialized
INFO - 2020-07-31 06:16:37 --> Language Class Initialized
INFO - 2020-07-31 06:16:37 --> Loader Class Initialized
INFO - 2020-07-31 06:16:37 --> Helper loaded: url_helper
INFO - 2020-07-31 06:16:37 --> Database Driver Class Initialized
INFO - 2020-07-31 06:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:16:37 --> Email Class Initialized
INFO - 2020-07-31 06:16:37 --> Controller Class Initialized
INFO - 2020-07-31 06:16:37 --> Model Class Initialized
INFO - 2020-07-31 06:16:37 --> Model Class Initialized
DEBUG - 2020-07-31 06:16:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:16:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:16:37 --> Final output sent to browser
DEBUG - 2020-07-31 06:16:37 --> Total execution time: 0.1439
INFO - 2020-07-31 06:16:46 --> Config Class Initialized
INFO - 2020-07-31 06:16:46 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:16:46 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:16:46 --> Utf8 Class Initialized
INFO - 2020-07-31 06:16:46 --> URI Class Initialized
INFO - 2020-07-31 06:16:46 --> Router Class Initialized
INFO - 2020-07-31 06:16:46 --> Output Class Initialized
INFO - 2020-07-31 06:16:46 --> Security Class Initialized
DEBUG - 2020-07-31 06:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:16:46 --> Input Class Initialized
INFO - 2020-07-31 06:16:46 --> Language Class Initialized
INFO - 2020-07-31 06:16:46 --> Loader Class Initialized
INFO - 2020-07-31 06:16:46 --> Helper loaded: url_helper
INFO - 2020-07-31 06:16:46 --> Database Driver Class Initialized
INFO - 2020-07-31 06:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:16:46 --> Email Class Initialized
INFO - 2020-07-31 06:16:46 --> Controller Class Initialized
INFO - 2020-07-31 06:16:46 --> Model Class Initialized
INFO - 2020-07-31 06:16:46 --> Model Class Initialized
DEBUG - 2020-07-31 06:16:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:16:47 --> Config Class Initialized
INFO - 2020-07-31 06:16:47 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:16:47 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:16:47 --> Utf8 Class Initialized
INFO - 2020-07-31 06:16:47 --> URI Class Initialized
DEBUG - 2020-07-31 06:16:47 --> No URI present. Default controller set.
INFO - 2020-07-31 06:16:47 --> Router Class Initialized
INFO - 2020-07-31 06:16:47 --> Output Class Initialized
INFO - 2020-07-31 06:16:47 --> Security Class Initialized
DEBUG - 2020-07-31 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:16:47 --> Input Class Initialized
INFO - 2020-07-31 06:16:47 --> Language Class Initialized
INFO - 2020-07-31 06:16:47 --> Loader Class Initialized
INFO - 2020-07-31 06:16:47 --> Helper loaded: url_helper
INFO - 2020-07-31 06:16:47 --> Database Driver Class Initialized
INFO - 2020-07-31 06:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:16:47 --> Email Class Initialized
INFO - 2020-07-31 06:16:47 --> Controller Class Initialized
INFO - 2020-07-31 06:16:47 --> Model Class Initialized
INFO - 2020-07-31 06:16:47 --> Model Class Initialized
DEBUG - 2020-07-31 06:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:16:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:16:47 --> Final output sent to browser
DEBUG - 2020-07-31 06:16:47 --> Total execution time: 0.0232
INFO - 2020-07-31 06:21:34 --> Config Class Initialized
INFO - 2020-07-31 06:21:34 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:21:34 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:21:34 --> Utf8 Class Initialized
INFO - 2020-07-31 06:21:34 --> URI Class Initialized
INFO - 2020-07-31 06:21:34 --> Router Class Initialized
INFO - 2020-07-31 06:21:34 --> Output Class Initialized
INFO - 2020-07-31 06:21:34 --> Security Class Initialized
DEBUG - 2020-07-31 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:21:34 --> Input Class Initialized
INFO - 2020-07-31 06:21:34 --> Language Class Initialized
INFO - 2020-07-31 06:21:34 --> Loader Class Initialized
INFO - 2020-07-31 06:21:34 --> Helper loaded: url_helper
INFO - 2020-07-31 06:21:34 --> Database Driver Class Initialized
INFO - 2020-07-31 06:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:21:34 --> Email Class Initialized
INFO - 2020-07-31 06:21:34 --> Controller Class Initialized
INFO - 2020-07-31 06:21:34 --> Model Class Initialized
INFO - 2020-07-31 06:21:34 --> Model Class Initialized
DEBUG - 2020-07-31 06:21:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:21:34 --> Config Class Initialized
INFO - 2020-07-31 06:21:34 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:21:34 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:21:34 --> Utf8 Class Initialized
INFO - 2020-07-31 06:21:34 --> URI Class Initialized
INFO - 2020-07-31 06:21:34 --> Router Class Initialized
INFO - 2020-07-31 06:21:34 --> Output Class Initialized
INFO - 2020-07-31 06:21:34 --> Security Class Initialized
DEBUG - 2020-07-31 06:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:21:34 --> Input Class Initialized
INFO - 2020-07-31 06:21:34 --> Language Class Initialized
INFO - 2020-07-31 06:21:34 --> Loader Class Initialized
INFO - 2020-07-31 06:21:34 --> Helper loaded: url_helper
INFO - 2020-07-31 06:21:34 --> Database Driver Class Initialized
INFO - 2020-07-31 06:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:21:34 --> Email Class Initialized
INFO - 2020-07-31 06:21:34 --> Controller Class Initialized
DEBUG - 2020-07-31 06:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:21:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:21:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:21:34 --> Final output sent to browser
DEBUG - 2020-07-31 06:21:34 --> Total execution time: 0.0239
INFO - 2020-07-31 06:21:41 --> Config Class Initialized
INFO - 2020-07-31 06:21:41 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:21:41 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:21:41 --> Utf8 Class Initialized
INFO - 2020-07-31 06:21:41 --> URI Class Initialized
DEBUG - 2020-07-31 06:21:41 --> No URI present. Default controller set.
INFO - 2020-07-31 06:21:41 --> Router Class Initialized
INFO - 2020-07-31 06:21:41 --> Output Class Initialized
INFO - 2020-07-31 06:21:41 --> Security Class Initialized
DEBUG - 2020-07-31 06:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:21:41 --> Input Class Initialized
INFO - 2020-07-31 06:21:41 --> Language Class Initialized
INFO - 2020-07-31 06:21:41 --> Loader Class Initialized
INFO - 2020-07-31 06:21:41 --> Helper loaded: url_helper
INFO - 2020-07-31 06:21:41 --> Database Driver Class Initialized
INFO - 2020-07-31 06:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:21:41 --> Email Class Initialized
INFO - 2020-07-31 06:21:41 --> Controller Class Initialized
INFO - 2020-07-31 06:21:41 --> Model Class Initialized
INFO - 2020-07-31 06:21:41 --> Model Class Initialized
DEBUG - 2020-07-31 06:21:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:21:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:21:41 --> Final output sent to browser
DEBUG - 2020-07-31 06:21:41 --> Total execution time: 0.0201
INFO - 2020-07-31 06:24:03 --> Config Class Initialized
INFO - 2020-07-31 06:24:03 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:24:03 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:24:03 --> Utf8 Class Initialized
INFO - 2020-07-31 06:24:03 --> URI Class Initialized
DEBUG - 2020-07-31 06:24:03 --> No URI present. Default controller set.
INFO - 2020-07-31 06:24:03 --> Router Class Initialized
INFO - 2020-07-31 06:24:03 --> Output Class Initialized
INFO - 2020-07-31 06:24:03 --> Security Class Initialized
DEBUG - 2020-07-31 06:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:24:03 --> Input Class Initialized
INFO - 2020-07-31 06:24:03 --> Language Class Initialized
INFO - 2020-07-31 06:24:03 --> Loader Class Initialized
INFO - 2020-07-31 06:24:03 --> Helper loaded: url_helper
INFO - 2020-07-31 06:24:03 --> Database Driver Class Initialized
INFO - 2020-07-31 06:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:24:03 --> Email Class Initialized
INFO - 2020-07-31 06:24:03 --> Controller Class Initialized
INFO - 2020-07-31 06:24:03 --> Model Class Initialized
INFO - 2020-07-31 06:24:03 --> Model Class Initialized
DEBUG - 2020-07-31 06:24:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:24:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:24:03 --> Final output sent to browser
DEBUG - 2020-07-31 06:24:03 --> Total execution time: 0.0221
INFO - 2020-07-31 06:24:37 --> Config Class Initialized
INFO - 2020-07-31 06:24:37 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:24:37 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:24:37 --> Utf8 Class Initialized
INFO - 2020-07-31 06:24:37 --> URI Class Initialized
DEBUG - 2020-07-31 06:24:37 --> No URI present. Default controller set.
INFO - 2020-07-31 06:24:37 --> Router Class Initialized
INFO - 2020-07-31 06:24:37 --> Output Class Initialized
INFO - 2020-07-31 06:24:37 --> Security Class Initialized
DEBUG - 2020-07-31 06:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:24:37 --> Input Class Initialized
INFO - 2020-07-31 06:24:37 --> Language Class Initialized
INFO - 2020-07-31 06:24:37 --> Loader Class Initialized
INFO - 2020-07-31 06:24:37 --> Helper loaded: url_helper
INFO - 2020-07-31 06:24:37 --> Database Driver Class Initialized
INFO - 2020-07-31 06:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:24:37 --> Email Class Initialized
INFO - 2020-07-31 06:24:37 --> Controller Class Initialized
INFO - 2020-07-31 06:24:37 --> Model Class Initialized
INFO - 2020-07-31 06:24:37 --> Model Class Initialized
DEBUG - 2020-07-31 06:24:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:24:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:24:37 --> Final output sent to browser
DEBUG - 2020-07-31 06:24:37 --> Total execution time: 0.0230
INFO - 2020-07-31 06:25:03 --> Config Class Initialized
INFO - 2020-07-31 06:25:03 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:25:03 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:25:03 --> Utf8 Class Initialized
INFO - 2020-07-31 06:25:03 --> URI Class Initialized
DEBUG - 2020-07-31 06:25:03 --> No URI present. Default controller set.
INFO - 2020-07-31 06:25:03 --> Router Class Initialized
INFO - 2020-07-31 06:25:03 --> Output Class Initialized
INFO - 2020-07-31 06:25:03 --> Security Class Initialized
DEBUG - 2020-07-31 06:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:25:03 --> Input Class Initialized
INFO - 2020-07-31 06:25:03 --> Language Class Initialized
INFO - 2020-07-31 06:25:03 --> Loader Class Initialized
INFO - 2020-07-31 06:25:03 --> Helper loaded: url_helper
INFO - 2020-07-31 06:25:03 --> Database Driver Class Initialized
INFO - 2020-07-31 06:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:25:03 --> Email Class Initialized
INFO - 2020-07-31 06:25:03 --> Controller Class Initialized
INFO - 2020-07-31 06:25:03 --> Model Class Initialized
INFO - 2020-07-31 06:25:03 --> Model Class Initialized
DEBUG - 2020-07-31 06:25:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:25:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:25:03 --> Final output sent to browser
DEBUG - 2020-07-31 06:25:03 --> Total execution time: 0.0240
INFO - 2020-07-31 06:25:06 --> Config Class Initialized
INFO - 2020-07-31 06:25:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:25:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:25:06 --> Utf8 Class Initialized
INFO - 2020-07-31 06:25:06 --> URI Class Initialized
INFO - 2020-07-31 06:25:06 --> Router Class Initialized
INFO - 2020-07-31 06:25:06 --> Output Class Initialized
INFO - 2020-07-31 06:25:06 --> Security Class Initialized
DEBUG - 2020-07-31 06:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:25:06 --> Input Class Initialized
INFO - 2020-07-31 06:25:06 --> Language Class Initialized
INFO - 2020-07-31 06:25:06 --> Loader Class Initialized
INFO - 2020-07-31 06:25:06 --> Helper loaded: url_helper
INFO - 2020-07-31 06:25:06 --> Database Driver Class Initialized
INFO - 2020-07-31 06:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:25:06 --> Email Class Initialized
INFO - 2020-07-31 06:25:06 --> Controller Class Initialized
INFO - 2020-07-31 06:25:06 --> Model Class Initialized
INFO - 2020-07-31 06:25:06 --> Model Class Initialized
DEBUG - 2020-07-31 06:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:25:06 --> Config Class Initialized
INFO - 2020-07-31 06:25:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:25:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:25:06 --> Utf8 Class Initialized
INFO - 2020-07-31 06:25:06 --> URI Class Initialized
INFO - 2020-07-31 06:25:06 --> Router Class Initialized
INFO - 2020-07-31 06:25:06 --> Output Class Initialized
INFO - 2020-07-31 06:25:06 --> Security Class Initialized
DEBUG - 2020-07-31 06:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:25:06 --> Input Class Initialized
INFO - 2020-07-31 06:25:06 --> Language Class Initialized
INFO - 2020-07-31 06:25:06 --> Loader Class Initialized
INFO - 2020-07-31 06:25:06 --> Helper loaded: url_helper
INFO - 2020-07-31 06:25:06 --> Database Driver Class Initialized
INFO - 2020-07-31 06:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:25:06 --> Email Class Initialized
INFO - 2020-07-31 06:25:06 --> Controller Class Initialized
DEBUG - 2020-07-31 06:25:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:25:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:25:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:25:06 --> Final output sent to browser
DEBUG - 2020-07-31 06:25:06 --> Total execution time: 0.0203
INFO - 2020-07-31 06:25:43 --> Config Class Initialized
INFO - 2020-07-31 06:25:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:25:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:25:43 --> Utf8 Class Initialized
INFO - 2020-07-31 06:25:43 --> URI Class Initialized
DEBUG - 2020-07-31 06:25:43 --> No URI present. Default controller set.
INFO - 2020-07-31 06:25:43 --> Router Class Initialized
INFO - 2020-07-31 06:25:43 --> Output Class Initialized
INFO - 2020-07-31 06:25:43 --> Security Class Initialized
DEBUG - 2020-07-31 06:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:25:43 --> Input Class Initialized
INFO - 2020-07-31 06:25:43 --> Language Class Initialized
INFO - 2020-07-31 06:25:43 --> Loader Class Initialized
INFO - 2020-07-31 06:25:43 --> Helper loaded: url_helper
INFO - 2020-07-31 06:25:43 --> Database Driver Class Initialized
INFO - 2020-07-31 06:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:25:43 --> Email Class Initialized
INFO - 2020-07-31 06:25:43 --> Controller Class Initialized
INFO - 2020-07-31 06:25:43 --> Model Class Initialized
INFO - 2020-07-31 06:25:43 --> Model Class Initialized
DEBUG - 2020-07-31 06:25:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:25:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:25:43 --> Final output sent to browser
DEBUG - 2020-07-31 06:25:43 --> Total execution time: 0.0277
INFO - 2020-07-31 06:25:45 --> Config Class Initialized
INFO - 2020-07-31 06:25:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:25:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:25:45 --> Utf8 Class Initialized
INFO - 2020-07-31 06:25:45 --> URI Class Initialized
INFO - 2020-07-31 06:25:45 --> Router Class Initialized
INFO - 2020-07-31 06:25:45 --> Output Class Initialized
INFO - 2020-07-31 06:25:45 --> Security Class Initialized
DEBUG - 2020-07-31 06:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:25:45 --> Input Class Initialized
INFO - 2020-07-31 06:25:45 --> Language Class Initialized
INFO - 2020-07-31 06:25:45 --> Loader Class Initialized
INFO - 2020-07-31 06:25:45 --> Helper loaded: url_helper
INFO - 2020-07-31 06:25:45 --> Database Driver Class Initialized
INFO - 2020-07-31 06:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:25:45 --> Email Class Initialized
INFO - 2020-07-31 06:25:45 --> Controller Class Initialized
INFO - 2020-07-31 06:25:45 --> Model Class Initialized
INFO - 2020-07-31 06:25:45 --> Model Class Initialized
DEBUG - 2020-07-31 06:25:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:25:46 --> Config Class Initialized
INFO - 2020-07-31 06:25:46 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:25:46 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:25:46 --> Utf8 Class Initialized
INFO - 2020-07-31 06:25:46 --> URI Class Initialized
INFO - 2020-07-31 06:25:46 --> Router Class Initialized
INFO - 2020-07-31 06:25:46 --> Output Class Initialized
INFO - 2020-07-31 06:25:46 --> Security Class Initialized
DEBUG - 2020-07-31 06:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:25:46 --> Input Class Initialized
INFO - 2020-07-31 06:25:46 --> Language Class Initialized
INFO - 2020-07-31 06:25:46 --> Loader Class Initialized
INFO - 2020-07-31 06:25:46 --> Helper loaded: url_helper
INFO - 2020-07-31 06:25:46 --> Database Driver Class Initialized
INFO - 2020-07-31 06:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:25:46 --> Email Class Initialized
INFO - 2020-07-31 06:25:46 --> Controller Class Initialized
DEBUG - 2020-07-31 06:25:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:25:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:25:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:25:46 --> Final output sent to browser
DEBUG - 2020-07-31 06:25:46 --> Total execution time: 0.0243
INFO - 2020-07-31 06:27:31 --> Config Class Initialized
INFO - 2020-07-31 06:27:31 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:27:31 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:27:31 --> Utf8 Class Initialized
INFO - 2020-07-31 06:27:31 --> URI Class Initialized
DEBUG - 2020-07-31 06:27:31 --> No URI present. Default controller set.
INFO - 2020-07-31 06:27:31 --> Router Class Initialized
INFO - 2020-07-31 06:27:31 --> Output Class Initialized
INFO - 2020-07-31 06:27:31 --> Security Class Initialized
DEBUG - 2020-07-31 06:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:27:31 --> Input Class Initialized
INFO - 2020-07-31 06:27:31 --> Language Class Initialized
INFO - 2020-07-31 06:27:31 --> Loader Class Initialized
INFO - 2020-07-31 06:27:31 --> Helper loaded: url_helper
INFO - 2020-07-31 06:27:31 --> Database Driver Class Initialized
INFO - 2020-07-31 06:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:27:32 --> Email Class Initialized
INFO - 2020-07-31 06:27:32 --> Controller Class Initialized
INFO - 2020-07-31 06:27:32 --> Model Class Initialized
INFO - 2020-07-31 06:27:32 --> Model Class Initialized
DEBUG - 2020-07-31 06:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:27:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:27:32 --> Final output sent to browser
DEBUG - 2020-07-31 06:27:32 --> Total execution time: 0.1316
INFO - 2020-07-31 06:27:44 --> Config Class Initialized
INFO - 2020-07-31 06:27:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:27:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:27:44 --> Utf8 Class Initialized
INFO - 2020-07-31 06:27:44 --> URI Class Initialized
INFO - 2020-07-31 06:27:44 --> Router Class Initialized
INFO - 2020-07-31 06:27:44 --> Output Class Initialized
INFO - 2020-07-31 06:27:44 --> Security Class Initialized
DEBUG - 2020-07-31 06:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:27:44 --> Input Class Initialized
INFO - 2020-07-31 06:27:44 --> Language Class Initialized
INFO - 2020-07-31 06:27:44 --> Loader Class Initialized
INFO - 2020-07-31 06:27:44 --> Helper loaded: url_helper
INFO - 2020-07-31 06:27:44 --> Database Driver Class Initialized
INFO - 2020-07-31 06:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:27:44 --> Email Class Initialized
INFO - 2020-07-31 06:27:44 --> Controller Class Initialized
INFO - 2020-07-31 06:27:44 --> Model Class Initialized
INFO - 2020-07-31 06:27:44 --> Model Class Initialized
DEBUG - 2020-07-31 06:27:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:27:45 --> Config Class Initialized
INFO - 2020-07-31 06:27:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:27:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:27:45 --> Utf8 Class Initialized
INFO - 2020-07-31 06:27:45 --> URI Class Initialized
DEBUG - 2020-07-31 06:27:45 --> No URI present. Default controller set.
INFO - 2020-07-31 06:27:45 --> Router Class Initialized
INFO - 2020-07-31 06:27:45 --> Output Class Initialized
INFO - 2020-07-31 06:27:45 --> Security Class Initialized
DEBUG - 2020-07-31 06:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:27:45 --> Input Class Initialized
INFO - 2020-07-31 06:27:45 --> Language Class Initialized
INFO - 2020-07-31 06:27:45 --> Loader Class Initialized
INFO - 2020-07-31 06:27:45 --> Helper loaded: url_helper
INFO - 2020-07-31 06:27:45 --> Database Driver Class Initialized
INFO - 2020-07-31 06:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:27:45 --> Email Class Initialized
INFO - 2020-07-31 06:27:45 --> Controller Class Initialized
INFO - 2020-07-31 06:27:45 --> Model Class Initialized
INFO - 2020-07-31 06:27:45 --> Model Class Initialized
DEBUG - 2020-07-31 06:27:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:27:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:27:45 --> Final output sent to browser
DEBUG - 2020-07-31 06:27:45 --> Total execution time: 0.0215
INFO - 2020-07-31 06:27:52 --> Config Class Initialized
INFO - 2020-07-31 06:27:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:27:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:27:52 --> Utf8 Class Initialized
INFO - 2020-07-31 06:27:52 --> URI Class Initialized
INFO - 2020-07-31 06:27:52 --> Router Class Initialized
INFO - 2020-07-31 06:27:52 --> Output Class Initialized
INFO - 2020-07-31 06:27:52 --> Security Class Initialized
DEBUG - 2020-07-31 06:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:27:52 --> Input Class Initialized
INFO - 2020-07-31 06:27:52 --> Language Class Initialized
INFO - 2020-07-31 06:27:52 --> Loader Class Initialized
INFO - 2020-07-31 06:27:52 --> Helper loaded: url_helper
INFO - 2020-07-31 06:27:52 --> Database Driver Class Initialized
INFO - 2020-07-31 06:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:27:52 --> Email Class Initialized
INFO - 2020-07-31 06:27:52 --> Controller Class Initialized
INFO - 2020-07-31 06:27:52 --> Model Class Initialized
INFO - 2020-07-31 06:27:52 --> Model Class Initialized
DEBUG - 2020-07-31 06:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:27:52 --> Config Class Initialized
INFO - 2020-07-31 06:27:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:27:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:27:52 --> Utf8 Class Initialized
INFO - 2020-07-31 06:27:52 --> URI Class Initialized
DEBUG - 2020-07-31 06:27:52 --> No URI present. Default controller set.
INFO - 2020-07-31 06:27:52 --> Router Class Initialized
INFO - 2020-07-31 06:27:52 --> Output Class Initialized
INFO - 2020-07-31 06:27:52 --> Security Class Initialized
DEBUG - 2020-07-31 06:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:27:52 --> Input Class Initialized
INFO - 2020-07-31 06:27:52 --> Language Class Initialized
INFO - 2020-07-31 06:27:52 --> Loader Class Initialized
INFO - 2020-07-31 06:27:52 --> Helper loaded: url_helper
INFO - 2020-07-31 06:27:52 --> Database Driver Class Initialized
INFO - 2020-07-31 06:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:27:52 --> Email Class Initialized
INFO - 2020-07-31 06:27:52 --> Controller Class Initialized
INFO - 2020-07-31 06:27:52 --> Model Class Initialized
INFO - 2020-07-31 06:27:52 --> Model Class Initialized
DEBUG - 2020-07-31 06:27:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:27:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:27:52 --> Final output sent to browser
DEBUG - 2020-07-31 06:27:52 --> Total execution time: 0.0206
INFO - 2020-07-31 06:28:26 --> Config Class Initialized
INFO - 2020-07-31 06:28:26 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:28:26 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:28:26 --> Utf8 Class Initialized
INFO - 2020-07-31 06:28:26 --> URI Class Initialized
INFO - 2020-07-31 06:28:26 --> Router Class Initialized
INFO - 2020-07-31 06:28:26 --> Output Class Initialized
INFO - 2020-07-31 06:28:26 --> Security Class Initialized
DEBUG - 2020-07-31 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:28:26 --> Input Class Initialized
INFO - 2020-07-31 06:28:26 --> Language Class Initialized
INFO - 2020-07-31 06:28:26 --> Loader Class Initialized
INFO - 2020-07-31 06:28:26 --> Helper loaded: url_helper
INFO - 2020-07-31 06:28:26 --> Database Driver Class Initialized
INFO - 2020-07-31 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:28:26 --> Email Class Initialized
INFO - 2020-07-31 06:28:26 --> Controller Class Initialized
INFO - 2020-07-31 06:28:26 --> Model Class Initialized
INFO - 2020-07-31 06:28:26 --> Model Class Initialized
DEBUG - 2020-07-31 06:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:28:26 --> Config Class Initialized
INFO - 2020-07-31 06:28:26 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:28:26 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:28:26 --> Utf8 Class Initialized
INFO - 2020-07-31 06:28:26 --> URI Class Initialized
DEBUG - 2020-07-31 06:28:26 --> No URI present. Default controller set.
INFO - 2020-07-31 06:28:26 --> Router Class Initialized
INFO - 2020-07-31 06:28:26 --> Output Class Initialized
INFO - 2020-07-31 06:28:26 --> Security Class Initialized
DEBUG - 2020-07-31 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:28:26 --> Input Class Initialized
INFO - 2020-07-31 06:28:26 --> Language Class Initialized
INFO - 2020-07-31 06:28:26 --> Loader Class Initialized
INFO - 2020-07-31 06:28:26 --> Helper loaded: url_helper
INFO - 2020-07-31 06:28:26 --> Database Driver Class Initialized
INFO - 2020-07-31 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:28:26 --> Email Class Initialized
INFO - 2020-07-31 06:28:26 --> Controller Class Initialized
INFO - 2020-07-31 06:28:26 --> Model Class Initialized
INFO - 2020-07-31 06:28:26 --> Model Class Initialized
DEBUG - 2020-07-31 06:28:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:28:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:28:26 --> Final output sent to browser
DEBUG - 2020-07-31 06:28:26 --> Total execution time: 0.0239
INFO - 2020-07-31 06:36:40 --> Config Class Initialized
INFO - 2020-07-31 06:36:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:36:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:36:40 --> Utf8 Class Initialized
INFO - 2020-07-31 06:36:40 --> URI Class Initialized
DEBUG - 2020-07-31 06:36:40 --> No URI present. Default controller set.
INFO - 2020-07-31 06:36:40 --> Router Class Initialized
INFO - 2020-07-31 06:36:40 --> Output Class Initialized
INFO - 2020-07-31 06:36:40 --> Security Class Initialized
DEBUG - 2020-07-31 06:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:36:40 --> Input Class Initialized
INFO - 2020-07-31 06:36:40 --> Language Class Initialized
INFO - 2020-07-31 06:36:40 --> Loader Class Initialized
INFO - 2020-07-31 06:36:40 --> Helper loaded: url_helper
INFO - 2020-07-31 06:36:40 --> Database Driver Class Initialized
INFO - 2020-07-31 06:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:36:40 --> Email Class Initialized
INFO - 2020-07-31 06:36:40 --> Controller Class Initialized
INFO - 2020-07-31 06:36:40 --> Model Class Initialized
INFO - 2020-07-31 06:36:40 --> Model Class Initialized
DEBUG - 2020-07-31 06:36:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:36:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:36:40 --> Final output sent to browser
DEBUG - 2020-07-31 06:36:40 --> Total execution time: 0.0300
INFO - 2020-07-31 06:36:51 --> Config Class Initialized
INFO - 2020-07-31 06:36:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:36:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:36:51 --> Utf8 Class Initialized
INFO - 2020-07-31 06:36:51 --> URI Class Initialized
INFO - 2020-07-31 06:36:51 --> Router Class Initialized
INFO - 2020-07-31 06:36:51 --> Output Class Initialized
INFO - 2020-07-31 06:36:51 --> Security Class Initialized
DEBUG - 2020-07-31 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:36:51 --> Input Class Initialized
INFO - 2020-07-31 06:36:51 --> Language Class Initialized
INFO - 2020-07-31 06:36:51 --> Loader Class Initialized
INFO - 2020-07-31 06:36:51 --> Helper loaded: url_helper
INFO - 2020-07-31 06:36:51 --> Database Driver Class Initialized
INFO - 2020-07-31 06:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:36:51 --> Email Class Initialized
INFO - 2020-07-31 06:36:51 --> Controller Class Initialized
INFO - 2020-07-31 06:36:51 --> Model Class Initialized
INFO - 2020-07-31 06:36:51 --> Model Class Initialized
DEBUG - 2020-07-31 06:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:36:51 --> Config Class Initialized
INFO - 2020-07-31 06:36:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:36:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:36:51 --> Utf8 Class Initialized
INFO - 2020-07-31 06:36:51 --> URI Class Initialized
DEBUG - 2020-07-31 06:36:51 --> No URI present. Default controller set.
INFO - 2020-07-31 06:36:51 --> Router Class Initialized
INFO - 2020-07-31 06:36:51 --> Output Class Initialized
INFO - 2020-07-31 06:36:51 --> Security Class Initialized
DEBUG - 2020-07-31 06:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:36:51 --> Input Class Initialized
INFO - 2020-07-31 06:36:51 --> Language Class Initialized
INFO - 2020-07-31 06:36:51 --> Loader Class Initialized
INFO - 2020-07-31 06:36:51 --> Helper loaded: url_helper
INFO - 2020-07-31 06:36:51 --> Database Driver Class Initialized
INFO - 2020-07-31 06:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:36:51 --> Email Class Initialized
INFO - 2020-07-31 06:36:51 --> Controller Class Initialized
INFO - 2020-07-31 06:36:51 --> Model Class Initialized
INFO - 2020-07-31 06:36:51 --> Model Class Initialized
DEBUG - 2020-07-31 06:36:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:36:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:36:51 --> Final output sent to browser
DEBUG - 2020-07-31 06:36:51 --> Total execution time: 0.0381
INFO - 2020-07-31 06:39:30 --> Config Class Initialized
INFO - 2020-07-31 06:39:30 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:39:30 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:39:30 --> Utf8 Class Initialized
INFO - 2020-07-31 06:39:30 --> URI Class Initialized
DEBUG - 2020-07-31 06:39:30 --> No URI present. Default controller set.
INFO - 2020-07-31 06:39:30 --> Router Class Initialized
INFO - 2020-07-31 06:39:30 --> Output Class Initialized
INFO - 2020-07-31 06:39:30 --> Security Class Initialized
DEBUG - 2020-07-31 06:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:39:30 --> Input Class Initialized
INFO - 2020-07-31 06:39:30 --> Language Class Initialized
INFO - 2020-07-31 06:39:30 --> Loader Class Initialized
INFO - 2020-07-31 06:39:30 --> Helper loaded: url_helper
INFO - 2020-07-31 06:39:30 --> Database Driver Class Initialized
INFO - 2020-07-31 06:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:39:30 --> Email Class Initialized
INFO - 2020-07-31 06:39:30 --> Controller Class Initialized
INFO - 2020-07-31 06:39:30 --> Model Class Initialized
INFO - 2020-07-31 06:39:30 --> Model Class Initialized
DEBUG - 2020-07-31 06:39:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:39:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:39:30 --> Final output sent to browser
DEBUG - 2020-07-31 06:39:30 --> Total execution time: 0.0216
INFO - 2020-07-31 06:39:40 --> Config Class Initialized
INFO - 2020-07-31 06:39:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:39:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:39:40 --> Utf8 Class Initialized
INFO - 2020-07-31 06:39:40 --> URI Class Initialized
INFO - 2020-07-31 06:39:40 --> Router Class Initialized
INFO - 2020-07-31 06:39:40 --> Output Class Initialized
INFO - 2020-07-31 06:39:40 --> Security Class Initialized
DEBUG - 2020-07-31 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:39:40 --> Input Class Initialized
INFO - 2020-07-31 06:39:40 --> Language Class Initialized
INFO - 2020-07-31 06:39:40 --> Loader Class Initialized
INFO - 2020-07-31 06:39:40 --> Helper loaded: url_helper
INFO - 2020-07-31 06:39:40 --> Database Driver Class Initialized
INFO - 2020-07-31 06:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:39:40 --> Email Class Initialized
INFO - 2020-07-31 06:39:40 --> Controller Class Initialized
INFO - 2020-07-31 06:39:40 --> Model Class Initialized
INFO - 2020-07-31 06:39:40 --> Model Class Initialized
DEBUG - 2020-07-31 06:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:39:40 --> Config Class Initialized
INFO - 2020-07-31 06:39:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:39:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:39:40 --> Utf8 Class Initialized
INFO - 2020-07-31 06:39:40 --> URI Class Initialized
DEBUG - 2020-07-31 06:39:40 --> No URI present. Default controller set.
INFO - 2020-07-31 06:39:40 --> Router Class Initialized
INFO - 2020-07-31 06:39:40 --> Output Class Initialized
INFO - 2020-07-31 06:39:40 --> Security Class Initialized
DEBUG - 2020-07-31 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:39:40 --> Input Class Initialized
INFO - 2020-07-31 06:39:40 --> Language Class Initialized
INFO - 2020-07-31 06:39:40 --> Loader Class Initialized
INFO - 2020-07-31 06:39:40 --> Helper loaded: url_helper
INFO - 2020-07-31 06:39:40 --> Database Driver Class Initialized
INFO - 2020-07-31 06:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:39:40 --> Email Class Initialized
INFO - 2020-07-31 06:39:40 --> Controller Class Initialized
INFO - 2020-07-31 06:39:40 --> Model Class Initialized
INFO - 2020-07-31 06:39:40 --> Model Class Initialized
DEBUG - 2020-07-31 06:39:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:39:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:39:40 --> Final output sent to browser
DEBUG - 2020-07-31 06:39:40 --> Total execution time: 0.1156
INFO - 2020-07-31 06:44:51 --> Config Class Initialized
INFO - 2020-07-31 06:44:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:44:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:44:51 --> Utf8 Class Initialized
INFO - 2020-07-31 06:44:51 --> URI Class Initialized
INFO - 2020-07-31 06:44:51 --> Router Class Initialized
INFO - 2020-07-31 06:44:51 --> Output Class Initialized
INFO - 2020-07-31 06:44:51 --> Security Class Initialized
DEBUG - 2020-07-31 06:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:44:51 --> Input Class Initialized
INFO - 2020-07-31 06:44:51 --> Language Class Initialized
INFO - 2020-07-31 06:44:51 --> Loader Class Initialized
INFO - 2020-07-31 06:44:51 --> Helper loaded: url_helper
INFO - 2020-07-31 06:44:51 --> Database Driver Class Initialized
INFO - 2020-07-31 06:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:44:51 --> Email Class Initialized
INFO - 2020-07-31 06:44:51 --> Controller Class Initialized
INFO - 2020-07-31 06:44:51 --> Model Class Initialized
INFO - 2020-07-31 06:44:51 --> Model Class Initialized
DEBUG - 2020-07-31 06:44:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:44:52 --> Config Class Initialized
INFO - 2020-07-31 06:44:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:44:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:44:52 --> Utf8 Class Initialized
INFO - 2020-07-31 06:44:52 --> URI Class Initialized
INFO - 2020-07-31 06:44:52 --> Router Class Initialized
INFO - 2020-07-31 06:44:52 --> Output Class Initialized
INFO - 2020-07-31 06:44:52 --> Security Class Initialized
DEBUG - 2020-07-31 06:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:44:52 --> Input Class Initialized
INFO - 2020-07-31 06:44:52 --> Language Class Initialized
INFO - 2020-07-31 06:44:52 --> Loader Class Initialized
INFO - 2020-07-31 06:44:52 --> Helper loaded: url_helper
INFO - 2020-07-31 06:44:52 --> Database Driver Class Initialized
INFO - 2020-07-31 06:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:44:52 --> Email Class Initialized
INFO - 2020-07-31 06:44:52 --> Controller Class Initialized
DEBUG - 2020-07-31 06:44:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:44:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:44:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:44:52 --> Final output sent to browser
DEBUG - 2020-07-31 06:44:52 --> Total execution time: 0.0275
INFO - 2020-07-31 06:44:58 --> Config Class Initialized
INFO - 2020-07-31 06:44:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:44:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:44:58 --> Utf8 Class Initialized
INFO - 2020-07-31 06:44:58 --> URI Class Initialized
DEBUG - 2020-07-31 06:44:58 --> No URI present. Default controller set.
INFO - 2020-07-31 06:44:58 --> Router Class Initialized
INFO - 2020-07-31 06:44:58 --> Output Class Initialized
INFO - 2020-07-31 06:44:58 --> Security Class Initialized
DEBUG - 2020-07-31 06:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:44:58 --> Input Class Initialized
INFO - 2020-07-31 06:44:58 --> Language Class Initialized
INFO - 2020-07-31 06:44:58 --> Loader Class Initialized
INFO - 2020-07-31 06:44:58 --> Helper loaded: url_helper
INFO - 2020-07-31 06:44:58 --> Database Driver Class Initialized
INFO - 2020-07-31 06:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:44:58 --> Email Class Initialized
INFO - 2020-07-31 06:44:58 --> Controller Class Initialized
INFO - 2020-07-31 06:44:58 --> Model Class Initialized
INFO - 2020-07-31 06:44:58 --> Model Class Initialized
DEBUG - 2020-07-31 06:44:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:44:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:44:58 --> Final output sent to browser
DEBUG - 2020-07-31 06:44:58 --> Total execution time: 0.0245
INFO - 2020-07-31 06:45:07 --> Config Class Initialized
INFO - 2020-07-31 06:45:07 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:07 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:07 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:07 --> URI Class Initialized
INFO - 2020-07-31 06:45:07 --> Router Class Initialized
INFO - 2020-07-31 06:45:07 --> Output Class Initialized
INFO - 2020-07-31 06:45:07 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:07 --> Input Class Initialized
INFO - 2020-07-31 06:45:07 --> Language Class Initialized
INFO - 2020-07-31 06:45:07 --> Loader Class Initialized
INFO - 2020-07-31 06:45:07 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:07 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:07 --> Email Class Initialized
INFO - 2020-07-31 06:45:07 --> Controller Class Initialized
INFO - 2020-07-31 06:45:07 --> Model Class Initialized
INFO - 2020-07-31 06:45:07 --> Model Class Initialized
DEBUG - 2020-07-31 06:45:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:08 --> Config Class Initialized
INFO - 2020-07-31 06:45:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:08 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:08 --> URI Class Initialized
DEBUG - 2020-07-31 06:45:08 --> No URI present. Default controller set.
INFO - 2020-07-31 06:45:08 --> Router Class Initialized
INFO - 2020-07-31 06:45:08 --> Output Class Initialized
INFO - 2020-07-31 06:45:08 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:08 --> Input Class Initialized
INFO - 2020-07-31 06:45:08 --> Language Class Initialized
INFO - 2020-07-31 06:45:08 --> Loader Class Initialized
INFO - 2020-07-31 06:45:08 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:08 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:08 --> Email Class Initialized
INFO - 2020-07-31 06:45:08 --> Controller Class Initialized
INFO - 2020-07-31 06:45:08 --> Model Class Initialized
INFO - 2020-07-31 06:45:08 --> Model Class Initialized
DEBUG - 2020-07-31 06:45:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:45:08 --> Final output sent to browser
DEBUG - 2020-07-31 06:45:08 --> Total execution time: 0.0238
INFO - 2020-07-31 06:45:39 --> Config Class Initialized
INFO - 2020-07-31 06:45:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:39 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:39 --> URI Class Initialized
INFO - 2020-07-31 06:45:39 --> Router Class Initialized
INFO - 2020-07-31 06:45:39 --> Output Class Initialized
INFO - 2020-07-31 06:45:39 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:39 --> Input Class Initialized
INFO - 2020-07-31 06:45:39 --> Language Class Initialized
INFO - 2020-07-31 06:45:39 --> Loader Class Initialized
INFO - 2020-07-31 06:45:39 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:39 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:39 --> Email Class Initialized
INFO - 2020-07-31 06:45:39 --> Controller Class Initialized
INFO - 2020-07-31 06:45:39 --> Model Class Initialized
INFO - 2020-07-31 06:45:39 --> Model Class Initialized
DEBUG - 2020-07-31 06:45:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:40 --> Config Class Initialized
INFO - 2020-07-31 06:45:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:40 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:40 --> URI Class Initialized
INFO - 2020-07-31 06:45:40 --> Router Class Initialized
INFO - 2020-07-31 06:45:40 --> Output Class Initialized
INFO - 2020-07-31 06:45:40 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:40 --> Input Class Initialized
INFO - 2020-07-31 06:45:40 --> Language Class Initialized
INFO - 2020-07-31 06:45:40 --> Loader Class Initialized
INFO - 2020-07-31 06:45:40 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:40 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:40 --> Email Class Initialized
INFO - 2020-07-31 06:45:40 --> Controller Class Initialized
DEBUG - 2020-07-31 06:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:45:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:45:40 --> Final output sent to browser
DEBUG - 2020-07-31 06:45:40 --> Total execution time: 0.0221
INFO - 2020-07-31 06:45:43 --> Config Class Initialized
INFO - 2020-07-31 06:45:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:43 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:43 --> URI Class Initialized
DEBUG - 2020-07-31 06:45:43 --> No URI present. Default controller set.
INFO - 2020-07-31 06:45:43 --> Router Class Initialized
INFO - 2020-07-31 06:45:43 --> Output Class Initialized
INFO - 2020-07-31 06:45:43 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:43 --> Input Class Initialized
INFO - 2020-07-31 06:45:43 --> Language Class Initialized
INFO - 2020-07-31 06:45:43 --> Loader Class Initialized
INFO - 2020-07-31 06:45:43 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:43 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:43 --> Email Class Initialized
INFO - 2020-07-31 06:45:43 --> Controller Class Initialized
INFO - 2020-07-31 06:45:43 --> Model Class Initialized
INFO - 2020-07-31 06:45:43 --> Model Class Initialized
DEBUG - 2020-07-31 06:45:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:45:43 --> Final output sent to browser
DEBUG - 2020-07-31 06:45:43 --> Total execution time: 0.0230
INFO - 2020-07-31 06:45:55 --> Config Class Initialized
INFO - 2020-07-31 06:45:55 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:55 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:55 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:55 --> URI Class Initialized
INFO - 2020-07-31 06:45:55 --> Router Class Initialized
INFO - 2020-07-31 06:45:55 --> Output Class Initialized
INFO - 2020-07-31 06:45:55 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:55 --> Input Class Initialized
INFO - 2020-07-31 06:45:55 --> Language Class Initialized
INFO - 2020-07-31 06:45:55 --> Loader Class Initialized
INFO - 2020-07-31 06:45:55 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:55 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:55 --> Email Class Initialized
INFO - 2020-07-31 06:45:55 --> Controller Class Initialized
INFO - 2020-07-31 06:45:55 --> Model Class Initialized
INFO - 2020-07-31 06:45:55 --> Model Class Initialized
DEBUG - 2020-07-31 06:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:55 --> Config Class Initialized
INFO - 2020-07-31 06:45:55 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:45:55 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:45:55 --> Utf8 Class Initialized
INFO - 2020-07-31 06:45:55 --> URI Class Initialized
DEBUG - 2020-07-31 06:45:55 --> No URI present. Default controller set.
INFO - 2020-07-31 06:45:55 --> Router Class Initialized
INFO - 2020-07-31 06:45:55 --> Output Class Initialized
INFO - 2020-07-31 06:45:55 --> Security Class Initialized
DEBUG - 2020-07-31 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:45:55 --> Input Class Initialized
INFO - 2020-07-31 06:45:55 --> Language Class Initialized
INFO - 2020-07-31 06:45:55 --> Loader Class Initialized
INFO - 2020-07-31 06:45:55 --> Helper loaded: url_helper
INFO - 2020-07-31 06:45:55 --> Database Driver Class Initialized
INFO - 2020-07-31 06:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:45:55 --> Email Class Initialized
INFO - 2020-07-31 06:45:55 --> Controller Class Initialized
INFO - 2020-07-31 06:45:55 --> Model Class Initialized
INFO - 2020-07-31 06:45:55 --> Model Class Initialized
DEBUG - 2020-07-31 06:45:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:45:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 06:45:55 --> Final output sent to browser
DEBUG - 2020-07-31 06:45:55 --> Total execution time: 0.0240
INFO - 2020-07-31 06:49:19 --> Config Class Initialized
INFO - 2020-07-31 06:49:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:49:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:49:19 --> Utf8 Class Initialized
INFO - 2020-07-31 06:49:19 --> URI Class Initialized
INFO - 2020-07-31 06:49:19 --> Router Class Initialized
INFO - 2020-07-31 06:49:19 --> Output Class Initialized
INFO - 2020-07-31 06:49:19 --> Security Class Initialized
DEBUG - 2020-07-31 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:49:19 --> Input Class Initialized
INFO - 2020-07-31 06:49:19 --> Language Class Initialized
INFO - 2020-07-31 06:49:19 --> Loader Class Initialized
INFO - 2020-07-31 06:49:19 --> Helper loaded: url_helper
INFO - 2020-07-31 06:49:19 --> Database Driver Class Initialized
INFO - 2020-07-31 06:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:49:19 --> Email Class Initialized
INFO - 2020-07-31 06:49:19 --> Controller Class Initialized
INFO - 2020-07-31 06:49:19 --> Model Class Initialized
INFO - 2020-07-31 06:49:19 --> Model Class Initialized
DEBUG - 2020-07-31 06:49:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:49:19 --> Config Class Initialized
INFO - 2020-07-31 06:49:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:49:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:49:19 --> Utf8 Class Initialized
INFO - 2020-07-31 06:49:19 --> URI Class Initialized
INFO - 2020-07-31 06:49:19 --> Router Class Initialized
INFO - 2020-07-31 06:49:19 --> Output Class Initialized
INFO - 2020-07-31 06:49:19 --> Security Class Initialized
DEBUG - 2020-07-31 06:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:49:19 --> Input Class Initialized
INFO - 2020-07-31 06:49:19 --> Language Class Initialized
INFO - 2020-07-31 06:49:19 --> Loader Class Initialized
INFO - 2020-07-31 06:49:19 --> Helper loaded: url_helper
INFO - 2020-07-31 06:49:19 --> Database Driver Class Initialized
INFO - 2020-07-31 06:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:49:19 --> Email Class Initialized
INFO - 2020-07-31 06:49:19 --> Controller Class Initialized
DEBUG - 2020-07-31 06:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:49:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:49:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 06:49:19 --> Final output sent to browser
DEBUG - 2020-07-31 06:49:19 --> Total execution time: 0.0232
INFO - 2020-07-31 06:49:25 --> Config Class Initialized
INFO - 2020-07-31 06:49:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:49:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:49:25 --> Utf8 Class Initialized
INFO - 2020-07-31 06:49:25 --> URI Class Initialized
INFO - 2020-07-31 06:49:25 --> Router Class Initialized
INFO - 2020-07-31 06:49:25 --> Output Class Initialized
INFO - 2020-07-31 06:49:25 --> Security Class Initialized
DEBUG - 2020-07-31 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:49:25 --> Input Class Initialized
INFO - 2020-07-31 06:49:25 --> Language Class Initialized
INFO - 2020-07-31 06:49:25 --> Loader Class Initialized
INFO - 2020-07-31 06:49:25 --> Helper loaded: url_helper
INFO - 2020-07-31 06:49:25 --> Database Driver Class Initialized
INFO - 2020-07-31 06:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:49:25 --> Email Class Initialized
INFO - 2020-07-31 06:49:25 --> Controller Class Initialized
DEBUG - 2020-07-31 06:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:49:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:49:25 --> Model Class Initialized
INFO - 2020-07-31 06:49:25 --> Model Class Initialized
INFO - 2020-07-31 06:49:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 06:49:25 --> Final output sent to browser
DEBUG - 2020-07-31 06:49:25 --> Total execution time: 0.0267
INFO - 2020-07-31 06:49:32 --> Config Class Initialized
INFO - 2020-07-31 06:49:32 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:49:32 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:49:32 --> Utf8 Class Initialized
INFO - 2020-07-31 06:49:32 --> URI Class Initialized
INFO - 2020-07-31 06:49:32 --> Router Class Initialized
INFO - 2020-07-31 06:49:32 --> Output Class Initialized
INFO - 2020-07-31 06:49:32 --> Security Class Initialized
DEBUG - 2020-07-31 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:49:32 --> Input Class Initialized
INFO - 2020-07-31 06:49:32 --> Language Class Initialized
INFO - 2020-07-31 06:49:32 --> Loader Class Initialized
INFO - 2020-07-31 06:49:32 --> Helper loaded: url_helper
INFO - 2020-07-31 06:49:32 --> Database Driver Class Initialized
INFO - 2020-07-31 06:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:49:32 --> Email Class Initialized
INFO - 2020-07-31 06:49:32 --> Controller Class Initialized
DEBUG - 2020-07-31 06:49:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:49:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:49:32 --> Model Class Initialized
INFO - 2020-07-31 06:49:32 --> Model Class Initialized
INFO - 2020-07-31 06:49:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 06:49:32 --> Final output sent to browser
DEBUG - 2020-07-31 06:49:32 --> Total execution time: 0.0256
INFO - 2020-07-31 06:50:31 --> Config Class Initialized
INFO - 2020-07-31 06:50:31 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:50:31 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:50:31 --> Utf8 Class Initialized
INFO - 2020-07-31 06:50:31 --> URI Class Initialized
INFO - 2020-07-31 06:50:31 --> Router Class Initialized
INFO - 2020-07-31 06:50:31 --> Output Class Initialized
INFO - 2020-07-31 06:50:31 --> Security Class Initialized
DEBUG - 2020-07-31 06:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:50:31 --> Input Class Initialized
INFO - 2020-07-31 06:50:31 --> Language Class Initialized
INFO - 2020-07-31 06:50:31 --> Loader Class Initialized
INFO - 2020-07-31 06:50:31 --> Helper loaded: url_helper
INFO - 2020-07-31 06:50:31 --> Database Driver Class Initialized
INFO - 2020-07-31 06:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:50:31 --> Email Class Initialized
INFO - 2020-07-31 06:50:31 --> Controller Class Initialized
DEBUG - 2020-07-31 06:50:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:50:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:50:31 --> Model Class Initialized
INFO - 2020-07-31 06:50:31 --> Model Class Initialized
INFO - 2020-07-31 06:50:31 --> Model Class Initialized
ERROR - 2020-07-31 06:50:31 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL user_registration('souravpatra396@gmail.com','ratan de','1234445454','asfsdfsdgdg  ','c1da827c',2)
INFO - 2020-07-31 06:50:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-07-31 06:53:58 --> Config Class Initialized
INFO - 2020-07-31 06:53:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:53:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:53:58 --> Utf8 Class Initialized
INFO - 2020-07-31 06:53:58 --> URI Class Initialized
INFO - 2020-07-31 06:53:58 --> Router Class Initialized
INFO - 2020-07-31 06:53:58 --> Output Class Initialized
INFO - 2020-07-31 06:53:58 --> Security Class Initialized
DEBUG - 2020-07-31 06:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:53:58 --> Input Class Initialized
INFO - 2020-07-31 06:53:58 --> Language Class Initialized
INFO - 2020-07-31 06:53:58 --> Loader Class Initialized
INFO - 2020-07-31 06:53:58 --> Helper loaded: url_helper
INFO - 2020-07-31 06:53:58 --> Database Driver Class Initialized
INFO - 2020-07-31 06:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:53:58 --> Email Class Initialized
INFO - 2020-07-31 06:53:58 --> Controller Class Initialized
DEBUG - 2020-07-31 06:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:53:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:53:58 --> Model Class Initialized
INFO - 2020-07-31 06:53:58 --> Model Class Initialized
INFO - 2020-07-31 06:53:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 06:53:58 --> Final output sent to browser
DEBUG - 2020-07-31 06:53:58 --> Total execution time: 0.0246
INFO - 2020-07-31 06:54:03 --> Config Class Initialized
INFO - 2020-07-31 06:54:03 --> Hooks Class Initialized
DEBUG - 2020-07-31 06:54:03 --> UTF-8 Support Enabled
INFO - 2020-07-31 06:54:03 --> Utf8 Class Initialized
INFO - 2020-07-31 06:54:03 --> URI Class Initialized
INFO - 2020-07-31 06:54:03 --> Router Class Initialized
INFO - 2020-07-31 06:54:03 --> Output Class Initialized
INFO - 2020-07-31 06:54:03 --> Security Class Initialized
DEBUG - 2020-07-31 06:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 06:54:03 --> Input Class Initialized
INFO - 2020-07-31 06:54:03 --> Language Class Initialized
INFO - 2020-07-31 06:54:03 --> Loader Class Initialized
INFO - 2020-07-31 06:54:03 --> Helper loaded: url_helper
INFO - 2020-07-31 06:54:03 --> Database Driver Class Initialized
INFO - 2020-07-31 06:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 06:54:03 --> Email Class Initialized
INFO - 2020-07-31 06:54:03 --> Controller Class Initialized
DEBUG - 2020-07-31 06:54:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 06:54:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 06:54:03 --> Model Class Initialized
INFO - 2020-07-31 06:54:03 --> Model Class Initialized
INFO - 2020-07-31 06:54:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 06:54:03 --> Final output sent to browser
DEBUG - 2020-07-31 06:54:03 --> Total execution time: 0.0333
INFO - 2020-07-31 07:02:38 --> Config Class Initialized
INFO - 2020-07-31 07:02:38 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:02:38 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:02:38 --> Utf8 Class Initialized
INFO - 2020-07-31 07:02:38 --> URI Class Initialized
INFO - 2020-07-31 07:02:38 --> Router Class Initialized
INFO - 2020-07-31 07:02:38 --> Output Class Initialized
INFO - 2020-07-31 07:02:38 --> Security Class Initialized
DEBUG - 2020-07-31 07:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:02:38 --> Input Class Initialized
INFO - 2020-07-31 07:02:38 --> Language Class Initialized
INFO - 2020-07-31 07:02:38 --> Loader Class Initialized
INFO - 2020-07-31 07:02:38 --> Helper loaded: url_helper
INFO - 2020-07-31 07:02:38 --> Database Driver Class Initialized
INFO - 2020-07-31 07:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:02:38 --> Email Class Initialized
INFO - 2020-07-31 07:02:38 --> Controller Class Initialized
DEBUG - 2020-07-31 07:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:02:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:02:38 --> Model Class Initialized
INFO - 2020-07-31 07:02:38 --> Model Class Initialized
INFO - 2020-07-31 07:02:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-31 07:02:38 --> Final output sent to browser
DEBUG - 2020-07-31 07:02:38 --> Total execution time: 0.0770
INFO - 2020-07-31 07:02:42 --> Config Class Initialized
INFO - 2020-07-31 07:02:42 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:02:42 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:02:42 --> Utf8 Class Initialized
INFO - 2020-07-31 07:02:42 --> URI Class Initialized
INFO - 2020-07-31 07:02:42 --> Router Class Initialized
INFO - 2020-07-31 07:02:42 --> Output Class Initialized
INFO - 2020-07-31 07:02:42 --> Security Class Initialized
DEBUG - 2020-07-31 07:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:02:42 --> Input Class Initialized
INFO - 2020-07-31 07:02:42 --> Language Class Initialized
INFO - 2020-07-31 07:02:42 --> Loader Class Initialized
INFO - 2020-07-31 07:02:42 --> Helper loaded: url_helper
INFO - 2020-07-31 07:02:42 --> Database Driver Class Initialized
INFO - 2020-07-31 07:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:02:42 --> Email Class Initialized
INFO - 2020-07-31 07:02:42 --> Controller Class Initialized
DEBUG - 2020-07-31 07:02:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:02:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:02:42 --> Model Class Initialized
INFO - 2020-07-31 07:02:42 --> Model Class Initialized
INFO - 2020-07-31 07:02:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 07:02:42 --> Final output sent to browser
DEBUG - 2020-07-31 07:02:42 --> Total execution time: 0.0243
INFO - 2020-07-31 07:02:45 --> Config Class Initialized
INFO - 2020-07-31 07:02:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:02:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:02:45 --> Utf8 Class Initialized
INFO - 2020-07-31 07:02:45 --> URI Class Initialized
INFO - 2020-07-31 07:02:45 --> Router Class Initialized
INFO - 2020-07-31 07:02:45 --> Output Class Initialized
INFO - 2020-07-31 07:02:45 --> Security Class Initialized
DEBUG - 2020-07-31 07:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:02:45 --> Input Class Initialized
INFO - 2020-07-31 07:02:45 --> Language Class Initialized
INFO - 2020-07-31 07:02:45 --> Loader Class Initialized
INFO - 2020-07-31 07:02:45 --> Helper loaded: url_helper
INFO - 2020-07-31 07:02:45 --> Database Driver Class Initialized
INFO - 2020-07-31 07:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:02:45 --> Email Class Initialized
INFO - 2020-07-31 07:02:45 --> Controller Class Initialized
DEBUG - 2020-07-31 07:02:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:02:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:02:45 --> Model Class Initialized
INFO - 2020-07-31 07:02:45 --> Model Class Initialized
INFO - 2020-07-31 07:02:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-07-31 07:02:45 --> Final output sent to browser
DEBUG - 2020-07-31 07:02:45 --> Total execution time: 0.0261
INFO - 2020-07-31 07:02:54 --> Config Class Initialized
INFO - 2020-07-31 07:02:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:02:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:02:54 --> Utf8 Class Initialized
INFO - 2020-07-31 07:02:54 --> URI Class Initialized
INFO - 2020-07-31 07:02:54 --> Router Class Initialized
INFO - 2020-07-31 07:02:54 --> Output Class Initialized
INFO - 2020-07-31 07:02:54 --> Security Class Initialized
DEBUG - 2020-07-31 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:02:54 --> Input Class Initialized
INFO - 2020-07-31 07:02:54 --> Language Class Initialized
INFO - 2020-07-31 07:02:54 --> Loader Class Initialized
INFO - 2020-07-31 07:02:54 --> Helper loaded: url_helper
INFO - 2020-07-31 07:02:54 --> Database Driver Class Initialized
INFO - 2020-07-31 07:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:02:54 --> Email Class Initialized
INFO - 2020-07-31 07:02:54 --> Controller Class Initialized
DEBUG - 2020-07-31 07:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:02:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:02:54 --> Model Class Initialized
INFO - 2020-07-31 07:02:54 --> Model Class Initialized
INFO - 2020-07-31 07:02:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 07:02:54 --> Final output sent to browser
DEBUG - 2020-07-31 07:02:54 --> Total execution time: 0.0261
INFO - 2020-07-31 07:03:08 --> Config Class Initialized
INFO - 2020-07-31 07:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:03:08 --> Utf8 Class Initialized
INFO - 2020-07-31 07:03:08 --> URI Class Initialized
DEBUG - 2020-07-31 07:03:08 --> No URI present. Default controller set.
INFO - 2020-07-31 07:03:08 --> Router Class Initialized
INFO - 2020-07-31 07:03:08 --> Output Class Initialized
INFO - 2020-07-31 07:03:08 --> Security Class Initialized
DEBUG - 2020-07-31 07:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:03:08 --> Input Class Initialized
INFO - 2020-07-31 07:03:08 --> Language Class Initialized
INFO - 2020-07-31 07:03:08 --> Loader Class Initialized
INFO - 2020-07-31 07:03:08 --> Helper loaded: url_helper
INFO - 2020-07-31 07:03:08 --> Database Driver Class Initialized
INFO - 2020-07-31 07:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:03:08 --> Email Class Initialized
INFO - 2020-07-31 07:03:08 --> Controller Class Initialized
INFO - 2020-07-31 07:03:08 --> Model Class Initialized
INFO - 2020-07-31 07:03:08 --> Model Class Initialized
DEBUG - 2020-07-31 07:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:03:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 07:03:08 --> Final output sent to browser
DEBUG - 2020-07-31 07:03:08 --> Total execution time: 0.0618
INFO - 2020-07-31 07:15:47 --> Config Class Initialized
INFO - 2020-07-31 07:15:47 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:15:47 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:15:47 --> Utf8 Class Initialized
INFO - 2020-07-31 07:15:47 --> URI Class Initialized
INFO - 2020-07-31 07:15:47 --> Router Class Initialized
INFO - 2020-07-31 07:15:47 --> Output Class Initialized
INFO - 2020-07-31 07:15:47 --> Security Class Initialized
DEBUG - 2020-07-31 07:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:15:47 --> Input Class Initialized
INFO - 2020-07-31 07:15:47 --> Language Class Initialized
INFO - 2020-07-31 07:15:47 --> Loader Class Initialized
INFO - 2020-07-31 07:15:47 --> Helper loaded: url_helper
INFO - 2020-07-31 07:15:47 --> Database Driver Class Initialized
INFO - 2020-07-31 07:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:15:47 --> Email Class Initialized
INFO - 2020-07-31 07:15:47 --> Controller Class Initialized
INFO - 2020-07-31 07:15:47 --> Model Class Initialized
INFO - 2020-07-31 07:15:47 --> Model Class Initialized
DEBUG - 2020-07-31 07:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:15:47 --> Config Class Initialized
INFO - 2020-07-31 07:15:47 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:15:47 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:15:47 --> Utf8 Class Initialized
INFO - 2020-07-31 07:15:47 --> URI Class Initialized
INFO - 2020-07-31 07:15:47 --> Router Class Initialized
INFO - 2020-07-31 07:15:47 --> Output Class Initialized
INFO - 2020-07-31 07:15:47 --> Security Class Initialized
DEBUG - 2020-07-31 07:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:15:47 --> Input Class Initialized
INFO - 2020-07-31 07:15:47 --> Language Class Initialized
INFO - 2020-07-31 07:15:47 --> Loader Class Initialized
INFO - 2020-07-31 07:15:47 --> Helper loaded: url_helper
INFO - 2020-07-31 07:15:47 --> Database Driver Class Initialized
INFO - 2020-07-31 07:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:15:47 --> Email Class Initialized
INFO - 2020-07-31 07:15:47 --> Controller Class Initialized
DEBUG - 2020-07-31 07:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:15:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:15:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 07:15:47 --> Final output sent to browser
DEBUG - 2020-07-31 07:15:47 --> Total execution time: 0.0398
INFO - 2020-07-31 07:15:54 --> Config Class Initialized
INFO - 2020-07-31 07:15:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:15:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:15:54 --> Utf8 Class Initialized
INFO - 2020-07-31 07:15:54 --> URI Class Initialized
INFO - 2020-07-31 07:15:54 --> Router Class Initialized
INFO - 2020-07-31 07:15:54 --> Output Class Initialized
INFO - 2020-07-31 07:15:54 --> Security Class Initialized
DEBUG - 2020-07-31 07:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:15:54 --> Input Class Initialized
INFO - 2020-07-31 07:15:54 --> Language Class Initialized
INFO - 2020-07-31 07:15:54 --> Loader Class Initialized
INFO - 2020-07-31 07:15:54 --> Helper loaded: url_helper
INFO - 2020-07-31 07:15:54 --> Database Driver Class Initialized
INFO - 2020-07-31 07:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:15:54 --> Email Class Initialized
INFO - 2020-07-31 07:15:54 --> Controller Class Initialized
DEBUG - 2020-07-31 07:15:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:15:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:15:54 --> Model Class Initialized
INFO - 2020-07-31 07:15:54 --> Model Class Initialized
INFO - 2020-07-31 07:15:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 07:15:54 --> Final output sent to browser
DEBUG - 2020-07-31 07:15:54 --> Total execution time: 0.0206
INFO - 2020-07-31 07:15:59 --> Config Class Initialized
INFO - 2020-07-31 07:15:59 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:15:59 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:15:59 --> Utf8 Class Initialized
INFO - 2020-07-31 07:15:59 --> URI Class Initialized
INFO - 2020-07-31 07:15:59 --> Router Class Initialized
INFO - 2020-07-31 07:15:59 --> Output Class Initialized
INFO - 2020-07-31 07:15:59 --> Security Class Initialized
DEBUG - 2020-07-31 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:15:59 --> Input Class Initialized
INFO - 2020-07-31 07:15:59 --> Language Class Initialized
INFO - 2020-07-31 07:15:59 --> Loader Class Initialized
INFO - 2020-07-31 07:15:59 --> Helper loaded: url_helper
INFO - 2020-07-31 07:15:59 --> Database Driver Class Initialized
INFO - 2020-07-31 07:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:15:59 --> Email Class Initialized
INFO - 2020-07-31 07:15:59 --> Controller Class Initialized
DEBUG - 2020-07-31 07:15:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:15:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:15:59 --> Model Class Initialized
INFO - 2020-07-31 07:15:59 --> Model Class Initialized
INFO - 2020-07-31 07:15:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-07-31 07:15:59 --> Final output sent to browser
DEBUG - 2020-07-31 07:15:59 --> Total execution time: 0.0262
INFO - 2020-07-31 07:16:02 --> Config Class Initialized
INFO - 2020-07-31 07:16:02 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:16:02 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:16:02 --> Utf8 Class Initialized
INFO - 2020-07-31 07:16:02 --> URI Class Initialized
INFO - 2020-07-31 07:16:02 --> Router Class Initialized
INFO - 2020-07-31 07:16:02 --> Output Class Initialized
INFO - 2020-07-31 07:16:02 --> Security Class Initialized
DEBUG - 2020-07-31 07:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:16:02 --> Input Class Initialized
INFO - 2020-07-31 07:16:02 --> Language Class Initialized
INFO - 2020-07-31 07:16:02 --> Loader Class Initialized
INFO - 2020-07-31 07:16:02 --> Helper loaded: url_helper
INFO - 2020-07-31 07:16:02 --> Database Driver Class Initialized
INFO - 2020-07-31 07:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:16:02 --> Email Class Initialized
INFO - 2020-07-31 07:16:02 --> Controller Class Initialized
DEBUG - 2020-07-31 07:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:16:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:16:02 --> Model Class Initialized
INFO - 2020-07-31 07:16:02 --> Model Class Initialized
INFO - 2020-07-31 07:16:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 07:16:02 --> Final output sent to browser
DEBUG - 2020-07-31 07:16:02 --> Total execution time: 0.0260
INFO - 2020-07-31 07:18:50 --> Config Class Initialized
INFO - 2020-07-31 07:18:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:18:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:18:50 --> Utf8 Class Initialized
INFO - 2020-07-31 07:18:50 --> URI Class Initialized
DEBUG - 2020-07-31 07:18:50 --> No URI present. Default controller set.
INFO - 2020-07-31 07:18:50 --> Router Class Initialized
INFO - 2020-07-31 07:18:50 --> Output Class Initialized
INFO - 2020-07-31 07:18:50 --> Security Class Initialized
DEBUG - 2020-07-31 07:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:18:50 --> Input Class Initialized
INFO - 2020-07-31 07:18:50 --> Language Class Initialized
INFO - 2020-07-31 07:18:50 --> Loader Class Initialized
INFO - 2020-07-31 07:18:50 --> Helper loaded: url_helper
INFO - 2020-07-31 07:18:50 --> Database Driver Class Initialized
INFO - 2020-07-31 07:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:18:50 --> Email Class Initialized
INFO - 2020-07-31 07:18:50 --> Controller Class Initialized
INFO - 2020-07-31 07:18:50 --> Model Class Initialized
INFO - 2020-07-31 07:18:50 --> Model Class Initialized
DEBUG - 2020-07-31 07:18:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:18:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 07:18:50 --> Final output sent to browser
DEBUG - 2020-07-31 07:18:50 --> Total execution time: 0.0212
INFO - 2020-07-31 07:18:54 --> Config Class Initialized
INFO - 2020-07-31 07:18:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:18:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:18:54 --> Utf8 Class Initialized
INFO - 2020-07-31 07:18:54 --> URI Class Initialized
INFO - 2020-07-31 07:18:54 --> Router Class Initialized
INFO - 2020-07-31 07:18:54 --> Output Class Initialized
INFO - 2020-07-31 07:18:54 --> Security Class Initialized
DEBUG - 2020-07-31 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:18:54 --> Input Class Initialized
INFO - 2020-07-31 07:18:54 --> Language Class Initialized
INFO - 2020-07-31 07:18:54 --> Loader Class Initialized
INFO - 2020-07-31 07:18:54 --> Helper loaded: url_helper
INFO - 2020-07-31 07:18:54 --> Database Driver Class Initialized
INFO - 2020-07-31 07:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:18:54 --> Email Class Initialized
INFO - 2020-07-31 07:18:54 --> Controller Class Initialized
INFO - 2020-07-31 07:18:54 --> Model Class Initialized
INFO - 2020-07-31 07:18:54 --> Model Class Initialized
DEBUG - 2020-07-31 07:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 07:18:54 --> Final output sent to browser
DEBUG - 2020-07-31 07:18:54 --> Total execution time: 0.0424
INFO - 2020-07-31 07:20:20 --> Config Class Initialized
INFO - 2020-07-31 07:20:20 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:20:20 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:20:20 --> Utf8 Class Initialized
INFO - 2020-07-31 07:20:20 --> URI Class Initialized
DEBUG - 2020-07-31 07:20:20 --> No URI present. Default controller set.
INFO - 2020-07-31 07:20:20 --> Router Class Initialized
INFO - 2020-07-31 07:20:20 --> Output Class Initialized
INFO - 2020-07-31 07:20:20 --> Security Class Initialized
DEBUG - 2020-07-31 07:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:20:20 --> Input Class Initialized
INFO - 2020-07-31 07:20:20 --> Language Class Initialized
INFO - 2020-07-31 07:20:20 --> Loader Class Initialized
INFO - 2020-07-31 07:20:20 --> Helper loaded: url_helper
INFO - 2020-07-31 07:20:20 --> Database Driver Class Initialized
INFO - 2020-07-31 07:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:20:20 --> Email Class Initialized
INFO - 2020-07-31 07:20:20 --> Controller Class Initialized
INFO - 2020-07-31 07:20:20 --> Model Class Initialized
INFO - 2020-07-31 07:20:20 --> Model Class Initialized
DEBUG - 2020-07-31 07:20:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:20:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 07:20:20 --> Final output sent to browser
DEBUG - 2020-07-31 07:20:20 --> Total execution time: 0.0237
INFO - 2020-07-31 07:24:23 --> Config Class Initialized
INFO - 2020-07-31 07:24:23 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:24:23 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:24:23 --> Utf8 Class Initialized
INFO - 2020-07-31 07:24:23 --> URI Class Initialized
INFO - 2020-07-31 07:24:23 --> Router Class Initialized
INFO - 2020-07-31 07:24:23 --> Output Class Initialized
INFO - 2020-07-31 07:24:23 --> Security Class Initialized
DEBUG - 2020-07-31 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:24:23 --> Input Class Initialized
INFO - 2020-07-31 07:24:23 --> Language Class Initialized
INFO - 2020-07-31 07:24:23 --> Loader Class Initialized
INFO - 2020-07-31 07:24:23 --> Helper loaded: url_helper
INFO - 2020-07-31 07:24:23 --> Database Driver Class Initialized
INFO - 2020-07-31 07:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:24:23 --> Email Class Initialized
INFO - 2020-07-31 07:24:23 --> Controller Class Initialized
INFO - 2020-07-31 07:24:23 --> Model Class Initialized
INFO - 2020-07-31 07:24:23 --> Model Class Initialized
DEBUG - 2020-07-31 07:24:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:24:23 --> Config Class Initialized
INFO - 2020-07-31 07:24:23 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:24:23 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:24:23 --> Utf8 Class Initialized
INFO - 2020-07-31 07:24:23 --> URI Class Initialized
INFO - 2020-07-31 07:24:23 --> Router Class Initialized
INFO - 2020-07-31 07:24:23 --> Output Class Initialized
INFO - 2020-07-31 07:24:23 --> Security Class Initialized
DEBUG - 2020-07-31 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:24:23 --> Input Class Initialized
INFO - 2020-07-31 07:24:23 --> Language Class Initialized
INFO - 2020-07-31 07:24:23 --> Loader Class Initialized
INFO - 2020-07-31 07:24:23 --> Helper loaded: url_helper
INFO - 2020-07-31 07:24:23 --> Database Driver Class Initialized
INFO - 2020-07-31 07:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:24:23 --> Email Class Initialized
INFO - 2020-07-31 07:24:23 --> Controller Class Initialized
DEBUG - 2020-07-31 07:24:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:24:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:24:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 07:24:23 --> Final output sent to browser
DEBUG - 2020-07-31 07:24:23 --> Total execution time: 0.0227
INFO - 2020-07-31 07:24:27 --> Config Class Initialized
INFO - 2020-07-31 07:24:27 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:24:27 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:24:27 --> Utf8 Class Initialized
INFO - 2020-07-31 07:24:27 --> URI Class Initialized
INFO - 2020-07-31 07:24:27 --> Router Class Initialized
INFO - 2020-07-31 07:24:27 --> Output Class Initialized
INFO - 2020-07-31 07:24:27 --> Security Class Initialized
DEBUG - 2020-07-31 07:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:24:27 --> Input Class Initialized
INFO - 2020-07-31 07:24:27 --> Language Class Initialized
INFO - 2020-07-31 07:24:27 --> Loader Class Initialized
INFO - 2020-07-31 07:24:27 --> Helper loaded: url_helper
INFO - 2020-07-31 07:24:27 --> Database Driver Class Initialized
INFO - 2020-07-31 07:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:24:27 --> Email Class Initialized
INFO - 2020-07-31 07:24:27 --> Controller Class Initialized
DEBUG - 2020-07-31 07:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:24:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:24:27 --> Model Class Initialized
INFO - 2020-07-31 07:24:27 --> Model Class Initialized
INFO - 2020-07-31 07:24:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 07:24:27 --> Final output sent to browser
DEBUG - 2020-07-31 07:24:27 --> Total execution time: 0.0330
INFO - 2020-07-31 07:24:29 --> Config Class Initialized
INFO - 2020-07-31 07:24:29 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:24:29 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:24:29 --> Utf8 Class Initialized
INFO - 2020-07-31 07:24:29 --> URI Class Initialized
INFO - 2020-07-31 07:24:29 --> Router Class Initialized
INFO - 2020-07-31 07:24:29 --> Output Class Initialized
INFO - 2020-07-31 07:24:29 --> Security Class Initialized
DEBUG - 2020-07-31 07:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:24:29 --> Input Class Initialized
INFO - 2020-07-31 07:24:29 --> Language Class Initialized
INFO - 2020-07-31 07:24:29 --> Loader Class Initialized
INFO - 2020-07-31 07:24:29 --> Helper loaded: url_helper
INFO - 2020-07-31 07:24:29 --> Database Driver Class Initialized
INFO - 2020-07-31 07:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:24:29 --> Email Class Initialized
INFO - 2020-07-31 07:24:29 --> Controller Class Initialized
DEBUG - 2020-07-31 07:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:24:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:24:29 --> Model Class Initialized
INFO - 2020-07-31 07:24:29 --> Model Class Initialized
INFO - 2020-07-31 07:24:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 07:24:29 --> Final output sent to browser
DEBUG - 2020-07-31 07:24:29 --> Total execution time: 0.0236
INFO - 2020-07-31 07:28:26 --> Config Class Initialized
INFO - 2020-07-31 07:28:26 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:28:26 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:28:26 --> Utf8 Class Initialized
INFO - 2020-07-31 07:28:26 --> URI Class Initialized
INFO - 2020-07-31 07:28:26 --> Router Class Initialized
INFO - 2020-07-31 07:28:26 --> Output Class Initialized
INFO - 2020-07-31 07:28:26 --> Security Class Initialized
DEBUG - 2020-07-31 07:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:28:26 --> Input Class Initialized
INFO - 2020-07-31 07:28:26 --> Language Class Initialized
INFO - 2020-07-31 07:28:26 --> Loader Class Initialized
INFO - 2020-07-31 07:28:26 --> Helper loaded: url_helper
INFO - 2020-07-31 07:28:26 --> Database Driver Class Initialized
INFO - 2020-07-31 07:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:28:26 --> Email Class Initialized
INFO - 2020-07-31 07:28:26 --> Controller Class Initialized
DEBUG - 2020-07-31 07:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 07:28:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:28:26 --> Model Class Initialized
INFO - 2020-07-31 07:28:26 --> Model Class Initialized
INFO - 2020-07-31 07:28:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 07:28:26 --> Final output sent to browser
DEBUG - 2020-07-31 07:28:26 --> Total execution time: 0.0254
INFO - 2020-07-31 07:29:19 --> Config Class Initialized
INFO - 2020-07-31 07:29:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 07:29:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 07:29:19 --> Utf8 Class Initialized
INFO - 2020-07-31 07:29:19 --> URI Class Initialized
DEBUG - 2020-07-31 07:29:19 --> No URI present. Default controller set.
INFO - 2020-07-31 07:29:19 --> Router Class Initialized
INFO - 2020-07-31 07:29:19 --> Output Class Initialized
INFO - 2020-07-31 07:29:19 --> Security Class Initialized
DEBUG - 2020-07-31 07:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 07:29:19 --> Input Class Initialized
INFO - 2020-07-31 07:29:19 --> Language Class Initialized
INFO - 2020-07-31 07:29:19 --> Loader Class Initialized
INFO - 2020-07-31 07:29:19 --> Helper loaded: url_helper
INFO - 2020-07-31 07:29:19 --> Database Driver Class Initialized
INFO - 2020-07-31 07:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 07:29:19 --> Email Class Initialized
INFO - 2020-07-31 07:29:19 --> Controller Class Initialized
INFO - 2020-07-31 07:29:19 --> Model Class Initialized
INFO - 2020-07-31 07:29:19 --> Model Class Initialized
DEBUG - 2020-07-31 07:29:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 07:29:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 07:29:19 --> Final output sent to browser
DEBUG - 2020-07-31 07:29:19 --> Total execution time: 0.0233
INFO - 2020-07-31 08:01:51 --> Config Class Initialized
INFO - 2020-07-31 08:01:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:01:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:01:51 --> Utf8 Class Initialized
INFO - 2020-07-31 08:01:51 --> URI Class Initialized
INFO - 2020-07-31 08:01:51 --> Router Class Initialized
INFO - 2020-07-31 08:01:51 --> Output Class Initialized
INFO - 2020-07-31 08:01:51 --> Security Class Initialized
DEBUG - 2020-07-31 08:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:01:51 --> Input Class Initialized
INFO - 2020-07-31 08:01:51 --> Language Class Initialized
INFO - 2020-07-31 08:01:51 --> Loader Class Initialized
INFO - 2020-07-31 08:01:51 --> Helper loaded: url_helper
INFO - 2020-07-31 08:01:51 --> Database Driver Class Initialized
INFO - 2020-07-31 08:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:01:51 --> Email Class Initialized
INFO - 2020-07-31 08:01:51 --> Controller Class Initialized
DEBUG - 2020-07-31 08:01:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:01:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:01:51 --> Model Class Initialized
INFO - 2020-07-31 08:01:51 --> Model Class Initialized
INFO - 2020-07-31 08:01:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 08:01:51 --> Final output sent to browser
DEBUG - 2020-07-31 08:01:51 --> Total execution time: 0.0223
INFO - 2020-07-31 08:01:55 --> Config Class Initialized
INFO - 2020-07-31 08:01:55 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:01:55 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:01:55 --> Utf8 Class Initialized
INFO - 2020-07-31 08:01:55 --> URI Class Initialized
INFO - 2020-07-31 08:01:55 --> Router Class Initialized
INFO - 2020-07-31 08:01:55 --> Output Class Initialized
INFO - 2020-07-31 08:01:55 --> Security Class Initialized
DEBUG - 2020-07-31 08:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:01:55 --> Input Class Initialized
INFO - 2020-07-31 08:01:55 --> Language Class Initialized
INFO - 2020-07-31 08:01:55 --> Loader Class Initialized
INFO - 2020-07-31 08:01:55 --> Helper loaded: url_helper
INFO - 2020-07-31 08:01:55 --> Database Driver Class Initialized
INFO - 2020-07-31 08:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:01:55 --> Email Class Initialized
INFO - 2020-07-31 08:01:55 --> Controller Class Initialized
DEBUG - 2020-07-31 08:01:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:01:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:01:55 --> Model Class Initialized
INFO - 2020-07-31 08:01:55 --> Model Class Initialized
INFO - 2020-07-31 08:01:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 08:01:55 --> Final output sent to browser
DEBUG - 2020-07-31 08:01:55 --> Total execution time: 0.0252
INFO - 2020-07-31 08:01:57 --> Config Class Initialized
INFO - 2020-07-31 08:01:57 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:01:57 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:01:57 --> Utf8 Class Initialized
INFO - 2020-07-31 08:01:57 --> URI Class Initialized
DEBUG - 2020-07-31 08:01:57 --> No URI present. Default controller set.
INFO - 2020-07-31 08:01:57 --> Router Class Initialized
INFO - 2020-07-31 08:01:57 --> Output Class Initialized
INFO - 2020-07-31 08:01:57 --> Security Class Initialized
DEBUG - 2020-07-31 08:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:01:57 --> Input Class Initialized
INFO - 2020-07-31 08:01:57 --> Language Class Initialized
INFO - 2020-07-31 08:01:57 --> Loader Class Initialized
INFO - 2020-07-31 08:01:57 --> Helper loaded: url_helper
INFO - 2020-07-31 08:01:57 --> Database Driver Class Initialized
INFO - 2020-07-31 08:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:01:57 --> Email Class Initialized
INFO - 2020-07-31 08:01:57 --> Controller Class Initialized
INFO - 2020-07-31 08:01:57 --> Model Class Initialized
INFO - 2020-07-31 08:01:57 --> Model Class Initialized
DEBUG - 2020-07-31 08:01:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:01:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:01:57 --> Final output sent to browser
DEBUG - 2020-07-31 08:01:57 --> Total execution time: 0.0232
INFO - 2020-07-31 08:03:45 --> Config Class Initialized
INFO - 2020-07-31 08:03:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:03:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:03:45 --> Utf8 Class Initialized
INFO - 2020-07-31 08:03:45 --> URI Class Initialized
INFO - 2020-07-31 08:03:45 --> Router Class Initialized
INFO - 2020-07-31 08:03:45 --> Output Class Initialized
INFO - 2020-07-31 08:03:45 --> Security Class Initialized
DEBUG - 2020-07-31 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:03:45 --> Input Class Initialized
INFO - 2020-07-31 08:03:45 --> Language Class Initialized
INFO - 2020-07-31 08:03:45 --> Loader Class Initialized
INFO - 2020-07-31 08:03:45 --> Helper loaded: url_helper
INFO - 2020-07-31 08:03:45 --> Database Driver Class Initialized
INFO - 2020-07-31 08:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:03:45 --> Email Class Initialized
INFO - 2020-07-31 08:03:45 --> Controller Class Initialized
INFO - 2020-07-31 08:03:45 --> Model Class Initialized
INFO - 2020-07-31 08:03:45 --> Model Class Initialized
DEBUG - 2020-07-31 08:03:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:03:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:03:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:03:45 --> Final output sent to browser
DEBUG - 2020-07-31 08:03:45 --> Total execution time: 0.0250
INFO - 2020-07-31 08:03:59 --> Config Class Initialized
INFO - 2020-07-31 08:03:59 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:03:59 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:03:59 --> Utf8 Class Initialized
INFO - 2020-07-31 08:03:59 --> URI Class Initialized
INFO - 2020-07-31 08:03:59 --> Router Class Initialized
INFO - 2020-07-31 08:03:59 --> Output Class Initialized
INFO - 2020-07-31 08:03:59 --> Security Class Initialized
DEBUG - 2020-07-31 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:03:59 --> Input Class Initialized
INFO - 2020-07-31 08:03:59 --> Language Class Initialized
INFO - 2020-07-31 08:03:59 --> Loader Class Initialized
INFO - 2020-07-31 08:03:59 --> Helper loaded: url_helper
INFO - 2020-07-31 08:03:59 --> Database Driver Class Initialized
INFO - 2020-07-31 08:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:03:59 --> Email Class Initialized
INFO - 2020-07-31 08:03:59 --> Controller Class Initialized
INFO - 2020-07-31 08:03:59 --> Model Class Initialized
INFO - 2020-07-31 08:03:59 --> Model Class Initialized
DEBUG - 2020-07-31 08:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:03:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:03:59 --> Model Class Initialized
INFO - 2020-07-31 08:03:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:03:59 --> Final output sent to browser
DEBUG - 2020-07-31 08:03:59 --> Total execution time: 0.0639
INFO - 2020-07-31 08:04:25 --> Config Class Initialized
INFO - 2020-07-31 08:04:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:04:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:04:25 --> Utf8 Class Initialized
INFO - 2020-07-31 08:04:25 --> URI Class Initialized
INFO - 2020-07-31 08:04:25 --> Router Class Initialized
INFO - 2020-07-31 08:04:25 --> Output Class Initialized
INFO - 2020-07-31 08:04:25 --> Security Class Initialized
DEBUG - 2020-07-31 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:04:25 --> Input Class Initialized
INFO - 2020-07-31 08:04:25 --> Language Class Initialized
INFO - 2020-07-31 08:04:25 --> Loader Class Initialized
INFO - 2020-07-31 08:04:25 --> Helper loaded: url_helper
INFO - 2020-07-31 08:04:25 --> Database Driver Class Initialized
INFO - 2020-07-31 08:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:04:25 --> Email Class Initialized
INFO - 2020-07-31 08:04:25 --> Controller Class Initialized
INFO - 2020-07-31 08:04:25 --> Model Class Initialized
INFO - 2020-07-31 08:04:25 --> Model Class Initialized
DEBUG - 2020-07-31 08:04:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:04:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:04:25 --> Config Class Initialized
INFO - 2020-07-31 08:04:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:04:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:04:25 --> Utf8 Class Initialized
INFO - 2020-07-31 08:04:25 --> URI Class Initialized
DEBUG - 2020-07-31 08:04:25 --> No URI present. Default controller set.
INFO - 2020-07-31 08:04:25 --> Router Class Initialized
INFO - 2020-07-31 08:04:25 --> Output Class Initialized
INFO - 2020-07-31 08:04:25 --> Security Class Initialized
DEBUG - 2020-07-31 08:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:04:25 --> Input Class Initialized
INFO - 2020-07-31 08:04:25 --> Language Class Initialized
INFO - 2020-07-31 08:04:25 --> Loader Class Initialized
INFO - 2020-07-31 08:04:25 --> Helper loaded: url_helper
INFO - 2020-07-31 08:04:25 --> Database Driver Class Initialized
INFO - 2020-07-31 08:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:04:25 --> Email Class Initialized
INFO - 2020-07-31 08:04:25 --> Controller Class Initialized
INFO - 2020-07-31 08:04:25 --> Model Class Initialized
INFO - 2020-07-31 08:04:25 --> Model Class Initialized
DEBUG - 2020-07-31 08:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:04:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:04:25 --> Final output sent to browser
DEBUG - 2020-07-31 08:04:25 --> Total execution time: 0.0216
INFO - 2020-07-31 08:04:35 --> Config Class Initialized
INFO - 2020-07-31 08:04:35 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:04:35 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:04:35 --> Utf8 Class Initialized
INFO - 2020-07-31 08:04:35 --> URI Class Initialized
INFO - 2020-07-31 08:04:35 --> Router Class Initialized
INFO - 2020-07-31 08:04:35 --> Output Class Initialized
INFO - 2020-07-31 08:04:35 --> Security Class Initialized
DEBUG - 2020-07-31 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:04:35 --> Input Class Initialized
INFO - 2020-07-31 08:04:35 --> Language Class Initialized
INFO - 2020-07-31 08:04:35 --> Loader Class Initialized
INFO - 2020-07-31 08:04:35 --> Helper loaded: url_helper
INFO - 2020-07-31 08:04:35 --> Database Driver Class Initialized
INFO - 2020-07-31 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:04:35 --> Email Class Initialized
INFO - 2020-07-31 08:04:35 --> Controller Class Initialized
INFO - 2020-07-31 08:04:35 --> Model Class Initialized
INFO - 2020-07-31 08:04:35 --> Model Class Initialized
DEBUG - 2020-07-31 08:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:04:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:04:36 --> Config Class Initialized
INFO - 2020-07-31 08:04:36 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:04:36 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:04:36 --> Utf8 Class Initialized
INFO - 2020-07-31 08:04:36 --> URI Class Initialized
DEBUG - 2020-07-31 08:04:36 --> No URI present. Default controller set.
INFO - 2020-07-31 08:04:36 --> Router Class Initialized
INFO - 2020-07-31 08:04:36 --> Output Class Initialized
INFO - 2020-07-31 08:04:36 --> Security Class Initialized
DEBUG - 2020-07-31 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:04:36 --> Input Class Initialized
INFO - 2020-07-31 08:04:36 --> Language Class Initialized
INFO - 2020-07-31 08:04:36 --> Loader Class Initialized
INFO - 2020-07-31 08:04:36 --> Helper loaded: url_helper
INFO - 2020-07-31 08:04:36 --> Database Driver Class Initialized
INFO - 2020-07-31 08:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:04:36 --> Email Class Initialized
INFO - 2020-07-31 08:04:36 --> Controller Class Initialized
INFO - 2020-07-31 08:04:36 --> Model Class Initialized
INFO - 2020-07-31 08:04:36 --> Model Class Initialized
DEBUG - 2020-07-31 08:04:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:04:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:04:36 --> Final output sent to browser
DEBUG - 2020-07-31 08:04:36 --> Total execution time: 0.0235
INFO - 2020-07-31 08:14:38 --> Config Class Initialized
INFO - 2020-07-31 08:14:38 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:14:38 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:14:38 --> Utf8 Class Initialized
INFO - 2020-07-31 08:14:38 --> URI Class Initialized
DEBUG - 2020-07-31 08:14:38 --> No URI present. Default controller set.
INFO - 2020-07-31 08:14:38 --> Router Class Initialized
INFO - 2020-07-31 08:14:38 --> Output Class Initialized
INFO - 2020-07-31 08:14:38 --> Security Class Initialized
DEBUG - 2020-07-31 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:14:38 --> Input Class Initialized
INFO - 2020-07-31 08:14:38 --> Language Class Initialized
INFO - 2020-07-31 08:14:38 --> Loader Class Initialized
INFO - 2020-07-31 08:14:38 --> Helper loaded: url_helper
INFO - 2020-07-31 08:14:38 --> Database Driver Class Initialized
INFO - 2020-07-31 08:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:14:38 --> Email Class Initialized
INFO - 2020-07-31 08:14:38 --> Controller Class Initialized
INFO - 2020-07-31 08:14:38 --> Model Class Initialized
INFO - 2020-07-31 08:14:38 --> Model Class Initialized
DEBUG - 2020-07-31 08:14:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:14:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:14:38 --> Final output sent to browser
DEBUG - 2020-07-31 08:14:38 --> Total execution time: 0.0229
INFO - 2020-07-31 08:17:58 --> Config Class Initialized
INFO - 2020-07-31 08:17:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:17:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:17:58 --> Utf8 Class Initialized
INFO - 2020-07-31 08:17:58 --> URI Class Initialized
INFO - 2020-07-31 08:17:58 --> Router Class Initialized
INFO - 2020-07-31 08:17:58 --> Output Class Initialized
INFO - 2020-07-31 08:17:58 --> Security Class Initialized
DEBUG - 2020-07-31 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:17:58 --> Input Class Initialized
INFO - 2020-07-31 08:17:58 --> Language Class Initialized
INFO - 2020-07-31 08:17:58 --> Loader Class Initialized
INFO - 2020-07-31 08:17:58 --> Helper loaded: url_helper
INFO - 2020-07-31 08:17:58 --> Database Driver Class Initialized
INFO - 2020-07-31 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:17:58 --> Email Class Initialized
INFO - 2020-07-31 08:17:58 --> Controller Class Initialized
INFO - 2020-07-31 08:17:58 --> Model Class Initialized
INFO - 2020-07-31 08:17:58 --> Model Class Initialized
DEBUG - 2020-07-31 08:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:17:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:17:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:17:58 --> Final output sent to browser
DEBUG - 2020-07-31 08:17:58 --> Total execution time: 0.0206
INFO - 2020-07-31 08:20:17 --> Config Class Initialized
INFO - 2020-07-31 08:20:17 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:20:17 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:20:17 --> Utf8 Class Initialized
INFO - 2020-07-31 08:20:17 --> URI Class Initialized
INFO - 2020-07-31 08:20:17 --> Router Class Initialized
INFO - 2020-07-31 08:20:17 --> Output Class Initialized
INFO - 2020-07-31 08:20:17 --> Security Class Initialized
DEBUG - 2020-07-31 08:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:20:17 --> Input Class Initialized
INFO - 2020-07-31 08:20:17 --> Language Class Initialized
INFO - 2020-07-31 08:20:17 --> Loader Class Initialized
INFO - 2020-07-31 08:20:17 --> Helper loaded: url_helper
INFO - 2020-07-31 08:20:17 --> Database Driver Class Initialized
INFO - 2020-07-31 08:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:20:17 --> Email Class Initialized
INFO - 2020-07-31 08:20:17 --> Controller Class Initialized
INFO - 2020-07-31 08:20:17 --> Model Class Initialized
INFO - 2020-07-31 08:20:17 --> Model Class Initialized
DEBUG - 2020-07-31 08:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:20:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:20:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:20:17 --> Final output sent to browser
DEBUG - 2020-07-31 08:20:17 --> Total execution time: 0.0254
INFO - 2020-07-31 08:21:41 --> Config Class Initialized
INFO - 2020-07-31 08:21:41 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:21:41 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:21:41 --> Utf8 Class Initialized
INFO - 2020-07-31 08:21:41 --> URI Class Initialized
INFO - 2020-07-31 08:21:41 --> Router Class Initialized
INFO - 2020-07-31 08:21:41 --> Output Class Initialized
INFO - 2020-07-31 08:21:41 --> Security Class Initialized
DEBUG - 2020-07-31 08:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:21:41 --> Input Class Initialized
INFO - 2020-07-31 08:21:41 --> Language Class Initialized
INFO - 2020-07-31 08:21:41 --> Loader Class Initialized
INFO - 2020-07-31 08:21:41 --> Helper loaded: url_helper
INFO - 2020-07-31 08:21:41 --> Database Driver Class Initialized
INFO - 2020-07-31 08:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:21:41 --> Email Class Initialized
INFO - 2020-07-31 08:21:41 --> Controller Class Initialized
INFO - 2020-07-31 08:21:41 --> Model Class Initialized
INFO - 2020-07-31 08:21:41 --> Model Class Initialized
DEBUG - 2020-07-31 08:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:21:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:21:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:21:41 --> Final output sent to browser
DEBUG - 2020-07-31 08:21:41 --> Total execution time: 0.0248
INFO - 2020-07-31 08:36:27 --> Config Class Initialized
INFO - 2020-07-31 08:36:27 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:36:27 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:36:27 --> Utf8 Class Initialized
INFO - 2020-07-31 08:36:27 --> URI Class Initialized
INFO - 2020-07-31 08:36:27 --> Router Class Initialized
INFO - 2020-07-31 08:36:27 --> Output Class Initialized
INFO - 2020-07-31 08:36:27 --> Security Class Initialized
DEBUG - 2020-07-31 08:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:36:27 --> Input Class Initialized
INFO - 2020-07-31 08:36:27 --> Language Class Initialized
INFO - 2020-07-31 08:36:27 --> Loader Class Initialized
INFO - 2020-07-31 08:36:27 --> Helper loaded: url_helper
INFO - 2020-07-31 08:36:27 --> Database Driver Class Initialized
INFO - 2020-07-31 08:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:36:27 --> Email Class Initialized
INFO - 2020-07-31 08:36:27 --> Controller Class Initialized
INFO - 2020-07-31 08:36:27 --> Model Class Initialized
INFO - 2020-07-31 08:36:27 --> Model Class Initialized
DEBUG - 2020-07-31 08:36:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:36:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:36:27 --> Model Class Initialized
INFO - 2020-07-31 08:36:27 --> Final output sent to browser
DEBUG - 2020-07-31 08:36:27 --> Total execution time: 0.0727
INFO - 2020-07-31 08:36:57 --> Config Class Initialized
INFO - 2020-07-31 08:36:57 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:36:57 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:36:57 --> Utf8 Class Initialized
INFO - 2020-07-31 08:36:57 --> URI Class Initialized
INFO - 2020-07-31 08:36:57 --> Router Class Initialized
INFO - 2020-07-31 08:36:57 --> Output Class Initialized
INFO - 2020-07-31 08:36:57 --> Security Class Initialized
DEBUG - 2020-07-31 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:36:57 --> Input Class Initialized
INFO - 2020-07-31 08:36:57 --> Language Class Initialized
INFO - 2020-07-31 08:36:57 --> Loader Class Initialized
INFO - 2020-07-31 08:36:57 --> Helper loaded: url_helper
INFO - 2020-07-31 08:36:57 --> Database Driver Class Initialized
INFO - 2020-07-31 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:36:57 --> Email Class Initialized
INFO - 2020-07-31 08:36:57 --> Controller Class Initialized
INFO - 2020-07-31 08:36:57 --> Model Class Initialized
INFO - 2020-07-31 08:36:57 --> Model Class Initialized
DEBUG - 2020-07-31 08:36:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:36:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:36:57 --> Config Class Initialized
INFO - 2020-07-31 08:36:57 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:36:57 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:36:57 --> Utf8 Class Initialized
INFO - 2020-07-31 08:36:57 --> URI Class Initialized
DEBUG - 2020-07-31 08:36:57 --> No URI present. Default controller set.
INFO - 2020-07-31 08:36:57 --> Router Class Initialized
INFO - 2020-07-31 08:36:57 --> Output Class Initialized
INFO - 2020-07-31 08:36:57 --> Security Class Initialized
DEBUG - 2020-07-31 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:36:57 --> Input Class Initialized
INFO - 2020-07-31 08:36:57 --> Language Class Initialized
INFO - 2020-07-31 08:36:57 --> Loader Class Initialized
INFO - 2020-07-31 08:36:57 --> Helper loaded: url_helper
INFO - 2020-07-31 08:36:57 --> Database Driver Class Initialized
INFO - 2020-07-31 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:36:57 --> Email Class Initialized
INFO - 2020-07-31 08:36:57 --> Controller Class Initialized
INFO - 2020-07-31 08:36:57 --> Model Class Initialized
INFO - 2020-07-31 08:36:57 --> Model Class Initialized
DEBUG - 2020-07-31 08:36:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:36:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:36:57 --> Final output sent to browser
DEBUG - 2020-07-31 08:36:57 --> Total execution time: 0.0217
INFO - 2020-07-31 08:37:03 --> Config Class Initialized
INFO - 2020-07-31 08:37:03 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:37:03 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:37:03 --> Utf8 Class Initialized
INFO - 2020-07-31 08:37:03 --> URI Class Initialized
INFO - 2020-07-31 08:37:03 --> Router Class Initialized
INFO - 2020-07-31 08:37:03 --> Output Class Initialized
INFO - 2020-07-31 08:37:03 --> Security Class Initialized
DEBUG - 2020-07-31 08:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:37:03 --> Input Class Initialized
INFO - 2020-07-31 08:37:03 --> Language Class Initialized
INFO - 2020-07-31 08:37:03 --> Loader Class Initialized
INFO - 2020-07-31 08:37:03 --> Helper loaded: url_helper
INFO - 2020-07-31 08:37:03 --> Database Driver Class Initialized
INFO - 2020-07-31 08:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:37:03 --> Email Class Initialized
INFO - 2020-07-31 08:37:03 --> Controller Class Initialized
INFO - 2020-07-31 08:37:03 --> Model Class Initialized
INFO - 2020-07-31 08:37:03 --> Model Class Initialized
DEBUG - 2020-07-31 08:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:37:05 --> Config Class Initialized
INFO - 2020-07-31 08:37:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:37:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:37:05 --> Utf8 Class Initialized
INFO - 2020-07-31 08:37:05 --> URI Class Initialized
DEBUG - 2020-07-31 08:37:05 --> No URI present. Default controller set.
INFO - 2020-07-31 08:37:05 --> Router Class Initialized
INFO - 2020-07-31 08:37:05 --> Output Class Initialized
INFO - 2020-07-31 08:37:05 --> Security Class Initialized
DEBUG - 2020-07-31 08:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:37:05 --> Input Class Initialized
INFO - 2020-07-31 08:37:05 --> Language Class Initialized
INFO - 2020-07-31 08:37:05 --> Loader Class Initialized
INFO - 2020-07-31 08:37:05 --> Helper loaded: url_helper
INFO - 2020-07-31 08:37:05 --> Database Driver Class Initialized
INFO - 2020-07-31 08:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:37:05 --> Email Class Initialized
INFO - 2020-07-31 08:37:05 --> Controller Class Initialized
INFO - 2020-07-31 08:37:05 --> Model Class Initialized
INFO - 2020-07-31 08:37:05 --> Model Class Initialized
DEBUG - 2020-07-31 08:37:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:37:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:37:05 --> Final output sent to browser
DEBUG - 2020-07-31 08:37:05 --> Total execution time: 0.0224
INFO - 2020-07-31 08:37:35 --> Config Class Initialized
INFO - 2020-07-31 08:37:35 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:37:35 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:37:35 --> Utf8 Class Initialized
INFO - 2020-07-31 08:37:35 --> URI Class Initialized
INFO - 2020-07-31 08:37:35 --> Router Class Initialized
INFO - 2020-07-31 08:37:35 --> Output Class Initialized
INFO - 2020-07-31 08:37:35 --> Security Class Initialized
DEBUG - 2020-07-31 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:37:35 --> Input Class Initialized
INFO - 2020-07-31 08:37:35 --> Language Class Initialized
INFO - 2020-07-31 08:37:35 --> Loader Class Initialized
INFO - 2020-07-31 08:37:35 --> Helper loaded: url_helper
INFO - 2020-07-31 08:37:35 --> Database Driver Class Initialized
INFO - 2020-07-31 08:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:37:35 --> Email Class Initialized
INFO - 2020-07-31 08:37:35 --> Controller Class Initialized
INFO - 2020-07-31 08:37:35 --> Model Class Initialized
INFO - 2020-07-31 08:37:35 --> Model Class Initialized
DEBUG - 2020-07-31 08:37:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:37:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:37:35 --> Config Class Initialized
INFO - 2020-07-31 08:37:35 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:37:35 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:37:35 --> Utf8 Class Initialized
INFO - 2020-07-31 08:37:35 --> URI Class Initialized
DEBUG - 2020-07-31 08:37:35 --> No URI present. Default controller set.
INFO - 2020-07-31 08:37:35 --> Router Class Initialized
INFO - 2020-07-31 08:37:35 --> Output Class Initialized
INFO - 2020-07-31 08:37:35 --> Security Class Initialized
DEBUG - 2020-07-31 08:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:37:35 --> Input Class Initialized
INFO - 2020-07-31 08:37:35 --> Language Class Initialized
INFO - 2020-07-31 08:37:35 --> Loader Class Initialized
INFO - 2020-07-31 08:37:35 --> Helper loaded: url_helper
INFO - 2020-07-31 08:37:35 --> Database Driver Class Initialized
INFO - 2020-07-31 08:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:37:35 --> Email Class Initialized
INFO - 2020-07-31 08:37:35 --> Controller Class Initialized
INFO - 2020-07-31 08:37:35 --> Model Class Initialized
INFO - 2020-07-31 08:37:35 --> Model Class Initialized
DEBUG - 2020-07-31 08:37:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:37:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:37:35 --> Final output sent to browser
DEBUG - 2020-07-31 08:37:35 --> Total execution time: 0.0245
INFO - 2020-07-31 08:37:50 --> Config Class Initialized
INFO - 2020-07-31 08:37:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:37:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:37:50 --> Utf8 Class Initialized
INFO - 2020-07-31 08:37:50 --> URI Class Initialized
INFO - 2020-07-31 08:37:50 --> Router Class Initialized
INFO - 2020-07-31 08:37:50 --> Output Class Initialized
INFO - 2020-07-31 08:37:50 --> Security Class Initialized
DEBUG - 2020-07-31 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:37:50 --> Input Class Initialized
INFO - 2020-07-31 08:37:50 --> Language Class Initialized
INFO - 2020-07-31 08:37:50 --> Loader Class Initialized
INFO - 2020-07-31 08:37:50 --> Helper loaded: url_helper
INFO - 2020-07-31 08:37:50 --> Database Driver Class Initialized
INFO - 2020-07-31 08:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:37:50 --> Email Class Initialized
INFO - 2020-07-31 08:37:50 --> Controller Class Initialized
INFO - 2020-07-31 08:37:50 --> Model Class Initialized
INFO - 2020-07-31 08:37:50 --> Model Class Initialized
DEBUG - 2020-07-31 08:37:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:37:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:37:50 --> Config Class Initialized
INFO - 2020-07-31 08:37:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:37:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:37:50 --> Utf8 Class Initialized
INFO - 2020-07-31 08:37:50 --> URI Class Initialized
DEBUG - 2020-07-31 08:37:50 --> No URI present. Default controller set.
INFO - 2020-07-31 08:37:50 --> Router Class Initialized
INFO - 2020-07-31 08:37:50 --> Output Class Initialized
INFO - 2020-07-31 08:37:50 --> Security Class Initialized
DEBUG - 2020-07-31 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:37:50 --> Input Class Initialized
INFO - 2020-07-31 08:37:50 --> Language Class Initialized
INFO - 2020-07-31 08:37:50 --> Loader Class Initialized
INFO - 2020-07-31 08:37:50 --> Helper loaded: url_helper
INFO - 2020-07-31 08:37:50 --> Database Driver Class Initialized
INFO - 2020-07-31 08:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:37:50 --> Email Class Initialized
INFO - 2020-07-31 08:37:50 --> Controller Class Initialized
INFO - 2020-07-31 08:37:50 --> Model Class Initialized
INFO - 2020-07-31 08:37:50 --> Model Class Initialized
DEBUG - 2020-07-31 08:37:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:37:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:37:50 --> Final output sent to browser
DEBUG - 2020-07-31 08:37:50 --> Total execution time: 0.0221
INFO - 2020-07-31 08:42:33 --> Config Class Initialized
INFO - 2020-07-31 08:42:33 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:33 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:33 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:33 --> URI Class Initialized
INFO - 2020-07-31 08:42:33 --> Router Class Initialized
INFO - 2020-07-31 08:42:33 --> Output Class Initialized
INFO - 2020-07-31 08:42:33 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:33 --> Input Class Initialized
INFO - 2020-07-31 08:42:33 --> Language Class Initialized
INFO - 2020-07-31 08:42:33 --> Loader Class Initialized
INFO - 2020-07-31 08:42:33 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:33 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:33 --> Email Class Initialized
INFO - 2020-07-31 08:42:33 --> Controller Class Initialized
INFO - 2020-07-31 08:42:33 --> Model Class Initialized
INFO - 2020-07-31 08:42:33 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:42:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:33 --> Config Class Initialized
INFO - 2020-07-31 08:42:33 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:33 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:33 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:33 --> URI Class Initialized
DEBUG - 2020-07-31 08:42:33 --> No URI present. Default controller set.
INFO - 2020-07-31 08:42:33 --> Router Class Initialized
INFO - 2020-07-31 08:42:33 --> Output Class Initialized
INFO - 2020-07-31 08:42:33 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:33 --> Input Class Initialized
INFO - 2020-07-31 08:42:33 --> Language Class Initialized
INFO - 2020-07-31 08:42:33 --> Loader Class Initialized
INFO - 2020-07-31 08:42:33 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:33 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:33 --> Email Class Initialized
INFO - 2020-07-31 08:42:33 --> Controller Class Initialized
INFO - 2020-07-31 08:42:33 --> Model Class Initialized
INFO - 2020-07-31 08:42:33 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:42:33 --> Final output sent to browser
DEBUG - 2020-07-31 08:42:33 --> Total execution time: 0.0204
INFO - 2020-07-31 08:42:43 --> Config Class Initialized
INFO - 2020-07-31 08:42:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:43 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:43 --> URI Class Initialized
INFO - 2020-07-31 08:42:43 --> Router Class Initialized
INFO - 2020-07-31 08:42:43 --> Output Class Initialized
INFO - 2020-07-31 08:42:43 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:43 --> Input Class Initialized
INFO - 2020-07-31 08:42:43 --> Language Class Initialized
INFO - 2020-07-31 08:42:43 --> Loader Class Initialized
INFO - 2020-07-31 08:42:43 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:43 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:43 --> Email Class Initialized
INFO - 2020-07-31 08:42:43 --> Controller Class Initialized
INFO - 2020-07-31 08:42:43 --> Model Class Initialized
INFO - 2020-07-31 08:42:43 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:42:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:43 --> Config Class Initialized
INFO - 2020-07-31 08:42:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:43 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:43 --> URI Class Initialized
DEBUG - 2020-07-31 08:42:43 --> No URI present. Default controller set.
INFO - 2020-07-31 08:42:43 --> Router Class Initialized
INFO - 2020-07-31 08:42:43 --> Output Class Initialized
INFO - 2020-07-31 08:42:43 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:43 --> Input Class Initialized
INFO - 2020-07-31 08:42:43 --> Language Class Initialized
INFO - 2020-07-31 08:42:43 --> Loader Class Initialized
INFO - 2020-07-31 08:42:43 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:43 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:43 --> Email Class Initialized
INFO - 2020-07-31 08:42:43 --> Controller Class Initialized
INFO - 2020-07-31 08:42:43 --> Model Class Initialized
INFO - 2020-07-31 08:42:43 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:42:43 --> Final output sent to browser
DEBUG - 2020-07-31 08:42:43 --> Total execution time: 0.0217
INFO - 2020-07-31 08:42:47 --> Config Class Initialized
INFO - 2020-07-31 08:42:47 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:47 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:47 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:47 --> URI Class Initialized
INFO - 2020-07-31 08:42:47 --> Router Class Initialized
INFO - 2020-07-31 08:42:47 --> Output Class Initialized
INFO - 2020-07-31 08:42:47 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:47 --> Input Class Initialized
INFO - 2020-07-31 08:42:47 --> Language Class Initialized
INFO - 2020-07-31 08:42:47 --> Loader Class Initialized
INFO - 2020-07-31 08:42:47 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:47 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:47 --> Email Class Initialized
INFO - 2020-07-31 08:42:47 --> Controller Class Initialized
INFO - 2020-07-31 08:42:47 --> Model Class Initialized
INFO - 2020-07-31 08:42:47 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:42:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:48 --> Config Class Initialized
INFO - 2020-07-31 08:42:48 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:48 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:48 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:48 --> URI Class Initialized
DEBUG - 2020-07-31 08:42:48 --> No URI present. Default controller set.
INFO - 2020-07-31 08:42:48 --> Router Class Initialized
INFO - 2020-07-31 08:42:48 --> Output Class Initialized
INFO - 2020-07-31 08:42:48 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:48 --> Input Class Initialized
INFO - 2020-07-31 08:42:48 --> Language Class Initialized
INFO - 2020-07-31 08:42:48 --> Loader Class Initialized
INFO - 2020-07-31 08:42:48 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:48 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:48 --> Email Class Initialized
INFO - 2020-07-31 08:42:48 --> Controller Class Initialized
INFO - 2020-07-31 08:42:48 --> Model Class Initialized
INFO - 2020-07-31 08:42:48 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:42:48 --> Final output sent to browser
DEBUG - 2020-07-31 08:42:48 --> Total execution time: 0.0243
INFO - 2020-07-31 08:42:54 --> Config Class Initialized
INFO - 2020-07-31 08:42:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:54 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:54 --> URI Class Initialized
DEBUG - 2020-07-31 08:42:54 --> No URI present. Default controller set.
INFO - 2020-07-31 08:42:54 --> Router Class Initialized
INFO - 2020-07-31 08:42:54 --> Output Class Initialized
INFO - 2020-07-31 08:42:54 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:54 --> Input Class Initialized
INFO - 2020-07-31 08:42:54 --> Language Class Initialized
INFO - 2020-07-31 08:42:54 --> Loader Class Initialized
INFO - 2020-07-31 08:42:54 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:54 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:54 --> Email Class Initialized
INFO - 2020-07-31 08:42:54 --> Controller Class Initialized
INFO - 2020-07-31 08:42:54 --> Model Class Initialized
INFO - 2020-07-31 08:42:54 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:42:54 --> Final output sent to browser
DEBUG - 2020-07-31 08:42:54 --> Total execution time: 0.0219
INFO - 2020-07-31 08:42:54 --> Config Class Initialized
INFO - 2020-07-31 08:42:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:54 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:54 --> URI Class Initialized
DEBUG - 2020-07-31 08:42:54 --> No URI present. Default controller set.
INFO - 2020-07-31 08:42:54 --> Router Class Initialized
INFO - 2020-07-31 08:42:54 --> Output Class Initialized
INFO - 2020-07-31 08:42:54 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:54 --> Input Class Initialized
INFO - 2020-07-31 08:42:54 --> Language Class Initialized
INFO - 2020-07-31 08:42:54 --> Loader Class Initialized
INFO - 2020-07-31 08:42:54 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:54 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:54 --> Email Class Initialized
INFO - 2020-07-31 08:42:54 --> Controller Class Initialized
INFO - 2020-07-31 08:42:54 --> Model Class Initialized
INFO - 2020-07-31 08:42:54 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:42:54 --> Final output sent to browser
DEBUG - 2020-07-31 08:42:54 --> Total execution time: 0.0283
INFO - 2020-07-31 08:42:58 --> Config Class Initialized
INFO - 2020-07-31 08:42:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:58 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:58 --> URI Class Initialized
INFO - 2020-07-31 08:42:58 --> Router Class Initialized
INFO - 2020-07-31 08:42:58 --> Output Class Initialized
INFO - 2020-07-31 08:42:58 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:58 --> Input Class Initialized
INFO - 2020-07-31 08:42:58 --> Language Class Initialized
INFO - 2020-07-31 08:42:58 --> Loader Class Initialized
INFO - 2020-07-31 08:42:58 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:58 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:58 --> Email Class Initialized
INFO - 2020-07-31 08:42:58 --> Controller Class Initialized
INFO - 2020-07-31 08:42:58 --> Model Class Initialized
INFO - 2020-07-31 08:42:58 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:42:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:58 --> Config Class Initialized
INFO - 2020-07-31 08:42:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:42:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:42:58 --> Utf8 Class Initialized
INFO - 2020-07-31 08:42:58 --> URI Class Initialized
DEBUG - 2020-07-31 08:42:58 --> No URI present. Default controller set.
INFO - 2020-07-31 08:42:58 --> Router Class Initialized
INFO - 2020-07-31 08:42:58 --> Output Class Initialized
INFO - 2020-07-31 08:42:58 --> Security Class Initialized
DEBUG - 2020-07-31 08:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:42:58 --> Input Class Initialized
INFO - 2020-07-31 08:42:58 --> Language Class Initialized
INFO - 2020-07-31 08:42:58 --> Loader Class Initialized
INFO - 2020-07-31 08:42:58 --> Helper loaded: url_helper
INFO - 2020-07-31 08:42:58 --> Database Driver Class Initialized
INFO - 2020-07-31 08:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:42:58 --> Email Class Initialized
INFO - 2020-07-31 08:42:58 --> Controller Class Initialized
INFO - 2020-07-31 08:42:58 --> Model Class Initialized
INFO - 2020-07-31 08:42:58 --> Model Class Initialized
DEBUG - 2020-07-31 08:42:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:42:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:42:58 --> Final output sent to browser
DEBUG - 2020-07-31 08:42:58 --> Total execution time: 0.0232
INFO - 2020-07-31 08:43:01 --> Config Class Initialized
INFO - 2020-07-31 08:43:01 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:01 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:01 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:01 --> URI Class Initialized
INFO - 2020-07-31 08:43:01 --> Router Class Initialized
INFO - 2020-07-31 08:43:01 --> Output Class Initialized
INFO - 2020-07-31 08:43:01 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:01 --> Input Class Initialized
INFO - 2020-07-31 08:43:01 --> Language Class Initialized
INFO - 2020-07-31 08:43:01 --> Loader Class Initialized
INFO - 2020-07-31 08:43:01 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:01 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:01 --> Email Class Initialized
INFO - 2020-07-31 08:43:01 --> Controller Class Initialized
INFO - 2020-07-31 08:43:01 --> Model Class Initialized
INFO - 2020-07-31 08:43:01 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:01 --> Config Class Initialized
INFO - 2020-07-31 08:43:01 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:01 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:01 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:01 --> URI Class Initialized
INFO - 2020-07-31 08:43:01 --> Router Class Initialized
INFO - 2020-07-31 08:43:01 --> Output Class Initialized
INFO - 2020-07-31 08:43:01 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:01 --> Input Class Initialized
INFO - 2020-07-31 08:43:01 --> Language Class Initialized
INFO - 2020-07-31 08:43:01 --> Loader Class Initialized
INFO - 2020-07-31 08:43:01 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:01 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:01 --> Email Class Initialized
INFO - 2020-07-31 08:43:01 --> Controller Class Initialized
DEBUG - 2020-07-31 08:43:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:43:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 08:43:01 --> Final output sent to browser
DEBUG - 2020-07-31 08:43:01 --> Total execution time: 0.0232
INFO - 2020-07-31 08:43:04 --> Config Class Initialized
INFO - 2020-07-31 08:43:04 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:04 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:04 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:04 --> URI Class Initialized
DEBUG - 2020-07-31 08:43:04 --> No URI present. Default controller set.
INFO - 2020-07-31 08:43:04 --> Router Class Initialized
INFO - 2020-07-31 08:43:04 --> Output Class Initialized
INFO - 2020-07-31 08:43:04 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:04 --> Input Class Initialized
INFO - 2020-07-31 08:43:04 --> Language Class Initialized
INFO - 2020-07-31 08:43:04 --> Loader Class Initialized
INFO - 2020-07-31 08:43:04 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:04 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:04 --> Email Class Initialized
INFO - 2020-07-31 08:43:04 --> Controller Class Initialized
INFO - 2020-07-31 08:43:04 --> Model Class Initialized
INFO - 2020-07-31 08:43:04 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:43:04 --> Final output sent to browser
DEBUG - 2020-07-31 08:43:04 --> Total execution time: 0.0249
INFO - 2020-07-31 08:43:07 --> Config Class Initialized
INFO - 2020-07-31 08:43:07 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:07 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:07 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:07 --> URI Class Initialized
INFO - 2020-07-31 08:43:07 --> Router Class Initialized
INFO - 2020-07-31 08:43:07 --> Output Class Initialized
INFO - 2020-07-31 08:43:07 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:07 --> Input Class Initialized
INFO - 2020-07-31 08:43:07 --> Language Class Initialized
INFO - 2020-07-31 08:43:07 --> Loader Class Initialized
INFO - 2020-07-31 08:43:07 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:07 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:07 --> Email Class Initialized
INFO - 2020-07-31 08:43:07 --> Controller Class Initialized
INFO - 2020-07-31 08:43:07 --> Model Class Initialized
INFO - 2020-07-31 08:43:07 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:43:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:43:07 --> Final output sent to browser
DEBUG - 2020-07-31 08:43:07 --> Total execution time: 0.0206
INFO - 2020-07-31 08:43:12 --> Config Class Initialized
INFO - 2020-07-31 08:43:12 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:12 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:12 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:12 --> URI Class Initialized
INFO - 2020-07-31 08:43:12 --> Router Class Initialized
INFO - 2020-07-31 08:43:12 --> Output Class Initialized
INFO - 2020-07-31 08:43:12 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:12 --> Input Class Initialized
INFO - 2020-07-31 08:43:12 --> Language Class Initialized
INFO - 2020-07-31 08:43:12 --> Loader Class Initialized
INFO - 2020-07-31 08:43:12 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:12 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:12 --> Email Class Initialized
INFO - 2020-07-31 08:43:12 --> Controller Class Initialized
INFO - 2020-07-31 08:43:12 --> Model Class Initialized
INFO - 2020-07-31 08:43:12 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:43:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:12 --> Model Class Initialized
INFO - 2020-07-31 08:43:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:43:12 --> Final output sent to browser
DEBUG - 2020-07-31 08:43:12 --> Total execution time: 0.0691
INFO - 2020-07-31 08:43:38 --> Config Class Initialized
INFO - 2020-07-31 08:43:38 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:38 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:38 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:38 --> URI Class Initialized
INFO - 2020-07-31 08:43:38 --> Router Class Initialized
INFO - 2020-07-31 08:43:38 --> Output Class Initialized
INFO - 2020-07-31 08:43:38 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:38 --> Input Class Initialized
INFO - 2020-07-31 08:43:38 --> Language Class Initialized
INFO - 2020-07-31 08:43:38 --> Loader Class Initialized
INFO - 2020-07-31 08:43:38 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:38 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:38 --> Email Class Initialized
INFO - 2020-07-31 08:43:38 --> Controller Class Initialized
INFO - 2020-07-31 08:43:38 --> Model Class Initialized
INFO - 2020-07-31 08:43:38 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:43:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:39 --> Config Class Initialized
INFO - 2020-07-31 08:43:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:39 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:39 --> URI Class Initialized
DEBUG - 2020-07-31 08:43:39 --> No URI present. Default controller set.
INFO - 2020-07-31 08:43:39 --> Router Class Initialized
INFO - 2020-07-31 08:43:39 --> Output Class Initialized
INFO - 2020-07-31 08:43:39 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:39 --> Input Class Initialized
INFO - 2020-07-31 08:43:39 --> Language Class Initialized
INFO - 2020-07-31 08:43:39 --> Loader Class Initialized
INFO - 2020-07-31 08:43:39 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:39 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:39 --> Email Class Initialized
INFO - 2020-07-31 08:43:39 --> Controller Class Initialized
INFO - 2020-07-31 08:43:39 --> Model Class Initialized
INFO - 2020-07-31 08:43:39 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:43:39 --> Final output sent to browser
DEBUG - 2020-07-31 08:43:39 --> Total execution time: 0.0259
INFO - 2020-07-31 08:43:50 --> Config Class Initialized
INFO - 2020-07-31 08:43:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:50 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:50 --> URI Class Initialized
INFO - 2020-07-31 08:43:50 --> Router Class Initialized
INFO - 2020-07-31 08:43:50 --> Output Class Initialized
INFO - 2020-07-31 08:43:50 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:50 --> Input Class Initialized
INFO - 2020-07-31 08:43:50 --> Language Class Initialized
INFO - 2020-07-31 08:43:50 --> Loader Class Initialized
INFO - 2020-07-31 08:43:50 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:50 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:50 --> Email Class Initialized
INFO - 2020-07-31 08:43:50 --> Controller Class Initialized
INFO - 2020-07-31 08:43:50 --> Model Class Initialized
INFO - 2020-07-31 08:43:50 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:43:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:51 --> Config Class Initialized
INFO - 2020-07-31 08:43:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:43:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:43:51 --> Utf8 Class Initialized
INFO - 2020-07-31 08:43:51 --> URI Class Initialized
DEBUG - 2020-07-31 08:43:51 --> No URI present. Default controller set.
INFO - 2020-07-31 08:43:51 --> Router Class Initialized
INFO - 2020-07-31 08:43:51 --> Output Class Initialized
INFO - 2020-07-31 08:43:51 --> Security Class Initialized
DEBUG - 2020-07-31 08:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:43:51 --> Input Class Initialized
INFO - 2020-07-31 08:43:51 --> Language Class Initialized
INFO - 2020-07-31 08:43:51 --> Loader Class Initialized
INFO - 2020-07-31 08:43:51 --> Helper loaded: url_helper
INFO - 2020-07-31 08:43:51 --> Database Driver Class Initialized
INFO - 2020-07-31 08:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:43:51 --> Email Class Initialized
INFO - 2020-07-31 08:43:51 --> Controller Class Initialized
INFO - 2020-07-31 08:43:51 --> Model Class Initialized
INFO - 2020-07-31 08:43:51 --> Model Class Initialized
DEBUG - 2020-07-31 08:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:43:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:43:51 --> Final output sent to browser
DEBUG - 2020-07-31 08:43:51 --> Total execution time: 0.0229
INFO - 2020-07-31 08:50:52 --> Config Class Initialized
INFO - 2020-07-31 08:50:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:50:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:50:52 --> Utf8 Class Initialized
INFO - 2020-07-31 08:50:52 --> URI Class Initialized
INFO - 2020-07-31 08:50:52 --> Router Class Initialized
INFO - 2020-07-31 08:50:52 --> Output Class Initialized
INFO - 2020-07-31 08:50:52 --> Security Class Initialized
DEBUG - 2020-07-31 08:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:50:52 --> Input Class Initialized
INFO - 2020-07-31 08:50:52 --> Language Class Initialized
INFO - 2020-07-31 08:50:52 --> Loader Class Initialized
INFO - 2020-07-31 08:50:52 --> Helper loaded: url_helper
INFO - 2020-07-31 08:50:52 --> Database Driver Class Initialized
INFO - 2020-07-31 08:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:50:52 --> Email Class Initialized
INFO - 2020-07-31 08:50:52 --> Controller Class Initialized
INFO - 2020-07-31 08:50:52 --> Model Class Initialized
INFO - 2020-07-31 08:50:52 --> Model Class Initialized
DEBUG - 2020-07-31 08:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:50:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:50:52 --> Model Class Initialized
INFO - 2020-07-31 08:50:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:50:52 --> Final output sent to browser
DEBUG - 2020-07-31 08:50:52 --> Total execution time: 0.0602
INFO - 2020-07-31 08:51:06 --> Config Class Initialized
INFO - 2020-07-31 08:51:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:51:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:51:06 --> Utf8 Class Initialized
INFO - 2020-07-31 08:51:06 --> URI Class Initialized
INFO - 2020-07-31 08:51:06 --> Router Class Initialized
INFO - 2020-07-31 08:51:06 --> Output Class Initialized
INFO - 2020-07-31 08:51:06 --> Security Class Initialized
DEBUG - 2020-07-31 08:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:51:06 --> Input Class Initialized
INFO - 2020-07-31 08:51:06 --> Language Class Initialized
INFO - 2020-07-31 08:51:06 --> Loader Class Initialized
INFO - 2020-07-31 08:51:06 --> Helper loaded: url_helper
INFO - 2020-07-31 08:51:06 --> Database Driver Class Initialized
INFO - 2020-07-31 08:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:51:06 --> Email Class Initialized
INFO - 2020-07-31 08:51:06 --> Controller Class Initialized
INFO - 2020-07-31 08:51:06 --> Model Class Initialized
INFO - 2020-07-31 08:51:06 --> Model Class Initialized
DEBUG - 2020-07-31 08:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:51:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:51:06 --> Model Class Initialized
INFO - 2020-07-31 08:51:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 08:51:06 --> Final output sent to browser
DEBUG - 2020-07-31 08:51:06 --> Total execution time: 0.0255
INFO - 2020-07-31 08:52:22 --> Config Class Initialized
INFO - 2020-07-31 08:52:22 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:52:22 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:52:22 --> Utf8 Class Initialized
INFO - 2020-07-31 08:52:22 --> URI Class Initialized
INFO - 2020-07-31 08:52:22 --> Router Class Initialized
INFO - 2020-07-31 08:52:22 --> Output Class Initialized
INFO - 2020-07-31 08:52:22 --> Security Class Initialized
DEBUG - 2020-07-31 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:52:22 --> Input Class Initialized
INFO - 2020-07-31 08:52:22 --> Language Class Initialized
INFO - 2020-07-31 08:52:22 --> Loader Class Initialized
INFO - 2020-07-31 08:52:22 --> Helper loaded: url_helper
INFO - 2020-07-31 08:52:22 --> Database Driver Class Initialized
INFO - 2020-07-31 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:52:22 --> Email Class Initialized
INFO - 2020-07-31 08:52:22 --> Controller Class Initialized
INFO - 2020-07-31 08:52:22 --> Model Class Initialized
INFO - 2020-07-31 08:52:22 --> Model Class Initialized
DEBUG - 2020-07-31 08:52:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:52:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:52:22 --> Model Class Initialized
INFO - 2020-07-31 08:52:22 --> Config Class Initialized
INFO - 2020-07-31 08:52:22 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:52:22 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:52:22 --> Utf8 Class Initialized
INFO - 2020-07-31 08:52:22 --> URI Class Initialized
DEBUG - 2020-07-31 08:52:22 --> No URI present. Default controller set.
INFO - 2020-07-31 08:52:22 --> Router Class Initialized
INFO - 2020-07-31 08:52:22 --> Output Class Initialized
INFO - 2020-07-31 08:52:22 --> Security Class Initialized
DEBUG - 2020-07-31 08:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:52:22 --> Input Class Initialized
INFO - 2020-07-31 08:52:22 --> Language Class Initialized
INFO - 2020-07-31 08:52:22 --> Loader Class Initialized
INFO - 2020-07-31 08:52:22 --> Helper loaded: url_helper
INFO - 2020-07-31 08:52:22 --> Database Driver Class Initialized
INFO - 2020-07-31 08:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:52:22 --> Email Class Initialized
INFO - 2020-07-31 08:52:22 --> Controller Class Initialized
INFO - 2020-07-31 08:52:22 --> Model Class Initialized
INFO - 2020-07-31 08:52:22 --> Model Class Initialized
DEBUG - 2020-07-31 08:52:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:52:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:52:22 --> Final output sent to browser
DEBUG - 2020-07-31 08:52:22 --> Total execution time: 0.0230
INFO - 2020-07-31 08:57:52 --> Config Class Initialized
INFO - 2020-07-31 08:57:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:57:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:57:52 --> Utf8 Class Initialized
INFO - 2020-07-31 08:57:52 --> URI Class Initialized
INFO - 2020-07-31 08:57:52 --> Router Class Initialized
INFO - 2020-07-31 08:57:52 --> Output Class Initialized
INFO - 2020-07-31 08:57:52 --> Security Class Initialized
DEBUG - 2020-07-31 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:57:52 --> Input Class Initialized
INFO - 2020-07-31 08:57:52 --> Language Class Initialized
INFO - 2020-07-31 08:57:52 --> Loader Class Initialized
INFO - 2020-07-31 08:57:52 --> Helper loaded: url_helper
INFO - 2020-07-31 08:57:52 --> Database Driver Class Initialized
INFO - 2020-07-31 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:57:52 --> Email Class Initialized
INFO - 2020-07-31 08:57:52 --> Controller Class Initialized
INFO - 2020-07-31 08:57:52 --> Model Class Initialized
INFO - 2020-07-31 08:57:52 --> Model Class Initialized
DEBUG - 2020-07-31 08:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:57:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:57:52 --> Model Class Initialized
INFO - 2020-07-31 08:57:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:57:52 --> Final output sent to browser
DEBUG - 2020-07-31 08:57:52 --> Total execution time: 0.0677
INFO - 2020-07-31 08:59:17 --> Config Class Initialized
INFO - 2020-07-31 08:59:17 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:59:17 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:59:17 --> Utf8 Class Initialized
INFO - 2020-07-31 08:59:17 --> URI Class Initialized
INFO - 2020-07-31 08:59:17 --> Router Class Initialized
INFO - 2020-07-31 08:59:17 --> Output Class Initialized
INFO - 2020-07-31 08:59:17 --> Security Class Initialized
DEBUG - 2020-07-31 08:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:59:17 --> Input Class Initialized
INFO - 2020-07-31 08:59:17 --> Language Class Initialized
INFO - 2020-07-31 08:59:17 --> Loader Class Initialized
INFO - 2020-07-31 08:59:17 --> Helper loaded: url_helper
INFO - 2020-07-31 08:59:17 --> Database Driver Class Initialized
INFO - 2020-07-31 08:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:59:17 --> Email Class Initialized
INFO - 2020-07-31 08:59:17 --> Controller Class Initialized
INFO - 2020-07-31 08:59:17 --> Model Class Initialized
INFO - 2020-07-31 08:59:17 --> Model Class Initialized
DEBUG - 2020-07-31 08:59:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 08:59:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:59:17 --> Model Class Initialized
INFO - 2020-07-31 08:59:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 08:59:17 --> Final output sent to browser
DEBUG - 2020-07-31 08:59:17 --> Total execution time: 0.0706
INFO - 2020-07-31 08:59:59 --> Config Class Initialized
INFO - 2020-07-31 08:59:59 --> Hooks Class Initialized
DEBUG - 2020-07-31 08:59:59 --> UTF-8 Support Enabled
INFO - 2020-07-31 08:59:59 --> Utf8 Class Initialized
INFO - 2020-07-31 08:59:59 --> URI Class Initialized
DEBUG - 2020-07-31 08:59:59 --> No URI present. Default controller set.
INFO - 2020-07-31 08:59:59 --> Router Class Initialized
INFO - 2020-07-31 08:59:59 --> Output Class Initialized
INFO - 2020-07-31 08:59:59 --> Security Class Initialized
DEBUG - 2020-07-31 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 08:59:59 --> Input Class Initialized
INFO - 2020-07-31 08:59:59 --> Language Class Initialized
INFO - 2020-07-31 08:59:59 --> Loader Class Initialized
INFO - 2020-07-31 08:59:59 --> Helper loaded: url_helper
INFO - 2020-07-31 08:59:59 --> Database Driver Class Initialized
INFO - 2020-07-31 08:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 08:59:59 --> Email Class Initialized
INFO - 2020-07-31 08:59:59 --> Controller Class Initialized
INFO - 2020-07-31 08:59:59 --> Model Class Initialized
INFO - 2020-07-31 08:59:59 --> Model Class Initialized
DEBUG - 2020-07-31 08:59:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 08:59:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 08:59:59 --> Final output sent to browser
DEBUG - 2020-07-31 08:59:59 --> Total execution time: 0.0212
INFO - 2020-07-31 09:00:02 --> Config Class Initialized
INFO - 2020-07-31 09:00:02 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:00:02 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:00:02 --> Utf8 Class Initialized
INFO - 2020-07-31 09:00:02 --> URI Class Initialized
DEBUG - 2020-07-31 09:00:02 --> No URI present. Default controller set.
INFO - 2020-07-31 09:00:02 --> Router Class Initialized
INFO - 2020-07-31 09:00:02 --> Output Class Initialized
INFO - 2020-07-31 09:00:02 --> Security Class Initialized
DEBUG - 2020-07-31 09:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:00:02 --> Input Class Initialized
INFO - 2020-07-31 09:00:02 --> Language Class Initialized
INFO - 2020-07-31 09:00:02 --> Loader Class Initialized
INFO - 2020-07-31 09:00:02 --> Helper loaded: url_helper
INFO - 2020-07-31 09:00:02 --> Database Driver Class Initialized
INFO - 2020-07-31 09:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:00:02 --> Email Class Initialized
INFO - 2020-07-31 09:00:02 --> Controller Class Initialized
INFO - 2020-07-31 09:00:02 --> Model Class Initialized
INFO - 2020-07-31 09:00:02 --> Model Class Initialized
DEBUG - 2020-07-31 09:00:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:00:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:00:02 --> Final output sent to browser
DEBUG - 2020-07-31 09:00:02 --> Total execution time: 0.0244
INFO - 2020-07-31 09:01:26 --> Config Class Initialized
INFO - 2020-07-31 09:01:26 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:01:26 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:01:26 --> Utf8 Class Initialized
INFO - 2020-07-31 09:01:26 --> URI Class Initialized
INFO - 2020-07-31 09:01:26 --> Router Class Initialized
INFO - 2020-07-31 09:01:26 --> Output Class Initialized
INFO - 2020-07-31 09:01:26 --> Security Class Initialized
DEBUG - 2020-07-31 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:01:26 --> Input Class Initialized
INFO - 2020-07-31 09:01:26 --> Language Class Initialized
INFO - 2020-07-31 09:01:26 --> Loader Class Initialized
INFO - 2020-07-31 09:01:26 --> Helper loaded: url_helper
INFO - 2020-07-31 09:01:26 --> Database Driver Class Initialized
INFO - 2020-07-31 09:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:01:26 --> Email Class Initialized
INFO - 2020-07-31 09:01:26 --> Controller Class Initialized
INFO - 2020-07-31 09:01:26 --> Model Class Initialized
INFO - 2020-07-31 09:01:26 --> Model Class Initialized
DEBUG - 2020-07-31 09:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:01:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:01:26 --> Model Class Initialized
INFO - 2020-07-31 09:01:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:01:26 --> Final output sent to browser
DEBUG - 2020-07-31 09:01:26 --> Total execution time: 0.0308
INFO - 2020-07-31 09:01:38 --> Config Class Initialized
INFO - 2020-07-31 09:01:38 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:01:38 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:01:38 --> Utf8 Class Initialized
INFO - 2020-07-31 09:01:38 --> URI Class Initialized
INFO - 2020-07-31 09:01:38 --> Router Class Initialized
INFO - 2020-07-31 09:01:38 --> Output Class Initialized
INFO - 2020-07-31 09:01:38 --> Security Class Initialized
DEBUG - 2020-07-31 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:01:38 --> Input Class Initialized
INFO - 2020-07-31 09:01:38 --> Language Class Initialized
INFO - 2020-07-31 09:01:38 --> Loader Class Initialized
INFO - 2020-07-31 09:01:38 --> Helper loaded: url_helper
INFO - 2020-07-31 09:01:38 --> Database Driver Class Initialized
INFO - 2020-07-31 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:01:38 --> Email Class Initialized
INFO - 2020-07-31 09:01:38 --> Controller Class Initialized
INFO - 2020-07-31 09:01:38 --> Model Class Initialized
INFO - 2020-07-31 09:01:38 --> Model Class Initialized
DEBUG - 2020-07-31 09:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:01:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:01:38 --> Model Class Initialized
INFO - 2020-07-31 09:01:38 --> Config Class Initialized
INFO - 2020-07-31 09:01:38 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:01:38 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:01:38 --> Utf8 Class Initialized
INFO - 2020-07-31 09:01:38 --> URI Class Initialized
INFO - 2020-07-31 09:01:38 --> Router Class Initialized
INFO - 2020-07-31 09:01:38 --> Output Class Initialized
INFO - 2020-07-31 09:01:38 --> Security Class Initialized
DEBUG - 2020-07-31 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:01:38 --> Input Class Initialized
INFO - 2020-07-31 09:01:38 --> Language Class Initialized
INFO - 2020-07-31 09:01:38 --> Loader Class Initialized
INFO - 2020-07-31 09:01:38 --> Helper loaded: url_helper
INFO - 2020-07-31 09:01:38 --> Database Driver Class Initialized
INFO - 2020-07-31 09:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:01:38 --> Email Class Initialized
INFO - 2020-07-31 09:01:38 --> Controller Class Initialized
INFO - 2020-07-31 09:01:38 --> Model Class Initialized
INFO - 2020-07-31 09:01:38 --> Model Class Initialized
DEBUG - 2020-07-31 09:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:01:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:01:38 --> Model Class Initialized
INFO - 2020-07-31 09:01:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:01:38 --> Final output sent to browser
DEBUG - 2020-07-31 09:01:38 --> Total execution time: 0.0400
INFO - 2020-07-31 09:02:18 --> Config Class Initialized
INFO - 2020-07-31 09:02:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:02:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:02:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:02:18 --> URI Class Initialized
INFO - 2020-07-31 09:02:18 --> Router Class Initialized
INFO - 2020-07-31 09:02:18 --> Output Class Initialized
INFO - 2020-07-31 09:02:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:02:18 --> Input Class Initialized
INFO - 2020-07-31 09:02:18 --> Language Class Initialized
INFO - 2020-07-31 09:02:18 --> Loader Class Initialized
INFO - 2020-07-31 09:02:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:02:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:02:18 --> Email Class Initialized
INFO - 2020-07-31 09:02:18 --> Controller Class Initialized
INFO - 2020-07-31 09:02:18 --> Model Class Initialized
INFO - 2020-07-31 09:02:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:02:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:02:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:02:18 --> Model Class Initialized
INFO - 2020-07-31 09:02:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:02:18 --> Final output sent to browser
DEBUG - 2020-07-31 09:02:18 --> Total execution time: 0.0224
INFO - 2020-07-31 09:02:47 --> Config Class Initialized
INFO - 2020-07-31 09:02:47 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:02:47 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:02:47 --> Utf8 Class Initialized
INFO - 2020-07-31 09:02:47 --> URI Class Initialized
INFO - 2020-07-31 09:02:47 --> Router Class Initialized
INFO - 2020-07-31 09:02:47 --> Output Class Initialized
INFO - 2020-07-31 09:02:47 --> Security Class Initialized
DEBUG - 2020-07-31 09:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:02:47 --> Input Class Initialized
INFO - 2020-07-31 09:02:47 --> Language Class Initialized
INFO - 2020-07-31 09:02:47 --> Loader Class Initialized
INFO - 2020-07-31 09:02:47 --> Helper loaded: url_helper
INFO - 2020-07-31 09:02:47 --> Database Driver Class Initialized
INFO - 2020-07-31 09:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:02:47 --> Email Class Initialized
INFO - 2020-07-31 09:02:47 --> Controller Class Initialized
INFO - 2020-07-31 09:02:47 --> Model Class Initialized
INFO - 2020-07-31 09:02:47 --> Model Class Initialized
DEBUG - 2020-07-31 09:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:02:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:02:47 --> Model Class Initialized
INFO - 2020-07-31 09:02:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:02:47 --> Final output sent to browser
DEBUG - 2020-07-31 09:02:47 --> Total execution time: 0.0250
INFO - 2020-07-31 09:04:02 --> Config Class Initialized
INFO - 2020-07-31 09:04:02 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:04:02 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:04:02 --> Utf8 Class Initialized
INFO - 2020-07-31 09:04:02 --> URI Class Initialized
DEBUG - 2020-07-31 09:04:02 --> No URI present. Default controller set.
INFO - 2020-07-31 09:04:02 --> Router Class Initialized
INFO - 2020-07-31 09:04:02 --> Output Class Initialized
INFO - 2020-07-31 09:04:02 --> Security Class Initialized
DEBUG - 2020-07-31 09:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:04:02 --> Input Class Initialized
INFO - 2020-07-31 09:04:02 --> Language Class Initialized
INFO - 2020-07-31 09:04:02 --> Loader Class Initialized
INFO - 2020-07-31 09:04:02 --> Helper loaded: url_helper
INFO - 2020-07-31 09:04:02 --> Database Driver Class Initialized
INFO - 2020-07-31 09:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:04:02 --> Email Class Initialized
INFO - 2020-07-31 09:04:02 --> Controller Class Initialized
INFO - 2020-07-31 09:04:02 --> Model Class Initialized
INFO - 2020-07-31 09:04:02 --> Model Class Initialized
DEBUG - 2020-07-31 09:04:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:04:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:04:02 --> Final output sent to browser
DEBUG - 2020-07-31 09:04:02 --> Total execution time: 0.0234
INFO - 2020-07-31 09:04:05 --> Config Class Initialized
INFO - 2020-07-31 09:04:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:04:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:04:05 --> Utf8 Class Initialized
INFO - 2020-07-31 09:04:05 --> URI Class Initialized
INFO - 2020-07-31 09:04:05 --> Router Class Initialized
INFO - 2020-07-31 09:04:05 --> Output Class Initialized
INFO - 2020-07-31 09:04:05 --> Security Class Initialized
DEBUG - 2020-07-31 09:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:04:05 --> Input Class Initialized
INFO - 2020-07-31 09:04:05 --> Language Class Initialized
INFO - 2020-07-31 09:04:05 --> Loader Class Initialized
INFO - 2020-07-31 09:04:05 --> Helper loaded: url_helper
INFO - 2020-07-31 09:04:05 --> Database Driver Class Initialized
INFO - 2020-07-31 09:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:04:05 --> Email Class Initialized
INFO - 2020-07-31 09:04:05 --> Controller Class Initialized
INFO - 2020-07-31 09:04:05 --> Model Class Initialized
INFO - 2020-07-31 09:04:05 --> Model Class Initialized
DEBUG - 2020-07-31 09:04:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:04:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:04:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:04:05 --> Final output sent to browser
DEBUG - 2020-07-31 09:04:05 --> Total execution time: 0.0249
INFO - 2020-07-31 09:04:09 --> Config Class Initialized
INFO - 2020-07-31 09:04:09 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:04:09 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:04:09 --> Utf8 Class Initialized
INFO - 2020-07-31 09:04:09 --> URI Class Initialized
INFO - 2020-07-31 09:04:09 --> Router Class Initialized
INFO - 2020-07-31 09:04:09 --> Output Class Initialized
INFO - 2020-07-31 09:04:09 --> Security Class Initialized
DEBUG - 2020-07-31 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:04:09 --> Input Class Initialized
INFO - 2020-07-31 09:04:09 --> Language Class Initialized
INFO - 2020-07-31 09:04:09 --> Loader Class Initialized
INFO - 2020-07-31 09:04:09 --> Helper loaded: url_helper
INFO - 2020-07-31 09:04:09 --> Database Driver Class Initialized
INFO - 2020-07-31 09:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:04:09 --> Email Class Initialized
INFO - 2020-07-31 09:04:09 --> Controller Class Initialized
INFO - 2020-07-31 09:04:09 --> Model Class Initialized
INFO - 2020-07-31 09:04:09 --> Model Class Initialized
DEBUG - 2020-07-31 09:04:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:04:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:04:09 --> Model Class Initialized
INFO - 2020-07-31 09:04:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:04:09 --> Final output sent to browser
DEBUG - 2020-07-31 09:04:09 --> Total execution time: 0.0753
INFO - 2020-07-31 09:04:19 --> Config Class Initialized
INFO - 2020-07-31 09:04:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:04:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:04:19 --> Utf8 Class Initialized
INFO - 2020-07-31 09:04:19 --> URI Class Initialized
INFO - 2020-07-31 09:04:19 --> Router Class Initialized
INFO - 2020-07-31 09:04:19 --> Output Class Initialized
INFO - 2020-07-31 09:04:19 --> Security Class Initialized
DEBUG - 2020-07-31 09:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:04:19 --> Input Class Initialized
INFO - 2020-07-31 09:04:19 --> Language Class Initialized
INFO - 2020-07-31 09:04:19 --> Loader Class Initialized
INFO - 2020-07-31 09:04:19 --> Helper loaded: url_helper
INFO - 2020-07-31 09:04:19 --> Database Driver Class Initialized
INFO - 2020-07-31 09:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:04:19 --> Email Class Initialized
INFO - 2020-07-31 09:04:19 --> Controller Class Initialized
INFO - 2020-07-31 09:04:19 --> Model Class Initialized
INFO - 2020-07-31 09:04:19 --> Model Class Initialized
DEBUG - 2020-07-31 09:04:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:04:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:04:19 --> Model Class Initialized
INFO - 2020-07-31 09:04:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:04:19 --> Final output sent to browser
DEBUG - 2020-07-31 09:04:19 --> Total execution time: 0.0357
INFO - 2020-07-31 09:04:49 --> Config Class Initialized
INFO - 2020-07-31 09:04:49 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:04:49 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:04:49 --> Utf8 Class Initialized
INFO - 2020-07-31 09:04:49 --> URI Class Initialized
INFO - 2020-07-31 09:04:49 --> Router Class Initialized
INFO - 2020-07-31 09:04:49 --> Output Class Initialized
INFO - 2020-07-31 09:04:49 --> Security Class Initialized
DEBUG - 2020-07-31 09:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:04:49 --> Input Class Initialized
INFO - 2020-07-31 09:04:49 --> Language Class Initialized
INFO - 2020-07-31 09:04:49 --> Loader Class Initialized
INFO - 2020-07-31 09:04:49 --> Helper loaded: url_helper
INFO - 2020-07-31 09:04:49 --> Database Driver Class Initialized
INFO - 2020-07-31 09:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:04:49 --> Email Class Initialized
INFO - 2020-07-31 09:04:49 --> Controller Class Initialized
INFO - 2020-07-31 09:04:49 --> Model Class Initialized
INFO - 2020-07-31 09:04:49 --> Model Class Initialized
DEBUG - 2020-07-31 09:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:04:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:04:49 --> Model Class Initialized
INFO - 2020-07-31 09:04:49 --> Config Class Initialized
INFO - 2020-07-31 09:04:49 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:04:49 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:04:49 --> Utf8 Class Initialized
INFO - 2020-07-31 09:04:49 --> URI Class Initialized
DEBUG - 2020-07-31 09:04:49 --> No URI present. Default controller set.
INFO - 2020-07-31 09:04:49 --> Router Class Initialized
INFO - 2020-07-31 09:04:49 --> Output Class Initialized
INFO - 2020-07-31 09:04:49 --> Security Class Initialized
DEBUG - 2020-07-31 09:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:04:49 --> Input Class Initialized
INFO - 2020-07-31 09:04:49 --> Language Class Initialized
INFO - 2020-07-31 09:04:49 --> Loader Class Initialized
INFO - 2020-07-31 09:04:49 --> Helper loaded: url_helper
INFO - 2020-07-31 09:04:49 --> Database Driver Class Initialized
INFO - 2020-07-31 09:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:04:49 --> Email Class Initialized
INFO - 2020-07-31 09:04:49 --> Controller Class Initialized
INFO - 2020-07-31 09:04:49 --> Model Class Initialized
INFO - 2020-07-31 09:04:49 --> Model Class Initialized
DEBUG - 2020-07-31 09:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:04:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:04:49 --> Final output sent to browser
DEBUG - 2020-07-31 09:04:49 --> Total execution time: 0.0225
INFO - 2020-07-31 09:08:47 --> Config Class Initialized
INFO - 2020-07-31 09:08:47 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:08:47 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:08:47 --> Utf8 Class Initialized
INFO - 2020-07-31 09:08:47 --> URI Class Initialized
INFO - 2020-07-31 09:08:47 --> Router Class Initialized
INFO - 2020-07-31 09:08:47 --> Output Class Initialized
INFO - 2020-07-31 09:08:47 --> Security Class Initialized
DEBUG - 2020-07-31 09:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:08:47 --> Input Class Initialized
INFO - 2020-07-31 09:08:47 --> Language Class Initialized
INFO - 2020-07-31 09:08:47 --> Loader Class Initialized
INFO - 2020-07-31 09:08:47 --> Helper loaded: url_helper
INFO - 2020-07-31 09:08:47 --> Database Driver Class Initialized
INFO - 2020-07-31 09:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:08:47 --> Email Class Initialized
INFO - 2020-07-31 09:08:47 --> Controller Class Initialized
INFO - 2020-07-31 09:08:47 --> Model Class Initialized
INFO - 2020-07-31 09:08:47 --> Model Class Initialized
DEBUG - 2020-07-31 09:08:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:08:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:08:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:08:47 --> Final output sent to browser
DEBUG - 2020-07-31 09:08:47 --> Total execution time: 0.0924
INFO - 2020-07-31 09:08:49 --> Config Class Initialized
INFO - 2020-07-31 09:08:49 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:08:49 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:08:49 --> Utf8 Class Initialized
INFO - 2020-07-31 09:08:49 --> URI Class Initialized
DEBUG - 2020-07-31 09:08:49 --> No URI present. Default controller set.
INFO - 2020-07-31 09:08:49 --> Router Class Initialized
INFO - 2020-07-31 09:08:49 --> Output Class Initialized
INFO - 2020-07-31 09:08:49 --> Security Class Initialized
DEBUG - 2020-07-31 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:08:49 --> Input Class Initialized
INFO - 2020-07-31 09:08:49 --> Language Class Initialized
INFO - 2020-07-31 09:08:49 --> Loader Class Initialized
INFO - 2020-07-31 09:08:49 --> Helper loaded: url_helper
INFO - 2020-07-31 09:08:49 --> Database Driver Class Initialized
INFO - 2020-07-31 09:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:08:49 --> Email Class Initialized
INFO - 2020-07-31 09:08:49 --> Controller Class Initialized
INFO - 2020-07-31 09:08:49 --> Model Class Initialized
INFO - 2020-07-31 09:08:49 --> Model Class Initialized
DEBUG - 2020-07-31 09:08:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:08:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:08:49 --> Final output sent to browser
DEBUG - 2020-07-31 09:08:49 --> Total execution time: 0.0224
INFO - 2020-07-31 09:08:54 --> Config Class Initialized
INFO - 2020-07-31 09:08:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:08:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:08:54 --> Utf8 Class Initialized
INFO - 2020-07-31 09:08:54 --> URI Class Initialized
INFO - 2020-07-31 09:08:54 --> Router Class Initialized
INFO - 2020-07-31 09:08:54 --> Output Class Initialized
INFO - 2020-07-31 09:08:54 --> Security Class Initialized
DEBUG - 2020-07-31 09:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:08:54 --> Input Class Initialized
INFO - 2020-07-31 09:08:54 --> Language Class Initialized
INFO - 2020-07-31 09:08:54 --> Loader Class Initialized
INFO - 2020-07-31 09:08:54 --> Helper loaded: url_helper
INFO - 2020-07-31 09:08:54 --> Database Driver Class Initialized
INFO - 2020-07-31 09:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:08:54 --> Email Class Initialized
INFO - 2020-07-31 09:08:54 --> Controller Class Initialized
INFO - 2020-07-31 09:08:54 --> Model Class Initialized
INFO - 2020-07-31 09:08:54 --> Model Class Initialized
DEBUG - 2020-07-31 09:08:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:08:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:08:54 --> Model Class Initialized
INFO - 2020-07-31 09:08:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:08:54 --> Final output sent to browser
DEBUG - 2020-07-31 09:08:54 --> Total execution time: 0.0255
INFO - 2020-07-31 09:09:06 --> Config Class Initialized
INFO - 2020-07-31 09:09:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:09:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:09:06 --> Utf8 Class Initialized
INFO - 2020-07-31 09:09:06 --> URI Class Initialized
INFO - 2020-07-31 09:09:06 --> Router Class Initialized
INFO - 2020-07-31 09:09:06 --> Output Class Initialized
INFO - 2020-07-31 09:09:06 --> Security Class Initialized
DEBUG - 2020-07-31 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:09:06 --> Input Class Initialized
INFO - 2020-07-31 09:09:06 --> Language Class Initialized
INFO - 2020-07-31 09:09:06 --> Loader Class Initialized
INFO - 2020-07-31 09:09:06 --> Helper loaded: url_helper
INFO - 2020-07-31 09:09:06 --> Database Driver Class Initialized
INFO - 2020-07-31 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:09:06 --> Email Class Initialized
INFO - 2020-07-31 09:09:06 --> Controller Class Initialized
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
DEBUG - 2020-07-31 09:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:09:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
INFO - 2020-07-31 09:09:06 --> Config Class Initialized
INFO - 2020-07-31 09:09:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:09:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:09:06 --> Utf8 Class Initialized
INFO - 2020-07-31 09:09:06 --> URI Class Initialized
INFO - 2020-07-31 09:09:06 --> Router Class Initialized
INFO - 2020-07-31 09:09:06 --> Output Class Initialized
INFO - 2020-07-31 09:09:06 --> Security Class Initialized
DEBUG - 2020-07-31 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:09:06 --> Input Class Initialized
INFO - 2020-07-31 09:09:06 --> Language Class Initialized
INFO - 2020-07-31 09:09:06 --> Loader Class Initialized
INFO - 2020-07-31 09:09:06 --> Helper loaded: url_helper
INFO - 2020-07-31 09:09:06 --> Database Driver Class Initialized
INFO - 2020-07-31 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:09:06 --> Email Class Initialized
INFO - 2020-07-31 09:09:06 --> Controller Class Initialized
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
DEBUG - 2020-07-31 09:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:09:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
INFO - 2020-07-31 09:09:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:09:06 --> Final output sent to browser
DEBUG - 2020-07-31 09:09:06 --> Total execution time: 0.0244
INFO - 2020-07-31 09:09:06 --> Config Class Initialized
INFO - 2020-07-31 09:09:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:09:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:09:06 --> Utf8 Class Initialized
INFO - 2020-07-31 09:09:06 --> URI Class Initialized
DEBUG - 2020-07-31 09:09:06 --> No URI present. Default controller set.
INFO - 2020-07-31 09:09:06 --> Router Class Initialized
INFO - 2020-07-31 09:09:06 --> Output Class Initialized
INFO - 2020-07-31 09:09:06 --> Security Class Initialized
DEBUG - 2020-07-31 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:09:06 --> Input Class Initialized
INFO - 2020-07-31 09:09:06 --> Language Class Initialized
INFO - 2020-07-31 09:09:06 --> Loader Class Initialized
INFO - 2020-07-31 09:09:06 --> Helper loaded: url_helper
INFO - 2020-07-31 09:09:06 --> Database Driver Class Initialized
INFO - 2020-07-31 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:09:06 --> Email Class Initialized
INFO - 2020-07-31 09:09:06 --> Controller Class Initialized
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
INFO - 2020-07-31 09:09:06 --> Model Class Initialized
DEBUG - 2020-07-31 09:09:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:09:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:09:06 --> Final output sent to browser
DEBUG - 2020-07-31 09:09:06 --> Total execution time: 0.0232
INFO - 2020-07-31 09:09:23 --> Config Class Initialized
INFO - 2020-07-31 09:09:23 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:09:23 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:09:23 --> Utf8 Class Initialized
INFO - 2020-07-31 09:09:23 --> URI Class Initialized
INFO - 2020-07-31 09:09:23 --> Router Class Initialized
INFO - 2020-07-31 09:09:23 --> Output Class Initialized
INFO - 2020-07-31 09:09:23 --> Security Class Initialized
DEBUG - 2020-07-31 09:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:09:23 --> Input Class Initialized
INFO - 2020-07-31 09:09:23 --> Language Class Initialized
INFO - 2020-07-31 09:09:23 --> Loader Class Initialized
INFO - 2020-07-31 09:09:23 --> Helper loaded: url_helper
INFO - 2020-07-31 09:09:23 --> Database Driver Class Initialized
INFO - 2020-07-31 09:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:09:23 --> Email Class Initialized
INFO - 2020-07-31 09:09:23 --> Controller Class Initialized
INFO - 2020-07-31 09:09:23 --> Model Class Initialized
INFO - 2020-07-31 09:09:23 --> Model Class Initialized
DEBUG - 2020-07-31 09:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:09:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:09:23 --> Model Class Initialized
INFO - 2020-07-31 09:09:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:09:23 --> Final output sent to browser
DEBUG - 2020-07-31 09:09:23 --> Total execution time: 0.0261
INFO - 2020-07-31 09:10:05 --> Config Class Initialized
INFO - 2020-07-31 09:10:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:10:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:10:05 --> Utf8 Class Initialized
INFO - 2020-07-31 09:10:05 --> URI Class Initialized
INFO - 2020-07-31 09:10:05 --> Router Class Initialized
INFO - 2020-07-31 09:10:05 --> Output Class Initialized
INFO - 2020-07-31 09:10:05 --> Security Class Initialized
DEBUG - 2020-07-31 09:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:10:05 --> Input Class Initialized
INFO - 2020-07-31 09:10:05 --> Language Class Initialized
INFO - 2020-07-31 09:10:05 --> Loader Class Initialized
INFO - 2020-07-31 09:10:05 --> Helper loaded: url_helper
INFO - 2020-07-31 09:10:05 --> Database Driver Class Initialized
INFO - 2020-07-31 09:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:10:05 --> Email Class Initialized
INFO - 2020-07-31 09:10:05 --> Controller Class Initialized
INFO - 2020-07-31 09:10:05 --> Model Class Initialized
INFO - 2020-07-31 09:10:05 --> Model Class Initialized
DEBUG - 2020-07-31 09:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:10:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:10:05 --> Model Class Initialized
INFO - 2020-07-31 09:10:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:10:05 --> Final output sent to browser
DEBUG - 2020-07-31 09:10:05 --> Total execution time: 0.0219
INFO - 2020-07-31 09:11:54 --> Config Class Initialized
INFO - 2020-07-31 09:11:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:11:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:11:54 --> Utf8 Class Initialized
INFO - 2020-07-31 09:11:54 --> URI Class Initialized
INFO - 2020-07-31 09:11:54 --> Router Class Initialized
INFO - 2020-07-31 09:11:54 --> Output Class Initialized
INFO - 2020-07-31 09:11:54 --> Security Class Initialized
DEBUG - 2020-07-31 09:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:11:54 --> Input Class Initialized
INFO - 2020-07-31 09:11:54 --> Language Class Initialized
INFO - 2020-07-31 09:11:54 --> Loader Class Initialized
INFO - 2020-07-31 09:11:54 --> Helper loaded: url_helper
INFO - 2020-07-31 09:11:54 --> Database Driver Class Initialized
INFO - 2020-07-31 09:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:11:54 --> Email Class Initialized
INFO - 2020-07-31 09:11:54 --> Controller Class Initialized
INFO - 2020-07-31 09:11:54 --> Model Class Initialized
INFO - 2020-07-31 09:11:54 --> Model Class Initialized
DEBUG - 2020-07-31 09:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:11:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:11:54 --> Model Class Initialized
INFO - 2020-07-31 09:11:54 --> Config Class Initialized
INFO - 2020-07-31 09:11:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:11:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:11:54 --> Utf8 Class Initialized
INFO - 2020-07-31 09:11:54 --> URI Class Initialized
DEBUG - 2020-07-31 09:11:54 --> No URI present. Default controller set.
INFO - 2020-07-31 09:11:54 --> Router Class Initialized
INFO - 2020-07-31 09:11:54 --> Output Class Initialized
INFO - 2020-07-31 09:11:54 --> Security Class Initialized
DEBUG - 2020-07-31 09:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:11:54 --> Input Class Initialized
INFO - 2020-07-31 09:11:54 --> Language Class Initialized
INFO - 2020-07-31 09:11:54 --> Loader Class Initialized
INFO - 2020-07-31 09:11:54 --> Helper loaded: url_helper
INFO - 2020-07-31 09:11:54 --> Database Driver Class Initialized
INFO - 2020-07-31 09:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:11:54 --> Email Class Initialized
INFO - 2020-07-31 09:11:54 --> Controller Class Initialized
INFO - 2020-07-31 09:11:54 --> Model Class Initialized
INFO - 2020-07-31 09:11:54 --> Model Class Initialized
DEBUG - 2020-07-31 09:11:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:11:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:11:54 --> Final output sent to browser
DEBUG - 2020-07-31 09:11:54 --> Total execution time: 0.0220
INFO - 2020-07-31 09:12:18 --> Config Class Initialized
INFO - 2020-07-31 09:12:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:12:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:12:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:12:18 --> URI Class Initialized
DEBUG - 2020-07-31 09:12:18 --> No URI present. Default controller set.
INFO - 2020-07-31 09:12:18 --> Router Class Initialized
INFO - 2020-07-31 09:12:18 --> Output Class Initialized
INFO - 2020-07-31 09:12:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:12:18 --> Input Class Initialized
INFO - 2020-07-31 09:12:18 --> Language Class Initialized
INFO - 2020-07-31 09:12:18 --> Loader Class Initialized
INFO - 2020-07-31 09:12:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:12:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:12:18 --> Email Class Initialized
INFO - 2020-07-31 09:12:18 --> Controller Class Initialized
INFO - 2020-07-31 09:12:18 --> Model Class Initialized
INFO - 2020-07-31 09:12:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:12:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:12:19 --> Final output sent to browser
DEBUG - 2020-07-31 09:12:19 --> Total execution time: 0.0227
INFO - 2020-07-31 09:12:21 --> Config Class Initialized
INFO - 2020-07-31 09:12:21 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:12:21 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:12:21 --> Utf8 Class Initialized
INFO - 2020-07-31 09:12:21 --> URI Class Initialized
INFO - 2020-07-31 09:12:21 --> Router Class Initialized
INFO - 2020-07-31 09:12:21 --> Output Class Initialized
INFO - 2020-07-31 09:12:21 --> Security Class Initialized
DEBUG - 2020-07-31 09:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:12:21 --> Input Class Initialized
INFO - 2020-07-31 09:12:21 --> Language Class Initialized
INFO - 2020-07-31 09:12:21 --> Loader Class Initialized
INFO - 2020-07-31 09:12:21 --> Helper loaded: url_helper
INFO - 2020-07-31 09:12:21 --> Database Driver Class Initialized
INFO - 2020-07-31 09:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:12:21 --> Email Class Initialized
INFO - 2020-07-31 09:12:21 --> Controller Class Initialized
INFO - 2020-07-31 09:12:21 --> Model Class Initialized
INFO - 2020-07-31 09:12:21 --> Model Class Initialized
DEBUG - 2020-07-31 09:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:12:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:12:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:12:21 --> Final output sent to browser
DEBUG - 2020-07-31 09:12:21 --> Total execution time: 0.0199
INFO - 2020-07-31 09:12:25 --> Config Class Initialized
INFO - 2020-07-31 09:12:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:12:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:12:25 --> Utf8 Class Initialized
INFO - 2020-07-31 09:12:25 --> URI Class Initialized
INFO - 2020-07-31 09:12:25 --> Router Class Initialized
INFO - 2020-07-31 09:12:25 --> Output Class Initialized
INFO - 2020-07-31 09:12:25 --> Security Class Initialized
DEBUG - 2020-07-31 09:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:12:25 --> Input Class Initialized
INFO - 2020-07-31 09:12:25 --> Language Class Initialized
INFO - 2020-07-31 09:12:25 --> Loader Class Initialized
INFO - 2020-07-31 09:12:25 --> Helper loaded: url_helper
INFO - 2020-07-31 09:12:25 --> Database Driver Class Initialized
INFO - 2020-07-31 09:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:12:25 --> Email Class Initialized
INFO - 2020-07-31 09:12:25 --> Controller Class Initialized
INFO - 2020-07-31 09:12:25 --> Model Class Initialized
INFO - 2020-07-31 09:12:25 --> Model Class Initialized
DEBUG - 2020-07-31 09:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:12:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:12:25 --> Model Class Initialized
INFO - 2020-07-31 09:12:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:12:25 --> Final output sent to browser
DEBUG - 2020-07-31 09:12:25 --> Total execution time: 0.0764
INFO - 2020-07-31 09:12:44 --> Config Class Initialized
INFO - 2020-07-31 09:12:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:12:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:12:44 --> Utf8 Class Initialized
INFO - 2020-07-31 09:12:44 --> URI Class Initialized
INFO - 2020-07-31 09:12:44 --> Router Class Initialized
INFO - 2020-07-31 09:12:44 --> Output Class Initialized
INFO - 2020-07-31 09:12:44 --> Security Class Initialized
DEBUG - 2020-07-31 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:12:44 --> Input Class Initialized
INFO - 2020-07-31 09:12:44 --> Language Class Initialized
INFO - 2020-07-31 09:12:44 --> Loader Class Initialized
INFO - 2020-07-31 09:12:44 --> Helper loaded: url_helper
INFO - 2020-07-31 09:12:44 --> Database Driver Class Initialized
INFO - 2020-07-31 09:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:12:44 --> Email Class Initialized
INFO - 2020-07-31 09:12:44 --> Controller Class Initialized
INFO - 2020-07-31 09:12:44 --> Model Class Initialized
INFO - 2020-07-31 09:12:44 --> Model Class Initialized
DEBUG - 2020-07-31 09:12:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:12:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:12:44 --> Model Class Initialized
INFO - 2020-07-31 09:12:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:12:44 --> Final output sent to browser
DEBUG - 2020-07-31 09:12:44 --> Total execution time: 0.0247
INFO - 2020-07-31 09:13:05 --> Config Class Initialized
INFO - 2020-07-31 09:13:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:13:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:13:05 --> Utf8 Class Initialized
INFO - 2020-07-31 09:13:05 --> URI Class Initialized
INFO - 2020-07-31 09:13:05 --> Router Class Initialized
INFO - 2020-07-31 09:13:05 --> Output Class Initialized
INFO - 2020-07-31 09:13:05 --> Security Class Initialized
DEBUG - 2020-07-31 09:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:13:05 --> Input Class Initialized
INFO - 2020-07-31 09:13:05 --> Language Class Initialized
INFO - 2020-07-31 09:13:05 --> Loader Class Initialized
INFO - 2020-07-31 09:13:05 --> Helper loaded: url_helper
INFO - 2020-07-31 09:13:05 --> Database Driver Class Initialized
INFO - 2020-07-31 09:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:13:05 --> Email Class Initialized
INFO - 2020-07-31 09:13:05 --> Controller Class Initialized
INFO - 2020-07-31 09:13:05 --> Model Class Initialized
INFO - 2020-07-31 09:13:05 --> Model Class Initialized
DEBUG - 2020-07-31 09:13:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:13:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:13:05 --> Model Class Initialized
INFO - 2020-07-31 09:13:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:13:05 --> Final output sent to browser
DEBUG - 2020-07-31 09:13:05 --> Total execution time: 0.0229
INFO - 2020-07-31 09:13:29 --> Config Class Initialized
INFO - 2020-07-31 09:13:29 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:13:29 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:13:29 --> Utf8 Class Initialized
INFO - 2020-07-31 09:13:29 --> URI Class Initialized
INFO - 2020-07-31 09:13:29 --> Router Class Initialized
INFO - 2020-07-31 09:13:29 --> Output Class Initialized
INFO - 2020-07-31 09:13:29 --> Security Class Initialized
DEBUG - 2020-07-31 09:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:13:29 --> Input Class Initialized
INFO - 2020-07-31 09:13:29 --> Language Class Initialized
INFO - 2020-07-31 09:13:29 --> Loader Class Initialized
INFO - 2020-07-31 09:13:29 --> Helper loaded: url_helper
INFO - 2020-07-31 09:13:29 --> Database Driver Class Initialized
INFO - 2020-07-31 09:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:13:29 --> Email Class Initialized
INFO - 2020-07-31 09:13:29 --> Controller Class Initialized
INFO - 2020-07-31 09:13:29 --> Model Class Initialized
INFO - 2020-07-31 09:13:29 --> Model Class Initialized
DEBUG - 2020-07-31 09:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:13:29 --> Model Class Initialized
INFO - 2020-07-31 09:13:29 --> Config Class Initialized
INFO - 2020-07-31 09:13:29 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:13:29 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:13:29 --> Utf8 Class Initialized
INFO - 2020-07-31 09:13:29 --> URI Class Initialized
DEBUG - 2020-07-31 09:13:29 --> No URI present. Default controller set.
INFO - 2020-07-31 09:13:29 --> Router Class Initialized
INFO - 2020-07-31 09:13:29 --> Output Class Initialized
INFO - 2020-07-31 09:13:29 --> Security Class Initialized
DEBUG - 2020-07-31 09:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:13:29 --> Input Class Initialized
INFO - 2020-07-31 09:13:29 --> Language Class Initialized
INFO - 2020-07-31 09:13:29 --> Loader Class Initialized
INFO - 2020-07-31 09:13:29 --> Helper loaded: url_helper
INFO - 2020-07-31 09:13:29 --> Database Driver Class Initialized
INFO - 2020-07-31 09:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:13:29 --> Email Class Initialized
INFO - 2020-07-31 09:13:29 --> Controller Class Initialized
INFO - 2020-07-31 09:13:29 --> Model Class Initialized
INFO - 2020-07-31 09:13:29 --> Model Class Initialized
DEBUG - 2020-07-31 09:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:13:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:13:29 --> Final output sent to browser
DEBUG - 2020-07-31 09:13:29 --> Total execution time: 0.0183
INFO - 2020-07-31 09:19:50 --> Config Class Initialized
INFO - 2020-07-31 09:19:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:19:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:19:50 --> Utf8 Class Initialized
INFO - 2020-07-31 09:19:50 --> URI Class Initialized
INFO - 2020-07-31 09:19:50 --> Router Class Initialized
INFO - 2020-07-31 09:19:50 --> Output Class Initialized
INFO - 2020-07-31 09:19:50 --> Security Class Initialized
DEBUG - 2020-07-31 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:19:50 --> Input Class Initialized
INFO - 2020-07-31 09:19:50 --> Language Class Initialized
INFO - 2020-07-31 09:19:50 --> Loader Class Initialized
INFO - 2020-07-31 09:19:50 --> Helper loaded: url_helper
INFO - 2020-07-31 09:19:50 --> Database Driver Class Initialized
INFO - 2020-07-31 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:19:50 --> Email Class Initialized
INFO - 2020-07-31 09:19:50 --> Controller Class Initialized
INFO - 2020-07-31 09:19:50 --> Model Class Initialized
INFO - 2020-07-31 09:19:50 --> Model Class Initialized
DEBUG - 2020-07-31 09:19:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:19:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:19:50 --> Model Class Initialized
INFO - 2020-07-31 09:19:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:19:50 --> Final output sent to browser
DEBUG - 2020-07-31 09:19:50 --> Total execution time: 0.0704
INFO - 2020-07-31 09:20:54 --> Config Class Initialized
INFO - 2020-07-31 09:20:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:20:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:20:54 --> Utf8 Class Initialized
INFO - 2020-07-31 09:20:54 --> URI Class Initialized
INFO - 2020-07-31 09:20:54 --> Router Class Initialized
INFO - 2020-07-31 09:20:54 --> Output Class Initialized
INFO - 2020-07-31 09:20:54 --> Security Class Initialized
DEBUG - 2020-07-31 09:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:20:54 --> Input Class Initialized
INFO - 2020-07-31 09:20:54 --> Language Class Initialized
INFO - 2020-07-31 09:20:54 --> Loader Class Initialized
INFO - 2020-07-31 09:20:54 --> Helper loaded: url_helper
INFO - 2020-07-31 09:20:54 --> Database Driver Class Initialized
INFO - 2020-07-31 09:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:20:54 --> Email Class Initialized
INFO - 2020-07-31 09:20:54 --> Controller Class Initialized
INFO - 2020-07-31 09:20:54 --> Model Class Initialized
INFO - 2020-07-31 09:20:54 --> Model Class Initialized
DEBUG - 2020-07-31 09:20:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:20:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:20:54 --> Model Class Initialized
INFO - 2020-07-31 09:20:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:20:54 --> Final output sent to browser
DEBUG - 2020-07-31 09:20:54 --> Total execution time: 0.0734
INFO - 2020-07-31 09:20:57 --> Config Class Initialized
INFO - 2020-07-31 09:20:57 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:20:57 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:20:57 --> Utf8 Class Initialized
INFO - 2020-07-31 09:20:57 --> URI Class Initialized
DEBUG - 2020-07-31 09:20:57 --> No URI present. Default controller set.
INFO - 2020-07-31 09:20:57 --> Router Class Initialized
INFO - 2020-07-31 09:20:57 --> Output Class Initialized
INFO - 2020-07-31 09:20:57 --> Security Class Initialized
DEBUG - 2020-07-31 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:20:57 --> Input Class Initialized
INFO - 2020-07-31 09:20:57 --> Language Class Initialized
INFO - 2020-07-31 09:20:57 --> Loader Class Initialized
INFO - 2020-07-31 09:20:57 --> Helper loaded: url_helper
INFO - 2020-07-31 09:20:57 --> Database Driver Class Initialized
INFO - 2020-07-31 09:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:20:57 --> Email Class Initialized
INFO - 2020-07-31 09:20:57 --> Controller Class Initialized
INFO - 2020-07-31 09:20:57 --> Model Class Initialized
INFO - 2020-07-31 09:20:57 --> Model Class Initialized
DEBUG - 2020-07-31 09:20:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:20:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:20:57 --> Final output sent to browser
DEBUG - 2020-07-31 09:20:57 --> Total execution time: 0.0205
INFO - 2020-07-31 09:21:04 --> Config Class Initialized
INFO - 2020-07-31 09:21:04 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:21:04 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:21:04 --> Utf8 Class Initialized
INFO - 2020-07-31 09:21:04 --> URI Class Initialized
INFO - 2020-07-31 09:21:04 --> Router Class Initialized
INFO - 2020-07-31 09:21:04 --> Output Class Initialized
INFO - 2020-07-31 09:21:04 --> Security Class Initialized
DEBUG - 2020-07-31 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:21:04 --> Input Class Initialized
INFO - 2020-07-31 09:21:04 --> Language Class Initialized
INFO - 2020-07-31 09:21:04 --> Loader Class Initialized
INFO - 2020-07-31 09:21:04 --> Helper loaded: url_helper
INFO - 2020-07-31 09:21:04 --> Database Driver Class Initialized
INFO - 2020-07-31 09:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:21:04 --> Email Class Initialized
INFO - 2020-07-31 09:21:04 --> Controller Class Initialized
INFO - 2020-07-31 09:21:04 --> Model Class Initialized
INFO - 2020-07-31 09:21:04 --> Model Class Initialized
DEBUG - 2020-07-31 09:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:21:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:21:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:21:04 --> Final output sent to browser
DEBUG - 2020-07-31 09:21:04 --> Total execution time: 0.0238
INFO - 2020-07-31 09:21:10 --> Config Class Initialized
INFO - 2020-07-31 09:21:10 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:21:10 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:21:10 --> Utf8 Class Initialized
INFO - 2020-07-31 09:21:10 --> URI Class Initialized
INFO - 2020-07-31 09:21:10 --> Router Class Initialized
INFO - 2020-07-31 09:21:10 --> Output Class Initialized
INFO - 2020-07-31 09:21:10 --> Security Class Initialized
DEBUG - 2020-07-31 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:21:10 --> Input Class Initialized
INFO - 2020-07-31 09:21:10 --> Language Class Initialized
INFO - 2020-07-31 09:21:10 --> Loader Class Initialized
INFO - 2020-07-31 09:21:10 --> Helper loaded: url_helper
INFO - 2020-07-31 09:21:10 --> Database Driver Class Initialized
INFO - 2020-07-31 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:21:10 --> Email Class Initialized
INFO - 2020-07-31 09:21:10 --> Controller Class Initialized
INFO - 2020-07-31 09:21:10 --> Model Class Initialized
INFO - 2020-07-31 09:21:10 --> Model Class Initialized
DEBUG - 2020-07-31 09:21:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:21:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:21:10 --> Model Class Initialized
INFO - 2020-07-31 09:21:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:21:10 --> Final output sent to browser
DEBUG - 2020-07-31 09:21:10 --> Total execution time: 0.0775
INFO - 2020-07-31 09:21:44 --> Config Class Initialized
INFO - 2020-07-31 09:21:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:21:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:21:44 --> Utf8 Class Initialized
INFO - 2020-07-31 09:21:44 --> URI Class Initialized
INFO - 2020-07-31 09:21:44 --> Router Class Initialized
INFO - 2020-07-31 09:21:44 --> Output Class Initialized
INFO - 2020-07-31 09:21:44 --> Security Class Initialized
DEBUG - 2020-07-31 09:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:21:44 --> Input Class Initialized
INFO - 2020-07-31 09:21:44 --> Language Class Initialized
INFO - 2020-07-31 09:21:44 --> Loader Class Initialized
INFO - 2020-07-31 09:21:44 --> Helper loaded: url_helper
INFO - 2020-07-31 09:21:44 --> Database Driver Class Initialized
INFO - 2020-07-31 09:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:21:44 --> Email Class Initialized
INFO - 2020-07-31 09:21:44 --> Controller Class Initialized
INFO - 2020-07-31 09:21:44 --> Model Class Initialized
INFO - 2020-07-31 09:21:44 --> Model Class Initialized
DEBUG - 2020-07-31 09:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:21:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:21:44 --> Model Class Initialized
INFO - 2020-07-31 09:21:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:21:44 --> Final output sent to browser
DEBUG - 2020-07-31 09:21:44 --> Total execution time: 0.0258
INFO - 2020-07-31 09:21:48 --> Config Class Initialized
INFO - 2020-07-31 09:21:48 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:21:48 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:21:48 --> Utf8 Class Initialized
INFO - 2020-07-31 09:21:48 --> URI Class Initialized
INFO - 2020-07-31 09:21:48 --> Router Class Initialized
INFO - 2020-07-31 09:21:48 --> Output Class Initialized
INFO - 2020-07-31 09:21:48 --> Security Class Initialized
DEBUG - 2020-07-31 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:21:48 --> Input Class Initialized
INFO - 2020-07-31 09:21:48 --> Language Class Initialized
INFO - 2020-07-31 09:21:48 --> Loader Class Initialized
INFO - 2020-07-31 09:21:48 --> Helper loaded: url_helper
INFO - 2020-07-31 09:21:48 --> Database Driver Class Initialized
INFO - 2020-07-31 09:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:21:48 --> Email Class Initialized
INFO - 2020-07-31 09:21:48 --> Controller Class Initialized
INFO - 2020-07-31 09:21:48 --> Model Class Initialized
INFO - 2020-07-31 09:21:48 --> Model Class Initialized
DEBUG - 2020-07-31 09:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:21:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:21:48 --> Model Class Initialized
INFO - 2020-07-31 09:21:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:21:48 --> Final output sent to browser
DEBUG - 2020-07-31 09:21:48 --> Total execution time: 0.0256
INFO - 2020-07-31 09:21:50 --> Config Class Initialized
INFO - 2020-07-31 09:21:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:21:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:21:50 --> Utf8 Class Initialized
INFO - 2020-07-31 09:21:50 --> URI Class Initialized
INFO - 2020-07-31 09:21:50 --> Router Class Initialized
INFO - 2020-07-31 09:21:50 --> Output Class Initialized
INFO - 2020-07-31 09:21:50 --> Security Class Initialized
DEBUG - 2020-07-31 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:21:50 --> Input Class Initialized
INFO - 2020-07-31 09:21:50 --> Language Class Initialized
INFO - 2020-07-31 09:21:50 --> Loader Class Initialized
INFO - 2020-07-31 09:21:50 --> Helper loaded: url_helper
INFO - 2020-07-31 09:21:50 --> Database Driver Class Initialized
INFO - 2020-07-31 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:21:50 --> Email Class Initialized
INFO - 2020-07-31 09:21:50 --> Controller Class Initialized
INFO - 2020-07-31 09:21:50 --> Model Class Initialized
INFO - 2020-07-31 09:21:50 --> Model Class Initialized
DEBUG - 2020-07-31 09:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:21:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:21:50 --> Model Class Initialized
INFO - 2020-07-31 09:21:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:21:50 --> Final output sent to browser
DEBUG - 2020-07-31 09:21:50 --> Total execution time: 0.0254
INFO - 2020-07-31 09:21:58 --> Config Class Initialized
INFO - 2020-07-31 09:21:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:21:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:21:58 --> Utf8 Class Initialized
INFO - 2020-07-31 09:21:58 --> URI Class Initialized
INFO - 2020-07-31 09:21:58 --> Router Class Initialized
INFO - 2020-07-31 09:21:58 --> Output Class Initialized
INFO - 2020-07-31 09:21:58 --> Security Class Initialized
DEBUG - 2020-07-31 09:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:21:58 --> Input Class Initialized
INFO - 2020-07-31 09:21:58 --> Language Class Initialized
INFO - 2020-07-31 09:21:58 --> Loader Class Initialized
INFO - 2020-07-31 09:21:58 --> Helper loaded: url_helper
INFO - 2020-07-31 09:21:58 --> Database Driver Class Initialized
INFO - 2020-07-31 09:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:21:58 --> Email Class Initialized
INFO - 2020-07-31 09:21:58 --> Controller Class Initialized
INFO - 2020-07-31 09:21:58 --> Model Class Initialized
INFO - 2020-07-31 09:21:58 --> Model Class Initialized
DEBUG - 2020-07-31 09:21:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:21:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:21:58 --> Model Class Initialized
INFO - 2020-07-31 09:21:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:21:58 --> Final output sent to browser
DEBUG - 2020-07-31 09:21:58 --> Total execution time: 0.0270
INFO - 2020-07-31 09:22:08 --> Config Class Initialized
INFO - 2020-07-31 09:22:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:22:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:22:08 --> Utf8 Class Initialized
INFO - 2020-07-31 09:22:08 --> URI Class Initialized
INFO - 2020-07-31 09:22:08 --> Router Class Initialized
INFO - 2020-07-31 09:22:08 --> Output Class Initialized
INFO - 2020-07-31 09:22:08 --> Security Class Initialized
DEBUG - 2020-07-31 09:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:22:08 --> Input Class Initialized
INFO - 2020-07-31 09:22:08 --> Language Class Initialized
INFO - 2020-07-31 09:22:08 --> Loader Class Initialized
INFO - 2020-07-31 09:22:08 --> Helper loaded: url_helper
INFO - 2020-07-31 09:22:08 --> Database Driver Class Initialized
INFO - 2020-07-31 09:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:22:08 --> Email Class Initialized
INFO - 2020-07-31 09:22:08 --> Controller Class Initialized
INFO - 2020-07-31 09:22:08 --> Model Class Initialized
INFO - 2020-07-31 09:22:08 --> Model Class Initialized
DEBUG - 2020-07-31 09:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:22:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:22:08 --> Model Class Initialized
INFO - 2020-07-31 09:22:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:22:08 --> Final output sent to browser
DEBUG - 2020-07-31 09:22:08 --> Total execution time: 0.0257
INFO - 2020-07-31 09:22:51 --> Config Class Initialized
INFO - 2020-07-31 09:22:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:22:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:22:51 --> Utf8 Class Initialized
INFO - 2020-07-31 09:22:51 --> URI Class Initialized
DEBUG - 2020-07-31 09:22:51 --> No URI present. Default controller set.
INFO - 2020-07-31 09:22:51 --> Router Class Initialized
INFO - 2020-07-31 09:22:51 --> Output Class Initialized
INFO - 2020-07-31 09:22:51 --> Security Class Initialized
DEBUG - 2020-07-31 09:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:22:51 --> Input Class Initialized
INFO - 2020-07-31 09:22:51 --> Language Class Initialized
INFO - 2020-07-31 09:22:51 --> Loader Class Initialized
INFO - 2020-07-31 09:22:51 --> Helper loaded: url_helper
INFO - 2020-07-31 09:22:51 --> Database Driver Class Initialized
INFO - 2020-07-31 09:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:22:51 --> Email Class Initialized
INFO - 2020-07-31 09:22:51 --> Controller Class Initialized
INFO - 2020-07-31 09:22:51 --> Model Class Initialized
INFO - 2020-07-31 09:22:51 --> Model Class Initialized
DEBUG - 2020-07-31 09:22:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:22:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:22:51 --> Final output sent to browser
DEBUG - 2020-07-31 09:22:51 --> Total execution time: 0.0241
INFO - 2020-07-31 09:22:56 --> Config Class Initialized
INFO - 2020-07-31 09:22:56 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:22:56 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:22:56 --> Utf8 Class Initialized
INFO - 2020-07-31 09:22:56 --> URI Class Initialized
INFO - 2020-07-31 09:22:56 --> Router Class Initialized
INFO - 2020-07-31 09:22:56 --> Output Class Initialized
INFO - 2020-07-31 09:22:56 --> Security Class Initialized
DEBUG - 2020-07-31 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:22:56 --> Input Class Initialized
INFO - 2020-07-31 09:22:56 --> Language Class Initialized
INFO - 2020-07-31 09:22:56 --> Loader Class Initialized
INFO - 2020-07-31 09:22:56 --> Helper loaded: url_helper
INFO - 2020-07-31 09:22:56 --> Database Driver Class Initialized
INFO - 2020-07-31 09:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:22:56 --> Email Class Initialized
INFO - 2020-07-31 09:22:56 --> Controller Class Initialized
INFO - 2020-07-31 09:22:56 --> Model Class Initialized
INFO - 2020-07-31 09:22:56 --> Model Class Initialized
DEBUG - 2020-07-31 09:22:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:22:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:22:56 --> Model Class Initialized
INFO - 2020-07-31 09:22:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:22:56 --> Final output sent to browser
DEBUG - 2020-07-31 09:22:56 --> Total execution time: 0.0231
INFO - 2020-07-31 09:23:18 --> Config Class Initialized
INFO - 2020-07-31 09:23:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:23:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:23:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:23:18 --> URI Class Initialized
INFO - 2020-07-31 09:23:18 --> Router Class Initialized
INFO - 2020-07-31 09:23:18 --> Output Class Initialized
INFO - 2020-07-31 09:23:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:23:18 --> Input Class Initialized
INFO - 2020-07-31 09:23:18 --> Language Class Initialized
INFO - 2020-07-31 09:23:18 --> Loader Class Initialized
INFO - 2020-07-31 09:23:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:23:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:23:18 --> Email Class Initialized
INFO - 2020-07-31 09:23:18 --> Controller Class Initialized
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:23:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:23:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
INFO - 2020-07-31 09:23:18 --> Config Class Initialized
INFO - 2020-07-31 09:23:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:23:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:23:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:23:18 --> URI Class Initialized
INFO - 2020-07-31 09:23:18 --> Router Class Initialized
INFO - 2020-07-31 09:23:18 --> Output Class Initialized
INFO - 2020-07-31 09:23:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:23:18 --> Input Class Initialized
INFO - 2020-07-31 09:23:18 --> Language Class Initialized
INFO - 2020-07-31 09:23:18 --> Loader Class Initialized
INFO - 2020-07-31 09:23:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:23:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:23:18 --> Email Class Initialized
INFO - 2020-07-31 09:23:18 --> Controller Class Initialized
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:23:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:23:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
INFO - 2020-07-31 09:23:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:23:18 --> Final output sent to browser
DEBUG - 2020-07-31 09:23:18 --> Total execution time: 0.0252
INFO - 2020-07-31 09:23:18 --> Config Class Initialized
INFO - 2020-07-31 09:23:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:23:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:23:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:23:18 --> URI Class Initialized
DEBUG - 2020-07-31 09:23:18 --> No URI present. Default controller set.
INFO - 2020-07-31 09:23:18 --> Router Class Initialized
INFO - 2020-07-31 09:23:18 --> Output Class Initialized
INFO - 2020-07-31 09:23:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:23:18 --> Input Class Initialized
INFO - 2020-07-31 09:23:18 --> Language Class Initialized
INFO - 2020-07-31 09:23:18 --> Loader Class Initialized
INFO - 2020-07-31 09:23:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:23:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:23:18 --> Email Class Initialized
INFO - 2020-07-31 09:23:18 --> Controller Class Initialized
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
INFO - 2020-07-31 09:23:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:23:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:23:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:23:18 --> Final output sent to browser
DEBUG - 2020-07-31 09:23:18 --> Total execution time: 0.0236
INFO - 2020-07-31 09:23:31 --> Config Class Initialized
INFO - 2020-07-31 09:23:31 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:23:31 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:23:31 --> Utf8 Class Initialized
INFO - 2020-07-31 09:23:31 --> URI Class Initialized
INFO - 2020-07-31 09:23:31 --> Router Class Initialized
INFO - 2020-07-31 09:23:31 --> Output Class Initialized
INFO - 2020-07-31 09:23:31 --> Security Class Initialized
DEBUG - 2020-07-31 09:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:23:31 --> Input Class Initialized
INFO - 2020-07-31 09:23:31 --> Language Class Initialized
INFO - 2020-07-31 09:23:31 --> Loader Class Initialized
INFO - 2020-07-31 09:23:31 --> Helper loaded: url_helper
INFO - 2020-07-31 09:23:31 --> Database Driver Class Initialized
INFO - 2020-07-31 09:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:23:31 --> Email Class Initialized
INFO - 2020-07-31 09:23:31 --> Controller Class Initialized
INFO - 2020-07-31 09:23:31 --> Model Class Initialized
INFO - 2020-07-31 09:23:31 --> Model Class Initialized
DEBUG - 2020-07-31 09:23:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:23:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:23:31 --> Model Class Initialized
INFO - 2020-07-31 09:23:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:23:31 --> Final output sent to browser
DEBUG - 2020-07-31 09:23:31 --> Total execution time: 0.0255
INFO - 2020-07-31 09:23:56 --> Config Class Initialized
INFO - 2020-07-31 09:23:56 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:23:56 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:23:56 --> Utf8 Class Initialized
INFO - 2020-07-31 09:23:56 --> URI Class Initialized
INFO - 2020-07-31 09:23:56 --> Router Class Initialized
INFO - 2020-07-31 09:23:56 --> Output Class Initialized
INFO - 2020-07-31 09:23:56 --> Security Class Initialized
DEBUG - 2020-07-31 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:23:56 --> Input Class Initialized
INFO - 2020-07-31 09:23:56 --> Language Class Initialized
INFO - 2020-07-31 09:23:56 --> Loader Class Initialized
INFO - 2020-07-31 09:23:56 --> Helper loaded: url_helper
INFO - 2020-07-31 09:23:56 --> Database Driver Class Initialized
INFO - 2020-07-31 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:23:56 --> Email Class Initialized
INFO - 2020-07-31 09:23:56 --> Controller Class Initialized
INFO - 2020-07-31 09:23:56 --> Model Class Initialized
INFO - 2020-07-31 09:23:56 --> Model Class Initialized
DEBUG - 2020-07-31 09:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:23:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:23:56 --> Model Class Initialized
INFO - 2020-07-31 09:23:56 --> Config Class Initialized
INFO - 2020-07-31 09:23:56 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:23:56 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:23:56 --> Utf8 Class Initialized
INFO - 2020-07-31 09:23:56 --> URI Class Initialized
DEBUG - 2020-07-31 09:23:56 --> No URI present. Default controller set.
INFO - 2020-07-31 09:23:56 --> Router Class Initialized
INFO - 2020-07-31 09:23:56 --> Output Class Initialized
INFO - 2020-07-31 09:23:56 --> Security Class Initialized
DEBUG - 2020-07-31 09:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:23:56 --> Input Class Initialized
INFO - 2020-07-31 09:23:56 --> Language Class Initialized
INFO - 2020-07-31 09:23:56 --> Loader Class Initialized
INFO - 2020-07-31 09:23:56 --> Helper loaded: url_helper
INFO - 2020-07-31 09:23:56 --> Database Driver Class Initialized
INFO - 2020-07-31 09:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:23:56 --> Email Class Initialized
INFO - 2020-07-31 09:23:56 --> Controller Class Initialized
INFO - 2020-07-31 09:23:56 --> Model Class Initialized
INFO - 2020-07-31 09:23:56 --> Model Class Initialized
DEBUG - 2020-07-31 09:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:23:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:23:56 --> Final output sent to browser
DEBUG - 2020-07-31 09:23:56 --> Total execution time: 0.0218
INFO - 2020-07-31 09:24:16 --> Config Class Initialized
INFO - 2020-07-31 09:24:16 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:24:16 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:24:16 --> Utf8 Class Initialized
INFO - 2020-07-31 09:24:16 --> URI Class Initialized
DEBUG - 2020-07-31 09:24:16 --> No URI present. Default controller set.
INFO - 2020-07-31 09:24:16 --> Router Class Initialized
INFO - 2020-07-31 09:24:16 --> Output Class Initialized
INFO - 2020-07-31 09:24:16 --> Security Class Initialized
DEBUG - 2020-07-31 09:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:24:16 --> Input Class Initialized
INFO - 2020-07-31 09:24:16 --> Language Class Initialized
INFO - 2020-07-31 09:24:16 --> Loader Class Initialized
INFO - 2020-07-31 09:24:16 --> Helper loaded: url_helper
INFO - 2020-07-31 09:24:16 --> Database Driver Class Initialized
INFO - 2020-07-31 09:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:24:16 --> Email Class Initialized
INFO - 2020-07-31 09:24:16 --> Controller Class Initialized
INFO - 2020-07-31 09:24:16 --> Model Class Initialized
INFO - 2020-07-31 09:24:16 --> Model Class Initialized
DEBUG - 2020-07-31 09:24:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:24:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:24:16 --> Final output sent to browser
DEBUG - 2020-07-31 09:24:16 --> Total execution time: 0.0229
INFO - 2020-07-31 09:24:19 --> Config Class Initialized
INFO - 2020-07-31 09:24:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:24:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:24:19 --> Utf8 Class Initialized
INFO - 2020-07-31 09:24:19 --> URI Class Initialized
INFO - 2020-07-31 09:24:19 --> Router Class Initialized
INFO - 2020-07-31 09:24:19 --> Output Class Initialized
INFO - 2020-07-31 09:24:19 --> Security Class Initialized
DEBUG - 2020-07-31 09:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:24:19 --> Input Class Initialized
INFO - 2020-07-31 09:24:19 --> Language Class Initialized
INFO - 2020-07-31 09:24:19 --> Loader Class Initialized
INFO - 2020-07-31 09:24:19 --> Helper loaded: url_helper
INFO - 2020-07-31 09:24:19 --> Database Driver Class Initialized
INFO - 2020-07-31 09:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:24:19 --> Email Class Initialized
INFO - 2020-07-31 09:24:19 --> Controller Class Initialized
INFO - 2020-07-31 09:24:19 --> Model Class Initialized
INFO - 2020-07-31 09:24:19 --> Model Class Initialized
DEBUG - 2020-07-31 09:24:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:24:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:24:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:24:19 --> Final output sent to browser
DEBUG - 2020-07-31 09:24:19 --> Total execution time: 0.0227
INFO - 2020-07-31 09:24:23 --> Config Class Initialized
INFO - 2020-07-31 09:24:23 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:24:23 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:24:23 --> Utf8 Class Initialized
INFO - 2020-07-31 09:24:23 --> URI Class Initialized
INFO - 2020-07-31 09:24:23 --> Router Class Initialized
INFO - 2020-07-31 09:24:23 --> Output Class Initialized
INFO - 2020-07-31 09:24:23 --> Security Class Initialized
DEBUG - 2020-07-31 09:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:24:23 --> Input Class Initialized
INFO - 2020-07-31 09:24:23 --> Language Class Initialized
INFO - 2020-07-31 09:24:23 --> Loader Class Initialized
INFO - 2020-07-31 09:24:23 --> Helper loaded: url_helper
INFO - 2020-07-31 09:24:23 --> Database Driver Class Initialized
INFO - 2020-07-31 09:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:24:23 --> Email Class Initialized
INFO - 2020-07-31 09:24:23 --> Controller Class Initialized
INFO - 2020-07-31 09:24:23 --> Model Class Initialized
INFO - 2020-07-31 09:24:23 --> Model Class Initialized
DEBUG - 2020-07-31 09:24:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:24:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:24:23 --> Model Class Initialized
INFO - 2020-07-31 09:24:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:24:23 --> Final output sent to browser
DEBUG - 2020-07-31 09:24:23 --> Total execution time: 0.0601
INFO - 2020-07-31 09:24:29 --> Config Class Initialized
INFO - 2020-07-31 09:24:29 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:24:29 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:24:29 --> Utf8 Class Initialized
INFO - 2020-07-31 09:24:29 --> URI Class Initialized
DEBUG - 2020-07-31 09:24:29 --> No URI present. Default controller set.
INFO - 2020-07-31 09:24:29 --> Router Class Initialized
INFO - 2020-07-31 09:24:29 --> Output Class Initialized
INFO - 2020-07-31 09:24:29 --> Security Class Initialized
DEBUG - 2020-07-31 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:24:29 --> Input Class Initialized
INFO - 2020-07-31 09:24:29 --> Language Class Initialized
INFO - 2020-07-31 09:24:29 --> Loader Class Initialized
INFO - 2020-07-31 09:24:29 --> Helper loaded: url_helper
INFO - 2020-07-31 09:24:29 --> Database Driver Class Initialized
INFO - 2020-07-31 09:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:24:29 --> Email Class Initialized
INFO - 2020-07-31 09:24:29 --> Controller Class Initialized
INFO - 2020-07-31 09:24:29 --> Model Class Initialized
INFO - 2020-07-31 09:24:29 --> Model Class Initialized
DEBUG - 2020-07-31 09:24:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:24:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:24:29 --> Final output sent to browser
DEBUG - 2020-07-31 09:24:29 --> Total execution time: 0.0209
INFO - 2020-07-31 09:24:48 --> Config Class Initialized
INFO - 2020-07-31 09:24:48 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:24:48 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:24:48 --> Utf8 Class Initialized
INFO - 2020-07-31 09:24:48 --> URI Class Initialized
INFO - 2020-07-31 09:24:48 --> Router Class Initialized
INFO - 2020-07-31 09:24:48 --> Output Class Initialized
INFO - 2020-07-31 09:24:48 --> Security Class Initialized
DEBUG - 2020-07-31 09:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:24:48 --> Input Class Initialized
INFO - 2020-07-31 09:24:48 --> Language Class Initialized
INFO - 2020-07-31 09:24:48 --> Loader Class Initialized
INFO - 2020-07-31 09:24:48 --> Helper loaded: url_helper
INFO - 2020-07-31 09:24:48 --> Database Driver Class Initialized
INFO - 2020-07-31 09:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:24:48 --> Email Class Initialized
INFO - 2020-07-31 09:24:48 --> Controller Class Initialized
INFO - 2020-07-31 09:24:48 --> Model Class Initialized
INFO - 2020-07-31 09:24:48 --> Model Class Initialized
DEBUG - 2020-07-31 09:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:24:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:24:48 --> Model Class Initialized
INFO - 2020-07-31 09:24:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:24:48 --> Final output sent to browser
DEBUG - 2020-07-31 09:24:48 --> Total execution time: 0.0227
INFO - 2020-07-31 09:25:13 --> Config Class Initialized
INFO - 2020-07-31 09:25:13 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:25:13 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:25:13 --> Utf8 Class Initialized
INFO - 2020-07-31 09:25:13 --> URI Class Initialized
INFO - 2020-07-31 09:25:13 --> Router Class Initialized
INFO - 2020-07-31 09:25:13 --> Output Class Initialized
INFO - 2020-07-31 09:25:13 --> Security Class Initialized
DEBUG - 2020-07-31 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:25:13 --> Input Class Initialized
INFO - 2020-07-31 09:25:13 --> Language Class Initialized
INFO - 2020-07-31 09:25:13 --> Loader Class Initialized
INFO - 2020-07-31 09:25:13 --> Helper loaded: url_helper
INFO - 2020-07-31 09:25:13 --> Database Driver Class Initialized
INFO - 2020-07-31 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:25:13 --> Email Class Initialized
INFO - 2020-07-31 09:25:13 --> Controller Class Initialized
INFO - 2020-07-31 09:25:13 --> Model Class Initialized
INFO - 2020-07-31 09:25:13 --> Model Class Initialized
DEBUG - 2020-07-31 09:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:25:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:25:13 --> Model Class Initialized
INFO - 2020-07-31 09:25:13 --> Config Class Initialized
INFO - 2020-07-31 09:25:13 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:25:13 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:25:13 --> Utf8 Class Initialized
INFO - 2020-07-31 09:25:13 --> URI Class Initialized
DEBUG - 2020-07-31 09:25:13 --> No URI present. Default controller set.
INFO - 2020-07-31 09:25:13 --> Router Class Initialized
INFO - 2020-07-31 09:25:13 --> Output Class Initialized
INFO - 2020-07-31 09:25:13 --> Security Class Initialized
DEBUG - 2020-07-31 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:25:13 --> Input Class Initialized
INFO - 2020-07-31 09:25:13 --> Language Class Initialized
INFO - 2020-07-31 09:25:13 --> Loader Class Initialized
INFO - 2020-07-31 09:25:13 --> Helper loaded: url_helper
INFO - 2020-07-31 09:25:13 --> Database Driver Class Initialized
INFO - 2020-07-31 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:25:13 --> Email Class Initialized
INFO - 2020-07-31 09:25:13 --> Controller Class Initialized
INFO - 2020-07-31 09:25:13 --> Model Class Initialized
INFO - 2020-07-31 09:25:13 --> Model Class Initialized
DEBUG - 2020-07-31 09:25:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:25:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:25:13 --> Final output sent to browser
DEBUG - 2020-07-31 09:25:13 --> Total execution time: 0.0235
INFO - 2020-07-31 09:26:04 --> Config Class Initialized
INFO - 2020-07-31 09:26:04 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:26:04 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:26:04 --> Utf8 Class Initialized
INFO - 2020-07-31 09:26:04 --> URI Class Initialized
INFO - 2020-07-31 09:26:04 --> Router Class Initialized
INFO - 2020-07-31 09:26:04 --> Output Class Initialized
INFO - 2020-07-31 09:26:04 --> Security Class Initialized
DEBUG - 2020-07-31 09:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:26:04 --> Input Class Initialized
INFO - 2020-07-31 09:26:04 --> Language Class Initialized
INFO - 2020-07-31 09:26:04 --> Loader Class Initialized
INFO - 2020-07-31 09:26:04 --> Helper loaded: url_helper
INFO - 2020-07-31 09:26:04 --> Database Driver Class Initialized
INFO - 2020-07-31 09:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:26:04 --> Email Class Initialized
INFO - 2020-07-31 09:26:04 --> Controller Class Initialized
INFO - 2020-07-31 09:26:04 --> Model Class Initialized
INFO - 2020-07-31 09:26:04 --> Model Class Initialized
DEBUG - 2020-07-31 09:26:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:26:05 --> Config Class Initialized
INFO - 2020-07-31 09:26:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:26:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:26:05 --> Utf8 Class Initialized
INFO - 2020-07-31 09:26:05 --> URI Class Initialized
INFO - 2020-07-31 09:26:05 --> Router Class Initialized
INFO - 2020-07-31 09:26:05 --> Output Class Initialized
INFO - 2020-07-31 09:26:05 --> Security Class Initialized
DEBUG - 2020-07-31 09:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:26:05 --> Input Class Initialized
INFO - 2020-07-31 09:26:05 --> Language Class Initialized
INFO - 2020-07-31 09:26:05 --> Loader Class Initialized
INFO - 2020-07-31 09:26:05 --> Helper loaded: url_helper
INFO - 2020-07-31 09:26:05 --> Database Driver Class Initialized
INFO - 2020-07-31 09:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:26:05 --> Email Class Initialized
INFO - 2020-07-31 09:26:05 --> Controller Class Initialized
DEBUG - 2020-07-31 09:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:26:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:26:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 09:26:05 --> Final output sent to browser
DEBUG - 2020-07-31 09:26:05 --> Total execution time: 0.0225
INFO - 2020-07-31 09:26:12 --> Config Class Initialized
INFO - 2020-07-31 09:26:12 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:26:12 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:26:12 --> Utf8 Class Initialized
INFO - 2020-07-31 09:26:12 --> URI Class Initialized
INFO - 2020-07-31 09:26:12 --> Router Class Initialized
INFO - 2020-07-31 09:26:12 --> Output Class Initialized
INFO - 2020-07-31 09:26:12 --> Security Class Initialized
DEBUG - 2020-07-31 09:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:26:12 --> Input Class Initialized
INFO - 2020-07-31 09:26:12 --> Language Class Initialized
INFO - 2020-07-31 09:26:12 --> Loader Class Initialized
INFO - 2020-07-31 09:26:12 --> Helper loaded: url_helper
INFO - 2020-07-31 09:26:12 --> Database Driver Class Initialized
INFO - 2020-07-31 09:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:26:12 --> Email Class Initialized
INFO - 2020-07-31 09:26:12 --> Controller Class Initialized
DEBUG - 2020-07-31 09:26:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:26:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:26:12 --> Model Class Initialized
INFO - 2020-07-31 09:26:12 --> Model Class Initialized
INFO - 2020-07-31 09:26:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 09:26:12 --> Final output sent to browser
DEBUG - 2020-07-31 09:26:12 --> Total execution time: 0.0282
INFO - 2020-07-31 09:27:57 --> Config Class Initialized
INFO - 2020-07-31 09:27:57 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:27:57 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:27:57 --> Utf8 Class Initialized
INFO - 2020-07-31 09:27:57 --> URI Class Initialized
DEBUG - 2020-07-31 09:27:57 --> No URI present. Default controller set.
INFO - 2020-07-31 09:27:57 --> Router Class Initialized
INFO - 2020-07-31 09:27:57 --> Output Class Initialized
INFO - 2020-07-31 09:27:57 --> Security Class Initialized
DEBUG - 2020-07-31 09:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:27:57 --> Input Class Initialized
INFO - 2020-07-31 09:27:57 --> Language Class Initialized
INFO - 2020-07-31 09:27:57 --> Loader Class Initialized
INFO - 2020-07-31 09:27:57 --> Helper loaded: url_helper
INFO - 2020-07-31 09:27:57 --> Database Driver Class Initialized
INFO - 2020-07-31 09:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:27:57 --> Email Class Initialized
INFO - 2020-07-31 09:27:57 --> Controller Class Initialized
INFO - 2020-07-31 09:27:57 --> Model Class Initialized
INFO - 2020-07-31 09:27:57 --> Model Class Initialized
DEBUG - 2020-07-31 09:27:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:27:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:27:57 --> Final output sent to browser
DEBUG - 2020-07-31 09:27:57 --> Total execution time: 0.0240
INFO - 2020-07-31 09:43:51 --> Config Class Initialized
INFO - 2020-07-31 09:43:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:43:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:43:51 --> Utf8 Class Initialized
INFO - 2020-07-31 09:43:51 --> URI Class Initialized
DEBUG - 2020-07-31 09:43:51 --> No URI present. Default controller set.
INFO - 2020-07-31 09:43:51 --> Router Class Initialized
INFO - 2020-07-31 09:43:51 --> Output Class Initialized
INFO - 2020-07-31 09:43:51 --> Security Class Initialized
DEBUG - 2020-07-31 09:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:43:51 --> Input Class Initialized
INFO - 2020-07-31 09:43:51 --> Language Class Initialized
INFO - 2020-07-31 09:43:51 --> Loader Class Initialized
INFO - 2020-07-31 09:43:51 --> Helper loaded: url_helper
INFO - 2020-07-31 09:43:51 --> Database Driver Class Initialized
INFO - 2020-07-31 09:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:43:51 --> Email Class Initialized
INFO - 2020-07-31 09:43:51 --> Controller Class Initialized
INFO - 2020-07-31 09:43:51 --> Model Class Initialized
INFO - 2020-07-31 09:43:51 --> Model Class Initialized
DEBUG - 2020-07-31 09:43:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:43:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:43:51 --> Final output sent to browser
DEBUG - 2020-07-31 09:43:51 --> Total execution time: 0.0258
INFO - 2020-07-31 09:43:54 --> Config Class Initialized
INFO - 2020-07-31 09:43:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:43:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:43:54 --> Utf8 Class Initialized
INFO - 2020-07-31 09:43:54 --> URI Class Initialized
INFO - 2020-07-31 09:43:54 --> Router Class Initialized
INFO - 2020-07-31 09:43:54 --> Output Class Initialized
INFO - 2020-07-31 09:43:54 --> Security Class Initialized
DEBUG - 2020-07-31 09:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:43:54 --> Input Class Initialized
INFO - 2020-07-31 09:43:54 --> Language Class Initialized
INFO - 2020-07-31 09:43:54 --> Loader Class Initialized
INFO - 2020-07-31 09:43:54 --> Helper loaded: url_helper
INFO - 2020-07-31 09:43:54 --> Database Driver Class Initialized
INFO - 2020-07-31 09:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:43:54 --> Email Class Initialized
INFO - 2020-07-31 09:43:54 --> Controller Class Initialized
INFO - 2020-07-31 09:43:54 --> Model Class Initialized
INFO - 2020-07-31 09:43:54 --> Model Class Initialized
DEBUG - 2020-07-31 09:43:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:43:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:43:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:43:54 --> Final output sent to browser
DEBUG - 2020-07-31 09:43:54 --> Total execution time: 0.0241
INFO - 2020-07-31 09:44:05 --> Config Class Initialized
INFO - 2020-07-31 09:44:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:44:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:44:05 --> Utf8 Class Initialized
INFO - 2020-07-31 09:44:05 --> URI Class Initialized
INFO - 2020-07-31 09:44:05 --> Router Class Initialized
INFO - 2020-07-31 09:44:05 --> Output Class Initialized
INFO - 2020-07-31 09:44:05 --> Security Class Initialized
DEBUG - 2020-07-31 09:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:44:05 --> Input Class Initialized
INFO - 2020-07-31 09:44:05 --> Language Class Initialized
INFO - 2020-07-31 09:44:05 --> Loader Class Initialized
INFO - 2020-07-31 09:44:05 --> Helper loaded: url_helper
INFO - 2020-07-31 09:44:05 --> Database Driver Class Initialized
INFO - 2020-07-31 09:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:44:05 --> Email Class Initialized
INFO - 2020-07-31 09:44:05 --> Controller Class Initialized
INFO - 2020-07-31 09:44:05 --> Model Class Initialized
INFO - 2020-07-31 09:44:05 --> Model Class Initialized
DEBUG - 2020-07-31 09:44:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:44:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:44:05 --> Model Class Initialized
INFO - 2020-07-31 09:44:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:44:06 --> Final output sent to browser
DEBUG - 2020-07-31 09:44:06 --> Total execution time: 0.0744
INFO - 2020-07-31 09:44:25 --> Config Class Initialized
INFO - 2020-07-31 09:44:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:44:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:44:25 --> Utf8 Class Initialized
INFO - 2020-07-31 09:44:25 --> URI Class Initialized
INFO - 2020-07-31 09:44:25 --> Router Class Initialized
INFO - 2020-07-31 09:44:25 --> Output Class Initialized
INFO - 2020-07-31 09:44:25 --> Security Class Initialized
DEBUG - 2020-07-31 09:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:44:25 --> Input Class Initialized
INFO - 2020-07-31 09:44:25 --> Language Class Initialized
INFO - 2020-07-31 09:44:25 --> Loader Class Initialized
INFO - 2020-07-31 09:44:25 --> Helper loaded: url_helper
INFO - 2020-07-31 09:44:25 --> Database Driver Class Initialized
INFO - 2020-07-31 09:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:44:25 --> Email Class Initialized
INFO - 2020-07-31 09:44:25 --> Controller Class Initialized
INFO - 2020-07-31 09:44:25 --> Model Class Initialized
INFO - 2020-07-31 09:44:25 --> Model Class Initialized
DEBUG - 2020-07-31 09:44:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:44:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:44:25 --> Model Class Initialized
INFO - 2020-07-31 09:44:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:44:25 --> Final output sent to browser
DEBUG - 2020-07-31 09:44:25 --> Total execution time: 0.0256
INFO - 2020-07-31 09:44:28 --> Config Class Initialized
INFO - 2020-07-31 09:44:28 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:44:28 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:44:28 --> Utf8 Class Initialized
INFO - 2020-07-31 09:44:28 --> URI Class Initialized
INFO - 2020-07-31 09:44:28 --> Router Class Initialized
INFO - 2020-07-31 09:44:28 --> Output Class Initialized
INFO - 2020-07-31 09:44:28 --> Security Class Initialized
DEBUG - 2020-07-31 09:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:44:28 --> Input Class Initialized
INFO - 2020-07-31 09:44:28 --> Language Class Initialized
INFO - 2020-07-31 09:44:28 --> Loader Class Initialized
INFO - 2020-07-31 09:44:28 --> Helper loaded: url_helper
INFO - 2020-07-31 09:44:28 --> Database Driver Class Initialized
INFO - 2020-07-31 09:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:44:28 --> Email Class Initialized
INFO - 2020-07-31 09:44:28 --> Controller Class Initialized
INFO - 2020-07-31 09:44:28 --> Model Class Initialized
INFO - 2020-07-31 09:44:28 --> Model Class Initialized
DEBUG - 2020-07-31 09:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:44:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:44:28 --> Model Class Initialized
INFO - 2020-07-31 09:44:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:44:28 --> Final output sent to browser
DEBUG - 2020-07-31 09:44:28 --> Total execution time: 0.0308
INFO - 2020-07-31 09:45:06 --> Config Class Initialized
INFO - 2020-07-31 09:45:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:45:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:45:06 --> Utf8 Class Initialized
INFO - 2020-07-31 09:45:06 --> URI Class Initialized
DEBUG - 2020-07-31 09:45:06 --> No URI present. Default controller set.
INFO - 2020-07-31 09:45:06 --> Router Class Initialized
INFO - 2020-07-31 09:45:06 --> Output Class Initialized
INFO - 2020-07-31 09:45:06 --> Security Class Initialized
DEBUG - 2020-07-31 09:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:45:06 --> Input Class Initialized
INFO - 2020-07-31 09:45:06 --> Language Class Initialized
INFO - 2020-07-31 09:45:06 --> Loader Class Initialized
INFO - 2020-07-31 09:45:06 --> Helper loaded: url_helper
INFO - 2020-07-31 09:45:06 --> Database Driver Class Initialized
INFO - 2020-07-31 09:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:45:06 --> Email Class Initialized
INFO - 2020-07-31 09:45:06 --> Controller Class Initialized
INFO - 2020-07-31 09:45:06 --> Model Class Initialized
INFO - 2020-07-31 09:45:06 --> Model Class Initialized
DEBUG - 2020-07-31 09:45:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:45:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:45:06 --> Final output sent to browser
DEBUG - 2020-07-31 09:45:06 --> Total execution time: 0.0257
INFO - 2020-07-31 09:45:09 --> Config Class Initialized
INFO - 2020-07-31 09:45:09 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:45:09 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:45:09 --> Utf8 Class Initialized
INFO - 2020-07-31 09:45:09 --> URI Class Initialized
INFO - 2020-07-31 09:45:09 --> Router Class Initialized
INFO - 2020-07-31 09:45:09 --> Output Class Initialized
INFO - 2020-07-31 09:45:09 --> Security Class Initialized
DEBUG - 2020-07-31 09:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:45:09 --> Input Class Initialized
INFO - 2020-07-31 09:45:09 --> Language Class Initialized
INFO - 2020-07-31 09:45:09 --> Loader Class Initialized
INFO - 2020-07-31 09:45:09 --> Helper loaded: url_helper
INFO - 2020-07-31 09:45:09 --> Database Driver Class Initialized
INFO - 2020-07-31 09:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:45:09 --> Email Class Initialized
INFO - 2020-07-31 09:45:09 --> Controller Class Initialized
INFO - 2020-07-31 09:45:09 --> Model Class Initialized
INFO - 2020-07-31 09:45:09 --> Model Class Initialized
DEBUG - 2020-07-31 09:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:45:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:45:09 --> Model Class Initialized
INFO - 2020-07-31 09:45:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:45:09 --> Final output sent to browser
DEBUG - 2020-07-31 09:45:09 --> Total execution time: 0.0243
INFO - 2020-07-31 09:45:20 --> Config Class Initialized
INFO - 2020-07-31 09:45:20 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:45:20 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:45:20 --> Utf8 Class Initialized
INFO - 2020-07-31 09:45:20 --> URI Class Initialized
INFO - 2020-07-31 09:45:20 --> Router Class Initialized
INFO - 2020-07-31 09:45:20 --> Output Class Initialized
INFO - 2020-07-31 09:45:20 --> Security Class Initialized
DEBUG - 2020-07-31 09:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:45:20 --> Input Class Initialized
INFO - 2020-07-31 09:45:20 --> Language Class Initialized
INFO - 2020-07-31 09:45:20 --> Loader Class Initialized
INFO - 2020-07-31 09:45:20 --> Helper loaded: url_helper
INFO - 2020-07-31 09:45:20 --> Database Driver Class Initialized
INFO - 2020-07-31 09:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:45:20 --> Email Class Initialized
INFO - 2020-07-31 09:45:20 --> Controller Class Initialized
INFO - 2020-07-31 09:45:20 --> Model Class Initialized
INFO - 2020-07-31 09:45:20 --> Model Class Initialized
DEBUG - 2020-07-31 09:45:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:45:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:45:20 --> Model Class Initialized
INFO - 2020-07-31 09:45:21 --> Config Class Initialized
INFO - 2020-07-31 09:45:21 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:45:21 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:45:21 --> Utf8 Class Initialized
INFO - 2020-07-31 09:45:21 --> URI Class Initialized
INFO - 2020-07-31 09:45:21 --> Router Class Initialized
INFO - 2020-07-31 09:45:21 --> Output Class Initialized
INFO - 2020-07-31 09:45:21 --> Security Class Initialized
DEBUG - 2020-07-31 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:45:21 --> Input Class Initialized
INFO - 2020-07-31 09:45:21 --> Language Class Initialized
INFO - 2020-07-31 09:45:21 --> Loader Class Initialized
INFO - 2020-07-31 09:45:21 --> Helper loaded: url_helper
INFO - 2020-07-31 09:45:21 --> Database Driver Class Initialized
INFO - 2020-07-31 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:45:21 --> Email Class Initialized
INFO - 2020-07-31 09:45:21 --> Controller Class Initialized
INFO - 2020-07-31 09:45:21 --> Model Class Initialized
INFO - 2020-07-31 09:45:21 --> Model Class Initialized
DEBUG - 2020-07-31 09:45:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:45:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:45:21 --> Model Class Initialized
INFO - 2020-07-31 09:45:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/register.php
INFO - 2020-07-31 09:45:21 --> Final output sent to browser
DEBUG - 2020-07-31 09:45:21 --> Total execution time: 0.0212
INFO - 2020-07-31 09:45:21 --> Config Class Initialized
INFO - 2020-07-31 09:45:21 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:45:21 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:45:21 --> Utf8 Class Initialized
INFO - 2020-07-31 09:45:21 --> URI Class Initialized
DEBUG - 2020-07-31 09:45:21 --> No URI present. Default controller set.
INFO - 2020-07-31 09:45:21 --> Router Class Initialized
INFO - 2020-07-31 09:45:21 --> Output Class Initialized
INFO - 2020-07-31 09:45:21 --> Security Class Initialized
DEBUG - 2020-07-31 09:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:45:21 --> Input Class Initialized
INFO - 2020-07-31 09:45:21 --> Language Class Initialized
INFO - 2020-07-31 09:45:21 --> Loader Class Initialized
INFO - 2020-07-31 09:45:21 --> Helper loaded: url_helper
INFO - 2020-07-31 09:45:21 --> Database Driver Class Initialized
INFO - 2020-07-31 09:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:45:21 --> Email Class Initialized
INFO - 2020-07-31 09:45:21 --> Controller Class Initialized
INFO - 2020-07-31 09:45:21 --> Model Class Initialized
INFO - 2020-07-31 09:45:21 --> Model Class Initialized
DEBUG - 2020-07-31 09:45:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:45:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:45:21 --> Final output sent to browser
DEBUG - 2020-07-31 09:45:21 --> Total execution time: 0.0225
INFO - 2020-07-31 09:45:36 --> Config Class Initialized
INFO - 2020-07-31 09:45:36 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:45:36 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:45:36 --> Utf8 Class Initialized
INFO - 2020-07-31 09:45:36 --> URI Class Initialized
INFO - 2020-07-31 09:45:36 --> Router Class Initialized
INFO - 2020-07-31 09:45:36 --> Output Class Initialized
INFO - 2020-07-31 09:45:36 --> Security Class Initialized
DEBUG - 2020-07-31 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:45:36 --> Input Class Initialized
INFO - 2020-07-31 09:45:36 --> Language Class Initialized
INFO - 2020-07-31 09:45:36 --> Loader Class Initialized
INFO - 2020-07-31 09:45:36 --> Helper loaded: url_helper
INFO - 2020-07-31 09:45:36 --> Database Driver Class Initialized
INFO - 2020-07-31 09:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:45:36 --> Email Class Initialized
INFO - 2020-07-31 09:45:36 --> Controller Class Initialized
INFO - 2020-07-31 09:45:36 --> Model Class Initialized
INFO - 2020-07-31 09:45:36 --> Model Class Initialized
DEBUG - 2020-07-31 09:45:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:45:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:45:36 --> Model Class Initialized
INFO - 2020-07-31 09:45:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:45:36 --> Final output sent to browser
DEBUG - 2020-07-31 09:45:36 --> Total execution time: 0.0265
INFO - 2020-07-31 09:46:07 --> Config Class Initialized
INFO - 2020-07-31 09:46:07 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:46:07 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:46:07 --> Utf8 Class Initialized
INFO - 2020-07-31 09:46:07 --> URI Class Initialized
INFO - 2020-07-31 09:46:07 --> Router Class Initialized
INFO - 2020-07-31 09:46:07 --> Output Class Initialized
INFO - 2020-07-31 09:46:07 --> Security Class Initialized
DEBUG - 2020-07-31 09:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:46:07 --> Input Class Initialized
INFO - 2020-07-31 09:46:07 --> Language Class Initialized
INFO - 2020-07-31 09:46:07 --> Loader Class Initialized
INFO - 2020-07-31 09:46:07 --> Helper loaded: url_helper
INFO - 2020-07-31 09:46:07 --> Database Driver Class Initialized
INFO - 2020-07-31 09:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:46:07 --> Email Class Initialized
INFO - 2020-07-31 09:46:07 --> Controller Class Initialized
INFO - 2020-07-31 09:46:07 --> Model Class Initialized
INFO - 2020-07-31 09:46:07 --> Model Class Initialized
DEBUG - 2020-07-31 09:46:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:46:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:46:07 --> Model Class Initialized
INFO - 2020-07-31 09:46:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:46:07 --> Final output sent to browser
DEBUG - 2020-07-31 09:46:07 --> Total execution time: 0.0275
INFO - 2020-07-31 09:46:40 --> Config Class Initialized
INFO - 2020-07-31 09:46:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:46:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:46:40 --> Utf8 Class Initialized
INFO - 2020-07-31 09:46:40 --> URI Class Initialized
INFO - 2020-07-31 09:46:40 --> Router Class Initialized
INFO - 2020-07-31 09:46:40 --> Output Class Initialized
INFO - 2020-07-31 09:46:40 --> Security Class Initialized
DEBUG - 2020-07-31 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:46:40 --> Input Class Initialized
INFO - 2020-07-31 09:46:40 --> Language Class Initialized
INFO - 2020-07-31 09:46:40 --> Loader Class Initialized
INFO - 2020-07-31 09:46:40 --> Helper loaded: url_helper
INFO - 2020-07-31 09:46:40 --> Database Driver Class Initialized
INFO - 2020-07-31 09:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:46:40 --> Email Class Initialized
INFO - 2020-07-31 09:46:40 --> Controller Class Initialized
INFO - 2020-07-31 09:46:40 --> Model Class Initialized
INFO - 2020-07-31 09:46:40 --> Model Class Initialized
DEBUG - 2020-07-31 09:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:46:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:46:40 --> Model Class Initialized
INFO - 2020-07-31 09:46:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:46:41 --> Final output sent to browser
DEBUG - 2020-07-31 09:46:41 --> Total execution time: 0.0273
INFO - 2020-07-31 09:47:08 --> Config Class Initialized
INFO - 2020-07-31 09:47:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:47:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:47:08 --> Utf8 Class Initialized
INFO - 2020-07-31 09:47:08 --> URI Class Initialized
INFO - 2020-07-31 09:47:08 --> Router Class Initialized
INFO - 2020-07-31 09:47:08 --> Output Class Initialized
INFO - 2020-07-31 09:47:08 --> Security Class Initialized
DEBUG - 2020-07-31 09:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:47:08 --> Input Class Initialized
INFO - 2020-07-31 09:47:08 --> Language Class Initialized
INFO - 2020-07-31 09:47:08 --> Loader Class Initialized
INFO - 2020-07-31 09:47:08 --> Helper loaded: url_helper
INFO - 2020-07-31 09:47:08 --> Database Driver Class Initialized
INFO - 2020-07-31 09:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:47:08 --> Email Class Initialized
INFO - 2020-07-31 09:47:08 --> Controller Class Initialized
INFO - 2020-07-31 09:47:08 --> Model Class Initialized
INFO - 2020-07-31 09:47:08 --> Model Class Initialized
DEBUG - 2020-07-31 09:47:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:47:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:47:08 --> Model Class Initialized
INFO - 2020-07-31 09:47:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:47:08 --> Final output sent to browser
DEBUG - 2020-07-31 09:47:08 --> Total execution time: 0.0254
INFO - 2020-07-31 09:47:50 --> Config Class Initialized
INFO - 2020-07-31 09:47:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:47:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:47:50 --> Utf8 Class Initialized
INFO - 2020-07-31 09:47:50 --> URI Class Initialized
INFO - 2020-07-31 09:47:50 --> Router Class Initialized
INFO - 2020-07-31 09:47:50 --> Output Class Initialized
INFO - 2020-07-31 09:47:50 --> Security Class Initialized
DEBUG - 2020-07-31 09:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:47:50 --> Input Class Initialized
INFO - 2020-07-31 09:47:50 --> Language Class Initialized
INFO - 2020-07-31 09:47:50 --> Loader Class Initialized
INFO - 2020-07-31 09:47:50 --> Helper loaded: url_helper
INFO - 2020-07-31 09:47:50 --> Database Driver Class Initialized
INFO - 2020-07-31 09:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:47:50 --> Email Class Initialized
INFO - 2020-07-31 09:47:50 --> Controller Class Initialized
INFO - 2020-07-31 09:47:50 --> Model Class Initialized
INFO - 2020-07-31 09:47:50 --> Model Class Initialized
DEBUG - 2020-07-31 09:47:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:47:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:47:50 --> Model Class Initialized
INFO - 2020-07-31 09:47:50 --> Config Class Initialized
INFO - 2020-07-31 09:47:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:47:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:47:50 --> Utf8 Class Initialized
INFO - 2020-07-31 09:47:50 --> URI Class Initialized
DEBUG - 2020-07-31 09:47:50 --> No URI present. Default controller set.
INFO - 2020-07-31 09:47:50 --> Router Class Initialized
INFO - 2020-07-31 09:47:50 --> Output Class Initialized
INFO - 2020-07-31 09:47:50 --> Security Class Initialized
DEBUG - 2020-07-31 09:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:47:50 --> Input Class Initialized
INFO - 2020-07-31 09:47:50 --> Language Class Initialized
INFO - 2020-07-31 09:47:50 --> Loader Class Initialized
INFO - 2020-07-31 09:47:50 --> Helper loaded: url_helper
INFO - 2020-07-31 09:47:50 --> Database Driver Class Initialized
INFO - 2020-07-31 09:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:47:50 --> Email Class Initialized
INFO - 2020-07-31 09:47:50 --> Controller Class Initialized
INFO - 2020-07-31 09:47:50 --> Model Class Initialized
INFO - 2020-07-31 09:47:50 --> Model Class Initialized
DEBUG - 2020-07-31 09:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:47:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:47:50 --> Final output sent to browser
DEBUG - 2020-07-31 09:47:50 --> Total execution time: 0.0227
INFO - 2020-07-31 09:48:09 --> Config Class Initialized
INFO - 2020-07-31 09:48:09 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:48:09 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:48:09 --> Utf8 Class Initialized
INFO - 2020-07-31 09:48:09 --> URI Class Initialized
DEBUG - 2020-07-31 09:48:09 --> No URI present. Default controller set.
INFO - 2020-07-31 09:48:09 --> Router Class Initialized
INFO - 2020-07-31 09:48:09 --> Output Class Initialized
INFO - 2020-07-31 09:48:09 --> Security Class Initialized
DEBUG - 2020-07-31 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:48:09 --> Input Class Initialized
INFO - 2020-07-31 09:48:09 --> Language Class Initialized
INFO - 2020-07-31 09:48:09 --> Loader Class Initialized
INFO - 2020-07-31 09:48:09 --> Helper loaded: url_helper
INFO - 2020-07-31 09:48:09 --> Database Driver Class Initialized
INFO - 2020-07-31 09:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:48:09 --> Email Class Initialized
INFO - 2020-07-31 09:48:09 --> Controller Class Initialized
INFO - 2020-07-31 09:48:09 --> Model Class Initialized
INFO - 2020-07-31 09:48:09 --> Model Class Initialized
DEBUG - 2020-07-31 09:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:48:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:48:09 --> Final output sent to browser
DEBUG - 2020-07-31 09:48:09 --> Total execution time: 0.0226
INFO - 2020-07-31 09:48:12 --> Config Class Initialized
INFO - 2020-07-31 09:48:12 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:48:12 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:48:12 --> Utf8 Class Initialized
INFO - 2020-07-31 09:48:12 --> URI Class Initialized
INFO - 2020-07-31 09:48:12 --> Router Class Initialized
INFO - 2020-07-31 09:48:12 --> Output Class Initialized
INFO - 2020-07-31 09:48:12 --> Security Class Initialized
DEBUG - 2020-07-31 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:48:12 --> Input Class Initialized
INFO - 2020-07-31 09:48:12 --> Language Class Initialized
INFO - 2020-07-31 09:48:12 --> Loader Class Initialized
INFO - 2020-07-31 09:48:12 --> Helper loaded: url_helper
INFO - 2020-07-31 09:48:12 --> Database Driver Class Initialized
INFO - 2020-07-31 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:48:12 --> Email Class Initialized
INFO - 2020-07-31 09:48:12 --> Controller Class Initialized
INFO - 2020-07-31 09:48:12 --> Model Class Initialized
INFO - 2020-07-31 09:48:12 --> Model Class Initialized
DEBUG - 2020-07-31 09:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:48:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:48:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:48:12 --> Final output sent to browser
DEBUG - 2020-07-31 09:48:12 --> Total execution time: 0.0214
INFO - 2020-07-31 09:48:19 --> Config Class Initialized
INFO - 2020-07-31 09:48:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:48:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:48:19 --> Utf8 Class Initialized
INFO - 2020-07-31 09:48:19 --> URI Class Initialized
INFO - 2020-07-31 09:48:19 --> Router Class Initialized
INFO - 2020-07-31 09:48:19 --> Output Class Initialized
INFO - 2020-07-31 09:48:19 --> Security Class Initialized
DEBUG - 2020-07-31 09:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:48:19 --> Input Class Initialized
INFO - 2020-07-31 09:48:19 --> Language Class Initialized
INFO - 2020-07-31 09:48:19 --> Loader Class Initialized
INFO - 2020-07-31 09:48:19 --> Helper loaded: url_helper
INFO - 2020-07-31 09:48:19 --> Database Driver Class Initialized
INFO - 2020-07-31 09:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:48:19 --> Email Class Initialized
INFO - 2020-07-31 09:48:19 --> Controller Class Initialized
INFO - 2020-07-31 09:48:19 --> Model Class Initialized
INFO - 2020-07-31 09:48:19 --> Model Class Initialized
DEBUG - 2020-07-31 09:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:48:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:48:19 --> Model Class Initialized
INFO - 2020-07-31 09:48:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-07-31 09:48:19 --> Final output sent to browser
DEBUG - 2020-07-31 09:48:19 --> Total execution time: 0.0670
INFO - 2020-07-31 09:48:22 --> Config Class Initialized
INFO - 2020-07-31 09:48:22 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:48:22 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:48:22 --> Utf8 Class Initialized
INFO - 2020-07-31 09:48:22 --> URI Class Initialized
DEBUG - 2020-07-31 09:48:22 --> No URI present. Default controller set.
INFO - 2020-07-31 09:48:22 --> Router Class Initialized
INFO - 2020-07-31 09:48:22 --> Output Class Initialized
INFO - 2020-07-31 09:48:22 --> Security Class Initialized
DEBUG - 2020-07-31 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:48:22 --> Input Class Initialized
INFO - 2020-07-31 09:48:22 --> Language Class Initialized
INFO - 2020-07-31 09:48:22 --> Loader Class Initialized
INFO - 2020-07-31 09:48:22 --> Helper loaded: url_helper
INFO - 2020-07-31 09:48:22 --> Database Driver Class Initialized
INFO - 2020-07-31 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:48:22 --> Email Class Initialized
INFO - 2020-07-31 09:48:22 --> Controller Class Initialized
INFO - 2020-07-31 09:48:22 --> Model Class Initialized
INFO - 2020-07-31 09:48:22 --> Model Class Initialized
DEBUG - 2020-07-31 09:48:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:48:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:48:22 --> Final output sent to browser
DEBUG - 2020-07-31 09:48:22 --> Total execution time: 0.0287
INFO - 2020-07-31 09:48:29 --> Config Class Initialized
INFO - 2020-07-31 09:48:29 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:48:29 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:48:29 --> Utf8 Class Initialized
INFO - 2020-07-31 09:48:29 --> URI Class Initialized
INFO - 2020-07-31 09:48:29 --> Router Class Initialized
INFO - 2020-07-31 09:48:29 --> Output Class Initialized
INFO - 2020-07-31 09:48:29 --> Security Class Initialized
DEBUG - 2020-07-31 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:48:29 --> Input Class Initialized
INFO - 2020-07-31 09:48:29 --> Language Class Initialized
INFO - 2020-07-31 09:48:29 --> Loader Class Initialized
INFO - 2020-07-31 09:48:29 --> Helper loaded: url_helper
INFO - 2020-07-31 09:48:29 --> Database Driver Class Initialized
INFO - 2020-07-31 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:48:29 --> Email Class Initialized
INFO - 2020-07-31 09:48:29 --> Controller Class Initialized
INFO - 2020-07-31 09:48:29 --> Model Class Initialized
INFO - 2020-07-31 09:48:29 --> Model Class Initialized
DEBUG - 2020-07-31 09:48:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:48:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:48:29 --> Model Class Initialized
INFO - 2020-07-31 09:48:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-07-31 09:48:29 --> Final output sent to browser
DEBUG - 2020-07-31 09:48:29 --> Total execution time: 0.0264
INFO - 2020-07-31 09:49:18 --> Config Class Initialized
INFO - 2020-07-31 09:49:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:49:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:49:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:49:18 --> URI Class Initialized
INFO - 2020-07-31 09:49:18 --> Router Class Initialized
INFO - 2020-07-31 09:49:18 --> Output Class Initialized
INFO - 2020-07-31 09:49:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:49:18 --> Input Class Initialized
INFO - 2020-07-31 09:49:18 --> Language Class Initialized
INFO - 2020-07-31 09:49:18 --> Loader Class Initialized
INFO - 2020-07-31 09:49:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:49:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:49:18 --> Email Class Initialized
INFO - 2020-07-31 09:49:18 --> Controller Class Initialized
INFO - 2020-07-31 09:49:18 --> Model Class Initialized
INFO - 2020-07-31 09:49:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 09:49:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:49:18 --> Model Class Initialized
INFO - 2020-07-31 09:49:18 --> Config Class Initialized
INFO - 2020-07-31 09:49:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 09:49:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 09:49:18 --> Utf8 Class Initialized
INFO - 2020-07-31 09:49:18 --> URI Class Initialized
DEBUG - 2020-07-31 09:49:18 --> No URI present. Default controller set.
INFO - 2020-07-31 09:49:18 --> Router Class Initialized
INFO - 2020-07-31 09:49:18 --> Output Class Initialized
INFO - 2020-07-31 09:49:18 --> Security Class Initialized
DEBUG - 2020-07-31 09:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 09:49:18 --> Input Class Initialized
INFO - 2020-07-31 09:49:18 --> Language Class Initialized
INFO - 2020-07-31 09:49:18 --> Loader Class Initialized
INFO - 2020-07-31 09:49:18 --> Helper loaded: url_helper
INFO - 2020-07-31 09:49:18 --> Database Driver Class Initialized
INFO - 2020-07-31 09:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 09:49:18 --> Email Class Initialized
INFO - 2020-07-31 09:49:18 --> Controller Class Initialized
INFO - 2020-07-31 09:49:18 --> Model Class Initialized
INFO - 2020-07-31 09:49:18 --> Model Class Initialized
DEBUG - 2020-07-31 09:49:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 09:49:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 09:49:18 --> Final output sent to browser
DEBUG - 2020-07-31 09:49:18 --> Total execution time: 0.0213
INFO - 2020-07-31 10:15:06 --> Config Class Initialized
INFO - 2020-07-31 10:15:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 10:15:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 10:15:06 --> Utf8 Class Initialized
INFO - 2020-07-31 10:15:06 --> URI Class Initialized
INFO - 2020-07-31 10:15:06 --> Router Class Initialized
INFO - 2020-07-31 10:15:06 --> Output Class Initialized
INFO - 2020-07-31 10:15:06 --> Security Class Initialized
DEBUG - 2020-07-31 10:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 10:15:06 --> Input Class Initialized
INFO - 2020-07-31 10:15:06 --> Language Class Initialized
INFO - 2020-07-31 10:15:06 --> Loader Class Initialized
INFO - 2020-07-31 10:15:06 --> Helper loaded: url_helper
INFO - 2020-07-31 10:15:06 --> Database Driver Class Initialized
INFO - 2020-07-31 10:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 10:15:06 --> Email Class Initialized
INFO - 2020-07-31 10:15:06 --> Controller Class Initialized
INFO - 2020-07-31 10:15:06 --> Model Class Initialized
INFO - 2020-07-31 10:15:06 --> Model Class Initialized
DEBUG - 2020-07-31 10:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 10:15:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 10:15:06 --> Config Class Initialized
INFO - 2020-07-31 10:15:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 10:15:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 10:15:06 --> Utf8 Class Initialized
INFO - 2020-07-31 10:15:06 --> URI Class Initialized
DEBUG - 2020-07-31 10:15:06 --> No URI present. Default controller set.
INFO - 2020-07-31 10:15:06 --> Router Class Initialized
INFO - 2020-07-31 10:15:06 --> Output Class Initialized
INFO - 2020-07-31 10:15:06 --> Security Class Initialized
DEBUG - 2020-07-31 10:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 10:15:06 --> Input Class Initialized
INFO - 2020-07-31 10:15:06 --> Language Class Initialized
INFO - 2020-07-31 10:15:06 --> Loader Class Initialized
INFO - 2020-07-31 10:15:06 --> Helper loaded: url_helper
INFO - 2020-07-31 10:15:06 --> Database Driver Class Initialized
INFO - 2020-07-31 10:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 10:15:06 --> Email Class Initialized
INFO - 2020-07-31 10:15:06 --> Controller Class Initialized
INFO - 2020-07-31 10:15:06 --> Model Class Initialized
INFO - 2020-07-31 10:15:06 --> Model Class Initialized
DEBUG - 2020-07-31 10:15:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 10:15:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 10:15:06 --> Final output sent to browser
DEBUG - 2020-07-31 10:15:06 --> Total execution time: 0.0235
INFO - 2020-07-31 10:36:52 --> Config Class Initialized
INFO - 2020-07-31 10:36:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 10:36:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 10:36:52 --> Utf8 Class Initialized
INFO - 2020-07-31 10:36:52 --> URI Class Initialized
INFO - 2020-07-31 10:36:52 --> Router Class Initialized
INFO - 2020-07-31 10:36:52 --> Output Class Initialized
INFO - 2020-07-31 10:36:52 --> Security Class Initialized
DEBUG - 2020-07-31 10:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 10:36:52 --> Input Class Initialized
INFO - 2020-07-31 10:36:52 --> Language Class Initialized
INFO - 2020-07-31 10:36:52 --> Loader Class Initialized
INFO - 2020-07-31 10:36:52 --> Helper loaded: url_helper
INFO - 2020-07-31 10:36:52 --> Database Driver Class Initialized
INFO - 2020-07-31 10:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 10:36:52 --> Email Class Initialized
INFO - 2020-07-31 10:36:52 --> Controller Class Initialized
INFO - 2020-07-31 10:36:52 --> Model Class Initialized
INFO - 2020-07-31 10:36:52 --> Model Class Initialized
DEBUG - 2020-07-31 10:36:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 10:36:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 10:36:52 --> Config Class Initialized
INFO - 2020-07-31 10:36:52 --> Hooks Class Initialized
DEBUG - 2020-07-31 10:36:52 --> UTF-8 Support Enabled
INFO - 2020-07-31 10:36:52 --> Utf8 Class Initialized
INFO - 2020-07-31 10:36:52 --> URI Class Initialized
DEBUG - 2020-07-31 10:36:52 --> No URI present. Default controller set.
INFO - 2020-07-31 10:36:52 --> Router Class Initialized
INFO - 2020-07-31 10:36:52 --> Output Class Initialized
INFO - 2020-07-31 10:36:52 --> Security Class Initialized
DEBUG - 2020-07-31 10:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 10:36:52 --> Input Class Initialized
INFO - 2020-07-31 10:36:52 --> Language Class Initialized
INFO - 2020-07-31 10:36:52 --> Loader Class Initialized
INFO - 2020-07-31 10:36:52 --> Helper loaded: url_helper
INFO - 2020-07-31 10:36:52 --> Database Driver Class Initialized
INFO - 2020-07-31 10:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 10:36:52 --> Email Class Initialized
INFO - 2020-07-31 10:36:52 --> Controller Class Initialized
INFO - 2020-07-31 10:36:52 --> Model Class Initialized
INFO - 2020-07-31 10:36:52 --> Model Class Initialized
DEBUG - 2020-07-31 10:36:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 10:36:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 10:36:52 --> Final output sent to browser
DEBUG - 2020-07-31 10:36:52 --> Total execution time: 0.0207
INFO - 2020-07-31 11:01:18 --> Config Class Initialized
INFO - 2020-07-31 11:01:18 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:01:18 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:01:18 --> Utf8 Class Initialized
INFO - 2020-07-31 11:01:18 --> URI Class Initialized
DEBUG - 2020-07-31 11:01:18 --> No URI present. Default controller set.
INFO - 2020-07-31 11:01:18 --> Router Class Initialized
INFO - 2020-07-31 11:01:18 --> Output Class Initialized
INFO - 2020-07-31 11:01:18 --> Security Class Initialized
DEBUG - 2020-07-31 11:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:01:18 --> Input Class Initialized
INFO - 2020-07-31 11:01:18 --> Language Class Initialized
INFO - 2020-07-31 11:01:18 --> Loader Class Initialized
INFO - 2020-07-31 11:01:18 --> Helper loaded: url_helper
INFO - 2020-07-31 11:01:18 --> Database Driver Class Initialized
INFO - 2020-07-31 11:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:01:18 --> Email Class Initialized
INFO - 2020-07-31 11:01:18 --> Controller Class Initialized
INFO - 2020-07-31 11:01:18 --> Model Class Initialized
INFO - 2020-07-31 11:01:18 --> Model Class Initialized
DEBUG - 2020-07-31 11:01:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:01:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:01:18 --> Final output sent to browser
DEBUG - 2020-07-31 11:01:18 --> Total execution time: 0.0208
INFO - 2020-07-31 11:01:21 --> Config Class Initialized
INFO - 2020-07-31 11:01:21 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:01:21 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:01:21 --> Utf8 Class Initialized
INFO - 2020-07-31 11:01:21 --> URI Class Initialized
INFO - 2020-07-31 11:01:21 --> Router Class Initialized
INFO - 2020-07-31 11:01:21 --> Output Class Initialized
INFO - 2020-07-31 11:01:21 --> Security Class Initialized
DEBUG - 2020-07-31 11:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:01:21 --> Input Class Initialized
INFO - 2020-07-31 11:01:21 --> Language Class Initialized
INFO - 2020-07-31 11:01:21 --> Loader Class Initialized
INFO - 2020-07-31 11:01:21 --> Helper loaded: url_helper
INFO - 2020-07-31 11:01:21 --> Database Driver Class Initialized
INFO - 2020-07-31 11:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:01:21 --> Email Class Initialized
INFO - 2020-07-31 11:01:21 --> Controller Class Initialized
INFO - 2020-07-31 11:01:21 --> Model Class Initialized
INFO - 2020-07-31 11:01:21 --> Model Class Initialized
DEBUG - 2020-07-31 11:01:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:01:21 --> Config Class Initialized
INFO - 2020-07-31 11:01:21 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:01:21 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:01:21 --> Utf8 Class Initialized
INFO - 2020-07-31 11:01:21 --> URI Class Initialized
INFO - 2020-07-31 11:01:21 --> Router Class Initialized
INFO - 2020-07-31 11:01:21 --> Output Class Initialized
INFO - 2020-07-31 11:01:21 --> Security Class Initialized
DEBUG - 2020-07-31 11:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:01:21 --> Input Class Initialized
INFO - 2020-07-31 11:01:21 --> Language Class Initialized
INFO - 2020-07-31 11:01:21 --> Loader Class Initialized
INFO - 2020-07-31 11:01:21 --> Helper loaded: url_helper
INFO - 2020-07-31 11:01:21 --> Database Driver Class Initialized
INFO - 2020-07-31 11:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:01:21 --> Email Class Initialized
INFO - 2020-07-31 11:01:21 --> Controller Class Initialized
DEBUG - 2020-07-31 11:01:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:01:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:01:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 11:01:21 --> Final output sent to browser
DEBUG - 2020-07-31 11:01:21 --> Total execution time: 0.0230
INFO - 2020-07-31 11:01:36 --> Config Class Initialized
INFO - 2020-07-31 11:01:36 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:01:36 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:01:36 --> Utf8 Class Initialized
INFO - 2020-07-31 11:01:36 --> URI Class Initialized
INFO - 2020-07-31 11:01:36 --> Router Class Initialized
INFO - 2020-07-31 11:01:36 --> Output Class Initialized
INFO - 2020-07-31 11:01:36 --> Security Class Initialized
DEBUG - 2020-07-31 11:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:01:36 --> Input Class Initialized
INFO - 2020-07-31 11:01:36 --> Language Class Initialized
INFO - 2020-07-31 11:01:36 --> Loader Class Initialized
INFO - 2020-07-31 11:01:36 --> Helper loaded: url_helper
INFO - 2020-07-31 11:01:36 --> Database Driver Class Initialized
INFO - 2020-07-31 11:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:01:36 --> Email Class Initialized
INFO - 2020-07-31 11:01:36 --> Controller Class Initialized
DEBUG - 2020-07-31 11:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:01:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:01:36 --> Model Class Initialized
INFO - 2020-07-31 11:01:36 --> Model Class Initialized
INFO - 2020-07-31 11:01:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 11:01:36 --> Final output sent to browser
DEBUG - 2020-07-31 11:01:36 --> Total execution time: 0.0252
INFO - 2020-07-31 11:01:37 --> Config Class Initialized
INFO - 2020-07-31 11:01:37 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:01:37 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:01:37 --> Utf8 Class Initialized
INFO - 2020-07-31 11:01:37 --> URI Class Initialized
INFO - 2020-07-31 11:01:37 --> Router Class Initialized
INFO - 2020-07-31 11:01:37 --> Output Class Initialized
INFO - 2020-07-31 11:01:37 --> Security Class Initialized
DEBUG - 2020-07-31 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:01:37 --> Input Class Initialized
INFO - 2020-07-31 11:01:37 --> Language Class Initialized
INFO - 2020-07-31 11:01:37 --> Loader Class Initialized
INFO - 2020-07-31 11:01:37 --> Helper loaded: url_helper
INFO - 2020-07-31 11:01:37 --> Database Driver Class Initialized
INFO - 2020-07-31 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:01:37 --> Email Class Initialized
INFO - 2020-07-31 11:01:37 --> Controller Class Initialized
DEBUG - 2020-07-31 11:01:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:01:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:01:37 --> Model Class Initialized
INFO - 2020-07-31 11:01:37 --> Model Class Initialized
INFO - 2020-07-31 11:01:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 11:01:37 --> Final output sent to browser
DEBUG - 2020-07-31 11:01:37 --> Total execution time: 0.0239
INFO - 2020-07-31 11:01:53 --> Config Class Initialized
INFO - 2020-07-31 11:01:53 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:01:53 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:01:53 --> Utf8 Class Initialized
INFO - 2020-07-31 11:01:53 --> URI Class Initialized
INFO - 2020-07-31 11:01:53 --> Router Class Initialized
INFO - 2020-07-31 11:01:53 --> Output Class Initialized
INFO - 2020-07-31 11:01:53 --> Security Class Initialized
DEBUG - 2020-07-31 11:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:01:53 --> Input Class Initialized
INFO - 2020-07-31 11:01:53 --> Language Class Initialized
INFO - 2020-07-31 11:01:53 --> Loader Class Initialized
INFO - 2020-07-31 11:01:53 --> Helper loaded: url_helper
INFO - 2020-07-31 11:01:53 --> Database Driver Class Initialized
INFO - 2020-07-31 11:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:01:53 --> Email Class Initialized
INFO - 2020-07-31 11:01:53 --> Controller Class Initialized
DEBUG - 2020-07-31 11:01:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:01:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:01:53 --> Model Class Initialized
INFO - 2020-07-31 11:01:53 --> Model Class Initialized
INFO - 2020-07-31 11:01:53 --> Model Class Initialized
ERROR - 2020-07-31 11:01:53 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL user_registration('s@gmail.com','sourav','1122222222','jhg','3a7ae93d',3)
INFO - 2020-07-31 11:01:53 --> Language file loaded: language/english/db_lang.php
INFO - 2020-07-31 11:02:21 --> Config Class Initialized
INFO - 2020-07-31 11:02:21 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:02:21 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:02:21 --> Utf8 Class Initialized
INFO - 2020-07-31 11:02:21 --> URI Class Initialized
INFO - 2020-07-31 11:02:21 --> Router Class Initialized
INFO - 2020-07-31 11:02:21 --> Output Class Initialized
INFO - 2020-07-31 11:02:21 --> Security Class Initialized
DEBUG - 2020-07-31 11:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:02:21 --> Input Class Initialized
INFO - 2020-07-31 11:02:21 --> Language Class Initialized
INFO - 2020-07-31 11:02:21 --> Loader Class Initialized
INFO - 2020-07-31 11:02:21 --> Helper loaded: url_helper
INFO - 2020-07-31 11:02:21 --> Database Driver Class Initialized
INFO - 2020-07-31 11:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:02:21 --> Email Class Initialized
INFO - 2020-07-31 11:02:21 --> Controller Class Initialized
DEBUG - 2020-07-31 11:02:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:02:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:02:21 --> Model Class Initialized
INFO - 2020-07-31 11:02:21 --> Model Class Initialized
INFO - 2020-07-31 11:02:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 11:02:21 --> Final output sent to browser
DEBUG - 2020-07-31 11:02:21 --> Total execution time: 0.0198
INFO - 2020-07-31 11:03:09 --> Config Class Initialized
INFO - 2020-07-31 11:03:09 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:03:09 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:03:09 --> Utf8 Class Initialized
INFO - 2020-07-31 11:03:09 --> URI Class Initialized
INFO - 2020-07-31 11:03:09 --> Router Class Initialized
INFO - 2020-07-31 11:03:09 --> Output Class Initialized
INFO - 2020-07-31 11:03:09 --> Security Class Initialized
DEBUG - 2020-07-31 11:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:03:09 --> Input Class Initialized
INFO - 2020-07-31 11:03:09 --> Language Class Initialized
INFO - 2020-07-31 11:03:09 --> Loader Class Initialized
INFO - 2020-07-31 11:03:09 --> Helper loaded: url_helper
INFO - 2020-07-31 11:03:09 --> Database Driver Class Initialized
INFO - 2020-07-31 11:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:03:09 --> Email Class Initialized
INFO - 2020-07-31 11:03:09 --> Controller Class Initialized
DEBUG - 2020-07-31 11:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:03:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:03:09 --> Model Class Initialized
INFO - 2020-07-31 11:03:09 --> Model Class Initialized
INFO - 2020-07-31 11:03:09 --> Model Class Initialized
ERROR - 2020-07-31 11:03:09 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL user_registration('s@gmail.com','sourav','1122222222','jhg','1e54399a',4)
INFO - 2020-07-31 11:03:09 --> Language file loaded: language/english/db_lang.php
INFO - 2020-07-31 11:03:13 --> Config Class Initialized
INFO - 2020-07-31 11:03:13 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:03:13 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:03:13 --> Utf8 Class Initialized
INFO - 2020-07-31 11:03:13 --> URI Class Initialized
INFO - 2020-07-31 11:03:13 --> Router Class Initialized
INFO - 2020-07-31 11:03:13 --> Output Class Initialized
INFO - 2020-07-31 11:03:13 --> Security Class Initialized
DEBUG - 2020-07-31 11:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:03:13 --> Input Class Initialized
INFO - 2020-07-31 11:03:13 --> Language Class Initialized
INFO - 2020-07-31 11:03:13 --> Loader Class Initialized
INFO - 2020-07-31 11:03:13 --> Helper loaded: url_helper
INFO - 2020-07-31 11:03:13 --> Database Driver Class Initialized
INFO - 2020-07-31 11:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:03:13 --> Email Class Initialized
INFO - 2020-07-31 11:03:13 --> Controller Class Initialized
DEBUG - 2020-07-31 11:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:03:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:03:13 --> Model Class Initialized
INFO - 2020-07-31 11:03:13 --> Model Class Initialized
INFO - 2020-07-31 11:03:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-31 11:03:13 --> Final output sent to browser
DEBUG - 2020-07-31 11:03:13 --> Total execution time: 0.0230
INFO - 2020-07-31 11:03:30 --> Config Class Initialized
INFO - 2020-07-31 11:03:30 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:03:30 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:03:30 --> Utf8 Class Initialized
INFO - 2020-07-31 11:03:30 --> URI Class Initialized
INFO - 2020-07-31 11:03:30 --> Router Class Initialized
INFO - 2020-07-31 11:03:30 --> Output Class Initialized
INFO - 2020-07-31 11:03:30 --> Security Class Initialized
DEBUG - 2020-07-31 11:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:03:30 --> Input Class Initialized
INFO - 2020-07-31 11:03:30 --> Language Class Initialized
INFO - 2020-07-31 11:03:30 --> Loader Class Initialized
INFO - 2020-07-31 11:03:30 --> Helper loaded: url_helper
INFO - 2020-07-31 11:03:30 --> Database Driver Class Initialized
INFO - 2020-07-31 11:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:03:30 --> Email Class Initialized
INFO - 2020-07-31 11:03:30 --> Controller Class Initialized
DEBUG - 2020-07-31 11:03:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:03:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:03:30 --> Model Class Initialized
INFO - 2020-07-31 11:03:30 --> Model Class Initialized
ERROR - 2020-07-31 11:03:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Admin_model.php:20) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-31 11:03:30 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::next_result() /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 20
INFO - 2020-07-31 11:04:01 --> Config Class Initialized
INFO - 2020-07-31 11:04:01 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:04:01 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:04:01 --> Utf8 Class Initialized
INFO - 2020-07-31 11:04:01 --> URI Class Initialized
INFO - 2020-07-31 11:04:01 --> Router Class Initialized
INFO - 2020-07-31 11:04:01 --> Output Class Initialized
INFO - 2020-07-31 11:04:01 --> Security Class Initialized
DEBUG - 2020-07-31 11:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:04:01 --> Input Class Initialized
INFO - 2020-07-31 11:04:01 --> Language Class Initialized
INFO - 2020-07-31 11:04:01 --> Loader Class Initialized
INFO - 2020-07-31 11:04:01 --> Helper loaded: url_helper
INFO - 2020-07-31 11:04:01 --> Database Driver Class Initialized
INFO - 2020-07-31 11:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:04:01 --> Email Class Initialized
INFO - 2020-07-31 11:04:01 --> Controller Class Initialized
DEBUG - 2020-07-31 11:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:04:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:04:01 --> Model Class Initialized
INFO - 2020-07-31 11:04:01 --> Model Class Initialized
INFO - 2020-07-31 11:04:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-31 11:04:01 --> Final output sent to browser
DEBUG - 2020-07-31 11:04:01 --> Total execution time: 0.1334
INFO - 2020-07-31 11:28:32 --> Config Class Initialized
INFO - 2020-07-31 11:28:32 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:28:32 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:28:32 --> Utf8 Class Initialized
INFO - 2020-07-31 11:28:32 --> URI Class Initialized
INFO - 2020-07-31 11:28:32 --> Router Class Initialized
INFO - 2020-07-31 11:28:32 --> Output Class Initialized
INFO - 2020-07-31 11:28:32 --> Security Class Initialized
DEBUG - 2020-07-31 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:28:32 --> Input Class Initialized
INFO - 2020-07-31 11:28:32 --> Language Class Initialized
INFO - 2020-07-31 11:28:32 --> Loader Class Initialized
INFO - 2020-07-31 11:28:32 --> Helper loaded: url_helper
INFO - 2020-07-31 11:28:32 --> Database Driver Class Initialized
INFO - 2020-07-31 11:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:28:32 --> Email Class Initialized
INFO - 2020-07-31 11:28:32 --> Controller Class Initialized
INFO - 2020-07-31 11:28:32 --> Model Class Initialized
INFO - 2020-07-31 11:28:32 --> Model Class Initialized
DEBUG - 2020-07-31 11:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:28:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:28:33 --> Config Class Initialized
INFO - 2020-07-31 11:28:33 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:28:33 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:28:33 --> Utf8 Class Initialized
INFO - 2020-07-31 11:28:33 --> URI Class Initialized
DEBUG - 2020-07-31 11:28:33 --> No URI present. Default controller set.
INFO - 2020-07-31 11:28:33 --> Router Class Initialized
INFO - 2020-07-31 11:28:33 --> Output Class Initialized
INFO - 2020-07-31 11:28:33 --> Security Class Initialized
DEBUG - 2020-07-31 11:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:28:33 --> Input Class Initialized
INFO - 2020-07-31 11:28:33 --> Language Class Initialized
INFO - 2020-07-31 11:28:33 --> Loader Class Initialized
INFO - 2020-07-31 11:28:33 --> Helper loaded: url_helper
INFO - 2020-07-31 11:28:33 --> Database Driver Class Initialized
INFO - 2020-07-31 11:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:28:33 --> Email Class Initialized
INFO - 2020-07-31 11:28:33 --> Controller Class Initialized
INFO - 2020-07-31 11:28:33 --> Model Class Initialized
INFO - 2020-07-31 11:28:33 --> Model Class Initialized
DEBUG - 2020-07-31 11:28:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:28:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:28:33 --> Final output sent to browser
DEBUG - 2020-07-31 11:28:33 --> Total execution time: 0.0257
INFO - 2020-07-31 11:54:58 --> Config Class Initialized
INFO - 2020-07-31 11:54:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:54:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:54:58 --> Utf8 Class Initialized
INFO - 2020-07-31 11:54:58 --> URI Class Initialized
DEBUG - 2020-07-31 11:54:58 --> No URI present. Default controller set.
INFO - 2020-07-31 11:54:58 --> Router Class Initialized
INFO - 2020-07-31 11:54:58 --> Output Class Initialized
INFO - 2020-07-31 11:54:58 --> Security Class Initialized
DEBUG - 2020-07-31 11:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:54:58 --> Input Class Initialized
INFO - 2020-07-31 11:54:58 --> Language Class Initialized
INFO - 2020-07-31 11:54:58 --> Loader Class Initialized
INFO - 2020-07-31 11:54:58 --> Helper loaded: url_helper
INFO - 2020-07-31 11:54:58 --> Database Driver Class Initialized
INFO - 2020-07-31 11:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:54:58 --> Email Class Initialized
INFO - 2020-07-31 11:54:58 --> Controller Class Initialized
INFO - 2020-07-31 11:54:58 --> Model Class Initialized
INFO - 2020-07-31 11:54:58 --> Model Class Initialized
DEBUG - 2020-07-31 11:54:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:54:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:54:58 --> Final output sent to browser
DEBUG - 2020-07-31 11:54:58 --> Total execution time: 0.0271
INFO - 2020-07-31 11:55:05 --> Config Class Initialized
INFO - 2020-07-31 11:55:05 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:05 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:05 --> Config Class Initialized
INFO - 2020-07-31 11:55:05 --> Hooks Class Initialized
INFO - 2020-07-31 11:55:05 --> URI Class Initialized
INFO - 2020-07-31 11:55:05 --> Router Class Initialized
DEBUG - 2020-07-31 11:55:05 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:05 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:05 --> Output Class Initialized
INFO - 2020-07-31 11:55:05 --> URI Class Initialized
INFO - 2020-07-31 11:55:05 --> Security Class Initialized
INFO - 2020-07-31 11:55:05 --> Router Class Initialized
DEBUG - 2020-07-31 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:05 --> Input Class Initialized
INFO - 2020-07-31 11:55:05 --> Language Class Initialized
INFO - 2020-07-31 11:55:05 --> Output Class Initialized
INFO - 2020-07-31 11:55:05 --> Security Class Initialized
INFO - 2020-07-31 11:55:05 --> Loader Class Initialized
DEBUG - 2020-07-31 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:05 --> Input Class Initialized
INFO - 2020-07-31 11:55:05 --> Language Class Initialized
INFO - 2020-07-31 11:55:05 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:05 --> Loader Class Initialized
INFO - 2020-07-31 11:55:05 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:05 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:05 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:05 --> Email Class Initialized
INFO - 2020-07-31 11:55:05 --> Controller Class Initialized
INFO - 2020-07-31 11:55:05 --> Model Class Initialized
INFO - 2020-07-31 11:55:05 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:55:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:05 --> Email Class Initialized
INFO - 2020-07-31 11:55:05 --> Controller Class Initialized
INFO - 2020-07-31 11:55:05 --> Model Class Initialized
INFO - 2020-07-31 11:55:05 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:06 --> Config Class Initialized
INFO - 2020-07-31 11:55:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:06 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:06 --> URI Class Initialized
DEBUG - 2020-07-31 11:55:06 --> No URI present. Default controller set.
INFO - 2020-07-31 11:55:06 --> Router Class Initialized
INFO - 2020-07-31 11:55:06 --> Output Class Initialized
INFO - 2020-07-31 11:55:06 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:06 --> Input Class Initialized
INFO - 2020-07-31 11:55:06 --> Language Class Initialized
INFO - 2020-07-31 11:55:06 --> Loader Class Initialized
INFO - 2020-07-31 11:55:06 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:06 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:06 --> Email Class Initialized
INFO - 2020-07-31 11:55:06 --> Controller Class Initialized
INFO - 2020-07-31 11:55:06 --> Model Class Initialized
INFO - 2020-07-31 11:55:06 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:55:06 --> Final output sent to browser
DEBUG - 2020-07-31 11:55:06 --> Total execution time: 0.0206
INFO - 2020-07-31 11:55:06 --> Config Class Initialized
INFO - 2020-07-31 11:55:06 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:06 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:06 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:06 --> URI Class Initialized
DEBUG - 2020-07-31 11:55:06 --> No URI present. Default controller set.
INFO - 2020-07-31 11:55:06 --> Router Class Initialized
INFO - 2020-07-31 11:55:06 --> Output Class Initialized
INFO - 2020-07-31 11:55:06 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:06 --> Input Class Initialized
INFO - 2020-07-31 11:55:06 --> Language Class Initialized
INFO - 2020-07-31 11:55:06 --> Loader Class Initialized
INFO - 2020-07-31 11:55:06 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:06 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:06 --> Email Class Initialized
INFO - 2020-07-31 11:55:06 --> Controller Class Initialized
INFO - 2020-07-31 11:55:06 --> Model Class Initialized
INFO - 2020-07-31 11:55:06 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:55:06 --> Final output sent to browser
DEBUG - 2020-07-31 11:55:06 --> Total execution time: 0.0230
INFO - 2020-07-31 11:55:39 --> Config Class Initialized
INFO - 2020-07-31 11:55:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:39 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:39 --> URI Class Initialized
INFO - 2020-07-31 11:55:39 --> Router Class Initialized
INFO - 2020-07-31 11:55:39 --> Output Class Initialized
INFO - 2020-07-31 11:55:39 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:39 --> Input Class Initialized
INFO - 2020-07-31 11:55:39 --> Language Class Initialized
INFO - 2020-07-31 11:55:39 --> Loader Class Initialized
INFO - 2020-07-31 11:55:39 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:39 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:39 --> Email Class Initialized
INFO - 2020-07-31 11:55:39 --> Controller Class Initialized
INFO - 2020-07-31 11:55:39 --> Model Class Initialized
INFO - 2020-07-31 11:55:39 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:55:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:39 --> Config Class Initialized
INFO - 2020-07-31 11:55:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:39 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:39 --> URI Class Initialized
INFO - 2020-07-31 11:55:39 --> Router Class Initialized
INFO - 2020-07-31 11:55:39 --> Output Class Initialized
INFO - 2020-07-31 11:55:39 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:39 --> Input Class Initialized
INFO - 2020-07-31 11:55:39 --> Language Class Initialized
INFO - 2020-07-31 11:55:39 --> Loader Class Initialized
INFO - 2020-07-31 11:55:39 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:39 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:39 --> Email Class Initialized
INFO - 2020-07-31 11:55:39 --> Controller Class Initialized
INFO - 2020-07-31 11:55:39 --> Model Class Initialized
INFO - 2020-07-31 11:55:39 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:39 --> Config Class Initialized
INFO - 2020-07-31 11:55:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:39 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:39 --> URI Class Initialized
DEBUG - 2020-07-31 11:55:39 --> No URI present. Default controller set.
INFO - 2020-07-31 11:55:39 --> Router Class Initialized
INFO - 2020-07-31 11:55:39 --> Output Class Initialized
INFO - 2020-07-31 11:55:39 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:39 --> Input Class Initialized
INFO - 2020-07-31 11:55:39 --> Language Class Initialized
INFO - 2020-07-31 11:55:39 --> Loader Class Initialized
INFO - 2020-07-31 11:55:39 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:39 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:39 --> Email Class Initialized
INFO - 2020-07-31 11:55:39 --> Controller Class Initialized
INFO - 2020-07-31 11:55:39 --> Model Class Initialized
INFO - 2020-07-31 11:55:39 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:55:39 --> Final output sent to browser
DEBUG - 2020-07-31 11:55:39 --> Total execution time: 0.0245
INFO - 2020-07-31 11:55:39 --> Config Class Initialized
INFO - 2020-07-31 11:55:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:39 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:39 --> URI Class Initialized
INFO - 2020-07-31 11:55:39 --> Router Class Initialized
INFO - 2020-07-31 11:55:39 --> Output Class Initialized
INFO - 2020-07-31 11:55:39 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:39 --> Input Class Initialized
INFO - 2020-07-31 11:55:39 --> Language Class Initialized
INFO - 2020-07-31 11:55:39 --> Loader Class Initialized
INFO - 2020-07-31 11:55:39 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:39 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:39 --> Email Class Initialized
INFO - 2020-07-31 11:55:39 --> Controller Class Initialized
DEBUG - 2020-07-31 11:55:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:55:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 11:55:39 --> Final output sent to browser
DEBUG - 2020-07-31 11:55:39 --> Total execution time: 0.0244
INFO - 2020-07-31 11:55:41 --> Config Class Initialized
INFO - 2020-07-31 11:55:41 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:55:41 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:55:41 --> Utf8 Class Initialized
INFO - 2020-07-31 11:55:41 --> URI Class Initialized
DEBUG - 2020-07-31 11:55:41 --> No URI present. Default controller set.
INFO - 2020-07-31 11:55:41 --> Router Class Initialized
INFO - 2020-07-31 11:55:41 --> Output Class Initialized
INFO - 2020-07-31 11:55:41 --> Security Class Initialized
DEBUG - 2020-07-31 11:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:55:41 --> Input Class Initialized
INFO - 2020-07-31 11:55:41 --> Language Class Initialized
INFO - 2020-07-31 11:55:41 --> Loader Class Initialized
INFO - 2020-07-31 11:55:41 --> Helper loaded: url_helper
INFO - 2020-07-31 11:55:41 --> Database Driver Class Initialized
INFO - 2020-07-31 11:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:55:41 --> Email Class Initialized
INFO - 2020-07-31 11:55:41 --> Controller Class Initialized
INFO - 2020-07-31 11:55:41 --> Model Class Initialized
INFO - 2020-07-31 11:55:41 --> Model Class Initialized
DEBUG - 2020-07-31 11:55:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:55:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:55:41 --> Final output sent to browser
DEBUG - 2020-07-31 11:55:41 --> Total execution time: 0.0236
INFO - 2020-07-31 11:56:25 --> Config Class Initialized
INFO - 2020-07-31 11:56:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:56:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:56:25 --> Utf8 Class Initialized
INFO - 2020-07-31 11:56:25 --> URI Class Initialized
INFO - 2020-07-31 11:56:25 --> Router Class Initialized
INFO - 2020-07-31 11:56:25 --> Output Class Initialized
INFO - 2020-07-31 11:56:25 --> Security Class Initialized
DEBUG - 2020-07-31 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:56:25 --> Input Class Initialized
INFO - 2020-07-31 11:56:25 --> Language Class Initialized
INFO - 2020-07-31 11:56:25 --> Loader Class Initialized
INFO - 2020-07-31 11:56:25 --> Helper loaded: url_helper
INFO - 2020-07-31 11:56:25 --> Database Driver Class Initialized
INFO - 2020-07-31 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:56:25 --> Email Class Initialized
INFO - 2020-07-31 11:56:25 --> Controller Class Initialized
INFO - 2020-07-31 11:56:25 --> Model Class Initialized
INFO - 2020-07-31 11:56:25 --> Model Class Initialized
DEBUG - 2020-07-31 11:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:56:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:56:25 --> Model Class Initialized
INFO - 2020-07-31 11:56:25 --> Final output sent to browser
DEBUG - 2020-07-31 11:56:25 --> Total execution time: 0.0252
INFO - 2020-07-31 11:56:25 --> Config Class Initialized
INFO - 2020-07-31 11:56:25 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:56:25 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:56:25 --> Utf8 Class Initialized
INFO - 2020-07-31 11:56:25 --> URI Class Initialized
INFO - 2020-07-31 11:56:25 --> Router Class Initialized
INFO - 2020-07-31 11:56:25 --> Output Class Initialized
INFO - 2020-07-31 11:56:25 --> Security Class Initialized
DEBUG - 2020-07-31 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:56:25 --> Input Class Initialized
INFO - 2020-07-31 11:56:25 --> Language Class Initialized
INFO - 2020-07-31 11:56:25 --> Loader Class Initialized
INFO - 2020-07-31 11:56:25 --> Helper loaded: url_helper
INFO - 2020-07-31 11:56:25 --> Database Driver Class Initialized
INFO - 2020-07-31 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:56:25 --> Email Class Initialized
INFO - 2020-07-31 11:56:25 --> Controller Class Initialized
INFO - 2020-07-31 11:56:25 --> Model Class Initialized
INFO - 2020-07-31 11:56:25 --> Model Class Initialized
DEBUG - 2020-07-31 11:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:56:26 --> Config Class Initialized
INFO - 2020-07-31 11:56:26 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:56:26 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:56:26 --> Utf8 Class Initialized
INFO - 2020-07-31 11:56:26 --> URI Class Initialized
INFO - 2020-07-31 11:56:26 --> Router Class Initialized
INFO - 2020-07-31 11:56:26 --> Output Class Initialized
INFO - 2020-07-31 11:56:26 --> Security Class Initialized
DEBUG - 2020-07-31 11:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:56:26 --> Input Class Initialized
INFO - 2020-07-31 11:56:26 --> Language Class Initialized
INFO - 2020-07-31 11:56:26 --> Loader Class Initialized
INFO - 2020-07-31 11:56:26 --> Helper loaded: url_helper
INFO - 2020-07-31 11:56:26 --> Database Driver Class Initialized
INFO - 2020-07-31 11:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:56:26 --> Email Class Initialized
INFO - 2020-07-31 11:56:26 --> Controller Class Initialized
DEBUG - 2020-07-31 11:56:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:56:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:56:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 11:56:26 --> Final output sent to browser
DEBUG - 2020-07-31 11:56:26 --> Total execution time: 0.0261
INFO - 2020-07-31 11:56:32 --> Config Class Initialized
INFO - 2020-07-31 11:56:32 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:56:32 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:56:32 --> Utf8 Class Initialized
INFO - 2020-07-31 11:56:32 --> URI Class Initialized
INFO - 2020-07-31 11:56:32 --> Router Class Initialized
INFO - 2020-07-31 11:56:32 --> Output Class Initialized
INFO - 2020-07-31 11:56:32 --> Security Class Initialized
DEBUG - 2020-07-31 11:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:56:32 --> Input Class Initialized
INFO - 2020-07-31 11:56:32 --> Language Class Initialized
INFO - 2020-07-31 11:56:32 --> Loader Class Initialized
INFO - 2020-07-31 11:56:32 --> Helper loaded: url_helper
INFO - 2020-07-31 11:56:32 --> Database Driver Class Initialized
INFO - 2020-07-31 11:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:56:32 --> Email Class Initialized
INFO - 2020-07-31 11:56:32 --> Controller Class Initialized
INFO - 2020-07-31 11:56:32 --> Model Class Initialized
INFO - 2020-07-31 11:56:32 --> Model Class Initialized
DEBUG - 2020-07-31 11:56:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:56:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:56:32 --> Model Class Initialized
INFO - 2020-07-31 11:56:32 --> Final output sent to browser
DEBUG - 2020-07-31 11:56:32 --> Total execution time: 0.0264
INFO - 2020-07-31 11:59:40 --> Config Class Initialized
INFO - 2020-07-31 11:59:40 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:59:40 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:59:40 --> Utf8 Class Initialized
INFO - 2020-07-31 11:59:40 --> URI Class Initialized
INFO - 2020-07-31 11:59:40 --> Router Class Initialized
INFO - 2020-07-31 11:59:40 --> Output Class Initialized
INFO - 2020-07-31 11:59:40 --> Security Class Initialized
DEBUG - 2020-07-31 11:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:59:40 --> Input Class Initialized
INFO - 2020-07-31 11:59:40 --> Language Class Initialized
INFO - 2020-07-31 11:59:40 --> Loader Class Initialized
INFO - 2020-07-31 11:59:40 --> Helper loaded: url_helper
INFO - 2020-07-31 11:59:40 --> Database Driver Class Initialized
INFO - 2020-07-31 11:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:59:40 --> Email Class Initialized
INFO - 2020-07-31 11:59:40 --> Controller Class Initialized
DEBUG - 2020-07-31 11:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:59:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:59:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 11:59:40 --> Final output sent to browser
DEBUG - 2020-07-31 11:59:40 --> Total execution time: 0.0228
INFO - 2020-07-31 11:59:44 --> Config Class Initialized
INFO - 2020-07-31 11:59:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:59:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:59:44 --> Utf8 Class Initialized
INFO - 2020-07-31 11:59:44 --> URI Class Initialized
DEBUG - 2020-07-31 11:59:44 --> No URI present. Default controller set.
INFO - 2020-07-31 11:59:44 --> Router Class Initialized
INFO - 2020-07-31 11:59:44 --> Output Class Initialized
INFO - 2020-07-31 11:59:44 --> Security Class Initialized
DEBUG - 2020-07-31 11:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:59:44 --> Input Class Initialized
INFO - 2020-07-31 11:59:44 --> Language Class Initialized
INFO - 2020-07-31 11:59:44 --> Loader Class Initialized
INFO - 2020-07-31 11:59:44 --> Helper loaded: url_helper
INFO - 2020-07-31 11:59:44 --> Database Driver Class Initialized
INFO - 2020-07-31 11:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:59:44 --> Email Class Initialized
INFO - 2020-07-31 11:59:44 --> Controller Class Initialized
INFO - 2020-07-31 11:59:44 --> Model Class Initialized
INFO - 2020-07-31 11:59:44 --> Model Class Initialized
DEBUG - 2020-07-31 11:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:59:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:59:44 --> Final output sent to browser
DEBUG - 2020-07-31 11:59:44 --> Total execution time: 0.0230
INFO - 2020-07-31 11:59:53 --> Config Class Initialized
INFO - 2020-07-31 11:59:53 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:59:53 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:59:53 --> Utf8 Class Initialized
INFO - 2020-07-31 11:59:53 --> URI Class Initialized
INFO - 2020-07-31 11:59:53 --> Router Class Initialized
INFO - 2020-07-31 11:59:53 --> Output Class Initialized
INFO - 2020-07-31 11:59:53 --> Security Class Initialized
DEBUG - 2020-07-31 11:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:59:53 --> Input Class Initialized
INFO - 2020-07-31 11:59:53 --> Language Class Initialized
INFO - 2020-07-31 11:59:53 --> Loader Class Initialized
INFO - 2020-07-31 11:59:53 --> Helper loaded: url_helper
INFO - 2020-07-31 11:59:53 --> Database Driver Class Initialized
INFO - 2020-07-31 11:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:59:53 --> Email Class Initialized
INFO - 2020-07-31 11:59:53 --> Controller Class Initialized
INFO - 2020-07-31 11:59:53 --> Model Class Initialized
INFO - 2020-07-31 11:59:53 --> Model Class Initialized
DEBUG - 2020-07-31 11:59:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 11:59:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:59:53 --> Model Class Initialized
INFO - 2020-07-31 11:59:53 --> Final output sent to browser
DEBUG - 2020-07-31 11:59:53 --> Total execution time: 0.0277
INFO - 2020-07-31 11:59:53 --> Config Class Initialized
INFO - 2020-07-31 11:59:53 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:59:53 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:59:53 --> Utf8 Class Initialized
INFO - 2020-07-31 11:59:53 --> URI Class Initialized
INFO - 2020-07-31 11:59:53 --> Router Class Initialized
INFO - 2020-07-31 11:59:53 --> Output Class Initialized
INFO - 2020-07-31 11:59:53 --> Security Class Initialized
DEBUG - 2020-07-31 11:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:59:53 --> Input Class Initialized
INFO - 2020-07-31 11:59:53 --> Language Class Initialized
INFO - 2020-07-31 11:59:53 --> Loader Class Initialized
INFO - 2020-07-31 11:59:53 --> Helper loaded: url_helper
INFO - 2020-07-31 11:59:53 --> Database Driver Class Initialized
INFO - 2020-07-31 11:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:59:53 --> Email Class Initialized
INFO - 2020-07-31 11:59:53 --> Controller Class Initialized
INFO - 2020-07-31 11:59:53 --> Model Class Initialized
INFO - 2020-07-31 11:59:53 --> Model Class Initialized
DEBUG - 2020-07-31 11:59:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:59:54 --> Config Class Initialized
INFO - 2020-07-31 11:59:54 --> Hooks Class Initialized
DEBUG - 2020-07-31 11:59:54 --> UTF-8 Support Enabled
INFO - 2020-07-31 11:59:54 --> Utf8 Class Initialized
INFO - 2020-07-31 11:59:54 --> URI Class Initialized
DEBUG - 2020-07-31 11:59:54 --> No URI present. Default controller set.
INFO - 2020-07-31 11:59:54 --> Router Class Initialized
INFO - 2020-07-31 11:59:54 --> Output Class Initialized
INFO - 2020-07-31 11:59:54 --> Security Class Initialized
DEBUG - 2020-07-31 11:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 11:59:54 --> Input Class Initialized
INFO - 2020-07-31 11:59:54 --> Language Class Initialized
INFO - 2020-07-31 11:59:54 --> Loader Class Initialized
INFO - 2020-07-31 11:59:54 --> Helper loaded: url_helper
INFO - 2020-07-31 11:59:54 --> Database Driver Class Initialized
INFO - 2020-07-31 11:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 11:59:54 --> Email Class Initialized
INFO - 2020-07-31 11:59:54 --> Controller Class Initialized
INFO - 2020-07-31 11:59:54 --> Model Class Initialized
INFO - 2020-07-31 11:59:54 --> Model Class Initialized
DEBUG - 2020-07-31 11:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 11:59:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 11:59:54 --> Final output sent to browser
DEBUG - 2020-07-31 11:59:54 --> Total execution time: 0.0226
INFO - 2020-07-31 12:03:08 --> Config Class Initialized
INFO - 2020-07-31 12:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:08 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:08 --> URI Class Initialized
INFO - 2020-07-31 12:03:08 --> Router Class Initialized
INFO - 2020-07-31 12:03:08 --> Output Class Initialized
INFO - 2020-07-31 12:03:08 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:08 --> Input Class Initialized
INFO - 2020-07-31 12:03:08 --> Language Class Initialized
INFO - 2020-07-31 12:03:08 --> Loader Class Initialized
INFO - 2020-07-31 12:03:08 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:08 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:08 --> Email Class Initialized
INFO - 2020-07-31 12:03:08 --> Controller Class Initialized
INFO - 2020-07-31 12:03:08 --> Model Class Initialized
INFO - 2020-07-31 12:03:08 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:03:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:08 --> Config Class Initialized
INFO - 2020-07-31 12:03:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:08 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:08 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:08 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:08 --> Router Class Initialized
INFO - 2020-07-31 12:03:08 --> Output Class Initialized
INFO - 2020-07-31 12:03:08 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:08 --> Input Class Initialized
INFO - 2020-07-31 12:03:08 --> Language Class Initialized
INFO - 2020-07-31 12:03:08 --> Loader Class Initialized
INFO - 2020-07-31 12:03:08 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:08 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:08 --> Email Class Initialized
INFO - 2020-07-31 12:03:08 --> Controller Class Initialized
INFO - 2020-07-31 12:03:08 --> Model Class Initialized
INFO - 2020-07-31 12:03:08 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:08 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:08 --> Total execution time: 0.0224
INFO - 2020-07-31 12:03:15 --> Config Class Initialized
INFO - 2020-07-31 12:03:15 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:15 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:15 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:15 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:15 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:15 --> Router Class Initialized
INFO - 2020-07-31 12:03:15 --> Output Class Initialized
INFO - 2020-07-31 12:03:15 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:15 --> Input Class Initialized
INFO - 2020-07-31 12:03:15 --> Language Class Initialized
INFO - 2020-07-31 12:03:15 --> Loader Class Initialized
INFO - 2020-07-31 12:03:15 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:15 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:15 --> Email Class Initialized
INFO - 2020-07-31 12:03:15 --> Controller Class Initialized
INFO - 2020-07-31 12:03:15 --> Model Class Initialized
INFO - 2020-07-31 12:03:15 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:15 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:15 --> Total execution time: 0.0210
INFO - 2020-07-31 12:03:24 --> Config Class Initialized
INFO - 2020-07-31 12:03:24 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:24 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:24 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:24 --> URI Class Initialized
INFO - 2020-07-31 12:03:24 --> Router Class Initialized
INFO - 2020-07-31 12:03:24 --> Output Class Initialized
INFO - 2020-07-31 12:03:24 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:24 --> Input Class Initialized
INFO - 2020-07-31 12:03:24 --> Language Class Initialized
INFO - 2020-07-31 12:03:24 --> Loader Class Initialized
INFO - 2020-07-31 12:03:24 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:24 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:24 --> Email Class Initialized
INFO - 2020-07-31 12:03:24 --> Controller Class Initialized
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:24 --> Config Class Initialized
INFO - 2020-07-31 12:03:24 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:24 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:24 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:24 --> URI Class Initialized
INFO - 2020-07-31 12:03:24 --> Router Class Initialized
INFO - 2020-07-31 12:03:24 --> Output Class Initialized
INFO - 2020-07-31 12:03:24 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:24 --> Input Class Initialized
INFO - 2020-07-31 12:03:24 --> Language Class Initialized
INFO - 2020-07-31 12:03:24 --> Loader Class Initialized
INFO - 2020-07-31 12:03:24 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:24 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:24 --> Email Class Initialized
INFO - 2020-07-31 12:03:24 --> Controller Class Initialized
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:03:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
INFO - 2020-07-31 12:03:24 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:24 --> Total execution time: 0.0249
INFO - 2020-07-31 12:03:24 --> Config Class Initialized
INFO - 2020-07-31 12:03:24 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:24 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:24 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:24 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:24 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:24 --> Router Class Initialized
INFO - 2020-07-31 12:03:24 --> Output Class Initialized
INFO - 2020-07-31 12:03:24 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:24 --> Input Class Initialized
INFO - 2020-07-31 12:03:24 --> Language Class Initialized
INFO - 2020-07-31 12:03:24 --> Loader Class Initialized
INFO - 2020-07-31 12:03:24 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:24 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:24 --> Email Class Initialized
INFO - 2020-07-31 12:03:24 --> Controller Class Initialized
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
INFO - 2020-07-31 12:03:24 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:24 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:24 --> Total execution time: 0.0201
INFO - 2020-07-31 12:03:33 --> Config Class Initialized
INFO - 2020-07-31 12:03:33 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:33 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:33 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:33 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:33 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:33 --> Router Class Initialized
INFO - 2020-07-31 12:03:33 --> Output Class Initialized
INFO - 2020-07-31 12:03:33 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:33 --> Input Class Initialized
INFO - 2020-07-31 12:03:33 --> Language Class Initialized
INFO - 2020-07-31 12:03:33 --> Loader Class Initialized
INFO - 2020-07-31 12:03:33 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:33 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:33 --> Email Class Initialized
INFO - 2020-07-31 12:03:33 --> Controller Class Initialized
INFO - 2020-07-31 12:03:33 --> Model Class Initialized
INFO - 2020-07-31 12:03:33 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:33 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:33 --> Total execution time: 0.0213
INFO - 2020-07-31 12:03:41 --> Config Class Initialized
INFO - 2020-07-31 12:03:41 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:41 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:41 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:41 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:41 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:41 --> Router Class Initialized
INFO - 2020-07-31 12:03:41 --> Output Class Initialized
INFO - 2020-07-31 12:03:41 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:41 --> Input Class Initialized
INFO - 2020-07-31 12:03:41 --> Language Class Initialized
INFO - 2020-07-31 12:03:41 --> Loader Class Initialized
INFO - 2020-07-31 12:03:41 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:41 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:41 --> Email Class Initialized
INFO - 2020-07-31 12:03:41 --> Controller Class Initialized
INFO - 2020-07-31 12:03:41 --> Model Class Initialized
INFO - 2020-07-31 12:03:41 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:41 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:41 --> Total execution time: 0.0231
INFO - 2020-07-31 12:03:43 --> Config Class Initialized
INFO - 2020-07-31 12:03:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:43 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:43 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:43 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:43 --> Router Class Initialized
INFO - 2020-07-31 12:03:43 --> Output Class Initialized
INFO - 2020-07-31 12:03:43 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:43 --> Input Class Initialized
INFO - 2020-07-31 12:03:43 --> Language Class Initialized
INFO - 2020-07-31 12:03:43 --> Loader Class Initialized
INFO - 2020-07-31 12:03:43 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:43 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:43 --> Email Class Initialized
INFO - 2020-07-31 12:03:43 --> Controller Class Initialized
INFO - 2020-07-31 12:03:43 --> Model Class Initialized
INFO - 2020-07-31 12:03:43 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:43 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:43 --> Total execution time: 0.0280
INFO - 2020-07-31 12:03:58 --> Config Class Initialized
INFO - 2020-07-31 12:03:58 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:58 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:58 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:58 --> URI Class Initialized
INFO - 2020-07-31 12:03:58 --> Router Class Initialized
INFO - 2020-07-31 12:03:58 --> Output Class Initialized
INFO - 2020-07-31 12:03:58 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:58 --> Input Class Initialized
INFO - 2020-07-31 12:03:58 --> Language Class Initialized
INFO - 2020-07-31 12:03:58 --> Loader Class Initialized
INFO - 2020-07-31 12:03:58 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:58 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:58 --> Email Class Initialized
INFO - 2020-07-31 12:03:58 --> Controller Class Initialized
INFO - 2020-07-31 12:03:58 --> Model Class Initialized
INFO - 2020-07-31 12:03:58 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:03:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:58 --> Model Class Initialized
INFO - 2020-07-31 12:03:58 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:58 --> Total execution time: 0.0235
INFO - 2020-07-31 12:03:59 --> Config Class Initialized
INFO - 2020-07-31 12:03:59 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:59 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:59 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:59 --> URI Class Initialized
INFO - 2020-07-31 12:03:59 --> Router Class Initialized
INFO - 2020-07-31 12:03:59 --> Output Class Initialized
INFO - 2020-07-31 12:03:59 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:59 --> Input Class Initialized
INFO - 2020-07-31 12:03:59 --> Language Class Initialized
INFO - 2020-07-31 12:03:59 --> Loader Class Initialized
INFO - 2020-07-31 12:03:59 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:59 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:59 --> Email Class Initialized
INFO - 2020-07-31 12:03:59 --> Controller Class Initialized
INFO - 2020-07-31 12:03:59 --> Model Class Initialized
INFO - 2020-07-31 12:03:59 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:59 --> Config Class Initialized
INFO - 2020-07-31 12:03:59 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:03:59 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:03:59 --> Utf8 Class Initialized
INFO - 2020-07-31 12:03:59 --> URI Class Initialized
DEBUG - 2020-07-31 12:03:59 --> No URI present. Default controller set.
INFO - 2020-07-31 12:03:59 --> Router Class Initialized
INFO - 2020-07-31 12:03:59 --> Output Class Initialized
INFO - 2020-07-31 12:03:59 --> Security Class Initialized
DEBUG - 2020-07-31 12:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:03:59 --> Input Class Initialized
INFO - 2020-07-31 12:03:59 --> Language Class Initialized
INFO - 2020-07-31 12:03:59 --> Loader Class Initialized
INFO - 2020-07-31 12:03:59 --> Helper loaded: url_helper
INFO - 2020-07-31 12:03:59 --> Database Driver Class Initialized
INFO - 2020-07-31 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:03:59 --> Email Class Initialized
INFO - 2020-07-31 12:03:59 --> Controller Class Initialized
INFO - 2020-07-31 12:03:59 --> Model Class Initialized
INFO - 2020-07-31 12:03:59 --> Model Class Initialized
DEBUG - 2020-07-31 12:03:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:03:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:03:59 --> Final output sent to browser
DEBUG - 2020-07-31 12:03:59 --> Total execution time: 0.0302
INFO - 2020-07-31 12:04:44 --> Config Class Initialized
INFO - 2020-07-31 12:04:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:04:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:04:44 --> Utf8 Class Initialized
INFO - 2020-07-31 12:04:44 --> URI Class Initialized
INFO - 2020-07-31 12:04:44 --> Router Class Initialized
INFO - 2020-07-31 12:04:44 --> Output Class Initialized
INFO - 2020-07-31 12:04:44 --> Security Class Initialized
DEBUG - 2020-07-31 12:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:04:44 --> Input Class Initialized
INFO - 2020-07-31 12:04:44 --> Language Class Initialized
INFO - 2020-07-31 12:04:44 --> Loader Class Initialized
INFO - 2020-07-31 12:04:44 --> Helper loaded: url_helper
INFO - 2020-07-31 12:04:44 --> Database Driver Class Initialized
INFO - 2020-07-31 12:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:04:44 --> Email Class Initialized
INFO - 2020-07-31 12:04:44 --> Controller Class Initialized
INFO - 2020-07-31 12:04:44 --> Model Class Initialized
INFO - 2020-07-31 12:04:44 --> Model Class Initialized
DEBUG - 2020-07-31 12:04:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:04:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:04:45 --> Config Class Initialized
INFO - 2020-07-31 12:04:45 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:04:45 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:04:45 --> Utf8 Class Initialized
INFO - 2020-07-31 12:04:45 --> URI Class Initialized
DEBUG - 2020-07-31 12:04:45 --> No URI present. Default controller set.
INFO - 2020-07-31 12:04:45 --> Router Class Initialized
INFO - 2020-07-31 12:04:45 --> Output Class Initialized
INFO - 2020-07-31 12:04:45 --> Security Class Initialized
DEBUG - 2020-07-31 12:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:04:45 --> Input Class Initialized
INFO - 2020-07-31 12:04:45 --> Language Class Initialized
INFO - 2020-07-31 12:04:45 --> Loader Class Initialized
INFO - 2020-07-31 12:04:45 --> Helper loaded: url_helper
INFO - 2020-07-31 12:04:45 --> Database Driver Class Initialized
INFO - 2020-07-31 12:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:04:45 --> Email Class Initialized
INFO - 2020-07-31 12:04:45 --> Controller Class Initialized
INFO - 2020-07-31 12:04:45 --> Model Class Initialized
INFO - 2020-07-31 12:04:45 --> Model Class Initialized
DEBUG - 2020-07-31 12:04:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:04:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:04:45 --> Final output sent to browser
DEBUG - 2020-07-31 12:04:45 --> Total execution time: 0.0197
INFO - 2020-07-31 12:05:14 --> Config Class Initialized
INFO - 2020-07-31 12:05:14 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:05:14 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:05:14 --> Utf8 Class Initialized
INFO - 2020-07-31 12:05:14 --> URI Class Initialized
DEBUG - 2020-07-31 12:05:14 --> No URI present. Default controller set.
INFO - 2020-07-31 12:05:14 --> Router Class Initialized
INFO - 2020-07-31 12:05:14 --> Output Class Initialized
INFO - 2020-07-31 12:05:14 --> Security Class Initialized
DEBUG - 2020-07-31 12:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:05:14 --> Input Class Initialized
INFO - 2020-07-31 12:05:14 --> Language Class Initialized
INFO - 2020-07-31 12:05:14 --> Loader Class Initialized
INFO - 2020-07-31 12:05:14 --> Helper loaded: url_helper
INFO - 2020-07-31 12:05:14 --> Database Driver Class Initialized
INFO - 2020-07-31 12:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:05:14 --> Email Class Initialized
INFO - 2020-07-31 12:05:14 --> Controller Class Initialized
INFO - 2020-07-31 12:05:14 --> Model Class Initialized
INFO - 2020-07-31 12:05:14 --> Model Class Initialized
DEBUG - 2020-07-31 12:05:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:05:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:05:14 --> Final output sent to browser
DEBUG - 2020-07-31 12:05:14 --> Total execution time: 0.0222
INFO - 2020-07-31 12:05:39 --> Config Class Initialized
INFO - 2020-07-31 12:05:39 --> Config Class Initialized
INFO - 2020-07-31 12:05:39 --> Hooks Class Initialized
INFO - 2020-07-31 12:05:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:05:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:05:39 --> Utf8 Class Initialized
DEBUG - 2020-07-31 12:05:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:05:39 --> Utf8 Class Initialized
INFO - 2020-07-31 12:05:39 --> URI Class Initialized
INFO - 2020-07-31 12:05:39 --> URI Class Initialized
INFO - 2020-07-31 12:05:39 --> Router Class Initialized
INFO - 2020-07-31 12:05:39 --> Router Class Initialized
INFO - 2020-07-31 12:05:39 --> Output Class Initialized
INFO - 2020-07-31 12:05:39 --> Output Class Initialized
INFO - 2020-07-31 12:05:39 --> Security Class Initialized
INFO - 2020-07-31 12:05:39 --> Security Class Initialized
DEBUG - 2020-07-31 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:05:39 --> Input Class Initialized
DEBUG - 2020-07-31 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:05:39 --> Input Class Initialized
INFO - 2020-07-31 12:05:39 --> Language Class Initialized
INFO - 2020-07-31 12:05:39 --> Language Class Initialized
INFO - 2020-07-31 12:05:39 --> Loader Class Initialized
INFO - 2020-07-31 12:05:39 --> Loader Class Initialized
INFO - 2020-07-31 12:05:39 --> Helper loaded: url_helper
INFO - 2020-07-31 12:05:39 --> Helper loaded: url_helper
INFO - 2020-07-31 12:05:39 --> Database Driver Class Initialized
INFO - 2020-07-31 12:05:39 --> Database Driver Class Initialized
INFO - 2020-07-31 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:05:39 --> Email Class Initialized
INFO - 2020-07-31 12:05:39 --> Controller Class Initialized
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
DEBUG - 2020-07-31 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:05:39 --> Email Class Initialized
INFO - 2020-07-31 12:05:39 --> Controller Class Initialized
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
DEBUG - 2020-07-31 12:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:05:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
INFO - 2020-07-31 12:05:39 --> Final output sent to browser
DEBUG - 2020-07-31 12:05:39 --> Total execution time: 0.0304
INFO - 2020-07-31 12:05:39 --> Config Class Initialized
INFO - 2020-07-31 12:05:39 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:05:39 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:05:39 --> Utf8 Class Initialized
INFO - 2020-07-31 12:05:39 --> URI Class Initialized
DEBUG - 2020-07-31 12:05:39 --> No URI present. Default controller set.
INFO - 2020-07-31 12:05:39 --> Router Class Initialized
INFO - 2020-07-31 12:05:39 --> Output Class Initialized
INFO - 2020-07-31 12:05:39 --> Security Class Initialized
DEBUG - 2020-07-31 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:05:39 --> Input Class Initialized
INFO - 2020-07-31 12:05:39 --> Language Class Initialized
INFO - 2020-07-31 12:05:39 --> Loader Class Initialized
INFO - 2020-07-31 12:05:39 --> Helper loaded: url_helper
INFO - 2020-07-31 12:05:39 --> Database Driver Class Initialized
INFO - 2020-07-31 12:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:05:39 --> Email Class Initialized
INFO - 2020-07-31 12:05:39 --> Controller Class Initialized
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
INFO - 2020-07-31 12:05:39 --> Model Class Initialized
DEBUG - 2020-07-31 12:05:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:05:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:05:39 --> Final output sent to browser
DEBUG - 2020-07-31 12:05:39 --> Total execution time: 0.0227
INFO - 2020-07-31 12:06:50 --> Config Class Initialized
INFO - 2020-07-31 12:06:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:06:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:06:50 --> Utf8 Class Initialized
INFO - 2020-07-31 12:06:50 --> URI Class Initialized
INFO - 2020-07-31 12:06:50 --> Router Class Initialized
INFO - 2020-07-31 12:06:50 --> Output Class Initialized
INFO - 2020-07-31 12:06:50 --> Security Class Initialized
DEBUG - 2020-07-31 12:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:06:50 --> Input Class Initialized
INFO - 2020-07-31 12:06:50 --> Language Class Initialized
INFO - 2020-07-31 12:06:50 --> Loader Class Initialized
INFO - 2020-07-31 12:06:50 --> Helper loaded: url_helper
INFO - 2020-07-31 12:06:50 --> Database Driver Class Initialized
INFO - 2020-07-31 12:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:06:50 --> Email Class Initialized
INFO - 2020-07-31 12:06:50 --> Controller Class Initialized
INFO - 2020-07-31 12:06:50 --> Model Class Initialized
INFO - 2020-07-31 12:06:50 --> Model Class Initialized
DEBUG - 2020-07-31 12:06:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:06:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:06:50 --> Model Class Initialized
INFO - 2020-07-31 12:06:50 --> Final output sent to browser
DEBUG - 2020-07-31 12:06:50 --> Total execution time: 0.0257
INFO - 2020-07-31 12:07:43 --> Config Class Initialized
INFO - 2020-07-31 12:07:43 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:07:43 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:07:43 --> Utf8 Class Initialized
INFO - 2020-07-31 12:07:43 --> URI Class Initialized
DEBUG - 2020-07-31 12:07:43 --> No URI present. Default controller set.
INFO - 2020-07-31 12:07:43 --> Router Class Initialized
INFO - 2020-07-31 12:07:43 --> Output Class Initialized
INFO - 2020-07-31 12:07:43 --> Security Class Initialized
DEBUG - 2020-07-31 12:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:07:43 --> Input Class Initialized
INFO - 2020-07-31 12:07:43 --> Language Class Initialized
INFO - 2020-07-31 12:07:43 --> Loader Class Initialized
INFO - 2020-07-31 12:07:43 --> Helper loaded: url_helper
INFO - 2020-07-31 12:07:43 --> Database Driver Class Initialized
INFO - 2020-07-31 12:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:07:43 --> Email Class Initialized
INFO - 2020-07-31 12:07:43 --> Controller Class Initialized
INFO - 2020-07-31 12:07:43 --> Model Class Initialized
INFO - 2020-07-31 12:07:43 --> Model Class Initialized
DEBUG - 2020-07-31 12:07:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:07:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:07:43 --> Final output sent to browser
DEBUG - 2020-07-31 12:07:43 --> Total execution time: 0.0772
INFO - 2020-07-31 12:07:51 --> Config Class Initialized
INFO - 2020-07-31 12:07:51 --> Config Class Initialized
INFO - 2020-07-31 12:07:51 --> Hooks Class Initialized
INFO - 2020-07-31 12:07:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:07:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:07:51 --> Utf8 Class Initialized
DEBUG - 2020-07-31 12:07:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:07:51 --> Utf8 Class Initialized
INFO - 2020-07-31 12:07:51 --> URI Class Initialized
INFO - 2020-07-31 12:07:51 --> URI Class Initialized
INFO - 2020-07-31 12:07:51 --> Router Class Initialized
INFO - 2020-07-31 12:07:51 --> Router Class Initialized
INFO - 2020-07-31 12:07:51 --> Output Class Initialized
INFO - 2020-07-31 12:07:51 --> Output Class Initialized
INFO - 2020-07-31 12:07:51 --> Security Class Initialized
INFO - 2020-07-31 12:07:51 --> Security Class Initialized
DEBUG - 2020-07-31 12:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:07:51 --> Input Class Initialized
DEBUG - 2020-07-31 12:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:07:51 --> Input Class Initialized
INFO - 2020-07-31 12:07:51 --> Language Class Initialized
INFO - 2020-07-31 12:07:51 --> Language Class Initialized
INFO - 2020-07-31 12:07:51 --> Loader Class Initialized
INFO - 2020-07-31 12:07:51 --> Loader Class Initialized
INFO - 2020-07-31 12:07:51 --> Helper loaded: url_helper
INFO - 2020-07-31 12:07:51 --> Helper loaded: url_helper
INFO - 2020-07-31 12:07:51 --> Database Driver Class Initialized
INFO - 2020-07-31 12:07:51 --> Database Driver Class Initialized
INFO - 2020-07-31 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:07:51 --> Email Class Initialized
INFO - 2020-07-31 12:07:51 --> Controller Class Initialized
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
DEBUG - 2020-07-31 12:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:07:51 --> Email Class Initialized
INFO - 2020-07-31 12:07:51 --> Controller Class Initialized
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
DEBUG - 2020-07-31 12:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:07:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
INFO - 2020-07-31 12:07:51 --> Final output sent to browser
DEBUG - 2020-07-31 12:07:51 --> Total execution time: 0.0336
INFO - 2020-07-31 12:07:51 --> Config Class Initialized
INFO - 2020-07-31 12:07:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:07:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:07:51 --> Utf8 Class Initialized
INFO - 2020-07-31 12:07:51 --> URI Class Initialized
DEBUG - 2020-07-31 12:07:51 --> No URI present. Default controller set.
INFO - 2020-07-31 12:07:51 --> Router Class Initialized
INFO - 2020-07-31 12:07:51 --> Output Class Initialized
INFO - 2020-07-31 12:07:51 --> Security Class Initialized
DEBUG - 2020-07-31 12:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:07:51 --> Input Class Initialized
INFO - 2020-07-31 12:07:51 --> Language Class Initialized
INFO - 2020-07-31 12:07:51 --> Loader Class Initialized
INFO - 2020-07-31 12:07:51 --> Helper loaded: url_helper
INFO - 2020-07-31 12:07:51 --> Database Driver Class Initialized
INFO - 2020-07-31 12:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:07:51 --> Email Class Initialized
INFO - 2020-07-31 12:07:51 --> Controller Class Initialized
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
INFO - 2020-07-31 12:07:51 --> Model Class Initialized
DEBUG - 2020-07-31 12:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:07:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:07:51 --> Final output sent to browser
DEBUG - 2020-07-31 12:07:51 --> Total execution time: 0.0227
INFO - 2020-07-31 12:08:09 --> Config Class Initialized
INFO - 2020-07-31 12:08:09 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:08:09 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:08:09 --> Utf8 Class Initialized
INFO - 2020-07-31 12:08:09 --> URI Class Initialized
INFO - 2020-07-31 12:08:09 --> Router Class Initialized
INFO - 2020-07-31 12:08:09 --> Output Class Initialized
INFO - 2020-07-31 12:08:09 --> Security Class Initialized
DEBUG - 2020-07-31 12:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:08:09 --> Input Class Initialized
INFO - 2020-07-31 12:08:09 --> Language Class Initialized
INFO - 2020-07-31 12:08:09 --> Loader Class Initialized
INFO - 2020-07-31 12:08:09 --> Helper loaded: url_helper
INFO - 2020-07-31 12:08:09 --> Database Driver Class Initialized
INFO - 2020-07-31 12:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:08:09 --> Email Class Initialized
INFO - 2020-07-31 12:08:09 --> Controller Class Initialized
INFO - 2020-07-31 12:08:09 --> Model Class Initialized
INFO - 2020-07-31 12:08:09 --> Model Class Initialized
DEBUG - 2020-07-31 12:08:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:08:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:08:09 --> Model Class Initialized
INFO - 2020-07-31 12:08:09 --> Final output sent to browser
DEBUG - 2020-07-31 12:08:09 --> Total execution time: 0.0289
INFO - 2020-07-31 12:08:10 --> Config Class Initialized
INFO - 2020-07-31 12:08:10 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:08:10 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:08:10 --> Utf8 Class Initialized
INFO - 2020-07-31 12:08:10 --> URI Class Initialized
INFO - 2020-07-31 12:08:10 --> Router Class Initialized
INFO - 2020-07-31 12:08:10 --> Output Class Initialized
INFO - 2020-07-31 12:08:10 --> Security Class Initialized
DEBUG - 2020-07-31 12:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:08:10 --> Input Class Initialized
INFO - 2020-07-31 12:08:10 --> Language Class Initialized
INFO - 2020-07-31 12:08:10 --> Loader Class Initialized
INFO - 2020-07-31 12:08:10 --> Helper loaded: url_helper
INFO - 2020-07-31 12:08:10 --> Database Driver Class Initialized
INFO - 2020-07-31 12:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:08:10 --> Email Class Initialized
INFO - 2020-07-31 12:08:10 --> Controller Class Initialized
INFO - 2020-07-31 12:08:10 --> Model Class Initialized
INFO - 2020-07-31 12:08:10 --> Model Class Initialized
DEBUG - 2020-07-31 12:08:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:08:10 --> Config Class Initialized
INFO - 2020-07-31 12:08:10 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:08:10 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:08:10 --> Utf8 Class Initialized
INFO - 2020-07-31 12:08:10 --> URI Class Initialized
INFO - 2020-07-31 12:08:10 --> Router Class Initialized
INFO - 2020-07-31 12:08:10 --> Output Class Initialized
INFO - 2020-07-31 12:08:10 --> Security Class Initialized
DEBUG - 2020-07-31 12:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:08:10 --> Input Class Initialized
INFO - 2020-07-31 12:08:10 --> Language Class Initialized
INFO - 2020-07-31 12:08:10 --> Loader Class Initialized
INFO - 2020-07-31 12:08:10 --> Helper loaded: url_helper
INFO - 2020-07-31 12:08:10 --> Database Driver Class Initialized
INFO - 2020-07-31 12:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:08:10 --> Email Class Initialized
INFO - 2020-07-31 12:08:10 --> Controller Class Initialized
DEBUG - 2020-07-31 12:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:08:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:08:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 12:08:10 --> Final output sent to browser
DEBUG - 2020-07-31 12:08:10 --> Total execution time: 0.0217
INFO - 2020-07-31 12:08:17 --> Config Class Initialized
INFO - 2020-07-31 12:08:17 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:08:17 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:08:17 --> Utf8 Class Initialized
INFO - 2020-07-31 12:08:17 --> URI Class Initialized
DEBUG - 2020-07-31 12:08:17 --> No URI present. Default controller set.
INFO - 2020-07-31 12:08:17 --> Router Class Initialized
INFO - 2020-07-31 12:08:17 --> Output Class Initialized
INFO - 2020-07-31 12:08:17 --> Security Class Initialized
DEBUG - 2020-07-31 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:08:17 --> Input Class Initialized
INFO - 2020-07-31 12:08:17 --> Language Class Initialized
INFO - 2020-07-31 12:08:17 --> Loader Class Initialized
INFO - 2020-07-31 12:08:17 --> Helper loaded: url_helper
INFO - 2020-07-31 12:08:17 --> Database Driver Class Initialized
INFO - 2020-07-31 12:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:08:17 --> Email Class Initialized
INFO - 2020-07-31 12:08:17 --> Controller Class Initialized
INFO - 2020-07-31 12:08:17 --> Model Class Initialized
INFO - 2020-07-31 12:08:17 --> Model Class Initialized
DEBUG - 2020-07-31 12:08:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:08:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:08:17 --> Final output sent to browser
DEBUG - 2020-07-31 12:08:17 --> Total execution time: 0.0200
INFO - 2020-07-31 12:14:19 --> Config Class Initialized
INFO - 2020-07-31 12:14:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:19 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:19 --> URI Class Initialized
INFO - 2020-07-31 12:14:19 --> Config Class Initialized
INFO - 2020-07-31 12:14:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:19 --> No URI present. Default controller set.
INFO - 2020-07-31 12:14:19 --> Router Class Initialized
INFO - 2020-07-31 12:14:19 --> Output Class Initialized
DEBUG - 2020-07-31 12:14:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:19 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:19 --> Security Class Initialized
INFO - 2020-07-31 12:14:19 --> URI Class Initialized
DEBUG - 2020-07-31 12:14:19 --> No URI present. Default controller set.
INFO - 2020-07-31 12:14:19 --> Router Class Initialized
DEBUG - 2020-07-31 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:19 --> Input Class Initialized
INFO - 2020-07-31 12:14:19 --> Language Class Initialized
INFO - 2020-07-31 12:14:19 --> Output Class Initialized
INFO - 2020-07-31 12:14:19 --> Loader Class Initialized
INFO - 2020-07-31 12:14:19 --> Security Class Initialized
INFO - 2020-07-31 12:14:19 --> Helper loaded: url_helper
DEBUG - 2020-07-31 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:19 --> Input Class Initialized
INFO - 2020-07-31 12:14:19 --> Language Class Initialized
INFO - 2020-07-31 12:14:19 --> Loader Class Initialized
INFO - 2020-07-31 12:14:19 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:19 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:19 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:19 --> Email Class Initialized
INFO - 2020-07-31 12:14:19 --> Controller Class Initialized
INFO - 2020-07-31 12:14:19 --> Model Class Initialized
INFO - 2020-07-31 12:14:19 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:14:19 --> Final output sent to browser
DEBUG - 2020-07-31 12:14:19 --> Total execution time: 0.0370
INFO - 2020-07-31 12:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:19 --> Email Class Initialized
INFO - 2020-07-31 12:14:19 --> Controller Class Initialized
INFO - 2020-07-31 12:14:19 --> Model Class Initialized
INFO - 2020-07-31 12:14:19 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:14:19 --> Final output sent to browser
DEBUG - 2020-07-31 12:14:19 --> Total execution time: 0.0415
INFO - 2020-07-31 12:14:44 --> Config Class Initialized
INFO - 2020-07-31 12:14:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:44 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:44 --> URI Class Initialized
INFO - 2020-07-31 12:14:44 --> Router Class Initialized
INFO - 2020-07-31 12:14:44 --> Output Class Initialized
INFO - 2020-07-31 12:14:44 --> Security Class Initialized
DEBUG - 2020-07-31 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:44 --> Input Class Initialized
INFO - 2020-07-31 12:14:44 --> Language Class Initialized
INFO - 2020-07-31 12:14:44 --> Loader Class Initialized
INFO - 2020-07-31 12:14:44 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:44 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:44 --> Email Class Initialized
INFO - 2020-07-31 12:14:44 --> Controller Class Initialized
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:44 --> Config Class Initialized
INFO - 2020-07-31 12:14:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:44 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:44 --> URI Class Initialized
INFO - 2020-07-31 12:14:44 --> Router Class Initialized
INFO - 2020-07-31 12:14:44 --> Output Class Initialized
INFO - 2020-07-31 12:14:44 --> Security Class Initialized
DEBUG - 2020-07-31 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:44 --> Input Class Initialized
INFO - 2020-07-31 12:14:44 --> Language Class Initialized
INFO - 2020-07-31 12:14:44 --> Loader Class Initialized
INFO - 2020-07-31 12:14:44 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:44 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:44 --> Email Class Initialized
INFO - 2020-07-31 12:14:44 --> Controller Class Initialized
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:14:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
INFO - 2020-07-31 12:14:44 --> Final output sent to browser
DEBUG - 2020-07-31 12:14:44 --> Total execution time: 0.0227
INFO - 2020-07-31 12:14:44 --> Config Class Initialized
INFO - 2020-07-31 12:14:44 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:44 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:44 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:44 --> URI Class Initialized
DEBUG - 2020-07-31 12:14:44 --> No URI present. Default controller set.
INFO - 2020-07-31 12:14:44 --> Router Class Initialized
INFO - 2020-07-31 12:14:44 --> Output Class Initialized
INFO - 2020-07-31 12:14:44 --> Security Class Initialized
DEBUG - 2020-07-31 12:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:44 --> Input Class Initialized
INFO - 2020-07-31 12:14:44 --> Language Class Initialized
INFO - 2020-07-31 12:14:44 --> Loader Class Initialized
INFO - 2020-07-31 12:14:44 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:44 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:44 --> Email Class Initialized
INFO - 2020-07-31 12:14:44 --> Controller Class Initialized
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
INFO - 2020-07-31 12:14:44 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:14:44 --> Final output sent to browser
DEBUG - 2020-07-31 12:14:44 --> Total execution time: 0.0225
INFO - 2020-07-31 12:14:50 --> Config Class Initialized
INFO - 2020-07-31 12:14:50 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:50 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:50 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:50 --> URI Class Initialized
INFO - 2020-07-31 12:14:50 --> Router Class Initialized
INFO - 2020-07-31 12:14:50 --> Output Class Initialized
INFO - 2020-07-31 12:14:50 --> Security Class Initialized
DEBUG - 2020-07-31 12:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:50 --> Input Class Initialized
INFO - 2020-07-31 12:14:50 --> Language Class Initialized
INFO - 2020-07-31 12:14:50 --> Loader Class Initialized
INFO - 2020-07-31 12:14:50 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:50 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:50 --> Email Class Initialized
INFO - 2020-07-31 12:14:50 --> Controller Class Initialized
INFO - 2020-07-31 12:14:50 --> Model Class Initialized
INFO - 2020-07-31 12:14:50 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:14:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:50 --> Model Class Initialized
INFO - 2020-07-31 12:14:50 --> Final output sent to browser
DEBUG - 2020-07-31 12:14:50 --> Total execution time: 0.0264
INFO - 2020-07-31 12:14:51 --> Config Class Initialized
INFO - 2020-07-31 12:14:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:51 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:51 --> URI Class Initialized
INFO - 2020-07-31 12:14:51 --> Router Class Initialized
INFO - 2020-07-31 12:14:51 --> Output Class Initialized
INFO - 2020-07-31 12:14:51 --> Security Class Initialized
DEBUG - 2020-07-31 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:51 --> Input Class Initialized
INFO - 2020-07-31 12:14:51 --> Language Class Initialized
INFO - 2020-07-31 12:14:51 --> Loader Class Initialized
INFO - 2020-07-31 12:14:51 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:51 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:51 --> Email Class Initialized
INFO - 2020-07-31 12:14:51 --> Controller Class Initialized
INFO - 2020-07-31 12:14:51 --> Model Class Initialized
INFO - 2020-07-31 12:14:51 --> Model Class Initialized
DEBUG - 2020-07-31 12:14:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:51 --> Config Class Initialized
INFO - 2020-07-31 12:14:51 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:14:51 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:14:51 --> Utf8 Class Initialized
INFO - 2020-07-31 12:14:51 --> URI Class Initialized
INFO - 2020-07-31 12:14:51 --> Router Class Initialized
INFO - 2020-07-31 12:14:51 --> Output Class Initialized
INFO - 2020-07-31 12:14:51 --> Security Class Initialized
DEBUG - 2020-07-31 12:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:14:51 --> Input Class Initialized
INFO - 2020-07-31 12:14:51 --> Language Class Initialized
INFO - 2020-07-31 12:14:51 --> Loader Class Initialized
INFO - 2020-07-31 12:14:51 --> Helper loaded: url_helper
INFO - 2020-07-31 12:14:51 --> Database Driver Class Initialized
INFO - 2020-07-31 12:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:14:51 --> Email Class Initialized
INFO - 2020-07-31 12:14:51 --> Controller Class Initialized
DEBUG - 2020-07-31 12:14:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:14:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:14:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 12:14:51 --> Final output sent to browser
DEBUG - 2020-07-31 12:14:51 --> Total execution time: 0.0217
INFO - 2020-07-31 12:26:10 --> Config Class Initialized
INFO - 2020-07-31 12:26:10 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:26:10 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:26:10 --> Utf8 Class Initialized
INFO - 2020-07-31 12:26:10 --> URI Class Initialized
DEBUG - 2020-07-31 12:26:10 --> No URI present. Default controller set.
INFO - 2020-07-31 12:26:10 --> Router Class Initialized
INFO - 2020-07-31 12:26:10 --> Output Class Initialized
INFO - 2020-07-31 12:26:10 --> Security Class Initialized
DEBUG - 2020-07-31 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:26:10 --> Input Class Initialized
INFO - 2020-07-31 12:26:10 --> Language Class Initialized
INFO - 2020-07-31 12:26:10 --> Loader Class Initialized
INFO - 2020-07-31 12:26:10 --> Helper loaded: url_helper
INFO - 2020-07-31 12:26:10 --> Database Driver Class Initialized
INFO - 2020-07-31 12:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:26:10 --> Email Class Initialized
INFO - 2020-07-31 12:26:10 --> Controller Class Initialized
INFO - 2020-07-31 12:26:10 --> Model Class Initialized
INFO - 2020-07-31 12:26:10 --> Model Class Initialized
DEBUG - 2020-07-31 12:26:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:26:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:26:10 --> Final output sent to browser
DEBUG - 2020-07-31 12:26:10 --> Total execution time: 0.0250
INFO - 2020-07-31 12:26:19 --> Config Class Initialized
INFO - 2020-07-31 12:26:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:26:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:26:19 --> Utf8 Class Initialized
INFO - 2020-07-31 12:26:19 --> URI Class Initialized
INFO - 2020-07-31 12:26:19 --> Router Class Initialized
INFO - 2020-07-31 12:26:19 --> Output Class Initialized
INFO - 2020-07-31 12:26:19 --> Security Class Initialized
DEBUG - 2020-07-31 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:26:19 --> Input Class Initialized
INFO - 2020-07-31 12:26:19 --> Language Class Initialized
INFO - 2020-07-31 12:26:19 --> Loader Class Initialized
INFO - 2020-07-31 12:26:19 --> Helper loaded: url_helper
INFO - 2020-07-31 12:26:19 --> Database Driver Class Initialized
INFO - 2020-07-31 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:26:19 --> Email Class Initialized
INFO - 2020-07-31 12:26:19 --> Controller Class Initialized
INFO - 2020-07-31 12:26:19 --> Model Class Initialized
INFO - 2020-07-31 12:26:19 --> Model Class Initialized
DEBUG - 2020-07-31 12:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:26:19 --> Config Class Initialized
INFO - 2020-07-31 12:26:19 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:26:19 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:26:19 --> Utf8 Class Initialized
INFO - 2020-07-31 12:26:19 --> URI Class Initialized
DEBUG - 2020-07-31 12:26:19 --> No URI present. Default controller set.
INFO - 2020-07-31 12:26:19 --> Router Class Initialized
INFO - 2020-07-31 12:26:19 --> Output Class Initialized
INFO - 2020-07-31 12:26:19 --> Security Class Initialized
DEBUG - 2020-07-31 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:26:19 --> Input Class Initialized
INFO - 2020-07-31 12:26:19 --> Language Class Initialized
INFO - 2020-07-31 12:26:19 --> Loader Class Initialized
INFO - 2020-07-31 12:26:19 --> Helper loaded: url_helper
INFO - 2020-07-31 12:26:19 --> Database Driver Class Initialized
INFO - 2020-07-31 12:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:26:19 --> Email Class Initialized
INFO - 2020-07-31 12:26:19 --> Controller Class Initialized
INFO - 2020-07-31 12:26:19 --> Model Class Initialized
INFO - 2020-07-31 12:26:19 --> Model Class Initialized
DEBUG - 2020-07-31 12:26:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:26:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:26:19 --> Final output sent to browser
DEBUG - 2020-07-31 12:26:19 --> Total execution time: 0.0226
INFO - 2020-07-31 12:27:08 --> Config Class Initialized
INFO - 2020-07-31 12:27:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:27:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:27:08 --> Utf8 Class Initialized
INFO - 2020-07-31 12:27:08 --> URI Class Initialized
INFO - 2020-07-31 12:27:08 --> Router Class Initialized
INFO - 2020-07-31 12:27:08 --> Output Class Initialized
INFO - 2020-07-31 12:27:08 --> Security Class Initialized
DEBUG - 2020-07-31 12:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:27:08 --> Input Class Initialized
INFO - 2020-07-31 12:27:08 --> Language Class Initialized
INFO - 2020-07-31 12:27:08 --> Loader Class Initialized
INFO - 2020-07-31 12:27:08 --> Helper loaded: url_helper
INFO - 2020-07-31 12:27:08 --> Database Driver Class Initialized
INFO - 2020-07-31 12:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:27:08 --> Email Class Initialized
INFO - 2020-07-31 12:27:08 --> Controller Class Initialized
INFO - 2020-07-31 12:27:08 --> Model Class Initialized
INFO - 2020-07-31 12:27:08 --> Model Class Initialized
DEBUG - 2020-07-31 12:27:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:27:08 --> Config Class Initialized
INFO - 2020-07-31 12:27:08 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:27:08 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:27:08 --> Utf8 Class Initialized
INFO - 2020-07-31 12:27:08 --> URI Class Initialized
INFO - 2020-07-31 12:27:08 --> Router Class Initialized
INFO - 2020-07-31 12:27:08 --> Output Class Initialized
INFO - 2020-07-31 12:27:08 --> Security Class Initialized
DEBUG - 2020-07-31 12:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:27:08 --> Input Class Initialized
INFO - 2020-07-31 12:27:08 --> Language Class Initialized
INFO - 2020-07-31 12:27:08 --> Loader Class Initialized
INFO - 2020-07-31 12:27:08 --> Helper loaded: url_helper
INFO - 2020-07-31 12:27:08 --> Database Driver Class Initialized
INFO - 2020-07-31 12:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:27:08 --> Email Class Initialized
INFO - 2020-07-31 12:27:08 --> Controller Class Initialized
DEBUG - 2020-07-31 12:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:27:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-31 12:27:08 --> Final output sent to browser
DEBUG - 2020-07-31 12:27:08 --> Total execution time: 0.0265
INFO - 2020-07-31 12:27:15 --> Config Class Initialized
INFO - 2020-07-31 12:27:15 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:27:15 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:27:15 --> Utf8 Class Initialized
INFO - 2020-07-31 12:27:15 --> URI Class Initialized
DEBUG - 2020-07-31 12:27:15 --> No URI present. Default controller set.
INFO - 2020-07-31 12:27:15 --> Router Class Initialized
INFO - 2020-07-31 12:27:15 --> Output Class Initialized
INFO - 2020-07-31 12:27:15 --> Security Class Initialized
DEBUG - 2020-07-31 12:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:27:15 --> Input Class Initialized
INFO - 2020-07-31 12:27:15 --> Language Class Initialized
INFO - 2020-07-31 12:27:15 --> Loader Class Initialized
INFO - 2020-07-31 12:27:15 --> Helper loaded: url_helper
INFO - 2020-07-31 12:27:15 --> Database Driver Class Initialized
INFO - 2020-07-31 12:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:27:15 --> Email Class Initialized
INFO - 2020-07-31 12:27:15 --> Controller Class Initialized
INFO - 2020-07-31 12:27:15 --> Model Class Initialized
INFO - 2020-07-31 12:27:15 --> Model Class Initialized
DEBUG - 2020-07-31 12:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:27:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:27:15 --> Final output sent to browser
DEBUG - 2020-07-31 12:27:15 --> Total execution time: 0.0247
INFO - 2020-07-31 12:43:28 --> Config Class Initialized
INFO - 2020-07-31 12:43:28 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:43:28 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:43:28 --> Utf8 Class Initialized
INFO - 2020-07-31 12:43:28 --> URI Class Initialized
INFO - 2020-07-31 12:43:28 --> Router Class Initialized
INFO - 2020-07-31 12:43:28 --> Output Class Initialized
INFO - 2020-07-31 12:43:28 --> Security Class Initialized
DEBUG - 2020-07-31 12:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:43:28 --> Input Class Initialized
INFO - 2020-07-31 12:43:28 --> Language Class Initialized
INFO - 2020-07-31 12:43:28 --> Loader Class Initialized
INFO - 2020-07-31 12:43:28 --> Helper loaded: url_helper
INFO - 2020-07-31 12:43:28 --> Database Driver Class Initialized
INFO - 2020-07-31 12:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:43:28 --> Email Class Initialized
INFO - 2020-07-31 12:43:28 --> Controller Class Initialized
INFO - 2020-07-31 12:43:28 --> Model Class Initialized
INFO - 2020-07-31 12:43:28 --> Model Class Initialized
DEBUG - 2020-07-31 12:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 12:43:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:43:30 --> Config Class Initialized
INFO - 2020-07-31 12:43:30 --> Hooks Class Initialized
DEBUG - 2020-07-31 12:43:30 --> UTF-8 Support Enabled
INFO - 2020-07-31 12:43:30 --> Utf8 Class Initialized
INFO - 2020-07-31 12:43:30 --> URI Class Initialized
DEBUG - 2020-07-31 12:43:30 --> No URI present. Default controller set.
INFO - 2020-07-31 12:43:30 --> Router Class Initialized
INFO - 2020-07-31 12:43:30 --> Output Class Initialized
INFO - 2020-07-31 12:43:30 --> Security Class Initialized
DEBUG - 2020-07-31 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 12:43:30 --> Input Class Initialized
INFO - 2020-07-31 12:43:30 --> Language Class Initialized
INFO - 2020-07-31 12:43:30 --> Loader Class Initialized
INFO - 2020-07-31 12:43:30 --> Helper loaded: url_helper
INFO - 2020-07-31 12:43:30 --> Database Driver Class Initialized
INFO - 2020-07-31 12:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 12:43:30 --> Email Class Initialized
INFO - 2020-07-31 12:43:30 --> Controller Class Initialized
INFO - 2020-07-31 12:43:30 --> Model Class Initialized
INFO - 2020-07-31 12:43:30 --> Model Class Initialized
DEBUG - 2020-07-31 12:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 12:43:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 12:43:30 --> Final output sent to browser
DEBUG - 2020-07-31 12:43:30 --> Total execution time: 0.0228
INFO - 2020-07-31 13:10:32 --> Config Class Initialized
INFO - 2020-07-31 13:10:32 --> Hooks Class Initialized
DEBUG - 2020-07-31 13:10:32 --> UTF-8 Support Enabled
INFO - 2020-07-31 13:10:32 --> Utf8 Class Initialized
INFO - 2020-07-31 13:10:32 --> URI Class Initialized
INFO - 2020-07-31 13:10:32 --> Router Class Initialized
INFO - 2020-07-31 13:10:32 --> Output Class Initialized
INFO - 2020-07-31 13:10:32 --> Security Class Initialized
DEBUG - 2020-07-31 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 13:10:32 --> Input Class Initialized
INFO - 2020-07-31 13:10:32 --> Language Class Initialized
INFO - 2020-07-31 13:10:32 --> Loader Class Initialized
INFO - 2020-07-31 13:10:32 --> Helper loaded: url_helper
INFO - 2020-07-31 13:10:32 --> Database Driver Class Initialized
INFO - 2020-07-31 13:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 13:10:32 --> Email Class Initialized
INFO - 2020-07-31 13:10:32 --> Controller Class Initialized
INFO - 2020-07-31 13:10:32 --> Model Class Initialized
INFO - 2020-07-31 13:10:32 --> Model Class Initialized
DEBUG - 2020-07-31 13:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 13:10:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 13:10:33 --> Config Class Initialized
INFO - 2020-07-31 13:10:33 --> Hooks Class Initialized
DEBUG - 2020-07-31 13:10:33 --> UTF-8 Support Enabled
INFO - 2020-07-31 13:10:33 --> Utf8 Class Initialized
INFO - 2020-07-31 13:10:33 --> URI Class Initialized
DEBUG - 2020-07-31 13:10:33 --> No URI present. Default controller set.
INFO - 2020-07-31 13:10:33 --> Router Class Initialized
INFO - 2020-07-31 13:10:33 --> Output Class Initialized
INFO - 2020-07-31 13:10:33 --> Security Class Initialized
DEBUG - 2020-07-31 13:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 13:10:33 --> Input Class Initialized
INFO - 2020-07-31 13:10:33 --> Language Class Initialized
INFO - 2020-07-31 13:10:33 --> Loader Class Initialized
INFO - 2020-07-31 13:10:33 --> Helper loaded: url_helper
INFO - 2020-07-31 13:10:33 --> Database Driver Class Initialized
INFO - 2020-07-31 13:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 13:10:33 --> Email Class Initialized
INFO - 2020-07-31 13:10:33 --> Controller Class Initialized
INFO - 2020-07-31 13:10:33 --> Model Class Initialized
INFO - 2020-07-31 13:10:33 --> Model Class Initialized
DEBUG - 2020-07-31 13:10:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 13:10:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 13:10:33 --> Final output sent to browser
DEBUG - 2020-07-31 13:10:33 --> Total execution time: 0.0237
INFO - 2020-07-31 16:52:34 --> Config Class Initialized
INFO - 2020-07-31 16:52:34 --> Hooks Class Initialized
DEBUG - 2020-07-31 16:52:34 --> UTF-8 Support Enabled
INFO - 2020-07-31 16:52:34 --> Utf8 Class Initialized
INFO - 2020-07-31 16:52:34 --> URI Class Initialized
INFO - 2020-07-31 16:52:34 --> Router Class Initialized
INFO - 2020-07-31 16:52:34 --> Output Class Initialized
INFO - 2020-07-31 16:52:34 --> Security Class Initialized
DEBUG - 2020-07-31 16:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 16:52:34 --> Input Class Initialized
INFO - 2020-07-31 16:52:34 --> Language Class Initialized
INFO - 2020-07-31 16:52:34 --> Loader Class Initialized
INFO - 2020-07-31 16:52:34 --> Helper loaded: url_helper
INFO - 2020-07-31 16:52:34 --> Database Driver Class Initialized
INFO - 2020-07-31 16:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 16:52:34 --> Email Class Initialized
INFO - 2020-07-31 16:52:34 --> Controller Class Initialized
INFO - 2020-07-31 16:52:34 --> Model Class Initialized
INFO - 2020-07-31 16:52:34 --> Model Class Initialized
DEBUG - 2020-07-31 16:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 16:52:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 16:52:35 --> Config Class Initialized
INFO - 2020-07-31 16:52:35 --> Hooks Class Initialized
DEBUG - 2020-07-31 16:52:35 --> UTF-8 Support Enabled
INFO - 2020-07-31 16:52:35 --> Utf8 Class Initialized
INFO - 2020-07-31 16:52:35 --> URI Class Initialized
DEBUG - 2020-07-31 16:52:35 --> No URI present. Default controller set.
INFO - 2020-07-31 16:52:35 --> Router Class Initialized
INFO - 2020-07-31 16:52:35 --> Output Class Initialized
INFO - 2020-07-31 16:52:35 --> Security Class Initialized
DEBUG - 2020-07-31 16:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 16:52:35 --> Input Class Initialized
INFO - 2020-07-31 16:52:35 --> Language Class Initialized
INFO - 2020-07-31 16:52:35 --> Loader Class Initialized
INFO - 2020-07-31 16:52:35 --> Helper loaded: url_helper
INFO - 2020-07-31 16:52:35 --> Database Driver Class Initialized
INFO - 2020-07-31 16:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 16:52:35 --> Email Class Initialized
INFO - 2020-07-31 16:52:35 --> Controller Class Initialized
INFO - 2020-07-31 16:52:35 --> Model Class Initialized
INFO - 2020-07-31 16:52:35 --> Model Class Initialized
DEBUG - 2020-07-31 16:52:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 16:52:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 16:52:35 --> Final output sent to browser
DEBUG - 2020-07-31 16:52:35 --> Total execution time: 0.0238
INFO - 2020-07-31 17:03:22 --> Config Class Initialized
INFO - 2020-07-31 17:03:22 --> Hooks Class Initialized
DEBUG - 2020-07-31 17:03:22 --> UTF-8 Support Enabled
INFO - 2020-07-31 17:03:22 --> Utf8 Class Initialized
INFO - 2020-07-31 17:03:22 --> URI Class Initialized
INFO - 2020-07-31 17:03:22 --> Router Class Initialized
INFO - 2020-07-31 17:03:22 --> Output Class Initialized
INFO - 2020-07-31 17:03:22 --> Security Class Initialized
DEBUG - 2020-07-31 17:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 17:03:22 --> Input Class Initialized
INFO - 2020-07-31 17:03:22 --> Language Class Initialized
INFO - 2020-07-31 17:03:22 --> Loader Class Initialized
INFO - 2020-07-31 17:03:22 --> Helper loaded: url_helper
INFO - 2020-07-31 17:03:22 --> Database Driver Class Initialized
INFO - 2020-07-31 17:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 17:03:22 --> Email Class Initialized
INFO - 2020-07-31 17:03:22 --> Controller Class Initialized
INFO - 2020-07-31 17:03:22 --> Model Class Initialized
INFO - 2020-07-31 17:03:22 --> Model Class Initialized
DEBUG - 2020-07-31 17:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-07-31 17:03:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-07-31 17:03:23 --> Config Class Initialized
INFO - 2020-07-31 17:03:23 --> Hooks Class Initialized
DEBUG - 2020-07-31 17:03:23 --> UTF-8 Support Enabled
INFO - 2020-07-31 17:03:23 --> Utf8 Class Initialized
INFO - 2020-07-31 17:03:23 --> URI Class Initialized
DEBUG - 2020-07-31 17:03:23 --> No URI present. Default controller set.
INFO - 2020-07-31 17:03:23 --> Router Class Initialized
INFO - 2020-07-31 17:03:23 --> Output Class Initialized
INFO - 2020-07-31 17:03:23 --> Security Class Initialized
DEBUG - 2020-07-31 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-31 17:03:23 --> Input Class Initialized
INFO - 2020-07-31 17:03:23 --> Language Class Initialized
INFO - 2020-07-31 17:03:23 --> Loader Class Initialized
INFO - 2020-07-31 17:03:23 --> Helper loaded: url_helper
INFO - 2020-07-31 17:03:23 --> Database Driver Class Initialized
INFO - 2020-07-31 17:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-31 17:03:23 --> Email Class Initialized
INFO - 2020-07-31 17:03:23 --> Controller Class Initialized
INFO - 2020-07-31 17:03:23 --> Model Class Initialized
INFO - 2020-07-31 17:03:23 --> Model Class Initialized
DEBUG - 2020-07-31 17:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-31 17:03:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-31 17:03:23 --> Final output sent to browser
DEBUG - 2020-07-31 17:03:23 --> Total execution time: 0.0210
