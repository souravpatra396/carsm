<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-06 07:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:54:14 --> Config Class Initialized
INFO - 2020-10-06 07:54:14 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:54:14 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:54:14 --> Utf8 Class Initialized
INFO - 2020-10-06 07:54:14 --> URI Class Initialized
DEBUG - 2020-10-06 07:54:14 --> No URI present. Default controller set.
INFO - 2020-10-06 07:54:14 --> Router Class Initialized
INFO - 2020-10-06 07:54:14 --> Output Class Initialized
INFO - 2020-10-06 07:54:14 --> Security Class Initialized
DEBUG - 2020-10-06 07:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:54:14 --> Input Class Initialized
INFO - 2020-10-06 07:54:14 --> Language Class Initialized
INFO - 2020-10-06 07:54:14 --> Loader Class Initialized
INFO - 2020-10-06 07:54:14 --> Helper loaded: url_helper
INFO - 2020-10-06 07:54:14 --> Database Driver Class Initialized
INFO - 2020-10-06 07:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:54:14 --> Email Class Initialized
INFO - 2020-10-06 07:54:14 --> Controller Class Initialized
INFO - 2020-10-06 07:54:14 --> Model Class Initialized
INFO - 2020-10-06 07:54:14 --> Model Class Initialized
DEBUG - 2020-10-06 07:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:54:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 07:54:14 --> Final output sent to browser
DEBUG - 2020-10-06 07:54:14 --> Total execution time: 0.1422
ERROR - 2020-10-06 07:54:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:54:20 --> Config Class Initialized
INFO - 2020-10-06 07:54:20 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:54:20 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:54:20 --> Utf8 Class Initialized
INFO - 2020-10-06 07:54:20 --> URI Class Initialized
DEBUG - 2020-10-06 07:54:20 --> No URI present. Default controller set.
INFO - 2020-10-06 07:54:20 --> Router Class Initialized
INFO - 2020-10-06 07:54:20 --> Output Class Initialized
INFO - 2020-10-06 07:54:20 --> Security Class Initialized
DEBUG - 2020-10-06 07:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:54:20 --> Input Class Initialized
INFO - 2020-10-06 07:54:20 --> Language Class Initialized
INFO - 2020-10-06 07:54:20 --> Loader Class Initialized
INFO - 2020-10-06 07:54:20 --> Helper loaded: url_helper
INFO - 2020-10-06 07:54:20 --> Database Driver Class Initialized
INFO - 2020-10-06 07:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:54:20 --> Email Class Initialized
INFO - 2020-10-06 07:54:20 --> Controller Class Initialized
INFO - 2020-10-06 07:54:20 --> Model Class Initialized
INFO - 2020-10-06 07:54:20 --> Model Class Initialized
DEBUG - 2020-10-06 07:54:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:54:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 07:54:20 --> Final output sent to browser
DEBUG - 2020-10-06 07:54:20 --> Total execution time: 0.0181
ERROR - 2020-10-06 07:54:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:54:22 --> Config Class Initialized
INFO - 2020-10-06 07:54:22 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:54:22 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:54:22 --> Utf8 Class Initialized
INFO - 2020-10-06 07:54:22 --> URI Class Initialized
DEBUG - 2020-10-06 07:54:22 --> No URI present. Default controller set.
INFO - 2020-10-06 07:54:22 --> Router Class Initialized
INFO - 2020-10-06 07:54:22 --> Output Class Initialized
INFO - 2020-10-06 07:54:22 --> Security Class Initialized
DEBUG - 2020-10-06 07:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:54:22 --> Input Class Initialized
INFO - 2020-10-06 07:54:22 --> Language Class Initialized
INFO - 2020-10-06 07:54:22 --> Loader Class Initialized
INFO - 2020-10-06 07:54:22 --> Helper loaded: url_helper
INFO - 2020-10-06 07:54:22 --> Database Driver Class Initialized
INFO - 2020-10-06 07:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:54:22 --> Email Class Initialized
INFO - 2020-10-06 07:54:22 --> Controller Class Initialized
INFO - 2020-10-06 07:54:22 --> Model Class Initialized
INFO - 2020-10-06 07:54:22 --> Model Class Initialized
DEBUG - 2020-10-06 07:54:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:54:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 07:54:22 --> Final output sent to browser
DEBUG - 2020-10-06 07:54:22 --> Total execution time: 0.0193
ERROR - 2020-10-06 07:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:54:30 --> Config Class Initialized
INFO - 2020-10-06 07:54:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:54:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:54:30 --> Utf8 Class Initialized
INFO - 2020-10-06 07:54:30 --> URI Class Initialized
DEBUG - 2020-10-06 07:54:30 --> No URI present. Default controller set.
INFO - 2020-10-06 07:54:30 --> Router Class Initialized
INFO - 2020-10-06 07:54:30 --> Output Class Initialized
INFO - 2020-10-06 07:54:30 --> Security Class Initialized
DEBUG - 2020-10-06 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:54:30 --> Input Class Initialized
INFO - 2020-10-06 07:54:30 --> Language Class Initialized
INFO - 2020-10-06 07:54:30 --> Loader Class Initialized
INFO - 2020-10-06 07:54:30 --> Helper loaded: url_helper
INFO - 2020-10-06 07:54:30 --> Database Driver Class Initialized
INFO - 2020-10-06 07:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:54:30 --> Email Class Initialized
INFO - 2020-10-06 07:54:30 --> Controller Class Initialized
INFO - 2020-10-06 07:54:30 --> Model Class Initialized
INFO - 2020-10-06 07:54:30 --> Model Class Initialized
DEBUG - 2020-10-06 07:54:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:54:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 07:54:30 --> Final output sent to browser
DEBUG - 2020-10-06 07:54:30 --> Total execution time: 0.0187
ERROR - 2020-10-06 07:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:55:00 --> Config Class Initialized
INFO - 2020-10-06 07:55:00 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:55:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:55:00 --> Utf8 Class Initialized
INFO - 2020-10-06 07:55:00 --> URI Class Initialized
INFO - 2020-10-06 07:55:00 --> Router Class Initialized
INFO - 2020-10-06 07:55:00 --> Output Class Initialized
INFO - 2020-10-06 07:55:00 --> Security Class Initialized
DEBUG - 2020-10-06 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:55:00 --> Input Class Initialized
INFO - 2020-10-06 07:55:00 --> Language Class Initialized
INFO - 2020-10-06 07:55:00 --> Loader Class Initialized
INFO - 2020-10-06 07:55:00 --> Helper loaded: url_helper
ERROR - 2020-10-06 07:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:55:00 --> Config Class Initialized
INFO - 2020-10-06 07:55:00 --> Hooks Class Initialized
INFO - 2020-10-06 07:55:00 --> Database Driver Class Initialized
DEBUG - 2020-10-06 07:55:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:55:00 --> Utf8 Class Initialized
INFO - 2020-10-06 07:55:00 --> URI Class Initialized
INFO - 2020-10-06 07:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:55:00 --> Router Class Initialized
INFO - 2020-10-06 07:55:00 --> Output Class Initialized
INFO - 2020-10-06 07:55:00 --> Security Class Initialized
INFO - 2020-10-06 07:55:00 --> Email Class Initialized
INFO - 2020-10-06 07:55:00 --> Controller Class Initialized
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
DEBUG - 2020-10-06 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:55:00 --> Input Class Initialized
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
INFO - 2020-10-06 07:55:00 --> Language Class Initialized
DEBUG - 2020-10-06 07:55:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:55:00 --> Loader Class Initialized
INFO - 2020-10-06 07:55:00 --> Helper loaded: url_helper
INFO - 2020-10-06 07:55:00 --> Database Driver Class Initialized
INFO - 2020-10-06 07:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:55:00 --> Email Class Initialized
INFO - 2020-10-06 07:55:00 --> Controller Class Initialized
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
DEBUG - 2020-10-06 07:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 07:55:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
INFO - 2020-10-06 07:55:00 --> Final output sent to browser
DEBUG - 2020-10-06 07:55:00 --> Total execution time: 0.0446
ERROR - 2020-10-06 07:55:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:55:00 --> Config Class Initialized
INFO - 2020-10-06 07:55:00 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:55:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:55:00 --> Utf8 Class Initialized
INFO - 2020-10-06 07:55:00 --> URI Class Initialized
INFO - 2020-10-06 07:55:00 --> Router Class Initialized
INFO - 2020-10-06 07:55:00 --> Output Class Initialized
INFO - 2020-10-06 07:55:00 --> Security Class Initialized
DEBUG - 2020-10-06 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:55:00 --> Input Class Initialized
INFO - 2020-10-06 07:55:00 --> Language Class Initialized
INFO - 2020-10-06 07:55:00 --> Loader Class Initialized
INFO - 2020-10-06 07:55:00 --> Helper loaded: url_helper
INFO - 2020-10-06 07:55:00 --> Database Driver Class Initialized
INFO - 2020-10-06 07:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:55:00 --> Email Class Initialized
INFO - 2020-10-06 07:55:00 --> Controller Class Initialized
DEBUG - 2020-10-06 07:55:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 07:55:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
INFO - 2020-10-06 07:55:00 --> Model Class Initialized
INFO - 2020-10-06 07:55:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 07:55:00 --> Final output sent to browser
DEBUG - 2020-10-06 07:55:00 --> Total execution time: 0.0524
ERROR - 2020-10-06 07:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:58:24 --> Config Class Initialized
INFO - 2020-10-06 07:58:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:58:24 --> Utf8 Class Initialized
INFO - 2020-10-06 07:58:24 --> URI Class Initialized
INFO - 2020-10-06 07:58:24 --> Router Class Initialized
INFO - 2020-10-06 07:58:24 --> Output Class Initialized
INFO - 2020-10-06 07:58:24 --> Security Class Initialized
DEBUG - 2020-10-06 07:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:58:24 --> Input Class Initialized
INFO - 2020-10-06 07:58:24 --> Language Class Initialized
INFO - 2020-10-06 07:58:24 --> Loader Class Initialized
INFO - 2020-10-06 07:58:24 --> Helper loaded: url_helper
INFO - 2020-10-06 07:58:24 --> Database Driver Class Initialized
INFO - 2020-10-06 07:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:58:24 --> Email Class Initialized
INFO - 2020-10-06 07:58:24 --> Controller Class Initialized
DEBUG - 2020-10-06 07:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 07:58:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:58:24 --> Model Class Initialized
INFO - 2020-10-06 07:58:24 --> Model Class Initialized
INFO - 2020-10-06 07:58:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 07:58:24 --> Final output sent to browser
DEBUG - 2020-10-06 07:58:24 --> Total execution time: 0.1954
ERROR - 2020-10-06 07:58:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:58:27 --> Config Class Initialized
INFO - 2020-10-06 07:58:27 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:58:27 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:58:27 --> Utf8 Class Initialized
INFO - 2020-10-06 07:58:27 --> URI Class Initialized
INFO - 2020-10-06 07:58:27 --> Router Class Initialized
INFO - 2020-10-06 07:58:27 --> Output Class Initialized
INFO - 2020-10-06 07:58:27 --> Security Class Initialized
DEBUG - 2020-10-06 07:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:58:27 --> Input Class Initialized
INFO - 2020-10-06 07:58:27 --> Language Class Initialized
INFO - 2020-10-06 07:58:27 --> Loader Class Initialized
INFO - 2020-10-06 07:58:27 --> Helper loaded: url_helper
INFO - 2020-10-06 07:58:27 --> Database Driver Class Initialized
INFO - 2020-10-06 07:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:58:27 --> Email Class Initialized
INFO - 2020-10-06 07:58:27 --> Controller Class Initialized
DEBUG - 2020-10-06 07:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 07:58:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:58:27 --> Model Class Initialized
INFO - 2020-10-06 07:58:27 --> Model Class Initialized
INFO - 2020-10-06 07:58:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 07:58:27 --> Final output sent to browser
DEBUG - 2020-10-06 07:58:27 --> Total execution time: 0.0705
ERROR - 2020-10-06 07:58:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 07:58:30 --> Config Class Initialized
INFO - 2020-10-06 07:58:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 07:58:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 07:58:30 --> Utf8 Class Initialized
INFO - 2020-10-06 07:58:30 --> URI Class Initialized
INFO - 2020-10-06 07:58:30 --> Router Class Initialized
INFO - 2020-10-06 07:58:30 --> Output Class Initialized
INFO - 2020-10-06 07:58:30 --> Security Class Initialized
DEBUG - 2020-10-06 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 07:58:30 --> Input Class Initialized
INFO - 2020-10-06 07:58:30 --> Language Class Initialized
INFO - 2020-10-06 07:58:30 --> Loader Class Initialized
INFO - 2020-10-06 07:58:30 --> Helper loaded: url_helper
INFO - 2020-10-06 07:58:30 --> Database Driver Class Initialized
INFO - 2020-10-06 07:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 07:58:30 --> Email Class Initialized
INFO - 2020-10-06 07:58:30 --> Controller Class Initialized
DEBUG - 2020-10-06 07:58:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 07:58:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 07:58:30 --> Model Class Initialized
INFO - 2020-10-06 07:58:30 --> Model Class Initialized
INFO - 2020-10-06 07:58:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-06 07:58:30 --> Final output sent to browser
DEBUG - 2020-10-06 07:58:30 --> Total execution time: 0.0283
ERROR - 2020-10-06 08:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:00:40 --> Config Class Initialized
INFO - 2020-10-06 08:00:40 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:00:40 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:00:40 --> Utf8 Class Initialized
INFO - 2020-10-06 08:00:40 --> URI Class Initialized
INFO - 2020-10-06 08:00:40 --> Router Class Initialized
INFO - 2020-10-06 08:00:40 --> Output Class Initialized
INFO - 2020-10-06 08:00:40 --> Security Class Initialized
DEBUG - 2020-10-06 08:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:00:40 --> Input Class Initialized
INFO - 2020-10-06 08:00:40 --> Language Class Initialized
INFO - 2020-10-06 08:00:40 --> Loader Class Initialized
INFO - 2020-10-06 08:00:40 --> Helper loaded: url_helper
INFO - 2020-10-06 08:00:40 --> Database Driver Class Initialized
INFO - 2020-10-06 08:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:00:40 --> Email Class Initialized
INFO - 2020-10-06 08:00:40 --> Controller Class Initialized
DEBUG - 2020-10-06 08:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:00:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:00:40 --> Model Class Initialized
INFO - 2020-10-06 08:00:40 --> Model Class Initialized
INFO - 2020-10-06 08:00:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-06 08:00:40 --> Final output sent to browser
DEBUG - 2020-10-06 08:00:40 --> Total execution time: 0.0263
ERROR - 2020-10-06 08:02:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:13 --> Config Class Initialized
INFO - 2020-10-06 08:02:13 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:13 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:13 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:13 --> URI Class Initialized
INFO - 2020-10-06 08:02:13 --> Router Class Initialized
INFO - 2020-10-06 08:02:13 --> Output Class Initialized
INFO - 2020-10-06 08:02:13 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:13 --> Input Class Initialized
INFO - 2020-10-06 08:02:13 --> Language Class Initialized
INFO - 2020-10-06 08:02:13 --> Loader Class Initialized
INFO - 2020-10-06 08:02:13 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:13 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:13 --> Email Class Initialized
INFO - 2020-10-06 08:02:13 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:13 --> Model Class Initialized
INFO - 2020-10-06 08:02:13 --> Model Class Initialized
INFO - 2020-10-06 08:02:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:02:13 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:13 --> Total execution time: 0.1196
ERROR - 2020-10-06 08:02:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:15 --> Config Class Initialized
INFO - 2020-10-06 08:02:15 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:15 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:15 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:15 --> URI Class Initialized
INFO - 2020-10-06 08:02:15 --> Router Class Initialized
INFO - 2020-10-06 08:02:15 --> Output Class Initialized
INFO - 2020-10-06 08:02:15 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:15 --> Input Class Initialized
INFO - 2020-10-06 08:02:15 --> Language Class Initialized
INFO - 2020-10-06 08:02:15 --> Loader Class Initialized
INFO - 2020-10-06 08:02:15 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:15 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:15 --> Email Class Initialized
INFO - 2020-10-06 08:02:15 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:15 --> Model Class Initialized
INFO - 2020-10-06 08:02:15 --> Model Class Initialized
INFO - 2020-10-06 08:02:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 08:02:15 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:15 --> Total execution time: 0.0215
ERROR - 2020-10-06 08:02:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:30 --> Config Class Initialized
INFO - 2020-10-06 08:02:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:30 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:30 --> URI Class Initialized
INFO - 2020-10-06 08:02:30 --> Router Class Initialized
INFO - 2020-10-06 08:02:30 --> Output Class Initialized
INFO - 2020-10-06 08:02:30 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:30 --> Input Class Initialized
INFO - 2020-10-06 08:02:30 --> Language Class Initialized
INFO - 2020-10-06 08:02:30 --> Loader Class Initialized
INFO - 2020-10-06 08:02:30 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:30 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:30 --> Email Class Initialized
INFO - 2020-10-06 08:02:30 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:30 --> Model Class Initialized
INFO - 2020-10-06 08:02:30 --> Model Class Initialized
INFO - 2020-10-06 08:02:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:02:30 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:30 --> Total execution time: 0.0202
ERROR - 2020-10-06 08:02:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:33 --> Config Class Initialized
INFO - 2020-10-06 08:02:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:33 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:33 --> URI Class Initialized
INFO - 2020-10-06 08:02:33 --> Router Class Initialized
INFO - 2020-10-06 08:02:33 --> Output Class Initialized
INFO - 2020-10-06 08:02:33 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:33 --> Input Class Initialized
INFO - 2020-10-06 08:02:33 --> Language Class Initialized
INFO - 2020-10-06 08:02:33 --> Loader Class Initialized
INFO - 2020-10-06 08:02:33 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:33 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:33 --> Email Class Initialized
INFO - 2020-10-06 08:02:33 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:33 --> Model Class Initialized
INFO - 2020-10-06 08:02:33 --> Model Class Initialized
INFO - 2020-10-06 08:02:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 08:02:33 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:33 --> Total execution time: 0.0309
ERROR - 2020-10-06 08:02:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:37 --> Config Class Initialized
INFO - 2020-10-06 08:02:37 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:37 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:37 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:37 --> URI Class Initialized
INFO - 2020-10-06 08:02:37 --> Router Class Initialized
INFO - 2020-10-06 08:02:37 --> Output Class Initialized
INFO - 2020-10-06 08:02:37 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:37 --> Input Class Initialized
INFO - 2020-10-06 08:02:37 --> Language Class Initialized
INFO - 2020-10-06 08:02:37 --> Loader Class Initialized
INFO - 2020-10-06 08:02:37 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:37 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:37 --> Email Class Initialized
INFO - 2020-10-06 08:02:37 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:37 --> Model Class Initialized
INFO - 2020-10-06 08:02:37 --> Model Class Initialized
INFO - 2020-10-06 08:02:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:02:37 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:37 --> Total execution time: 0.0253
ERROR - 2020-10-06 08:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:40 --> Config Class Initialized
INFO - 2020-10-06 08:02:40 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:40 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:40 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:40 --> URI Class Initialized
INFO - 2020-10-06 08:02:40 --> Router Class Initialized
INFO - 2020-10-06 08:02:40 --> Output Class Initialized
INFO - 2020-10-06 08:02:40 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:40 --> Input Class Initialized
INFO - 2020-10-06 08:02:40 --> Language Class Initialized
INFO - 2020-10-06 08:02:40 --> Loader Class Initialized
INFO - 2020-10-06 08:02:40 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:40 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:40 --> Email Class Initialized
INFO - 2020-10-06 08:02:40 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:40 --> Model Class Initialized
INFO - 2020-10-06 08:02:40 --> Model Class Initialized
INFO - 2020-10-06 08:02:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 08:02:40 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:40 --> Total execution time: 0.0218
ERROR - 2020-10-06 08:02:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:44 --> Config Class Initialized
INFO - 2020-10-06 08:02:44 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:44 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:44 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:44 --> URI Class Initialized
INFO - 2020-10-06 08:02:44 --> Router Class Initialized
INFO - 2020-10-06 08:02:44 --> Output Class Initialized
INFO - 2020-10-06 08:02:44 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:44 --> Input Class Initialized
INFO - 2020-10-06 08:02:44 --> Language Class Initialized
INFO - 2020-10-06 08:02:44 --> Loader Class Initialized
INFO - 2020-10-06 08:02:44 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:44 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:44 --> Email Class Initialized
INFO - 2020-10-06 08:02:44 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:44 --> Model Class Initialized
INFO - 2020-10-06 08:02:44 --> Model Class Initialized
INFO - 2020-10-06 08:02:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:02:44 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:44 --> Total execution time: 0.0265
ERROR - 2020-10-06 08:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:46 --> Config Class Initialized
INFO - 2020-10-06 08:02:46 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:46 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:46 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:46 --> URI Class Initialized
INFO - 2020-10-06 08:02:46 --> Router Class Initialized
INFO - 2020-10-06 08:02:46 --> Output Class Initialized
INFO - 2020-10-06 08:02:46 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:46 --> Input Class Initialized
INFO - 2020-10-06 08:02:46 --> Language Class Initialized
INFO - 2020-10-06 08:02:46 --> Loader Class Initialized
INFO - 2020-10-06 08:02:46 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:46 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:46 --> Email Class Initialized
INFO - 2020-10-06 08:02:46 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:46 --> Model Class Initialized
INFO - 2020-10-06 08:02:46 --> Model Class Initialized
INFO - 2020-10-06 08:02:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 08:02:46 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:46 --> Total execution time: 0.0246
ERROR - 2020-10-06 08:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:50 --> Config Class Initialized
INFO - 2020-10-06 08:02:50 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:50 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:50 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:50 --> URI Class Initialized
INFO - 2020-10-06 08:02:50 --> Router Class Initialized
INFO - 2020-10-06 08:02:50 --> Output Class Initialized
INFO - 2020-10-06 08:02:50 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:50 --> Input Class Initialized
INFO - 2020-10-06 08:02:50 --> Language Class Initialized
INFO - 2020-10-06 08:02:50 --> Loader Class Initialized
INFO - 2020-10-06 08:02:50 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:50 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:50 --> Email Class Initialized
INFO - 2020-10-06 08:02:50 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:50 --> Model Class Initialized
INFO - 2020-10-06 08:02:50 --> Model Class Initialized
INFO - 2020-10-06 08:02:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:02:50 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:50 --> Total execution time: 0.0250
ERROR - 2020-10-06 08:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:54 --> Config Class Initialized
INFO - 2020-10-06 08:02:54 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:54 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:54 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:54 --> URI Class Initialized
INFO - 2020-10-06 08:02:54 --> Router Class Initialized
INFO - 2020-10-06 08:02:54 --> Output Class Initialized
INFO - 2020-10-06 08:02:54 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:54 --> Input Class Initialized
INFO - 2020-10-06 08:02:54 --> Language Class Initialized
INFO - 2020-10-06 08:02:54 --> Loader Class Initialized
INFO - 2020-10-06 08:02:54 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:54 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:54 --> Email Class Initialized
INFO - 2020-10-06 08:02:54 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:54 --> Model Class Initialized
INFO - 2020-10-06 08:02:54 --> Model Class Initialized
INFO - 2020-10-06 08:02:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 08:02:54 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:54 --> Total execution time: 0.0238
ERROR - 2020-10-06 08:02:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:57 --> Config Class Initialized
INFO - 2020-10-06 08:02:57 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:57 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:57 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:57 --> URI Class Initialized
INFO - 2020-10-06 08:02:57 --> Router Class Initialized
INFO - 2020-10-06 08:02:57 --> Output Class Initialized
INFO - 2020-10-06 08:02:57 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:57 --> Input Class Initialized
INFO - 2020-10-06 08:02:57 --> Language Class Initialized
INFO - 2020-10-06 08:02:57 --> Loader Class Initialized
INFO - 2020-10-06 08:02:57 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:57 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:57 --> Email Class Initialized
INFO - 2020-10-06 08:02:57 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:57 --> Model Class Initialized
INFO - 2020-10-06 08:02:57 --> Model Class Initialized
INFO - 2020-10-06 08:02:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:02:57 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:57 --> Total execution time: 0.0240
ERROR - 2020-10-06 08:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:02:59 --> Config Class Initialized
INFO - 2020-10-06 08:02:59 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:02:59 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:02:59 --> Utf8 Class Initialized
INFO - 2020-10-06 08:02:59 --> URI Class Initialized
INFO - 2020-10-06 08:02:59 --> Router Class Initialized
INFO - 2020-10-06 08:02:59 --> Output Class Initialized
INFO - 2020-10-06 08:02:59 --> Security Class Initialized
DEBUG - 2020-10-06 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:02:59 --> Input Class Initialized
INFO - 2020-10-06 08:02:59 --> Language Class Initialized
INFO - 2020-10-06 08:02:59 --> Loader Class Initialized
INFO - 2020-10-06 08:02:59 --> Helper loaded: url_helper
INFO - 2020-10-06 08:02:59 --> Database Driver Class Initialized
INFO - 2020-10-06 08:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:02:59 --> Email Class Initialized
INFO - 2020-10-06 08:02:59 --> Controller Class Initialized
DEBUG - 2020-10-06 08:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:02:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:02:59 --> Model Class Initialized
INFO - 2020-10-06 08:02:59 --> Model Class Initialized
INFO - 2020-10-06 08:02:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 08:02:59 --> Final output sent to browser
DEBUG - 2020-10-06 08:02:59 --> Total execution time: 0.0247
ERROR - 2020-10-06 08:03:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:03:03 --> Config Class Initialized
INFO - 2020-10-06 08:03:03 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:03:03 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:03:03 --> Utf8 Class Initialized
INFO - 2020-10-06 08:03:03 --> URI Class Initialized
INFO - 2020-10-06 08:03:03 --> Router Class Initialized
INFO - 2020-10-06 08:03:03 --> Output Class Initialized
INFO - 2020-10-06 08:03:03 --> Security Class Initialized
DEBUG - 2020-10-06 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:03:03 --> Input Class Initialized
INFO - 2020-10-06 08:03:03 --> Language Class Initialized
INFO - 2020-10-06 08:03:03 --> Loader Class Initialized
INFO - 2020-10-06 08:03:03 --> Helper loaded: url_helper
INFO - 2020-10-06 08:03:03 --> Database Driver Class Initialized
INFO - 2020-10-06 08:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:03:03 --> Email Class Initialized
INFO - 2020-10-06 08:03:03 --> Controller Class Initialized
DEBUG - 2020-10-06 08:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:03:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:03:03 --> Model Class Initialized
INFO - 2020-10-06 08:03:03 --> Model Class Initialized
INFO - 2020-10-06 08:03:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 08:03:03 --> Final output sent to browser
DEBUG - 2020-10-06 08:03:03 --> Total execution time: 0.0259
ERROR - 2020-10-06 08:03:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:03:15 --> Config Class Initialized
INFO - 2020-10-06 08:03:15 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:03:15 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:03:15 --> Utf8 Class Initialized
INFO - 2020-10-06 08:03:15 --> URI Class Initialized
INFO - 2020-10-06 08:03:15 --> Router Class Initialized
INFO - 2020-10-06 08:03:15 --> Output Class Initialized
INFO - 2020-10-06 08:03:15 --> Security Class Initialized
DEBUG - 2020-10-06 08:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:03:15 --> Input Class Initialized
INFO - 2020-10-06 08:03:15 --> Language Class Initialized
INFO - 2020-10-06 08:03:15 --> Loader Class Initialized
INFO - 2020-10-06 08:03:15 --> Helper loaded: url_helper
INFO - 2020-10-06 08:03:15 --> Database Driver Class Initialized
INFO - 2020-10-06 08:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:03:15 --> Email Class Initialized
INFO - 2020-10-06 08:03:15 --> Controller Class Initialized
DEBUG - 2020-10-06 08:03:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:03:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:03:15 --> Model Class Initialized
INFO - 2020-10-06 08:03:15 --> Model Class Initialized
INFO - 2020-10-06 08:03:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-06 08:03:15 --> Final output sent to browser
DEBUG - 2020-10-06 08:03:15 --> Total execution time: 0.0378
ERROR - 2020-10-06 08:03:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:03:17 --> Config Class Initialized
INFO - 2020-10-06 08:03:17 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:03:17 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:03:17 --> Utf8 Class Initialized
INFO - 2020-10-06 08:03:17 --> URI Class Initialized
INFO - 2020-10-06 08:03:17 --> Router Class Initialized
INFO - 2020-10-06 08:03:17 --> Output Class Initialized
INFO - 2020-10-06 08:03:17 --> Security Class Initialized
DEBUG - 2020-10-06 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:03:17 --> Input Class Initialized
INFO - 2020-10-06 08:03:17 --> Language Class Initialized
INFO - 2020-10-06 08:03:17 --> Loader Class Initialized
INFO - 2020-10-06 08:03:17 --> Helper loaded: url_helper
INFO - 2020-10-06 08:03:17 --> Database Driver Class Initialized
INFO - 2020-10-06 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:03:17 --> Email Class Initialized
INFO - 2020-10-06 08:03:17 --> Controller Class Initialized
DEBUG - 2020-10-06 08:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:03:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:03:17 --> Model Class Initialized
INFO - 2020-10-06 08:03:17 --> Model Class Initialized
INFO - 2020-10-06 08:03:17 --> Final output sent to browser
DEBUG - 2020-10-06 08:03:17 --> Total execution time: 0.0253
ERROR - 2020-10-06 08:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:00 --> Config Class Initialized
INFO - 2020-10-06 08:04:00 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:00 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:00 --> URI Class Initialized
INFO - 2020-10-06 08:04:00 --> Router Class Initialized
INFO - 2020-10-06 08:04:00 --> Output Class Initialized
INFO - 2020-10-06 08:04:00 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:00 --> Input Class Initialized
INFO - 2020-10-06 08:04:00 --> Language Class Initialized
INFO - 2020-10-06 08:04:00 --> Loader Class Initialized
INFO - 2020-10-06 08:04:00 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:00 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:00 --> Email Class Initialized
INFO - 2020-10-06 08:04:00 --> Controller Class Initialized
DEBUG - 2020-10-06 08:04:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:00 --> Model Class Initialized
INFO - 2020-10-06 08:04:00 --> Model Class Initialized
INFO - 2020-10-06 08:04:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 08:04:00 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:00 --> Total execution time: 0.0415
ERROR - 2020-10-06 08:04:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:05 --> Config Class Initialized
INFO - 2020-10-06 08:04:05 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:05 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:05 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:05 --> URI Class Initialized
INFO - 2020-10-06 08:04:05 --> Router Class Initialized
INFO - 2020-10-06 08:04:05 --> Output Class Initialized
INFO - 2020-10-06 08:04:05 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:05 --> Input Class Initialized
INFO - 2020-10-06 08:04:05 --> Language Class Initialized
INFO - 2020-10-06 08:04:05 --> Loader Class Initialized
INFO - 2020-10-06 08:04:05 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:05 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:05 --> Email Class Initialized
INFO - 2020-10-06 08:04:05 --> Controller Class Initialized
DEBUG - 2020-10-06 08:04:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:05 --> Model Class Initialized
INFO - 2020-10-06 08:04:05 --> Model Class Initialized
INFO - 2020-10-06 08:04:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-06 08:04:05 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:05 --> Total execution time: 0.0232
ERROR - 2020-10-06 08:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:06 --> Config Class Initialized
INFO - 2020-10-06 08:04:06 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:06 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:06 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:06 --> URI Class Initialized
INFO - 2020-10-06 08:04:06 --> Router Class Initialized
INFO - 2020-10-06 08:04:06 --> Output Class Initialized
INFO - 2020-10-06 08:04:06 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:06 --> Input Class Initialized
INFO - 2020-10-06 08:04:06 --> Language Class Initialized
INFO - 2020-10-06 08:04:06 --> Loader Class Initialized
INFO - 2020-10-06 08:04:06 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:06 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:06 --> Email Class Initialized
INFO - 2020-10-06 08:04:06 --> Controller Class Initialized
DEBUG - 2020-10-06 08:04:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:06 --> Model Class Initialized
INFO - 2020-10-06 08:04:06 --> Model Class Initialized
INFO - 2020-10-06 08:04:06 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:06 --> Total execution time: 0.0271
ERROR - 2020-10-06 08:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:13 --> Config Class Initialized
INFO - 2020-10-06 08:04:13 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:13 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:13 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:13 --> URI Class Initialized
INFO - 2020-10-06 08:04:13 --> Router Class Initialized
INFO - 2020-10-06 08:04:13 --> Output Class Initialized
INFO - 2020-10-06 08:04:13 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:13 --> Input Class Initialized
INFO - 2020-10-06 08:04:13 --> Language Class Initialized
INFO - 2020-10-06 08:04:13 --> Loader Class Initialized
INFO - 2020-10-06 08:04:13 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:13 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:13 --> Email Class Initialized
INFO - 2020-10-06 08:04:13 --> Controller Class Initialized
DEBUG - 2020-10-06 08:04:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:13 --> Model Class Initialized
INFO - 2020-10-06 08:04:13 --> Model Class Initialized
INFO - 2020-10-06 08:04:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 08:04:13 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:13 --> Total execution time: 0.0328
ERROR - 2020-10-06 08:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:14 --> Config Class Initialized
INFO - 2020-10-06 08:04:14 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:14 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:14 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:14 --> URI Class Initialized
INFO - 2020-10-06 08:04:14 --> Router Class Initialized
INFO - 2020-10-06 08:04:14 --> Output Class Initialized
INFO - 2020-10-06 08:04:14 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:14 --> Input Class Initialized
INFO - 2020-10-06 08:04:14 --> Language Class Initialized
INFO - 2020-10-06 08:04:14 --> Loader Class Initialized
INFO - 2020-10-06 08:04:14 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:14 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:14 --> Email Class Initialized
INFO - 2020-10-06 08:04:14 --> Controller Class Initialized
DEBUG - 2020-10-06 08:04:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:14 --> Model Class Initialized
INFO - 2020-10-06 08:04:14 --> Model Class Initialized
INFO - 2020-10-06 08:04:14 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:14 --> Total execution time: 0.0234
ERROR - 2020-10-06 08:04:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:21 --> Config Class Initialized
INFO - 2020-10-06 08:04:21 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:21 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:21 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:21 --> URI Class Initialized
DEBUG - 2020-10-06 08:04:21 --> No URI present. Default controller set.
INFO - 2020-10-06 08:04:21 --> Router Class Initialized
INFO - 2020-10-06 08:04:21 --> Output Class Initialized
INFO - 2020-10-06 08:04:21 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:21 --> Input Class Initialized
INFO - 2020-10-06 08:04:21 --> Language Class Initialized
INFO - 2020-10-06 08:04:21 --> Loader Class Initialized
INFO - 2020-10-06 08:04:21 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:21 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:21 --> Email Class Initialized
INFO - 2020-10-06 08:04:21 --> Controller Class Initialized
INFO - 2020-10-06 08:04:21 --> Model Class Initialized
INFO - 2020-10-06 08:04:21 --> Model Class Initialized
DEBUG - 2020-10-06 08:04:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 08:04:21 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:21 --> Total execution time: 0.0520
ERROR - 2020-10-06 08:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:35 --> Config Class Initialized
INFO - 2020-10-06 08:04:35 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:35 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:35 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:35 --> URI Class Initialized
INFO - 2020-10-06 08:04:35 --> Router Class Initialized
INFO - 2020-10-06 08:04:35 --> Output Class Initialized
INFO - 2020-10-06 08:04:35 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:35 --> Input Class Initialized
INFO - 2020-10-06 08:04:35 --> Language Class Initialized
INFO - 2020-10-06 08:04:35 --> Loader Class Initialized
INFO - 2020-10-06 08:04:35 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:35 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:35 --> Email Class Initialized
INFO - 2020-10-06 08:04:35 --> Controller Class Initialized
INFO - 2020-10-06 08:04:35 --> Model Class Initialized
INFO - 2020-10-06 08:04:35 --> Model Class Initialized
DEBUG - 2020-10-06 08:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:35 --> Model Class Initialized
INFO - 2020-10-06 08:04:35 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:35 --> Total execution time: 0.0238
ERROR - 2020-10-06 08:04:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:35 --> Config Class Initialized
INFO - 2020-10-06 08:04:35 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:35 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:35 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:35 --> URI Class Initialized
INFO - 2020-10-06 08:04:35 --> Router Class Initialized
INFO - 2020-10-06 08:04:35 --> Output Class Initialized
INFO - 2020-10-06 08:04:35 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:35 --> Input Class Initialized
INFO - 2020-10-06 08:04:35 --> Language Class Initialized
INFO - 2020-10-06 08:04:35 --> Loader Class Initialized
INFO - 2020-10-06 08:04:35 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:35 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:35 --> Email Class Initialized
INFO - 2020-10-06 08:04:35 --> Controller Class Initialized
INFO - 2020-10-06 08:04:35 --> Model Class Initialized
INFO - 2020-10-06 08:04:35 --> Model Class Initialized
DEBUG - 2020-10-06 08:04:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 08:04:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:36 --> Config Class Initialized
INFO - 2020-10-06 08:04:36 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:36 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:36 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:36 --> URI Class Initialized
INFO - 2020-10-06 08:04:36 --> Router Class Initialized
INFO - 2020-10-06 08:04:36 --> Output Class Initialized
INFO - 2020-10-06 08:04:36 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:36 --> Input Class Initialized
INFO - 2020-10-06 08:04:36 --> Language Class Initialized
INFO - 2020-10-06 08:04:36 --> Loader Class Initialized
INFO - 2020-10-06 08:04:36 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:36 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:36 --> Email Class Initialized
INFO - 2020-10-06 08:04:36 --> Controller Class Initialized
DEBUG - 2020-10-06 08:04:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 08:04:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:36 --> Model Class Initialized
INFO - 2020-10-06 08:04:36 --> Model Class Initialized
INFO - 2020-10-06 08:04:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 08:04:36 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:36 --> Total execution time: 0.0361
ERROR - 2020-10-06 08:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 08:04:49 --> Config Class Initialized
INFO - 2020-10-06 08:04:49 --> Hooks Class Initialized
DEBUG - 2020-10-06 08:04:49 --> UTF-8 Support Enabled
INFO - 2020-10-06 08:04:49 --> Utf8 Class Initialized
INFO - 2020-10-06 08:04:49 --> URI Class Initialized
DEBUG - 2020-10-06 08:04:49 --> No URI present. Default controller set.
INFO - 2020-10-06 08:04:49 --> Router Class Initialized
INFO - 2020-10-06 08:04:49 --> Output Class Initialized
INFO - 2020-10-06 08:04:49 --> Security Class Initialized
DEBUG - 2020-10-06 08:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 08:04:49 --> Input Class Initialized
INFO - 2020-10-06 08:04:49 --> Language Class Initialized
INFO - 2020-10-06 08:04:49 --> Loader Class Initialized
INFO - 2020-10-06 08:04:49 --> Helper loaded: url_helper
INFO - 2020-10-06 08:04:49 --> Database Driver Class Initialized
INFO - 2020-10-06 08:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 08:04:49 --> Email Class Initialized
INFO - 2020-10-06 08:04:49 --> Controller Class Initialized
INFO - 2020-10-06 08:04:49 --> Model Class Initialized
INFO - 2020-10-06 08:04:49 --> Model Class Initialized
DEBUG - 2020-10-06 08:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 08:04:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 08:04:49 --> Final output sent to browser
DEBUG - 2020-10-06 08:04:49 --> Total execution time: 0.0525
ERROR - 2020-10-06 17:30:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:30:44 --> Config Class Initialized
INFO - 2020-10-06 17:30:44 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:30:44 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:30:44 --> Utf8 Class Initialized
INFO - 2020-10-06 17:30:44 --> URI Class Initialized
DEBUG - 2020-10-06 17:30:44 --> No URI present. Default controller set.
INFO - 2020-10-06 17:30:44 --> Router Class Initialized
INFO - 2020-10-06 17:30:44 --> Output Class Initialized
INFO - 2020-10-06 17:30:44 --> Security Class Initialized
DEBUG - 2020-10-06 17:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:30:44 --> Input Class Initialized
INFO - 2020-10-06 17:30:44 --> Language Class Initialized
INFO - 2020-10-06 17:30:44 --> Loader Class Initialized
INFO - 2020-10-06 17:30:44 --> Helper loaded: url_helper
INFO - 2020-10-06 17:30:44 --> Database Driver Class Initialized
INFO - 2020-10-06 17:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:30:44 --> Email Class Initialized
INFO - 2020-10-06 17:30:44 --> Controller Class Initialized
INFO - 2020-10-06 17:30:44 --> Model Class Initialized
INFO - 2020-10-06 17:30:44 --> Model Class Initialized
DEBUG - 2020-10-06 17:30:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:30:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 17:30:44 --> Final output sent to browser
DEBUG - 2020-10-06 17:30:44 --> Total execution time: 0.0375
ERROR - 2020-10-06 17:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:30:52 --> Config Class Initialized
INFO - 2020-10-06 17:30:52 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:30:52 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:30:52 --> Utf8 Class Initialized
INFO - 2020-10-06 17:30:52 --> URI Class Initialized
INFO - 2020-10-06 17:30:52 --> Router Class Initialized
INFO - 2020-10-06 17:30:52 --> Output Class Initialized
INFO - 2020-10-06 17:30:52 --> Security Class Initialized
DEBUG - 2020-10-06 17:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:30:52 --> Input Class Initialized
INFO - 2020-10-06 17:30:52 --> Language Class Initialized
INFO - 2020-10-06 17:30:52 --> Loader Class Initialized
INFO - 2020-10-06 17:30:52 --> Helper loaded: url_helper
INFO - 2020-10-06 17:30:52 --> Database Driver Class Initialized
INFO - 2020-10-06 17:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:30:52 --> Email Class Initialized
INFO - 2020-10-06 17:30:52 --> Controller Class Initialized
INFO - 2020-10-06 17:30:52 --> Model Class Initialized
INFO - 2020-10-06 17:30:52 --> Model Class Initialized
DEBUG - 2020-10-06 17:30:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 17:30:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:30:52 --> Config Class Initialized
INFO - 2020-10-06 17:30:52 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:30:52 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:30:52 --> Utf8 Class Initialized
INFO - 2020-10-06 17:30:52 --> URI Class Initialized
INFO - 2020-10-06 17:30:52 --> Router Class Initialized
INFO - 2020-10-06 17:30:52 --> Output Class Initialized
INFO - 2020-10-06 17:30:52 --> Security Class Initialized
DEBUG - 2020-10-06 17:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:30:52 --> Input Class Initialized
INFO - 2020-10-06 17:30:52 --> Language Class Initialized
INFO - 2020-10-06 17:30:52 --> Loader Class Initialized
INFO - 2020-10-06 17:30:52 --> Helper loaded: url_helper
INFO - 2020-10-06 17:30:52 --> Database Driver Class Initialized
INFO - 2020-10-06 17:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:30:52 --> Email Class Initialized
INFO - 2020-10-06 17:30:52 --> Controller Class Initialized
INFO - 2020-10-06 17:30:52 --> Model Class Initialized
INFO - 2020-10-06 17:30:52 --> Model Class Initialized
DEBUG - 2020-10-06 17:30:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:30:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:30:52 --> Model Class Initialized
INFO - 2020-10-06 17:30:52 --> Final output sent to browser
DEBUG - 2020-10-06 17:30:52 --> Total execution time: 0.0195
ERROR - 2020-10-06 17:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:30:53 --> Config Class Initialized
INFO - 2020-10-06 17:30:53 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:30:53 --> Utf8 Class Initialized
INFO - 2020-10-06 17:30:53 --> URI Class Initialized
INFO - 2020-10-06 17:30:53 --> Router Class Initialized
INFO - 2020-10-06 17:30:53 --> Output Class Initialized
INFO - 2020-10-06 17:30:53 --> Security Class Initialized
DEBUG - 2020-10-06 17:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:30:53 --> Input Class Initialized
INFO - 2020-10-06 17:30:53 --> Language Class Initialized
INFO - 2020-10-06 17:30:53 --> Loader Class Initialized
INFO - 2020-10-06 17:30:53 --> Helper loaded: url_helper
INFO - 2020-10-06 17:30:53 --> Database Driver Class Initialized
INFO - 2020-10-06 17:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:30:53 --> Email Class Initialized
INFO - 2020-10-06 17:30:53 --> Controller Class Initialized
DEBUG - 2020-10-06 17:30:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:30:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:30:53 --> Model Class Initialized
INFO - 2020-10-06 17:30:53 --> Model Class Initialized
INFO - 2020-10-06 17:30:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 17:30:53 --> Final output sent to browser
DEBUG - 2020-10-06 17:30:53 --> Total execution time: 0.0410
ERROR - 2020-10-06 17:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:30:57 --> Config Class Initialized
INFO - 2020-10-06 17:30:57 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:30:57 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:30:57 --> Utf8 Class Initialized
INFO - 2020-10-06 17:30:57 --> URI Class Initialized
INFO - 2020-10-06 17:30:57 --> Router Class Initialized
INFO - 2020-10-06 17:30:57 --> Output Class Initialized
INFO - 2020-10-06 17:30:57 --> Security Class Initialized
DEBUG - 2020-10-06 17:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:30:57 --> Input Class Initialized
INFO - 2020-10-06 17:30:57 --> Language Class Initialized
INFO - 2020-10-06 17:30:57 --> Loader Class Initialized
INFO - 2020-10-06 17:30:57 --> Helper loaded: url_helper
INFO - 2020-10-06 17:30:57 --> Database Driver Class Initialized
INFO - 2020-10-06 17:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:30:57 --> Email Class Initialized
INFO - 2020-10-06 17:30:57 --> Controller Class Initialized
DEBUG - 2020-10-06 17:30:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:30:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:30:57 --> Model Class Initialized
INFO - 2020-10-06 17:30:57 --> Model Class Initialized
INFO - 2020-10-06 17:30:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:30:57 --> Final output sent to browser
DEBUG - 2020-10-06 17:30:57 --> Total execution time: 0.0311
ERROR - 2020-10-06 17:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:31:02 --> Config Class Initialized
INFO - 2020-10-06 17:31:02 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:31:02 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:31:02 --> Utf8 Class Initialized
INFO - 2020-10-06 17:31:02 --> URI Class Initialized
INFO - 2020-10-06 17:31:02 --> Router Class Initialized
INFO - 2020-10-06 17:31:02 --> Output Class Initialized
INFO - 2020-10-06 17:31:02 --> Security Class Initialized
DEBUG - 2020-10-06 17:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:31:02 --> Input Class Initialized
INFO - 2020-10-06 17:31:02 --> Language Class Initialized
INFO - 2020-10-06 17:31:02 --> Loader Class Initialized
INFO - 2020-10-06 17:31:02 --> Helper loaded: url_helper
INFO - 2020-10-06 17:31:02 --> Database Driver Class Initialized
INFO - 2020-10-06 17:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:31:02 --> Email Class Initialized
INFO - 2020-10-06 17:31:02 --> Controller Class Initialized
DEBUG - 2020-10-06 17:31:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:31:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:31:02 --> Model Class Initialized
INFO - 2020-10-06 17:31:02 --> Model Class Initialized
INFO - 2020-10-06 17:31:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-06 17:31:02 --> Final output sent to browser
DEBUG - 2020-10-06 17:31:02 --> Total execution time: 0.0328
ERROR - 2020-10-06 17:31:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:31:51 --> Config Class Initialized
INFO - 2020-10-06 17:31:51 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:31:51 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:31:51 --> Utf8 Class Initialized
INFO - 2020-10-06 17:31:51 --> URI Class Initialized
INFO - 2020-10-06 17:31:51 --> Router Class Initialized
INFO - 2020-10-06 17:31:51 --> Output Class Initialized
INFO - 2020-10-06 17:31:51 --> Security Class Initialized
DEBUG - 2020-10-06 17:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:31:51 --> Input Class Initialized
INFO - 2020-10-06 17:31:51 --> Language Class Initialized
INFO - 2020-10-06 17:31:51 --> Loader Class Initialized
INFO - 2020-10-06 17:31:51 --> Helper loaded: url_helper
INFO - 2020-10-06 17:31:51 --> Database Driver Class Initialized
INFO - 2020-10-06 17:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:31:51 --> Email Class Initialized
INFO - 2020-10-06 17:31:51 --> Controller Class Initialized
DEBUG - 2020-10-06 17:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:31:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:31:51 --> Model Class Initialized
INFO - 2020-10-06 17:31:51 --> Model Class Initialized
INFO - 2020-10-06 17:31:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:31:51 --> Final output sent to browser
DEBUG - 2020-10-06 17:31:51 --> Total execution time: 0.0224
ERROR - 2020-10-06 17:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:31:55 --> Config Class Initialized
INFO - 2020-10-06 17:31:55 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:31:55 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:31:55 --> Utf8 Class Initialized
INFO - 2020-10-06 17:31:55 --> URI Class Initialized
INFO - 2020-10-06 17:31:55 --> Router Class Initialized
INFO - 2020-10-06 17:31:55 --> Output Class Initialized
INFO - 2020-10-06 17:31:55 --> Security Class Initialized
DEBUG - 2020-10-06 17:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:31:55 --> Input Class Initialized
INFO - 2020-10-06 17:31:55 --> Language Class Initialized
INFO - 2020-10-06 17:31:55 --> Loader Class Initialized
INFO - 2020-10-06 17:31:55 --> Helper loaded: url_helper
INFO - 2020-10-06 17:31:55 --> Database Driver Class Initialized
INFO - 2020-10-06 17:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:31:55 --> Email Class Initialized
INFO - 2020-10-06 17:31:55 --> Controller Class Initialized
DEBUG - 2020-10-06 17:31:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:31:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:31:55 --> Model Class Initialized
INFO - 2020-10-06 17:31:55 --> Model Class Initialized
INFO - 2020-10-06 17:31:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-06 17:31:55 --> Final output sent to browser
DEBUG - 2020-10-06 17:31:55 --> Total execution time: 0.0231
ERROR - 2020-10-06 17:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:33:10 --> Config Class Initialized
INFO - 2020-10-06 17:33:10 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:33:10 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:33:10 --> Utf8 Class Initialized
INFO - 2020-10-06 17:33:10 --> URI Class Initialized
INFO - 2020-10-06 17:33:10 --> Router Class Initialized
INFO - 2020-10-06 17:33:10 --> Output Class Initialized
INFO - 2020-10-06 17:33:10 --> Security Class Initialized
DEBUG - 2020-10-06 17:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:33:10 --> Input Class Initialized
INFO - 2020-10-06 17:33:10 --> Language Class Initialized
INFO - 2020-10-06 17:33:10 --> Loader Class Initialized
INFO - 2020-10-06 17:33:10 --> Helper loaded: url_helper
INFO - 2020-10-06 17:33:10 --> Database Driver Class Initialized
INFO - 2020-10-06 17:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:33:10 --> Email Class Initialized
INFO - 2020-10-06 17:33:10 --> Controller Class Initialized
DEBUG - 2020-10-06 17:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:33:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:33:10 --> Model Class Initialized
INFO - 2020-10-06 17:33:10 --> Model Class Initialized
INFO - 2020-10-06 17:33:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-06 17:33:10 --> Final output sent to browser
DEBUG - 2020-10-06 17:33:10 --> Total execution time: 0.0329
ERROR - 2020-10-06 17:33:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:33:14 --> Config Class Initialized
INFO - 2020-10-06 17:33:14 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:33:14 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:33:14 --> Utf8 Class Initialized
INFO - 2020-10-06 17:33:14 --> URI Class Initialized
INFO - 2020-10-06 17:33:14 --> Router Class Initialized
INFO - 2020-10-06 17:33:14 --> Output Class Initialized
INFO - 2020-10-06 17:33:14 --> Security Class Initialized
DEBUG - 2020-10-06 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:33:14 --> Input Class Initialized
INFO - 2020-10-06 17:33:14 --> Language Class Initialized
INFO - 2020-10-06 17:33:14 --> Loader Class Initialized
INFO - 2020-10-06 17:33:14 --> Helper loaded: url_helper
INFO - 2020-10-06 17:33:14 --> Database Driver Class Initialized
INFO - 2020-10-06 17:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:33:14 --> Email Class Initialized
INFO - 2020-10-06 17:33:14 --> Controller Class Initialized
DEBUG - 2020-10-06 17:33:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:33:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:33:14 --> Model Class Initialized
INFO - 2020-10-06 17:33:14 --> Model Class Initialized
INFO - 2020-10-06 17:33:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:33:14 --> Final output sent to browser
DEBUG - 2020-10-06 17:33:14 --> Total execution time: 0.0209
ERROR - 2020-10-06 17:33:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:33:18 --> Config Class Initialized
INFO - 2020-10-06 17:33:18 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:33:18 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:33:18 --> Utf8 Class Initialized
INFO - 2020-10-06 17:33:18 --> URI Class Initialized
INFO - 2020-10-06 17:33:18 --> Router Class Initialized
INFO - 2020-10-06 17:33:18 --> Output Class Initialized
INFO - 2020-10-06 17:33:18 --> Security Class Initialized
DEBUG - 2020-10-06 17:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:33:18 --> Input Class Initialized
INFO - 2020-10-06 17:33:18 --> Language Class Initialized
INFO - 2020-10-06 17:33:18 --> Loader Class Initialized
INFO - 2020-10-06 17:33:18 --> Helper loaded: url_helper
INFO - 2020-10-06 17:33:18 --> Database Driver Class Initialized
INFO - 2020-10-06 17:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:33:18 --> Email Class Initialized
INFO - 2020-10-06 17:33:18 --> Controller Class Initialized
DEBUG - 2020-10-06 17:33:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:33:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:33:18 --> Model Class Initialized
INFO - 2020-10-06 17:33:18 --> Model Class Initialized
INFO - 2020-10-06 17:33:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-06 17:33:18 --> Final output sent to browser
DEBUG - 2020-10-06 17:33:18 --> Total execution time: 0.0219
ERROR - 2020-10-06 17:33:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:33:35 --> Config Class Initialized
INFO - 2020-10-06 17:33:35 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:33:35 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:33:35 --> Utf8 Class Initialized
INFO - 2020-10-06 17:33:35 --> URI Class Initialized
INFO - 2020-10-06 17:33:35 --> Router Class Initialized
INFO - 2020-10-06 17:33:35 --> Output Class Initialized
INFO - 2020-10-06 17:33:35 --> Security Class Initialized
DEBUG - 2020-10-06 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:33:35 --> Input Class Initialized
INFO - 2020-10-06 17:33:35 --> Language Class Initialized
INFO - 2020-10-06 17:33:35 --> Loader Class Initialized
INFO - 2020-10-06 17:33:35 --> Helper loaded: url_helper
INFO - 2020-10-06 17:33:35 --> Database Driver Class Initialized
INFO - 2020-10-06 17:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:33:35 --> Email Class Initialized
INFO - 2020-10-06 17:33:35 --> Controller Class Initialized
DEBUG - 2020-10-06 17:33:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:33:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:33:35 --> Model Class Initialized
INFO - 2020-10-06 17:33:35 --> Model Class Initialized
INFO - 2020-10-06 17:33:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:33:35 --> Final output sent to browser
DEBUG - 2020-10-06 17:33:35 --> Total execution time: 0.0230
ERROR - 2020-10-06 17:33:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:33:37 --> Config Class Initialized
INFO - 2020-10-06 17:33:37 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:33:37 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:33:37 --> Utf8 Class Initialized
INFO - 2020-10-06 17:33:37 --> URI Class Initialized
INFO - 2020-10-06 17:33:37 --> Router Class Initialized
INFO - 2020-10-06 17:33:37 --> Output Class Initialized
INFO - 2020-10-06 17:33:37 --> Security Class Initialized
DEBUG - 2020-10-06 17:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:33:37 --> Input Class Initialized
INFO - 2020-10-06 17:33:37 --> Language Class Initialized
INFO - 2020-10-06 17:33:37 --> Loader Class Initialized
INFO - 2020-10-06 17:33:37 --> Helper loaded: url_helper
INFO - 2020-10-06 17:33:37 --> Database Driver Class Initialized
INFO - 2020-10-06 17:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:33:37 --> Email Class Initialized
INFO - 2020-10-06 17:33:37 --> Controller Class Initialized
DEBUG - 2020-10-06 17:33:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:33:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:33:37 --> Model Class Initialized
INFO - 2020-10-06 17:33:37 --> Model Class Initialized
INFO - 2020-10-06 17:33:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-06 17:33:37 --> Final output sent to browser
DEBUG - 2020-10-06 17:33:37 --> Total execution time: 0.0348
ERROR - 2020-10-06 17:33:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:33:58 --> Config Class Initialized
INFO - 2020-10-06 17:33:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:33:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:33:58 --> Utf8 Class Initialized
INFO - 2020-10-06 17:33:58 --> URI Class Initialized
INFO - 2020-10-06 17:33:58 --> Router Class Initialized
INFO - 2020-10-06 17:33:58 --> Output Class Initialized
INFO - 2020-10-06 17:33:58 --> Security Class Initialized
DEBUG - 2020-10-06 17:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:33:58 --> Input Class Initialized
INFO - 2020-10-06 17:33:58 --> Language Class Initialized
INFO - 2020-10-06 17:33:58 --> Loader Class Initialized
INFO - 2020-10-06 17:33:58 --> Helper loaded: url_helper
INFO - 2020-10-06 17:33:58 --> Database Driver Class Initialized
INFO - 2020-10-06 17:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:33:58 --> Email Class Initialized
INFO - 2020-10-06 17:33:58 --> Controller Class Initialized
DEBUG - 2020-10-06 17:33:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:33:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:33:58 --> Model Class Initialized
INFO - 2020-10-06 17:33:58 --> Model Class Initialized
INFO - 2020-10-06 17:33:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:33:58 --> Final output sent to browser
DEBUG - 2020-10-06 17:33:58 --> Total execution time: 0.0238
ERROR - 2020-10-06 17:35:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:35:09 --> Config Class Initialized
INFO - 2020-10-06 17:35:09 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:35:09 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:35:09 --> Utf8 Class Initialized
INFO - 2020-10-06 17:35:09 --> URI Class Initialized
INFO - 2020-10-06 17:35:09 --> Router Class Initialized
INFO - 2020-10-06 17:35:09 --> Output Class Initialized
INFO - 2020-10-06 17:35:09 --> Security Class Initialized
DEBUG - 2020-10-06 17:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:35:09 --> Input Class Initialized
INFO - 2020-10-06 17:35:09 --> Language Class Initialized
INFO - 2020-10-06 17:35:09 --> Loader Class Initialized
INFO - 2020-10-06 17:35:09 --> Helper loaded: url_helper
INFO - 2020-10-06 17:35:09 --> Database Driver Class Initialized
INFO - 2020-10-06 17:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:35:09 --> Email Class Initialized
INFO - 2020-10-06 17:35:09 --> Controller Class Initialized
DEBUG - 2020-10-06 17:35:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:35:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:35:09 --> Model Class Initialized
INFO - 2020-10-06 17:35:09 --> Model Class Initialized
INFO - 2020-10-06 17:35:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-06 17:35:09 --> Final output sent to browser
DEBUG - 2020-10-06 17:35:09 --> Total execution time: 0.0225
ERROR - 2020-10-06 17:40:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:40:13 --> Config Class Initialized
INFO - 2020-10-06 17:40:13 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:40:13 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:40:13 --> Utf8 Class Initialized
INFO - 2020-10-06 17:40:13 --> URI Class Initialized
INFO - 2020-10-06 17:40:13 --> Router Class Initialized
INFO - 2020-10-06 17:40:13 --> Output Class Initialized
INFO - 2020-10-06 17:40:13 --> Security Class Initialized
DEBUG - 2020-10-06 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:40:13 --> Input Class Initialized
INFO - 2020-10-06 17:40:13 --> Language Class Initialized
INFO - 2020-10-06 17:40:13 --> Loader Class Initialized
INFO - 2020-10-06 17:40:13 --> Helper loaded: url_helper
INFO - 2020-10-06 17:40:13 --> Database Driver Class Initialized
INFO - 2020-10-06 17:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:40:13 --> Email Class Initialized
INFO - 2020-10-06 17:40:13 --> Controller Class Initialized
DEBUG - 2020-10-06 17:40:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:40:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:40:13 --> Model Class Initialized
INFO - 2020-10-06 17:40:13 --> Model Class Initialized
INFO - 2020-10-06 17:40:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-06 17:40:13 --> Final output sent to browser
DEBUG - 2020-10-06 17:40:13 --> Total execution time: 0.0236
ERROR - 2020-10-06 17:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:40:47 --> Config Class Initialized
INFO - 2020-10-06 17:40:47 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:40:47 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:40:47 --> Utf8 Class Initialized
INFO - 2020-10-06 17:40:47 --> URI Class Initialized
INFO - 2020-10-06 17:40:47 --> Router Class Initialized
INFO - 2020-10-06 17:40:47 --> Output Class Initialized
INFO - 2020-10-06 17:40:47 --> Security Class Initialized
DEBUG - 2020-10-06 17:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:40:47 --> Input Class Initialized
INFO - 2020-10-06 17:40:47 --> Language Class Initialized
INFO - 2020-10-06 17:40:47 --> Loader Class Initialized
INFO - 2020-10-06 17:40:47 --> Helper loaded: url_helper
INFO - 2020-10-06 17:40:47 --> Database Driver Class Initialized
INFO - 2020-10-06 17:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:40:47 --> Email Class Initialized
INFO - 2020-10-06 17:40:47 --> Controller Class Initialized
DEBUG - 2020-10-06 17:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:40:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:40:47 --> Model Class Initialized
INFO - 2020-10-06 17:40:47 --> Model Class Initialized
INFO - 2020-10-06 17:40:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:40:47 --> Final output sent to browser
DEBUG - 2020-10-06 17:40:47 --> Total execution time: 0.0220
ERROR - 2020-10-06 17:40:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:40:50 --> Config Class Initialized
INFO - 2020-10-06 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-06 17:40:50 --> URI Class Initialized
INFO - 2020-10-06 17:40:50 --> Router Class Initialized
INFO - 2020-10-06 17:40:50 --> Output Class Initialized
INFO - 2020-10-06 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-06 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:40:50 --> Input Class Initialized
INFO - 2020-10-06 17:40:50 --> Language Class Initialized
INFO - 2020-10-06 17:40:50 --> Loader Class Initialized
INFO - 2020-10-06 17:40:50 --> Helper loaded: url_helper
INFO - 2020-10-06 17:40:50 --> Database Driver Class Initialized
INFO - 2020-10-06 17:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:40:50 --> Email Class Initialized
INFO - 2020-10-06 17:40:50 --> Controller Class Initialized
DEBUG - 2020-10-06 17:40:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:40:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:40:50 --> Model Class Initialized
INFO - 2020-10-06 17:40:50 --> Model Class Initialized
INFO - 2020-10-06 17:40:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-06 17:40:50 --> Final output sent to browser
DEBUG - 2020-10-06 17:40:50 --> Total execution time: 0.0234
ERROR - 2020-10-06 17:41:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:41:05 --> Config Class Initialized
INFO - 2020-10-06 17:41:05 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:41:05 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:41:05 --> Utf8 Class Initialized
INFO - 2020-10-06 17:41:05 --> URI Class Initialized
INFO - 2020-10-06 17:41:05 --> Router Class Initialized
INFO - 2020-10-06 17:41:05 --> Output Class Initialized
INFO - 2020-10-06 17:41:05 --> Security Class Initialized
DEBUG - 2020-10-06 17:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:41:05 --> Input Class Initialized
INFO - 2020-10-06 17:41:05 --> Language Class Initialized
INFO - 2020-10-06 17:41:05 --> Loader Class Initialized
INFO - 2020-10-06 17:41:05 --> Helper loaded: url_helper
INFO - 2020-10-06 17:41:05 --> Database Driver Class Initialized
INFO - 2020-10-06 17:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:41:05 --> Email Class Initialized
INFO - 2020-10-06 17:41:05 --> Controller Class Initialized
DEBUG - 2020-10-06 17:41:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:41:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:41:05 --> Model Class Initialized
INFO - 2020-10-06 17:41:05 --> Model Class Initialized
INFO - 2020-10-06 17:41:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 17:41:05 --> Final output sent to browser
DEBUG - 2020-10-06 17:41:05 --> Total execution time: 0.0219
ERROR - 2020-10-06 17:41:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:41:43 --> Config Class Initialized
INFO - 2020-10-06 17:41:43 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:41:43 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:41:43 --> Utf8 Class Initialized
INFO - 2020-10-06 17:41:43 --> URI Class Initialized
INFO - 2020-10-06 17:41:43 --> Router Class Initialized
INFO - 2020-10-06 17:41:43 --> Output Class Initialized
INFO - 2020-10-06 17:41:43 --> Security Class Initialized
DEBUG - 2020-10-06 17:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:41:43 --> Input Class Initialized
INFO - 2020-10-06 17:41:43 --> Language Class Initialized
INFO - 2020-10-06 17:41:43 --> Loader Class Initialized
INFO - 2020-10-06 17:41:43 --> Helper loaded: url_helper
INFO - 2020-10-06 17:41:43 --> Database Driver Class Initialized
INFO - 2020-10-06 17:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:41:43 --> Email Class Initialized
INFO - 2020-10-06 17:41:43 --> Controller Class Initialized
DEBUG - 2020-10-06 17:41:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:41:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:41:43 --> Model Class Initialized
INFO - 2020-10-06 17:41:43 --> Model Class Initialized
INFO - 2020-10-06 17:41:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 17:41:43 --> Final output sent to browser
DEBUG - 2020-10-06 17:41:43 --> Total execution time: 0.0259
ERROR - 2020-10-06 17:41:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:41:49 --> Config Class Initialized
INFO - 2020-10-06 17:41:49 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:41:49 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:41:49 --> Utf8 Class Initialized
INFO - 2020-10-06 17:41:49 --> URI Class Initialized
INFO - 2020-10-06 17:41:49 --> Router Class Initialized
INFO - 2020-10-06 17:41:49 --> Output Class Initialized
INFO - 2020-10-06 17:41:49 --> Security Class Initialized
DEBUG - 2020-10-06 17:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:41:49 --> Input Class Initialized
INFO - 2020-10-06 17:41:49 --> Language Class Initialized
INFO - 2020-10-06 17:41:49 --> Loader Class Initialized
INFO - 2020-10-06 17:41:49 --> Helper loaded: url_helper
INFO - 2020-10-06 17:41:49 --> Database Driver Class Initialized
INFO - 2020-10-06 17:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:41:49 --> Email Class Initialized
INFO - 2020-10-06 17:41:49 --> Controller Class Initialized
DEBUG - 2020-10-06 17:41:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:41:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:41:49 --> Model Class Initialized
INFO - 2020-10-06 17:41:49 --> Model Class Initialized
INFO - 2020-10-06 17:41:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-10-06 17:41:49 --> Final output sent to browser
DEBUG - 2020-10-06 17:41:49 --> Total execution time: 0.0249
ERROR - 2020-10-06 17:42:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:00 --> Config Class Initialized
INFO - 2020-10-06 17:42:00 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:00 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:00 --> URI Class Initialized
INFO - 2020-10-06 17:42:00 --> Router Class Initialized
INFO - 2020-10-06 17:42:00 --> Output Class Initialized
INFO - 2020-10-06 17:42:00 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:00 --> Input Class Initialized
INFO - 2020-10-06 17:42:00 --> Language Class Initialized
INFO - 2020-10-06 17:42:00 --> Loader Class Initialized
INFO - 2020-10-06 17:42:00 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:00 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:00 --> Email Class Initialized
INFO - 2020-10-06 17:42:00 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:00 --> Model Class Initialized
INFO - 2020-10-06 17:42:00 --> Model Class Initialized
INFO - 2020-10-06 17:42:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 17:42:00 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:00 --> Total execution time: 0.0234
ERROR - 2020-10-06 17:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:07 --> Config Class Initialized
INFO - 2020-10-06 17:42:07 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:07 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:07 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:07 --> URI Class Initialized
INFO - 2020-10-06 17:42:07 --> Router Class Initialized
INFO - 2020-10-06 17:42:07 --> Output Class Initialized
INFO - 2020-10-06 17:42:07 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:07 --> Input Class Initialized
INFO - 2020-10-06 17:42:07 --> Language Class Initialized
INFO - 2020-10-06 17:42:07 --> Loader Class Initialized
INFO - 2020-10-06 17:42:07 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:07 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:07 --> Email Class Initialized
INFO - 2020-10-06 17:42:07 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:07 --> Model Class Initialized
INFO - 2020-10-06 17:42:07 --> Model Class Initialized
INFO - 2020-10-06 17:42:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-10-06 17:42:07 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:07 --> Total execution time: 0.0193
ERROR - 2020-10-06 17:42:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:11 --> Config Class Initialized
INFO - 2020-10-06 17:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:11 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:11 --> URI Class Initialized
INFO - 2020-10-06 17:42:11 --> Router Class Initialized
INFO - 2020-10-06 17:42:11 --> Output Class Initialized
INFO - 2020-10-06 17:42:11 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:11 --> Input Class Initialized
INFO - 2020-10-06 17:42:11 --> Language Class Initialized
INFO - 2020-10-06 17:42:11 --> Loader Class Initialized
INFO - 2020-10-06 17:42:11 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:11 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:11 --> Email Class Initialized
INFO - 2020-10-06 17:42:11 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:11 --> Model Class Initialized
INFO - 2020-10-06 17:42:11 --> Model Class Initialized
INFO - 2020-10-06 17:42:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 17:42:11 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:11 --> Total execution time: 0.0207
ERROR - 2020-10-06 17:42:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:13 --> Config Class Initialized
INFO - 2020-10-06 17:42:13 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:13 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:13 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:13 --> URI Class Initialized
INFO - 2020-10-06 17:42:13 --> Router Class Initialized
INFO - 2020-10-06 17:42:13 --> Output Class Initialized
INFO - 2020-10-06 17:42:13 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:13 --> Input Class Initialized
INFO - 2020-10-06 17:42:13 --> Language Class Initialized
INFO - 2020-10-06 17:42:13 --> Loader Class Initialized
INFO - 2020-10-06 17:42:13 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:13 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:13 --> Email Class Initialized
INFO - 2020-10-06 17:42:13 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:13 --> Model Class Initialized
INFO - 2020-10-06 17:42:13 --> Model Class Initialized
INFO - 2020-10-06 17:42:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-06 17:42:13 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:13 --> Total execution time: 0.0210
ERROR - 2020-10-06 17:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:17 --> Config Class Initialized
INFO - 2020-10-06 17:42:17 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:17 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:17 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:17 --> URI Class Initialized
INFO - 2020-10-06 17:42:17 --> Router Class Initialized
INFO - 2020-10-06 17:42:17 --> Output Class Initialized
INFO - 2020-10-06 17:42:17 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:17 --> Input Class Initialized
INFO - 2020-10-06 17:42:17 --> Language Class Initialized
INFO - 2020-10-06 17:42:17 --> Loader Class Initialized
INFO - 2020-10-06 17:42:17 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:17 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:17 --> Email Class Initialized
INFO - 2020-10-06 17:42:17 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:17 --> Model Class Initialized
INFO - 2020-10-06 17:42:17 --> Model Class Initialized
INFO - 2020-10-06 17:42:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-06 17:42:17 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:17 --> Total execution time: 0.2713
ERROR - 2020-10-06 17:42:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:20 --> Config Class Initialized
INFO - 2020-10-06 17:42:20 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:20 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:20 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:20 --> URI Class Initialized
INFO - 2020-10-06 17:42:20 --> Router Class Initialized
INFO - 2020-10-06 17:42:20 --> Output Class Initialized
INFO - 2020-10-06 17:42:20 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:20 --> Input Class Initialized
INFO - 2020-10-06 17:42:20 --> Language Class Initialized
INFO - 2020-10-06 17:42:20 --> Loader Class Initialized
INFO - 2020-10-06 17:42:20 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:20 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:20 --> Email Class Initialized
INFO - 2020-10-06 17:42:20 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:20 --> Model Class Initialized
INFO - 2020-10-06 17:42:20 --> Model Class Initialized
INFO - 2020-10-06 17:42:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-06 17:42:20 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:20 --> Total execution time: 0.0322
ERROR - 2020-10-06 17:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:21 --> Config Class Initialized
INFO - 2020-10-06 17:42:21 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:21 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:21 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:21 --> URI Class Initialized
INFO - 2020-10-06 17:42:21 --> Router Class Initialized
INFO - 2020-10-06 17:42:21 --> Output Class Initialized
INFO - 2020-10-06 17:42:21 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:21 --> Input Class Initialized
INFO - 2020-10-06 17:42:21 --> Language Class Initialized
INFO - 2020-10-06 17:42:21 --> Loader Class Initialized
INFO - 2020-10-06 17:42:21 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:21 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:21 --> Email Class Initialized
INFO - 2020-10-06 17:42:21 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:21 --> Model Class Initialized
INFO - 2020-10-06 17:42:21 --> Model Class Initialized
INFO - 2020-10-06 17:42:21 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:21 --> Total execution time: 0.0220
ERROR - 2020-10-06 17:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:24 --> Config Class Initialized
INFO - 2020-10-06 17:42:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:24 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:24 --> URI Class Initialized
INFO - 2020-10-06 17:42:24 --> Router Class Initialized
INFO - 2020-10-06 17:42:24 --> Output Class Initialized
INFO - 2020-10-06 17:42:24 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:24 --> Input Class Initialized
INFO - 2020-10-06 17:42:24 --> Language Class Initialized
INFO - 2020-10-06 17:42:24 --> Loader Class Initialized
INFO - 2020-10-06 17:42:24 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:24 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:24 --> Email Class Initialized
INFO - 2020-10-06 17:42:24 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:24 --> Model Class Initialized
INFO - 2020-10-06 17:42:24 --> Model Class Initialized
INFO - 2020-10-06 17:42:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:42:24 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:24 --> Total execution time: 0.0251
ERROR - 2020-10-06 17:42:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:25 --> Config Class Initialized
INFO - 2020-10-06 17:42:25 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:25 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:25 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:25 --> URI Class Initialized
INFO - 2020-10-06 17:42:25 --> Router Class Initialized
INFO - 2020-10-06 17:42:25 --> Output Class Initialized
INFO - 2020-10-06 17:42:25 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:25 --> Input Class Initialized
INFO - 2020-10-06 17:42:25 --> Language Class Initialized
INFO - 2020-10-06 17:42:25 --> Loader Class Initialized
INFO - 2020-10-06 17:42:25 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:25 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:25 --> Email Class Initialized
INFO - 2020-10-06 17:42:25 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:25 --> Model Class Initialized
INFO - 2020-10-06 17:42:25 --> Model Class Initialized
INFO - 2020-10-06 17:42:25 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:25 --> Total execution time: 0.0199
ERROR - 2020-10-06 17:42:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:33 --> Config Class Initialized
INFO - 2020-10-06 17:42:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:33 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:33 --> URI Class Initialized
INFO - 2020-10-06 17:42:33 --> Router Class Initialized
INFO - 2020-10-06 17:42:33 --> Output Class Initialized
INFO - 2020-10-06 17:42:33 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:33 --> Input Class Initialized
INFO - 2020-10-06 17:42:33 --> Language Class Initialized
INFO - 2020-10-06 17:42:33 --> Loader Class Initialized
INFO - 2020-10-06 17:42:33 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:33 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:33 --> Email Class Initialized
INFO - 2020-10-06 17:42:33 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:33 --> Model Class Initialized
INFO - 2020-10-06 17:42:33 --> Model Class Initialized
INFO - 2020-10-06 17:42:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:42:33 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:33 --> Total execution time: 0.0233
ERROR - 2020-10-06 17:42:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:42:33 --> Config Class Initialized
INFO - 2020-10-06 17:42:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:42:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:42:33 --> Utf8 Class Initialized
INFO - 2020-10-06 17:42:33 --> URI Class Initialized
INFO - 2020-10-06 17:42:33 --> Router Class Initialized
INFO - 2020-10-06 17:42:33 --> Output Class Initialized
INFO - 2020-10-06 17:42:33 --> Security Class Initialized
DEBUG - 2020-10-06 17:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:42:33 --> Input Class Initialized
INFO - 2020-10-06 17:42:33 --> Language Class Initialized
INFO - 2020-10-06 17:42:33 --> Loader Class Initialized
INFO - 2020-10-06 17:42:33 --> Helper loaded: url_helper
INFO - 2020-10-06 17:42:33 --> Database Driver Class Initialized
INFO - 2020-10-06 17:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:42:33 --> Email Class Initialized
INFO - 2020-10-06 17:42:33 --> Controller Class Initialized
DEBUG - 2020-10-06 17:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:42:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:42:33 --> Model Class Initialized
INFO - 2020-10-06 17:42:33 --> Model Class Initialized
INFO - 2020-10-06 17:42:33 --> Final output sent to browser
DEBUG - 2020-10-06 17:42:33 --> Total execution time: 0.0209
ERROR - 2020-10-06 17:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:49:15 --> Config Class Initialized
INFO - 2020-10-06 17:49:15 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:49:15 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:49:15 --> Utf8 Class Initialized
INFO - 2020-10-06 17:49:15 --> URI Class Initialized
INFO - 2020-10-06 17:49:15 --> Router Class Initialized
INFO - 2020-10-06 17:49:15 --> Output Class Initialized
INFO - 2020-10-06 17:49:15 --> Security Class Initialized
DEBUG - 2020-10-06 17:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:49:15 --> Input Class Initialized
INFO - 2020-10-06 17:49:15 --> Language Class Initialized
INFO - 2020-10-06 17:49:15 --> Loader Class Initialized
INFO - 2020-10-06 17:49:15 --> Helper loaded: url_helper
INFO - 2020-10-06 17:49:15 --> Database Driver Class Initialized
INFO - 2020-10-06 17:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:49:15 --> Email Class Initialized
INFO - 2020-10-06 17:49:15 --> Controller Class Initialized
DEBUG - 2020-10-06 17:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:49:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:49:15 --> Model Class Initialized
INFO - 2020-10-06 17:49:15 --> Model Class Initialized
INFO - 2020-10-06 17:49:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:49:15 --> Final output sent to browser
DEBUG - 2020-10-06 17:49:15 --> Total execution time: 0.0247
ERROR - 2020-10-06 17:49:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:49:16 --> Config Class Initialized
INFO - 2020-10-06 17:49:16 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:49:16 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:49:16 --> Utf8 Class Initialized
INFO - 2020-10-06 17:49:16 --> URI Class Initialized
INFO - 2020-10-06 17:49:16 --> Router Class Initialized
INFO - 2020-10-06 17:49:16 --> Output Class Initialized
INFO - 2020-10-06 17:49:16 --> Security Class Initialized
DEBUG - 2020-10-06 17:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:49:16 --> Input Class Initialized
INFO - 2020-10-06 17:49:16 --> Language Class Initialized
INFO - 2020-10-06 17:49:16 --> Loader Class Initialized
INFO - 2020-10-06 17:49:16 --> Helper loaded: url_helper
INFO - 2020-10-06 17:49:16 --> Database Driver Class Initialized
INFO - 2020-10-06 17:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:49:16 --> Email Class Initialized
INFO - 2020-10-06 17:49:16 --> Controller Class Initialized
DEBUG - 2020-10-06 17:49:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:49:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:49:16 --> Model Class Initialized
INFO - 2020-10-06 17:49:16 --> Model Class Initialized
INFO - 2020-10-06 17:49:16 --> Final output sent to browser
DEBUG - 2020-10-06 17:49:16 --> Total execution time: 0.0200
ERROR - 2020-10-06 17:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:49:19 --> Config Class Initialized
INFO - 2020-10-06 17:49:19 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:49:19 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:49:19 --> Utf8 Class Initialized
INFO - 2020-10-06 17:49:19 --> URI Class Initialized
INFO - 2020-10-06 17:49:19 --> Router Class Initialized
INFO - 2020-10-06 17:49:19 --> Output Class Initialized
INFO - 2020-10-06 17:49:19 --> Security Class Initialized
DEBUG - 2020-10-06 17:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:49:19 --> Input Class Initialized
INFO - 2020-10-06 17:49:19 --> Language Class Initialized
INFO - 2020-10-06 17:49:19 --> Loader Class Initialized
INFO - 2020-10-06 17:49:19 --> Helper loaded: url_helper
INFO - 2020-10-06 17:49:19 --> Database Driver Class Initialized
INFO - 2020-10-06 17:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:49:19 --> Email Class Initialized
INFO - 2020-10-06 17:49:19 --> Controller Class Initialized
DEBUG - 2020-10-06 17:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:49:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:49:19 --> Model Class Initialized
INFO - 2020-10-06 17:49:19 --> Model Class Initialized
ERROR - 2020-10-06 17:49:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-06 17:49:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-06 17:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:49:36 --> Config Class Initialized
INFO - 2020-10-06 17:49:36 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:49:36 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:49:36 --> Utf8 Class Initialized
INFO - 2020-10-06 17:49:36 --> URI Class Initialized
INFO - 2020-10-06 17:49:36 --> Router Class Initialized
INFO - 2020-10-06 17:49:36 --> Output Class Initialized
INFO - 2020-10-06 17:49:36 --> Security Class Initialized
DEBUG - 2020-10-06 17:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:49:36 --> Input Class Initialized
INFO - 2020-10-06 17:49:36 --> Language Class Initialized
INFO - 2020-10-06 17:49:36 --> Loader Class Initialized
INFO - 2020-10-06 17:49:36 --> Helper loaded: url_helper
INFO - 2020-10-06 17:49:36 --> Database Driver Class Initialized
INFO - 2020-10-06 17:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:49:36 --> Email Class Initialized
INFO - 2020-10-06 17:49:36 --> Controller Class Initialized
DEBUG - 2020-10-06 17:49:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:49:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:49:36 --> Model Class Initialized
INFO - 2020-10-06 17:49:36 --> Model Class Initialized
INFO - 2020-10-06 17:49:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:49:36 --> Final output sent to browser
DEBUG - 2020-10-06 17:49:36 --> Total execution time: 0.0245
ERROR - 2020-10-06 17:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:49:38 --> Config Class Initialized
INFO - 2020-10-06 17:49:38 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:49:38 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:49:38 --> Utf8 Class Initialized
INFO - 2020-10-06 17:49:38 --> URI Class Initialized
INFO - 2020-10-06 17:49:38 --> Router Class Initialized
INFO - 2020-10-06 17:49:38 --> Output Class Initialized
INFO - 2020-10-06 17:49:38 --> Security Class Initialized
DEBUG - 2020-10-06 17:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:49:38 --> Input Class Initialized
INFO - 2020-10-06 17:49:38 --> Language Class Initialized
INFO - 2020-10-06 17:49:38 --> Loader Class Initialized
INFO - 2020-10-06 17:49:38 --> Helper loaded: url_helper
INFO - 2020-10-06 17:49:38 --> Database Driver Class Initialized
INFO - 2020-10-06 17:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:49:38 --> Email Class Initialized
INFO - 2020-10-06 17:49:38 --> Controller Class Initialized
DEBUG - 2020-10-06 17:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:49:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:49:38 --> Model Class Initialized
INFO - 2020-10-06 17:49:38 --> Model Class Initialized
INFO - 2020-10-06 17:49:38 --> Final output sent to browser
DEBUG - 2020-10-06 17:49:38 --> Total execution time: 0.0241
ERROR - 2020-10-06 17:52:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:43 --> Config Class Initialized
INFO - 2020-10-06 17:52:43 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:43 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:43 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:43 --> URI Class Initialized
INFO - 2020-10-06 17:52:43 --> Router Class Initialized
INFO - 2020-10-06 17:52:43 --> Output Class Initialized
INFO - 2020-10-06 17:52:43 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:43 --> Input Class Initialized
INFO - 2020-10-06 17:52:43 --> Language Class Initialized
INFO - 2020-10-06 17:52:43 --> Loader Class Initialized
INFO - 2020-10-06 17:52:43 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:43 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:43 --> Email Class Initialized
INFO - 2020-10-06 17:52:43 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:43 --> Model Class Initialized
INFO - 2020-10-06 17:52:43 --> Model Class Initialized
ERROR - 2020-10-06 17:52:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-06 17:52:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-06 17:52:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:45 --> Config Class Initialized
INFO - 2020-10-06 17:52:45 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:45 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:45 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:45 --> URI Class Initialized
INFO - 2020-10-06 17:52:45 --> Router Class Initialized
INFO - 2020-10-06 17:52:45 --> Output Class Initialized
INFO - 2020-10-06 17:52:45 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:45 --> Input Class Initialized
INFO - 2020-10-06 17:52:45 --> Language Class Initialized
INFO - 2020-10-06 17:52:45 --> Loader Class Initialized
INFO - 2020-10-06 17:52:45 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:45 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:45 --> Email Class Initialized
INFO - 2020-10-06 17:52:45 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:45 --> Model Class Initialized
INFO - 2020-10-06 17:52:45 --> Model Class Initialized
INFO - 2020-10-06 17:52:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:52:45 --> Final output sent to browser
DEBUG - 2020-10-06 17:52:45 --> Total execution time: 0.0195
ERROR - 2020-10-06 17:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:46 --> Config Class Initialized
INFO - 2020-10-06 17:52:46 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:46 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:46 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:46 --> URI Class Initialized
INFO - 2020-10-06 17:52:46 --> Router Class Initialized
INFO - 2020-10-06 17:52:46 --> Output Class Initialized
INFO - 2020-10-06 17:52:46 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:46 --> Input Class Initialized
INFO - 2020-10-06 17:52:46 --> Language Class Initialized
INFO - 2020-10-06 17:52:46 --> Loader Class Initialized
INFO - 2020-10-06 17:52:46 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:46 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:46 --> Email Class Initialized
INFO - 2020-10-06 17:52:46 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:46 --> Model Class Initialized
INFO - 2020-10-06 17:52:46 --> Model Class Initialized
INFO - 2020-10-06 17:52:46 --> Final output sent to browser
DEBUG - 2020-10-06 17:52:46 --> Total execution time: 0.0195
ERROR - 2020-10-06 17:52:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:48 --> Config Class Initialized
INFO - 2020-10-06 17:52:48 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:48 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:48 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:48 --> URI Class Initialized
INFO - 2020-10-06 17:52:48 --> Router Class Initialized
INFO - 2020-10-06 17:52:48 --> Output Class Initialized
INFO - 2020-10-06 17:52:48 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:48 --> Input Class Initialized
INFO - 2020-10-06 17:52:48 --> Language Class Initialized
INFO - 2020-10-06 17:52:48 --> Loader Class Initialized
INFO - 2020-10-06 17:52:48 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:48 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:48 --> Email Class Initialized
INFO - 2020-10-06 17:52:48 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:48 --> Model Class Initialized
INFO - 2020-10-06 17:52:48 --> Model Class Initialized
INFO - 2020-10-06 17:52:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:52:48 --> Final output sent to browser
DEBUG - 2020-10-06 17:52:48 --> Total execution time: 0.0337
ERROR - 2020-10-06 17:52:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:49 --> Config Class Initialized
INFO - 2020-10-06 17:52:49 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:49 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:49 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:49 --> URI Class Initialized
INFO - 2020-10-06 17:52:49 --> Router Class Initialized
INFO - 2020-10-06 17:52:49 --> Output Class Initialized
INFO - 2020-10-06 17:52:49 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:49 --> Input Class Initialized
INFO - 2020-10-06 17:52:49 --> Language Class Initialized
INFO - 2020-10-06 17:52:49 --> Loader Class Initialized
INFO - 2020-10-06 17:52:49 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:49 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:49 --> Email Class Initialized
INFO - 2020-10-06 17:52:49 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:49 --> Model Class Initialized
INFO - 2020-10-06 17:52:49 --> Model Class Initialized
INFO - 2020-10-06 17:52:49 --> Final output sent to browser
DEBUG - 2020-10-06 17:52:49 --> Total execution time: 0.0230
ERROR - 2020-10-06 17:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:55 --> Config Class Initialized
INFO - 2020-10-06 17:52:55 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:55 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:55 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:55 --> URI Class Initialized
INFO - 2020-10-06 17:52:55 --> Router Class Initialized
INFO - 2020-10-06 17:52:55 --> Output Class Initialized
INFO - 2020-10-06 17:52:55 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:55 --> Input Class Initialized
INFO - 2020-10-06 17:52:55 --> Language Class Initialized
INFO - 2020-10-06 17:52:55 --> Loader Class Initialized
INFO - 2020-10-06 17:52:55 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:55 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:55 --> Email Class Initialized
INFO - 2020-10-06 17:52:55 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:55 --> Model Class Initialized
INFO - 2020-10-06 17:52:55 --> Model Class Initialized
INFO - 2020-10-06 17:52:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:52:55 --> Final output sent to browser
DEBUG - 2020-10-06 17:52:55 --> Total execution time: 0.0263
ERROR - 2020-10-06 17:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:52:55 --> Config Class Initialized
INFO - 2020-10-06 17:52:55 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:52:55 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:52:55 --> Utf8 Class Initialized
INFO - 2020-10-06 17:52:55 --> URI Class Initialized
INFO - 2020-10-06 17:52:55 --> Router Class Initialized
INFO - 2020-10-06 17:52:55 --> Output Class Initialized
INFO - 2020-10-06 17:52:55 --> Security Class Initialized
DEBUG - 2020-10-06 17:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:52:55 --> Input Class Initialized
INFO - 2020-10-06 17:52:55 --> Language Class Initialized
INFO - 2020-10-06 17:52:55 --> Loader Class Initialized
INFO - 2020-10-06 17:52:55 --> Helper loaded: url_helper
INFO - 2020-10-06 17:52:55 --> Database Driver Class Initialized
INFO - 2020-10-06 17:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:52:55 --> Email Class Initialized
INFO - 2020-10-06 17:52:55 --> Controller Class Initialized
DEBUG - 2020-10-06 17:52:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:52:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:52:55 --> Model Class Initialized
INFO - 2020-10-06 17:52:55 --> Model Class Initialized
INFO - 2020-10-06 17:52:55 --> Final output sent to browser
DEBUG - 2020-10-06 17:52:55 --> Total execution time: 0.0192
ERROR - 2020-10-06 17:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:24 --> Config Class Initialized
INFO - 2020-10-06 17:53:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:24 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:24 --> URI Class Initialized
INFO - 2020-10-06 17:53:24 --> Router Class Initialized
INFO - 2020-10-06 17:53:24 --> Output Class Initialized
INFO - 2020-10-06 17:53:24 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:24 --> Input Class Initialized
INFO - 2020-10-06 17:53:24 --> Language Class Initialized
INFO - 2020-10-06 17:53:24 --> Loader Class Initialized
INFO - 2020-10-06 17:53:24 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:24 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:24 --> Email Class Initialized
INFO - 2020-10-06 17:53:24 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:24 --> Model Class Initialized
INFO - 2020-10-06 17:53:24 --> Model Class Initialized
INFO - 2020-10-06 17:53:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:53:24 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:24 --> Total execution time: 0.0217
ERROR - 2020-10-06 17:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:25 --> Config Class Initialized
INFO - 2020-10-06 17:53:25 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:25 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:25 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:25 --> URI Class Initialized
INFO - 2020-10-06 17:53:25 --> Router Class Initialized
INFO - 2020-10-06 17:53:25 --> Output Class Initialized
INFO - 2020-10-06 17:53:25 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:25 --> Input Class Initialized
INFO - 2020-10-06 17:53:25 --> Language Class Initialized
INFO - 2020-10-06 17:53:25 --> Loader Class Initialized
INFO - 2020-10-06 17:53:25 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:25 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:25 --> Email Class Initialized
INFO - 2020-10-06 17:53:25 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:25 --> Model Class Initialized
INFO - 2020-10-06 17:53:25 --> Model Class Initialized
INFO - 2020-10-06 17:53:25 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:25 --> Total execution time: 0.0206
ERROR - 2020-10-06 17:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:28 --> Config Class Initialized
INFO - 2020-10-06 17:53:28 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:28 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:28 --> URI Class Initialized
INFO - 2020-10-06 17:53:28 --> Router Class Initialized
INFO - 2020-10-06 17:53:28 --> Output Class Initialized
INFO - 2020-10-06 17:53:28 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:28 --> Input Class Initialized
INFO - 2020-10-06 17:53:28 --> Language Class Initialized
INFO - 2020-10-06 17:53:28 --> Loader Class Initialized
INFO - 2020-10-06 17:53:28 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:28 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:28 --> Email Class Initialized
INFO - 2020-10-06 17:53:28 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:28 --> Model Class Initialized
INFO - 2020-10-06 17:53:28 --> Model Class Initialized
INFO - 2020-10-06 17:53:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:53:28 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:28 --> Total execution time: 0.0312
ERROR - 2020-10-06 17:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:28 --> Config Class Initialized
INFO - 2020-10-06 17:53:28 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:28 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:28 --> URI Class Initialized
INFO - 2020-10-06 17:53:28 --> Router Class Initialized
INFO - 2020-10-06 17:53:28 --> Output Class Initialized
INFO - 2020-10-06 17:53:28 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:28 --> Input Class Initialized
INFO - 2020-10-06 17:53:28 --> Language Class Initialized
INFO - 2020-10-06 17:53:28 --> Loader Class Initialized
INFO - 2020-10-06 17:53:28 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:28 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:28 --> Email Class Initialized
INFO - 2020-10-06 17:53:28 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:28 --> Model Class Initialized
INFO - 2020-10-06 17:53:28 --> Model Class Initialized
INFO - 2020-10-06 17:53:28 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:28 --> Total execution time: 0.0241
ERROR - 2020-10-06 17:53:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:30 --> Config Class Initialized
INFO - 2020-10-06 17:53:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:30 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:30 --> URI Class Initialized
INFO - 2020-10-06 17:53:30 --> Router Class Initialized
INFO - 2020-10-06 17:53:30 --> Output Class Initialized
INFO - 2020-10-06 17:53:30 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:30 --> Input Class Initialized
INFO - 2020-10-06 17:53:30 --> Language Class Initialized
INFO - 2020-10-06 17:53:30 --> Loader Class Initialized
INFO - 2020-10-06 17:53:30 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:30 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:30 --> Email Class Initialized
INFO - 2020-10-06 17:53:30 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:30 --> Model Class Initialized
INFO - 2020-10-06 17:53:30 --> Model Class Initialized
INFO - 2020-10-06 17:53:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:53:31 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:31 --> Total execution time: 0.0255
ERROR - 2020-10-06 17:53:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:31 --> Config Class Initialized
INFO - 2020-10-06 17:53:31 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:31 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:31 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:31 --> URI Class Initialized
INFO - 2020-10-06 17:53:31 --> Router Class Initialized
INFO - 2020-10-06 17:53:31 --> Output Class Initialized
INFO - 2020-10-06 17:53:31 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:31 --> Input Class Initialized
INFO - 2020-10-06 17:53:31 --> Language Class Initialized
INFO - 2020-10-06 17:53:31 --> Loader Class Initialized
INFO - 2020-10-06 17:53:31 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:31 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:31 --> Email Class Initialized
INFO - 2020-10-06 17:53:31 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:31 --> Model Class Initialized
INFO - 2020-10-06 17:53:31 --> Model Class Initialized
INFO - 2020-10-06 17:53:31 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:31 --> Total execution time: 0.0220
ERROR - 2020-10-06 17:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:38 --> Config Class Initialized
INFO - 2020-10-06 17:53:38 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:38 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:38 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:38 --> URI Class Initialized
INFO - 2020-10-06 17:53:38 --> Router Class Initialized
INFO - 2020-10-06 17:53:38 --> Output Class Initialized
INFO - 2020-10-06 17:53:38 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:38 --> Input Class Initialized
INFO - 2020-10-06 17:53:38 --> Language Class Initialized
INFO - 2020-10-06 17:53:38 --> Loader Class Initialized
INFO - 2020-10-06 17:53:38 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:38 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:38 --> Email Class Initialized
INFO - 2020-10-06 17:53:38 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:38 --> Model Class Initialized
INFO - 2020-10-06 17:53:38 --> Model Class Initialized
INFO - 2020-10-06 17:53:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:53:38 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:38 --> Total execution time: 0.0260
ERROR - 2020-10-06 17:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:39 --> Config Class Initialized
INFO - 2020-10-06 17:53:39 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:39 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:39 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:39 --> URI Class Initialized
INFO - 2020-10-06 17:53:39 --> Router Class Initialized
INFO - 2020-10-06 17:53:39 --> Output Class Initialized
INFO - 2020-10-06 17:53:39 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:39 --> Input Class Initialized
INFO - 2020-10-06 17:53:39 --> Language Class Initialized
INFO - 2020-10-06 17:53:39 --> Loader Class Initialized
INFO - 2020-10-06 17:53:39 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:39 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:39 --> Email Class Initialized
INFO - 2020-10-06 17:53:39 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:39 --> Model Class Initialized
INFO - 2020-10-06 17:53:39 --> Model Class Initialized
INFO - 2020-10-06 17:53:39 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:39 --> Total execution time: 0.0214
ERROR - 2020-10-06 17:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:43 --> Config Class Initialized
INFO - 2020-10-06 17:53:43 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:43 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:43 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:43 --> URI Class Initialized
INFO - 2020-10-06 17:53:43 --> Router Class Initialized
INFO - 2020-10-06 17:53:43 --> Output Class Initialized
INFO - 2020-10-06 17:53:43 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:43 --> Input Class Initialized
INFO - 2020-10-06 17:53:43 --> Language Class Initialized
INFO - 2020-10-06 17:53:43 --> Loader Class Initialized
INFO - 2020-10-06 17:53:43 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:43 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:43 --> Email Class Initialized
INFO - 2020-10-06 17:53:43 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:43 --> Model Class Initialized
INFO - 2020-10-06 17:53:43 --> Model Class Initialized
INFO - 2020-10-06 17:53:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:53:43 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:43 --> Total execution time: 0.0249
ERROR - 2020-10-06 17:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:43 --> Config Class Initialized
INFO - 2020-10-06 17:53:43 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:43 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:43 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:43 --> URI Class Initialized
INFO - 2020-10-06 17:53:43 --> Router Class Initialized
INFO - 2020-10-06 17:53:43 --> Output Class Initialized
INFO - 2020-10-06 17:53:43 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:43 --> Input Class Initialized
INFO - 2020-10-06 17:53:43 --> Language Class Initialized
INFO - 2020-10-06 17:53:43 --> Loader Class Initialized
INFO - 2020-10-06 17:53:43 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:43 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:43 --> Email Class Initialized
INFO - 2020-10-06 17:53:43 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:43 --> Model Class Initialized
INFO - 2020-10-06 17:53:43 --> Model Class Initialized
INFO - 2020-10-06 17:53:43 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:43 --> Total execution time: 0.0218
ERROR - 2020-10-06 17:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:57 --> Config Class Initialized
INFO - 2020-10-06 17:53:57 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:57 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:57 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:57 --> URI Class Initialized
INFO - 2020-10-06 17:53:57 --> Router Class Initialized
INFO - 2020-10-06 17:53:57 --> Output Class Initialized
INFO - 2020-10-06 17:53:57 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:57 --> Input Class Initialized
INFO - 2020-10-06 17:53:57 --> Language Class Initialized
INFO - 2020-10-06 17:53:57 --> Loader Class Initialized
INFO - 2020-10-06 17:53:57 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:57 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:57 --> Email Class Initialized
INFO - 2020-10-06 17:53:57 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:57 --> Model Class Initialized
INFO - 2020-10-06 17:53:57 --> Model Class Initialized
INFO - 2020-10-06 17:53:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:53:57 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:57 --> Total execution time: 0.0205
ERROR - 2020-10-06 17:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:53:57 --> Config Class Initialized
INFO - 2020-10-06 17:53:57 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:53:57 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:53:57 --> Utf8 Class Initialized
INFO - 2020-10-06 17:53:57 --> URI Class Initialized
INFO - 2020-10-06 17:53:57 --> Router Class Initialized
INFO - 2020-10-06 17:53:57 --> Output Class Initialized
INFO - 2020-10-06 17:53:57 --> Security Class Initialized
DEBUG - 2020-10-06 17:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:53:57 --> Input Class Initialized
INFO - 2020-10-06 17:53:57 --> Language Class Initialized
INFO - 2020-10-06 17:53:57 --> Loader Class Initialized
INFO - 2020-10-06 17:53:57 --> Helper loaded: url_helper
INFO - 2020-10-06 17:53:57 --> Database Driver Class Initialized
INFO - 2020-10-06 17:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:53:57 --> Email Class Initialized
INFO - 2020-10-06 17:53:57 --> Controller Class Initialized
DEBUG - 2020-10-06 17:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:53:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:53:57 --> Model Class Initialized
INFO - 2020-10-06 17:53:57 --> Model Class Initialized
INFO - 2020-10-06 17:53:57 --> Final output sent to browser
DEBUG - 2020-10-06 17:53:57 --> Total execution time: 0.0193
ERROR - 2020-10-06 17:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:06 --> Config Class Initialized
INFO - 2020-10-06 17:54:06 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:06 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:06 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:06 --> URI Class Initialized
INFO - 2020-10-06 17:54:06 --> Router Class Initialized
INFO - 2020-10-06 17:54:06 --> Output Class Initialized
INFO - 2020-10-06 17:54:06 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:06 --> Input Class Initialized
INFO - 2020-10-06 17:54:06 --> Language Class Initialized
INFO - 2020-10-06 17:54:06 --> Loader Class Initialized
INFO - 2020-10-06 17:54:06 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:06 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:06 --> Email Class Initialized
INFO - 2020-10-06 17:54:06 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:06 --> Model Class Initialized
INFO - 2020-10-06 17:54:06 --> Model Class Initialized
INFO - 2020-10-06 17:54:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:54:06 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:06 --> Total execution time: 0.0295
ERROR - 2020-10-06 17:54:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:08 --> Config Class Initialized
INFO - 2020-10-06 17:54:08 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:08 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:08 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:08 --> URI Class Initialized
INFO - 2020-10-06 17:54:08 --> Router Class Initialized
INFO - 2020-10-06 17:54:08 --> Output Class Initialized
INFO - 2020-10-06 17:54:08 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:08 --> Input Class Initialized
INFO - 2020-10-06 17:54:08 --> Language Class Initialized
INFO - 2020-10-06 17:54:08 --> Loader Class Initialized
INFO - 2020-10-06 17:54:08 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:08 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:08 --> Email Class Initialized
INFO - 2020-10-06 17:54:08 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:08 --> Model Class Initialized
INFO - 2020-10-06 17:54:08 --> Model Class Initialized
INFO - 2020-10-06 17:54:08 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:08 --> Total execution time: 0.0214
ERROR - 2020-10-06 17:54:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:16 --> Config Class Initialized
INFO - 2020-10-06 17:54:16 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:16 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:16 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:16 --> URI Class Initialized
INFO - 2020-10-06 17:54:16 --> Router Class Initialized
INFO - 2020-10-06 17:54:16 --> Output Class Initialized
INFO - 2020-10-06 17:54:16 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:16 --> Input Class Initialized
INFO - 2020-10-06 17:54:16 --> Language Class Initialized
INFO - 2020-10-06 17:54:16 --> Loader Class Initialized
INFO - 2020-10-06 17:54:16 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:16 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:16 --> Email Class Initialized
INFO - 2020-10-06 17:54:16 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:16 --> Model Class Initialized
INFO - 2020-10-06 17:54:16 --> Model Class Initialized
INFO - 2020-10-06 17:54:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:54:16 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:16 --> Total execution time: 0.0264
ERROR - 2020-10-06 17:54:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:17 --> Config Class Initialized
INFO - 2020-10-06 17:54:17 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:17 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:17 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:17 --> URI Class Initialized
INFO - 2020-10-06 17:54:17 --> Router Class Initialized
INFO - 2020-10-06 17:54:17 --> Output Class Initialized
INFO - 2020-10-06 17:54:17 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:17 --> Input Class Initialized
INFO - 2020-10-06 17:54:17 --> Language Class Initialized
INFO - 2020-10-06 17:54:17 --> Loader Class Initialized
INFO - 2020-10-06 17:54:17 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:17 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:17 --> Email Class Initialized
INFO - 2020-10-06 17:54:17 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:17 --> Model Class Initialized
INFO - 2020-10-06 17:54:17 --> Model Class Initialized
INFO - 2020-10-06 17:54:17 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:17 --> Total execution time: 0.0249
ERROR - 2020-10-06 17:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:29 --> Config Class Initialized
INFO - 2020-10-06 17:54:29 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:29 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:29 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:29 --> URI Class Initialized
INFO - 2020-10-06 17:54:29 --> Router Class Initialized
INFO - 2020-10-06 17:54:29 --> Output Class Initialized
INFO - 2020-10-06 17:54:29 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:29 --> Input Class Initialized
INFO - 2020-10-06 17:54:29 --> Language Class Initialized
INFO - 2020-10-06 17:54:29 --> Loader Class Initialized
INFO - 2020-10-06 17:54:29 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:29 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:29 --> Email Class Initialized
INFO - 2020-10-06 17:54:29 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:29 --> Model Class Initialized
INFO - 2020-10-06 17:54:29 --> Model Class Initialized
INFO - 2020-10-06 17:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-06 17:54:29 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:29 --> Total execution time: 0.0267
ERROR - 2020-10-06 17:54:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:30 --> Config Class Initialized
INFO - 2020-10-06 17:54:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:30 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:30 --> URI Class Initialized
INFO - 2020-10-06 17:54:30 --> Router Class Initialized
INFO - 2020-10-06 17:54:30 --> Output Class Initialized
INFO - 2020-10-06 17:54:30 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:30 --> Input Class Initialized
INFO - 2020-10-06 17:54:30 --> Language Class Initialized
INFO - 2020-10-06 17:54:30 --> Loader Class Initialized
INFO - 2020-10-06 17:54:30 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:30 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:30 --> Email Class Initialized
INFO - 2020-10-06 17:54:30 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:30 --> Model Class Initialized
INFO - 2020-10-06 17:54:30 --> Model Class Initialized
INFO - 2020-10-06 17:54:30 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:30 --> Total execution time: 0.0238
ERROR - 2020-10-06 17:54:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:51 --> Config Class Initialized
INFO - 2020-10-06 17:54:51 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:51 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:51 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:51 --> URI Class Initialized
INFO - 2020-10-06 17:54:51 --> Router Class Initialized
INFO - 2020-10-06 17:54:51 --> Output Class Initialized
INFO - 2020-10-06 17:54:51 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:51 --> Input Class Initialized
INFO - 2020-10-06 17:54:51 --> Language Class Initialized
INFO - 2020-10-06 17:54:51 --> Loader Class Initialized
INFO - 2020-10-06 17:54:51 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:51 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:51 --> Email Class Initialized
INFO - 2020-10-06 17:54:51 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:51 --> Model Class Initialized
INFO - 2020-10-06 17:54:51 --> Model Class Initialized
INFO - 2020-10-06 17:54:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:54:51 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:51 --> Total execution time: 0.0366
ERROR - 2020-10-06 17:54:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:54:56 --> Config Class Initialized
INFO - 2020-10-06 17:54:56 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:54:56 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:54:56 --> Utf8 Class Initialized
INFO - 2020-10-06 17:54:56 --> URI Class Initialized
INFO - 2020-10-06 17:54:56 --> Router Class Initialized
INFO - 2020-10-06 17:54:56 --> Output Class Initialized
INFO - 2020-10-06 17:54:56 --> Security Class Initialized
DEBUG - 2020-10-06 17:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:54:56 --> Input Class Initialized
INFO - 2020-10-06 17:54:56 --> Language Class Initialized
INFO - 2020-10-06 17:54:56 --> Loader Class Initialized
INFO - 2020-10-06 17:54:56 --> Helper loaded: url_helper
INFO - 2020-10-06 17:54:56 --> Database Driver Class Initialized
INFO - 2020-10-06 17:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:54:56 --> Email Class Initialized
INFO - 2020-10-06 17:54:56 --> Controller Class Initialized
DEBUG - 2020-10-06 17:54:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:54:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:54:56 --> Model Class Initialized
INFO - 2020-10-06 17:54:56 --> Model Class Initialized
INFO - 2020-10-06 17:54:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 17:54:56 --> Final output sent to browser
DEBUG - 2020-10-06 17:54:56 --> Total execution time: 0.0389
ERROR - 2020-10-06 17:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:58:07 --> Config Class Initialized
INFO - 2020-10-06 17:58:07 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:58:07 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:58:07 --> Utf8 Class Initialized
INFO - 2020-10-06 17:58:07 --> URI Class Initialized
INFO - 2020-10-06 17:58:07 --> Router Class Initialized
INFO - 2020-10-06 17:58:07 --> Output Class Initialized
INFO - 2020-10-06 17:58:07 --> Security Class Initialized
DEBUG - 2020-10-06 17:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:58:07 --> Input Class Initialized
INFO - 2020-10-06 17:58:07 --> Language Class Initialized
INFO - 2020-10-06 17:58:07 --> Loader Class Initialized
INFO - 2020-10-06 17:58:07 --> Helper loaded: url_helper
INFO - 2020-10-06 17:58:07 --> Database Driver Class Initialized
INFO - 2020-10-06 17:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:58:07 --> Email Class Initialized
INFO - 2020-10-06 17:58:07 --> Controller Class Initialized
DEBUG - 2020-10-06 17:58:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:58:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:58:07 --> Model Class Initialized
INFO - 2020-10-06 17:58:07 --> Model Class Initialized
INFO - 2020-10-06 17:58:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 17:58:07 --> Final output sent to browser
DEBUG - 2020-10-06 17:58:07 --> Total execution time: 0.0300
ERROR - 2020-10-06 17:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:58:15 --> Config Class Initialized
INFO - 2020-10-06 17:58:15 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:58:15 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:58:15 --> Utf8 Class Initialized
INFO - 2020-10-06 17:58:15 --> URI Class Initialized
INFO - 2020-10-06 17:58:15 --> Router Class Initialized
INFO - 2020-10-06 17:58:15 --> Output Class Initialized
INFO - 2020-10-06 17:58:15 --> Security Class Initialized
DEBUG - 2020-10-06 17:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:58:15 --> Input Class Initialized
INFO - 2020-10-06 17:58:15 --> Language Class Initialized
INFO - 2020-10-06 17:58:15 --> Loader Class Initialized
INFO - 2020-10-06 17:58:15 --> Helper loaded: url_helper
INFO - 2020-10-06 17:58:15 --> Database Driver Class Initialized
INFO - 2020-10-06 17:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:58:15 --> Email Class Initialized
INFO - 2020-10-06 17:58:15 --> Controller Class Initialized
DEBUG - 2020-10-06 17:58:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:58:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:58:15 --> Model Class Initialized
INFO - 2020-10-06 17:58:15 --> Model Class Initialized
INFO - 2020-10-06 17:58:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:58:15 --> Final output sent to browser
DEBUG - 2020-10-06 17:58:15 --> Total execution time: 0.0204
ERROR - 2020-10-06 17:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:58:19 --> Config Class Initialized
INFO - 2020-10-06 17:58:19 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:58:19 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:58:19 --> Utf8 Class Initialized
INFO - 2020-10-06 17:58:19 --> URI Class Initialized
INFO - 2020-10-06 17:58:19 --> Router Class Initialized
INFO - 2020-10-06 17:58:19 --> Output Class Initialized
INFO - 2020-10-06 17:58:19 --> Security Class Initialized
DEBUG - 2020-10-06 17:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:58:19 --> Input Class Initialized
INFO - 2020-10-06 17:58:19 --> Language Class Initialized
INFO - 2020-10-06 17:58:19 --> Loader Class Initialized
INFO - 2020-10-06 17:58:19 --> Helper loaded: url_helper
INFO - 2020-10-06 17:58:19 --> Database Driver Class Initialized
INFO - 2020-10-06 17:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:58:19 --> Email Class Initialized
INFO - 2020-10-06 17:58:19 --> Controller Class Initialized
DEBUG - 2020-10-06 17:58:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:58:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:58:19 --> Model Class Initialized
INFO - 2020-10-06 17:58:19 --> Model Class Initialized
INFO - 2020-10-06 17:58:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 17:58:19 --> Final output sent to browser
DEBUG - 2020-10-06 17:58:19 --> Total execution time: 0.0230
ERROR - 2020-10-06 17:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:58:24 --> Config Class Initialized
INFO - 2020-10-06 17:58:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:58:24 --> Utf8 Class Initialized
INFO - 2020-10-06 17:58:24 --> URI Class Initialized
INFO - 2020-10-06 17:58:24 --> Router Class Initialized
INFO - 2020-10-06 17:58:24 --> Output Class Initialized
INFO - 2020-10-06 17:58:24 --> Security Class Initialized
DEBUG - 2020-10-06 17:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:58:24 --> Input Class Initialized
INFO - 2020-10-06 17:58:24 --> Language Class Initialized
INFO - 2020-10-06 17:58:24 --> Loader Class Initialized
INFO - 2020-10-06 17:58:24 --> Helper loaded: url_helper
INFO - 2020-10-06 17:58:24 --> Database Driver Class Initialized
INFO - 2020-10-06 17:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:58:24 --> Email Class Initialized
INFO - 2020-10-06 17:58:24 --> Controller Class Initialized
DEBUG - 2020-10-06 17:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:58:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:58:24 --> Model Class Initialized
INFO - 2020-10-06 17:58:24 --> Model Class Initialized
INFO - 2020-10-06 17:58:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:58:24 --> Final output sent to browser
DEBUG - 2020-10-06 17:58:24 --> Total execution time: 0.0218
ERROR - 2020-10-06 17:58:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:58:26 --> Config Class Initialized
INFO - 2020-10-06 17:58:26 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:58:26 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:58:26 --> Utf8 Class Initialized
INFO - 2020-10-06 17:58:26 --> URI Class Initialized
INFO - 2020-10-06 17:58:26 --> Router Class Initialized
INFO - 2020-10-06 17:58:26 --> Output Class Initialized
INFO - 2020-10-06 17:58:26 --> Security Class Initialized
DEBUG - 2020-10-06 17:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:58:26 --> Input Class Initialized
INFO - 2020-10-06 17:58:26 --> Language Class Initialized
INFO - 2020-10-06 17:58:26 --> Loader Class Initialized
INFO - 2020-10-06 17:58:26 --> Helper loaded: url_helper
INFO - 2020-10-06 17:58:26 --> Database Driver Class Initialized
INFO - 2020-10-06 17:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:58:26 --> Email Class Initialized
INFO - 2020-10-06 17:58:26 --> Controller Class Initialized
DEBUG - 2020-10-06 17:58:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:58:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:58:26 --> Model Class Initialized
INFO - 2020-10-06 17:58:26 --> Model Class Initialized
INFO - 2020-10-06 17:58:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 17:58:26 --> Final output sent to browser
DEBUG - 2020-10-06 17:58:26 --> Total execution time: 0.0213
ERROR - 2020-10-06 17:59:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:06 --> Config Class Initialized
INFO - 2020-10-06 17:59:06 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:06 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:06 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:06 --> URI Class Initialized
INFO - 2020-10-06 17:59:06 --> Router Class Initialized
INFO - 2020-10-06 17:59:06 --> Output Class Initialized
INFO - 2020-10-06 17:59:06 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:06 --> Input Class Initialized
INFO - 2020-10-06 17:59:06 --> Language Class Initialized
INFO - 2020-10-06 17:59:06 --> Loader Class Initialized
INFO - 2020-10-06 17:59:06 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:06 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:06 --> Email Class Initialized
INFO - 2020-10-06 17:59:06 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:06 --> Model Class Initialized
INFO - 2020-10-06 17:59:06 --> Model Class Initialized
INFO - 2020-10-06 17:59:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 17:59:06 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:06 --> Total execution time: 0.0230
ERROR - 2020-10-06 17:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:25 --> Config Class Initialized
INFO - 2020-10-06 17:59:25 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:25 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:25 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:25 --> URI Class Initialized
INFO - 2020-10-06 17:59:25 --> Router Class Initialized
INFO - 2020-10-06 17:59:25 --> Output Class Initialized
INFO - 2020-10-06 17:59:25 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:25 --> Input Class Initialized
INFO - 2020-10-06 17:59:25 --> Language Class Initialized
INFO - 2020-10-06 17:59:25 --> Loader Class Initialized
INFO - 2020-10-06 17:59:25 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:25 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:25 --> Email Class Initialized
INFO - 2020-10-06 17:59:25 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:25 --> Model Class Initialized
INFO - 2020-10-06 17:59:25 --> Model Class Initialized
INFO - 2020-10-06 17:59:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:59:25 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:25 --> Total execution time: 0.0245
ERROR - 2020-10-06 17:59:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:28 --> Config Class Initialized
INFO - 2020-10-06 17:59:28 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:28 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:28 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:28 --> URI Class Initialized
INFO - 2020-10-06 17:59:28 --> Router Class Initialized
INFO - 2020-10-06 17:59:28 --> Output Class Initialized
INFO - 2020-10-06 17:59:28 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:28 --> Input Class Initialized
INFO - 2020-10-06 17:59:28 --> Language Class Initialized
INFO - 2020-10-06 17:59:28 --> Loader Class Initialized
INFO - 2020-10-06 17:59:28 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:28 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:28 --> Email Class Initialized
INFO - 2020-10-06 17:59:28 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:28 --> Model Class Initialized
INFO - 2020-10-06 17:59:28 --> Model Class Initialized
INFO - 2020-10-06 17:59:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 17:59:28 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:28 --> Total execution time: 0.0227
ERROR - 2020-10-06 17:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:32 --> Config Class Initialized
INFO - 2020-10-06 17:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:32 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:32 --> URI Class Initialized
INFO - 2020-10-06 17:59:32 --> Router Class Initialized
INFO - 2020-10-06 17:59:32 --> Output Class Initialized
INFO - 2020-10-06 17:59:32 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:32 --> Input Class Initialized
INFO - 2020-10-06 17:59:32 --> Language Class Initialized
INFO - 2020-10-06 17:59:32 --> Loader Class Initialized
INFO - 2020-10-06 17:59:32 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:32 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:32 --> Email Class Initialized
INFO - 2020-10-06 17:59:32 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:32 --> Model Class Initialized
INFO - 2020-10-06 17:59:32 --> Model Class Initialized
INFO - 2020-10-06 17:59:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:59:32 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:32 --> Total execution time: 0.0207
ERROR - 2020-10-06 17:59:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:34 --> Config Class Initialized
INFO - 2020-10-06 17:59:34 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:34 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:34 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:34 --> URI Class Initialized
INFO - 2020-10-06 17:59:34 --> Router Class Initialized
INFO - 2020-10-06 17:59:34 --> Output Class Initialized
INFO - 2020-10-06 17:59:34 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:34 --> Input Class Initialized
INFO - 2020-10-06 17:59:34 --> Language Class Initialized
INFO - 2020-10-06 17:59:34 --> Loader Class Initialized
INFO - 2020-10-06 17:59:34 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:34 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:34 --> Email Class Initialized
INFO - 2020-10-06 17:59:34 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:34 --> Model Class Initialized
INFO - 2020-10-06 17:59:34 --> Model Class Initialized
INFO - 2020-10-06 17:59:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 17:59:34 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:34 --> Total execution time: 0.0243
ERROR - 2020-10-06 17:59:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:45 --> Config Class Initialized
INFO - 2020-10-06 17:59:45 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:45 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:45 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:45 --> URI Class Initialized
INFO - 2020-10-06 17:59:45 --> Router Class Initialized
INFO - 2020-10-06 17:59:45 --> Output Class Initialized
INFO - 2020-10-06 17:59:45 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:45 --> Input Class Initialized
INFO - 2020-10-06 17:59:45 --> Language Class Initialized
INFO - 2020-10-06 17:59:45 --> Loader Class Initialized
INFO - 2020-10-06 17:59:45 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:45 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:45 --> Email Class Initialized
INFO - 2020-10-06 17:59:45 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:45 --> Model Class Initialized
INFO - 2020-10-06 17:59:45 --> Model Class Initialized
INFO - 2020-10-06 17:59:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:59:45 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:45 --> Total execution time: 0.0231
ERROR - 2020-10-06 17:59:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:48 --> Config Class Initialized
INFO - 2020-10-06 17:59:48 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:48 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:48 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:48 --> URI Class Initialized
INFO - 2020-10-06 17:59:48 --> Router Class Initialized
INFO - 2020-10-06 17:59:48 --> Output Class Initialized
INFO - 2020-10-06 17:59:48 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:48 --> Input Class Initialized
INFO - 2020-10-06 17:59:48 --> Language Class Initialized
INFO - 2020-10-06 17:59:48 --> Loader Class Initialized
INFO - 2020-10-06 17:59:48 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:48 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:48 --> Email Class Initialized
INFO - 2020-10-06 17:59:48 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:48 --> Model Class Initialized
INFO - 2020-10-06 17:59:48 --> Model Class Initialized
INFO - 2020-10-06 17:59:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 17:59:48 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:48 --> Total execution time: 0.0254
ERROR - 2020-10-06 17:59:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 17:59:57 --> Config Class Initialized
INFO - 2020-10-06 17:59:57 --> Hooks Class Initialized
DEBUG - 2020-10-06 17:59:57 --> UTF-8 Support Enabled
INFO - 2020-10-06 17:59:57 --> Utf8 Class Initialized
INFO - 2020-10-06 17:59:57 --> URI Class Initialized
INFO - 2020-10-06 17:59:57 --> Router Class Initialized
INFO - 2020-10-06 17:59:57 --> Output Class Initialized
INFO - 2020-10-06 17:59:57 --> Security Class Initialized
DEBUG - 2020-10-06 17:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 17:59:57 --> Input Class Initialized
INFO - 2020-10-06 17:59:57 --> Language Class Initialized
INFO - 2020-10-06 17:59:57 --> Loader Class Initialized
INFO - 2020-10-06 17:59:57 --> Helper loaded: url_helper
INFO - 2020-10-06 17:59:57 --> Database Driver Class Initialized
INFO - 2020-10-06 17:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 17:59:57 --> Email Class Initialized
INFO - 2020-10-06 17:59:57 --> Controller Class Initialized
DEBUG - 2020-10-06 17:59:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 17:59:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 17:59:57 --> Model Class Initialized
INFO - 2020-10-06 17:59:57 --> Model Class Initialized
INFO - 2020-10-06 17:59:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 17:59:57 --> Final output sent to browser
DEBUG - 2020-10-06 17:59:57 --> Total execution time: 0.0245
ERROR - 2020-10-06 18:00:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:00:29 --> Config Class Initialized
INFO - 2020-10-06 18:00:29 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:00:29 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:00:29 --> Utf8 Class Initialized
INFO - 2020-10-06 18:00:29 --> URI Class Initialized
INFO - 2020-10-06 18:00:29 --> Router Class Initialized
INFO - 2020-10-06 18:00:29 --> Output Class Initialized
INFO - 2020-10-06 18:00:29 --> Security Class Initialized
DEBUG - 2020-10-06 18:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:00:29 --> Input Class Initialized
INFO - 2020-10-06 18:00:29 --> Language Class Initialized
INFO - 2020-10-06 18:00:29 --> Loader Class Initialized
INFO - 2020-10-06 18:00:29 --> Helper loaded: url_helper
INFO - 2020-10-06 18:00:29 --> Database Driver Class Initialized
INFO - 2020-10-06 18:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:00:29 --> Email Class Initialized
INFO - 2020-10-06 18:00:29 --> Controller Class Initialized
DEBUG - 2020-10-06 18:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:00:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:00:29 --> Model Class Initialized
INFO - 2020-10-06 18:00:29 --> Model Class Initialized
INFO - 2020-10-06 18:00:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:00:29 --> Final output sent to browser
DEBUG - 2020-10-06 18:00:29 --> Total execution time: 0.0266
ERROR - 2020-10-06 18:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:00:41 --> Config Class Initialized
INFO - 2020-10-06 18:00:41 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:00:41 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:00:41 --> Utf8 Class Initialized
INFO - 2020-10-06 18:00:41 --> URI Class Initialized
INFO - 2020-10-06 18:00:41 --> Router Class Initialized
INFO - 2020-10-06 18:00:41 --> Output Class Initialized
INFO - 2020-10-06 18:00:41 --> Security Class Initialized
DEBUG - 2020-10-06 18:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:00:41 --> Input Class Initialized
INFO - 2020-10-06 18:00:41 --> Language Class Initialized
INFO - 2020-10-06 18:00:41 --> Loader Class Initialized
INFO - 2020-10-06 18:00:41 --> Helper loaded: url_helper
INFO - 2020-10-06 18:00:41 --> Database Driver Class Initialized
INFO - 2020-10-06 18:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:00:41 --> Email Class Initialized
INFO - 2020-10-06 18:00:41 --> Controller Class Initialized
DEBUG - 2020-10-06 18:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:00:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:00:41 --> Model Class Initialized
INFO - 2020-10-06 18:00:41 --> Model Class Initialized
INFO - 2020-10-06 18:00:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:00:41 --> Final output sent to browser
DEBUG - 2020-10-06 18:00:41 --> Total execution time: 0.0214
ERROR - 2020-10-06 18:00:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:00:43 --> Config Class Initialized
INFO - 2020-10-06 18:00:43 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:00:43 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:00:43 --> Utf8 Class Initialized
INFO - 2020-10-06 18:00:43 --> URI Class Initialized
INFO - 2020-10-06 18:00:43 --> Router Class Initialized
INFO - 2020-10-06 18:00:43 --> Output Class Initialized
INFO - 2020-10-06 18:00:43 --> Security Class Initialized
DEBUG - 2020-10-06 18:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:00:43 --> Input Class Initialized
INFO - 2020-10-06 18:00:43 --> Language Class Initialized
INFO - 2020-10-06 18:00:43 --> Loader Class Initialized
INFO - 2020-10-06 18:00:43 --> Helper loaded: url_helper
INFO - 2020-10-06 18:00:43 --> Database Driver Class Initialized
INFO - 2020-10-06 18:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:00:43 --> Email Class Initialized
INFO - 2020-10-06 18:00:43 --> Controller Class Initialized
DEBUG - 2020-10-06 18:00:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:00:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:00:43 --> Model Class Initialized
INFO - 2020-10-06 18:00:43 --> Model Class Initialized
INFO - 2020-10-06 18:00:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:00:43 --> Final output sent to browser
DEBUG - 2020-10-06 18:00:43 --> Total execution time: 0.0221
ERROR - 2020-10-06 18:00:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:00:48 --> Config Class Initialized
INFO - 2020-10-06 18:00:48 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:00:48 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:00:48 --> Utf8 Class Initialized
INFO - 2020-10-06 18:00:48 --> URI Class Initialized
INFO - 2020-10-06 18:00:48 --> Router Class Initialized
INFO - 2020-10-06 18:00:48 --> Output Class Initialized
INFO - 2020-10-06 18:00:48 --> Security Class Initialized
DEBUG - 2020-10-06 18:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:00:48 --> Input Class Initialized
INFO - 2020-10-06 18:00:48 --> Language Class Initialized
INFO - 2020-10-06 18:00:48 --> Loader Class Initialized
INFO - 2020-10-06 18:00:48 --> Helper loaded: url_helper
INFO - 2020-10-06 18:00:48 --> Database Driver Class Initialized
INFO - 2020-10-06 18:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:00:48 --> Email Class Initialized
INFO - 2020-10-06 18:00:48 --> Controller Class Initialized
DEBUG - 2020-10-06 18:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:00:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:00:48 --> Model Class Initialized
INFO - 2020-10-06 18:00:48 --> Model Class Initialized
INFO - 2020-10-06 18:00:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:00:48 --> Final output sent to browser
DEBUG - 2020-10-06 18:00:48 --> Total execution time: 0.0228
ERROR - 2020-10-06 18:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:01:04 --> Config Class Initialized
INFO - 2020-10-06 18:01:04 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:01:04 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:01:04 --> Utf8 Class Initialized
INFO - 2020-10-06 18:01:04 --> URI Class Initialized
INFO - 2020-10-06 18:01:04 --> Router Class Initialized
INFO - 2020-10-06 18:01:04 --> Output Class Initialized
INFO - 2020-10-06 18:01:04 --> Security Class Initialized
DEBUG - 2020-10-06 18:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:01:04 --> Input Class Initialized
INFO - 2020-10-06 18:01:04 --> Language Class Initialized
INFO - 2020-10-06 18:01:04 --> Loader Class Initialized
INFO - 2020-10-06 18:01:04 --> Helper loaded: url_helper
INFO - 2020-10-06 18:01:04 --> Database Driver Class Initialized
INFO - 2020-10-06 18:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:01:04 --> Email Class Initialized
INFO - 2020-10-06 18:01:04 --> Controller Class Initialized
DEBUG - 2020-10-06 18:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:01:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:01:04 --> Model Class Initialized
INFO - 2020-10-06 18:01:04 --> Model Class Initialized
INFO - 2020-10-06 18:01:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:01:04 --> Final output sent to browser
DEBUG - 2020-10-06 18:01:04 --> Total execution time: 0.0270
ERROR - 2020-10-06 18:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:05:09 --> Config Class Initialized
INFO - 2020-10-06 18:05:09 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:05:09 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:05:09 --> Utf8 Class Initialized
INFO - 2020-10-06 18:05:09 --> URI Class Initialized
DEBUG - 2020-10-06 18:05:09 --> No URI present. Default controller set.
INFO - 2020-10-06 18:05:09 --> Router Class Initialized
INFO - 2020-10-06 18:05:09 --> Output Class Initialized
INFO - 2020-10-06 18:05:09 --> Security Class Initialized
DEBUG - 2020-10-06 18:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:05:09 --> Input Class Initialized
INFO - 2020-10-06 18:05:09 --> Language Class Initialized
INFO - 2020-10-06 18:05:09 --> Loader Class Initialized
INFO - 2020-10-06 18:05:09 --> Helper loaded: url_helper
INFO - 2020-10-06 18:05:09 --> Database Driver Class Initialized
INFO - 2020-10-06 18:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:05:09 --> Email Class Initialized
INFO - 2020-10-06 18:05:09 --> Controller Class Initialized
INFO - 2020-10-06 18:05:09 --> Model Class Initialized
INFO - 2020-10-06 18:05:09 --> Model Class Initialized
DEBUG - 2020-10-06 18:05:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:05:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:05:09 --> Final output sent to browser
DEBUG - 2020-10-06 18:05:09 --> Total execution time: 0.0184
ERROR - 2020-10-06 18:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:12:58 --> Config Class Initialized
INFO - 2020-10-06 18:12:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:12:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:12:58 --> Utf8 Class Initialized
INFO - 2020-10-06 18:12:58 --> URI Class Initialized
INFO - 2020-10-06 18:12:58 --> Router Class Initialized
INFO - 2020-10-06 18:12:58 --> Output Class Initialized
INFO - 2020-10-06 18:12:58 --> Security Class Initialized
DEBUG - 2020-10-06 18:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:12:58 --> Input Class Initialized
INFO - 2020-10-06 18:12:58 --> Language Class Initialized
INFO - 2020-10-06 18:12:58 --> Loader Class Initialized
INFO - 2020-10-06 18:12:58 --> Helper loaded: url_helper
INFO - 2020-10-06 18:12:58 --> Database Driver Class Initialized
INFO - 2020-10-06 18:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:12:58 --> Email Class Initialized
INFO - 2020-10-06 18:12:58 --> Controller Class Initialized
INFO - 2020-10-06 18:12:58 --> Model Class Initialized
INFO - 2020-10-06 18:12:58 --> Model Class Initialized
DEBUG - 2020-10-06 18:12:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:12:58 --> Config Class Initialized
INFO - 2020-10-06 18:12:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:12:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:12:58 --> Utf8 Class Initialized
INFO - 2020-10-06 18:12:58 --> URI Class Initialized
INFO - 2020-10-06 18:12:58 --> Router Class Initialized
INFO - 2020-10-06 18:12:58 --> Output Class Initialized
INFO - 2020-10-06 18:12:58 --> Security Class Initialized
DEBUG - 2020-10-06 18:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:12:58 --> Input Class Initialized
INFO - 2020-10-06 18:12:58 --> Language Class Initialized
INFO - 2020-10-06 18:12:58 --> Loader Class Initialized
INFO - 2020-10-06 18:12:58 --> Helper loaded: url_helper
INFO - 2020-10-06 18:12:58 --> Database Driver Class Initialized
INFO - 2020-10-06 18:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:12:58 --> Email Class Initialized
INFO - 2020-10-06 18:12:58 --> Controller Class Initialized
INFO - 2020-10-06 18:12:58 --> Model Class Initialized
INFO - 2020-10-06 18:12:58 --> Model Class Initialized
DEBUG - 2020-10-06 18:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:12:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:12:58 --> Model Class Initialized
INFO - 2020-10-06 18:12:59 --> Final output sent to browser
DEBUG - 2020-10-06 18:12:59 --> Total execution time: 0.0262
ERROR - 2020-10-06 18:12:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:12:59 --> Config Class Initialized
INFO - 2020-10-06 18:12:59 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:12:59 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:12:59 --> Utf8 Class Initialized
INFO - 2020-10-06 18:12:59 --> URI Class Initialized
INFO - 2020-10-06 18:12:59 --> Router Class Initialized
INFO - 2020-10-06 18:12:59 --> Output Class Initialized
INFO - 2020-10-06 18:12:59 --> Security Class Initialized
DEBUG - 2020-10-06 18:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:12:59 --> Input Class Initialized
INFO - 2020-10-06 18:12:59 --> Language Class Initialized
INFO - 2020-10-06 18:12:59 --> Loader Class Initialized
INFO - 2020-10-06 18:12:59 --> Helper loaded: url_helper
INFO - 2020-10-06 18:12:59 --> Database Driver Class Initialized
INFO - 2020-10-06 18:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:12:59 --> Email Class Initialized
INFO - 2020-10-06 18:12:59 --> Controller Class Initialized
DEBUG - 2020-10-06 18:12:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:12:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:12:59 --> Model Class Initialized
INFO - 2020-10-06 18:12:59 --> Model Class Initialized
INFO - 2020-10-06 18:12:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:12:59 --> Final output sent to browser
DEBUG - 2020-10-06 18:12:59 --> Total execution time: 0.0265
ERROR - 2020-10-06 18:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:14:28 --> Config Class Initialized
INFO - 2020-10-06 18:14:28 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:14:28 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:14:28 --> Utf8 Class Initialized
INFO - 2020-10-06 18:14:28 --> URI Class Initialized
INFO - 2020-10-06 18:14:28 --> Router Class Initialized
INFO - 2020-10-06 18:14:28 --> Output Class Initialized
INFO - 2020-10-06 18:14:28 --> Security Class Initialized
DEBUG - 2020-10-06 18:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:14:28 --> Input Class Initialized
INFO - 2020-10-06 18:14:28 --> Language Class Initialized
INFO - 2020-10-06 18:14:28 --> Loader Class Initialized
INFO - 2020-10-06 18:14:28 --> Helper loaded: url_helper
INFO - 2020-10-06 18:14:28 --> Database Driver Class Initialized
INFO - 2020-10-06 18:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:14:28 --> Email Class Initialized
INFO - 2020-10-06 18:14:28 --> Controller Class Initialized
DEBUG - 2020-10-06 18:14:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:14:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:14:28 --> Model Class Initialized
INFO - 2020-10-06 18:14:28 --> Model Class Initialized
INFO - 2020-10-06 18:14:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:14:28 --> Final output sent to browser
DEBUG - 2020-10-06 18:14:28 --> Total execution time: 0.0362
ERROR - 2020-10-06 18:14:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:14:38 --> Config Class Initialized
INFO - 2020-10-06 18:14:38 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:14:38 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:14:38 --> Utf8 Class Initialized
INFO - 2020-10-06 18:14:38 --> URI Class Initialized
DEBUG - 2020-10-06 18:14:38 --> No URI present. Default controller set.
INFO - 2020-10-06 18:14:38 --> Router Class Initialized
INFO - 2020-10-06 18:14:38 --> Output Class Initialized
INFO - 2020-10-06 18:14:38 --> Security Class Initialized
DEBUG - 2020-10-06 18:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:14:38 --> Input Class Initialized
INFO - 2020-10-06 18:14:38 --> Language Class Initialized
INFO - 2020-10-06 18:14:38 --> Loader Class Initialized
INFO - 2020-10-06 18:14:38 --> Helper loaded: url_helper
INFO - 2020-10-06 18:14:38 --> Database Driver Class Initialized
INFO - 2020-10-06 18:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:14:39 --> Email Class Initialized
INFO - 2020-10-06 18:14:39 --> Controller Class Initialized
INFO - 2020-10-06 18:14:39 --> Model Class Initialized
INFO - 2020-10-06 18:14:39 --> Model Class Initialized
DEBUG - 2020-10-06 18:14:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:14:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:14:39 --> Final output sent to browser
DEBUG - 2020-10-06 18:14:39 --> Total execution time: 0.0220
ERROR - 2020-10-06 18:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:09 --> Config Class Initialized
INFO - 2020-10-06 18:15:09 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:09 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:09 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:09 --> URI Class Initialized
INFO - 2020-10-06 18:15:09 --> Router Class Initialized
INFO - 2020-10-06 18:15:09 --> Output Class Initialized
INFO - 2020-10-06 18:15:09 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:09 --> Input Class Initialized
INFO - 2020-10-06 18:15:09 --> Language Class Initialized
INFO - 2020-10-06 18:15:09 --> Loader Class Initialized
INFO - 2020-10-06 18:15:09 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:09 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:09 --> Email Class Initialized
INFO - 2020-10-06 18:15:09 --> Controller Class Initialized
INFO - 2020-10-06 18:15:09 --> Model Class Initialized
INFO - 2020-10-06 18:15:09 --> Model Class Initialized
DEBUG - 2020-10-06 18:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:09 --> Model Class Initialized
INFO - 2020-10-06 18:15:09 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:09 --> Total execution time: 0.0225
ERROR - 2020-10-06 18:15:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:10 --> Config Class Initialized
INFO - 2020-10-06 18:15:10 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:10 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:10 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:10 --> URI Class Initialized
INFO - 2020-10-06 18:15:10 --> Router Class Initialized
INFO - 2020-10-06 18:15:10 --> Output Class Initialized
INFO - 2020-10-06 18:15:10 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:10 --> Input Class Initialized
INFO - 2020-10-06 18:15:10 --> Language Class Initialized
INFO - 2020-10-06 18:15:10 --> Loader Class Initialized
INFO - 2020-10-06 18:15:10 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:10 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:10 --> Email Class Initialized
INFO - 2020-10-06 18:15:10 --> Controller Class Initialized
INFO - 2020-10-06 18:15:10 --> Model Class Initialized
INFO - 2020-10-06 18:15:10 --> Model Class Initialized
DEBUG - 2020-10-06 18:15:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:15:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:10 --> Config Class Initialized
INFO - 2020-10-06 18:15:10 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:10 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:10 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:10 --> URI Class Initialized
INFO - 2020-10-06 18:15:10 --> Router Class Initialized
INFO - 2020-10-06 18:15:10 --> Output Class Initialized
INFO - 2020-10-06 18:15:10 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:10 --> Input Class Initialized
INFO - 2020-10-06 18:15:10 --> Language Class Initialized
INFO - 2020-10-06 18:15:10 --> Loader Class Initialized
INFO - 2020-10-06 18:15:10 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:10 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:10 --> Email Class Initialized
INFO - 2020-10-06 18:15:10 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:10 --> Model Class Initialized
INFO - 2020-10-06 18:15:10 --> Model Class Initialized
INFO - 2020-10-06 18:15:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:15:10 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:10 --> Total execution time: 0.0239
ERROR - 2020-10-06 18:15:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:19 --> Config Class Initialized
INFO - 2020-10-06 18:15:19 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:19 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:19 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:19 --> URI Class Initialized
INFO - 2020-10-06 18:15:19 --> Router Class Initialized
INFO - 2020-10-06 18:15:19 --> Output Class Initialized
INFO - 2020-10-06 18:15:19 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:19 --> Input Class Initialized
INFO - 2020-10-06 18:15:19 --> Language Class Initialized
INFO - 2020-10-06 18:15:19 --> Loader Class Initialized
INFO - 2020-10-06 18:15:19 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:19 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:19 --> Email Class Initialized
INFO - 2020-10-06 18:15:19 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:19 --> Model Class Initialized
INFO - 2020-10-06 18:15:19 --> Model Class Initialized
INFO - 2020-10-06 18:15:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:15:19 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:19 --> Total execution time: 0.0265
ERROR - 2020-10-06 18:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:31 --> Config Class Initialized
INFO - 2020-10-06 18:15:31 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:31 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:31 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:31 --> URI Class Initialized
INFO - 2020-10-06 18:15:31 --> Router Class Initialized
INFO - 2020-10-06 18:15:31 --> Output Class Initialized
INFO - 2020-10-06 18:15:31 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:31 --> Input Class Initialized
INFO - 2020-10-06 18:15:31 --> Language Class Initialized
INFO - 2020-10-06 18:15:31 --> Loader Class Initialized
INFO - 2020-10-06 18:15:31 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:31 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:31 --> Email Class Initialized
INFO - 2020-10-06 18:15:31 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:31 --> Model Class Initialized
INFO - 2020-10-06 18:15:31 --> Model Class Initialized
INFO - 2020-10-06 18:15:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:15:31 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:31 --> Total execution time: 0.0254
ERROR - 2020-10-06 18:15:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:37 --> Config Class Initialized
INFO - 2020-10-06 18:15:37 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:37 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:37 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:37 --> URI Class Initialized
INFO - 2020-10-06 18:15:37 --> Router Class Initialized
INFO - 2020-10-06 18:15:37 --> Output Class Initialized
INFO - 2020-10-06 18:15:37 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:37 --> Input Class Initialized
INFO - 2020-10-06 18:15:37 --> Language Class Initialized
INFO - 2020-10-06 18:15:37 --> Loader Class Initialized
INFO - 2020-10-06 18:15:37 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:37 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:37 --> Email Class Initialized
INFO - 2020-10-06 18:15:37 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:37 --> Model Class Initialized
INFO - 2020-10-06 18:15:37 --> Model Class Initialized
INFO - 2020-10-06 18:15:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:15:37 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:37 --> Total execution time: 0.0266
ERROR - 2020-10-06 18:15:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:41 --> Config Class Initialized
INFO - 2020-10-06 18:15:41 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:41 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:41 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:41 --> URI Class Initialized
INFO - 2020-10-06 18:15:41 --> Router Class Initialized
INFO - 2020-10-06 18:15:41 --> Output Class Initialized
INFO - 2020-10-06 18:15:41 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:41 --> Input Class Initialized
INFO - 2020-10-06 18:15:41 --> Language Class Initialized
INFO - 2020-10-06 18:15:41 --> Loader Class Initialized
INFO - 2020-10-06 18:15:41 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:41 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:41 --> Email Class Initialized
INFO - 2020-10-06 18:15:41 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:41 --> Model Class Initialized
INFO - 2020-10-06 18:15:41 --> Model Class Initialized
INFO - 2020-10-06 18:15:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:15:41 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:41 --> Total execution time: 0.0259
ERROR - 2020-10-06 18:15:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:46 --> Config Class Initialized
INFO - 2020-10-06 18:15:46 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:46 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:46 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:46 --> URI Class Initialized
INFO - 2020-10-06 18:15:46 --> Router Class Initialized
INFO - 2020-10-06 18:15:46 --> Output Class Initialized
INFO - 2020-10-06 18:15:46 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:46 --> Input Class Initialized
INFO - 2020-10-06 18:15:46 --> Language Class Initialized
INFO - 2020-10-06 18:15:46 --> Loader Class Initialized
INFO - 2020-10-06 18:15:46 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:46 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:47 --> Email Class Initialized
INFO - 2020-10-06 18:15:47 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:47 --> Model Class Initialized
INFO - 2020-10-06 18:15:47 --> Model Class Initialized
INFO - 2020-10-06 18:15:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:15:47 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:47 --> Total execution time: 0.0291
ERROR - 2020-10-06 18:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:15:50 --> Config Class Initialized
INFO - 2020-10-06 18:15:50 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:15:50 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:15:50 --> Utf8 Class Initialized
INFO - 2020-10-06 18:15:50 --> URI Class Initialized
INFO - 2020-10-06 18:15:50 --> Router Class Initialized
INFO - 2020-10-06 18:15:50 --> Output Class Initialized
INFO - 2020-10-06 18:15:50 --> Security Class Initialized
DEBUG - 2020-10-06 18:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:15:50 --> Input Class Initialized
INFO - 2020-10-06 18:15:50 --> Language Class Initialized
INFO - 2020-10-06 18:15:50 --> Loader Class Initialized
INFO - 2020-10-06 18:15:50 --> Helper loaded: url_helper
INFO - 2020-10-06 18:15:50 --> Database Driver Class Initialized
INFO - 2020-10-06 18:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:15:50 --> Email Class Initialized
INFO - 2020-10-06 18:15:50 --> Controller Class Initialized
DEBUG - 2020-10-06 18:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:15:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:15:50 --> Model Class Initialized
INFO - 2020-10-06 18:15:50 --> Model Class Initialized
INFO - 2020-10-06 18:15:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:15:50 --> Final output sent to browser
DEBUG - 2020-10-06 18:15:50 --> Total execution time: 0.0252
ERROR - 2020-10-06 18:16:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:16:52 --> Config Class Initialized
INFO - 2020-10-06 18:16:52 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:16:52 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:16:52 --> Utf8 Class Initialized
INFO - 2020-10-06 18:16:52 --> URI Class Initialized
INFO - 2020-10-06 18:16:52 --> Router Class Initialized
INFO - 2020-10-06 18:16:52 --> Output Class Initialized
INFO - 2020-10-06 18:16:52 --> Security Class Initialized
DEBUG - 2020-10-06 18:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:16:52 --> Input Class Initialized
INFO - 2020-10-06 18:16:52 --> Language Class Initialized
INFO - 2020-10-06 18:16:52 --> Loader Class Initialized
INFO - 2020-10-06 18:16:52 --> Helper loaded: url_helper
INFO - 2020-10-06 18:16:52 --> Database Driver Class Initialized
INFO - 2020-10-06 18:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:16:52 --> Email Class Initialized
INFO - 2020-10-06 18:16:52 --> Controller Class Initialized
DEBUG - 2020-10-06 18:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:16:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:16:52 --> Model Class Initialized
INFO - 2020-10-06 18:16:52 --> Model Class Initialized
INFO - 2020-10-06 18:16:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 18:16:52 --> Final output sent to browser
DEBUG - 2020-10-06 18:16:52 --> Total execution time: 0.0228
ERROR - 2020-10-06 18:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:06 --> Config Class Initialized
INFO - 2020-10-06 18:17:06 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:06 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:06 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:06 --> URI Class Initialized
DEBUG - 2020-10-06 18:17:06 --> No URI present. Default controller set.
INFO - 2020-10-06 18:17:06 --> Router Class Initialized
INFO - 2020-10-06 18:17:06 --> Output Class Initialized
INFO - 2020-10-06 18:17:06 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:06 --> Input Class Initialized
INFO - 2020-10-06 18:17:06 --> Language Class Initialized
INFO - 2020-10-06 18:17:06 --> Loader Class Initialized
INFO - 2020-10-06 18:17:06 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:06 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:06 --> Email Class Initialized
INFO - 2020-10-06 18:17:06 --> Controller Class Initialized
INFO - 2020-10-06 18:17:06 --> Model Class Initialized
INFO - 2020-10-06 18:17:06 --> Model Class Initialized
DEBUG - 2020-10-06 18:17:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:17:06 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:06 --> Total execution time: 0.0175
ERROR - 2020-10-06 18:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:20 --> Config Class Initialized
INFO - 2020-10-06 18:17:20 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:20 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:20 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:20 --> URI Class Initialized
INFO - 2020-10-06 18:17:20 --> Router Class Initialized
INFO - 2020-10-06 18:17:20 --> Output Class Initialized
INFO - 2020-10-06 18:17:20 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:20 --> Input Class Initialized
INFO - 2020-10-06 18:17:20 --> Language Class Initialized
INFO - 2020-10-06 18:17:21 --> Loader Class Initialized
INFO - 2020-10-06 18:17:21 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:21 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:21 --> Email Class Initialized
INFO - 2020-10-06 18:17:21 --> Controller Class Initialized
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
DEBUG - 2020-10-06 18:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:17:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
INFO - 2020-10-06 18:17:21 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:21 --> Total execution time: 0.0211
ERROR - 2020-10-06 18:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:21 --> Config Class Initialized
INFO - 2020-10-06 18:17:21 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:21 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:21 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:21 --> URI Class Initialized
INFO - 2020-10-06 18:17:21 --> Router Class Initialized
INFO - 2020-10-06 18:17:21 --> Output Class Initialized
INFO - 2020-10-06 18:17:21 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:21 --> Input Class Initialized
INFO - 2020-10-06 18:17:21 --> Language Class Initialized
INFO - 2020-10-06 18:17:21 --> Loader Class Initialized
INFO - 2020-10-06 18:17:21 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:21 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:21 --> Email Class Initialized
INFO - 2020-10-06 18:17:21 --> Controller Class Initialized
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
DEBUG - 2020-10-06 18:17:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:17:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:21 --> Config Class Initialized
INFO - 2020-10-06 18:17:21 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:21 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:21 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:21 --> URI Class Initialized
INFO - 2020-10-06 18:17:21 --> Router Class Initialized
INFO - 2020-10-06 18:17:21 --> Output Class Initialized
INFO - 2020-10-06 18:17:21 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:21 --> Input Class Initialized
INFO - 2020-10-06 18:17:21 --> Language Class Initialized
INFO - 2020-10-06 18:17:21 --> Loader Class Initialized
INFO - 2020-10-06 18:17:21 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:21 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:21 --> Email Class Initialized
INFO - 2020-10-06 18:17:21 --> Controller Class Initialized
DEBUG - 2020-10-06 18:17:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:17:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
INFO - 2020-10-06 18:17:21 --> Model Class Initialized
INFO - 2020-10-06 18:17:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:17:21 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:21 --> Total execution time: 0.0227
ERROR - 2020-10-06 18:17:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:27 --> Config Class Initialized
INFO - 2020-10-06 18:17:27 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:27 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:27 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:27 --> URI Class Initialized
INFO - 2020-10-06 18:17:27 --> Router Class Initialized
INFO - 2020-10-06 18:17:27 --> Output Class Initialized
INFO - 2020-10-06 18:17:27 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:27 --> Input Class Initialized
INFO - 2020-10-06 18:17:27 --> Language Class Initialized
INFO - 2020-10-06 18:17:27 --> Loader Class Initialized
INFO - 2020-10-06 18:17:27 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:27 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:27 --> Email Class Initialized
INFO - 2020-10-06 18:17:27 --> Controller Class Initialized
DEBUG - 2020-10-06 18:17:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:17:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:27 --> Model Class Initialized
INFO - 2020-10-06 18:17:27 --> Model Class Initialized
INFO - 2020-10-06 18:17:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:17:27 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:27 --> Total execution time: 0.0249
ERROR - 2020-10-06 18:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:51 --> Config Class Initialized
INFO - 2020-10-06 18:17:51 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:51 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:51 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:51 --> URI Class Initialized
INFO - 2020-10-06 18:17:51 --> Router Class Initialized
INFO - 2020-10-06 18:17:51 --> Output Class Initialized
INFO - 2020-10-06 18:17:51 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:51 --> Input Class Initialized
INFO - 2020-10-06 18:17:51 --> Language Class Initialized
INFO - 2020-10-06 18:17:51 --> Loader Class Initialized
INFO - 2020-10-06 18:17:51 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:51 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:51 --> Email Class Initialized
INFO - 2020-10-06 18:17:51 --> Controller Class Initialized
DEBUG - 2020-10-06 18:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:17:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:51 --> Model Class Initialized
INFO - 2020-10-06 18:17:51 --> Model Class Initialized
INFO - 2020-10-06 18:17:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:17:51 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:51 --> Total execution time: 0.0222
ERROR - 2020-10-06 18:17:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:55 --> Config Class Initialized
INFO - 2020-10-06 18:17:55 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:55 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:55 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:55 --> URI Class Initialized
INFO - 2020-10-06 18:17:55 --> Router Class Initialized
INFO - 2020-10-06 18:17:55 --> Output Class Initialized
INFO - 2020-10-06 18:17:55 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:55 --> Input Class Initialized
INFO - 2020-10-06 18:17:55 --> Language Class Initialized
INFO - 2020-10-06 18:17:55 --> Loader Class Initialized
INFO - 2020-10-06 18:17:55 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:55 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:55 --> Email Class Initialized
INFO - 2020-10-06 18:17:55 --> Controller Class Initialized
DEBUG - 2020-10-06 18:17:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:17:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:55 --> Model Class Initialized
INFO - 2020-10-06 18:17:55 --> Model Class Initialized
INFO - 2020-10-06 18:17:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:17:55 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:55 --> Total execution time: 0.2542
ERROR - 2020-10-06 18:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:17:57 --> Config Class Initialized
INFO - 2020-10-06 18:17:57 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:17:57 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:17:57 --> Utf8 Class Initialized
INFO - 2020-10-06 18:17:57 --> URI Class Initialized
INFO - 2020-10-06 18:17:57 --> Router Class Initialized
INFO - 2020-10-06 18:17:57 --> Output Class Initialized
INFO - 2020-10-06 18:17:57 --> Security Class Initialized
DEBUG - 2020-10-06 18:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:17:57 --> Input Class Initialized
INFO - 2020-10-06 18:17:57 --> Language Class Initialized
INFO - 2020-10-06 18:17:57 --> Loader Class Initialized
INFO - 2020-10-06 18:17:57 --> Helper loaded: url_helper
INFO - 2020-10-06 18:17:57 --> Database Driver Class Initialized
INFO - 2020-10-06 18:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:17:57 --> Email Class Initialized
INFO - 2020-10-06 18:17:57 --> Controller Class Initialized
DEBUG - 2020-10-06 18:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:17:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:17:57 --> Model Class Initialized
INFO - 2020-10-06 18:17:57 --> Model Class Initialized
INFO - 2020-10-06 18:17:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:17:57 --> Final output sent to browser
DEBUG - 2020-10-06 18:17:57 --> Total execution time: 0.0218
ERROR - 2020-10-06 18:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:06 --> Config Class Initialized
INFO - 2020-10-06 18:18:06 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:06 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:06 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:06 --> URI Class Initialized
INFO - 2020-10-06 18:18:06 --> Router Class Initialized
INFO - 2020-10-06 18:18:06 --> Output Class Initialized
INFO - 2020-10-06 18:18:06 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:06 --> Input Class Initialized
INFO - 2020-10-06 18:18:06 --> Language Class Initialized
INFO - 2020-10-06 18:18:06 --> Loader Class Initialized
INFO - 2020-10-06 18:18:06 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:06 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:06 --> Email Class Initialized
INFO - 2020-10-06 18:18:06 --> Controller Class Initialized
DEBUG - 2020-10-06 18:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:18:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:06 --> Model Class Initialized
INFO - 2020-10-06 18:18:06 --> Model Class Initialized
INFO - 2020-10-06 18:18:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 18:18:06 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:06 --> Total execution time: 0.0187
ERROR - 2020-10-06 18:18:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:25 --> Config Class Initialized
INFO - 2020-10-06 18:18:25 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:25 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:25 --> URI Class Initialized
INFO - 2020-10-06 18:18:25 --> Router Class Initialized
INFO - 2020-10-06 18:18:25 --> Output Class Initialized
INFO - 2020-10-06 18:18:25 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:25 --> Input Class Initialized
INFO - 2020-10-06 18:18:25 --> Language Class Initialized
INFO - 2020-10-06 18:18:25 --> Loader Class Initialized
INFO - 2020-10-06 18:18:25 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:25 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:25 --> Email Class Initialized
INFO - 2020-10-06 18:18:25 --> Controller Class Initialized
DEBUG - 2020-10-06 18:18:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:18:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:25 --> Model Class Initialized
INFO - 2020-10-06 18:18:25 --> Model Class Initialized
INFO - 2020-10-06 18:18:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:18:25 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:25 --> Total execution time: 0.0278
ERROR - 2020-10-06 18:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:30 --> Config Class Initialized
INFO - 2020-10-06 18:18:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:30 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:30 --> URI Class Initialized
INFO - 2020-10-06 18:18:30 --> Router Class Initialized
INFO - 2020-10-06 18:18:30 --> Output Class Initialized
INFO - 2020-10-06 18:18:30 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:30 --> Input Class Initialized
INFO - 2020-10-06 18:18:30 --> Language Class Initialized
INFO - 2020-10-06 18:18:30 --> Loader Class Initialized
INFO - 2020-10-06 18:18:30 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:30 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:30 --> Email Class Initialized
INFO - 2020-10-06 18:18:30 --> Controller Class Initialized
DEBUG - 2020-10-06 18:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:18:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:30 --> Model Class Initialized
INFO - 2020-10-06 18:18:30 --> Model Class Initialized
INFO - 2020-10-06 18:18:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:18:30 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:30 --> Total execution time: 0.0206
ERROR - 2020-10-06 18:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:45 --> Config Class Initialized
INFO - 2020-10-06 18:18:45 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:45 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:45 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:45 --> URI Class Initialized
INFO - 2020-10-06 18:18:45 --> Router Class Initialized
INFO - 2020-10-06 18:18:45 --> Output Class Initialized
INFO - 2020-10-06 18:18:45 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:45 --> Input Class Initialized
INFO - 2020-10-06 18:18:45 --> Language Class Initialized
INFO - 2020-10-06 18:18:45 --> Loader Class Initialized
INFO - 2020-10-06 18:18:45 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:45 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:45 --> Email Class Initialized
INFO - 2020-10-06 18:18:45 --> Controller Class Initialized
DEBUG - 2020-10-06 18:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:18:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:45 --> Model Class Initialized
INFO - 2020-10-06 18:18:45 --> Model Class Initialized
INFO - 2020-10-06 18:18:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:18:45 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:45 --> Total execution time: 0.0202
ERROR - 2020-10-06 18:18:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:51 --> Config Class Initialized
INFO - 2020-10-06 18:18:51 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:51 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:51 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:51 --> URI Class Initialized
DEBUG - 2020-10-06 18:18:51 --> No URI present. Default controller set.
INFO - 2020-10-06 18:18:51 --> Router Class Initialized
INFO - 2020-10-06 18:18:51 --> Output Class Initialized
INFO - 2020-10-06 18:18:51 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:51 --> Input Class Initialized
INFO - 2020-10-06 18:18:51 --> Language Class Initialized
INFO - 2020-10-06 18:18:51 --> Loader Class Initialized
INFO - 2020-10-06 18:18:51 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:51 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:51 --> Email Class Initialized
INFO - 2020-10-06 18:18:51 --> Controller Class Initialized
INFO - 2020-10-06 18:18:51 --> Model Class Initialized
INFO - 2020-10-06 18:18:51 --> Model Class Initialized
DEBUG - 2020-10-06 18:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:18:51 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:51 --> Total execution time: 0.0202
ERROR - 2020-10-06 18:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:58 --> Config Class Initialized
INFO - 2020-10-06 18:18:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:58 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:58 --> URI Class Initialized
INFO - 2020-10-06 18:18:58 --> Router Class Initialized
INFO - 2020-10-06 18:18:58 --> Output Class Initialized
INFO - 2020-10-06 18:18:58 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:58 --> Input Class Initialized
INFO - 2020-10-06 18:18:58 --> Language Class Initialized
INFO - 2020-10-06 18:18:58 --> Loader Class Initialized
INFO - 2020-10-06 18:18:58 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:58 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:58 --> Email Class Initialized
INFO - 2020-10-06 18:18:58 --> Controller Class Initialized
INFO - 2020-10-06 18:18:58 --> Model Class Initialized
INFO - 2020-10-06 18:18:58 --> Model Class Initialized
DEBUG - 2020-10-06 18:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:18:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:58 --> Model Class Initialized
INFO - 2020-10-06 18:18:58 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:58 --> Total execution time: 0.0224
ERROR - 2020-10-06 18:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:58 --> Config Class Initialized
INFO - 2020-10-06 18:18:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:58 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:58 --> URI Class Initialized
INFO - 2020-10-06 18:18:58 --> Router Class Initialized
INFO - 2020-10-06 18:18:58 --> Output Class Initialized
INFO - 2020-10-06 18:18:58 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:58 --> Input Class Initialized
INFO - 2020-10-06 18:18:58 --> Language Class Initialized
INFO - 2020-10-06 18:18:58 --> Loader Class Initialized
INFO - 2020-10-06 18:18:58 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:58 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:58 --> Email Class Initialized
INFO - 2020-10-06 18:18:58 --> Controller Class Initialized
INFO - 2020-10-06 18:18:58 --> Model Class Initialized
INFO - 2020-10-06 18:18:58 --> Model Class Initialized
DEBUG - 2020-10-06 18:18:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:18:59 --> Config Class Initialized
INFO - 2020-10-06 18:18:59 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:18:59 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:18:59 --> Utf8 Class Initialized
INFO - 2020-10-06 18:18:59 --> URI Class Initialized
INFO - 2020-10-06 18:18:59 --> Router Class Initialized
INFO - 2020-10-06 18:18:59 --> Output Class Initialized
INFO - 2020-10-06 18:18:59 --> Security Class Initialized
DEBUG - 2020-10-06 18:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:18:59 --> Input Class Initialized
INFO - 2020-10-06 18:18:59 --> Language Class Initialized
INFO - 2020-10-06 18:18:59 --> Loader Class Initialized
INFO - 2020-10-06 18:18:59 --> Helper loaded: url_helper
INFO - 2020-10-06 18:18:59 --> Database Driver Class Initialized
INFO - 2020-10-06 18:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:18:59 --> Email Class Initialized
INFO - 2020-10-06 18:18:59 --> Controller Class Initialized
DEBUG - 2020-10-06 18:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:18:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:18:59 --> Model Class Initialized
INFO - 2020-10-06 18:18:59 --> Model Class Initialized
INFO - 2020-10-06 18:18:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:18:59 --> Final output sent to browser
DEBUG - 2020-10-06 18:18:59 --> Total execution time: 0.0214
ERROR - 2020-10-06 18:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:19:04 --> Config Class Initialized
INFO - 2020-10-06 18:19:04 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:19:04 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:19:04 --> Utf8 Class Initialized
INFO - 2020-10-06 18:19:04 --> URI Class Initialized
INFO - 2020-10-06 18:19:04 --> Router Class Initialized
INFO - 2020-10-06 18:19:04 --> Output Class Initialized
INFO - 2020-10-06 18:19:04 --> Security Class Initialized
DEBUG - 2020-10-06 18:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:19:04 --> Input Class Initialized
INFO - 2020-10-06 18:19:04 --> Language Class Initialized
INFO - 2020-10-06 18:19:04 --> Loader Class Initialized
INFO - 2020-10-06 18:19:04 --> Helper loaded: url_helper
INFO - 2020-10-06 18:19:04 --> Database Driver Class Initialized
INFO - 2020-10-06 18:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:19:04 --> Email Class Initialized
INFO - 2020-10-06 18:19:04 --> Controller Class Initialized
DEBUG - 2020-10-06 18:19:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:19:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:19:04 --> Model Class Initialized
INFO - 2020-10-06 18:19:04 --> Model Class Initialized
INFO - 2020-10-06 18:19:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:19:04 --> Final output sent to browser
DEBUG - 2020-10-06 18:19:04 --> Total execution time: 0.0223
ERROR - 2020-10-06 18:19:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:19:51 --> Config Class Initialized
INFO - 2020-10-06 18:19:51 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:19:51 --> Utf8 Class Initialized
INFO - 2020-10-06 18:19:51 --> URI Class Initialized
INFO - 2020-10-06 18:19:51 --> Router Class Initialized
INFO - 2020-10-06 18:19:51 --> Output Class Initialized
INFO - 2020-10-06 18:19:51 --> Security Class Initialized
DEBUG - 2020-10-06 18:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:19:51 --> Input Class Initialized
INFO - 2020-10-06 18:19:51 --> Language Class Initialized
INFO - 2020-10-06 18:19:51 --> Loader Class Initialized
INFO - 2020-10-06 18:19:51 --> Helper loaded: url_helper
INFO - 2020-10-06 18:19:51 --> Database Driver Class Initialized
INFO - 2020-10-06 18:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:19:51 --> Email Class Initialized
INFO - 2020-10-06 18:19:51 --> Controller Class Initialized
DEBUG - 2020-10-06 18:19:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:19:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:19:51 --> Model Class Initialized
INFO - 2020-10-06 18:19:51 --> Model Class Initialized
INFO - 2020-10-06 18:19:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:19:51 --> Final output sent to browser
DEBUG - 2020-10-06 18:19:51 --> Total execution time: 0.0207
ERROR - 2020-10-06 18:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:19:54 --> Config Class Initialized
INFO - 2020-10-06 18:19:54 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:19:54 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:19:54 --> Utf8 Class Initialized
INFO - 2020-10-06 18:19:54 --> URI Class Initialized
INFO - 2020-10-06 18:19:54 --> Router Class Initialized
INFO - 2020-10-06 18:19:54 --> Output Class Initialized
INFO - 2020-10-06 18:19:54 --> Security Class Initialized
DEBUG - 2020-10-06 18:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:19:54 --> Input Class Initialized
INFO - 2020-10-06 18:19:54 --> Language Class Initialized
INFO - 2020-10-06 18:19:54 --> Loader Class Initialized
INFO - 2020-10-06 18:19:54 --> Helper loaded: url_helper
INFO - 2020-10-06 18:19:54 --> Database Driver Class Initialized
INFO - 2020-10-06 18:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:19:54 --> Email Class Initialized
INFO - 2020-10-06 18:19:54 --> Controller Class Initialized
DEBUG - 2020-10-06 18:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:19:54 --> Model Class Initialized
INFO - 2020-10-06 18:19:54 --> Model Class Initialized
INFO - 2020-10-06 18:19:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 18:19:54 --> Final output sent to browser
DEBUG - 2020-10-06 18:19:54 --> Total execution time: 0.0237
ERROR - 2020-10-06 18:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:19:58 --> Config Class Initialized
INFO - 2020-10-06 18:19:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:19:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:19:58 --> Utf8 Class Initialized
INFO - 2020-10-06 18:19:58 --> URI Class Initialized
DEBUG - 2020-10-06 18:19:58 --> No URI present. Default controller set.
INFO - 2020-10-06 18:19:58 --> Router Class Initialized
INFO - 2020-10-06 18:19:58 --> Output Class Initialized
INFO - 2020-10-06 18:19:58 --> Security Class Initialized
DEBUG - 2020-10-06 18:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:19:58 --> Input Class Initialized
INFO - 2020-10-06 18:19:58 --> Language Class Initialized
INFO - 2020-10-06 18:19:58 --> Loader Class Initialized
INFO - 2020-10-06 18:19:58 --> Helper loaded: url_helper
INFO - 2020-10-06 18:19:58 --> Database Driver Class Initialized
INFO - 2020-10-06 18:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:19:58 --> Email Class Initialized
INFO - 2020-10-06 18:19:58 --> Controller Class Initialized
INFO - 2020-10-06 18:19:58 --> Model Class Initialized
INFO - 2020-10-06 18:19:58 --> Model Class Initialized
DEBUG - 2020-10-06 18:19:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:19:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:19:58 --> Final output sent to browser
DEBUG - 2020-10-06 18:19:58 --> Total execution time: 0.0263
ERROR - 2020-10-06 18:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:20:02 --> Config Class Initialized
INFO - 2020-10-06 18:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:20:02 --> Utf8 Class Initialized
INFO - 2020-10-06 18:20:02 --> URI Class Initialized
INFO - 2020-10-06 18:20:02 --> Router Class Initialized
INFO - 2020-10-06 18:20:02 --> Output Class Initialized
INFO - 2020-10-06 18:20:02 --> Security Class Initialized
DEBUG - 2020-10-06 18:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:20:02 --> Input Class Initialized
INFO - 2020-10-06 18:20:02 --> Language Class Initialized
INFO - 2020-10-06 18:20:02 --> Loader Class Initialized
INFO - 2020-10-06 18:20:02 --> Helper loaded: url_helper
INFO - 2020-10-06 18:20:02 --> Database Driver Class Initialized
INFO - 2020-10-06 18:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:20:02 --> Email Class Initialized
INFO - 2020-10-06 18:20:02 --> Controller Class Initialized
INFO - 2020-10-06 18:20:02 --> Model Class Initialized
INFO - 2020-10-06 18:20:02 --> Model Class Initialized
DEBUG - 2020-10-06 18:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:20:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:20:02 --> Model Class Initialized
INFO - 2020-10-06 18:20:02 --> Final output sent to browser
DEBUG - 2020-10-06 18:20:02 --> Total execution time: 0.0201
ERROR - 2020-10-06 18:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:20:02 --> Config Class Initialized
INFO - 2020-10-06 18:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:20:02 --> Utf8 Class Initialized
INFO - 2020-10-06 18:20:02 --> URI Class Initialized
INFO - 2020-10-06 18:20:02 --> Router Class Initialized
INFO - 2020-10-06 18:20:02 --> Output Class Initialized
INFO - 2020-10-06 18:20:02 --> Security Class Initialized
DEBUG - 2020-10-06 18:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:20:02 --> Input Class Initialized
INFO - 2020-10-06 18:20:02 --> Language Class Initialized
INFO - 2020-10-06 18:20:02 --> Loader Class Initialized
INFO - 2020-10-06 18:20:02 --> Helper loaded: url_helper
INFO - 2020-10-06 18:20:02 --> Database Driver Class Initialized
INFO - 2020-10-06 18:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:20:02 --> Email Class Initialized
INFO - 2020-10-06 18:20:02 --> Controller Class Initialized
INFO - 2020-10-06 18:20:02 --> Model Class Initialized
INFO - 2020-10-06 18:20:02 --> Model Class Initialized
DEBUG - 2020-10-06 18:20:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:20:03 --> Config Class Initialized
INFO - 2020-10-06 18:20:03 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:20:03 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:20:03 --> Utf8 Class Initialized
INFO - 2020-10-06 18:20:03 --> URI Class Initialized
INFO - 2020-10-06 18:20:03 --> Router Class Initialized
INFO - 2020-10-06 18:20:03 --> Output Class Initialized
INFO - 2020-10-06 18:20:03 --> Security Class Initialized
DEBUG - 2020-10-06 18:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:20:03 --> Input Class Initialized
INFO - 2020-10-06 18:20:03 --> Language Class Initialized
INFO - 2020-10-06 18:20:03 --> Loader Class Initialized
INFO - 2020-10-06 18:20:03 --> Helper loaded: url_helper
INFO - 2020-10-06 18:20:03 --> Database Driver Class Initialized
INFO - 2020-10-06 18:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:20:03 --> Email Class Initialized
INFO - 2020-10-06 18:20:03 --> Controller Class Initialized
DEBUG - 2020-10-06 18:20:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:20:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:20:03 --> Model Class Initialized
INFO - 2020-10-06 18:20:03 --> Model Class Initialized
INFO - 2020-10-06 18:20:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:20:03 --> Final output sent to browser
DEBUG - 2020-10-06 18:20:03 --> Total execution time: 0.0231
ERROR - 2020-10-06 18:20:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:20:05 --> Config Class Initialized
INFO - 2020-10-06 18:20:05 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:20:05 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:20:05 --> Utf8 Class Initialized
INFO - 2020-10-06 18:20:05 --> URI Class Initialized
INFO - 2020-10-06 18:20:05 --> Router Class Initialized
INFO - 2020-10-06 18:20:05 --> Output Class Initialized
INFO - 2020-10-06 18:20:05 --> Security Class Initialized
DEBUG - 2020-10-06 18:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:20:05 --> Input Class Initialized
INFO - 2020-10-06 18:20:05 --> Language Class Initialized
INFO - 2020-10-06 18:20:05 --> Loader Class Initialized
INFO - 2020-10-06 18:20:05 --> Helper loaded: url_helper
INFO - 2020-10-06 18:20:05 --> Database Driver Class Initialized
INFO - 2020-10-06 18:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:20:05 --> Email Class Initialized
INFO - 2020-10-06 18:20:05 --> Controller Class Initialized
DEBUG - 2020-10-06 18:20:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:20:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:20:05 --> Model Class Initialized
INFO - 2020-10-06 18:20:05 --> Model Class Initialized
INFO - 2020-10-06 18:20:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:20:05 --> Final output sent to browser
DEBUG - 2020-10-06 18:20:05 --> Total execution time: 0.0224
ERROR - 2020-10-06 18:25:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:00 --> Config Class Initialized
INFO - 2020-10-06 18:25:00 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:00 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:00 --> URI Class Initialized
DEBUG - 2020-10-06 18:25:00 --> No URI present. Default controller set.
INFO - 2020-10-06 18:25:00 --> Router Class Initialized
INFO - 2020-10-06 18:25:00 --> Output Class Initialized
INFO - 2020-10-06 18:25:00 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:00 --> Input Class Initialized
INFO - 2020-10-06 18:25:00 --> Language Class Initialized
INFO - 2020-10-06 18:25:00 --> Loader Class Initialized
INFO - 2020-10-06 18:25:00 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:00 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:00 --> Email Class Initialized
INFO - 2020-10-06 18:25:00 --> Controller Class Initialized
INFO - 2020-10-06 18:25:00 --> Model Class Initialized
INFO - 2020-10-06 18:25:00 --> Model Class Initialized
DEBUG - 2020-10-06 18:25:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:25:00 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:00 --> Total execution time: 0.0199
ERROR - 2020-10-06 18:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:03 --> Config Class Initialized
INFO - 2020-10-06 18:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:03 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:03 --> URI Class Initialized
INFO - 2020-10-06 18:25:03 --> Router Class Initialized
INFO - 2020-10-06 18:25:03 --> Output Class Initialized
INFO - 2020-10-06 18:25:03 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:03 --> Input Class Initialized
INFO - 2020-10-06 18:25:03 --> Language Class Initialized
INFO - 2020-10-06 18:25:03 --> Loader Class Initialized
INFO - 2020-10-06 18:25:03 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:03 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:03 --> Email Class Initialized
INFO - 2020-10-06 18:25:03 --> Controller Class Initialized
ERROR - 2020-10-06 18:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
DEBUG - 2020-10-06 18:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
INFO - 2020-10-06 18:25:03 --> Config Class Initialized
INFO - 2020-10-06 18:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:03 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:03 --> URI Class Initialized
INFO - 2020-10-06 18:25:03 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:03 --> Total execution time: 0.0236
INFO - 2020-10-06 18:25:03 --> Router Class Initialized
INFO - 2020-10-06 18:25:03 --> Output Class Initialized
INFO - 2020-10-06 18:25:03 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:03 --> Input Class Initialized
INFO - 2020-10-06 18:25:03 --> Language Class Initialized
INFO - 2020-10-06 18:25:03 --> Loader Class Initialized
INFO - 2020-10-06 18:25:03 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:03 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:03 --> Email Class Initialized
INFO - 2020-10-06 18:25:03 --> Controller Class Initialized
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
DEBUG - 2020-10-06 18:25:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:03 --> Config Class Initialized
INFO - 2020-10-06 18:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:03 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:03 --> URI Class Initialized
INFO - 2020-10-06 18:25:03 --> Router Class Initialized
INFO - 2020-10-06 18:25:03 --> Output Class Initialized
INFO - 2020-10-06 18:25:03 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:03 --> Input Class Initialized
INFO - 2020-10-06 18:25:03 --> Language Class Initialized
INFO - 2020-10-06 18:25:03 --> Loader Class Initialized
INFO - 2020-10-06 18:25:03 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:03 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:03 --> Email Class Initialized
INFO - 2020-10-06 18:25:03 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
INFO - 2020-10-06 18:25:03 --> Model Class Initialized
INFO - 2020-10-06 18:25:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:25:03 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:03 --> Total execution time: 0.0258
ERROR - 2020-10-06 18:25:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:07 --> Config Class Initialized
INFO - 2020-10-06 18:25:07 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:07 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:07 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:07 --> URI Class Initialized
INFO - 2020-10-06 18:25:07 --> Router Class Initialized
INFO - 2020-10-06 18:25:07 --> Output Class Initialized
INFO - 2020-10-06 18:25:07 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:07 --> Input Class Initialized
INFO - 2020-10-06 18:25:07 --> Language Class Initialized
INFO - 2020-10-06 18:25:07 --> Loader Class Initialized
INFO - 2020-10-06 18:25:07 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:07 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:07 --> Email Class Initialized
INFO - 2020-10-06 18:25:07 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:07 --> Model Class Initialized
INFO - 2020-10-06 18:25:07 --> Model Class Initialized
INFO - 2020-10-06 18:25:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:25:07 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:07 --> Total execution time: 0.0199
ERROR - 2020-10-06 18:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:12 --> Config Class Initialized
INFO - 2020-10-06 18:25:12 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:12 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:12 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:12 --> URI Class Initialized
INFO - 2020-10-06 18:25:12 --> Router Class Initialized
INFO - 2020-10-06 18:25:12 --> Output Class Initialized
INFO - 2020-10-06 18:25:12 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:12 --> Input Class Initialized
INFO - 2020-10-06 18:25:12 --> Language Class Initialized
INFO - 2020-10-06 18:25:12 --> Loader Class Initialized
INFO - 2020-10-06 18:25:12 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:12 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:12 --> Email Class Initialized
INFO - 2020-10-06 18:25:12 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:12 --> Model Class Initialized
INFO - 2020-10-06 18:25:12 --> Model Class Initialized
INFO - 2020-10-06 18:25:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:25:12 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:12 --> Total execution time: 0.0201
ERROR - 2020-10-06 18:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:15 --> Config Class Initialized
INFO - 2020-10-06 18:25:15 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:15 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:15 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:15 --> URI Class Initialized
INFO - 2020-10-06 18:25:15 --> Router Class Initialized
INFO - 2020-10-06 18:25:15 --> Output Class Initialized
INFO - 2020-10-06 18:25:15 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:15 --> Input Class Initialized
INFO - 2020-10-06 18:25:15 --> Language Class Initialized
INFO - 2020-10-06 18:25:15 --> Loader Class Initialized
INFO - 2020-10-06 18:25:15 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:15 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:15 --> Email Class Initialized
INFO - 2020-10-06 18:25:15 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:15 --> Model Class Initialized
INFO - 2020-10-06 18:25:15 --> Model Class Initialized
INFO - 2020-10-06 18:25:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:25:15 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:15 --> Total execution time: 0.0245
ERROR - 2020-10-06 18:25:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:18 --> Config Class Initialized
INFO - 2020-10-06 18:25:18 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:18 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:18 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:18 --> URI Class Initialized
INFO - 2020-10-06 18:25:18 --> Router Class Initialized
INFO - 2020-10-06 18:25:18 --> Output Class Initialized
INFO - 2020-10-06 18:25:18 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:18 --> Input Class Initialized
INFO - 2020-10-06 18:25:18 --> Language Class Initialized
INFO - 2020-10-06 18:25:18 --> Loader Class Initialized
INFO - 2020-10-06 18:25:18 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:18 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:18 --> Email Class Initialized
INFO - 2020-10-06 18:25:18 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:18 --> Model Class Initialized
INFO - 2020-10-06 18:25:18 --> Model Class Initialized
INFO - 2020-10-06 18:25:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:25:18 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:18 --> Total execution time: 0.0222
ERROR - 2020-10-06 18:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:22 --> Config Class Initialized
INFO - 2020-10-06 18:25:22 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:22 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:22 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:22 --> URI Class Initialized
INFO - 2020-10-06 18:25:22 --> Router Class Initialized
INFO - 2020-10-06 18:25:22 --> Output Class Initialized
INFO - 2020-10-06 18:25:22 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:22 --> Input Class Initialized
INFO - 2020-10-06 18:25:22 --> Language Class Initialized
INFO - 2020-10-06 18:25:22 --> Loader Class Initialized
INFO - 2020-10-06 18:25:22 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:22 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:22 --> Email Class Initialized
INFO - 2020-10-06 18:25:22 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:22 --> Model Class Initialized
INFO - 2020-10-06 18:25:22 --> Model Class Initialized
INFO - 2020-10-06 18:25:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:25:22 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:22 --> Total execution time: 0.0247
ERROR - 2020-10-06 18:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:24 --> Config Class Initialized
INFO - 2020-10-06 18:25:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:24 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:24 --> URI Class Initialized
INFO - 2020-10-06 18:25:24 --> Router Class Initialized
INFO - 2020-10-06 18:25:24 --> Output Class Initialized
INFO - 2020-10-06 18:25:24 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:24 --> Input Class Initialized
INFO - 2020-10-06 18:25:24 --> Language Class Initialized
INFO - 2020-10-06 18:25:24 --> Loader Class Initialized
INFO - 2020-10-06 18:25:24 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:24 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:24 --> Email Class Initialized
INFO - 2020-10-06 18:25:24 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:24 --> Model Class Initialized
INFO - 2020-10-06 18:25:24 --> Model Class Initialized
INFO - 2020-10-06 18:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:25:24 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:24 --> Total execution time: 0.0176
ERROR - 2020-10-06 18:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:30 --> Config Class Initialized
INFO - 2020-10-06 18:25:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:30 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:30 --> URI Class Initialized
INFO - 2020-10-06 18:25:30 --> Router Class Initialized
INFO - 2020-10-06 18:25:30 --> Output Class Initialized
INFO - 2020-10-06 18:25:30 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:30 --> Input Class Initialized
INFO - 2020-10-06 18:25:30 --> Language Class Initialized
INFO - 2020-10-06 18:25:30 --> Loader Class Initialized
INFO - 2020-10-06 18:25:30 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:30 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:30 --> Email Class Initialized
INFO - 2020-10-06 18:25:30 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:30 --> Model Class Initialized
INFO - 2020-10-06 18:25:30 --> Model Class Initialized
INFO - 2020-10-06 18:25:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:25:30 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:30 --> Total execution time: 0.0242
ERROR - 2020-10-06 18:25:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:37 --> Config Class Initialized
INFO - 2020-10-06 18:25:37 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:37 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:37 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:37 --> URI Class Initialized
INFO - 2020-10-06 18:25:37 --> Router Class Initialized
INFO - 2020-10-06 18:25:37 --> Output Class Initialized
INFO - 2020-10-06 18:25:37 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:37 --> Input Class Initialized
INFO - 2020-10-06 18:25:37 --> Language Class Initialized
INFO - 2020-10-06 18:25:37 --> Loader Class Initialized
INFO - 2020-10-06 18:25:37 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:37 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:37 --> Email Class Initialized
INFO - 2020-10-06 18:25:37 --> Controller Class Initialized
DEBUG - 2020-10-06 18:25:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:25:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:37 --> Model Class Initialized
INFO - 2020-10-06 18:25:37 --> Model Class Initialized
INFO - 2020-10-06 18:25:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:25:37 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:37 --> Total execution time: 0.0197
ERROR - 2020-10-06 18:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:25:56 --> Config Class Initialized
INFO - 2020-10-06 18:25:56 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:25:56 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:25:56 --> Utf8 Class Initialized
INFO - 2020-10-06 18:25:56 --> URI Class Initialized
DEBUG - 2020-10-06 18:25:56 --> No URI present. Default controller set.
INFO - 2020-10-06 18:25:56 --> Router Class Initialized
INFO - 2020-10-06 18:25:56 --> Output Class Initialized
INFO - 2020-10-06 18:25:56 --> Security Class Initialized
DEBUG - 2020-10-06 18:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:25:56 --> Input Class Initialized
INFO - 2020-10-06 18:25:56 --> Language Class Initialized
INFO - 2020-10-06 18:25:56 --> Loader Class Initialized
INFO - 2020-10-06 18:25:56 --> Helper loaded: url_helper
INFO - 2020-10-06 18:25:56 --> Database Driver Class Initialized
INFO - 2020-10-06 18:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:25:56 --> Email Class Initialized
INFO - 2020-10-06 18:25:56 --> Controller Class Initialized
INFO - 2020-10-06 18:25:56 --> Model Class Initialized
INFO - 2020-10-06 18:25:56 --> Model Class Initialized
DEBUG - 2020-10-06 18:25:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:25:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:25:56 --> Final output sent to browser
DEBUG - 2020-10-06 18:25:56 --> Total execution time: 0.0178
ERROR - 2020-10-06 18:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:10 --> Config Class Initialized
INFO - 2020-10-06 18:26:10 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:10 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:10 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:10 --> URI Class Initialized
INFO - 2020-10-06 18:26:10 --> Router Class Initialized
INFO - 2020-10-06 18:26:10 --> Output Class Initialized
INFO - 2020-10-06 18:26:10 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:10 --> Input Class Initialized
INFO - 2020-10-06 18:26:10 --> Language Class Initialized
INFO - 2020-10-06 18:26:10 --> Loader Class Initialized
INFO - 2020-10-06 18:26:10 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:10 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:10 --> Email Class Initialized
INFO - 2020-10-06 18:26:10 --> Controller Class Initialized
INFO - 2020-10-06 18:26:10 --> Model Class Initialized
INFO - 2020-10-06 18:26:10 --> Model Class Initialized
DEBUG - 2020-10-06 18:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:10 --> Model Class Initialized
INFO - 2020-10-06 18:26:10 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:10 --> Total execution time: 0.0219
ERROR - 2020-10-06 18:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:10 --> Config Class Initialized
INFO - 2020-10-06 18:26:10 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:10 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:10 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:10 --> URI Class Initialized
INFO - 2020-10-06 18:26:10 --> Router Class Initialized
INFO - 2020-10-06 18:26:10 --> Output Class Initialized
INFO - 2020-10-06 18:26:10 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:10 --> Input Class Initialized
INFO - 2020-10-06 18:26:10 --> Language Class Initialized
INFO - 2020-10-06 18:26:10 --> Loader Class Initialized
INFO - 2020-10-06 18:26:10 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:10 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:10 --> Email Class Initialized
INFO - 2020-10-06 18:26:10 --> Controller Class Initialized
INFO - 2020-10-06 18:26:10 --> Model Class Initialized
INFO - 2020-10-06 18:26:10 --> Model Class Initialized
DEBUG - 2020-10-06 18:26:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:11 --> Config Class Initialized
INFO - 2020-10-06 18:26:11 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:11 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:11 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:11 --> URI Class Initialized
INFO - 2020-10-06 18:26:11 --> Router Class Initialized
INFO - 2020-10-06 18:26:11 --> Output Class Initialized
INFO - 2020-10-06 18:26:11 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:11 --> Input Class Initialized
INFO - 2020-10-06 18:26:11 --> Language Class Initialized
INFO - 2020-10-06 18:26:11 --> Loader Class Initialized
INFO - 2020-10-06 18:26:11 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:11 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:11 --> Email Class Initialized
INFO - 2020-10-06 18:26:11 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:26:11 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:11 --> Total execution time: 0.0485
ERROR - 2020-10-06 18:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:16 --> Config Class Initialized
INFO - 2020-10-06 18:26:16 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:16 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:16 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:16 --> URI Class Initialized
INFO - 2020-10-06 18:26:16 --> Router Class Initialized
INFO - 2020-10-06 18:26:16 --> Output Class Initialized
INFO - 2020-10-06 18:26:16 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:16 --> Input Class Initialized
INFO - 2020-10-06 18:26:16 --> Language Class Initialized
INFO - 2020-10-06 18:26:16 --> Loader Class Initialized
INFO - 2020-10-06 18:26:16 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:16 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:16 --> Email Class Initialized
INFO - 2020-10-06 18:26:16 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:16 --> Model Class Initialized
INFO - 2020-10-06 18:26:16 --> Model Class Initialized
INFO - 2020-10-06 18:26:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:26:16 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:16 --> Total execution time: 0.0232
ERROR - 2020-10-06 18:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:18 --> Config Class Initialized
INFO - 2020-10-06 18:26:18 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:18 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:18 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:18 --> URI Class Initialized
INFO - 2020-10-06 18:26:18 --> Router Class Initialized
INFO - 2020-10-06 18:26:18 --> Output Class Initialized
INFO - 2020-10-06 18:26:18 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:18 --> Input Class Initialized
INFO - 2020-10-06 18:26:18 --> Language Class Initialized
INFO - 2020-10-06 18:26:18 --> Loader Class Initialized
INFO - 2020-10-06 18:26:18 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:18 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:18 --> Email Class Initialized
INFO - 2020-10-06 18:26:18 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:26:18 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:18 --> Total execution time: 0.0199
ERROR - 2020-10-06 18:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:21 --> Config Class Initialized
INFO - 2020-10-06 18:26:21 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:21 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:21 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:21 --> URI Class Initialized
INFO - 2020-10-06 18:26:21 --> Router Class Initialized
INFO - 2020-10-06 18:26:21 --> Output Class Initialized
INFO - 2020-10-06 18:26:21 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:21 --> Input Class Initialized
INFO - 2020-10-06 18:26:21 --> Language Class Initialized
INFO - 2020-10-06 18:26:21 --> Loader Class Initialized
INFO - 2020-10-06 18:26:21 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:21 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:21 --> Email Class Initialized
INFO - 2020-10-06 18:26:21 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:21 --> Model Class Initialized
INFO - 2020-10-06 18:26:21 --> Model Class Initialized
INFO - 2020-10-06 18:26:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:26:21 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:21 --> Total execution time: 0.0261
ERROR - 2020-10-06 18:26:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:24 --> Config Class Initialized
INFO - 2020-10-06 18:26:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:24 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:24 --> URI Class Initialized
INFO - 2020-10-06 18:26:24 --> Router Class Initialized
INFO - 2020-10-06 18:26:24 --> Output Class Initialized
INFO - 2020-10-06 18:26:24 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:24 --> Input Class Initialized
INFO - 2020-10-06 18:26:24 --> Language Class Initialized
INFO - 2020-10-06 18:26:24 --> Loader Class Initialized
INFO - 2020-10-06 18:26:24 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:24 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:24 --> Email Class Initialized
INFO - 2020-10-06 18:26:24 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:26:24 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:24 --> Total execution time: 0.0205
ERROR - 2020-10-06 18:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:27 --> Config Class Initialized
INFO - 2020-10-06 18:26:27 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:27 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:27 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:27 --> URI Class Initialized
INFO - 2020-10-06 18:26:27 --> Router Class Initialized
INFO - 2020-10-06 18:26:27 --> Output Class Initialized
INFO - 2020-10-06 18:26:27 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:27 --> Input Class Initialized
INFO - 2020-10-06 18:26:27 --> Language Class Initialized
INFO - 2020-10-06 18:26:27 --> Loader Class Initialized
INFO - 2020-10-06 18:26:27 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:27 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:27 --> Email Class Initialized
INFO - 2020-10-06 18:26:27 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:27 --> Model Class Initialized
INFO - 2020-10-06 18:26:27 --> Model Class Initialized
INFO - 2020-10-06 18:26:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:26:27 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:27 --> Total execution time: 0.0206
ERROR - 2020-10-06 18:26:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:29 --> Config Class Initialized
INFO - 2020-10-06 18:26:29 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:29 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:29 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:29 --> URI Class Initialized
INFO - 2020-10-06 18:26:29 --> Router Class Initialized
INFO - 2020-10-06 18:26:29 --> Output Class Initialized
INFO - 2020-10-06 18:26:29 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:29 --> Input Class Initialized
INFO - 2020-10-06 18:26:29 --> Language Class Initialized
INFO - 2020-10-06 18:26:29 --> Loader Class Initialized
INFO - 2020-10-06 18:26:29 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:29 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:29 --> Email Class Initialized
INFO - 2020-10-06 18:26:29 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:29 --> Model Class Initialized
INFO - 2020-10-06 18:26:29 --> Model Class Initialized
INFO - 2020-10-06 18:26:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:26:29 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:29 --> Total execution time: 0.0239
ERROR - 2020-10-06 18:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:31 --> Config Class Initialized
INFO - 2020-10-06 18:26:31 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:31 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:31 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:31 --> URI Class Initialized
INFO - 2020-10-06 18:26:31 --> Router Class Initialized
INFO - 2020-10-06 18:26:31 --> Output Class Initialized
INFO - 2020-10-06 18:26:31 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:31 --> Input Class Initialized
INFO - 2020-10-06 18:26:31 --> Language Class Initialized
INFO - 2020-10-06 18:26:31 --> Loader Class Initialized
INFO - 2020-10-06 18:26:31 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:31 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:31 --> Email Class Initialized
INFO - 2020-10-06 18:26:31 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:26:31 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:31 --> Total execution time: 0.0176
ERROR - 2020-10-06 18:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:34 --> Config Class Initialized
INFO - 2020-10-06 18:26:34 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:34 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:34 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:34 --> URI Class Initialized
INFO - 2020-10-06 18:26:34 --> Router Class Initialized
INFO - 2020-10-06 18:26:34 --> Output Class Initialized
INFO - 2020-10-06 18:26:34 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:34 --> Input Class Initialized
INFO - 2020-10-06 18:26:34 --> Language Class Initialized
INFO - 2020-10-06 18:26:34 --> Loader Class Initialized
INFO - 2020-10-06 18:26:34 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:34 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:34 --> Email Class Initialized
INFO - 2020-10-06 18:26:34 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:34 --> Model Class Initialized
INFO - 2020-10-06 18:26:34 --> Model Class Initialized
INFO - 2020-10-06 18:26:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:26:34 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:34 --> Total execution time: 0.0218
ERROR - 2020-10-06 18:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:38 --> Config Class Initialized
INFO - 2020-10-06 18:26:38 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:38 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:38 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:38 --> URI Class Initialized
INFO - 2020-10-06 18:26:38 --> Router Class Initialized
INFO - 2020-10-06 18:26:38 --> Output Class Initialized
INFO - 2020-10-06 18:26:38 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:38 --> Input Class Initialized
INFO - 2020-10-06 18:26:38 --> Language Class Initialized
INFO - 2020-10-06 18:26:38 --> Loader Class Initialized
INFO - 2020-10-06 18:26:38 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:38 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:38 --> Email Class Initialized
INFO - 2020-10-06 18:26:38 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:38 --> Model Class Initialized
INFO - 2020-10-06 18:26:38 --> Model Class Initialized
INFO - 2020-10-06 18:26:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:26:38 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:38 --> Total execution time: 0.0241
ERROR - 2020-10-06 18:26:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:26:40 --> Config Class Initialized
INFO - 2020-10-06 18:26:40 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:26:40 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:26:40 --> Utf8 Class Initialized
INFO - 2020-10-06 18:26:40 --> URI Class Initialized
INFO - 2020-10-06 18:26:40 --> Router Class Initialized
INFO - 2020-10-06 18:26:40 --> Output Class Initialized
INFO - 2020-10-06 18:26:40 --> Security Class Initialized
DEBUG - 2020-10-06 18:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:26:40 --> Input Class Initialized
INFO - 2020-10-06 18:26:40 --> Language Class Initialized
INFO - 2020-10-06 18:26:40 --> Loader Class Initialized
INFO - 2020-10-06 18:26:40 --> Helper loaded: url_helper
INFO - 2020-10-06 18:26:40 --> Database Driver Class Initialized
INFO - 2020-10-06 18:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:26:40 --> Email Class Initialized
INFO - 2020-10-06 18:26:40 --> Controller Class Initialized
DEBUG - 2020-10-06 18:26:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:26:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:26:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:26:40 --> Final output sent to browser
DEBUG - 2020-10-06 18:26:40 --> Total execution time: 0.0189
ERROR - 2020-10-06 18:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:27:29 --> Config Class Initialized
INFO - 2020-10-06 18:27:29 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:27:29 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:27:29 --> Utf8 Class Initialized
INFO - 2020-10-06 18:27:29 --> URI Class Initialized
INFO - 2020-10-06 18:27:29 --> Router Class Initialized
INFO - 2020-10-06 18:27:29 --> Output Class Initialized
INFO - 2020-10-06 18:27:29 --> Security Class Initialized
DEBUG - 2020-10-06 18:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:27:29 --> Input Class Initialized
INFO - 2020-10-06 18:27:29 --> Language Class Initialized
INFO - 2020-10-06 18:27:29 --> Loader Class Initialized
INFO - 2020-10-06 18:27:29 --> Helper loaded: url_helper
INFO - 2020-10-06 18:27:29 --> Database Driver Class Initialized
INFO - 2020-10-06 18:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:27:29 --> Email Class Initialized
INFO - 2020-10-06 18:27:29 --> Controller Class Initialized
DEBUG - 2020-10-06 18:27:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:27:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:27:29 --> Model Class Initialized
INFO - 2020-10-06 18:27:29 --> Model Class Initialized
INFO - 2020-10-06 18:27:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:27:29 --> Final output sent to browser
DEBUG - 2020-10-06 18:27:29 --> Total execution time: 0.0225
ERROR - 2020-10-06 18:27:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:27:32 --> Config Class Initialized
INFO - 2020-10-06 18:27:32 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:27:32 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:27:32 --> Utf8 Class Initialized
INFO - 2020-10-06 18:27:32 --> URI Class Initialized
INFO - 2020-10-06 18:27:32 --> Router Class Initialized
INFO - 2020-10-06 18:27:32 --> Output Class Initialized
INFO - 2020-10-06 18:27:32 --> Security Class Initialized
DEBUG - 2020-10-06 18:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:27:32 --> Input Class Initialized
INFO - 2020-10-06 18:27:32 --> Language Class Initialized
INFO - 2020-10-06 18:27:32 --> Loader Class Initialized
INFO - 2020-10-06 18:27:32 --> Helper loaded: url_helper
INFO - 2020-10-06 18:27:32 --> Database Driver Class Initialized
INFO - 2020-10-06 18:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:27:32 --> Email Class Initialized
INFO - 2020-10-06 18:27:32 --> Controller Class Initialized
DEBUG - 2020-10-06 18:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:27:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:27:32 --> Model Class Initialized
INFO - 2020-10-06 18:27:32 --> Model Class Initialized
INFO - 2020-10-06 18:27:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:27:32 --> Final output sent to browser
DEBUG - 2020-10-06 18:27:32 --> Total execution time: 0.0220
ERROR - 2020-10-06 18:27:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:27:37 --> Config Class Initialized
INFO - 2020-10-06 18:27:37 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:27:37 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:27:37 --> Utf8 Class Initialized
INFO - 2020-10-06 18:27:37 --> URI Class Initialized
INFO - 2020-10-06 18:27:37 --> Router Class Initialized
INFO - 2020-10-06 18:27:37 --> Output Class Initialized
INFO - 2020-10-06 18:27:37 --> Security Class Initialized
DEBUG - 2020-10-06 18:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:27:37 --> Input Class Initialized
INFO - 2020-10-06 18:27:37 --> Language Class Initialized
INFO - 2020-10-06 18:27:37 --> Loader Class Initialized
INFO - 2020-10-06 18:27:37 --> Helper loaded: url_helper
INFO - 2020-10-06 18:27:37 --> Database Driver Class Initialized
INFO - 2020-10-06 18:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:27:37 --> Email Class Initialized
INFO - 2020-10-06 18:27:37 --> Controller Class Initialized
DEBUG - 2020-10-06 18:27:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:27:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:27:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:27:37 --> Final output sent to browser
DEBUG - 2020-10-06 18:27:37 --> Total execution time: 0.0194
ERROR - 2020-10-06 18:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:27:40 --> Config Class Initialized
INFO - 2020-10-06 18:27:40 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:27:40 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:27:40 --> Utf8 Class Initialized
INFO - 2020-10-06 18:27:40 --> URI Class Initialized
INFO - 2020-10-06 18:27:40 --> Router Class Initialized
INFO - 2020-10-06 18:27:40 --> Output Class Initialized
INFO - 2020-10-06 18:27:40 --> Security Class Initialized
DEBUG - 2020-10-06 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:27:40 --> Input Class Initialized
INFO - 2020-10-06 18:27:40 --> Language Class Initialized
INFO - 2020-10-06 18:27:40 --> Loader Class Initialized
INFO - 2020-10-06 18:27:40 --> Helper loaded: url_helper
INFO - 2020-10-06 18:27:40 --> Database Driver Class Initialized
INFO - 2020-10-06 18:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:27:40 --> Email Class Initialized
INFO - 2020-10-06 18:27:40 --> Controller Class Initialized
DEBUG - 2020-10-06 18:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:27:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:27:40 --> Model Class Initialized
INFO - 2020-10-06 18:27:40 --> Model Class Initialized
INFO - 2020-10-06 18:27:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:27:40 --> Final output sent to browser
DEBUG - 2020-10-06 18:27:40 --> Total execution time: 0.0210
ERROR - 2020-10-06 18:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:01 --> Config Class Initialized
INFO - 2020-10-06 18:28:01 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:01 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:01 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:01 --> URI Class Initialized
INFO - 2020-10-06 18:28:01 --> Router Class Initialized
INFO - 2020-10-06 18:28:01 --> Output Class Initialized
INFO - 2020-10-06 18:28:01 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:01 --> Input Class Initialized
INFO - 2020-10-06 18:28:01 --> Language Class Initialized
INFO - 2020-10-06 18:28:01 --> Loader Class Initialized
INFO - 2020-10-06 18:28:01 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:01 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:01 --> Email Class Initialized
INFO - 2020-10-06 18:28:01 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:28:01 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:01 --> Total execution time: 0.0196
ERROR - 2020-10-06 18:28:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:05 --> Config Class Initialized
INFO - 2020-10-06 18:28:05 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:05 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:05 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:05 --> URI Class Initialized
INFO - 2020-10-06 18:28:05 --> Router Class Initialized
INFO - 2020-10-06 18:28:05 --> Output Class Initialized
INFO - 2020-10-06 18:28:05 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:05 --> Input Class Initialized
INFO - 2020-10-06 18:28:05 --> Language Class Initialized
INFO - 2020-10-06 18:28:05 --> Loader Class Initialized
INFO - 2020-10-06 18:28:05 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:05 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:05 --> Email Class Initialized
INFO - 2020-10-06 18:28:05 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:05 --> Model Class Initialized
INFO - 2020-10-06 18:28:05 --> Model Class Initialized
INFO - 2020-10-06 18:28:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:28:05 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:05 --> Total execution time: 0.0291
ERROR - 2020-10-06 18:28:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:07 --> Config Class Initialized
INFO - 2020-10-06 18:28:07 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:07 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:07 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:07 --> URI Class Initialized
INFO - 2020-10-06 18:28:07 --> Router Class Initialized
INFO - 2020-10-06 18:28:07 --> Output Class Initialized
INFO - 2020-10-06 18:28:07 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:07 --> Input Class Initialized
INFO - 2020-10-06 18:28:07 --> Language Class Initialized
INFO - 2020-10-06 18:28:07 --> Loader Class Initialized
INFO - 2020-10-06 18:28:07 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:07 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:07 --> Email Class Initialized
INFO - 2020-10-06 18:28:07 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:07 --> Model Class Initialized
INFO - 2020-10-06 18:28:07 --> Model Class Initialized
INFO - 2020-10-06 18:28:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:28:07 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:07 --> Total execution time: 0.0251
ERROR - 2020-10-06 18:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:09 --> Config Class Initialized
INFO - 2020-10-06 18:28:09 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:09 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:09 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:09 --> URI Class Initialized
INFO - 2020-10-06 18:28:09 --> Router Class Initialized
INFO - 2020-10-06 18:28:09 --> Output Class Initialized
INFO - 2020-10-06 18:28:09 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:09 --> Input Class Initialized
INFO - 2020-10-06 18:28:09 --> Language Class Initialized
INFO - 2020-10-06 18:28:09 --> Loader Class Initialized
INFO - 2020-10-06 18:28:09 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:09 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:09 --> Email Class Initialized
INFO - 2020-10-06 18:28:09 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:09 --> Model Class Initialized
INFO - 2020-10-06 18:28:09 --> Model Class Initialized
INFO - 2020-10-06 18:28:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 18:28:09 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:09 --> Total execution time: 0.0259
ERROR - 2020-10-06 18:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:13 --> Config Class Initialized
INFO - 2020-10-06 18:28:13 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:13 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:13 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:13 --> URI Class Initialized
INFO - 2020-10-06 18:28:13 --> Router Class Initialized
INFO - 2020-10-06 18:28:13 --> Output Class Initialized
INFO - 2020-10-06 18:28:13 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:13 --> Input Class Initialized
INFO - 2020-10-06 18:28:13 --> Language Class Initialized
INFO - 2020-10-06 18:28:13 --> Loader Class Initialized
INFO - 2020-10-06 18:28:13 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:13 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:13 --> Email Class Initialized
INFO - 2020-10-06 18:28:13 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:13 --> Model Class Initialized
INFO - 2020-10-06 18:28:13 --> Model Class Initialized
INFO - 2020-10-06 18:28:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:28:13 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:13 --> Total execution time: 0.0208
ERROR - 2020-10-06 18:28:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:16 --> Config Class Initialized
INFO - 2020-10-06 18:28:16 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:16 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:16 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:16 --> URI Class Initialized
INFO - 2020-10-06 18:28:16 --> Router Class Initialized
INFO - 2020-10-06 18:28:16 --> Output Class Initialized
INFO - 2020-10-06 18:28:16 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:16 --> Input Class Initialized
INFO - 2020-10-06 18:28:16 --> Language Class Initialized
INFO - 2020-10-06 18:28:16 --> Loader Class Initialized
INFO - 2020-10-06 18:28:16 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:16 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:16 --> Email Class Initialized
INFO - 2020-10-06 18:28:16 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:16 --> Model Class Initialized
INFO - 2020-10-06 18:28:16 --> Model Class Initialized
INFO - 2020-10-06 18:28:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:28:16 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:16 --> Total execution time: 0.0203
ERROR - 2020-10-06 18:28:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:23 --> Config Class Initialized
INFO - 2020-10-06 18:28:23 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:23 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:23 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:23 --> URI Class Initialized
INFO - 2020-10-06 18:28:23 --> Router Class Initialized
INFO - 2020-10-06 18:28:23 --> Output Class Initialized
INFO - 2020-10-06 18:28:23 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:23 --> Input Class Initialized
INFO - 2020-10-06 18:28:23 --> Language Class Initialized
INFO - 2020-10-06 18:28:23 --> Loader Class Initialized
INFO - 2020-10-06 18:28:23 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:23 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:23 --> Email Class Initialized
INFO - 2020-10-06 18:28:23 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:23 --> Model Class Initialized
INFO - 2020-10-06 18:28:23 --> Model Class Initialized
INFO - 2020-10-06 18:28:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-06 18:28:23 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:23 --> Total execution time: 0.0212
ERROR - 2020-10-06 18:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:28:28 --> Config Class Initialized
INFO - 2020-10-06 18:28:28 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:28:28 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:28:28 --> Utf8 Class Initialized
INFO - 2020-10-06 18:28:28 --> URI Class Initialized
INFO - 2020-10-06 18:28:28 --> Router Class Initialized
INFO - 2020-10-06 18:28:28 --> Output Class Initialized
INFO - 2020-10-06 18:28:28 --> Security Class Initialized
DEBUG - 2020-10-06 18:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:28:28 --> Input Class Initialized
INFO - 2020-10-06 18:28:28 --> Language Class Initialized
INFO - 2020-10-06 18:28:28 --> Loader Class Initialized
INFO - 2020-10-06 18:28:28 --> Helper loaded: url_helper
INFO - 2020-10-06 18:28:28 --> Database Driver Class Initialized
INFO - 2020-10-06 18:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:28:28 --> Email Class Initialized
INFO - 2020-10-06 18:28:28 --> Controller Class Initialized
DEBUG - 2020-10-06 18:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:28:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:28:28 --> Model Class Initialized
INFO - 2020-10-06 18:28:28 --> Model Class Initialized
INFO - 2020-10-06 18:28:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:28:28 --> Final output sent to browser
DEBUG - 2020-10-06 18:28:28 --> Total execution time: 0.0218
ERROR - 2020-10-06 18:29:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:13 --> Config Class Initialized
INFO - 2020-10-06 18:29:13 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:13 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:13 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:13 --> URI Class Initialized
INFO - 2020-10-06 18:29:13 --> Router Class Initialized
INFO - 2020-10-06 18:29:13 --> Output Class Initialized
INFO - 2020-10-06 18:29:13 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:13 --> Input Class Initialized
INFO - 2020-10-06 18:29:13 --> Language Class Initialized
INFO - 2020-10-06 18:29:13 --> Loader Class Initialized
INFO - 2020-10-06 18:29:13 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:13 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:13 --> Email Class Initialized
INFO - 2020-10-06 18:29:13 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:13 --> Model Class Initialized
INFO - 2020-10-06 18:29:13 --> Model Class Initialized
INFO - 2020-10-06 18:29:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:29:13 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:13 --> Total execution time: 0.0194
ERROR - 2020-10-06 18:29:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:16 --> Config Class Initialized
INFO - 2020-10-06 18:29:16 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:16 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:16 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:16 --> URI Class Initialized
INFO - 2020-10-06 18:29:16 --> Router Class Initialized
INFO - 2020-10-06 18:29:16 --> Output Class Initialized
INFO - 2020-10-06 18:29:16 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:16 --> Input Class Initialized
INFO - 2020-10-06 18:29:16 --> Language Class Initialized
INFO - 2020-10-06 18:29:16 --> Loader Class Initialized
INFO - 2020-10-06 18:29:16 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:16 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:16 --> Email Class Initialized
INFO - 2020-10-06 18:29:16 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:16 --> Model Class Initialized
INFO - 2020-10-06 18:29:16 --> Model Class Initialized
INFO - 2020-10-06 18:29:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:29:16 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:16 --> Total execution time: 0.0213
ERROR - 2020-10-06 18:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:18 --> Config Class Initialized
INFO - 2020-10-06 18:29:18 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:18 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:18 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:18 --> URI Class Initialized
INFO - 2020-10-06 18:29:18 --> Router Class Initialized
INFO - 2020-10-06 18:29:18 --> Output Class Initialized
INFO - 2020-10-06 18:29:18 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:18 --> Input Class Initialized
INFO - 2020-10-06 18:29:18 --> Language Class Initialized
INFO - 2020-10-06 18:29:18 --> Loader Class Initialized
INFO - 2020-10-06 18:29:18 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:18 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:18 --> Email Class Initialized
INFO - 2020-10-06 18:29:18 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:18 --> Model Class Initialized
INFO - 2020-10-06 18:29:18 --> Model Class Initialized
INFO - 2020-10-06 18:29:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:29:18 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:18 --> Total execution time: 0.0192
ERROR - 2020-10-06 18:29:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:21 --> Config Class Initialized
INFO - 2020-10-06 18:29:21 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:21 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:21 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:21 --> URI Class Initialized
INFO - 2020-10-06 18:29:21 --> Router Class Initialized
INFO - 2020-10-06 18:29:21 --> Output Class Initialized
INFO - 2020-10-06 18:29:21 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:21 --> Input Class Initialized
INFO - 2020-10-06 18:29:21 --> Language Class Initialized
INFO - 2020-10-06 18:29:21 --> Loader Class Initialized
INFO - 2020-10-06 18:29:21 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:21 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:21 --> Email Class Initialized
INFO - 2020-10-06 18:29:21 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:21 --> Model Class Initialized
INFO - 2020-10-06 18:29:21 --> Model Class Initialized
INFO - 2020-10-06 18:29:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:29:21 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:21 --> Total execution time: 0.0219
ERROR - 2020-10-06 18:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:23 --> Config Class Initialized
INFO - 2020-10-06 18:29:23 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:23 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:23 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:23 --> URI Class Initialized
INFO - 2020-10-06 18:29:23 --> Router Class Initialized
INFO - 2020-10-06 18:29:23 --> Output Class Initialized
INFO - 2020-10-06 18:29:23 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:23 --> Input Class Initialized
INFO - 2020-10-06 18:29:23 --> Language Class Initialized
INFO - 2020-10-06 18:29:23 --> Loader Class Initialized
INFO - 2020-10-06 18:29:23 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:23 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:23 --> Email Class Initialized
INFO - 2020-10-06 18:29:23 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:23 --> Model Class Initialized
INFO - 2020-10-06 18:29:23 --> Model Class Initialized
INFO - 2020-10-06 18:29:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:29:23 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:23 --> Total execution time: 0.0208
ERROR - 2020-10-06 18:29:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:24 --> Config Class Initialized
INFO - 2020-10-06 18:29:24 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:24 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:24 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:24 --> URI Class Initialized
INFO - 2020-10-06 18:29:24 --> Router Class Initialized
INFO - 2020-10-06 18:29:24 --> Output Class Initialized
INFO - 2020-10-06 18:29:24 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:24 --> Input Class Initialized
INFO - 2020-10-06 18:29:24 --> Language Class Initialized
INFO - 2020-10-06 18:29:24 --> Loader Class Initialized
INFO - 2020-10-06 18:29:24 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:24 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:24 --> Email Class Initialized
INFO - 2020-10-06 18:29:24 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-06 18:29:24 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:24 --> Total execution time: 0.0230
ERROR - 2020-10-06 18:29:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:29 --> Config Class Initialized
INFO - 2020-10-06 18:29:29 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:29 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:29 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:29 --> URI Class Initialized
DEBUG - 2020-10-06 18:29:29 --> No URI present. Default controller set.
INFO - 2020-10-06 18:29:29 --> Router Class Initialized
INFO - 2020-10-06 18:29:29 --> Output Class Initialized
INFO - 2020-10-06 18:29:29 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:29 --> Input Class Initialized
INFO - 2020-10-06 18:29:29 --> Language Class Initialized
INFO - 2020-10-06 18:29:29 --> Loader Class Initialized
INFO - 2020-10-06 18:29:29 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:29 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:29 --> Email Class Initialized
INFO - 2020-10-06 18:29:29 --> Controller Class Initialized
INFO - 2020-10-06 18:29:29 --> Model Class Initialized
INFO - 2020-10-06 18:29:29 --> Model Class Initialized
DEBUG - 2020-10-06 18:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:29:29 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:29 --> Total execution time: 0.0181
ERROR - 2020-10-06 18:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:33 --> Config Class Initialized
INFO - 2020-10-06 18:29:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:33 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:33 --> URI Class Initialized
INFO - 2020-10-06 18:29:33 --> Router Class Initialized
INFO - 2020-10-06 18:29:33 --> Output Class Initialized
INFO - 2020-10-06 18:29:33 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:33 --> Input Class Initialized
INFO - 2020-10-06 18:29:33 --> Language Class Initialized
INFO - 2020-10-06 18:29:33 --> Loader Class Initialized
INFO - 2020-10-06 18:29:33 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:33 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:33 --> Email Class Initialized
INFO - 2020-10-06 18:29:33 --> Controller Class Initialized
INFO - 2020-10-06 18:29:33 --> Model Class Initialized
INFO - 2020-10-06 18:29:33 --> Model Class Initialized
DEBUG - 2020-10-06 18:29:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:33 --> Model Class Initialized
INFO - 2020-10-06 18:29:33 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:33 --> Total execution time: 0.0219
ERROR - 2020-10-06 18:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:33 --> Config Class Initialized
INFO - 2020-10-06 18:29:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:33 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:33 --> URI Class Initialized
INFO - 2020-10-06 18:29:33 --> Router Class Initialized
INFO - 2020-10-06 18:29:33 --> Output Class Initialized
INFO - 2020-10-06 18:29:33 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:33 --> Input Class Initialized
INFO - 2020-10-06 18:29:33 --> Language Class Initialized
INFO - 2020-10-06 18:29:33 --> Loader Class Initialized
INFO - 2020-10-06 18:29:33 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:33 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:33 --> Email Class Initialized
INFO - 2020-10-06 18:29:33 --> Controller Class Initialized
INFO - 2020-10-06 18:29:33 --> Model Class Initialized
INFO - 2020-10-06 18:29:33 --> Model Class Initialized
DEBUG - 2020-10-06 18:29:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:29:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:33 --> Config Class Initialized
INFO - 2020-10-06 18:29:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:33 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:33 --> URI Class Initialized
INFO - 2020-10-06 18:29:33 --> Router Class Initialized
INFO - 2020-10-06 18:29:33 --> Output Class Initialized
INFO - 2020-10-06 18:29:33 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:33 --> Input Class Initialized
INFO - 2020-10-06 18:29:33 --> Language Class Initialized
INFO - 2020-10-06 18:29:33 --> Loader Class Initialized
INFO - 2020-10-06 18:29:33 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:33 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:34 --> Email Class Initialized
INFO - 2020-10-06 18:29:34 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:34 --> Model Class Initialized
INFO - 2020-10-06 18:29:34 --> Model Class Initialized
INFO - 2020-10-06 18:29:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-06 18:29:34 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:34 --> Total execution time: 0.0323
ERROR - 2020-10-06 18:29:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:38 --> Config Class Initialized
INFO - 2020-10-06 18:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:38 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:38 --> URI Class Initialized
INFO - 2020-10-06 18:29:38 --> Router Class Initialized
INFO - 2020-10-06 18:29:38 --> Output Class Initialized
INFO - 2020-10-06 18:29:38 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:38 --> Input Class Initialized
INFO - 2020-10-06 18:29:38 --> Language Class Initialized
INFO - 2020-10-06 18:29:38 --> Loader Class Initialized
INFO - 2020-10-06 18:29:38 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:38 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:38 --> Email Class Initialized
INFO - 2020-10-06 18:29:38 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:38 --> Model Class Initialized
INFO - 2020-10-06 18:29:38 --> Model Class Initialized
INFO - 2020-10-06 18:29:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:29:38 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:38 --> Total execution time: 0.0230
ERROR - 2020-10-06 18:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:40 --> Config Class Initialized
INFO - 2020-10-06 18:29:40 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:40 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:40 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:40 --> URI Class Initialized
INFO - 2020-10-06 18:29:40 --> Router Class Initialized
INFO - 2020-10-06 18:29:40 --> Output Class Initialized
INFO - 2020-10-06 18:29:40 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:40 --> Input Class Initialized
INFO - 2020-10-06 18:29:40 --> Language Class Initialized
INFO - 2020-10-06 18:29:40 --> Loader Class Initialized
INFO - 2020-10-06 18:29:40 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:40 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:40 --> Email Class Initialized
INFO - 2020-10-06 18:29:40 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:40 --> Model Class Initialized
INFO - 2020-10-06 18:29:40 --> Model Class Initialized
INFO - 2020-10-06 18:29:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:29:40 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:40 --> Total execution time: 0.0239
ERROR - 2020-10-06 18:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:41 --> Config Class Initialized
INFO - 2020-10-06 18:29:41 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:41 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:41 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:41 --> URI Class Initialized
INFO - 2020-10-06 18:29:41 --> Router Class Initialized
INFO - 2020-10-06 18:29:41 --> Output Class Initialized
INFO - 2020-10-06 18:29:41 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:41 --> Input Class Initialized
INFO - 2020-10-06 18:29:41 --> Language Class Initialized
INFO - 2020-10-06 18:29:41 --> Loader Class Initialized
INFO - 2020-10-06 18:29:41 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:41 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:41 --> Email Class Initialized
INFO - 2020-10-06 18:29:41 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:41 --> Model Class Initialized
INFO - 2020-10-06 18:29:41 --> Model Class Initialized
INFO - 2020-10-06 18:29:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:29:41 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:41 --> Total execution time: 0.0214
ERROR - 2020-10-06 18:29:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:44 --> Config Class Initialized
INFO - 2020-10-06 18:29:44 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:44 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:44 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:44 --> URI Class Initialized
INFO - 2020-10-06 18:29:44 --> Router Class Initialized
INFO - 2020-10-06 18:29:44 --> Output Class Initialized
INFO - 2020-10-06 18:29:44 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:44 --> Input Class Initialized
INFO - 2020-10-06 18:29:44 --> Language Class Initialized
INFO - 2020-10-06 18:29:44 --> Loader Class Initialized
INFO - 2020-10-06 18:29:44 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:44 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:44 --> Email Class Initialized
INFO - 2020-10-06 18:29:44 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:44 --> Model Class Initialized
INFO - 2020-10-06 18:29:44 --> Model Class Initialized
INFO - 2020-10-06 18:29:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:29:44 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:44 --> Total execution time: 0.0232
ERROR - 2020-10-06 18:29:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:52 --> Config Class Initialized
INFO - 2020-10-06 18:29:52 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:52 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:52 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:52 --> URI Class Initialized
INFO - 2020-10-06 18:29:52 --> Router Class Initialized
INFO - 2020-10-06 18:29:52 --> Output Class Initialized
INFO - 2020-10-06 18:29:52 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:52 --> Input Class Initialized
INFO - 2020-10-06 18:29:52 --> Language Class Initialized
INFO - 2020-10-06 18:29:52 --> Loader Class Initialized
INFO - 2020-10-06 18:29:52 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:52 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:52 --> Email Class Initialized
INFO - 2020-10-06 18:29:52 --> Controller Class Initialized
DEBUG - 2020-10-06 18:29:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:29:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:52 --> Model Class Initialized
INFO - 2020-10-06 18:29:52 --> Model Class Initialized
INFO - 2020-10-06 18:29:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:29:52 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:52 --> Total execution time: 0.0218
ERROR - 2020-10-06 18:29:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:29:56 --> Config Class Initialized
INFO - 2020-10-06 18:29:56 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:29:56 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:29:56 --> Utf8 Class Initialized
INFO - 2020-10-06 18:29:56 --> URI Class Initialized
DEBUG - 2020-10-06 18:29:56 --> No URI present. Default controller set.
INFO - 2020-10-06 18:29:56 --> Router Class Initialized
INFO - 2020-10-06 18:29:56 --> Output Class Initialized
INFO - 2020-10-06 18:29:56 --> Security Class Initialized
DEBUG - 2020-10-06 18:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:29:56 --> Input Class Initialized
INFO - 2020-10-06 18:29:56 --> Language Class Initialized
INFO - 2020-10-06 18:29:56 --> Loader Class Initialized
INFO - 2020-10-06 18:29:56 --> Helper loaded: url_helper
INFO - 2020-10-06 18:29:56 --> Database Driver Class Initialized
INFO - 2020-10-06 18:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:29:56 --> Email Class Initialized
INFO - 2020-10-06 18:29:56 --> Controller Class Initialized
INFO - 2020-10-06 18:29:56 --> Model Class Initialized
INFO - 2020-10-06 18:29:56 --> Model Class Initialized
DEBUG - 2020-10-06 18:29:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:29:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:29:56 --> Final output sent to browser
DEBUG - 2020-10-06 18:29:56 --> Total execution time: 0.0202
ERROR - 2020-10-06 18:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:14 --> Config Class Initialized
INFO - 2020-10-06 18:30:14 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:14 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:14 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:14 --> URI Class Initialized
INFO - 2020-10-06 18:30:14 --> Router Class Initialized
INFO - 2020-10-06 18:30:14 --> Output Class Initialized
INFO - 2020-10-06 18:30:14 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:14 --> Input Class Initialized
INFO - 2020-10-06 18:30:14 --> Language Class Initialized
INFO - 2020-10-06 18:30:14 --> Loader Class Initialized
INFO - 2020-10-06 18:30:14 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:14 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:14 --> Email Class Initialized
INFO - 2020-10-06 18:30:14 --> Controller Class Initialized
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
DEBUG - 2020-10-06 18:30:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
INFO - 2020-10-06 18:30:14 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:14 --> Total execution time: 0.0206
ERROR - 2020-10-06 18:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:14 --> Config Class Initialized
INFO - 2020-10-06 18:30:14 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:14 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:14 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:14 --> URI Class Initialized
INFO - 2020-10-06 18:30:14 --> Router Class Initialized
INFO - 2020-10-06 18:30:14 --> Output Class Initialized
INFO - 2020-10-06 18:30:14 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:14 --> Input Class Initialized
INFO - 2020-10-06 18:30:14 --> Language Class Initialized
INFO - 2020-10-06 18:30:14 --> Loader Class Initialized
INFO - 2020-10-06 18:30:14 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:14 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:14 --> Email Class Initialized
INFO - 2020-10-06 18:30:14 --> Controller Class Initialized
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
DEBUG - 2020-10-06 18:30:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-06 18:30:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:14 --> Config Class Initialized
INFO - 2020-10-06 18:30:14 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:14 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:14 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:14 --> URI Class Initialized
INFO - 2020-10-06 18:30:14 --> Router Class Initialized
INFO - 2020-10-06 18:30:14 --> Output Class Initialized
INFO - 2020-10-06 18:30:14 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:14 --> Input Class Initialized
INFO - 2020-10-06 18:30:14 --> Language Class Initialized
INFO - 2020-10-06 18:30:14 --> Loader Class Initialized
INFO - 2020-10-06 18:30:14 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:14 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:14 --> Email Class Initialized
INFO - 2020-10-06 18:30:14 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
INFO - 2020-10-06 18:30:14 --> Model Class Initialized
INFO - 2020-10-06 18:30:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:30:14 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:14 --> Total execution time: 0.0235
ERROR - 2020-10-06 18:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:23 --> Config Class Initialized
INFO - 2020-10-06 18:30:23 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:23 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:23 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:23 --> URI Class Initialized
INFO - 2020-10-06 18:30:23 --> Router Class Initialized
INFO - 2020-10-06 18:30:23 --> Output Class Initialized
INFO - 2020-10-06 18:30:23 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:23 --> Input Class Initialized
INFO - 2020-10-06 18:30:23 --> Language Class Initialized
INFO - 2020-10-06 18:30:23 --> Loader Class Initialized
INFO - 2020-10-06 18:30:23 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:23 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:23 --> Email Class Initialized
INFO - 2020-10-06 18:30:23 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:23 --> Model Class Initialized
INFO - 2020-10-06 18:30:23 --> Model Class Initialized
INFO - 2020-10-06 18:30:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:30:23 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:23 --> Total execution time: 0.0204
ERROR - 2020-10-06 18:30:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:30 --> Config Class Initialized
INFO - 2020-10-06 18:30:30 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:30 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:30 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:30 --> URI Class Initialized
INFO - 2020-10-06 18:30:30 --> Router Class Initialized
INFO - 2020-10-06 18:30:30 --> Output Class Initialized
INFO - 2020-10-06 18:30:30 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:30 --> Input Class Initialized
INFO - 2020-10-06 18:30:30 --> Language Class Initialized
INFO - 2020-10-06 18:30:30 --> Loader Class Initialized
INFO - 2020-10-06 18:30:30 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:30 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:30 --> Email Class Initialized
INFO - 2020-10-06 18:30:30 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:30 --> Model Class Initialized
INFO - 2020-10-06 18:30:30 --> Model Class Initialized
INFO - 2020-10-06 18:30:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:30:30 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:30 --> Total execution time: 0.0242
ERROR - 2020-10-06 18:30:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:33 --> Config Class Initialized
INFO - 2020-10-06 18:30:33 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:33 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:33 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:33 --> URI Class Initialized
INFO - 2020-10-06 18:30:33 --> Router Class Initialized
INFO - 2020-10-06 18:30:33 --> Output Class Initialized
INFO - 2020-10-06 18:30:33 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:33 --> Input Class Initialized
INFO - 2020-10-06 18:30:33 --> Language Class Initialized
INFO - 2020-10-06 18:30:33 --> Loader Class Initialized
INFO - 2020-10-06 18:30:33 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:33 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:33 --> Email Class Initialized
INFO - 2020-10-06 18:30:33 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:33 --> Model Class Initialized
INFO - 2020-10-06 18:30:33 --> Model Class Initialized
INFO - 2020-10-06 18:30:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:30:33 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:33 --> Total execution time: 0.0236
ERROR - 2020-10-06 18:30:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:37 --> Config Class Initialized
INFO - 2020-10-06 18:30:37 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:37 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:37 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:37 --> URI Class Initialized
INFO - 2020-10-06 18:30:37 --> Router Class Initialized
INFO - 2020-10-06 18:30:37 --> Output Class Initialized
INFO - 2020-10-06 18:30:37 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:37 --> Input Class Initialized
INFO - 2020-10-06 18:30:37 --> Language Class Initialized
INFO - 2020-10-06 18:30:37 --> Loader Class Initialized
INFO - 2020-10-06 18:30:37 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:37 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:37 --> Email Class Initialized
INFO - 2020-10-06 18:30:37 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:37 --> Model Class Initialized
INFO - 2020-10-06 18:30:37 --> Model Class Initialized
INFO - 2020-10-06 18:30:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:30:37 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:37 --> Total execution time: 0.0228
ERROR - 2020-10-06 18:30:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:40 --> Config Class Initialized
INFO - 2020-10-06 18:30:40 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:40 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:40 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:40 --> URI Class Initialized
INFO - 2020-10-06 18:30:40 --> Router Class Initialized
INFO - 2020-10-06 18:30:40 --> Output Class Initialized
INFO - 2020-10-06 18:30:40 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:40 --> Input Class Initialized
INFO - 2020-10-06 18:30:40 --> Language Class Initialized
INFO - 2020-10-06 18:30:40 --> Loader Class Initialized
INFO - 2020-10-06 18:30:40 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:40 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:40 --> Email Class Initialized
INFO - 2020-10-06 18:30:40 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:40 --> Model Class Initialized
INFO - 2020-10-06 18:30:40 --> Model Class Initialized
INFO - 2020-10-06 18:30:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:30:40 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:40 --> Total execution time: 0.0230
ERROR - 2020-10-06 18:30:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:46 --> Config Class Initialized
INFO - 2020-10-06 18:30:46 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:46 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:46 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:46 --> URI Class Initialized
INFO - 2020-10-06 18:30:46 --> Router Class Initialized
INFO - 2020-10-06 18:30:46 --> Output Class Initialized
INFO - 2020-10-06 18:30:46 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:46 --> Input Class Initialized
INFO - 2020-10-06 18:30:46 --> Language Class Initialized
INFO - 2020-10-06 18:30:46 --> Loader Class Initialized
INFO - 2020-10-06 18:30:46 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:46 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:46 --> Email Class Initialized
INFO - 2020-10-06 18:30:46 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:46 --> Model Class Initialized
INFO - 2020-10-06 18:30:46 --> Model Class Initialized
INFO - 2020-10-06 18:30:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:30:46 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:46 --> Total execution time: 0.0234
ERROR - 2020-10-06 18:30:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:49 --> Config Class Initialized
INFO - 2020-10-06 18:30:49 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:49 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:49 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:49 --> URI Class Initialized
INFO - 2020-10-06 18:30:49 --> Router Class Initialized
INFO - 2020-10-06 18:30:49 --> Output Class Initialized
INFO - 2020-10-06 18:30:49 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:49 --> Input Class Initialized
INFO - 2020-10-06 18:30:49 --> Language Class Initialized
INFO - 2020-10-06 18:30:49 --> Loader Class Initialized
INFO - 2020-10-06 18:30:49 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:49 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:49 --> Email Class Initialized
INFO - 2020-10-06 18:30:49 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:49 --> Model Class Initialized
INFO - 2020-10-06 18:30:49 --> Model Class Initialized
INFO - 2020-10-06 18:30:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:30:49 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:49 --> Total execution time: 0.0204
ERROR - 2020-10-06 18:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:30:58 --> Config Class Initialized
INFO - 2020-10-06 18:30:58 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:30:58 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:30:58 --> Utf8 Class Initialized
INFO - 2020-10-06 18:30:58 --> URI Class Initialized
INFO - 2020-10-06 18:30:58 --> Router Class Initialized
INFO - 2020-10-06 18:30:58 --> Output Class Initialized
INFO - 2020-10-06 18:30:58 --> Security Class Initialized
DEBUG - 2020-10-06 18:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:30:58 --> Input Class Initialized
INFO - 2020-10-06 18:30:58 --> Language Class Initialized
INFO - 2020-10-06 18:30:58 --> Loader Class Initialized
INFO - 2020-10-06 18:30:58 --> Helper loaded: url_helper
INFO - 2020-10-06 18:30:58 --> Database Driver Class Initialized
INFO - 2020-10-06 18:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:30:58 --> Email Class Initialized
INFO - 2020-10-06 18:30:58 --> Controller Class Initialized
DEBUG - 2020-10-06 18:30:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:30:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:30:58 --> Model Class Initialized
INFO - 2020-10-06 18:30:58 --> Model Class Initialized
INFO - 2020-10-06 18:30:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:30:58 --> Final output sent to browser
DEBUG - 2020-10-06 18:30:58 --> Total execution time: 0.0208
ERROR - 2020-10-06 18:31:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:31:00 --> Config Class Initialized
INFO - 2020-10-06 18:31:00 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:31:00 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:31:00 --> Utf8 Class Initialized
INFO - 2020-10-06 18:31:00 --> URI Class Initialized
INFO - 2020-10-06 18:31:00 --> Router Class Initialized
INFO - 2020-10-06 18:31:00 --> Output Class Initialized
INFO - 2020-10-06 18:31:00 --> Security Class Initialized
DEBUG - 2020-10-06 18:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:31:00 --> Input Class Initialized
INFO - 2020-10-06 18:31:00 --> Language Class Initialized
INFO - 2020-10-06 18:31:00 --> Loader Class Initialized
INFO - 2020-10-06 18:31:00 --> Helper loaded: url_helper
INFO - 2020-10-06 18:31:00 --> Database Driver Class Initialized
INFO - 2020-10-06 18:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:31:00 --> Email Class Initialized
INFO - 2020-10-06 18:31:00 --> Controller Class Initialized
DEBUG - 2020-10-06 18:31:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:31:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:31:00 --> Model Class Initialized
INFO - 2020-10-06 18:31:00 --> Model Class Initialized
INFO - 2020-10-06 18:31:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-06 18:31:00 --> Final output sent to browser
DEBUG - 2020-10-06 18:31:00 --> Total execution time: 0.0254
ERROR - 2020-10-06 18:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:31:10 --> Config Class Initialized
INFO - 2020-10-06 18:31:10 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:31:10 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:31:10 --> Utf8 Class Initialized
INFO - 2020-10-06 18:31:10 --> URI Class Initialized
INFO - 2020-10-06 18:31:10 --> Router Class Initialized
INFO - 2020-10-06 18:31:10 --> Output Class Initialized
INFO - 2020-10-06 18:31:10 --> Security Class Initialized
DEBUG - 2020-10-06 18:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:31:10 --> Input Class Initialized
INFO - 2020-10-06 18:31:10 --> Language Class Initialized
INFO - 2020-10-06 18:31:10 --> Loader Class Initialized
INFO - 2020-10-06 18:31:10 --> Helper loaded: url_helper
INFO - 2020-10-06 18:31:10 --> Database Driver Class Initialized
INFO - 2020-10-06 18:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:31:10 --> Email Class Initialized
INFO - 2020-10-06 18:31:10 --> Controller Class Initialized
DEBUG - 2020-10-06 18:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:31:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:31:10 --> Model Class Initialized
INFO - 2020-10-06 18:31:10 --> Model Class Initialized
INFO - 2020-10-06 18:31:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-06 18:31:10 --> Final output sent to browser
DEBUG - 2020-10-06 18:31:10 --> Total execution time: 0.0197
ERROR - 2020-10-06 18:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:31:15 --> Config Class Initialized
INFO - 2020-10-06 18:31:15 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:31:15 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:31:15 --> Utf8 Class Initialized
INFO - 2020-10-06 18:31:15 --> URI Class Initialized
INFO - 2020-10-06 18:31:15 --> Router Class Initialized
INFO - 2020-10-06 18:31:15 --> Output Class Initialized
INFO - 2020-10-06 18:31:15 --> Security Class Initialized
DEBUG - 2020-10-06 18:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:31:15 --> Input Class Initialized
INFO - 2020-10-06 18:31:15 --> Language Class Initialized
INFO - 2020-10-06 18:31:15 --> Loader Class Initialized
INFO - 2020-10-06 18:31:15 --> Helper loaded: url_helper
INFO - 2020-10-06 18:31:15 --> Database Driver Class Initialized
INFO - 2020-10-06 18:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:31:15 --> Email Class Initialized
INFO - 2020-10-06 18:31:15 --> Controller Class Initialized
DEBUG - 2020-10-06 18:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-06 18:31:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:31:15 --> Model Class Initialized
INFO - 2020-10-06 18:31:15 --> Model Class Initialized
INFO - 2020-10-06 18:31:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-06 18:31:15 --> Final output sent to browser
DEBUG - 2020-10-06 18:31:15 --> Total execution time: 0.0204
ERROR - 2020-10-06 18:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-06 18:31:19 --> Config Class Initialized
INFO - 2020-10-06 18:31:19 --> Hooks Class Initialized
DEBUG - 2020-10-06 18:31:19 --> UTF-8 Support Enabled
INFO - 2020-10-06 18:31:19 --> Utf8 Class Initialized
INFO - 2020-10-06 18:31:19 --> URI Class Initialized
DEBUG - 2020-10-06 18:31:19 --> No URI present. Default controller set.
INFO - 2020-10-06 18:31:19 --> Router Class Initialized
INFO - 2020-10-06 18:31:19 --> Output Class Initialized
INFO - 2020-10-06 18:31:19 --> Security Class Initialized
DEBUG - 2020-10-06 18:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-06 18:31:19 --> Input Class Initialized
INFO - 2020-10-06 18:31:19 --> Language Class Initialized
INFO - 2020-10-06 18:31:19 --> Loader Class Initialized
INFO - 2020-10-06 18:31:19 --> Helper loaded: url_helper
INFO - 2020-10-06 18:31:19 --> Database Driver Class Initialized
INFO - 2020-10-06 18:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-06 18:31:19 --> Email Class Initialized
INFO - 2020-10-06 18:31:19 --> Controller Class Initialized
INFO - 2020-10-06 18:31:19 --> Model Class Initialized
INFO - 2020-10-06 18:31:19 --> Model Class Initialized
DEBUG - 2020-10-06 18:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-06 18:31:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-06 18:31:19 --> Final output sent to browser
DEBUG - 2020-10-06 18:31:19 --> Total execution time: 0.0222
