<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-02 14:14:17 --> Config Class Initialized
INFO - 2020-08-02 14:14:17 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:14:17 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:14:17 --> Utf8 Class Initialized
INFO - 2020-08-02 14:14:17 --> URI Class Initialized
DEBUG - 2020-08-02 14:14:17 --> No URI present. Default controller set.
INFO - 2020-08-02 14:14:17 --> Router Class Initialized
INFO - 2020-08-02 14:14:17 --> Output Class Initialized
INFO - 2020-08-02 14:14:17 --> Security Class Initialized
DEBUG - 2020-08-02 14:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:14:17 --> Input Class Initialized
INFO - 2020-08-02 14:14:17 --> Language Class Initialized
INFO - 2020-08-02 14:14:17 --> Loader Class Initialized
INFO - 2020-08-02 14:14:17 --> Helper loaded: url_helper
INFO - 2020-08-02 14:14:17 --> Database Driver Class Initialized
INFO - 2020-08-02 14:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:14:17 --> Email Class Initialized
INFO - 2020-08-02 14:14:17 --> Controller Class Initialized
INFO - 2020-08-02 14:14:17 --> Model Class Initialized
INFO - 2020-08-02 14:14:17 --> Model Class Initialized
DEBUG - 2020-08-02 14:14:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:14:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-02 14:14:17 --> Final output sent to browser
DEBUG - 2020-08-02 14:14:17 --> Total execution time: 0.2441
INFO - 2020-08-02 14:14:48 --> Config Class Initialized
INFO - 2020-08-02 14:14:48 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:14:48 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:14:48 --> Utf8 Class Initialized
INFO - 2020-08-02 14:14:48 --> URI Class Initialized
INFO - 2020-08-02 14:14:48 --> Router Class Initialized
INFO - 2020-08-02 14:14:48 --> Output Class Initialized
INFO - 2020-08-02 14:14:48 --> Security Class Initialized
DEBUG - 2020-08-02 14:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:14:48 --> Input Class Initialized
INFO - 2020-08-02 14:14:48 --> Language Class Initialized
INFO - 2020-08-02 14:14:48 --> Loader Class Initialized
INFO - 2020-08-02 14:14:48 --> Helper loaded: url_helper
INFO - 2020-08-02 14:14:48 --> Database Driver Class Initialized
INFO - 2020-08-02 14:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:14:48 --> Email Class Initialized
INFO - 2020-08-02 14:14:48 --> Controller Class Initialized
INFO - 2020-08-02 14:14:48 --> Model Class Initialized
INFO - 2020-08-02 14:14:48 --> Model Class Initialized
DEBUG - 2020-08-02 14:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-02 14:14:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:14:49 --> Config Class Initialized
INFO - 2020-08-02 14:14:49 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:14:49 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:14:49 --> Utf8 Class Initialized
INFO - 2020-08-02 14:14:49 --> URI Class Initialized
DEBUG - 2020-08-02 14:14:49 --> No URI present. Default controller set.
INFO - 2020-08-02 14:14:49 --> Router Class Initialized
INFO - 2020-08-02 14:14:49 --> Output Class Initialized
INFO - 2020-08-02 14:14:49 --> Security Class Initialized
DEBUG - 2020-08-02 14:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:14:49 --> Input Class Initialized
INFO - 2020-08-02 14:14:49 --> Language Class Initialized
INFO - 2020-08-02 14:14:49 --> Loader Class Initialized
INFO - 2020-08-02 14:14:49 --> Helper loaded: url_helper
INFO - 2020-08-02 14:14:49 --> Database Driver Class Initialized
INFO - 2020-08-02 14:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:14:49 --> Email Class Initialized
INFO - 2020-08-02 14:14:49 --> Controller Class Initialized
INFO - 2020-08-02 14:14:49 --> Model Class Initialized
INFO - 2020-08-02 14:14:49 --> Model Class Initialized
DEBUG - 2020-08-02 14:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:14:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-02 14:14:49 --> Final output sent to browser
DEBUG - 2020-08-02 14:14:49 --> Total execution time: 0.0239
INFO - 2020-08-02 14:14:49 --> Config Class Initialized
INFO - 2020-08-02 14:14:49 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:14:49 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:14:49 --> Utf8 Class Initialized
INFO - 2020-08-02 14:14:49 --> URI Class Initialized
INFO - 2020-08-02 14:14:49 --> Router Class Initialized
INFO - 2020-08-02 14:14:49 --> Output Class Initialized
INFO - 2020-08-02 14:14:49 --> Security Class Initialized
DEBUG - 2020-08-02 14:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:14:49 --> Input Class Initialized
INFO - 2020-08-02 14:14:49 --> Language Class Initialized
INFO - 2020-08-02 14:14:49 --> Loader Class Initialized
INFO - 2020-08-02 14:14:49 --> Helper loaded: url_helper
INFO - 2020-08-02 14:14:49 --> Database Driver Class Initialized
INFO - 2020-08-02 14:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:14:49 --> Email Class Initialized
INFO - 2020-08-02 14:14:49 --> Controller Class Initialized
INFO - 2020-08-02 14:14:49 --> Model Class Initialized
INFO - 2020-08-02 14:14:49 --> Model Class Initialized
DEBUG - 2020-08-02 14:14:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:14:50 --> Config Class Initialized
INFO - 2020-08-02 14:14:50 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:14:50 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:14:50 --> Utf8 Class Initialized
INFO - 2020-08-02 14:14:50 --> URI Class Initialized
INFO - 2020-08-02 14:14:50 --> Router Class Initialized
INFO - 2020-08-02 14:14:50 --> Output Class Initialized
INFO - 2020-08-02 14:14:50 --> Security Class Initialized
DEBUG - 2020-08-02 14:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:14:50 --> Input Class Initialized
INFO - 2020-08-02 14:14:50 --> Language Class Initialized
INFO - 2020-08-02 14:14:50 --> Loader Class Initialized
INFO - 2020-08-02 14:14:50 --> Helper loaded: url_helper
INFO - 2020-08-02 14:14:50 --> Database Driver Class Initialized
INFO - 2020-08-02 14:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:14:50 --> Email Class Initialized
INFO - 2020-08-02 14:14:50 --> Controller Class Initialized
DEBUG - 2020-08-02 14:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-02 14:14:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:14:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-02 14:14:50 --> Final output sent to browser
DEBUG - 2020-08-02 14:14:50 --> Total execution time: 0.0455
INFO - 2020-08-02 14:15:02 --> Config Class Initialized
INFO - 2020-08-02 14:15:02 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:15:02 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:15:02 --> Utf8 Class Initialized
INFO - 2020-08-02 14:15:02 --> URI Class Initialized
INFO - 2020-08-02 14:15:02 --> Router Class Initialized
INFO - 2020-08-02 14:15:02 --> Output Class Initialized
INFO - 2020-08-02 14:15:02 --> Security Class Initialized
DEBUG - 2020-08-02 14:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:15:02 --> Input Class Initialized
INFO - 2020-08-02 14:15:02 --> Language Class Initialized
INFO - 2020-08-02 14:15:02 --> Loader Class Initialized
INFO - 2020-08-02 14:15:02 --> Helper loaded: url_helper
INFO - 2020-08-02 14:15:02 --> Database Driver Class Initialized
INFO - 2020-08-02 14:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:15:02 --> Email Class Initialized
INFO - 2020-08-02 14:15:02 --> Controller Class Initialized
DEBUG - 2020-08-02 14:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-02 14:15:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:15:02 --> Model Class Initialized
INFO - 2020-08-02 14:15:02 --> Model Class Initialized
INFO - 2020-08-02 14:15:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-02 14:15:02 --> Final output sent to browser
DEBUG - 2020-08-02 14:15:02 --> Total execution time: 0.0449
INFO - 2020-08-02 14:15:17 --> Config Class Initialized
INFO - 2020-08-02 14:15:17 --> Hooks Class Initialized
DEBUG - 2020-08-02 14:15:17 --> UTF-8 Support Enabled
INFO - 2020-08-02 14:15:17 --> Utf8 Class Initialized
INFO - 2020-08-02 14:15:17 --> URI Class Initialized
INFO - 2020-08-02 14:15:17 --> Router Class Initialized
INFO - 2020-08-02 14:15:17 --> Output Class Initialized
INFO - 2020-08-02 14:15:17 --> Security Class Initialized
DEBUG - 2020-08-02 14:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-02 14:15:17 --> Input Class Initialized
INFO - 2020-08-02 14:15:17 --> Language Class Initialized
INFO - 2020-08-02 14:15:17 --> Loader Class Initialized
INFO - 2020-08-02 14:15:17 --> Helper loaded: url_helper
INFO - 2020-08-02 14:15:17 --> Database Driver Class Initialized
INFO - 2020-08-02 14:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-02 14:15:17 --> Email Class Initialized
INFO - 2020-08-02 14:15:17 --> Controller Class Initialized
DEBUG - 2020-08-02 14:15:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-02 14:15:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-02 14:15:17 --> Model Class Initialized
INFO - 2020-08-02 14:15:17 --> Model Class Initialized
INFO - 2020-08-02 14:15:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-02 14:15:17 --> Final output sent to browser
DEBUG - 2020-08-02 14:15:17 --> Total execution time: 0.0469
