<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-13 14:07:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-13 14:07:13 --> Config Class Initialized
INFO - 2020-10-13 14:07:13 --> Hooks Class Initialized
DEBUG - 2020-10-13 14:07:13 --> UTF-8 Support Enabled
INFO - 2020-10-13 14:07:13 --> Utf8 Class Initialized
INFO - 2020-10-13 14:07:13 --> URI Class Initialized
DEBUG - 2020-10-13 14:07:13 --> No URI present. Default controller set.
INFO - 2020-10-13 14:07:13 --> Router Class Initialized
INFO - 2020-10-13 14:07:13 --> Output Class Initialized
INFO - 2020-10-13 14:07:13 --> Security Class Initialized
DEBUG - 2020-10-13 14:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-13 14:07:13 --> Input Class Initialized
INFO - 2020-10-13 14:07:13 --> Language Class Initialized
INFO - 2020-10-13 14:07:13 --> Loader Class Initialized
INFO - 2020-10-13 14:07:13 --> Helper loaded: url_helper
INFO - 2020-10-13 14:07:13 --> Database Driver Class Initialized
INFO - 2020-10-13 14:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-13 14:07:13 --> Email Class Initialized
INFO - 2020-10-13 14:07:13 --> Controller Class Initialized
INFO - 2020-10-13 14:07:13 --> Model Class Initialized
INFO - 2020-10-13 14:07:13 --> Model Class Initialized
DEBUG - 2020-10-13 14:07:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-13 14:07:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-13 14:07:13 --> Final output sent to browser
DEBUG - 2020-10-13 14:07:13 --> Total execution time: 0.1914
ERROR - 2020-10-13 15:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-13 15:51:30 --> Config Class Initialized
INFO - 2020-10-13 15:51:30 --> Hooks Class Initialized
DEBUG - 2020-10-13 15:51:30 --> UTF-8 Support Enabled
INFO - 2020-10-13 15:51:30 --> Utf8 Class Initialized
INFO - 2020-10-13 15:51:30 --> URI Class Initialized
DEBUG - 2020-10-13 15:51:30 --> No URI present. Default controller set.
INFO - 2020-10-13 15:51:30 --> Router Class Initialized
INFO - 2020-10-13 15:51:30 --> Output Class Initialized
INFO - 2020-10-13 15:51:30 --> Security Class Initialized
DEBUG - 2020-10-13 15:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-13 15:51:30 --> Input Class Initialized
INFO - 2020-10-13 15:51:30 --> Language Class Initialized
INFO - 2020-10-13 15:51:30 --> Loader Class Initialized
INFO - 2020-10-13 15:51:30 --> Helper loaded: url_helper
INFO - 2020-10-13 15:51:30 --> Database Driver Class Initialized
INFO - 2020-10-13 15:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-13 15:51:30 --> Email Class Initialized
INFO - 2020-10-13 15:51:30 --> Controller Class Initialized
INFO - 2020-10-13 15:51:30 --> Model Class Initialized
INFO - 2020-10-13 15:51:30 --> Model Class Initialized
DEBUG - 2020-10-13 15:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-13 15:51:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-13 15:51:30 --> Final output sent to browser
DEBUG - 2020-10-13 15:51:30 --> Total execution time: 0.1208
