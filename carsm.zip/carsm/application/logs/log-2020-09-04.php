<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-04 07:07:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:07:07 --> Config Class Initialized
INFO - 2020-09-04 07:07:07 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:07:07 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:07:07 --> Utf8 Class Initialized
INFO - 2020-09-04 07:07:07 --> URI Class Initialized
DEBUG - 2020-09-04 07:07:07 --> No URI present. Default controller set.
INFO - 2020-09-04 07:07:07 --> Router Class Initialized
INFO - 2020-09-04 07:07:07 --> Output Class Initialized
INFO - 2020-09-04 07:07:07 --> Security Class Initialized
DEBUG - 2020-09-04 07:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:07:07 --> Input Class Initialized
INFO - 2020-09-04 07:07:07 --> Language Class Initialized
INFO - 2020-09-04 07:07:07 --> Loader Class Initialized
INFO - 2020-09-04 07:07:07 --> Helper loaded: url_helper
INFO - 2020-09-04 07:07:07 --> Database Driver Class Initialized
INFO - 2020-09-04 07:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:07:07 --> Email Class Initialized
INFO - 2020-09-04 07:07:07 --> Controller Class Initialized
INFO - 2020-09-04 07:07:07 --> Model Class Initialized
INFO - 2020-09-04 07:07:07 --> Model Class Initialized
DEBUG - 2020-09-04 07:07:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-04 07:07:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-04 07:07:07 --> Final output sent to browser
DEBUG - 2020-09-04 07:07:07 --> Total execution time: 0.1322
ERROR - 2020-09-04 07:21:42 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-04 07:23:38 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-04 07:23:45 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-04 07:26:36 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-04 07:28:25 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-04 07:28:38 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-04 07:29:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:29:19 --> Config Class Initialized
INFO - 2020-09-04 07:29:19 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:29:19 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:29:19 --> Utf8 Class Initialized
INFO - 2020-09-04 07:29:19 --> URI Class Initialized
DEBUG - 2020-09-04 07:29:19 --> No URI present. Default controller set.
INFO - 2020-09-04 07:29:19 --> Router Class Initialized
INFO - 2020-09-04 07:29:19 --> Output Class Initialized
INFO - 2020-09-04 07:29:19 --> Security Class Initialized
DEBUG - 2020-09-04 07:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:29:19 --> Input Class Initialized
INFO - 2020-09-04 07:29:19 --> Language Class Initialized
INFO - 2020-09-04 07:29:19 --> Loader Class Initialized
INFO - 2020-09-04 07:29:19 --> Helper loaded: url_helper
INFO - 2020-09-04 07:29:19 --> Database Driver Class Initialized
INFO - 2020-09-04 07:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:29:20 --> Email Class Initialized
INFO - 2020-09-04 07:29:20 --> Controller Class Initialized
INFO - 2020-09-04 07:29:20 --> Model Class Initialized
INFO - 2020-09-04 07:29:20 --> Model Class Initialized
DEBUG - 2020-09-04 07:29:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-04 07:29:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-04 07:29:20 --> Final output sent to browser
DEBUG - 2020-09-04 07:29:20 --> Total execution time: 0.1958
ERROR - 2020-09-04 07:29:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:29:22 --> Config Class Initialized
INFO - 2020-09-04 07:29:22 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:29:22 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:29:22 --> Utf8 Class Initialized
INFO - 2020-09-04 07:29:22 --> URI Class Initialized
INFO - 2020-09-04 07:29:22 --> Router Class Initialized
INFO - 2020-09-04 07:29:22 --> Output Class Initialized
INFO - 2020-09-04 07:29:22 --> Security Class Initialized
DEBUG - 2020-09-04 07:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:29:22 --> Input Class Initialized
INFO - 2020-09-04 07:29:22 --> Language Class Initialized
INFO - 2020-09-04 07:29:22 --> Loader Class Initialized
INFO - 2020-09-04 07:29:22 --> Helper loaded: url_helper
INFO - 2020-09-04 07:29:22 --> Database Driver Class Initialized
INFO - 2020-09-04 07:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:29:22 --> Email Class Initialized
INFO - 2020-09-04 07:29:22 --> Controller Class Initialized
INFO - 2020-09-04 07:29:22 --> Model Class Initialized
INFO - 2020-09-04 07:29:22 --> Model Class Initialized
DEBUG - 2020-09-04 07:29:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 07:29:22 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-04 07:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:29:23 --> Config Class Initialized
INFO - 2020-09-04 07:29:23 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:29:23 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:29:23 --> Utf8 Class Initialized
INFO - 2020-09-04 07:29:23 --> URI Class Initialized
INFO - 2020-09-04 07:29:23 --> Router Class Initialized
INFO - 2020-09-04 07:29:23 --> Output Class Initialized
INFO - 2020-09-04 07:29:23 --> Security Class Initialized
DEBUG - 2020-09-04 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:29:23 --> Input Class Initialized
INFO - 2020-09-04 07:29:23 --> Language Class Initialized
INFO - 2020-09-04 07:29:23 --> Loader Class Initialized
INFO - 2020-09-04 07:29:23 --> Helper loaded: url_helper
INFO - 2020-09-04 07:29:23 --> Database Driver Class Initialized
INFO - 2020-09-04 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:29:23 --> Email Class Initialized
INFO - 2020-09-04 07:29:23 --> Controller Class Initialized
INFO - 2020-09-04 07:29:23 --> Model Class Initialized
INFO - 2020-09-04 07:29:23 --> Model Class Initialized
DEBUG - 2020-09-04 07:29:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-04 07:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:29:23 --> Config Class Initialized
INFO - 2020-09-04 07:29:23 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:29:23 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:29:23 --> Utf8 Class Initialized
INFO - 2020-09-04 07:29:23 --> URI Class Initialized
DEBUG - 2020-09-04 07:29:23 --> No URI present. Default controller set.
INFO - 2020-09-04 07:29:23 --> Router Class Initialized
INFO - 2020-09-04 07:29:23 --> Output Class Initialized
INFO - 2020-09-04 07:29:23 --> Security Class Initialized
DEBUG - 2020-09-04 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:29:23 --> Input Class Initialized
INFO - 2020-09-04 07:29:23 --> Language Class Initialized
INFO - 2020-09-04 07:29:23 --> Loader Class Initialized
INFO - 2020-09-04 07:29:23 --> Helper loaded: url_helper
INFO - 2020-09-04 07:29:23 --> Database Driver Class Initialized
INFO - 2020-09-04 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:29:23 --> Email Class Initialized
INFO - 2020-09-04 07:29:23 --> Controller Class Initialized
INFO - 2020-09-04 07:29:23 --> Model Class Initialized
INFO - 2020-09-04 07:29:23 --> Model Class Initialized
DEBUG - 2020-09-04 07:29:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-04 07:29:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-04 07:29:23 --> Final output sent to browser
DEBUG - 2020-09-04 07:29:23 --> Total execution time: 0.0205
ERROR - 2020-09-04 07:29:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:29:23 --> Config Class Initialized
INFO - 2020-09-04 07:29:23 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:29:23 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:29:23 --> Utf8 Class Initialized
INFO - 2020-09-04 07:29:23 --> URI Class Initialized
INFO - 2020-09-04 07:29:23 --> Router Class Initialized
INFO - 2020-09-04 07:29:23 --> Output Class Initialized
INFO - 2020-09-04 07:29:23 --> Security Class Initialized
DEBUG - 2020-09-04 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:29:23 --> Input Class Initialized
INFO - 2020-09-04 07:29:23 --> Language Class Initialized
INFO - 2020-09-04 07:29:23 --> Loader Class Initialized
INFO - 2020-09-04 07:29:23 --> Helper loaded: url_helper
INFO - 2020-09-04 07:29:23 --> Database Driver Class Initialized
INFO - 2020-09-04 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:29:23 --> Email Class Initialized
INFO - 2020-09-04 07:29:23 --> Controller Class Initialized
DEBUG - 2020-09-04 07:29:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-04 07:29:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-04 07:29:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-04 07:29:23 --> Final output sent to browser
DEBUG - 2020-09-04 07:29:23 --> Total execution time: 0.0428
ERROR - 2020-09-04 07:32:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-04 07:32:45 --> Config Class Initialized
INFO - 2020-09-04 07:32:45 --> Hooks Class Initialized
DEBUG - 2020-09-04 07:32:45 --> UTF-8 Support Enabled
INFO - 2020-09-04 07:32:45 --> Utf8 Class Initialized
INFO - 2020-09-04 07:32:45 --> URI Class Initialized
DEBUG - 2020-09-04 07:32:45 --> No URI present. Default controller set.
INFO - 2020-09-04 07:32:45 --> Router Class Initialized
INFO - 2020-09-04 07:32:45 --> Output Class Initialized
INFO - 2020-09-04 07:32:45 --> Security Class Initialized
DEBUG - 2020-09-04 07:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-04 07:32:45 --> Input Class Initialized
INFO - 2020-09-04 07:32:45 --> Language Class Initialized
INFO - 2020-09-04 07:32:45 --> Loader Class Initialized
INFO - 2020-09-04 07:32:45 --> Helper loaded: url_helper
INFO - 2020-09-04 07:32:45 --> Database Driver Class Initialized
INFO - 2020-09-04 07:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-04 07:32:45 --> Email Class Initialized
INFO - 2020-09-04 07:32:45 --> Controller Class Initialized
INFO - 2020-09-04 07:32:45 --> Model Class Initialized
INFO - 2020-09-04 07:32:45 --> Model Class Initialized
DEBUG - 2020-09-04 07:32:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-04 07:32:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-04 07:32:45 --> Final output sent to browser
DEBUG - 2020-09-04 07:32:45 --> Total execution time: 0.0229
ERROR - 2020-09-04 07:44:17 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
