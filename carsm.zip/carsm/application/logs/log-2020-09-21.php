<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-21 07:03:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:03:48 --> Config Class Initialized
INFO - 2020-09-21 07:03:48 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:03:48 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:03:48 --> Utf8 Class Initialized
INFO - 2020-09-21 07:03:48 --> URI Class Initialized
DEBUG - 2020-09-21 07:03:48 --> No URI present. Default controller set.
INFO - 2020-09-21 07:03:48 --> Router Class Initialized
INFO - 2020-09-21 07:03:48 --> Output Class Initialized
INFO - 2020-09-21 07:03:48 --> Security Class Initialized
DEBUG - 2020-09-21 07:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:03:48 --> Input Class Initialized
INFO - 2020-09-21 07:03:48 --> Language Class Initialized
INFO - 2020-09-21 07:03:48 --> Loader Class Initialized
INFO - 2020-09-21 07:03:48 --> Helper loaded: url_helper
INFO - 2020-09-21 07:03:48 --> Database Driver Class Initialized
INFO - 2020-09-21 07:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:03:48 --> Email Class Initialized
INFO - 2020-09-21 07:03:48 --> Controller Class Initialized
INFO - 2020-09-21 07:03:48 --> Model Class Initialized
INFO - 2020-09-21 07:03:48 --> Model Class Initialized
DEBUG - 2020-09-21 07:03:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:03:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 07:03:48 --> Final output sent to browser
DEBUG - 2020-09-21 07:03:48 --> Total execution time: 0.0211
ERROR - 2020-09-21 07:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:04:06 --> Config Class Initialized
INFO - 2020-09-21 07:04:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:04:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:04:06 --> Utf8 Class Initialized
INFO - 2020-09-21 07:04:06 --> URI Class Initialized
DEBUG - 2020-09-21 07:04:06 --> No URI present. Default controller set.
INFO - 2020-09-21 07:04:06 --> Router Class Initialized
INFO - 2020-09-21 07:04:06 --> Output Class Initialized
INFO - 2020-09-21 07:04:06 --> Security Class Initialized
DEBUG - 2020-09-21 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:04:06 --> Input Class Initialized
INFO - 2020-09-21 07:04:06 --> Language Class Initialized
INFO - 2020-09-21 07:04:06 --> Loader Class Initialized
INFO - 2020-09-21 07:04:06 --> Helper loaded: url_helper
INFO - 2020-09-21 07:04:06 --> Database Driver Class Initialized
INFO - 2020-09-21 07:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:04:06 --> Email Class Initialized
INFO - 2020-09-21 07:04:06 --> Controller Class Initialized
INFO - 2020-09-21 07:04:06 --> Model Class Initialized
INFO - 2020-09-21 07:04:06 --> Model Class Initialized
DEBUG - 2020-09-21 07:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:04:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 07:04:06 --> Final output sent to browser
DEBUG - 2020-09-21 07:04:06 --> Total execution time: 0.0238
ERROR - 2020-09-21 07:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:04:42 --> Config Class Initialized
INFO - 2020-09-21 07:04:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:04:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:04:42 --> Utf8 Class Initialized
INFO - 2020-09-21 07:04:42 --> URI Class Initialized
ERROR - 2020-09-21 07:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:04:42 --> Router Class Initialized
INFO - 2020-09-21 07:04:42 --> Config Class Initialized
INFO - 2020-09-21 07:04:42 --> Hooks Class Initialized
INFO - 2020-09-21 07:04:42 --> Output Class Initialized
DEBUG - 2020-09-21 07:04:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:04:42 --> Utf8 Class Initialized
INFO - 2020-09-21 07:04:42 --> URI Class Initialized
INFO - 2020-09-21 07:04:42 --> Security Class Initialized
INFO - 2020-09-21 07:04:42 --> Router Class Initialized
DEBUG - 2020-09-21 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:04:42 --> Input Class Initialized
INFO - 2020-09-21 07:04:42 --> Output Class Initialized
INFO - 2020-09-21 07:04:42 --> Language Class Initialized
INFO - 2020-09-21 07:04:42 --> Security Class Initialized
DEBUG - 2020-09-21 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:04:42 --> Input Class Initialized
INFO - 2020-09-21 07:04:42 --> Language Class Initialized
INFO - 2020-09-21 07:04:42 --> Loader Class Initialized
INFO - 2020-09-21 07:04:42 --> Helper loaded: url_helper
INFO - 2020-09-21 07:04:42 --> Loader Class Initialized
INFO - 2020-09-21 07:04:42 --> Helper loaded: url_helper
INFO - 2020-09-21 07:04:42 --> Database Driver Class Initialized
INFO - 2020-09-21 07:04:42 --> Database Driver Class Initialized
INFO - 2020-09-21 07:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:04:42 --> Email Class Initialized
INFO - 2020-09-21 07:04:42 --> Controller Class Initialized
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
DEBUG - 2020-09-21 07:04:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:04:42 --> Email Class Initialized
INFO - 2020-09-21 07:04:42 --> Controller Class Initialized
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
DEBUG - 2020-09-21 07:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:04:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
INFO - 2020-09-21 07:04:42 --> Final output sent to browser
DEBUG - 2020-09-21 07:04:42 --> Total execution time: 0.0399
ERROR - 2020-09-21 07:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:04:42 --> Config Class Initialized
INFO - 2020-09-21 07:04:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:04:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:04:42 --> Utf8 Class Initialized
INFO - 2020-09-21 07:04:42 --> URI Class Initialized
INFO - 2020-09-21 07:04:42 --> Router Class Initialized
INFO - 2020-09-21 07:04:42 --> Output Class Initialized
INFO - 2020-09-21 07:04:42 --> Security Class Initialized
DEBUG - 2020-09-21 07:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:04:42 --> Input Class Initialized
INFO - 2020-09-21 07:04:42 --> Language Class Initialized
INFO - 2020-09-21 07:04:42 --> Loader Class Initialized
INFO - 2020-09-21 07:04:42 --> Helper loaded: url_helper
INFO - 2020-09-21 07:04:42 --> Database Driver Class Initialized
INFO - 2020-09-21 07:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:04:42 --> Email Class Initialized
INFO - 2020-09-21 07:04:42 --> Controller Class Initialized
DEBUG - 2020-09-21 07:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:04:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
INFO - 2020-09-21 07:04:42 --> Model Class Initialized
INFO - 2020-09-21 07:04:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 07:04:42 --> Final output sent to browser
DEBUG - 2020-09-21 07:04:42 --> Total execution time: 0.0630
ERROR - 2020-09-21 07:04:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:04:51 --> Config Class Initialized
INFO - 2020-09-21 07:04:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:04:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:04:51 --> Utf8 Class Initialized
INFO - 2020-09-21 07:04:51 --> URI Class Initialized
INFO - 2020-09-21 07:04:51 --> Router Class Initialized
INFO - 2020-09-21 07:04:51 --> Output Class Initialized
INFO - 2020-09-21 07:04:51 --> Security Class Initialized
DEBUG - 2020-09-21 07:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:04:51 --> Input Class Initialized
INFO - 2020-09-21 07:04:51 --> Language Class Initialized
INFO - 2020-09-21 07:04:51 --> Loader Class Initialized
INFO - 2020-09-21 07:04:51 --> Helper loaded: url_helper
INFO - 2020-09-21 07:04:51 --> Database Driver Class Initialized
INFO - 2020-09-21 07:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:04:51 --> Email Class Initialized
INFO - 2020-09-21 07:04:51 --> Controller Class Initialized
DEBUG - 2020-09-21 07:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:04:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:04:51 --> Model Class Initialized
INFO - 2020-09-21 07:04:51 --> Model Class Initialized
INFO - 2020-09-21 07:04:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:04:51 --> Final output sent to browser
DEBUG - 2020-09-21 07:04:51 --> Total execution time: 0.0373
ERROR - 2020-09-21 07:04:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:04:56 --> Config Class Initialized
INFO - 2020-09-21 07:04:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:04:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:04:56 --> Utf8 Class Initialized
INFO - 2020-09-21 07:04:56 --> URI Class Initialized
INFO - 2020-09-21 07:04:56 --> Router Class Initialized
INFO - 2020-09-21 07:04:56 --> Output Class Initialized
INFO - 2020-09-21 07:04:56 --> Security Class Initialized
DEBUG - 2020-09-21 07:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:04:56 --> Input Class Initialized
INFO - 2020-09-21 07:04:56 --> Language Class Initialized
INFO - 2020-09-21 07:04:56 --> Loader Class Initialized
INFO - 2020-09-21 07:04:56 --> Helper loaded: url_helper
INFO - 2020-09-21 07:04:56 --> Database Driver Class Initialized
INFO - 2020-09-21 07:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:04:56 --> Email Class Initialized
INFO - 2020-09-21 07:04:56 --> Controller Class Initialized
DEBUG - 2020-09-21 07:04:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:04:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:04:56 --> Model Class Initialized
INFO - 2020-09-21 07:04:56 --> Model Class Initialized
INFO - 2020-09-21 07:04:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:04:56 --> Final output sent to browser
DEBUG - 2020-09-21 07:04:56 --> Total execution time: 0.0443
ERROR - 2020-09-21 07:05:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:05:03 --> Config Class Initialized
INFO - 2020-09-21 07:05:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:05:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:05:03 --> Utf8 Class Initialized
INFO - 2020-09-21 07:05:03 --> URI Class Initialized
INFO - 2020-09-21 07:05:03 --> Router Class Initialized
INFO - 2020-09-21 07:05:03 --> Output Class Initialized
INFO - 2020-09-21 07:05:03 --> Security Class Initialized
DEBUG - 2020-09-21 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:05:03 --> Input Class Initialized
INFO - 2020-09-21 07:05:03 --> Language Class Initialized
INFO - 2020-09-21 07:05:03 --> Loader Class Initialized
INFO - 2020-09-21 07:05:03 --> Helper loaded: url_helper
INFO - 2020-09-21 07:05:03 --> Database Driver Class Initialized
INFO - 2020-09-21 07:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:05:03 --> Email Class Initialized
INFO - 2020-09-21 07:05:03 --> Controller Class Initialized
DEBUG - 2020-09-21 07:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:05:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:05:03 --> Model Class Initialized
INFO - 2020-09-21 07:05:03 --> Model Class Initialized
INFO - 2020-09-21 07:05:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:05:03 --> Final output sent to browser
DEBUG - 2020-09-21 07:05:03 --> Total execution time: 0.0263
ERROR - 2020-09-21 07:05:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:05:06 --> Config Class Initialized
INFO - 2020-09-21 07:05:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:05:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:05:06 --> Utf8 Class Initialized
INFO - 2020-09-21 07:05:06 --> URI Class Initialized
INFO - 2020-09-21 07:05:06 --> Router Class Initialized
INFO - 2020-09-21 07:05:06 --> Output Class Initialized
INFO - 2020-09-21 07:05:06 --> Security Class Initialized
DEBUG - 2020-09-21 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:05:06 --> Input Class Initialized
INFO - 2020-09-21 07:05:06 --> Language Class Initialized
INFO - 2020-09-21 07:05:06 --> Loader Class Initialized
INFO - 2020-09-21 07:05:06 --> Helper loaded: url_helper
INFO - 2020-09-21 07:05:06 --> Database Driver Class Initialized
INFO - 2020-09-21 07:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:05:06 --> Email Class Initialized
INFO - 2020-09-21 07:05:06 --> Controller Class Initialized
DEBUG - 2020-09-21 07:05:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:05:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:05:06 --> Model Class Initialized
INFO - 2020-09-21 07:05:06 --> Model Class Initialized
INFO - 2020-09-21 07:05:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:05:06 --> Final output sent to browser
DEBUG - 2020-09-21 07:05:06 --> Total execution time: 0.0276
ERROR - 2020-09-21 07:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:05:16 --> Config Class Initialized
INFO - 2020-09-21 07:05:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:05:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:05:16 --> Utf8 Class Initialized
INFO - 2020-09-21 07:05:16 --> URI Class Initialized
INFO - 2020-09-21 07:05:16 --> Router Class Initialized
INFO - 2020-09-21 07:05:16 --> Output Class Initialized
INFO - 2020-09-21 07:05:16 --> Security Class Initialized
DEBUG - 2020-09-21 07:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:05:16 --> Input Class Initialized
INFO - 2020-09-21 07:05:16 --> Language Class Initialized
INFO - 2020-09-21 07:05:16 --> Loader Class Initialized
INFO - 2020-09-21 07:05:16 --> Helper loaded: url_helper
INFO - 2020-09-21 07:05:16 --> Database Driver Class Initialized
INFO - 2020-09-21 07:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:05:16 --> Email Class Initialized
INFO - 2020-09-21 07:05:16 --> Controller Class Initialized
DEBUG - 2020-09-21 07:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:05:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:05:16 --> Model Class Initialized
INFO - 2020-09-21 07:05:16 --> Model Class Initialized
INFO - 2020-09-21 07:05:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:05:16 --> Final output sent to browser
DEBUG - 2020-09-21 07:05:16 --> Total execution time: 0.0271
ERROR - 2020-09-21 07:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:05:19 --> Config Class Initialized
INFO - 2020-09-21 07:05:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:05:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:05:19 --> Utf8 Class Initialized
INFO - 2020-09-21 07:05:19 --> URI Class Initialized
INFO - 2020-09-21 07:05:19 --> Router Class Initialized
INFO - 2020-09-21 07:05:19 --> Output Class Initialized
INFO - 2020-09-21 07:05:19 --> Security Class Initialized
DEBUG - 2020-09-21 07:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:05:19 --> Input Class Initialized
INFO - 2020-09-21 07:05:19 --> Language Class Initialized
INFO - 2020-09-21 07:05:19 --> Loader Class Initialized
INFO - 2020-09-21 07:05:19 --> Helper loaded: url_helper
INFO - 2020-09-21 07:05:19 --> Database Driver Class Initialized
INFO - 2020-09-21 07:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:05:19 --> Email Class Initialized
INFO - 2020-09-21 07:05:19 --> Controller Class Initialized
DEBUG - 2020-09-21 07:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:05:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:05:19 --> Model Class Initialized
INFO - 2020-09-21 07:05:19 --> Model Class Initialized
INFO - 2020-09-21 07:05:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-21 07:05:19 --> Final output sent to browser
DEBUG - 2020-09-21 07:05:19 --> Total execution time: 0.0301
ERROR - 2020-09-21 07:05:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:05:59 --> Config Class Initialized
INFO - 2020-09-21 07:05:59 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:05:59 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:05:59 --> Utf8 Class Initialized
INFO - 2020-09-21 07:05:59 --> URI Class Initialized
INFO - 2020-09-21 07:05:59 --> Router Class Initialized
INFO - 2020-09-21 07:05:59 --> Output Class Initialized
INFO - 2020-09-21 07:05:59 --> Security Class Initialized
DEBUG - 2020-09-21 07:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:05:59 --> Input Class Initialized
INFO - 2020-09-21 07:05:59 --> Language Class Initialized
INFO - 2020-09-21 07:05:59 --> Loader Class Initialized
INFO - 2020-09-21 07:05:59 --> Helper loaded: url_helper
INFO - 2020-09-21 07:05:59 --> Database Driver Class Initialized
INFO - 2020-09-21 07:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:05:59 --> Email Class Initialized
INFO - 2020-09-21 07:05:59 --> Controller Class Initialized
DEBUG - 2020-09-21 07:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:05:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:05:59 --> Model Class Initialized
INFO - 2020-09-21 07:05:59 --> Model Class Initialized
INFO - 2020-09-21 07:05:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:05:59 --> Final output sent to browser
DEBUG - 2020-09-21 07:05:59 --> Total execution time: 0.0289
ERROR - 2020-09-21 07:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:06:02 --> Config Class Initialized
INFO - 2020-09-21 07:06:02 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:06:02 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:06:02 --> Utf8 Class Initialized
INFO - 2020-09-21 07:06:02 --> URI Class Initialized
INFO - 2020-09-21 07:06:02 --> Router Class Initialized
INFO - 2020-09-21 07:06:02 --> Output Class Initialized
INFO - 2020-09-21 07:06:02 --> Security Class Initialized
DEBUG - 2020-09-21 07:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:06:02 --> Input Class Initialized
INFO - 2020-09-21 07:06:02 --> Language Class Initialized
INFO - 2020-09-21 07:06:02 --> Loader Class Initialized
INFO - 2020-09-21 07:06:02 --> Helper loaded: url_helper
INFO - 2020-09-21 07:06:02 --> Database Driver Class Initialized
INFO - 2020-09-21 07:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:06:02 --> Email Class Initialized
INFO - 2020-09-21 07:06:02 --> Controller Class Initialized
DEBUG - 2020-09-21 07:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:06:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:06:02 --> Model Class Initialized
INFO - 2020-09-21 07:06:02 --> Model Class Initialized
INFO - 2020-09-21 07:06:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:06:02 --> Final output sent to browser
DEBUG - 2020-09-21 07:06:02 --> Total execution time: 0.0250
ERROR - 2020-09-21 07:06:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:06:25 --> Config Class Initialized
INFO - 2020-09-21 07:06:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:06:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:06:25 --> Utf8 Class Initialized
INFO - 2020-09-21 07:06:25 --> URI Class Initialized
INFO - 2020-09-21 07:06:25 --> Router Class Initialized
INFO - 2020-09-21 07:06:25 --> Output Class Initialized
INFO - 2020-09-21 07:06:25 --> Security Class Initialized
DEBUG - 2020-09-21 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:06:25 --> Input Class Initialized
INFO - 2020-09-21 07:06:25 --> Language Class Initialized
INFO - 2020-09-21 07:06:25 --> Loader Class Initialized
INFO - 2020-09-21 07:06:25 --> Helper loaded: url_helper
INFO - 2020-09-21 07:06:25 --> Database Driver Class Initialized
INFO - 2020-09-21 07:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:06:25 --> Email Class Initialized
INFO - 2020-09-21 07:06:25 --> Controller Class Initialized
DEBUG - 2020-09-21 07:06:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:06:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:06:25 --> Model Class Initialized
INFO - 2020-09-21 07:06:25 --> Model Class Initialized
INFO - 2020-09-21 07:06:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:06:25 --> Final output sent to browser
DEBUG - 2020-09-21 07:06:25 --> Total execution time: 0.0412
ERROR - 2020-09-21 07:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:06:28 --> Config Class Initialized
INFO - 2020-09-21 07:06:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:06:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:06:28 --> Utf8 Class Initialized
INFO - 2020-09-21 07:06:28 --> URI Class Initialized
INFO - 2020-09-21 07:06:28 --> Router Class Initialized
INFO - 2020-09-21 07:06:28 --> Output Class Initialized
INFO - 2020-09-21 07:06:28 --> Security Class Initialized
DEBUG - 2020-09-21 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:06:28 --> Input Class Initialized
INFO - 2020-09-21 07:06:28 --> Language Class Initialized
INFO - 2020-09-21 07:06:28 --> Loader Class Initialized
INFO - 2020-09-21 07:06:28 --> Helper loaded: url_helper
INFO - 2020-09-21 07:06:28 --> Database Driver Class Initialized
INFO - 2020-09-21 07:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:06:28 --> Email Class Initialized
INFO - 2020-09-21 07:06:28 --> Controller Class Initialized
DEBUG - 2020-09-21 07:06:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:06:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:06:28 --> Model Class Initialized
INFO - 2020-09-21 07:06:28 --> Model Class Initialized
INFO - 2020-09-21 07:06:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:06:28 --> Final output sent to browser
DEBUG - 2020-09-21 07:06:28 --> Total execution time: 0.0311
ERROR - 2020-09-21 07:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:22:43 --> Config Class Initialized
INFO - 2020-09-21 07:22:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:22:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:22:43 --> Utf8 Class Initialized
INFO - 2020-09-21 07:22:43 --> URI Class Initialized
INFO - 2020-09-21 07:22:43 --> Router Class Initialized
INFO - 2020-09-21 07:22:43 --> Output Class Initialized
INFO - 2020-09-21 07:22:43 --> Security Class Initialized
DEBUG - 2020-09-21 07:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:22:43 --> Input Class Initialized
INFO - 2020-09-21 07:22:43 --> Language Class Initialized
INFO - 2020-09-21 07:22:43 --> Loader Class Initialized
INFO - 2020-09-21 07:22:43 --> Helper loaded: url_helper
INFO - 2020-09-21 07:22:43 --> Database Driver Class Initialized
INFO - 2020-09-21 07:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:22:43 --> Email Class Initialized
INFO - 2020-09-21 07:22:43 --> Controller Class Initialized
DEBUG - 2020-09-21 07:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:22:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:22:43 --> Model Class Initialized
INFO - 2020-09-21 07:22:43 --> Model Class Initialized
INFO - 2020-09-21 07:22:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 07:22:43 --> Final output sent to browser
DEBUG - 2020-09-21 07:22:43 --> Total execution time: 0.0282
ERROR - 2020-09-21 07:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:23:19 --> Config Class Initialized
INFO - 2020-09-21 07:23:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:23:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:23:19 --> Utf8 Class Initialized
INFO - 2020-09-21 07:23:19 --> URI Class Initialized
DEBUG - 2020-09-21 07:23:19 --> No URI present. Default controller set.
INFO - 2020-09-21 07:23:19 --> Router Class Initialized
INFO - 2020-09-21 07:23:19 --> Output Class Initialized
INFO - 2020-09-21 07:23:19 --> Security Class Initialized
DEBUG - 2020-09-21 07:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:23:19 --> Input Class Initialized
INFO - 2020-09-21 07:23:19 --> Language Class Initialized
INFO - 2020-09-21 07:23:19 --> Loader Class Initialized
INFO - 2020-09-21 07:23:19 --> Helper loaded: url_helper
INFO - 2020-09-21 07:23:19 --> Database Driver Class Initialized
INFO - 2020-09-21 07:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:23:19 --> Email Class Initialized
INFO - 2020-09-21 07:23:19 --> Controller Class Initialized
INFO - 2020-09-21 07:23:19 --> Model Class Initialized
INFO - 2020-09-21 07:23:19 --> Model Class Initialized
DEBUG - 2020-09-21 07:23:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:23:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 07:23:19 --> Final output sent to browser
DEBUG - 2020-09-21 07:23:19 --> Total execution time: 0.0207
ERROR - 2020-09-21 07:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:23:37 --> Config Class Initialized
INFO - 2020-09-21 07:23:37 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:23:37 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:23:37 --> Utf8 Class Initialized
INFO - 2020-09-21 07:23:37 --> URI Class Initialized
INFO - 2020-09-21 07:23:37 --> Router Class Initialized
INFO - 2020-09-21 07:23:37 --> Output Class Initialized
INFO - 2020-09-21 07:23:37 --> Security Class Initialized
DEBUG - 2020-09-21 07:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:23:37 --> Input Class Initialized
INFO - 2020-09-21 07:23:37 --> Language Class Initialized
INFO - 2020-09-21 07:23:37 --> Loader Class Initialized
INFO - 2020-09-21 07:23:37 --> Helper loaded: url_helper
INFO - 2020-09-21 07:23:37 --> Database Driver Class Initialized
INFO - 2020-09-21 07:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:23:37 --> Email Class Initialized
INFO - 2020-09-21 07:23:37 --> Controller Class Initialized
INFO - 2020-09-21 07:23:37 --> Model Class Initialized
INFO - 2020-09-21 07:23:37 --> Model Class Initialized
DEBUG - 2020-09-21 07:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:23:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:23:37 --> Model Class Initialized
INFO - 2020-09-21 07:23:37 --> Final output sent to browser
DEBUG - 2020-09-21 07:23:37 --> Total execution time: 0.0217
ERROR - 2020-09-21 07:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:23:38 --> Config Class Initialized
INFO - 2020-09-21 07:23:38 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:23:38 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:23:38 --> Utf8 Class Initialized
INFO - 2020-09-21 07:23:38 --> URI Class Initialized
INFO - 2020-09-21 07:23:38 --> Router Class Initialized
INFO - 2020-09-21 07:23:38 --> Output Class Initialized
INFO - 2020-09-21 07:23:38 --> Security Class Initialized
DEBUG - 2020-09-21 07:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:23:38 --> Input Class Initialized
INFO - 2020-09-21 07:23:38 --> Language Class Initialized
INFO - 2020-09-21 07:23:38 --> Loader Class Initialized
INFO - 2020-09-21 07:23:38 --> Helper loaded: url_helper
INFO - 2020-09-21 07:23:38 --> Database Driver Class Initialized
INFO - 2020-09-21 07:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:23:38 --> Email Class Initialized
INFO - 2020-09-21 07:23:38 --> Controller Class Initialized
INFO - 2020-09-21 07:23:38 --> Model Class Initialized
INFO - 2020-09-21 07:23:38 --> Model Class Initialized
DEBUG - 2020-09-21 07:23:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 07:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:23:38 --> Config Class Initialized
INFO - 2020-09-21 07:23:38 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:23:38 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:23:38 --> Utf8 Class Initialized
INFO - 2020-09-21 07:23:38 --> URI Class Initialized
INFO - 2020-09-21 07:23:38 --> Router Class Initialized
INFO - 2020-09-21 07:23:38 --> Output Class Initialized
INFO - 2020-09-21 07:23:38 --> Security Class Initialized
DEBUG - 2020-09-21 07:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:23:38 --> Input Class Initialized
INFO - 2020-09-21 07:23:38 --> Language Class Initialized
INFO - 2020-09-21 07:23:38 --> Loader Class Initialized
INFO - 2020-09-21 07:23:38 --> Helper loaded: url_helper
INFO - 2020-09-21 07:23:38 --> Database Driver Class Initialized
INFO - 2020-09-21 07:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:23:38 --> Email Class Initialized
INFO - 2020-09-21 07:23:38 --> Controller Class Initialized
DEBUG - 2020-09-21 07:23:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:23:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:23:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-21 07:23:38 --> Final output sent to browser
DEBUG - 2020-09-21 07:23:38 --> Total execution time: 0.0338
ERROR - 2020-09-21 07:23:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:23:49 --> Config Class Initialized
INFO - 2020-09-21 07:23:49 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:23:49 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:23:49 --> Utf8 Class Initialized
INFO - 2020-09-21 07:23:49 --> URI Class Initialized
INFO - 2020-09-21 07:23:49 --> Router Class Initialized
INFO - 2020-09-21 07:23:49 --> Output Class Initialized
INFO - 2020-09-21 07:23:49 --> Security Class Initialized
DEBUG - 2020-09-21 07:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:23:49 --> Input Class Initialized
INFO - 2020-09-21 07:23:49 --> Language Class Initialized
INFO - 2020-09-21 07:23:49 --> Loader Class Initialized
INFO - 2020-09-21 07:23:49 --> Helper loaded: url_helper
INFO - 2020-09-21 07:23:49 --> Database Driver Class Initialized
INFO - 2020-09-21 07:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:23:49 --> Email Class Initialized
INFO - 2020-09-21 07:23:49 --> Controller Class Initialized
DEBUG - 2020-09-21 07:23:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:23:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:23:49 --> Model Class Initialized
INFO - 2020-09-21 07:23:49 --> Model Class Initialized
INFO - 2020-09-21 07:23:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-21 07:23:49 --> Final output sent to browser
DEBUG - 2020-09-21 07:23:49 --> Total execution time: 0.0585
ERROR - 2020-09-21 07:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:24:08 --> Config Class Initialized
INFO - 2020-09-21 07:24:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:24:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:24:08 --> Utf8 Class Initialized
INFO - 2020-09-21 07:24:08 --> URI Class Initialized
INFO - 2020-09-21 07:24:08 --> Router Class Initialized
INFO - 2020-09-21 07:24:08 --> Output Class Initialized
INFO - 2020-09-21 07:24:08 --> Security Class Initialized
DEBUG - 2020-09-21 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:24:08 --> Input Class Initialized
INFO - 2020-09-21 07:24:08 --> Language Class Initialized
INFO - 2020-09-21 07:24:08 --> Loader Class Initialized
INFO - 2020-09-21 07:24:08 --> Helper loaded: url_helper
INFO - 2020-09-21 07:24:08 --> Database Driver Class Initialized
INFO - 2020-09-21 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:24:08 --> Email Class Initialized
INFO - 2020-09-21 07:24:08 --> Controller Class Initialized
INFO - 2020-09-21 07:24:08 --> Model Class Initialized
INFO - 2020-09-21 07:24:08 --> Model Class Initialized
INFO - 2020-09-21 07:24:08 --> Model Class Initialized
INFO - 2020-09-21 07:24:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 07:24:08 --> Final output sent to browser
DEBUG - 2020-09-21 07:24:08 --> Total execution time: 0.2101
ERROR - 2020-09-21 07:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:24:08 --> Config Class Initialized
INFO - 2020-09-21 07:24:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:24:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:24:08 --> Utf8 Class Initialized
INFO - 2020-09-21 07:24:08 --> URI Class Initialized
INFO - 2020-09-21 07:24:08 --> Router Class Initialized
INFO - 2020-09-21 07:24:08 --> Output Class Initialized
INFO - 2020-09-21 07:24:08 --> Security Class Initialized
DEBUG - 2020-09-21 07:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:24:08 --> Input Class Initialized
INFO - 2020-09-21 07:24:08 --> Language Class Initialized
INFO - 2020-09-21 07:24:08 --> Loader Class Initialized
INFO - 2020-09-21 07:24:08 --> Helper loaded: url_helper
INFO - 2020-09-21 07:24:08 --> Database Driver Class Initialized
INFO - 2020-09-21 07:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:24:08 --> Email Class Initialized
INFO - 2020-09-21 07:24:08 --> Controller Class Initialized
INFO - 2020-09-21 07:24:08 --> Model Class Initialized
INFO - 2020-09-21 07:24:08 --> Model Class Initialized
INFO - 2020-09-21 07:24:08 --> Final output sent to browser
DEBUG - 2020-09-21 07:24:08 --> Total execution time: 0.0485
ERROR - 2020-09-21 07:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:24:43 --> Config Class Initialized
INFO - 2020-09-21 07:24:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:24:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:24:43 --> Utf8 Class Initialized
INFO - 2020-09-21 07:24:43 --> URI Class Initialized
INFO - 2020-09-21 07:24:43 --> Router Class Initialized
INFO - 2020-09-21 07:24:43 --> Output Class Initialized
INFO - 2020-09-21 07:24:43 --> Security Class Initialized
DEBUG - 2020-09-21 07:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:24:43 --> Input Class Initialized
INFO - 2020-09-21 07:24:43 --> Language Class Initialized
INFO - 2020-09-21 07:24:43 --> Loader Class Initialized
INFO - 2020-09-21 07:24:43 --> Helper loaded: url_helper
INFO - 2020-09-21 07:24:43 --> Database Driver Class Initialized
INFO - 2020-09-21 07:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:24:43 --> Email Class Initialized
INFO - 2020-09-21 07:24:43 --> Controller Class Initialized
INFO - 2020-09-21 07:24:43 --> Model Class Initialized
INFO - 2020-09-21 07:24:43 --> Model Class Initialized
INFO - 2020-09-21 07:24:43 --> Final output sent to browser
DEBUG - 2020-09-21 07:24:43 --> Total execution time: 0.2030
ERROR - 2020-09-21 07:24:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:24:44 --> Config Class Initialized
INFO - 2020-09-21 07:24:44 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:24:44 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:24:44 --> Utf8 Class Initialized
INFO - 2020-09-21 07:24:44 --> URI Class Initialized
INFO - 2020-09-21 07:24:44 --> Router Class Initialized
INFO - 2020-09-21 07:24:44 --> Output Class Initialized
INFO - 2020-09-21 07:24:44 --> Security Class Initialized
DEBUG - 2020-09-21 07:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:24:44 --> Input Class Initialized
INFO - 2020-09-21 07:24:44 --> Language Class Initialized
INFO - 2020-09-21 07:24:44 --> Loader Class Initialized
INFO - 2020-09-21 07:24:44 --> Helper loaded: url_helper
INFO - 2020-09-21 07:24:44 --> Database Driver Class Initialized
INFO - 2020-09-21 07:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:24:44 --> Email Class Initialized
INFO - 2020-09-21 07:24:44 --> Controller Class Initialized
INFO - 2020-09-21 07:24:44 --> Model Class Initialized
INFO - 2020-09-21 07:24:44 --> Model Class Initialized
INFO - 2020-09-21 07:24:44 --> Final output sent to browser
DEBUG - 2020-09-21 07:24:44 --> Total execution time: 0.0474
ERROR - 2020-09-21 07:24:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:24:53 --> Config Class Initialized
INFO - 2020-09-21 07:24:53 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:24:53 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:24:53 --> Utf8 Class Initialized
INFO - 2020-09-21 07:24:53 --> URI Class Initialized
INFO - 2020-09-21 07:24:53 --> Router Class Initialized
INFO - 2020-09-21 07:24:53 --> Output Class Initialized
INFO - 2020-09-21 07:24:53 --> Security Class Initialized
DEBUG - 2020-09-21 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:24:53 --> Input Class Initialized
INFO - 2020-09-21 07:24:53 --> Language Class Initialized
INFO - 2020-09-21 07:24:53 --> Loader Class Initialized
INFO - 2020-09-21 07:24:53 --> Helper loaded: url_helper
INFO - 2020-09-21 07:24:53 --> Database Driver Class Initialized
INFO - 2020-09-21 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:24:53 --> Email Class Initialized
INFO - 2020-09-21 07:24:53 --> Controller Class Initialized
INFO - 2020-09-21 07:24:53 --> Model Class Initialized
INFO - 2020-09-21 07:24:53 --> Model Class Initialized
INFO - 2020-09-21 07:24:53 --> Model Class Initialized
INFO - 2020-09-21 07:24:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 07:24:53 --> Final output sent to browser
DEBUG - 2020-09-21 07:24:53 --> Total execution time: 0.0513
ERROR - 2020-09-21 07:25:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:25:41 --> Config Class Initialized
INFO - 2020-09-21 07:25:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:25:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:25:41 --> Utf8 Class Initialized
INFO - 2020-09-21 07:25:41 --> URI Class Initialized
INFO - 2020-09-21 07:25:41 --> Router Class Initialized
INFO - 2020-09-21 07:25:41 --> Output Class Initialized
INFO - 2020-09-21 07:25:41 --> Security Class Initialized
DEBUG - 2020-09-21 07:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:25:41 --> Input Class Initialized
INFO - 2020-09-21 07:25:41 --> Language Class Initialized
INFO - 2020-09-21 07:25:41 --> Loader Class Initialized
INFO - 2020-09-21 07:25:41 --> Helper loaded: url_helper
INFO - 2020-09-21 07:25:41 --> Database Driver Class Initialized
INFO - 2020-09-21 07:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:25:41 --> Email Class Initialized
INFO - 2020-09-21 07:25:41 --> Controller Class Initialized
DEBUG - 2020-09-21 07:25:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:25:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:25:41 --> Model Class Initialized
INFO - 2020-09-21 07:25:41 --> Model Class Initialized
INFO - 2020-09-21 07:25:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 07:25:41 --> Final output sent to browser
DEBUG - 2020-09-21 07:25:41 --> Total execution time: 0.0391
ERROR - 2020-09-21 07:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:26:26 --> Config Class Initialized
INFO - 2020-09-21 07:26:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:26:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:26:26 --> Utf8 Class Initialized
INFO - 2020-09-21 07:26:26 --> URI Class Initialized
DEBUG - 2020-09-21 07:26:26 --> No URI present. Default controller set.
INFO - 2020-09-21 07:26:26 --> Router Class Initialized
INFO - 2020-09-21 07:26:26 --> Output Class Initialized
INFO - 2020-09-21 07:26:26 --> Security Class Initialized
DEBUG - 2020-09-21 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:26:26 --> Input Class Initialized
INFO - 2020-09-21 07:26:26 --> Language Class Initialized
INFO - 2020-09-21 07:26:26 --> Loader Class Initialized
INFO - 2020-09-21 07:26:26 --> Helper loaded: url_helper
INFO - 2020-09-21 07:26:26 --> Database Driver Class Initialized
INFO - 2020-09-21 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:26:26 --> Email Class Initialized
INFO - 2020-09-21 07:26:26 --> Controller Class Initialized
INFO - 2020-09-21 07:26:26 --> Model Class Initialized
INFO - 2020-09-21 07:26:26 --> Model Class Initialized
DEBUG - 2020-09-21 07:26:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:26:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 07:26:26 --> Final output sent to browser
DEBUG - 2020-09-21 07:26:26 --> Total execution time: 0.0203
ERROR - 2020-09-21 07:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:26:31 --> Config Class Initialized
INFO - 2020-09-21 07:26:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:26:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:26:31 --> Utf8 Class Initialized
INFO - 2020-09-21 07:26:31 --> URI Class Initialized
INFO - 2020-09-21 07:26:31 --> Router Class Initialized
INFO - 2020-09-21 07:26:31 --> Output Class Initialized
INFO - 2020-09-21 07:26:31 --> Security Class Initialized
DEBUG - 2020-09-21 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:26:31 --> Input Class Initialized
INFO - 2020-09-21 07:26:31 --> Language Class Initialized
INFO - 2020-09-21 07:26:31 --> Loader Class Initialized
INFO - 2020-09-21 07:26:31 --> Helper loaded: url_helper
INFO - 2020-09-21 07:26:31 --> Database Driver Class Initialized
INFO - 2020-09-21 07:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:26:31 --> Email Class Initialized
INFO - 2020-09-21 07:26:31 --> Controller Class Initialized
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
DEBUG - 2020-09-21 07:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:26:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
INFO - 2020-09-21 07:26:31 --> Final output sent to browser
DEBUG - 2020-09-21 07:26:31 --> Total execution time: 0.0251
ERROR - 2020-09-21 07:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:26:31 --> Config Class Initialized
INFO - 2020-09-21 07:26:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:26:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:26:31 --> Utf8 Class Initialized
INFO - 2020-09-21 07:26:31 --> URI Class Initialized
INFO - 2020-09-21 07:26:31 --> Router Class Initialized
INFO - 2020-09-21 07:26:31 --> Output Class Initialized
INFO - 2020-09-21 07:26:31 --> Security Class Initialized
DEBUG - 2020-09-21 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:26:31 --> Input Class Initialized
INFO - 2020-09-21 07:26:31 --> Language Class Initialized
INFO - 2020-09-21 07:26:31 --> Loader Class Initialized
INFO - 2020-09-21 07:26:31 --> Helper loaded: url_helper
INFO - 2020-09-21 07:26:31 --> Database Driver Class Initialized
INFO - 2020-09-21 07:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:26:31 --> Email Class Initialized
INFO - 2020-09-21 07:26:31 --> Controller Class Initialized
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
DEBUG - 2020-09-21 07:26:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 07:26:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:26:31 --> Config Class Initialized
INFO - 2020-09-21 07:26:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:26:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:26:31 --> Utf8 Class Initialized
INFO - 2020-09-21 07:26:31 --> URI Class Initialized
INFO - 2020-09-21 07:26:31 --> Router Class Initialized
INFO - 2020-09-21 07:26:31 --> Output Class Initialized
INFO - 2020-09-21 07:26:31 --> Security Class Initialized
DEBUG - 2020-09-21 07:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:26:31 --> Input Class Initialized
INFO - 2020-09-21 07:26:31 --> Language Class Initialized
INFO - 2020-09-21 07:26:31 --> Loader Class Initialized
INFO - 2020-09-21 07:26:31 --> Helper loaded: url_helper
INFO - 2020-09-21 07:26:31 --> Database Driver Class Initialized
INFO - 2020-09-21 07:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:26:31 --> Email Class Initialized
INFO - 2020-09-21 07:26:31 --> Controller Class Initialized
DEBUG - 2020-09-21 07:26:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:26:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
INFO - 2020-09-21 07:26:31 --> Model Class Initialized
INFO - 2020-09-21 07:26:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 07:26:31 --> Final output sent to browser
DEBUG - 2020-09-21 07:26:31 --> Total execution time: 0.0605
ERROR - 2020-09-21 07:26:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:26:42 --> Config Class Initialized
INFO - 2020-09-21 07:26:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:26:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:26:42 --> Utf8 Class Initialized
INFO - 2020-09-21 07:26:42 --> URI Class Initialized
INFO - 2020-09-21 07:26:42 --> Router Class Initialized
INFO - 2020-09-21 07:26:42 --> Output Class Initialized
INFO - 2020-09-21 07:26:42 --> Security Class Initialized
DEBUG - 2020-09-21 07:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:26:42 --> Input Class Initialized
INFO - 2020-09-21 07:26:42 --> Language Class Initialized
INFO - 2020-09-21 07:26:42 --> Loader Class Initialized
INFO - 2020-09-21 07:26:42 --> Helper loaded: url_helper
INFO - 2020-09-21 07:26:42 --> Database Driver Class Initialized
INFO - 2020-09-21 07:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:26:42 --> Email Class Initialized
INFO - 2020-09-21 07:26:42 --> Controller Class Initialized
DEBUG - 2020-09-21 07:26:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:26:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:26:42 --> Model Class Initialized
INFO - 2020-09-21 07:26:42 --> Model Class Initialized
INFO - 2020-09-21 07:26:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 07:26:42 --> Final output sent to browser
DEBUG - 2020-09-21 07:26:42 --> Total execution time: 0.0600
ERROR - 2020-09-21 07:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:27:12 --> Config Class Initialized
INFO - 2020-09-21 07:27:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:27:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:27:12 --> Utf8 Class Initialized
INFO - 2020-09-21 07:27:12 --> URI Class Initialized
INFO - 2020-09-21 07:27:12 --> Router Class Initialized
INFO - 2020-09-21 07:27:12 --> Output Class Initialized
INFO - 2020-09-21 07:27:12 --> Security Class Initialized
DEBUG - 2020-09-21 07:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:27:12 --> Input Class Initialized
INFO - 2020-09-21 07:27:12 --> Language Class Initialized
INFO - 2020-09-21 07:27:12 --> Loader Class Initialized
INFO - 2020-09-21 07:27:12 --> Helper loaded: url_helper
INFO - 2020-09-21 07:27:12 --> Database Driver Class Initialized
INFO - 2020-09-21 07:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:27:12 --> Email Class Initialized
INFO - 2020-09-21 07:27:12 --> Controller Class Initialized
DEBUG - 2020-09-21 07:27:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:27:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:27:12 --> Model Class Initialized
INFO - 2020-09-21 07:27:12 --> Model Class Initialized
INFO - 2020-09-21 07:27:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-21 07:27:12 --> Final output sent to browser
DEBUG - 2020-09-21 07:27:12 --> Total execution time: 0.0487
ERROR - 2020-09-21 07:27:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:27:17 --> Config Class Initialized
INFO - 2020-09-21 07:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:27:17 --> Utf8 Class Initialized
INFO - 2020-09-21 07:27:17 --> URI Class Initialized
INFO - 2020-09-21 07:27:17 --> Router Class Initialized
INFO - 2020-09-21 07:27:17 --> Output Class Initialized
INFO - 2020-09-21 07:27:17 --> Security Class Initialized
DEBUG - 2020-09-21 07:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:27:17 --> Input Class Initialized
INFO - 2020-09-21 07:27:17 --> Language Class Initialized
INFO - 2020-09-21 07:27:17 --> Loader Class Initialized
INFO - 2020-09-21 07:27:17 --> Helper loaded: url_helper
INFO - 2020-09-21 07:27:17 --> Database Driver Class Initialized
INFO - 2020-09-21 07:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:27:17 --> Email Class Initialized
INFO - 2020-09-21 07:27:17 --> Controller Class Initialized
DEBUG - 2020-09-21 07:27:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:27:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:27:17 --> Model Class Initialized
INFO - 2020-09-21 07:27:17 --> Model Class Initialized
INFO - 2020-09-21 07:27:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 07:27:17 --> Final output sent to browser
DEBUG - 2020-09-21 07:27:17 --> Total execution time: 0.0246
ERROR - 2020-09-21 07:28:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:28:03 --> Config Class Initialized
INFO - 2020-09-21 07:28:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:28:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:28:03 --> Utf8 Class Initialized
INFO - 2020-09-21 07:28:03 --> URI Class Initialized
INFO - 2020-09-21 07:28:03 --> Router Class Initialized
INFO - 2020-09-21 07:28:03 --> Output Class Initialized
INFO - 2020-09-21 07:28:03 --> Security Class Initialized
DEBUG - 2020-09-21 07:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:28:03 --> Input Class Initialized
INFO - 2020-09-21 07:28:03 --> Language Class Initialized
INFO - 2020-09-21 07:28:03 --> Loader Class Initialized
INFO - 2020-09-21 07:28:03 --> Helper loaded: url_helper
INFO - 2020-09-21 07:28:03 --> Database Driver Class Initialized
INFO - 2020-09-21 07:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:28:03 --> Email Class Initialized
INFO - 2020-09-21 07:28:03 --> Controller Class Initialized
DEBUG - 2020-09-21 07:28:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:28:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:28:03 --> Model Class Initialized
INFO - 2020-09-21 07:28:03 --> Model Class Initialized
INFO - 2020-09-21 07:28:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 07:28:04 --> Final output sent to browser
DEBUG - 2020-09-21 07:28:04 --> Total execution time: 0.0375
ERROR - 2020-09-21 07:28:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:28:10 --> Config Class Initialized
INFO - 2020-09-21 07:28:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:28:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:28:10 --> Utf8 Class Initialized
INFO - 2020-09-21 07:28:10 --> URI Class Initialized
INFO - 2020-09-21 07:28:10 --> Router Class Initialized
INFO - 2020-09-21 07:28:10 --> Output Class Initialized
INFO - 2020-09-21 07:28:10 --> Security Class Initialized
DEBUG - 2020-09-21 07:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:28:10 --> Input Class Initialized
INFO - 2020-09-21 07:28:10 --> Language Class Initialized
INFO - 2020-09-21 07:28:10 --> Loader Class Initialized
INFO - 2020-09-21 07:28:10 --> Helper loaded: url_helper
INFO - 2020-09-21 07:28:10 --> Database Driver Class Initialized
INFO - 2020-09-21 07:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:28:10 --> Email Class Initialized
INFO - 2020-09-21 07:28:10 --> Controller Class Initialized
DEBUG - 2020-09-21 07:28:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:28:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:28:10 --> Model Class Initialized
INFO - 2020-09-21 07:28:10 --> Model Class Initialized
INFO - 2020-09-21 07:28:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-21 07:28:10 --> Final output sent to browser
DEBUG - 2020-09-21 07:28:10 --> Total execution time: 0.0260
ERROR - 2020-09-21 07:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:28:13 --> Config Class Initialized
INFO - 2020-09-21 07:28:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:28:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:28:13 --> Utf8 Class Initialized
INFO - 2020-09-21 07:28:13 --> URI Class Initialized
INFO - 2020-09-21 07:28:13 --> Router Class Initialized
INFO - 2020-09-21 07:28:13 --> Output Class Initialized
INFO - 2020-09-21 07:28:13 --> Security Class Initialized
DEBUG - 2020-09-21 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:28:13 --> Input Class Initialized
INFO - 2020-09-21 07:28:13 --> Language Class Initialized
INFO - 2020-09-21 07:28:13 --> Loader Class Initialized
INFO - 2020-09-21 07:28:13 --> Helper loaded: url_helper
INFO - 2020-09-21 07:28:13 --> Database Driver Class Initialized
INFO - 2020-09-21 07:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:28:13 --> Email Class Initialized
INFO - 2020-09-21 07:28:13 --> Controller Class Initialized
DEBUG - 2020-09-21 07:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:28:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:28:13 --> Model Class Initialized
INFO - 2020-09-21 07:28:13 --> Model Class Initialized
INFO - 2020-09-21 07:28:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 07:28:13 --> Final output sent to browser
DEBUG - 2020-09-21 07:28:13 --> Total execution time: 0.0235
ERROR - 2020-09-21 07:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:28:19 --> Config Class Initialized
INFO - 2020-09-21 07:28:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:28:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:28:19 --> Utf8 Class Initialized
INFO - 2020-09-21 07:28:19 --> URI Class Initialized
INFO - 2020-09-21 07:28:19 --> Router Class Initialized
INFO - 2020-09-21 07:28:19 --> Output Class Initialized
INFO - 2020-09-21 07:28:19 --> Security Class Initialized
DEBUG - 2020-09-21 07:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:28:19 --> Input Class Initialized
INFO - 2020-09-21 07:28:19 --> Language Class Initialized
INFO - 2020-09-21 07:28:19 --> Loader Class Initialized
INFO - 2020-09-21 07:28:19 --> Helper loaded: url_helper
INFO - 2020-09-21 07:28:19 --> Database Driver Class Initialized
INFO - 2020-09-21 07:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:28:19 --> Email Class Initialized
INFO - 2020-09-21 07:28:19 --> Controller Class Initialized
DEBUG - 2020-09-21 07:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:28:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:28:19 --> Model Class Initialized
INFO - 2020-09-21 07:28:19 --> Model Class Initialized
INFO - 2020-09-21 07:28:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-21 07:28:19 --> Final output sent to browser
DEBUG - 2020-09-21 07:28:19 --> Total execution time: 0.0250
ERROR - 2020-09-21 07:28:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:28:23 --> Config Class Initialized
INFO - 2020-09-21 07:28:23 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:28:23 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:28:23 --> Utf8 Class Initialized
INFO - 2020-09-21 07:28:23 --> URI Class Initialized
INFO - 2020-09-21 07:28:23 --> Router Class Initialized
INFO - 2020-09-21 07:28:23 --> Output Class Initialized
INFO - 2020-09-21 07:28:23 --> Security Class Initialized
DEBUG - 2020-09-21 07:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:28:23 --> Input Class Initialized
INFO - 2020-09-21 07:28:23 --> Language Class Initialized
INFO - 2020-09-21 07:28:23 --> Loader Class Initialized
INFO - 2020-09-21 07:28:23 --> Helper loaded: url_helper
INFO - 2020-09-21 07:28:23 --> Database Driver Class Initialized
INFO - 2020-09-21 07:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:28:23 --> Email Class Initialized
INFO - 2020-09-21 07:28:23 --> Controller Class Initialized
DEBUG - 2020-09-21 07:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:28:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:28:23 --> Model Class Initialized
INFO - 2020-09-21 07:28:23 --> Model Class Initialized
INFO - 2020-09-21 07:28:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 07:28:23 --> Final output sent to browser
DEBUG - 2020-09-21 07:28:23 --> Total execution time: 0.0239
ERROR - 2020-09-21 07:28:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:28:53 --> Config Class Initialized
INFO - 2020-09-21 07:28:53 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:28:53 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:28:53 --> Utf8 Class Initialized
INFO - 2020-09-21 07:28:53 --> URI Class Initialized
INFO - 2020-09-21 07:28:53 --> Router Class Initialized
INFO - 2020-09-21 07:28:53 --> Output Class Initialized
INFO - 2020-09-21 07:28:53 --> Security Class Initialized
DEBUG - 2020-09-21 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:28:53 --> Input Class Initialized
INFO - 2020-09-21 07:28:53 --> Language Class Initialized
INFO - 2020-09-21 07:28:53 --> Loader Class Initialized
INFO - 2020-09-21 07:28:53 --> Helper loaded: url_helper
INFO - 2020-09-21 07:28:53 --> Database Driver Class Initialized
INFO - 2020-09-21 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:28:53 --> Email Class Initialized
INFO - 2020-09-21 07:28:53 --> Controller Class Initialized
DEBUG - 2020-09-21 07:28:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:28:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:28:53 --> Model Class Initialized
INFO - 2020-09-21 07:28:53 --> Model Class Initialized
INFO - 2020-09-21 07:28:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-21 07:28:53 --> Final output sent to browser
DEBUG - 2020-09-21 07:28:53 --> Total execution time: 0.0251
ERROR - 2020-09-21 07:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:29:03 --> Config Class Initialized
INFO - 2020-09-21 07:29:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:29:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:29:03 --> Utf8 Class Initialized
INFO - 2020-09-21 07:29:03 --> URI Class Initialized
INFO - 2020-09-21 07:29:03 --> Router Class Initialized
INFO - 2020-09-21 07:29:03 --> Output Class Initialized
INFO - 2020-09-21 07:29:03 --> Security Class Initialized
DEBUG - 2020-09-21 07:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:29:03 --> Input Class Initialized
INFO - 2020-09-21 07:29:03 --> Language Class Initialized
INFO - 2020-09-21 07:29:03 --> Loader Class Initialized
INFO - 2020-09-21 07:29:03 --> Helper loaded: url_helper
INFO - 2020-09-21 07:29:03 --> Database Driver Class Initialized
INFO - 2020-09-21 07:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:29:03 --> Email Class Initialized
INFO - 2020-09-21 07:29:03 --> Controller Class Initialized
DEBUG - 2020-09-21 07:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:29:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:29:03 --> Model Class Initialized
INFO - 2020-09-21 07:29:03 --> Model Class Initialized
INFO - 2020-09-21 07:29:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 07:29:03 --> Final output sent to browser
DEBUG - 2020-09-21 07:29:03 --> Total execution time: 0.0241
ERROR - 2020-09-21 07:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:29:18 --> Config Class Initialized
INFO - 2020-09-21 07:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:29:18 --> Utf8 Class Initialized
INFO - 2020-09-21 07:29:18 --> URI Class Initialized
INFO - 2020-09-21 07:29:18 --> Router Class Initialized
INFO - 2020-09-21 07:29:18 --> Output Class Initialized
INFO - 2020-09-21 07:29:18 --> Security Class Initialized
DEBUG - 2020-09-21 07:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:29:18 --> Input Class Initialized
INFO - 2020-09-21 07:29:18 --> Language Class Initialized
INFO - 2020-09-21 07:29:18 --> Loader Class Initialized
INFO - 2020-09-21 07:29:18 --> Helper loaded: url_helper
INFO - 2020-09-21 07:29:18 --> Database Driver Class Initialized
INFO - 2020-09-21 07:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:29:18 --> Email Class Initialized
INFO - 2020-09-21 07:29:18 --> Controller Class Initialized
DEBUG - 2020-09-21 07:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:29:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:29:18 --> Model Class Initialized
INFO - 2020-09-21 07:29:18 --> Model Class Initialized
INFO - 2020-09-21 07:29:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-21 07:29:18 --> Final output sent to browser
DEBUG - 2020-09-21 07:29:18 --> Total execution time: 0.0258
ERROR - 2020-09-21 07:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:29:26 --> Config Class Initialized
INFO - 2020-09-21 07:29:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:29:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:29:26 --> Utf8 Class Initialized
INFO - 2020-09-21 07:29:26 --> URI Class Initialized
INFO - 2020-09-21 07:29:26 --> Router Class Initialized
INFO - 2020-09-21 07:29:26 --> Output Class Initialized
INFO - 2020-09-21 07:29:26 --> Security Class Initialized
DEBUG - 2020-09-21 07:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:29:26 --> Input Class Initialized
INFO - 2020-09-21 07:29:26 --> Language Class Initialized
INFO - 2020-09-21 07:29:26 --> Loader Class Initialized
INFO - 2020-09-21 07:29:26 --> Helper loaded: url_helper
INFO - 2020-09-21 07:29:26 --> Database Driver Class Initialized
INFO - 2020-09-21 07:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:29:26 --> Email Class Initialized
INFO - 2020-09-21 07:29:26 --> Controller Class Initialized
DEBUG - 2020-09-21 07:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:29:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:29:26 --> Model Class Initialized
INFO - 2020-09-21 07:29:26 --> Model Class Initialized
INFO - 2020-09-21 07:29:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 07:29:26 --> Final output sent to browser
DEBUG - 2020-09-21 07:29:26 --> Total execution time: 0.0256
ERROR - 2020-09-21 07:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:32:28 --> Config Class Initialized
INFO - 2020-09-21 07:32:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:32:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:32:28 --> Utf8 Class Initialized
INFO - 2020-09-21 07:32:28 --> URI Class Initialized
DEBUG - 2020-09-21 07:32:28 --> No URI present. Default controller set.
INFO - 2020-09-21 07:32:28 --> Router Class Initialized
INFO - 2020-09-21 07:32:28 --> Output Class Initialized
INFO - 2020-09-21 07:32:28 --> Security Class Initialized
DEBUG - 2020-09-21 07:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:32:28 --> Input Class Initialized
INFO - 2020-09-21 07:32:28 --> Language Class Initialized
INFO - 2020-09-21 07:32:28 --> Loader Class Initialized
INFO - 2020-09-21 07:32:28 --> Helper loaded: url_helper
INFO - 2020-09-21 07:32:28 --> Database Driver Class Initialized
INFO - 2020-09-21 07:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:32:28 --> Email Class Initialized
INFO - 2020-09-21 07:32:28 --> Controller Class Initialized
INFO - 2020-09-21 07:32:28 --> Model Class Initialized
INFO - 2020-09-21 07:32:28 --> Model Class Initialized
DEBUG - 2020-09-21 07:32:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:32:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 07:32:28 --> Final output sent to browser
DEBUG - 2020-09-21 07:32:28 --> Total execution time: 0.0198
ERROR - 2020-09-21 07:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:32:40 --> Config Class Initialized
INFO - 2020-09-21 07:32:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:32:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:32:40 --> Utf8 Class Initialized
INFO - 2020-09-21 07:32:40 --> URI Class Initialized
INFO - 2020-09-21 07:32:40 --> Router Class Initialized
INFO - 2020-09-21 07:32:40 --> Output Class Initialized
INFO - 2020-09-21 07:32:40 --> Security Class Initialized
DEBUG - 2020-09-21 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:32:40 --> Input Class Initialized
INFO - 2020-09-21 07:32:40 --> Language Class Initialized
INFO - 2020-09-21 07:32:40 --> Loader Class Initialized
INFO - 2020-09-21 07:32:40 --> Helper loaded: url_helper
ERROR - 2020-09-21 07:32:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:32:40 --> Database Driver Class Initialized
INFO - 2020-09-21 07:32:40 --> Config Class Initialized
INFO - 2020-09-21 07:32:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:32:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:32:40 --> Utf8 Class Initialized
INFO - 2020-09-21 07:32:40 --> URI Class Initialized
INFO - 2020-09-21 07:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:32:40 --> Router Class Initialized
INFO - 2020-09-21 07:32:40 --> Output Class Initialized
INFO - 2020-09-21 07:32:40 --> Email Class Initialized
INFO - 2020-09-21 07:32:40 --> Controller Class Initialized
INFO - 2020-09-21 07:32:40 --> Model Class Initialized
INFO - 2020-09-21 07:32:40 --> Security Class Initialized
INFO - 2020-09-21 07:32:40 --> Model Class Initialized
DEBUG - 2020-09-21 07:32:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:32:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:32:40 --> Model Class Initialized
DEBUG - 2020-09-21 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:32:40 --> Input Class Initialized
INFO - 2020-09-21 07:32:40 --> Language Class Initialized
INFO - 2020-09-21 07:32:40 --> Loader Class Initialized
INFO - 2020-09-21 07:32:40 --> Final output sent to browser
DEBUG - 2020-09-21 07:32:40 --> Total execution time: 0.0260
INFO - 2020-09-21 07:32:40 --> Helper loaded: url_helper
INFO - 2020-09-21 07:32:40 --> Database Driver Class Initialized
INFO - 2020-09-21 07:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:32:40 --> Email Class Initialized
INFO - 2020-09-21 07:32:40 --> Controller Class Initialized
INFO - 2020-09-21 07:32:40 --> Model Class Initialized
INFO - 2020-09-21 07:32:40 --> Model Class Initialized
DEBUG - 2020-09-21 07:32:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 07:32:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:32:41 --> Config Class Initialized
INFO - 2020-09-21 07:32:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:32:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:32:41 --> Utf8 Class Initialized
INFO - 2020-09-21 07:32:41 --> URI Class Initialized
INFO - 2020-09-21 07:32:41 --> Router Class Initialized
INFO - 2020-09-21 07:32:41 --> Output Class Initialized
INFO - 2020-09-21 07:32:41 --> Security Class Initialized
DEBUG - 2020-09-21 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:32:41 --> Input Class Initialized
INFO - 2020-09-21 07:32:41 --> Language Class Initialized
INFO - 2020-09-21 07:32:41 --> Loader Class Initialized
INFO - 2020-09-21 07:32:41 --> Helper loaded: url_helper
INFO - 2020-09-21 07:32:41 --> Database Driver Class Initialized
INFO - 2020-09-21 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:32:41 --> Email Class Initialized
INFO - 2020-09-21 07:32:41 --> Controller Class Initialized
DEBUG - 2020-09-21 07:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:32:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:32:41 --> Model Class Initialized
INFO - 2020-09-21 07:32:41 --> Model Class Initialized
INFO - 2020-09-21 07:32:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 07:32:41 --> Final output sent to browser
DEBUG - 2020-09-21 07:32:41 --> Total execution time: 0.0286
ERROR - 2020-09-21 07:33:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:33:12 --> Config Class Initialized
INFO - 2020-09-21 07:33:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:33:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:33:12 --> Utf8 Class Initialized
INFO - 2020-09-21 07:33:12 --> URI Class Initialized
INFO - 2020-09-21 07:33:12 --> Router Class Initialized
INFO - 2020-09-21 07:33:12 --> Output Class Initialized
INFO - 2020-09-21 07:33:12 --> Security Class Initialized
DEBUG - 2020-09-21 07:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:33:12 --> Input Class Initialized
INFO - 2020-09-21 07:33:12 --> Language Class Initialized
INFO - 2020-09-21 07:33:12 --> Loader Class Initialized
INFO - 2020-09-21 07:33:12 --> Helper loaded: url_helper
INFO - 2020-09-21 07:33:12 --> Database Driver Class Initialized
INFO - 2020-09-21 07:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:33:12 --> Email Class Initialized
INFO - 2020-09-21 07:33:12 --> Controller Class Initialized
DEBUG - 2020-09-21 07:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:33:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:33:12 --> Model Class Initialized
INFO - 2020-09-21 07:33:12 --> Model Class Initialized
INFO - 2020-09-21 07:33:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:33:12 --> Final output sent to browser
DEBUG - 2020-09-21 07:33:12 --> Total execution time: 0.0262
ERROR - 2020-09-21 07:33:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:33:28 --> Config Class Initialized
INFO - 2020-09-21 07:33:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:33:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:33:28 --> Utf8 Class Initialized
INFO - 2020-09-21 07:33:28 --> URI Class Initialized
INFO - 2020-09-21 07:33:28 --> Router Class Initialized
INFO - 2020-09-21 07:33:28 --> Output Class Initialized
INFO - 2020-09-21 07:33:28 --> Security Class Initialized
DEBUG - 2020-09-21 07:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:33:28 --> Input Class Initialized
INFO - 2020-09-21 07:33:28 --> Language Class Initialized
INFO - 2020-09-21 07:33:28 --> Loader Class Initialized
INFO - 2020-09-21 07:33:28 --> Helper loaded: url_helper
INFO - 2020-09-21 07:33:28 --> Database Driver Class Initialized
INFO - 2020-09-21 07:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:33:28 --> Email Class Initialized
INFO - 2020-09-21 07:33:28 --> Controller Class Initialized
DEBUG - 2020-09-21 07:33:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:33:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:33:28 --> Model Class Initialized
INFO - 2020-09-21 07:33:28 --> Model Class Initialized
INFO - 2020-09-21 07:33:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-21 07:33:28 --> Final output sent to browser
DEBUG - 2020-09-21 07:33:28 --> Total execution time: 0.0354
ERROR - 2020-09-21 07:33:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:33:32 --> Config Class Initialized
INFO - 2020-09-21 07:33:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:33:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:33:32 --> Utf8 Class Initialized
INFO - 2020-09-21 07:33:32 --> URI Class Initialized
INFO - 2020-09-21 07:33:32 --> Router Class Initialized
INFO - 2020-09-21 07:33:32 --> Output Class Initialized
INFO - 2020-09-21 07:33:32 --> Security Class Initialized
DEBUG - 2020-09-21 07:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:33:32 --> Input Class Initialized
INFO - 2020-09-21 07:33:32 --> Language Class Initialized
INFO - 2020-09-21 07:33:32 --> Loader Class Initialized
INFO - 2020-09-21 07:33:32 --> Helper loaded: url_helper
INFO - 2020-09-21 07:33:32 --> Database Driver Class Initialized
INFO - 2020-09-21 07:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:33:32 --> Email Class Initialized
INFO - 2020-09-21 07:33:32 --> Controller Class Initialized
DEBUG - 2020-09-21 07:33:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:33:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:33:32 --> Model Class Initialized
INFO - 2020-09-21 07:33:32 --> Model Class Initialized
INFO - 2020-09-21 07:33:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:33:32 --> Final output sent to browser
DEBUG - 2020-09-21 07:33:32 --> Total execution time: 0.0226
ERROR - 2020-09-21 07:33:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:33:51 --> Config Class Initialized
INFO - 2020-09-21 07:33:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:33:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:33:51 --> Utf8 Class Initialized
INFO - 2020-09-21 07:33:51 --> URI Class Initialized
INFO - 2020-09-21 07:33:51 --> Router Class Initialized
INFO - 2020-09-21 07:33:51 --> Output Class Initialized
INFO - 2020-09-21 07:33:51 --> Security Class Initialized
DEBUG - 2020-09-21 07:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:33:51 --> Input Class Initialized
INFO - 2020-09-21 07:33:51 --> Language Class Initialized
INFO - 2020-09-21 07:33:51 --> Loader Class Initialized
INFO - 2020-09-21 07:33:51 --> Helper loaded: url_helper
INFO - 2020-09-21 07:33:51 --> Database Driver Class Initialized
INFO - 2020-09-21 07:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:33:51 --> Email Class Initialized
INFO - 2020-09-21 07:33:51 --> Controller Class Initialized
DEBUG - 2020-09-21 07:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:33:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:33:51 --> Model Class Initialized
INFO - 2020-09-21 07:33:51 --> Model Class Initialized
INFO - 2020-09-21 07:33:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 07:33:51 --> Final output sent to browser
DEBUG - 2020-09-21 07:33:51 --> Total execution time: 0.0237
ERROR - 2020-09-21 07:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:34:30 --> Config Class Initialized
INFO - 2020-09-21 07:34:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:34:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:34:30 --> Utf8 Class Initialized
INFO - 2020-09-21 07:34:30 --> URI Class Initialized
INFO - 2020-09-21 07:34:30 --> Router Class Initialized
INFO - 2020-09-21 07:34:30 --> Output Class Initialized
INFO - 2020-09-21 07:34:30 --> Security Class Initialized
DEBUG - 2020-09-21 07:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:34:30 --> Input Class Initialized
INFO - 2020-09-21 07:34:30 --> Language Class Initialized
INFO - 2020-09-21 07:34:30 --> Loader Class Initialized
INFO - 2020-09-21 07:34:30 --> Helper loaded: url_helper
INFO - 2020-09-21 07:34:30 --> Database Driver Class Initialized
INFO - 2020-09-21 07:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:34:30 --> Email Class Initialized
INFO - 2020-09-21 07:34:30 --> Controller Class Initialized
DEBUG - 2020-09-21 07:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:34:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:34:30 --> Model Class Initialized
INFO - 2020-09-21 07:34:30 --> Model Class Initialized
INFO - 2020-09-21 07:34:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 07:34:30 --> Final output sent to browser
DEBUG - 2020-09-21 07:34:30 --> Total execution time: 0.0260
ERROR - 2020-09-21 07:34:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:34:56 --> Config Class Initialized
INFO - 2020-09-21 07:34:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:34:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:34:56 --> Utf8 Class Initialized
INFO - 2020-09-21 07:34:56 --> URI Class Initialized
INFO - 2020-09-21 07:34:56 --> Router Class Initialized
INFO - 2020-09-21 07:34:56 --> Output Class Initialized
INFO - 2020-09-21 07:34:56 --> Security Class Initialized
DEBUG - 2020-09-21 07:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:34:56 --> Input Class Initialized
INFO - 2020-09-21 07:34:56 --> Language Class Initialized
INFO - 2020-09-21 07:34:56 --> Loader Class Initialized
INFO - 2020-09-21 07:34:56 --> Helper loaded: url_helper
INFO - 2020-09-21 07:34:56 --> Database Driver Class Initialized
INFO - 2020-09-21 07:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:34:56 --> Email Class Initialized
INFO - 2020-09-21 07:34:56 --> Controller Class Initialized
DEBUG - 2020-09-21 07:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:34:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:34:56 --> Model Class Initialized
INFO - 2020-09-21 07:34:56 --> Model Class Initialized
INFO - 2020-09-21 07:34:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:34:56 --> Final output sent to browser
DEBUG - 2020-09-21 07:34:56 --> Total execution time: 0.0258
ERROR - 2020-09-21 07:35:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:35:19 --> Config Class Initialized
INFO - 2020-09-21 07:35:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:35:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:35:19 --> Utf8 Class Initialized
INFO - 2020-09-21 07:35:19 --> URI Class Initialized
INFO - 2020-09-21 07:35:19 --> Router Class Initialized
INFO - 2020-09-21 07:35:19 --> Output Class Initialized
INFO - 2020-09-21 07:35:19 --> Security Class Initialized
DEBUG - 2020-09-21 07:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:35:19 --> Input Class Initialized
INFO - 2020-09-21 07:35:19 --> Language Class Initialized
INFO - 2020-09-21 07:35:19 --> Loader Class Initialized
INFO - 2020-09-21 07:35:19 --> Helper loaded: url_helper
INFO - 2020-09-21 07:35:19 --> Database Driver Class Initialized
INFO - 2020-09-21 07:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:35:19 --> Email Class Initialized
INFO - 2020-09-21 07:35:19 --> Controller Class Initialized
DEBUG - 2020-09-21 07:35:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:35:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:35:19 --> Model Class Initialized
INFO - 2020-09-21 07:35:19 --> Model Class Initialized
INFO - 2020-09-21 07:35:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:35:19 --> Final output sent to browser
DEBUG - 2020-09-21 07:35:19 --> Total execution time: 0.0251
ERROR - 2020-09-21 07:35:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:35:24 --> Config Class Initialized
INFO - 2020-09-21 07:35:24 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:35:24 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:35:24 --> Utf8 Class Initialized
INFO - 2020-09-21 07:35:24 --> URI Class Initialized
INFO - 2020-09-21 07:35:24 --> Router Class Initialized
INFO - 2020-09-21 07:35:24 --> Output Class Initialized
INFO - 2020-09-21 07:35:24 --> Security Class Initialized
DEBUG - 2020-09-21 07:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:35:24 --> Input Class Initialized
INFO - 2020-09-21 07:35:24 --> Language Class Initialized
INFO - 2020-09-21 07:35:24 --> Loader Class Initialized
INFO - 2020-09-21 07:35:24 --> Helper loaded: url_helper
INFO - 2020-09-21 07:35:24 --> Database Driver Class Initialized
INFO - 2020-09-21 07:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:35:24 --> Email Class Initialized
INFO - 2020-09-21 07:35:24 --> Controller Class Initialized
DEBUG - 2020-09-21 07:35:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:35:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:35:24 --> Model Class Initialized
INFO - 2020-09-21 07:35:24 --> Model Class Initialized
INFO - 2020-09-21 07:35:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:35:24 --> Final output sent to browser
DEBUG - 2020-09-21 07:35:24 --> Total execution time: 0.0279
ERROR - 2020-09-21 07:35:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:35:48 --> Config Class Initialized
INFO - 2020-09-21 07:35:48 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:35:48 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:35:48 --> Utf8 Class Initialized
INFO - 2020-09-21 07:35:48 --> URI Class Initialized
INFO - 2020-09-21 07:35:48 --> Router Class Initialized
INFO - 2020-09-21 07:35:48 --> Output Class Initialized
INFO - 2020-09-21 07:35:48 --> Security Class Initialized
DEBUG - 2020-09-21 07:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:35:48 --> Input Class Initialized
INFO - 2020-09-21 07:35:48 --> Language Class Initialized
INFO - 2020-09-21 07:35:48 --> Loader Class Initialized
INFO - 2020-09-21 07:35:48 --> Helper loaded: url_helper
INFO - 2020-09-21 07:35:48 --> Database Driver Class Initialized
INFO - 2020-09-21 07:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:35:48 --> Email Class Initialized
INFO - 2020-09-21 07:35:48 --> Controller Class Initialized
DEBUG - 2020-09-21 07:35:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:35:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:35:48 --> Model Class Initialized
INFO - 2020-09-21 07:35:48 --> Model Class Initialized
INFO - 2020-09-21 07:35:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:35:48 --> Final output sent to browser
DEBUG - 2020-09-21 07:35:48 --> Total execution time: 0.0282
ERROR - 2020-09-21 07:36:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:36:10 --> Config Class Initialized
INFO - 2020-09-21 07:36:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:36:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:36:10 --> Utf8 Class Initialized
INFO - 2020-09-21 07:36:10 --> URI Class Initialized
INFO - 2020-09-21 07:36:10 --> Router Class Initialized
INFO - 2020-09-21 07:36:10 --> Output Class Initialized
INFO - 2020-09-21 07:36:10 --> Security Class Initialized
DEBUG - 2020-09-21 07:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:36:10 --> Input Class Initialized
INFO - 2020-09-21 07:36:10 --> Language Class Initialized
INFO - 2020-09-21 07:36:10 --> Loader Class Initialized
INFO - 2020-09-21 07:36:10 --> Helper loaded: url_helper
INFO - 2020-09-21 07:36:10 --> Database Driver Class Initialized
INFO - 2020-09-21 07:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:36:10 --> Email Class Initialized
INFO - 2020-09-21 07:36:10 --> Controller Class Initialized
DEBUG - 2020-09-21 07:36:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:36:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:36:10 --> Model Class Initialized
INFO - 2020-09-21 07:36:10 --> Model Class Initialized
INFO - 2020-09-21 07:36:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:36:10 --> Final output sent to browser
DEBUG - 2020-09-21 07:36:10 --> Total execution time: 0.0247
ERROR - 2020-09-21 07:36:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:36:13 --> Config Class Initialized
INFO - 2020-09-21 07:36:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:36:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:36:13 --> Utf8 Class Initialized
INFO - 2020-09-21 07:36:13 --> URI Class Initialized
INFO - 2020-09-21 07:36:13 --> Router Class Initialized
INFO - 2020-09-21 07:36:13 --> Output Class Initialized
INFO - 2020-09-21 07:36:13 --> Security Class Initialized
DEBUG - 2020-09-21 07:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:36:13 --> Input Class Initialized
INFO - 2020-09-21 07:36:13 --> Language Class Initialized
INFO - 2020-09-21 07:36:13 --> Loader Class Initialized
INFO - 2020-09-21 07:36:13 --> Helper loaded: url_helper
INFO - 2020-09-21 07:36:13 --> Database Driver Class Initialized
INFO - 2020-09-21 07:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:36:13 --> Email Class Initialized
INFO - 2020-09-21 07:36:13 --> Controller Class Initialized
DEBUG - 2020-09-21 07:36:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:36:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:36:13 --> Model Class Initialized
INFO - 2020-09-21 07:36:13 --> Model Class Initialized
INFO - 2020-09-21 07:36:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:36:13 --> Final output sent to browser
DEBUG - 2020-09-21 07:36:13 --> Total execution time: 0.0300
ERROR - 2020-09-21 07:36:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:36:22 --> Config Class Initialized
INFO - 2020-09-21 07:36:22 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:36:22 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:36:22 --> Utf8 Class Initialized
INFO - 2020-09-21 07:36:22 --> URI Class Initialized
INFO - 2020-09-21 07:36:22 --> Router Class Initialized
INFO - 2020-09-21 07:36:22 --> Output Class Initialized
INFO - 2020-09-21 07:36:22 --> Security Class Initialized
DEBUG - 2020-09-21 07:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:36:22 --> Input Class Initialized
INFO - 2020-09-21 07:36:22 --> Language Class Initialized
INFO - 2020-09-21 07:36:22 --> Loader Class Initialized
INFO - 2020-09-21 07:36:22 --> Helper loaded: url_helper
INFO - 2020-09-21 07:36:22 --> Database Driver Class Initialized
INFO - 2020-09-21 07:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:36:22 --> Email Class Initialized
INFO - 2020-09-21 07:36:22 --> Controller Class Initialized
DEBUG - 2020-09-21 07:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:36:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:36:22 --> Model Class Initialized
INFO - 2020-09-21 07:36:22 --> Model Class Initialized
INFO - 2020-09-21 07:36:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:36:22 --> Final output sent to browser
DEBUG - 2020-09-21 07:36:22 --> Total execution time: 0.0262
ERROR - 2020-09-21 07:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:36:42 --> Config Class Initialized
INFO - 2020-09-21 07:36:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:36:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:36:42 --> Utf8 Class Initialized
INFO - 2020-09-21 07:36:42 --> URI Class Initialized
INFO - 2020-09-21 07:36:42 --> Router Class Initialized
INFO - 2020-09-21 07:36:42 --> Output Class Initialized
INFO - 2020-09-21 07:36:42 --> Security Class Initialized
DEBUG - 2020-09-21 07:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:36:42 --> Input Class Initialized
INFO - 2020-09-21 07:36:42 --> Language Class Initialized
INFO - 2020-09-21 07:36:42 --> Loader Class Initialized
INFO - 2020-09-21 07:36:42 --> Helper loaded: url_helper
INFO - 2020-09-21 07:36:42 --> Database Driver Class Initialized
INFO - 2020-09-21 07:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:36:42 --> Email Class Initialized
INFO - 2020-09-21 07:36:42 --> Controller Class Initialized
DEBUG - 2020-09-21 07:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:36:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:36:42 --> Model Class Initialized
INFO - 2020-09-21 07:36:42 --> Model Class Initialized
INFO - 2020-09-21 07:36:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:36:42 --> Final output sent to browser
DEBUG - 2020-09-21 07:36:42 --> Total execution time: 0.0262
ERROR - 2020-09-21 07:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:37:03 --> Config Class Initialized
INFO - 2020-09-21 07:37:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:37:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:37:03 --> Utf8 Class Initialized
INFO - 2020-09-21 07:37:03 --> URI Class Initialized
INFO - 2020-09-21 07:37:03 --> Router Class Initialized
INFO - 2020-09-21 07:37:03 --> Output Class Initialized
INFO - 2020-09-21 07:37:03 --> Security Class Initialized
DEBUG - 2020-09-21 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:37:03 --> Input Class Initialized
INFO - 2020-09-21 07:37:03 --> Language Class Initialized
INFO - 2020-09-21 07:37:03 --> Loader Class Initialized
INFO - 2020-09-21 07:37:03 --> Helper loaded: url_helper
INFO - 2020-09-21 07:37:03 --> Database Driver Class Initialized
INFO - 2020-09-21 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:37:03 --> Email Class Initialized
INFO - 2020-09-21 07:37:03 --> Controller Class Initialized
DEBUG - 2020-09-21 07:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:37:03 --> Model Class Initialized
INFO - 2020-09-21 07:37:03 --> Model Class Initialized
INFO - 2020-09-21 07:37:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:37:03 --> Final output sent to browser
DEBUG - 2020-09-21 07:37:03 --> Total execution time: 0.0257
ERROR - 2020-09-21 07:41:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:41:42 --> Config Class Initialized
INFO - 2020-09-21 07:41:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:41:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:41:42 --> Utf8 Class Initialized
INFO - 2020-09-21 07:41:42 --> URI Class Initialized
INFO - 2020-09-21 07:41:42 --> Router Class Initialized
INFO - 2020-09-21 07:41:42 --> Output Class Initialized
INFO - 2020-09-21 07:41:42 --> Security Class Initialized
DEBUG - 2020-09-21 07:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:41:42 --> Input Class Initialized
INFO - 2020-09-21 07:41:42 --> Language Class Initialized
INFO - 2020-09-21 07:41:42 --> Loader Class Initialized
INFO - 2020-09-21 07:41:42 --> Helper loaded: url_helper
INFO - 2020-09-21 07:41:42 --> Database Driver Class Initialized
INFO - 2020-09-21 07:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:41:42 --> Email Class Initialized
INFO - 2020-09-21 07:41:42 --> Controller Class Initialized
DEBUG - 2020-09-21 07:41:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:41:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:41:42 --> Model Class Initialized
INFO - 2020-09-21 07:41:42 --> Model Class Initialized
INFO - 2020-09-21 07:41:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-21 07:41:42 --> Final output sent to browser
DEBUG - 2020-09-21 07:41:42 --> Total execution time: 0.0315
ERROR - 2020-09-21 07:41:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:41:57 --> Config Class Initialized
INFO - 2020-09-21 07:41:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:41:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:41:57 --> Utf8 Class Initialized
INFO - 2020-09-21 07:41:57 --> URI Class Initialized
INFO - 2020-09-21 07:41:57 --> Router Class Initialized
INFO - 2020-09-21 07:41:57 --> Output Class Initialized
INFO - 2020-09-21 07:41:57 --> Security Class Initialized
DEBUG - 2020-09-21 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:41:57 --> Input Class Initialized
INFO - 2020-09-21 07:41:57 --> Language Class Initialized
INFO - 2020-09-21 07:41:57 --> Loader Class Initialized
INFO - 2020-09-21 07:41:57 --> Helper loaded: url_helper
INFO - 2020-09-21 07:41:57 --> Database Driver Class Initialized
INFO - 2020-09-21 07:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:41:57 --> Email Class Initialized
INFO - 2020-09-21 07:41:57 --> Controller Class Initialized
DEBUG - 2020-09-21 07:41:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:41:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:41:57 --> Model Class Initialized
INFO - 2020-09-21 07:41:57 --> Model Class Initialized
INFO - 2020-09-21 07:41:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:41:57 --> Final output sent to browser
DEBUG - 2020-09-21 07:41:57 --> Total execution time: 0.0289
ERROR - 2020-09-21 07:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:42:09 --> Config Class Initialized
INFO - 2020-09-21 07:42:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:42:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:42:09 --> Utf8 Class Initialized
INFO - 2020-09-21 07:42:09 --> URI Class Initialized
INFO - 2020-09-21 07:42:09 --> Router Class Initialized
INFO - 2020-09-21 07:42:09 --> Output Class Initialized
INFO - 2020-09-21 07:42:09 --> Security Class Initialized
DEBUG - 2020-09-21 07:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:42:09 --> Input Class Initialized
INFO - 2020-09-21 07:42:09 --> Language Class Initialized
INFO - 2020-09-21 07:42:09 --> Loader Class Initialized
INFO - 2020-09-21 07:42:09 --> Helper loaded: url_helper
INFO - 2020-09-21 07:42:09 --> Database Driver Class Initialized
INFO - 2020-09-21 07:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:42:09 --> Email Class Initialized
INFO - 2020-09-21 07:42:09 --> Controller Class Initialized
DEBUG - 2020-09-21 07:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:42:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:42:09 --> Model Class Initialized
INFO - 2020-09-21 07:42:09 --> Model Class Initialized
INFO - 2020-09-21 07:42:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:42:09 --> Final output sent to browser
DEBUG - 2020-09-21 07:42:09 --> Total execution time: 0.0263
ERROR - 2020-09-21 07:42:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:42:11 --> Config Class Initialized
INFO - 2020-09-21 07:42:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:42:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:42:11 --> Utf8 Class Initialized
INFO - 2020-09-21 07:42:11 --> URI Class Initialized
INFO - 2020-09-21 07:42:11 --> Router Class Initialized
INFO - 2020-09-21 07:42:11 --> Output Class Initialized
INFO - 2020-09-21 07:42:11 --> Security Class Initialized
DEBUG - 2020-09-21 07:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:42:11 --> Input Class Initialized
INFO - 2020-09-21 07:42:11 --> Language Class Initialized
INFO - 2020-09-21 07:42:11 --> Loader Class Initialized
INFO - 2020-09-21 07:42:11 --> Helper loaded: url_helper
INFO - 2020-09-21 07:42:11 --> Database Driver Class Initialized
INFO - 2020-09-21 07:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:42:11 --> Email Class Initialized
INFO - 2020-09-21 07:42:11 --> Controller Class Initialized
DEBUG - 2020-09-21 07:42:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:42:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:42:11 --> Model Class Initialized
INFO - 2020-09-21 07:42:11 --> Model Class Initialized
INFO - 2020-09-21 07:42:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:42:11 --> Final output sent to browser
DEBUG - 2020-09-21 07:42:11 --> Total execution time: 0.0242
ERROR - 2020-09-21 07:42:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:42:15 --> Config Class Initialized
INFO - 2020-09-21 07:42:15 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:42:15 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:42:15 --> Utf8 Class Initialized
INFO - 2020-09-21 07:42:15 --> URI Class Initialized
INFO - 2020-09-21 07:42:15 --> Router Class Initialized
INFO - 2020-09-21 07:42:15 --> Output Class Initialized
INFO - 2020-09-21 07:42:15 --> Security Class Initialized
DEBUG - 2020-09-21 07:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:42:15 --> Input Class Initialized
INFO - 2020-09-21 07:42:15 --> Language Class Initialized
INFO - 2020-09-21 07:42:15 --> Loader Class Initialized
INFO - 2020-09-21 07:42:15 --> Helper loaded: url_helper
INFO - 2020-09-21 07:42:15 --> Database Driver Class Initialized
INFO - 2020-09-21 07:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:42:15 --> Email Class Initialized
INFO - 2020-09-21 07:42:15 --> Controller Class Initialized
DEBUG - 2020-09-21 07:42:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:42:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:42:15 --> Model Class Initialized
INFO - 2020-09-21 07:42:15 --> Model Class Initialized
INFO - 2020-09-21 07:42:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 07:42:15 --> Final output sent to browser
DEBUG - 2020-09-21 07:42:15 --> Total execution time: 0.0249
ERROR - 2020-09-21 07:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:42:21 --> Config Class Initialized
INFO - 2020-09-21 07:42:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:42:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:42:21 --> Utf8 Class Initialized
INFO - 2020-09-21 07:42:21 --> URI Class Initialized
INFO - 2020-09-21 07:42:21 --> Router Class Initialized
INFO - 2020-09-21 07:42:21 --> Output Class Initialized
INFO - 2020-09-21 07:42:21 --> Security Class Initialized
DEBUG - 2020-09-21 07:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:42:21 --> Input Class Initialized
INFO - 2020-09-21 07:42:21 --> Language Class Initialized
INFO - 2020-09-21 07:42:21 --> Loader Class Initialized
INFO - 2020-09-21 07:42:21 --> Helper loaded: url_helper
INFO - 2020-09-21 07:42:21 --> Database Driver Class Initialized
INFO - 2020-09-21 07:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:42:21 --> Email Class Initialized
INFO - 2020-09-21 07:42:21 --> Controller Class Initialized
DEBUG - 2020-09-21 07:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:42:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:42:21 --> Model Class Initialized
INFO - 2020-09-21 07:42:21 --> Model Class Initialized
INFO - 2020-09-21 07:42:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:42:21 --> Final output sent to browser
DEBUG - 2020-09-21 07:42:21 --> Total execution time: 0.0245
ERROR - 2020-09-21 07:43:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:43:54 --> Config Class Initialized
INFO - 2020-09-21 07:43:54 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:43:54 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:43:54 --> Utf8 Class Initialized
INFO - 2020-09-21 07:43:54 --> URI Class Initialized
INFO - 2020-09-21 07:43:54 --> Router Class Initialized
INFO - 2020-09-21 07:43:54 --> Output Class Initialized
INFO - 2020-09-21 07:43:54 --> Security Class Initialized
DEBUG - 2020-09-21 07:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:43:54 --> Input Class Initialized
INFO - 2020-09-21 07:43:54 --> Language Class Initialized
INFO - 2020-09-21 07:43:54 --> Loader Class Initialized
INFO - 2020-09-21 07:43:54 --> Helper loaded: url_helper
INFO - 2020-09-21 07:43:54 --> Database Driver Class Initialized
INFO - 2020-09-21 07:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:43:54 --> Email Class Initialized
INFO - 2020-09-21 07:43:54 --> Controller Class Initialized
DEBUG - 2020-09-21 07:43:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:43:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:43:54 --> Model Class Initialized
INFO - 2020-09-21 07:43:54 --> Model Class Initialized
INFO - 2020-09-21 07:43:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-21 07:43:54 --> Final output sent to browser
DEBUG - 2020-09-21 07:43:54 --> Total execution time: 0.0288
ERROR - 2020-09-21 07:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:44:28 --> Config Class Initialized
INFO - 2020-09-21 07:44:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:44:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:44:28 --> Utf8 Class Initialized
INFO - 2020-09-21 07:44:28 --> URI Class Initialized
INFO - 2020-09-21 07:44:28 --> Router Class Initialized
INFO - 2020-09-21 07:44:28 --> Output Class Initialized
INFO - 2020-09-21 07:44:28 --> Security Class Initialized
DEBUG - 2020-09-21 07:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:44:28 --> Input Class Initialized
INFO - 2020-09-21 07:44:28 --> Language Class Initialized
INFO - 2020-09-21 07:44:28 --> Loader Class Initialized
INFO - 2020-09-21 07:44:28 --> Helper loaded: url_helper
INFO - 2020-09-21 07:44:28 --> Database Driver Class Initialized
INFO - 2020-09-21 07:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:44:28 --> Email Class Initialized
INFO - 2020-09-21 07:44:28 --> Controller Class Initialized
DEBUG - 2020-09-21 07:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:44:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:44:28 --> Model Class Initialized
INFO - 2020-09-21 07:44:28 --> Model Class Initialized
INFO - 2020-09-21 07:44:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:44:28 --> Final output sent to browser
DEBUG - 2020-09-21 07:44:28 --> Total execution time: 0.0243
ERROR - 2020-09-21 07:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:56:30 --> Config Class Initialized
INFO - 2020-09-21 07:56:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:56:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:56:30 --> Utf8 Class Initialized
INFO - 2020-09-21 07:56:30 --> URI Class Initialized
INFO - 2020-09-21 07:56:30 --> Router Class Initialized
INFO - 2020-09-21 07:56:30 --> Output Class Initialized
INFO - 2020-09-21 07:56:30 --> Security Class Initialized
DEBUG - 2020-09-21 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:56:30 --> Input Class Initialized
INFO - 2020-09-21 07:56:30 --> Language Class Initialized
INFO - 2020-09-21 07:56:30 --> Loader Class Initialized
INFO - 2020-09-21 07:56:30 --> Helper loaded: url_helper
INFO - 2020-09-21 07:56:30 --> Database Driver Class Initialized
INFO - 2020-09-21 07:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:56:30 --> Email Class Initialized
INFO - 2020-09-21 07:56:30 --> Controller Class Initialized
DEBUG - 2020-09-21 07:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:56:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:56:30 --> Model Class Initialized
INFO - 2020-09-21 07:56:30 --> Model Class Initialized
INFO - 2020-09-21 07:56:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 07:56:30 --> Final output sent to browser
DEBUG - 2020-09-21 07:56:30 --> Total execution time: 0.0271
ERROR - 2020-09-21 07:58:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:58:47 --> Config Class Initialized
INFO - 2020-09-21 07:58:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:58:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:58:47 --> Utf8 Class Initialized
INFO - 2020-09-21 07:58:47 --> URI Class Initialized
INFO - 2020-09-21 07:58:47 --> Router Class Initialized
INFO - 2020-09-21 07:58:47 --> Output Class Initialized
INFO - 2020-09-21 07:58:47 --> Security Class Initialized
DEBUG - 2020-09-21 07:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:58:47 --> Input Class Initialized
INFO - 2020-09-21 07:58:47 --> Language Class Initialized
INFO - 2020-09-21 07:58:47 --> Loader Class Initialized
INFO - 2020-09-21 07:58:47 --> Helper loaded: url_helper
INFO - 2020-09-21 07:58:47 --> Database Driver Class Initialized
INFO - 2020-09-21 07:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:58:47 --> Email Class Initialized
INFO - 2020-09-21 07:58:47 --> Controller Class Initialized
DEBUG - 2020-09-21 07:58:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:58:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:58:47 --> Model Class Initialized
INFO - 2020-09-21 07:58:47 --> Model Class Initialized
INFO - 2020-09-21 07:58:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:58:47 --> Final output sent to browser
DEBUG - 2020-09-21 07:58:47 --> Total execution time: 0.0253
ERROR - 2020-09-21 07:59:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 07:59:09 --> Config Class Initialized
INFO - 2020-09-21 07:59:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 07:59:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 07:59:09 --> Utf8 Class Initialized
INFO - 2020-09-21 07:59:09 --> URI Class Initialized
INFO - 2020-09-21 07:59:09 --> Router Class Initialized
INFO - 2020-09-21 07:59:09 --> Output Class Initialized
INFO - 2020-09-21 07:59:09 --> Security Class Initialized
DEBUG - 2020-09-21 07:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 07:59:09 --> Input Class Initialized
INFO - 2020-09-21 07:59:09 --> Language Class Initialized
INFO - 2020-09-21 07:59:09 --> Loader Class Initialized
INFO - 2020-09-21 07:59:09 --> Helper loaded: url_helper
INFO - 2020-09-21 07:59:09 --> Database Driver Class Initialized
INFO - 2020-09-21 07:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 07:59:09 --> Email Class Initialized
INFO - 2020-09-21 07:59:09 --> Controller Class Initialized
DEBUG - 2020-09-21 07:59:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 07:59:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 07:59:09 --> Model Class Initialized
INFO - 2020-09-21 07:59:09 --> Model Class Initialized
INFO - 2020-09-21 07:59:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 07:59:09 --> Final output sent to browser
DEBUG - 2020-09-21 07:59:09 --> Total execution time: 0.0263
ERROR - 2020-09-21 11:07:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:07:52 --> Config Class Initialized
INFO - 2020-09-21 11:07:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:07:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:07:52 --> Utf8 Class Initialized
INFO - 2020-09-21 11:07:52 --> URI Class Initialized
DEBUG - 2020-09-21 11:07:52 --> No URI present. Default controller set.
INFO - 2020-09-21 11:07:52 --> Router Class Initialized
INFO - 2020-09-21 11:07:52 --> Output Class Initialized
INFO - 2020-09-21 11:07:52 --> Security Class Initialized
DEBUG - 2020-09-21 11:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:07:52 --> Input Class Initialized
INFO - 2020-09-21 11:07:52 --> Language Class Initialized
INFO - 2020-09-21 11:07:52 --> Loader Class Initialized
INFO - 2020-09-21 11:07:52 --> Helper loaded: url_helper
INFO - 2020-09-21 11:07:52 --> Database Driver Class Initialized
INFO - 2020-09-21 11:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:07:52 --> Email Class Initialized
INFO - 2020-09-21 11:07:52 --> Controller Class Initialized
INFO - 2020-09-21 11:07:52 --> Model Class Initialized
INFO - 2020-09-21 11:07:52 --> Model Class Initialized
DEBUG - 2020-09-21 11:07:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:07:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 11:07:52 --> Final output sent to browser
DEBUG - 2020-09-21 11:07:52 --> Total execution time: 0.0214
ERROR - 2020-09-21 11:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:08:31 --> Config Class Initialized
INFO - 2020-09-21 11:08:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:08:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:08:31 --> Utf8 Class Initialized
INFO - 2020-09-21 11:08:31 --> URI Class Initialized
INFO - 2020-09-21 11:08:31 --> Router Class Initialized
INFO - 2020-09-21 11:08:31 --> Output Class Initialized
INFO - 2020-09-21 11:08:31 --> Security Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:08:31 --> Input Class Initialized
INFO - 2020-09-21 11:08:31 --> Language Class Initialized
INFO - 2020-09-21 11:08:31 --> Loader Class Initialized
INFO - 2020-09-21 11:08:31 --> Helper loaded: url_helper
INFO - 2020-09-21 11:08:31 --> Database Driver Class Initialized
INFO - 2020-09-21 11:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:08:31 --> Email Class Initialized
INFO - 2020-09-21 11:08:31 --> Controller Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:08:31 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-21 11:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:08:31 --> Config Class Initialized
INFO - 2020-09-21 11:08:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:08:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:08:31 --> Utf8 Class Initialized
INFO - 2020-09-21 11:08:31 --> URI Class Initialized
INFO - 2020-09-21 11:08:31 --> Router Class Initialized
INFO - 2020-09-21 11:08:31 --> Output Class Initialized
INFO - 2020-09-21 11:08:31 --> Security Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:08:31 --> Input Class Initialized
INFO - 2020-09-21 11:08:31 --> Language Class Initialized
INFO - 2020-09-21 11:08:31 --> Loader Class Initialized
INFO - 2020-09-21 11:08:31 --> Helper loaded: url_helper
INFO - 2020-09-21 11:08:31 --> Database Driver Class Initialized
INFO - 2020-09-21 11:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:08:31 --> Email Class Initialized
INFO - 2020-09-21 11:08:31 --> Controller Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 11:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:08:31 --> Config Class Initialized
INFO - 2020-09-21 11:08:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:08:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:08:31 --> Utf8 Class Initialized
INFO - 2020-09-21 11:08:31 --> URI Class Initialized
DEBUG - 2020-09-21 11:08:31 --> No URI present. Default controller set.
INFO - 2020-09-21 11:08:31 --> Router Class Initialized
INFO - 2020-09-21 11:08:31 --> Output Class Initialized
INFO - 2020-09-21 11:08:31 --> Security Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:08:31 --> Input Class Initialized
INFO - 2020-09-21 11:08:31 --> Language Class Initialized
INFO - 2020-09-21 11:08:31 --> Loader Class Initialized
INFO - 2020-09-21 11:08:31 --> Helper loaded: url_helper
INFO - 2020-09-21 11:08:31 --> Database Driver Class Initialized
INFO - 2020-09-21 11:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:08:31 --> Email Class Initialized
INFO - 2020-09-21 11:08:31 --> Controller Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:08:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 11:08:31 --> Final output sent to browser
DEBUG - 2020-09-21 11:08:31 --> Total execution time: 0.0195
ERROR - 2020-09-21 11:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:08:31 --> Config Class Initialized
INFO - 2020-09-21 11:08:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:08:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:08:31 --> Utf8 Class Initialized
INFO - 2020-09-21 11:08:31 --> URI Class Initialized
INFO - 2020-09-21 11:08:31 --> Router Class Initialized
INFO - 2020-09-21 11:08:31 --> Output Class Initialized
INFO - 2020-09-21 11:08:31 --> Security Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:08:31 --> Input Class Initialized
INFO - 2020-09-21 11:08:31 --> Language Class Initialized
INFO - 2020-09-21 11:08:31 --> Loader Class Initialized
INFO - 2020-09-21 11:08:31 --> Helper loaded: url_helper
INFO - 2020-09-21 11:08:31 --> Database Driver Class Initialized
INFO - 2020-09-21 11:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:08:31 --> Email Class Initialized
INFO - 2020-09-21 11:08:31 --> Controller Class Initialized
DEBUG - 2020-09-21 11:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:08:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
INFO - 2020-09-21 11:08:31 --> Model Class Initialized
INFO - 2020-09-21 11:08:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 11:08:31 --> Final output sent to browser
DEBUG - 2020-09-21 11:08:31 --> Total execution time: 0.0296
ERROR - 2020-09-21 11:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:11:38 --> Config Class Initialized
INFO - 2020-09-21 11:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:11:38 --> Utf8 Class Initialized
INFO - 2020-09-21 11:11:38 --> URI Class Initialized
INFO - 2020-09-21 11:11:38 --> Router Class Initialized
INFO - 2020-09-21 11:11:38 --> Output Class Initialized
INFO - 2020-09-21 11:11:38 --> Security Class Initialized
DEBUG - 2020-09-21 11:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:11:38 --> Input Class Initialized
INFO - 2020-09-21 11:11:38 --> Language Class Initialized
INFO - 2020-09-21 11:11:38 --> Loader Class Initialized
INFO - 2020-09-21 11:11:38 --> Helper loaded: url_helper
INFO - 2020-09-21 11:11:38 --> Database Driver Class Initialized
INFO - 2020-09-21 11:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:11:38 --> Email Class Initialized
INFO - 2020-09-21 11:11:38 --> Controller Class Initialized
DEBUG - 2020-09-21 11:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:11:38 --> Model Class Initialized
INFO - 2020-09-21 11:11:38 --> Model Class Initialized
INFO - 2020-09-21 11:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:11:38 --> Final output sent to browser
DEBUG - 2020-09-21 11:11:38 --> Total execution time: 0.0269
ERROR - 2020-09-21 11:13:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:13:34 --> Config Class Initialized
INFO - 2020-09-21 11:13:34 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:13:34 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:13:34 --> Utf8 Class Initialized
INFO - 2020-09-21 11:13:34 --> URI Class Initialized
INFO - 2020-09-21 11:13:34 --> Router Class Initialized
INFO - 2020-09-21 11:13:34 --> Output Class Initialized
INFO - 2020-09-21 11:13:34 --> Security Class Initialized
DEBUG - 2020-09-21 11:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:13:34 --> Input Class Initialized
INFO - 2020-09-21 11:13:34 --> Language Class Initialized
INFO - 2020-09-21 11:13:34 --> Loader Class Initialized
INFO - 2020-09-21 11:13:34 --> Helper loaded: url_helper
INFO - 2020-09-21 11:13:34 --> Database Driver Class Initialized
INFO - 2020-09-21 11:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:13:34 --> Email Class Initialized
INFO - 2020-09-21 11:13:34 --> Controller Class Initialized
DEBUG - 2020-09-21 11:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:13:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:13:34 --> Model Class Initialized
INFO - 2020-09-21 11:13:34 --> Model Class Initialized
INFO - 2020-09-21 11:13:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:13:34 --> Final output sent to browser
DEBUG - 2020-09-21 11:13:34 --> Total execution time: 0.0235
ERROR - 2020-09-21 11:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:17:06 --> Config Class Initialized
INFO - 2020-09-21 11:17:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:17:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:17:06 --> Utf8 Class Initialized
INFO - 2020-09-21 11:17:06 --> URI Class Initialized
INFO - 2020-09-21 11:17:06 --> Router Class Initialized
INFO - 2020-09-21 11:17:06 --> Output Class Initialized
INFO - 2020-09-21 11:17:06 --> Security Class Initialized
DEBUG - 2020-09-21 11:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:17:06 --> Input Class Initialized
INFO - 2020-09-21 11:17:06 --> Language Class Initialized
INFO - 2020-09-21 11:17:06 --> Loader Class Initialized
INFO - 2020-09-21 11:17:06 --> Helper loaded: url_helper
INFO - 2020-09-21 11:17:06 --> Database Driver Class Initialized
INFO - 2020-09-21 11:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:17:06 --> Email Class Initialized
INFO - 2020-09-21 11:17:06 --> Controller Class Initialized
DEBUG - 2020-09-21 11:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:17:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:17:06 --> Model Class Initialized
INFO - 2020-09-21 11:17:06 --> Model Class Initialized
INFO - 2020-09-21 11:17:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:17:06 --> Final output sent to browser
DEBUG - 2020-09-21 11:17:06 --> Total execution time: 0.0246
ERROR - 2020-09-21 11:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:17:11 --> Config Class Initialized
INFO - 2020-09-21 11:17:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:17:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:17:11 --> Utf8 Class Initialized
INFO - 2020-09-21 11:17:11 --> URI Class Initialized
INFO - 2020-09-21 11:17:11 --> Router Class Initialized
INFO - 2020-09-21 11:17:11 --> Output Class Initialized
INFO - 2020-09-21 11:17:11 --> Security Class Initialized
DEBUG - 2020-09-21 11:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:17:11 --> Input Class Initialized
INFO - 2020-09-21 11:17:11 --> Language Class Initialized
INFO - 2020-09-21 11:17:11 --> Loader Class Initialized
INFO - 2020-09-21 11:17:11 --> Helper loaded: url_helper
INFO - 2020-09-21 11:17:11 --> Database Driver Class Initialized
INFO - 2020-09-21 11:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:17:11 --> Email Class Initialized
INFO - 2020-09-21 11:17:11 --> Controller Class Initialized
DEBUG - 2020-09-21 11:17:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:17:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:17:11 --> Model Class Initialized
INFO - 2020-09-21 11:17:11 --> Model Class Initialized
INFO - 2020-09-21 11:17:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 11:17:11 --> Final output sent to browser
DEBUG - 2020-09-21 11:17:11 --> Total execution time: 0.0223
ERROR - 2020-09-21 11:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:20:27 --> Config Class Initialized
INFO - 2020-09-21 11:20:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:20:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:20:27 --> Utf8 Class Initialized
INFO - 2020-09-21 11:20:27 --> URI Class Initialized
INFO - 2020-09-21 11:20:27 --> Router Class Initialized
INFO - 2020-09-21 11:20:27 --> Output Class Initialized
INFO - 2020-09-21 11:20:27 --> Security Class Initialized
DEBUG - 2020-09-21 11:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:20:27 --> Input Class Initialized
INFO - 2020-09-21 11:20:27 --> Language Class Initialized
INFO - 2020-09-21 11:20:27 --> Loader Class Initialized
INFO - 2020-09-21 11:20:27 --> Helper loaded: url_helper
INFO - 2020-09-21 11:20:27 --> Database Driver Class Initialized
INFO - 2020-09-21 11:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:20:27 --> Email Class Initialized
INFO - 2020-09-21 11:20:27 --> Controller Class Initialized
DEBUG - 2020-09-21 11:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:20:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:20:27 --> Model Class Initialized
INFO - 2020-09-21 11:20:27 --> Model Class Initialized
ERROR - 2020-09-21 11:20:27 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list2; expected 1, got 0 - Invalid query: CALL status_master_list2()
INFO - 2020-09-21 11:20:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-21 11:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:20:40 --> Config Class Initialized
INFO - 2020-09-21 11:20:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:20:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:20:40 --> Utf8 Class Initialized
INFO - 2020-09-21 11:20:40 --> URI Class Initialized
INFO - 2020-09-21 11:20:40 --> Router Class Initialized
INFO - 2020-09-21 11:20:40 --> Output Class Initialized
INFO - 2020-09-21 11:20:40 --> Security Class Initialized
DEBUG - 2020-09-21 11:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:20:40 --> Input Class Initialized
INFO - 2020-09-21 11:20:40 --> Language Class Initialized
INFO - 2020-09-21 11:20:40 --> Loader Class Initialized
INFO - 2020-09-21 11:20:40 --> Helper loaded: url_helper
INFO - 2020-09-21 11:20:40 --> Database Driver Class Initialized
INFO - 2020-09-21 11:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:20:40 --> Email Class Initialized
INFO - 2020-09-21 11:20:40 --> Controller Class Initialized
DEBUG - 2020-09-21 11:20:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:20:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:20:40 --> Model Class Initialized
INFO - 2020-09-21 11:20:40 --> Model Class Initialized
INFO - 2020-09-21 11:20:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:20:40 --> Final output sent to browser
DEBUG - 2020-09-21 11:20:40 --> Total execution time: 0.0266
ERROR - 2020-09-21 11:20:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:20:43 --> Config Class Initialized
INFO - 2020-09-21 11:20:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:20:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:20:43 --> Utf8 Class Initialized
INFO - 2020-09-21 11:20:43 --> URI Class Initialized
INFO - 2020-09-21 11:20:43 --> Router Class Initialized
INFO - 2020-09-21 11:20:43 --> Output Class Initialized
INFO - 2020-09-21 11:20:43 --> Security Class Initialized
DEBUG - 2020-09-21 11:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:20:43 --> Input Class Initialized
INFO - 2020-09-21 11:20:43 --> Language Class Initialized
INFO - 2020-09-21 11:20:43 --> Loader Class Initialized
INFO - 2020-09-21 11:20:43 --> Helper loaded: url_helper
INFO - 2020-09-21 11:20:43 --> Database Driver Class Initialized
INFO - 2020-09-21 11:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:20:43 --> Email Class Initialized
INFO - 2020-09-21 11:20:43 --> Controller Class Initialized
DEBUG - 2020-09-21 11:20:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:20:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:20:43 --> Model Class Initialized
INFO - 2020-09-21 11:20:43 --> Model Class Initialized
ERROR - 2020-09-21 11:20:43 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list2; expected 1, got 0 - Invalid query: CALL status_master_list2()
INFO - 2020-09-21 11:20:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-21 11:20:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:20:47 --> Config Class Initialized
INFO - 2020-09-21 11:20:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:20:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:20:47 --> Utf8 Class Initialized
INFO - 2020-09-21 11:20:47 --> URI Class Initialized
INFO - 2020-09-21 11:20:47 --> Router Class Initialized
INFO - 2020-09-21 11:20:47 --> Output Class Initialized
INFO - 2020-09-21 11:20:47 --> Security Class Initialized
DEBUG - 2020-09-21 11:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:20:47 --> Input Class Initialized
INFO - 2020-09-21 11:20:47 --> Language Class Initialized
INFO - 2020-09-21 11:20:47 --> Loader Class Initialized
INFO - 2020-09-21 11:20:47 --> Helper loaded: url_helper
INFO - 2020-09-21 11:20:47 --> Database Driver Class Initialized
INFO - 2020-09-21 11:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:20:47 --> Email Class Initialized
INFO - 2020-09-21 11:20:47 --> Controller Class Initialized
DEBUG - 2020-09-21 11:20:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:20:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:20:47 --> Model Class Initialized
INFO - 2020-09-21 11:20:47 --> Model Class Initialized
INFO - 2020-09-21 11:20:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:20:47 --> Final output sent to browser
DEBUG - 2020-09-21 11:20:47 --> Total execution time: 0.0258
ERROR - 2020-09-21 11:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:21:43 --> Config Class Initialized
INFO - 2020-09-21 11:21:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:21:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:21:43 --> Utf8 Class Initialized
INFO - 2020-09-21 11:21:43 --> URI Class Initialized
INFO - 2020-09-21 11:21:43 --> Router Class Initialized
INFO - 2020-09-21 11:21:43 --> Output Class Initialized
INFO - 2020-09-21 11:21:43 --> Security Class Initialized
DEBUG - 2020-09-21 11:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:21:43 --> Input Class Initialized
INFO - 2020-09-21 11:21:43 --> Language Class Initialized
INFO - 2020-09-21 11:21:43 --> Loader Class Initialized
INFO - 2020-09-21 11:21:43 --> Helper loaded: url_helper
INFO - 2020-09-21 11:21:43 --> Database Driver Class Initialized
INFO - 2020-09-21 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:21:43 --> Email Class Initialized
INFO - 2020-09-21 11:21:43 --> Controller Class Initialized
DEBUG - 2020-09-21 11:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:21:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:21:43 --> Model Class Initialized
INFO - 2020-09-21 11:21:43 --> Model Class Initialized
INFO - 2020-09-21 11:21:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:21:43 --> Final output sent to browser
DEBUG - 2020-09-21 11:21:43 --> Total execution time: 0.0316
ERROR - 2020-09-21 11:21:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:21:47 --> Config Class Initialized
INFO - 2020-09-21 11:21:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:21:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:21:47 --> Utf8 Class Initialized
INFO - 2020-09-21 11:21:47 --> URI Class Initialized
INFO - 2020-09-21 11:21:47 --> Router Class Initialized
INFO - 2020-09-21 11:21:47 --> Output Class Initialized
INFO - 2020-09-21 11:21:47 --> Security Class Initialized
DEBUG - 2020-09-21 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:21:47 --> Input Class Initialized
INFO - 2020-09-21 11:21:47 --> Language Class Initialized
INFO - 2020-09-21 11:21:47 --> Loader Class Initialized
INFO - 2020-09-21 11:21:47 --> Helper loaded: url_helper
INFO - 2020-09-21 11:21:47 --> Database Driver Class Initialized
INFO - 2020-09-21 11:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:21:47 --> Email Class Initialized
INFO - 2020-09-21 11:21:47 --> Controller Class Initialized
DEBUG - 2020-09-21 11:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:21:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:21:47 --> Model Class Initialized
INFO - 2020-09-21 11:21:47 --> Model Class Initialized
ERROR - 2020-09-21 11:21:47 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.status_master_list2; expected 1, got 0 - Invalid query: CALL status_master_list2()
INFO - 2020-09-21 11:21:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-21 11:22:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:22:33 --> Config Class Initialized
INFO - 2020-09-21 11:22:33 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:22:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:22:33 --> Utf8 Class Initialized
INFO - 2020-09-21 11:22:33 --> URI Class Initialized
INFO - 2020-09-21 11:22:33 --> Router Class Initialized
INFO - 2020-09-21 11:22:33 --> Output Class Initialized
INFO - 2020-09-21 11:22:33 --> Security Class Initialized
DEBUG - 2020-09-21 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:22:33 --> Input Class Initialized
INFO - 2020-09-21 11:22:33 --> Language Class Initialized
INFO - 2020-09-21 11:22:33 --> Loader Class Initialized
INFO - 2020-09-21 11:22:33 --> Helper loaded: url_helper
INFO - 2020-09-21 11:22:33 --> Database Driver Class Initialized
INFO - 2020-09-21 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:22:33 --> Email Class Initialized
INFO - 2020-09-21 11:22:33 --> Controller Class Initialized
DEBUG - 2020-09-21 11:22:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:22:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:22:33 --> Model Class Initialized
INFO - 2020-09-21 11:22:33 --> Model Class Initialized
INFO - 2020-09-21 11:22:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 11:22:33 --> Final output sent to browser
DEBUG - 2020-09-21 11:22:33 --> Total execution time: 0.0279
ERROR - 2020-09-21 11:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:22:51 --> Config Class Initialized
INFO - 2020-09-21 11:22:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:22:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:22:51 --> Utf8 Class Initialized
INFO - 2020-09-21 11:22:51 --> URI Class Initialized
INFO - 2020-09-21 11:22:51 --> Router Class Initialized
INFO - 2020-09-21 11:22:51 --> Output Class Initialized
INFO - 2020-09-21 11:22:51 --> Security Class Initialized
DEBUG - 2020-09-21 11:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:22:51 --> Input Class Initialized
INFO - 2020-09-21 11:22:51 --> Language Class Initialized
INFO - 2020-09-21 11:22:51 --> Loader Class Initialized
INFO - 2020-09-21 11:22:51 --> Helper loaded: url_helper
INFO - 2020-09-21 11:22:51 --> Database Driver Class Initialized
INFO - 2020-09-21 11:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:22:51 --> Email Class Initialized
INFO - 2020-09-21 11:22:51 --> Controller Class Initialized
DEBUG - 2020-09-21 11:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:22:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:22:51 --> Model Class Initialized
INFO - 2020-09-21 11:22:51 --> Model Class Initialized
INFO - 2020-09-21 11:22:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:22:51 --> Final output sent to browser
DEBUG - 2020-09-21 11:22:51 --> Total execution time: 0.0253
ERROR - 2020-09-21 11:23:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:23:02 --> Config Class Initialized
INFO - 2020-09-21 11:23:02 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:23:02 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:23:02 --> Utf8 Class Initialized
INFO - 2020-09-21 11:23:02 --> URI Class Initialized
INFO - 2020-09-21 11:23:02 --> Router Class Initialized
INFO - 2020-09-21 11:23:02 --> Output Class Initialized
INFO - 2020-09-21 11:23:02 --> Security Class Initialized
DEBUG - 2020-09-21 11:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:23:02 --> Input Class Initialized
INFO - 2020-09-21 11:23:02 --> Language Class Initialized
INFO - 2020-09-21 11:23:02 --> Loader Class Initialized
INFO - 2020-09-21 11:23:02 --> Helper loaded: url_helper
INFO - 2020-09-21 11:23:02 --> Database Driver Class Initialized
INFO - 2020-09-21 11:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:23:02 --> Email Class Initialized
INFO - 2020-09-21 11:23:02 --> Controller Class Initialized
DEBUG - 2020-09-21 11:23:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:23:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:23:02 --> Model Class Initialized
INFO - 2020-09-21 11:23:02 --> Model Class Initialized
INFO - 2020-09-21 11:23:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:23:02 --> Final output sent to browser
DEBUG - 2020-09-21 11:23:02 --> Total execution time: 0.0276
ERROR - 2020-09-21 11:23:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:23:05 --> Config Class Initialized
INFO - 2020-09-21 11:23:05 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:23:05 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:23:05 --> Utf8 Class Initialized
INFO - 2020-09-21 11:23:05 --> URI Class Initialized
DEBUG - 2020-09-21 11:23:05 --> No URI present. Default controller set.
INFO - 2020-09-21 11:23:05 --> Router Class Initialized
INFO - 2020-09-21 11:23:05 --> Output Class Initialized
INFO - 2020-09-21 11:23:05 --> Security Class Initialized
DEBUG - 2020-09-21 11:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:23:05 --> Input Class Initialized
INFO - 2020-09-21 11:23:05 --> Language Class Initialized
INFO - 2020-09-21 11:23:05 --> Loader Class Initialized
INFO - 2020-09-21 11:23:05 --> Helper loaded: url_helper
INFO - 2020-09-21 11:23:05 --> Database Driver Class Initialized
INFO - 2020-09-21 11:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:23:05 --> Email Class Initialized
INFO - 2020-09-21 11:23:05 --> Controller Class Initialized
INFO - 2020-09-21 11:23:05 --> Model Class Initialized
INFO - 2020-09-21 11:23:05 --> Model Class Initialized
DEBUG - 2020-09-21 11:23:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:23:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 11:23:05 --> Final output sent to browser
DEBUG - 2020-09-21 11:23:05 --> Total execution time: 0.0246
ERROR - 2020-09-21 11:23:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:23:14 --> Config Class Initialized
INFO - 2020-09-21 11:23:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:23:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:23:14 --> Utf8 Class Initialized
INFO - 2020-09-21 11:23:14 --> URI Class Initialized
INFO - 2020-09-21 11:23:14 --> Router Class Initialized
INFO - 2020-09-21 11:23:14 --> Output Class Initialized
INFO - 2020-09-21 11:23:14 --> Security Class Initialized
DEBUG - 2020-09-21 11:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:23:14 --> Input Class Initialized
INFO - 2020-09-21 11:23:14 --> Language Class Initialized
INFO - 2020-09-21 11:23:14 --> Loader Class Initialized
INFO - 2020-09-21 11:23:14 --> Helper loaded: url_helper
INFO - 2020-09-21 11:23:14 --> Database Driver Class Initialized
INFO - 2020-09-21 11:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:23:14 --> Email Class Initialized
INFO - 2020-09-21 11:23:14 --> Controller Class Initialized
INFO - 2020-09-21 11:23:14 --> Model Class Initialized
INFO - 2020-09-21 11:23:14 --> Model Class Initialized
DEBUG - 2020-09-21 11:23:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:23:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:23:14 --> Model Class Initialized
INFO - 2020-09-21 11:23:14 --> Final output sent to browser
DEBUG - 2020-09-21 11:23:14 --> Total execution time: 0.0225
ERROR - 2020-09-21 11:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:23:15 --> Config Class Initialized
INFO - 2020-09-21 11:23:15 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:23:15 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:23:15 --> Utf8 Class Initialized
INFO - 2020-09-21 11:23:15 --> URI Class Initialized
INFO - 2020-09-21 11:23:15 --> Router Class Initialized
INFO - 2020-09-21 11:23:15 --> Output Class Initialized
INFO - 2020-09-21 11:23:15 --> Security Class Initialized
DEBUG - 2020-09-21 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:23:15 --> Input Class Initialized
INFO - 2020-09-21 11:23:15 --> Language Class Initialized
INFO - 2020-09-21 11:23:15 --> Loader Class Initialized
INFO - 2020-09-21 11:23:15 --> Helper loaded: url_helper
INFO - 2020-09-21 11:23:15 --> Database Driver Class Initialized
INFO - 2020-09-21 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:23:15 --> Email Class Initialized
INFO - 2020-09-21 11:23:15 --> Controller Class Initialized
INFO - 2020-09-21 11:23:15 --> Model Class Initialized
INFO - 2020-09-21 11:23:15 --> Model Class Initialized
DEBUG - 2020-09-21 11:23:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 11:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:23:15 --> Config Class Initialized
INFO - 2020-09-21 11:23:15 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:23:15 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:23:15 --> Utf8 Class Initialized
INFO - 2020-09-21 11:23:15 --> URI Class Initialized
INFO - 2020-09-21 11:23:15 --> Router Class Initialized
INFO - 2020-09-21 11:23:15 --> Output Class Initialized
INFO - 2020-09-21 11:23:15 --> Security Class Initialized
DEBUG - 2020-09-21 11:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:23:15 --> Input Class Initialized
INFO - 2020-09-21 11:23:15 --> Language Class Initialized
INFO - 2020-09-21 11:23:15 --> Loader Class Initialized
INFO - 2020-09-21 11:23:15 --> Helper loaded: url_helper
INFO - 2020-09-21 11:23:15 --> Database Driver Class Initialized
INFO - 2020-09-21 11:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:23:15 --> Email Class Initialized
INFO - 2020-09-21 11:23:15 --> Controller Class Initialized
DEBUG - 2020-09-21 11:23:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:23:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:23:15 --> Model Class Initialized
INFO - 2020-09-21 11:23:15 --> Model Class Initialized
INFO - 2020-09-21 11:23:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 11:23:15 --> Final output sent to browser
DEBUG - 2020-09-21 11:23:15 --> Total execution time: 0.0287
ERROR - 2020-09-21 11:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:25:23 --> Config Class Initialized
INFO - 2020-09-21 11:25:23 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:25:23 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:25:23 --> Utf8 Class Initialized
INFO - 2020-09-21 11:25:23 --> URI Class Initialized
INFO - 2020-09-21 11:25:23 --> Router Class Initialized
INFO - 2020-09-21 11:25:23 --> Output Class Initialized
INFO - 2020-09-21 11:25:23 --> Security Class Initialized
DEBUG - 2020-09-21 11:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:25:23 --> Input Class Initialized
INFO - 2020-09-21 11:25:23 --> Language Class Initialized
INFO - 2020-09-21 11:25:23 --> Loader Class Initialized
INFO - 2020-09-21 11:25:23 --> Helper loaded: url_helper
INFO - 2020-09-21 11:25:23 --> Database Driver Class Initialized
INFO - 2020-09-21 11:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:25:23 --> Email Class Initialized
INFO - 2020-09-21 11:25:23 --> Controller Class Initialized
DEBUG - 2020-09-21 11:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:25:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:25:23 --> Model Class Initialized
INFO - 2020-09-21 11:25:23 --> Model Class Initialized
INFO - 2020-09-21 11:25:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 11:25:23 --> Final output sent to browser
DEBUG - 2020-09-21 11:25:23 --> Total execution time: 0.0243
ERROR - 2020-09-21 11:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:25:40 --> Config Class Initialized
INFO - 2020-09-21 11:25:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:25:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:25:40 --> Utf8 Class Initialized
INFO - 2020-09-21 11:25:40 --> URI Class Initialized
INFO - 2020-09-21 11:25:40 --> Router Class Initialized
INFO - 2020-09-21 11:25:40 --> Output Class Initialized
INFO - 2020-09-21 11:25:40 --> Security Class Initialized
DEBUG - 2020-09-21 11:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:25:40 --> Input Class Initialized
INFO - 2020-09-21 11:25:40 --> Language Class Initialized
INFO - 2020-09-21 11:25:40 --> Loader Class Initialized
INFO - 2020-09-21 11:25:40 --> Helper loaded: url_helper
INFO - 2020-09-21 11:25:40 --> Database Driver Class Initialized
INFO - 2020-09-21 11:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:25:40 --> Email Class Initialized
INFO - 2020-09-21 11:25:40 --> Controller Class Initialized
DEBUG - 2020-09-21 11:25:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:25:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:25:40 --> Model Class Initialized
INFO - 2020-09-21 11:25:40 --> Model Class Initialized
INFO - 2020-09-21 11:25:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:25:40 --> Final output sent to browser
DEBUG - 2020-09-21 11:25:40 --> Total execution time: 0.0243
ERROR - 2020-09-21 11:25:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:25:43 --> Config Class Initialized
INFO - 2020-09-21 11:25:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:25:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:25:43 --> Utf8 Class Initialized
INFO - 2020-09-21 11:25:43 --> URI Class Initialized
INFO - 2020-09-21 11:25:43 --> Router Class Initialized
INFO - 2020-09-21 11:25:43 --> Output Class Initialized
INFO - 2020-09-21 11:25:43 --> Security Class Initialized
DEBUG - 2020-09-21 11:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:25:43 --> Input Class Initialized
INFO - 2020-09-21 11:25:43 --> Language Class Initialized
INFO - 2020-09-21 11:25:43 --> Loader Class Initialized
INFO - 2020-09-21 11:25:43 --> Helper loaded: url_helper
INFO - 2020-09-21 11:25:43 --> Database Driver Class Initialized
INFO - 2020-09-21 11:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:25:43 --> Email Class Initialized
INFO - 2020-09-21 11:25:43 --> Controller Class Initialized
DEBUG - 2020-09-21 11:25:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:25:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:25:43 --> Model Class Initialized
INFO - 2020-09-21 11:25:43 --> Model Class Initialized
INFO - 2020-09-21 11:25:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 11:25:43 --> Final output sent to browser
DEBUG - 2020-09-21 11:25:43 --> Total execution time: 0.0270
ERROR - 2020-09-21 11:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:27:08 --> Config Class Initialized
INFO - 2020-09-21 11:27:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:27:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:27:08 --> Utf8 Class Initialized
INFO - 2020-09-21 11:27:08 --> URI Class Initialized
INFO - 2020-09-21 11:27:08 --> Router Class Initialized
INFO - 2020-09-21 11:27:08 --> Output Class Initialized
INFO - 2020-09-21 11:27:08 --> Security Class Initialized
DEBUG - 2020-09-21 11:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:27:08 --> Input Class Initialized
INFO - 2020-09-21 11:27:08 --> Language Class Initialized
INFO - 2020-09-21 11:27:08 --> Loader Class Initialized
INFO - 2020-09-21 11:27:08 --> Helper loaded: url_helper
INFO - 2020-09-21 11:27:08 --> Database Driver Class Initialized
INFO - 2020-09-21 11:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:27:08 --> Email Class Initialized
INFO - 2020-09-21 11:27:08 --> Controller Class Initialized
DEBUG - 2020-09-21 11:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:27:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:27:08 --> Model Class Initialized
INFO - 2020-09-21 11:27:08 --> Model Class Initialized
INFO - 2020-09-21 11:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:27:08 --> Final output sent to browser
DEBUG - 2020-09-21 11:27:08 --> Total execution time: 0.0236
ERROR - 2020-09-21 11:27:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:27:46 --> Config Class Initialized
INFO - 2020-09-21 11:27:46 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:27:46 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:27:46 --> Utf8 Class Initialized
INFO - 2020-09-21 11:27:46 --> URI Class Initialized
INFO - 2020-09-21 11:27:46 --> Router Class Initialized
INFO - 2020-09-21 11:27:46 --> Output Class Initialized
INFO - 2020-09-21 11:27:46 --> Security Class Initialized
DEBUG - 2020-09-21 11:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:27:46 --> Input Class Initialized
INFO - 2020-09-21 11:27:46 --> Language Class Initialized
INFO - 2020-09-21 11:27:46 --> Loader Class Initialized
INFO - 2020-09-21 11:27:46 --> Helper loaded: url_helper
INFO - 2020-09-21 11:27:46 --> Database Driver Class Initialized
INFO - 2020-09-21 11:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:27:46 --> Email Class Initialized
INFO - 2020-09-21 11:27:46 --> Controller Class Initialized
DEBUG - 2020-09-21 11:27:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:27:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:27:46 --> Model Class Initialized
INFO - 2020-09-21 11:27:46 --> Model Class Initialized
INFO - 2020-09-21 11:27:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:27:46 --> Final output sent to browser
DEBUG - 2020-09-21 11:27:46 --> Total execution time: 0.0261
ERROR - 2020-09-21 11:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:31:33 --> Config Class Initialized
INFO - 2020-09-21 11:31:33 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:31:33 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:31:33 --> Utf8 Class Initialized
INFO - 2020-09-21 11:31:33 --> URI Class Initialized
INFO - 2020-09-21 11:31:33 --> Router Class Initialized
INFO - 2020-09-21 11:31:33 --> Output Class Initialized
INFO - 2020-09-21 11:31:33 --> Security Class Initialized
DEBUG - 2020-09-21 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:31:33 --> Input Class Initialized
INFO - 2020-09-21 11:31:33 --> Language Class Initialized
INFO - 2020-09-21 11:31:33 --> Loader Class Initialized
INFO - 2020-09-21 11:31:33 --> Helper loaded: url_helper
INFO - 2020-09-21 11:31:33 --> Database Driver Class Initialized
INFO - 2020-09-21 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:31:33 --> Email Class Initialized
INFO - 2020-09-21 11:31:33 --> Controller Class Initialized
DEBUG - 2020-09-21 11:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:31:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:31:33 --> Model Class Initialized
INFO - 2020-09-21 11:31:33 --> Model Class Initialized
INFO - 2020-09-21 11:31:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:31:33 --> Final output sent to browser
DEBUG - 2020-09-21 11:31:33 --> Total execution time: 0.0255
ERROR - 2020-09-21 11:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:32:46 --> Config Class Initialized
INFO - 2020-09-21 11:32:46 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:32:46 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:32:46 --> Utf8 Class Initialized
INFO - 2020-09-21 11:32:46 --> URI Class Initialized
INFO - 2020-09-21 11:32:46 --> Router Class Initialized
INFO - 2020-09-21 11:32:46 --> Output Class Initialized
INFO - 2020-09-21 11:32:46 --> Security Class Initialized
DEBUG - 2020-09-21 11:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:32:46 --> Input Class Initialized
INFO - 2020-09-21 11:32:46 --> Language Class Initialized
INFO - 2020-09-21 11:32:46 --> Loader Class Initialized
INFO - 2020-09-21 11:32:46 --> Helper loaded: url_helper
INFO - 2020-09-21 11:32:46 --> Database Driver Class Initialized
INFO - 2020-09-21 11:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:32:46 --> Email Class Initialized
INFO - 2020-09-21 11:32:46 --> Controller Class Initialized
DEBUG - 2020-09-21 11:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:32:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:32:46 --> Model Class Initialized
INFO - 2020-09-21 11:32:46 --> Model Class Initialized
INFO - 2020-09-21 11:32:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:32:46 --> Final output sent to browser
DEBUG - 2020-09-21 11:32:46 --> Total execution time: 0.0278
ERROR - 2020-09-21 11:33:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:33:03 --> Config Class Initialized
INFO - 2020-09-21 11:33:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:33:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:33:03 --> Utf8 Class Initialized
INFO - 2020-09-21 11:33:03 --> URI Class Initialized
INFO - 2020-09-21 11:33:03 --> Router Class Initialized
INFO - 2020-09-21 11:33:03 --> Output Class Initialized
INFO - 2020-09-21 11:33:03 --> Security Class Initialized
DEBUG - 2020-09-21 11:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:33:03 --> Input Class Initialized
INFO - 2020-09-21 11:33:03 --> Language Class Initialized
INFO - 2020-09-21 11:33:03 --> Loader Class Initialized
INFO - 2020-09-21 11:33:03 --> Helper loaded: url_helper
INFO - 2020-09-21 11:33:03 --> Database Driver Class Initialized
INFO - 2020-09-21 11:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:33:03 --> Email Class Initialized
INFO - 2020-09-21 11:33:03 --> Controller Class Initialized
DEBUG - 2020-09-21 11:33:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:33:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:33:03 --> Model Class Initialized
INFO - 2020-09-21 11:33:03 --> Model Class Initialized
INFO - 2020-09-21 11:33:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 11:33:03 --> Final output sent to browser
DEBUG - 2020-09-21 11:33:03 --> Total execution time: 0.0288
ERROR - 2020-09-21 11:33:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:33:22 --> Config Class Initialized
INFO - 2020-09-21 11:33:22 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:33:22 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:33:22 --> Utf8 Class Initialized
INFO - 2020-09-21 11:33:22 --> URI Class Initialized
INFO - 2020-09-21 11:33:22 --> Router Class Initialized
INFO - 2020-09-21 11:33:22 --> Output Class Initialized
INFO - 2020-09-21 11:33:22 --> Security Class Initialized
DEBUG - 2020-09-21 11:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:33:22 --> Input Class Initialized
INFO - 2020-09-21 11:33:22 --> Language Class Initialized
INFO - 2020-09-21 11:33:22 --> Loader Class Initialized
INFO - 2020-09-21 11:33:22 --> Helper loaded: url_helper
INFO - 2020-09-21 11:33:22 --> Database Driver Class Initialized
INFO - 2020-09-21 11:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:33:22 --> Email Class Initialized
INFO - 2020-09-21 11:33:22 --> Controller Class Initialized
DEBUG - 2020-09-21 11:33:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:33:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:33:22 --> Model Class Initialized
INFO - 2020-09-21 11:33:22 --> Model Class Initialized
INFO - 2020-09-21 11:33:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:33:22 --> Final output sent to browser
DEBUG - 2020-09-21 11:33:22 --> Total execution time: 0.0372
ERROR - 2020-09-21 11:33:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:33:22 --> Config Class Initialized
INFO - 2020-09-21 11:33:22 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:33:22 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:33:22 --> Utf8 Class Initialized
INFO - 2020-09-21 11:33:22 --> URI Class Initialized
INFO - 2020-09-21 11:33:22 --> Router Class Initialized
INFO - 2020-09-21 11:33:22 --> Output Class Initialized
INFO - 2020-09-21 11:33:22 --> Security Class Initialized
DEBUG - 2020-09-21 11:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:33:22 --> Input Class Initialized
INFO - 2020-09-21 11:33:22 --> Language Class Initialized
INFO - 2020-09-21 11:33:22 --> Loader Class Initialized
INFO - 2020-09-21 11:33:22 --> Helper loaded: url_helper
INFO - 2020-09-21 11:33:22 --> Database Driver Class Initialized
INFO - 2020-09-21 11:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:33:22 --> Email Class Initialized
INFO - 2020-09-21 11:33:22 --> Controller Class Initialized
DEBUG - 2020-09-21 11:33:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:33:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:33:22 --> Model Class Initialized
INFO - 2020-09-21 11:33:22 --> Model Class Initialized
INFO - 2020-09-21 11:33:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:33:22 --> Final output sent to browser
DEBUG - 2020-09-21 11:33:22 --> Total execution time: 0.0344
ERROR - 2020-09-21 11:36:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:36:08 --> Config Class Initialized
INFO - 2020-09-21 11:36:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:36:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:36:08 --> Utf8 Class Initialized
INFO - 2020-09-21 11:36:08 --> URI Class Initialized
INFO - 2020-09-21 11:36:08 --> Router Class Initialized
INFO - 2020-09-21 11:36:08 --> Output Class Initialized
INFO - 2020-09-21 11:36:08 --> Security Class Initialized
DEBUG - 2020-09-21 11:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:36:08 --> Input Class Initialized
INFO - 2020-09-21 11:36:08 --> Language Class Initialized
INFO - 2020-09-21 11:36:08 --> Loader Class Initialized
INFO - 2020-09-21 11:36:08 --> Helper loaded: url_helper
INFO - 2020-09-21 11:36:08 --> Database Driver Class Initialized
INFO - 2020-09-21 11:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:36:08 --> Email Class Initialized
INFO - 2020-09-21 11:36:08 --> Controller Class Initialized
DEBUG - 2020-09-21 11:36:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:36:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:36:08 --> Model Class Initialized
INFO - 2020-09-21 11:36:08 --> Model Class Initialized
INFO - 2020-09-21 11:36:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:36:08 --> Final output sent to browser
DEBUG - 2020-09-21 11:36:08 --> Total execution time: 0.0333
ERROR - 2020-09-21 11:36:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:36:54 --> Config Class Initialized
INFO - 2020-09-21 11:36:54 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:36:54 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:36:54 --> Utf8 Class Initialized
INFO - 2020-09-21 11:36:54 --> URI Class Initialized
INFO - 2020-09-21 11:36:54 --> Router Class Initialized
INFO - 2020-09-21 11:36:54 --> Output Class Initialized
INFO - 2020-09-21 11:36:54 --> Security Class Initialized
DEBUG - 2020-09-21 11:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:36:54 --> Input Class Initialized
INFO - 2020-09-21 11:36:54 --> Language Class Initialized
INFO - 2020-09-21 11:36:54 --> Loader Class Initialized
INFO - 2020-09-21 11:36:54 --> Helper loaded: url_helper
INFO - 2020-09-21 11:36:54 --> Database Driver Class Initialized
INFO - 2020-09-21 11:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:36:54 --> Email Class Initialized
INFO - 2020-09-21 11:36:54 --> Controller Class Initialized
DEBUG - 2020-09-21 11:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:36:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:36:54 --> Model Class Initialized
INFO - 2020-09-21 11:36:54 --> Model Class Initialized
INFO - 2020-09-21 11:36:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:36:54 --> Final output sent to browser
DEBUG - 2020-09-21 11:36:54 --> Total execution time: 0.0255
ERROR - 2020-09-21 11:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:37:37 --> Config Class Initialized
INFO - 2020-09-21 11:37:37 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:37:37 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:37:37 --> Utf8 Class Initialized
INFO - 2020-09-21 11:37:37 --> URI Class Initialized
INFO - 2020-09-21 11:37:37 --> Router Class Initialized
INFO - 2020-09-21 11:37:37 --> Output Class Initialized
INFO - 2020-09-21 11:37:37 --> Security Class Initialized
DEBUG - 2020-09-21 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:37:37 --> Input Class Initialized
INFO - 2020-09-21 11:37:37 --> Language Class Initialized
INFO - 2020-09-21 11:37:37 --> Loader Class Initialized
INFO - 2020-09-21 11:37:37 --> Helper loaded: url_helper
INFO - 2020-09-21 11:37:37 --> Database Driver Class Initialized
INFO - 2020-09-21 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:37:37 --> Email Class Initialized
INFO - 2020-09-21 11:37:37 --> Controller Class Initialized
DEBUG - 2020-09-21 11:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:37:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:37:37 --> Model Class Initialized
INFO - 2020-09-21 11:37:37 --> Model Class Initialized
INFO - 2020-09-21 11:37:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 11:37:37 --> Final output sent to browser
DEBUG - 2020-09-21 11:37:37 --> Total execution time: 0.0244
ERROR - 2020-09-21 11:37:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:37:42 --> Config Class Initialized
INFO - 2020-09-21 11:37:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:37:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:37:42 --> Utf8 Class Initialized
INFO - 2020-09-21 11:37:42 --> URI Class Initialized
INFO - 2020-09-21 11:37:42 --> Router Class Initialized
INFO - 2020-09-21 11:37:42 --> Output Class Initialized
INFO - 2020-09-21 11:37:42 --> Security Class Initialized
DEBUG - 2020-09-21 11:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:37:42 --> Input Class Initialized
INFO - 2020-09-21 11:37:42 --> Language Class Initialized
INFO - 2020-09-21 11:37:42 --> Loader Class Initialized
INFO - 2020-09-21 11:37:42 --> Helper loaded: url_helper
INFO - 2020-09-21 11:37:42 --> Database Driver Class Initialized
INFO - 2020-09-21 11:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:37:42 --> Email Class Initialized
INFO - 2020-09-21 11:37:42 --> Controller Class Initialized
DEBUG - 2020-09-21 11:37:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:37:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:37:42 --> Model Class Initialized
INFO - 2020-09-21 11:37:42 --> Model Class Initialized
INFO - 2020-09-21 11:37:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:37:42 --> Final output sent to browser
DEBUG - 2020-09-21 11:37:42 --> Total execution time: 0.0255
ERROR - 2020-09-21 11:38:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:38:20 --> Config Class Initialized
INFO - 2020-09-21 11:38:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:38:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:38:20 --> Utf8 Class Initialized
INFO - 2020-09-21 11:38:20 --> URI Class Initialized
INFO - 2020-09-21 11:38:20 --> Router Class Initialized
INFO - 2020-09-21 11:38:20 --> Output Class Initialized
INFO - 2020-09-21 11:38:20 --> Security Class Initialized
DEBUG - 2020-09-21 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:38:20 --> Input Class Initialized
INFO - 2020-09-21 11:38:20 --> Language Class Initialized
INFO - 2020-09-21 11:38:20 --> Loader Class Initialized
INFO - 2020-09-21 11:38:20 --> Helper loaded: url_helper
INFO - 2020-09-21 11:38:20 --> Database Driver Class Initialized
INFO - 2020-09-21 11:38:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:38:20 --> Email Class Initialized
INFO - 2020-09-21 11:38:20 --> Controller Class Initialized
DEBUG - 2020-09-21 11:38:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:38:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:38:20 --> Model Class Initialized
INFO - 2020-09-21 11:38:20 --> Model Class Initialized
INFO - 2020-09-21 11:38:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:38:20 --> Final output sent to browser
DEBUG - 2020-09-21 11:38:20 --> Total execution time: 0.0229
ERROR - 2020-09-21 11:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:38:56 --> Config Class Initialized
INFO - 2020-09-21 11:38:56 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:38:56 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:38:56 --> Utf8 Class Initialized
INFO - 2020-09-21 11:38:56 --> URI Class Initialized
INFO - 2020-09-21 11:38:56 --> Router Class Initialized
INFO - 2020-09-21 11:38:56 --> Output Class Initialized
INFO - 2020-09-21 11:38:56 --> Security Class Initialized
DEBUG - 2020-09-21 11:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:38:56 --> Input Class Initialized
INFO - 2020-09-21 11:38:56 --> Language Class Initialized
INFO - 2020-09-21 11:38:56 --> Loader Class Initialized
INFO - 2020-09-21 11:38:56 --> Helper loaded: url_helper
INFO - 2020-09-21 11:38:56 --> Database Driver Class Initialized
INFO - 2020-09-21 11:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:38:56 --> Email Class Initialized
INFO - 2020-09-21 11:38:56 --> Controller Class Initialized
DEBUG - 2020-09-21 11:38:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:38:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:38:56 --> Model Class Initialized
INFO - 2020-09-21 11:38:56 --> Model Class Initialized
INFO - 2020-09-21 11:38:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:38:56 --> Final output sent to browser
DEBUG - 2020-09-21 11:38:56 --> Total execution time: 0.0255
ERROR - 2020-09-21 11:56:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:56:27 --> Config Class Initialized
INFO - 2020-09-21 11:56:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:56:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:56:27 --> Utf8 Class Initialized
INFO - 2020-09-21 11:56:27 --> URI Class Initialized
INFO - 2020-09-21 11:56:27 --> Router Class Initialized
INFO - 2020-09-21 11:56:27 --> Output Class Initialized
INFO - 2020-09-21 11:56:27 --> Security Class Initialized
DEBUG - 2020-09-21 11:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:56:27 --> Input Class Initialized
INFO - 2020-09-21 11:56:27 --> Language Class Initialized
INFO - 2020-09-21 11:56:27 --> Loader Class Initialized
INFO - 2020-09-21 11:56:27 --> Helper loaded: url_helper
INFO - 2020-09-21 11:56:27 --> Database Driver Class Initialized
INFO - 2020-09-21 11:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:56:27 --> Email Class Initialized
INFO - 2020-09-21 11:56:27 --> Controller Class Initialized
DEBUG - 2020-09-21 11:56:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:56:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:56:27 --> Model Class Initialized
INFO - 2020-09-21 11:56:27 --> Model Class Initialized
INFO - 2020-09-21 11:56:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:56:27 --> Final output sent to browser
DEBUG - 2020-09-21 11:56:27 --> Total execution time: 0.0295
ERROR - 2020-09-21 11:57:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:57:06 --> Config Class Initialized
INFO - 2020-09-21 11:57:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:57:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:57:06 --> Utf8 Class Initialized
INFO - 2020-09-21 11:57:06 --> URI Class Initialized
INFO - 2020-09-21 11:57:06 --> Router Class Initialized
INFO - 2020-09-21 11:57:06 --> Output Class Initialized
INFO - 2020-09-21 11:57:06 --> Security Class Initialized
DEBUG - 2020-09-21 11:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:57:06 --> Input Class Initialized
INFO - 2020-09-21 11:57:06 --> Language Class Initialized
INFO - 2020-09-21 11:57:06 --> Loader Class Initialized
INFO - 2020-09-21 11:57:06 --> Helper loaded: url_helper
INFO - 2020-09-21 11:57:06 --> Database Driver Class Initialized
INFO - 2020-09-21 11:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:57:06 --> Email Class Initialized
INFO - 2020-09-21 11:57:06 --> Controller Class Initialized
DEBUG - 2020-09-21 11:57:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:57:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:57:06 --> Model Class Initialized
INFO - 2020-09-21 11:57:06 --> Model Class Initialized
INFO - 2020-09-21 11:57:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:57:06 --> Final output sent to browser
DEBUG - 2020-09-21 11:57:06 --> Total execution time: 0.0266
ERROR - 2020-09-21 11:57:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:57:11 --> Config Class Initialized
INFO - 2020-09-21 11:57:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:57:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:57:11 --> Utf8 Class Initialized
INFO - 2020-09-21 11:57:11 --> URI Class Initialized
INFO - 2020-09-21 11:57:11 --> Router Class Initialized
INFO - 2020-09-21 11:57:11 --> Output Class Initialized
INFO - 2020-09-21 11:57:11 --> Security Class Initialized
DEBUG - 2020-09-21 11:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:57:11 --> Input Class Initialized
INFO - 2020-09-21 11:57:11 --> Language Class Initialized
INFO - 2020-09-21 11:57:11 --> Loader Class Initialized
INFO - 2020-09-21 11:57:11 --> Helper loaded: url_helper
INFO - 2020-09-21 11:57:11 --> Database Driver Class Initialized
INFO - 2020-09-21 11:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:57:11 --> Email Class Initialized
INFO - 2020-09-21 11:57:11 --> Controller Class Initialized
DEBUG - 2020-09-21 11:57:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:57:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:57:11 --> Model Class Initialized
INFO - 2020-09-21 11:57:11 --> Model Class Initialized
INFO - 2020-09-21 11:57:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 11:57:11 --> Final output sent to browser
DEBUG - 2020-09-21 11:57:11 --> Total execution time: 0.0273
ERROR - 2020-09-21 11:57:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:57:16 --> Config Class Initialized
INFO - 2020-09-21 11:57:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:57:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:57:16 --> Utf8 Class Initialized
INFO - 2020-09-21 11:57:16 --> URI Class Initialized
INFO - 2020-09-21 11:57:16 --> Router Class Initialized
INFO - 2020-09-21 11:57:16 --> Output Class Initialized
INFO - 2020-09-21 11:57:16 --> Security Class Initialized
DEBUG - 2020-09-21 11:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:57:16 --> Input Class Initialized
INFO - 2020-09-21 11:57:16 --> Language Class Initialized
INFO - 2020-09-21 11:57:16 --> Loader Class Initialized
INFO - 2020-09-21 11:57:16 --> Helper loaded: url_helper
INFO - 2020-09-21 11:57:16 --> Database Driver Class Initialized
INFO - 2020-09-21 11:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:57:16 --> Email Class Initialized
INFO - 2020-09-21 11:57:16 --> Controller Class Initialized
DEBUG - 2020-09-21 11:57:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:57:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:57:16 --> Model Class Initialized
INFO - 2020-09-21 11:57:16 --> Model Class Initialized
INFO - 2020-09-21 11:57:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 11:57:16 --> Final output sent to browser
DEBUG - 2020-09-21 11:57:16 --> Total execution time: 0.0228
ERROR - 2020-09-21 11:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 11:57:39 --> Config Class Initialized
INFO - 2020-09-21 11:57:39 --> Hooks Class Initialized
DEBUG - 2020-09-21 11:57:39 --> UTF-8 Support Enabled
INFO - 2020-09-21 11:57:39 --> Utf8 Class Initialized
INFO - 2020-09-21 11:57:39 --> URI Class Initialized
INFO - 2020-09-21 11:57:39 --> Router Class Initialized
INFO - 2020-09-21 11:57:39 --> Output Class Initialized
INFO - 2020-09-21 11:57:39 --> Security Class Initialized
DEBUG - 2020-09-21 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 11:57:39 --> Input Class Initialized
INFO - 2020-09-21 11:57:39 --> Language Class Initialized
INFO - 2020-09-21 11:57:39 --> Loader Class Initialized
INFO - 2020-09-21 11:57:39 --> Helper loaded: url_helper
INFO - 2020-09-21 11:57:39 --> Database Driver Class Initialized
INFO - 2020-09-21 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 11:57:39 --> Email Class Initialized
INFO - 2020-09-21 11:57:39 --> Controller Class Initialized
DEBUG - 2020-09-21 11:57:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 11:57:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 11:57:39 --> Model Class Initialized
INFO - 2020-09-21 11:57:39 --> Model Class Initialized
INFO - 2020-09-21 11:57:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 11:57:39 --> Final output sent to browser
DEBUG - 2020-09-21 11:57:39 --> Total execution time: 0.0276
ERROR - 2020-09-21 12:00:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:00:15 --> Config Class Initialized
INFO - 2020-09-21 12:00:15 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:00:15 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:00:15 --> Utf8 Class Initialized
INFO - 2020-09-21 12:00:15 --> URI Class Initialized
INFO - 2020-09-21 12:00:15 --> Router Class Initialized
INFO - 2020-09-21 12:00:15 --> Output Class Initialized
INFO - 2020-09-21 12:00:15 --> Security Class Initialized
DEBUG - 2020-09-21 12:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:00:15 --> Input Class Initialized
INFO - 2020-09-21 12:00:15 --> Language Class Initialized
INFO - 2020-09-21 12:00:15 --> Loader Class Initialized
INFO - 2020-09-21 12:00:15 --> Helper loaded: url_helper
INFO - 2020-09-21 12:00:15 --> Database Driver Class Initialized
INFO - 2020-09-21 12:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:00:15 --> Email Class Initialized
INFO - 2020-09-21 12:00:15 --> Controller Class Initialized
DEBUG - 2020-09-21 12:00:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:00:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:00:15 --> Model Class Initialized
INFO - 2020-09-21 12:00:15 --> Model Class Initialized
INFO - 2020-09-21 12:00:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 12:00:15 --> Final output sent to browser
DEBUG - 2020-09-21 12:00:15 --> Total execution time: 0.0324
ERROR - 2020-09-21 12:00:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:00:27 --> Config Class Initialized
INFO - 2020-09-21 12:00:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:00:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:00:27 --> Utf8 Class Initialized
INFO - 2020-09-21 12:00:27 --> URI Class Initialized
INFO - 2020-09-21 12:00:27 --> Router Class Initialized
INFO - 2020-09-21 12:00:27 --> Output Class Initialized
INFO - 2020-09-21 12:00:27 --> Security Class Initialized
DEBUG - 2020-09-21 12:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:00:27 --> Input Class Initialized
INFO - 2020-09-21 12:00:27 --> Language Class Initialized
INFO - 2020-09-21 12:00:27 --> Loader Class Initialized
INFO - 2020-09-21 12:00:27 --> Helper loaded: url_helper
INFO - 2020-09-21 12:00:27 --> Database Driver Class Initialized
INFO - 2020-09-21 12:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:00:27 --> Email Class Initialized
INFO - 2020-09-21 12:00:27 --> Controller Class Initialized
DEBUG - 2020-09-21 12:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:00:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:00:27 --> Model Class Initialized
INFO - 2020-09-21 12:00:27 --> Model Class Initialized
INFO - 2020-09-21 12:00:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-21 12:00:27 --> Final output sent to browser
DEBUG - 2020-09-21 12:00:27 --> Total execution time: 0.0219
ERROR - 2020-09-21 12:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:00:32 --> Config Class Initialized
INFO - 2020-09-21 12:00:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:00:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:00:32 --> Utf8 Class Initialized
INFO - 2020-09-21 12:00:32 --> URI Class Initialized
INFO - 2020-09-21 12:00:32 --> Router Class Initialized
INFO - 2020-09-21 12:00:32 --> Output Class Initialized
INFO - 2020-09-21 12:00:32 --> Security Class Initialized
DEBUG - 2020-09-21 12:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:00:32 --> Input Class Initialized
INFO - 2020-09-21 12:00:32 --> Language Class Initialized
INFO - 2020-09-21 12:00:32 --> Loader Class Initialized
INFO - 2020-09-21 12:00:32 --> Helper loaded: url_helper
INFO - 2020-09-21 12:00:32 --> Database Driver Class Initialized
INFO - 2020-09-21 12:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:00:32 --> Email Class Initialized
INFO - 2020-09-21 12:00:32 --> Controller Class Initialized
DEBUG - 2020-09-21 12:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:00:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:00:32 --> Model Class Initialized
INFO - 2020-09-21 12:00:32 --> Model Class Initialized
INFO - 2020-09-21 12:00:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 12:00:32 --> Final output sent to browser
DEBUG - 2020-09-21 12:00:32 --> Total execution time: 0.0231
ERROR - 2020-09-21 12:01:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:01:55 --> Config Class Initialized
INFO - 2020-09-21 12:01:55 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:01:55 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:01:55 --> Utf8 Class Initialized
INFO - 2020-09-21 12:01:55 --> URI Class Initialized
INFO - 2020-09-21 12:01:55 --> Router Class Initialized
INFO - 2020-09-21 12:01:55 --> Output Class Initialized
INFO - 2020-09-21 12:01:55 --> Security Class Initialized
DEBUG - 2020-09-21 12:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:01:55 --> Input Class Initialized
INFO - 2020-09-21 12:01:55 --> Language Class Initialized
INFO - 2020-09-21 12:01:55 --> Loader Class Initialized
INFO - 2020-09-21 12:01:55 --> Helper loaded: url_helper
INFO - 2020-09-21 12:01:55 --> Database Driver Class Initialized
INFO - 2020-09-21 12:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:01:55 --> Email Class Initialized
INFO - 2020-09-21 12:01:55 --> Controller Class Initialized
DEBUG - 2020-09-21 12:01:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:01:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:01:55 --> Model Class Initialized
INFO - 2020-09-21 12:01:55 --> Model Class Initialized
INFO - 2020-09-21 12:01:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 12:01:55 --> Final output sent to browser
DEBUG - 2020-09-21 12:01:55 --> Total execution time: 0.0238
ERROR - 2020-09-21 12:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:03:37 --> Config Class Initialized
INFO - 2020-09-21 12:03:37 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:03:37 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:03:37 --> Utf8 Class Initialized
INFO - 2020-09-21 12:03:37 --> URI Class Initialized
INFO - 2020-09-21 12:03:37 --> Router Class Initialized
INFO - 2020-09-21 12:03:37 --> Output Class Initialized
INFO - 2020-09-21 12:03:37 --> Security Class Initialized
DEBUG - 2020-09-21 12:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:03:37 --> Input Class Initialized
INFO - 2020-09-21 12:03:37 --> Language Class Initialized
INFO - 2020-09-21 12:03:37 --> Loader Class Initialized
INFO - 2020-09-21 12:03:37 --> Helper loaded: url_helper
INFO - 2020-09-21 12:03:37 --> Database Driver Class Initialized
INFO - 2020-09-21 12:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:03:37 --> Email Class Initialized
INFO - 2020-09-21 12:03:37 --> Controller Class Initialized
DEBUG - 2020-09-21 12:03:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:03:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:03:37 --> Model Class Initialized
INFO - 2020-09-21 12:03:37 --> Model Class Initialized
INFO - 2020-09-21 12:03:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 12:03:37 --> Final output sent to browser
DEBUG - 2020-09-21 12:03:37 --> Total execution time: 0.0273
ERROR - 2020-09-21 12:05:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:00 --> Config Class Initialized
INFO - 2020-09-21 12:05:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:00 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:00 --> URI Class Initialized
DEBUG - 2020-09-21 12:05:00 --> No URI present. Default controller set.
INFO - 2020-09-21 12:05:00 --> Router Class Initialized
INFO - 2020-09-21 12:05:00 --> Output Class Initialized
INFO - 2020-09-21 12:05:00 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:00 --> Input Class Initialized
INFO - 2020-09-21 12:05:00 --> Language Class Initialized
INFO - 2020-09-21 12:05:00 --> Loader Class Initialized
INFO - 2020-09-21 12:05:00 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:00 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:00 --> Email Class Initialized
INFO - 2020-09-21 12:05:00 --> Controller Class Initialized
INFO - 2020-09-21 12:05:00 --> Model Class Initialized
INFO - 2020-09-21 12:05:00 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:05:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 12:05:00 --> Final output sent to browser
DEBUG - 2020-09-21 12:05:00 --> Total execution time: 0.0171
ERROR - 2020-09-21 12:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:13 --> Config Class Initialized
INFO - 2020-09-21 12:05:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:13 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:13 --> URI Class Initialized
INFO - 2020-09-21 12:05:13 --> Router Class Initialized
INFO - 2020-09-21 12:05:13 --> Output Class Initialized
INFO - 2020-09-21 12:05:13 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:13 --> Input Class Initialized
INFO - 2020-09-21 12:05:13 --> Language Class Initialized
INFO - 2020-09-21 12:05:13 --> Loader Class Initialized
INFO - 2020-09-21 12:05:13 --> Helper loaded: url_helper
ERROR - 2020-09-21 12:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:13 --> Config Class Initialized
INFO - 2020-09-21 12:05:13 --> Hooks Class Initialized
INFO - 2020-09-21 12:05:13 --> Database Driver Class Initialized
DEBUG - 2020-09-21 12:05:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:13 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:13 --> URI Class Initialized
INFO - 2020-09-21 12:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:13 --> Router Class Initialized
INFO - 2020-09-21 12:05:13 --> Output Class Initialized
INFO - 2020-09-21 12:05:13 --> Email Class Initialized
INFO - 2020-09-21 12:05:13 --> Controller Class Initialized
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:05:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:05:13 --> Security Class Initialized
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:13 --> Input Class Initialized
INFO - 2020-09-21 12:05:13 --> Language Class Initialized
INFO - 2020-09-21 12:05:13 --> Final output sent to browser
DEBUG - 2020-09-21 12:05:13 --> Total execution time: 0.0266
INFO - 2020-09-21 12:05:13 --> Loader Class Initialized
INFO - 2020-09-21 12:05:13 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:13 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:13 --> Email Class Initialized
INFO - 2020-09-21 12:05:13 --> Controller Class Initialized
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:13 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 12:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:13 --> Config Class Initialized
INFO - 2020-09-21 12:05:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:13 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:13 --> URI Class Initialized
INFO - 2020-09-21 12:05:13 --> Router Class Initialized
INFO - 2020-09-21 12:05:13 --> Output Class Initialized
INFO - 2020-09-21 12:05:13 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:13 --> Input Class Initialized
INFO - 2020-09-21 12:05:13 --> Language Class Initialized
INFO - 2020-09-21 12:05:13 --> Loader Class Initialized
INFO - 2020-09-21 12:05:13 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:13 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:13 --> Email Class Initialized
INFO - 2020-09-21 12:05:13 --> Controller Class Initialized
DEBUG - 2020-09-21 12:05:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:05:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
INFO - 2020-09-21 12:05:13 --> Model Class Initialized
INFO - 2020-09-21 12:05:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 12:05:13 --> Final output sent to browser
DEBUG - 2020-09-21 12:05:13 --> Total execution time: 0.0246
ERROR - 2020-09-21 12:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:27 --> Config Class Initialized
INFO - 2020-09-21 12:05:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:27 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:27 --> URI Class Initialized
DEBUG - 2020-09-21 12:05:27 --> No URI present. Default controller set.
INFO - 2020-09-21 12:05:27 --> Router Class Initialized
INFO - 2020-09-21 12:05:27 --> Output Class Initialized
INFO - 2020-09-21 12:05:27 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:27 --> Input Class Initialized
INFO - 2020-09-21 12:05:27 --> Language Class Initialized
INFO - 2020-09-21 12:05:27 --> Loader Class Initialized
INFO - 2020-09-21 12:05:27 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:27 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:27 --> Email Class Initialized
INFO - 2020-09-21 12:05:27 --> Controller Class Initialized
INFO - 2020-09-21 12:05:27 --> Model Class Initialized
INFO - 2020-09-21 12:05:27 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:05:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 12:05:27 --> Final output sent to browser
DEBUG - 2020-09-21 12:05:27 --> Total execution time: 0.0228
ERROR - 2020-09-21 12:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:41 --> Config Class Initialized
INFO - 2020-09-21 12:05:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:41 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:41 --> URI Class Initialized
INFO - 2020-09-21 12:05:41 --> Router Class Initialized
INFO - 2020-09-21 12:05:41 --> Output Class Initialized
INFO - 2020-09-21 12:05:41 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:41 --> Input Class Initialized
INFO - 2020-09-21 12:05:41 --> Language Class Initialized
INFO - 2020-09-21 12:05:41 --> Loader Class Initialized
INFO - 2020-09-21 12:05:41 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:41 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:41 --> Email Class Initialized
INFO - 2020-09-21 12:05:41 --> Controller Class Initialized
INFO - 2020-09-21 12:05:41 --> Model Class Initialized
INFO - 2020-09-21 12:05:41 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:05:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:05:41 --> Model Class Initialized
INFO - 2020-09-21 12:05:41 --> Final output sent to browser
DEBUG - 2020-09-21 12:05:41 --> Total execution time: 0.0259
ERROR - 2020-09-21 12:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:41 --> Config Class Initialized
INFO - 2020-09-21 12:05:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:41 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:41 --> URI Class Initialized
INFO - 2020-09-21 12:05:41 --> Router Class Initialized
INFO - 2020-09-21 12:05:41 --> Output Class Initialized
INFO - 2020-09-21 12:05:41 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:41 --> Input Class Initialized
INFO - 2020-09-21 12:05:41 --> Language Class Initialized
INFO - 2020-09-21 12:05:41 --> Loader Class Initialized
INFO - 2020-09-21 12:05:41 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:41 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:41 --> Email Class Initialized
INFO - 2020-09-21 12:05:41 --> Controller Class Initialized
INFO - 2020-09-21 12:05:41 --> Model Class Initialized
INFO - 2020-09-21 12:05:41 --> Model Class Initialized
DEBUG - 2020-09-21 12:05:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 12:05:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:05:42 --> Config Class Initialized
INFO - 2020-09-21 12:05:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:05:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:05:42 --> Utf8 Class Initialized
INFO - 2020-09-21 12:05:42 --> URI Class Initialized
INFO - 2020-09-21 12:05:42 --> Router Class Initialized
INFO - 2020-09-21 12:05:42 --> Output Class Initialized
INFO - 2020-09-21 12:05:42 --> Security Class Initialized
DEBUG - 2020-09-21 12:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:05:42 --> Input Class Initialized
INFO - 2020-09-21 12:05:42 --> Language Class Initialized
INFO - 2020-09-21 12:05:42 --> Loader Class Initialized
INFO - 2020-09-21 12:05:42 --> Helper loaded: url_helper
INFO - 2020-09-21 12:05:42 --> Database Driver Class Initialized
INFO - 2020-09-21 12:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:05:42 --> Email Class Initialized
INFO - 2020-09-21 12:05:42 --> Controller Class Initialized
DEBUG - 2020-09-21 12:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:05:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:05:42 --> Model Class Initialized
INFO - 2020-09-21 12:05:42 --> Model Class Initialized
INFO - 2020-09-21 12:05:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 12:05:42 --> Final output sent to browser
DEBUG - 2020-09-21 12:05:42 --> Total execution time: 0.0252
ERROR - 2020-09-21 12:06:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:06:16 --> Config Class Initialized
INFO - 2020-09-21 12:06:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:06:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:06:16 --> Utf8 Class Initialized
INFO - 2020-09-21 12:06:16 --> URI Class Initialized
INFO - 2020-09-21 12:06:16 --> Router Class Initialized
INFO - 2020-09-21 12:06:16 --> Output Class Initialized
INFO - 2020-09-21 12:06:16 --> Security Class Initialized
DEBUG - 2020-09-21 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:06:16 --> Input Class Initialized
INFO - 2020-09-21 12:06:16 --> Language Class Initialized
INFO - 2020-09-21 12:06:16 --> Loader Class Initialized
INFO - 2020-09-21 12:06:16 --> Helper loaded: url_helper
INFO - 2020-09-21 12:06:16 --> Database Driver Class Initialized
INFO - 2020-09-21 12:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:06:16 --> Email Class Initialized
INFO - 2020-09-21 12:06:16 --> Controller Class Initialized
DEBUG - 2020-09-21 12:06:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:06:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:06:16 --> Model Class Initialized
INFO - 2020-09-21 12:06:16 --> Model Class Initialized
INFO - 2020-09-21 12:06:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-21 12:06:16 --> Final output sent to browser
DEBUG - 2020-09-21 12:06:16 --> Total execution time: 0.0251
ERROR - 2020-09-21 12:06:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:06:47 --> Config Class Initialized
INFO - 2020-09-21 12:06:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:06:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:06:47 --> Utf8 Class Initialized
INFO - 2020-09-21 12:06:47 --> URI Class Initialized
INFO - 2020-09-21 12:06:47 --> Router Class Initialized
INFO - 2020-09-21 12:06:47 --> Output Class Initialized
INFO - 2020-09-21 12:06:47 --> Security Class Initialized
DEBUG - 2020-09-21 12:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:06:47 --> Input Class Initialized
INFO - 2020-09-21 12:06:47 --> Language Class Initialized
INFO - 2020-09-21 12:06:47 --> Loader Class Initialized
INFO - 2020-09-21 12:06:47 --> Helper loaded: url_helper
INFO - 2020-09-21 12:06:47 --> Database Driver Class Initialized
INFO - 2020-09-21 12:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:06:47 --> Email Class Initialized
INFO - 2020-09-21 12:06:47 --> Controller Class Initialized
DEBUG - 2020-09-21 12:06:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:06:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:06:47 --> Model Class Initialized
INFO - 2020-09-21 12:06:47 --> Model Class Initialized
INFO - 2020-09-21 12:06:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-21 12:06:47 --> Final output sent to browser
DEBUG - 2020-09-21 12:06:47 --> Total execution time: 0.0265
ERROR - 2020-09-21 12:06:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:06:53 --> Config Class Initialized
INFO - 2020-09-21 12:06:53 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:06:53 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:06:53 --> Utf8 Class Initialized
INFO - 2020-09-21 12:06:53 --> URI Class Initialized
DEBUG - 2020-09-21 12:06:53 --> No URI present. Default controller set.
INFO - 2020-09-21 12:06:53 --> Router Class Initialized
INFO - 2020-09-21 12:06:53 --> Output Class Initialized
INFO - 2020-09-21 12:06:53 --> Security Class Initialized
DEBUG - 2020-09-21 12:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:06:53 --> Input Class Initialized
INFO - 2020-09-21 12:06:53 --> Language Class Initialized
INFO - 2020-09-21 12:06:53 --> Loader Class Initialized
INFO - 2020-09-21 12:06:53 --> Helper loaded: url_helper
INFO - 2020-09-21 12:06:53 --> Database Driver Class Initialized
INFO - 2020-09-21 12:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:06:53 --> Email Class Initialized
INFO - 2020-09-21 12:06:53 --> Controller Class Initialized
INFO - 2020-09-21 12:06:53 --> Model Class Initialized
INFO - 2020-09-21 12:06:53 --> Model Class Initialized
DEBUG - 2020-09-21 12:06:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:06:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 12:06:53 --> Final output sent to browser
DEBUG - 2020-09-21 12:06:53 --> Total execution time: 0.0208
ERROR - 2020-09-21 12:06:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:06:59 --> Config Class Initialized
INFO - 2020-09-21 12:06:59 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:06:59 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:06:59 --> Utf8 Class Initialized
INFO - 2020-09-21 12:06:59 --> URI Class Initialized
INFO - 2020-09-21 12:06:59 --> Router Class Initialized
INFO - 2020-09-21 12:06:59 --> Output Class Initialized
INFO - 2020-09-21 12:06:59 --> Security Class Initialized
DEBUG - 2020-09-21 12:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:06:59 --> Input Class Initialized
INFO - 2020-09-21 12:06:59 --> Language Class Initialized
INFO - 2020-09-21 12:06:59 --> Loader Class Initialized
INFO - 2020-09-21 12:06:59 --> Helper loaded: url_helper
INFO - 2020-09-21 12:06:59 --> Database Driver Class Initialized
INFO - 2020-09-21 12:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:06:59 --> Email Class Initialized
INFO - 2020-09-21 12:06:59 --> Controller Class Initialized
INFO - 2020-09-21 12:06:59 --> Model Class Initialized
INFO - 2020-09-21 12:06:59 --> Model Class Initialized
DEBUG - 2020-09-21 12:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:06:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:06:59 --> Model Class Initialized
INFO - 2020-09-21 12:06:59 --> Final output sent to browser
DEBUG - 2020-09-21 12:06:59 --> Total execution time: 0.0213
ERROR - 2020-09-21 12:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:07:00 --> Config Class Initialized
INFO - 2020-09-21 12:07:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:07:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:07:00 --> Utf8 Class Initialized
INFO - 2020-09-21 12:07:00 --> URI Class Initialized
INFO - 2020-09-21 12:07:00 --> Router Class Initialized
INFO - 2020-09-21 12:07:00 --> Output Class Initialized
INFO - 2020-09-21 12:07:00 --> Security Class Initialized
DEBUG - 2020-09-21 12:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:07:00 --> Input Class Initialized
INFO - 2020-09-21 12:07:00 --> Language Class Initialized
INFO - 2020-09-21 12:07:00 --> Loader Class Initialized
INFO - 2020-09-21 12:07:00 --> Helper loaded: url_helper
INFO - 2020-09-21 12:07:00 --> Database Driver Class Initialized
INFO - 2020-09-21 12:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:07:00 --> Email Class Initialized
INFO - 2020-09-21 12:07:00 --> Controller Class Initialized
INFO - 2020-09-21 12:07:00 --> Model Class Initialized
INFO - 2020-09-21 12:07:00 --> Model Class Initialized
DEBUG - 2020-09-21 12:07:00 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 12:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:07:00 --> Config Class Initialized
INFO - 2020-09-21 12:07:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:07:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:07:00 --> Utf8 Class Initialized
INFO - 2020-09-21 12:07:00 --> URI Class Initialized
INFO - 2020-09-21 12:07:00 --> Router Class Initialized
INFO - 2020-09-21 12:07:00 --> Output Class Initialized
INFO - 2020-09-21 12:07:00 --> Security Class Initialized
DEBUG - 2020-09-21 12:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:07:00 --> Input Class Initialized
INFO - 2020-09-21 12:07:00 --> Language Class Initialized
INFO - 2020-09-21 12:07:00 --> Loader Class Initialized
INFO - 2020-09-21 12:07:00 --> Helper loaded: url_helper
INFO - 2020-09-21 12:07:00 --> Database Driver Class Initialized
INFO - 2020-09-21 12:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:07:00 --> Email Class Initialized
INFO - 2020-09-21 12:07:00 --> Controller Class Initialized
DEBUG - 2020-09-21 12:07:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:07:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:07:00 --> Model Class Initialized
INFO - 2020-09-21 12:07:00 --> Model Class Initialized
INFO - 2020-09-21 12:07:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 12:07:00 --> Final output sent to browser
DEBUG - 2020-09-21 12:07:00 --> Total execution time: 0.0232
ERROR - 2020-09-21 12:07:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:07:05 --> Config Class Initialized
INFO - 2020-09-21 12:07:05 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:07:05 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:07:05 --> Utf8 Class Initialized
INFO - 2020-09-21 12:07:05 --> URI Class Initialized
INFO - 2020-09-21 12:07:05 --> Router Class Initialized
INFO - 2020-09-21 12:07:05 --> Output Class Initialized
INFO - 2020-09-21 12:07:05 --> Security Class Initialized
DEBUG - 2020-09-21 12:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:07:05 --> Input Class Initialized
INFO - 2020-09-21 12:07:05 --> Language Class Initialized
INFO - 2020-09-21 12:07:05 --> Loader Class Initialized
INFO - 2020-09-21 12:07:05 --> Helper loaded: url_helper
INFO - 2020-09-21 12:07:05 --> Database Driver Class Initialized
INFO - 2020-09-21 12:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:07:05 --> Email Class Initialized
INFO - 2020-09-21 12:07:05 --> Controller Class Initialized
DEBUG - 2020-09-21 12:07:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:07:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:07:05 --> Model Class Initialized
INFO - 2020-09-21 12:07:05 --> Model Class Initialized
INFO - 2020-09-21 12:07:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 12:07:05 --> Final output sent to browser
DEBUG - 2020-09-21 12:07:05 --> Total execution time: 0.0259
ERROR - 2020-09-21 12:09:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:09:35 --> Config Class Initialized
INFO - 2020-09-21 12:09:35 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:09:35 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:09:35 --> Utf8 Class Initialized
INFO - 2020-09-21 12:09:35 --> URI Class Initialized
DEBUG - 2020-09-21 12:09:35 --> No URI present. Default controller set.
INFO - 2020-09-21 12:09:35 --> Router Class Initialized
INFO - 2020-09-21 12:09:35 --> Output Class Initialized
INFO - 2020-09-21 12:09:35 --> Security Class Initialized
DEBUG - 2020-09-21 12:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:09:35 --> Input Class Initialized
INFO - 2020-09-21 12:09:35 --> Language Class Initialized
INFO - 2020-09-21 12:09:35 --> Loader Class Initialized
INFO - 2020-09-21 12:09:35 --> Helper loaded: url_helper
INFO - 2020-09-21 12:09:35 --> Database Driver Class Initialized
INFO - 2020-09-21 12:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:09:35 --> Email Class Initialized
INFO - 2020-09-21 12:09:35 --> Controller Class Initialized
INFO - 2020-09-21 12:09:35 --> Model Class Initialized
INFO - 2020-09-21 12:09:35 --> Model Class Initialized
DEBUG - 2020-09-21 12:09:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:09:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 12:09:35 --> Final output sent to browser
DEBUG - 2020-09-21 12:09:35 --> Total execution time: 0.0190
ERROR - 2020-09-21 12:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:09:58 --> Config Class Initialized
INFO - 2020-09-21 12:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:09:58 --> Utf8 Class Initialized
INFO - 2020-09-21 12:09:58 --> URI Class Initialized
INFO - 2020-09-21 12:09:58 --> Router Class Initialized
INFO - 2020-09-21 12:09:58 --> Output Class Initialized
INFO - 2020-09-21 12:09:58 --> Security Class Initialized
DEBUG - 2020-09-21 12:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:09:58 --> Input Class Initialized
INFO - 2020-09-21 12:09:58 --> Language Class Initialized
INFO - 2020-09-21 12:09:58 --> Loader Class Initialized
INFO - 2020-09-21 12:09:58 --> Helper loaded: url_helper
INFO - 2020-09-21 12:09:58 --> Database Driver Class Initialized
INFO - 2020-09-21 12:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:09:58 --> Email Class Initialized
INFO - 2020-09-21 12:09:58 --> Controller Class Initialized
INFO - 2020-09-21 12:09:58 --> Model Class Initialized
INFO - 2020-09-21 12:09:58 --> Model Class Initialized
DEBUG - 2020-09-21 12:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:09:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:09:58 --> Model Class Initialized
INFO - 2020-09-21 12:09:58 --> Final output sent to browser
DEBUG - 2020-09-21 12:09:58 --> Total execution time: 0.0224
ERROR - 2020-09-21 12:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:09:58 --> Config Class Initialized
INFO - 2020-09-21 12:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:09:58 --> Utf8 Class Initialized
INFO - 2020-09-21 12:09:58 --> URI Class Initialized
INFO - 2020-09-21 12:09:58 --> Router Class Initialized
INFO - 2020-09-21 12:09:58 --> Output Class Initialized
INFO - 2020-09-21 12:09:58 --> Security Class Initialized
DEBUG - 2020-09-21 12:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:09:58 --> Input Class Initialized
INFO - 2020-09-21 12:09:58 --> Language Class Initialized
INFO - 2020-09-21 12:09:58 --> Loader Class Initialized
INFO - 2020-09-21 12:09:58 --> Helper loaded: url_helper
INFO - 2020-09-21 12:09:58 --> Database Driver Class Initialized
INFO - 2020-09-21 12:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:09:58 --> Email Class Initialized
INFO - 2020-09-21 12:09:58 --> Controller Class Initialized
INFO - 2020-09-21 12:09:58 --> Model Class Initialized
INFO - 2020-09-21 12:09:58 --> Model Class Initialized
DEBUG - 2020-09-21 12:09:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 12:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:09:58 --> Config Class Initialized
INFO - 2020-09-21 12:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:09:58 --> Utf8 Class Initialized
INFO - 2020-09-21 12:09:58 --> URI Class Initialized
INFO - 2020-09-21 12:09:58 --> Router Class Initialized
INFO - 2020-09-21 12:09:58 --> Output Class Initialized
INFO - 2020-09-21 12:09:58 --> Security Class Initialized
DEBUG - 2020-09-21 12:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:09:58 --> Input Class Initialized
INFO - 2020-09-21 12:09:58 --> Language Class Initialized
INFO - 2020-09-21 12:09:58 --> Loader Class Initialized
INFO - 2020-09-21 12:09:58 --> Helper loaded: url_helper
INFO - 2020-09-21 12:09:58 --> Database Driver Class Initialized
INFO - 2020-09-21 12:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:09:58 --> Email Class Initialized
INFO - 2020-09-21 12:09:58 --> Controller Class Initialized
DEBUG - 2020-09-21 12:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 12:09:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 12:09:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-21 12:09:58 --> Final output sent to browser
DEBUG - 2020-09-21 12:09:58 --> Total execution time: 0.0210
ERROR - 2020-09-21 12:10:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:10:10 --> Config Class Initialized
INFO - 2020-09-21 12:10:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:10:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:10:10 --> Utf8 Class Initialized
INFO - 2020-09-21 12:10:10 --> URI Class Initialized
INFO - 2020-09-21 12:10:10 --> Router Class Initialized
INFO - 2020-09-21 12:10:10 --> Output Class Initialized
INFO - 2020-09-21 12:10:10 --> Security Class Initialized
DEBUG - 2020-09-21 12:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:10:10 --> Input Class Initialized
INFO - 2020-09-21 12:10:10 --> Language Class Initialized
INFO - 2020-09-21 12:10:10 --> Loader Class Initialized
INFO - 2020-09-21 12:10:10 --> Helper loaded: url_helper
INFO - 2020-09-21 12:10:10 --> Database Driver Class Initialized
INFO - 2020-09-21 12:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:10:10 --> Email Class Initialized
INFO - 2020-09-21 12:10:10 --> Controller Class Initialized
INFO - 2020-09-21 12:10:10 --> Model Class Initialized
INFO - 2020-09-21 12:10:10 --> Model Class Initialized
INFO - 2020-09-21 12:10:10 --> Model Class Initialized
INFO - 2020-09-21 12:10:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 12:10:10 --> Final output sent to browser
DEBUG - 2020-09-21 12:10:10 --> Total execution time: 0.0411
ERROR - 2020-09-21 12:10:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:10:10 --> Config Class Initialized
INFO - 2020-09-21 12:10:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:10:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:10:10 --> Utf8 Class Initialized
INFO - 2020-09-21 12:10:10 --> URI Class Initialized
INFO - 2020-09-21 12:10:10 --> Router Class Initialized
INFO - 2020-09-21 12:10:10 --> Output Class Initialized
INFO - 2020-09-21 12:10:10 --> Security Class Initialized
DEBUG - 2020-09-21 12:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:10:10 --> Input Class Initialized
INFO - 2020-09-21 12:10:10 --> Language Class Initialized
INFO - 2020-09-21 12:10:10 --> Loader Class Initialized
INFO - 2020-09-21 12:10:10 --> Helper loaded: url_helper
INFO - 2020-09-21 12:10:10 --> Database Driver Class Initialized
INFO - 2020-09-21 12:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:10:10 --> Email Class Initialized
INFO - 2020-09-21 12:10:10 --> Controller Class Initialized
INFO - 2020-09-21 12:10:10 --> Model Class Initialized
INFO - 2020-09-21 12:10:10 --> Model Class Initialized
INFO - 2020-09-21 12:10:10 --> Final output sent to browser
DEBUG - 2020-09-21 12:10:10 --> Total execution time: 0.0406
ERROR - 2020-09-21 12:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 12:10:16 --> Config Class Initialized
INFO - 2020-09-21 12:10:16 --> Hooks Class Initialized
DEBUG - 2020-09-21 12:10:16 --> UTF-8 Support Enabled
INFO - 2020-09-21 12:10:16 --> Utf8 Class Initialized
INFO - 2020-09-21 12:10:16 --> URI Class Initialized
INFO - 2020-09-21 12:10:16 --> Router Class Initialized
INFO - 2020-09-21 12:10:16 --> Output Class Initialized
INFO - 2020-09-21 12:10:16 --> Security Class Initialized
DEBUG - 2020-09-21 12:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 12:10:16 --> Input Class Initialized
INFO - 2020-09-21 12:10:16 --> Language Class Initialized
INFO - 2020-09-21 12:10:16 --> Loader Class Initialized
INFO - 2020-09-21 12:10:16 --> Helper loaded: url_helper
INFO - 2020-09-21 12:10:16 --> Database Driver Class Initialized
INFO - 2020-09-21 12:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 12:10:16 --> Email Class Initialized
INFO - 2020-09-21 12:10:16 --> Controller Class Initialized
INFO - 2020-09-21 12:10:16 --> Model Class Initialized
INFO - 2020-09-21 12:10:16 --> Model Class Initialized
INFO - 2020-09-21 12:10:16 --> Model Class Initialized
INFO - 2020-09-21 12:10:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 12:10:16 --> Final output sent to browser
DEBUG - 2020-09-21 12:10:16 --> Total execution time: 0.0563
ERROR - 2020-09-21 14:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:35:40 --> Config Class Initialized
INFO - 2020-09-21 14:35:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:35:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:35:40 --> Utf8 Class Initialized
INFO - 2020-09-21 14:35:40 --> URI Class Initialized
DEBUG - 2020-09-21 14:35:40 --> No URI present. Default controller set.
INFO - 2020-09-21 14:35:40 --> Router Class Initialized
INFO - 2020-09-21 14:35:40 --> Output Class Initialized
INFO - 2020-09-21 14:35:40 --> Security Class Initialized
DEBUG - 2020-09-21 14:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:35:40 --> Input Class Initialized
INFO - 2020-09-21 14:35:40 --> Language Class Initialized
INFO - 2020-09-21 14:35:40 --> Loader Class Initialized
INFO - 2020-09-21 14:35:40 --> Helper loaded: url_helper
INFO - 2020-09-21 14:35:40 --> Database Driver Class Initialized
INFO - 2020-09-21 14:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:35:40 --> Email Class Initialized
INFO - 2020-09-21 14:35:40 --> Controller Class Initialized
INFO - 2020-09-21 14:35:40 --> Model Class Initialized
INFO - 2020-09-21 14:35:40 --> Model Class Initialized
DEBUG - 2020-09-21 14:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:35:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 14:35:40 --> Final output sent to browser
DEBUG - 2020-09-21 14:35:40 --> Total execution time: 0.0233
ERROR - 2020-09-21 14:35:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:35:54 --> Config Class Initialized
INFO - 2020-09-21 14:35:54 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:35:54 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:35:54 --> Utf8 Class Initialized
INFO - 2020-09-21 14:35:54 --> URI Class Initialized
DEBUG - 2020-09-21 14:35:54 --> No URI present. Default controller set.
INFO - 2020-09-21 14:35:54 --> Router Class Initialized
INFO - 2020-09-21 14:35:54 --> Output Class Initialized
INFO - 2020-09-21 14:35:54 --> Security Class Initialized
DEBUG - 2020-09-21 14:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:35:54 --> Input Class Initialized
INFO - 2020-09-21 14:35:54 --> Language Class Initialized
INFO - 2020-09-21 14:35:54 --> Loader Class Initialized
INFO - 2020-09-21 14:35:54 --> Helper loaded: url_helper
INFO - 2020-09-21 14:35:54 --> Database Driver Class Initialized
INFO - 2020-09-21 14:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:35:54 --> Email Class Initialized
INFO - 2020-09-21 14:35:54 --> Controller Class Initialized
INFO - 2020-09-21 14:35:54 --> Model Class Initialized
INFO - 2020-09-21 14:35:54 --> Model Class Initialized
DEBUG - 2020-09-21 14:35:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:35:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 14:35:54 --> Final output sent to browser
DEBUG - 2020-09-21 14:35:54 --> Total execution time: 0.0212
ERROR - 2020-09-21 14:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:36:20 --> Config Class Initialized
INFO - 2020-09-21 14:36:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:36:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:36:20 --> Utf8 Class Initialized
INFO - 2020-09-21 14:36:20 --> URI Class Initialized
INFO - 2020-09-21 14:36:20 --> Router Class Initialized
INFO - 2020-09-21 14:36:20 --> Output Class Initialized
INFO - 2020-09-21 14:36:20 --> Security Class Initialized
DEBUG - 2020-09-21 14:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:36:20 --> Input Class Initialized
INFO - 2020-09-21 14:36:20 --> Language Class Initialized
INFO - 2020-09-21 14:36:20 --> Loader Class Initialized
INFO - 2020-09-21 14:36:20 --> Helper loaded: url_helper
INFO - 2020-09-21 14:36:20 --> Database Driver Class Initialized
INFO - 2020-09-21 14:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:36:20 --> Email Class Initialized
INFO - 2020-09-21 14:36:20 --> Controller Class Initialized
INFO - 2020-09-21 14:36:20 --> Model Class Initialized
INFO - 2020-09-21 14:36:20 --> Model Class Initialized
DEBUG - 2020-09-21 14:36:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:36:20 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-21 14:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:36:20 --> Config Class Initialized
INFO - 2020-09-21 14:36:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:36:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:36:20 --> Utf8 Class Initialized
INFO - 2020-09-21 14:36:20 --> URI Class Initialized
INFO - 2020-09-21 14:36:20 --> Router Class Initialized
INFO - 2020-09-21 14:36:20 --> Output Class Initialized
INFO - 2020-09-21 14:36:20 --> Security Class Initialized
DEBUG - 2020-09-21 14:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:36:20 --> Input Class Initialized
INFO - 2020-09-21 14:36:20 --> Language Class Initialized
INFO - 2020-09-21 14:36:20 --> Loader Class Initialized
INFO - 2020-09-21 14:36:20 --> Helper loaded: url_helper
INFO - 2020-09-21 14:36:20 --> Database Driver Class Initialized
INFO - 2020-09-21 14:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:36:20 --> Email Class Initialized
INFO - 2020-09-21 14:36:20 --> Controller Class Initialized
INFO - 2020-09-21 14:36:20 --> Model Class Initialized
INFO - 2020-09-21 14:36:20 --> Model Class Initialized
DEBUG - 2020-09-21 14:36:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 14:36:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:36:20 --> Config Class Initialized
INFO - 2020-09-21 14:36:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:36:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:36:20 --> Utf8 Class Initialized
INFO - 2020-09-21 14:36:20 --> URI Class Initialized
DEBUG - 2020-09-21 14:36:20 --> No URI present. Default controller set.
INFO - 2020-09-21 14:36:20 --> Router Class Initialized
INFO - 2020-09-21 14:36:20 --> Output Class Initialized
INFO - 2020-09-21 14:36:20 --> Security Class Initialized
DEBUG - 2020-09-21 14:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:36:20 --> Input Class Initialized
INFO - 2020-09-21 14:36:20 --> Language Class Initialized
INFO - 2020-09-21 14:36:20 --> Loader Class Initialized
INFO - 2020-09-21 14:36:20 --> Helper loaded: url_helper
INFO - 2020-09-21 14:36:20 --> Database Driver Class Initialized
INFO - 2020-09-21 14:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:36:20 --> Email Class Initialized
INFO - 2020-09-21 14:36:20 --> Controller Class Initialized
INFO - 2020-09-21 14:36:20 --> Model Class Initialized
INFO - 2020-09-21 14:36:20 --> Model Class Initialized
DEBUG - 2020-09-21 14:36:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:36:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 14:36:20 --> Final output sent to browser
DEBUG - 2020-09-21 14:36:20 --> Total execution time: 0.0208
ERROR - 2020-09-21 14:36:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:36:21 --> Config Class Initialized
INFO - 2020-09-21 14:36:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:36:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:36:21 --> Utf8 Class Initialized
INFO - 2020-09-21 14:36:21 --> URI Class Initialized
INFO - 2020-09-21 14:36:21 --> Router Class Initialized
INFO - 2020-09-21 14:36:21 --> Output Class Initialized
INFO - 2020-09-21 14:36:21 --> Security Class Initialized
DEBUG - 2020-09-21 14:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:36:21 --> Input Class Initialized
INFO - 2020-09-21 14:36:21 --> Language Class Initialized
INFO - 2020-09-21 14:36:21 --> Loader Class Initialized
INFO - 2020-09-21 14:36:21 --> Helper loaded: url_helper
INFO - 2020-09-21 14:36:21 --> Database Driver Class Initialized
INFO - 2020-09-21 14:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:36:21 --> Email Class Initialized
INFO - 2020-09-21 14:36:21 --> Controller Class Initialized
DEBUG - 2020-09-21 14:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:36:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:36:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-21 14:36:21 --> Final output sent to browser
DEBUG - 2020-09-21 14:36:21 --> Total execution time: 0.0200
ERROR - 2020-09-21 14:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:36:42 --> Config Class Initialized
INFO - 2020-09-21 14:36:42 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:36:42 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:36:42 --> Utf8 Class Initialized
INFO - 2020-09-21 14:36:42 --> URI Class Initialized
INFO - 2020-09-21 14:36:42 --> Router Class Initialized
INFO - 2020-09-21 14:36:42 --> Output Class Initialized
INFO - 2020-09-21 14:36:42 --> Security Class Initialized
DEBUG - 2020-09-21 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:36:42 --> Input Class Initialized
INFO - 2020-09-21 14:36:42 --> Language Class Initialized
INFO - 2020-09-21 14:36:42 --> Loader Class Initialized
INFO - 2020-09-21 14:36:42 --> Helper loaded: url_helper
INFO - 2020-09-21 14:36:42 --> Database Driver Class Initialized
INFO - 2020-09-21 14:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:36:42 --> Email Class Initialized
INFO - 2020-09-21 14:36:42 --> Controller Class Initialized
DEBUG - 2020-09-21 14:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:36:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:36:42 --> Model Class Initialized
INFO - 2020-09-21 14:36:42 --> Model Class Initialized
INFO - 2020-09-21 14:36:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-21 14:36:42 --> Final output sent to browser
DEBUG - 2020-09-21 14:36:42 --> Total execution time: 0.0309
ERROR - 2020-09-21 14:36:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:36:50 --> Config Class Initialized
INFO - 2020-09-21 14:36:50 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:36:50 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:36:50 --> Utf8 Class Initialized
INFO - 2020-09-21 14:36:50 --> URI Class Initialized
INFO - 2020-09-21 14:36:50 --> Router Class Initialized
INFO - 2020-09-21 14:36:50 --> Output Class Initialized
INFO - 2020-09-21 14:36:50 --> Security Class Initialized
DEBUG - 2020-09-21 14:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:36:50 --> Input Class Initialized
INFO - 2020-09-21 14:36:50 --> Language Class Initialized
INFO - 2020-09-21 14:36:50 --> Loader Class Initialized
INFO - 2020-09-21 14:36:50 --> Helper loaded: url_helper
INFO - 2020-09-21 14:36:50 --> Database Driver Class Initialized
INFO - 2020-09-21 14:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:36:50 --> Email Class Initialized
INFO - 2020-09-21 14:36:50 --> Controller Class Initialized
DEBUG - 2020-09-21 14:36:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:36:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:36:50 --> Model Class Initialized
INFO - 2020-09-21 14:36:50 --> Model Class Initialized
INFO - 2020-09-21 14:36:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:36:50 --> Final output sent to browser
DEBUG - 2020-09-21 14:36:50 --> Total execution time: 0.0256
ERROR - 2020-09-21 14:37:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:37:12 --> Config Class Initialized
INFO - 2020-09-21 14:37:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:37:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:37:12 --> Utf8 Class Initialized
INFO - 2020-09-21 14:37:12 --> URI Class Initialized
INFO - 2020-09-21 14:37:12 --> Router Class Initialized
INFO - 2020-09-21 14:37:12 --> Output Class Initialized
INFO - 2020-09-21 14:37:12 --> Security Class Initialized
DEBUG - 2020-09-21 14:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:37:12 --> Input Class Initialized
INFO - 2020-09-21 14:37:12 --> Language Class Initialized
INFO - 2020-09-21 14:37:12 --> Loader Class Initialized
INFO - 2020-09-21 14:37:12 --> Helper loaded: url_helper
INFO - 2020-09-21 14:37:12 --> Database Driver Class Initialized
INFO - 2020-09-21 14:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:37:12 --> Email Class Initialized
INFO - 2020-09-21 14:37:12 --> Controller Class Initialized
INFO - 2020-09-21 14:37:12 --> Model Class Initialized
INFO - 2020-09-21 14:37:12 --> Model Class Initialized
INFO - 2020-09-21 14:37:12 --> Model Class Initialized
INFO - 2020-09-21 14:37:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:37:12 --> Final output sent to browser
DEBUG - 2020-09-21 14:37:12 --> Total execution time: 0.0461
ERROR - 2020-09-21 14:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:37:13 --> Config Class Initialized
INFO - 2020-09-21 14:37:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:37:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:37:13 --> Utf8 Class Initialized
INFO - 2020-09-21 14:37:13 --> URI Class Initialized
INFO - 2020-09-21 14:37:13 --> Router Class Initialized
INFO - 2020-09-21 14:37:13 --> Output Class Initialized
INFO - 2020-09-21 14:37:13 --> Security Class Initialized
DEBUG - 2020-09-21 14:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:37:13 --> Input Class Initialized
INFO - 2020-09-21 14:37:13 --> Language Class Initialized
INFO - 2020-09-21 14:37:13 --> Loader Class Initialized
INFO - 2020-09-21 14:37:13 --> Helper loaded: url_helper
INFO - 2020-09-21 14:37:13 --> Database Driver Class Initialized
INFO - 2020-09-21 14:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:37:13 --> Email Class Initialized
INFO - 2020-09-21 14:37:13 --> Controller Class Initialized
INFO - 2020-09-21 14:37:13 --> Model Class Initialized
INFO - 2020-09-21 14:37:13 --> Model Class Initialized
INFO - 2020-09-21 14:37:13 --> Final output sent to browser
DEBUG - 2020-09-21 14:37:13 --> Total execution time: 0.0448
ERROR - 2020-09-21 14:37:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:37:28 --> Config Class Initialized
INFO - 2020-09-21 14:37:28 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:37:28 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:37:28 --> Utf8 Class Initialized
INFO - 2020-09-21 14:37:28 --> URI Class Initialized
INFO - 2020-09-21 14:37:28 --> Router Class Initialized
INFO - 2020-09-21 14:37:28 --> Output Class Initialized
INFO - 2020-09-21 14:37:28 --> Security Class Initialized
DEBUG - 2020-09-21 14:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:37:28 --> Input Class Initialized
INFO - 2020-09-21 14:37:28 --> Language Class Initialized
INFO - 2020-09-21 14:37:28 --> Loader Class Initialized
INFO - 2020-09-21 14:37:28 --> Helper loaded: url_helper
INFO - 2020-09-21 14:37:28 --> Database Driver Class Initialized
INFO - 2020-09-21 14:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:37:28 --> Email Class Initialized
INFO - 2020-09-21 14:37:28 --> Controller Class Initialized
INFO - 2020-09-21 14:37:28 --> Model Class Initialized
INFO - 2020-09-21 14:37:28 --> Model Class Initialized
INFO - 2020-09-21 14:37:28 --> Model Class Initialized
INFO - 2020-09-21 14:37:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 14:37:28 --> Final output sent to browser
DEBUG - 2020-09-21 14:37:28 --> Total execution time: 0.0368
ERROR - 2020-09-21 14:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:37:44 --> Config Class Initialized
INFO - 2020-09-21 14:37:44 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:37:44 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:37:44 --> Utf8 Class Initialized
INFO - 2020-09-21 14:37:44 --> URI Class Initialized
INFO - 2020-09-21 14:37:44 --> Router Class Initialized
INFO - 2020-09-21 14:37:44 --> Output Class Initialized
INFO - 2020-09-21 14:37:44 --> Security Class Initialized
DEBUG - 2020-09-21 14:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:37:44 --> Input Class Initialized
INFO - 2020-09-21 14:37:44 --> Language Class Initialized
INFO - 2020-09-21 14:37:44 --> Loader Class Initialized
INFO - 2020-09-21 14:37:44 --> Helper loaded: url_helper
INFO - 2020-09-21 14:37:44 --> Database Driver Class Initialized
INFO - 2020-09-21 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:37:44 --> Email Class Initialized
INFO - 2020-09-21 14:37:44 --> Controller Class Initialized
INFO - 2020-09-21 14:37:44 --> Model Class Initialized
INFO - 2020-09-21 14:37:44 --> Model Class Initialized
INFO - 2020-09-21 14:37:44 --> Model Class Initialized
INFO - 2020-09-21 14:37:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:37:44 --> Final output sent to browser
DEBUG - 2020-09-21 14:37:44 --> Total execution time: 0.0474
ERROR - 2020-09-21 14:37:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:37:44 --> Config Class Initialized
INFO - 2020-09-21 14:37:44 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:37:44 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:37:44 --> Utf8 Class Initialized
INFO - 2020-09-21 14:37:44 --> URI Class Initialized
INFO - 2020-09-21 14:37:44 --> Router Class Initialized
INFO - 2020-09-21 14:37:44 --> Output Class Initialized
INFO - 2020-09-21 14:37:44 --> Security Class Initialized
DEBUG - 2020-09-21 14:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:37:44 --> Input Class Initialized
INFO - 2020-09-21 14:37:44 --> Language Class Initialized
INFO - 2020-09-21 14:37:44 --> Loader Class Initialized
INFO - 2020-09-21 14:37:44 --> Helper loaded: url_helper
INFO - 2020-09-21 14:37:44 --> Database Driver Class Initialized
INFO - 2020-09-21 14:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:37:44 --> Email Class Initialized
INFO - 2020-09-21 14:37:44 --> Controller Class Initialized
INFO - 2020-09-21 14:37:44 --> Model Class Initialized
INFO - 2020-09-21 14:37:44 --> Model Class Initialized
INFO - 2020-09-21 14:37:44 --> Final output sent to browser
DEBUG - 2020-09-21 14:37:44 --> Total execution time: 0.0482
ERROR - 2020-09-21 14:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:37:52 --> Config Class Initialized
INFO - 2020-09-21 14:37:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:37:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:37:52 --> Utf8 Class Initialized
INFO - 2020-09-21 14:37:52 --> URI Class Initialized
INFO - 2020-09-21 14:37:52 --> Router Class Initialized
INFO - 2020-09-21 14:37:52 --> Output Class Initialized
INFO - 2020-09-21 14:37:52 --> Security Class Initialized
DEBUG - 2020-09-21 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:37:52 --> Input Class Initialized
INFO - 2020-09-21 14:37:52 --> Language Class Initialized
INFO - 2020-09-21 14:37:52 --> Loader Class Initialized
INFO - 2020-09-21 14:37:52 --> Helper loaded: url_helper
INFO - 2020-09-21 14:37:52 --> Database Driver Class Initialized
INFO - 2020-09-21 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:37:52 --> Email Class Initialized
INFO - 2020-09-21 14:37:52 --> Controller Class Initialized
DEBUG - 2020-09-21 14:37:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:37:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:37:52 --> Model Class Initialized
INFO - 2020-09-21 14:37:52 --> Model Class Initialized
INFO - 2020-09-21 14:37:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:37:52 --> Final output sent to browser
DEBUG - 2020-09-21 14:37:52 --> Total execution time: 0.0271
ERROR - 2020-09-21 14:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:38:03 --> Config Class Initialized
INFO - 2020-09-21 14:38:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:38:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:38:03 --> Utf8 Class Initialized
INFO - 2020-09-21 14:38:03 --> URI Class Initialized
INFO - 2020-09-21 14:38:03 --> Router Class Initialized
INFO - 2020-09-21 14:38:03 --> Output Class Initialized
INFO - 2020-09-21 14:38:03 --> Security Class Initialized
DEBUG - 2020-09-21 14:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:38:03 --> Input Class Initialized
INFO - 2020-09-21 14:38:03 --> Language Class Initialized
INFO - 2020-09-21 14:38:03 --> Loader Class Initialized
INFO - 2020-09-21 14:38:03 --> Helper loaded: url_helper
INFO - 2020-09-21 14:38:03 --> Database Driver Class Initialized
INFO - 2020-09-21 14:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:38:03 --> Email Class Initialized
INFO - 2020-09-21 14:38:03 --> Controller Class Initialized
INFO - 2020-09-21 14:38:03 --> Model Class Initialized
INFO - 2020-09-21 14:38:03 --> Model Class Initialized
INFO - 2020-09-21 14:38:03 --> Model Class Initialized
INFO - 2020-09-21 14:38:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:38:03 --> Final output sent to browser
DEBUG - 2020-09-21 14:38:03 --> Total execution time: 0.0460
ERROR - 2020-09-21 14:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:38:03 --> Config Class Initialized
INFO - 2020-09-21 14:38:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:38:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:38:03 --> Utf8 Class Initialized
INFO - 2020-09-21 14:38:03 --> URI Class Initialized
INFO - 2020-09-21 14:38:03 --> Router Class Initialized
INFO - 2020-09-21 14:38:03 --> Output Class Initialized
INFO - 2020-09-21 14:38:03 --> Security Class Initialized
DEBUG - 2020-09-21 14:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:38:03 --> Input Class Initialized
INFO - 2020-09-21 14:38:03 --> Language Class Initialized
INFO - 2020-09-21 14:38:03 --> Loader Class Initialized
INFO - 2020-09-21 14:38:03 --> Helper loaded: url_helper
INFO - 2020-09-21 14:38:03 --> Database Driver Class Initialized
INFO - 2020-09-21 14:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:38:03 --> Email Class Initialized
INFO - 2020-09-21 14:38:03 --> Controller Class Initialized
INFO - 2020-09-21 14:38:03 --> Model Class Initialized
INFO - 2020-09-21 14:38:03 --> Model Class Initialized
INFO - 2020-09-21 14:38:04 --> Final output sent to browser
DEBUG - 2020-09-21 14:38:04 --> Total execution time: 0.0431
ERROR - 2020-09-21 14:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:38:07 --> Config Class Initialized
INFO - 2020-09-21 14:38:07 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:38:07 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:38:07 --> Utf8 Class Initialized
INFO - 2020-09-21 14:38:07 --> URI Class Initialized
INFO - 2020-09-21 14:38:07 --> Router Class Initialized
INFO - 2020-09-21 14:38:07 --> Output Class Initialized
INFO - 2020-09-21 14:38:07 --> Security Class Initialized
DEBUG - 2020-09-21 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:38:07 --> Input Class Initialized
INFO - 2020-09-21 14:38:07 --> Language Class Initialized
INFO - 2020-09-21 14:38:07 --> Loader Class Initialized
INFO - 2020-09-21 14:38:07 --> Helper loaded: url_helper
INFO - 2020-09-21 14:38:07 --> Database Driver Class Initialized
INFO - 2020-09-21 14:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:38:07 --> Email Class Initialized
INFO - 2020-09-21 14:38:07 --> Controller Class Initialized
INFO - 2020-09-21 14:38:07 --> Model Class Initialized
INFO - 2020-09-21 14:38:07 --> Model Class Initialized
INFO - 2020-09-21 14:38:07 --> Model Class Initialized
INFO - 2020-09-21 14:38:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 14:38:07 --> Final output sent to browser
DEBUG - 2020-09-21 14:38:07 --> Total execution time: 0.0476
ERROR - 2020-09-21 14:38:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:38:11 --> Config Class Initialized
INFO - 2020-09-21 14:38:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:38:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:38:11 --> Utf8 Class Initialized
INFO - 2020-09-21 14:38:11 --> URI Class Initialized
INFO - 2020-09-21 14:38:11 --> Router Class Initialized
INFO - 2020-09-21 14:38:11 --> Output Class Initialized
INFO - 2020-09-21 14:38:11 --> Security Class Initialized
DEBUG - 2020-09-21 14:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:38:11 --> Input Class Initialized
INFO - 2020-09-21 14:38:11 --> Language Class Initialized
INFO - 2020-09-21 14:38:11 --> Loader Class Initialized
INFO - 2020-09-21 14:38:11 --> Helper loaded: url_helper
INFO - 2020-09-21 14:38:11 --> Database Driver Class Initialized
INFO - 2020-09-21 14:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:38:11 --> Email Class Initialized
INFO - 2020-09-21 14:38:11 --> Controller Class Initialized
INFO - 2020-09-21 14:38:11 --> Model Class Initialized
INFO - 2020-09-21 14:38:11 --> Model Class Initialized
INFO - 2020-09-21 14:38:11 --> Model Class Initialized
INFO - 2020-09-21 14:38:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:38:11 --> Final output sent to browser
DEBUG - 2020-09-21 14:38:11 --> Total execution time: 0.2221
ERROR - 2020-09-21 14:38:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:38:11 --> Config Class Initialized
INFO - 2020-09-21 14:38:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:38:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:38:11 --> Utf8 Class Initialized
INFO - 2020-09-21 14:38:11 --> URI Class Initialized
INFO - 2020-09-21 14:38:11 --> Router Class Initialized
INFO - 2020-09-21 14:38:11 --> Output Class Initialized
INFO - 2020-09-21 14:38:11 --> Security Class Initialized
DEBUG - 2020-09-21 14:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:38:11 --> Input Class Initialized
INFO - 2020-09-21 14:38:11 --> Language Class Initialized
INFO - 2020-09-21 14:38:11 --> Loader Class Initialized
INFO - 2020-09-21 14:38:11 --> Helper loaded: url_helper
INFO - 2020-09-21 14:38:11 --> Database Driver Class Initialized
INFO - 2020-09-21 14:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:38:11 --> Email Class Initialized
INFO - 2020-09-21 14:38:11 --> Controller Class Initialized
INFO - 2020-09-21 14:38:11 --> Model Class Initialized
INFO - 2020-09-21 14:38:11 --> Model Class Initialized
INFO - 2020-09-21 14:38:11 --> Final output sent to browser
DEBUG - 2020-09-21 14:38:11 --> Total execution time: 0.0445
ERROR - 2020-09-21 14:38:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:38:17 --> Config Class Initialized
INFO - 2020-09-21 14:38:17 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:38:17 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:38:17 --> Utf8 Class Initialized
INFO - 2020-09-21 14:38:17 --> URI Class Initialized
INFO - 2020-09-21 14:38:17 --> Router Class Initialized
INFO - 2020-09-21 14:38:17 --> Output Class Initialized
INFO - 2020-09-21 14:38:17 --> Security Class Initialized
DEBUG - 2020-09-21 14:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:38:17 --> Input Class Initialized
INFO - 2020-09-21 14:38:17 --> Language Class Initialized
INFO - 2020-09-21 14:38:17 --> Loader Class Initialized
INFO - 2020-09-21 14:38:17 --> Helper loaded: url_helper
INFO - 2020-09-21 14:38:17 --> Database Driver Class Initialized
INFO - 2020-09-21 14:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:38:17 --> Email Class Initialized
INFO - 2020-09-21 14:38:17 --> Controller Class Initialized
DEBUG - 2020-09-21 14:38:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:38:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:38:17 --> Model Class Initialized
INFO - 2020-09-21 14:38:17 --> Model Class Initialized
INFO - 2020-09-21 14:38:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:38:17 --> Final output sent to browser
DEBUG - 2020-09-21 14:38:17 --> Total execution time: 0.0266
ERROR - 2020-09-21 14:41:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:41:32 --> Config Class Initialized
INFO - 2020-09-21 14:41:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:41:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:41:32 --> Utf8 Class Initialized
INFO - 2020-09-21 14:41:32 --> URI Class Initialized
INFO - 2020-09-21 14:41:32 --> Router Class Initialized
INFO - 2020-09-21 14:41:32 --> Output Class Initialized
INFO - 2020-09-21 14:41:32 --> Security Class Initialized
DEBUG - 2020-09-21 14:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:41:32 --> Input Class Initialized
INFO - 2020-09-21 14:41:32 --> Language Class Initialized
INFO - 2020-09-21 14:41:32 --> Loader Class Initialized
INFO - 2020-09-21 14:41:32 --> Helper loaded: url_helper
INFO - 2020-09-21 14:41:32 --> Database Driver Class Initialized
INFO - 2020-09-21 14:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:41:32 --> Email Class Initialized
INFO - 2020-09-21 14:41:32 --> Controller Class Initialized
DEBUG - 2020-09-21 14:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:41:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:41:32 --> Model Class Initialized
INFO - 2020-09-21 14:41:32 --> Model Class Initialized
INFO - 2020-09-21 14:41:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:41:32 --> Final output sent to browser
DEBUG - 2020-09-21 14:41:32 --> Total execution time: 0.0221
ERROR - 2020-09-21 14:42:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:42:10 --> Config Class Initialized
INFO - 2020-09-21 14:42:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:42:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:42:10 --> Utf8 Class Initialized
INFO - 2020-09-21 14:42:10 --> URI Class Initialized
INFO - 2020-09-21 14:42:10 --> Router Class Initialized
INFO - 2020-09-21 14:42:10 --> Output Class Initialized
INFO - 2020-09-21 14:42:10 --> Security Class Initialized
DEBUG - 2020-09-21 14:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:42:10 --> Input Class Initialized
INFO - 2020-09-21 14:42:10 --> Language Class Initialized
INFO - 2020-09-21 14:42:10 --> Loader Class Initialized
INFO - 2020-09-21 14:42:10 --> Helper loaded: url_helper
INFO - 2020-09-21 14:42:10 --> Database Driver Class Initialized
INFO - 2020-09-21 14:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:42:10 --> Email Class Initialized
INFO - 2020-09-21 14:42:10 --> Controller Class Initialized
INFO - 2020-09-21 14:42:10 --> Model Class Initialized
INFO - 2020-09-21 14:42:10 --> Model Class Initialized
INFO - 2020-09-21 14:42:10 --> Model Class Initialized
INFO - 2020-09-21 14:42:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:42:10 --> Final output sent to browser
DEBUG - 2020-09-21 14:42:10 --> Total execution time: 0.0413
ERROR - 2020-09-21 14:42:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:42:11 --> Config Class Initialized
INFO - 2020-09-21 14:42:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:42:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:42:11 --> Utf8 Class Initialized
INFO - 2020-09-21 14:42:11 --> URI Class Initialized
INFO - 2020-09-21 14:42:11 --> Router Class Initialized
INFO - 2020-09-21 14:42:11 --> Output Class Initialized
INFO - 2020-09-21 14:42:11 --> Security Class Initialized
DEBUG - 2020-09-21 14:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:42:11 --> Input Class Initialized
INFO - 2020-09-21 14:42:11 --> Language Class Initialized
INFO - 2020-09-21 14:42:11 --> Loader Class Initialized
INFO - 2020-09-21 14:42:11 --> Helper loaded: url_helper
INFO - 2020-09-21 14:42:11 --> Database Driver Class Initialized
INFO - 2020-09-21 14:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:42:11 --> Email Class Initialized
INFO - 2020-09-21 14:42:11 --> Controller Class Initialized
INFO - 2020-09-21 14:42:11 --> Model Class Initialized
INFO - 2020-09-21 14:42:11 --> Model Class Initialized
INFO - 2020-09-21 14:42:11 --> Final output sent to browser
DEBUG - 2020-09-21 14:42:11 --> Total execution time: 0.0449
ERROR - 2020-09-21 14:42:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:42:12 --> Config Class Initialized
INFO - 2020-09-21 14:42:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:42:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:42:12 --> Utf8 Class Initialized
INFO - 2020-09-21 14:42:12 --> URI Class Initialized
INFO - 2020-09-21 14:42:12 --> Router Class Initialized
INFO - 2020-09-21 14:42:12 --> Output Class Initialized
INFO - 2020-09-21 14:42:12 --> Security Class Initialized
DEBUG - 2020-09-21 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:42:12 --> Input Class Initialized
INFO - 2020-09-21 14:42:12 --> Language Class Initialized
INFO - 2020-09-21 14:42:12 --> Loader Class Initialized
INFO - 2020-09-21 14:42:12 --> Helper loaded: url_helper
INFO - 2020-09-21 14:42:12 --> Database Driver Class Initialized
INFO - 2020-09-21 14:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:42:12 --> Email Class Initialized
INFO - 2020-09-21 14:42:12 --> Controller Class Initialized
DEBUG - 2020-09-21 14:42:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:42:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:42:12 --> Model Class Initialized
INFO - 2020-09-21 14:42:12 --> Model Class Initialized
INFO - 2020-09-21 14:42:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:42:12 --> Final output sent to browser
DEBUG - 2020-09-21 14:42:12 --> Total execution time: 0.0238
ERROR - 2020-09-21 14:42:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:42:18 --> Config Class Initialized
INFO - 2020-09-21 14:42:18 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:42:18 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:42:18 --> Utf8 Class Initialized
INFO - 2020-09-21 14:42:18 --> URI Class Initialized
INFO - 2020-09-21 14:42:18 --> Router Class Initialized
INFO - 2020-09-21 14:42:18 --> Output Class Initialized
INFO - 2020-09-21 14:42:18 --> Security Class Initialized
DEBUG - 2020-09-21 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:42:18 --> Input Class Initialized
INFO - 2020-09-21 14:42:18 --> Language Class Initialized
INFO - 2020-09-21 14:42:18 --> Loader Class Initialized
INFO - 2020-09-21 14:42:18 --> Helper loaded: url_helper
INFO - 2020-09-21 14:42:18 --> Database Driver Class Initialized
INFO - 2020-09-21 14:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:42:18 --> Email Class Initialized
INFO - 2020-09-21 14:42:18 --> Controller Class Initialized
INFO - 2020-09-21 14:42:18 --> Model Class Initialized
INFO - 2020-09-21 14:42:18 --> Model Class Initialized
INFO - 2020-09-21 14:42:18 --> Model Class Initialized
INFO - 2020-09-21 14:42:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:42:18 --> Final output sent to browser
DEBUG - 2020-09-21 14:42:18 --> Total execution time: 0.0462
ERROR - 2020-09-21 14:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:42:21 --> Config Class Initialized
INFO - 2020-09-21 14:42:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:42:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:42:21 --> Utf8 Class Initialized
INFO - 2020-09-21 14:42:21 --> URI Class Initialized
INFO - 2020-09-21 14:42:21 --> Router Class Initialized
INFO - 2020-09-21 14:42:21 --> Output Class Initialized
INFO - 2020-09-21 14:42:21 --> Security Class Initialized
DEBUG - 2020-09-21 14:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:42:21 --> Input Class Initialized
INFO - 2020-09-21 14:42:21 --> Language Class Initialized
INFO - 2020-09-21 14:42:21 --> Loader Class Initialized
INFO - 2020-09-21 14:42:21 --> Helper loaded: url_helper
INFO - 2020-09-21 14:42:21 --> Database Driver Class Initialized
INFO - 2020-09-21 14:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:42:21 --> Email Class Initialized
INFO - 2020-09-21 14:42:21 --> Controller Class Initialized
INFO - 2020-09-21 14:42:21 --> Model Class Initialized
INFO - 2020-09-21 14:42:21 --> Model Class Initialized
INFO - 2020-09-21 14:42:21 --> Model Class Initialized
INFO - 2020-09-21 14:42:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:42:21 --> Final output sent to browser
DEBUG - 2020-09-21 14:42:21 --> Total execution time: 0.0441
ERROR - 2020-09-21 14:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:42:21 --> Config Class Initialized
INFO - 2020-09-21 14:42:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:42:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:42:21 --> Utf8 Class Initialized
INFO - 2020-09-21 14:42:21 --> URI Class Initialized
INFO - 2020-09-21 14:42:21 --> Router Class Initialized
INFO - 2020-09-21 14:42:21 --> Output Class Initialized
INFO - 2020-09-21 14:42:21 --> Security Class Initialized
DEBUG - 2020-09-21 14:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:42:21 --> Input Class Initialized
INFO - 2020-09-21 14:42:21 --> Language Class Initialized
INFO - 2020-09-21 14:42:21 --> Loader Class Initialized
INFO - 2020-09-21 14:42:21 --> Helper loaded: url_helper
INFO - 2020-09-21 14:42:21 --> Database Driver Class Initialized
INFO - 2020-09-21 14:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:42:21 --> Email Class Initialized
INFO - 2020-09-21 14:42:21 --> Controller Class Initialized
INFO - 2020-09-21 14:42:21 --> Model Class Initialized
INFO - 2020-09-21 14:42:21 --> Model Class Initialized
INFO - 2020-09-21 14:42:21 --> Final output sent to browser
DEBUG - 2020-09-21 14:42:21 --> Total execution time: 0.0446
ERROR - 2020-09-21 14:43:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:43:57 --> Config Class Initialized
INFO - 2020-09-21 14:43:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:43:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:43:57 --> Utf8 Class Initialized
INFO - 2020-09-21 14:43:57 --> URI Class Initialized
INFO - 2020-09-21 14:43:57 --> Router Class Initialized
INFO - 2020-09-21 14:43:57 --> Output Class Initialized
INFO - 2020-09-21 14:43:57 --> Security Class Initialized
DEBUG - 2020-09-21 14:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:43:57 --> Input Class Initialized
INFO - 2020-09-21 14:43:57 --> Language Class Initialized
INFO - 2020-09-21 14:43:57 --> Loader Class Initialized
INFO - 2020-09-21 14:43:57 --> Helper loaded: url_helper
INFO - 2020-09-21 14:43:57 --> Database Driver Class Initialized
INFO - 2020-09-21 14:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:43:57 --> Email Class Initialized
INFO - 2020-09-21 14:43:57 --> Controller Class Initialized
INFO - 2020-09-21 14:43:57 --> Model Class Initialized
INFO - 2020-09-21 14:43:57 --> Model Class Initialized
INFO - 2020-09-21 14:43:57 --> Model Class Initialized
INFO - 2020-09-21 14:43:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 14:43:57 --> Final output sent to browser
DEBUG - 2020-09-21 14:43:57 --> Total execution time: 0.0495
ERROR - 2020-09-21 14:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:00 --> Config Class Initialized
INFO - 2020-09-21 14:44:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:00 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:00 --> URI Class Initialized
INFO - 2020-09-21 14:44:00 --> Router Class Initialized
INFO - 2020-09-21 14:44:00 --> Output Class Initialized
INFO - 2020-09-21 14:44:00 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:00 --> Input Class Initialized
INFO - 2020-09-21 14:44:00 --> Language Class Initialized
INFO - 2020-09-21 14:44:00 --> Loader Class Initialized
INFO - 2020-09-21 14:44:00 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:00 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:00 --> Email Class Initialized
INFO - 2020-09-21 14:44:00 --> Controller Class Initialized
INFO - 2020-09-21 14:44:00 --> Model Class Initialized
INFO - 2020-09-21 14:44:00 --> Model Class Initialized
INFO - 2020-09-21 14:44:00 --> Model Class Initialized
INFO - 2020-09-21 14:44:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:44:00 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:00 --> Total execution time: 0.0448
ERROR - 2020-09-21 14:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:00 --> Config Class Initialized
INFO - 2020-09-21 14:44:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:00 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:00 --> URI Class Initialized
INFO - 2020-09-21 14:44:00 --> Router Class Initialized
INFO - 2020-09-21 14:44:00 --> Output Class Initialized
INFO - 2020-09-21 14:44:00 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:00 --> Input Class Initialized
INFO - 2020-09-21 14:44:00 --> Language Class Initialized
INFO - 2020-09-21 14:44:00 --> Loader Class Initialized
INFO - 2020-09-21 14:44:00 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:00 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:00 --> Email Class Initialized
INFO - 2020-09-21 14:44:00 --> Controller Class Initialized
INFO - 2020-09-21 14:44:00 --> Model Class Initialized
INFO - 2020-09-21 14:44:00 --> Model Class Initialized
INFO - 2020-09-21 14:44:00 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:00 --> Total execution time: 0.0443
ERROR - 2020-09-21 14:44:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:07 --> Config Class Initialized
INFO - 2020-09-21 14:44:07 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:07 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:07 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:07 --> URI Class Initialized
INFO - 2020-09-21 14:44:07 --> Router Class Initialized
INFO - 2020-09-21 14:44:07 --> Output Class Initialized
INFO - 2020-09-21 14:44:07 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:07 --> Input Class Initialized
INFO - 2020-09-21 14:44:07 --> Language Class Initialized
INFO - 2020-09-21 14:44:07 --> Loader Class Initialized
INFO - 2020-09-21 14:44:07 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:07 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:07 --> Email Class Initialized
INFO - 2020-09-21 14:44:07 --> Controller Class Initialized
INFO - 2020-09-21 14:44:07 --> Model Class Initialized
INFO - 2020-09-21 14:44:07 --> Model Class Initialized
INFO - 2020-09-21 14:44:07 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:07 --> Total execution time: 0.2054
ERROR - 2020-09-21 14:44:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:08 --> Config Class Initialized
INFO - 2020-09-21 14:44:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:08 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:08 --> URI Class Initialized
INFO - 2020-09-21 14:44:08 --> Router Class Initialized
INFO - 2020-09-21 14:44:08 --> Output Class Initialized
INFO - 2020-09-21 14:44:08 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:08 --> Input Class Initialized
INFO - 2020-09-21 14:44:08 --> Language Class Initialized
INFO - 2020-09-21 14:44:08 --> Loader Class Initialized
INFO - 2020-09-21 14:44:08 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:08 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:08 --> Email Class Initialized
INFO - 2020-09-21 14:44:08 --> Controller Class Initialized
INFO - 2020-09-21 14:44:08 --> Model Class Initialized
INFO - 2020-09-21 14:44:08 --> Model Class Initialized
INFO - 2020-09-21 14:44:08 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:08 --> Total execution time: 0.0440
ERROR - 2020-09-21 14:44:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:26 --> Config Class Initialized
INFO - 2020-09-21 14:44:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:26 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:26 --> URI Class Initialized
INFO - 2020-09-21 14:44:26 --> Router Class Initialized
INFO - 2020-09-21 14:44:26 --> Output Class Initialized
INFO - 2020-09-21 14:44:26 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:26 --> Input Class Initialized
INFO - 2020-09-21 14:44:26 --> Language Class Initialized
INFO - 2020-09-21 14:44:26 --> Loader Class Initialized
INFO - 2020-09-21 14:44:26 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:26 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:26 --> Email Class Initialized
INFO - 2020-09-21 14:44:26 --> Controller Class Initialized
INFO - 2020-09-21 14:44:26 --> Model Class Initialized
INFO - 2020-09-21 14:44:26 --> Model Class Initialized
INFO - 2020-09-21 14:44:26 --> Model Class Initialized
INFO - 2020-09-21 14:44:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 14:44:26 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:26 --> Total execution time: 0.0530
ERROR - 2020-09-21 14:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:32 --> Config Class Initialized
INFO - 2020-09-21 14:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:32 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:32 --> URI Class Initialized
INFO - 2020-09-21 14:44:32 --> Router Class Initialized
INFO - 2020-09-21 14:44:32 --> Output Class Initialized
INFO - 2020-09-21 14:44:32 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:32 --> Input Class Initialized
INFO - 2020-09-21 14:44:32 --> Language Class Initialized
INFO - 2020-09-21 14:44:32 --> Loader Class Initialized
INFO - 2020-09-21 14:44:32 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:32 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:32 --> Email Class Initialized
INFO - 2020-09-21 14:44:32 --> Controller Class Initialized
INFO - 2020-09-21 14:44:32 --> Model Class Initialized
INFO - 2020-09-21 14:44:32 --> Model Class Initialized
INFO - 2020-09-21 14:44:32 --> Model Class Initialized
INFO - 2020-09-21 14:44:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:44:32 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:32 --> Total execution time: 0.1073
ERROR - 2020-09-21 14:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:32 --> Config Class Initialized
INFO - 2020-09-21 14:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:32 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:32 --> URI Class Initialized
INFO - 2020-09-21 14:44:32 --> Router Class Initialized
INFO - 2020-09-21 14:44:32 --> Output Class Initialized
INFO - 2020-09-21 14:44:32 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:32 --> Input Class Initialized
INFO - 2020-09-21 14:44:32 --> Language Class Initialized
INFO - 2020-09-21 14:44:32 --> Loader Class Initialized
INFO - 2020-09-21 14:44:32 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:32 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:32 --> Email Class Initialized
INFO - 2020-09-21 14:44:32 --> Controller Class Initialized
INFO - 2020-09-21 14:44:32 --> Model Class Initialized
INFO - 2020-09-21 14:44:32 --> Model Class Initialized
INFO - 2020-09-21 14:44:32 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:32 --> Total execution time: 0.0427
ERROR - 2020-09-21 14:44:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:44:35 --> Config Class Initialized
INFO - 2020-09-21 14:44:35 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:44:35 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:44:35 --> Utf8 Class Initialized
INFO - 2020-09-21 14:44:35 --> URI Class Initialized
INFO - 2020-09-21 14:44:35 --> Router Class Initialized
INFO - 2020-09-21 14:44:35 --> Output Class Initialized
INFO - 2020-09-21 14:44:35 --> Security Class Initialized
DEBUG - 2020-09-21 14:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:44:35 --> Input Class Initialized
INFO - 2020-09-21 14:44:35 --> Language Class Initialized
INFO - 2020-09-21 14:44:35 --> Loader Class Initialized
INFO - 2020-09-21 14:44:35 --> Helper loaded: url_helper
INFO - 2020-09-21 14:44:35 --> Database Driver Class Initialized
INFO - 2020-09-21 14:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:44:35 --> Email Class Initialized
INFO - 2020-09-21 14:44:35 --> Controller Class Initialized
DEBUG - 2020-09-21 14:44:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:44:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:44:35 --> Model Class Initialized
INFO - 2020-09-21 14:44:35 --> Model Class Initialized
INFO - 2020-09-21 14:44:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:44:35 --> Final output sent to browser
DEBUG - 2020-09-21 14:44:35 --> Total execution time: 0.0227
ERROR - 2020-09-21 14:45:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:45:50 --> Config Class Initialized
INFO - 2020-09-21 14:45:50 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:45:50 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:45:50 --> Utf8 Class Initialized
INFO - 2020-09-21 14:45:50 --> URI Class Initialized
INFO - 2020-09-21 14:45:50 --> Router Class Initialized
INFO - 2020-09-21 14:45:50 --> Output Class Initialized
INFO - 2020-09-21 14:45:50 --> Security Class Initialized
DEBUG - 2020-09-21 14:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:45:50 --> Input Class Initialized
INFO - 2020-09-21 14:45:50 --> Language Class Initialized
INFO - 2020-09-21 14:45:50 --> Loader Class Initialized
INFO - 2020-09-21 14:45:50 --> Helper loaded: url_helper
INFO - 2020-09-21 14:45:50 --> Database Driver Class Initialized
INFO - 2020-09-21 14:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:45:50 --> Email Class Initialized
INFO - 2020-09-21 14:45:50 --> Controller Class Initialized
INFO - 2020-09-21 14:45:50 --> Model Class Initialized
INFO - 2020-09-21 14:45:50 --> Model Class Initialized
INFO - 2020-09-21 14:45:50 --> Model Class Initialized
INFO - 2020-09-21 14:45:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-21 14:45:50 --> Final output sent to browser
DEBUG - 2020-09-21 14:45:50 --> Total execution time: 0.0380
ERROR - 2020-09-21 14:45:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:45:51 --> Config Class Initialized
INFO - 2020-09-21 14:45:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:45:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:45:51 --> Utf8 Class Initialized
INFO - 2020-09-21 14:45:51 --> URI Class Initialized
INFO - 2020-09-21 14:45:51 --> Router Class Initialized
INFO - 2020-09-21 14:45:51 --> Output Class Initialized
INFO - 2020-09-21 14:45:51 --> Security Class Initialized
DEBUG - 2020-09-21 14:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:45:51 --> Input Class Initialized
INFO - 2020-09-21 14:45:51 --> Language Class Initialized
INFO - 2020-09-21 14:45:51 --> Loader Class Initialized
INFO - 2020-09-21 14:45:51 --> Helper loaded: url_helper
INFO - 2020-09-21 14:45:51 --> Database Driver Class Initialized
INFO - 2020-09-21 14:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:45:51 --> Email Class Initialized
INFO - 2020-09-21 14:45:51 --> Controller Class Initialized
INFO - 2020-09-21 14:45:51 --> Model Class Initialized
INFO - 2020-09-21 14:45:51 --> Model Class Initialized
INFO - 2020-09-21 14:45:51 --> Final output sent to browser
DEBUG - 2020-09-21 14:45:51 --> Total execution time: 0.0466
ERROR - 2020-09-21 14:46:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:46:13 --> Config Class Initialized
INFO - 2020-09-21 14:46:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:46:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:46:13 --> Utf8 Class Initialized
INFO - 2020-09-21 14:46:13 --> URI Class Initialized
INFO - 2020-09-21 14:46:13 --> Router Class Initialized
INFO - 2020-09-21 14:46:13 --> Output Class Initialized
INFO - 2020-09-21 14:46:13 --> Security Class Initialized
DEBUG - 2020-09-21 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:46:13 --> Input Class Initialized
INFO - 2020-09-21 14:46:13 --> Language Class Initialized
INFO - 2020-09-21 14:46:13 --> Loader Class Initialized
INFO - 2020-09-21 14:46:13 --> Helper loaded: url_helper
INFO - 2020-09-21 14:46:14 --> Database Driver Class Initialized
INFO - 2020-09-21 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:46:14 --> Email Class Initialized
INFO - 2020-09-21 14:46:14 --> Controller Class Initialized
INFO - 2020-09-21 14:46:14 --> Model Class Initialized
INFO - 2020-09-21 14:46:14 --> Model Class Initialized
INFO - 2020-09-21 14:46:14 --> Model Class Initialized
INFO - 2020-09-21 14:46:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 14:46:14 --> Final output sent to browser
DEBUG - 2020-09-21 14:46:14 --> Total execution time: 0.0398
ERROR - 2020-09-21 14:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:50:03 --> Config Class Initialized
INFO - 2020-09-21 14:50:03 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:50:03 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:50:03 --> Utf8 Class Initialized
INFO - 2020-09-21 14:50:03 --> URI Class Initialized
INFO - 2020-09-21 14:50:03 --> Router Class Initialized
INFO - 2020-09-21 14:50:03 --> Output Class Initialized
INFO - 2020-09-21 14:50:03 --> Security Class Initialized
DEBUG - 2020-09-21 14:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:50:03 --> Input Class Initialized
INFO - 2020-09-21 14:50:03 --> Language Class Initialized
INFO - 2020-09-21 14:50:03 --> Loader Class Initialized
INFO - 2020-09-21 14:50:03 --> Helper loaded: url_helper
INFO - 2020-09-21 14:50:03 --> Database Driver Class Initialized
INFO - 2020-09-21 14:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:50:03 --> Email Class Initialized
INFO - 2020-09-21 14:50:03 --> Controller Class Initialized
INFO - 2020-09-21 14:50:03 --> Model Class Initialized
INFO - 2020-09-21 14:50:03 --> Model Class Initialized
INFO - 2020-09-21 14:50:03 --> Model Class Initialized
INFO - 2020-09-21 14:50:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-21 14:50:03 --> Final output sent to browser
DEBUG - 2020-09-21 14:50:03 --> Total execution time: 0.0514
ERROR - 2020-09-21 14:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 14:50:40 --> Config Class Initialized
INFO - 2020-09-21 14:50:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 14:50:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 14:50:40 --> Utf8 Class Initialized
INFO - 2020-09-21 14:50:40 --> URI Class Initialized
INFO - 2020-09-21 14:50:40 --> Router Class Initialized
INFO - 2020-09-21 14:50:40 --> Output Class Initialized
INFO - 2020-09-21 14:50:40 --> Security Class Initialized
DEBUG - 2020-09-21 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 14:50:40 --> Input Class Initialized
INFO - 2020-09-21 14:50:40 --> Language Class Initialized
INFO - 2020-09-21 14:50:40 --> Loader Class Initialized
INFO - 2020-09-21 14:50:40 --> Helper loaded: url_helper
INFO - 2020-09-21 14:50:40 --> Database Driver Class Initialized
INFO - 2020-09-21 14:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 14:50:40 --> Email Class Initialized
INFO - 2020-09-21 14:50:40 --> Controller Class Initialized
DEBUG - 2020-09-21 14:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 14:50:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 14:50:40 --> Model Class Initialized
INFO - 2020-09-21 14:50:40 --> Model Class Initialized
INFO - 2020-09-21 14:50:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 14:50:40 --> Final output sent to browser
DEBUG - 2020-09-21 14:50:40 --> Total execution time: 0.0268
ERROR - 2020-09-21 15:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:02:50 --> Config Class Initialized
INFO - 2020-09-21 15:02:50 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:02:50 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:02:50 --> Utf8 Class Initialized
INFO - 2020-09-21 15:02:50 --> URI Class Initialized
INFO - 2020-09-21 15:02:50 --> Router Class Initialized
INFO - 2020-09-21 15:02:50 --> Output Class Initialized
INFO - 2020-09-21 15:02:50 --> Security Class Initialized
DEBUG - 2020-09-21 15:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:02:50 --> Input Class Initialized
INFO - 2020-09-21 15:02:50 --> Language Class Initialized
INFO - 2020-09-21 15:02:50 --> Loader Class Initialized
INFO - 2020-09-21 15:02:50 --> Helper loaded: url_helper
INFO - 2020-09-21 15:02:50 --> Database Driver Class Initialized
INFO - 2020-09-21 15:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:02:50 --> Email Class Initialized
INFO - 2020-09-21 15:02:50 --> Controller Class Initialized
DEBUG - 2020-09-21 15:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:02:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:02:50 --> Model Class Initialized
INFO - 2020-09-21 15:02:50 --> Model Class Initialized
INFO - 2020-09-21 15:02:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 15:02:50 --> Final output sent to browser
DEBUG - 2020-09-21 15:02:50 --> Total execution time: 0.0240
ERROR - 2020-09-21 15:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:03:57 --> Config Class Initialized
INFO - 2020-09-21 15:03:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:03:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:03:57 --> Utf8 Class Initialized
INFO - 2020-09-21 15:03:57 --> URI Class Initialized
INFO - 2020-09-21 15:03:57 --> Router Class Initialized
INFO - 2020-09-21 15:03:57 --> Output Class Initialized
INFO - 2020-09-21 15:03:57 --> Security Class Initialized
DEBUG - 2020-09-21 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:03:57 --> Input Class Initialized
INFO - 2020-09-21 15:03:57 --> Language Class Initialized
INFO - 2020-09-21 15:03:57 --> Loader Class Initialized
INFO - 2020-09-21 15:03:57 --> Helper loaded: url_helper
INFO - 2020-09-21 15:03:57 --> Database Driver Class Initialized
INFO - 2020-09-21 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:03:57 --> Email Class Initialized
INFO - 2020-09-21 15:03:57 --> Controller Class Initialized
DEBUG - 2020-09-21 15:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:03:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:03:57 --> Model Class Initialized
INFO - 2020-09-21 15:03:57 --> Model Class Initialized
INFO - 2020-09-21 15:03:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 15:03:57 --> Final output sent to browser
DEBUG - 2020-09-21 15:03:57 --> Total execution time: 0.0280
ERROR - 2020-09-21 15:04:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:04:51 --> Config Class Initialized
INFO - 2020-09-21 15:04:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:04:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:04:51 --> Utf8 Class Initialized
INFO - 2020-09-21 15:04:51 --> URI Class Initialized
INFO - 2020-09-21 15:04:51 --> Router Class Initialized
INFO - 2020-09-21 15:04:51 --> Output Class Initialized
INFO - 2020-09-21 15:04:51 --> Security Class Initialized
DEBUG - 2020-09-21 15:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:04:51 --> Input Class Initialized
INFO - 2020-09-21 15:04:51 --> Language Class Initialized
INFO - 2020-09-21 15:04:51 --> Loader Class Initialized
INFO - 2020-09-21 15:04:51 --> Helper loaded: url_helper
INFO - 2020-09-21 15:04:51 --> Database Driver Class Initialized
INFO - 2020-09-21 15:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:04:51 --> Email Class Initialized
INFO - 2020-09-21 15:04:51 --> Controller Class Initialized
DEBUG - 2020-09-21 15:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:04:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:04:51 --> Model Class Initialized
INFO - 2020-09-21 15:04:51 --> Model Class Initialized
INFO - 2020-09-21 15:04:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-21 15:04:51 --> Final output sent to browser
DEBUG - 2020-09-21 15:04:51 --> Total execution time: 0.0220
ERROR - 2020-09-21 15:06:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:06:09 --> Config Class Initialized
INFO - 2020-09-21 15:06:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:06:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:06:09 --> Utf8 Class Initialized
INFO - 2020-09-21 15:06:09 --> URI Class Initialized
DEBUG - 2020-09-21 15:06:09 --> No URI present. Default controller set.
INFO - 2020-09-21 15:06:09 --> Router Class Initialized
INFO - 2020-09-21 15:06:09 --> Output Class Initialized
INFO - 2020-09-21 15:06:09 --> Security Class Initialized
DEBUG - 2020-09-21 15:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:06:09 --> Input Class Initialized
INFO - 2020-09-21 15:06:09 --> Language Class Initialized
INFO - 2020-09-21 15:06:09 --> Loader Class Initialized
INFO - 2020-09-21 15:06:09 --> Helper loaded: url_helper
INFO - 2020-09-21 15:06:09 --> Database Driver Class Initialized
INFO - 2020-09-21 15:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:06:09 --> Email Class Initialized
INFO - 2020-09-21 15:06:09 --> Controller Class Initialized
INFO - 2020-09-21 15:06:09 --> Model Class Initialized
INFO - 2020-09-21 15:06:09 --> Model Class Initialized
DEBUG - 2020-09-21 15:06:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:06:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-21 15:06:09 --> Final output sent to browser
DEBUG - 2020-09-21 15:06:09 --> Total execution time: 0.0210
ERROR - 2020-09-21 15:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:06:12 --> Config Class Initialized
INFO - 2020-09-21 15:06:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:06:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:06:12 --> Utf8 Class Initialized
INFO - 2020-09-21 15:06:12 --> URI Class Initialized
INFO - 2020-09-21 15:06:12 --> Router Class Initialized
INFO - 2020-09-21 15:06:12 --> Output Class Initialized
INFO - 2020-09-21 15:06:12 --> Security Class Initialized
DEBUG - 2020-09-21 15:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:06:12 --> Input Class Initialized
INFO - 2020-09-21 15:06:12 --> Language Class Initialized
INFO - 2020-09-21 15:06:12 --> Loader Class Initialized
INFO - 2020-09-21 15:06:12 --> Helper loaded: url_helper
INFO - 2020-09-21 15:06:12 --> Database Driver Class Initialized
INFO - 2020-09-21 15:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:06:12 --> Email Class Initialized
INFO - 2020-09-21 15:06:12 --> Controller Class Initialized
INFO - 2020-09-21 15:06:12 --> Model Class Initialized
INFO - 2020-09-21 15:06:12 --> Model Class Initialized
DEBUG - 2020-09-21 15:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:06:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:06:12 --> Model Class Initialized
ERROR - 2020-09-21 15:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:06:12 --> Config Class Initialized
INFO - 2020-09-21 15:06:12 --> Hooks Class Initialized
INFO - 2020-09-21 15:06:12 --> Final output sent to browser
DEBUG - 2020-09-21 15:06:12 --> Total execution time: 0.0235
DEBUG - 2020-09-21 15:06:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:06:12 --> Utf8 Class Initialized
INFO - 2020-09-21 15:06:12 --> URI Class Initialized
INFO - 2020-09-21 15:06:12 --> Router Class Initialized
INFO - 2020-09-21 15:06:12 --> Output Class Initialized
INFO - 2020-09-21 15:06:12 --> Security Class Initialized
DEBUG - 2020-09-21 15:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:06:12 --> Input Class Initialized
INFO - 2020-09-21 15:06:12 --> Language Class Initialized
INFO - 2020-09-21 15:06:12 --> Loader Class Initialized
INFO - 2020-09-21 15:06:12 --> Helper loaded: url_helper
INFO - 2020-09-21 15:06:12 --> Database Driver Class Initialized
INFO - 2020-09-21 15:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:06:12 --> Email Class Initialized
INFO - 2020-09-21 15:06:12 --> Controller Class Initialized
INFO - 2020-09-21 15:06:12 --> Model Class Initialized
INFO - 2020-09-21 15:06:12 --> Model Class Initialized
DEBUG - 2020-09-21 15:06:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-21 15:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:06:13 --> Config Class Initialized
INFO - 2020-09-21 15:06:13 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:06:13 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:06:13 --> Utf8 Class Initialized
INFO - 2020-09-21 15:06:13 --> URI Class Initialized
INFO - 2020-09-21 15:06:13 --> Router Class Initialized
INFO - 2020-09-21 15:06:13 --> Output Class Initialized
INFO - 2020-09-21 15:06:13 --> Security Class Initialized
DEBUG - 2020-09-21 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:06:13 --> Input Class Initialized
INFO - 2020-09-21 15:06:13 --> Language Class Initialized
INFO - 2020-09-21 15:06:13 --> Loader Class Initialized
INFO - 2020-09-21 15:06:13 --> Helper loaded: url_helper
INFO - 2020-09-21 15:06:13 --> Database Driver Class Initialized
INFO - 2020-09-21 15:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:06:13 --> Email Class Initialized
INFO - 2020-09-21 15:06:13 --> Controller Class Initialized
DEBUG - 2020-09-21 15:06:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:06:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:06:13 --> Model Class Initialized
INFO - 2020-09-21 15:06:13 --> Model Class Initialized
INFO - 2020-09-21 15:06:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 15:06:13 --> Final output sent to browser
DEBUG - 2020-09-21 15:06:13 --> Total execution time: 0.0244
ERROR - 2020-09-21 15:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:06:26 --> Config Class Initialized
INFO - 2020-09-21 15:06:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:06:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:06:26 --> Utf8 Class Initialized
INFO - 2020-09-21 15:06:26 --> URI Class Initialized
INFO - 2020-09-21 15:06:26 --> Router Class Initialized
INFO - 2020-09-21 15:06:26 --> Output Class Initialized
INFO - 2020-09-21 15:06:26 --> Security Class Initialized
DEBUG - 2020-09-21 15:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:06:26 --> Input Class Initialized
INFO - 2020-09-21 15:06:26 --> Language Class Initialized
INFO - 2020-09-21 15:06:26 --> Loader Class Initialized
INFO - 2020-09-21 15:06:26 --> Helper loaded: url_helper
INFO - 2020-09-21 15:06:26 --> Database Driver Class Initialized
INFO - 2020-09-21 15:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:06:26 --> Email Class Initialized
INFO - 2020-09-21 15:06:26 --> Controller Class Initialized
DEBUG - 2020-09-21 15:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:06:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:06:26 --> Model Class Initialized
INFO - 2020-09-21 15:06:26 --> Model Class Initialized
INFO - 2020-09-21 15:06:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:06:26 --> Final output sent to browser
DEBUG - 2020-09-21 15:06:26 --> Total execution time: 0.0256
ERROR - 2020-09-21 15:11:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:11:18 --> Config Class Initialized
INFO - 2020-09-21 15:11:18 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:11:18 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:11:18 --> Utf8 Class Initialized
INFO - 2020-09-21 15:11:18 --> URI Class Initialized
INFO - 2020-09-21 15:11:18 --> Router Class Initialized
INFO - 2020-09-21 15:11:18 --> Output Class Initialized
INFO - 2020-09-21 15:11:18 --> Security Class Initialized
DEBUG - 2020-09-21 15:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:11:18 --> Input Class Initialized
INFO - 2020-09-21 15:11:18 --> Language Class Initialized
INFO - 2020-09-21 15:11:18 --> Loader Class Initialized
INFO - 2020-09-21 15:11:18 --> Helper loaded: url_helper
INFO - 2020-09-21 15:11:18 --> Database Driver Class Initialized
INFO - 2020-09-21 15:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:11:18 --> Email Class Initialized
INFO - 2020-09-21 15:11:18 --> Controller Class Initialized
DEBUG - 2020-09-21 15:11:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:11:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:11:18 --> Model Class Initialized
INFO - 2020-09-21 15:11:18 --> Model Class Initialized
INFO - 2020-09-21 15:11:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:11:18 --> Final output sent to browser
DEBUG - 2020-09-21 15:11:18 --> Total execution time: 0.0281
ERROR - 2020-09-21 15:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:11:38 --> Config Class Initialized
INFO - 2020-09-21 15:11:38 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:11:38 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:11:38 --> Utf8 Class Initialized
INFO - 2020-09-21 15:11:38 --> URI Class Initialized
INFO - 2020-09-21 15:11:38 --> Router Class Initialized
INFO - 2020-09-21 15:11:38 --> Output Class Initialized
INFO - 2020-09-21 15:11:38 --> Security Class Initialized
DEBUG - 2020-09-21 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:11:38 --> Input Class Initialized
INFO - 2020-09-21 15:11:38 --> Language Class Initialized
INFO - 2020-09-21 15:11:38 --> Loader Class Initialized
INFO - 2020-09-21 15:11:38 --> Helper loaded: url_helper
INFO - 2020-09-21 15:11:38 --> Database Driver Class Initialized
INFO - 2020-09-21 15:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:11:38 --> Email Class Initialized
INFO - 2020-09-21 15:11:38 --> Controller Class Initialized
DEBUG - 2020-09-21 15:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:11:38 --> Model Class Initialized
INFO - 2020-09-21 15:11:38 --> Model Class Initialized
INFO - 2020-09-21 15:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:11:38 --> Final output sent to browser
DEBUG - 2020-09-21 15:11:38 --> Total execution time: 0.0245
ERROR - 2020-09-21 15:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:11:45 --> Config Class Initialized
INFO - 2020-09-21 15:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:11:45 --> Utf8 Class Initialized
INFO - 2020-09-21 15:11:45 --> URI Class Initialized
INFO - 2020-09-21 15:11:45 --> Router Class Initialized
INFO - 2020-09-21 15:11:45 --> Output Class Initialized
INFO - 2020-09-21 15:11:45 --> Security Class Initialized
DEBUG - 2020-09-21 15:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:11:45 --> Input Class Initialized
INFO - 2020-09-21 15:11:45 --> Language Class Initialized
INFO - 2020-09-21 15:11:45 --> Loader Class Initialized
INFO - 2020-09-21 15:11:45 --> Helper loaded: url_helper
INFO - 2020-09-21 15:11:45 --> Database Driver Class Initialized
INFO - 2020-09-21 15:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:11:45 --> Email Class Initialized
INFO - 2020-09-21 15:11:45 --> Controller Class Initialized
DEBUG - 2020-09-21 15:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:11:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:11:45 --> Model Class Initialized
INFO - 2020-09-21 15:11:45 --> Model Class Initialized
INFO - 2020-09-21 15:11:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 15:11:45 --> Final output sent to browser
DEBUG - 2020-09-21 15:11:45 --> Total execution time: 0.0260
ERROR - 2020-09-21 15:11:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:11:51 --> Config Class Initialized
INFO - 2020-09-21 15:11:51 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:11:51 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:11:51 --> Utf8 Class Initialized
INFO - 2020-09-21 15:11:51 --> URI Class Initialized
INFO - 2020-09-21 15:11:51 --> Router Class Initialized
INFO - 2020-09-21 15:11:51 --> Output Class Initialized
INFO - 2020-09-21 15:11:51 --> Security Class Initialized
DEBUG - 2020-09-21 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:11:51 --> Input Class Initialized
INFO - 2020-09-21 15:11:51 --> Language Class Initialized
INFO - 2020-09-21 15:11:51 --> Loader Class Initialized
INFO - 2020-09-21 15:11:51 --> Helper loaded: url_helper
INFO - 2020-09-21 15:11:51 --> Database Driver Class Initialized
INFO - 2020-09-21 15:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:11:51 --> Email Class Initialized
INFO - 2020-09-21 15:11:51 --> Controller Class Initialized
DEBUG - 2020-09-21 15:11:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:11:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:11:51 --> Model Class Initialized
INFO - 2020-09-21 15:11:51 --> Model Class Initialized
INFO - 2020-09-21 15:11:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:11:51 --> Final output sent to browser
DEBUG - 2020-09-21 15:11:51 --> Total execution time: 0.0222
ERROR - 2020-09-21 15:12:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:12:25 --> Config Class Initialized
INFO - 2020-09-21 15:12:25 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:12:25 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:12:25 --> Utf8 Class Initialized
INFO - 2020-09-21 15:12:25 --> URI Class Initialized
INFO - 2020-09-21 15:12:25 --> Router Class Initialized
INFO - 2020-09-21 15:12:25 --> Output Class Initialized
INFO - 2020-09-21 15:12:25 --> Security Class Initialized
DEBUG - 2020-09-21 15:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:12:25 --> Input Class Initialized
INFO - 2020-09-21 15:12:25 --> Language Class Initialized
INFO - 2020-09-21 15:12:25 --> Loader Class Initialized
INFO - 2020-09-21 15:12:25 --> Helper loaded: url_helper
INFO - 2020-09-21 15:12:25 --> Database Driver Class Initialized
INFO - 2020-09-21 15:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:12:25 --> Email Class Initialized
INFO - 2020-09-21 15:12:25 --> Controller Class Initialized
DEBUG - 2020-09-21 15:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:12:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:12:25 --> Model Class Initialized
INFO - 2020-09-21 15:12:25 --> Model Class Initialized
INFO - 2020-09-21 15:12:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:12:25 --> Final output sent to browser
DEBUG - 2020-09-21 15:12:25 --> Total execution time: 0.0265
ERROR - 2020-09-21 15:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:12:35 --> Config Class Initialized
INFO - 2020-09-21 15:12:35 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:12:35 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:12:35 --> Utf8 Class Initialized
INFO - 2020-09-21 15:12:36 --> URI Class Initialized
INFO - 2020-09-21 15:12:36 --> Router Class Initialized
INFO - 2020-09-21 15:12:36 --> Output Class Initialized
INFO - 2020-09-21 15:12:36 --> Security Class Initialized
DEBUG - 2020-09-21 15:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:12:36 --> Input Class Initialized
INFO - 2020-09-21 15:12:36 --> Language Class Initialized
INFO - 2020-09-21 15:12:36 --> Loader Class Initialized
INFO - 2020-09-21 15:12:36 --> Helper loaded: url_helper
INFO - 2020-09-21 15:12:36 --> Database Driver Class Initialized
INFO - 2020-09-21 15:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:12:36 --> Email Class Initialized
INFO - 2020-09-21 15:12:36 --> Controller Class Initialized
DEBUG - 2020-09-21 15:12:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:12:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:12:36 --> Model Class Initialized
INFO - 2020-09-21 15:12:36 --> Model Class Initialized
INFO - 2020-09-21 15:12:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-21 15:12:36 --> Final output sent to browser
DEBUG - 2020-09-21 15:12:36 --> Total execution time: 0.0223
ERROR - 2020-09-21 15:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:14:18 --> Config Class Initialized
INFO - 2020-09-21 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:14:18 --> Utf8 Class Initialized
INFO - 2020-09-21 15:14:18 --> URI Class Initialized
INFO - 2020-09-21 15:14:18 --> Router Class Initialized
INFO - 2020-09-21 15:14:18 --> Output Class Initialized
INFO - 2020-09-21 15:14:18 --> Security Class Initialized
DEBUG - 2020-09-21 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:14:18 --> Input Class Initialized
INFO - 2020-09-21 15:14:18 --> Language Class Initialized
INFO - 2020-09-21 15:14:18 --> Loader Class Initialized
INFO - 2020-09-21 15:14:18 --> Helper loaded: url_helper
INFO - 2020-09-21 15:14:18 --> Database Driver Class Initialized
INFO - 2020-09-21 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:14:18 --> Email Class Initialized
INFO - 2020-09-21 15:14:18 --> Controller Class Initialized
DEBUG - 2020-09-21 15:14:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:14:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:14:18 --> Model Class Initialized
INFO - 2020-09-21 15:14:18 --> Model Class Initialized
INFO - 2020-09-21 15:14:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-21 15:14:18 --> Final output sent to browser
DEBUG - 2020-09-21 15:14:18 --> Total execution time: 0.1039
ERROR - 2020-09-21 15:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:14:27 --> Config Class Initialized
INFO - 2020-09-21 15:14:27 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:14:27 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:14:27 --> Utf8 Class Initialized
INFO - 2020-09-21 15:14:27 --> URI Class Initialized
INFO - 2020-09-21 15:14:27 --> Router Class Initialized
INFO - 2020-09-21 15:14:27 --> Output Class Initialized
INFO - 2020-09-21 15:14:27 --> Security Class Initialized
DEBUG - 2020-09-21 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:14:27 --> Input Class Initialized
INFO - 2020-09-21 15:14:27 --> Language Class Initialized
INFO - 2020-09-21 15:14:27 --> Loader Class Initialized
INFO - 2020-09-21 15:14:27 --> Helper loaded: url_helper
INFO - 2020-09-21 15:14:27 --> Database Driver Class Initialized
INFO - 2020-09-21 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:14:27 --> Email Class Initialized
INFO - 2020-09-21 15:14:27 --> Controller Class Initialized
DEBUG - 2020-09-21 15:14:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:14:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:14:27 --> Model Class Initialized
INFO - 2020-09-21 15:14:27 --> Model Class Initialized
INFO - 2020-09-21 15:14:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:14:27 --> Final output sent to browser
DEBUG - 2020-09-21 15:14:27 --> Total execution time: 0.0263
ERROR - 2020-09-21 15:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:14:29 --> Config Class Initialized
INFO - 2020-09-21 15:14:29 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:14:29 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:14:29 --> Utf8 Class Initialized
INFO - 2020-09-21 15:14:29 --> URI Class Initialized
INFO - 2020-09-21 15:14:29 --> Router Class Initialized
INFO - 2020-09-21 15:14:29 --> Output Class Initialized
INFO - 2020-09-21 15:14:29 --> Security Class Initialized
DEBUG - 2020-09-21 15:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:14:29 --> Input Class Initialized
INFO - 2020-09-21 15:14:29 --> Language Class Initialized
INFO - 2020-09-21 15:14:29 --> Loader Class Initialized
INFO - 2020-09-21 15:14:29 --> Helper loaded: url_helper
INFO - 2020-09-21 15:14:29 --> Database Driver Class Initialized
INFO - 2020-09-21 15:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:14:29 --> Email Class Initialized
INFO - 2020-09-21 15:14:29 --> Controller Class Initialized
DEBUG - 2020-09-21 15:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:14:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:14:29 --> Model Class Initialized
INFO - 2020-09-21 15:14:29 --> Model Class Initialized
INFO - 2020-09-21 15:14:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-21 15:14:29 --> Final output sent to browser
DEBUG - 2020-09-21 15:14:29 --> Total execution time: 0.0387
ERROR - 2020-09-21 15:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:15:34 --> Config Class Initialized
INFO - 2020-09-21 15:15:34 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:15:34 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:15:34 --> Utf8 Class Initialized
INFO - 2020-09-21 15:15:34 --> URI Class Initialized
INFO - 2020-09-21 15:15:34 --> Router Class Initialized
INFO - 2020-09-21 15:15:34 --> Output Class Initialized
INFO - 2020-09-21 15:15:34 --> Security Class Initialized
DEBUG - 2020-09-21 15:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:15:34 --> Input Class Initialized
INFO - 2020-09-21 15:15:34 --> Language Class Initialized
INFO - 2020-09-21 15:15:34 --> Loader Class Initialized
INFO - 2020-09-21 15:15:34 --> Helper loaded: url_helper
INFO - 2020-09-21 15:15:34 --> Database Driver Class Initialized
INFO - 2020-09-21 15:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:15:34 --> Email Class Initialized
INFO - 2020-09-21 15:15:34 --> Controller Class Initialized
DEBUG - 2020-09-21 15:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:15:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:15:34 --> Model Class Initialized
INFO - 2020-09-21 15:15:34 --> Model Class Initialized
INFO - 2020-09-21 15:15:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-09-21 15:15:34 --> Final output sent to browser
DEBUG - 2020-09-21 15:15:34 --> Total execution time: 0.0257
ERROR - 2020-09-21 15:15:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:15:37 --> Config Class Initialized
INFO - 2020-09-21 15:15:37 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:15:37 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:15:37 --> Utf8 Class Initialized
INFO - 2020-09-21 15:15:37 --> URI Class Initialized
INFO - 2020-09-21 15:15:37 --> Router Class Initialized
INFO - 2020-09-21 15:15:37 --> Output Class Initialized
INFO - 2020-09-21 15:15:37 --> Security Class Initialized
DEBUG - 2020-09-21 15:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:15:37 --> Input Class Initialized
INFO - 2020-09-21 15:15:37 --> Language Class Initialized
INFO - 2020-09-21 15:15:37 --> Loader Class Initialized
INFO - 2020-09-21 15:15:37 --> Helper loaded: url_helper
INFO - 2020-09-21 15:15:37 --> Database Driver Class Initialized
INFO - 2020-09-21 15:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:15:37 --> Email Class Initialized
INFO - 2020-09-21 15:15:37 --> Controller Class Initialized
DEBUG - 2020-09-21 15:15:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:15:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:15:37 --> Model Class Initialized
INFO - 2020-09-21 15:15:37 --> Model Class Initialized
INFO - 2020-09-21 15:15:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:15:37 --> Final output sent to browser
DEBUG - 2020-09-21 15:15:37 --> Total execution time: 0.0235
ERROR - 2020-09-21 15:15:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:15:40 --> Config Class Initialized
INFO - 2020-09-21 15:15:40 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:15:40 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:15:40 --> Utf8 Class Initialized
INFO - 2020-09-21 15:15:40 --> URI Class Initialized
INFO - 2020-09-21 15:15:40 --> Router Class Initialized
INFO - 2020-09-21 15:15:40 --> Output Class Initialized
INFO - 2020-09-21 15:15:40 --> Security Class Initialized
DEBUG - 2020-09-21 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:15:40 --> Input Class Initialized
INFO - 2020-09-21 15:15:40 --> Language Class Initialized
INFO - 2020-09-21 15:15:40 --> Loader Class Initialized
INFO - 2020-09-21 15:15:40 --> Helper loaded: url_helper
INFO - 2020-09-21 15:15:40 --> Database Driver Class Initialized
INFO - 2020-09-21 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:15:40 --> Email Class Initialized
INFO - 2020-09-21 15:15:40 --> Controller Class Initialized
DEBUG - 2020-09-21 15:15:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:15:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:15:40 --> Model Class Initialized
INFO - 2020-09-21 15:15:40 --> Model Class Initialized
INFO - 2020-09-21 15:15:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-21 15:15:40 --> Final output sent to browser
DEBUG - 2020-09-21 15:15:40 --> Total execution time: 0.0388
ERROR - 2020-09-21 15:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:16:31 --> Config Class Initialized
INFO - 2020-09-21 15:16:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:16:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:16:31 --> Utf8 Class Initialized
INFO - 2020-09-21 15:16:31 --> URI Class Initialized
INFO - 2020-09-21 15:16:31 --> Router Class Initialized
INFO - 2020-09-21 15:16:31 --> Output Class Initialized
INFO - 2020-09-21 15:16:31 --> Security Class Initialized
DEBUG - 2020-09-21 15:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:16:31 --> Input Class Initialized
INFO - 2020-09-21 15:16:31 --> Language Class Initialized
INFO - 2020-09-21 15:16:31 --> Loader Class Initialized
INFO - 2020-09-21 15:16:31 --> Helper loaded: url_helper
INFO - 2020-09-21 15:16:31 --> Database Driver Class Initialized
INFO - 2020-09-21 15:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:16:31 --> Email Class Initialized
INFO - 2020-09-21 15:16:31 --> Controller Class Initialized
DEBUG - 2020-09-21 15:16:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:16:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:16:31 --> Model Class Initialized
INFO - 2020-09-21 15:16:31 --> Model Class Initialized
INFO - 2020-09-21 15:16:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-09-21 15:16:31 --> Final output sent to browser
DEBUG - 2020-09-21 15:16:31 --> Total execution time: 0.0248
ERROR - 2020-09-21 15:16:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:16:36 --> Config Class Initialized
INFO - 2020-09-21 15:16:36 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:16:36 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:16:36 --> Utf8 Class Initialized
INFO - 2020-09-21 15:16:36 --> URI Class Initialized
INFO - 2020-09-21 15:16:36 --> Router Class Initialized
INFO - 2020-09-21 15:16:36 --> Output Class Initialized
INFO - 2020-09-21 15:16:36 --> Security Class Initialized
DEBUG - 2020-09-21 15:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:16:36 --> Input Class Initialized
INFO - 2020-09-21 15:16:36 --> Language Class Initialized
INFO - 2020-09-21 15:16:36 --> Loader Class Initialized
INFO - 2020-09-21 15:16:36 --> Helper loaded: url_helper
INFO - 2020-09-21 15:16:36 --> Database Driver Class Initialized
INFO - 2020-09-21 15:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:16:36 --> Email Class Initialized
INFO - 2020-09-21 15:16:36 --> Controller Class Initialized
DEBUG - 2020-09-21 15:16:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:16:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:16:36 --> Model Class Initialized
INFO - 2020-09-21 15:16:36 --> Model Class Initialized
INFO - 2020-09-21 15:16:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:16:36 --> Final output sent to browser
DEBUG - 2020-09-21 15:16:36 --> Total execution time: 0.0244
ERROR - 2020-09-21 15:16:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:16:43 --> Config Class Initialized
INFO - 2020-09-21 15:16:43 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:16:43 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:16:43 --> Utf8 Class Initialized
INFO - 2020-09-21 15:16:43 --> URI Class Initialized
INFO - 2020-09-21 15:16:43 --> Router Class Initialized
INFO - 2020-09-21 15:16:43 --> Output Class Initialized
INFO - 2020-09-21 15:16:43 --> Security Class Initialized
DEBUG - 2020-09-21 15:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:16:43 --> Input Class Initialized
INFO - 2020-09-21 15:16:43 --> Language Class Initialized
INFO - 2020-09-21 15:16:43 --> Loader Class Initialized
INFO - 2020-09-21 15:16:43 --> Helper loaded: url_helper
INFO - 2020-09-21 15:16:43 --> Database Driver Class Initialized
INFO - 2020-09-21 15:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:16:43 --> Email Class Initialized
INFO - 2020-09-21 15:16:43 --> Controller Class Initialized
DEBUG - 2020-09-21 15:16:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:16:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:16:43 --> Model Class Initialized
INFO - 2020-09-21 15:16:43 --> Model Class Initialized
INFO - 2020-09-21 15:16:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-21 15:16:43 --> Final output sent to browser
DEBUG - 2020-09-21 15:16:43 --> Total execution time: 0.0233
ERROR - 2020-09-21 15:16:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:16:46 --> Config Class Initialized
INFO - 2020-09-21 15:16:46 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:16:46 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:16:46 --> Utf8 Class Initialized
INFO - 2020-09-21 15:16:46 --> URI Class Initialized
INFO - 2020-09-21 15:16:46 --> Router Class Initialized
INFO - 2020-09-21 15:16:46 --> Output Class Initialized
INFO - 2020-09-21 15:16:46 --> Security Class Initialized
DEBUG - 2020-09-21 15:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:16:46 --> Input Class Initialized
INFO - 2020-09-21 15:16:46 --> Language Class Initialized
INFO - 2020-09-21 15:16:46 --> Loader Class Initialized
INFO - 2020-09-21 15:16:46 --> Helper loaded: url_helper
INFO - 2020-09-21 15:16:46 --> Database Driver Class Initialized
INFO - 2020-09-21 15:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:16:46 --> Email Class Initialized
INFO - 2020-09-21 15:16:46 --> Controller Class Initialized
DEBUG - 2020-09-21 15:16:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:16:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:16:46 --> Model Class Initialized
INFO - 2020-09-21 15:16:46 --> Model Class Initialized
INFO - 2020-09-21 15:16:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-21 15:16:46 --> Final output sent to browser
DEBUG - 2020-09-21 15:16:46 --> Total execution time: 0.2449
ERROR - 2020-09-21 15:18:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:18:57 --> Config Class Initialized
INFO - 2020-09-21 15:18:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:18:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:18:57 --> Utf8 Class Initialized
INFO - 2020-09-21 15:18:57 --> URI Class Initialized
INFO - 2020-09-21 15:18:57 --> Router Class Initialized
INFO - 2020-09-21 15:18:57 --> Output Class Initialized
INFO - 2020-09-21 15:18:57 --> Security Class Initialized
DEBUG - 2020-09-21 15:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:18:57 --> Input Class Initialized
INFO - 2020-09-21 15:18:57 --> Language Class Initialized
INFO - 2020-09-21 15:18:57 --> Loader Class Initialized
INFO - 2020-09-21 15:18:57 --> Helper loaded: url_helper
INFO - 2020-09-21 15:18:57 --> Database Driver Class Initialized
INFO - 2020-09-21 15:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:18:57 --> Email Class Initialized
INFO - 2020-09-21 15:18:57 --> Controller Class Initialized
DEBUG - 2020-09-21 15:18:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:18:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:18:57 --> Model Class Initialized
INFO - 2020-09-21 15:18:57 --> Model Class Initialized
INFO - 2020-09-21 15:18:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-21 15:18:57 --> Final output sent to browser
DEBUG - 2020-09-21 15:18:57 --> Total execution time: 0.0290
ERROR - 2020-09-21 15:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:19:04 --> Config Class Initialized
INFO - 2020-09-21 15:19:04 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:19:04 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:19:04 --> Utf8 Class Initialized
INFO - 2020-09-21 15:19:04 --> URI Class Initialized
INFO - 2020-09-21 15:19:04 --> Router Class Initialized
INFO - 2020-09-21 15:19:04 --> Output Class Initialized
INFO - 2020-09-21 15:19:04 --> Security Class Initialized
DEBUG - 2020-09-21 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:19:04 --> Input Class Initialized
INFO - 2020-09-21 15:19:04 --> Language Class Initialized
INFO - 2020-09-21 15:19:04 --> Loader Class Initialized
INFO - 2020-09-21 15:19:04 --> Helper loaded: url_helper
INFO - 2020-09-21 15:19:04 --> Database Driver Class Initialized
INFO - 2020-09-21 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:19:04 --> Email Class Initialized
INFO - 2020-09-21 15:19:04 --> Controller Class Initialized
DEBUG - 2020-09-21 15:19:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:19:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:19:04 --> Model Class Initialized
INFO - 2020-09-21 15:19:04 --> Model Class Initialized
INFO - 2020-09-21 15:19:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-21 15:19:04 --> Final output sent to browser
DEBUG - 2020-09-21 15:19:04 --> Total execution time: 0.0298
ERROR - 2020-09-21 15:20:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:20:00 --> Config Class Initialized
INFO - 2020-09-21 15:20:00 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:20:00 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:20:00 --> Utf8 Class Initialized
INFO - 2020-09-21 15:20:00 --> URI Class Initialized
INFO - 2020-09-21 15:20:00 --> Router Class Initialized
INFO - 2020-09-21 15:20:00 --> Output Class Initialized
INFO - 2020-09-21 15:20:00 --> Security Class Initialized
DEBUG - 2020-09-21 15:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:20:00 --> Input Class Initialized
INFO - 2020-09-21 15:20:00 --> Language Class Initialized
INFO - 2020-09-21 15:20:00 --> Loader Class Initialized
INFO - 2020-09-21 15:20:00 --> Helper loaded: url_helper
INFO - 2020-09-21 15:20:00 --> Database Driver Class Initialized
INFO - 2020-09-21 15:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:20:00 --> Email Class Initialized
INFO - 2020-09-21 15:20:00 --> Controller Class Initialized
DEBUG - 2020-09-21 15:20:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:20:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:20:00 --> Model Class Initialized
INFO - 2020-09-21 15:20:00 --> Model Class Initialized
INFO - 2020-09-21 15:20:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-21 15:20:00 --> Final output sent to browser
DEBUG - 2020-09-21 15:20:00 --> Total execution time: 0.0255
ERROR - 2020-09-21 15:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:20:08 --> Config Class Initialized
INFO - 2020-09-21 15:20:08 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:20:08 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:20:08 --> Utf8 Class Initialized
INFO - 2020-09-21 15:20:08 --> URI Class Initialized
INFO - 2020-09-21 15:20:08 --> Router Class Initialized
INFO - 2020-09-21 15:20:08 --> Output Class Initialized
INFO - 2020-09-21 15:20:08 --> Security Class Initialized
DEBUG - 2020-09-21 15:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:20:08 --> Input Class Initialized
INFO - 2020-09-21 15:20:08 --> Language Class Initialized
INFO - 2020-09-21 15:20:08 --> Loader Class Initialized
INFO - 2020-09-21 15:20:08 --> Helper loaded: url_helper
INFO - 2020-09-21 15:20:08 --> Database Driver Class Initialized
INFO - 2020-09-21 15:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:20:08 --> Email Class Initialized
INFO - 2020-09-21 15:20:08 --> Controller Class Initialized
DEBUG - 2020-09-21 15:20:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:20:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:20:08 --> Model Class Initialized
INFO - 2020-09-21 15:20:08 --> Model Class Initialized
INFO - 2020-09-21 15:20:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-21 15:20:08 --> Final output sent to browser
DEBUG - 2020-09-21 15:20:08 --> Total execution time: 0.0237
ERROR - 2020-09-21 15:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:20:12 --> Config Class Initialized
INFO - 2020-09-21 15:20:12 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:20:12 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:20:12 --> Utf8 Class Initialized
INFO - 2020-09-21 15:20:12 --> URI Class Initialized
INFO - 2020-09-21 15:20:12 --> Router Class Initialized
INFO - 2020-09-21 15:20:12 --> Output Class Initialized
INFO - 2020-09-21 15:20:12 --> Security Class Initialized
DEBUG - 2020-09-21 15:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:20:12 --> Input Class Initialized
INFO - 2020-09-21 15:20:12 --> Language Class Initialized
INFO - 2020-09-21 15:20:12 --> Loader Class Initialized
INFO - 2020-09-21 15:20:12 --> Helper loaded: url_helper
INFO - 2020-09-21 15:20:12 --> Database Driver Class Initialized
INFO - 2020-09-21 15:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:20:12 --> Email Class Initialized
INFO - 2020-09-21 15:20:12 --> Controller Class Initialized
DEBUG - 2020-09-21 15:20:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:20:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:20:12 --> Model Class Initialized
INFO - 2020-09-21 15:20:12 --> Model Class Initialized
INFO - 2020-09-21 15:20:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-21 15:20:12 --> Final output sent to browser
DEBUG - 2020-09-21 15:20:12 --> Total execution time: 0.0336
ERROR - 2020-09-21 15:21:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:21:01 --> Config Class Initialized
INFO - 2020-09-21 15:21:01 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:21:01 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:21:01 --> Utf8 Class Initialized
INFO - 2020-09-21 15:21:01 --> URI Class Initialized
INFO - 2020-09-21 15:21:01 --> Router Class Initialized
INFO - 2020-09-21 15:21:01 --> Output Class Initialized
INFO - 2020-09-21 15:21:01 --> Security Class Initialized
DEBUG - 2020-09-21 15:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:21:01 --> Input Class Initialized
INFO - 2020-09-21 15:21:01 --> Language Class Initialized
INFO - 2020-09-21 15:21:01 --> Loader Class Initialized
INFO - 2020-09-21 15:21:01 --> Helper loaded: url_helper
INFO - 2020-09-21 15:21:01 --> Database Driver Class Initialized
INFO - 2020-09-21 15:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:21:01 --> Email Class Initialized
INFO - 2020-09-21 15:21:01 --> Controller Class Initialized
DEBUG - 2020-09-21 15:21:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:21:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:21:01 --> Model Class Initialized
INFO - 2020-09-21 15:21:01 --> Model Class Initialized
INFO - 2020-09-21 15:21:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-21 15:21:01 --> Final output sent to browser
DEBUG - 2020-09-21 15:21:01 --> Total execution time: 0.0276
ERROR - 2020-09-21 15:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:21:14 --> Config Class Initialized
INFO - 2020-09-21 15:21:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:21:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:21:14 --> Utf8 Class Initialized
INFO - 2020-09-21 15:21:14 --> URI Class Initialized
INFO - 2020-09-21 15:21:14 --> Router Class Initialized
INFO - 2020-09-21 15:21:14 --> Output Class Initialized
INFO - 2020-09-21 15:21:14 --> Security Class Initialized
DEBUG - 2020-09-21 15:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:21:14 --> Input Class Initialized
INFO - 2020-09-21 15:21:14 --> Language Class Initialized
INFO - 2020-09-21 15:21:14 --> Loader Class Initialized
INFO - 2020-09-21 15:21:14 --> Helper loaded: url_helper
INFO - 2020-09-21 15:21:14 --> Database Driver Class Initialized
INFO - 2020-09-21 15:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:21:14 --> Email Class Initialized
INFO - 2020-09-21 15:21:14 --> Controller Class Initialized
DEBUG - 2020-09-21 15:21:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:21:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:21:14 --> Model Class Initialized
INFO - 2020-09-21 15:21:14 --> Model Class Initialized
INFO - 2020-09-21 15:21:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 15:21:14 --> Final output sent to browser
DEBUG - 2020-09-21 15:21:14 --> Total execution time: 0.0275
ERROR - 2020-09-21 15:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:22:07 --> Config Class Initialized
INFO - 2020-09-21 15:22:07 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:22:07 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:22:07 --> Utf8 Class Initialized
INFO - 2020-09-21 15:22:07 --> URI Class Initialized
INFO - 2020-09-21 15:22:07 --> Router Class Initialized
INFO - 2020-09-21 15:22:07 --> Output Class Initialized
INFO - 2020-09-21 15:22:07 --> Security Class Initialized
DEBUG - 2020-09-21 15:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:22:07 --> Input Class Initialized
INFO - 2020-09-21 15:22:07 --> Language Class Initialized
INFO - 2020-09-21 15:22:07 --> Loader Class Initialized
INFO - 2020-09-21 15:22:07 --> Helper loaded: url_helper
INFO - 2020-09-21 15:22:07 --> Database Driver Class Initialized
INFO - 2020-09-21 15:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:22:07 --> Email Class Initialized
INFO - 2020-09-21 15:22:07 --> Controller Class Initialized
DEBUG - 2020-09-21 15:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:22:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:22:07 --> Model Class Initialized
INFO - 2020-09-21 15:22:07 --> Model Class Initialized
INFO - 2020-09-21 15:22:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 15:22:07 --> Final output sent to browser
DEBUG - 2020-09-21 15:22:07 --> Total execution time: 0.0238
ERROR - 2020-09-21 15:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:22:11 --> Config Class Initialized
INFO - 2020-09-21 15:22:11 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:22:11 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:22:11 --> Utf8 Class Initialized
INFO - 2020-09-21 15:22:11 --> URI Class Initialized
INFO - 2020-09-21 15:22:11 --> Router Class Initialized
INFO - 2020-09-21 15:22:11 --> Output Class Initialized
INFO - 2020-09-21 15:22:11 --> Security Class Initialized
DEBUG - 2020-09-21 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:22:11 --> Input Class Initialized
INFO - 2020-09-21 15:22:11 --> Language Class Initialized
INFO - 2020-09-21 15:22:11 --> Loader Class Initialized
INFO - 2020-09-21 15:22:11 --> Helper loaded: url_helper
INFO - 2020-09-21 15:22:11 --> Database Driver Class Initialized
INFO - 2020-09-21 15:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:22:11 --> Email Class Initialized
INFO - 2020-09-21 15:22:11 --> Controller Class Initialized
DEBUG - 2020-09-21 15:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:22:11 --> Model Class Initialized
INFO - 2020-09-21 15:22:11 --> Model Class Initialized
INFO - 2020-09-21 15:22:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 15:22:11 --> Final output sent to browser
DEBUG - 2020-09-21 15:22:11 --> Total execution time: 0.0260
ERROR - 2020-09-21 15:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:22:26 --> Config Class Initialized
INFO - 2020-09-21 15:22:26 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:22:26 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:22:26 --> Utf8 Class Initialized
INFO - 2020-09-21 15:22:26 --> URI Class Initialized
INFO - 2020-09-21 15:22:26 --> Router Class Initialized
INFO - 2020-09-21 15:22:26 --> Output Class Initialized
INFO - 2020-09-21 15:22:26 --> Security Class Initialized
DEBUG - 2020-09-21 15:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:22:26 --> Input Class Initialized
INFO - 2020-09-21 15:22:26 --> Language Class Initialized
INFO - 2020-09-21 15:22:26 --> Loader Class Initialized
INFO - 2020-09-21 15:22:26 --> Helper loaded: url_helper
INFO - 2020-09-21 15:22:26 --> Database Driver Class Initialized
INFO - 2020-09-21 15:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:22:26 --> Email Class Initialized
INFO - 2020-09-21 15:22:26 --> Controller Class Initialized
DEBUG - 2020-09-21 15:22:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:22:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:22:26 --> Model Class Initialized
INFO - 2020-09-21 15:22:26 --> Model Class Initialized
INFO - 2020-09-21 15:22:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 15:22:26 --> Final output sent to browser
DEBUG - 2020-09-21 15:22:26 --> Total execution time: 0.0242
ERROR - 2020-09-21 15:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:22:31 --> Config Class Initialized
INFO - 2020-09-21 15:22:31 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:22:31 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:22:31 --> Utf8 Class Initialized
INFO - 2020-09-21 15:22:31 --> URI Class Initialized
INFO - 2020-09-21 15:22:31 --> Router Class Initialized
INFO - 2020-09-21 15:22:31 --> Output Class Initialized
INFO - 2020-09-21 15:22:31 --> Security Class Initialized
DEBUG - 2020-09-21 15:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:22:31 --> Input Class Initialized
INFO - 2020-09-21 15:22:31 --> Language Class Initialized
INFO - 2020-09-21 15:22:31 --> Loader Class Initialized
INFO - 2020-09-21 15:22:31 --> Helper loaded: url_helper
INFO - 2020-09-21 15:22:31 --> Database Driver Class Initialized
INFO - 2020-09-21 15:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:22:31 --> Email Class Initialized
INFO - 2020-09-21 15:22:31 --> Controller Class Initialized
DEBUG - 2020-09-21 15:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:22:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:22:31 --> Model Class Initialized
INFO - 2020-09-21 15:22:31 --> Model Class Initialized
INFO - 2020-09-21 15:22:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 15:22:31 --> Final output sent to browser
DEBUG - 2020-09-21 15:22:31 --> Total execution time: 0.0247
ERROR - 2020-09-21 15:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:22:41 --> Config Class Initialized
INFO - 2020-09-21 15:22:41 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:22:41 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:22:41 --> Utf8 Class Initialized
INFO - 2020-09-21 15:22:41 --> URI Class Initialized
INFO - 2020-09-21 15:22:41 --> Router Class Initialized
INFO - 2020-09-21 15:22:41 --> Output Class Initialized
INFO - 2020-09-21 15:22:41 --> Security Class Initialized
DEBUG - 2020-09-21 15:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:22:41 --> Input Class Initialized
INFO - 2020-09-21 15:22:41 --> Language Class Initialized
INFO - 2020-09-21 15:22:41 --> Loader Class Initialized
INFO - 2020-09-21 15:22:41 --> Helper loaded: url_helper
INFO - 2020-09-21 15:22:41 --> Database Driver Class Initialized
INFO - 2020-09-21 15:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:22:41 --> Email Class Initialized
INFO - 2020-09-21 15:22:41 --> Controller Class Initialized
DEBUG - 2020-09-21 15:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:22:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:22:41 --> Model Class Initialized
INFO - 2020-09-21 15:22:41 --> Model Class Initialized
INFO - 2020-09-21 15:22:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-21 15:22:41 --> Final output sent to browser
DEBUG - 2020-09-21 15:22:41 --> Total execution time: 0.0246
ERROR - 2020-09-21 15:22:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:22:47 --> Config Class Initialized
INFO - 2020-09-21 15:22:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:22:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:22:47 --> Utf8 Class Initialized
INFO - 2020-09-21 15:22:47 --> URI Class Initialized
INFO - 2020-09-21 15:22:47 --> Router Class Initialized
INFO - 2020-09-21 15:22:47 --> Output Class Initialized
INFO - 2020-09-21 15:22:47 --> Security Class Initialized
DEBUG - 2020-09-21 15:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:22:47 --> Input Class Initialized
INFO - 2020-09-21 15:22:47 --> Language Class Initialized
INFO - 2020-09-21 15:22:48 --> Loader Class Initialized
INFO - 2020-09-21 15:22:48 --> Helper loaded: url_helper
INFO - 2020-09-21 15:22:48 --> Database Driver Class Initialized
INFO - 2020-09-21 15:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:22:48 --> Email Class Initialized
INFO - 2020-09-21 15:22:48 --> Controller Class Initialized
DEBUG - 2020-09-21 15:22:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:22:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:22:48 --> Model Class Initialized
INFO - 2020-09-21 15:22:48 --> Model Class Initialized
INFO - 2020-09-21 15:22:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 15:22:48 --> Final output sent to browser
DEBUG - 2020-09-21 15:22:48 --> Total execution time: 0.0382
ERROR - 2020-09-21 15:23:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 15:23:01 --> Config Class Initialized
INFO - 2020-09-21 15:23:01 --> Hooks Class Initialized
DEBUG - 2020-09-21 15:23:01 --> UTF-8 Support Enabled
INFO - 2020-09-21 15:23:01 --> Utf8 Class Initialized
INFO - 2020-09-21 15:23:01 --> URI Class Initialized
INFO - 2020-09-21 15:23:01 --> Router Class Initialized
INFO - 2020-09-21 15:23:01 --> Output Class Initialized
INFO - 2020-09-21 15:23:01 --> Security Class Initialized
DEBUG - 2020-09-21 15:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 15:23:01 --> Input Class Initialized
INFO - 2020-09-21 15:23:01 --> Language Class Initialized
INFO - 2020-09-21 15:23:01 --> Loader Class Initialized
INFO - 2020-09-21 15:23:01 --> Helper loaded: url_helper
INFO - 2020-09-21 15:23:01 --> Database Driver Class Initialized
INFO - 2020-09-21 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 15:23:01 --> Email Class Initialized
INFO - 2020-09-21 15:23:01 --> Controller Class Initialized
DEBUG - 2020-09-21 15:23:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 15:23:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 15:23:01 --> Model Class Initialized
INFO - 2020-09-21 15:23:01 --> Model Class Initialized
INFO - 2020-09-21 15:23:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-21 15:23:01 --> Final output sent to browser
DEBUG - 2020-09-21 15:23:01 --> Total execution time: 0.0348
ERROR - 2020-09-21 16:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:24:47 --> Config Class Initialized
INFO - 2020-09-21 16:24:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:24:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:24:47 --> Utf8 Class Initialized
INFO - 2020-09-21 16:24:47 --> URI Class Initialized
INFO - 2020-09-21 16:24:47 --> Router Class Initialized
INFO - 2020-09-21 16:24:47 --> Output Class Initialized
INFO - 2020-09-21 16:24:47 --> Security Class Initialized
DEBUG - 2020-09-21 16:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:24:47 --> Input Class Initialized
INFO - 2020-09-21 16:24:47 --> Language Class Initialized
INFO - 2020-09-21 16:24:47 --> Loader Class Initialized
INFO - 2020-09-21 16:24:47 --> Helper loaded: url_helper
INFO - 2020-09-21 16:24:47 --> Database Driver Class Initialized
INFO - 2020-09-21 16:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:24:48 --> Email Class Initialized
INFO - 2020-09-21 16:24:48 --> Controller Class Initialized
DEBUG - 2020-09-21 16:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:24:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:24:48 --> Model Class Initialized
INFO - 2020-09-21 16:24:48 --> Model Class Initialized
INFO - 2020-09-21 16:24:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 16:24:48 --> Final output sent to browser
DEBUG - 2020-09-21 16:24:48 --> Total execution time: 0.0280
ERROR - 2020-09-21 16:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:26:06 --> Config Class Initialized
INFO - 2020-09-21 16:26:06 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:26:06 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:26:06 --> Utf8 Class Initialized
INFO - 2020-09-21 16:26:06 --> URI Class Initialized
INFO - 2020-09-21 16:26:06 --> Router Class Initialized
INFO - 2020-09-21 16:26:06 --> Output Class Initialized
INFO - 2020-09-21 16:26:06 --> Security Class Initialized
DEBUG - 2020-09-21 16:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:26:06 --> Input Class Initialized
INFO - 2020-09-21 16:26:06 --> Language Class Initialized
INFO - 2020-09-21 16:26:06 --> Loader Class Initialized
INFO - 2020-09-21 16:26:06 --> Helper loaded: url_helper
INFO - 2020-09-21 16:26:06 --> Database Driver Class Initialized
INFO - 2020-09-21 16:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:26:06 --> Email Class Initialized
INFO - 2020-09-21 16:26:06 --> Controller Class Initialized
DEBUG - 2020-09-21 16:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:26:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:26:06 --> Model Class Initialized
INFO - 2020-09-21 16:26:06 --> Model Class Initialized
INFO - 2020-09-21 16:26:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 16:26:06 --> Final output sent to browser
DEBUG - 2020-09-21 16:26:06 --> Total execution time: 0.0281
ERROR - 2020-09-21 16:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:26:57 --> Config Class Initialized
INFO - 2020-09-21 16:26:57 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:26:57 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:26:57 --> Utf8 Class Initialized
INFO - 2020-09-21 16:26:57 --> URI Class Initialized
INFO - 2020-09-21 16:26:57 --> Router Class Initialized
INFO - 2020-09-21 16:26:57 --> Output Class Initialized
INFO - 2020-09-21 16:26:57 --> Security Class Initialized
DEBUG - 2020-09-21 16:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:26:57 --> Input Class Initialized
INFO - 2020-09-21 16:26:57 --> Language Class Initialized
INFO - 2020-09-21 16:26:57 --> Loader Class Initialized
INFO - 2020-09-21 16:26:57 --> Helper loaded: url_helper
INFO - 2020-09-21 16:26:57 --> Database Driver Class Initialized
INFO - 2020-09-21 16:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:26:57 --> Email Class Initialized
INFO - 2020-09-21 16:26:57 --> Controller Class Initialized
DEBUG - 2020-09-21 16:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:26:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:26:57 --> Model Class Initialized
INFO - 2020-09-21 16:26:57 --> Model Class Initialized
INFO - 2020-09-21 16:26:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-21 16:26:57 --> Final output sent to browser
DEBUG - 2020-09-21 16:26:57 --> Total execution time: 0.0294
ERROR - 2020-09-21 16:27:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:27:05 --> Config Class Initialized
INFO - 2020-09-21 16:27:05 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:27:05 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:27:05 --> Utf8 Class Initialized
INFO - 2020-09-21 16:27:05 --> URI Class Initialized
INFO - 2020-09-21 16:27:05 --> Router Class Initialized
INFO - 2020-09-21 16:27:05 --> Output Class Initialized
INFO - 2020-09-21 16:27:05 --> Security Class Initialized
DEBUG - 2020-09-21 16:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:27:05 --> Input Class Initialized
INFO - 2020-09-21 16:27:05 --> Language Class Initialized
INFO - 2020-09-21 16:27:05 --> Loader Class Initialized
INFO - 2020-09-21 16:27:05 --> Helper loaded: url_helper
INFO - 2020-09-21 16:27:05 --> Database Driver Class Initialized
INFO - 2020-09-21 16:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:27:05 --> Email Class Initialized
INFO - 2020-09-21 16:27:05 --> Controller Class Initialized
DEBUG - 2020-09-21 16:27:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:27:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:27:05 --> Model Class Initialized
INFO - 2020-09-21 16:27:05 --> Model Class Initialized
INFO - 2020-09-21 16:27:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 16:27:05 --> Final output sent to browser
DEBUG - 2020-09-21 16:27:05 --> Total execution time: 0.0211
ERROR - 2020-09-21 16:46:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:46:09 --> Config Class Initialized
INFO - 2020-09-21 16:46:09 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:46:09 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:46:09 --> Utf8 Class Initialized
INFO - 2020-09-21 16:46:09 --> URI Class Initialized
INFO - 2020-09-21 16:46:09 --> Router Class Initialized
INFO - 2020-09-21 16:46:09 --> Output Class Initialized
INFO - 2020-09-21 16:46:09 --> Security Class Initialized
DEBUG - 2020-09-21 16:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:46:09 --> Input Class Initialized
INFO - 2020-09-21 16:46:09 --> Language Class Initialized
INFO - 2020-09-21 16:46:09 --> Loader Class Initialized
INFO - 2020-09-21 16:46:09 --> Helper loaded: url_helper
INFO - 2020-09-21 16:46:09 --> Database Driver Class Initialized
INFO - 2020-09-21 16:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:46:09 --> Email Class Initialized
INFO - 2020-09-21 16:46:09 --> Controller Class Initialized
DEBUG - 2020-09-21 16:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:46:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:46:09 --> Model Class Initialized
INFO - 2020-09-21 16:46:09 --> Model Class Initialized
INFO - 2020-09-21 16:46:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 16:46:09 --> Final output sent to browser
DEBUG - 2020-09-21 16:46:09 --> Total execution time: 0.0255
ERROR - 2020-09-21 16:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:46:20 --> Config Class Initialized
INFO - 2020-09-21 16:46:20 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:46:20 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:46:20 --> Utf8 Class Initialized
INFO - 2020-09-21 16:46:20 --> URI Class Initialized
INFO - 2020-09-21 16:46:20 --> Router Class Initialized
INFO - 2020-09-21 16:46:20 --> Output Class Initialized
INFO - 2020-09-21 16:46:20 --> Security Class Initialized
DEBUG - 2020-09-21 16:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:46:20 --> Input Class Initialized
INFO - 2020-09-21 16:46:20 --> Language Class Initialized
INFO - 2020-09-21 16:46:20 --> Loader Class Initialized
INFO - 2020-09-21 16:46:20 --> Helper loaded: url_helper
INFO - 2020-09-21 16:46:20 --> Database Driver Class Initialized
INFO - 2020-09-21 16:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:46:20 --> Email Class Initialized
INFO - 2020-09-21 16:46:20 --> Controller Class Initialized
DEBUG - 2020-09-21 16:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:46:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:46:20 --> Model Class Initialized
INFO - 2020-09-21 16:46:20 --> Model Class Initialized
INFO - 2020-09-21 16:46:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 16:46:20 --> Final output sent to browser
DEBUG - 2020-09-21 16:46:20 --> Total execution time: 0.0238
ERROR - 2020-09-21 16:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:47:30 --> Config Class Initialized
INFO - 2020-09-21 16:47:30 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:47:30 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:47:30 --> Utf8 Class Initialized
INFO - 2020-09-21 16:47:30 --> URI Class Initialized
INFO - 2020-09-21 16:47:30 --> Router Class Initialized
INFO - 2020-09-21 16:47:30 --> Output Class Initialized
INFO - 2020-09-21 16:47:30 --> Security Class Initialized
DEBUG - 2020-09-21 16:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:47:30 --> Input Class Initialized
INFO - 2020-09-21 16:47:30 --> Language Class Initialized
INFO - 2020-09-21 16:47:30 --> Loader Class Initialized
INFO - 2020-09-21 16:47:30 --> Helper loaded: url_helper
INFO - 2020-09-21 16:47:30 --> Database Driver Class Initialized
INFO - 2020-09-21 16:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:47:30 --> Email Class Initialized
INFO - 2020-09-21 16:47:30 --> Controller Class Initialized
DEBUG - 2020-09-21 16:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:47:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:47:30 --> Model Class Initialized
INFO - 2020-09-21 16:47:30 --> Model Class Initialized
INFO - 2020-09-21 16:47:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-21 16:47:30 --> Final output sent to browser
DEBUG - 2020-09-21 16:47:30 --> Total execution time: 0.0247
ERROR - 2020-09-21 16:48:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 16:48:19 --> Config Class Initialized
INFO - 2020-09-21 16:48:19 --> Hooks Class Initialized
DEBUG - 2020-09-21 16:48:19 --> UTF-8 Support Enabled
INFO - 2020-09-21 16:48:19 --> Utf8 Class Initialized
INFO - 2020-09-21 16:48:19 --> URI Class Initialized
INFO - 2020-09-21 16:48:19 --> Router Class Initialized
INFO - 2020-09-21 16:48:19 --> Output Class Initialized
INFO - 2020-09-21 16:48:19 --> Security Class Initialized
DEBUG - 2020-09-21 16:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 16:48:19 --> Input Class Initialized
INFO - 2020-09-21 16:48:19 --> Language Class Initialized
INFO - 2020-09-21 16:48:19 --> Loader Class Initialized
INFO - 2020-09-21 16:48:19 --> Helper loaded: url_helper
INFO - 2020-09-21 16:48:19 --> Database Driver Class Initialized
INFO - 2020-09-21 16:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 16:48:19 --> Email Class Initialized
INFO - 2020-09-21 16:48:19 --> Controller Class Initialized
DEBUG - 2020-09-21 16:48:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 16:48:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 16:48:19 --> Model Class Initialized
INFO - 2020-09-21 16:48:19 --> Model Class Initialized
INFO - 2020-09-21 16:48:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 16:48:19 --> Final output sent to browser
DEBUG - 2020-09-21 16:48:19 --> Total execution time: 0.0276
ERROR - 2020-09-21 17:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:02:10 --> Config Class Initialized
INFO - 2020-09-21 17:02:10 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:02:10 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:02:10 --> Utf8 Class Initialized
INFO - 2020-09-21 17:02:10 --> URI Class Initialized
INFO - 2020-09-21 17:02:10 --> Router Class Initialized
INFO - 2020-09-21 17:02:10 --> Output Class Initialized
INFO - 2020-09-21 17:02:10 --> Security Class Initialized
DEBUG - 2020-09-21 17:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:02:10 --> Input Class Initialized
INFO - 2020-09-21 17:02:10 --> Language Class Initialized
INFO - 2020-09-21 17:02:10 --> Loader Class Initialized
INFO - 2020-09-21 17:02:10 --> Helper loaded: url_helper
INFO - 2020-09-21 17:02:10 --> Database Driver Class Initialized
INFO - 2020-09-21 17:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:02:10 --> Email Class Initialized
INFO - 2020-09-21 17:02:10 --> Controller Class Initialized
DEBUG - 2020-09-21 17:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:02:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:02:10 --> Model Class Initialized
INFO - 2020-09-21 17:02:10 --> Model Class Initialized
INFO - 2020-09-21 17:02:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_view_for_client.php
INFO - 2020-09-21 17:02:10 --> Final output sent to browser
DEBUG - 2020-09-21 17:02:10 --> Total execution time: 0.0254
ERROR - 2020-09-21 17:02:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:02:14 --> Config Class Initialized
INFO - 2020-09-21 17:02:14 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:02:14 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:02:14 --> Utf8 Class Initialized
INFO - 2020-09-21 17:02:14 --> URI Class Initialized
INFO - 2020-09-21 17:02:14 --> Router Class Initialized
INFO - 2020-09-21 17:02:14 --> Output Class Initialized
INFO - 2020-09-21 17:02:14 --> Security Class Initialized
DEBUG - 2020-09-21 17:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:02:14 --> Input Class Initialized
INFO - 2020-09-21 17:02:14 --> Language Class Initialized
INFO - 2020-09-21 17:02:14 --> Loader Class Initialized
INFO - 2020-09-21 17:02:14 --> Helper loaded: url_helper
INFO - 2020-09-21 17:02:14 --> Database Driver Class Initialized
INFO - 2020-09-21 17:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:02:14 --> Email Class Initialized
INFO - 2020-09-21 17:02:14 --> Controller Class Initialized
DEBUG - 2020-09-21 17:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:02:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:02:14 --> Model Class Initialized
INFO - 2020-09-21 17:02:14 --> Model Class Initialized
INFO - 2020-09-21 17:02:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 17:02:14 --> Final output sent to browser
DEBUG - 2020-09-21 17:02:14 --> Total execution time: 0.0231
ERROR - 2020-09-21 17:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:02:17 --> Config Class Initialized
INFO - 2020-09-21 17:02:17 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:02:17 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:02:17 --> Utf8 Class Initialized
INFO - 2020-09-21 17:02:17 --> URI Class Initialized
INFO - 2020-09-21 17:02:17 --> Router Class Initialized
INFO - 2020-09-21 17:02:17 --> Output Class Initialized
INFO - 2020-09-21 17:02:17 --> Security Class Initialized
DEBUG - 2020-09-21 17:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:02:17 --> Input Class Initialized
INFO - 2020-09-21 17:02:17 --> Language Class Initialized
INFO - 2020-09-21 17:02:17 --> Loader Class Initialized
INFO - 2020-09-21 17:02:17 --> Helper loaded: url_helper
INFO - 2020-09-21 17:02:17 --> Database Driver Class Initialized
INFO - 2020-09-21 17:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:02:17 --> Email Class Initialized
INFO - 2020-09-21 17:02:17 --> Controller Class Initialized
DEBUG - 2020-09-21 17:02:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:02:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:02:17 --> Model Class Initialized
INFO - 2020-09-21 17:02:17 --> Model Class Initialized
INFO - 2020-09-21 17:02:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign_edit.php
INFO - 2020-09-21 17:02:17 --> Final output sent to browser
DEBUG - 2020-09-21 17:02:17 --> Total execution time: 0.0254
ERROR - 2020-09-21 17:02:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:02:23 --> Config Class Initialized
INFO - 2020-09-21 17:02:23 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:02:23 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:02:23 --> Utf8 Class Initialized
INFO - 2020-09-21 17:02:23 --> URI Class Initialized
INFO - 2020-09-21 17:02:23 --> Router Class Initialized
INFO - 2020-09-21 17:02:23 --> Output Class Initialized
INFO - 2020-09-21 17:02:23 --> Security Class Initialized
DEBUG - 2020-09-21 17:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:02:23 --> Input Class Initialized
INFO - 2020-09-21 17:02:23 --> Language Class Initialized
INFO - 2020-09-21 17:02:23 --> Loader Class Initialized
INFO - 2020-09-21 17:02:23 --> Helper loaded: url_helper
INFO - 2020-09-21 17:02:23 --> Database Driver Class Initialized
INFO - 2020-09-21 17:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:02:23 --> Email Class Initialized
INFO - 2020-09-21 17:02:23 --> Controller Class Initialized
DEBUG - 2020-09-21 17:02:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:02:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:02:23 --> Model Class Initialized
INFO - 2020-09-21 17:02:23 --> Model Class Initialized
INFO - 2020-09-21 17:02:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 17:02:23 --> Final output sent to browser
DEBUG - 2020-09-21 17:02:23 --> Total execution time: 0.0239
ERROR - 2020-09-21 17:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:35:52 --> Config Class Initialized
INFO - 2020-09-21 17:35:52 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:35:52 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:35:52 --> Utf8 Class Initialized
INFO - 2020-09-21 17:35:52 --> URI Class Initialized
INFO - 2020-09-21 17:35:52 --> Router Class Initialized
INFO - 2020-09-21 17:35:52 --> Output Class Initialized
INFO - 2020-09-21 17:35:52 --> Security Class Initialized
DEBUG - 2020-09-21 17:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:35:52 --> Input Class Initialized
INFO - 2020-09-21 17:35:52 --> Language Class Initialized
INFO - 2020-09-21 17:35:52 --> Loader Class Initialized
INFO - 2020-09-21 17:35:52 --> Helper loaded: url_helper
INFO - 2020-09-21 17:35:52 --> Database Driver Class Initialized
INFO - 2020-09-21 17:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:35:52 --> Email Class Initialized
INFO - 2020-09-21 17:35:52 --> Controller Class Initialized
DEBUG - 2020-09-21 17:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:35:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:35:52 --> Model Class Initialized
INFO - 2020-09-21 17:35:52 --> Model Class Initialized
INFO - 2020-09-21 17:35:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-21 17:35:52 --> Final output sent to browser
DEBUG - 2020-09-21 17:35:52 --> Total execution time: 0.0250
ERROR - 2020-09-21 17:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:35:55 --> Config Class Initialized
INFO - 2020-09-21 17:35:55 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:35:55 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:35:55 --> Utf8 Class Initialized
INFO - 2020-09-21 17:35:55 --> URI Class Initialized
INFO - 2020-09-21 17:35:55 --> Router Class Initialized
INFO - 2020-09-21 17:35:56 --> Output Class Initialized
INFO - 2020-09-21 17:35:56 --> Security Class Initialized
DEBUG - 2020-09-21 17:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:35:56 --> Input Class Initialized
INFO - 2020-09-21 17:35:56 --> Language Class Initialized
INFO - 2020-09-21 17:35:56 --> Loader Class Initialized
INFO - 2020-09-21 17:35:56 --> Helper loaded: url_helper
INFO - 2020-09-21 17:35:56 --> Database Driver Class Initialized
INFO - 2020-09-21 17:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:35:56 --> Email Class Initialized
INFO - 2020-09-21 17:35:56 --> Controller Class Initialized
DEBUG - 2020-09-21 17:35:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:35:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:35:56 --> Model Class Initialized
INFO - 2020-09-21 17:35:56 --> Model Class Initialized
INFO - 2020-09-21 17:35:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 17:35:56 --> Final output sent to browser
DEBUG - 2020-09-21 17:35:56 --> Total execution time: 0.0232
ERROR - 2020-09-21 17:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:35:59 --> Config Class Initialized
INFO - 2020-09-21 17:35:59 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:35:59 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:35:59 --> Utf8 Class Initialized
INFO - 2020-09-21 17:35:59 --> URI Class Initialized
INFO - 2020-09-21 17:35:59 --> Router Class Initialized
INFO - 2020-09-21 17:35:59 --> Output Class Initialized
INFO - 2020-09-21 17:35:59 --> Security Class Initialized
DEBUG - 2020-09-21 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:35:59 --> Input Class Initialized
INFO - 2020-09-21 17:35:59 --> Language Class Initialized
INFO - 2020-09-21 17:35:59 --> Loader Class Initialized
INFO - 2020-09-21 17:35:59 --> Helper loaded: url_helper
INFO - 2020-09-21 17:35:59 --> Database Driver Class Initialized
INFO - 2020-09-21 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:35:59 --> Email Class Initialized
INFO - 2020-09-21 17:35:59 --> Controller Class Initialized
DEBUG - 2020-09-21 17:35:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:35:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:35:59 --> Model Class Initialized
INFO - 2020-09-21 17:35:59 --> Model Class Initialized
INFO - 2020-09-21 17:35:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 17:35:59 --> Final output sent to browser
DEBUG - 2020-09-21 17:35:59 --> Total execution time: 0.0271
ERROR - 2020-09-21 17:36:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:36:21 --> Config Class Initialized
INFO - 2020-09-21 17:36:21 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:36:21 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:36:21 --> Utf8 Class Initialized
INFO - 2020-09-21 17:36:21 --> URI Class Initialized
INFO - 2020-09-21 17:36:21 --> Router Class Initialized
INFO - 2020-09-21 17:36:21 --> Output Class Initialized
INFO - 2020-09-21 17:36:21 --> Security Class Initialized
DEBUG - 2020-09-21 17:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:36:21 --> Input Class Initialized
INFO - 2020-09-21 17:36:21 --> Language Class Initialized
INFO - 2020-09-21 17:36:21 --> Loader Class Initialized
INFO - 2020-09-21 17:36:21 --> Helper loaded: url_helper
INFO - 2020-09-21 17:36:21 --> Database Driver Class Initialized
INFO - 2020-09-21 17:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:36:21 --> Email Class Initialized
INFO - 2020-09-21 17:36:21 --> Controller Class Initialized
DEBUG - 2020-09-21 17:36:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:36:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:36:21 --> Model Class Initialized
INFO - 2020-09-21 17:36:21 --> Model Class Initialized
INFO - 2020-09-21 17:36:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-21 17:36:21 --> Final output sent to browser
DEBUG - 2020-09-21 17:36:21 --> Total execution time: 0.0257
ERROR - 2020-09-21 17:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-21 17:36:47 --> Config Class Initialized
INFO - 2020-09-21 17:36:47 --> Hooks Class Initialized
DEBUG - 2020-09-21 17:36:47 --> UTF-8 Support Enabled
INFO - 2020-09-21 17:36:47 --> Utf8 Class Initialized
INFO - 2020-09-21 17:36:47 --> URI Class Initialized
INFO - 2020-09-21 17:36:47 --> Router Class Initialized
INFO - 2020-09-21 17:36:47 --> Output Class Initialized
INFO - 2020-09-21 17:36:47 --> Security Class Initialized
DEBUG - 2020-09-21 17:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-21 17:36:47 --> Input Class Initialized
INFO - 2020-09-21 17:36:47 --> Language Class Initialized
INFO - 2020-09-21 17:36:47 --> Loader Class Initialized
INFO - 2020-09-21 17:36:47 --> Helper loaded: url_helper
INFO - 2020-09-21 17:36:47 --> Database Driver Class Initialized
INFO - 2020-09-21 17:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-21 17:36:47 --> Email Class Initialized
INFO - 2020-09-21 17:36:47 --> Controller Class Initialized
DEBUG - 2020-09-21 17:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-21 17:36:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-21 17:36:47 --> Model Class Initialized
INFO - 2020-09-21 17:36:47 --> Model Class Initialized
INFO - 2020-09-21 17:36:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-21 17:36:47 --> Final output sent to browser
DEBUG - 2020-09-21 17:36:47 --> Total execution time: 0.0314
