<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-05 11:03:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:03:37 --> Config Class Initialized
INFO - 2020-12-05 11:03:37 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:03:37 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:03:37 --> Utf8 Class Initialized
INFO - 2020-12-05 11:03:37 --> URI Class Initialized
DEBUG - 2020-12-05 11:03:37 --> No URI present. Default controller set.
INFO - 2020-12-05 11:03:37 --> Router Class Initialized
INFO - 2020-12-05 11:03:37 --> Output Class Initialized
INFO - 2020-12-05 11:03:37 --> Security Class Initialized
DEBUG - 2020-12-05 11:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:03:37 --> Input Class Initialized
INFO - 2020-12-05 11:03:37 --> Language Class Initialized
INFO - 2020-12-05 11:03:37 --> Loader Class Initialized
INFO - 2020-12-05 11:03:37 --> Helper loaded: url_helper
INFO - 2020-12-05 11:03:37 --> Database Driver Class Initialized
INFO - 2020-12-05 11:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:03:37 --> Email Class Initialized
INFO - 2020-12-05 11:03:37 --> Controller Class Initialized
INFO - 2020-12-05 11:03:37 --> Model Class Initialized
INFO - 2020-12-05 11:03:37 --> Model Class Initialized
DEBUG - 2020-12-05 11:03:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:03:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-05 11:03:37 --> Final output sent to browser
DEBUG - 2020-12-05 11:03:37 --> Total execution time: 0.2404
ERROR - 2020-12-05 11:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:03:49 --> Config Class Initialized
INFO - 2020-12-05 11:03:49 --> Hooks Class Initialized
ERROR - 2020-12-05 11:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2020-12-05 11:03:49 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:03:49 --> Utf8 Class Initialized
INFO - 2020-12-05 11:03:49 --> Config Class Initialized
INFO - 2020-12-05 11:03:49 --> Hooks Class Initialized
INFO - 2020-12-05 11:03:49 --> URI Class Initialized
INFO - 2020-12-05 11:03:49 --> Router Class Initialized
DEBUG - 2020-12-05 11:03:49 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:03:49 --> Output Class Initialized
INFO - 2020-12-05 11:03:49 --> Utf8 Class Initialized
INFO - 2020-12-05 11:03:49 --> Security Class Initialized
INFO - 2020-12-05 11:03:49 --> URI Class Initialized
DEBUG - 2020-12-05 11:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:03:49 --> Input Class Initialized
INFO - 2020-12-05 11:03:49 --> Router Class Initialized
INFO - 2020-12-05 11:03:49 --> Language Class Initialized
INFO - 2020-12-05 11:03:49 --> Output Class Initialized
INFO - 2020-12-05 11:03:49 --> Loader Class Initialized
INFO - 2020-12-05 11:03:49 --> Security Class Initialized
INFO - 2020-12-05 11:03:49 --> Helper loaded: url_helper
DEBUG - 2020-12-05 11:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:03:49 --> Input Class Initialized
INFO - 2020-12-05 11:03:49 --> Language Class Initialized
INFO - 2020-12-05 11:03:49 --> Database Driver Class Initialized
INFO - 2020-12-05 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:03:49 --> Loader Class Initialized
INFO - 2020-12-05 11:03:49 --> Helper loaded: url_helper
INFO - 2020-12-05 11:03:49 --> Email Class Initialized
INFO - 2020-12-05 11:03:49 --> Controller Class Initialized
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
DEBUG - 2020-12-05 11:03:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:03:49 --> Database Driver Class Initialized
INFO - 2020-12-05 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:03:49 --> Email Class Initialized
INFO - 2020-12-05 11:03:49 --> Controller Class Initialized
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
DEBUG - 2020-12-05 11:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:03:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
INFO - 2020-12-05 11:03:49 --> Final output sent to browser
DEBUG - 2020-12-05 11:03:49 --> Total execution time: 0.0639
ERROR - 2020-12-05 11:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:03:49 --> Config Class Initialized
INFO - 2020-12-05 11:03:49 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:03:49 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:03:49 --> Utf8 Class Initialized
INFO - 2020-12-05 11:03:49 --> URI Class Initialized
INFO - 2020-12-05 11:03:49 --> Router Class Initialized
INFO - 2020-12-05 11:03:49 --> Output Class Initialized
INFO - 2020-12-05 11:03:49 --> Security Class Initialized
DEBUG - 2020-12-05 11:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:03:49 --> Input Class Initialized
INFO - 2020-12-05 11:03:49 --> Language Class Initialized
INFO - 2020-12-05 11:03:49 --> Loader Class Initialized
INFO - 2020-12-05 11:03:49 --> Helper loaded: url_helper
INFO - 2020-12-05 11:03:49 --> Database Driver Class Initialized
INFO - 2020-12-05 11:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:03:49 --> Email Class Initialized
INFO - 2020-12-05 11:03:49 --> Controller Class Initialized
DEBUG - 2020-12-05 11:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:03:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
INFO - 2020-12-05 11:03:49 --> Model Class Initialized
INFO - 2020-12-05 11:03:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-12-05 11:03:49 --> Final output sent to browser
DEBUG - 2020-12-05 11:03:49 --> Total execution time: 0.0784
ERROR - 2020-12-05 11:03:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:03:52 --> Config Class Initialized
INFO - 2020-12-05 11:03:52 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:03:52 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:03:52 --> Utf8 Class Initialized
INFO - 2020-12-05 11:03:52 --> URI Class Initialized
DEBUG - 2020-12-05 11:03:52 --> No URI present. Default controller set.
INFO - 2020-12-05 11:03:52 --> Router Class Initialized
INFO - 2020-12-05 11:03:52 --> Output Class Initialized
INFO - 2020-12-05 11:03:52 --> Security Class Initialized
DEBUG - 2020-12-05 11:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:03:52 --> Input Class Initialized
INFO - 2020-12-05 11:03:52 --> Language Class Initialized
INFO - 2020-12-05 11:03:52 --> Loader Class Initialized
INFO - 2020-12-05 11:03:52 --> Helper loaded: url_helper
INFO - 2020-12-05 11:03:52 --> Database Driver Class Initialized
INFO - 2020-12-05 11:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:03:52 --> Email Class Initialized
INFO - 2020-12-05 11:03:52 --> Controller Class Initialized
INFO - 2020-12-05 11:03:52 --> Model Class Initialized
INFO - 2020-12-05 11:03:52 --> Model Class Initialized
DEBUG - 2020-12-05 11:03:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:03:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-05 11:03:52 --> Final output sent to browser
DEBUG - 2020-12-05 11:03:52 --> Total execution time: 0.0187
ERROR - 2020-12-05 11:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:06 --> Config Class Initialized
INFO - 2020-12-05 11:04:06 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:06 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:06 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:06 --> URI Class Initialized
INFO - 2020-12-05 11:04:06 --> Router Class Initialized
INFO - 2020-12-05 11:04:06 --> Output Class Initialized
INFO - 2020-12-05 11:04:06 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:06 --> Input Class Initialized
INFO - 2020-12-05 11:04:06 --> Language Class Initialized
INFO - 2020-12-05 11:04:06 --> Loader Class Initialized
INFO - 2020-12-05 11:04:06 --> Helper loaded: url_helper
ERROR - 2020-12-05 11:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:06 --> Config Class Initialized
INFO - 2020-12-05 11:04:06 --> Hooks Class Initialized
INFO - 2020-12-05 11:04:06 --> Database Driver Class Initialized
DEBUG - 2020-12-05 11:04:06 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:06 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:06 --> URI Class Initialized
INFO - 2020-12-05 11:04:06 --> Router Class Initialized
INFO - 2020-12-05 11:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:06 --> Output Class Initialized
INFO - 2020-12-05 11:04:06 --> Security Class Initialized
INFO - 2020-12-05 11:04:06 --> Email Class Initialized
INFO - 2020-12-05 11:04:06 --> Controller Class Initialized
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
DEBUG - 2020-12-05 11:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:06 --> Input Class Initialized
INFO - 2020-12-05 11:04:06 --> Language Class Initialized
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
DEBUG - 2020-12-05 11:04:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:06 --> Loader Class Initialized
INFO - 2020-12-05 11:04:06 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:06 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:06 --> Email Class Initialized
INFO - 2020-12-05 11:04:06 --> Controller Class Initialized
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
DEBUG - 2020-12-05 11:04:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
INFO - 2020-12-05 11:04:06 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:06 --> Total execution time: 0.0224
ERROR - 2020-12-05 11:04:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:06 --> Config Class Initialized
INFO - 2020-12-05 11:04:06 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:06 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:06 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:06 --> URI Class Initialized
INFO - 2020-12-05 11:04:06 --> Router Class Initialized
INFO - 2020-12-05 11:04:06 --> Output Class Initialized
INFO - 2020-12-05 11:04:06 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:06 --> Input Class Initialized
INFO - 2020-12-05 11:04:06 --> Language Class Initialized
INFO - 2020-12-05 11:04:06 --> Loader Class Initialized
INFO - 2020-12-05 11:04:06 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:06 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:06 --> Email Class Initialized
INFO - 2020-12-05 11:04:06 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
INFO - 2020-12-05 11:04:06 --> Model Class Initialized
INFO - 2020-12-05 11:04:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 11:04:06 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:06 --> Total execution time: 0.0918
ERROR - 2020-12-05 11:04:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:27 --> Config Class Initialized
INFO - 2020-12-05 11:04:27 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:27 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:27 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:27 --> URI Class Initialized
INFO - 2020-12-05 11:04:27 --> Router Class Initialized
INFO - 2020-12-05 11:04:27 --> Output Class Initialized
INFO - 2020-12-05 11:04:27 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:27 --> Input Class Initialized
INFO - 2020-12-05 11:04:27 --> Language Class Initialized
INFO - 2020-12-05 11:04:27 --> Loader Class Initialized
INFO - 2020-12-05 11:04:27 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:27 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:27 --> Email Class Initialized
INFO - 2020-12-05 11:04:27 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:27 --> Model Class Initialized
INFO - 2020-12-05 11:04:27 --> Model Class Initialized
INFO - 2020-12-05 11:04:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-12-05 11:04:27 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:27 --> Total execution time: 0.0776
ERROR - 2020-12-05 11:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:33 --> Config Class Initialized
INFO - 2020-12-05 11:04:33 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:33 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:33 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:33 --> URI Class Initialized
INFO - 2020-12-05 11:04:33 --> Router Class Initialized
INFO - 2020-12-05 11:04:33 --> Output Class Initialized
INFO - 2020-12-05 11:04:33 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:33 --> Input Class Initialized
INFO - 2020-12-05 11:04:33 --> Language Class Initialized
INFO - 2020-12-05 11:04:33 --> Loader Class Initialized
INFO - 2020-12-05 11:04:33 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:33 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:33 --> Email Class Initialized
INFO - 2020-12-05 11:04:33 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:33 --> Model Class Initialized
INFO - 2020-12-05 11:04:33 --> Model Class Initialized
INFO - 2020-12-05 11:04:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:04:33 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:33 --> Total execution time: 0.0362
ERROR - 2020-12-05 11:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:33 --> Config Class Initialized
INFO - 2020-12-05 11:04:33 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:33 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:33 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:33 --> URI Class Initialized
INFO - 2020-12-05 11:04:33 --> Router Class Initialized
INFO - 2020-12-05 11:04:33 --> Output Class Initialized
INFO - 2020-12-05 11:04:33 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:33 --> Input Class Initialized
INFO - 2020-12-05 11:04:33 --> Language Class Initialized
INFO - 2020-12-05 11:04:33 --> Loader Class Initialized
INFO - 2020-12-05 11:04:33 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:33 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:33 --> Email Class Initialized
INFO - 2020-12-05 11:04:33 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:33 --> Model Class Initialized
INFO - 2020-12-05 11:04:33 --> Model Class Initialized
INFO - 2020-12-05 11:04:33 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:33 --> Total execution time: 0.0497
ERROR - 2020-12-05 11:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:42 --> Config Class Initialized
INFO - 2020-12-05 11:04:42 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:42 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:42 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:42 --> URI Class Initialized
INFO - 2020-12-05 11:04:42 --> Router Class Initialized
INFO - 2020-12-05 11:04:42 --> Output Class Initialized
INFO - 2020-12-05 11:04:42 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:42 --> Input Class Initialized
INFO - 2020-12-05 11:04:42 --> Language Class Initialized
INFO - 2020-12-05 11:04:42 --> Loader Class Initialized
INFO - 2020-12-05 11:04:42 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:42 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:42 --> Email Class Initialized
INFO - 2020-12-05 11:04:42 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:42 --> Model Class Initialized
INFO - 2020-12-05 11:04:42 --> Model Class Initialized
INFO - 2020-12-05 11:04:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:04:42 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:42 --> Total execution time: 0.0381
ERROR - 2020-12-05 11:04:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:43 --> Config Class Initialized
INFO - 2020-12-05 11:04:43 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:43 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:43 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:43 --> URI Class Initialized
INFO - 2020-12-05 11:04:43 --> Router Class Initialized
INFO - 2020-12-05 11:04:43 --> Output Class Initialized
INFO - 2020-12-05 11:04:43 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:43 --> Input Class Initialized
INFO - 2020-12-05 11:04:43 --> Language Class Initialized
INFO - 2020-12-05 11:04:43 --> Loader Class Initialized
INFO - 2020-12-05 11:04:43 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:43 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:43 --> Email Class Initialized
INFO - 2020-12-05 11:04:43 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:43 --> Model Class Initialized
INFO - 2020-12-05 11:04:43 --> Model Class Initialized
INFO - 2020-12-05 11:04:43 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:43 --> Total execution time: 0.0225
ERROR - 2020-12-05 11:04:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:45 --> Config Class Initialized
INFO - 2020-12-05 11:04:45 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:45 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:45 --> URI Class Initialized
INFO - 2020-12-05 11:04:45 --> Router Class Initialized
INFO - 2020-12-05 11:04:45 --> Output Class Initialized
INFO - 2020-12-05 11:04:45 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:45 --> Input Class Initialized
INFO - 2020-12-05 11:04:45 --> Language Class Initialized
INFO - 2020-12-05 11:04:45 --> Loader Class Initialized
INFO - 2020-12-05 11:04:45 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:45 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:45 --> Email Class Initialized
INFO - 2020-12-05 11:04:45 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:45 --> Model Class Initialized
INFO - 2020-12-05 11:04:45 --> Model Class Initialized
INFO - 2020-12-05 11:04:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-12-05 11:04:45 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:45 --> Total execution time: 0.0207
ERROR - 2020-12-05 11:04:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:50 --> Config Class Initialized
INFO - 2020-12-05 11:04:50 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:50 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:50 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:50 --> URI Class Initialized
INFO - 2020-12-05 11:04:50 --> Router Class Initialized
INFO - 2020-12-05 11:04:50 --> Output Class Initialized
INFO - 2020-12-05 11:04:50 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:50 --> Input Class Initialized
INFO - 2020-12-05 11:04:50 --> Language Class Initialized
INFO - 2020-12-05 11:04:50 --> Loader Class Initialized
INFO - 2020-12-05 11:04:50 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:50 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:50 --> Email Class Initialized
INFO - 2020-12-05 11:04:50 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:50 --> Model Class Initialized
INFO - 2020-12-05 11:04:50 --> Model Class Initialized
INFO - 2020-12-05 11:04:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:04:50 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:50 --> Total execution time: 0.0208
ERROR - 2020-12-05 11:04:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:51 --> Config Class Initialized
INFO - 2020-12-05 11:04:51 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:51 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:51 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:51 --> URI Class Initialized
INFO - 2020-12-05 11:04:51 --> Router Class Initialized
INFO - 2020-12-05 11:04:51 --> Output Class Initialized
INFO - 2020-12-05 11:04:51 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:51 --> Input Class Initialized
INFO - 2020-12-05 11:04:51 --> Language Class Initialized
INFO - 2020-12-05 11:04:51 --> Loader Class Initialized
INFO - 2020-12-05 11:04:51 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:51 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:51 --> Email Class Initialized
INFO - 2020-12-05 11:04:51 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:51 --> Model Class Initialized
INFO - 2020-12-05 11:04:51 --> Model Class Initialized
INFO - 2020-12-05 11:04:51 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:51 --> Total execution time: 0.0227
ERROR - 2020-12-05 11:04:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:52 --> Config Class Initialized
INFO - 2020-12-05 11:04:52 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:52 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:52 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:52 --> URI Class Initialized
INFO - 2020-12-05 11:04:52 --> Router Class Initialized
INFO - 2020-12-05 11:04:52 --> Output Class Initialized
INFO - 2020-12-05 11:04:52 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:52 --> Input Class Initialized
INFO - 2020-12-05 11:04:52 --> Language Class Initialized
INFO - 2020-12-05 11:04:52 --> Loader Class Initialized
INFO - 2020-12-05 11:04:52 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:52 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:52 --> Email Class Initialized
INFO - 2020-12-05 11:04:52 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:52 --> Model Class Initialized
INFO - 2020-12-05 11:04:52 --> Model Class Initialized
INFO - 2020-12-05 11:04:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:04:52 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:52 --> Total execution time: 0.0216
ERROR - 2020-12-05 11:04:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:53 --> Config Class Initialized
INFO - 2020-12-05 11:04:53 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:53 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:53 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:53 --> URI Class Initialized
INFO - 2020-12-05 11:04:53 --> Router Class Initialized
INFO - 2020-12-05 11:04:53 --> Output Class Initialized
INFO - 2020-12-05 11:04:53 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:53 --> Input Class Initialized
INFO - 2020-12-05 11:04:53 --> Language Class Initialized
INFO - 2020-12-05 11:04:53 --> Loader Class Initialized
INFO - 2020-12-05 11:04:53 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:53 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:53 --> Email Class Initialized
INFO - 2020-12-05 11:04:53 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:53 --> Model Class Initialized
INFO - 2020-12-05 11:04:53 --> Model Class Initialized
INFO - 2020-12-05 11:04:53 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:53 --> Total execution time: 0.0225
ERROR - 2020-12-05 11:04:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:58 --> Config Class Initialized
INFO - 2020-12-05 11:04:58 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:58 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:58 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:58 --> URI Class Initialized
INFO - 2020-12-05 11:04:58 --> Router Class Initialized
INFO - 2020-12-05 11:04:58 --> Output Class Initialized
INFO - 2020-12-05 11:04:58 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:58 --> Input Class Initialized
INFO - 2020-12-05 11:04:58 --> Language Class Initialized
INFO - 2020-12-05 11:04:58 --> Loader Class Initialized
INFO - 2020-12-05 11:04:58 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:58 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:58 --> Email Class Initialized
INFO - 2020-12-05 11:04:58 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:58 --> Model Class Initialized
INFO - 2020-12-05 11:04:58 --> Model Class Initialized
INFO - 2020-12-05 11:04:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:04:58 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:58 --> Total execution time: 0.0230
ERROR - 2020-12-05 11:04:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:04:59 --> Config Class Initialized
INFO - 2020-12-05 11:04:59 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:04:59 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:04:59 --> Utf8 Class Initialized
INFO - 2020-12-05 11:04:59 --> URI Class Initialized
INFO - 2020-12-05 11:04:59 --> Router Class Initialized
INFO - 2020-12-05 11:04:59 --> Output Class Initialized
INFO - 2020-12-05 11:04:59 --> Security Class Initialized
DEBUG - 2020-12-05 11:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:04:59 --> Input Class Initialized
INFO - 2020-12-05 11:04:59 --> Language Class Initialized
INFO - 2020-12-05 11:04:59 --> Loader Class Initialized
INFO - 2020-12-05 11:04:59 --> Helper loaded: url_helper
INFO - 2020-12-05 11:04:59 --> Database Driver Class Initialized
INFO - 2020-12-05 11:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:04:59 --> Email Class Initialized
INFO - 2020-12-05 11:04:59 --> Controller Class Initialized
DEBUG - 2020-12-05 11:04:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:04:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:04:59 --> Model Class Initialized
INFO - 2020-12-05 11:04:59 --> Model Class Initialized
INFO - 2020-12-05 11:04:59 --> Final output sent to browser
DEBUG - 2020-12-05 11:04:59 --> Total execution time: 0.0287
ERROR - 2020-12-05 11:05:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:00 --> Config Class Initialized
INFO - 2020-12-05 11:05:00 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:00 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:00 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:00 --> URI Class Initialized
INFO - 2020-12-05 11:05:00 --> Router Class Initialized
INFO - 2020-12-05 11:05:00 --> Output Class Initialized
INFO - 2020-12-05 11:05:00 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:00 --> Input Class Initialized
INFO - 2020-12-05 11:05:00 --> Language Class Initialized
INFO - 2020-12-05 11:05:00 --> Loader Class Initialized
INFO - 2020-12-05 11:05:00 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:00 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:00 --> Email Class Initialized
INFO - 2020-12-05 11:05:00 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:00 --> Model Class Initialized
INFO - 2020-12-05 11:05:00 --> Model Class Initialized
INFO - 2020-12-05 11:05:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-12-05 11:05:00 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:00 --> Total execution time: 0.0203
ERROR - 2020-12-05 11:05:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:03 --> Config Class Initialized
INFO - 2020-12-05 11:05:03 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:03 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:03 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:03 --> URI Class Initialized
INFO - 2020-12-05 11:05:03 --> Router Class Initialized
INFO - 2020-12-05 11:05:03 --> Output Class Initialized
INFO - 2020-12-05 11:05:03 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:03 --> Input Class Initialized
INFO - 2020-12-05 11:05:03 --> Language Class Initialized
INFO - 2020-12-05 11:05:03 --> Loader Class Initialized
INFO - 2020-12-05 11:05:03 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:03 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:03 --> Email Class Initialized
INFO - 2020-12-05 11:05:03 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:03 --> Model Class Initialized
INFO - 2020-12-05 11:05:03 --> Model Class Initialized
INFO - 2020-12-05 11:05:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:05:03 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:03 --> Total execution time: 0.0194
ERROR - 2020-12-05 11:05:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:04 --> Config Class Initialized
INFO - 2020-12-05 11:05:04 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:04 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:04 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:04 --> URI Class Initialized
INFO - 2020-12-05 11:05:04 --> Router Class Initialized
INFO - 2020-12-05 11:05:04 --> Output Class Initialized
INFO - 2020-12-05 11:05:04 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:04 --> Input Class Initialized
INFO - 2020-12-05 11:05:04 --> Language Class Initialized
INFO - 2020-12-05 11:05:04 --> Loader Class Initialized
INFO - 2020-12-05 11:05:04 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:04 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:04 --> Email Class Initialized
INFO - 2020-12-05 11:05:04 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:04 --> Model Class Initialized
INFO - 2020-12-05 11:05:04 --> Model Class Initialized
INFO - 2020-12-05 11:05:04 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:04 --> Total execution time: 0.0220
ERROR - 2020-12-05 11:05:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:08 --> Config Class Initialized
INFO - 2020-12-05 11:05:08 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:08 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:08 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:08 --> URI Class Initialized
INFO - 2020-12-05 11:05:08 --> Router Class Initialized
INFO - 2020-12-05 11:05:08 --> Output Class Initialized
INFO - 2020-12-05 11:05:08 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:08 --> Input Class Initialized
INFO - 2020-12-05 11:05:08 --> Language Class Initialized
INFO - 2020-12-05 11:05:08 --> Loader Class Initialized
INFO - 2020-12-05 11:05:08 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:08 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:08 --> Email Class Initialized
INFO - 2020-12-05 11:05:08 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:08 --> Model Class Initialized
INFO - 2020-12-05 11:05:08 --> Model Class Initialized
INFO - 2020-12-05 11:05:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:05:08 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:08 --> Total execution time: 0.0226
ERROR - 2020-12-05 11:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:09 --> Config Class Initialized
INFO - 2020-12-05 11:05:09 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:09 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:09 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:09 --> URI Class Initialized
INFO - 2020-12-05 11:05:09 --> Router Class Initialized
INFO - 2020-12-05 11:05:09 --> Output Class Initialized
INFO - 2020-12-05 11:05:09 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:09 --> Input Class Initialized
INFO - 2020-12-05 11:05:09 --> Language Class Initialized
INFO - 2020-12-05 11:05:09 --> Loader Class Initialized
INFO - 2020-12-05 11:05:09 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:09 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:09 --> Email Class Initialized
INFO - 2020-12-05 11:05:09 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:09 --> Model Class Initialized
INFO - 2020-12-05 11:05:09 --> Model Class Initialized
INFO - 2020-12-05 11:05:09 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:09 --> Total execution time: 0.0247
ERROR - 2020-12-05 11:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:15 --> Config Class Initialized
INFO - 2020-12-05 11:05:15 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:15 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:15 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:15 --> URI Class Initialized
INFO - 2020-12-05 11:05:15 --> Router Class Initialized
INFO - 2020-12-05 11:05:15 --> Output Class Initialized
INFO - 2020-12-05 11:05:15 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:15 --> Input Class Initialized
INFO - 2020-12-05 11:05:15 --> Language Class Initialized
INFO - 2020-12-05 11:05:15 --> Loader Class Initialized
INFO - 2020-12-05 11:05:15 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:15 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:15 --> Email Class Initialized
INFO - 2020-12-05 11:05:15 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:15 --> Model Class Initialized
INFO - 2020-12-05 11:05:15 --> Model Class Initialized
INFO - 2020-12-05 11:05:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:05:15 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:15 --> Total execution time: 0.0223
ERROR - 2020-12-05 11:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:16 --> Config Class Initialized
INFO - 2020-12-05 11:05:16 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:16 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:16 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:16 --> URI Class Initialized
INFO - 2020-12-05 11:05:16 --> Router Class Initialized
INFO - 2020-12-05 11:05:16 --> Output Class Initialized
INFO - 2020-12-05 11:05:16 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:16 --> Input Class Initialized
INFO - 2020-12-05 11:05:16 --> Language Class Initialized
INFO - 2020-12-05 11:05:16 --> Loader Class Initialized
INFO - 2020-12-05 11:05:16 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:16 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:16 --> Email Class Initialized
INFO - 2020-12-05 11:05:16 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:16 --> Model Class Initialized
INFO - 2020-12-05 11:05:16 --> Model Class Initialized
INFO - 2020-12-05 11:05:16 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:16 --> Total execution time: 0.0222
ERROR - 2020-12-05 11:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:17 --> Config Class Initialized
INFO - 2020-12-05 11:05:17 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:17 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:17 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:17 --> URI Class Initialized
INFO - 2020-12-05 11:05:17 --> Router Class Initialized
INFO - 2020-12-05 11:05:17 --> Output Class Initialized
INFO - 2020-12-05 11:05:17 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:17 --> Input Class Initialized
INFO - 2020-12-05 11:05:17 --> Language Class Initialized
INFO - 2020-12-05 11:05:17 --> Loader Class Initialized
INFO - 2020-12-05 11:05:17 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:17 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:17 --> Email Class Initialized
INFO - 2020-12-05 11:05:17 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:17 --> Model Class Initialized
INFO - 2020-12-05 11:05:17 --> Model Class Initialized
INFO - 2020-12-05 11:05:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-12-05 11:05:17 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:17 --> Total execution time: 0.0244
ERROR - 2020-12-05 11:05:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:18 --> Config Class Initialized
INFO - 2020-12-05 11:05:18 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:18 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:18 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:18 --> URI Class Initialized
INFO - 2020-12-05 11:05:18 --> Router Class Initialized
INFO - 2020-12-05 11:05:18 --> Output Class Initialized
INFO - 2020-12-05 11:05:18 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:18 --> Input Class Initialized
INFO - 2020-12-05 11:05:18 --> Language Class Initialized
INFO - 2020-12-05 11:05:18 --> Loader Class Initialized
INFO - 2020-12-05 11:05:18 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:18 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:18 --> Email Class Initialized
INFO - 2020-12-05 11:05:18 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:18 --> Model Class Initialized
INFO - 2020-12-05 11:05:18 --> Model Class Initialized
INFO - 2020-12-05 11:05:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:05:18 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:18 --> Total execution time: 0.0220
ERROR - 2020-12-05 11:05:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:19 --> Config Class Initialized
INFO - 2020-12-05 11:05:19 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:19 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:19 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:19 --> URI Class Initialized
INFO - 2020-12-05 11:05:19 --> Router Class Initialized
INFO - 2020-12-05 11:05:19 --> Output Class Initialized
INFO - 2020-12-05 11:05:19 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:19 --> Input Class Initialized
INFO - 2020-12-05 11:05:19 --> Language Class Initialized
INFO - 2020-12-05 11:05:19 --> Loader Class Initialized
INFO - 2020-12-05 11:05:19 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:19 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:19 --> Email Class Initialized
INFO - 2020-12-05 11:05:19 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:19 --> Model Class Initialized
INFO - 2020-12-05 11:05:19 --> Model Class Initialized
INFO - 2020-12-05 11:05:19 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:19 --> Total execution time: 0.0226
ERROR - 2020-12-05 11:05:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:22 --> Config Class Initialized
INFO - 2020-12-05 11:05:22 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:22 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:22 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:22 --> URI Class Initialized
INFO - 2020-12-05 11:05:22 --> Router Class Initialized
INFO - 2020-12-05 11:05:22 --> Output Class Initialized
INFO - 2020-12-05 11:05:22 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:22 --> Input Class Initialized
INFO - 2020-12-05 11:05:22 --> Language Class Initialized
INFO - 2020-12-05 11:05:22 --> Loader Class Initialized
INFO - 2020-12-05 11:05:22 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:22 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:22 --> Email Class Initialized
INFO - 2020-12-05 11:05:22 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:22 --> Model Class Initialized
INFO - 2020-12-05 11:05:22 --> Model Class Initialized
INFO - 2020-12-05 11:05:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:05:23 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:23 --> Total execution time: 1.2857
ERROR - 2020-12-05 11:05:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:23 --> Config Class Initialized
INFO - 2020-12-05 11:05:23 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:23 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:23 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:23 --> URI Class Initialized
INFO - 2020-12-05 11:05:23 --> Router Class Initialized
INFO - 2020-12-05 11:05:23 --> Output Class Initialized
INFO - 2020-12-05 11:05:23 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:23 --> Input Class Initialized
INFO - 2020-12-05 11:05:23 --> Language Class Initialized
INFO - 2020-12-05 11:05:23 --> Loader Class Initialized
INFO - 2020-12-05 11:05:23 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:23 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:23 --> Email Class Initialized
INFO - 2020-12-05 11:05:23 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:23 --> Model Class Initialized
INFO - 2020-12-05 11:05:23 --> Model Class Initialized
INFO - 2020-12-05 11:05:23 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:23 --> Total execution time: 0.0195
ERROR - 2020-12-05 11:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:26 --> Config Class Initialized
INFO - 2020-12-05 11:05:26 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:26 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:26 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:26 --> URI Class Initialized
INFO - 2020-12-05 11:05:26 --> Router Class Initialized
INFO - 2020-12-05 11:05:26 --> Output Class Initialized
INFO - 2020-12-05 11:05:26 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:26 --> Input Class Initialized
INFO - 2020-12-05 11:05:26 --> Language Class Initialized
INFO - 2020-12-05 11:05:26 --> Loader Class Initialized
INFO - 2020-12-05 11:05:26 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:26 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:26 --> Email Class Initialized
INFO - 2020-12-05 11:05:26 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:26 --> Model Class Initialized
INFO - 2020-12-05 11:05:26 --> Model Class Initialized
INFO - 2020-12-05 11:05:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:05:26 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:26 --> Total execution time: 0.0235
ERROR - 2020-12-05 11:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:05:26 --> Config Class Initialized
INFO - 2020-12-05 11:05:26 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:05:26 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:05:26 --> Utf8 Class Initialized
INFO - 2020-12-05 11:05:26 --> URI Class Initialized
INFO - 2020-12-05 11:05:26 --> Router Class Initialized
INFO - 2020-12-05 11:05:26 --> Output Class Initialized
INFO - 2020-12-05 11:05:26 --> Security Class Initialized
DEBUG - 2020-12-05 11:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:05:26 --> Input Class Initialized
INFO - 2020-12-05 11:05:26 --> Language Class Initialized
INFO - 2020-12-05 11:05:26 --> Loader Class Initialized
INFO - 2020-12-05 11:05:26 --> Helper loaded: url_helper
INFO - 2020-12-05 11:05:26 --> Database Driver Class Initialized
INFO - 2020-12-05 11:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:05:26 --> Email Class Initialized
INFO - 2020-12-05 11:05:26 --> Controller Class Initialized
DEBUG - 2020-12-05 11:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:05:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:05:26 --> Model Class Initialized
INFO - 2020-12-05 11:05:26 --> Model Class Initialized
INFO - 2020-12-05 11:05:26 --> Final output sent to browser
DEBUG - 2020-12-05 11:05:26 --> Total execution time: 0.0223
ERROR - 2020-12-05 11:06:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:06:05 --> Config Class Initialized
INFO - 2020-12-05 11:06:05 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:06:05 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:06:05 --> Utf8 Class Initialized
INFO - 2020-12-05 11:06:05 --> URI Class Initialized
INFO - 2020-12-05 11:06:05 --> Router Class Initialized
INFO - 2020-12-05 11:06:05 --> Output Class Initialized
INFO - 2020-12-05 11:06:05 --> Security Class Initialized
DEBUG - 2020-12-05 11:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:06:05 --> Input Class Initialized
INFO - 2020-12-05 11:06:05 --> Language Class Initialized
INFO - 2020-12-05 11:06:05 --> Loader Class Initialized
INFO - 2020-12-05 11:06:05 --> Helper loaded: url_helper
INFO - 2020-12-05 11:06:05 --> Database Driver Class Initialized
INFO - 2020-12-05 11:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:06:05 --> Email Class Initialized
INFO - 2020-12-05 11:06:05 --> Controller Class Initialized
DEBUG - 2020-12-05 11:06:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:06:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:06:05 --> Model Class Initialized
INFO - 2020-12-05 11:06:05 --> Model Class Initialized
INFO - 2020-12-05 11:06:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:06:07 --> Final output sent to browser
DEBUG - 2020-12-05 11:06:07 --> Total execution time: 2.8679
ERROR - 2020-12-05 11:06:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:06:08 --> Config Class Initialized
INFO - 2020-12-05 11:06:08 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:06:08 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:06:08 --> Utf8 Class Initialized
INFO - 2020-12-05 11:06:08 --> URI Class Initialized
INFO - 2020-12-05 11:06:08 --> Router Class Initialized
INFO - 2020-12-05 11:06:08 --> Output Class Initialized
INFO - 2020-12-05 11:06:08 --> Security Class Initialized
DEBUG - 2020-12-05 11:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:06:08 --> Input Class Initialized
INFO - 2020-12-05 11:06:08 --> Language Class Initialized
INFO - 2020-12-05 11:06:08 --> Loader Class Initialized
INFO - 2020-12-05 11:06:08 --> Helper loaded: url_helper
INFO - 2020-12-05 11:06:08 --> Database Driver Class Initialized
INFO - 2020-12-05 11:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:06:08 --> Email Class Initialized
INFO - 2020-12-05 11:06:08 --> Controller Class Initialized
DEBUG - 2020-12-05 11:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:06:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:06:08 --> Model Class Initialized
INFO - 2020-12-05 11:06:08 --> Model Class Initialized
INFO - 2020-12-05 11:06:08 --> Final output sent to browser
DEBUG - 2020-12-05 11:06:08 --> Total execution time: 0.0227
ERROR - 2020-12-05 11:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:06:12 --> Config Class Initialized
INFO - 2020-12-05 11:06:12 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:06:12 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:06:12 --> Utf8 Class Initialized
INFO - 2020-12-05 11:06:12 --> URI Class Initialized
INFO - 2020-12-05 11:06:12 --> Router Class Initialized
INFO - 2020-12-05 11:06:12 --> Output Class Initialized
INFO - 2020-12-05 11:06:12 --> Security Class Initialized
DEBUG - 2020-12-05 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:06:12 --> Input Class Initialized
INFO - 2020-12-05 11:06:12 --> Language Class Initialized
INFO - 2020-12-05 11:06:12 --> Loader Class Initialized
INFO - 2020-12-05 11:06:12 --> Helper loaded: url_helper
INFO - 2020-12-05 11:06:12 --> Database Driver Class Initialized
INFO - 2020-12-05 11:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:06:12 --> Email Class Initialized
INFO - 2020-12-05 11:06:12 --> Controller Class Initialized
DEBUG - 2020-12-05 11:06:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:06:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:06:12 --> Model Class Initialized
INFO - 2020-12-05 11:06:12 --> Model Class Initialized
INFO - 2020-12-05 11:06:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 11:06:12 --> Final output sent to browser
DEBUG - 2020-12-05 11:06:12 --> Total execution time: 0.0258
ERROR - 2020-12-05 11:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:13:25 --> Config Class Initialized
INFO - 2020-12-05 11:13:25 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:13:25 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:13:25 --> Utf8 Class Initialized
INFO - 2020-12-05 11:13:25 --> URI Class Initialized
INFO - 2020-12-05 11:13:25 --> Router Class Initialized
INFO - 2020-12-05 11:13:25 --> Output Class Initialized
INFO - 2020-12-05 11:13:25 --> Security Class Initialized
DEBUG - 2020-12-05 11:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:13:25 --> Input Class Initialized
INFO - 2020-12-05 11:13:25 --> Language Class Initialized
INFO - 2020-12-05 11:13:25 --> Loader Class Initialized
INFO - 2020-12-05 11:13:25 --> Helper loaded: url_helper
INFO - 2020-12-05 11:13:25 --> Database Driver Class Initialized
INFO - 2020-12-05 11:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:13:25 --> Email Class Initialized
INFO - 2020-12-05 11:13:25 --> Controller Class Initialized
DEBUG - 2020-12-05 11:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:13:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:13:25 --> Model Class Initialized
INFO - 2020-12-05 11:13:25 --> Model Class Initialized
INFO - 2020-12-05 11:13:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:13:25 --> Final output sent to browser
DEBUG - 2020-12-05 11:13:25 --> Total execution time: 0.0353
ERROR - 2020-12-05 11:13:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:13:26 --> Config Class Initialized
INFO - 2020-12-05 11:13:26 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:13:26 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:13:26 --> Utf8 Class Initialized
INFO - 2020-12-05 11:13:26 --> URI Class Initialized
INFO - 2020-12-05 11:13:26 --> Router Class Initialized
INFO - 2020-12-05 11:13:26 --> Output Class Initialized
INFO - 2020-12-05 11:13:26 --> Security Class Initialized
DEBUG - 2020-12-05 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:13:26 --> Input Class Initialized
INFO - 2020-12-05 11:13:26 --> Language Class Initialized
INFO - 2020-12-05 11:13:26 --> Loader Class Initialized
INFO - 2020-12-05 11:13:26 --> Helper loaded: url_helper
INFO - 2020-12-05 11:13:26 --> Database Driver Class Initialized
INFO - 2020-12-05 11:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:13:26 --> Email Class Initialized
INFO - 2020-12-05 11:13:26 --> Controller Class Initialized
DEBUG - 2020-12-05 11:13:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:13:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:13:26 --> Model Class Initialized
INFO - 2020-12-05 11:13:26 --> Model Class Initialized
INFO - 2020-12-05 11:13:26 --> Final output sent to browser
DEBUG - 2020-12-05 11:13:26 --> Total execution time: 0.0556
ERROR - 2020-12-05 11:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:16:42 --> Config Class Initialized
INFO - 2020-12-05 11:16:42 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:16:42 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:16:42 --> Utf8 Class Initialized
INFO - 2020-12-05 11:16:42 --> URI Class Initialized
INFO - 2020-12-05 11:16:42 --> Router Class Initialized
INFO - 2020-12-05 11:16:42 --> Output Class Initialized
INFO - 2020-12-05 11:16:42 --> Security Class Initialized
DEBUG - 2020-12-05 11:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:16:42 --> Input Class Initialized
INFO - 2020-12-05 11:16:42 --> Language Class Initialized
INFO - 2020-12-05 11:16:42 --> Loader Class Initialized
INFO - 2020-12-05 11:16:42 --> Helper loaded: url_helper
INFO - 2020-12-05 11:16:42 --> Database Driver Class Initialized
INFO - 2020-12-05 11:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:16:42 --> Email Class Initialized
INFO - 2020-12-05 11:16:42 --> Controller Class Initialized
DEBUG - 2020-12-05 11:16:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:16:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:16:42 --> Model Class Initialized
INFO - 2020-12-05 11:16:42 --> Model Class Initialized
INFO - 2020-12-05 11:16:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 11:16:43 --> Final output sent to browser
DEBUG - 2020-12-05 11:16:43 --> Total execution time: 1.0215
ERROR - 2020-12-05 11:16:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:16:44 --> Config Class Initialized
INFO - 2020-12-05 11:16:44 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:16:44 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:16:44 --> Utf8 Class Initialized
INFO - 2020-12-05 11:16:44 --> URI Class Initialized
INFO - 2020-12-05 11:16:44 --> Router Class Initialized
INFO - 2020-12-05 11:16:44 --> Output Class Initialized
INFO - 2020-12-05 11:16:44 --> Security Class Initialized
DEBUG - 2020-12-05 11:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:16:44 --> Input Class Initialized
INFO - 2020-12-05 11:16:44 --> Language Class Initialized
INFO - 2020-12-05 11:16:44 --> Loader Class Initialized
INFO - 2020-12-05 11:16:44 --> Helper loaded: url_helper
INFO - 2020-12-05 11:16:44 --> Database Driver Class Initialized
INFO - 2020-12-05 11:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:16:44 --> Email Class Initialized
INFO - 2020-12-05 11:16:44 --> Controller Class Initialized
DEBUG - 2020-12-05 11:16:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:16:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:16:44 --> Model Class Initialized
INFO - 2020-12-05 11:16:44 --> Model Class Initialized
INFO - 2020-12-05 11:16:44 --> Final output sent to browser
DEBUG - 2020-12-05 11:16:44 --> Total execution time: 0.0233
ERROR - 2020-12-05 11:17:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:17:50 --> Config Class Initialized
INFO - 2020-12-05 11:17:50 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:17:50 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:17:50 --> Utf8 Class Initialized
INFO - 2020-12-05 11:17:50 --> URI Class Initialized
INFO - 2020-12-05 11:17:50 --> Router Class Initialized
INFO - 2020-12-05 11:17:50 --> Output Class Initialized
INFO - 2020-12-05 11:17:50 --> Security Class Initialized
DEBUG - 2020-12-05 11:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:17:50 --> Input Class Initialized
INFO - 2020-12-05 11:17:50 --> Language Class Initialized
INFO - 2020-12-05 11:17:50 --> Loader Class Initialized
INFO - 2020-12-05 11:17:50 --> Helper loaded: url_helper
INFO - 2020-12-05 11:17:50 --> Database Driver Class Initialized
INFO - 2020-12-05 11:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:17:50 --> Email Class Initialized
INFO - 2020-12-05 11:17:50 --> Controller Class Initialized
DEBUG - 2020-12-05 11:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:17:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:17:50 --> Model Class Initialized
INFO - 2020-12-05 11:17:50 --> Model Class Initialized
INFO - 2020-12-05 11:17:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:17:50 --> Final output sent to browser
DEBUG - 2020-12-05 11:17:50 --> Total execution time: 0.0342
ERROR - 2020-12-05 11:17:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:17:50 --> Config Class Initialized
INFO - 2020-12-05 11:17:50 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:17:50 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:17:50 --> Utf8 Class Initialized
INFO - 2020-12-05 11:17:50 --> URI Class Initialized
INFO - 2020-12-05 11:17:50 --> Router Class Initialized
INFO - 2020-12-05 11:17:50 --> Output Class Initialized
INFO - 2020-12-05 11:17:50 --> Security Class Initialized
DEBUG - 2020-12-05 11:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:17:50 --> Input Class Initialized
INFO - 2020-12-05 11:17:50 --> Language Class Initialized
INFO - 2020-12-05 11:17:50 --> Loader Class Initialized
INFO - 2020-12-05 11:17:50 --> Helper loaded: url_helper
INFO - 2020-12-05 11:17:50 --> Database Driver Class Initialized
INFO - 2020-12-05 11:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:17:50 --> Email Class Initialized
INFO - 2020-12-05 11:17:50 --> Controller Class Initialized
DEBUG - 2020-12-05 11:17:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:17:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:17:50 --> Model Class Initialized
INFO - 2020-12-05 11:17:50 --> Model Class Initialized
INFO - 2020-12-05 11:17:50 --> Final output sent to browser
DEBUG - 2020-12-05 11:17:50 --> Total execution time: 0.0236
ERROR - 2020-12-05 11:18:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:18:15 --> Config Class Initialized
INFO - 2020-12-05 11:18:15 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:18:15 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:18:15 --> Utf8 Class Initialized
INFO - 2020-12-05 11:18:15 --> URI Class Initialized
INFO - 2020-12-05 11:18:15 --> Router Class Initialized
INFO - 2020-12-05 11:18:15 --> Output Class Initialized
INFO - 2020-12-05 11:18:15 --> Security Class Initialized
DEBUG - 2020-12-05 11:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:18:15 --> Input Class Initialized
INFO - 2020-12-05 11:18:15 --> Language Class Initialized
INFO - 2020-12-05 11:18:15 --> Loader Class Initialized
INFO - 2020-12-05 11:18:15 --> Helper loaded: url_helper
INFO - 2020-12-05 11:18:15 --> Database Driver Class Initialized
INFO - 2020-12-05 11:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:18:15 --> Email Class Initialized
INFO - 2020-12-05 11:18:15 --> Controller Class Initialized
DEBUG - 2020-12-05 11:18:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:18:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:18:15 --> Model Class Initialized
INFO - 2020-12-05 11:18:15 --> Model Class Initialized
INFO - 2020-12-05 11:18:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:18:15 --> Final output sent to browser
DEBUG - 2020-12-05 11:18:15 --> Total execution time: 0.0222
ERROR - 2020-12-05 11:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:18:16 --> Config Class Initialized
INFO - 2020-12-05 11:18:16 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:18:16 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:18:16 --> Utf8 Class Initialized
INFO - 2020-12-05 11:18:16 --> URI Class Initialized
INFO - 2020-12-05 11:18:16 --> Router Class Initialized
INFO - 2020-12-05 11:18:16 --> Output Class Initialized
INFO - 2020-12-05 11:18:16 --> Security Class Initialized
DEBUG - 2020-12-05 11:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:18:16 --> Input Class Initialized
INFO - 2020-12-05 11:18:16 --> Language Class Initialized
INFO - 2020-12-05 11:18:16 --> Loader Class Initialized
INFO - 2020-12-05 11:18:16 --> Helper loaded: url_helper
INFO - 2020-12-05 11:18:16 --> Database Driver Class Initialized
INFO - 2020-12-05 11:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:18:16 --> Email Class Initialized
INFO - 2020-12-05 11:18:16 --> Controller Class Initialized
DEBUG - 2020-12-05 11:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:18:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:18:16 --> Model Class Initialized
INFO - 2020-12-05 11:18:16 --> Model Class Initialized
INFO - 2020-12-05 11:18:16 --> Final output sent to browser
DEBUG - 2020-12-05 11:18:16 --> Total execution time: 0.0253
ERROR - 2020-12-05 11:18:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:18:45 --> Config Class Initialized
INFO - 2020-12-05 11:18:45 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:18:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:18:45 --> Utf8 Class Initialized
INFO - 2020-12-05 11:18:45 --> URI Class Initialized
INFO - 2020-12-05 11:18:45 --> Router Class Initialized
INFO - 2020-12-05 11:18:45 --> Output Class Initialized
INFO - 2020-12-05 11:18:45 --> Security Class Initialized
DEBUG - 2020-12-05 11:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:18:45 --> Input Class Initialized
INFO - 2020-12-05 11:18:45 --> Language Class Initialized
INFO - 2020-12-05 11:18:45 --> Loader Class Initialized
INFO - 2020-12-05 11:18:45 --> Helper loaded: url_helper
INFO - 2020-12-05 11:18:45 --> Database Driver Class Initialized
INFO - 2020-12-05 11:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:18:45 --> Email Class Initialized
INFO - 2020-12-05 11:18:45 --> Controller Class Initialized
DEBUG - 2020-12-05 11:18:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:18:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:18:45 --> Model Class Initialized
INFO - 2020-12-05 11:18:45 --> Model Class Initialized
INFO - 2020-12-05 11:18:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:18:48 --> Final output sent to browser
DEBUG - 2020-12-05 11:18:48 --> Total execution time: 2.2389
ERROR - 2020-12-05 11:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:18:48 --> Config Class Initialized
INFO - 2020-12-05 11:18:48 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:18:48 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:18:48 --> Utf8 Class Initialized
INFO - 2020-12-05 11:18:48 --> URI Class Initialized
INFO - 2020-12-05 11:18:48 --> Router Class Initialized
INFO - 2020-12-05 11:18:48 --> Output Class Initialized
INFO - 2020-12-05 11:18:48 --> Security Class Initialized
DEBUG - 2020-12-05 11:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:18:48 --> Input Class Initialized
INFO - 2020-12-05 11:18:48 --> Language Class Initialized
INFO - 2020-12-05 11:18:48 --> Loader Class Initialized
INFO - 2020-12-05 11:18:48 --> Helper loaded: url_helper
INFO - 2020-12-05 11:18:48 --> Database Driver Class Initialized
INFO - 2020-12-05 11:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:18:48 --> Email Class Initialized
INFO - 2020-12-05 11:18:48 --> Controller Class Initialized
DEBUG - 2020-12-05 11:18:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:18:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:18:48 --> Model Class Initialized
INFO - 2020-12-05 11:18:48 --> Model Class Initialized
INFO - 2020-12-05 11:18:48 --> Final output sent to browser
DEBUG - 2020-12-05 11:18:48 --> Total execution time: 0.0210
ERROR - 2020-12-05 11:20:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:20:20 --> Config Class Initialized
INFO - 2020-12-05 11:20:20 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:20:20 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:20:20 --> Utf8 Class Initialized
INFO - 2020-12-05 11:20:20 --> URI Class Initialized
INFO - 2020-12-05 11:20:20 --> Router Class Initialized
INFO - 2020-12-05 11:20:20 --> Output Class Initialized
INFO - 2020-12-05 11:20:20 --> Security Class Initialized
DEBUG - 2020-12-05 11:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:20:20 --> Input Class Initialized
INFO - 2020-12-05 11:20:20 --> Language Class Initialized
INFO - 2020-12-05 11:20:20 --> Loader Class Initialized
INFO - 2020-12-05 11:20:20 --> Helper loaded: url_helper
INFO - 2020-12-05 11:20:20 --> Database Driver Class Initialized
INFO - 2020-12-05 11:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:20:20 --> Email Class Initialized
INFO - 2020-12-05 11:20:20 --> Controller Class Initialized
DEBUG - 2020-12-05 11:20:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:20:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:20:20 --> Model Class Initialized
INFO - 2020-12-05 11:20:20 --> Model Class Initialized
ERROR - 2020-12-05 11:20:20 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 560
ERROR - 2020-12-05 11:20:20 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-12-05 11:20:22 --> Final output sent to browser
DEBUG - 2020-12-05 11:20:22 --> Total execution time: 1.6617
ERROR - 2020-12-05 11:22:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:22:24 --> Config Class Initialized
INFO - 2020-12-05 11:22:24 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:22:24 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:22:24 --> Utf8 Class Initialized
INFO - 2020-12-05 11:22:24 --> URI Class Initialized
INFO - 2020-12-05 11:22:24 --> Router Class Initialized
INFO - 2020-12-05 11:22:24 --> Output Class Initialized
INFO - 2020-12-05 11:22:24 --> Security Class Initialized
DEBUG - 2020-12-05 11:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:22:24 --> Input Class Initialized
INFO - 2020-12-05 11:22:24 --> Language Class Initialized
INFO - 2020-12-05 11:22:24 --> Loader Class Initialized
INFO - 2020-12-05 11:22:24 --> Helper loaded: url_helper
INFO - 2020-12-05 11:22:24 --> Database Driver Class Initialized
INFO - 2020-12-05 11:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:22:24 --> Email Class Initialized
INFO - 2020-12-05 11:22:24 --> Controller Class Initialized
DEBUG - 2020-12-05 11:22:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:22:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:22:24 --> Model Class Initialized
INFO - 2020-12-05 11:22:24 --> Model Class Initialized
ERROR - 2020-12-05 11:22:24 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 560
ERROR - 2020-12-05 11:22:24 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-12-05 11:22:25 --> Final output sent to browser
DEBUG - 2020-12-05 11:22:25 --> Total execution time: 1.4729
ERROR - 2020-12-05 11:22:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:22:27 --> Config Class Initialized
INFO - 2020-12-05 11:22:27 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:22:27 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:22:27 --> Utf8 Class Initialized
INFO - 2020-12-05 11:22:27 --> URI Class Initialized
INFO - 2020-12-05 11:22:27 --> Router Class Initialized
INFO - 2020-12-05 11:22:27 --> Output Class Initialized
INFO - 2020-12-05 11:22:27 --> Security Class Initialized
DEBUG - 2020-12-05 11:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:22:27 --> Input Class Initialized
INFO - 2020-12-05 11:22:27 --> Language Class Initialized
INFO - 2020-12-05 11:22:27 --> Loader Class Initialized
INFO - 2020-12-05 11:22:27 --> Helper loaded: url_helper
INFO - 2020-12-05 11:22:27 --> Database Driver Class Initialized
INFO - 2020-12-05 11:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:22:27 --> Email Class Initialized
INFO - 2020-12-05 11:22:27 --> Controller Class Initialized
DEBUG - 2020-12-05 11:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:22:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:22:27 --> Model Class Initialized
INFO - 2020-12-05 11:22:27 --> Model Class Initialized
ERROR - 2020-12-05 11:22:27 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 560
ERROR - 2020-12-05 11:22:27 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-12-05 11:22:29 --> Final output sent to browser
DEBUG - 2020-12-05 11:22:29 --> Total execution time: 1.4144
ERROR - 2020-12-05 11:22:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:22:54 --> Config Class Initialized
INFO - 2020-12-05 11:22:54 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:22:54 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:22:54 --> Utf8 Class Initialized
INFO - 2020-12-05 11:22:54 --> URI Class Initialized
INFO - 2020-12-05 11:22:54 --> Router Class Initialized
INFO - 2020-12-05 11:22:54 --> Output Class Initialized
INFO - 2020-12-05 11:22:54 --> Security Class Initialized
DEBUG - 2020-12-05 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:22:54 --> Input Class Initialized
INFO - 2020-12-05 11:22:54 --> Language Class Initialized
INFO - 2020-12-05 11:22:54 --> Loader Class Initialized
INFO - 2020-12-05 11:22:54 --> Helper loaded: url_helper
INFO - 2020-12-05 11:22:54 --> Database Driver Class Initialized
INFO - 2020-12-05 11:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:22:54 --> Email Class Initialized
INFO - 2020-12-05 11:22:54 --> Controller Class Initialized
DEBUG - 2020-12-05 11:22:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:22:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:22:54 --> Model Class Initialized
INFO - 2020-12-05 11:22:54 --> Model Class Initialized
ERROR - 2020-12-05 11:22:54 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 560
ERROR - 2020-12-05 11:22:54 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-12-05 11:22:55 --> Final output sent to browser
DEBUG - 2020-12-05 11:22:55 --> Total execution time: 1.5120
ERROR - 2020-12-05 11:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:32:25 --> Config Class Initialized
INFO - 2020-12-05 11:32:25 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:32:25 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:32:25 --> Utf8 Class Initialized
INFO - 2020-12-05 11:32:25 --> URI Class Initialized
INFO - 2020-12-05 11:32:25 --> Router Class Initialized
INFO - 2020-12-05 11:32:25 --> Output Class Initialized
INFO - 2020-12-05 11:32:25 --> Security Class Initialized
DEBUG - 2020-12-05 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:32:25 --> Input Class Initialized
INFO - 2020-12-05 11:32:25 --> Language Class Initialized
INFO - 2020-12-05 11:32:25 --> Loader Class Initialized
INFO - 2020-12-05 11:32:25 --> Helper loaded: url_helper
INFO - 2020-12-05 11:32:25 --> Database Driver Class Initialized
INFO - 2020-12-05 11:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:32:25 --> Email Class Initialized
INFO - 2020-12-05 11:32:25 --> Controller Class Initialized
DEBUG - 2020-12-05 11:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:32:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:32:25 --> Model Class Initialized
INFO - 2020-12-05 11:32:25 --> Model Class Initialized
INFO - 2020-12-05 11:32:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:32:25 --> Final output sent to browser
DEBUG - 2020-12-05 11:32:25 --> Total execution time: 0.0510
ERROR - 2020-12-05 11:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:32:26 --> Config Class Initialized
INFO - 2020-12-05 11:32:26 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:32:26 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:32:26 --> Utf8 Class Initialized
INFO - 2020-12-05 11:32:26 --> URI Class Initialized
INFO - 2020-12-05 11:32:26 --> Router Class Initialized
INFO - 2020-12-05 11:32:26 --> Output Class Initialized
INFO - 2020-12-05 11:32:26 --> Security Class Initialized
DEBUG - 2020-12-05 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:32:26 --> Input Class Initialized
INFO - 2020-12-05 11:32:26 --> Language Class Initialized
INFO - 2020-12-05 11:32:26 --> Loader Class Initialized
INFO - 2020-12-05 11:32:26 --> Helper loaded: url_helper
INFO - 2020-12-05 11:32:26 --> Database Driver Class Initialized
INFO - 2020-12-05 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:32:26 --> Email Class Initialized
INFO - 2020-12-05 11:32:26 --> Controller Class Initialized
DEBUG - 2020-12-05 11:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:32:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:32:26 --> Model Class Initialized
INFO - 2020-12-05 11:32:26 --> Model Class Initialized
INFO - 2020-12-05 11:32:26 --> Final output sent to browser
DEBUG - 2020-12-05 11:32:26 --> Total execution time: 0.0222
ERROR - 2020-12-05 11:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:32:28 --> Config Class Initialized
INFO - 2020-12-05 11:32:28 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:32:28 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:32:28 --> Utf8 Class Initialized
INFO - 2020-12-05 11:32:28 --> URI Class Initialized
INFO - 2020-12-05 11:32:28 --> Router Class Initialized
INFO - 2020-12-05 11:32:28 --> Output Class Initialized
INFO - 2020-12-05 11:32:28 --> Security Class Initialized
DEBUG - 2020-12-05 11:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:32:28 --> Input Class Initialized
INFO - 2020-12-05 11:32:28 --> Language Class Initialized
INFO - 2020-12-05 11:32:28 --> Loader Class Initialized
INFO - 2020-12-05 11:32:28 --> Helper loaded: url_helper
INFO - 2020-12-05 11:32:28 --> Database Driver Class Initialized
INFO - 2020-12-05 11:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:32:28 --> Email Class Initialized
INFO - 2020-12-05 11:32:28 --> Controller Class Initialized
DEBUG - 2020-12-05 11:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:32:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:32:28 --> Model Class Initialized
INFO - 2020-12-05 11:32:28 --> Model Class Initialized
INFO - 2020-12-05 11:32:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:32:31 --> Final output sent to browser
DEBUG - 2020-12-05 11:32:31 --> Total execution time: 2.4108
ERROR - 2020-12-05 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:32:31 --> Config Class Initialized
INFO - 2020-12-05 11:32:31 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:32:31 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:32:31 --> Utf8 Class Initialized
INFO - 2020-12-05 11:32:31 --> URI Class Initialized
INFO - 2020-12-05 11:32:31 --> Router Class Initialized
INFO - 2020-12-05 11:32:31 --> Output Class Initialized
INFO - 2020-12-05 11:32:31 --> Security Class Initialized
DEBUG - 2020-12-05 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:32:31 --> Input Class Initialized
INFO - 2020-12-05 11:32:31 --> Language Class Initialized
INFO - 2020-12-05 11:32:31 --> Loader Class Initialized
INFO - 2020-12-05 11:32:31 --> Helper loaded: url_helper
INFO - 2020-12-05 11:32:31 --> Database Driver Class Initialized
INFO - 2020-12-05 11:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:32:31 --> Email Class Initialized
INFO - 2020-12-05 11:32:31 --> Controller Class Initialized
DEBUG - 2020-12-05 11:32:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:32:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:32:31 --> Model Class Initialized
INFO - 2020-12-05 11:32:31 --> Model Class Initialized
INFO - 2020-12-05 11:32:31 --> Final output sent to browser
DEBUG - 2020-12-05 11:32:31 --> Total execution time: 0.0238
ERROR - 2020-12-05 11:33:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:33:46 --> Config Class Initialized
INFO - 2020-12-05 11:33:46 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:33:46 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:33:46 --> Utf8 Class Initialized
INFO - 2020-12-05 11:33:46 --> URI Class Initialized
INFO - 2020-12-05 11:33:46 --> Router Class Initialized
INFO - 2020-12-05 11:33:46 --> Output Class Initialized
INFO - 2020-12-05 11:33:46 --> Security Class Initialized
DEBUG - 2020-12-05 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:33:46 --> Input Class Initialized
INFO - 2020-12-05 11:33:46 --> Language Class Initialized
INFO - 2020-12-05 11:33:46 --> Loader Class Initialized
INFO - 2020-12-05 11:33:46 --> Helper loaded: url_helper
INFO - 2020-12-05 11:33:46 --> Database Driver Class Initialized
INFO - 2020-12-05 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:33:46 --> Email Class Initialized
INFO - 2020-12-05 11:33:46 --> Controller Class Initialized
DEBUG - 2020-12-05 11:33:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:33:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:33:46 --> Model Class Initialized
INFO - 2020-12-05 11:33:46 --> Model Class Initialized
INFO - 2020-12-05 11:33:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:33:46 --> Final output sent to browser
DEBUG - 2020-12-05 11:33:46 --> Total execution time: 0.0236
ERROR - 2020-12-05 11:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:33:47 --> Config Class Initialized
INFO - 2020-12-05 11:33:47 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:33:47 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:33:47 --> Utf8 Class Initialized
INFO - 2020-12-05 11:33:47 --> URI Class Initialized
INFO - 2020-12-05 11:33:47 --> Router Class Initialized
INFO - 2020-12-05 11:33:47 --> Output Class Initialized
INFO - 2020-12-05 11:33:47 --> Security Class Initialized
DEBUG - 2020-12-05 11:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:33:47 --> Input Class Initialized
INFO - 2020-12-05 11:33:47 --> Language Class Initialized
INFO - 2020-12-05 11:33:47 --> Loader Class Initialized
INFO - 2020-12-05 11:33:47 --> Helper loaded: url_helper
INFO - 2020-12-05 11:33:47 --> Database Driver Class Initialized
INFO - 2020-12-05 11:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:33:47 --> Email Class Initialized
INFO - 2020-12-05 11:33:47 --> Controller Class Initialized
DEBUG - 2020-12-05 11:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:33:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:33:47 --> Model Class Initialized
INFO - 2020-12-05 11:33:47 --> Model Class Initialized
INFO - 2020-12-05 11:33:47 --> Final output sent to browser
DEBUG - 2020-12-05 11:33:47 --> Total execution time: 0.0199
ERROR - 2020-12-05 11:33:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:33:49 --> Config Class Initialized
INFO - 2020-12-05 11:33:49 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:33:49 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:33:49 --> Utf8 Class Initialized
INFO - 2020-12-05 11:33:49 --> URI Class Initialized
INFO - 2020-12-05 11:33:49 --> Router Class Initialized
INFO - 2020-12-05 11:33:49 --> Output Class Initialized
INFO - 2020-12-05 11:33:49 --> Security Class Initialized
DEBUG - 2020-12-05 11:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:33:49 --> Input Class Initialized
INFO - 2020-12-05 11:33:49 --> Language Class Initialized
INFO - 2020-12-05 11:33:49 --> Loader Class Initialized
INFO - 2020-12-05 11:33:49 --> Helper loaded: url_helper
INFO - 2020-12-05 11:33:49 --> Database Driver Class Initialized
INFO - 2020-12-05 11:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:33:49 --> Email Class Initialized
INFO - 2020-12-05 11:33:49 --> Controller Class Initialized
DEBUG - 2020-12-05 11:33:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:33:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:33:49 --> Model Class Initialized
INFO - 2020-12-05 11:33:49 --> Model Class Initialized
INFO - 2020-12-05 11:33:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 11:33:52 --> Final output sent to browser
DEBUG - 2020-12-05 11:33:52 --> Total execution time: 2.8105
ERROR - 2020-12-05 11:33:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 11:33:53 --> Config Class Initialized
INFO - 2020-12-05 11:33:53 --> Hooks Class Initialized
DEBUG - 2020-12-05 11:33:53 --> UTF-8 Support Enabled
INFO - 2020-12-05 11:33:53 --> Utf8 Class Initialized
INFO - 2020-12-05 11:33:53 --> URI Class Initialized
INFO - 2020-12-05 11:33:53 --> Router Class Initialized
INFO - 2020-12-05 11:33:53 --> Output Class Initialized
INFO - 2020-12-05 11:33:53 --> Security Class Initialized
DEBUG - 2020-12-05 11:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 11:33:53 --> Input Class Initialized
INFO - 2020-12-05 11:33:53 --> Language Class Initialized
INFO - 2020-12-05 11:33:53 --> Loader Class Initialized
INFO - 2020-12-05 11:33:53 --> Helper loaded: url_helper
INFO - 2020-12-05 11:33:53 --> Database Driver Class Initialized
INFO - 2020-12-05 11:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 11:33:53 --> Email Class Initialized
INFO - 2020-12-05 11:33:53 --> Controller Class Initialized
DEBUG - 2020-12-05 11:33:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 11:33:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 11:33:53 --> Model Class Initialized
INFO - 2020-12-05 11:33:53 --> Model Class Initialized
INFO - 2020-12-05 11:33:53 --> Final output sent to browser
DEBUG - 2020-12-05 11:33:53 --> Total execution time: 0.0223
ERROR - 2020-12-05 12:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:06:43 --> Config Class Initialized
INFO - 2020-12-05 12:06:43 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:06:43 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:06:43 --> Utf8 Class Initialized
INFO - 2020-12-05 12:06:43 --> URI Class Initialized
INFO - 2020-12-05 12:06:43 --> Router Class Initialized
INFO - 2020-12-05 12:06:43 --> Output Class Initialized
INFO - 2020-12-05 12:06:43 --> Security Class Initialized
DEBUG - 2020-12-05 12:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:06:43 --> Input Class Initialized
INFO - 2020-12-05 12:06:43 --> Language Class Initialized
INFO - 2020-12-05 12:06:43 --> Loader Class Initialized
INFO - 2020-12-05 12:06:43 --> Helper loaded: url_helper
INFO - 2020-12-05 12:06:43 --> Database Driver Class Initialized
INFO - 2020-12-05 12:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:06:43 --> Email Class Initialized
INFO - 2020-12-05 12:06:43 --> Controller Class Initialized
DEBUG - 2020-12-05 12:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:06:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:06:43 --> Model Class Initialized
INFO - 2020-12-05 12:06:43 --> Model Class Initialized
INFO - 2020-12-05 12:06:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:06:43 --> Final output sent to browser
DEBUG - 2020-12-05 12:06:43 --> Total execution time: 0.0346
ERROR - 2020-12-05 12:13:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:13:36 --> Config Class Initialized
INFO - 2020-12-05 12:13:36 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:13:36 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:13:36 --> Utf8 Class Initialized
INFO - 2020-12-05 12:13:36 --> URI Class Initialized
INFO - 2020-12-05 12:13:36 --> Router Class Initialized
INFO - 2020-12-05 12:13:36 --> Output Class Initialized
INFO - 2020-12-05 12:13:36 --> Security Class Initialized
DEBUG - 2020-12-05 12:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:13:36 --> Input Class Initialized
INFO - 2020-12-05 12:13:36 --> Language Class Initialized
INFO - 2020-12-05 12:13:36 --> Loader Class Initialized
INFO - 2020-12-05 12:13:36 --> Helper loaded: url_helper
INFO - 2020-12-05 12:13:36 --> Database Driver Class Initialized
INFO - 2020-12-05 12:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:13:36 --> Email Class Initialized
INFO - 2020-12-05 12:13:36 --> Controller Class Initialized
DEBUG - 2020-12-05 12:13:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:13:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:13:36 --> Model Class Initialized
INFO - 2020-12-05 12:13:36 --> Model Class Initialized
INFO - 2020-12-05 12:13:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:13:36 --> Final output sent to browser
DEBUG - 2020-12-05 12:13:36 --> Total execution time: 0.0237
ERROR - 2020-12-05 12:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:13:37 --> Config Class Initialized
INFO - 2020-12-05 12:13:37 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:13:37 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:13:37 --> Utf8 Class Initialized
INFO - 2020-12-05 12:13:37 --> URI Class Initialized
INFO - 2020-12-05 12:13:37 --> Router Class Initialized
INFO - 2020-12-05 12:13:37 --> Output Class Initialized
INFO - 2020-12-05 12:13:37 --> Security Class Initialized
DEBUG - 2020-12-05 12:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:13:37 --> Input Class Initialized
INFO - 2020-12-05 12:13:37 --> Language Class Initialized
INFO - 2020-12-05 12:13:37 --> Loader Class Initialized
INFO - 2020-12-05 12:13:37 --> Helper loaded: url_helper
INFO - 2020-12-05 12:13:37 --> Database Driver Class Initialized
INFO - 2020-12-05 12:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:13:37 --> Email Class Initialized
INFO - 2020-12-05 12:13:37 --> Controller Class Initialized
DEBUG - 2020-12-05 12:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:13:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:13:37 --> Model Class Initialized
INFO - 2020-12-05 12:13:37 --> Model Class Initialized
INFO - 2020-12-05 12:13:37 --> Final output sent to browser
DEBUG - 2020-12-05 12:13:37 --> Total execution time: 0.0236
ERROR - 2020-12-05 12:15:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:29 --> Config Class Initialized
INFO - 2020-12-05 12:15:29 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:29 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:29 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:29 --> URI Class Initialized
INFO - 2020-12-05 12:15:29 --> Router Class Initialized
INFO - 2020-12-05 12:15:29 --> Output Class Initialized
INFO - 2020-12-05 12:15:29 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:29 --> Input Class Initialized
INFO - 2020-12-05 12:15:29 --> Language Class Initialized
INFO - 2020-12-05 12:15:29 --> Loader Class Initialized
INFO - 2020-12-05 12:15:29 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:29 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:29 --> Email Class Initialized
INFO - 2020-12-05 12:15:29 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:29 --> Model Class Initialized
INFO - 2020-12-05 12:15:29 --> Model Class Initialized
INFO - 2020-12-05 12:15:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:15:29 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:29 --> Total execution time: 0.0198
ERROR - 2020-12-05 12:15:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:30 --> Config Class Initialized
INFO - 2020-12-05 12:15:30 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:30 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:30 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:30 --> URI Class Initialized
INFO - 2020-12-05 12:15:30 --> Router Class Initialized
INFO - 2020-12-05 12:15:30 --> Output Class Initialized
INFO - 2020-12-05 12:15:30 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:30 --> Input Class Initialized
INFO - 2020-12-05 12:15:30 --> Language Class Initialized
INFO - 2020-12-05 12:15:30 --> Loader Class Initialized
INFO - 2020-12-05 12:15:30 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:30 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:30 --> Email Class Initialized
INFO - 2020-12-05 12:15:30 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:30 --> Model Class Initialized
INFO - 2020-12-05 12:15:30 --> Model Class Initialized
INFO - 2020-12-05 12:15:30 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:30 --> Total execution time: 0.0220
ERROR - 2020-12-05 12:15:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:31 --> Config Class Initialized
INFO - 2020-12-05 12:15:31 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:31 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:31 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:31 --> URI Class Initialized
INFO - 2020-12-05 12:15:31 --> Router Class Initialized
INFO - 2020-12-05 12:15:31 --> Output Class Initialized
INFO - 2020-12-05 12:15:31 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:31 --> Input Class Initialized
INFO - 2020-12-05 12:15:31 --> Language Class Initialized
INFO - 2020-12-05 12:15:31 --> Loader Class Initialized
INFO - 2020-12-05 12:15:31 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:31 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:31 --> Email Class Initialized
INFO - 2020-12-05 12:15:31 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:31 --> Model Class Initialized
INFO - 2020-12-05 12:15:31 --> Model Class Initialized
INFO - 2020-12-05 12:15:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 12:15:31 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:31 --> Total execution time: 0.0221
ERROR - 2020-12-05 12:15:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:32 --> Config Class Initialized
INFO - 2020-12-05 12:15:32 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:32 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:32 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:32 --> URI Class Initialized
INFO - 2020-12-05 12:15:32 --> Router Class Initialized
INFO - 2020-12-05 12:15:32 --> Output Class Initialized
INFO - 2020-12-05 12:15:32 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:32 --> Input Class Initialized
INFO - 2020-12-05 12:15:32 --> Language Class Initialized
INFO - 2020-12-05 12:15:32 --> Loader Class Initialized
INFO - 2020-12-05 12:15:32 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:32 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:32 --> Email Class Initialized
INFO - 2020-12-05 12:15:32 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:32 --> Model Class Initialized
INFO - 2020-12-05 12:15:32 --> Model Class Initialized
INFO - 2020-12-05 12:15:32 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:32 --> Total execution time: 0.0249
ERROR - 2020-12-05 12:15:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:33 --> Config Class Initialized
INFO - 2020-12-05 12:15:33 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:33 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:33 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:33 --> URI Class Initialized
INFO - 2020-12-05 12:15:33 --> Router Class Initialized
INFO - 2020-12-05 12:15:33 --> Output Class Initialized
INFO - 2020-12-05 12:15:33 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:33 --> Input Class Initialized
INFO - 2020-12-05 12:15:33 --> Language Class Initialized
INFO - 2020-12-05 12:15:33 --> Loader Class Initialized
INFO - 2020-12-05 12:15:33 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:33 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:33 --> Email Class Initialized
INFO - 2020-12-05 12:15:33 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:33 --> Model Class Initialized
INFO - 2020-12-05 12:15:33 --> Model Class Initialized
INFO - 2020-12-05 12:15:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:15:33 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:33 --> Total execution time: 0.0235
ERROR - 2020-12-05 12:15:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:34 --> Config Class Initialized
INFO - 2020-12-05 12:15:34 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:34 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:34 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:34 --> URI Class Initialized
INFO - 2020-12-05 12:15:34 --> Router Class Initialized
INFO - 2020-12-05 12:15:34 --> Output Class Initialized
INFO - 2020-12-05 12:15:34 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:34 --> Input Class Initialized
INFO - 2020-12-05 12:15:34 --> Language Class Initialized
INFO - 2020-12-05 12:15:34 --> Loader Class Initialized
INFO - 2020-12-05 12:15:34 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:34 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:34 --> Email Class Initialized
INFO - 2020-12-05 12:15:34 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:34 --> Model Class Initialized
INFO - 2020-12-05 12:15:34 --> Model Class Initialized
INFO - 2020-12-05 12:15:34 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:34 --> Total execution time: 0.0233
ERROR - 2020-12-05 12:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:15:38 --> Config Class Initialized
INFO - 2020-12-05 12:15:38 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:15:38 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:15:38 --> Utf8 Class Initialized
INFO - 2020-12-05 12:15:38 --> URI Class Initialized
INFO - 2020-12-05 12:15:38 --> Router Class Initialized
INFO - 2020-12-05 12:15:38 --> Output Class Initialized
INFO - 2020-12-05 12:15:38 --> Security Class Initialized
DEBUG - 2020-12-05 12:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:15:38 --> Input Class Initialized
INFO - 2020-12-05 12:15:38 --> Language Class Initialized
INFO - 2020-12-05 12:15:38 --> Loader Class Initialized
INFO - 2020-12-05 12:15:38 --> Helper loaded: url_helper
INFO - 2020-12-05 12:15:38 --> Database Driver Class Initialized
INFO - 2020-12-05 12:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:15:38 --> Email Class Initialized
INFO - 2020-12-05 12:15:38 --> Controller Class Initialized
DEBUG - 2020-12-05 12:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:15:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:15:38 --> Model Class Initialized
INFO - 2020-12-05 12:15:38 --> Model Class Initialized
INFO - 2020-12-05 12:15:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:15:38 --> Final output sent to browser
DEBUG - 2020-12-05 12:15:38 --> Total execution time: 0.0266
ERROR - 2020-12-05 12:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:08 --> Config Class Initialized
INFO - 2020-12-05 12:22:08 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:08 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:08 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:08 --> URI Class Initialized
INFO - 2020-12-05 12:22:08 --> Router Class Initialized
INFO - 2020-12-05 12:22:08 --> Output Class Initialized
INFO - 2020-12-05 12:22:08 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:08 --> Input Class Initialized
INFO - 2020-12-05 12:22:08 --> Language Class Initialized
INFO - 2020-12-05 12:22:08 --> Loader Class Initialized
INFO - 2020-12-05 12:22:08 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:08 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:08 --> Email Class Initialized
INFO - 2020-12-05 12:22:08 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:08 --> Model Class Initialized
INFO - 2020-12-05 12:22:08 --> Model Class Initialized
INFO - 2020-12-05 12:22:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 12:22:08 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:08 --> Total execution time: 0.0213
ERROR - 2020-12-05 12:22:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:09 --> Config Class Initialized
INFO - 2020-12-05 12:22:09 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:09 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:09 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:09 --> URI Class Initialized
INFO - 2020-12-05 12:22:09 --> Router Class Initialized
INFO - 2020-12-05 12:22:09 --> Output Class Initialized
INFO - 2020-12-05 12:22:09 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:09 --> Input Class Initialized
INFO - 2020-12-05 12:22:09 --> Language Class Initialized
INFO - 2020-12-05 12:22:09 --> Loader Class Initialized
INFO - 2020-12-05 12:22:09 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:09 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:09 --> Email Class Initialized
INFO - 2020-12-05 12:22:09 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:09 --> Model Class Initialized
INFO - 2020-12-05 12:22:09 --> Model Class Initialized
INFO - 2020-12-05 12:22:09 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:09 --> Total execution time: 0.0209
ERROR - 2020-12-05 12:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:11 --> Config Class Initialized
INFO - 2020-12-05 12:22:11 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:11 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:11 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:11 --> URI Class Initialized
INFO - 2020-12-05 12:22:11 --> Router Class Initialized
INFO - 2020-12-05 12:22:11 --> Output Class Initialized
INFO - 2020-12-05 12:22:11 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:11 --> Input Class Initialized
INFO - 2020-12-05 12:22:11 --> Language Class Initialized
INFO - 2020-12-05 12:22:11 --> Loader Class Initialized
INFO - 2020-12-05 12:22:11 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:11 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:11 --> Email Class Initialized
INFO - 2020-12-05 12:22:11 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:11 --> Model Class Initialized
INFO - 2020-12-05 12:22:11 --> Model Class Initialized
INFO - 2020-12-05 12:22:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:22:11 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:11 --> Total execution time: 0.0204
ERROR - 2020-12-05 12:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:12 --> Config Class Initialized
INFO - 2020-12-05 12:22:12 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:12 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:12 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:12 --> URI Class Initialized
INFO - 2020-12-05 12:22:12 --> Router Class Initialized
INFO - 2020-12-05 12:22:12 --> Output Class Initialized
INFO - 2020-12-05 12:22:12 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:12 --> Input Class Initialized
INFO - 2020-12-05 12:22:12 --> Language Class Initialized
INFO - 2020-12-05 12:22:12 --> Loader Class Initialized
INFO - 2020-12-05 12:22:12 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:12 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:12 --> Email Class Initialized
INFO - 2020-12-05 12:22:12 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:12 --> Model Class Initialized
INFO - 2020-12-05 12:22:12 --> Model Class Initialized
INFO - 2020-12-05 12:22:12 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:12 --> Total execution time: 0.0201
ERROR - 2020-12-05 12:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:14 --> Config Class Initialized
INFO - 2020-12-05 12:22:14 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:14 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:14 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:14 --> URI Class Initialized
INFO - 2020-12-05 12:22:14 --> Router Class Initialized
INFO - 2020-12-05 12:22:14 --> Output Class Initialized
INFO - 2020-12-05 12:22:14 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:14 --> Input Class Initialized
INFO - 2020-12-05 12:22:14 --> Language Class Initialized
INFO - 2020-12-05 12:22:14 --> Loader Class Initialized
INFO - 2020-12-05 12:22:14 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:14 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:14 --> Email Class Initialized
INFO - 2020-12-05 12:22:14 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:14 --> Model Class Initialized
INFO - 2020-12-05 12:22:14 --> Model Class Initialized
INFO - 2020-12-05 12:22:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:22:16 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:16 --> Total execution time: 2.3802
ERROR - 2020-12-05 12:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:17 --> Config Class Initialized
INFO - 2020-12-05 12:22:17 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:17 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:17 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:17 --> URI Class Initialized
INFO - 2020-12-05 12:22:17 --> Router Class Initialized
INFO - 2020-12-05 12:22:17 --> Output Class Initialized
INFO - 2020-12-05 12:22:17 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:17 --> Input Class Initialized
INFO - 2020-12-05 12:22:17 --> Language Class Initialized
INFO - 2020-12-05 12:22:17 --> Loader Class Initialized
INFO - 2020-12-05 12:22:17 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:17 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:17 --> Email Class Initialized
INFO - 2020-12-05 12:22:17 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:17 --> Model Class Initialized
INFO - 2020-12-05 12:22:17 --> Model Class Initialized
INFO - 2020-12-05 12:22:17 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:17 --> Total execution time: 0.0247
ERROR - 2020-12-05 12:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:22:20 --> Config Class Initialized
INFO - 2020-12-05 12:22:20 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:22:20 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:22:20 --> Utf8 Class Initialized
INFO - 2020-12-05 12:22:20 --> URI Class Initialized
INFO - 2020-12-05 12:22:20 --> Router Class Initialized
INFO - 2020-12-05 12:22:20 --> Output Class Initialized
INFO - 2020-12-05 12:22:20 --> Security Class Initialized
DEBUG - 2020-12-05 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:22:20 --> Input Class Initialized
INFO - 2020-12-05 12:22:20 --> Language Class Initialized
INFO - 2020-12-05 12:22:20 --> Loader Class Initialized
INFO - 2020-12-05 12:22:20 --> Helper loaded: url_helper
INFO - 2020-12-05 12:22:20 --> Database Driver Class Initialized
INFO - 2020-12-05 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:22:20 --> Email Class Initialized
INFO - 2020-12-05 12:22:20 --> Controller Class Initialized
DEBUG - 2020-12-05 12:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:22:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:22:20 --> Model Class Initialized
INFO - 2020-12-05 12:22:20 --> Model Class Initialized
INFO - 2020-12-05 12:22:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:22:20 --> Final output sent to browser
DEBUG - 2020-12-05 12:22:20 --> Total execution time: 0.0248
ERROR - 2020-12-05 12:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:27 --> Config Class Initialized
INFO - 2020-12-05 12:26:27 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:27 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:27 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:27 --> URI Class Initialized
INFO - 2020-12-05 12:26:27 --> Router Class Initialized
INFO - 2020-12-05 12:26:27 --> Output Class Initialized
INFO - 2020-12-05 12:26:27 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:27 --> Input Class Initialized
INFO - 2020-12-05 12:26:27 --> Language Class Initialized
INFO - 2020-12-05 12:26:27 --> Loader Class Initialized
INFO - 2020-12-05 12:26:27 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:27 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:27 --> Email Class Initialized
INFO - 2020-12-05 12:26:27 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:27 --> Model Class Initialized
INFO - 2020-12-05 12:26:27 --> Model Class Initialized
INFO - 2020-12-05 12:26:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:26:27 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:27 --> Total execution time: 0.0265
ERROR - 2020-12-05 12:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:28 --> Config Class Initialized
INFO - 2020-12-05 12:26:28 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:28 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:28 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:28 --> URI Class Initialized
INFO - 2020-12-05 12:26:28 --> Router Class Initialized
INFO - 2020-12-05 12:26:28 --> Output Class Initialized
INFO - 2020-12-05 12:26:28 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:28 --> Input Class Initialized
INFO - 2020-12-05 12:26:28 --> Language Class Initialized
INFO - 2020-12-05 12:26:28 --> Loader Class Initialized
INFO - 2020-12-05 12:26:28 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:28 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:28 --> Email Class Initialized
INFO - 2020-12-05 12:26:28 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:28 --> Model Class Initialized
INFO - 2020-12-05 12:26:28 --> Model Class Initialized
INFO - 2020-12-05 12:26:28 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:28 --> Total execution time: 0.0226
ERROR - 2020-12-05 12:26:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:30 --> Config Class Initialized
INFO - 2020-12-05 12:26:30 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:30 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:30 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:30 --> URI Class Initialized
INFO - 2020-12-05 12:26:30 --> Router Class Initialized
INFO - 2020-12-05 12:26:30 --> Output Class Initialized
INFO - 2020-12-05 12:26:30 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:30 --> Input Class Initialized
INFO - 2020-12-05 12:26:30 --> Language Class Initialized
INFO - 2020-12-05 12:26:30 --> Loader Class Initialized
INFO - 2020-12-05 12:26:30 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:30 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:30 --> Email Class Initialized
INFO - 2020-12-05 12:26:30 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:30 --> Model Class Initialized
INFO - 2020-12-05 12:26:30 --> Model Class Initialized
INFO - 2020-12-05 12:26:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:26:32 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:32 --> Total execution time: 2.2070
ERROR - 2020-12-05 12:26:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:33 --> Config Class Initialized
INFO - 2020-12-05 12:26:33 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:33 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:33 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:33 --> URI Class Initialized
INFO - 2020-12-05 12:26:33 --> Router Class Initialized
INFO - 2020-12-05 12:26:33 --> Output Class Initialized
INFO - 2020-12-05 12:26:33 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:33 --> Input Class Initialized
INFO - 2020-12-05 12:26:33 --> Language Class Initialized
INFO - 2020-12-05 12:26:33 --> Loader Class Initialized
INFO - 2020-12-05 12:26:33 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:33 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:33 --> Email Class Initialized
INFO - 2020-12-05 12:26:33 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:33 --> Model Class Initialized
INFO - 2020-12-05 12:26:33 --> Model Class Initialized
INFO - 2020-12-05 12:26:33 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:33 --> Total execution time: 0.0233
ERROR - 2020-12-05 12:26:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:37 --> Config Class Initialized
INFO - 2020-12-05 12:26:37 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:37 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:37 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:37 --> URI Class Initialized
INFO - 2020-12-05 12:26:37 --> Router Class Initialized
INFO - 2020-12-05 12:26:37 --> Output Class Initialized
INFO - 2020-12-05 12:26:37 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:37 --> Input Class Initialized
INFO - 2020-12-05 12:26:37 --> Language Class Initialized
INFO - 2020-12-05 12:26:37 --> Loader Class Initialized
INFO - 2020-12-05 12:26:37 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:37 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:37 --> Email Class Initialized
INFO - 2020-12-05 12:26:37 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:37 --> Model Class Initialized
INFO - 2020-12-05 12:26:37 --> Model Class Initialized
INFO - 2020-12-05 12:26:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:26:37 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:37 --> Total execution time: 0.0307
ERROR - 2020-12-05 12:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-12-05 12:26:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:52 --> Config Class Initialized
INFO - 2020-12-05 12:26:52 --> Hooks Class Initialized
INFO - 2020-12-05 12:26:52 --> Config Class Initialized
INFO - 2020-12-05 12:26:52 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:52 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:52 --> Utf8 Class Initialized
DEBUG - 2020-12-05 12:26:52 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:52 --> URI Class Initialized
INFO - 2020-12-05 12:26:52 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:52 --> URI Class Initialized
INFO - 2020-12-05 12:26:52 --> Router Class Initialized
INFO - 2020-12-05 12:26:52 --> Router Class Initialized
INFO - 2020-12-05 12:26:52 --> Output Class Initialized
INFO - 2020-12-05 12:26:52 --> Output Class Initialized
INFO - 2020-12-05 12:26:52 --> Security Class Initialized
INFO - 2020-12-05 12:26:52 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:52 --> Input Class Initialized
DEBUG - 2020-12-05 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:52 --> Input Class Initialized
INFO - 2020-12-05 12:26:52 --> Language Class Initialized
INFO - 2020-12-05 12:26:52 --> Language Class Initialized
INFO - 2020-12-05 12:26:52 --> Loader Class Initialized
INFO - 2020-12-05 12:26:52 --> Loader Class Initialized
INFO - 2020-12-05 12:26:52 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:52 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:52 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:52 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:52 --> Email Class Initialized
INFO - 2020-12-05 12:26:52 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:52 --> Model Class Initialized
INFO - 2020-12-05 12:26:52 --> Model Class Initialized
INFO - 2020-12-05 12:26:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:26:52 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:52 --> Total execution time: 0.0338
INFO - 2020-12-05 12:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:52 --> Email Class Initialized
INFO - 2020-12-05 12:26:52 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:52 --> Model Class Initialized
INFO - 2020-12-05 12:26:52 --> Model Class Initialized
INFO - 2020-12-05 12:26:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:26:52 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:52 --> Total execution time: 0.0470
ERROR - 2020-12-05 12:26:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:53 --> Config Class Initialized
INFO - 2020-12-05 12:26:53 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:53 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:53 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:53 --> URI Class Initialized
INFO - 2020-12-05 12:26:53 --> Router Class Initialized
INFO - 2020-12-05 12:26:53 --> Output Class Initialized
INFO - 2020-12-05 12:26:53 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:53 --> Input Class Initialized
INFO - 2020-12-05 12:26:53 --> Language Class Initialized
INFO - 2020-12-05 12:26:53 --> Loader Class Initialized
INFO - 2020-12-05 12:26:53 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:53 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:53 --> Email Class Initialized
INFO - 2020-12-05 12:26:53 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:53 --> Model Class Initialized
INFO - 2020-12-05 12:26:53 --> Model Class Initialized
INFO - 2020-12-05 12:26:53 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:53 --> Total execution time: 0.0258
ERROR - 2020-12-05 12:26:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:56 --> Config Class Initialized
INFO - 2020-12-05 12:26:56 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:56 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:56 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:56 --> URI Class Initialized
INFO - 2020-12-05 12:26:56 --> Router Class Initialized
INFO - 2020-12-05 12:26:56 --> Output Class Initialized
INFO - 2020-12-05 12:26:56 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:56 --> Input Class Initialized
INFO - 2020-12-05 12:26:56 --> Language Class Initialized
INFO - 2020-12-05 12:26:56 --> Loader Class Initialized
INFO - 2020-12-05 12:26:56 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:56 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:56 --> Email Class Initialized
INFO - 2020-12-05 12:26:56 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:56 --> Model Class Initialized
INFO - 2020-12-05 12:26:56 --> Model Class Initialized
INFO - 2020-12-05 12:26:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:26:59 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:59 --> Total execution time: 2.3031
ERROR - 2020-12-05 12:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:26:59 --> Config Class Initialized
INFO - 2020-12-05 12:26:59 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:26:59 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:26:59 --> Utf8 Class Initialized
INFO - 2020-12-05 12:26:59 --> URI Class Initialized
INFO - 2020-12-05 12:26:59 --> Router Class Initialized
INFO - 2020-12-05 12:26:59 --> Output Class Initialized
INFO - 2020-12-05 12:26:59 --> Security Class Initialized
DEBUG - 2020-12-05 12:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:26:59 --> Input Class Initialized
INFO - 2020-12-05 12:26:59 --> Language Class Initialized
INFO - 2020-12-05 12:26:59 --> Loader Class Initialized
INFO - 2020-12-05 12:26:59 --> Helper loaded: url_helper
INFO - 2020-12-05 12:26:59 --> Database Driver Class Initialized
INFO - 2020-12-05 12:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:26:59 --> Email Class Initialized
INFO - 2020-12-05 12:26:59 --> Controller Class Initialized
DEBUG - 2020-12-05 12:26:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:26:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:26:59 --> Model Class Initialized
INFO - 2020-12-05 12:26:59 --> Model Class Initialized
INFO - 2020-12-05 12:26:59 --> Final output sent to browser
DEBUG - 2020-12-05 12:26:59 --> Total execution time: 0.0222
ERROR - 2020-12-05 12:27:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:27:02 --> Config Class Initialized
INFO - 2020-12-05 12:27:02 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:27:02 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:27:02 --> Utf8 Class Initialized
INFO - 2020-12-05 12:27:02 --> URI Class Initialized
INFO - 2020-12-05 12:27:02 --> Router Class Initialized
INFO - 2020-12-05 12:27:02 --> Output Class Initialized
INFO - 2020-12-05 12:27:02 --> Security Class Initialized
DEBUG - 2020-12-05 12:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:27:02 --> Input Class Initialized
INFO - 2020-12-05 12:27:02 --> Language Class Initialized
INFO - 2020-12-05 12:27:02 --> Loader Class Initialized
INFO - 2020-12-05 12:27:02 --> Helper loaded: url_helper
INFO - 2020-12-05 12:27:02 --> Database Driver Class Initialized
INFO - 2020-12-05 12:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:27:02 --> Email Class Initialized
INFO - 2020-12-05 12:27:02 --> Controller Class Initialized
DEBUG - 2020-12-05 12:27:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:27:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:27:02 --> Model Class Initialized
INFO - 2020-12-05 12:27:02 --> Model Class Initialized
INFO - 2020-12-05 12:27:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:27:02 --> Final output sent to browser
DEBUG - 2020-12-05 12:27:02 --> Total execution time: 0.0304
ERROR - 2020-12-05 12:28:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:18 --> Config Class Initialized
INFO - 2020-12-05 12:28:18 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:18 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:18 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:18 --> URI Class Initialized
INFO - 2020-12-05 12:28:18 --> Router Class Initialized
INFO - 2020-12-05 12:28:18 --> Output Class Initialized
INFO - 2020-12-05 12:28:18 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:18 --> Input Class Initialized
INFO - 2020-12-05 12:28:18 --> Language Class Initialized
INFO - 2020-12-05 12:28:18 --> Loader Class Initialized
INFO - 2020-12-05 12:28:18 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:18 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:18 --> Email Class Initialized
INFO - 2020-12-05 12:28:18 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:18 --> Model Class Initialized
INFO - 2020-12-05 12:28:18 --> Model Class Initialized
INFO - 2020-12-05 12:28:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-12-05 12:28:18 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:18 --> Total execution time: 0.0312
ERROR - 2020-12-05 12:28:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:19 --> Config Class Initialized
INFO - 2020-12-05 12:28:19 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:19 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:19 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:19 --> URI Class Initialized
INFO - 2020-12-05 12:28:19 --> Router Class Initialized
INFO - 2020-12-05 12:28:19 --> Output Class Initialized
INFO - 2020-12-05 12:28:19 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:19 --> Input Class Initialized
INFO - 2020-12-05 12:28:19 --> Language Class Initialized
INFO - 2020-12-05 12:28:19 --> Loader Class Initialized
INFO - 2020-12-05 12:28:19 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:19 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:19 --> Email Class Initialized
INFO - 2020-12-05 12:28:19 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:19 --> Model Class Initialized
INFO - 2020-12-05 12:28:19 --> Model Class Initialized
INFO - 2020-12-05 12:28:19 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:19 --> Total execution time: 0.0243
ERROR - 2020-12-05 12:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:20 --> Config Class Initialized
INFO - 2020-12-05 12:28:20 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:20 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:20 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:20 --> URI Class Initialized
INFO - 2020-12-05 12:28:20 --> Router Class Initialized
INFO - 2020-12-05 12:28:20 --> Output Class Initialized
INFO - 2020-12-05 12:28:20 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:20 --> Input Class Initialized
INFO - 2020-12-05 12:28:20 --> Language Class Initialized
INFO - 2020-12-05 12:28:20 --> Loader Class Initialized
INFO - 2020-12-05 12:28:20 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:20 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:20 --> Email Class Initialized
INFO - 2020-12-05 12:28:20 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:20 --> Model Class Initialized
INFO - 2020-12-05 12:28:20 --> Model Class Initialized
INFO - 2020-12-05 12:28:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:28:20 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:20 --> Total execution time: 0.0242
ERROR - 2020-12-05 12:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:20 --> Config Class Initialized
INFO - 2020-12-05 12:28:20 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:20 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:20 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:20 --> URI Class Initialized
INFO - 2020-12-05 12:28:20 --> Router Class Initialized
INFO - 2020-12-05 12:28:20 --> Output Class Initialized
INFO - 2020-12-05 12:28:20 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:20 --> Input Class Initialized
INFO - 2020-12-05 12:28:20 --> Language Class Initialized
INFO - 2020-12-05 12:28:20 --> Loader Class Initialized
INFO - 2020-12-05 12:28:20 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:20 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:20 --> Email Class Initialized
INFO - 2020-12-05 12:28:20 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:20 --> Model Class Initialized
INFO - 2020-12-05 12:28:20 --> Model Class Initialized
INFO - 2020-12-05 12:28:20 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:20 --> Total execution time: 0.0195
ERROR - 2020-12-05 12:28:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:23 --> Config Class Initialized
INFO - 2020-12-05 12:28:23 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:23 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:23 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:23 --> URI Class Initialized
INFO - 2020-12-05 12:28:23 --> Router Class Initialized
INFO - 2020-12-05 12:28:23 --> Output Class Initialized
INFO - 2020-12-05 12:28:23 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:23 --> Input Class Initialized
INFO - 2020-12-05 12:28:23 --> Language Class Initialized
INFO - 2020-12-05 12:28:23 --> Loader Class Initialized
INFO - 2020-12-05 12:28:23 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:23 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:23 --> Email Class Initialized
INFO - 2020-12-05 12:28:23 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:23 --> Model Class Initialized
INFO - 2020-12-05 12:28:23 --> Model Class Initialized
INFO - 2020-12-05 12:28:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:28:25 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:25 --> Total execution time: 2.1331
ERROR - 2020-12-05 12:28:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:26 --> Config Class Initialized
INFO - 2020-12-05 12:28:26 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:26 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:26 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:26 --> URI Class Initialized
INFO - 2020-12-05 12:28:26 --> Router Class Initialized
INFO - 2020-12-05 12:28:26 --> Output Class Initialized
INFO - 2020-12-05 12:28:26 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:26 --> Input Class Initialized
INFO - 2020-12-05 12:28:26 --> Language Class Initialized
INFO - 2020-12-05 12:28:26 --> Loader Class Initialized
INFO - 2020-12-05 12:28:26 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:26 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:26 --> Email Class Initialized
INFO - 2020-12-05 12:28:26 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:26 --> Model Class Initialized
INFO - 2020-12-05 12:28:26 --> Model Class Initialized
INFO - 2020-12-05 12:28:26 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:26 --> Total execution time: 0.0229
ERROR - 2020-12-05 12:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:28:28 --> Config Class Initialized
INFO - 2020-12-05 12:28:28 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:28:28 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:28:28 --> Utf8 Class Initialized
INFO - 2020-12-05 12:28:28 --> URI Class Initialized
INFO - 2020-12-05 12:28:28 --> Router Class Initialized
INFO - 2020-12-05 12:28:28 --> Output Class Initialized
INFO - 2020-12-05 12:28:28 --> Security Class Initialized
DEBUG - 2020-12-05 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:28:28 --> Input Class Initialized
INFO - 2020-12-05 12:28:28 --> Language Class Initialized
INFO - 2020-12-05 12:28:28 --> Loader Class Initialized
INFO - 2020-12-05 12:28:28 --> Helper loaded: url_helper
INFO - 2020-12-05 12:28:28 --> Database Driver Class Initialized
INFO - 2020-12-05 12:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:28:28 --> Email Class Initialized
INFO - 2020-12-05 12:28:28 --> Controller Class Initialized
DEBUG - 2020-12-05 12:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:28:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:28:28 --> Model Class Initialized
INFO - 2020-12-05 12:28:28 --> Model Class Initialized
INFO - 2020-12-05 12:28:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:28:28 --> Final output sent to browser
DEBUG - 2020-12-05 12:28:28 --> Total execution time: 0.0257
ERROR - 2020-12-05 12:30:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:30:50 --> Config Class Initialized
INFO - 2020-12-05 12:30:50 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:30:50 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:30:50 --> Utf8 Class Initialized
INFO - 2020-12-05 12:30:50 --> URI Class Initialized
INFO - 2020-12-05 12:30:50 --> Router Class Initialized
INFO - 2020-12-05 12:30:50 --> Output Class Initialized
INFO - 2020-12-05 12:30:50 --> Security Class Initialized
DEBUG - 2020-12-05 12:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:30:50 --> Input Class Initialized
INFO - 2020-12-05 12:30:50 --> Language Class Initialized
INFO - 2020-12-05 12:30:50 --> Loader Class Initialized
INFO - 2020-12-05 12:30:50 --> Helper loaded: url_helper
INFO - 2020-12-05 12:30:50 --> Database Driver Class Initialized
INFO - 2020-12-05 12:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:30:50 --> Email Class Initialized
INFO - 2020-12-05 12:30:50 --> Controller Class Initialized
DEBUG - 2020-12-05 12:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:30:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:30:50 --> Model Class Initialized
INFO - 2020-12-05 12:30:50 --> Model Class Initialized
INFO - 2020-12-05 12:30:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:30:50 --> Final output sent to browser
DEBUG - 2020-12-05 12:30:50 --> Total execution time: 0.0280
ERROR - 2020-12-05 12:30:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:30:51 --> Config Class Initialized
INFO - 2020-12-05 12:30:51 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:30:51 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:30:51 --> Utf8 Class Initialized
INFO - 2020-12-05 12:30:51 --> URI Class Initialized
INFO - 2020-12-05 12:30:51 --> Router Class Initialized
INFO - 2020-12-05 12:30:51 --> Output Class Initialized
INFO - 2020-12-05 12:30:51 --> Security Class Initialized
DEBUG - 2020-12-05 12:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:30:51 --> Input Class Initialized
INFO - 2020-12-05 12:30:51 --> Language Class Initialized
INFO - 2020-12-05 12:30:51 --> Loader Class Initialized
INFO - 2020-12-05 12:30:51 --> Helper loaded: url_helper
INFO - 2020-12-05 12:30:51 --> Database Driver Class Initialized
INFO - 2020-12-05 12:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:30:51 --> Email Class Initialized
INFO - 2020-12-05 12:30:51 --> Controller Class Initialized
DEBUG - 2020-12-05 12:30:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:30:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:30:51 --> Model Class Initialized
INFO - 2020-12-05 12:30:51 --> Model Class Initialized
INFO - 2020-12-05 12:30:51 --> Final output sent to browser
DEBUG - 2020-12-05 12:30:51 --> Total execution time: 0.0222
ERROR - 2020-12-05 12:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:30:54 --> Config Class Initialized
INFO - 2020-12-05 12:30:54 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:30:54 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:30:54 --> Utf8 Class Initialized
INFO - 2020-12-05 12:30:54 --> URI Class Initialized
INFO - 2020-12-05 12:30:54 --> Router Class Initialized
INFO - 2020-12-05 12:30:54 --> Output Class Initialized
INFO - 2020-12-05 12:30:54 --> Security Class Initialized
DEBUG - 2020-12-05 12:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:30:54 --> Input Class Initialized
INFO - 2020-12-05 12:30:54 --> Language Class Initialized
INFO - 2020-12-05 12:30:54 --> Loader Class Initialized
INFO - 2020-12-05 12:30:54 --> Helper loaded: url_helper
INFO - 2020-12-05 12:30:54 --> Database Driver Class Initialized
INFO - 2020-12-05 12:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:30:54 --> Email Class Initialized
INFO - 2020-12-05 12:30:54 --> Controller Class Initialized
DEBUG - 2020-12-05 12:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:30:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:30:54 --> Model Class Initialized
INFO - 2020-12-05 12:30:54 --> Model Class Initialized
INFO - 2020-12-05 12:30:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 12:30:56 --> Final output sent to browser
DEBUG - 2020-12-05 12:30:56 --> Total execution time: 2.1227
ERROR - 2020-12-05 12:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:30:56 --> Config Class Initialized
INFO - 2020-12-05 12:30:56 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:30:56 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:30:56 --> Utf8 Class Initialized
INFO - 2020-12-05 12:30:56 --> URI Class Initialized
INFO - 2020-12-05 12:30:56 --> Router Class Initialized
INFO - 2020-12-05 12:30:56 --> Output Class Initialized
INFO - 2020-12-05 12:30:56 --> Security Class Initialized
DEBUG - 2020-12-05 12:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:30:56 --> Input Class Initialized
INFO - 2020-12-05 12:30:56 --> Language Class Initialized
INFO - 2020-12-05 12:30:56 --> Loader Class Initialized
INFO - 2020-12-05 12:30:56 --> Helper loaded: url_helper
INFO - 2020-12-05 12:30:56 --> Database Driver Class Initialized
INFO - 2020-12-05 12:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:30:56 --> Email Class Initialized
INFO - 2020-12-05 12:30:56 --> Controller Class Initialized
DEBUG - 2020-12-05 12:30:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:30:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:30:56 --> Model Class Initialized
INFO - 2020-12-05 12:30:56 --> Model Class Initialized
INFO - 2020-12-05 12:30:56 --> Final output sent to browser
DEBUG - 2020-12-05 12:30:56 --> Total execution time: 0.0237
ERROR - 2020-12-05 12:30:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 12:30:59 --> Config Class Initialized
INFO - 2020-12-05 12:30:59 --> Hooks Class Initialized
DEBUG - 2020-12-05 12:30:59 --> UTF-8 Support Enabled
INFO - 2020-12-05 12:30:59 --> Utf8 Class Initialized
INFO - 2020-12-05 12:30:59 --> URI Class Initialized
INFO - 2020-12-05 12:30:59 --> Router Class Initialized
INFO - 2020-12-05 12:30:59 --> Output Class Initialized
INFO - 2020-12-05 12:30:59 --> Security Class Initialized
DEBUG - 2020-12-05 12:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 12:30:59 --> Input Class Initialized
INFO - 2020-12-05 12:30:59 --> Language Class Initialized
INFO - 2020-12-05 12:30:59 --> Loader Class Initialized
INFO - 2020-12-05 12:30:59 --> Helper loaded: url_helper
INFO - 2020-12-05 12:30:59 --> Database Driver Class Initialized
INFO - 2020-12-05 12:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 12:30:59 --> Email Class Initialized
INFO - 2020-12-05 12:30:59 --> Controller Class Initialized
DEBUG - 2020-12-05 12:30:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 12:30:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 12:30:59 --> Model Class Initialized
INFO - 2020-12-05 12:30:59 --> Model Class Initialized
INFO - 2020-12-05 12:30:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 12:30:59 --> Final output sent to browser
DEBUG - 2020-12-05 12:30:59 --> Total execution time: 0.0320
ERROR - 2020-12-05 14:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:23:37 --> Config Class Initialized
INFO - 2020-12-05 14:23:37 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:23:37 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:23:37 --> Utf8 Class Initialized
INFO - 2020-12-05 14:23:37 --> URI Class Initialized
DEBUG - 2020-12-05 14:23:37 --> No URI present. Default controller set.
INFO - 2020-12-05 14:23:37 --> Router Class Initialized
INFO - 2020-12-05 14:23:37 --> Output Class Initialized
INFO - 2020-12-05 14:23:37 --> Security Class Initialized
DEBUG - 2020-12-05 14:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:23:37 --> Input Class Initialized
INFO - 2020-12-05 14:23:37 --> Language Class Initialized
INFO - 2020-12-05 14:23:37 --> Loader Class Initialized
INFO - 2020-12-05 14:23:37 --> Helper loaded: url_helper
INFO - 2020-12-05 14:23:37 --> Database Driver Class Initialized
INFO - 2020-12-05 14:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:23:37 --> Email Class Initialized
INFO - 2020-12-05 14:23:37 --> Controller Class Initialized
INFO - 2020-12-05 14:23:37 --> Model Class Initialized
INFO - 2020-12-05 14:23:37 --> Model Class Initialized
DEBUG - 2020-12-05 14:23:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:23:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-05 14:23:37 --> Final output sent to browser
DEBUG - 2020-12-05 14:23:37 --> Total execution time: 0.0415
ERROR - 2020-12-05 14:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:23:45 --> Config Class Initialized
INFO - 2020-12-05 14:23:45 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:23:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:23:45 --> Utf8 Class Initialized
INFO - 2020-12-05 14:23:45 --> URI Class Initialized
INFO - 2020-12-05 14:23:45 --> Router Class Initialized
INFO - 2020-12-05 14:23:45 --> Output Class Initialized
INFO - 2020-12-05 14:23:45 --> Security Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:23:45 --> Input Class Initialized
INFO - 2020-12-05 14:23:45 --> Language Class Initialized
INFO - 2020-12-05 14:23:45 --> Loader Class Initialized
INFO - 2020-12-05 14:23:45 --> Helper loaded: url_helper
INFO - 2020-12-05 14:23:45 --> Database Driver Class Initialized
ERROR - 2020-12-05 14:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:23:45 --> Config Class Initialized
INFO - 2020-12-05 14:23:45 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:23:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:23:45 --> Utf8 Class Initialized
INFO - 2020-12-05 14:23:45 --> URI Class Initialized
INFO - 2020-12-05 14:23:45 --> Router Class Initialized
INFO - 2020-12-05 14:23:45 --> Output Class Initialized
INFO - 2020-12-05 14:23:45 --> Security Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:23:45 --> Input Class Initialized
INFO - 2020-12-05 14:23:45 --> Language Class Initialized
INFO - 2020-12-05 14:23:45 --> Loader Class Initialized
INFO - 2020-12-05 14:23:45 --> Helper loaded: url_helper
INFO - 2020-12-05 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:23:45 --> Email Class Initialized
INFO - 2020-12-05 14:23:45 --> Controller Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:23:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:23:45 --> Database Driver Class Initialized
INFO - 2020-12-05 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:23:45 --> Email Class Initialized
INFO - 2020-12-05 14:23:45 --> Controller Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-05 14:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:23:45 --> Config Class Initialized
INFO - 2020-12-05 14:23:45 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:23:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:23:45 --> Utf8 Class Initialized
INFO - 2020-12-05 14:23:45 --> URI Class Initialized
DEBUG - 2020-12-05 14:23:45 --> No URI present. Default controller set.
INFO - 2020-12-05 14:23:45 --> Router Class Initialized
INFO - 2020-12-05 14:23:45 --> Output Class Initialized
INFO - 2020-12-05 14:23:45 --> Security Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:23:45 --> Input Class Initialized
INFO - 2020-12-05 14:23:45 --> Language Class Initialized
INFO - 2020-12-05 14:23:45 --> Loader Class Initialized
INFO - 2020-12-05 14:23:45 --> Helper loaded: url_helper
ERROR - 2020-12-05 14:23:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:23:45 --> Config Class Initialized
INFO - 2020-12-05 14:23:45 --> Hooks Class Initialized
INFO - 2020-12-05 14:23:45 --> Database Driver Class Initialized
DEBUG - 2020-12-05 14:23:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:23:45 --> Utf8 Class Initialized
INFO - 2020-12-05 14:23:45 --> URI Class Initialized
INFO - 2020-12-05 14:23:45 --> Router Class Initialized
INFO - 2020-12-05 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:23:45 --> Output Class Initialized
INFO - 2020-12-05 14:23:45 --> Security Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:23:45 --> Input Class Initialized
INFO - 2020-12-05 14:23:45 --> Email Class Initialized
INFO - 2020-12-05 14:23:45 --> Controller Class Initialized
INFO - 2020-12-05 14:23:45 --> Language Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:23:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-05 14:23:45 --> Final output sent to browser
DEBUG - 2020-12-05 14:23:45 --> Total execution time: 0.0194
INFO - 2020-12-05 14:23:45 --> Loader Class Initialized
INFO - 2020-12-05 14:23:45 --> Helper loaded: url_helper
INFO - 2020-12-05 14:23:45 --> Database Driver Class Initialized
INFO - 2020-12-05 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:23:45 --> Email Class Initialized
INFO - 2020-12-05 14:23:45 --> Controller Class Initialized
DEBUG - 2020-12-05 14:23:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:23:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
INFO - 2020-12-05 14:23:45 --> Model Class Initialized
INFO - 2020-12-05 14:23:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-12-05 14:23:45 --> Final output sent to browser
DEBUG - 2020-12-05 14:23:45 --> Total execution time: 0.0746
ERROR - 2020-12-05 14:23:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:23:56 --> Config Class Initialized
INFO - 2020-12-05 14:23:56 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:23:56 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:23:56 --> Utf8 Class Initialized
INFO - 2020-12-05 14:23:56 --> URI Class Initialized
DEBUG - 2020-12-05 14:23:56 --> No URI present. Default controller set.
INFO - 2020-12-05 14:23:56 --> Router Class Initialized
INFO - 2020-12-05 14:23:56 --> Output Class Initialized
INFO - 2020-12-05 14:23:56 --> Security Class Initialized
DEBUG - 2020-12-05 14:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:23:56 --> Input Class Initialized
INFO - 2020-12-05 14:23:56 --> Language Class Initialized
INFO - 2020-12-05 14:23:56 --> Loader Class Initialized
INFO - 2020-12-05 14:23:56 --> Helper loaded: url_helper
INFO - 2020-12-05 14:23:56 --> Database Driver Class Initialized
INFO - 2020-12-05 14:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:23:56 --> Email Class Initialized
INFO - 2020-12-05 14:23:56 --> Controller Class Initialized
INFO - 2020-12-05 14:23:56 --> Model Class Initialized
INFO - 2020-12-05 14:23:56 --> Model Class Initialized
DEBUG - 2020-12-05 14:23:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:23:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-05 14:23:56 --> Final output sent to browser
DEBUG - 2020-12-05 14:23:56 --> Total execution time: 0.0267
ERROR - 2020-12-05 14:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:24:03 --> Config Class Initialized
INFO - 2020-12-05 14:24:03 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:24:03 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:24:03 --> Utf8 Class Initialized
INFO - 2020-12-05 14:24:03 --> URI Class Initialized
INFO - 2020-12-05 14:24:03 --> Router Class Initialized
INFO - 2020-12-05 14:24:03 --> Output Class Initialized
INFO - 2020-12-05 14:24:03 --> Security Class Initialized
DEBUG - 2020-12-05 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:24:03 --> Input Class Initialized
INFO - 2020-12-05 14:24:03 --> Language Class Initialized
INFO - 2020-12-05 14:24:03 --> Loader Class Initialized
INFO - 2020-12-05 14:24:03 --> Helper loaded: url_helper
INFO - 2020-12-05 14:24:03 --> Database Driver Class Initialized
INFO - 2020-12-05 14:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:24:03 --> Email Class Initialized
INFO - 2020-12-05 14:24:03 --> Controller Class Initialized
INFO - 2020-12-05 14:24:03 --> Model Class Initialized
INFO - 2020-12-05 14:24:03 --> Model Class Initialized
DEBUG - 2020-12-05 14:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:24:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:24:03 --> Model Class Initialized
INFO - 2020-12-05 14:24:03 --> Final output sent to browser
DEBUG - 2020-12-05 14:24:03 --> Total execution time: 0.0215
ERROR - 2020-12-05 14:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:24:03 --> Config Class Initialized
INFO - 2020-12-05 14:24:03 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:24:03 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:24:03 --> Utf8 Class Initialized
INFO - 2020-12-05 14:24:03 --> URI Class Initialized
INFO - 2020-12-05 14:24:03 --> Router Class Initialized
INFO - 2020-12-05 14:24:03 --> Output Class Initialized
INFO - 2020-12-05 14:24:03 --> Security Class Initialized
DEBUG - 2020-12-05 14:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:24:03 --> Input Class Initialized
INFO - 2020-12-05 14:24:03 --> Language Class Initialized
INFO - 2020-12-05 14:24:03 --> Loader Class Initialized
INFO - 2020-12-05 14:24:03 --> Helper loaded: url_helper
INFO - 2020-12-05 14:24:03 --> Database Driver Class Initialized
INFO - 2020-12-05 14:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:24:04 --> Email Class Initialized
INFO - 2020-12-05 14:24:04 --> Controller Class Initialized
INFO - 2020-12-05 14:24:04 --> Model Class Initialized
INFO - 2020-12-05 14:24:04 --> Model Class Initialized
DEBUG - 2020-12-05 14:24:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-05 14:24:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:24:04 --> Config Class Initialized
INFO - 2020-12-05 14:24:04 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:24:04 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:24:04 --> Utf8 Class Initialized
INFO - 2020-12-05 14:24:04 --> URI Class Initialized
INFO - 2020-12-05 14:24:04 --> Router Class Initialized
INFO - 2020-12-05 14:24:04 --> Output Class Initialized
INFO - 2020-12-05 14:24:04 --> Security Class Initialized
DEBUG - 2020-12-05 14:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:24:04 --> Input Class Initialized
INFO - 2020-12-05 14:24:04 --> Language Class Initialized
INFO - 2020-12-05 14:24:04 --> Loader Class Initialized
INFO - 2020-12-05 14:24:04 --> Helper loaded: url_helper
INFO - 2020-12-05 14:24:04 --> Database Driver Class Initialized
INFO - 2020-12-05 14:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:24:04 --> Email Class Initialized
INFO - 2020-12-05 14:24:04 --> Controller Class Initialized
DEBUG - 2020-12-05 14:24:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:24:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:24:04 --> Model Class Initialized
INFO - 2020-12-05 14:24:04 --> Model Class Initialized
INFO - 2020-12-05 14:24:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-12-05 14:24:04 --> Final output sent to browser
DEBUG - 2020-12-05 14:24:04 --> Total execution time: 0.0280
ERROR - 2020-12-05 14:24:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:24:42 --> Config Class Initialized
INFO - 2020-12-05 14:24:42 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:24:42 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:24:42 --> Utf8 Class Initialized
INFO - 2020-12-05 14:24:42 --> URI Class Initialized
DEBUG - 2020-12-05 14:24:42 --> No URI present. Default controller set.
INFO - 2020-12-05 14:24:42 --> Router Class Initialized
INFO - 2020-12-05 14:24:42 --> Output Class Initialized
INFO - 2020-12-05 14:24:42 --> Security Class Initialized
DEBUG - 2020-12-05 14:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:24:42 --> Input Class Initialized
INFO - 2020-12-05 14:24:42 --> Language Class Initialized
INFO - 2020-12-05 14:24:42 --> Loader Class Initialized
INFO - 2020-12-05 14:24:42 --> Helper loaded: url_helper
INFO - 2020-12-05 14:24:42 --> Database Driver Class Initialized
INFO - 2020-12-05 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:24:42 --> Email Class Initialized
INFO - 2020-12-05 14:24:42 --> Controller Class Initialized
INFO - 2020-12-05 14:24:42 --> Model Class Initialized
INFO - 2020-12-05 14:24:42 --> Model Class Initialized
DEBUG - 2020-12-05 14:24:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:24:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-05 14:24:42 --> Final output sent to browser
DEBUG - 2020-12-05 14:24:42 --> Total execution time: 0.0190
ERROR - 2020-12-05 14:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:25:15 --> Config Class Initialized
INFO - 2020-12-05 14:25:15 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:25:15 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:25:15 --> Utf8 Class Initialized
INFO - 2020-12-05 14:25:15 --> URI Class Initialized
INFO - 2020-12-05 14:25:15 --> Router Class Initialized
INFO - 2020-12-05 14:25:15 --> Output Class Initialized
INFO - 2020-12-05 14:25:15 --> Security Class Initialized
DEBUG - 2020-12-05 14:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:25:15 --> Input Class Initialized
INFO - 2020-12-05 14:25:15 --> Language Class Initialized
INFO - 2020-12-05 14:25:15 --> Loader Class Initialized
INFO - 2020-12-05 14:25:15 --> Helper loaded: url_helper
INFO - 2020-12-05 14:25:15 --> Database Driver Class Initialized
INFO - 2020-12-05 14:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:25:15 --> Email Class Initialized
INFO - 2020-12-05 14:25:15 --> Controller Class Initialized
INFO - 2020-12-05 14:25:15 --> Model Class Initialized
INFO - 2020-12-05 14:25:15 --> Model Class Initialized
DEBUG - 2020-12-05 14:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:25:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:25:15 --> Model Class Initialized
INFO - 2020-12-05 14:25:15 --> Final output sent to browser
DEBUG - 2020-12-05 14:25:15 --> Total execution time: 0.0224
ERROR - 2020-12-05 14:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:25:15 --> Config Class Initialized
INFO - 2020-12-05 14:25:15 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:25:15 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:25:15 --> Utf8 Class Initialized
INFO - 2020-12-05 14:25:15 --> URI Class Initialized
INFO - 2020-12-05 14:25:15 --> Router Class Initialized
INFO - 2020-12-05 14:25:15 --> Output Class Initialized
INFO - 2020-12-05 14:25:15 --> Security Class Initialized
DEBUG - 2020-12-05 14:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:25:15 --> Input Class Initialized
INFO - 2020-12-05 14:25:15 --> Language Class Initialized
INFO - 2020-12-05 14:25:15 --> Loader Class Initialized
INFO - 2020-12-05 14:25:15 --> Helper loaded: url_helper
INFO - 2020-12-05 14:25:15 --> Database Driver Class Initialized
INFO - 2020-12-05 14:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:25:15 --> Email Class Initialized
INFO - 2020-12-05 14:25:15 --> Controller Class Initialized
INFO - 2020-12-05 14:25:15 --> Model Class Initialized
INFO - 2020-12-05 14:25:15 --> Model Class Initialized
DEBUG - 2020-12-05 14:25:15 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-05 14:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:25:16 --> Config Class Initialized
INFO - 2020-12-05 14:25:16 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:25:16 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:25:16 --> Utf8 Class Initialized
INFO - 2020-12-05 14:25:16 --> URI Class Initialized
INFO - 2020-12-05 14:25:16 --> Router Class Initialized
INFO - 2020-12-05 14:25:16 --> Output Class Initialized
INFO - 2020-12-05 14:25:16 --> Security Class Initialized
DEBUG - 2020-12-05 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:25:16 --> Input Class Initialized
INFO - 2020-12-05 14:25:16 --> Language Class Initialized
INFO - 2020-12-05 14:25:16 --> Loader Class Initialized
INFO - 2020-12-05 14:25:16 --> Helper loaded: url_helper
INFO - 2020-12-05 14:25:16 --> Database Driver Class Initialized
INFO - 2020-12-05 14:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:25:16 --> Email Class Initialized
INFO - 2020-12-05 14:25:16 --> Controller Class Initialized
DEBUG - 2020-12-05 14:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:25:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:25:16 --> Model Class Initialized
INFO - 2020-12-05 14:25:16 --> Model Class Initialized
INFO - 2020-12-05 14:25:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 14:25:16 --> Final output sent to browser
DEBUG - 2020-12-05 14:25:16 --> Total execution time: 0.0352
ERROR - 2020-12-05 14:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:28:34 --> Config Class Initialized
INFO - 2020-12-05 14:28:34 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:28:34 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:28:34 --> Utf8 Class Initialized
INFO - 2020-12-05 14:28:34 --> URI Class Initialized
INFO - 2020-12-05 14:28:34 --> Router Class Initialized
INFO - 2020-12-05 14:28:34 --> Output Class Initialized
INFO - 2020-12-05 14:28:34 --> Security Class Initialized
DEBUG - 2020-12-05 14:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:28:34 --> Input Class Initialized
INFO - 2020-12-05 14:28:34 --> Language Class Initialized
INFO - 2020-12-05 14:28:34 --> Loader Class Initialized
INFO - 2020-12-05 14:28:34 --> Helper loaded: url_helper
INFO - 2020-12-05 14:28:34 --> Database Driver Class Initialized
INFO - 2020-12-05 14:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:28:34 --> Email Class Initialized
INFO - 2020-12-05 14:28:34 --> Controller Class Initialized
DEBUG - 2020-12-05 14:28:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:28:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:28:34 --> Model Class Initialized
INFO - 2020-12-05 14:28:34 --> Model Class Initialized
INFO - 2020-12-05 14:28:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 14:28:34 --> Final output sent to browser
DEBUG - 2020-12-05 14:28:34 --> Total execution time: 0.0209
ERROR - 2020-12-05 14:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:28:40 --> Config Class Initialized
INFO - 2020-12-05 14:28:40 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:28:40 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:28:40 --> Utf8 Class Initialized
INFO - 2020-12-05 14:28:40 --> URI Class Initialized
INFO - 2020-12-05 14:28:40 --> Router Class Initialized
INFO - 2020-12-05 14:28:40 --> Output Class Initialized
INFO - 2020-12-05 14:28:40 --> Security Class Initialized
DEBUG - 2020-12-05 14:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:28:40 --> Input Class Initialized
INFO - 2020-12-05 14:28:40 --> Language Class Initialized
INFO - 2020-12-05 14:28:40 --> Loader Class Initialized
INFO - 2020-12-05 14:28:40 --> Helper loaded: url_helper
INFO - 2020-12-05 14:28:40 --> Database Driver Class Initialized
INFO - 2020-12-05 14:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:28:40 --> Email Class Initialized
INFO - 2020-12-05 14:28:40 --> Controller Class Initialized
DEBUG - 2020-12-05 14:28:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:28:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:28:40 --> Model Class Initialized
INFO - 2020-12-05 14:28:40 --> Model Class Initialized
INFO - 2020-12-05 14:28:40 --> Final output sent to browser
DEBUG - 2020-12-05 14:28:40 --> Total execution time: 0.0279
ERROR - 2020-12-05 14:28:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:28:41 --> Config Class Initialized
INFO - 2020-12-05 14:28:41 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:28:41 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:28:41 --> Utf8 Class Initialized
INFO - 2020-12-05 14:28:41 --> URI Class Initialized
INFO - 2020-12-05 14:28:41 --> Router Class Initialized
INFO - 2020-12-05 14:28:41 --> Output Class Initialized
INFO - 2020-12-05 14:28:41 --> Security Class Initialized
DEBUG - 2020-12-05 14:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:28:41 --> Input Class Initialized
INFO - 2020-12-05 14:28:41 --> Language Class Initialized
INFO - 2020-12-05 14:28:41 --> Loader Class Initialized
INFO - 2020-12-05 14:28:41 --> Helper loaded: url_helper
INFO - 2020-12-05 14:28:41 --> Database Driver Class Initialized
INFO - 2020-12-05 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:28:41 --> Email Class Initialized
INFO - 2020-12-05 14:28:41 --> Controller Class Initialized
DEBUG - 2020-12-05 14:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:28:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:28:41 --> Model Class Initialized
INFO - 2020-12-05 14:28:41 --> Model Class Initialized
ERROR - 2020-12-05 14:28:41 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 560
ERROR - 2020-12-05 14:28:41 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-12-05 14:28:42 --> Final output sent to browser
DEBUG - 2020-12-05 14:28:42 --> Total execution time: 1.7950
ERROR - 2020-12-05 14:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:36:14 --> Config Class Initialized
INFO - 2020-12-05 14:36:14 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:36:14 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:36:14 --> Utf8 Class Initialized
INFO - 2020-12-05 14:36:14 --> URI Class Initialized
INFO - 2020-12-05 14:36:14 --> Router Class Initialized
INFO - 2020-12-05 14:36:14 --> Output Class Initialized
INFO - 2020-12-05 14:36:14 --> Security Class Initialized
DEBUG - 2020-12-05 14:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:36:14 --> Input Class Initialized
INFO - 2020-12-05 14:36:14 --> Language Class Initialized
INFO - 2020-12-05 14:36:14 --> Loader Class Initialized
INFO - 2020-12-05 14:36:14 --> Helper loaded: url_helper
INFO - 2020-12-05 14:36:14 --> Database Driver Class Initialized
INFO - 2020-12-05 14:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:36:14 --> Email Class Initialized
INFO - 2020-12-05 14:36:14 --> Controller Class Initialized
DEBUG - 2020-12-05 14:36:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:36:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:36:14 --> Model Class Initialized
INFO - 2020-12-05 14:36:14 --> Model Class Initialized
INFO - 2020-12-05 14:36:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 14:36:14 --> Final output sent to browser
DEBUG - 2020-12-05 14:36:14 --> Total execution time: 0.0342
ERROR - 2020-12-05 14:36:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:36:15 --> Config Class Initialized
INFO - 2020-12-05 14:36:15 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:36:15 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:36:15 --> Utf8 Class Initialized
INFO - 2020-12-05 14:36:15 --> URI Class Initialized
INFO - 2020-12-05 14:36:15 --> Router Class Initialized
INFO - 2020-12-05 14:36:15 --> Output Class Initialized
INFO - 2020-12-05 14:36:15 --> Security Class Initialized
DEBUG - 2020-12-05 14:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:36:15 --> Input Class Initialized
INFO - 2020-12-05 14:36:15 --> Language Class Initialized
INFO - 2020-12-05 14:36:15 --> Loader Class Initialized
INFO - 2020-12-05 14:36:15 --> Helper loaded: url_helper
INFO - 2020-12-05 14:36:15 --> Database Driver Class Initialized
INFO - 2020-12-05 14:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:36:15 --> Email Class Initialized
INFO - 2020-12-05 14:36:15 --> Controller Class Initialized
DEBUG - 2020-12-05 14:36:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:36:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:36:15 --> Model Class Initialized
INFO - 2020-12-05 14:36:15 --> Model Class Initialized
INFO - 2020-12-05 14:36:15 --> Final output sent to browser
DEBUG - 2020-12-05 14:36:15 --> Total execution time: 0.0229
ERROR - 2020-12-05 14:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:36:45 --> Config Class Initialized
INFO - 2020-12-05 14:36:45 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:36:45 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:36:45 --> Utf8 Class Initialized
INFO - 2020-12-05 14:36:45 --> URI Class Initialized
INFO - 2020-12-05 14:36:45 --> Router Class Initialized
INFO - 2020-12-05 14:36:45 --> Output Class Initialized
INFO - 2020-12-05 14:36:45 --> Security Class Initialized
DEBUG - 2020-12-05 14:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:36:45 --> Input Class Initialized
INFO - 2020-12-05 14:36:45 --> Language Class Initialized
INFO - 2020-12-05 14:36:45 --> Loader Class Initialized
INFO - 2020-12-05 14:36:45 --> Helper loaded: url_helper
INFO - 2020-12-05 14:36:45 --> Database Driver Class Initialized
INFO - 2020-12-05 14:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:36:45 --> Email Class Initialized
INFO - 2020-12-05 14:36:45 --> Controller Class Initialized
DEBUG - 2020-12-05 14:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:36:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:36:45 --> Model Class Initialized
INFO - 2020-12-05 14:36:45 --> Model Class Initialized
INFO - 2020-12-05 14:36:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-12-05 14:36:48 --> Final output sent to browser
DEBUG - 2020-12-05 14:36:48 --> Total execution time: 2.7479
ERROR - 2020-12-05 14:36:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:36:49 --> Config Class Initialized
INFO - 2020-12-05 14:36:49 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:36:49 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:36:49 --> Utf8 Class Initialized
INFO - 2020-12-05 14:36:49 --> URI Class Initialized
INFO - 2020-12-05 14:36:49 --> Router Class Initialized
INFO - 2020-12-05 14:36:49 --> Output Class Initialized
INFO - 2020-12-05 14:36:49 --> Security Class Initialized
DEBUG - 2020-12-05 14:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:36:49 --> Input Class Initialized
INFO - 2020-12-05 14:36:49 --> Language Class Initialized
INFO - 2020-12-05 14:36:49 --> Loader Class Initialized
INFO - 2020-12-05 14:36:49 --> Helper loaded: url_helper
INFO - 2020-12-05 14:36:49 --> Database Driver Class Initialized
INFO - 2020-12-05 14:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:36:49 --> Email Class Initialized
INFO - 2020-12-05 14:36:49 --> Controller Class Initialized
DEBUG - 2020-12-05 14:36:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:36:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:36:49 --> Model Class Initialized
INFO - 2020-12-05 14:36:49 --> Model Class Initialized
INFO - 2020-12-05 14:36:49 --> Final output sent to browser
DEBUG - 2020-12-05 14:36:49 --> Total execution time: 0.0227
ERROR - 2020-12-05 14:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-05 14:44:51 --> Config Class Initialized
INFO - 2020-12-05 14:44:51 --> Hooks Class Initialized
DEBUG - 2020-12-05 14:44:51 --> UTF-8 Support Enabled
INFO - 2020-12-05 14:44:51 --> Utf8 Class Initialized
INFO - 2020-12-05 14:44:51 --> URI Class Initialized
INFO - 2020-12-05 14:44:51 --> Router Class Initialized
INFO - 2020-12-05 14:44:51 --> Output Class Initialized
INFO - 2020-12-05 14:44:51 --> Security Class Initialized
DEBUG - 2020-12-05 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 14:44:51 --> Input Class Initialized
INFO - 2020-12-05 14:44:51 --> Language Class Initialized
INFO - 2020-12-05 14:44:51 --> Loader Class Initialized
INFO - 2020-12-05 14:44:51 --> Helper loaded: url_helper
INFO - 2020-12-05 14:44:51 --> Database Driver Class Initialized
INFO - 2020-12-05 14:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 14:44:51 --> Email Class Initialized
INFO - 2020-12-05 14:44:51 --> Controller Class Initialized
DEBUG - 2020-12-05 14:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-05 14:44:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-05 14:44:51 --> Model Class Initialized
INFO - 2020-12-05 14:44:51 --> Model Class Initialized
INFO - 2020-12-05 14:44:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-12-05 14:44:51 --> Final output sent to browser
DEBUG - 2020-12-05 14:44:51 --> Total execution time: 0.0437
