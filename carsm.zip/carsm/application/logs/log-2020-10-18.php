<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-18 06:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-18 06:31:47 --> Config Class Initialized
INFO - 2020-10-18 06:31:47 --> Hooks Class Initialized
DEBUG - 2020-10-18 06:31:47 --> UTF-8 Support Enabled
INFO - 2020-10-18 06:31:47 --> Utf8 Class Initialized
INFO - 2020-10-18 06:31:47 --> URI Class Initialized
DEBUG - 2020-10-18 06:31:47 --> No URI present. Default controller set.
INFO - 2020-10-18 06:31:47 --> Router Class Initialized
INFO - 2020-10-18 06:31:47 --> Output Class Initialized
INFO - 2020-10-18 06:31:47 --> Security Class Initialized
DEBUG - 2020-10-18 06:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-18 06:31:47 --> Input Class Initialized
INFO - 2020-10-18 06:31:47 --> Language Class Initialized
INFO - 2020-10-18 06:31:47 --> Loader Class Initialized
INFO - 2020-10-18 06:31:47 --> Helper loaded: url_helper
INFO - 2020-10-18 06:31:47 --> Database Driver Class Initialized
INFO - 2020-10-18 06:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-18 06:31:47 --> Email Class Initialized
INFO - 2020-10-18 06:31:47 --> Controller Class Initialized
INFO - 2020-10-18 06:31:47 --> Model Class Initialized
INFO - 2020-10-18 06:31:47 --> Model Class Initialized
DEBUG - 2020-10-18 06:31:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-18 06:31:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-18 06:31:47 --> Final output sent to browser
DEBUG - 2020-10-18 06:31:47 --> Total execution time: 0.2360
ERROR - 2020-10-18 09:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-18 09:27:35 --> Config Class Initialized
INFO - 2020-10-18 09:27:35 --> Hooks Class Initialized
DEBUG - 2020-10-18 09:27:35 --> UTF-8 Support Enabled
INFO - 2020-10-18 09:27:35 --> Utf8 Class Initialized
INFO - 2020-10-18 09:27:35 --> URI Class Initialized
DEBUG - 2020-10-18 09:27:35 --> No URI present. Default controller set.
INFO - 2020-10-18 09:27:35 --> Router Class Initialized
INFO - 2020-10-18 09:27:35 --> Output Class Initialized
INFO - 2020-10-18 09:27:35 --> Security Class Initialized
DEBUG - 2020-10-18 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-18 09:27:35 --> Input Class Initialized
INFO - 2020-10-18 09:27:35 --> Language Class Initialized
INFO - 2020-10-18 09:27:35 --> Loader Class Initialized
INFO - 2020-10-18 09:27:35 --> Helper loaded: url_helper
INFO - 2020-10-18 09:27:35 --> Database Driver Class Initialized
INFO - 2020-10-18 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-18 09:27:35 --> Email Class Initialized
INFO - 2020-10-18 09:27:35 --> Controller Class Initialized
INFO - 2020-10-18 09:27:35 --> Model Class Initialized
INFO - 2020-10-18 09:27:35 --> Model Class Initialized
DEBUG - 2020-10-18 09:27:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-18 09:27:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-18 09:27:35 --> Final output sent to browser
DEBUG - 2020-10-18 09:27:35 --> Total execution time: 0.0218
ERROR - 2020-10-18 09:55:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-18 09:55:46 --> Config Class Initialized
INFO - 2020-10-18 09:55:46 --> Hooks Class Initialized
DEBUG - 2020-10-18 09:55:46 --> UTF-8 Support Enabled
INFO - 2020-10-18 09:55:46 --> Utf8 Class Initialized
INFO - 2020-10-18 09:55:46 --> URI Class Initialized
DEBUG - 2020-10-18 09:55:46 --> No URI present. Default controller set.
INFO - 2020-10-18 09:55:46 --> Router Class Initialized
INFO - 2020-10-18 09:55:46 --> Output Class Initialized
INFO - 2020-10-18 09:55:46 --> Security Class Initialized
DEBUG - 2020-10-18 09:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-18 09:55:46 --> Input Class Initialized
INFO - 2020-10-18 09:55:46 --> Language Class Initialized
INFO - 2020-10-18 09:55:46 --> Loader Class Initialized
INFO - 2020-10-18 09:55:46 --> Helper loaded: url_helper
INFO - 2020-10-18 09:55:46 --> Database Driver Class Initialized
INFO - 2020-10-18 09:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-18 09:55:46 --> Email Class Initialized
INFO - 2020-10-18 09:55:46 --> Controller Class Initialized
INFO - 2020-10-18 09:55:46 --> Model Class Initialized
INFO - 2020-10-18 09:55:46 --> Model Class Initialized
DEBUG - 2020-10-18 09:55:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-18 09:55:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-18 09:55:46 --> Final output sent to browser
DEBUG - 2020-10-18 09:55:46 --> Total execution time: 0.0197
ERROR - 2020-10-18 11:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-18 11:21:43 --> Config Class Initialized
INFO - 2020-10-18 11:21:43 --> Hooks Class Initialized
DEBUG - 2020-10-18 11:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-18 11:21:43 --> Utf8 Class Initialized
INFO - 2020-10-18 11:21:43 --> URI Class Initialized
DEBUG - 2020-10-18 11:21:43 --> No URI present. Default controller set.
INFO - 2020-10-18 11:21:43 --> Router Class Initialized
INFO - 2020-10-18 11:21:43 --> Output Class Initialized
INFO - 2020-10-18 11:21:43 --> Security Class Initialized
DEBUG - 2020-10-18 11:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-18 11:21:43 --> Input Class Initialized
INFO - 2020-10-18 11:21:43 --> Language Class Initialized
INFO - 2020-10-18 11:21:43 --> Loader Class Initialized
INFO - 2020-10-18 11:21:43 --> Helper loaded: url_helper
INFO - 2020-10-18 11:21:43 --> Database Driver Class Initialized
INFO - 2020-10-18 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-18 11:21:43 --> Email Class Initialized
INFO - 2020-10-18 11:21:43 --> Controller Class Initialized
INFO - 2020-10-18 11:21:43 --> Model Class Initialized
INFO - 2020-10-18 11:21:43 --> Model Class Initialized
DEBUG - 2020-10-18 11:21:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-18 11:21:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-18 11:21:43 --> Final output sent to browser
DEBUG - 2020-10-18 11:21:43 --> Total execution time: 0.0171
ERROR - 2020-10-18 14:42:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-18 14:42:37 --> Config Class Initialized
INFO - 2020-10-18 14:42:37 --> Hooks Class Initialized
DEBUG - 2020-10-18 14:42:37 --> UTF-8 Support Enabled
INFO - 2020-10-18 14:42:37 --> Utf8 Class Initialized
INFO - 2020-10-18 14:42:37 --> URI Class Initialized
DEBUG - 2020-10-18 14:42:37 --> No URI present. Default controller set.
INFO - 2020-10-18 14:42:37 --> Router Class Initialized
INFO - 2020-10-18 14:42:37 --> Output Class Initialized
INFO - 2020-10-18 14:42:37 --> Security Class Initialized
DEBUG - 2020-10-18 14:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-18 14:42:37 --> Input Class Initialized
INFO - 2020-10-18 14:42:37 --> Language Class Initialized
INFO - 2020-10-18 14:42:37 --> Loader Class Initialized
INFO - 2020-10-18 14:42:37 --> Helper loaded: url_helper
INFO - 2020-10-18 14:42:37 --> Database Driver Class Initialized
INFO - 2020-10-18 14:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-18 14:42:37 --> Email Class Initialized
INFO - 2020-10-18 14:42:37 --> Controller Class Initialized
INFO - 2020-10-18 14:42:37 --> Model Class Initialized
INFO - 2020-10-18 14:42:37 --> Model Class Initialized
DEBUG - 2020-10-18 14:42:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-18 14:42:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-18 14:42:37 --> Final output sent to browser
DEBUG - 2020-10-18 14:42:37 --> Total execution time: 0.0213
ERROR - 2020-10-18 14:42:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-18 14:42:44 --> Config Class Initialized
INFO - 2020-10-18 14:42:44 --> Hooks Class Initialized
DEBUG - 2020-10-18 14:42:44 --> UTF-8 Support Enabled
INFO - 2020-10-18 14:42:44 --> Utf8 Class Initialized
INFO - 2020-10-18 14:42:44 --> URI Class Initialized
DEBUG - 2020-10-18 14:42:44 --> No URI present. Default controller set.
INFO - 2020-10-18 14:42:44 --> Router Class Initialized
INFO - 2020-10-18 14:42:44 --> Output Class Initialized
INFO - 2020-10-18 14:42:44 --> Security Class Initialized
DEBUG - 2020-10-18 14:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-18 14:42:44 --> Input Class Initialized
INFO - 2020-10-18 14:42:44 --> Language Class Initialized
INFO - 2020-10-18 14:42:44 --> Loader Class Initialized
INFO - 2020-10-18 14:42:44 --> Helper loaded: url_helper
INFO - 2020-10-18 14:42:44 --> Database Driver Class Initialized
INFO - 2020-10-18 14:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-18 14:42:44 --> Email Class Initialized
INFO - 2020-10-18 14:42:44 --> Controller Class Initialized
INFO - 2020-10-18 14:42:44 --> Model Class Initialized
INFO - 2020-10-18 14:42:44 --> Model Class Initialized
DEBUG - 2020-10-18 14:42:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-18 14:42:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-18 14:42:44 --> Final output sent to browser
DEBUG - 2020-10-18 14:42:44 --> Total execution time: 0.0191
