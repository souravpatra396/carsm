<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-10 07:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-10 07:03:34 --> Config Class Initialized
INFO - 2020-11-10 07:03:34 --> Hooks Class Initialized
DEBUG - 2020-11-10 07:03:34 --> UTF-8 Support Enabled
INFO - 2020-11-10 07:03:34 --> Utf8 Class Initialized
INFO - 2020-11-10 07:03:34 --> URI Class Initialized
DEBUG - 2020-11-10 07:03:34 --> No URI present. Default controller set.
INFO - 2020-11-10 07:03:34 --> Router Class Initialized
INFO - 2020-11-10 07:03:34 --> Output Class Initialized
INFO - 2020-11-10 07:03:34 --> Security Class Initialized
DEBUG - 2020-11-10 07:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 07:03:34 --> Input Class Initialized
INFO - 2020-11-10 07:03:34 --> Language Class Initialized
INFO - 2020-11-10 07:03:34 --> Loader Class Initialized
INFO - 2020-11-10 07:03:34 --> Helper loaded: url_helper
INFO - 2020-11-10 07:03:34 --> Database Driver Class Initialized
INFO - 2020-11-10 07:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 07:03:34 --> Email Class Initialized
INFO - 2020-11-10 07:03:34 --> Controller Class Initialized
INFO - 2020-11-10 07:03:34 --> Model Class Initialized
INFO - 2020-11-10 07:03:34 --> Model Class Initialized
DEBUG - 2020-11-10 07:03:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-10 07:03:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-10 07:03:34 --> Final output sent to browser
DEBUG - 2020-11-10 07:03:34 --> Total execution time: 0.1744
ERROR - 2020-11-10 11:49:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-10 11:49:05 --> Config Class Initialized
INFO - 2020-11-10 11:49:05 --> Hooks Class Initialized
DEBUG - 2020-11-10 11:49:05 --> UTF-8 Support Enabled
INFO - 2020-11-10 11:49:05 --> Utf8 Class Initialized
INFO - 2020-11-10 11:49:05 --> URI Class Initialized
DEBUG - 2020-11-10 11:49:05 --> No URI present. Default controller set.
INFO - 2020-11-10 11:49:05 --> Router Class Initialized
INFO - 2020-11-10 11:49:05 --> Output Class Initialized
INFO - 2020-11-10 11:49:05 --> Security Class Initialized
DEBUG - 2020-11-10 11:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-10 11:49:05 --> Input Class Initialized
INFO - 2020-11-10 11:49:05 --> Language Class Initialized
INFO - 2020-11-10 11:49:05 --> Loader Class Initialized
INFO - 2020-11-10 11:49:05 --> Helper loaded: url_helper
INFO - 2020-11-10 11:49:05 --> Database Driver Class Initialized
INFO - 2020-11-10 11:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-10 11:49:05 --> Email Class Initialized
INFO - 2020-11-10 11:49:05 --> Controller Class Initialized
INFO - 2020-11-10 11:49:05 --> Model Class Initialized
INFO - 2020-11-10 11:49:05 --> Model Class Initialized
DEBUG - 2020-11-10 11:49:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-10 11:49:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-10 11:49:05 --> Final output sent to browser
DEBUG - 2020-11-10 11:49:05 --> Total execution time: 0.0199
