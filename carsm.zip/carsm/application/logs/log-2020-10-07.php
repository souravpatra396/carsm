<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-07 05:12:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:12:17 --> Config Class Initialized
INFO - 2020-10-07 05:12:17 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:12:17 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:12:17 --> Utf8 Class Initialized
INFO - 2020-10-07 05:12:17 --> URI Class Initialized
DEBUG - 2020-10-07 05:12:17 --> No URI present. Default controller set.
INFO - 2020-10-07 05:12:17 --> Router Class Initialized
INFO - 2020-10-07 05:12:17 --> Output Class Initialized
INFO - 2020-10-07 05:12:17 --> Security Class Initialized
DEBUG - 2020-10-07 05:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:12:17 --> Input Class Initialized
INFO - 2020-10-07 05:12:17 --> Language Class Initialized
INFO - 2020-10-07 05:12:17 --> Loader Class Initialized
INFO - 2020-10-07 05:12:17 --> Helper loaded: url_helper
INFO - 2020-10-07 05:12:17 --> Database Driver Class Initialized
INFO - 2020-10-07 05:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:12:17 --> Email Class Initialized
INFO - 2020-10-07 05:12:17 --> Controller Class Initialized
INFO - 2020-10-07 05:12:17 --> Model Class Initialized
INFO - 2020-10-07 05:12:17 --> Model Class Initialized
DEBUG - 2020-10-07 05:12:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:12:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:12:17 --> Final output sent to browser
DEBUG - 2020-10-07 05:12:17 --> Total execution time: 0.0450
ERROR - 2020-10-07 05:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:12:18 --> Config Class Initialized
INFO - 2020-10-07 05:12:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:12:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:12:18 --> Utf8 Class Initialized
INFO - 2020-10-07 05:12:18 --> URI Class Initialized
DEBUG - 2020-10-07 05:12:18 --> No URI present. Default controller set.
INFO - 2020-10-07 05:12:18 --> Router Class Initialized
INFO - 2020-10-07 05:12:18 --> Output Class Initialized
INFO - 2020-10-07 05:12:18 --> Security Class Initialized
DEBUG - 2020-10-07 05:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:12:18 --> Input Class Initialized
INFO - 2020-10-07 05:12:18 --> Language Class Initialized
INFO - 2020-10-07 05:12:18 --> Loader Class Initialized
INFO - 2020-10-07 05:12:18 --> Helper loaded: url_helper
INFO - 2020-10-07 05:12:18 --> Database Driver Class Initialized
INFO - 2020-10-07 05:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:12:18 --> Email Class Initialized
INFO - 2020-10-07 05:12:18 --> Controller Class Initialized
INFO - 2020-10-07 05:12:18 --> Model Class Initialized
INFO - 2020-10-07 05:12:18 --> Model Class Initialized
DEBUG - 2020-10-07 05:12:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:12:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:12:18 --> Final output sent to browser
DEBUG - 2020-10-07 05:12:18 --> Total execution time: 0.0191
ERROR - 2020-10-07 05:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:27 --> Config Class Initialized
INFO - 2020-10-07 05:18:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:27 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:27 --> URI Class Initialized
DEBUG - 2020-10-07 05:18:27 --> No URI present. Default controller set.
INFO - 2020-10-07 05:18:27 --> Router Class Initialized
INFO - 2020-10-07 05:18:27 --> Output Class Initialized
INFO - 2020-10-07 05:18:27 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:27 --> Input Class Initialized
INFO - 2020-10-07 05:18:27 --> Language Class Initialized
INFO - 2020-10-07 05:18:27 --> Loader Class Initialized
INFO - 2020-10-07 05:18:27 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:27 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:27 --> Email Class Initialized
INFO - 2020-10-07 05:18:27 --> Controller Class Initialized
INFO - 2020-10-07 05:18:27 --> Model Class Initialized
INFO - 2020-10-07 05:18:27 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:18:27 --> Final output sent to browser
DEBUG - 2020-10-07 05:18:27 --> Total execution time: 0.0217
ERROR - 2020-10-07 05:18:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:33 --> Config Class Initialized
INFO - 2020-10-07 05:18:33 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:33 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:33 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:33 --> URI Class Initialized
INFO - 2020-10-07 05:18:33 --> Router Class Initialized
INFO - 2020-10-07 05:18:33 --> Output Class Initialized
INFO - 2020-10-07 05:18:33 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:33 --> Input Class Initialized
INFO - 2020-10-07 05:18:33 --> Language Class Initialized
INFO - 2020-10-07 05:18:33 --> Loader Class Initialized
INFO - 2020-10-07 05:18:33 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:33 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:33 --> Email Class Initialized
INFO - 2020-10-07 05:18:33 --> Controller Class Initialized
INFO - 2020-10-07 05:18:33 --> Model Class Initialized
INFO - 2020-10-07 05:18:33 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:18:33 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-07 05:18:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:33 --> Config Class Initialized
INFO - 2020-10-07 05:18:33 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:33 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:33 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:33 --> URI Class Initialized
DEBUG - 2020-10-07 05:18:33 --> No URI present. Default controller set.
INFO - 2020-10-07 05:18:33 --> Router Class Initialized
INFO - 2020-10-07 05:18:33 --> Output Class Initialized
INFO - 2020-10-07 05:18:33 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:33 --> Input Class Initialized
INFO - 2020-10-07 05:18:33 --> Language Class Initialized
INFO - 2020-10-07 05:18:33 --> Loader Class Initialized
INFO - 2020-10-07 05:18:33 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:33 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:33 --> Email Class Initialized
INFO - 2020-10-07 05:18:33 --> Controller Class Initialized
INFO - 2020-10-07 05:18:33 --> Model Class Initialized
INFO - 2020-10-07 05:18:33 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:18:33 --> Final output sent to browser
DEBUG - 2020-10-07 05:18:33 --> Total execution time: 0.0180
ERROR - 2020-10-07 05:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:39 --> Config Class Initialized
INFO - 2020-10-07 05:18:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:39 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:39 --> URI Class Initialized
INFO - 2020-10-07 05:18:39 --> Router Class Initialized
INFO - 2020-10-07 05:18:39 --> Output Class Initialized
INFO - 2020-10-07 05:18:39 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:39 --> Input Class Initialized
INFO - 2020-10-07 05:18:39 --> Language Class Initialized
INFO - 2020-10-07 05:18:39 --> Loader Class Initialized
INFO - 2020-10-07 05:18:39 --> Helper loaded: url_helper
ERROR - 2020-10-07 05:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:39 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:39 --> Config Class Initialized
INFO - 2020-10-07 05:18:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:39 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:39 --> URI Class Initialized
INFO - 2020-10-07 05:18:39 --> Router Class Initialized
INFO - 2020-10-07 05:18:39 --> Output Class Initialized
INFO - 2020-10-07 05:18:39 --> Email Class Initialized
INFO - 2020-10-07 05:18:39 --> Controller Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
INFO - 2020-10-07 05:18:39 --> Security Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:18:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:39 --> Input Class Initialized
INFO - 2020-10-07 05:18:39 --> Language Class Initialized
INFO - 2020-10-07 05:18:39 --> Loader Class Initialized
INFO - 2020-10-07 05:18:39 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:39 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:39 --> Email Class Initialized
INFO - 2020-10-07 05:18:39 --> Controller Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 05:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:39 --> Config Class Initialized
INFO - 2020-10-07 05:18:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:39 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:39 --> URI Class Initialized
DEBUG - 2020-10-07 05:18:39 --> No URI present. Default controller set.
INFO - 2020-10-07 05:18:39 --> Router Class Initialized
INFO - 2020-10-07 05:18:39 --> Output Class Initialized
INFO - 2020-10-07 05:18:39 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:39 --> Input Class Initialized
INFO - 2020-10-07 05:18:39 --> Language Class Initialized
INFO - 2020-10-07 05:18:39 --> Loader Class Initialized
INFO - 2020-10-07 05:18:39 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:39 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:39 --> Email Class Initialized
INFO - 2020-10-07 05:18:39 --> Controller Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:18:39 --> Final output sent to browser
DEBUG - 2020-10-07 05:18:39 --> Total execution time: 0.0187
ERROR - 2020-10-07 05:18:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:39 --> Config Class Initialized
INFO - 2020-10-07 05:18:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:39 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:39 --> URI Class Initialized
DEBUG - 2020-10-07 05:18:39 --> No URI present. Default controller set.
INFO - 2020-10-07 05:18:39 --> Router Class Initialized
INFO - 2020-10-07 05:18:39 --> Output Class Initialized
INFO - 2020-10-07 05:18:39 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:39 --> Input Class Initialized
INFO - 2020-10-07 05:18:39 --> Language Class Initialized
INFO - 2020-10-07 05:18:39 --> Loader Class Initialized
INFO - 2020-10-07 05:18:39 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:39 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:39 --> Email Class Initialized
INFO - 2020-10-07 05:18:39 --> Controller Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
INFO - 2020-10-07 05:18:39 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:18:39 --> Final output sent to browser
DEBUG - 2020-10-07 05:18:39 --> Total execution time: 0.0184
ERROR - 2020-10-07 05:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:54 --> Config Class Initialized
INFO - 2020-10-07 05:18:54 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:54 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:54 --> URI Class Initialized
INFO - 2020-10-07 05:18:54 --> Router Class Initialized
INFO - 2020-10-07 05:18:54 --> Output Class Initialized
INFO - 2020-10-07 05:18:54 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:54 --> Input Class Initialized
INFO - 2020-10-07 05:18:54 --> Language Class Initialized
INFO - 2020-10-07 05:18:54 --> Loader Class Initialized
INFO - 2020-10-07 05:18:54 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:54 --> Database Driver Class Initialized
ERROR - 2020-10-07 05:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:54 --> Config Class Initialized
INFO - 2020-10-07 05:18:54 --> Hooks Class Initialized
INFO - 2020-10-07 05:18:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-07 05:18:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:54 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:54 --> URI Class Initialized
INFO - 2020-10-07 05:18:54 --> Router Class Initialized
INFO - 2020-10-07 05:18:54 --> Email Class Initialized
INFO - 2020-10-07 05:18:54 --> Controller Class Initialized
INFO - 2020-10-07 05:18:54 --> Model Class Initialized
INFO - 2020-10-07 05:18:54 --> Output Class Initialized
INFO - 2020-10-07 05:18:54 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:54 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:54 --> Input Class Initialized
INFO - 2020-10-07 05:18:54 --> Language Class Initialized
INFO - 2020-10-07 05:18:54 --> Loader Class Initialized
INFO - 2020-10-07 05:18:54 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:54 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:54 --> Email Class Initialized
INFO - 2020-10-07 05:18:54 --> Controller Class Initialized
INFO - 2020-10-07 05:18:54 --> Model Class Initialized
INFO - 2020-10-07 05:18:54 --> Model Class Initialized
DEBUG - 2020-10-07 05:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:54 --> Model Class Initialized
INFO - 2020-10-07 05:18:54 --> Final output sent to browser
DEBUG - 2020-10-07 05:18:54 --> Total execution time: 0.0262
ERROR - 2020-10-07 05:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:18:54 --> Config Class Initialized
INFO - 2020-10-07 05:18:54 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:18:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:18:54 --> Utf8 Class Initialized
INFO - 2020-10-07 05:18:54 --> URI Class Initialized
INFO - 2020-10-07 05:18:54 --> Router Class Initialized
INFO - 2020-10-07 05:18:54 --> Output Class Initialized
INFO - 2020-10-07 05:18:54 --> Security Class Initialized
DEBUG - 2020-10-07 05:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:18:54 --> Input Class Initialized
INFO - 2020-10-07 05:18:54 --> Language Class Initialized
INFO - 2020-10-07 05:18:54 --> Loader Class Initialized
INFO - 2020-10-07 05:18:54 --> Helper loaded: url_helper
INFO - 2020-10-07 05:18:54 --> Database Driver Class Initialized
INFO - 2020-10-07 05:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:18:54 --> Email Class Initialized
INFO - 2020-10-07 05:18:54 --> Controller Class Initialized
DEBUG - 2020-10-07 05:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 05:18:54 --> Final output sent to browser
DEBUG - 2020-10-07 05:18:54 --> Total execution time: 0.0430
ERROR - 2020-10-07 05:19:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:12 --> Config Class Initialized
INFO - 2020-10-07 05:19:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:12 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:12 --> URI Class Initialized
INFO - 2020-10-07 05:19:12 --> Router Class Initialized
INFO - 2020-10-07 05:19:12 --> Output Class Initialized
INFO - 2020-10-07 05:19:12 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:12 --> Input Class Initialized
INFO - 2020-10-07 05:19:12 --> Language Class Initialized
INFO - 2020-10-07 05:19:12 --> Loader Class Initialized
INFO - 2020-10-07 05:19:12 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:12 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:12 --> Email Class Initialized
INFO - 2020-10-07 05:19:12 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:12 --> Model Class Initialized
INFO - 2020-10-07 05:19:12 --> Model Class Initialized
INFO - 2020-10-07 05:19:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 05:19:12 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:12 --> Total execution time: 0.0652
ERROR - 2020-10-07 05:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:39 --> Config Class Initialized
INFO - 2020-10-07 05:19:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:39 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:39 --> URI Class Initialized
INFO - 2020-10-07 05:19:39 --> Router Class Initialized
INFO - 2020-10-07 05:19:39 --> Output Class Initialized
INFO - 2020-10-07 05:19:39 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:39 --> Input Class Initialized
INFO - 2020-10-07 05:19:39 --> Language Class Initialized
INFO - 2020-10-07 05:19:39 --> Loader Class Initialized
INFO - 2020-10-07 05:19:39 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:39 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:39 --> Email Class Initialized
INFO - 2020-10-07 05:19:39 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:39 --> Model Class Initialized
INFO - 2020-10-07 05:19:39 --> Model Class Initialized
INFO - 2020-10-07 05:19:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 05:19:39 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:39 --> Total execution time: 0.0340
ERROR - 2020-10-07 05:19:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:40 --> Config Class Initialized
INFO - 2020-10-07 05:19:40 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:40 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:40 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:40 --> URI Class Initialized
INFO - 2020-10-07 05:19:40 --> Router Class Initialized
INFO - 2020-10-07 05:19:40 --> Output Class Initialized
INFO - 2020-10-07 05:19:40 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:40 --> Input Class Initialized
INFO - 2020-10-07 05:19:40 --> Language Class Initialized
INFO - 2020-10-07 05:19:40 --> Loader Class Initialized
INFO - 2020-10-07 05:19:40 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:40 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:40 --> Email Class Initialized
INFO - 2020-10-07 05:19:40 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:40 --> Model Class Initialized
INFO - 2020-10-07 05:19:40 --> Model Class Initialized
INFO - 2020-10-07 05:19:40 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:40 --> Total execution time: 0.0269
ERROR - 2020-10-07 05:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:46 --> Config Class Initialized
INFO - 2020-10-07 05:19:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:46 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:46 --> URI Class Initialized
INFO - 2020-10-07 05:19:46 --> Router Class Initialized
INFO - 2020-10-07 05:19:46 --> Output Class Initialized
INFO - 2020-10-07 05:19:46 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:46 --> Input Class Initialized
INFO - 2020-10-07 05:19:46 --> Language Class Initialized
INFO - 2020-10-07 05:19:46 --> Loader Class Initialized
INFO - 2020-10-07 05:19:46 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:46 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:46 --> Email Class Initialized
INFO - 2020-10-07 05:19:46 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:46 --> Model Class Initialized
INFO - 2020-10-07 05:19:46 --> Model Class Initialized
INFO - 2020-10-07 05:19:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 05:19:46 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:46 --> Total execution time: 0.0208
ERROR - 2020-10-07 05:19:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:53 --> Config Class Initialized
INFO - 2020-10-07 05:19:53 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:53 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:53 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:53 --> URI Class Initialized
INFO - 2020-10-07 05:19:53 --> Router Class Initialized
INFO - 2020-10-07 05:19:53 --> Output Class Initialized
INFO - 2020-10-07 05:19:53 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:53 --> Input Class Initialized
INFO - 2020-10-07 05:19:53 --> Language Class Initialized
INFO - 2020-10-07 05:19:53 --> Loader Class Initialized
INFO - 2020-10-07 05:19:53 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:53 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:53 --> Email Class Initialized
INFO - 2020-10-07 05:19:53 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:53 --> Model Class Initialized
INFO - 2020-10-07 05:19:53 --> Model Class Initialized
INFO - 2020-10-07 05:19:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-07 05:19:53 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:53 --> Total execution time: 0.0327
ERROR - 2020-10-07 05:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:55 --> Config Class Initialized
INFO - 2020-10-07 05:19:55 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:55 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:55 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:55 --> URI Class Initialized
INFO - 2020-10-07 05:19:55 --> Router Class Initialized
INFO - 2020-10-07 05:19:55 --> Output Class Initialized
INFO - 2020-10-07 05:19:55 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:55 --> Input Class Initialized
INFO - 2020-10-07 05:19:55 --> Language Class Initialized
INFO - 2020-10-07 05:19:55 --> Loader Class Initialized
INFO - 2020-10-07 05:19:55 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:55 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:55 --> Email Class Initialized
INFO - 2020-10-07 05:19:55 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:55 --> Model Class Initialized
INFO - 2020-10-07 05:19:55 --> Model Class Initialized
INFO - 2020-10-07 05:19:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 05:19:55 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:55 --> Total execution time: 0.0229
ERROR - 2020-10-07 05:19:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:56 --> Config Class Initialized
INFO - 2020-10-07 05:19:56 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:56 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:56 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:56 --> URI Class Initialized
INFO - 2020-10-07 05:19:56 --> Router Class Initialized
INFO - 2020-10-07 05:19:56 --> Output Class Initialized
INFO - 2020-10-07 05:19:56 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:56 --> Input Class Initialized
INFO - 2020-10-07 05:19:56 --> Language Class Initialized
INFO - 2020-10-07 05:19:56 --> Loader Class Initialized
INFO - 2020-10-07 05:19:56 --> Helper loaded: url_helper
INFO - 2020-10-07 05:19:57 --> Database Driver Class Initialized
INFO - 2020-10-07 05:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:19:57 --> Email Class Initialized
INFO - 2020-10-07 05:19:57 --> Controller Class Initialized
DEBUG - 2020-10-07 05:19:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:19:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:19:57 --> Model Class Initialized
INFO - 2020-10-07 05:19:57 --> Model Class Initialized
INFO - 2020-10-07 05:19:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 05:19:57 --> Final output sent to browser
DEBUG - 2020-10-07 05:19:57 --> Total execution time: 0.0222
ERROR - 2020-10-07 05:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:19:57 --> Config Class Initialized
INFO - 2020-10-07 05:19:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:19:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:19:57 --> Utf8 Class Initialized
INFO - 2020-10-07 05:19:57 --> URI Class Initialized
INFO - 2020-10-07 05:19:57 --> Router Class Initialized
INFO - 2020-10-07 05:19:57 --> Output Class Initialized
INFO - 2020-10-07 05:19:57 --> Security Class Initialized
DEBUG - 2020-10-07 05:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:19:57 --> Input Class Initialized
INFO - 2020-10-07 05:19:57 --> Language Class Initialized
ERROR - 2020-10-07 05:19:57 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 05:20:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:20:01 --> Config Class Initialized
INFO - 2020-10-07 05:20:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:20:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:20:01 --> Utf8 Class Initialized
INFO - 2020-10-07 05:20:01 --> URI Class Initialized
INFO - 2020-10-07 05:20:01 --> Router Class Initialized
INFO - 2020-10-07 05:20:01 --> Output Class Initialized
INFO - 2020-10-07 05:20:01 --> Security Class Initialized
DEBUG - 2020-10-07 05:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:20:01 --> Input Class Initialized
INFO - 2020-10-07 05:20:01 --> Language Class Initialized
INFO - 2020-10-07 05:20:01 --> Loader Class Initialized
INFO - 2020-10-07 05:20:01 --> Helper loaded: url_helper
INFO - 2020-10-07 05:20:01 --> Database Driver Class Initialized
INFO - 2020-10-07 05:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:20:01 --> Email Class Initialized
INFO - 2020-10-07 05:20:01 --> Controller Class Initialized
DEBUG - 2020-10-07 05:20:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:20:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:20:01 --> Model Class Initialized
INFO - 2020-10-07 05:20:01 --> Model Class Initialized
INFO - 2020-10-07 05:20:01 --> Final output sent to browser
DEBUG - 2020-10-07 05:20:01 --> Total execution time: 0.0202
ERROR - 2020-10-07 05:20:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:20:02 --> Config Class Initialized
INFO - 2020-10-07 05:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:20:02 --> Utf8 Class Initialized
INFO - 2020-10-07 05:20:02 --> URI Class Initialized
INFO - 2020-10-07 05:20:02 --> Router Class Initialized
INFO - 2020-10-07 05:20:02 --> Output Class Initialized
INFO - 2020-10-07 05:20:02 --> Security Class Initialized
DEBUG - 2020-10-07 05:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:20:02 --> Input Class Initialized
INFO - 2020-10-07 05:20:02 --> Language Class Initialized
INFO - 2020-10-07 05:20:02 --> Loader Class Initialized
INFO - 2020-10-07 05:20:02 --> Helper loaded: url_helper
INFO - 2020-10-07 05:20:02 --> Database Driver Class Initialized
INFO - 2020-10-07 05:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:20:02 --> Email Class Initialized
INFO - 2020-10-07 05:20:02 --> Controller Class Initialized
DEBUG - 2020-10-07 05:20:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:20:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:20:02 --> Model Class Initialized
INFO - 2020-10-07 05:20:02 --> Model Class Initialized
INFO - 2020-10-07 05:20:02 --> Final output sent to browser
DEBUG - 2020-10-07 05:20:02 --> Total execution time: 0.0207
ERROR - 2020-10-07 05:20:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:20:11 --> Config Class Initialized
INFO - 2020-10-07 05:20:11 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:20:11 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:20:11 --> Utf8 Class Initialized
INFO - 2020-10-07 05:20:11 --> URI Class Initialized
INFO - 2020-10-07 05:20:11 --> Router Class Initialized
INFO - 2020-10-07 05:20:11 --> Output Class Initialized
INFO - 2020-10-07 05:20:11 --> Security Class Initialized
DEBUG - 2020-10-07 05:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:20:11 --> Input Class Initialized
INFO - 2020-10-07 05:20:11 --> Language Class Initialized
INFO - 2020-10-07 05:20:11 --> Loader Class Initialized
INFO - 2020-10-07 05:20:11 --> Helper loaded: url_helper
INFO - 2020-10-07 05:20:11 --> Database Driver Class Initialized
INFO - 2020-10-07 05:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:20:11 --> Email Class Initialized
INFO - 2020-10-07 05:20:11 --> Controller Class Initialized
DEBUG - 2020-10-07 05:20:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:20:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:20:11 --> Model Class Initialized
INFO - 2020-10-07 05:20:11 --> Model Class Initialized
INFO - 2020-10-07 05:20:11 --> Final output sent to browser
DEBUG - 2020-10-07 05:20:11 --> Total execution time: 0.0201
ERROR - 2020-10-07 05:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:20:54 --> Config Class Initialized
INFO - 2020-10-07 05:20:54 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:20:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:20:54 --> Utf8 Class Initialized
INFO - 2020-10-07 05:20:54 --> URI Class Initialized
INFO - 2020-10-07 05:20:54 --> Router Class Initialized
INFO - 2020-10-07 05:20:54 --> Output Class Initialized
INFO - 2020-10-07 05:20:54 --> Security Class Initialized
DEBUG - 2020-10-07 05:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:20:54 --> Input Class Initialized
INFO - 2020-10-07 05:20:54 --> Language Class Initialized
INFO - 2020-10-07 05:20:54 --> Loader Class Initialized
INFO - 2020-10-07 05:20:54 --> Helper loaded: url_helper
INFO - 2020-10-07 05:20:54 --> Database Driver Class Initialized
INFO - 2020-10-07 05:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:20:54 --> Email Class Initialized
INFO - 2020-10-07 05:20:54 --> Controller Class Initialized
DEBUG - 2020-10-07 05:20:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:20:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:20:54 --> Model Class Initialized
INFO - 2020-10-07 05:20:54 --> Model Class Initialized
INFO - 2020-10-07 05:20:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 05:20:54 --> Final output sent to browser
DEBUG - 2020-10-07 05:20:54 --> Total execution time: 0.0233
ERROR - 2020-10-07 05:21:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:21:01 --> Config Class Initialized
INFO - 2020-10-07 05:21:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:21:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:21:01 --> Utf8 Class Initialized
INFO - 2020-10-07 05:21:01 --> URI Class Initialized
INFO - 2020-10-07 05:21:01 --> Router Class Initialized
INFO - 2020-10-07 05:21:01 --> Output Class Initialized
INFO - 2020-10-07 05:21:01 --> Security Class Initialized
DEBUG - 2020-10-07 05:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:21:01 --> Input Class Initialized
INFO - 2020-10-07 05:21:01 --> Language Class Initialized
INFO - 2020-10-07 05:21:01 --> Loader Class Initialized
INFO - 2020-10-07 05:21:01 --> Helper loaded: url_helper
INFO - 2020-10-07 05:21:01 --> Database Driver Class Initialized
INFO - 2020-10-07 05:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:21:01 --> Email Class Initialized
INFO - 2020-10-07 05:21:01 --> Controller Class Initialized
INFO - 2020-10-07 05:21:01 --> Model Class Initialized
INFO - 2020-10-07 05:21:01 --> Model Class Initialized
INFO - 2020-10-07 05:21:01 --> Model Class Initialized
INFO - 2020-10-07 05:21:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 05:21:01 --> Final output sent to browser
DEBUG - 2020-10-07 05:21:01 --> Total execution time: 0.2056
ERROR - 2020-10-07 05:21:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:21:02 --> Config Class Initialized
INFO - 2020-10-07 05:21:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:21:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:21:02 --> Utf8 Class Initialized
INFO - 2020-10-07 05:21:02 --> URI Class Initialized
INFO - 2020-10-07 05:21:02 --> Router Class Initialized
INFO - 2020-10-07 05:21:02 --> Output Class Initialized
INFO - 2020-10-07 05:21:02 --> Security Class Initialized
DEBUG - 2020-10-07 05:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:21:02 --> Input Class Initialized
INFO - 2020-10-07 05:21:02 --> Language Class Initialized
INFO - 2020-10-07 05:21:02 --> Loader Class Initialized
INFO - 2020-10-07 05:21:02 --> Helper loaded: url_helper
INFO - 2020-10-07 05:21:02 --> Database Driver Class Initialized
INFO - 2020-10-07 05:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:21:02 --> Email Class Initialized
INFO - 2020-10-07 05:21:02 --> Controller Class Initialized
INFO - 2020-10-07 05:21:02 --> Model Class Initialized
INFO - 2020-10-07 05:21:02 --> Model Class Initialized
INFO - 2020-10-07 05:21:02 --> Final output sent to browser
DEBUG - 2020-10-07 05:21:02 --> Total execution time: 0.0481
ERROR - 2020-10-07 05:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:21:12 --> Config Class Initialized
INFO - 2020-10-07 05:21:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:21:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:21:12 --> Utf8 Class Initialized
INFO - 2020-10-07 05:21:12 --> URI Class Initialized
INFO - 2020-10-07 05:21:12 --> Router Class Initialized
INFO - 2020-10-07 05:21:12 --> Output Class Initialized
INFO - 2020-10-07 05:21:12 --> Security Class Initialized
DEBUG - 2020-10-07 05:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:21:12 --> Input Class Initialized
INFO - 2020-10-07 05:21:12 --> Language Class Initialized
INFO - 2020-10-07 05:21:12 --> Loader Class Initialized
INFO - 2020-10-07 05:21:12 --> Helper loaded: url_helper
INFO - 2020-10-07 05:21:12 --> Database Driver Class Initialized
INFO - 2020-10-07 05:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:21:12 --> Email Class Initialized
INFO - 2020-10-07 05:21:12 --> Controller Class Initialized
DEBUG - 2020-10-07 05:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:21:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:21:12 --> Model Class Initialized
INFO - 2020-10-07 05:21:12 --> Model Class Initialized
INFO - 2020-10-07 05:21:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 05:21:12 --> Final output sent to browser
DEBUG - 2020-10-07 05:21:12 --> Total execution time: 0.0424
ERROR - 2020-10-07 05:23:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:23:25 --> Config Class Initialized
INFO - 2020-10-07 05:23:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:23:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:23:25 --> Utf8 Class Initialized
INFO - 2020-10-07 05:23:25 --> URI Class Initialized
INFO - 2020-10-07 05:23:25 --> Router Class Initialized
INFO - 2020-10-07 05:23:25 --> Output Class Initialized
INFO - 2020-10-07 05:23:25 --> Security Class Initialized
DEBUG - 2020-10-07 05:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:23:25 --> Input Class Initialized
INFO - 2020-10-07 05:23:25 --> Language Class Initialized
INFO - 2020-10-07 05:23:25 --> Loader Class Initialized
INFO - 2020-10-07 05:23:25 --> Helper loaded: url_helper
INFO - 2020-10-07 05:23:25 --> Database Driver Class Initialized
INFO - 2020-10-07 05:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:23:25 --> Email Class Initialized
INFO - 2020-10-07 05:23:25 --> Controller Class Initialized
DEBUG - 2020-10-07 05:23:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:23:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:23:25 --> Model Class Initialized
INFO - 2020-10-07 05:23:25 --> Model Class Initialized
INFO - 2020-10-07 05:23:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 05:23:25 --> Final output sent to browser
DEBUG - 2020-10-07 05:23:25 --> Total execution time: 0.0616
ERROR - 2020-10-07 05:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:24:10 --> Config Class Initialized
INFO - 2020-10-07 05:24:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:24:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:24:10 --> Utf8 Class Initialized
INFO - 2020-10-07 05:24:10 --> URI Class Initialized
INFO - 2020-10-07 05:24:10 --> Router Class Initialized
INFO - 2020-10-07 05:24:10 --> Output Class Initialized
INFO - 2020-10-07 05:24:10 --> Security Class Initialized
DEBUG - 2020-10-07 05:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:24:10 --> Input Class Initialized
INFO - 2020-10-07 05:24:10 --> Language Class Initialized
INFO - 2020-10-07 05:24:10 --> Loader Class Initialized
INFO - 2020-10-07 05:24:10 --> Helper loaded: url_helper
INFO - 2020-10-07 05:24:10 --> Database Driver Class Initialized
INFO - 2020-10-07 05:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:24:10 --> Email Class Initialized
INFO - 2020-10-07 05:24:10 --> Controller Class Initialized
DEBUG - 2020-10-07 05:24:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:24:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:24:10 --> Model Class Initialized
INFO - 2020-10-07 05:24:10 --> Model Class Initialized
INFO - 2020-10-07 05:24:10 --> Model Class Initialized
INFO - 2020-10-07 05:24:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-07 05:24:10 --> Final output sent to browser
DEBUG - 2020-10-07 05:24:10 --> Total execution time: 0.0467
ERROR - 2020-10-07 05:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:25:10 --> Config Class Initialized
INFO - 2020-10-07 05:25:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:25:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:25:10 --> Utf8 Class Initialized
INFO - 2020-10-07 05:25:10 --> URI Class Initialized
INFO - 2020-10-07 05:25:10 --> Router Class Initialized
INFO - 2020-10-07 05:25:10 --> Output Class Initialized
INFO - 2020-10-07 05:25:10 --> Security Class Initialized
DEBUG - 2020-10-07 05:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:25:10 --> Input Class Initialized
INFO - 2020-10-07 05:25:10 --> Language Class Initialized
INFO - 2020-10-07 05:25:10 --> Loader Class Initialized
INFO - 2020-10-07 05:25:10 --> Helper loaded: url_helper
INFO - 2020-10-07 05:25:10 --> Database Driver Class Initialized
INFO - 2020-10-07 05:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:25:10 --> Email Class Initialized
INFO - 2020-10-07 05:25:10 --> Controller Class Initialized
DEBUG - 2020-10-07 05:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:25:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:25:10 --> Model Class Initialized
INFO - 2020-10-07 05:25:10 --> Model Class Initialized
INFO - 2020-10-07 05:25:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 05:25:10 --> Final output sent to browser
DEBUG - 2020-10-07 05:25:10 --> Total execution time: 0.0221
ERROR - 2020-10-07 05:29:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:29:25 --> Config Class Initialized
INFO - 2020-10-07 05:29:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:29:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:29:25 --> Utf8 Class Initialized
INFO - 2020-10-07 05:29:25 --> URI Class Initialized
INFO - 2020-10-07 05:29:25 --> Router Class Initialized
INFO - 2020-10-07 05:29:25 --> Output Class Initialized
INFO - 2020-10-07 05:29:25 --> Security Class Initialized
DEBUG - 2020-10-07 05:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:29:25 --> Input Class Initialized
INFO - 2020-10-07 05:29:25 --> Language Class Initialized
INFO - 2020-10-07 05:29:25 --> Loader Class Initialized
INFO - 2020-10-07 05:29:25 --> Helper loaded: url_helper
INFO - 2020-10-07 05:29:25 --> Database Driver Class Initialized
INFO - 2020-10-07 05:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:29:25 --> Email Class Initialized
INFO - 2020-10-07 05:29:25 --> Controller Class Initialized
DEBUG - 2020-10-07 05:29:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:29:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:29:25 --> Model Class Initialized
INFO - 2020-10-07 05:29:25 --> Model Class Initialized
INFO - 2020-10-07 05:29:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 05:29:25 --> Final output sent to browser
DEBUG - 2020-10-07 05:29:25 --> Total execution time: 0.0217
ERROR - 2020-10-07 05:29:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:29:58 --> Config Class Initialized
INFO - 2020-10-07 05:29:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:29:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:29:58 --> Utf8 Class Initialized
INFO - 2020-10-07 05:29:58 --> URI Class Initialized
INFO - 2020-10-07 05:29:58 --> Router Class Initialized
INFO - 2020-10-07 05:29:58 --> Output Class Initialized
INFO - 2020-10-07 05:29:58 --> Security Class Initialized
DEBUG - 2020-10-07 05:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:29:58 --> Input Class Initialized
INFO - 2020-10-07 05:29:58 --> Language Class Initialized
INFO - 2020-10-07 05:29:58 --> Loader Class Initialized
INFO - 2020-10-07 05:29:58 --> Helper loaded: url_helper
INFO - 2020-10-07 05:29:58 --> Database Driver Class Initialized
INFO - 2020-10-07 05:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:29:58 --> Email Class Initialized
INFO - 2020-10-07 05:29:58 --> Controller Class Initialized
DEBUG - 2020-10-07 05:29:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:29:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:29:58 --> Model Class Initialized
INFO - 2020-10-07 05:29:58 --> Model Class Initialized
INFO - 2020-10-07 05:29:58 --> Model Class Initialized
INFO - 2020-10-07 05:29:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-07 05:29:58 --> Final output sent to browser
DEBUG - 2020-10-07 05:29:58 --> Total execution time: 0.0255
ERROR - 2020-10-07 05:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:31:09 --> Config Class Initialized
INFO - 2020-10-07 05:31:09 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:31:09 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:31:09 --> Utf8 Class Initialized
INFO - 2020-10-07 05:31:09 --> URI Class Initialized
DEBUG - 2020-10-07 05:31:09 --> No URI present. Default controller set.
INFO - 2020-10-07 05:31:09 --> Router Class Initialized
INFO - 2020-10-07 05:31:09 --> Output Class Initialized
INFO - 2020-10-07 05:31:09 --> Security Class Initialized
DEBUG - 2020-10-07 05:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:31:09 --> Input Class Initialized
INFO - 2020-10-07 05:31:09 --> Language Class Initialized
INFO - 2020-10-07 05:31:09 --> Loader Class Initialized
INFO - 2020-10-07 05:31:09 --> Helper loaded: url_helper
INFO - 2020-10-07 05:31:09 --> Database Driver Class Initialized
INFO - 2020-10-07 05:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:31:09 --> Email Class Initialized
INFO - 2020-10-07 05:31:09 --> Controller Class Initialized
INFO - 2020-10-07 05:31:09 --> Model Class Initialized
INFO - 2020-10-07 05:31:09 --> Model Class Initialized
DEBUG - 2020-10-07 05:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:31:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:31:09 --> Final output sent to browser
DEBUG - 2020-10-07 05:31:09 --> Total execution time: 0.0199
ERROR - 2020-10-07 05:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:31:26 --> Config Class Initialized
INFO - 2020-10-07 05:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:31:26 --> Utf8 Class Initialized
INFO - 2020-10-07 05:31:26 --> URI Class Initialized
INFO - 2020-10-07 05:31:26 --> Router Class Initialized
INFO - 2020-10-07 05:31:26 --> Output Class Initialized
INFO - 2020-10-07 05:31:26 --> Security Class Initialized
DEBUG - 2020-10-07 05:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:31:26 --> Input Class Initialized
INFO - 2020-10-07 05:31:26 --> Language Class Initialized
INFO - 2020-10-07 05:31:26 --> Loader Class Initialized
INFO - 2020-10-07 05:31:26 --> Helper loaded: url_helper
INFO - 2020-10-07 05:31:26 --> Database Driver Class Initialized
INFO - 2020-10-07 05:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:31:26 --> Email Class Initialized
INFO - 2020-10-07 05:31:26 --> Controller Class Initialized
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
DEBUG - 2020-10-07 05:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:31:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
INFO - 2020-10-07 05:31:26 --> Final output sent to browser
DEBUG - 2020-10-07 05:31:26 --> Total execution time: 0.0211
ERROR - 2020-10-07 05:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:31:26 --> Config Class Initialized
INFO - 2020-10-07 05:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:31:26 --> Utf8 Class Initialized
INFO - 2020-10-07 05:31:26 --> URI Class Initialized
INFO - 2020-10-07 05:31:26 --> Router Class Initialized
INFO - 2020-10-07 05:31:26 --> Output Class Initialized
INFO - 2020-10-07 05:31:26 --> Security Class Initialized
DEBUG - 2020-10-07 05:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:31:26 --> Input Class Initialized
INFO - 2020-10-07 05:31:26 --> Language Class Initialized
INFO - 2020-10-07 05:31:26 --> Loader Class Initialized
INFO - 2020-10-07 05:31:26 --> Helper loaded: url_helper
INFO - 2020-10-07 05:31:26 --> Database Driver Class Initialized
INFO - 2020-10-07 05:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:31:26 --> Email Class Initialized
INFO - 2020-10-07 05:31:26 --> Controller Class Initialized
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
DEBUG - 2020-10-07 05:31:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 05:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:31:26 --> Config Class Initialized
INFO - 2020-10-07 05:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:31:26 --> Utf8 Class Initialized
INFO - 2020-10-07 05:31:26 --> URI Class Initialized
INFO - 2020-10-07 05:31:26 --> Router Class Initialized
INFO - 2020-10-07 05:31:26 --> Output Class Initialized
INFO - 2020-10-07 05:31:26 --> Security Class Initialized
DEBUG - 2020-10-07 05:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:31:26 --> Input Class Initialized
INFO - 2020-10-07 05:31:26 --> Language Class Initialized
INFO - 2020-10-07 05:31:26 --> Loader Class Initialized
INFO - 2020-10-07 05:31:26 --> Helper loaded: url_helper
INFO - 2020-10-07 05:31:26 --> Database Driver Class Initialized
INFO - 2020-10-07 05:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:31:26 --> Email Class Initialized
INFO - 2020-10-07 05:31:26 --> Controller Class Initialized
DEBUG - 2020-10-07 05:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:31:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
INFO - 2020-10-07 05:31:26 --> Model Class Initialized
INFO - 2020-10-07 05:31:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-07 05:31:26 --> Final output sent to browser
DEBUG - 2020-10-07 05:31:26 --> Total execution time: 0.0364
ERROR - 2020-10-07 05:33:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:33:21 --> Config Class Initialized
INFO - 2020-10-07 05:33:21 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:33:21 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:33:21 --> Utf8 Class Initialized
INFO - 2020-10-07 05:33:21 --> URI Class Initialized
DEBUG - 2020-10-07 05:33:21 --> No URI present. Default controller set.
INFO - 2020-10-07 05:33:21 --> Router Class Initialized
INFO - 2020-10-07 05:33:21 --> Output Class Initialized
INFO - 2020-10-07 05:33:21 --> Security Class Initialized
DEBUG - 2020-10-07 05:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:33:21 --> Input Class Initialized
INFO - 2020-10-07 05:33:21 --> Language Class Initialized
INFO - 2020-10-07 05:33:21 --> Loader Class Initialized
INFO - 2020-10-07 05:33:21 --> Helper loaded: url_helper
INFO - 2020-10-07 05:33:21 --> Database Driver Class Initialized
INFO - 2020-10-07 05:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:33:21 --> Email Class Initialized
INFO - 2020-10-07 05:33:21 --> Controller Class Initialized
INFO - 2020-10-07 05:33:21 --> Model Class Initialized
INFO - 2020-10-07 05:33:21 --> Model Class Initialized
DEBUG - 2020-10-07 05:33:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:33:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:33:21 --> Final output sent to browser
DEBUG - 2020-10-07 05:33:21 --> Total execution time: 0.0165
ERROR - 2020-10-07 05:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:33:48 --> Config Class Initialized
INFO - 2020-10-07 05:33:48 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:33:48 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:33:48 --> Utf8 Class Initialized
INFO - 2020-10-07 05:33:48 --> URI Class Initialized
INFO - 2020-10-07 05:33:48 --> Router Class Initialized
INFO - 2020-10-07 05:33:48 --> Output Class Initialized
INFO - 2020-10-07 05:33:48 --> Security Class Initialized
DEBUG - 2020-10-07 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:33:48 --> Input Class Initialized
INFO - 2020-10-07 05:33:48 --> Language Class Initialized
INFO - 2020-10-07 05:33:48 --> Loader Class Initialized
INFO - 2020-10-07 05:33:48 --> Helper loaded: url_helper
INFO - 2020-10-07 05:33:48 --> Database Driver Class Initialized
INFO - 2020-10-07 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:33:48 --> Email Class Initialized
INFO - 2020-10-07 05:33:48 --> Controller Class Initialized
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
DEBUG - 2020-10-07 05:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:33:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
INFO - 2020-10-07 05:33:48 --> Final output sent to browser
DEBUG - 2020-10-07 05:33:48 --> Total execution time: 0.0207
ERROR - 2020-10-07 05:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:33:48 --> Config Class Initialized
INFO - 2020-10-07 05:33:48 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:33:48 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:33:48 --> Utf8 Class Initialized
INFO - 2020-10-07 05:33:48 --> URI Class Initialized
INFO - 2020-10-07 05:33:48 --> Router Class Initialized
INFO - 2020-10-07 05:33:48 --> Output Class Initialized
INFO - 2020-10-07 05:33:48 --> Security Class Initialized
DEBUG - 2020-10-07 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:33:48 --> Input Class Initialized
INFO - 2020-10-07 05:33:48 --> Language Class Initialized
INFO - 2020-10-07 05:33:48 --> Loader Class Initialized
INFO - 2020-10-07 05:33:48 --> Helper loaded: url_helper
INFO - 2020-10-07 05:33:48 --> Database Driver Class Initialized
INFO - 2020-10-07 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:33:48 --> Email Class Initialized
INFO - 2020-10-07 05:33:48 --> Controller Class Initialized
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
DEBUG - 2020-10-07 05:33:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 05:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:33:48 --> Config Class Initialized
INFO - 2020-10-07 05:33:48 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:33:48 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:33:48 --> Utf8 Class Initialized
INFO - 2020-10-07 05:33:48 --> URI Class Initialized
DEBUG - 2020-10-07 05:33:48 --> No URI present. Default controller set.
INFO - 2020-10-07 05:33:48 --> Router Class Initialized
INFO - 2020-10-07 05:33:48 --> Output Class Initialized
INFO - 2020-10-07 05:33:48 --> Security Class Initialized
DEBUG - 2020-10-07 05:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:33:48 --> Input Class Initialized
INFO - 2020-10-07 05:33:48 --> Language Class Initialized
INFO - 2020-10-07 05:33:48 --> Loader Class Initialized
INFO - 2020-10-07 05:33:48 --> Helper loaded: url_helper
INFO - 2020-10-07 05:33:48 --> Database Driver Class Initialized
INFO - 2020-10-07 05:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:33:48 --> Email Class Initialized
INFO - 2020-10-07 05:33:48 --> Controller Class Initialized
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
INFO - 2020-10-07 05:33:48 --> Model Class Initialized
DEBUG - 2020-10-07 05:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:33:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:33:48 --> Final output sent to browser
DEBUG - 2020-10-07 05:33:48 --> Total execution time: 0.0201
ERROR - 2020-10-07 05:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:34:14 --> Config Class Initialized
INFO - 2020-10-07 05:34:14 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:34:14 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:34:14 --> Utf8 Class Initialized
INFO - 2020-10-07 05:34:14 --> URI Class Initialized
INFO - 2020-10-07 05:34:14 --> Router Class Initialized
INFO - 2020-10-07 05:34:14 --> Output Class Initialized
INFO - 2020-10-07 05:34:14 --> Security Class Initialized
DEBUG - 2020-10-07 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:34:14 --> Input Class Initialized
INFO - 2020-10-07 05:34:14 --> Language Class Initialized
INFO - 2020-10-07 05:34:14 --> Loader Class Initialized
INFO - 2020-10-07 05:34:14 --> Helper loaded: url_helper
ERROR - 2020-10-07 05:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:34:14 --> Config Class Initialized
INFO - 2020-10-07 05:34:14 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:34:14 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:34:14 --> Utf8 Class Initialized
INFO - 2020-10-07 05:34:14 --> Database Driver Class Initialized
INFO - 2020-10-07 05:34:14 --> URI Class Initialized
INFO - 2020-10-07 05:34:14 --> Router Class Initialized
INFO - 2020-10-07 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:34:14 --> Output Class Initialized
INFO - 2020-10-07 05:34:14 --> Security Class Initialized
INFO - 2020-10-07 05:34:14 --> Email Class Initialized
INFO - 2020-10-07 05:34:14 --> Controller Class Initialized
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:34:14 --> Input Class Initialized
INFO - 2020-10-07 05:34:14 --> Language Class Initialized
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:34:14 --> Loader Class Initialized
INFO - 2020-10-07 05:34:14 --> Helper loaded: url_helper
INFO - 2020-10-07 05:34:14 --> Database Driver Class Initialized
INFO - 2020-10-07 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:34:14 --> Email Class Initialized
INFO - 2020-10-07 05:34:14 --> Controller Class Initialized
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:34:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
INFO - 2020-10-07 05:34:14 --> Final output sent to browser
DEBUG - 2020-10-07 05:34:14 --> Total execution time: 0.0317
ERROR - 2020-10-07 05:34:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:34:14 --> Config Class Initialized
INFO - 2020-10-07 05:34:14 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:34:14 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:34:14 --> Utf8 Class Initialized
INFO - 2020-10-07 05:34:14 --> URI Class Initialized
DEBUG - 2020-10-07 05:34:14 --> No URI present. Default controller set.
INFO - 2020-10-07 05:34:14 --> Router Class Initialized
INFO - 2020-10-07 05:34:14 --> Output Class Initialized
INFO - 2020-10-07 05:34:14 --> Security Class Initialized
DEBUG - 2020-10-07 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:34:14 --> Input Class Initialized
INFO - 2020-10-07 05:34:14 --> Language Class Initialized
INFO - 2020-10-07 05:34:14 --> Loader Class Initialized
INFO - 2020-10-07 05:34:14 --> Helper loaded: url_helper
INFO - 2020-10-07 05:34:14 --> Database Driver Class Initialized
INFO - 2020-10-07 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:34:14 --> Email Class Initialized
INFO - 2020-10-07 05:34:14 --> Controller Class Initialized
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
INFO - 2020-10-07 05:34:14 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:34:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:34:14 --> Final output sent to browser
DEBUG - 2020-10-07 05:34:14 --> Total execution time: 0.0206
ERROR - 2020-10-07 05:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:34:28 --> Config Class Initialized
INFO - 2020-10-07 05:34:28 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:34:28 --> Utf8 Class Initialized
INFO - 2020-10-07 05:34:28 --> URI Class Initialized
INFO - 2020-10-07 05:34:28 --> Router Class Initialized
INFO - 2020-10-07 05:34:28 --> Output Class Initialized
INFO - 2020-10-07 05:34:28 --> Security Class Initialized
DEBUG - 2020-10-07 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:34:28 --> Input Class Initialized
INFO - 2020-10-07 05:34:28 --> Language Class Initialized
INFO - 2020-10-07 05:34:28 --> Loader Class Initialized
INFO - 2020-10-07 05:34:28 --> Helper loaded: url_helper
INFO - 2020-10-07 05:34:28 --> Database Driver Class Initialized
ERROR - 2020-10-07 05:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:34:28 --> Config Class Initialized
INFO - 2020-10-07 05:34:28 --> Hooks Class Initialized
INFO - 2020-10-07 05:34:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-07 05:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:34:28 --> Utf8 Class Initialized
INFO - 2020-10-07 05:34:28 --> URI Class Initialized
INFO - 2020-10-07 05:34:28 --> Router Class Initialized
INFO - 2020-10-07 05:34:28 --> Email Class Initialized
INFO - 2020-10-07 05:34:28 --> Controller Class Initialized
INFO - 2020-10-07 05:34:28 --> Model Class Initialized
INFO - 2020-10-07 05:34:28 --> Output Class Initialized
INFO - 2020-10-07 05:34:28 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:34:28 --> Security Class Initialized
DEBUG - 2020-10-07 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:34:28 --> Input Class Initialized
INFO - 2020-10-07 05:34:28 --> Language Class Initialized
INFO - 2020-10-07 05:34:28 --> Loader Class Initialized
INFO - 2020-10-07 05:34:28 --> Helper loaded: url_helper
INFO - 2020-10-07 05:34:28 --> Database Driver Class Initialized
INFO - 2020-10-07 05:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:34:28 --> Email Class Initialized
INFO - 2020-10-07 05:34:28 --> Controller Class Initialized
INFO - 2020-10-07 05:34:28 --> Model Class Initialized
INFO - 2020-10-07 05:34:28 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:34:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:34:28 --> Model Class Initialized
INFO - 2020-10-07 05:34:28 --> Final output sent to browser
DEBUG - 2020-10-07 05:34:28 --> Total execution time: 0.0226
ERROR - 2020-10-07 05:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:34:29 --> Config Class Initialized
INFO - 2020-10-07 05:34:29 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:34:29 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:34:29 --> Utf8 Class Initialized
INFO - 2020-10-07 05:34:29 --> URI Class Initialized
DEBUG - 2020-10-07 05:34:29 --> No URI present. Default controller set.
INFO - 2020-10-07 05:34:29 --> Router Class Initialized
INFO - 2020-10-07 05:34:29 --> Output Class Initialized
INFO - 2020-10-07 05:34:29 --> Security Class Initialized
DEBUG - 2020-10-07 05:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:34:29 --> Input Class Initialized
INFO - 2020-10-07 05:34:29 --> Language Class Initialized
INFO - 2020-10-07 05:34:29 --> Loader Class Initialized
INFO - 2020-10-07 05:34:29 --> Helper loaded: url_helper
INFO - 2020-10-07 05:34:29 --> Database Driver Class Initialized
INFO - 2020-10-07 05:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:34:29 --> Email Class Initialized
INFO - 2020-10-07 05:34:29 --> Controller Class Initialized
INFO - 2020-10-07 05:34:29 --> Model Class Initialized
INFO - 2020-10-07 05:34:29 --> Model Class Initialized
DEBUG - 2020-10-07 05:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:34:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:34:29 --> Final output sent to browser
DEBUG - 2020-10-07 05:34:29 --> Total execution time: 0.0221
ERROR - 2020-10-07 05:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:35:45 --> Config Class Initialized
INFO - 2020-10-07 05:35:45 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:35:45 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:35:45 --> Utf8 Class Initialized
INFO - 2020-10-07 05:35:45 --> URI Class Initialized
INFO - 2020-10-07 05:35:45 --> Router Class Initialized
INFO - 2020-10-07 05:35:45 --> Output Class Initialized
INFO - 2020-10-07 05:35:45 --> Security Class Initialized
DEBUG - 2020-10-07 05:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:35:45 --> Input Class Initialized
INFO - 2020-10-07 05:35:45 --> Language Class Initialized
INFO - 2020-10-07 05:35:45 --> Loader Class Initialized
INFO - 2020-10-07 05:35:45 --> Helper loaded: url_helper
INFO - 2020-10-07 05:35:45 --> Database Driver Class Initialized
INFO - 2020-10-07 05:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:35:45 --> Email Class Initialized
INFO - 2020-10-07 05:35:45 --> Controller Class Initialized
INFO - 2020-10-07 05:35:45 --> Model Class Initialized
INFO - 2020-10-07 05:35:45 --> Model Class Initialized
DEBUG - 2020-10-07 05:35:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 05:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:35:45 --> Config Class Initialized
INFO - 2020-10-07 05:35:45 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:35:45 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:35:45 --> Utf8 Class Initialized
INFO - 2020-10-07 05:35:45 --> URI Class Initialized
INFO - 2020-10-07 05:35:45 --> Router Class Initialized
INFO - 2020-10-07 05:35:45 --> Output Class Initialized
INFO - 2020-10-07 05:35:45 --> Security Class Initialized
DEBUG - 2020-10-07 05:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:35:45 --> Input Class Initialized
INFO - 2020-10-07 05:35:45 --> Language Class Initialized
INFO - 2020-10-07 05:35:45 --> Loader Class Initialized
INFO - 2020-10-07 05:35:45 --> Helper loaded: url_helper
INFO - 2020-10-07 05:35:45 --> Database Driver Class Initialized
INFO - 2020-10-07 05:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:35:45 --> Email Class Initialized
INFO - 2020-10-07 05:35:45 --> Controller Class Initialized
INFO - 2020-10-07 05:35:45 --> Model Class Initialized
INFO - 2020-10-07 05:35:45 --> Model Class Initialized
DEBUG - 2020-10-07 05:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:35:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:35:45 --> Model Class Initialized
INFO - 2020-10-07 05:35:45 --> Final output sent to browser
DEBUG - 2020-10-07 05:35:45 --> Total execution time: 0.0209
ERROR - 2020-10-07 05:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:35:46 --> Config Class Initialized
INFO - 2020-10-07 05:35:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:35:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:35:46 --> Utf8 Class Initialized
INFO - 2020-10-07 05:35:46 --> URI Class Initialized
INFO - 2020-10-07 05:35:46 --> Router Class Initialized
INFO - 2020-10-07 05:35:46 --> Output Class Initialized
INFO - 2020-10-07 05:35:46 --> Security Class Initialized
DEBUG - 2020-10-07 05:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:35:46 --> Input Class Initialized
INFO - 2020-10-07 05:35:46 --> Language Class Initialized
INFO - 2020-10-07 05:35:46 --> Loader Class Initialized
INFO - 2020-10-07 05:35:46 --> Helper loaded: url_helper
INFO - 2020-10-07 05:35:46 --> Database Driver Class Initialized
INFO - 2020-10-07 05:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:35:46 --> Email Class Initialized
INFO - 2020-10-07 05:35:46 --> Controller Class Initialized
DEBUG - 2020-10-07 05:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:35:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:35:46 --> Model Class Initialized
INFO - 2020-10-07 05:35:46 --> Model Class Initialized
INFO - 2020-10-07 05:35:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-07 05:35:46 --> Final output sent to browser
DEBUG - 2020-10-07 05:35:46 --> Total execution time: 0.0416
ERROR - 2020-10-07 05:36:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:36:05 --> Config Class Initialized
INFO - 2020-10-07 05:36:05 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:36:05 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:36:05 --> Utf8 Class Initialized
INFO - 2020-10-07 05:36:05 --> URI Class Initialized
INFO - 2020-10-07 05:36:05 --> Router Class Initialized
INFO - 2020-10-07 05:36:05 --> Output Class Initialized
INFO - 2020-10-07 05:36:05 --> Security Class Initialized
DEBUG - 2020-10-07 05:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:36:05 --> Input Class Initialized
INFO - 2020-10-07 05:36:05 --> Language Class Initialized
INFO - 2020-10-07 05:36:05 --> Loader Class Initialized
INFO - 2020-10-07 05:36:05 --> Helper loaded: url_helper
INFO - 2020-10-07 05:36:05 --> Database Driver Class Initialized
INFO - 2020-10-07 05:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:36:05 --> Email Class Initialized
INFO - 2020-10-07 05:36:05 --> Controller Class Initialized
DEBUG - 2020-10-07 05:36:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:36:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:36:05 --> Model Class Initialized
INFO - 2020-10-07 05:36:05 --> Model Class Initialized
INFO - 2020-10-07 05:36:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-07 05:36:05 --> Final output sent to browser
DEBUG - 2020-10-07 05:36:05 --> Total execution time: 0.0256
ERROR - 2020-10-07 05:36:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:36:11 --> Config Class Initialized
INFO - 2020-10-07 05:36:11 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:36:11 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:36:11 --> Utf8 Class Initialized
INFO - 2020-10-07 05:36:11 --> URI Class Initialized
INFO - 2020-10-07 05:36:11 --> Router Class Initialized
INFO - 2020-10-07 05:36:11 --> Output Class Initialized
INFO - 2020-10-07 05:36:11 --> Security Class Initialized
DEBUG - 2020-10-07 05:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:36:11 --> Input Class Initialized
INFO - 2020-10-07 05:36:11 --> Language Class Initialized
INFO - 2020-10-07 05:36:11 --> Loader Class Initialized
INFO - 2020-10-07 05:36:11 --> Helper loaded: url_helper
INFO - 2020-10-07 05:36:11 --> Database Driver Class Initialized
INFO - 2020-10-07 05:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:36:11 --> Email Class Initialized
INFO - 2020-10-07 05:36:11 --> Controller Class Initialized
DEBUG - 2020-10-07 05:36:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:36:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:36:11 --> Model Class Initialized
INFO - 2020-10-07 05:36:11 --> Model Class Initialized
INFO - 2020-10-07 05:36:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-07 05:36:11 --> Final output sent to browser
DEBUG - 2020-10-07 05:36:11 --> Total execution time: 0.0233
ERROR - 2020-10-07 05:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:36:19 --> Config Class Initialized
INFO - 2020-10-07 05:36:19 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:36:19 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:36:19 --> Utf8 Class Initialized
INFO - 2020-10-07 05:36:19 --> URI Class Initialized
INFO - 2020-10-07 05:36:19 --> Router Class Initialized
INFO - 2020-10-07 05:36:19 --> Output Class Initialized
INFO - 2020-10-07 05:36:19 --> Security Class Initialized
DEBUG - 2020-10-07 05:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:36:19 --> Input Class Initialized
INFO - 2020-10-07 05:36:19 --> Language Class Initialized
INFO - 2020-10-07 05:36:19 --> Loader Class Initialized
INFO - 2020-10-07 05:36:19 --> Helper loaded: url_helper
INFO - 2020-10-07 05:36:19 --> Database Driver Class Initialized
INFO - 2020-10-07 05:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:36:19 --> Email Class Initialized
INFO - 2020-10-07 05:36:19 --> Controller Class Initialized
DEBUG - 2020-10-07 05:36:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:36:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:36:19 --> Model Class Initialized
INFO - 2020-10-07 05:36:19 --> Model Class Initialized
INFO - 2020-10-07 05:36:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-07 05:36:19 --> Final output sent to browser
DEBUG - 2020-10-07 05:36:19 --> Total execution time: 0.0348
ERROR - 2020-10-07 05:36:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:36:23 --> Config Class Initialized
INFO - 2020-10-07 05:36:23 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:36:23 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:36:23 --> Utf8 Class Initialized
INFO - 2020-10-07 05:36:23 --> URI Class Initialized
INFO - 2020-10-07 05:36:23 --> Router Class Initialized
INFO - 2020-10-07 05:36:23 --> Output Class Initialized
INFO - 2020-10-07 05:36:23 --> Security Class Initialized
DEBUG - 2020-10-07 05:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:36:23 --> Input Class Initialized
INFO - 2020-10-07 05:36:23 --> Language Class Initialized
INFO - 2020-10-07 05:36:23 --> Loader Class Initialized
INFO - 2020-10-07 05:36:23 --> Helper loaded: url_helper
INFO - 2020-10-07 05:36:23 --> Database Driver Class Initialized
INFO - 2020-10-07 05:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:36:23 --> Email Class Initialized
INFO - 2020-10-07 05:36:23 --> Controller Class Initialized
DEBUG - 2020-10-07 05:36:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:36:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:36:23 --> Model Class Initialized
INFO - 2020-10-07 05:36:23 --> Model Class Initialized
INFO - 2020-10-07 05:36:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-07 05:36:23 --> Final output sent to browser
DEBUG - 2020-10-07 05:36:23 --> Total execution time: 0.0229
ERROR - 2020-10-07 05:37:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:37:12 --> Config Class Initialized
INFO - 2020-10-07 05:37:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:37:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:37:12 --> Utf8 Class Initialized
INFO - 2020-10-07 05:37:12 --> URI Class Initialized
INFO - 2020-10-07 05:37:12 --> Router Class Initialized
INFO - 2020-10-07 05:37:12 --> Output Class Initialized
INFO - 2020-10-07 05:37:12 --> Security Class Initialized
DEBUG - 2020-10-07 05:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:37:12 --> Input Class Initialized
INFO - 2020-10-07 05:37:12 --> Language Class Initialized
INFO - 2020-10-07 05:37:12 --> Loader Class Initialized
INFO - 2020-10-07 05:37:12 --> Helper loaded: url_helper
INFO - 2020-10-07 05:37:12 --> Database Driver Class Initialized
INFO - 2020-10-07 05:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:37:12 --> Email Class Initialized
INFO - 2020-10-07 05:37:12 --> Controller Class Initialized
DEBUG - 2020-10-07 05:37:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:37:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:37:12 --> Model Class Initialized
INFO - 2020-10-07 05:37:12 --> Model Class Initialized
INFO - 2020-10-07 05:37:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-07 05:37:12 --> Final output sent to browser
DEBUG - 2020-10-07 05:37:12 --> Total execution time: 0.0215
ERROR - 2020-10-07 05:37:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:37:17 --> Config Class Initialized
INFO - 2020-10-07 05:37:17 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:37:17 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:37:17 --> Utf8 Class Initialized
INFO - 2020-10-07 05:37:17 --> URI Class Initialized
INFO - 2020-10-07 05:37:17 --> Router Class Initialized
INFO - 2020-10-07 05:37:17 --> Output Class Initialized
INFO - 2020-10-07 05:37:17 --> Security Class Initialized
DEBUG - 2020-10-07 05:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:37:17 --> Input Class Initialized
INFO - 2020-10-07 05:37:17 --> Language Class Initialized
INFO - 2020-10-07 05:37:17 --> Loader Class Initialized
INFO - 2020-10-07 05:37:17 --> Helper loaded: url_helper
INFO - 2020-10-07 05:37:17 --> Database Driver Class Initialized
INFO - 2020-10-07 05:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:37:17 --> Email Class Initialized
INFO - 2020-10-07 05:37:17 --> Controller Class Initialized
DEBUG - 2020-10-07 05:37:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 05:37:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:37:17 --> Model Class Initialized
INFO - 2020-10-07 05:37:17 --> Model Class Initialized
INFO - 2020-10-07 05:37:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-07 05:37:17 --> Final output sent to browser
DEBUG - 2020-10-07 05:37:17 --> Total execution time: 0.0227
ERROR - 2020-10-07 05:38:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 05:38:45 --> Config Class Initialized
INFO - 2020-10-07 05:38:45 --> Hooks Class Initialized
DEBUG - 2020-10-07 05:38:45 --> UTF-8 Support Enabled
INFO - 2020-10-07 05:38:45 --> Utf8 Class Initialized
INFO - 2020-10-07 05:38:45 --> URI Class Initialized
DEBUG - 2020-10-07 05:38:45 --> No URI present. Default controller set.
INFO - 2020-10-07 05:38:45 --> Router Class Initialized
INFO - 2020-10-07 05:38:45 --> Output Class Initialized
INFO - 2020-10-07 05:38:45 --> Security Class Initialized
DEBUG - 2020-10-07 05:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 05:38:45 --> Input Class Initialized
INFO - 2020-10-07 05:38:45 --> Language Class Initialized
INFO - 2020-10-07 05:38:45 --> Loader Class Initialized
INFO - 2020-10-07 05:38:45 --> Helper loaded: url_helper
INFO - 2020-10-07 05:38:45 --> Database Driver Class Initialized
INFO - 2020-10-07 05:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 05:38:45 --> Email Class Initialized
INFO - 2020-10-07 05:38:45 --> Controller Class Initialized
INFO - 2020-10-07 05:38:45 --> Model Class Initialized
INFO - 2020-10-07 05:38:45 --> Model Class Initialized
DEBUG - 2020-10-07 05:38:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 05:38:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 05:38:45 --> Final output sent to browser
DEBUG - 2020-10-07 05:38:45 --> Total execution time: 0.0218
ERROR - 2020-10-07 13:57:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:57:50 --> Config Class Initialized
INFO - 2020-10-07 13:57:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:57:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:57:50 --> Utf8 Class Initialized
INFO - 2020-10-07 13:57:50 --> URI Class Initialized
DEBUG - 2020-10-07 13:57:50 --> No URI present. Default controller set.
INFO - 2020-10-07 13:57:50 --> Router Class Initialized
INFO - 2020-10-07 13:57:50 --> Output Class Initialized
INFO - 2020-10-07 13:57:50 --> Security Class Initialized
DEBUG - 2020-10-07 13:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:57:50 --> Input Class Initialized
INFO - 2020-10-07 13:57:50 --> Language Class Initialized
INFO - 2020-10-07 13:57:50 --> Loader Class Initialized
INFO - 2020-10-07 13:57:50 --> Helper loaded: url_helper
INFO - 2020-10-07 13:57:50 --> Database Driver Class Initialized
INFO - 2020-10-07 13:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:57:50 --> Email Class Initialized
INFO - 2020-10-07 13:57:50 --> Controller Class Initialized
INFO - 2020-10-07 13:57:50 --> Model Class Initialized
INFO - 2020-10-07 13:57:50 --> Model Class Initialized
DEBUG - 2020-10-07 13:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 13:57:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 13:57:50 --> Final output sent to browser
DEBUG - 2020-10-07 13:57:50 --> Total execution time: 0.1104
ERROR - 2020-10-07 13:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:58:10 --> Config Class Initialized
INFO - 2020-10-07 13:58:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:58:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:58:10 --> Utf8 Class Initialized
INFO - 2020-10-07 13:58:10 --> URI Class Initialized
INFO - 2020-10-07 13:58:10 --> Router Class Initialized
INFO - 2020-10-07 13:58:10 --> Output Class Initialized
INFO - 2020-10-07 13:58:10 --> Security Class Initialized
DEBUG - 2020-10-07 13:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:58:10 --> Input Class Initialized
INFO - 2020-10-07 13:58:10 --> Language Class Initialized
INFO - 2020-10-07 13:58:10 --> Loader Class Initialized
INFO - 2020-10-07 13:58:10 --> Helper loaded: url_helper
INFO - 2020-10-07 13:58:10 --> Database Driver Class Initialized
INFO - 2020-10-07 13:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:58:10 --> Email Class Initialized
INFO - 2020-10-07 13:58:10 --> Controller Class Initialized
INFO - 2020-10-07 13:58:10 --> Model Class Initialized
INFO - 2020-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2020-10-07 13:58:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 13:58:10 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-07 13:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:58:10 --> Config Class Initialized
INFO - 2020-10-07 13:58:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:58:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:58:10 --> Utf8 Class Initialized
INFO - 2020-10-07 13:58:10 --> URI Class Initialized
INFO - 2020-10-07 13:58:10 --> Router Class Initialized
INFO - 2020-10-07 13:58:10 --> Output Class Initialized
INFO - 2020-10-07 13:58:10 --> Security Class Initialized
DEBUG - 2020-10-07 13:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:58:10 --> Input Class Initialized
INFO - 2020-10-07 13:58:10 --> Language Class Initialized
INFO - 2020-10-07 13:58:10 --> Loader Class Initialized
INFO - 2020-10-07 13:58:10 --> Helper loaded: url_helper
INFO - 2020-10-07 13:58:10 --> Database Driver Class Initialized
INFO - 2020-10-07 13:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:58:10 --> Email Class Initialized
INFO - 2020-10-07 13:58:10 --> Controller Class Initialized
INFO - 2020-10-07 13:58:10 --> Model Class Initialized
INFO - 2020-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2020-10-07 13:58:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 13:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:58:10 --> Config Class Initialized
INFO - 2020-10-07 13:58:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:58:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:58:10 --> Utf8 Class Initialized
INFO - 2020-10-07 13:58:10 --> URI Class Initialized
DEBUG - 2020-10-07 13:58:10 --> No URI present. Default controller set.
INFO - 2020-10-07 13:58:10 --> Router Class Initialized
INFO - 2020-10-07 13:58:10 --> Output Class Initialized
INFO - 2020-10-07 13:58:10 --> Security Class Initialized
DEBUG - 2020-10-07 13:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:58:10 --> Input Class Initialized
INFO - 2020-10-07 13:58:10 --> Language Class Initialized
INFO - 2020-10-07 13:58:10 --> Loader Class Initialized
INFO - 2020-10-07 13:58:10 --> Helper loaded: url_helper
INFO - 2020-10-07 13:58:10 --> Database Driver Class Initialized
INFO - 2020-10-07 13:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:58:10 --> Email Class Initialized
INFO - 2020-10-07 13:58:10 --> Controller Class Initialized
INFO - 2020-10-07 13:58:10 --> Model Class Initialized
INFO - 2020-10-07 13:58:10 --> Model Class Initialized
DEBUG - 2020-10-07 13:58:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 13:58:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 13:58:10 --> Final output sent to browser
DEBUG - 2020-10-07 13:58:10 --> Total execution time: 0.0220
ERROR - 2020-10-07 13:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:58:11 --> Config Class Initialized
INFO - 2020-10-07 13:58:11 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:58:11 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:58:11 --> Utf8 Class Initialized
INFO - 2020-10-07 13:58:11 --> URI Class Initialized
INFO - 2020-10-07 13:58:11 --> Router Class Initialized
INFO - 2020-10-07 13:58:11 --> Output Class Initialized
INFO - 2020-10-07 13:58:11 --> Security Class Initialized
DEBUG - 2020-10-07 13:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:58:11 --> Input Class Initialized
INFO - 2020-10-07 13:58:11 --> Language Class Initialized
INFO - 2020-10-07 13:58:11 --> Loader Class Initialized
INFO - 2020-10-07 13:58:11 --> Helper loaded: url_helper
INFO - 2020-10-07 13:58:11 --> Database Driver Class Initialized
INFO - 2020-10-07 13:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:58:11 --> Email Class Initialized
INFO - 2020-10-07 13:58:11 --> Controller Class Initialized
DEBUG - 2020-10-07 13:58:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 13:58:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 13:58:11 --> Model Class Initialized
INFO - 2020-10-07 13:58:11 --> Model Class Initialized
INFO - 2020-10-07 13:58:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-07 13:58:11 --> Final output sent to browser
DEBUG - 2020-10-07 13:58:11 --> Total execution time: 0.0580
ERROR - 2020-10-07 13:59:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:59:18 --> Config Class Initialized
INFO - 2020-10-07 13:59:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:59:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:59:18 --> Utf8 Class Initialized
INFO - 2020-10-07 13:59:18 --> URI Class Initialized
DEBUG - 2020-10-07 13:59:18 --> No URI present. Default controller set.
INFO - 2020-10-07 13:59:18 --> Router Class Initialized
INFO - 2020-10-07 13:59:18 --> Output Class Initialized
INFO - 2020-10-07 13:59:18 --> Security Class Initialized
DEBUG - 2020-10-07 13:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:59:18 --> Input Class Initialized
INFO - 2020-10-07 13:59:18 --> Language Class Initialized
INFO - 2020-10-07 13:59:18 --> Loader Class Initialized
INFO - 2020-10-07 13:59:18 --> Helper loaded: url_helper
INFO - 2020-10-07 13:59:18 --> Database Driver Class Initialized
INFO - 2020-10-07 13:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:59:18 --> Email Class Initialized
INFO - 2020-10-07 13:59:18 --> Controller Class Initialized
INFO - 2020-10-07 13:59:18 --> Model Class Initialized
INFO - 2020-10-07 13:59:18 --> Model Class Initialized
DEBUG - 2020-10-07 13:59:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 13:59:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 13:59:18 --> Final output sent to browser
DEBUG - 2020-10-07 13:59:18 --> Total execution time: 0.0214
ERROR - 2020-10-07 13:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:59:32 --> Config Class Initialized
INFO - 2020-10-07 13:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:59:32 --> Utf8 Class Initialized
INFO - 2020-10-07 13:59:32 --> URI Class Initialized
INFO - 2020-10-07 13:59:32 --> Router Class Initialized
INFO - 2020-10-07 13:59:32 --> Output Class Initialized
INFO - 2020-10-07 13:59:32 --> Security Class Initialized
DEBUG - 2020-10-07 13:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:59:32 --> Input Class Initialized
INFO - 2020-10-07 13:59:32 --> Language Class Initialized
INFO - 2020-10-07 13:59:32 --> Loader Class Initialized
INFO - 2020-10-07 13:59:32 --> Helper loaded: url_helper
INFO - 2020-10-07 13:59:32 --> Database Driver Class Initialized
INFO - 2020-10-07 13:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:59:32 --> Email Class Initialized
INFO - 2020-10-07 13:59:32 --> Controller Class Initialized
INFO - 2020-10-07 13:59:32 --> Model Class Initialized
INFO - 2020-10-07 13:59:32 --> Model Class Initialized
DEBUG - 2020-10-07 13:59:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 13:59:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 13:59:32 --> Model Class Initialized
INFO - 2020-10-07 13:59:32 --> Final output sent to browser
DEBUG - 2020-10-07 13:59:32 --> Total execution time: 0.0221
ERROR - 2020-10-07 13:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:59:32 --> Config Class Initialized
INFO - 2020-10-07 13:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:59:32 --> Utf8 Class Initialized
INFO - 2020-10-07 13:59:32 --> URI Class Initialized
INFO - 2020-10-07 13:59:32 --> Router Class Initialized
INFO - 2020-10-07 13:59:32 --> Output Class Initialized
INFO - 2020-10-07 13:59:32 --> Security Class Initialized
DEBUG - 2020-10-07 13:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:59:32 --> Input Class Initialized
INFO - 2020-10-07 13:59:32 --> Language Class Initialized
INFO - 2020-10-07 13:59:32 --> Loader Class Initialized
INFO - 2020-10-07 13:59:32 --> Helper loaded: url_helper
INFO - 2020-10-07 13:59:32 --> Database Driver Class Initialized
INFO - 2020-10-07 13:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:59:32 --> Email Class Initialized
INFO - 2020-10-07 13:59:32 --> Controller Class Initialized
INFO - 2020-10-07 13:59:32 --> Model Class Initialized
INFO - 2020-10-07 13:59:32 --> Model Class Initialized
DEBUG - 2020-10-07 13:59:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 13:59:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 13:59:32 --> Config Class Initialized
INFO - 2020-10-07 13:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 13:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 13:59:32 --> Utf8 Class Initialized
INFO - 2020-10-07 13:59:32 --> URI Class Initialized
INFO - 2020-10-07 13:59:32 --> Router Class Initialized
INFO - 2020-10-07 13:59:32 --> Output Class Initialized
INFO - 2020-10-07 13:59:32 --> Security Class Initialized
DEBUG - 2020-10-07 13:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 13:59:32 --> Input Class Initialized
INFO - 2020-10-07 13:59:32 --> Language Class Initialized
INFO - 2020-10-07 13:59:32 --> Loader Class Initialized
INFO - 2020-10-07 13:59:32 --> Helper loaded: url_helper
INFO - 2020-10-07 13:59:32 --> Database Driver Class Initialized
INFO - 2020-10-07 13:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 13:59:32 --> Email Class Initialized
INFO - 2020-10-07 13:59:32 --> Controller Class Initialized
DEBUG - 2020-10-07 13:59:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 13:59:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 13:59:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 13:59:32 --> Final output sent to browser
DEBUG - 2020-10-07 13:59:32 --> Total execution time: 0.0275
ERROR - 2020-10-07 14:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:01:50 --> Config Class Initialized
INFO - 2020-10-07 14:01:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:01:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:01:50 --> Utf8 Class Initialized
INFO - 2020-10-07 14:01:50 --> URI Class Initialized
INFO - 2020-10-07 14:01:50 --> Router Class Initialized
INFO - 2020-10-07 14:01:50 --> Output Class Initialized
INFO - 2020-10-07 14:01:50 --> Security Class Initialized
DEBUG - 2020-10-07 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:01:50 --> Input Class Initialized
INFO - 2020-10-07 14:01:50 --> Language Class Initialized
INFO - 2020-10-07 14:01:50 --> Loader Class Initialized
INFO - 2020-10-07 14:01:50 --> Helper loaded: url_helper
INFO - 2020-10-07 14:01:50 --> Database Driver Class Initialized
INFO - 2020-10-07 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:01:50 --> Email Class Initialized
INFO - 2020-10-07 14:01:50 --> Controller Class Initialized
DEBUG - 2020-10-07 14:01:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:01:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:01:50 --> Model Class Initialized
INFO - 2020-10-07 14:01:50 --> Model Class Initialized
INFO - 2020-10-07 14:01:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 14:01:50 --> Final output sent to browser
DEBUG - 2020-10-07 14:01:50 --> Total execution time: 0.0556
ERROR - 2020-10-07 14:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:04:39 --> Config Class Initialized
INFO - 2020-10-07 14:04:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:04:39 --> Utf8 Class Initialized
INFO - 2020-10-07 14:04:39 --> URI Class Initialized
INFO - 2020-10-07 14:04:39 --> Router Class Initialized
INFO - 2020-10-07 14:04:39 --> Output Class Initialized
INFO - 2020-10-07 14:04:39 --> Security Class Initialized
DEBUG - 2020-10-07 14:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:04:39 --> Input Class Initialized
INFO - 2020-10-07 14:04:39 --> Language Class Initialized
INFO - 2020-10-07 14:04:39 --> Loader Class Initialized
INFO - 2020-10-07 14:04:39 --> Helper loaded: url_helper
INFO - 2020-10-07 14:04:39 --> Database Driver Class Initialized
INFO - 2020-10-07 14:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:04:39 --> Email Class Initialized
INFO - 2020-10-07 14:04:39 --> Controller Class Initialized
DEBUG - 2020-10-07 14:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:04:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:04:39 --> Model Class Initialized
INFO - 2020-10-07 14:04:39 --> Model Class Initialized
INFO - 2020-10-07 14:04:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 14:04:39 --> Final output sent to browser
DEBUG - 2020-10-07 14:04:39 --> Total execution time: 0.0303
ERROR - 2020-10-07 14:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:08:46 --> Config Class Initialized
INFO - 2020-10-07 14:08:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:08:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:08:46 --> Utf8 Class Initialized
INFO - 2020-10-07 14:08:46 --> URI Class Initialized
INFO - 2020-10-07 14:08:46 --> Router Class Initialized
INFO - 2020-10-07 14:08:46 --> Output Class Initialized
INFO - 2020-10-07 14:08:46 --> Security Class Initialized
DEBUG - 2020-10-07 14:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:08:46 --> Input Class Initialized
INFO - 2020-10-07 14:08:46 --> Language Class Initialized
INFO - 2020-10-07 14:08:46 --> Loader Class Initialized
INFO - 2020-10-07 14:08:46 --> Helper loaded: url_helper
INFO - 2020-10-07 14:08:46 --> Database Driver Class Initialized
INFO - 2020-10-07 14:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:08:46 --> Email Class Initialized
INFO - 2020-10-07 14:08:46 --> Controller Class Initialized
DEBUG - 2020-10-07 14:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:08:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:08:46 --> Model Class Initialized
INFO - 2020-10-07 14:08:46 --> Model Class Initialized
INFO - 2020-10-07 14:08:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 14:08:46 --> Final output sent to browser
DEBUG - 2020-10-07 14:08:46 --> Total execution time: 0.0321
ERROR - 2020-10-07 14:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:28:20 --> Config Class Initialized
INFO - 2020-10-07 14:28:20 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:28:20 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:28:20 --> Utf8 Class Initialized
INFO - 2020-10-07 14:28:20 --> URI Class Initialized
DEBUG - 2020-10-07 14:28:20 --> No URI present. Default controller set.
INFO - 2020-10-07 14:28:20 --> Router Class Initialized
INFO - 2020-10-07 14:28:21 --> Output Class Initialized
INFO - 2020-10-07 14:28:21 --> Security Class Initialized
DEBUG - 2020-10-07 14:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:28:21 --> Input Class Initialized
INFO - 2020-10-07 14:28:21 --> Language Class Initialized
INFO - 2020-10-07 14:28:21 --> Loader Class Initialized
INFO - 2020-10-07 14:28:21 --> Helper loaded: url_helper
INFO - 2020-10-07 14:28:21 --> Database Driver Class Initialized
INFO - 2020-10-07 14:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:28:21 --> Email Class Initialized
INFO - 2020-10-07 14:28:21 --> Controller Class Initialized
INFO - 2020-10-07 14:28:21 --> Model Class Initialized
INFO - 2020-10-07 14:28:21 --> Model Class Initialized
DEBUG - 2020-10-07 14:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:28:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 14:28:21 --> Final output sent to browser
DEBUG - 2020-10-07 14:28:21 --> Total execution time: 0.0170
ERROR - 2020-10-07 14:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:28:37 --> Config Class Initialized
INFO - 2020-10-07 14:28:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:28:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:28:37 --> Utf8 Class Initialized
INFO - 2020-10-07 14:28:37 --> URI Class Initialized
INFO - 2020-10-07 14:28:37 --> Router Class Initialized
INFO - 2020-10-07 14:28:37 --> Output Class Initialized
INFO - 2020-10-07 14:28:37 --> Security Class Initialized
DEBUG - 2020-10-07 14:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:28:37 --> Input Class Initialized
INFO - 2020-10-07 14:28:37 --> Language Class Initialized
INFO - 2020-10-07 14:28:37 --> Loader Class Initialized
INFO - 2020-10-07 14:28:37 --> Helper loaded: url_helper
INFO - 2020-10-07 14:28:37 --> Database Driver Class Initialized
INFO - 2020-10-07 14:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:28:37 --> Email Class Initialized
INFO - 2020-10-07 14:28:37 --> Controller Class Initialized
INFO - 2020-10-07 14:28:37 --> Model Class Initialized
INFO - 2020-10-07 14:28:37 --> Model Class Initialized
DEBUG - 2020-10-07 14:28:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:28:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:28:37 --> Model Class Initialized
INFO - 2020-10-07 14:28:37 --> Final output sent to browser
DEBUG - 2020-10-07 14:28:37 --> Total execution time: 0.0222
ERROR - 2020-10-07 14:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:28:37 --> Config Class Initialized
INFO - 2020-10-07 14:28:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:28:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:28:37 --> Utf8 Class Initialized
INFO - 2020-10-07 14:28:37 --> URI Class Initialized
INFO - 2020-10-07 14:28:37 --> Router Class Initialized
INFO - 2020-10-07 14:28:37 --> Output Class Initialized
INFO - 2020-10-07 14:28:37 --> Security Class Initialized
DEBUG - 2020-10-07 14:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:28:37 --> Input Class Initialized
INFO - 2020-10-07 14:28:37 --> Language Class Initialized
INFO - 2020-10-07 14:28:37 --> Loader Class Initialized
INFO - 2020-10-07 14:28:37 --> Helper loaded: url_helper
INFO - 2020-10-07 14:28:37 --> Database Driver Class Initialized
INFO - 2020-10-07 14:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:28:37 --> Email Class Initialized
INFO - 2020-10-07 14:28:37 --> Controller Class Initialized
INFO - 2020-10-07 14:28:37 --> Model Class Initialized
INFO - 2020-10-07 14:28:37 --> Model Class Initialized
DEBUG - 2020-10-07 14:28:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 14:28:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:28:37 --> Config Class Initialized
INFO - 2020-10-07 14:28:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:28:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:28:37 --> Utf8 Class Initialized
INFO - 2020-10-07 14:28:37 --> URI Class Initialized
INFO - 2020-10-07 14:28:37 --> Router Class Initialized
INFO - 2020-10-07 14:28:37 --> Output Class Initialized
INFO - 2020-10-07 14:28:37 --> Security Class Initialized
DEBUG - 2020-10-07 14:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:28:37 --> Input Class Initialized
INFO - 2020-10-07 14:28:37 --> Language Class Initialized
INFO - 2020-10-07 14:28:37 --> Loader Class Initialized
INFO - 2020-10-07 14:28:37 --> Helper loaded: url_helper
INFO - 2020-10-07 14:28:37 --> Database Driver Class Initialized
INFO - 2020-10-07 14:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:28:37 --> Email Class Initialized
INFO - 2020-10-07 14:28:37 --> Controller Class Initialized
DEBUG - 2020-10-07 14:28:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:28:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:28:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:28:37 --> Final output sent to browser
DEBUG - 2020-10-07 14:28:37 --> Total execution time: 0.0176
ERROR - 2020-10-07 14:31:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:31:46 --> Config Class Initialized
INFO - 2020-10-07 14:31:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:31:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:31:46 --> Utf8 Class Initialized
INFO - 2020-10-07 14:31:46 --> URI Class Initialized
INFO - 2020-10-07 14:31:46 --> Router Class Initialized
INFO - 2020-10-07 14:31:46 --> Output Class Initialized
INFO - 2020-10-07 14:31:46 --> Security Class Initialized
DEBUG - 2020-10-07 14:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:31:46 --> Input Class Initialized
INFO - 2020-10-07 14:31:46 --> Language Class Initialized
INFO - 2020-10-07 14:31:46 --> Loader Class Initialized
INFO - 2020-10-07 14:31:46 --> Helper loaded: url_helper
INFO - 2020-10-07 14:31:46 --> Database Driver Class Initialized
INFO - 2020-10-07 14:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:31:46 --> Email Class Initialized
INFO - 2020-10-07 14:31:46 --> Controller Class Initialized
DEBUG - 2020-10-07 14:31:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:31:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:31:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:31:46 --> Final output sent to browser
DEBUG - 2020-10-07 14:31:46 --> Total execution time: 0.0192
ERROR - 2020-10-07 14:32:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:32:52 --> Config Class Initialized
INFO - 2020-10-07 14:32:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:32:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:32:52 --> Utf8 Class Initialized
INFO - 2020-10-07 14:32:52 --> URI Class Initialized
INFO - 2020-10-07 14:32:52 --> Router Class Initialized
INFO - 2020-10-07 14:32:52 --> Output Class Initialized
INFO - 2020-10-07 14:32:52 --> Security Class Initialized
DEBUG - 2020-10-07 14:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:32:52 --> Input Class Initialized
INFO - 2020-10-07 14:32:52 --> Language Class Initialized
INFO - 2020-10-07 14:32:52 --> Loader Class Initialized
INFO - 2020-10-07 14:32:52 --> Helper loaded: url_helper
INFO - 2020-10-07 14:32:52 --> Database Driver Class Initialized
INFO - 2020-10-07 14:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:32:52 --> Email Class Initialized
INFO - 2020-10-07 14:32:52 --> Controller Class Initialized
DEBUG - 2020-10-07 14:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:32:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:32:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:32:52 --> Final output sent to browser
DEBUG - 2020-10-07 14:32:52 --> Total execution time: 0.0241
ERROR - 2020-10-07 14:34:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:34:06 --> Config Class Initialized
INFO - 2020-10-07 14:34:06 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:34:06 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:34:06 --> Utf8 Class Initialized
INFO - 2020-10-07 14:34:06 --> URI Class Initialized
INFO - 2020-10-07 14:34:06 --> Router Class Initialized
INFO - 2020-10-07 14:34:06 --> Output Class Initialized
INFO - 2020-10-07 14:34:06 --> Security Class Initialized
DEBUG - 2020-10-07 14:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:34:06 --> Input Class Initialized
INFO - 2020-10-07 14:34:06 --> Language Class Initialized
INFO - 2020-10-07 14:34:06 --> Loader Class Initialized
INFO - 2020-10-07 14:34:06 --> Helper loaded: url_helper
INFO - 2020-10-07 14:34:06 --> Database Driver Class Initialized
INFO - 2020-10-07 14:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:34:06 --> Email Class Initialized
INFO - 2020-10-07 14:34:06 --> Controller Class Initialized
DEBUG - 2020-10-07 14:34:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:34:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:34:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:34:06 --> Final output sent to browser
DEBUG - 2020-10-07 14:34:06 --> Total execution time: 0.0220
ERROR - 2020-10-07 14:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:31 --> Config Class Initialized
INFO - 2020-10-07 14:35:31 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:31 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:31 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:31 --> URI Class Initialized
INFO - 2020-10-07 14:35:31 --> Router Class Initialized
INFO - 2020-10-07 14:35:31 --> Output Class Initialized
INFO - 2020-10-07 14:35:31 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:31 --> Input Class Initialized
INFO - 2020-10-07 14:35:31 --> Language Class Initialized
INFO - 2020-10-07 14:35:31 --> Loader Class Initialized
INFO - 2020-10-07 14:35:31 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:31 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:31 --> Email Class Initialized
INFO - 2020-10-07 14:35:31 --> Controller Class Initialized
DEBUG - 2020-10-07 14:35:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:31 --> Model Class Initialized
INFO - 2020-10-07 14:35:31 --> Model Class Initialized
INFO - 2020-10-07 14:35:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 14:35:31 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:31 --> Total execution time: 0.0246
ERROR - 2020-10-07 14:35:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:41 --> Config Class Initialized
INFO - 2020-10-07 14:35:41 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:41 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:41 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:41 --> URI Class Initialized
DEBUG - 2020-10-07 14:35:41 --> No URI present. Default controller set.
INFO - 2020-10-07 14:35:41 --> Router Class Initialized
INFO - 2020-10-07 14:35:41 --> Output Class Initialized
INFO - 2020-10-07 14:35:41 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:41 --> Input Class Initialized
INFO - 2020-10-07 14:35:41 --> Language Class Initialized
INFO - 2020-10-07 14:35:41 --> Loader Class Initialized
INFO - 2020-10-07 14:35:41 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:41 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:41 --> Email Class Initialized
INFO - 2020-10-07 14:35:41 --> Controller Class Initialized
INFO - 2020-10-07 14:35:41 --> Model Class Initialized
INFO - 2020-10-07 14:35:41 --> Model Class Initialized
DEBUG - 2020-10-07 14:35:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 14:35:41 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:41 --> Total execution time: 0.0184
ERROR - 2020-10-07 14:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:46 --> Config Class Initialized
INFO - 2020-10-07 14:35:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:46 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:46 --> URI Class Initialized
INFO - 2020-10-07 14:35:46 --> Router Class Initialized
INFO - 2020-10-07 14:35:46 --> Output Class Initialized
INFO - 2020-10-07 14:35:46 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:46 --> Input Class Initialized
INFO - 2020-10-07 14:35:46 --> Language Class Initialized
INFO - 2020-10-07 14:35:46 --> Loader Class Initialized
INFO - 2020-10-07 14:35:46 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:46 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:46 --> Email Class Initialized
INFO - 2020-10-07 14:35:46 --> Controller Class Initialized
INFO - 2020-10-07 14:35:46 --> Model Class Initialized
INFO - 2020-10-07 14:35:46 --> Model Class Initialized
DEBUG - 2020-10-07 14:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:46 --> Model Class Initialized
INFO - 2020-10-07 14:35:46 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:46 --> Total execution time: 0.0227
ERROR - 2020-10-07 14:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:47 --> Config Class Initialized
INFO - 2020-10-07 14:35:47 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:47 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:47 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:47 --> URI Class Initialized
INFO - 2020-10-07 14:35:47 --> Router Class Initialized
INFO - 2020-10-07 14:35:47 --> Output Class Initialized
INFO - 2020-10-07 14:35:47 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:47 --> Input Class Initialized
INFO - 2020-10-07 14:35:47 --> Language Class Initialized
INFO - 2020-10-07 14:35:47 --> Loader Class Initialized
INFO - 2020-10-07 14:35:47 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:47 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:47 --> Email Class Initialized
INFO - 2020-10-07 14:35:47 --> Controller Class Initialized
INFO - 2020-10-07 14:35:47 --> Model Class Initialized
INFO - 2020-10-07 14:35:47 --> Model Class Initialized
DEBUG - 2020-10-07 14:35:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 14:35:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:47 --> Config Class Initialized
INFO - 2020-10-07 14:35:47 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:47 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:47 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:47 --> URI Class Initialized
INFO - 2020-10-07 14:35:47 --> Router Class Initialized
INFO - 2020-10-07 14:35:47 --> Output Class Initialized
INFO - 2020-10-07 14:35:47 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:47 --> Input Class Initialized
INFO - 2020-10-07 14:35:47 --> Language Class Initialized
INFO - 2020-10-07 14:35:47 --> Loader Class Initialized
INFO - 2020-10-07 14:35:47 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:47 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:47 --> Email Class Initialized
INFO - 2020-10-07 14:35:47 --> Controller Class Initialized
DEBUG - 2020-10-07 14:35:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:47 --> Model Class Initialized
INFO - 2020-10-07 14:35:47 --> Model Class Initialized
INFO - 2020-10-07 14:35:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-07 14:35:47 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:47 --> Total execution time: 0.0208
ERROR - 2020-10-07 14:35:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:52 --> Config Class Initialized
INFO - 2020-10-07 14:35:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:52 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:52 --> URI Class Initialized
INFO - 2020-10-07 14:35:52 --> Router Class Initialized
INFO - 2020-10-07 14:35:52 --> Output Class Initialized
INFO - 2020-10-07 14:35:52 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:52 --> Input Class Initialized
INFO - 2020-10-07 14:35:52 --> Language Class Initialized
INFO - 2020-10-07 14:35:52 --> Loader Class Initialized
INFO - 2020-10-07 14:35:52 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:52 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:52 --> Email Class Initialized
INFO - 2020-10-07 14:35:52 --> Controller Class Initialized
DEBUG - 2020-10-07 14:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:52 --> Model Class Initialized
INFO - 2020-10-07 14:35:52 --> Model Class Initialized
INFO - 2020-10-07 14:35:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-07 14:35:52 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:52 --> Total execution time: 0.0324
ERROR - 2020-10-07 14:35:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:55 --> Config Class Initialized
INFO - 2020-10-07 14:35:55 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:55 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:55 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:55 --> URI Class Initialized
INFO - 2020-10-07 14:35:55 --> Router Class Initialized
INFO - 2020-10-07 14:35:55 --> Output Class Initialized
INFO - 2020-10-07 14:35:55 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:55 --> Input Class Initialized
INFO - 2020-10-07 14:35:55 --> Language Class Initialized
INFO - 2020-10-07 14:35:55 --> Loader Class Initialized
INFO - 2020-10-07 14:35:55 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:55 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:55 --> Email Class Initialized
INFO - 2020-10-07 14:35:55 --> Controller Class Initialized
DEBUG - 2020-10-07 14:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:55 --> Model Class Initialized
INFO - 2020-10-07 14:35:55 --> Model Class Initialized
INFO - 2020-10-07 14:35:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-07 14:35:55 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:55 --> Total execution time: 0.0602
ERROR - 2020-10-07 14:35:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:58 --> Config Class Initialized
INFO - 2020-10-07 14:35:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:58 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:58 --> URI Class Initialized
INFO - 2020-10-07 14:35:58 --> Router Class Initialized
INFO - 2020-10-07 14:35:58 --> Output Class Initialized
INFO - 2020-10-07 14:35:58 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:58 --> Input Class Initialized
INFO - 2020-10-07 14:35:58 --> Language Class Initialized
INFO - 2020-10-07 14:35:58 --> Loader Class Initialized
INFO - 2020-10-07 14:35:58 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:58 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:58 --> Email Class Initialized
INFO - 2020-10-07 14:35:58 --> Controller Class Initialized
DEBUG - 2020-10-07 14:35:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:58 --> Model Class Initialized
INFO - 2020-10-07 14:35:58 --> Model Class Initialized
INFO - 2020-10-07 14:35:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-07 14:35:58 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:58 --> Total execution time: 0.0363
ERROR - 2020-10-07 14:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:35:59 --> Config Class Initialized
INFO - 2020-10-07 14:35:59 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:35:59 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:35:59 --> Utf8 Class Initialized
INFO - 2020-10-07 14:35:59 --> URI Class Initialized
INFO - 2020-10-07 14:35:59 --> Router Class Initialized
INFO - 2020-10-07 14:35:59 --> Output Class Initialized
INFO - 2020-10-07 14:35:59 --> Security Class Initialized
DEBUG - 2020-10-07 14:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:35:59 --> Input Class Initialized
INFO - 2020-10-07 14:35:59 --> Language Class Initialized
INFO - 2020-10-07 14:35:59 --> Loader Class Initialized
INFO - 2020-10-07 14:35:59 --> Helper loaded: url_helper
INFO - 2020-10-07 14:35:59 --> Database Driver Class Initialized
INFO - 2020-10-07 14:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:35:59 --> Email Class Initialized
INFO - 2020-10-07 14:35:59 --> Controller Class Initialized
DEBUG - 2020-10-07 14:35:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:35:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:35:59 --> Model Class Initialized
INFO - 2020-10-07 14:35:59 --> Model Class Initialized
INFO - 2020-10-07 14:35:59 --> Final output sent to browser
DEBUG - 2020-10-07 14:35:59 --> Total execution time: 0.0229
ERROR - 2020-10-07 14:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:36:00 --> Config Class Initialized
INFO - 2020-10-07 14:36:00 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:36:00 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:36:00 --> Utf8 Class Initialized
INFO - 2020-10-07 14:36:00 --> URI Class Initialized
INFO - 2020-10-07 14:36:00 --> Router Class Initialized
INFO - 2020-10-07 14:36:00 --> Output Class Initialized
INFO - 2020-10-07 14:36:00 --> Security Class Initialized
DEBUG - 2020-10-07 14:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:36:00 --> Input Class Initialized
INFO - 2020-10-07 14:36:00 --> Language Class Initialized
INFO - 2020-10-07 14:36:00 --> Loader Class Initialized
INFO - 2020-10-07 14:36:00 --> Helper loaded: url_helper
INFO - 2020-10-07 14:36:00 --> Database Driver Class Initialized
INFO - 2020-10-07 14:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:36:00 --> Email Class Initialized
INFO - 2020-10-07 14:36:00 --> Controller Class Initialized
DEBUG - 2020-10-07 14:36:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:36:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:36:00 --> Model Class Initialized
INFO - 2020-10-07 14:36:00 --> Model Class Initialized
INFO - 2020-10-07 14:36:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-07 14:36:00 --> Final output sent to browser
DEBUG - 2020-10-07 14:36:00 --> Total execution time: 0.0316
ERROR - 2020-10-07 14:36:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:36:02 --> Config Class Initialized
INFO - 2020-10-07 14:36:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:36:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:36:02 --> Utf8 Class Initialized
INFO - 2020-10-07 14:36:02 --> URI Class Initialized
INFO - 2020-10-07 14:36:02 --> Router Class Initialized
INFO - 2020-10-07 14:36:02 --> Output Class Initialized
INFO - 2020-10-07 14:36:02 --> Security Class Initialized
DEBUG - 2020-10-07 14:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:36:02 --> Input Class Initialized
INFO - 2020-10-07 14:36:02 --> Language Class Initialized
INFO - 2020-10-07 14:36:02 --> Loader Class Initialized
INFO - 2020-10-07 14:36:02 --> Helper loaded: url_helper
INFO - 2020-10-07 14:36:02 --> Database Driver Class Initialized
INFO - 2020-10-07 14:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:36:02 --> Email Class Initialized
INFO - 2020-10-07 14:36:02 --> Controller Class Initialized
DEBUG - 2020-10-07 14:36:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:36:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:36:02 --> Model Class Initialized
INFO - 2020-10-07 14:36:02 --> Model Class Initialized
INFO - 2020-10-07 14:36:02 --> Final output sent to browser
DEBUG - 2020-10-07 14:36:02 --> Total execution time: 0.0244
ERROR - 2020-10-07 14:41:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:41:59 --> Config Class Initialized
INFO - 2020-10-07 14:41:59 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:41:59 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:41:59 --> Utf8 Class Initialized
INFO - 2020-10-07 14:41:59 --> URI Class Initialized
DEBUG - 2020-10-07 14:41:59 --> No URI present. Default controller set.
INFO - 2020-10-07 14:41:59 --> Router Class Initialized
INFO - 2020-10-07 14:41:59 --> Output Class Initialized
INFO - 2020-10-07 14:41:59 --> Security Class Initialized
DEBUG - 2020-10-07 14:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:41:59 --> Input Class Initialized
INFO - 2020-10-07 14:41:59 --> Language Class Initialized
INFO - 2020-10-07 14:41:59 --> Loader Class Initialized
INFO - 2020-10-07 14:41:59 --> Helper loaded: url_helper
INFO - 2020-10-07 14:41:59 --> Database Driver Class Initialized
INFO - 2020-10-07 14:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:41:59 --> Email Class Initialized
INFO - 2020-10-07 14:41:59 --> Controller Class Initialized
INFO - 2020-10-07 14:41:59 --> Model Class Initialized
INFO - 2020-10-07 14:41:59 --> Model Class Initialized
DEBUG - 2020-10-07 14:41:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:41:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 14:41:59 --> Final output sent to browser
DEBUG - 2020-10-07 14:41:59 --> Total execution time: 0.0212
ERROR - 2020-10-07 14:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:42:26 --> Config Class Initialized
INFO - 2020-10-07 14:42:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:42:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:42:26 --> Utf8 Class Initialized
INFO - 2020-10-07 14:42:26 --> URI Class Initialized
INFO - 2020-10-07 14:42:26 --> Router Class Initialized
INFO - 2020-10-07 14:42:26 --> Output Class Initialized
INFO - 2020-10-07 14:42:26 --> Security Class Initialized
DEBUG - 2020-10-07 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:42:26 --> Input Class Initialized
INFO - 2020-10-07 14:42:26 --> Language Class Initialized
INFO - 2020-10-07 14:42:26 --> Loader Class Initialized
INFO - 2020-10-07 14:42:26 --> Helper loaded: url_helper
INFO - 2020-10-07 14:42:26 --> Database Driver Class Initialized
INFO - 2020-10-07 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:42:26 --> Email Class Initialized
INFO - 2020-10-07 14:42:26 --> Controller Class Initialized
ERROR - 2020-10-07 14:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:42:26 --> Model Class Initialized
INFO - 2020-10-07 14:42:26 --> Model Class Initialized
DEBUG - 2020-10-07 14:42:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:42:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:42:26 --> Model Class Initialized
INFO - 2020-10-07 14:42:26 --> Config Class Initialized
INFO - 2020-10-07 14:42:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:42:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:42:26 --> Utf8 Class Initialized
INFO - 2020-10-07 14:42:26 --> Final output sent to browser
DEBUG - 2020-10-07 14:42:26 --> Total execution time: 0.0238
INFO - 2020-10-07 14:42:26 --> URI Class Initialized
INFO - 2020-10-07 14:42:26 --> Router Class Initialized
INFO - 2020-10-07 14:42:26 --> Output Class Initialized
INFO - 2020-10-07 14:42:26 --> Security Class Initialized
DEBUG - 2020-10-07 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:42:26 --> Input Class Initialized
INFO - 2020-10-07 14:42:26 --> Language Class Initialized
INFO - 2020-10-07 14:42:26 --> Loader Class Initialized
INFO - 2020-10-07 14:42:26 --> Helper loaded: url_helper
INFO - 2020-10-07 14:42:26 --> Database Driver Class Initialized
INFO - 2020-10-07 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:42:26 --> Email Class Initialized
INFO - 2020-10-07 14:42:26 --> Controller Class Initialized
INFO - 2020-10-07 14:42:26 --> Model Class Initialized
INFO - 2020-10-07 14:42:26 --> Model Class Initialized
DEBUG - 2020-10-07 14:42:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 14:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:42:27 --> Config Class Initialized
INFO - 2020-10-07 14:42:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:42:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:42:27 --> Utf8 Class Initialized
INFO - 2020-10-07 14:42:27 --> URI Class Initialized
INFO - 2020-10-07 14:42:27 --> Router Class Initialized
INFO - 2020-10-07 14:42:27 --> Output Class Initialized
INFO - 2020-10-07 14:42:27 --> Security Class Initialized
DEBUG - 2020-10-07 14:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:42:27 --> Input Class Initialized
INFO - 2020-10-07 14:42:27 --> Language Class Initialized
INFO - 2020-10-07 14:42:27 --> Loader Class Initialized
INFO - 2020-10-07 14:42:27 --> Helper loaded: url_helper
INFO - 2020-10-07 14:42:27 --> Database Driver Class Initialized
INFO - 2020-10-07 14:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:42:27 --> Email Class Initialized
INFO - 2020-10-07 14:42:27 --> Controller Class Initialized
DEBUG - 2020-10-07 14:42:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:42:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:42:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:42:27 --> Final output sent to browser
DEBUG - 2020-10-07 14:42:27 --> Total execution time: 0.0208
ERROR - 2020-10-07 14:42:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:42:33 --> Config Class Initialized
INFO - 2020-10-07 14:42:33 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:42:33 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:42:33 --> Utf8 Class Initialized
INFO - 2020-10-07 14:42:33 --> URI Class Initialized
INFO - 2020-10-07 14:42:33 --> Router Class Initialized
INFO - 2020-10-07 14:42:33 --> Output Class Initialized
INFO - 2020-10-07 14:42:33 --> Security Class Initialized
DEBUG - 2020-10-07 14:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:42:33 --> Input Class Initialized
INFO - 2020-10-07 14:42:33 --> Language Class Initialized
INFO - 2020-10-07 14:42:33 --> Loader Class Initialized
INFO - 2020-10-07 14:42:33 --> Helper loaded: url_helper
INFO - 2020-10-07 14:42:33 --> Database Driver Class Initialized
INFO - 2020-10-07 14:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:42:33 --> Email Class Initialized
INFO - 2020-10-07 14:42:33 --> Controller Class Initialized
INFO - 2020-10-07 14:42:33 --> Model Class Initialized
INFO - 2020-10-07 14:42:33 --> Model Class Initialized
INFO - 2020-10-07 14:42:33 --> Model Class Initialized
INFO - 2020-10-07 14:42:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 14:42:33 --> Final output sent to browser
DEBUG - 2020-10-07 14:42:33 --> Total execution time: 0.0433
ERROR - 2020-10-07 14:42:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:42:34 --> Config Class Initialized
INFO - 2020-10-07 14:42:34 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:42:34 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:42:34 --> Utf8 Class Initialized
INFO - 2020-10-07 14:42:34 --> URI Class Initialized
INFO - 2020-10-07 14:42:34 --> Router Class Initialized
INFO - 2020-10-07 14:42:34 --> Output Class Initialized
INFO - 2020-10-07 14:42:34 --> Security Class Initialized
DEBUG - 2020-10-07 14:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:42:34 --> Input Class Initialized
INFO - 2020-10-07 14:42:34 --> Language Class Initialized
INFO - 2020-10-07 14:42:34 --> Loader Class Initialized
INFO - 2020-10-07 14:42:34 --> Helper loaded: url_helper
INFO - 2020-10-07 14:42:34 --> Database Driver Class Initialized
INFO - 2020-10-07 14:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:42:34 --> Email Class Initialized
INFO - 2020-10-07 14:42:34 --> Controller Class Initialized
INFO - 2020-10-07 14:42:34 --> Model Class Initialized
INFO - 2020-10-07 14:42:34 --> Model Class Initialized
INFO - 2020-10-07 14:42:34 --> Final output sent to browser
DEBUG - 2020-10-07 14:42:34 --> Total execution time: 0.0435
ERROR - 2020-10-07 14:42:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:42:36 --> Config Class Initialized
INFO - 2020-10-07 14:42:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:42:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:42:36 --> Utf8 Class Initialized
INFO - 2020-10-07 14:42:36 --> URI Class Initialized
INFO - 2020-10-07 14:42:36 --> Router Class Initialized
INFO - 2020-10-07 14:42:36 --> Output Class Initialized
INFO - 2020-10-07 14:42:36 --> Security Class Initialized
DEBUG - 2020-10-07 14:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:42:36 --> Input Class Initialized
INFO - 2020-10-07 14:42:36 --> Language Class Initialized
INFO - 2020-10-07 14:42:36 --> Loader Class Initialized
INFO - 2020-10-07 14:42:36 --> Helper loaded: url_helper
INFO - 2020-10-07 14:42:36 --> Database Driver Class Initialized
INFO - 2020-10-07 14:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:42:36 --> Email Class Initialized
INFO - 2020-10-07 14:42:36 --> Controller Class Initialized
INFO - 2020-10-07 14:42:36 --> Model Class Initialized
INFO - 2020-10-07 14:42:36 --> Model Class Initialized
INFO - 2020-10-07 14:42:36 --> Model Class Initialized
INFO - 2020-10-07 14:42:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-10-07 14:42:36 --> Final output sent to browser
DEBUG - 2020-10-07 14:42:36 --> Total execution time: 0.0549
ERROR - 2020-10-07 14:44:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:44:59 --> Config Class Initialized
INFO - 2020-10-07 14:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:44:59 --> Utf8 Class Initialized
INFO - 2020-10-07 14:44:59 --> URI Class Initialized
INFO - 2020-10-07 14:44:59 --> Router Class Initialized
INFO - 2020-10-07 14:44:59 --> Output Class Initialized
INFO - 2020-10-07 14:44:59 --> Security Class Initialized
DEBUG - 2020-10-07 14:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:44:59 --> Input Class Initialized
INFO - 2020-10-07 14:44:59 --> Language Class Initialized
INFO - 2020-10-07 14:44:59 --> Loader Class Initialized
INFO - 2020-10-07 14:44:59 --> Helper loaded: url_helper
INFO - 2020-10-07 14:44:59 --> Database Driver Class Initialized
INFO - 2020-10-07 14:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:44:59 --> Email Class Initialized
INFO - 2020-10-07 14:44:59 --> Controller Class Initialized
DEBUG - 2020-10-07 14:44:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:44:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:44:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:44:59 --> Final output sent to browser
DEBUG - 2020-10-07 14:44:59 --> Total execution time: 0.0217
ERROR - 2020-10-07 14:46:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:46:28 --> Config Class Initialized
INFO - 2020-10-07 14:46:28 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:46:28 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:46:28 --> Utf8 Class Initialized
INFO - 2020-10-07 14:46:28 --> URI Class Initialized
INFO - 2020-10-07 14:46:28 --> Router Class Initialized
INFO - 2020-10-07 14:46:28 --> Output Class Initialized
INFO - 2020-10-07 14:46:28 --> Security Class Initialized
DEBUG - 2020-10-07 14:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:46:28 --> Input Class Initialized
INFO - 2020-10-07 14:46:28 --> Language Class Initialized
INFO - 2020-10-07 14:46:28 --> Loader Class Initialized
INFO - 2020-10-07 14:46:28 --> Helper loaded: url_helper
INFO - 2020-10-07 14:46:28 --> Database Driver Class Initialized
INFO - 2020-10-07 14:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:46:28 --> Email Class Initialized
INFO - 2020-10-07 14:46:28 --> Controller Class Initialized
DEBUG - 2020-10-07 14:46:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:46:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:46:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:46:28 --> Final output sent to browser
DEBUG - 2020-10-07 14:46:28 --> Total execution time: 0.0181
ERROR - 2020-10-07 14:47:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:47:23 --> Config Class Initialized
INFO - 2020-10-07 14:47:23 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:47:23 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:47:23 --> Utf8 Class Initialized
INFO - 2020-10-07 14:47:23 --> URI Class Initialized
INFO - 2020-10-07 14:47:23 --> Router Class Initialized
INFO - 2020-10-07 14:47:23 --> Output Class Initialized
INFO - 2020-10-07 14:47:23 --> Security Class Initialized
DEBUG - 2020-10-07 14:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:47:23 --> Input Class Initialized
INFO - 2020-10-07 14:47:23 --> Language Class Initialized
INFO - 2020-10-07 14:47:23 --> Loader Class Initialized
INFO - 2020-10-07 14:47:23 --> Helper loaded: url_helper
INFO - 2020-10-07 14:47:23 --> Database Driver Class Initialized
INFO - 2020-10-07 14:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:47:23 --> Email Class Initialized
INFO - 2020-10-07 14:47:23 --> Controller Class Initialized
DEBUG - 2020-10-07 14:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:47:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:47:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:47:23 --> Final output sent to browser
DEBUG - 2020-10-07 14:47:23 --> Total execution time: 0.0176
ERROR - 2020-10-07 14:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:48:08 --> Config Class Initialized
INFO - 2020-10-07 14:48:08 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:48:08 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:48:08 --> Utf8 Class Initialized
INFO - 2020-10-07 14:48:08 --> URI Class Initialized
INFO - 2020-10-07 14:48:08 --> Router Class Initialized
INFO - 2020-10-07 14:48:08 --> Output Class Initialized
INFO - 2020-10-07 14:48:08 --> Security Class Initialized
DEBUG - 2020-10-07 14:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:48:08 --> Input Class Initialized
INFO - 2020-10-07 14:48:08 --> Language Class Initialized
INFO - 2020-10-07 14:48:08 --> Loader Class Initialized
INFO - 2020-10-07 14:48:08 --> Helper loaded: url_helper
INFO - 2020-10-07 14:48:08 --> Database Driver Class Initialized
INFO - 2020-10-07 14:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:48:08 --> Email Class Initialized
INFO - 2020-10-07 14:48:08 --> Controller Class Initialized
DEBUG - 2020-10-07 14:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:48:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:48:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:48:08 --> Final output sent to browser
DEBUG - 2020-10-07 14:48:08 --> Total execution time: 0.0169
ERROR - 2020-10-07 14:48:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:48:51 --> Config Class Initialized
INFO - 2020-10-07 14:48:51 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:48:51 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:48:51 --> Utf8 Class Initialized
INFO - 2020-10-07 14:48:51 --> URI Class Initialized
INFO - 2020-10-07 14:48:51 --> Router Class Initialized
INFO - 2020-10-07 14:48:51 --> Output Class Initialized
INFO - 2020-10-07 14:48:51 --> Security Class Initialized
DEBUG - 2020-10-07 14:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:48:51 --> Input Class Initialized
INFO - 2020-10-07 14:48:51 --> Language Class Initialized
INFO - 2020-10-07 14:48:51 --> Loader Class Initialized
INFO - 2020-10-07 14:48:51 --> Helper loaded: url_helper
INFO - 2020-10-07 14:48:51 --> Database Driver Class Initialized
INFO - 2020-10-07 14:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:48:51 --> Email Class Initialized
INFO - 2020-10-07 14:48:51 --> Controller Class Initialized
DEBUG - 2020-10-07 14:48:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:48:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:48:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:48:51 --> Final output sent to browser
DEBUG - 2020-10-07 14:48:51 --> Total execution time: 0.0198
ERROR - 2020-10-07 14:49:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:49:37 --> Config Class Initialized
INFO - 2020-10-07 14:49:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:49:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:49:37 --> Utf8 Class Initialized
INFO - 2020-10-07 14:49:37 --> URI Class Initialized
INFO - 2020-10-07 14:49:37 --> Router Class Initialized
INFO - 2020-10-07 14:49:37 --> Output Class Initialized
INFO - 2020-10-07 14:49:37 --> Security Class Initialized
DEBUG - 2020-10-07 14:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:49:37 --> Input Class Initialized
INFO - 2020-10-07 14:49:37 --> Language Class Initialized
INFO - 2020-10-07 14:49:37 --> Loader Class Initialized
INFO - 2020-10-07 14:49:37 --> Helper loaded: url_helper
INFO - 2020-10-07 14:49:37 --> Database Driver Class Initialized
INFO - 2020-10-07 14:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:49:37 --> Email Class Initialized
INFO - 2020-10-07 14:49:37 --> Controller Class Initialized
DEBUG - 2020-10-07 14:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:49:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:49:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:49:37 --> Final output sent to browser
DEBUG - 2020-10-07 14:49:37 --> Total execution time: 0.0203
ERROR - 2020-10-07 14:50:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:50:40 --> Config Class Initialized
INFO - 2020-10-07 14:50:40 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:50:40 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:50:40 --> Utf8 Class Initialized
INFO - 2020-10-07 14:50:40 --> URI Class Initialized
INFO - 2020-10-07 14:50:40 --> Router Class Initialized
INFO - 2020-10-07 14:50:40 --> Output Class Initialized
INFO - 2020-10-07 14:50:40 --> Security Class Initialized
DEBUG - 2020-10-07 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:50:40 --> Input Class Initialized
INFO - 2020-10-07 14:50:40 --> Language Class Initialized
INFO - 2020-10-07 14:50:40 --> Loader Class Initialized
INFO - 2020-10-07 14:50:40 --> Helper loaded: url_helper
INFO - 2020-10-07 14:50:40 --> Database Driver Class Initialized
INFO - 2020-10-07 14:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:50:40 --> Email Class Initialized
INFO - 2020-10-07 14:50:40 --> Controller Class Initialized
DEBUG - 2020-10-07 14:50:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:50:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:50:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:50:40 --> Final output sent to browser
DEBUG - 2020-10-07 14:50:40 --> Total execution time: 0.0187
ERROR - 2020-10-07 14:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:51:06 --> Config Class Initialized
INFO - 2020-10-07 14:51:06 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:51:06 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:51:06 --> Utf8 Class Initialized
INFO - 2020-10-07 14:51:06 --> URI Class Initialized
INFO - 2020-10-07 14:51:06 --> Router Class Initialized
INFO - 2020-10-07 14:51:06 --> Output Class Initialized
INFO - 2020-10-07 14:51:06 --> Security Class Initialized
DEBUG - 2020-10-07 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:51:06 --> Input Class Initialized
INFO - 2020-10-07 14:51:06 --> Language Class Initialized
INFO - 2020-10-07 14:51:06 --> Loader Class Initialized
INFO - 2020-10-07 14:51:06 --> Helper loaded: url_helper
INFO - 2020-10-07 14:51:06 --> Database Driver Class Initialized
INFO - 2020-10-07 14:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:51:06 --> Email Class Initialized
INFO - 2020-10-07 14:51:06 --> Controller Class Initialized
DEBUG - 2020-10-07 14:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:51:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:51:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:51:06 --> Final output sent to browser
DEBUG - 2020-10-07 14:51:06 --> Total execution time: 0.0216
ERROR - 2020-10-07 14:51:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:51:31 --> Config Class Initialized
INFO - 2020-10-07 14:51:31 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:51:31 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:51:31 --> Utf8 Class Initialized
INFO - 2020-10-07 14:51:31 --> URI Class Initialized
INFO - 2020-10-07 14:51:31 --> Router Class Initialized
INFO - 2020-10-07 14:51:31 --> Output Class Initialized
INFO - 2020-10-07 14:51:31 --> Security Class Initialized
DEBUG - 2020-10-07 14:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:51:31 --> Input Class Initialized
INFO - 2020-10-07 14:51:31 --> Language Class Initialized
INFO - 2020-10-07 14:51:31 --> Loader Class Initialized
INFO - 2020-10-07 14:51:31 --> Helper loaded: url_helper
INFO - 2020-10-07 14:51:31 --> Database Driver Class Initialized
INFO - 2020-10-07 14:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:51:31 --> Email Class Initialized
INFO - 2020-10-07 14:51:31 --> Controller Class Initialized
DEBUG - 2020-10-07 14:51:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:51:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:51:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:51:31 --> Final output sent to browser
DEBUG - 2020-10-07 14:51:31 --> Total execution time: 0.0196
ERROR - 2020-10-07 14:52:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:52:26 --> Config Class Initialized
INFO - 2020-10-07 14:52:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:52:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:52:26 --> Utf8 Class Initialized
INFO - 2020-10-07 14:52:26 --> URI Class Initialized
INFO - 2020-10-07 14:52:26 --> Router Class Initialized
INFO - 2020-10-07 14:52:26 --> Output Class Initialized
INFO - 2020-10-07 14:52:26 --> Security Class Initialized
DEBUG - 2020-10-07 14:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:52:26 --> Input Class Initialized
INFO - 2020-10-07 14:52:26 --> Language Class Initialized
INFO - 2020-10-07 14:52:26 --> Loader Class Initialized
INFO - 2020-10-07 14:52:26 --> Helper loaded: url_helper
INFO - 2020-10-07 14:52:26 --> Database Driver Class Initialized
INFO - 2020-10-07 14:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:52:26 --> Email Class Initialized
INFO - 2020-10-07 14:52:26 --> Controller Class Initialized
DEBUG - 2020-10-07 14:52:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:52:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:52:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:52:26 --> Final output sent to browser
DEBUG - 2020-10-07 14:52:26 --> Total execution time: 0.0184
ERROR - 2020-10-07 14:52:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:52:59 --> Config Class Initialized
INFO - 2020-10-07 14:52:59 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:52:59 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:52:59 --> Utf8 Class Initialized
INFO - 2020-10-07 14:52:59 --> URI Class Initialized
INFO - 2020-10-07 14:52:59 --> Router Class Initialized
INFO - 2020-10-07 14:52:59 --> Output Class Initialized
INFO - 2020-10-07 14:52:59 --> Security Class Initialized
DEBUG - 2020-10-07 14:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:52:59 --> Input Class Initialized
INFO - 2020-10-07 14:52:59 --> Language Class Initialized
INFO - 2020-10-07 14:52:59 --> Loader Class Initialized
INFO - 2020-10-07 14:52:59 --> Helper loaded: url_helper
INFO - 2020-10-07 14:52:59 --> Database Driver Class Initialized
INFO - 2020-10-07 14:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:52:59 --> Email Class Initialized
INFO - 2020-10-07 14:52:59 --> Controller Class Initialized
DEBUG - 2020-10-07 14:52:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:52:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:52:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:52:59 --> Final output sent to browser
DEBUG - 2020-10-07 14:52:59 --> Total execution time: 0.0315
ERROR - 2020-10-07 14:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:53:41 --> Config Class Initialized
INFO - 2020-10-07 14:53:41 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:53:41 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:53:41 --> Utf8 Class Initialized
INFO - 2020-10-07 14:53:41 --> URI Class Initialized
INFO - 2020-10-07 14:53:41 --> Router Class Initialized
INFO - 2020-10-07 14:53:41 --> Output Class Initialized
INFO - 2020-10-07 14:53:41 --> Security Class Initialized
DEBUG - 2020-10-07 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:53:41 --> Input Class Initialized
INFO - 2020-10-07 14:53:41 --> Language Class Initialized
INFO - 2020-10-07 14:53:41 --> Loader Class Initialized
INFO - 2020-10-07 14:53:41 --> Helper loaded: url_helper
INFO - 2020-10-07 14:53:41 --> Database Driver Class Initialized
INFO - 2020-10-07 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:53:41 --> Email Class Initialized
INFO - 2020-10-07 14:53:41 --> Controller Class Initialized
INFO - 2020-10-07 14:53:41 --> Model Class Initialized
INFO - 2020-10-07 14:53:41 --> Model Class Initialized
INFO - 2020-10-07 14:53:41 --> Model Class Initialized
INFO - 2020-10-07 14:53:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 14:53:41 --> Final output sent to browser
DEBUG - 2020-10-07 14:53:41 --> Total execution time: 0.0440
ERROR - 2020-10-07 14:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:53:41 --> Config Class Initialized
INFO - 2020-10-07 14:53:41 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:53:41 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:53:41 --> Utf8 Class Initialized
INFO - 2020-10-07 14:53:41 --> URI Class Initialized
INFO - 2020-10-07 14:53:41 --> Router Class Initialized
INFO - 2020-10-07 14:53:41 --> Output Class Initialized
INFO - 2020-10-07 14:53:41 --> Security Class Initialized
DEBUG - 2020-10-07 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:53:41 --> Input Class Initialized
INFO - 2020-10-07 14:53:41 --> Language Class Initialized
INFO - 2020-10-07 14:53:41 --> Loader Class Initialized
INFO - 2020-10-07 14:53:41 --> Helper loaded: url_helper
INFO - 2020-10-07 14:53:41 --> Database Driver Class Initialized
INFO - 2020-10-07 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:53:41 --> Email Class Initialized
INFO - 2020-10-07 14:53:41 --> Controller Class Initialized
INFO - 2020-10-07 14:53:41 --> Model Class Initialized
INFO - 2020-10-07 14:53:41 --> Model Class Initialized
INFO - 2020-10-07 14:53:42 --> Final output sent to browser
DEBUG - 2020-10-07 14:53:42 --> Total execution time: 0.0404
ERROR - 2020-10-07 14:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:53:44 --> Config Class Initialized
INFO - 2020-10-07 14:53:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:53:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:53:44 --> Utf8 Class Initialized
INFO - 2020-10-07 14:53:44 --> URI Class Initialized
INFO - 2020-10-07 14:53:44 --> Router Class Initialized
INFO - 2020-10-07 14:53:44 --> Output Class Initialized
INFO - 2020-10-07 14:53:44 --> Security Class Initialized
DEBUG - 2020-10-07 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:53:44 --> Input Class Initialized
INFO - 2020-10-07 14:53:44 --> Language Class Initialized
INFO - 2020-10-07 14:53:44 --> Loader Class Initialized
INFO - 2020-10-07 14:53:44 --> Helper loaded: url_helper
INFO - 2020-10-07 14:53:44 --> Database Driver Class Initialized
INFO - 2020-10-07 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:53:44 --> Email Class Initialized
INFO - 2020-10-07 14:53:44 --> Controller Class Initialized
INFO - 2020-10-07 14:53:44 --> Model Class Initialized
INFO - 2020-10-07 14:53:44 --> Model Class Initialized
INFO - 2020-10-07 14:53:44 --> Model Class Initialized
INFO - 2020-10-07 14:53:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-10-07 14:53:44 --> Final output sent to browser
DEBUG - 2020-10-07 14:53:44 --> Total execution time: 0.0405
ERROR - 2020-10-07 14:54:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:54:52 --> Config Class Initialized
INFO - 2020-10-07 14:54:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:54:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:54:52 --> Utf8 Class Initialized
INFO - 2020-10-07 14:54:52 --> URI Class Initialized
INFO - 2020-10-07 14:54:52 --> Router Class Initialized
INFO - 2020-10-07 14:54:52 --> Output Class Initialized
INFO - 2020-10-07 14:54:52 --> Security Class Initialized
DEBUG - 2020-10-07 14:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:54:52 --> Input Class Initialized
INFO - 2020-10-07 14:54:52 --> Language Class Initialized
INFO - 2020-10-07 14:54:52 --> Loader Class Initialized
INFO - 2020-10-07 14:54:52 --> Helper loaded: url_helper
INFO - 2020-10-07 14:54:52 --> Database Driver Class Initialized
INFO - 2020-10-07 14:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:54:52 --> Email Class Initialized
INFO - 2020-10-07 14:54:52 --> Controller Class Initialized
DEBUG - 2020-10-07 14:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:54:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:54:52 --> Model Class Initialized
INFO - 2020-10-07 14:54:52 --> Model Class Initialized
INFO - 2020-10-07 14:54:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:54:52 --> Final output sent to browser
DEBUG - 2020-10-07 14:54:52 --> Total execution time: 0.0303
ERROR - 2020-10-07 14:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:55:36 --> Config Class Initialized
INFO - 2020-10-07 14:55:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:55:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:55:36 --> Utf8 Class Initialized
INFO - 2020-10-07 14:55:36 --> URI Class Initialized
INFO - 2020-10-07 14:55:36 --> Router Class Initialized
INFO - 2020-10-07 14:55:36 --> Output Class Initialized
INFO - 2020-10-07 14:55:36 --> Security Class Initialized
DEBUG - 2020-10-07 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:55:36 --> Input Class Initialized
INFO - 2020-10-07 14:55:36 --> Language Class Initialized
INFO - 2020-10-07 14:55:36 --> Loader Class Initialized
INFO - 2020-10-07 14:55:36 --> Helper loaded: url_helper
INFO - 2020-10-07 14:55:36 --> Database Driver Class Initialized
INFO - 2020-10-07 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:55:36 --> Email Class Initialized
INFO - 2020-10-07 14:55:36 --> Controller Class Initialized
DEBUG - 2020-10-07 14:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:55:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:55:36 --> Model Class Initialized
INFO - 2020-10-07 14:55:36 --> Model Class Initialized
INFO - 2020-10-07 14:55:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:55:36 --> Final output sent to browser
DEBUG - 2020-10-07 14:55:36 --> Total execution time: 0.0227
ERROR - 2020-10-07 14:56:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:56:35 --> Config Class Initialized
INFO - 2020-10-07 14:56:35 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:56:35 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:56:35 --> Utf8 Class Initialized
INFO - 2020-10-07 14:56:35 --> URI Class Initialized
INFO - 2020-10-07 14:56:35 --> Router Class Initialized
INFO - 2020-10-07 14:56:35 --> Output Class Initialized
INFO - 2020-10-07 14:56:35 --> Security Class Initialized
DEBUG - 2020-10-07 14:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:56:35 --> Input Class Initialized
INFO - 2020-10-07 14:56:35 --> Language Class Initialized
INFO - 2020-10-07 14:56:35 --> Loader Class Initialized
INFO - 2020-10-07 14:56:35 --> Helper loaded: url_helper
INFO - 2020-10-07 14:56:35 --> Database Driver Class Initialized
INFO - 2020-10-07 14:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:56:35 --> Email Class Initialized
INFO - 2020-10-07 14:56:35 --> Controller Class Initialized
DEBUG - 2020-10-07 14:56:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:56:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:56:35 --> Model Class Initialized
INFO - 2020-10-07 14:56:35 --> Model Class Initialized
INFO - 2020-10-07 14:56:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:56:35 --> Final output sent to browser
DEBUG - 2020-10-07 14:56:35 --> Total execution time: 0.0225
ERROR - 2020-10-07 14:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 14:57:20 --> Config Class Initialized
INFO - 2020-10-07 14:57:20 --> Hooks Class Initialized
DEBUG - 2020-10-07 14:57:20 --> UTF-8 Support Enabled
INFO - 2020-10-07 14:57:20 --> Utf8 Class Initialized
INFO - 2020-10-07 14:57:20 --> URI Class Initialized
INFO - 2020-10-07 14:57:20 --> Router Class Initialized
INFO - 2020-10-07 14:57:20 --> Output Class Initialized
INFO - 2020-10-07 14:57:20 --> Security Class Initialized
DEBUG - 2020-10-07 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 14:57:20 --> Input Class Initialized
INFO - 2020-10-07 14:57:20 --> Language Class Initialized
INFO - 2020-10-07 14:57:20 --> Loader Class Initialized
INFO - 2020-10-07 14:57:20 --> Helper loaded: url_helper
INFO - 2020-10-07 14:57:20 --> Database Driver Class Initialized
INFO - 2020-10-07 14:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 14:57:20 --> Email Class Initialized
INFO - 2020-10-07 14:57:20 --> Controller Class Initialized
DEBUG - 2020-10-07 14:57:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 14:57:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 14:57:20 --> Model Class Initialized
INFO - 2020-10-07 14:57:20 --> Model Class Initialized
INFO - 2020-10-07 14:57:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 14:57:20 --> Final output sent to browser
DEBUG - 2020-10-07 14:57:20 --> Total execution time: 0.0255
ERROR - 2020-10-07 15:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 15:14:27 --> Config Class Initialized
INFO - 2020-10-07 15:14:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 15:14:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 15:14:27 --> Utf8 Class Initialized
INFO - 2020-10-07 15:14:27 --> URI Class Initialized
DEBUG - 2020-10-07 15:14:27 --> No URI present. Default controller set.
INFO - 2020-10-07 15:14:27 --> Router Class Initialized
INFO - 2020-10-07 15:14:27 --> Output Class Initialized
INFO - 2020-10-07 15:14:27 --> Security Class Initialized
DEBUG - 2020-10-07 15:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 15:14:27 --> Input Class Initialized
INFO - 2020-10-07 15:14:27 --> Language Class Initialized
INFO - 2020-10-07 15:14:27 --> Loader Class Initialized
INFO - 2020-10-07 15:14:27 --> Helper loaded: url_helper
INFO - 2020-10-07 15:14:27 --> Database Driver Class Initialized
INFO - 2020-10-07 15:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 15:14:27 --> Email Class Initialized
INFO - 2020-10-07 15:14:27 --> Controller Class Initialized
INFO - 2020-10-07 15:14:27 --> Model Class Initialized
INFO - 2020-10-07 15:14:27 --> Model Class Initialized
DEBUG - 2020-10-07 15:14:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 15:14:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 15:14:27 --> Final output sent to browser
DEBUG - 2020-10-07 15:14:27 --> Total execution time: 0.0209
ERROR - 2020-10-07 15:14:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 15:14:54 --> Config Class Initialized
INFO - 2020-10-07 15:14:54 --> Hooks Class Initialized
DEBUG - 2020-10-07 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-07 15:14:54 --> URI Class Initialized
DEBUG - 2020-10-07 15:14:54 --> No URI present. Default controller set.
INFO - 2020-10-07 15:14:54 --> Router Class Initialized
INFO - 2020-10-07 15:14:54 --> Output Class Initialized
INFO - 2020-10-07 15:14:54 --> Security Class Initialized
DEBUG - 2020-10-07 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 15:14:54 --> Input Class Initialized
INFO - 2020-10-07 15:14:54 --> Language Class Initialized
INFO - 2020-10-07 15:14:54 --> Loader Class Initialized
INFO - 2020-10-07 15:14:54 --> Helper loaded: url_helper
INFO - 2020-10-07 15:14:54 --> Database Driver Class Initialized
INFO - 2020-10-07 15:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 15:14:54 --> Email Class Initialized
INFO - 2020-10-07 15:14:54 --> Controller Class Initialized
INFO - 2020-10-07 15:14:54 --> Model Class Initialized
INFO - 2020-10-07 15:14:54 --> Model Class Initialized
DEBUG - 2020-10-07 15:14:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 15:14:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 15:14:54 --> Final output sent to browser
DEBUG - 2020-10-07 15:14:54 --> Total execution time: 0.0195
ERROR - 2020-10-07 15:15:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 15:15:20 --> Config Class Initialized
INFO - 2020-10-07 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-07 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-07 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-07 15:15:20 --> URI Class Initialized
DEBUG - 2020-10-07 15:15:20 --> No URI present. Default controller set.
INFO - 2020-10-07 15:15:20 --> Router Class Initialized
INFO - 2020-10-07 15:15:20 --> Output Class Initialized
INFO - 2020-10-07 15:15:20 --> Security Class Initialized
DEBUG - 2020-10-07 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 15:15:20 --> Input Class Initialized
INFO - 2020-10-07 15:15:20 --> Language Class Initialized
INFO - 2020-10-07 15:15:20 --> Loader Class Initialized
INFO - 2020-10-07 15:15:20 --> Helper loaded: url_helper
INFO - 2020-10-07 15:15:20 --> Database Driver Class Initialized
INFO - 2020-10-07 15:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 15:15:20 --> Email Class Initialized
INFO - 2020-10-07 15:15:20 --> Controller Class Initialized
INFO - 2020-10-07 15:15:20 --> Model Class Initialized
INFO - 2020-10-07 15:15:20 --> Model Class Initialized
DEBUG - 2020-10-07 15:15:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 15:15:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 15:15:20 --> Final output sent to browser
DEBUG - 2020-10-07 15:15:20 --> Total execution time: 0.0214
ERROR - 2020-10-07 16:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:10:27 --> Config Class Initialized
INFO - 2020-10-07 16:10:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:10:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:10:27 --> Utf8 Class Initialized
INFO - 2020-10-07 16:10:27 --> URI Class Initialized
DEBUG - 2020-10-07 16:10:27 --> No URI present. Default controller set.
INFO - 2020-10-07 16:10:27 --> Router Class Initialized
INFO - 2020-10-07 16:10:27 --> Output Class Initialized
INFO - 2020-10-07 16:10:27 --> Security Class Initialized
DEBUG - 2020-10-07 16:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:10:27 --> Input Class Initialized
INFO - 2020-10-07 16:10:27 --> Language Class Initialized
INFO - 2020-10-07 16:10:27 --> Loader Class Initialized
INFO - 2020-10-07 16:10:27 --> Helper loaded: url_helper
INFO - 2020-10-07 16:10:27 --> Database Driver Class Initialized
INFO - 2020-10-07 16:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:10:27 --> Email Class Initialized
INFO - 2020-10-07 16:10:27 --> Controller Class Initialized
INFO - 2020-10-07 16:10:27 --> Model Class Initialized
INFO - 2020-10-07 16:10:27 --> Model Class Initialized
DEBUG - 2020-10-07 16:10:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:10:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 16:10:27 --> Final output sent to browser
DEBUG - 2020-10-07 16:10:27 --> Total execution time: 0.0170
ERROR - 2020-10-07 16:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:10:57 --> Config Class Initialized
INFO - 2020-10-07 16:10:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:10:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:10:57 --> Utf8 Class Initialized
INFO - 2020-10-07 16:10:57 --> URI Class Initialized
INFO - 2020-10-07 16:10:57 --> Router Class Initialized
INFO - 2020-10-07 16:10:57 --> Output Class Initialized
INFO - 2020-10-07 16:10:57 --> Security Class Initialized
DEBUG - 2020-10-07 16:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:10:57 --> Input Class Initialized
INFO - 2020-10-07 16:10:57 --> Language Class Initialized
INFO - 2020-10-07 16:10:57 --> Loader Class Initialized
INFO - 2020-10-07 16:10:57 --> Helper loaded: url_helper
INFO - 2020-10-07 16:10:57 --> Database Driver Class Initialized
INFO - 2020-10-07 16:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:10:57 --> Email Class Initialized
INFO - 2020-10-07 16:10:57 --> Controller Class Initialized
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
DEBUG - 2020-10-07 16:10:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:10:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
INFO - 2020-10-07 16:10:57 --> Final output sent to browser
DEBUG - 2020-10-07 16:10:57 --> Total execution time: 0.0244
ERROR - 2020-10-07 16:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:10:57 --> Config Class Initialized
INFO - 2020-10-07 16:10:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:10:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:10:57 --> Utf8 Class Initialized
INFO - 2020-10-07 16:10:57 --> URI Class Initialized
INFO - 2020-10-07 16:10:57 --> Router Class Initialized
INFO - 2020-10-07 16:10:57 --> Output Class Initialized
INFO - 2020-10-07 16:10:57 --> Security Class Initialized
DEBUG - 2020-10-07 16:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:10:57 --> Input Class Initialized
INFO - 2020-10-07 16:10:57 --> Language Class Initialized
INFO - 2020-10-07 16:10:57 --> Loader Class Initialized
INFO - 2020-10-07 16:10:57 --> Helper loaded: url_helper
INFO - 2020-10-07 16:10:57 --> Database Driver Class Initialized
INFO - 2020-10-07 16:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:10:57 --> Email Class Initialized
INFO - 2020-10-07 16:10:57 --> Controller Class Initialized
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
DEBUG - 2020-10-07 16:10:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 16:10:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:10:57 --> Config Class Initialized
INFO - 2020-10-07 16:10:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:10:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:10:57 --> Utf8 Class Initialized
INFO - 2020-10-07 16:10:57 --> URI Class Initialized
INFO - 2020-10-07 16:10:57 --> Router Class Initialized
INFO - 2020-10-07 16:10:57 --> Output Class Initialized
INFO - 2020-10-07 16:10:57 --> Security Class Initialized
DEBUG - 2020-10-07 16:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:10:57 --> Input Class Initialized
INFO - 2020-10-07 16:10:57 --> Language Class Initialized
INFO - 2020-10-07 16:10:57 --> Loader Class Initialized
INFO - 2020-10-07 16:10:57 --> Helper loaded: url_helper
INFO - 2020-10-07 16:10:57 --> Database Driver Class Initialized
INFO - 2020-10-07 16:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:10:57 --> Email Class Initialized
INFO - 2020-10-07 16:10:57 --> Controller Class Initialized
DEBUG - 2020-10-07 16:10:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:10:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
INFO - 2020-10-07 16:10:57 --> Model Class Initialized
INFO - 2020-10-07 16:10:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-07 16:10:57 --> Final output sent to browser
DEBUG - 2020-10-07 16:10:57 --> Total execution time: 0.0228
ERROR - 2020-10-07 16:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:31:01 --> Config Class Initialized
INFO - 2020-10-07 16:31:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:31:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:31:01 --> Utf8 Class Initialized
INFO - 2020-10-07 16:31:01 --> URI Class Initialized
DEBUG - 2020-10-07 16:31:01 --> No URI present. Default controller set.
INFO - 2020-10-07 16:31:01 --> Router Class Initialized
INFO - 2020-10-07 16:31:01 --> Output Class Initialized
INFO - 2020-10-07 16:31:01 --> Security Class Initialized
DEBUG - 2020-10-07 16:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:31:01 --> Input Class Initialized
INFO - 2020-10-07 16:31:01 --> Language Class Initialized
INFO - 2020-10-07 16:31:01 --> Loader Class Initialized
INFO - 2020-10-07 16:31:01 --> Helper loaded: url_helper
INFO - 2020-10-07 16:31:01 --> Database Driver Class Initialized
INFO - 2020-10-07 16:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:31:01 --> Email Class Initialized
INFO - 2020-10-07 16:31:01 --> Controller Class Initialized
INFO - 2020-10-07 16:31:01 --> Model Class Initialized
INFO - 2020-10-07 16:31:01 --> Model Class Initialized
DEBUG - 2020-10-07 16:31:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:31:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 16:31:01 --> Final output sent to browser
DEBUG - 2020-10-07 16:31:01 --> Total execution time: 0.0188
ERROR - 2020-10-07 16:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:31:04 --> Config Class Initialized
INFO - 2020-10-07 16:31:04 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:31:04 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:31:04 --> Utf8 Class Initialized
INFO - 2020-10-07 16:31:04 --> URI Class Initialized
INFO - 2020-10-07 16:31:04 --> Router Class Initialized
INFO - 2020-10-07 16:31:04 --> Output Class Initialized
INFO - 2020-10-07 16:31:04 --> Security Class Initialized
DEBUG - 2020-10-07 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:31:04 --> Input Class Initialized
INFO - 2020-10-07 16:31:04 --> Language Class Initialized
INFO - 2020-10-07 16:31:04 --> Loader Class Initialized
INFO - 2020-10-07 16:31:04 --> Helper loaded: url_helper
INFO - 2020-10-07 16:31:04 --> Database Driver Class Initialized
INFO - 2020-10-07 16:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:31:04 --> Email Class Initialized
INFO - 2020-10-07 16:31:04 --> Controller Class Initialized
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
DEBUG - 2020-10-07 16:31:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:31:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
INFO - 2020-10-07 16:31:04 --> Final output sent to browser
DEBUG - 2020-10-07 16:31:04 --> Total execution time: 0.0243
ERROR - 2020-10-07 16:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:31:04 --> Config Class Initialized
INFO - 2020-10-07 16:31:04 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:31:04 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:31:04 --> Utf8 Class Initialized
INFO - 2020-10-07 16:31:04 --> URI Class Initialized
INFO - 2020-10-07 16:31:04 --> Router Class Initialized
INFO - 2020-10-07 16:31:04 --> Output Class Initialized
INFO - 2020-10-07 16:31:04 --> Security Class Initialized
DEBUG - 2020-10-07 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:31:04 --> Input Class Initialized
INFO - 2020-10-07 16:31:04 --> Language Class Initialized
INFO - 2020-10-07 16:31:04 --> Loader Class Initialized
INFO - 2020-10-07 16:31:04 --> Helper loaded: url_helper
INFO - 2020-10-07 16:31:04 --> Database Driver Class Initialized
INFO - 2020-10-07 16:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:31:04 --> Email Class Initialized
INFO - 2020-10-07 16:31:04 --> Controller Class Initialized
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
DEBUG - 2020-10-07 16:31:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 16:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:31:04 --> Config Class Initialized
INFO - 2020-10-07 16:31:04 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:31:04 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:31:04 --> Utf8 Class Initialized
INFO - 2020-10-07 16:31:04 --> URI Class Initialized
INFO - 2020-10-07 16:31:04 --> Router Class Initialized
INFO - 2020-10-07 16:31:04 --> Output Class Initialized
INFO - 2020-10-07 16:31:04 --> Security Class Initialized
DEBUG - 2020-10-07 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:31:04 --> Input Class Initialized
INFO - 2020-10-07 16:31:04 --> Language Class Initialized
INFO - 2020-10-07 16:31:04 --> Loader Class Initialized
INFO - 2020-10-07 16:31:04 --> Helper loaded: url_helper
INFO - 2020-10-07 16:31:04 --> Database Driver Class Initialized
INFO - 2020-10-07 16:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:31:04 --> Email Class Initialized
INFO - 2020-10-07 16:31:04 --> Controller Class Initialized
DEBUG - 2020-10-07 16:31:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:31:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
INFO - 2020-10-07 16:31:04 --> Model Class Initialized
INFO - 2020-10-07 16:31:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-07 16:31:04 --> Final output sent to browser
DEBUG - 2020-10-07 16:31:04 --> Total execution time: 0.0276
ERROR - 2020-10-07 16:31:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:31:12 --> Config Class Initialized
INFO - 2020-10-07 16:31:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:31:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:31:12 --> Utf8 Class Initialized
INFO - 2020-10-07 16:31:12 --> URI Class Initialized
DEBUG - 2020-10-07 16:31:12 --> No URI present. Default controller set.
INFO - 2020-10-07 16:31:12 --> Router Class Initialized
INFO - 2020-10-07 16:31:12 --> Output Class Initialized
INFO - 2020-10-07 16:31:12 --> Security Class Initialized
DEBUG - 2020-10-07 16:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:31:12 --> Input Class Initialized
INFO - 2020-10-07 16:31:12 --> Language Class Initialized
INFO - 2020-10-07 16:31:12 --> Loader Class Initialized
INFO - 2020-10-07 16:31:12 --> Helper loaded: url_helper
INFO - 2020-10-07 16:31:12 --> Database Driver Class Initialized
INFO - 2020-10-07 16:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:31:12 --> Email Class Initialized
INFO - 2020-10-07 16:31:12 --> Controller Class Initialized
INFO - 2020-10-07 16:31:12 --> Model Class Initialized
INFO - 2020-10-07 16:31:12 --> Model Class Initialized
DEBUG - 2020-10-07 16:31:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:31:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 16:31:12 --> Final output sent to browser
DEBUG - 2020-10-07 16:31:12 --> Total execution time: 0.0209
ERROR - 2020-10-07 16:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:32:12 --> Config Class Initialized
INFO - 2020-10-07 16:32:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:32:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:32:12 --> Utf8 Class Initialized
INFO - 2020-10-07 16:32:12 --> URI Class Initialized
INFO - 2020-10-07 16:32:12 --> Router Class Initialized
INFO - 2020-10-07 16:32:12 --> Output Class Initialized
INFO - 2020-10-07 16:32:12 --> Security Class Initialized
DEBUG - 2020-10-07 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:32:12 --> Input Class Initialized
INFO - 2020-10-07 16:32:12 --> Language Class Initialized
INFO - 2020-10-07 16:32:12 --> Loader Class Initialized
INFO - 2020-10-07 16:32:12 --> Helper loaded: url_helper
INFO - 2020-10-07 16:32:12 --> Database Driver Class Initialized
INFO - 2020-10-07 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:32:12 --> Email Class Initialized
INFO - 2020-10-07 16:32:12 --> Controller Class Initialized
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
DEBUG - 2020-10-07 16:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:32:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
INFO - 2020-10-07 16:32:12 --> Final output sent to browser
DEBUG - 2020-10-07 16:32:12 --> Total execution time: 0.0214
ERROR - 2020-10-07 16:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:32:12 --> Config Class Initialized
INFO - 2020-10-07 16:32:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:32:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:32:12 --> Utf8 Class Initialized
INFO - 2020-10-07 16:32:12 --> URI Class Initialized
INFO - 2020-10-07 16:32:12 --> Router Class Initialized
INFO - 2020-10-07 16:32:12 --> Output Class Initialized
INFO - 2020-10-07 16:32:12 --> Security Class Initialized
DEBUG - 2020-10-07 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:32:12 --> Input Class Initialized
INFO - 2020-10-07 16:32:12 --> Language Class Initialized
INFO - 2020-10-07 16:32:12 --> Loader Class Initialized
INFO - 2020-10-07 16:32:12 --> Helper loaded: url_helper
INFO - 2020-10-07 16:32:12 --> Database Driver Class Initialized
INFO - 2020-10-07 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:32:12 --> Email Class Initialized
INFO - 2020-10-07 16:32:12 --> Controller Class Initialized
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
DEBUG - 2020-10-07 16:32:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 16:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:32:12 --> Config Class Initialized
INFO - 2020-10-07 16:32:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:32:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:32:12 --> Utf8 Class Initialized
INFO - 2020-10-07 16:32:12 --> URI Class Initialized
INFO - 2020-10-07 16:32:12 --> Router Class Initialized
INFO - 2020-10-07 16:32:12 --> Output Class Initialized
INFO - 2020-10-07 16:32:12 --> Security Class Initialized
DEBUG - 2020-10-07 16:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:32:12 --> Input Class Initialized
INFO - 2020-10-07 16:32:12 --> Language Class Initialized
INFO - 2020-10-07 16:32:12 --> Loader Class Initialized
INFO - 2020-10-07 16:32:12 --> Helper loaded: url_helper
INFO - 2020-10-07 16:32:12 --> Database Driver Class Initialized
INFO - 2020-10-07 16:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:32:12 --> Email Class Initialized
INFO - 2020-10-07 16:32:12 --> Controller Class Initialized
DEBUG - 2020-10-07 16:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:32:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
INFO - 2020-10-07 16:32:12 --> Model Class Initialized
INFO - 2020-10-07 16:32:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 16:32:12 --> Final output sent to browser
DEBUG - 2020-10-07 16:32:12 --> Total execution time: 0.0209
ERROR - 2020-10-07 16:34:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:34:43 --> Config Class Initialized
INFO - 2020-10-07 16:34:43 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:34:43 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:34:43 --> Utf8 Class Initialized
INFO - 2020-10-07 16:34:43 --> URI Class Initialized
INFO - 2020-10-07 16:34:43 --> Router Class Initialized
INFO - 2020-10-07 16:34:43 --> Output Class Initialized
INFO - 2020-10-07 16:34:43 --> Security Class Initialized
DEBUG - 2020-10-07 16:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:34:43 --> Input Class Initialized
INFO - 2020-10-07 16:34:43 --> Language Class Initialized
INFO - 2020-10-07 16:34:43 --> Loader Class Initialized
INFO - 2020-10-07 16:34:43 --> Helper loaded: url_helper
INFO - 2020-10-07 16:34:43 --> Database Driver Class Initialized
INFO - 2020-10-07 16:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:34:43 --> Email Class Initialized
INFO - 2020-10-07 16:34:43 --> Controller Class Initialized
DEBUG - 2020-10-07 16:34:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:34:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:34:43 --> Model Class Initialized
INFO - 2020-10-07 16:34:43 --> Model Class Initialized
INFO - 2020-10-07 16:34:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 16:34:43 --> Final output sent to browser
DEBUG - 2020-10-07 16:34:43 --> Total execution time: 0.0215
ERROR - 2020-10-07 16:37:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:37:08 --> Config Class Initialized
INFO - 2020-10-07 16:37:08 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:37:08 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:37:08 --> Utf8 Class Initialized
INFO - 2020-10-07 16:37:08 --> URI Class Initialized
INFO - 2020-10-07 16:37:08 --> Router Class Initialized
INFO - 2020-10-07 16:37:08 --> Output Class Initialized
INFO - 2020-10-07 16:37:08 --> Security Class Initialized
DEBUG - 2020-10-07 16:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:37:08 --> Input Class Initialized
INFO - 2020-10-07 16:37:08 --> Language Class Initialized
INFO - 2020-10-07 16:37:08 --> Loader Class Initialized
INFO - 2020-10-07 16:37:08 --> Helper loaded: url_helper
INFO - 2020-10-07 16:37:08 --> Database Driver Class Initialized
INFO - 2020-10-07 16:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:37:08 --> Email Class Initialized
INFO - 2020-10-07 16:37:08 --> Controller Class Initialized
DEBUG - 2020-10-07 16:37:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:37:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:37:08 --> Model Class Initialized
INFO - 2020-10-07 16:37:08 --> Model Class Initialized
INFO - 2020-10-07 16:37:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 16:37:08 --> Final output sent to browser
DEBUG - 2020-10-07 16:37:08 --> Total execution time: 0.0219
ERROR - 2020-10-07 16:37:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:37:19 --> Config Class Initialized
INFO - 2020-10-07 16:37:19 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:37:19 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:37:19 --> Utf8 Class Initialized
INFO - 2020-10-07 16:37:19 --> URI Class Initialized
INFO - 2020-10-07 16:37:19 --> Router Class Initialized
INFO - 2020-10-07 16:37:19 --> Output Class Initialized
INFO - 2020-10-07 16:37:19 --> Security Class Initialized
DEBUG - 2020-10-07 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:37:19 --> Input Class Initialized
INFO - 2020-10-07 16:37:19 --> Language Class Initialized
INFO - 2020-10-07 16:37:19 --> Loader Class Initialized
INFO - 2020-10-07 16:37:19 --> Helper loaded: url_helper
INFO - 2020-10-07 16:37:19 --> Database Driver Class Initialized
INFO - 2020-10-07 16:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:37:19 --> Email Class Initialized
INFO - 2020-10-07 16:37:19 --> Controller Class Initialized
DEBUG - 2020-10-07 16:37:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:37:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:37:19 --> Model Class Initialized
INFO - 2020-10-07 16:37:19 --> Model Class Initialized
INFO - 2020-10-07 16:37:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:37:19 --> Final output sent to browser
DEBUG - 2020-10-07 16:37:19 --> Total execution time: 0.0223
ERROR - 2020-10-07 16:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:38:06 --> Config Class Initialized
INFO - 2020-10-07 16:38:06 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:38:06 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:38:06 --> Utf8 Class Initialized
INFO - 2020-10-07 16:38:06 --> URI Class Initialized
INFO - 2020-10-07 16:38:06 --> Router Class Initialized
INFO - 2020-10-07 16:38:06 --> Output Class Initialized
INFO - 2020-10-07 16:38:06 --> Security Class Initialized
DEBUG - 2020-10-07 16:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:38:06 --> Input Class Initialized
INFO - 2020-10-07 16:38:06 --> Language Class Initialized
INFO - 2020-10-07 16:38:06 --> Loader Class Initialized
INFO - 2020-10-07 16:38:06 --> Helper loaded: url_helper
INFO - 2020-10-07 16:38:06 --> Database Driver Class Initialized
INFO - 2020-10-07 16:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:38:06 --> Email Class Initialized
INFO - 2020-10-07 16:38:06 --> Controller Class Initialized
DEBUG - 2020-10-07 16:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:38:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:38:06 --> Model Class Initialized
INFO - 2020-10-07 16:38:06 --> Model Class Initialized
INFO - 2020-10-07 16:38:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:38:06 --> Final output sent to browser
DEBUG - 2020-10-07 16:38:06 --> Total execution time: 0.0223
ERROR - 2020-10-07 16:38:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:38:13 --> Config Class Initialized
INFO - 2020-10-07 16:38:13 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:38:13 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:38:13 --> Utf8 Class Initialized
INFO - 2020-10-07 16:38:13 --> URI Class Initialized
INFO - 2020-10-07 16:38:13 --> Router Class Initialized
INFO - 2020-10-07 16:38:13 --> Output Class Initialized
INFO - 2020-10-07 16:38:13 --> Security Class Initialized
DEBUG - 2020-10-07 16:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:38:13 --> Input Class Initialized
INFO - 2020-10-07 16:38:13 --> Language Class Initialized
INFO - 2020-10-07 16:38:13 --> Loader Class Initialized
INFO - 2020-10-07 16:38:13 --> Helper loaded: url_helper
INFO - 2020-10-07 16:38:13 --> Database Driver Class Initialized
INFO - 2020-10-07 16:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:38:13 --> Email Class Initialized
INFO - 2020-10-07 16:38:13 --> Controller Class Initialized
DEBUG - 2020-10-07 16:38:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:38:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:38:13 --> Model Class Initialized
INFO - 2020-10-07 16:38:13 --> Model Class Initialized
INFO - 2020-10-07 16:38:13 --> Model Class Initialized
INFO - 2020-10-07 16:38:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-07 16:38:13 --> Final output sent to browser
DEBUG - 2020-10-07 16:38:13 --> Total execution time: 0.0339
ERROR - 2020-10-07 16:38:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:38:54 --> Config Class Initialized
INFO - 2020-10-07 16:38:54 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:38:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:38:54 --> Utf8 Class Initialized
INFO - 2020-10-07 16:38:54 --> URI Class Initialized
INFO - 2020-10-07 16:38:54 --> Router Class Initialized
INFO - 2020-10-07 16:38:54 --> Output Class Initialized
INFO - 2020-10-07 16:38:54 --> Security Class Initialized
DEBUG - 2020-10-07 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:38:54 --> Input Class Initialized
INFO - 2020-10-07 16:38:54 --> Language Class Initialized
INFO - 2020-10-07 16:38:54 --> Loader Class Initialized
INFO - 2020-10-07 16:38:54 --> Helper loaded: url_helper
INFO - 2020-10-07 16:38:54 --> Database Driver Class Initialized
INFO - 2020-10-07 16:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:38:54 --> Email Class Initialized
INFO - 2020-10-07 16:38:54 --> Controller Class Initialized
DEBUG - 2020-10-07 16:38:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:38:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:38:54 --> Model Class Initialized
INFO - 2020-10-07 16:38:54 --> Model Class Initialized
INFO - 2020-10-07 16:38:54 --> Model Class Initialized
INFO - 2020-10-07 16:38:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-07 16:38:54 --> Final output sent to browser
DEBUG - 2020-10-07 16:38:54 --> Total execution time: 0.0212
ERROR - 2020-10-07 16:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:38:55 --> Config Class Initialized
INFO - 2020-10-07 16:38:55 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:38:55 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:38:55 --> Utf8 Class Initialized
INFO - 2020-10-07 16:38:55 --> URI Class Initialized
INFO - 2020-10-07 16:38:55 --> Router Class Initialized
INFO - 2020-10-07 16:38:55 --> Output Class Initialized
INFO - 2020-10-07 16:38:55 --> Security Class Initialized
DEBUG - 2020-10-07 16:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:38:55 --> Input Class Initialized
INFO - 2020-10-07 16:38:55 --> Language Class Initialized
INFO - 2020-10-07 16:38:55 --> Loader Class Initialized
INFO - 2020-10-07 16:38:55 --> Helper loaded: url_helper
INFO - 2020-10-07 16:38:55 --> Database Driver Class Initialized
INFO - 2020-10-07 16:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:38:55 --> Email Class Initialized
INFO - 2020-10-07 16:38:55 --> Controller Class Initialized
DEBUG - 2020-10-07 16:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:38:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:38:55 --> Model Class Initialized
INFO - 2020-10-07 16:38:55 --> Model Class Initialized
INFO - 2020-10-07 16:38:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:38:55 --> Final output sent to browser
DEBUG - 2020-10-07 16:38:55 --> Total execution time: 0.0215
ERROR - 2020-10-07 16:38:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:38:57 --> Config Class Initialized
INFO - 2020-10-07 16:38:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:38:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:38:57 --> Utf8 Class Initialized
INFO - 2020-10-07 16:38:57 --> URI Class Initialized
INFO - 2020-10-07 16:38:57 --> Router Class Initialized
INFO - 2020-10-07 16:38:57 --> Output Class Initialized
INFO - 2020-10-07 16:38:57 --> Security Class Initialized
DEBUG - 2020-10-07 16:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:38:57 --> Input Class Initialized
INFO - 2020-10-07 16:38:57 --> Language Class Initialized
INFO - 2020-10-07 16:38:57 --> Loader Class Initialized
INFO - 2020-10-07 16:38:57 --> Helper loaded: url_helper
INFO - 2020-10-07 16:38:57 --> Database Driver Class Initialized
INFO - 2020-10-07 16:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:38:57 --> Email Class Initialized
INFO - 2020-10-07 16:38:57 --> Controller Class Initialized
DEBUG - 2020-10-07 16:38:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:38:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:38:57 --> Model Class Initialized
INFO - 2020-10-07 16:38:57 --> Model Class Initialized
INFO - 2020-10-07 16:38:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-07 16:38:57 --> Final output sent to browser
DEBUG - 2020-10-07 16:38:57 --> Total execution time: 0.0379
ERROR - 2020-10-07 16:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:02 --> Config Class Initialized
INFO - 2020-10-07 16:39:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:02 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:02 --> URI Class Initialized
INFO - 2020-10-07 16:39:02 --> Router Class Initialized
INFO - 2020-10-07 16:39:02 --> Output Class Initialized
INFO - 2020-10-07 16:39:02 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:02 --> Input Class Initialized
INFO - 2020-10-07 16:39:02 --> Language Class Initialized
INFO - 2020-10-07 16:39:02 --> Loader Class Initialized
INFO - 2020-10-07 16:39:02 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:02 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:02 --> Email Class Initialized
INFO - 2020-10-07 16:39:02 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:02 --> Model Class Initialized
INFO - 2020-10-07 16:39:02 --> Model Class Initialized
INFO - 2020-10-07 16:39:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-07 16:39:02 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:02 --> Total execution time: 0.0250
ERROR - 2020-10-07 16:39:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:23 --> Config Class Initialized
INFO - 2020-10-07 16:39:23 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:23 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:23 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:23 --> URI Class Initialized
INFO - 2020-10-07 16:39:23 --> Router Class Initialized
INFO - 2020-10-07 16:39:23 --> Output Class Initialized
INFO - 2020-10-07 16:39:23 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:23 --> Input Class Initialized
INFO - 2020-10-07 16:39:23 --> Language Class Initialized
INFO - 2020-10-07 16:39:23 --> Loader Class Initialized
INFO - 2020-10-07 16:39:23 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:23 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:23 --> Email Class Initialized
INFO - 2020-10-07 16:39:23 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:23 --> Model Class Initialized
INFO - 2020-10-07 16:39:23 --> Model Class Initialized
INFO - 2020-10-07 16:39:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-07 16:39:23 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:23 --> Total execution time: 0.0222
ERROR - 2020-10-07 16:39:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:25 --> Config Class Initialized
INFO - 2020-10-07 16:39:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:25 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:25 --> URI Class Initialized
INFO - 2020-10-07 16:39:25 --> Router Class Initialized
INFO - 2020-10-07 16:39:25 --> Output Class Initialized
INFO - 2020-10-07 16:39:25 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:25 --> Input Class Initialized
INFO - 2020-10-07 16:39:25 --> Language Class Initialized
INFO - 2020-10-07 16:39:25 --> Loader Class Initialized
INFO - 2020-10-07 16:39:25 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:25 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:25 --> Email Class Initialized
INFO - 2020-10-07 16:39:25 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:25 --> Model Class Initialized
INFO - 2020-10-07 16:39:25 --> Model Class Initialized
INFO - 2020-10-07 16:39:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:39:25 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:25 --> Total execution time: 0.0185
ERROR - 2020-10-07 16:39:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:29 --> Config Class Initialized
INFO - 2020-10-07 16:39:29 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:29 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:29 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:29 --> URI Class Initialized
INFO - 2020-10-07 16:39:29 --> Router Class Initialized
INFO - 2020-10-07 16:39:29 --> Output Class Initialized
INFO - 2020-10-07 16:39:29 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:29 --> Input Class Initialized
INFO - 2020-10-07 16:39:29 --> Language Class Initialized
INFO - 2020-10-07 16:39:29 --> Loader Class Initialized
INFO - 2020-10-07 16:39:29 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:29 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:29 --> Email Class Initialized
INFO - 2020-10-07 16:39:29 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:29 --> Model Class Initialized
INFO - 2020-10-07 16:39:29 --> Model Class Initialized
INFO - 2020-10-07 16:39:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-07 16:39:29 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:29 --> Total execution time: 0.0233
ERROR - 2020-10-07 16:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:36 --> Config Class Initialized
INFO - 2020-10-07 16:39:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:36 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:36 --> URI Class Initialized
INFO - 2020-10-07 16:39:36 --> Router Class Initialized
INFO - 2020-10-07 16:39:36 --> Output Class Initialized
INFO - 2020-10-07 16:39:36 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:36 --> Input Class Initialized
INFO - 2020-10-07 16:39:36 --> Language Class Initialized
INFO - 2020-10-07 16:39:36 --> Loader Class Initialized
INFO - 2020-10-07 16:39:36 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:36 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:36 --> Email Class Initialized
INFO - 2020-10-07 16:39:36 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:36 --> Model Class Initialized
INFO - 2020-10-07 16:39:36 --> Model Class Initialized
INFO - 2020-10-07 16:39:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:39:36 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:36 --> Total execution time: 0.0332
ERROR - 2020-10-07 16:39:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:39 --> Config Class Initialized
INFO - 2020-10-07 16:39:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:39 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:39 --> URI Class Initialized
INFO - 2020-10-07 16:39:39 --> Router Class Initialized
INFO - 2020-10-07 16:39:39 --> Output Class Initialized
INFO - 2020-10-07 16:39:39 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:39 --> Input Class Initialized
INFO - 2020-10-07 16:39:39 --> Language Class Initialized
INFO - 2020-10-07 16:39:39 --> Loader Class Initialized
INFO - 2020-10-07 16:39:39 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:39 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:39 --> Email Class Initialized
INFO - 2020-10-07 16:39:39 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:39 --> Model Class Initialized
INFO - 2020-10-07 16:39:39 --> Model Class Initialized
INFO - 2020-10-07 16:39:39 --> Model Class Initialized
INFO - 2020-10-07 16:39:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-10-07 16:39:39 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:39 --> Total execution time: 0.0254
ERROR - 2020-10-07 16:39:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:39:57 --> Config Class Initialized
INFO - 2020-10-07 16:39:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:39:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:39:57 --> Utf8 Class Initialized
INFO - 2020-10-07 16:39:57 --> URI Class Initialized
INFO - 2020-10-07 16:39:57 --> Router Class Initialized
INFO - 2020-10-07 16:39:57 --> Output Class Initialized
INFO - 2020-10-07 16:39:57 --> Security Class Initialized
DEBUG - 2020-10-07 16:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:39:57 --> Input Class Initialized
INFO - 2020-10-07 16:39:57 --> Language Class Initialized
INFO - 2020-10-07 16:39:57 --> Loader Class Initialized
INFO - 2020-10-07 16:39:57 --> Helper loaded: url_helper
INFO - 2020-10-07 16:39:57 --> Database Driver Class Initialized
INFO - 2020-10-07 16:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:39:57 --> Email Class Initialized
INFO - 2020-10-07 16:39:57 --> Controller Class Initialized
DEBUG - 2020-10-07 16:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:39:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:39:57 --> Model Class Initialized
INFO - 2020-10-07 16:39:57 --> Model Class Initialized
INFO - 2020-10-07 16:39:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:39:57 --> Final output sent to browser
DEBUG - 2020-10-07 16:39:57 --> Total execution time: 0.0193
ERROR - 2020-10-07 16:40:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:40:24 --> Config Class Initialized
INFO - 2020-10-07 16:40:24 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:40:24 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:40:24 --> Utf8 Class Initialized
INFO - 2020-10-07 16:40:24 --> URI Class Initialized
INFO - 2020-10-07 16:40:24 --> Router Class Initialized
INFO - 2020-10-07 16:40:24 --> Output Class Initialized
INFO - 2020-10-07 16:40:24 --> Security Class Initialized
DEBUG - 2020-10-07 16:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:40:24 --> Input Class Initialized
INFO - 2020-10-07 16:40:24 --> Language Class Initialized
INFO - 2020-10-07 16:40:24 --> Loader Class Initialized
INFO - 2020-10-07 16:40:24 --> Helper loaded: url_helper
INFO - 2020-10-07 16:40:24 --> Database Driver Class Initialized
INFO - 2020-10-07 16:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:40:24 --> Email Class Initialized
INFO - 2020-10-07 16:40:24 --> Controller Class Initialized
DEBUG - 2020-10-07 16:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:40:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:40:24 --> Model Class Initialized
INFO - 2020-10-07 16:40:24 --> Model Class Initialized
INFO - 2020-10-07 16:40:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:40:24 --> Final output sent to browser
DEBUG - 2020-10-07 16:40:24 --> Total execution time: 0.0225
ERROR - 2020-10-07 16:41:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:41:50 --> Config Class Initialized
INFO - 2020-10-07 16:41:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:41:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:41:50 --> Utf8 Class Initialized
INFO - 2020-10-07 16:41:50 --> URI Class Initialized
INFO - 2020-10-07 16:41:50 --> Router Class Initialized
INFO - 2020-10-07 16:41:50 --> Output Class Initialized
INFO - 2020-10-07 16:41:50 --> Security Class Initialized
DEBUG - 2020-10-07 16:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:41:50 --> Input Class Initialized
INFO - 2020-10-07 16:41:50 --> Language Class Initialized
INFO - 2020-10-07 16:41:50 --> Loader Class Initialized
INFO - 2020-10-07 16:41:50 --> Helper loaded: url_helper
INFO - 2020-10-07 16:41:50 --> Database Driver Class Initialized
INFO - 2020-10-07 16:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:41:50 --> Email Class Initialized
INFO - 2020-10-07 16:41:50 --> Controller Class Initialized
DEBUG - 2020-10-07 16:41:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:41:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:41:50 --> Model Class Initialized
INFO - 2020-10-07 16:41:50 --> Model Class Initialized
INFO - 2020-10-07 16:41:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-07 16:41:50 --> Final output sent to browser
DEBUG - 2020-10-07 16:41:50 --> Total execution time: 0.0202
ERROR - 2020-10-07 16:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:44:43 --> Config Class Initialized
INFO - 2020-10-07 16:44:43 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:44:43 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:44:43 --> Utf8 Class Initialized
INFO - 2020-10-07 16:44:43 --> URI Class Initialized
INFO - 2020-10-07 16:44:43 --> Router Class Initialized
INFO - 2020-10-07 16:44:43 --> Output Class Initialized
INFO - 2020-10-07 16:44:43 --> Security Class Initialized
DEBUG - 2020-10-07 16:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:44:43 --> Input Class Initialized
INFO - 2020-10-07 16:44:43 --> Language Class Initialized
INFO - 2020-10-07 16:44:43 --> Loader Class Initialized
INFO - 2020-10-07 16:44:43 --> Helper loaded: url_helper
INFO - 2020-10-07 16:44:43 --> Database Driver Class Initialized
INFO - 2020-10-07 16:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:44:43 --> Email Class Initialized
INFO - 2020-10-07 16:44:43 --> Controller Class Initialized
DEBUG - 2020-10-07 16:44:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:44:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:44:43 --> Model Class Initialized
INFO - 2020-10-07 16:44:43 --> Model Class Initialized
INFO - 2020-10-07 16:44:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-07 16:44:43 --> Final output sent to browser
DEBUG - 2020-10-07 16:44:43 --> Total execution time: 0.0249
ERROR - 2020-10-07 16:44:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:44:47 --> Config Class Initialized
INFO - 2020-10-07 16:44:47 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:44:47 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:44:47 --> Utf8 Class Initialized
INFO - 2020-10-07 16:44:47 --> URI Class Initialized
INFO - 2020-10-07 16:44:47 --> Router Class Initialized
INFO - 2020-10-07 16:44:47 --> Output Class Initialized
INFO - 2020-10-07 16:44:47 --> Security Class Initialized
DEBUG - 2020-10-07 16:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:44:47 --> Input Class Initialized
INFO - 2020-10-07 16:44:47 --> Language Class Initialized
INFO - 2020-10-07 16:44:47 --> Loader Class Initialized
INFO - 2020-10-07 16:44:47 --> Helper loaded: url_helper
INFO - 2020-10-07 16:44:47 --> Database Driver Class Initialized
INFO - 2020-10-07 16:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:44:47 --> Email Class Initialized
INFO - 2020-10-07 16:44:47 --> Controller Class Initialized
DEBUG - 2020-10-07 16:44:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:44:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:44:47 --> Model Class Initialized
INFO - 2020-10-07 16:44:47 --> Model Class Initialized
INFO - 2020-10-07 16:44:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:44:47 --> Final output sent to browser
DEBUG - 2020-10-07 16:44:47 --> Total execution time: 0.0235
ERROR - 2020-10-07 16:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:44:51 --> Config Class Initialized
INFO - 2020-10-07 16:44:51 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:44:51 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:44:51 --> Utf8 Class Initialized
INFO - 2020-10-07 16:44:51 --> URI Class Initialized
INFO - 2020-10-07 16:44:51 --> Router Class Initialized
INFO - 2020-10-07 16:44:51 --> Output Class Initialized
INFO - 2020-10-07 16:44:51 --> Security Class Initialized
DEBUG - 2020-10-07 16:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:44:51 --> Input Class Initialized
INFO - 2020-10-07 16:44:51 --> Language Class Initialized
INFO - 2020-10-07 16:44:51 --> Loader Class Initialized
INFO - 2020-10-07 16:44:51 --> Helper loaded: url_helper
INFO - 2020-10-07 16:44:51 --> Database Driver Class Initialized
INFO - 2020-10-07 16:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:44:51 --> Email Class Initialized
INFO - 2020-10-07 16:44:51 --> Controller Class Initialized
DEBUG - 2020-10-07 16:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:44:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:44:51 --> Model Class Initialized
INFO - 2020-10-07 16:44:51 --> Model Class Initialized
INFO - 2020-10-07 16:44:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-07 16:44:51 --> Final output sent to browser
DEBUG - 2020-10-07 16:44:51 --> Total execution time: 0.0222
ERROR - 2020-10-07 16:44:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:44:56 --> Config Class Initialized
INFO - 2020-10-07 16:44:56 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:44:56 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:44:56 --> Utf8 Class Initialized
INFO - 2020-10-07 16:44:56 --> URI Class Initialized
INFO - 2020-10-07 16:44:56 --> Router Class Initialized
INFO - 2020-10-07 16:44:56 --> Output Class Initialized
INFO - 2020-10-07 16:44:56 --> Security Class Initialized
DEBUG - 2020-10-07 16:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:44:56 --> Input Class Initialized
INFO - 2020-10-07 16:44:56 --> Language Class Initialized
INFO - 2020-10-07 16:44:56 --> Loader Class Initialized
INFO - 2020-10-07 16:44:56 --> Helper loaded: url_helper
INFO - 2020-10-07 16:44:56 --> Database Driver Class Initialized
INFO - 2020-10-07 16:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:44:56 --> Email Class Initialized
INFO - 2020-10-07 16:44:56 --> Controller Class Initialized
DEBUG - 2020-10-07 16:44:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:44:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:44:56 --> Model Class Initialized
INFO - 2020-10-07 16:44:56 --> Model Class Initialized
INFO - 2020-10-07 16:44:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:44:56 --> Final output sent to browser
DEBUG - 2020-10-07 16:44:56 --> Total execution time: 0.0216
ERROR - 2020-10-07 16:44:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:44:58 --> Config Class Initialized
INFO - 2020-10-07 16:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:44:58 --> Utf8 Class Initialized
INFO - 2020-10-07 16:44:58 --> URI Class Initialized
INFO - 2020-10-07 16:44:58 --> Router Class Initialized
INFO - 2020-10-07 16:44:58 --> Output Class Initialized
INFO - 2020-10-07 16:44:58 --> Security Class Initialized
DEBUG - 2020-10-07 16:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:44:58 --> Input Class Initialized
INFO - 2020-10-07 16:44:58 --> Language Class Initialized
INFO - 2020-10-07 16:44:58 --> Loader Class Initialized
INFO - 2020-10-07 16:44:58 --> Helper loaded: url_helper
INFO - 2020-10-07 16:44:58 --> Database Driver Class Initialized
INFO - 2020-10-07 16:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:44:58 --> Email Class Initialized
INFO - 2020-10-07 16:44:58 --> Controller Class Initialized
DEBUG - 2020-10-07 16:44:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:44:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:44:58 --> Model Class Initialized
INFO - 2020-10-07 16:44:58 --> Model Class Initialized
INFO - 2020-10-07 16:44:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-07 16:44:58 --> Final output sent to browser
DEBUG - 2020-10-07 16:44:58 --> Total execution time: 0.0193
ERROR - 2020-10-07 16:45:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:01 --> Config Class Initialized
INFO - 2020-10-07 16:45:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:01 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:01 --> URI Class Initialized
INFO - 2020-10-07 16:45:01 --> Router Class Initialized
INFO - 2020-10-07 16:45:01 --> Output Class Initialized
INFO - 2020-10-07 16:45:01 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:01 --> Input Class Initialized
INFO - 2020-10-07 16:45:01 --> Language Class Initialized
INFO - 2020-10-07 16:45:01 --> Loader Class Initialized
INFO - 2020-10-07 16:45:01 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:01 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:01 --> Email Class Initialized
INFO - 2020-10-07 16:45:01 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:01 --> Model Class Initialized
INFO - 2020-10-07 16:45:01 --> Model Class Initialized
INFO - 2020-10-07 16:45:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:45:01 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:01 --> Total execution time: 0.0278
ERROR - 2020-10-07 16:45:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:18 --> Config Class Initialized
INFO - 2020-10-07 16:45:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:18 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:18 --> URI Class Initialized
INFO - 2020-10-07 16:45:18 --> Router Class Initialized
INFO - 2020-10-07 16:45:18 --> Output Class Initialized
INFO - 2020-10-07 16:45:18 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:18 --> Input Class Initialized
INFO - 2020-10-07 16:45:18 --> Language Class Initialized
INFO - 2020-10-07 16:45:18 --> Loader Class Initialized
INFO - 2020-10-07 16:45:18 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:18 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:18 --> Email Class Initialized
INFO - 2020-10-07 16:45:18 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:18 --> Model Class Initialized
INFO - 2020-10-07 16:45:18 --> Model Class Initialized
INFO - 2020-10-07 16:45:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-07 16:45:18 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:18 --> Total execution time: 0.0241
ERROR - 2020-10-07 16:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:32 --> Config Class Initialized
INFO - 2020-10-07 16:45:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:32 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:32 --> URI Class Initialized
INFO - 2020-10-07 16:45:32 --> Router Class Initialized
INFO - 2020-10-07 16:45:32 --> Output Class Initialized
INFO - 2020-10-07 16:45:32 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:32 --> Input Class Initialized
INFO - 2020-10-07 16:45:32 --> Language Class Initialized
INFO - 2020-10-07 16:45:32 --> Loader Class Initialized
INFO - 2020-10-07 16:45:32 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:32 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:32 --> Email Class Initialized
INFO - 2020-10-07 16:45:32 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:32 --> Model Class Initialized
INFO - 2020-10-07 16:45:32 --> Model Class Initialized
INFO - 2020-10-07 16:45:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:45:32 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:32 --> Total execution time: 0.0198
ERROR - 2020-10-07 16:45:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:35 --> Config Class Initialized
INFO - 2020-10-07 16:45:35 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:35 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:35 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:35 --> URI Class Initialized
INFO - 2020-10-07 16:45:35 --> Router Class Initialized
INFO - 2020-10-07 16:45:35 --> Output Class Initialized
INFO - 2020-10-07 16:45:35 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:35 --> Input Class Initialized
INFO - 2020-10-07 16:45:35 --> Language Class Initialized
INFO - 2020-10-07 16:45:35 --> Loader Class Initialized
INFO - 2020-10-07 16:45:35 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:35 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:35 --> Email Class Initialized
INFO - 2020-10-07 16:45:35 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:35 --> Model Class Initialized
INFO - 2020-10-07 16:45:35 --> Model Class Initialized
INFO - 2020-10-07 16:45:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 16:45:35 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:35 --> Total execution time: 0.0294
ERROR - 2020-10-07 16:45:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:36 --> Config Class Initialized
INFO - 2020-10-07 16:45:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:36 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:36 --> URI Class Initialized
INFO - 2020-10-07 16:45:36 --> Router Class Initialized
INFO - 2020-10-07 16:45:36 --> Output Class Initialized
INFO - 2020-10-07 16:45:36 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:36 --> Input Class Initialized
INFO - 2020-10-07 16:45:36 --> Language Class Initialized
INFO - 2020-10-07 16:45:36 --> Loader Class Initialized
INFO - 2020-10-07 16:45:36 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:36 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:36 --> Email Class Initialized
INFO - 2020-10-07 16:45:36 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:36 --> Model Class Initialized
INFO - 2020-10-07 16:45:36 --> Model Class Initialized
INFO - 2020-10-07 16:45:36 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:36 --> Total execution time: 0.0221
ERROR - 2020-10-07 16:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:40 --> Config Class Initialized
INFO - 2020-10-07 16:45:40 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:40 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:40 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:40 --> URI Class Initialized
INFO - 2020-10-07 16:45:40 --> Router Class Initialized
INFO - 2020-10-07 16:45:40 --> Output Class Initialized
INFO - 2020-10-07 16:45:40 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:40 --> Input Class Initialized
INFO - 2020-10-07 16:45:40 --> Language Class Initialized
INFO - 2020-10-07 16:45:40 --> Loader Class Initialized
INFO - 2020-10-07 16:45:40 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:40 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:40 --> Email Class Initialized
INFO - 2020-10-07 16:45:40 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:40 --> Model Class Initialized
INFO - 2020-10-07 16:45:40 --> Model Class Initialized
INFO - 2020-10-07 16:45:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:45:40 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:40 --> Total execution time: 0.0231
ERROR - 2020-10-07 16:45:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:45:58 --> Config Class Initialized
INFO - 2020-10-07 16:45:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:45:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:45:58 --> Utf8 Class Initialized
INFO - 2020-10-07 16:45:58 --> URI Class Initialized
INFO - 2020-10-07 16:45:58 --> Router Class Initialized
INFO - 2020-10-07 16:45:58 --> Output Class Initialized
INFO - 2020-10-07 16:45:58 --> Security Class Initialized
DEBUG - 2020-10-07 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:45:58 --> Input Class Initialized
INFO - 2020-10-07 16:45:58 --> Language Class Initialized
INFO - 2020-10-07 16:45:58 --> Loader Class Initialized
INFO - 2020-10-07 16:45:58 --> Helper loaded: url_helper
INFO - 2020-10-07 16:45:58 --> Database Driver Class Initialized
INFO - 2020-10-07 16:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:45:58 --> Email Class Initialized
INFO - 2020-10-07 16:45:58 --> Controller Class Initialized
DEBUG - 2020-10-07 16:45:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:45:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:45:58 --> Model Class Initialized
INFO - 2020-10-07 16:45:58 --> Model Class Initialized
INFO - 2020-10-07 16:45:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 16:45:58 --> Final output sent to browser
DEBUG - 2020-10-07 16:45:58 --> Total execution time: 0.0237
ERROR - 2020-10-07 16:46:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:46:02 --> Config Class Initialized
INFO - 2020-10-07 16:46:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:46:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:46:02 --> Utf8 Class Initialized
INFO - 2020-10-07 16:46:02 --> URI Class Initialized
INFO - 2020-10-07 16:46:02 --> Router Class Initialized
INFO - 2020-10-07 16:46:02 --> Output Class Initialized
INFO - 2020-10-07 16:46:02 --> Security Class Initialized
DEBUG - 2020-10-07 16:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:46:02 --> Input Class Initialized
INFO - 2020-10-07 16:46:02 --> Language Class Initialized
INFO - 2020-10-07 16:46:02 --> Loader Class Initialized
INFO - 2020-10-07 16:46:02 --> Helper loaded: url_helper
INFO - 2020-10-07 16:46:02 --> Database Driver Class Initialized
INFO - 2020-10-07 16:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:46:02 --> Email Class Initialized
INFO - 2020-10-07 16:46:02 --> Controller Class Initialized
DEBUG - 2020-10-07 16:46:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:46:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:46:02 --> Model Class Initialized
INFO - 2020-10-07 16:46:02 --> Model Class Initialized
INFO - 2020-10-07 16:46:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:46:02 --> Final output sent to browser
DEBUG - 2020-10-07 16:46:02 --> Total execution time: 0.0264
ERROR - 2020-10-07 16:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:47:16 --> Config Class Initialized
INFO - 2020-10-07 16:47:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:47:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:47:16 --> Utf8 Class Initialized
INFO - 2020-10-07 16:47:16 --> URI Class Initialized
INFO - 2020-10-07 16:47:16 --> Router Class Initialized
INFO - 2020-10-07 16:47:16 --> Output Class Initialized
INFO - 2020-10-07 16:47:16 --> Security Class Initialized
DEBUG - 2020-10-07 16:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:47:16 --> Input Class Initialized
INFO - 2020-10-07 16:47:16 --> Language Class Initialized
INFO - 2020-10-07 16:47:16 --> Loader Class Initialized
INFO - 2020-10-07 16:47:16 --> Helper loaded: url_helper
INFO - 2020-10-07 16:47:16 --> Database Driver Class Initialized
INFO - 2020-10-07 16:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:47:16 --> Email Class Initialized
INFO - 2020-10-07 16:47:16 --> Controller Class Initialized
DEBUG - 2020-10-07 16:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:47:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:47:16 --> Model Class Initialized
INFO - 2020-10-07 16:47:16 --> Model Class Initialized
INFO - 2020-10-07 16:47:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:47:16 --> Final output sent to browser
DEBUG - 2020-10-07 16:47:16 --> Total execution time: 0.0215
ERROR - 2020-10-07 16:47:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:47:23 --> Config Class Initialized
INFO - 2020-10-07 16:47:23 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:47:23 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:47:23 --> Utf8 Class Initialized
INFO - 2020-10-07 16:47:23 --> URI Class Initialized
INFO - 2020-10-07 16:47:23 --> Router Class Initialized
INFO - 2020-10-07 16:47:23 --> Output Class Initialized
INFO - 2020-10-07 16:47:23 --> Security Class Initialized
DEBUG - 2020-10-07 16:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:47:23 --> Input Class Initialized
INFO - 2020-10-07 16:47:23 --> Language Class Initialized
INFO - 2020-10-07 16:47:23 --> Loader Class Initialized
INFO - 2020-10-07 16:47:23 --> Helper loaded: url_helper
INFO - 2020-10-07 16:47:23 --> Database Driver Class Initialized
INFO - 2020-10-07 16:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:47:23 --> Email Class Initialized
INFO - 2020-10-07 16:47:23 --> Controller Class Initialized
DEBUG - 2020-10-07 16:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:47:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:47:23 --> Model Class Initialized
INFO - 2020-10-07 16:47:23 --> Model Class Initialized
INFO - 2020-10-07 16:47:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:47:23 --> Final output sent to browser
DEBUG - 2020-10-07 16:47:23 --> Total execution time: 0.0269
ERROR - 2020-10-07 16:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:47:29 --> Config Class Initialized
INFO - 2020-10-07 16:47:29 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:47:29 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:47:29 --> Utf8 Class Initialized
INFO - 2020-10-07 16:47:29 --> URI Class Initialized
INFO - 2020-10-07 16:47:29 --> Router Class Initialized
INFO - 2020-10-07 16:47:29 --> Output Class Initialized
INFO - 2020-10-07 16:47:29 --> Security Class Initialized
DEBUG - 2020-10-07 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:47:29 --> Input Class Initialized
INFO - 2020-10-07 16:47:29 --> Language Class Initialized
INFO - 2020-10-07 16:47:29 --> Loader Class Initialized
INFO - 2020-10-07 16:47:29 --> Helper loaded: url_helper
INFO - 2020-10-07 16:47:29 --> Database Driver Class Initialized
INFO - 2020-10-07 16:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:47:29 --> Email Class Initialized
INFO - 2020-10-07 16:47:29 --> Controller Class Initialized
INFO - 2020-10-07 16:47:29 --> Model Class Initialized
INFO - 2020-10-07 16:47:29 --> Model Class Initialized
INFO - 2020-10-07 16:47:29 --> Model Class Initialized
INFO - 2020-10-07 16:47:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 16:47:29 --> Final output sent to browser
DEBUG - 2020-10-07 16:47:29 --> Total execution time: 0.0406
ERROR - 2020-10-07 16:47:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:47:29 --> Config Class Initialized
INFO - 2020-10-07 16:47:29 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:47:29 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:47:29 --> Utf8 Class Initialized
INFO - 2020-10-07 16:47:29 --> URI Class Initialized
INFO - 2020-10-07 16:47:29 --> Router Class Initialized
INFO - 2020-10-07 16:47:29 --> Output Class Initialized
INFO - 2020-10-07 16:47:29 --> Security Class Initialized
DEBUG - 2020-10-07 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:47:29 --> Input Class Initialized
INFO - 2020-10-07 16:47:29 --> Language Class Initialized
INFO - 2020-10-07 16:47:29 --> Loader Class Initialized
INFO - 2020-10-07 16:47:29 --> Helper loaded: url_helper
INFO - 2020-10-07 16:47:29 --> Database Driver Class Initialized
INFO - 2020-10-07 16:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:47:29 --> Email Class Initialized
INFO - 2020-10-07 16:47:29 --> Controller Class Initialized
INFO - 2020-10-07 16:47:29 --> Model Class Initialized
INFO - 2020-10-07 16:47:29 --> Model Class Initialized
INFO - 2020-10-07 16:47:29 --> Final output sent to browser
DEBUG - 2020-10-07 16:47:29 --> Total execution time: 0.0375
ERROR - 2020-10-07 16:48:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:48:03 --> Config Class Initialized
INFO - 2020-10-07 16:48:03 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:48:03 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:48:03 --> Utf8 Class Initialized
INFO - 2020-10-07 16:48:03 --> URI Class Initialized
INFO - 2020-10-07 16:48:03 --> Router Class Initialized
INFO - 2020-10-07 16:48:03 --> Output Class Initialized
INFO - 2020-10-07 16:48:03 --> Security Class Initialized
DEBUG - 2020-10-07 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:48:03 --> Input Class Initialized
INFO - 2020-10-07 16:48:03 --> Language Class Initialized
INFO - 2020-10-07 16:48:03 --> Loader Class Initialized
INFO - 2020-10-07 16:48:03 --> Helper loaded: url_helper
INFO - 2020-10-07 16:48:03 --> Database Driver Class Initialized
INFO - 2020-10-07 16:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:48:03 --> Email Class Initialized
INFO - 2020-10-07 16:48:03 --> Controller Class Initialized
INFO - 2020-10-07 16:48:03 --> Model Class Initialized
INFO - 2020-10-07 16:48:03 --> Model Class Initialized
INFO - 2020-10-07 16:48:03 --> Model Class Initialized
INFO - 2020-10-07 16:48:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 16:48:03 --> Final output sent to browser
DEBUG - 2020-10-07 16:48:03 --> Total execution time: 0.0465
ERROR - 2020-10-07 16:48:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:48:04 --> Config Class Initialized
INFO - 2020-10-07 16:48:04 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:48:04 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:48:04 --> Utf8 Class Initialized
INFO - 2020-10-07 16:48:04 --> URI Class Initialized
INFO - 2020-10-07 16:48:04 --> Router Class Initialized
INFO - 2020-10-07 16:48:04 --> Output Class Initialized
INFO - 2020-10-07 16:48:04 --> Security Class Initialized
DEBUG - 2020-10-07 16:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:48:04 --> Input Class Initialized
INFO - 2020-10-07 16:48:04 --> Language Class Initialized
INFO - 2020-10-07 16:48:04 --> Loader Class Initialized
INFO - 2020-10-07 16:48:04 --> Helper loaded: url_helper
INFO - 2020-10-07 16:48:04 --> Database Driver Class Initialized
INFO - 2020-10-07 16:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:48:04 --> Email Class Initialized
INFO - 2020-10-07 16:48:04 --> Controller Class Initialized
INFO - 2020-10-07 16:48:04 --> Model Class Initialized
INFO - 2020-10-07 16:48:04 --> Model Class Initialized
INFO - 2020-10-07 16:48:04 --> Final output sent to browser
DEBUG - 2020-10-07 16:48:04 --> Total execution time: 0.0436
ERROR - 2020-10-07 16:48:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:48:08 --> Config Class Initialized
INFO - 2020-10-07 16:48:08 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:48:08 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:48:08 --> Utf8 Class Initialized
INFO - 2020-10-07 16:48:08 --> URI Class Initialized
INFO - 2020-10-07 16:48:08 --> Router Class Initialized
INFO - 2020-10-07 16:48:08 --> Output Class Initialized
INFO - 2020-10-07 16:48:08 --> Security Class Initialized
DEBUG - 2020-10-07 16:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:48:08 --> Input Class Initialized
INFO - 2020-10-07 16:48:08 --> Language Class Initialized
INFO - 2020-10-07 16:48:08 --> Loader Class Initialized
INFO - 2020-10-07 16:48:08 --> Helper loaded: url_helper
INFO - 2020-10-07 16:48:08 --> Database Driver Class Initialized
INFO - 2020-10-07 16:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:48:08 --> Email Class Initialized
INFO - 2020-10-07 16:48:08 --> Controller Class Initialized
INFO - 2020-10-07 16:48:08 --> Model Class Initialized
INFO - 2020-10-07 16:48:08 --> Model Class Initialized
INFO - 2020-10-07 16:48:08 --> Model Class Initialized
INFO - 2020-10-07 16:48:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-10-07 16:48:08 --> Final output sent to browser
DEBUG - 2020-10-07 16:48:08 --> Total execution time: 0.0431
ERROR - 2020-10-07 16:49:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:49:01 --> Config Class Initialized
INFO - 2020-10-07 16:49:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:49:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:49:01 --> Utf8 Class Initialized
INFO - 2020-10-07 16:49:01 --> URI Class Initialized
INFO - 2020-10-07 16:49:01 --> Router Class Initialized
INFO - 2020-10-07 16:49:01 --> Output Class Initialized
INFO - 2020-10-07 16:49:01 --> Security Class Initialized
DEBUG - 2020-10-07 16:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:49:01 --> Input Class Initialized
INFO - 2020-10-07 16:49:01 --> Language Class Initialized
INFO - 2020-10-07 16:49:01 --> Loader Class Initialized
INFO - 2020-10-07 16:49:01 --> Helper loaded: url_helper
INFO - 2020-10-07 16:49:01 --> Database Driver Class Initialized
INFO - 2020-10-07 16:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:49:01 --> Email Class Initialized
INFO - 2020-10-07 16:49:01 --> Controller Class Initialized
INFO - 2020-10-07 16:49:01 --> Model Class Initialized
INFO - 2020-10-07 16:49:01 --> Model Class Initialized
INFO - 2020-10-07 16:49:01 --> Model Class Initialized
INFO - 2020-10-07 16:49:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-10-07 16:49:01 --> Final output sent to browser
DEBUG - 2020-10-07 16:49:01 --> Total execution time: 0.0488
ERROR - 2020-10-07 16:49:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:49:04 --> Config Class Initialized
INFO - 2020-10-07 16:49:04 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:49:04 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:49:04 --> Utf8 Class Initialized
INFO - 2020-10-07 16:49:04 --> URI Class Initialized
INFO - 2020-10-07 16:49:04 --> Router Class Initialized
INFO - 2020-10-07 16:49:04 --> Output Class Initialized
INFO - 2020-10-07 16:49:04 --> Security Class Initialized
DEBUG - 2020-10-07 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:49:04 --> Input Class Initialized
INFO - 2020-10-07 16:49:04 --> Language Class Initialized
INFO - 2020-10-07 16:49:04 --> Loader Class Initialized
INFO - 2020-10-07 16:49:04 --> Helper loaded: url_helper
INFO - 2020-10-07 16:49:04 --> Database Driver Class Initialized
INFO - 2020-10-07 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:49:04 --> Email Class Initialized
INFO - 2020-10-07 16:49:04 --> Controller Class Initialized
DEBUG - 2020-10-07 16:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:49:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:49:04 --> Model Class Initialized
INFO - 2020-10-07 16:49:04 --> Model Class Initialized
INFO - 2020-10-07 16:49:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:49:04 --> Final output sent to browser
DEBUG - 2020-10-07 16:49:04 --> Total execution time: 0.0203
ERROR - 2020-10-07 16:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:14 --> Config Class Initialized
INFO - 2020-10-07 16:50:14 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:14 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:14 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:14 --> URI Class Initialized
INFO - 2020-10-07 16:50:14 --> Router Class Initialized
INFO - 2020-10-07 16:50:14 --> Output Class Initialized
INFO - 2020-10-07 16:50:14 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:14 --> Input Class Initialized
INFO - 2020-10-07 16:50:14 --> Language Class Initialized
INFO - 2020-10-07 16:50:14 --> Loader Class Initialized
INFO - 2020-10-07 16:50:14 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:14 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:14 --> Email Class Initialized
INFO - 2020-10-07 16:50:14 --> Controller Class Initialized
DEBUG - 2020-10-07 16:50:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:50:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:50:14 --> Model Class Initialized
INFO - 2020-10-07 16:50:14 --> Model Class Initialized
INFO - 2020-10-07 16:50:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:50:14 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:14 --> Total execution time: 0.0226
ERROR - 2020-10-07 16:50:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:18 --> Config Class Initialized
INFO - 2020-10-07 16:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:18 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:18 --> URI Class Initialized
INFO - 2020-10-07 16:50:18 --> Router Class Initialized
INFO - 2020-10-07 16:50:18 --> Output Class Initialized
INFO - 2020-10-07 16:50:18 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:18 --> Input Class Initialized
INFO - 2020-10-07 16:50:18 --> Language Class Initialized
INFO - 2020-10-07 16:50:18 --> Loader Class Initialized
INFO - 2020-10-07 16:50:18 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:18 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:18 --> Email Class Initialized
INFO - 2020-10-07 16:50:18 --> Controller Class Initialized
DEBUG - 2020-10-07 16:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:50:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:50:18 --> Model Class Initialized
INFO - 2020-10-07 16:50:18 --> Model Class Initialized
INFO - 2020-10-07 16:50:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:50:18 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:18 --> Total execution time: 0.1977
ERROR - 2020-10-07 16:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:22 --> Config Class Initialized
INFO - 2020-10-07 16:50:22 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:22 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:22 --> URI Class Initialized
INFO - 2020-10-07 16:50:22 --> Router Class Initialized
INFO - 2020-10-07 16:50:22 --> Output Class Initialized
INFO - 2020-10-07 16:50:22 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:22 --> Input Class Initialized
INFO - 2020-10-07 16:50:22 --> Language Class Initialized
INFO - 2020-10-07 16:50:22 --> Loader Class Initialized
INFO - 2020-10-07 16:50:22 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:22 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:22 --> Email Class Initialized
INFO - 2020-10-07 16:50:22 --> Controller Class Initialized
DEBUG - 2020-10-07 16:50:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:50:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:50:22 --> Model Class Initialized
INFO - 2020-10-07 16:50:22 --> Model Class Initialized
INFO - 2020-10-07 16:50:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:50:22 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:22 --> Total execution time: 0.0270
ERROR - 2020-10-07 16:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:26 --> Config Class Initialized
INFO - 2020-10-07 16:50:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:26 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:26 --> URI Class Initialized
INFO - 2020-10-07 16:50:26 --> Router Class Initialized
INFO - 2020-10-07 16:50:26 --> Output Class Initialized
INFO - 2020-10-07 16:50:26 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:26 --> Input Class Initialized
INFO - 2020-10-07 16:50:26 --> Language Class Initialized
INFO - 2020-10-07 16:50:26 --> Loader Class Initialized
INFO - 2020-10-07 16:50:26 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:26 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:26 --> Email Class Initialized
INFO - 2020-10-07 16:50:26 --> Controller Class Initialized
INFO - 2020-10-07 16:50:26 --> Model Class Initialized
INFO - 2020-10-07 16:50:26 --> Model Class Initialized
INFO - 2020-10-07 16:50:26 --> Model Class Initialized
INFO - 2020-10-07 16:50:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 16:50:26 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:26 --> Total execution time: 0.0394
ERROR - 2020-10-07 16:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:26 --> Config Class Initialized
INFO - 2020-10-07 16:50:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:26 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:26 --> URI Class Initialized
INFO - 2020-10-07 16:50:26 --> Router Class Initialized
INFO - 2020-10-07 16:50:26 --> Output Class Initialized
INFO - 2020-10-07 16:50:26 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:26 --> Input Class Initialized
INFO - 2020-10-07 16:50:26 --> Language Class Initialized
INFO - 2020-10-07 16:50:26 --> Loader Class Initialized
INFO - 2020-10-07 16:50:26 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:26 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:26 --> Email Class Initialized
INFO - 2020-10-07 16:50:26 --> Controller Class Initialized
INFO - 2020-10-07 16:50:26 --> Model Class Initialized
INFO - 2020-10-07 16:50:26 --> Model Class Initialized
INFO - 2020-10-07 16:50:26 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:26 --> Total execution time: 0.0386
ERROR - 2020-10-07 16:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:49 --> Config Class Initialized
INFO - 2020-10-07 16:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:49 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:49 --> URI Class Initialized
INFO - 2020-10-07 16:50:49 --> Router Class Initialized
INFO - 2020-10-07 16:50:49 --> Output Class Initialized
INFO - 2020-10-07 16:50:49 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:49 --> Input Class Initialized
INFO - 2020-10-07 16:50:49 --> Language Class Initialized
INFO - 2020-10-07 16:50:49 --> Loader Class Initialized
INFO - 2020-10-07 16:50:49 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:49 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:49 --> Email Class Initialized
INFO - 2020-10-07 16:50:49 --> Controller Class Initialized
INFO - 2020-10-07 16:50:49 --> Model Class Initialized
INFO - 2020-10-07 16:50:49 --> Model Class Initialized
INFO - 2020-10-07 16:50:49 --> Model Class Initialized
INFO - 2020-10-07 16:50:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 16:50:49 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:49 --> Total execution time: 0.0409
ERROR - 2020-10-07 16:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:50 --> Config Class Initialized
INFO - 2020-10-07 16:50:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:50 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:50 --> URI Class Initialized
INFO - 2020-10-07 16:50:50 --> Router Class Initialized
INFO - 2020-10-07 16:50:50 --> Output Class Initialized
INFO - 2020-10-07 16:50:50 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:50 --> Input Class Initialized
INFO - 2020-10-07 16:50:50 --> Language Class Initialized
INFO - 2020-10-07 16:50:50 --> Loader Class Initialized
INFO - 2020-10-07 16:50:50 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:50 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:50 --> Email Class Initialized
INFO - 2020-10-07 16:50:50 --> Controller Class Initialized
INFO - 2020-10-07 16:50:50 --> Model Class Initialized
INFO - 2020-10-07 16:50:50 --> Model Class Initialized
INFO - 2020-10-07 16:50:50 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:50 --> Total execution time: 0.0429
ERROR - 2020-10-07 16:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:52 --> Config Class Initialized
INFO - 2020-10-07 16:50:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:52 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:52 --> URI Class Initialized
INFO - 2020-10-07 16:50:52 --> Router Class Initialized
INFO - 2020-10-07 16:50:52 --> Output Class Initialized
INFO - 2020-10-07 16:50:52 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:52 --> Input Class Initialized
INFO - 2020-10-07 16:50:52 --> Language Class Initialized
INFO - 2020-10-07 16:50:52 --> Loader Class Initialized
INFO - 2020-10-07 16:50:52 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:52 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:52 --> Email Class Initialized
INFO - 2020-10-07 16:50:52 --> Controller Class Initialized
INFO - 2020-10-07 16:50:52 --> Model Class Initialized
INFO - 2020-10-07 16:50:52 --> Model Class Initialized
INFO - 2020-10-07 16:50:52 --> Model Class Initialized
INFO - 2020-10-07 16:50:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-07 16:50:52 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:52 --> Total execution time: 0.0455
ERROR - 2020-10-07 16:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:53 --> Config Class Initialized
INFO - 2020-10-07 16:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:53 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:53 --> URI Class Initialized
INFO - 2020-10-07 16:50:53 --> Router Class Initialized
INFO - 2020-10-07 16:50:53 --> Output Class Initialized
INFO - 2020-10-07 16:50:53 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:53 --> Input Class Initialized
INFO - 2020-10-07 16:50:53 --> Language Class Initialized
INFO - 2020-10-07 16:50:53 --> Loader Class Initialized
INFO - 2020-10-07 16:50:53 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:53 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:53 --> Email Class Initialized
INFO - 2020-10-07 16:50:53 --> Controller Class Initialized
INFO - 2020-10-07 16:50:53 --> Model Class Initialized
INFO - 2020-10-07 16:50:53 --> Model Class Initialized
INFO - 2020-10-07 16:50:53 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:53 --> Total execution time: 0.0413
ERROR - 2020-10-07 16:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:54 --> Config Class Initialized
INFO - 2020-10-07 16:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:54 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:54 --> URI Class Initialized
INFO - 2020-10-07 16:50:54 --> Router Class Initialized
INFO - 2020-10-07 16:50:54 --> Output Class Initialized
INFO - 2020-10-07 16:50:54 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:54 --> Input Class Initialized
INFO - 2020-10-07 16:50:54 --> Language Class Initialized
INFO - 2020-10-07 16:50:54 --> Loader Class Initialized
INFO - 2020-10-07 16:50:54 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:54 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:54 --> Email Class Initialized
INFO - 2020-10-07 16:50:54 --> Controller Class Initialized
DEBUG - 2020-10-07 16:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:50:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:50:54 --> Model Class Initialized
INFO - 2020-10-07 16:50:54 --> Model Class Initialized
INFO - 2020-10-07 16:50:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:50:54 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:54 --> Total execution time: 0.0261
ERROR - 2020-10-07 16:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:50:58 --> Config Class Initialized
INFO - 2020-10-07 16:50:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:50:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:50:58 --> Utf8 Class Initialized
INFO - 2020-10-07 16:50:58 --> URI Class Initialized
INFO - 2020-10-07 16:50:58 --> Router Class Initialized
INFO - 2020-10-07 16:50:58 --> Output Class Initialized
INFO - 2020-10-07 16:50:58 --> Security Class Initialized
DEBUG - 2020-10-07 16:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:50:58 --> Input Class Initialized
INFO - 2020-10-07 16:50:58 --> Language Class Initialized
INFO - 2020-10-07 16:50:58 --> Loader Class Initialized
INFO - 2020-10-07 16:50:58 --> Helper loaded: url_helper
INFO - 2020-10-07 16:50:58 --> Database Driver Class Initialized
INFO - 2020-10-07 16:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:50:58 --> Email Class Initialized
INFO - 2020-10-07 16:50:58 --> Controller Class Initialized
DEBUG - 2020-10-07 16:50:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:50:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:50:58 --> Model Class Initialized
INFO - 2020-10-07 16:50:58 --> Model Class Initialized
INFO - 2020-10-07 16:50:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:50:58 --> Final output sent to browser
DEBUG - 2020-10-07 16:50:58 --> Total execution time: 0.0238
ERROR - 2020-10-07 16:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:51:02 --> Config Class Initialized
INFO - 2020-10-07 16:51:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:51:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:51:02 --> Utf8 Class Initialized
INFO - 2020-10-07 16:51:02 --> URI Class Initialized
INFO - 2020-10-07 16:51:02 --> Router Class Initialized
INFO - 2020-10-07 16:51:02 --> Output Class Initialized
INFO - 2020-10-07 16:51:02 --> Security Class Initialized
DEBUG - 2020-10-07 16:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:51:02 --> Input Class Initialized
INFO - 2020-10-07 16:51:02 --> Language Class Initialized
INFO - 2020-10-07 16:51:02 --> Loader Class Initialized
INFO - 2020-10-07 16:51:02 --> Helper loaded: url_helper
INFO - 2020-10-07 16:51:02 --> Database Driver Class Initialized
INFO - 2020-10-07 16:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:51:02 --> Email Class Initialized
INFO - 2020-10-07 16:51:02 --> Controller Class Initialized
DEBUG - 2020-10-07 16:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:51:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:51:02 --> Model Class Initialized
INFO - 2020-10-07 16:51:02 --> Model Class Initialized
INFO - 2020-10-07 16:51:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 16:51:02 --> Final output sent to browser
DEBUG - 2020-10-07 16:51:02 --> Total execution time: 0.0252
ERROR - 2020-10-07 16:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:51:06 --> Config Class Initialized
INFO - 2020-10-07 16:51:06 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:51:06 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:51:06 --> Utf8 Class Initialized
INFO - 2020-10-07 16:51:06 --> URI Class Initialized
INFO - 2020-10-07 16:51:06 --> Router Class Initialized
INFO - 2020-10-07 16:51:06 --> Output Class Initialized
INFO - 2020-10-07 16:51:06 --> Security Class Initialized
DEBUG - 2020-10-07 16:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:51:06 --> Input Class Initialized
INFO - 2020-10-07 16:51:06 --> Language Class Initialized
INFO - 2020-10-07 16:51:06 --> Loader Class Initialized
INFO - 2020-10-07 16:51:06 --> Helper loaded: url_helper
INFO - 2020-10-07 16:51:06 --> Database Driver Class Initialized
INFO - 2020-10-07 16:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:51:06 --> Email Class Initialized
INFO - 2020-10-07 16:51:06 --> Controller Class Initialized
DEBUG - 2020-10-07 16:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:51:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:51:06 --> Model Class Initialized
INFO - 2020-10-07 16:51:06 --> Model Class Initialized
INFO - 2020-10-07 16:51:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 16:51:06 --> Final output sent to browser
DEBUG - 2020-10-07 16:51:06 --> Total execution time: 0.0223
ERROR - 2020-10-07 16:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:51:11 --> Config Class Initialized
INFO - 2020-10-07 16:51:11 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:51:11 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:51:11 --> Utf8 Class Initialized
INFO - 2020-10-07 16:51:11 --> URI Class Initialized
INFO - 2020-10-07 16:51:11 --> Router Class Initialized
INFO - 2020-10-07 16:51:11 --> Output Class Initialized
INFO - 2020-10-07 16:51:11 --> Security Class Initialized
DEBUG - 2020-10-07 16:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:51:11 --> Input Class Initialized
INFO - 2020-10-07 16:51:11 --> Language Class Initialized
INFO - 2020-10-07 16:51:11 --> Loader Class Initialized
INFO - 2020-10-07 16:51:11 --> Helper loaded: url_helper
INFO - 2020-10-07 16:51:11 --> Database Driver Class Initialized
INFO - 2020-10-07 16:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:51:11 --> Email Class Initialized
INFO - 2020-10-07 16:51:11 --> Controller Class Initialized
DEBUG - 2020-10-07 16:51:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:51:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:51:11 --> Model Class Initialized
INFO - 2020-10-07 16:51:11 --> Model Class Initialized
INFO - 2020-10-07 16:51:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 16:51:11 --> Final output sent to browser
DEBUG - 2020-10-07 16:51:11 --> Total execution time: 0.0235
ERROR - 2020-10-07 16:51:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:51:58 --> Config Class Initialized
INFO - 2020-10-07 16:51:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:51:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:51:58 --> Utf8 Class Initialized
INFO - 2020-10-07 16:51:58 --> URI Class Initialized
INFO - 2020-10-07 16:51:58 --> Router Class Initialized
INFO - 2020-10-07 16:51:58 --> Output Class Initialized
INFO - 2020-10-07 16:51:58 --> Security Class Initialized
DEBUG - 2020-10-07 16:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:51:58 --> Input Class Initialized
INFO - 2020-10-07 16:51:58 --> Language Class Initialized
INFO - 2020-10-07 16:51:58 --> Loader Class Initialized
INFO - 2020-10-07 16:51:58 --> Helper loaded: url_helper
INFO - 2020-10-07 16:51:58 --> Database Driver Class Initialized
INFO - 2020-10-07 16:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:51:58 --> Email Class Initialized
INFO - 2020-10-07 16:51:58 --> Controller Class Initialized
DEBUG - 2020-10-07 16:51:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:51:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:51:58 --> Model Class Initialized
INFO - 2020-10-07 16:51:58 --> Model Class Initialized
INFO - 2020-10-07 16:51:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:51:58 --> Final output sent to browser
DEBUG - 2020-10-07 16:51:58 --> Total execution time: 0.0243
ERROR - 2020-10-07 16:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:53:06 --> Config Class Initialized
INFO - 2020-10-07 16:53:06 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:53:06 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:53:06 --> Utf8 Class Initialized
INFO - 2020-10-07 16:53:06 --> URI Class Initialized
INFO - 2020-10-07 16:53:06 --> Router Class Initialized
INFO - 2020-10-07 16:53:06 --> Output Class Initialized
INFO - 2020-10-07 16:53:06 --> Security Class Initialized
DEBUG - 2020-10-07 16:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:53:06 --> Input Class Initialized
INFO - 2020-10-07 16:53:06 --> Language Class Initialized
INFO - 2020-10-07 16:53:06 --> Loader Class Initialized
INFO - 2020-10-07 16:53:06 --> Helper loaded: url_helper
INFO - 2020-10-07 16:53:06 --> Database Driver Class Initialized
INFO - 2020-10-07 16:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:53:06 --> Email Class Initialized
INFO - 2020-10-07 16:53:06 --> Controller Class Initialized
DEBUG - 2020-10-07 16:53:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:53:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:53:06 --> Model Class Initialized
INFO - 2020-10-07 16:53:06 --> Model Class Initialized
INFO - 2020-10-07 16:53:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 16:53:06 --> Final output sent to browser
DEBUG - 2020-10-07 16:53:06 --> Total execution time: 0.0264
ERROR - 2020-10-07 16:54:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:54:00 --> Config Class Initialized
INFO - 2020-10-07 16:54:00 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:54:00 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:54:00 --> Utf8 Class Initialized
INFO - 2020-10-07 16:54:00 --> URI Class Initialized
INFO - 2020-10-07 16:54:00 --> Router Class Initialized
INFO - 2020-10-07 16:54:00 --> Output Class Initialized
INFO - 2020-10-07 16:54:00 --> Security Class Initialized
DEBUG - 2020-10-07 16:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:54:00 --> Input Class Initialized
INFO - 2020-10-07 16:54:00 --> Language Class Initialized
INFO - 2020-10-07 16:54:00 --> Loader Class Initialized
INFO - 2020-10-07 16:54:00 --> Helper loaded: url_helper
INFO - 2020-10-07 16:54:00 --> Database Driver Class Initialized
INFO - 2020-10-07 16:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:54:00 --> Email Class Initialized
INFO - 2020-10-07 16:54:00 --> Controller Class Initialized
DEBUG - 2020-10-07 16:54:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 16:54:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:54:00 --> Model Class Initialized
INFO - 2020-10-07 16:54:00 --> Model Class Initialized
INFO - 2020-10-07 16:54:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 16:54:00 --> Final output sent to browser
DEBUG - 2020-10-07 16:54:00 --> Total execution time: 0.0185
ERROR - 2020-10-07 16:55:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 16:55:13 --> Config Class Initialized
INFO - 2020-10-07 16:55:13 --> Hooks Class Initialized
DEBUG - 2020-10-07 16:55:13 --> UTF-8 Support Enabled
INFO - 2020-10-07 16:55:13 --> Utf8 Class Initialized
INFO - 2020-10-07 16:55:13 --> URI Class Initialized
DEBUG - 2020-10-07 16:55:13 --> No URI present. Default controller set.
INFO - 2020-10-07 16:55:13 --> Router Class Initialized
INFO - 2020-10-07 16:55:13 --> Output Class Initialized
INFO - 2020-10-07 16:55:13 --> Security Class Initialized
DEBUG - 2020-10-07 16:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 16:55:13 --> Input Class Initialized
INFO - 2020-10-07 16:55:13 --> Language Class Initialized
INFO - 2020-10-07 16:55:13 --> Loader Class Initialized
INFO - 2020-10-07 16:55:13 --> Helper loaded: url_helper
INFO - 2020-10-07 16:55:13 --> Database Driver Class Initialized
INFO - 2020-10-07 16:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 16:55:13 --> Email Class Initialized
INFO - 2020-10-07 16:55:13 --> Controller Class Initialized
INFO - 2020-10-07 16:55:13 --> Model Class Initialized
INFO - 2020-10-07 16:55:13 --> Model Class Initialized
DEBUG - 2020-10-07 16:55:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 16:55:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 16:55:13 --> Final output sent to browser
DEBUG - 2020-10-07 16:55:13 --> Total execution time: 0.0594
ERROR - 2020-10-07 17:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:09:44 --> Config Class Initialized
INFO - 2020-10-07 17:09:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:09:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:09:44 --> Utf8 Class Initialized
INFO - 2020-10-07 17:09:44 --> URI Class Initialized
INFO - 2020-10-07 17:09:44 --> Router Class Initialized
ERROR - 2020-10-07 17:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:09:44 --> Output Class Initialized
INFO - 2020-10-07 17:09:44 --> Config Class Initialized
INFO - 2020-10-07 17:09:44 --> Hooks Class Initialized
INFO - 2020-10-07 17:09:44 --> Security Class Initialized
DEBUG - 2020-10-07 17:09:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:09:44 --> Utf8 Class Initialized
DEBUG - 2020-10-07 17:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:09:44 --> Input Class Initialized
INFO - 2020-10-07 17:09:44 --> Language Class Initialized
INFO - 2020-10-07 17:09:44 --> URI Class Initialized
INFO - 2020-10-07 17:09:44 --> Router Class Initialized
INFO - 2020-10-07 17:09:44 --> Loader Class Initialized
INFO - 2020-10-07 17:09:44 --> Output Class Initialized
INFO - 2020-10-07 17:09:44 --> Helper loaded: url_helper
INFO - 2020-10-07 17:09:44 --> Security Class Initialized
DEBUG - 2020-10-07 17:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:09:44 --> Input Class Initialized
INFO - 2020-10-07 17:09:44 --> Language Class Initialized
INFO - 2020-10-07 17:09:44 --> Loader Class Initialized
INFO - 2020-10-07 17:09:44 --> Helper loaded: url_helper
INFO - 2020-10-07 17:09:44 --> Database Driver Class Initialized
INFO - 2020-10-07 17:09:44 --> Database Driver Class Initialized
INFO - 2020-10-07 17:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:09:44 --> Email Class Initialized
INFO - 2020-10-07 17:09:44 --> Controller Class Initialized
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
DEBUG - 2020-10-07 17:09:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:09:44 --> Email Class Initialized
INFO - 2020-10-07 17:09:44 --> Controller Class Initialized
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
DEBUG - 2020-10-07 17:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:09:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
INFO - 2020-10-07 17:09:44 --> Final output sent to browser
DEBUG - 2020-10-07 17:09:44 --> Total execution time: 0.0238
ERROR - 2020-10-07 17:09:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:09:44 --> Config Class Initialized
INFO - 2020-10-07 17:09:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:09:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:09:44 --> Utf8 Class Initialized
INFO - 2020-10-07 17:09:44 --> URI Class Initialized
INFO - 2020-10-07 17:09:44 --> Router Class Initialized
INFO - 2020-10-07 17:09:44 --> Output Class Initialized
INFO - 2020-10-07 17:09:44 --> Security Class Initialized
DEBUG - 2020-10-07 17:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:09:44 --> Input Class Initialized
INFO - 2020-10-07 17:09:44 --> Language Class Initialized
INFO - 2020-10-07 17:09:44 --> Loader Class Initialized
INFO - 2020-10-07 17:09:44 --> Helper loaded: url_helper
INFO - 2020-10-07 17:09:44 --> Database Driver Class Initialized
INFO - 2020-10-07 17:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:09:44 --> Email Class Initialized
INFO - 2020-10-07 17:09:44 --> Controller Class Initialized
DEBUG - 2020-10-07 17:09:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:09:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
INFO - 2020-10-07 17:09:44 --> Model Class Initialized
INFO - 2020-10-07 17:09:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:09:44 --> Final output sent to browser
DEBUG - 2020-10-07 17:09:44 --> Total execution time: 0.0252
ERROR - 2020-10-07 17:09:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:09:47 --> Config Class Initialized
INFO - 2020-10-07 17:09:47 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:09:47 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:09:47 --> Utf8 Class Initialized
INFO - 2020-10-07 17:09:47 --> URI Class Initialized
INFO - 2020-10-07 17:09:47 --> Router Class Initialized
INFO - 2020-10-07 17:09:47 --> Output Class Initialized
INFO - 2020-10-07 17:09:47 --> Security Class Initialized
DEBUG - 2020-10-07 17:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:09:47 --> Input Class Initialized
INFO - 2020-10-07 17:09:47 --> Language Class Initialized
INFO - 2020-10-07 17:09:47 --> Loader Class Initialized
INFO - 2020-10-07 17:09:47 --> Helper loaded: url_helper
INFO - 2020-10-07 17:09:47 --> Database Driver Class Initialized
INFO - 2020-10-07 17:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:09:47 --> Email Class Initialized
INFO - 2020-10-07 17:09:47 --> Controller Class Initialized
DEBUG - 2020-10-07 17:09:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:09:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:09:47 --> Model Class Initialized
INFO - 2020-10-07 17:09:47 --> Model Class Initialized
INFO - 2020-10-07 17:09:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:09:47 --> Final output sent to browser
DEBUG - 2020-10-07 17:09:47 --> Total execution time: 0.0252
ERROR - 2020-10-07 17:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:10:16 --> Config Class Initialized
INFO - 2020-10-07 17:10:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:10:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:10:16 --> Utf8 Class Initialized
INFO - 2020-10-07 17:10:16 --> URI Class Initialized
INFO - 2020-10-07 17:10:16 --> Router Class Initialized
INFO - 2020-10-07 17:10:16 --> Output Class Initialized
INFO - 2020-10-07 17:10:16 --> Security Class Initialized
DEBUG - 2020-10-07 17:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:10:16 --> Input Class Initialized
INFO - 2020-10-07 17:10:16 --> Language Class Initialized
INFO - 2020-10-07 17:10:16 --> Loader Class Initialized
INFO - 2020-10-07 17:10:16 --> Helper loaded: url_helper
INFO - 2020-10-07 17:10:16 --> Database Driver Class Initialized
INFO - 2020-10-07 17:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:10:16 --> Email Class Initialized
INFO - 2020-10-07 17:10:16 --> Controller Class Initialized
DEBUG - 2020-10-07 17:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:10:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:10:16 --> Model Class Initialized
INFO - 2020-10-07 17:10:16 --> Model Class Initialized
INFO - 2020-10-07 17:10:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:10:16 --> Final output sent to browser
DEBUG - 2020-10-07 17:10:16 --> Total execution time: 0.0270
ERROR - 2020-10-07 17:10:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:10:44 --> Config Class Initialized
INFO - 2020-10-07 17:10:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:10:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:10:44 --> Utf8 Class Initialized
INFO - 2020-10-07 17:10:44 --> URI Class Initialized
INFO - 2020-10-07 17:10:44 --> Router Class Initialized
INFO - 2020-10-07 17:10:44 --> Output Class Initialized
INFO - 2020-10-07 17:10:44 --> Security Class Initialized
DEBUG - 2020-10-07 17:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:10:44 --> Input Class Initialized
INFO - 2020-10-07 17:10:44 --> Language Class Initialized
INFO - 2020-10-07 17:10:44 --> Loader Class Initialized
INFO - 2020-10-07 17:10:44 --> Helper loaded: url_helper
INFO - 2020-10-07 17:10:44 --> Database Driver Class Initialized
INFO - 2020-10-07 17:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:10:44 --> Email Class Initialized
INFO - 2020-10-07 17:10:44 --> Controller Class Initialized
DEBUG - 2020-10-07 17:10:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:10:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:10:44 --> Model Class Initialized
INFO - 2020-10-07 17:10:44 --> Model Class Initialized
INFO - 2020-10-07 17:10:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:10:44 --> Final output sent to browser
DEBUG - 2020-10-07 17:10:44 --> Total execution time: 0.0287
ERROR - 2020-10-07 17:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:12:32 --> Config Class Initialized
INFO - 2020-10-07 17:12:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:12:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:12:32 --> Utf8 Class Initialized
INFO - 2020-10-07 17:12:32 --> URI Class Initialized
INFO - 2020-10-07 17:12:32 --> Router Class Initialized
INFO - 2020-10-07 17:12:32 --> Output Class Initialized
INFO - 2020-10-07 17:12:32 --> Security Class Initialized
DEBUG - 2020-10-07 17:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:12:32 --> Input Class Initialized
INFO - 2020-10-07 17:12:32 --> Language Class Initialized
INFO - 2020-10-07 17:12:32 --> Loader Class Initialized
INFO - 2020-10-07 17:12:32 --> Helper loaded: url_helper
INFO - 2020-10-07 17:12:32 --> Database Driver Class Initialized
INFO - 2020-10-07 17:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:12:32 --> Email Class Initialized
INFO - 2020-10-07 17:12:32 --> Controller Class Initialized
DEBUG - 2020-10-07 17:12:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:12:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:12:32 --> Model Class Initialized
INFO - 2020-10-07 17:12:32 --> Model Class Initialized
INFO - 2020-10-07 17:12:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:12:32 --> Final output sent to browser
DEBUG - 2020-10-07 17:12:32 --> Total execution time: 0.0232
ERROR - 2020-10-07 17:13:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:13:27 --> Config Class Initialized
INFO - 2020-10-07 17:13:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:13:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:13:27 --> Utf8 Class Initialized
INFO - 2020-10-07 17:13:27 --> URI Class Initialized
INFO - 2020-10-07 17:13:27 --> Router Class Initialized
INFO - 2020-10-07 17:13:27 --> Output Class Initialized
INFO - 2020-10-07 17:13:27 --> Security Class Initialized
DEBUG - 2020-10-07 17:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:13:27 --> Input Class Initialized
INFO - 2020-10-07 17:13:27 --> Language Class Initialized
INFO - 2020-10-07 17:13:27 --> Loader Class Initialized
INFO - 2020-10-07 17:13:27 --> Helper loaded: url_helper
INFO - 2020-10-07 17:13:27 --> Database Driver Class Initialized
INFO - 2020-10-07 17:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:13:27 --> Email Class Initialized
INFO - 2020-10-07 17:13:27 --> Controller Class Initialized
DEBUG - 2020-10-07 17:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:13:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:13:27 --> Model Class Initialized
INFO - 2020-10-07 17:13:27 --> Model Class Initialized
INFO - 2020-10-07 17:13:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:13:27 --> Final output sent to browser
DEBUG - 2020-10-07 17:13:27 --> Total execution time: 0.0205
ERROR - 2020-10-07 17:14:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:14:50 --> Config Class Initialized
INFO - 2020-10-07 17:14:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:14:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:14:50 --> Utf8 Class Initialized
INFO - 2020-10-07 17:14:50 --> URI Class Initialized
INFO - 2020-10-07 17:14:50 --> Router Class Initialized
INFO - 2020-10-07 17:14:50 --> Output Class Initialized
INFO - 2020-10-07 17:14:50 --> Security Class Initialized
DEBUG - 2020-10-07 17:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:14:50 --> Input Class Initialized
INFO - 2020-10-07 17:14:50 --> Language Class Initialized
INFO - 2020-10-07 17:14:50 --> Loader Class Initialized
INFO - 2020-10-07 17:14:50 --> Helper loaded: url_helper
INFO - 2020-10-07 17:14:50 --> Database Driver Class Initialized
INFO - 2020-10-07 17:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:14:50 --> Email Class Initialized
INFO - 2020-10-07 17:14:50 --> Controller Class Initialized
DEBUG - 2020-10-07 17:14:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:14:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:14:50 --> Model Class Initialized
INFO - 2020-10-07 17:14:50 --> Model Class Initialized
INFO - 2020-10-07 17:14:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:14:50 --> Final output sent to browser
DEBUG - 2020-10-07 17:14:50 --> Total execution time: 0.0220
ERROR - 2020-10-07 17:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:15:53 --> Config Class Initialized
INFO - 2020-10-07 17:15:53 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:15:53 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:15:53 --> Utf8 Class Initialized
INFO - 2020-10-07 17:15:53 --> URI Class Initialized
INFO - 2020-10-07 17:15:53 --> Router Class Initialized
INFO - 2020-10-07 17:15:53 --> Output Class Initialized
INFO - 2020-10-07 17:15:53 --> Security Class Initialized
DEBUG - 2020-10-07 17:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:15:53 --> Input Class Initialized
INFO - 2020-10-07 17:15:53 --> Language Class Initialized
INFO - 2020-10-07 17:15:53 --> Loader Class Initialized
INFO - 2020-10-07 17:15:53 --> Helper loaded: url_helper
INFO - 2020-10-07 17:15:53 --> Database Driver Class Initialized
INFO - 2020-10-07 17:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:15:53 --> Email Class Initialized
INFO - 2020-10-07 17:15:53 --> Controller Class Initialized
DEBUG - 2020-10-07 17:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:15:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:15:53 --> Model Class Initialized
INFO - 2020-10-07 17:15:53 --> Model Class Initialized
INFO - 2020-10-07 17:15:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:15:53 --> Final output sent to browser
DEBUG - 2020-10-07 17:15:53 --> Total execution time: 0.0253
ERROR - 2020-10-07 17:15:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:15:57 --> Config Class Initialized
INFO - 2020-10-07 17:15:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:15:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:15:57 --> Utf8 Class Initialized
INFO - 2020-10-07 17:15:57 --> URI Class Initialized
DEBUG - 2020-10-07 17:15:57 --> No URI present. Default controller set.
INFO - 2020-10-07 17:15:57 --> Router Class Initialized
INFO - 2020-10-07 17:15:57 --> Output Class Initialized
INFO - 2020-10-07 17:15:57 --> Security Class Initialized
DEBUG - 2020-10-07 17:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:15:57 --> Input Class Initialized
INFO - 2020-10-07 17:15:57 --> Language Class Initialized
INFO - 2020-10-07 17:15:57 --> Loader Class Initialized
INFO - 2020-10-07 17:15:57 --> Helper loaded: url_helper
INFO - 2020-10-07 17:15:57 --> Database Driver Class Initialized
INFO - 2020-10-07 17:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:15:57 --> Email Class Initialized
INFO - 2020-10-07 17:15:57 --> Controller Class Initialized
INFO - 2020-10-07 17:15:57 --> Model Class Initialized
INFO - 2020-10-07 17:15:57 --> Model Class Initialized
DEBUG - 2020-10-07 17:15:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:15:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 17:15:57 --> Final output sent to browser
DEBUG - 2020-10-07 17:15:57 --> Total execution time: 0.0189
ERROR - 2020-10-07 17:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:16:17 --> Config Class Initialized
INFO - 2020-10-07 17:16:17 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:16:17 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:16:17 --> Utf8 Class Initialized
INFO - 2020-10-07 17:16:17 --> URI Class Initialized
INFO - 2020-10-07 17:16:17 --> Router Class Initialized
INFO - 2020-10-07 17:16:17 --> Output Class Initialized
INFO - 2020-10-07 17:16:17 --> Security Class Initialized
DEBUG - 2020-10-07 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:16:17 --> Input Class Initialized
INFO - 2020-10-07 17:16:17 --> Language Class Initialized
INFO - 2020-10-07 17:16:17 --> Loader Class Initialized
INFO - 2020-10-07 17:16:17 --> Helper loaded: url_helper
INFO - 2020-10-07 17:16:17 --> Database Driver Class Initialized
INFO - 2020-10-07 17:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:16:17 --> Email Class Initialized
INFO - 2020-10-07 17:16:17 --> Controller Class Initialized
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
DEBUG - 2020-10-07 17:16:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:16:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
INFO - 2020-10-07 17:16:17 --> Final output sent to browser
DEBUG - 2020-10-07 17:16:17 --> Total execution time: 0.0233
ERROR - 2020-10-07 17:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:16:17 --> Config Class Initialized
INFO - 2020-10-07 17:16:17 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:16:17 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:16:17 --> Utf8 Class Initialized
INFO - 2020-10-07 17:16:17 --> URI Class Initialized
INFO - 2020-10-07 17:16:17 --> Router Class Initialized
INFO - 2020-10-07 17:16:17 --> Output Class Initialized
INFO - 2020-10-07 17:16:17 --> Security Class Initialized
DEBUG - 2020-10-07 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:16:17 --> Input Class Initialized
INFO - 2020-10-07 17:16:17 --> Language Class Initialized
INFO - 2020-10-07 17:16:17 --> Loader Class Initialized
INFO - 2020-10-07 17:16:17 --> Helper loaded: url_helper
INFO - 2020-10-07 17:16:17 --> Database Driver Class Initialized
INFO - 2020-10-07 17:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:16:17 --> Email Class Initialized
INFO - 2020-10-07 17:16:17 --> Controller Class Initialized
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
DEBUG - 2020-10-07 17:16:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 17:16:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:16:17 --> Config Class Initialized
INFO - 2020-10-07 17:16:17 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:16:17 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:16:17 --> Utf8 Class Initialized
INFO - 2020-10-07 17:16:17 --> URI Class Initialized
INFO - 2020-10-07 17:16:17 --> Router Class Initialized
INFO - 2020-10-07 17:16:17 --> Output Class Initialized
INFO - 2020-10-07 17:16:17 --> Security Class Initialized
DEBUG - 2020-10-07 17:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:16:17 --> Input Class Initialized
INFO - 2020-10-07 17:16:17 --> Language Class Initialized
INFO - 2020-10-07 17:16:17 --> Loader Class Initialized
INFO - 2020-10-07 17:16:17 --> Helper loaded: url_helper
INFO - 2020-10-07 17:16:17 --> Database Driver Class Initialized
INFO - 2020-10-07 17:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:16:17 --> Email Class Initialized
INFO - 2020-10-07 17:16:17 --> Controller Class Initialized
DEBUG - 2020-10-07 17:16:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:16:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
INFO - 2020-10-07 17:16:17 --> Model Class Initialized
INFO - 2020-10-07 17:16:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:16:17 --> Final output sent to browser
DEBUG - 2020-10-07 17:16:17 --> Total execution time: 0.0222
ERROR - 2020-10-07 17:16:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:16:39 --> Config Class Initialized
INFO - 2020-10-07 17:16:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:16:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:16:39 --> Utf8 Class Initialized
INFO - 2020-10-07 17:16:39 --> URI Class Initialized
INFO - 2020-10-07 17:16:39 --> Router Class Initialized
INFO - 2020-10-07 17:16:39 --> Output Class Initialized
INFO - 2020-10-07 17:16:39 --> Security Class Initialized
DEBUG - 2020-10-07 17:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:16:39 --> Input Class Initialized
INFO - 2020-10-07 17:16:39 --> Language Class Initialized
INFO - 2020-10-07 17:16:39 --> Loader Class Initialized
INFO - 2020-10-07 17:16:39 --> Helper loaded: url_helper
INFO - 2020-10-07 17:16:39 --> Database Driver Class Initialized
INFO - 2020-10-07 17:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:16:39 --> Email Class Initialized
INFO - 2020-10-07 17:16:39 --> Controller Class Initialized
DEBUG - 2020-10-07 17:16:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:16:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:16:39 --> Model Class Initialized
INFO - 2020-10-07 17:16:39 --> Model Class Initialized
INFO - 2020-10-07 17:16:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:16:39 --> Final output sent to browser
DEBUG - 2020-10-07 17:16:39 --> Total execution time: 0.0225
ERROR - 2020-10-07 17:17:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:17:48 --> Config Class Initialized
INFO - 2020-10-07 17:17:48 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:17:48 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:17:48 --> Utf8 Class Initialized
INFO - 2020-10-07 17:17:48 --> URI Class Initialized
INFO - 2020-10-07 17:17:48 --> Router Class Initialized
INFO - 2020-10-07 17:17:48 --> Output Class Initialized
INFO - 2020-10-07 17:17:48 --> Security Class Initialized
DEBUG - 2020-10-07 17:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:17:48 --> Input Class Initialized
INFO - 2020-10-07 17:17:48 --> Language Class Initialized
INFO - 2020-10-07 17:17:48 --> Loader Class Initialized
INFO - 2020-10-07 17:17:48 --> Helper loaded: url_helper
INFO - 2020-10-07 17:17:48 --> Database Driver Class Initialized
INFO - 2020-10-07 17:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:17:48 --> Email Class Initialized
INFO - 2020-10-07 17:17:48 --> Controller Class Initialized
DEBUG - 2020-10-07 17:17:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:17:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:17:48 --> Model Class Initialized
INFO - 2020-10-07 17:17:48 --> Model Class Initialized
INFO - 2020-10-07 17:17:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:17:48 --> Final output sent to browser
DEBUG - 2020-10-07 17:17:48 --> Total execution time: 0.0235
ERROR - 2020-10-07 17:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:17:51 --> Config Class Initialized
INFO - 2020-10-07 17:17:51 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:17:51 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:17:51 --> Utf8 Class Initialized
INFO - 2020-10-07 17:17:51 --> URI Class Initialized
INFO - 2020-10-07 17:17:51 --> Router Class Initialized
INFO - 2020-10-07 17:17:51 --> Output Class Initialized
INFO - 2020-10-07 17:17:51 --> Security Class Initialized
DEBUG - 2020-10-07 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:17:51 --> Input Class Initialized
INFO - 2020-10-07 17:17:51 --> Language Class Initialized
INFO - 2020-10-07 17:17:51 --> Loader Class Initialized
INFO - 2020-10-07 17:17:51 --> Helper loaded: url_helper
INFO - 2020-10-07 17:17:51 --> Database Driver Class Initialized
INFO - 2020-10-07 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:17:51 --> Email Class Initialized
INFO - 2020-10-07 17:17:51 --> Controller Class Initialized
DEBUG - 2020-10-07 17:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:17:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:17:51 --> Model Class Initialized
INFO - 2020-10-07 17:17:51 --> Model Class Initialized
INFO - 2020-10-07 17:17:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:17:51 --> Final output sent to browser
DEBUG - 2020-10-07 17:17:51 --> Total execution time: 0.0205
ERROR - 2020-10-07 17:17:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:17:53 --> Config Class Initialized
INFO - 2020-10-07 17:17:53 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:17:53 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:17:53 --> Utf8 Class Initialized
INFO - 2020-10-07 17:17:53 --> URI Class Initialized
INFO - 2020-10-07 17:17:53 --> Router Class Initialized
INFO - 2020-10-07 17:17:53 --> Output Class Initialized
INFO - 2020-10-07 17:17:53 --> Security Class Initialized
DEBUG - 2020-10-07 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:17:53 --> Input Class Initialized
INFO - 2020-10-07 17:17:53 --> Language Class Initialized
INFO - 2020-10-07 17:17:53 --> Loader Class Initialized
INFO - 2020-10-07 17:17:53 --> Helper loaded: url_helper
INFO - 2020-10-07 17:17:53 --> Database Driver Class Initialized
INFO - 2020-10-07 17:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:17:53 --> Email Class Initialized
INFO - 2020-10-07 17:17:53 --> Controller Class Initialized
DEBUG - 2020-10-07 17:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:17:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:17:53 --> Model Class Initialized
INFO - 2020-10-07 17:17:53 --> Model Class Initialized
INFO - 2020-10-07 17:17:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:17:53 --> Final output sent to browser
DEBUG - 2020-10-07 17:17:53 --> Total execution time: 0.0243
ERROR - 2020-10-07 17:19:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:19:01 --> Config Class Initialized
INFO - 2020-10-07 17:19:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:19:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:19:01 --> Utf8 Class Initialized
INFO - 2020-10-07 17:19:01 --> URI Class Initialized
INFO - 2020-10-07 17:19:01 --> Router Class Initialized
INFO - 2020-10-07 17:19:01 --> Output Class Initialized
INFO - 2020-10-07 17:19:01 --> Security Class Initialized
DEBUG - 2020-10-07 17:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:19:01 --> Input Class Initialized
INFO - 2020-10-07 17:19:01 --> Language Class Initialized
INFO - 2020-10-07 17:19:01 --> Loader Class Initialized
INFO - 2020-10-07 17:19:01 --> Helper loaded: url_helper
INFO - 2020-10-07 17:19:01 --> Database Driver Class Initialized
INFO - 2020-10-07 17:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:19:01 --> Email Class Initialized
INFO - 2020-10-07 17:19:01 --> Controller Class Initialized
DEBUG - 2020-10-07 17:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:19:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:19:01 --> Model Class Initialized
INFO - 2020-10-07 17:19:01 --> Model Class Initialized
INFO - 2020-10-07 17:19:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:19:01 --> Final output sent to browser
DEBUG - 2020-10-07 17:19:01 --> Total execution time: 0.0291
ERROR - 2020-10-07 17:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:19:44 --> Config Class Initialized
INFO - 2020-10-07 17:19:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:19:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:19:44 --> Utf8 Class Initialized
INFO - 2020-10-07 17:19:44 --> URI Class Initialized
INFO - 2020-10-07 17:19:44 --> Router Class Initialized
INFO - 2020-10-07 17:19:44 --> Output Class Initialized
INFO - 2020-10-07 17:19:44 --> Security Class Initialized
DEBUG - 2020-10-07 17:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:19:44 --> Input Class Initialized
INFO - 2020-10-07 17:19:44 --> Language Class Initialized
INFO - 2020-10-07 17:19:44 --> Loader Class Initialized
INFO - 2020-10-07 17:19:44 --> Helper loaded: url_helper
INFO - 2020-10-07 17:19:44 --> Database Driver Class Initialized
INFO - 2020-10-07 17:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:19:44 --> Email Class Initialized
INFO - 2020-10-07 17:19:44 --> Controller Class Initialized
DEBUG - 2020-10-07 17:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:19:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:19:44 --> Model Class Initialized
INFO - 2020-10-07 17:19:44 --> Model Class Initialized
INFO - 2020-10-07 17:19:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:19:44 --> Final output sent to browser
DEBUG - 2020-10-07 17:19:44 --> Total execution time: 0.0255
ERROR - 2020-10-07 17:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:19:58 --> Config Class Initialized
INFO - 2020-10-07 17:19:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:19:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:19:58 --> Utf8 Class Initialized
INFO - 2020-10-07 17:19:58 --> URI Class Initialized
INFO - 2020-10-07 17:19:58 --> Router Class Initialized
INFO - 2020-10-07 17:19:58 --> Output Class Initialized
INFO - 2020-10-07 17:19:58 --> Security Class Initialized
DEBUG - 2020-10-07 17:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:19:58 --> Input Class Initialized
INFO - 2020-10-07 17:19:58 --> Language Class Initialized
INFO - 2020-10-07 17:19:58 --> Loader Class Initialized
INFO - 2020-10-07 17:19:58 --> Helper loaded: url_helper
INFO - 2020-10-07 17:19:58 --> Database Driver Class Initialized
INFO - 2020-10-07 17:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:19:58 --> Email Class Initialized
INFO - 2020-10-07 17:19:58 --> Controller Class Initialized
DEBUG - 2020-10-07 17:19:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:19:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:19:58 --> Model Class Initialized
INFO - 2020-10-07 17:19:58 --> Model Class Initialized
INFO - 2020-10-07 17:19:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:19:58 --> Final output sent to browser
DEBUG - 2020-10-07 17:19:58 --> Total execution time: 0.0228
ERROR - 2020-10-07 17:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:20:14 --> Config Class Initialized
INFO - 2020-10-07 17:20:14 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:20:14 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:20:14 --> Utf8 Class Initialized
INFO - 2020-10-07 17:20:14 --> URI Class Initialized
INFO - 2020-10-07 17:20:14 --> Router Class Initialized
INFO - 2020-10-07 17:20:14 --> Output Class Initialized
INFO - 2020-10-07 17:20:14 --> Security Class Initialized
DEBUG - 2020-10-07 17:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:20:14 --> Input Class Initialized
INFO - 2020-10-07 17:20:14 --> Language Class Initialized
INFO - 2020-10-07 17:20:14 --> Loader Class Initialized
INFO - 2020-10-07 17:20:14 --> Helper loaded: url_helper
INFO - 2020-10-07 17:20:14 --> Database Driver Class Initialized
INFO - 2020-10-07 17:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:20:14 --> Email Class Initialized
INFO - 2020-10-07 17:20:14 --> Controller Class Initialized
DEBUG - 2020-10-07 17:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:20:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:20:14 --> Model Class Initialized
INFO - 2020-10-07 17:20:14 --> Model Class Initialized
INFO - 2020-10-07 17:20:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:20:14 --> Final output sent to browser
DEBUG - 2020-10-07 17:20:14 --> Total execution time: 0.0271
ERROR - 2020-10-07 17:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:22:08 --> Config Class Initialized
INFO - 2020-10-07 17:22:08 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:22:08 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:22:08 --> Utf8 Class Initialized
INFO - 2020-10-07 17:22:08 --> URI Class Initialized
INFO - 2020-10-07 17:22:08 --> Router Class Initialized
INFO - 2020-10-07 17:22:08 --> Output Class Initialized
INFO - 2020-10-07 17:22:08 --> Security Class Initialized
DEBUG - 2020-10-07 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:22:08 --> Input Class Initialized
INFO - 2020-10-07 17:22:08 --> Language Class Initialized
INFO - 2020-10-07 17:22:08 --> Loader Class Initialized
INFO - 2020-10-07 17:22:08 --> Helper loaded: url_helper
INFO - 2020-10-07 17:22:08 --> Database Driver Class Initialized
INFO - 2020-10-07 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:22:08 --> Email Class Initialized
INFO - 2020-10-07 17:22:08 --> Controller Class Initialized
DEBUG - 2020-10-07 17:22:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:22:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:22:08 --> Model Class Initialized
INFO - 2020-10-07 17:22:08 --> Model Class Initialized
INFO - 2020-10-07 17:22:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:22:08 --> Final output sent to browser
DEBUG - 2020-10-07 17:22:08 --> Total execution time: 0.0259
ERROR - 2020-10-07 17:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:23:18 --> Config Class Initialized
INFO - 2020-10-07 17:23:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:23:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:23:18 --> Utf8 Class Initialized
INFO - 2020-10-07 17:23:18 --> URI Class Initialized
INFO - 2020-10-07 17:23:18 --> Router Class Initialized
INFO - 2020-10-07 17:23:19 --> Output Class Initialized
INFO - 2020-10-07 17:23:19 --> Security Class Initialized
DEBUG - 2020-10-07 17:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:23:19 --> Input Class Initialized
INFO - 2020-10-07 17:23:19 --> Language Class Initialized
INFO - 2020-10-07 17:23:19 --> Loader Class Initialized
INFO - 2020-10-07 17:23:19 --> Helper loaded: url_helper
INFO - 2020-10-07 17:23:19 --> Database Driver Class Initialized
INFO - 2020-10-07 17:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:23:19 --> Email Class Initialized
INFO - 2020-10-07 17:23:19 --> Controller Class Initialized
DEBUG - 2020-10-07 17:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:23:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:23:19 --> Model Class Initialized
INFO - 2020-10-07 17:23:19 --> Model Class Initialized
INFO - 2020-10-07 17:23:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:23:19 --> Final output sent to browser
DEBUG - 2020-10-07 17:23:19 --> Total execution time: 0.0230
ERROR - 2020-10-07 17:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:27:36 --> Config Class Initialized
INFO - 2020-10-07 17:27:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:27:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:27:36 --> Utf8 Class Initialized
INFO - 2020-10-07 17:27:36 --> URI Class Initialized
INFO - 2020-10-07 17:27:36 --> Router Class Initialized
INFO - 2020-10-07 17:27:36 --> Output Class Initialized
INFO - 2020-10-07 17:27:36 --> Security Class Initialized
DEBUG - 2020-10-07 17:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:27:36 --> Input Class Initialized
INFO - 2020-10-07 17:27:36 --> Language Class Initialized
INFO - 2020-10-07 17:27:36 --> Loader Class Initialized
INFO - 2020-10-07 17:27:36 --> Helper loaded: url_helper
INFO - 2020-10-07 17:27:36 --> Database Driver Class Initialized
INFO - 2020-10-07 17:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:27:36 --> Email Class Initialized
INFO - 2020-10-07 17:27:36 --> Controller Class Initialized
DEBUG - 2020-10-07 17:27:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:27:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:27:36 --> Model Class Initialized
INFO - 2020-10-07 17:27:36 --> Model Class Initialized
ERROR - 2020-10-07 17:27:36 --> Query error: PROCEDURE purpu1ex_carsm.total_client_in_system_view_for_admin does not exist - Invalid query: CALL total_client_in_system_view_for_admin()
INFO - 2020-10-07 17:27:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:28:59 --> Config Class Initialized
INFO - 2020-10-07 17:28:59 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:28:59 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:28:59 --> Utf8 Class Initialized
INFO - 2020-10-07 17:28:59 --> URI Class Initialized
DEBUG - 2020-10-07 17:28:59 --> No URI present. Default controller set.
INFO - 2020-10-07 17:28:59 --> Router Class Initialized
INFO - 2020-10-07 17:28:59 --> Output Class Initialized
INFO - 2020-10-07 17:28:59 --> Security Class Initialized
DEBUG - 2020-10-07 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:28:59 --> Input Class Initialized
INFO - 2020-10-07 17:28:59 --> Language Class Initialized
INFO - 2020-10-07 17:28:59 --> Loader Class Initialized
INFO - 2020-10-07 17:28:59 --> Helper loaded: url_helper
INFO - 2020-10-07 17:28:59 --> Database Driver Class Initialized
INFO - 2020-10-07 17:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:28:59 --> Email Class Initialized
INFO - 2020-10-07 17:28:59 --> Controller Class Initialized
INFO - 2020-10-07 17:28:59 --> Model Class Initialized
INFO - 2020-10-07 17:28:59 --> Model Class Initialized
DEBUG - 2020-10-07 17:28:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:28:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 17:28:59 --> Final output sent to browser
DEBUG - 2020-10-07 17:28:59 --> Total execution time: 0.0181
ERROR - 2020-10-07 17:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:29:10 --> Config Class Initialized
INFO - 2020-10-07 17:29:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:29:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:29:10 --> Utf8 Class Initialized
INFO - 2020-10-07 17:29:10 --> URI Class Initialized
INFO - 2020-10-07 17:29:10 --> Router Class Initialized
INFO - 2020-10-07 17:29:10 --> Output Class Initialized
INFO - 2020-10-07 17:29:10 --> Security Class Initialized
DEBUG - 2020-10-07 17:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:29:10 --> Input Class Initialized
INFO - 2020-10-07 17:29:10 --> Language Class Initialized
INFO - 2020-10-07 17:29:10 --> Loader Class Initialized
INFO - 2020-10-07 17:29:10 --> Helper loaded: url_helper
INFO - 2020-10-07 17:29:10 --> Database Driver Class Initialized
INFO - 2020-10-07 17:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:29:10 --> Email Class Initialized
INFO - 2020-10-07 17:29:10 --> Controller Class Initialized
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
DEBUG - 2020-10-07 17:29:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:29:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
INFO - 2020-10-07 17:29:10 --> Final output sent to browser
DEBUG - 2020-10-07 17:29:10 --> Total execution time: 0.0249
ERROR - 2020-10-07 17:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:29:10 --> Config Class Initialized
INFO - 2020-10-07 17:29:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:29:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:29:10 --> Utf8 Class Initialized
INFO - 2020-10-07 17:29:10 --> URI Class Initialized
INFO - 2020-10-07 17:29:10 --> Router Class Initialized
INFO - 2020-10-07 17:29:10 --> Output Class Initialized
INFO - 2020-10-07 17:29:10 --> Security Class Initialized
DEBUG - 2020-10-07 17:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:29:10 --> Input Class Initialized
INFO - 2020-10-07 17:29:10 --> Language Class Initialized
INFO - 2020-10-07 17:29:10 --> Loader Class Initialized
INFO - 2020-10-07 17:29:10 --> Helper loaded: url_helper
INFO - 2020-10-07 17:29:10 --> Database Driver Class Initialized
INFO - 2020-10-07 17:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:29:10 --> Email Class Initialized
INFO - 2020-10-07 17:29:10 --> Controller Class Initialized
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
DEBUG - 2020-10-07 17:29:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 17:29:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:29:10 --> Config Class Initialized
INFO - 2020-10-07 17:29:10 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:29:10 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:29:10 --> Utf8 Class Initialized
INFO - 2020-10-07 17:29:10 --> URI Class Initialized
INFO - 2020-10-07 17:29:10 --> Router Class Initialized
INFO - 2020-10-07 17:29:10 --> Output Class Initialized
INFO - 2020-10-07 17:29:10 --> Security Class Initialized
DEBUG - 2020-10-07 17:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:29:10 --> Input Class Initialized
INFO - 2020-10-07 17:29:10 --> Language Class Initialized
INFO - 2020-10-07 17:29:10 --> Loader Class Initialized
INFO - 2020-10-07 17:29:10 --> Helper loaded: url_helper
INFO - 2020-10-07 17:29:10 --> Database Driver Class Initialized
INFO - 2020-10-07 17:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:29:10 --> Email Class Initialized
INFO - 2020-10-07 17:29:10 --> Controller Class Initialized
DEBUG - 2020-10-07 17:29:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:29:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
INFO - 2020-10-07 17:29:10 --> Model Class Initialized
ERROR - 2020-10-07 17:29:10 --> Query error: PROCEDURE purpu1ex_carsm.total_client_in_system_view_for_admin does not exist - Invalid query: CALL total_client_in_system_view_for_admin()
INFO - 2020-10-07 17:29:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:30:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:30:30 --> Config Class Initialized
INFO - 2020-10-07 17:30:30 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:30:30 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:30:30 --> Utf8 Class Initialized
INFO - 2020-10-07 17:30:30 --> URI Class Initialized
DEBUG - 2020-10-07 17:30:30 --> No URI present. Default controller set.
INFO - 2020-10-07 17:30:30 --> Router Class Initialized
INFO - 2020-10-07 17:30:30 --> Output Class Initialized
INFO - 2020-10-07 17:30:30 --> Security Class Initialized
DEBUG - 2020-10-07 17:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:30:30 --> Input Class Initialized
INFO - 2020-10-07 17:30:30 --> Language Class Initialized
INFO - 2020-10-07 17:30:30 --> Loader Class Initialized
INFO - 2020-10-07 17:30:30 --> Helper loaded: url_helper
INFO - 2020-10-07 17:30:30 --> Database Driver Class Initialized
INFO - 2020-10-07 17:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:30:30 --> Email Class Initialized
INFO - 2020-10-07 17:30:30 --> Controller Class Initialized
INFO - 2020-10-07 17:30:30 --> Model Class Initialized
INFO - 2020-10-07 17:30:30 --> Model Class Initialized
DEBUG - 2020-10-07 17:30:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:30:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 17:30:30 --> Final output sent to browser
DEBUG - 2020-10-07 17:30:30 --> Total execution time: 0.0198
ERROR - 2020-10-07 17:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:30:39 --> Config Class Initialized
INFO - 2020-10-07 17:30:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:30:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:30:39 --> Utf8 Class Initialized
INFO - 2020-10-07 17:30:39 --> URI Class Initialized
INFO - 2020-10-07 17:30:39 --> Router Class Initialized
INFO - 2020-10-07 17:30:39 --> Output Class Initialized
INFO - 2020-10-07 17:30:39 --> Security Class Initialized
DEBUG - 2020-10-07 17:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:30:39 --> Input Class Initialized
INFO - 2020-10-07 17:30:39 --> Language Class Initialized
INFO - 2020-10-07 17:30:39 --> Loader Class Initialized
INFO - 2020-10-07 17:30:39 --> Helper loaded: url_helper
INFO - 2020-10-07 17:30:39 --> Database Driver Class Initialized
INFO - 2020-10-07 17:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:30:39 --> Email Class Initialized
INFO - 2020-10-07 17:30:39 --> Controller Class Initialized
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
DEBUG - 2020-10-07 17:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:30:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
INFO - 2020-10-07 17:30:39 --> Final output sent to browser
DEBUG - 2020-10-07 17:30:39 --> Total execution time: 0.0213
ERROR - 2020-10-07 17:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:30:39 --> Config Class Initialized
INFO - 2020-10-07 17:30:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:30:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:30:39 --> Utf8 Class Initialized
INFO - 2020-10-07 17:30:39 --> URI Class Initialized
INFO - 2020-10-07 17:30:39 --> Router Class Initialized
INFO - 2020-10-07 17:30:39 --> Output Class Initialized
INFO - 2020-10-07 17:30:39 --> Security Class Initialized
DEBUG - 2020-10-07 17:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:30:39 --> Input Class Initialized
INFO - 2020-10-07 17:30:39 --> Language Class Initialized
INFO - 2020-10-07 17:30:39 --> Loader Class Initialized
INFO - 2020-10-07 17:30:39 --> Helper loaded: url_helper
INFO - 2020-10-07 17:30:39 --> Database Driver Class Initialized
INFO - 2020-10-07 17:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:30:39 --> Email Class Initialized
INFO - 2020-10-07 17:30:39 --> Controller Class Initialized
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
DEBUG - 2020-10-07 17:30:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 17:30:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:30:39 --> Config Class Initialized
INFO - 2020-10-07 17:30:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:30:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:30:39 --> Utf8 Class Initialized
INFO - 2020-10-07 17:30:39 --> URI Class Initialized
INFO - 2020-10-07 17:30:39 --> Router Class Initialized
INFO - 2020-10-07 17:30:39 --> Output Class Initialized
INFO - 2020-10-07 17:30:39 --> Security Class Initialized
DEBUG - 2020-10-07 17:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:30:39 --> Input Class Initialized
INFO - 2020-10-07 17:30:39 --> Language Class Initialized
INFO - 2020-10-07 17:30:39 --> Loader Class Initialized
INFO - 2020-10-07 17:30:39 --> Helper loaded: url_helper
INFO - 2020-10-07 17:30:39 --> Database Driver Class Initialized
INFO - 2020-10-07 17:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:30:39 --> Email Class Initialized
INFO - 2020-10-07 17:30:39 --> Controller Class Initialized
DEBUG - 2020-10-07 17:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:30:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
INFO - 2020-10-07 17:30:39 --> Model Class Initialized
ERROR - 2020-10-07 17:30:39 --> Query error: PROCEDURE purpu1ex_carsm.total_client_in_system_view_for_admin does not exist - Invalid query: CALL total_client_in_system_view_for_admin()
INFO - 2020-10-07 17:30:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:31:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:31:44 --> Config Class Initialized
INFO - 2020-10-07 17:31:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:31:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:31:44 --> Utf8 Class Initialized
INFO - 2020-10-07 17:31:44 --> URI Class Initialized
INFO - 2020-10-07 17:31:44 --> Router Class Initialized
INFO - 2020-10-07 17:31:44 --> Output Class Initialized
INFO - 2020-10-07 17:31:44 --> Security Class Initialized
DEBUG - 2020-10-07 17:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:31:44 --> Input Class Initialized
INFO - 2020-10-07 17:31:44 --> Language Class Initialized
INFO - 2020-10-07 17:31:44 --> Loader Class Initialized
INFO - 2020-10-07 17:31:44 --> Helper loaded: url_helper
INFO - 2020-10-07 17:31:44 --> Database Driver Class Initialized
INFO - 2020-10-07 17:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:31:44 --> Email Class Initialized
INFO - 2020-10-07 17:31:44 --> Controller Class Initialized
DEBUG - 2020-10-07 17:31:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:31:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:31:44 --> Model Class Initialized
INFO - 2020-10-07 17:31:44 --> Model Class Initialized
INFO - 2020-10-07 17:31:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:31:44 --> Final output sent to browser
DEBUG - 2020-10-07 17:31:44 --> Total execution time: 0.0259
ERROR - 2020-10-07 17:33:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:33:02 --> Config Class Initialized
INFO - 2020-10-07 17:33:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:33:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:33:02 --> Utf8 Class Initialized
INFO - 2020-10-07 17:33:02 --> URI Class Initialized
INFO - 2020-10-07 17:33:02 --> Router Class Initialized
INFO - 2020-10-07 17:33:02 --> Output Class Initialized
INFO - 2020-10-07 17:33:02 --> Security Class Initialized
DEBUG - 2020-10-07 17:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:33:02 --> Input Class Initialized
INFO - 2020-10-07 17:33:02 --> Language Class Initialized
INFO - 2020-10-07 17:33:02 --> Loader Class Initialized
INFO - 2020-10-07 17:33:02 --> Helper loaded: url_helper
INFO - 2020-10-07 17:33:02 --> Database Driver Class Initialized
INFO - 2020-10-07 17:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:33:02 --> Email Class Initialized
INFO - 2020-10-07 17:33:02 --> Controller Class Initialized
DEBUG - 2020-10-07 17:33:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:33:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:33:02 --> Model Class Initialized
INFO - 2020-10-07 17:33:02 --> Model Class Initialized
INFO - 2020-10-07 17:33:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:33:02 --> Final output sent to browser
DEBUG - 2020-10-07 17:33:02 --> Total execution time: 0.0236
ERROR - 2020-10-07 17:33:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:33:19 --> Config Class Initialized
INFO - 2020-10-07 17:33:19 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:33:19 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:33:19 --> Utf8 Class Initialized
INFO - 2020-10-07 17:33:19 --> URI Class Initialized
INFO - 2020-10-07 17:33:19 --> Router Class Initialized
INFO - 2020-10-07 17:33:19 --> Output Class Initialized
INFO - 2020-10-07 17:33:19 --> Security Class Initialized
DEBUG - 2020-10-07 17:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:33:19 --> Input Class Initialized
INFO - 2020-10-07 17:33:19 --> Language Class Initialized
INFO - 2020-10-07 17:33:19 --> Loader Class Initialized
INFO - 2020-10-07 17:33:19 --> Helper loaded: url_helper
INFO - 2020-10-07 17:33:19 --> Database Driver Class Initialized
INFO - 2020-10-07 17:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:33:19 --> Email Class Initialized
INFO - 2020-10-07 17:33:19 --> Controller Class Initialized
DEBUG - 2020-10-07 17:33:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:33:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:33:19 --> Model Class Initialized
INFO - 2020-10-07 17:33:19 --> Model Class Initialized
ERROR - 2020-10-07 17:33:19 --> Query error: PROCEDURE purpu1ex_carsm.total_client_in_system_view_for_admin does not exist - Invalid query: CALL total_client_in_system_view_for_admin()
INFO - 2020-10-07 17:33:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:34:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:34:29 --> Config Class Initialized
INFO - 2020-10-07 17:34:29 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:34:29 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:34:29 --> Utf8 Class Initialized
INFO - 2020-10-07 17:34:29 --> URI Class Initialized
INFO - 2020-10-07 17:34:29 --> Router Class Initialized
INFO - 2020-10-07 17:34:29 --> Output Class Initialized
INFO - 2020-10-07 17:34:29 --> Security Class Initialized
DEBUG - 2020-10-07 17:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:34:29 --> Input Class Initialized
INFO - 2020-10-07 17:34:29 --> Language Class Initialized
INFO - 2020-10-07 17:34:29 --> Loader Class Initialized
INFO - 2020-10-07 17:34:29 --> Helper loaded: url_helper
INFO - 2020-10-07 17:34:29 --> Database Driver Class Initialized
INFO - 2020-10-07 17:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:34:29 --> Email Class Initialized
INFO - 2020-10-07 17:34:29 --> Controller Class Initialized
DEBUG - 2020-10-07 17:34:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:34:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:34:29 --> Model Class Initialized
INFO - 2020-10-07 17:34:29 --> Model Class Initialized
INFO - 2020-10-07 17:34:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:34:29 --> Final output sent to browser
DEBUG - 2020-10-07 17:34:29 --> Total execution time: 0.0196
ERROR - 2020-10-07 17:34:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:34:50 --> Config Class Initialized
INFO - 2020-10-07 17:34:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:34:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:34:50 --> Utf8 Class Initialized
INFO - 2020-10-07 17:34:50 --> URI Class Initialized
INFO - 2020-10-07 17:34:50 --> Router Class Initialized
INFO - 2020-10-07 17:34:50 --> Output Class Initialized
INFO - 2020-10-07 17:34:50 --> Security Class Initialized
DEBUG - 2020-10-07 17:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:34:50 --> Input Class Initialized
INFO - 2020-10-07 17:34:50 --> Language Class Initialized
INFO - 2020-10-07 17:34:50 --> Loader Class Initialized
INFO - 2020-10-07 17:34:50 --> Helper loaded: url_helper
INFO - 2020-10-07 17:34:50 --> Database Driver Class Initialized
INFO - 2020-10-07 17:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:34:50 --> Email Class Initialized
INFO - 2020-10-07 17:34:50 --> Controller Class Initialized
DEBUG - 2020-10-07 17:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:34:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:34:50 --> Model Class Initialized
INFO - 2020-10-07 17:34:50 --> Model Class Initialized
INFO - 2020-10-07 17:34:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:34:50 --> Final output sent to browser
DEBUG - 2020-10-07 17:34:50 --> Total execution time: 0.0242
ERROR - 2020-10-07 17:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:35:39 --> Config Class Initialized
INFO - 2020-10-07 17:35:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:35:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:35:39 --> Utf8 Class Initialized
INFO - 2020-10-07 17:35:39 --> URI Class Initialized
INFO - 2020-10-07 17:35:39 --> Router Class Initialized
INFO - 2020-10-07 17:35:39 --> Output Class Initialized
INFO - 2020-10-07 17:35:39 --> Security Class Initialized
DEBUG - 2020-10-07 17:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:35:39 --> Input Class Initialized
INFO - 2020-10-07 17:35:39 --> Language Class Initialized
INFO - 2020-10-07 17:35:39 --> Loader Class Initialized
INFO - 2020-10-07 17:35:39 --> Helper loaded: url_helper
INFO - 2020-10-07 17:35:39 --> Database Driver Class Initialized
INFO - 2020-10-07 17:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:35:39 --> Email Class Initialized
INFO - 2020-10-07 17:35:39 --> Controller Class Initialized
DEBUG - 2020-10-07 17:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:35:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:35:39 --> Model Class Initialized
INFO - 2020-10-07 17:35:39 --> Model Class Initialized
ERROR - 2020-10-07 17:35:39 --> Query error: PROCEDURE purpu1ex_carsm.total_client_in_system_view_for_admin does not exist - Invalid query: CALL total_client_in_system_view_for_admin()
INFO - 2020-10-07 17:35:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:38:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:38:35 --> Config Class Initialized
INFO - 2020-10-07 17:38:35 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:38:35 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:38:35 --> Utf8 Class Initialized
INFO - 2020-10-07 17:38:35 --> URI Class Initialized
DEBUG - 2020-10-07 17:38:35 --> No URI present. Default controller set.
INFO - 2020-10-07 17:38:35 --> Router Class Initialized
INFO - 2020-10-07 17:38:35 --> Output Class Initialized
INFO - 2020-10-07 17:38:35 --> Security Class Initialized
DEBUG - 2020-10-07 17:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:38:35 --> Input Class Initialized
INFO - 2020-10-07 17:38:35 --> Language Class Initialized
INFO - 2020-10-07 17:38:35 --> Loader Class Initialized
INFO - 2020-10-07 17:38:35 --> Helper loaded: url_helper
INFO - 2020-10-07 17:38:35 --> Database Driver Class Initialized
INFO - 2020-10-07 17:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:38:35 --> Email Class Initialized
INFO - 2020-10-07 17:38:35 --> Controller Class Initialized
INFO - 2020-10-07 17:38:35 --> Model Class Initialized
INFO - 2020-10-07 17:38:35 --> Model Class Initialized
DEBUG - 2020-10-07 17:38:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:38:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 17:38:35 --> Final output sent to browser
DEBUG - 2020-10-07 17:38:35 --> Total execution time: 0.0191
ERROR - 2020-10-07 17:38:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:38:37 --> Config Class Initialized
INFO - 2020-10-07 17:38:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:38:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:38:37 --> Utf8 Class Initialized
INFO - 2020-10-07 17:38:37 --> URI Class Initialized
DEBUG - 2020-10-07 17:38:37 --> No URI present. Default controller set.
INFO - 2020-10-07 17:38:37 --> Router Class Initialized
INFO - 2020-10-07 17:38:37 --> Output Class Initialized
INFO - 2020-10-07 17:38:37 --> Security Class Initialized
DEBUG - 2020-10-07 17:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:38:37 --> Input Class Initialized
INFO - 2020-10-07 17:38:37 --> Language Class Initialized
INFO - 2020-10-07 17:38:37 --> Loader Class Initialized
INFO - 2020-10-07 17:38:37 --> Helper loaded: url_helper
INFO - 2020-10-07 17:38:37 --> Database Driver Class Initialized
INFO - 2020-10-07 17:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:38:37 --> Email Class Initialized
INFO - 2020-10-07 17:38:37 --> Controller Class Initialized
INFO - 2020-10-07 17:38:37 --> Model Class Initialized
INFO - 2020-10-07 17:38:37 --> Model Class Initialized
DEBUG - 2020-10-07 17:38:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:38:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 17:38:37 --> Final output sent to browser
DEBUG - 2020-10-07 17:38:37 --> Total execution time: 0.0218
ERROR - 2020-10-07 17:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:38:50 --> Config Class Initialized
INFO - 2020-10-07 17:38:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:38:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:38:50 --> Utf8 Class Initialized
INFO - 2020-10-07 17:38:50 --> URI Class Initialized
INFO - 2020-10-07 17:38:50 --> Router Class Initialized
INFO - 2020-10-07 17:38:50 --> Output Class Initialized
INFO - 2020-10-07 17:38:50 --> Security Class Initialized
DEBUG - 2020-10-07 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:38:50 --> Input Class Initialized
INFO - 2020-10-07 17:38:50 --> Language Class Initialized
INFO - 2020-10-07 17:38:50 --> Loader Class Initialized
INFO - 2020-10-07 17:38:50 --> Helper loaded: url_helper
INFO - 2020-10-07 17:38:50 --> Database Driver Class Initialized
INFO - 2020-10-07 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:38:50 --> Email Class Initialized
INFO - 2020-10-07 17:38:50 --> Controller Class Initialized
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
DEBUG - 2020-10-07 17:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:38:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
INFO - 2020-10-07 17:38:50 --> Final output sent to browser
DEBUG - 2020-10-07 17:38:50 --> Total execution time: 0.0228
ERROR - 2020-10-07 17:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:38:50 --> Config Class Initialized
INFO - 2020-10-07 17:38:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:38:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:38:50 --> Utf8 Class Initialized
INFO - 2020-10-07 17:38:50 --> URI Class Initialized
INFO - 2020-10-07 17:38:50 --> Router Class Initialized
INFO - 2020-10-07 17:38:50 --> Output Class Initialized
INFO - 2020-10-07 17:38:50 --> Security Class Initialized
DEBUG - 2020-10-07 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:38:50 --> Input Class Initialized
INFO - 2020-10-07 17:38:50 --> Language Class Initialized
INFO - 2020-10-07 17:38:50 --> Loader Class Initialized
INFO - 2020-10-07 17:38:50 --> Helper loaded: url_helper
INFO - 2020-10-07 17:38:50 --> Database Driver Class Initialized
INFO - 2020-10-07 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:38:50 --> Email Class Initialized
INFO - 2020-10-07 17:38:50 --> Controller Class Initialized
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
DEBUG - 2020-10-07 17:38:50 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-07 17:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:38:50 --> Config Class Initialized
INFO - 2020-10-07 17:38:50 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:38:50 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:38:50 --> Utf8 Class Initialized
INFO - 2020-10-07 17:38:50 --> URI Class Initialized
INFO - 2020-10-07 17:38:50 --> Router Class Initialized
INFO - 2020-10-07 17:38:50 --> Output Class Initialized
INFO - 2020-10-07 17:38:50 --> Security Class Initialized
DEBUG - 2020-10-07 17:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:38:50 --> Input Class Initialized
INFO - 2020-10-07 17:38:50 --> Language Class Initialized
INFO - 2020-10-07 17:38:50 --> Loader Class Initialized
INFO - 2020-10-07 17:38:50 --> Helper loaded: url_helper
INFO - 2020-10-07 17:38:50 --> Database Driver Class Initialized
INFO - 2020-10-07 17:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:38:50 --> Email Class Initialized
INFO - 2020-10-07 17:38:50 --> Controller Class Initialized
DEBUG - 2020-10-07 17:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:38:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
INFO - 2020-10-07 17:38:50 --> Model Class Initialized
ERROR - 2020-10-07 17:38:50 --> Query error: PROCEDURE purpu1ex_carsm.total_client_view_for_admin does not exist - Invalid query: CALL total_client_view_for_admin()
INFO - 2020-10-07 17:38:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:39:20 --> Config Class Initialized
INFO - 2020-10-07 17:39:20 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:39:20 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:39:20 --> Utf8 Class Initialized
INFO - 2020-10-07 17:39:20 --> URI Class Initialized
INFO - 2020-10-07 17:39:20 --> Router Class Initialized
INFO - 2020-10-07 17:39:20 --> Output Class Initialized
INFO - 2020-10-07 17:39:20 --> Security Class Initialized
DEBUG - 2020-10-07 17:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:39:20 --> Input Class Initialized
INFO - 2020-10-07 17:39:20 --> Language Class Initialized
INFO - 2020-10-07 17:39:20 --> Loader Class Initialized
INFO - 2020-10-07 17:39:20 --> Helper loaded: url_helper
INFO - 2020-10-07 17:39:20 --> Database Driver Class Initialized
INFO - 2020-10-07 17:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:39:20 --> Email Class Initialized
INFO - 2020-10-07 17:39:20 --> Controller Class Initialized
DEBUG - 2020-10-07 17:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:39:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:39:20 --> Model Class Initialized
INFO - 2020-10-07 17:39:20 --> Model Class Initialized
INFO - 2020-10-07 17:39:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:39:20 --> Final output sent to browser
DEBUG - 2020-10-07 17:39:20 --> Total execution time: 0.0207
ERROR - 2020-10-07 17:39:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:39:57 --> Config Class Initialized
INFO - 2020-10-07 17:39:57 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:39:57 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:39:57 --> Utf8 Class Initialized
INFO - 2020-10-07 17:39:57 --> URI Class Initialized
INFO - 2020-10-07 17:39:57 --> Router Class Initialized
INFO - 2020-10-07 17:39:57 --> Output Class Initialized
INFO - 2020-10-07 17:39:57 --> Security Class Initialized
DEBUG - 2020-10-07 17:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:39:57 --> Input Class Initialized
INFO - 2020-10-07 17:39:57 --> Language Class Initialized
INFO - 2020-10-07 17:39:57 --> Loader Class Initialized
INFO - 2020-10-07 17:39:57 --> Helper loaded: url_helper
INFO - 2020-10-07 17:39:57 --> Database Driver Class Initialized
INFO - 2020-10-07 17:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:39:57 --> Email Class Initialized
INFO - 2020-10-07 17:39:57 --> Controller Class Initialized
DEBUG - 2020-10-07 17:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:39:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:39:57 --> Model Class Initialized
INFO - 2020-10-07 17:39:57 --> Model Class Initialized
ERROR - 2020-10-07 17:39:57 --> Query error: PROCEDURE purpu1ex_carsm.total_client_view_for_admin does not exist - Invalid query: CALL total_client_view_for_admin()
INFO - 2020-10-07 17:39:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-07 17:42:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:42:56 --> Config Class Initialized
INFO - 2020-10-07 17:42:56 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:42:56 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:42:56 --> Utf8 Class Initialized
INFO - 2020-10-07 17:42:56 --> URI Class Initialized
INFO - 2020-10-07 17:42:56 --> Router Class Initialized
INFO - 2020-10-07 17:42:56 --> Output Class Initialized
INFO - 2020-10-07 17:42:56 --> Security Class Initialized
DEBUG - 2020-10-07 17:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:42:56 --> Input Class Initialized
INFO - 2020-10-07 17:42:56 --> Language Class Initialized
INFO - 2020-10-07 17:42:56 --> Loader Class Initialized
INFO - 2020-10-07 17:42:56 --> Helper loaded: url_helper
INFO - 2020-10-07 17:42:56 --> Database Driver Class Initialized
INFO - 2020-10-07 17:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:42:56 --> Email Class Initialized
INFO - 2020-10-07 17:42:56 --> Controller Class Initialized
DEBUG - 2020-10-07 17:42:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:42:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:42:56 --> Model Class Initialized
INFO - 2020-10-07 17:42:56 --> Model Class Initialized
INFO - 2020-10-07 17:42:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:42:56 --> Final output sent to browser
DEBUG - 2020-10-07 17:42:56 --> Total execution time: 0.0256
ERROR - 2020-10-07 17:43:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:43:37 --> Config Class Initialized
INFO - 2020-10-07 17:43:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:43:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:43:37 --> Utf8 Class Initialized
INFO - 2020-10-07 17:43:37 --> URI Class Initialized
INFO - 2020-10-07 17:43:37 --> Router Class Initialized
INFO - 2020-10-07 17:43:37 --> Output Class Initialized
INFO - 2020-10-07 17:43:37 --> Security Class Initialized
DEBUG - 2020-10-07 17:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:43:37 --> Input Class Initialized
INFO - 2020-10-07 17:43:37 --> Language Class Initialized
INFO - 2020-10-07 17:43:37 --> Loader Class Initialized
INFO - 2020-10-07 17:43:37 --> Helper loaded: url_helper
INFO - 2020-10-07 17:43:37 --> Database Driver Class Initialized
INFO - 2020-10-07 17:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:43:37 --> Email Class Initialized
INFO - 2020-10-07 17:43:37 --> Controller Class Initialized
DEBUG - 2020-10-07 17:43:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:43:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:43:37 --> Model Class Initialized
INFO - 2020-10-07 17:43:37 --> Model Class Initialized
INFO - 2020-10-07 17:43:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:43:37 --> Final output sent to browser
DEBUG - 2020-10-07 17:43:37 --> Total execution time: 0.0243
ERROR - 2020-10-07 17:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:45:41 --> Config Class Initialized
INFO - 2020-10-07 17:45:41 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:45:41 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:45:41 --> Utf8 Class Initialized
INFO - 2020-10-07 17:45:41 --> URI Class Initialized
INFO - 2020-10-07 17:45:41 --> Router Class Initialized
INFO - 2020-10-07 17:45:41 --> Output Class Initialized
INFO - 2020-10-07 17:45:41 --> Security Class Initialized
DEBUG - 2020-10-07 17:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:45:41 --> Input Class Initialized
INFO - 2020-10-07 17:45:41 --> Language Class Initialized
INFO - 2020-10-07 17:45:41 --> Loader Class Initialized
INFO - 2020-10-07 17:45:41 --> Helper loaded: url_helper
INFO - 2020-10-07 17:45:41 --> Database Driver Class Initialized
INFO - 2020-10-07 17:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:45:41 --> Email Class Initialized
INFO - 2020-10-07 17:45:41 --> Controller Class Initialized
DEBUG - 2020-10-07 17:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:45:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:45:41 --> Model Class Initialized
INFO - 2020-10-07 17:45:41 --> Model Class Initialized
INFO - 2020-10-07 17:45:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:45:41 --> Final output sent to browser
DEBUG - 2020-10-07 17:45:41 --> Total execution time: 0.0272
ERROR - 2020-10-07 17:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:45:46 --> Config Class Initialized
INFO - 2020-10-07 17:45:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:45:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:45:46 --> Utf8 Class Initialized
INFO - 2020-10-07 17:45:46 --> URI Class Initialized
INFO - 2020-10-07 17:45:46 --> Router Class Initialized
INFO - 2020-10-07 17:45:46 --> Output Class Initialized
INFO - 2020-10-07 17:45:46 --> Security Class Initialized
DEBUG - 2020-10-07 17:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:45:46 --> Input Class Initialized
INFO - 2020-10-07 17:45:46 --> Language Class Initialized
INFO - 2020-10-07 17:45:46 --> Loader Class Initialized
INFO - 2020-10-07 17:45:46 --> Helper loaded: url_helper
INFO - 2020-10-07 17:45:46 --> Database Driver Class Initialized
INFO - 2020-10-07 17:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:45:46 --> Email Class Initialized
INFO - 2020-10-07 17:45:46 --> Controller Class Initialized
DEBUG - 2020-10-07 17:45:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:45:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:45:46 --> Model Class Initialized
INFO - 2020-10-07 17:45:46 --> Model Class Initialized
INFO - 2020-10-07 17:45:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 17:45:46 --> Final output sent to browser
DEBUG - 2020-10-07 17:45:46 --> Total execution time: 0.0212
ERROR - 2020-10-07 17:46:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:46:52 --> Config Class Initialized
INFO - 2020-10-07 17:46:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:46:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:46:52 --> Utf8 Class Initialized
INFO - 2020-10-07 17:46:52 --> URI Class Initialized
INFO - 2020-10-07 17:46:52 --> Router Class Initialized
INFO - 2020-10-07 17:46:52 --> Output Class Initialized
INFO - 2020-10-07 17:46:52 --> Security Class Initialized
DEBUG - 2020-10-07 17:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:46:52 --> Input Class Initialized
INFO - 2020-10-07 17:46:52 --> Language Class Initialized
INFO - 2020-10-07 17:46:52 --> Loader Class Initialized
INFO - 2020-10-07 17:46:52 --> Helper loaded: url_helper
INFO - 2020-10-07 17:46:52 --> Database Driver Class Initialized
INFO - 2020-10-07 17:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:46:52 --> Email Class Initialized
INFO - 2020-10-07 17:46:52 --> Controller Class Initialized
DEBUG - 2020-10-07 17:46:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:46:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:46:52 --> Model Class Initialized
INFO - 2020-10-07 17:46:52 --> Model Class Initialized
INFO - 2020-10-07 17:46:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:46:52 --> Final output sent to browser
DEBUG - 2020-10-07 17:46:52 --> Total execution time: 0.0217
ERROR - 2020-10-07 17:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:46:58 --> Config Class Initialized
INFO - 2020-10-07 17:46:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:46:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:46:58 --> Utf8 Class Initialized
INFO - 2020-10-07 17:46:58 --> URI Class Initialized
INFO - 2020-10-07 17:46:58 --> Router Class Initialized
INFO - 2020-10-07 17:46:58 --> Output Class Initialized
INFO - 2020-10-07 17:46:58 --> Security Class Initialized
DEBUG - 2020-10-07 17:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:46:58 --> Input Class Initialized
INFO - 2020-10-07 17:46:58 --> Language Class Initialized
INFO - 2020-10-07 17:46:58 --> Loader Class Initialized
INFO - 2020-10-07 17:46:58 --> Helper loaded: url_helper
INFO - 2020-10-07 17:46:58 --> Database Driver Class Initialized
INFO - 2020-10-07 17:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:46:58 --> Email Class Initialized
INFO - 2020-10-07 17:46:58 --> Controller Class Initialized
DEBUG - 2020-10-07 17:46:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:46:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:46:58 --> Model Class Initialized
INFO - 2020-10-07 17:46:58 --> Model Class Initialized
INFO - 2020-10-07 17:46:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 17:46:58 --> Final output sent to browser
DEBUG - 2020-10-07 17:46:58 --> Total execution time: 0.0238
ERROR - 2020-10-07 17:53:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:53:25 --> Config Class Initialized
INFO - 2020-10-07 17:53:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:53:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:53:25 --> Utf8 Class Initialized
INFO - 2020-10-07 17:53:25 --> URI Class Initialized
INFO - 2020-10-07 17:53:25 --> Router Class Initialized
INFO - 2020-10-07 17:53:25 --> Output Class Initialized
INFO - 2020-10-07 17:53:25 --> Security Class Initialized
DEBUG - 2020-10-07 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:53:25 --> Input Class Initialized
INFO - 2020-10-07 17:53:25 --> Language Class Initialized
INFO - 2020-10-07 17:53:25 --> Loader Class Initialized
INFO - 2020-10-07 17:53:25 --> Helper loaded: url_helper
INFO - 2020-10-07 17:53:25 --> Database Driver Class Initialized
INFO - 2020-10-07 17:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:53:25 --> Email Class Initialized
INFO - 2020-10-07 17:53:25 --> Controller Class Initialized
DEBUG - 2020-10-07 17:53:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:53:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:53:25 --> Model Class Initialized
INFO - 2020-10-07 17:53:25 --> Model Class Initialized
INFO - 2020-10-07 17:53:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 17:53:25 --> Final output sent to browser
DEBUG - 2020-10-07 17:53:25 --> Total execution time: 0.0201
ERROR - 2020-10-07 17:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:53:27 --> Config Class Initialized
INFO - 2020-10-07 17:53:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:53:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:53:27 --> Utf8 Class Initialized
INFO - 2020-10-07 17:53:27 --> URI Class Initialized
INFO - 2020-10-07 17:53:27 --> Router Class Initialized
INFO - 2020-10-07 17:53:27 --> Output Class Initialized
INFO - 2020-10-07 17:53:27 --> Security Class Initialized
DEBUG - 2020-10-07 17:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:53:27 --> Input Class Initialized
INFO - 2020-10-07 17:53:27 --> Language Class Initialized
INFO - 2020-10-07 17:53:27 --> Loader Class Initialized
INFO - 2020-10-07 17:53:27 --> Helper loaded: url_helper
INFO - 2020-10-07 17:53:27 --> Database Driver Class Initialized
INFO - 2020-10-07 17:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:53:27 --> Email Class Initialized
INFO - 2020-10-07 17:53:27 --> Controller Class Initialized
DEBUG - 2020-10-07 17:53:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:53:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:53:27 --> Model Class Initialized
INFO - 2020-10-07 17:53:27 --> Model Class Initialized
INFO - 2020-10-07 17:53:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 17:53:27 --> Final output sent to browser
DEBUG - 2020-10-07 17:53:27 --> Total execution time: 0.0208
ERROR - 2020-10-07 17:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:53:28 --> Config Class Initialized
INFO - 2020-10-07 17:53:28 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:53:28 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:53:28 --> Utf8 Class Initialized
INFO - 2020-10-07 17:53:28 --> URI Class Initialized
INFO - 2020-10-07 17:53:28 --> Router Class Initialized
INFO - 2020-10-07 17:53:28 --> Output Class Initialized
INFO - 2020-10-07 17:53:28 --> Security Class Initialized
DEBUG - 2020-10-07 17:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:53:28 --> Input Class Initialized
INFO - 2020-10-07 17:53:28 --> Language Class Initialized
ERROR - 2020-10-07 17:53:28 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 17:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:55:27 --> Config Class Initialized
INFO - 2020-10-07 17:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:55:27 --> Utf8 Class Initialized
INFO - 2020-10-07 17:55:27 --> URI Class Initialized
INFO - 2020-10-07 17:55:27 --> Router Class Initialized
INFO - 2020-10-07 17:55:27 --> Output Class Initialized
INFO - 2020-10-07 17:55:27 --> Security Class Initialized
DEBUG - 2020-10-07 17:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:55:27 --> Input Class Initialized
INFO - 2020-10-07 17:55:27 --> Language Class Initialized
INFO - 2020-10-07 17:55:27 --> Loader Class Initialized
INFO - 2020-10-07 17:55:27 --> Helper loaded: url_helper
INFO - 2020-10-07 17:55:27 --> Database Driver Class Initialized
INFO - 2020-10-07 17:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:55:27 --> Email Class Initialized
INFO - 2020-10-07 17:55:27 --> Controller Class Initialized
DEBUG - 2020-10-07 17:55:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:55:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:55:27 --> Model Class Initialized
INFO - 2020-10-07 17:55:27 --> Model Class Initialized
INFO - 2020-10-07 17:55:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 17:55:27 --> Final output sent to browser
DEBUG - 2020-10-07 17:55:27 --> Total execution time: 0.0245
ERROR - 2020-10-07 17:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:55:27 --> Config Class Initialized
INFO - 2020-10-07 17:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:55:27 --> Utf8 Class Initialized
INFO - 2020-10-07 17:55:27 --> URI Class Initialized
INFO - 2020-10-07 17:55:27 --> Router Class Initialized
INFO - 2020-10-07 17:55:27 --> Output Class Initialized
INFO - 2020-10-07 17:55:27 --> Security Class Initialized
DEBUG - 2020-10-07 17:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:55:27 --> Input Class Initialized
INFO - 2020-10-07 17:55:27 --> Language Class Initialized
ERROR - 2020-10-07 17:55:27 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 17:56:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:56:25 --> Config Class Initialized
INFO - 2020-10-07 17:56:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:56:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:56:25 --> Utf8 Class Initialized
INFO - 2020-10-07 17:56:25 --> URI Class Initialized
INFO - 2020-10-07 17:56:25 --> Router Class Initialized
INFO - 2020-10-07 17:56:25 --> Output Class Initialized
INFO - 2020-10-07 17:56:25 --> Security Class Initialized
DEBUG - 2020-10-07 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:56:25 --> Input Class Initialized
INFO - 2020-10-07 17:56:25 --> Language Class Initialized
INFO - 2020-10-07 17:56:25 --> Loader Class Initialized
INFO - 2020-10-07 17:56:25 --> Helper loaded: url_helper
INFO - 2020-10-07 17:56:25 --> Database Driver Class Initialized
INFO - 2020-10-07 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:56:25 --> Email Class Initialized
INFO - 2020-10-07 17:56:25 --> Controller Class Initialized
DEBUG - 2020-10-07 17:56:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:56:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:56:25 --> Model Class Initialized
INFO - 2020-10-07 17:56:25 --> Model Class Initialized
INFO - 2020-10-07 17:56:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 17:56:25 --> Final output sent to browser
DEBUG - 2020-10-07 17:56:25 --> Total execution time: 0.0193
ERROR - 2020-10-07 17:56:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:56:25 --> Config Class Initialized
INFO - 2020-10-07 17:56:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:56:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:56:25 --> Utf8 Class Initialized
INFO - 2020-10-07 17:56:25 --> URI Class Initialized
INFO - 2020-10-07 17:56:25 --> Router Class Initialized
INFO - 2020-10-07 17:56:25 --> Output Class Initialized
INFO - 2020-10-07 17:56:25 --> Security Class Initialized
DEBUG - 2020-10-07 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:56:25 --> Input Class Initialized
INFO - 2020-10-07 17:56:25 --> Language Class Initialized
ERROR - 2020-10-07 17:56:25 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 17:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:58:02 --> Config Class Initialized
INFO - 2020-10-07 17:58:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:58:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:58:02 --> Utf8 Class Initialized
INFO - 2020-10-07 17:58:02 --> URI Class Initialized
INFO - 2020-10-07 17:58:02 --> Router Class Initialized
INFO - 2020-10-07 17:58:02 --> Output Class Initialized
INFO - 2020-10-07 17:58:02 --> Security Class Initialized
DEBUG - 2020-10-07 17:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:58:02 --> Input Class Initialized
INFO - 2020-10-07 17:58:02 --> Language Class Initialized
INFO - 2020-10-07 17:58:02 --> Loader Class Initialized
INFO - 2020-10-07 17:58:02 --> Helper loaded: url_helper
INFO - 2020-10-07 17:58:02 --> Database Driver Class Initialized
INFO - 2020-10-07 17:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:58:02 --> Email Class Initialized
INFO - 2020-10-07 17:58:02 --> Controller Class Initialized
DEBUG - 2020-10-07 17:58:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:58:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:58:02 --> Model Class Initialized
INFO - 2020-10-07 17:58:02 --> Model Class Initialized
INFO - 2020-10-07 17:58:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 17:58:02 --> Final output sent to browser
DEBUG - 2020-10-07 17:58:02 --> Total execution time: 0.0208
ERROR - 2020-10-07 17:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:58:05 --> Config Class Initialized
INFO - 2020-10-07 17:58:05 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:58:05 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:58:05 --> Utf8 Class Initialized
INFO - 2020-10-07 17:58:05 --> URI Class Initialized
INFO - 2020-10-07 17:58:05 --> Router Class Initialized
INFO - 2020-10-07 17:58:05 --> Output Class Initialized
INFO - 2020-10-07 17:58:05 --> Security Class Initialized
DEBUG - 2020-10-07 17:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:58:05 --> Input Class Initialized
INFO - 2020-10-07 17:58:05 --> Language Class Initialized
INFO - 2020-10-07 17:58:05 --> Loader Class Initialized
INFO - 2020-10-07 17:58:05 --> Helper loaded: url_helper
INFO - 2020-10-07 17:58:05 --> Database Driver Class Initialized
INFO - 2020-10-07 17:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:58:05 --> Email Class Initialized
INFO - 2020-10-07 17:58:05 --> Controller Class Initialized
DEBUG - 2020-10-07 17:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:58:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:58:05 --> Model Class Initialized
INFO - 2020-10-07 17:58:05 --> Model Class Initialized
INFO - 2020-10-07 17:58:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 17:58:05 --> Final output sent to browser
DEBUG - 2020-10-07 17:58:05 --> Total execution time: 0.0242
ERROR - 2020-10-07 17:58:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:58:05 --> Config Class Initialized
INFO - 2020-10-07 17:58:05 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:58:05 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:58:05 --> Utf8 Class Initialized
INFO - 2020-10-07 17:58:05 --> URI Class Initialized
INFO - 2020-10-07 17:58:05 --> Router Class Initialized
INFO - 2020-10-07 17:58:05 --> Output Class Initialized
INFO - 2020-10-07 17:58:05 --> Security Class Initialized
DEBUG - 2020-10-07 17:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:58:05 --> Input Class Initialized
INFO - 2020-10-07 17:58:05 --> Language Class Initialized
INFO - 2020-10-07 17:58:05 --> Loader Class Initialized
INFO - 2020-10-07 17:58:05 --> Helper loaded: url_helper
INFO - 2020-10-07 17:58:05 --> Database Driver Class Initialized
INFO - 2020-10-07 17:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:58:05 --> Email Class Initialized
INFO - 2020-10-07 17:58:05 --> Controller Class Initialized
DEBUG - 2020-10-07 17:58:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:58:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:58:05 --> Model Class Initialized
INFO - 2020-10-07 17:58:05 --> Model Class Initialized
INFO - 2020-10-07 17:58:05 --> Final output sent to browser
DEBUG - 2020-10-07 17:58:05 --> Total execution time: 0.0250
ERROR - 2020-10-07 17:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:58:13 --> Config Class Initialized
INFO - 2020-10-07 17:58:13 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:58:13 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:58:13 --> Utf8 Class Initialized
INFO - 2020-10-07 17:58:13 --> URI Class Initialized
INFO - 2020-10-07 17:58:13 --> Router Class Initialized
INFO - 2020-10-07 17:58:13 --> Output Class Initialized
INFO - 2020-10-07 17:58:13 --> Security Class Initialized
DEBUG - 2020-10-07 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:58:13 --> Input Class Initialized
INFO - 2020-10-07 17:58:13 --> Language Class Initialized
INFO - 2020-10-07 17:58:13 --> Loader Class Initialized
INFO - 2020-10-07 17:58:13 --> Helper loaded: url_helper
INFO - 2020-10-07 17:58:13 --> Database Driver Class Initialized
INFO - 2020-10-07 17:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:58:13 --> Email Class Initialized
INFO - 2020-10-07 17:58:13 --> Controller Class Initialized
DEBUG - 2020-10-07 17:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:58:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:58:13 --> Model Class Initialized
INFO - 2020-10-07 17:58:13 --> Model Class Initialized
INFO - 2020-10-07 17:58:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 17:58:13 --> Final output sent to browser
DEBUG - 2020-10-07 17:58:13 --> Total execution time: 0.0205
ERROR - 2020-10-07 17:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:59:16 --> Config Class Initialized
INFO - 2020-10-07 17:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:59:16 --> Utf8 Class Initialized
INFO - 2020-10-07 17:59:16 --> URI Class Initialized
INFO - 2020-10-07 17:59:16 --> Router Class Initialized
INFO - 2020-10-07 17:59:16 --> Output Class Initialized
INFO - 2020-10-07 17:59:16 --> Security Class Initialized
DEBUG - 2020-10-07 17:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:59:16 --> Input Class Initialized
INFO - 2020-10-07 17:59:16 --> Language Class Initialized
INFO - 2020-10-07 17:59:16 --> Loader Class Initialized
INFO - 2020-10-07 17:59:16 --> Helper loaded: url_helper
INFO - 2020-10-07 17:59:16 --> Database Driver Class Initialized
INFO - 2020-10-07 17:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:59:16 --> Email Class Initialized
INFO - 2020-10-07 17:59:16 --> Controller Class Initialized
DEBUG - 2020-10-07 17:59:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:59:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:59:16 --> Model Class Initialized
INFO - 2020-10-07 17:59:16 --> Model Class Initialized
INFO - 2020-10-07 17:59:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 17:59:16 --> Final output sent to browser
DEBUG - 2020-10-07 17:59:16 --> Total execution time: 0.0229
ERROR - 2020-10-07 17:59:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:59:18 --> Config Class Initialized
INFO - 2020-10-07 17:59:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:59:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:59:18 --> Utf8 Class Initialized
INFO - 2020-10-07 17:59:18 --> URI Class Initialized
INFO - 2020-10-07 17:59:18 --> Router Class Initialized
INFO - 2020-10-07 17:59:18 --> Output Class Initialized
INFO - 2020-10-07 17:59:18 --> Security Class Initialized
DEBUG - 2020-10-07 17:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:59:18 --> Input Class Initialized
INFO - 2020-10-07 17:59:18 --> Language Class Initialized
INFO - 2020-10-07 17:59:18 --> Loader Class Initialized
INFO - 2020-10-07 17:59:18 --> Helper loaded: url_helper
INFO - 2020-10-07 17:59:18 --> Database Driver Class Initialized
INFO - 2020-10-07 17:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 17:59:18 --> Email Class Initialized
INFO - 2020-10-07 17:59:18 --> Controller Class Initialized
DEBUG - 2020-10-07 17:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 17:59:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 17:59:18 --> Model Class Initialized
INFO - 2020-10-07 17:59:18 --> Model Class Initialized
INFO - 2020-10-07 17:59:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 17:59:18 --> Final output sent to browser
DEBUG - 2020-10-07 17:59:18 --> Total execution time: 0.0219
ERROR - 2020-10-07 17:59:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 17:59:19 --> Config Class Initialized
INFO - 2020-10-07 17:59:19 --> Hooks Class Initialized
DEBUG - 2020-10-07 17:59:19 --> UTF-8 Support Enabled
INFO - 2020-10-07 17:59:19 --> Utf8 Class Initialized
INFO - 2020-10-07 17:59:19 --> URI Class Initialized
INFO - 2020-10-07 17:59:19 --> Router Class Initialized
INFO - 2020-10-07 17:59:19 --> Output Class Initialized
INFO - 2020-10-07 17:59:19 --> Security Class Initialized
DEBUG - 2020-10-07 17:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 17:59:19 --> Input Class Initialized
INFO - 2020-10-07 17:59:19 --> Language Class Initialized
ERROR - 2020-10-07 17:59:19 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 18:05:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:05:12 --> Config Class Initialized
INFO - 2020-10-07 18:05:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:05:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:05:12 --> Utf8 Class Initialized
INFO - 2020-10-07 18:05:12 --> URI Class Initialized
INFO - 2020-10-07 18:05:12 --> Router Class Initialized
INFO - 2020-10-07 18:05:12 --> Output Class Initialized
INFO - 2020-10-07 18:05:12 --> Security Class Initialized
DEBUG - 2020-10-07 18:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:05:12 --> Input Class Initialized
INFO - 2020-10-07 18:05:12 --> Language Class Initialized
INFO - 2020-10-07 18:05:12 --> Loader Class Initialized
INFO - 2020-10-07 18:05:12 --> Helper loaded: url_helper
INFO - 2020-10-07 18:05:12 --> Database Driver Class Initialized
INFO - 2020-10-07 18:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:05:12 --> Email Class Initialized
INFO - 2020-10-07 18:05:12 --> Controller Class Initialized
DEBUG - 2020-10-07 18:05:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:05:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:05:12 --> Model Class Initialized
INFO - 2020-10-07 18:05:12 --> Model Class Initialized
INFO - 2020-10-07 18:05:12 --> Final output sent to browser
DEBUG - 2020-10-07 18:05:12 --> Total execution time: 0.0213
ERROR - 2020-10-07 18:05:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:05:16 --> Config Class Initialized
INFO - 2020-10-07 18:05:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:05:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:05:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:05:16 --> URI Class Initialized
INFO - 2020-10-07 18:05:16 --> Router Class Initialized
INFO - 2020-10-07 18:05:16 --> Output Class Initialized
INFO - 2020-10-07 18:05:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:05:16 --> Input Class Initialized
INFO - 2020-10-07 18:05:16 --> Language Class Initialized
INFO - 2020-10-07 18:05:16 --> Loader Class Initialized
INFO - 2020-10-07 18:05:16 --> Helper loaded: url_helper
INFO - 2020-10-07 18:05:16 --> Database Driver Class Initialized
INFO - 2020-10-07 18:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:05:16 --> Email Class Initialized
INFO - 2020-10-07 18:05:16 --> Controller Class Initialized
DEBUG - 2020-10-07 18:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:05:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:05:16 --> Model Class Initialized
INFO - 2020-10-07 18:05:16 --> Model Class Initialized
INFO - 2020-10-07 18:05:16 --> Final output sent to browser
DEBUG - 2020-10-07 18:05:16 --> Total execution time: 0.0238
ERROR - 2020-10-07 18:05:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:05:32 --> Config Class Initialized
INFO - 2020-10-07 18:05:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:05:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:05:32 --> Utf8 Class Initialized
INFO - 2020-10-07 18:05:32 --> URI Class Initialized
INFO - 2020-10-07 18:05:32 --> Router Class Initialized
INFO - 2020-10-07 18:05:32 --> Output Class Initialized
INFO - 2020-10-07 18:05:32 --> Security Class Initialized
DEBUG - 2020-10-07 18:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:05:32 --> Input Class Initialized
INFO - 2020-10-07 18:05:32 --> Language Class Initialized
INFO - 2020-10-07 18:05:32 --> Loader Class Initialized
INFO - 2020-10-07 18:05:32 --> Helper loaded: url_helper
INFO - 2020-10-07 18:05:32 --> Database Driver Class Initialized
INFO - 2020-10-07 18:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:05:32 --> Email Class Initialized
INFO - 2020-10-07 18:05:32 --> Controller Class Initialized
DEBUG - 2020-10-07 18:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:05:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:05:32 --> Model Class Initialized
INFO - 2020-10-07 18:05:32 --> Model Class Initialized
INFO - 2020-10-07 18:05:32 --> Model Class Initialized
INFO - 2020-10-07 18:05:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:05:32 --> Final output sent to browser
DEBUG - 2020-10-07 18:05:32 --> Total execution time: 0.0681
ERROR - 2020-10-07 18:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:05:38 --> Config Class Initialized
INFO - 2020-10-07 18:05:38 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:05:38 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:05:38 --> Utf8 Class Initialized
INFO - 2020-10-07 18:05:38 --> URI Class Initialized
INFO - 2020-10-07 18:05:38 --> Router Class Initialized
INFO - 2020-10-07 18:05:38 --> Output Class Initialized
INFO - 2020-10-07 18:05:38 --> Security Class Initialized
DEBUG - 2020-10-07 18:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:05:38 --> Input Class Initialized
INFO - 2020-10-07 18:05:38 --> Language Class Initialized
INFO - 2020-10-07 18:05:38 --> Loader Class Initialized
INFO - 2020-10-07 18:05:38 --> Helper loaded: url_helper
INFO - 2020-10-07 18:05:38 --> Database Driver Class Initialized
INFO - 2020-10-07 18:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:05:38 --> Email Class Initialized
INFO - 2020-10-07 18:05:38 --> Controller Class Initialized
DEBUG - 2020-10-07 18:05:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:05:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:05:38 --> Model Class Initialized
INFO - 2020-10-07 18:05:38 --> Model Class Initialized
INFO - 2020-10-07 18:05:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:05:38 --> Final output sent to browser
DEBUG - 2020-10-07 18:05:38 --> Total execution time: 0.0255
ERROR - 2020-10-07 18:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:05:39 --> Config Class Initialized
INFO - 2020-10-07 18:05:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:05:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:05:39 --> Utf8 Class Initialized
INFO - 2020-10-07 18:05:39 --> URI Class Initialized
INFO - 2020-10-07 18:05:39 --> Router Class Initialized
INFO - 2020-10-07 18:05:39 --> Output Class Initialized
INFO - 2020-10-07 18:05:39 --> Security Class Initialized
DEBUG - 2020-10-07 18:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:05:39 --> Input Class Initialized
INFO - 2020-10-07 18:05:39 --> Language Class Initialized
INFO - 2020-10-07 18:05:39 --> Loader Class Initialized
INFO - 2020-10-07 18:05:39 --> Helper loaded: url_helper
INFO - 2020-10-07 18:05:39 --> Database Driver Class Initialized
INFO - 2020-10-07 18:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:05:39 --> Email Class Initialized
INFO - 2020-10-07 18:05:39 --> Controller Class Initialized
DEBUG - 2020-10-07 18:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:05:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:05:39 --> Model Class Initialized
INFO - 2020-10-07 18:05:39 --> Model Class Initialized
INFO - 2020-10-07 18:05:39 --> Final output sent to browser
DEBUG - 2020-10-07 18:05:39 --> Total execution time: 0.0187
ERROR - 2020-10-07 18:07:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:15 --> Config Class Initialized
INFO - 2020-10-07 18:07:15 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:15 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:15 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:15 --> URI Class Initialized
INFO - 2020-10-07 18:07:15 --> Router Class Initialized
INFO - 2020-10-07 18:07:15 --> Output Class Initialized
INFO - 2020-10-07 18:07:15 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:15 --> Input Class Initialized
INFO - 2020-10-07 18:07:15 --> Language Class Initialized
INFO - 2020-10-07 18:07:15 --> Loader Class Initialized
INFO - 2020-10-07 18:07:15 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:15 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:15 --> Email Class Initialized
INFO - 2020-10-07 18:07:15 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:15 --> Model Class Initialized
INFO - 2020-10-07 18:07:15 --> Model Class Initialized
INFO - 2020-10-07 18:07:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:07:15 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:15 --> Total execution time: 0.0201
ERROR - 2020-10-07 18:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:16 --> Config Class Initialized
INFO - 2020-10-07 18:07:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:16 --> URI Class Initialized
INFO - 2020-10-07 18:07:16 --> Router Class Initialized
INFO - 2020-10-07 18:07:16 --> Output Class Initialized
INFO - 2020-10-07 18:07:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:16 --> Input Class Initialized
INFO - 2020-10-07 18:07:16 --> Language Class Initialized
INFO - 2020-10-07 18:07:16 --> Loader Class Initialized
INFO - 2020-10-07 18:07:16 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:16 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:16 --> Email Class Initialized
INFO - 2020-10-07 18:07:16 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:16 --> Model Class Initialized
INFO - 2020-10-07 18:07:16 --> Model Class Initialized
INFO - 2020-10-07 18:07:16 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:16 --> Total execution time: 0.0238
ERROR - 2020-10-07 18:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:18 --> Config Class Initialized
INFO - 2020-10-07 18:07:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:18 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:18 --> URI Class Initialized
INFO - 2020-10-07 18:07:18 --> Router Class Initialized
INFO - 2020-10-07 18:07:18 --> Output Class Initialized
INFO - 2020-10-07 18:07:18 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:18 --> Input Class Initialized
INFO - 2020-10-07 18:07:18 --> Language Class Initialized
INFO - 2020-10-07 18:07:18 --> Loader Class Initialized
INFO - 2020-10-07 18:07:18 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:18 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:18 --> Email Class Initialized
INFO - 2020-10-07 18:07:18 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:18 --> Model Class Initialized
INFO - 2020-10-07 18:07:18 --> Model Class Initialized
INFO - 2020-10-07 18:07:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:07:18 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:18 --> Total execution time: 0.0205
ERROR - 2020-10-07 18:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:20 --> Config Class Initialized
INFO - 2020-10-07 18:07:20 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:20 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:20 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:20 --> URI Class Initialized
INFO - 2020-10-07 18:07:20 --> Router Class Initialized
INFO - 2020-10-07 18:07:20 --> Output Class Initialized
INFO - 2020-10-07 18:07:20 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:20 --> Input Class Initialized
INFO - 2020-10-07 18:07:20 --> Language Class Initialized
INFO - 2020-10-07 18:07:20 --> Loader Class Initialized
INFO - 2020-10-07 18:07:20 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:20 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:20 --> Email Class Initialized
INFO - 2020-10-07 18:07:20 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:20 --> Model Class Initialized
INFO - 2020-10-07 18:07:20 --> Model Class Initialized
INFO - 2020-10-07 18:07:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 18:07:20 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:20 --> Total execution time: 0.0220
ERROR - 2020-10-07 18:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:20 --> Config Class Initialized
INFO - 2020-10-07 18:07:20 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:20 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:20 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:20 --> URI Class Initialized
INFO - 2020-10-07 18:07:20 --> Router Class Initialized
INFO - 2020-10-07 18:07:20 --> Output Class Initialized
INFO - 2020-10-07 18:07:20 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:20 --> Input Class Initialized
INFO - 2020-10-07 18:07:20 --> Language Class Initialized
ERROR - 2020-10-07 18:07:20 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 18:07:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:32 --> Config Class Initialized
INFO - 2020-10-07 18:07:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:32 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:32 --> URI Class Initialized
INFO - 2020-10-07 18:07:32 --> Router Class Initialized
INFO - 2020-10-07 18:07:32 --> Output Class Initialized
INFO - 2020-10-07 18:07:32 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:32 --> Input Class Initialized
INFO - 2020-10-07 18:07:32 --> Language Class Initialized
INFO - 2020-10-07 18:07:32 --> Loader Class Initialized
INFO - 2020-10-07 18:07:32 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:32 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:32 --> Email Class Initialized
INFO - 2020-10-07 18:07:32 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:32 --> Model Class Initialized
INFO - 2020-10-07 18:07:32 --> Model Class Initialized
INFO - 2020-10-07 18:07:32 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:32 --> Total execution time: 0.0275
ERROR - 2020-10-07 18:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:51 --> Config Class Initialized
INFO - 2020-10-07 18:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:51 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:51 --> URI Class Initialized
INFO - 2020-10-07 18:07:51 --> Router Class Initialized
INFO - 2020-10-07 18:07:51 --> Output Class Initialized
INFO - 2020-10-07 18:07:51 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:51 --> Input Class Initialized
INFO - 2020-10-07 18:07:51 --> Language Class Initialized
INFO - 2020-10-07 18:07:51 --> Loader Class Initialized
INFO - 2020-10-07 18:07:51 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:51 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:51 --> Email Class Initialized
INFO - 2020-10-07 18:07:51 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:51 --> Model Class Initialized
INFO - 2020-10-07 18:07:51 --> Model Class Initialized
INFO - 2020-10-07 18:07:51 --> Model Class Initialized
INFO - 2020-10-07 18:07:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:07:51 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:51 --> Total execution time: 0.0612
ERROR - 2020-10-07 18:07:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:56 --> Config Class Initialized
INFO - 2020-10-07 18:07:56 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:56 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:56 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:56 --> URI Class Initialized
INFO - 2020-10-07 18:07:56 --> Router Class Initialized
INFO - 2020-10-07 18:07:56 --> Output Class Initialized
INFO - 2020-10-07 18:07:56 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:56 --> Input Class Initialized
INFO - 2020-10-07 18:07:56 --> Language Class Initialized
INFO - 2020-10-07 18:07:56 --> Loader Class Initialized
INFO - 2020-10-07 18:07:56 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:56 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:56 --> Email Class Initialized
INFO - 2020-10-07 18:07:56 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:56 --> Model Class Initialized
INFO - 2020-10-07 18:07:56 --> Model Class Initialized
INFO - 2020-10-07 18:07:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:07:56 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:56 --> Total execution time: 0.0235
ERROR - 2020-10-07 18:07:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:07:56 --> Config Class Initialized
INFO - 2020-10-07 18:07:56 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:07:56 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:07:56 --> Utf8 Class Initialized
INFO - 2020-10-07 18:07:56 --> URI Class Initialized
INFO - 2020-10-07 18:07:56 --> Router Class Initialized
INFO - 2020-10-07 18:07:56 --> Output Class Initialized
INFO - 2020-10-07 18:07:56 --> Security Class Initialized
DEBUG - 2020-10-07 18:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:07:56 --> Input Class Initialized
INFO - 2020-10-07 18:07:56 --> Language Class Initialized
INFO - 2020-10-07 18:07:56 --> Loader Class Initialized
INFO - 2020-10-07 18:07:56 --> Helper loaded: url_helper
INFO - 2020-10-07 18:07:56 --> Database Driver Class Initialized
INFO - 2020-10-07 18:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:07:56 --> Email Class Initialized
INFO - 2020-10-07 18:07:56 --> Controller Class Initialized
DEBUG - 2020-10-07 18:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:07:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:07:56 --> Model Class Initialized
INFO - 2020-10-07 18:07:56 --> Model Class Initialized
INFO - 2020-10-07 18:07:56 --> Final output sent to browser
DEBUG - 2020-10-07 18:07:56 --> Total execution time: 0.0240
ERROR - 2020-10-07 18:08:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:24 --> Config Class Initialized
INFO - 2020-10-07 18:08:24 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:24 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:24 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:24 --> URI Class Initialized
INFO - 2020-10-07 18:08:24 --> Router Class Initialized
INFO - 2020-10-07 18:08:24 --> Output Class Initialized
INFO - 2020-10-07 18:08:24 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:24 --> Input Class Initialized
INFO - 2020-10-07 18:08:24 --> Language Class Initialized
INFO - 2020-10-07 18:08:24 --> Loader Class Initialized
INFO - 2020-10-07 18:08:24 --> Helper loaded: url_helper
INFO - 2020-10-07 18:08:24 --> Database Driver Class Initialized
INFO - 2020-10-07 18:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:08:24 --> Email Class Initialized
INFO - 2020-10-07 18:08:24 --> Controller Class Initialized
DEBUG - 2020-10-07 18:08:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:08:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:08:24 --> Model Class Initialized
INFO - 2020-10-07 18:08:24 --> Model Class Initialized
INFO - 2020-10-07 18:08:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:08:24 --> Final output sent to browser
DEBUG - 2020-10-07 18:08:24 --> Total execution time: 0.0226
ERROR - 2020-10-07 18:08:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:26 --> Config Class Initialized
INFO - 2020-10-07 18:08:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:26 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:26 --> URI Class Initialized
INFO - 2020-10-07 18:08:26 --> Router Class Initialized
INFO - 2020-10-07 18:08:26 --> Output Class Initialized
INFO - 2020-10-07 18:08:26 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:26 --> Input Class Initialized
INFO - 2020-10-07 18:08:26 --> Language Class Initialized
INFO - 2020-10-07 18:08:26 --> Loader Class Initialized
INFO - 2020-10-07 18:08:26 --> Helper loaded: url_helper
INFO - 2020-10-07 18:08:26 --> Database Driver Class Initialized
INFO - 2020-10-07 18:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:08:26 --> Email Class Initialized
INFO - 2020-10-07 18:08:26 --> Controller Class Initialized
DEBUG - 2020-10-07 18:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:08:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:08:26 --> Model Class Initialized
INFO - 2020-10-07 18:08:26 --> Model Class Initialized
INFO - 2020-10-07 18:08:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 18:08:26 --> Final output sent to browser
DEBUG - 2020-10-07 18:08:26 --> Total execution time: 0.0223
ERROR - 2020-10-07 18:08:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:26 --> Config Class Initialized
INFO - 2020-10-07 18:08:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:26 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:26 --> URI Class Initialized
INFO - 2020-10-07 18:08:26 --> Router Class Initialized
INFO - 2020-10-07 18:08:26 --> Output Class Initialized
INFO - 2020-10-07 18:08:26 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:26 --> Input Class Initialized
INFO - 2020-10-07 18:08:26 --> Language Class Initialized
ERROR - 2020-10-07 18:08:26 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 18:08:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:36 --> Config Class Initialized
INFO - 2020-10-07 18:08:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:36 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:36 --> URI Class Initialized
INFO - 2020-10-07 18:08:36 --> Router Class Initialized
INFO - 2020-10-07 18:08:36 --> Output Class Initialized
INFO - 2020-10-07 18:08:36 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:36 --> Input Class Initialized
INFO - 2020-10-07 18:08:36 --> Language Class Initialized
INFO - 2020-10-07 18:08:36 --> Loader Class Initialized
INFO - 2020-10-07 18:08:36 --> Helper loaded: url_helper
INFO - 2020-10-07 18:08:36 --> Database Driver Class Initialized
INFO - 2020-10-07 18:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:08:36 --> Email Class Initialized
INFO - 2020-10-07 18:08:36 --> Controller Class Initialized
DEBUG - 2020-10-07 18:08:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:08:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:08:36 --> Model Class Initialized
INFO - 2020-10-07 18:08:36 --> Model Class Initialized
INFO - 2020-10-07 18:08:36 --> Final output sent to browser
DEBUG - 2020-10-07 18:08:36 --> Total execution time: 0.0223
ERROR - 2020-10-07 18:08:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:46 --> Config Class Initialized
INFO - 2020-10-07 18:08:46 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:46 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:46 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:46 --> URI Class Initialized
INFO - 2020-10-07 18:08:46 --> Router Class Initialized
INFO - 2020-10-07 18:08:46 --> Output Class Initialized
INFO - 2020-10-07 18:08:46 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:46 --> Input Class Initialized
INFO - 2020-10-07 18:08:46 --> Language Class Initialized
INFO - 2020-10-07 18:08:46 --> Loader Class Initialized
INFO - 2020-10-07 18:08:46 --> Helper loaded: url_helper
INFO - 2020-10-07 18:08:46 --> Database Driver Class Initialized
INFO - 2020-10-07 18:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:08:46 --> Email Class Initialized
INFO - 2020-10-07 18:08:46 --> Controller Class Initialized
DEBUG - 2020-10-07 18:08:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:08:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:08:46 --> Model Class Initialized
INFO - 2020-10-07 18:08:46 --> Model Class Initialized
INFO - 2020-10-07 18:08:46 --> Model Class Initialized
INFO - 2020-10-07 18:08:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:08:46 --> Final output sent to browser
DEBUG - 2020-10-07 18:08:46 --> Total execution time: 0.0692
ERROR - 2020-10-07 18:08:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:52 --> Config Class Initialized
INFO - 2020-10-07 18:08:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:52 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:52 --> URI Class Initialized
INFO - 2020-10-07 18:08:52 --> Router Class Initialized
INFO - 2020-10-07 18:08:52 --> Output Class Initialized
INFO - 2020-10-07 18:08:52 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:52 --> Input Class Initialized
INFO - 2020-10-07 18:08:52 --> Language Class Initialized
INFO - 2020-10-07 18:08:52 --> Loader Class Initialized
INFO - 2020-10-07 18:08:52 --> Helper loaded: url_helper
INFO - 2020-10-07 18:08:52 --> Database Driver Class Initialized
INFO - 2020-10-07 18:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:08:52 --> Email Class Initialized
INFO - 2020-10-07 18:08:52 --> Controller Class Initialized
DEBUG - 2020-10-07 18:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:08:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:08:52 --> Model Class Initialized
INFO - 2020-10-07 18:08:52 --> Model Class Initialized
INFO - 2020-10-07 18:08:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:08:52 --> Final output sent to browser
DEBUG - 2020-10-07 18:08:52 --> Total execution time: 0.0214
ERROR - 2020-10-07 18:08:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:08:52 --> Config Class Initialized
INFO - 2020-10-07 18:08:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:08:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:08:52 --> Utf8 Class Initialized
INFO - 2020-10-07 18:08:52 --> URI Class Initialized
INFO - 2020-10-07 18:08:52 --> Router Class Initialized
INFO - 2020-10-07 18:08:52 --> Output Class Initialized
INFO - 2020-10-07 18:08:52 --> Security Class Initialized
DEBUG - 2020-10-07 18:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:08:52 --> Input Class Initialized
INFO - 2020-10-07 18:08:52 --> Language Class Initialized
INFO - 2020-10-07 18:08:52 --> Loader Class Initialized
INFO - 2020-10-07 18:08:52 --> Helper loaded: url_helper
INFO - 2020-10-07 18:08:52 --> Database Driver Class Initialized
INFO - 2020-10-07 18:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:08:52 --> Email Class Initialized
INFO - 2020-10-07 18:08:52 --> Controller Class Initialized
DEBUG - 2020-10-07 18:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:08:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:08:52 --> Model Class Initialized
INFO - 2020-10-07 18:08:52 --> Model Class Initialized
INFO - 2020-10-07 18:08:52 --> Final output sent to browser
DEBUG - 2020-10-07 18:08:52 --> Total execution time: 0.0235
ERROR - 2020-10-07 18:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:10:18 --> Config Class Initialized
INFO - 2020-10-07 18:10:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:10:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:10:18 --> Utf8 Class Initialized
INFO - 2020-10-07 18:10:18 --> URI Class Initialized
INFO - 2020-10-07 18:10:18 --> Router Class Initialized
INFO - 2020-10-07 18:10:18 --> Output Class Initialized
INFO - 2020-10-07 18:10:18 --> Security Class Initialized
DEBUG - 2020-10-07 18:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:10:18 --> Input Class Initialized
INFO - 2020-10-07 18:10:18 --> Language Class Initialized
INFO - 2020-10-07 18:10:18 --> Loader Class Initialized
INFO - 2020-10-07 18:10:18 --> Helper loaded: url_helper
INFO - 2020-10-07 18:10:18 --> Database Driver Class Initialized
INFO - 2020-10-07 18:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:10:18 --> Email Class Initialized
INFO - 2020-10-07 18:10:18 --> Controller Class Initialized
DEBUG - 2020-10-07 18:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:10:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:10:18 --> Model Class Initialized
INFO - 2020-10-07 18:10:18 --> Model Class Initialized
INFO - 2020-10-07 18:10:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:10:18 --> Final output sent to browser
DEBUG - 2020-10-07 18:10:18 --> Total execution time: 0.0207
ERROR - 2020-10-07 18:10:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:10:18 --> Config Class Initialized
INFO - 2020-10-07 18:10:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:10:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:10:18 --> Utf8 Class Initialized
INFO - 2020-10-07 18:10:18 --> URI Class Initialized
INFO - 2020-10-07 18:10:18 --> Router Class Initialized
INFO - 2020-10-07 18:10:18 --> Output Class Initialized
INFO - 2020-10-07 18:10:18 --> Security Class Initialized
DEBUG - 2020-10-07 18:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:10:18 --> Input Class Initialized
INFO - 2020-10-07 18:10:18 --> Language Class Initialized
INFO - 2020-10-07 18:10:18 --> Loader Class Initialized
INFO - 2020-10-07 18:10:18 --> Helper loaded: url_helper
INFO - 2020-10-07 18:10:18 --> Database Driver Class Initialized
INFO - 2020-10-07 18:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:10:18 --> Email Class Initialized
INFO - 2020-10-07 18:10:18 --> Controller Class Initialized
DEBUG - 2020-10-07 18:10:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:10:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:10:18 --> Model Class Initialized
INFO - 2020-10-07 18:10:18 --> Model Class Initialized
INFO - 2020-10-07 18:10:18 --> Final output sent to browser
DEBUG - 2020-10-07 18:10:18 --> Total execution time: 0.0213
ERROR - 2020-10-07 18:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:18:14 --> Config Class Initialized
INFO - 2020-10-07 18:18:14 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:18:14 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:18:14 --> Utf8 Class Initialized
INFO - 2020-10-07 18:18:14 --> URI Class Initialized
INFO - 2020-10-07 18:18:14 --> Router Class Initialized
INFO - 2020-10-07 18:18:14 --> Output Class Initialized
INFO - 2020-10-07 18:18:14 --> Security Class Initialized
DEBUG - 2020-10-07 18:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:18:14 --> Input Class Initialized
INFO - 2020-10-07 18:18:14 --> Language Class Initialized
INFO - 2020-10-07 18:18:14 --> Loader Class Initialized
INFO - 2020-10-07 18:18:14 --> Helper loaded: url_helper
INFO - 2020-10-07 18:18:14 --> Database Driver Class Initialized
INFO - 2020-10-07 18:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:18:14 --> Email Class Initialized
INFO - 2020-10-07 18:18:14 --> Controller Class Initialized
DEBUG - 2020-10-07 18:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:18:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:18:14 --> Model Class Initialized
INFO - 2020-10-07 18:18:14 --> Model Class Initialized
INFO - 2020-10-07 18:18:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:18:14 --> Final output sent to browser
DEBUG - 2020-10-07 18:18:14 --> Total execution time: 0.0239
ERROR - 2020-10-07 18:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:18:16 --> Config Class Initialized
INFO - 2020-10-07 18:18:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:18:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:18:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:18:16 --> URI Class Initialized
INFO - 2020-10-07 18:18:16 --> Router Class Initialized
INFO - 2020-10-07 18:18:16 --> Output Class Initialized
INFO - 2020-10-07 18:18:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:18:16 --> Input Class Initialized
INFO - 2020-10-07 18:18:16 --> Language Class Initialized
INFO - 2020-10-07 18:18:16 --> Loader Class Initialized
INFO - 2020-10-07 18:18:16 --> Helper loaded: url_helper
INFO - 2020-10-07 18:18:16 --> Database Driver Class Initialized
INFO - 2020-10-07 18:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:18:16 --> Email Class Initialized
INFO - 2020-10-07 18:18:16 --> Controller Class Initialized
DEBUG - 2020-10-07 18:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:18:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:18:16 --> Model Class Initialized
INFO - 2020-10-07 18:18:16 --> Model Class Initialized
INFO - 2020-10-07 18:18:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-07 18:18:16 --> Final output sent to browser
DEBUG - 2020-10-07 18:18:16 --> Total execution time: 0.0218
ERROR - 2020-10-07 18:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:18:16 --> Config Class Initialized
INFO - 2020-10-07 18:18:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:18:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:18:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:18:16 --> URI Class Initialized
INFO - 2020-10-07 18:18:16 --> Router Class Initialized
INFO - 2020-10-07 18:18:16 --> Output Class Initialized
INFO - 2020-10-07 18:18:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:18:16 --> Input Class Initialized
INFO - 2020-10-07 18:18:16 --> Language Class Initialized
ERROR - 2020-10-07 18:18:16 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-07 18:18:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:18:26 --> Config Class Initialized
INFO - 2020-10-07 18:18:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:18:26 --> Utf8 Class Initialized
INFO - 2020-10-07 18:18:26 --> URI Class Initialized
INFO - 2020-10-07 18:18:26 --> Router Class Initialized
INFO - 2020-10-07 18:18:26 --> Output Class Initialized
INFO - 2020-10-07 18:18:26 --> Security Class Initialized
DEBUG - 2020-10-07 18:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:18:26 --> Input Class Initialized
INFO - 2020-10-07 18:18:26 --> Language Class Initialized
INFO - 2020-10-07 18:18:26 --> Loader Class Initialized
INFO - 2020-10-07 18:18:26 --> Helper loaded: url_helper
INFO - 2020-10-07 18:18:26 --> Database Driver Class Initialized
INFO - 2020-10-07 18:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:18:26 --> Email Class Initialized
INFO - 2020-10-07 18:18:26 --> Controller Class Initialized
DEBUG - 2020-10-07 18:18:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:18:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:18:26 --> Model Class Initialized
INFO - 2020-10-07 18:18:26 --> Model Class Initialized
INFO - 2020-10-07 18:18:26 --> Final output sent to browser
DEBUG - 2020-10-07 18:18:26 --> Total execution time: 0.0215
ERROR - 2020-10-07 18:18:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:18:53 --> Config Class Initialized
INFO - 2020-10-07 18:18:53 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:18:53 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:18:53 --> Utf8 Class Initialized
INFO - 2020-10-07 18:18:53 --> URI Class Initialized
INFO - 2020-10-07 18:18:53 --> Router Class Initialized
INFO - 2020-10-07 18:18:53 --> Output Class Initialized
INFO - 2020-10-07 18:18:53 --> Security Class Initialized
DEBUG - 2020-10-07 18:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:18:53 --> Input Class Initialized
INFO - 2020-10-07 18:18:53 --> Language Class Initialized
INFO - 2020-10-07 18:18:53 --> Loader Class Initialized
INFO - 2020-10-07 18:18:53 --> Helper loaded: url_helper
INFO - 2020-10-07 18:18:53 --> Database Driver Class Initialized
INFO - 2020-10-07 18:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:18:53 --> Email Class Initialized
INFO - 2020-10-07 18:18:53 --> Controller Class Initialized
DEBUG - 2020-10-07 18:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:18:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:18:53 --> Model Class Initialized
INFO - 2020-10-07 18:18:53 --> Model Class Initialized
INFO - 2020-10-07 18:18:53 --> Model Class Initialized
INFO - 2020-10-07 18:18:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:18:53 --> Final output sent to browser
DEBUG - 2020-10-07 18:18:53 --> Total execution time: 0.0756
ERROR - 2020-10-07 18:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:23 --> Config Class Initialized
INFO - 2020-10-07 18:22:23 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:23 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:23 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:23 --> URI Class Initialized
INFO - 2020-10-07 18:22:23 --> Router Class Initialized
INFO - 2020-10-07 18:22:23 --> Output Class Initialized
INFO - 2020-10-07 18:22:23 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:23 --> Input Class Initialized
INFO - 2020-10-07 18:22:23 --> Language Class Initialized
INFO - 2020-10-07 18:22:23 --> Loader Class Initialized
INFO - 2020-10-07 18:22:23 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:23 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:23 --> Email Class Initialized
INFO - 2020-10-07 18:22:23 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:23 --> Model Class Initialized
INFO - 2020-10-07 18:22:23 --> Model Class Initialized
INFO - 2020-10-07 18:22:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:22:23 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:23 --> Total execution time: 0.0223
ERROR - 2020-10-07 18:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:26 --> Config Class Initialized
INFO - 2020-10-07 18:22:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:26 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:26 --> URI Class Initialized
INFO - 2020-10-07 18:22:26 --> Router Class Initialized
INFO - 2020-10-07 18:22:26 --> Output Class Initialized
INFO - 2020-10-07 18:22:26 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:26 --> Input Class Initialized
INFO - 2020-10-07 18:22:26 --> Language Class Initialized
INFO - 2020-10-07 18:22:26 --> Loader Class Initialized
INFO - 2020-10-07 18:22:26 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:26 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:26 --> Email Class Initialized
INFO - 2020-10-07 18:22:26 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:26 --> Model Class Initialized
INFO - 2020-10-07 18:22:26 --> Model Class Initialized
INFO - 2020-10-07 18:22:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:22:26 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:26 --> Total execution time: 0.0226
ERROR - 2020-10-07 18:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:26 --> Config Class Initialized
INFO - 2020-10-07 18:22:26 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:26 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:26 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:26 --> URI Class Initialized
INFO - 2020-10-07 18:22:26 --> Router Class Initialized
INFO - 2020-10-07 18:22:26 --> Output Class Initialized
INFO - 2020-10-07 18:22:26 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:26 --> Input Class Initialized
INFO - 2020-10-07 18:22:26 --> Language Class Initialized
INFO - 2020-10-07 18:22:26 --> Loader Class Initialized
INFO - 2020-10-07 18:22:26 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:26 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:26 --> Email Class Initialized
INFO - 2020-10-07 18:22:26 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:26 --> Model Class Initialized
INFO - 2020-10-07 18:22:26 --> Model Class Initialized
INFO - 2020-10-07 18:22:26 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:26 --> Total execution time: 0.0251
ERROR - 2020-10-07 18:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:31 --> Config Class Initialized
INFO - 2020-10-07 18:22:31 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:31 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:31 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:31 --> URI Class Initialized
INFO - 2020-10-07 18:22:31 --> Router Class Initialized
INFO - 2020-10-07 18:22:31 --> Output Class Initialized
INFO - 2020-10-07 18:22:31 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:31 --> Input Class Initialized
INFO - 2020-10-07 18:22:31 --> Language Class Initialized
INFO - 2020-10-07 18:22:31 --> Loader Class Initialized
INFO - 2020-10-07 18:22:31 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:31 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:31 --> Email Class Initialized
INFO - 2020-10-07 18:22:31 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:31 --> Model Class Initialized
INFO - 2020-10-07 18:22:31 --> Model Class Initialized
INFO - 2020-10-07 18:22:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:22:31 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:31 --> Total execution time: 0.0255
ERROR - 2020-10-07 18:22:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:36 --> Config Class Initialized
INFO - 2020-10-07 18:22:36 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:36 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:36 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:36 --> URI Class Initialized
INFO - 2020-10-07 18:22:36 --> Router Class Initialized
INFO - 2020-10-07 18:22:36 --> Output Class Initialized
INFO - 2020-10-07 18:22:36 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:36 --> Input Class Initialized
INFO - 2020-10-07 18:22:36 --> Language Class Initialized
INFO - 2020-10-07 18:22:36 --> Loader Class Initialized
INFO - 2020-10-07 18:22:36 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:36 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:36 --> Email Class Initialized
INFO - 2020-10-07 18:22:36 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:36 --> Model Class Initialized
INFO - 2020-10-07 18:22:36 --> Model Class Initialized
INFO - 2020-10-07 18:22:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:22:36 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:36 --> Total execution time: 0.0248
ERROR - 2020-10-07 18:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:37 --> Config Class Initialized
INFO - 2020-10-07 18:22:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:37 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:37 --> URI Class Initialized
INFO - 2020-10-07 18:22:37 --> Router Class Initialized
INFO - 2020-10-07 18:22:37 --> Output Class Initialized
INFO - 2020-10-07 18:22:37 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:37 --> Input Class Initialized
INFO - 2020-10-07 18:22:37 --> Language Class Initialized
INFO - 2020-10-07 18:22:37 --> Loader Class Initialized
INFO - 2020-10-07 18:22:37 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:37 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:37 --> Email Class Initialized
INFO - 2020-10-07 18:22:37 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:37 --> Model Class Initialized
INFO - 2020-10-07 18:22:37 --> Model Class Initialized
INFO - 2020-10-07 18:22:37 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:37 --> Total execution time: 0.0242
ERROR - 2020-10-07 18:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:22:49 --> Config Class Initialized
INFO - 2020-10-07 18:22:49 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:22:49 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:22:49 --> Utf8 Class Initialized
INFO - 2020-10-07 18:22:49 --> URI Class Initialized
INFO - 2020-10-07 18:22:49 --> Router Class Initialized
INFO - 2020-10-07 18:22:49 --> Output Class Initialized
INFO - 2020-10-07 18:22:49 --> Security Class Initialized
DEBUG - 2020-10-07 18:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:22:49 --> Input Class Initialized
INFO - 2020-10-07 18:22:49 --> Language Class Initialized
INFO - 2020-10-07 18:22:49 --> Loader Class Initialized
INFO - 2020-10-07 18:22:49 --> Helper loaded: url_helper
INFO - 2020-10-07 18:22:49 --> Database Driver Class Initialized
INFO - 2020-10-07 18:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:22:49 --> Email Class Initialized
INFO - 2020-10-07 18:22:49 --> Controller Class Initialized
DEBUG - 2020-10-07 18:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:22:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:22:49 --> Model Class Initialized
INFO - 2020-10-07 18:22:49 --> Model Class Initialized
INFO - 2020-10-07 18:22:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:22:49 --> Final output sent to browser
DEBUG - 2020-10-07 18:22:49 --> Total execution time: 0.0201
ERROR - 2020-10-07 18:24:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:24:32 --> Config Class Initialized
INFO - 2020-10-07 18:24:32 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:24:32 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:24:32 --> Utf8 Class Initialized
INFO - 2020-10-07 18:24:32 --> URI Class Initialized
INFO - 2020-10-07 18:24:32 --> Router Class Initialized
INFO - 2020-10-07 18:24:32 --> Output Class Initialized
INFO - 2020-10-07 18:24:32 --> Security Class Initialized
DEBUG - 2020-10-07 18:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:24:32 --> Input Class Initialized
INFO - 2020-10-07 18:24:32 --> Language Class Initialized
INFO - 2020-10-07 18:24:32 --> Loader Class Initialized
INFO - 2020-10-07 18:24:32 --> Helper loaded: url_helper
INFO - 2020-10-07 18:24:32 --> Database Driver Class Initialized
INFO - 2020-10-07 18:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:24:32 --> Email Class Initialized
INFO - 2020-10-07 18:24:32 --> Controller Class Initialized
DEBUG - 2020-10-07 18:24:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:24:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:24:32 --> Model Class Initialized
INFO - 2020-10-07 18:24:32 --> Model Class Initialized
INFO - 2020-10-07 18:24:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:24:32 --> Final output sent to browser
DEBUG - 2020-10-07 18:24:32 --> Total execution time: 0.0206
ERROR - 2020-10-07 18:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:24:37 --> Config Class Initialized
INFO - 2020-10-07 18:24:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:24:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:24:37 --> Utf8 Class Initialized
INFO - 2020-10-07 18:24:37 --> URI Class Initialized
INFO - 2020-10-07 18:24:37 --> Router Class Initialized
INFO - 2020-10-07 18:24:37 --> Output Class Initialized
INFO - 2020-10-07 18:24:37 --> Security Class Initialized
DEBUG - 2020-10-07 18:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:24:37 --> Input Class Initialized
INFO - 2020-10-07 18:24:37 --> Language Class Initialized
INFO - 2020-10-07 18:24:37 --> Loader Class Initialized
INFO - 2020-10-07 18:24:37 --> Helper loaded: url_helper
INFO - 2020-10-07 18:24:37 --> Database Driver Class Initialized
INFO - 2020-10-07 18:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:24:37 --> Email Class Initialized
INFO - 2020-10-07 18:24:37 --> Controller Class Initialized
DEBUG - 2020-10-07 18:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:24:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:24:37 --> Model Class Initialized
INFO - 2020-10-07 18:24:37 --> Model Class Initialized
INFO - 2020-10-07 18:24:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:24:37 --> Final output sent to browser
DEBUG - 2020-10-07 18:24:37 --> Total execution time: 0.0224
ERROR - 2020-10-07 18:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:24:37 --> Config Class Initialized
INFO - 2020-10-07 18:24:37 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:24:37 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:24:37 --> Utf8 Class Initialized
INFO - 2020-10-07 18:24:37 --> URI Class Initialized
INFO - 2020-10-07 18:24:37 --> Router Class Initialized
INFO - 2020-10-07 18:24:37 --> Output Class Initialized
INFO - 2020-10-07 18:24:37 --> Security Class Initialized
DEBUG - 2020-10-07 18:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:24:37 --> Input Class Initialized
INFO - 2020-10-07 18:24:37 --> Language Class Initialized
INFO - 2020-10-07 18:24:37 --> Loader Class Initialized
INFO - 2020-10-07 18:24:37 --> Helper loaded: url_helper
INFO - 2020-10-07 18:24:37 --> Database Driver Class Initialized
INFO - 2020-10-07 18:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:24:37 --> Email Class Initialized
INFO - 2020-10-07 18:24:37 --> Controller Class Initialized
DEBUG - 2020-10-07 18:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:24:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:24:37 --> Model Class Initialized
INFO - 2020-10-07 18:24:37 --> Model Class Initialized
INFO - 2020-10-07 18:24:37 --> Final output sent to browser
DEBUG - 2020-10-07 18:24:37 --> Total execution time: 0.0292
ERROR - 2020-10-07 18:24:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:24:47 --> Config Class Initialized
INFO - 2020-10-07 18:24:47 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:24:47 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:24:47 --> Utf8 Class Initialized
INFO - 2020-10-07 18:24:47 --> URI Class Initialized
INFO - 2020-10-07 18:24:47 --> Router Class Initialized
INFO - 2020-10-07 18:24:47 --> Output Class Initialized
INFO - 2020-10-07 18:24:47 --> Security Class Initialized
DEBUG - 2020-10-07 18:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:24:47 --> Input Class Initialized
INFO - 2020-10-07 18:24:47 --> Language Class Initialized
INFO - 2020-10-07 18:24:47 --> Loader Class Initialized
INFO - 2020-10-07 18:24:47 --> Helper loaded: url_helper
INFO - 2020-10-07 18:24:47 --> Database Driver Class Initialized
INFO - 2020-10-07 18:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:24:47 --> Email Class Initialized
INFO - 2020-10-07 18:24:47 --> Controller Class Initialized
DEBUG - 2020-10-07 18:24:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:24:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:24:47 --> Model Class Initialized
INFO - 2020-10-07 18:24:47 --> Model Class Initialized
INFO - 2020-10-07 18:24:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:24:47 --> Final output sent to browser
DEBUG - 2020-10-07 18:24:47 --> Total execution time: 0.0219
ERROR - 2020-10-07 18:24:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:24:48 --> Config Class Initialized
INFO - 2020-10-07 18:24:48 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:24:48 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:24:48 --> Utf8 Class Initialized
INFO - 2020-10-07 18:24:48 --> URI Class Initialized
INFO - 2020-10-07 18:24:48 --> Router Class Initialized
INFO - 2020-10-07 18:24:48 --> Output Class Initialized
INFO - 2020-10-07 18:24:48 --> Security Class Initialized
DEBUG - 2020-10-07 18:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:24:48 --> Input Class Initialized
INFO - 2020-10-07 18:24:48 --> Language Class Initialized
INFO - 2020-10-07 18:24:48 --> Loader Class Initialized
INFO - 2020-10-07 18:24:48 --> Helper loaded: url_helper
INFO - 2020-10-07 18:24:48 --> Database Driver Class Initialized
INFO - 2020-10-07 18:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:24:48 --> Email Class Initialized
INFO - 2020-10-07 18:24:48 --> Controller Class Initialized
DEBUG - 2020-10-07 18:24:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:24:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:24:48 --> Model Class Initialized
INFO - 2020-10-07 18:24:48 --> Model Class Initialized
INFO - 2020-10-07 18:24:48 --> Final output sent to browser
DEBUG - 2020-10-07 18:24:48 --> Total execution time: 0.0227
ERROR - 2020-10-07 18:25:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:25:03 --> Config Class Initialized
INFO - 2020-10-07 18:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:25:03 --> Utf8 Class Initialized
INFO - 2020-10-07 18:25:03 --> URI Class Initialized
INFO - 2020-10-07 18:25:03 --> Router Class Initialized
INFO - 2020-10-07 18:25:03 --> Output Class Initialized
INFO - 2020-10-07 18:25:03 --> Security Class Initialized
DEBUG - 2020-10-07 18:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:25:03 --> Input Class Initialized
INFO - 2020-10-07 18:25:03 --> Language Class Initialized
INFO - 2020-10-07 18:25:03 --> Loader Class Initialized
INFO - 2020-10-07 18:25:03 --> Helper loaded: url_helper
INFO - 2020-10-07 18:25:03 --> Database Driver Class Initialized
INFO - 2020-10-07 18:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:25:03 --> Email Class Initialized
INFO - 2020-10-07 18:25:03 --> Controller Class Initialized
DEBUG - 2020-10-07 18:25:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:25:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:25:03 --> Model Class Initialized
INFO - 2020-10-07 18:25:03 --> Model Class Initialized
INFO - 2020-10-07 18:25:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:25:03 --> Final output sent to browser
DEBUG - 2020-10-07 18:25:03 --> Total execution time: 0.0244
ERROR - 2020-10-07 18:25:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:25:04 --> Config Class Initialized
INFO - 2020-10-07 18:25:04 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:25:04 --> Utf8 Class Initialized
INFO - 2020-10-07 18:25:04 --> URI Class Initialized
INFO - 2020-10-07 18:25:04 --> Router Class Initialized
INFO - 2020-10-07 18:25:04 --> Output Class Initialized
INFO - 2020-10-07 18:25:04 --> Security Class Initialized
DEBUG - 2020-10-07 18:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:25:04 --> Input Class Initialized
INFO - 2020-10-07 18:25:04 --> Language Class Initialized
INFO - 2020-10-07 18:25:04 --> Loader Class Initialized
INFO - 2020-10-07 18:25:04 --> Helper loaded: url_helper
INFO - 2020-10-07 18:25:04 --> Database Driver Class Initialized
INFO - 2020-10-07 18:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:25:04 --> Email Class Initialized
INFO - 2020-10-07 18:25:04 --> Controller Class Initialized
DEBUG - 2020-10-07 18:25:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:25:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:25:04 --> Model Class Initialized
INFO - 2020-10-07 18:25:04 --> Model Class Initialized
INFO - 2020-10-07 18:25:04 --> Final output sent to browser
DEBUG - 2020-10-07 18:25:04 --> Total execution time: 0.0233
ERROR - 2020-10-07 18:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:25:16 --> Config Class Initialized
INFO - 2020-10-07 18:25:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:25:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:25:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:25:16 --> URI Class Initialized
INFO - 2020-10-07 18:25:16 --> Router Class Initialized
INFO - 2020-10-07 18:25:16 --> Output Class Initialized
INFO - 2020-10-07 18:25:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:25:16 --> Input Class Initialized
INFO - 2020-10-07 18:25:16 --> Language Class Initialized
INFO - 2020-10-07 18:25:16 --> Loader Class Initialized
INFO - 2020-10-07 18:25:16 --> Helper loaded: url_helper
INFO - 2020-10-07 18:25:16 --> Database Driver Class Initialized
INFO - 2020-10-07 18:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:25:16 --> Email Class Initialized
INFO - 2020-10-07 18:25:16 --> Controller Class Initialized
DEBUG - 2020-10-07 18:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:25:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:25:16 --> Model Class Initialized
INFO - 2020-10-07 18:25:16 --> Model Class Initialized
INFO - 2020-10-07 18:25:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:25:16 --> Final output sent to browser
DEBUG - 2020-10-07 18:25:16 --> Total execution time: 0.0205
ERROR - 2020-10-07 18:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:25:16 --> Config Class Initialized
INFO - 2020-10-07 18:25:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:25:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:25:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:25:16 --> URI Class Initialized
INFO - 2020-10-07 18:25:16 --> Router Class Initialized
INFO - 2020-10-07 18:25:16 --> Output Class Initialized
INFO - 2020-10-07 18:25:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:25:16 --> Input Class Initialized
INFO - 2020-10-07 18:25:16 --> Language Class Initialized
INFO - 2020-10-07 18:25:16 --> Loader Class Initialized
INFO - 2020-10-07 18:25:17 --> Helper loaded: url_helper
INFO - 2020-10-07 18:25:17 --> Database Driver Class Initialized
INFO - 2020-10-07 18:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:25:17 --> Email Class Initialized
INFO - 2020-10-07 18:25:17 --> Controller Class Initialized
DEBUG - 2020-10-07 18:25:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:25:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:25:17 --> Model Class Initialized
INFO - 2020-10-07 18:25:17 --> Model Class Initialized
INFO - 2020-10-07 18:25:17 --> Final output sent to browser
DEBUG - 2020-10-07 18:25:17 --> Total execution time: 0.0292
ERROR - 2020-10-07 18:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:26:16 --> Config Class Initialized
INFO - 2020-10-07 18:26:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:26:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:26:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:26:16 --> URI Class Initialized
INFO - 2020-10-07 18:26:16 --> Router Class Initialized
INFO - 2020-10-07 18:26:16 --> Output Class Initialized
INFO - 2020-10-07 18:26:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:26:16 --> Input Class Initialized
INFO - 2020-10-07 18:26:16 --> Language Class Initialized
INFO - 2020-10-07 18:26:16 --> Loader Class Initialized
INFO - 2020-10-07 18:26:16 --> Helper loaded: url_helper
INFO - 2020-10-07 18:26:16 --> Database Driver Class Initialized
INFO - 2020-10-07 18:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:26:16 --> Email Class Initialized
INFO - 2020-10-07 18:26:16 --> Controller Class Initialized
DEBUG - 2020-10-07 18:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:26:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:26:16 --> Model Class Initialized
INFO - 2020-10-07 18:26:16 --> Model Class Initialized
INFO - 2020-10-07 18:26:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:26:16 --> Final output sent to browser
DEBUG - 2020-10-07 18:26:16 --> Total execution time: 0.0258
ERROR - 2020-10-07 18:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:26:16 --> Config Class Initialized
INFO - 2020-10-07 18:26:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:26:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:26:16 --> Utf8 Class Initialized
INFO - 2020-10-07 18:26:16 --> URI Class Initialized
INFO - 2020-10-07 18:26:16 --> Router Class Initialized
INFO - 2020-10-07 18:26:16 --> Output Class Initialized
INFO - 2020-10-07 18:26:16 --> Security Class Initialized
DEBUG - 2020-10-07 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:26:16 --> Input Class Initialized
INFO - 2020-10-07 18:26:16 --> Language Class Initialized
INFO - 2020-10-07 18:26:16 --> Loader Class Initialized
INFO - 2020-10-07 18:26:16 --> Helper loaded: url_helper
INFO - 2020-10-07 18:26:16 --> Database Driver Class Initialized
INFO - 2020-10-07 18:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:26:16 --> Email Class Initialized
INFO - 2020-10-07 18:26:16 --> Controller Class Initialized
DEBUG - 2020-10-07 18:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:26:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:26:16 --> Model Class Initialized
INFO - 2020-10-07 18:26:16 --> Model Class Initialized
INFO - 2020-10-07 18:26:16 --> Final output sent to browser
DEBUG - 2020-10-07 18:26:16 --> Total execution time: 0.0222
ERROR - 2020-10-07 18:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:26:18 --> Config Class Initialized
INFO - 2020-10-07 18:26:18 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:26:18 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:26:18 --> Utf8 Class Initialized
INFO - 2020-10-07 18:26:18 --> URI Class Initialized
INFO - 2020-10-07 18:26:18 --> Router Class Initialized
INFO - 2020-10-07 18:26:18 --> Output Class Initialized
INFO - 2020-10-07 18:26:18 --> Security Class Initialized
DEBUG - 2020-10-07 18:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:26:18 --> Input Class Initialized
INFO - 2020-10-07 18:26:18 --> Language Class Initialized
INFO - 2020-10-07 18:26:18 --> Loader Class Initialized
INFO - 2020-10-07 18:26:18 --> Helper loaded: url_helper
INFO - 2020-10-07 18:26:18 --> Database Driver Class Initialized
INFO - 2020-10-07 18:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:26:18 --> Email Class Initialized
INFO - 2020-10-07 18:26:18 --> Controller Class Initialized
DEBUG - 2020-10-07 18:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:26:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:26:18 --> Model Class Initialized
INFO - 2020-10-07 18:26:18 --> Model Class Initialized
INFO - 2020-10-07 18:26:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:26:18 --> Final output sent to browser
DEBUG - 2020-10-07 18:26:18 --> Total execution time: 0.0211
ERROR - 2020-10-07 18:26:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:26:22 --> Config Class Initialized
INFO - 2020-10-07 18:26:22 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:26:22 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:26:22 --> Utf8 Class Initialized
INFO - 2020-10-07 18:26:22 --> URI Class Initialized
INFO - 2020-10-07 18:26:22 --> Router Class Initialized
INFO - 2020-10-07 18:26:22 --> Output Class Initialized
INFO - 2020-10-07 18:26:22 --> Security Class Initialized
DEBUG - 2020-10-07 18:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:26:22 --> Input Class Initialized
INFO - 2020-10-07 18:26:22 --> Language Class Initialized
INFO - 2020-10-07 18:26:22 --> Loader Class Initialized
INFO - 2020-10-07 18:26:22 --> Helper loaded: url_helper
INFO - 2020-10-07 18:26:22 --> Database Driver Class Initialized
INFO - 2020-10-07 18:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:26:22 --> Email Class Initialized
INFO - 2020-10-07 18:26:22 --> Controller Class Initialized
DEBUG - 2020-10-07 18:26:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:26:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:26:22 --> Model Class Initialized
INFO - 2020-10-07 18:26:22 --> Model Class Initialized
INFO - 2020-10-07 18:26:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-07 18:26:22 --> Final output sent to browser
DEBUG - 2020-10-07 18:26:22 --> Total execution time: 0.0219
ERROR - 2020-10-07 18:26:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:26:22 --> Config Class Initialized
INFO - 2020-10-07 18:26:22 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:26:22 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:26:22 --> Utf8 Class Initialized
INFO - 2020-10-07 18:26:22 --> URI Class Initialized
INFO - 2020-10-07 18:26:22 --> Router Class Initialized
INFO - 2020-10-07 18:26:22 --> Output Class Initialized
INFO - 2020-10-07 18:26:22 --> Security Class Initialized
DEBUG - 2020-10-07 18:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:26:22 --> Input Class Initialized
INFO - 2020-10-07 18:26:22 --> Language Class Initialized
INFO - 2020-10-07 18:26:22 --> Loader Class Initialized
INFO - 2020-10-07 18:26:22 --> Helper loaded: url_helper
INFO - 2020-10-07 18:26:22 --> Database Driver Class Initialized
INFO - 2020-10-07 18:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:26:22 --> Email Class Initialized
INFO - 2020-10-07 18:26:22 --> Controller Class Initialized
DEBUG - 2020-10-07 18:26:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:26:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:26:22 --> Model Class Initialized
INFO - 2020-10-07 18:26:22 --> Model Class Initialized
INFO - 2020-10-07 18:26:22 --> Final output sent to browser
DEBUG - 2020-10-07 18:26:22 --> Total execution time: 0.0190
ERROR - 2020-10-07 18:26:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:26:33 --> Config Class Initialized
INFO - 2020-10-07 18:26:33 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:26:33 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:26:33 --> Utf8 Class Initialized
INFO - 2020-10-07 18:26:33 --> URI Class Initialized
INFO - 2020-10-07 18:26:33 --> Router Class Initialized
INFO - 2020-10-07 18:26:33 --> Output Class Initialized
INFO - 2020-10-07 18:26:33 --> Security Class Initialized
DEBUG - 2020-10-07 18:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:26:33 --> Input Class Initialized
INFO - 2020-10-07 18:26:33 --> Language Class Initialized
INFO - 2020-10-07 18:26:33 --> Loader Class Initialized
INFO - 2020-10-07 18:26:33 --> Helper loaded: url_helper
INFO - 2020-10-07 18:26:33 --> Database Driver Class Initialized
INFO - 2020-10-07 18:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:26:33 --> Email Class Initialized
INFO - 2020-10-07 18:26:33 --> Controller Class Initialized
DEBUG - 2020-10-07 18:26:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:26:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:26:33 --> Model Class Initialized
INFO - 2020-10-07 18:26:33 --> Model Class Initialized
INFO - 2020-10-07 18:26:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:26:33 --> Final output sent to browser
DEBUG - 2020-10-07 18:26:33 --> Total execution time: 0.0245
ERROR - 2020-10-07 18:49:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:49:55 --> Config Class Initialized
INFO - 2020-10-07 18:49:55 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:49:55 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:49:55 --> Utf8 Class Initialized
INFO - 2020-10-07 18:49:55 --> URI Class Initialized
INFO - 2020-10-07 18:49:55 --> Router Class Initialized
INFO - 2020-10-07 18:49:55 --> Output Class Initialized
INFO - 2020-10-07 18:49:55 --> Security Class Initialized
DEBUG - 2020-10-07 18:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:49:55 --> Input Class Initialized
INFO - 2020-10-07 18:49:55 --> Language Class Initialized
INFO - 2020-10-07 18:49:55 --> Loader Class Initialized
INFO - 2020-10-07 18:49:55 --> Helper loaded: url_helper
INFO - 2020-10-07 18:49:55 --> Database Driver Class Initialized
INFO - 2020-10-07 18:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:49:55 --> Email Class Initialized
INFO - 2020-10-07 18:49:55 --> Controller Class Initialized
DEBUG - 2020-10-07 18:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:49:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:49:55 --> Model Class Initialized
INFO - 2020-10-07 18:49:55 --> Model Class Initialized
INFO - 2020-10-07 18:49:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:49:55 --> Final output sent to browser
DEBUG - 2020-10-07 18:49:55 --> Total execution time: 0.0311
ERROR - 2020-10-07 18:51:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:51:39 --> Config Class Initialized
INFO - 2020-10-07 18:51:39 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:51:39 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:51:39 --> Utf8 Class Initialized
INFO - 2020-10-07 18:51:39 --> URI Class Initialized
INFO - 2020-10-07 18:51:39 --> Router Class Initialized
INFO - 2020-10-07 18:51:39 --> Output Class Initialized
INFO - 2020-10-07 18:51:39 --> Security Class Initialized
DEBUG - 2020-10-07 18:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:51:39 --> Input Class Initialized
INFO - 2020-10-07 18:51:39 --> Language Class Initialized
INFO - 2020-10-07 18:51:39 --> Loader Class Initialized
INFO - 2020-10-07 18:51:39 --> Helper loaded: url_helper
INFO - 2020-10-07 18:51:39 --> Database Driver Class Initialized
INFO - 2020-10-07 18:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:51:39 --> Email Class Initialized
INFO - 2020-10-07 18:51:39 --> Controller Class Initialized
DEBUG - 2020-10-07 18:51:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:51:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:51:39 --> Model Class Initialized
INFO - 2020-10-07 18:51:39 --> Model Class Initialized
INFO - 2020-10-07 18:51:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:51:39 --> Final output sent to browser
DEBUG - 2020-10-07 18:51:39 --> Total execution time: 0.0219
ERROR - 2020-10-07 18:52:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:52:02 --> Config Class Initialized
INFO - 2020-10-07 18:52:02 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:52:02 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:52:02 --> Utf8 Class Initialized
INFO - 2020-10-07 18:52:02 --> URI Class Initialized
INFO - 2020-10-07 18:52:02 --> Router Class Initialized
INFO - 2020-10-07 18:52:02 --> Output Class Initialized
INFO - 2020-10-07 18:52:02 --> Security Class Initialized
DEBUG - 2020-10-07 18:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:52:02 --> Input Class Initialized
INFO - 2020-10-07 18:52:02 --> Language Class Initialized
INFO - 2020-10-07 18:52:02 --> Loader Class Initialized
INFO - 2020-10-07 18:52:02 --> Helper loaded: url_helper
INFO - 2020-10-07 18:52:02 --> Database Driver Class Initialized
INFO - 2020-10-07 18:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:52:02 --> Email Class Initialized
INFO - 2020-10-07 18:52:02 --> Controller Class Initialized
DEBUG - 2020-10-07 18:52:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:52:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:52:02 --> Model Class Initialized
INFO - 2020-10-07 18:52:02 --> Model Class Initialized
INFO - 2020-10-07 18:52:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:52:02 --> Final output sent to browser
DEBUG - 2020-10-07 18:52:02 --> Total execution time: 0.0252
ERROR - 2020-10-07 18:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:52:41 --> Config Class Initialized
INFO - 2020-10-07 18:52:41 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:52:41 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:52:41 --> Utf8 Class Initialized
INFO - 2020-10-07 18:52:41 --> URI Class Initialized
INFO - 2020-10-07 18:52:41 --> Router Class Initialized
INFO - 2020-10-07 18:52:41 --> Output Class Initialized
INFO - 2020-10-07 18:52:41 --> Security Class Initialized
DEBUG - 2020-10-07 18:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:52:41 --> Input Class Initialized
INFO - 2020-10-07 18:52:41 --> Language Class Initialized
INFO - 2020-10-07 18:52:41 --> Loader Class Initialized
INFO - 2020-10-07 18:52:41 --> Helper loaded: url_helper
INFO - 2020-10-07 18:52:42 --> Database Driver Class Initialized
INFO - 2020-10-07 18:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:52:42 --> Email Class Initialized
INFO - 2020-10-07 18:52:42 --> Controller Class Initialized
DEBUG - 2020-10-07 18:52:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:52:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:52:42 --> Model Class Initialized
INFO - 2020-10-07 18:52:42 --> Model Class Initialized
INFO - 2020-10-07 18:52:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:52:42 --> Final output sent to browser
DEBUG - 2020-10-07 18:52:42 --> Total execution time: 0.0225
ERROR - 2020-10-07 18:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:53:11 --> Config Class Initialized
INFO - 2020-10-07 18:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:53:11 --> Utf8 Class Initialized
INFO - 2020-10-07 18:53:11 --> URI Class Initialized
INFO - 2020-10-07 18:53:11 --> Router Class Initialized
INFO - 2020-10-07 18:53:11 --> Output Class Initialized
INFO - 2020-10-07 18:53:11 --> Security Class Initialized
DEBUG - 2020-10-07 18:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:53:11 --> Input Class Initialized
INFO - 2020-10-07 18:53:11 --> Language Class Initialized
INFO - 2020-10-07 18:53:11 --> Loader Class Initialized
INFO - 2020-10-07 18:53:11 --> Helper loaded: url_helper
INFO - 2020-10-07 18:53:11 --> Database Driver Class Initialized
INFO - 2020-10-07 18:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:53:11 --> Email Class Initialized
INFO - 2020-10-07 18:53:11 --> Controller Class Initialized
DEBUG - 2020-10-07 18:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:53:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:53:11 --> Model Class Initialized
INFO - 2020-10-07 18:53:11 --> Model Class Initialized
INFO - 2020-10-07 18:53:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:53:11 --> Final output sent to browser
DEBUG - 2020-10-07 18:53:11 --> Total execution time: 0.0206
ERROR - 2020-10-07 18:53:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:53:28 --> Config Class Initialized
INFO - 2020-10-07 18:53:28 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:53:28 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:53:28 --> Utf8 Class Initialized
INFO - 2020-10-07 18:53:28 --> URI Class Initialized
INFO - 2020-10-07 18:53:28 --> Router Class Initialized
INFO - 2020-10-07 18:53:28 --> Output Class Initialized
INFO - 2020-10-07 18:53:28 --> Security Class Initialized
DEBUG - 2020-10-07 18:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:53:28 --> Input Class Initialized
INFO - 2020-10-07 18:53:28 --> Language Class Initialized
INFO - 2020-10-07 18:53:28 --> Loader Class Initialized
INFO - 2020-10-07 18:53:28 --> Helper loaded: url_helper
INFO - 2020-10-07 18:53:28 --> Database Driver Class Initialized
INFO - 2020-10-07 18:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:53:28 --> Email Class Initialized
INFO - 2020-10-07 18:53:28 --> Controller Class Initialized
DEBUG - 2020-10-07 18:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:53:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:53:28 --> Model Class Initialized
INFO - 2020-10-07 18:53:28 --> Model Class Initialized
INFO - 2020-10-07 18:53:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:53:28 --> Final output sent to browser
DEBUG - 2020-10-07 18:53:28 --> Total execution time: 0.0229
ERROR - 2020-10-07 18:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:53:44 --> Config Class Initialized
INFO - 2020-10-07 18:53:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:53:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:53:44 --> Utf8 Class Initialized
INFO - 2020-10-07 18:53:44 --> URI Class Initialized
INFO - 2020-10-07 18:53:44 --> Router Class Initialized
INFO - 2020-10-07 18:53:44 --> Output Class Initialized
INFO - 2020-10-07 18:53:44 --> Security Class Initialized
DEBUG - 2020-10-07 18:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:53:44 --> Input Class Initialized
INFO - 2020-10-07 18:53:44 --> Language Class Initialized
INFO - 2020-10-07 18:53:44 --> Loader Class Initialized
INFO - 2020-10-07 18:53:44 --> Helper loaded: url_helper
INFO - 2020-10-07 18:53:44 --> Database Driver Class Initialized
INFO - 2020-10-07 18:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:53:44 --> Email Class Initialized
INFO - 2020-10-07 18:53:44 --> Controller Class Initialized
DEBUG - 2020-10-07 18:53:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:53:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:53:44 --> Model Class Initialized
INFO - 2020-10-07 18:53:44 --> Model Class Initialized
INFO - 2020-10-07 18:53:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 18:53:44 --> Final output sent to browser
DEBUG - 2020-10-07 18:53:44 --> Total execution time: 0.0262
ERROR - 2020-10-07 18:54:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:54:15 --> Config Class Initialized
INFO - 2020-10-07 18:54:15 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:54:15 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:54:15 --> Utf8 Class Initialized
INFO - 2020-10-07 18:54:15 --> URI Class Initialized
INFO - 2020-10-07 18:54:15 --> Router Class Initialized
INFO - 2020-10-07 18:54:15 --> Output Class Initialized
INFO - 2020-10-07 18:54:15 --> Security Class Initialized
DEBUG - 2020-10-07 18:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:54:15 --> Input Class Initialized
INFO - 2020-10-07 18:54:15 --> Language Class Initialized
INFO - 2020-10-07 18:54:15 --> Loader Class Initialized
INFO - 2020-10-07 18:54:15 --> Helper loaded: url_helper
INFO - 2020-10-07 18:54:15 --> Database Driver Class Initialized
INFO - 2020-10-07 18:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:54:15 --> Email Class Initialized
INFO - 2020-10-07 18:54:15 --> Controller Class Initialized
DEBUG - 2020-10-07 18:54:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:54:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:54:15 --> Model Class Initialized
INFO - 2020-10-07 18:54:15 --> Model Class Initialized
INFO - 2020-10-07 18:54:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:54:15 --> Final output sent to browser
DEBUG - 2020-10-07 18:54:15 --> Total execution time: 0.0349
ERROR - 2020-10-07 18:56:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:56:15 --> Config Class Initialized
INFO - 2020-10-07 18:56:15 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:56:15 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:56:15 --> Utf8 Class Initialized
INFO - 2020-10-07 18:56:15 --> URI Class Initialized
INFO - 2020-10-07 18:56:15 --> Router Class Initialized
INFO - 2020-10-07 18:56:15 --> Output Class Initialized
INFO - 2020-10-07 18:56:15 --> Security Class Initialized
DEBUG - 2020-10-07 18:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:56:15 --> Input Class Initialized
INFO - 2020-10-07 18:56:15 --> Language Class Initialized
INFO - 2020-10-07 18:56:15 --> Loader Class Initialized
INFO - 2020-10-07 18:56:15 --> Helper loaded: url_helper
INFO - 2020-10-07 18:56:15 --> Database Driver Class Initialized
INFO - 2020-10-07 18:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:56:15 --> Email Class Initialized
INFO - 2020-10-07 18:56:15 --> Controller Class Initialized
DEBUG - 2020-10-07 18:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:56:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:56:15 --> Model Class Initialized
INFO - 2020-10-07 18:56:15 --> Model Class Initialized
INFO - 2020-10-07 18:56:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:56:15 --> Final output sent to browser
DEBUG - 2020-10-07 18:56:15 --> Total execution time: 0.0265
ERROR - 2020-10-07 18:57:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:57:01 --> Config Class Initialized
INFO - 2020-10-07 18:57:01 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:57:01 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:57:01 --> Utf8 Class Initialized
INFO - 2020-10-07 18:57:01 --> URI Class Initialized
INFO - 2020-10-07 18:57:01 --> Router Class Initialized
INFO - 2020-10-07 18:57:01 --> Output Class Initialized
INFO - 2020-10-07 18:57:01 --> Security Class Initialized
DEBUG - 2020-10-07 18:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:57:01 --> Input Class Initialized
INFO - 2020-10-07 18:57:01 --> Language Class Initialized
INFO - 2020-10-07 18:57:01 --> Loader Class Initialized
INFO - 2020-10-07 18:57:01 --> Helper loaded: url_helper
INFO - 2020-10-07 18:57:01 --> Database Driver Class Initialized
INFO - 2020-10-07 18:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:57:01 --> Email Class Initialized
INFO - 2020-10-07 18:57:01 --> Controller Class Initialized
DEBUG - 2020-10-07 18:57:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:57:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:57:01 --> Model Class Initialized
INFO - 2020-10-07 18:57:01 --> Model Class Initialized
INFO - 2020-10-07 18:57:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:57:01 --> Final output sent to browser
DEBUG - 2020-10-07 18:57:01 --> Total execution time: 0.0272
ERROR - 2020-10-07 18:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:57:33 --> Config Class Initialized
INFO - 2020-10-07 18:57:33 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:57:33 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:57:33 --> Utf8 Class Initialized
INFO - 2020-10-07 18:57:33 --> URI Class Initialized
INFO - 2020-10-07 18:57:33 --> Router Class Initialized
INFO - 2020-10-07 18:57:33 --> Output Class Initialized
INFO - 2020-10-07 18:57:33 --> Security Class Initialized
DEBUG - 2020-10-07 18:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:57:33 --> Input Class Initialized
INFO - 2020-10-07 18:57:33 --> Language Class Initialized
INFO - 2020-10-07 18:57:33 --> Loader Class Initialized
INFO - 2020-10-07 18:57:33 --> Helper loaded: url_helper
INFO - 2020-10-07 18:57:33 --> Database Driver Class Initialized
INFO - 2020-10-07 18:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:57:33 --> Email Class Initialized
INFO - 2020-10-07 18:57:33 --> Controller Class Initialized
DEBUG - 2020-10-07 18:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:57:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:57:33 --> Model Class Initialized
INFO - 2020-10-07 18:57:33 --> Model Class Initialized
INFO - 2020-10-07 18:57:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:57:33 --> Final output sent to browser
DEBUG - 2020-10-07 18:57:33 --> Total execution time: 0.0225
ERROR - 2020-10-07 18:57:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:57:58 --> Config Class Initialized
INFO - 2020-10-07 18:57:58 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:57:58 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:57:58 --> Utf8 Class Initialized
INFO - 2020-10-07 18:57:58 --> URI Class Initialized
INFO - 2020-10-07 18:57:58 --> Router Class Initialized
INFO - 2020-10-07 18:57:58 --> Output Class Initialized
INFO - 2020-10-07 18:57:58 --> Security Class Initialized
DEBUG - 2020-10-07 18:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:57:58 --> Input Class Initialized
INFO - 2020-10-07 18:57:58 --> Language Class Initialized
INFO - 2020-10-07 18:57:58 --> Loader Class Initialized
INFO - 2020-10-07 18:57:58 --> Helper loaded: url_helper
INFO - 2020-10-07 18:57:58 --> Database Driver Class Initialized
INFO - 2020-10-07 18:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:57:58 --> Email Class Initialized
INFO - 2020-10-07 18:57:58 --> Controller Class Initialized
DEBUG - 2020-10-07 18:57:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:57:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:57:58 --> Model Class Initialized
INFO - 2020-10-07 18:57:58 --> Model Class Initialized
INFO - 2020-10-07 18:57:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:57:58 --> Final output sent to browser
DEBUG - 2020-10-07 18:57:58 --> Total execution time: 0.0257
ERROR - 2020-10-07 18:58:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:58:17 --> Config Class Initialized
INFO - 2020-10-07 18:58:17 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:58:17 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:58:17 --> Utf8 Class Initialized
INFO - 2020-10-07 18:58:17 --> URI Class Initialized
INFO - 2020-10-07 18:58:17 --> Router Class Initialized
INFO - 2020-10-07 18:58:17 --> Output Class Initialized
INFO - 2020-10-07 18:58:17 --> Security Class Initialized
DEBUG - 2020-10-07 18:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:58:17 --> Input Class Initialized
INFO - 2020-10-07 18:58:17 --> Language Class Initialized
INFO - 2020-10-07 18:58:17 --> Loader Class Initialized
INFO - 2020-10-07 18:58:17 --> Helper loaded: url_helper
INFO - 2020-10-07 18:58:17 --> Database Driver Class Initialized
INFO - 2020-10-07 18:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:58:17 --> Email Class Initialized
INFO - 2020-10-07 18:58:17 --> Controller Class Initialized
DEBUG - 2020-10-07 18:58:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:58:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:58:17 --> Model Class Initialized
INFO - 2020-10-07 18:58:17 --> Model Class Initialized
INFO - 2020-10-07 18:58:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:58:17 --> Final output sent to browser
DEBUG - 2020-10-07 18:58:17 --> Total execution time: 0.0238
ERROR - 2020-10-07 18:58:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:58:40 --> Config Class Initialized
INFO - 2020-10-07 18:58:40 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:58:40 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:58:40 --> Utf8 Class Initialized
INFO - 2020-10-07 18:58:40 --> URI Class Initialized
INFO - 2020-10-07 18:58:40 --> Router Class Initialized
INFO - 2020-10-07 18:58:40 --> Output Class Initialized
INFO - 2020-10-07 18:58:40 --> Security Class Initialized
DEBUG - 2020-10-07 18:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:58:40 --> Input Class Initialized
INFO - 2020-10-07 18:58:40 --> Language Class Initialized
INFO - 2020-10-07 18:58:40 --> Loader Class Initialized
INFO - 2020-10-07 18:58:40 --> Helper loaded: url_helper
INFO - 2020-10-07 18:58:40 --> Database Driver Class Initialized
INFO - 2020-10-07 18:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:58:40 --> Email Class Initialized
INFO - 2020-10-07 18:58:40 --> Controller Class Initialized
DEBUG - 2020-10-07 18:58:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:58:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:58:40 --> Model Class Initialized
INFO - 2020-10-07 18:58:40 --> Model Class Initialized
INFO - 2020-10-07 18:58:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:58:40 --> Final output sent to browser
DEBUG - 2020-10-07 18:58:40 --> Total execution time: 0.0247
ERROR - 2020-10-07 18:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 18:59:52 --> Config Class Initialized
INFO - 2020-10-07 18:59:52 --> Hooks Class Initialized
DEBUG - 2020-10-07 18:59:52 --> UTF-8 Support Enabled
INFO - 2020-10-07 18:59:52 --> Utf8 Class Initialized
INFO - 2020-10-07 18:59:52 --> URI Class Initialized
INFO - 2020-10-07 18:59:52 --> Router Class Initialized
INFO - 2020-10-07 18:59:52 --> Output Class Initialized
INFO - 2020-10-07 18:59:52 --> Security Class Initialized
DEBUG - 2020-10-07 18:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 18:59:52 --> Input Class Initialized
INFO - 2020-10-07 18:59:52 --> Language Class Initialized
INFO - 2020-10-07 18:59:52 --> Loader Class Initialized
INFO - 2020-10-07 18:59:52 --> Helper loaded: url_helper
INFO - 2020-10-07 18:59:52 --> Database Driver Class Initialized
INFO - 2020-10-07 18:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 18:59:52 --> Email Class Initialized
INFO - 2020-10-07 18:59:52 --> Controller Class Initialized
DEBUG - 2020-10-07 18:59:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 18:59:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 18:59:52 --> Model Class Initialized
INFO - 2020-10-07 18:59:52 --> Model Class Initialized
INFO - 2020-10-07 18:59:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 18:59:52 --> Final output sent to browser
DEBUG - 2020-10-07 18:59:52 --> Total execution time: 0.0254
ERROR - 2020-10-07 19:01:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:01:25 --> Config Class Initialized
INFO - 2020-10-07 19:01:25 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:01:25 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:01:25 --> Utf8 Class Initialized
INFO - 2020-10-07 19:01:25 --> URI Class Initialized
INFO - 2020-10-07 19:01:25 --> Router Class Initialized
INFO - 2020-10-07 19:01:25 --> Output Class Initialized
INFO - 2020-10-07 19:01:25 --> Security Class Initialized
DEBUG - 2020-10-07 19:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:01:25 --> Input Class Initialized
INFO - 2020-10-07 19:01:25 --> Language Class Initialized
INFO - 2020-10-07 19:01:25 --> Loader Class Initialized
INFO - 2020-10-07 19:01:25 --> Helper loaded: url_helper
INFO - 2020-10-07 19:01:25 --> Database Driver Class Initialized
INFO - 2020-10-07 19:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:01:25 --> Email Class Initialized
INFO - 2020-10-07 19:01:25 --> Controller Class Initialized
DEBUG - 2020-10-07 19:01:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:01:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:01:25 --> Model Class Initialized
INFO - 2020-10-07 19:01:25 --> Model Class Initialized
INFO - 2020-10-07 19:01:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 19:01:25 --> Final output sent to browser
DEBUG - 2020-10-07 19:01:25 --> Total execution time: 0.0291
ERROR - 2020-10-07 19:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:02:59 --> Config Class Initialized
INFO - 2020-10-07 19:02:59 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:02:59 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:02:59 --> Utf8 Class Initialized
INFO - 2020-10-07 19:02:59 --> URI Class Initialized
INFO - 2020-10-07 19:02:59 --> Router Class Initialized
INFO - 2020-10-07 19:02:59 --> Output Class Initialized
INFO - 2020-10-07 19:02:59 --> Security Class Initialized
DEBUG - 2020-10-07 19:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:02:59 --> Input Class Initialized
INFO - 2020-10-07 19:02:59 --> Language Class Initialized
INFO - 2020-10-07 19:02:59 --> Loader Class Initialized
INFO - 2020-10-07 19:02:59 --> Helper loaded: url_helper
INFO - 2020-10-07 19:02:59 --> Database Driver Class Initialized
INFO - 2020-10-07 19:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:02:59 --> Email Class Initialized
INFO - 2020-10-07 19:02:59 --> Controller Class Initialized
DEBUG - 2020-10-07 19:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:02:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:02:59 --> Model Class Initialized
INFO - 2020-10-07 19:02:59 --> Model Class Initialized
INFO - 2020-10-07 19:02:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 19:02:59 --> Final output sent to browser
DEBUG - 2020-10-07 19:02:59 --> Total execution time: 0.0234
ERROR - 2020-10-07 19:03:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:03:12 --> Config Class Initialized
INFO - 2020-10-07 19:03:12 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:03:12 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:03:12 --> Utf8 Class Initialized
INFO - 2020-10-07 19:03:12 --> URI Class Initialized
INFO - 2020-10-07 19:03:12 --> Router Class Initialized
INFO - 2020-10-07 19:03:12 --> Output Class Initialized
INFO - 2020-10-07 19:03:12 --> Security Class Initialized
DEBUG - 2020-10-07 19:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:03:12 --> Input Class Initialized
INFO - 2020-10-07 19:03:12 --> Language Class Initialized
INFO - 2020-10-07 19:03:12 --> Loader Class Initialized
INFO - 2020-10-07 19:03:12 --> Helper loaded: url_helper
INFO - 2020-10-07 19:03:12 --> Database Driver Class Initialized
INFO - 2020-10-07 19:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:03:12 --> Email Class Initialized
INFO - 2020-10-07 19:03:12 --> Controller Class Initialized
DEBUG - 2020-10-07 19:03:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:03:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:03:12 --> Model Class Initialized
INFO - 2020-10-07 19:03:12 --> Model Class Initialized
INFO - 2020-10-07 19:03:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 19:03:12 --> Final output sent to browser
DEBUG - 2020-10-07 19:03:12 --> Total execution time: 0.0247
ERROR - 2020-10-07 19:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:04:16 --> Config Class Initialized
INFO - 2020-10-07 19:04:16 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:04:16 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:04:16 --> Utf8 Class Initialized
INFO - 2020-10-07 19:04:16 --> URI Class Initialized
INFO - 2020-10-07 19:04:16 --> Router Class Initialized
INFO - 2020-10-07 19:04:16 --> Output Class Initialized
INFO - 2020-10-07 19:04:16 --> Security Class Initialized
DEBUG - 2020-10-07 19:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:04:16 --> Input Class Initialized
INFO - 2020-10-07 19:04:16 --> Language Class Initialized
INFO - 2020-10-07 19:04:16 --> Loader Class Initialized
INFO - 2020-10-07 19:04:16 --> Helper loaded: url_helper
INFO - 2020-10-07 19:04:16 --> Database Driver Class Initialized
INFO - 2020-10-07 19:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:04:16 --> Email Class Initialized
INFO - 2020-10-07 19:04:16 --> Controller Class Initialized
DEBUG - 2020-10-07 19:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:04:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:04:16 --> Model Class Initialized
INFO - 2020-10-07 19:04:16 --> Model Class Initialized
INFO - 2020-10-07 19:04:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 19:04:16 --> Final output sent to browser
DEBUG - 2020-10-07 19:04:16 --> Total execution time: 0.0258
ERROR - 2020-10-07 19:04:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:04:23 --> Config Class Initialized
INFO - 2020-10-07 19:04:23 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:04:23 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:04:23 --> Utf8 Class Initialized
INFO - 2020-10-07 19:04:23 --> URI Class Initialized
INFO - 2020-10-07 19:04:23 --> Router Class Initialized
INFO - 2020-10-07 19:04:23 --> Output Class Initialized
INFO - 2020-10-07 19:04:23 --> Security Class Initialized
DEBUG - 2020-10-07 19:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:04:23 --> Input Class Initialized
INFO - 2020-10-07 19:04:23 --> Language Class Initialized
INFO - 2020-10-07 19:04:23 --> Loader Class Initialized
INFO - 2020-10-07 19:04:23 --> Helper loaded: url_helper
INFO - 2020-10-07 19:04:23 --> Database Driver Class Initialized
INFO - 2020-10-07 19:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:04:23 --> Email Class Initialized
INFO - 2020-10-07 19:04:23 --> Controller Class Initialized
DEBUG - 2020-10-07 19:04:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:04:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:04:23 --> Model Class Initialized
INFO - 2020-10-07 19:04:23 --> Model Class Initialized
INFO - 2020-10-07 19:04:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 19:04:23 --> Final output sent to browser
DEBUG - 2020-10-07 19:04:23 --> Total execution time: 0.0239
ERROR - 2020-10-07 19:05:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:05:15 --> Config Class Initialized
INFO - 2020-10-07 19:05:15 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:05:15 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:05:15 --> Utf8 Class Initialized
INFO - 2020-10-07 19:05:15 --> URI Class Initialized
INFO - 2020-10-07 19:05:15 --> Router Class Initialized
INFO - 2020-10-07 19:05:15 --> Output Class Initialized
INFO - 2020-10-07 19:05:15 --> Security Class Initialized
DEBUG - 2020-10-07 19:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:05:15 --> Input Class Initialized
INFO - 2020-10-07 19:05:15 --> Language Class Initialized
INFO - 2020-10-07 19:05:15 --> Loader Class Initialized
INFO - 2020-10-07 19:05:15 --> Helper loaded: url_helper
INFO - 2020-10-07 19:05:15 --> Database Driver Class Initialized
INFO - 2020-10-07 19:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:05:15 --> Email Class Initialized
INFO - 2020-10-07 19:05:15 --> Controller Class Initialized
DEBUG - 2020-10-07 19:05:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:05:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:05:15 --> Model Class Initialized
INFO - 2020-10-07 19:05:15 --> Model Class Initialized
INFO - 2020-10-07 19:05:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-07 19:05:15 --> Final output sent to browser
DEBUG - 2020-10-07 19:05:15 --> Total execution time: 0.0252
ERROR - 2020-10-07 19:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:05:41 --> Config Class Initialized
INFO - 2020-10-07 19:05:41 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:05:41 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:05:41 --> Utf8 Class Initialized
INFO - 2020-10-07 19:05:41 --> URI Class Initialized
INFO - 2020-10-07 19:05:41 --> Router Class Initialized
INFO - 2020-10-07 19:05:41 --> Output Class Initialized
INFO - 2020-10-07 19:05:41 --> Security Class Initialized
DEBUG - 2020-10-07 19:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:05:41 --> Input Class Initialized
INFO - 2020-10-07 19:05:41 --> Language Class Initialized
INFO - 2020-10-07 19:05:41 --> Loader Class Initialized
INFO - 2020-10-07 19:05:41 --> Helper loaded: url_helper
INFO - 2020-10-07 19:05:41 --> Database Driver Class Initialized
INFO - 2020-10-07 19:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:05:41 --> Email Class Initialized
INFO - 2020-10-07 19:05:41 --> Controller Class Initialized
DEBUG - 2020-10-07 19:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:05:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:05:41 --> Model Class Initialized
INFO - 2020-10-07 19:05:41 --> Model Class Initialized
INFO - 2020-10-07 19:05:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-07 19:05:41 --> Final output sent to browser
DEBUG - 2020-10-07 19:05:41 --> Total execution time: 0.0216
ERROR - 2020-10-07 19:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:05:44 --> Config Class Initialized
INFO - 2020-10-07 19:05:44 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:05:44 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:05:44 --> Utf8 Class Initialized
INFO - 2020-10-07 19:05:44 --> URI Class Initialized
INFO - 2020-10-07 19:05:44 --> Router Class Initialized
INFO - 2020-10-07 19:05:44 --> Output Class Initialized
INFO - 2020-10-07 19:05:44 --> Security Class Initialized
DEBUG - 2020-10-07 19:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:05:44 --> Input Class Initialized
INFO - 2020-10-07 19:05:44 --> Language Class Initialized
INFO - 2020-10-07 19:05:44 --> Loader Class Initialized
INFO - 2020-10-07 19:05:44 --> Helper loaded: url_helper
INFO - 2020-10-07 19:05:44 --> Database Driver Class Initialized
INFO - 2020-10-07 19:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:05:44 --> Email Class Initialized
INFO - 2020-10-07 19:05:44 --> Controller Class Initialized
DEBUG - 2020-10-07 19:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:05:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:05:44 --> Model Class Initialized
INFO - 2020-10-07 19:05:44 --> Model Class Initialized
INFO - 2020-10-07 19:05:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-07 19:05:44 --> Final output sent to browser
DEBUG - 2020-10-07 19:05:44 --> Total execution time: 0.0225
ERROR - 2020-10-07 19:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:05:51 --> Config Class Initialized
INFO - 2020-10-07 19:05:51 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:05:51 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:05:51 --> Utf8 Class Initialized
INFO - 2020-10-07 19:05:51 --> URI Class Initialized
INFO - 2020-10-07 19:05:51 --> Router Class Initialized
INFO - 2020-10-07 19:05:51 --> Output Class Initialized
INFO - 2020-10-07 19:05:51 --> Security Class Initialized
DEBUG - 2020-10-07 19:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:05:51 --> Input Class Initialized
INFO - 2020-10-07 19:05:51 --> Language Class Initialized
INFO - 2020-10-07 19:05:51 --> Loader Class Initialized
INFO - 2020-10-07 19:05:51 --> Helper loaded: url_helper
INFO - 2020-10-07 19:05:51 --> Database Driver Class Initialized
INFO - 2020-10-07 19:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:05:51 --> Email Class Initialized
INFO - 2020-10-07 19:05:51 --> Controller Class Initialized
DEBUG - 2020-10-07 19:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-07 19:05:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:05:51 --> Model Class Initialized
INFO - 2020-10-07 19:05:51 --> Model Class Initialized
INFO - 2020-10-07 19:05:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-07 19:05:51 --> Final output sent to browser
DEBUG - 2020-10-07 19:05:51 --> Total execution time: 0.0240
ERROR - 2020-10-07 19:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-07 19:05:56 --> Config Class Initialized
INFO - 2020-10-07 19:05:56 --> Hooks Class Initialized
DEBUG - 2020-10-07 19:05:56 --> UTF-8 Support Enabled
INFO - 2020-10-07 19:05:56 --> Utf8 Class Initialized
INFO - 2020-10-07 19:05:56 --> URI Class Initialized
DEBUG - 2020-10-07 19:05:56 --> No URI present. Default controller set.
INFO - 2020-10-07 19:05:56 --> Router Class Initialized
INFO - 2020-10-07 19:05:56 --> Output Class Initialized
INFO - 2020-10-07 19:05:56 --> Security Class Initialized
DEBUG - 2020-10-07 19:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-07 19:05:57 --> Input Class Initialized
INFO - 2020-10-07 19:05:57 --> Language Class Initialized
INFO - 2020-10-07 19:05:57 --> Loader Class Initialized
INFO - 2020-10-07 19:05:57 --> Helper loaded: url_helper
INFO - 2020-10-07 19:05:57 --> Database Driver Class Initialized
INFO - 2020-10-07 19:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-07 19:05:57 --> Email Class Initialized
INFO - 2020-10-07 19:05:57 --> Controller Class Initialized
INFO - 2020-10-07 19:05:57 --> Model Class Initialized
INFO - 2020-10-07 19:05:57 --> Model Class Initialized
DEBUG - 2020-10-07 19:05:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-07 19:05:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-07 19:05:57 --> Final output sent to browser
DEBUG - 2020-10-07 19:05:57 --> Total execution time: 0.0227
