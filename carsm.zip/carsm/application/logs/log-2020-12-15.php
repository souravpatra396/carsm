<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-15 01:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 01:01:49 --> Config Class Initialized
INFO - 2020-12-15 01:01:49 --> Hooks Class Initialized
DEBUG - 2020-12-15 01:01:49 --> UTF-8 Support Enabled
INFO - 2020-12-15 01:01:49 --> Utf8 Class Initialized
INFO - 2020-12-15 01:01:49 --> URI Class Initialized
DEBUG - 2020-12-15 01:01:49 --> No URI present. Default controller set.
INFO - 2020-12-15 01:01:49 --> Router Class Initialized
INFO - 2020-12-15 01:01:49 --> Output Class Initialized
INFO - 2020-12-15 01:01:49 --> Security Class Initialized
DEBUG - 2020-12-15 01:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 01:01:49 --> Input Class Initialized
INFO - 2020-12-15 01:01:49 --> Language Class Initialized
INFO - 2020-12-15 01:01:49 --> Loader Class Initialized
INFO - 2020-12-15 01:01:49 --> Helper loaded: url_helper
INFO - 2020-12-15 01:01:49 --> Database Driver Class Initialized
INFO - 2020-12-15 01:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 01:01:50 --> Email Class Initialized
INFO - 2020-12-15 01:01:50 --> Controller Class Initialized
INFO - 2020-12-15 01:01:50 --> Model Class Initialized
INFO - 2020-12-15 01:01:50 --> Model Class Initialized
DEBUG - 2020-12-15 01:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 01:01:50 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 01:01:50 --> Final output sent to browser
DEBUG - 2020-12-15 01:01:50 --> Total execution time: 0.1704
ERROR - 2020-12-15 11:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 11:19:54 --> Config Class Initialized
INFO - 2020-12-15 11:19:54 --> Hooks Class Initialized
DEBUG - 2020-12-15 11:19:54 --> UTF-8 Support Enabled
INFO - 2020-12-15 11:19:54 --> Utf8 Class Initialized
INFO - 2020-12-15 11:19:54 --> URI Class Initialized
DEBUG - 2020-12-15 11:19:54 --> No URI present. Default controller set.
INFO - 2020-12-15 11:19:54 --> Router Class Initialized
INFO - 2020-12-15 11:19:54 --> Output Class Initialized
INFO - 2020-12-15 11:19:54 --> Security Class Initialized
DEBUG - 2020-12-15 11:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 11:19:54 --> Input Class Initialized
INFO - 2020-12-15 11:19:54 --> Language Class Initialized
INFO - 2020-12-15 11:19:54 --> Loader Class Initialized
INFO - 2020-12-15 11:19:54 --> Helper loaded: url_helper
INFO - 2020-12-15 11:19:54 --> Database Driver Class Initialized
INFO - 2020-12-15 11:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 11:19:54 --> Email Class Initialized
INFO - 2020-12-15 11:19:54 --> Controller Class Initialized
INFO - 2020-12-15 11:19:54 --> Model Class Initialized
INFO - 2020-12-15 11:19:54 --> Model Class Initialized
DEBUG - 2020-12-15 11:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 11:19:54 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 11:19:54 --> Final output sent to browser
DEBUG - 2020-12-15 11:19:54 --> Total execution time: 0.1581
ERROR - 2020-12-15 16:03:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 16:03:21 --> Config Class Initialized
INFO - 2020-12-15 16:03:21 --> Hooks Class Initialized
DEBUG - 2020-12-15 16:03:21 --> UTF-8 Support Enabled
INFO - 2020-12-15 16:03:21 --> Utf8 Class Initialized
INFO - 2020-12-15 16:03:21 --> URI Class Initialized
DEBUG - 2020-12-15 16:03:21 --> No URI present. Default controller set.
INFO - 2020-12-15 16:03:21 --> Router Class Initialized
INFO - 2020-12-15 16:03:21 --> Output Class Initialized
INFO - 2020-12-15 16:03:21 --> Security Class Initialized
DEBUG - 2020-12-15 16:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 16:03:21 --> Input Class Initialized
INFO - 2020-12-15 16:03:21 --> Language Class Initialized
INFO - 2020-12-15 16:03:21 --> Loader Class Initialized
INFO - 2020-12-15 16:03:21 --> Helper loaded: url_helper
INFO - 2020-12-15 16:03:21 --> Database Driver Class Initialized
INFO - 2020-12-15 16:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 16:03:21 --> Email Class Initialized
INFO - 2020-12-15 16:03:21 --> Controller Class Initialized
INFO - 2020-12-15 16:03:21 --> Model Class Initialized
INFO - 2020-12-15 16:03:21 --> Model Class Initialized
DEBUG - 2020-12-15 16:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 16:03:21 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 16:03:21 --> Final output sent to browser
DEBUG - 2020-12-15 16:03:21 --> Total execution time: 0.1612
ERROR - 2020-12-15 16:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 16:15:28 --> Config Class Initialized
INFO - 2020-12-15 16:15:28 --> Hooks Class Initialized
DEBUG - 2020-12-15 16:15:28 --> UTF-8 Support Enabled
INFO - 2020-12-15 16:15:28 --> Utf8 Class Initialized
INFO - 2020-12-15 16:15:28 --> URI Class Initialized
DEBUG - 2020-12-15 16:15:28 --> No URI present. Default controller set.
INFO - 2020-12-15 16:15:28 --> Router Class Initialized
INFO - 2020-12-15 16:15:28 --> Output Class Initialized
INFO - 2020-12-15 16:15:28 --> Security Class Initialized
DEBUG - 2020-12-15 16:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 16:15:28 --> Input Class Initialized
INFO - 2020-12-15 16:15:28 --> Language Class Initialized
INFO - 2020-12-15 16:15:28 --> Loader Class Initialized
INFO - 2020-12-15 16:15:28 --> Helper loaded: url_helper
INFO - 2020-12-15 16:15:28 --> Database Driver Class Initialized
INFO - 2020-12-15 16:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 16:15:28 --> Email Class Initialized
INFO - 2020-12-15 16:15:28 --> Controller Class Initialized
INFO - 2020-12-15 16:15:28 --> Model Class Initialized
INFO - 2020-12-15 16:15:28 --> Model Class Initialized
DEBUG - 2020-12-15 16:15:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 16:15:28 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 16:15:28 --> Final output sent to browser
DEBUG - 2020-12-15 16:15:28 --> Total execution time: 0.0433
ERROR - 2020-12-15 20:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:39:50 --> Config Class Initialized
INFO - 2020-12-15 20:39:50 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:39:50 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:39:50 --> Utf8 Class Initialized
INFO - 2020-12-15 20:39:50 --> URI Class Initialized
DEBUG - 2020-12-15 20:39:50 --> No URI present. Default controller set.
INFO - 2020-12-15 20:39:50 --> Router Class Initialized
INFO - 2020-12-15 20:39:50 --> Output Class Initialized
INFO - 2020-12-15 20:39:50 --> Security Class Initialized
DEBUG - 2020-12-15 20:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:39:50 --> Input Class Initialized
INFO - 2020-12-15 20:39:50 --> Language Class Initialized
INFO - 2020-12-15 20:39:51 --> Loader Class Initialized
INFO - 2020-12-15 20:39:51 --> Helper loaded: url_helper
INFO - 2020-12-15 20:39:51 --> Database Driver Class Initialized
INFO - 2020-12-15 20:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:39:51 --> Email Class Initialized
INFO - 2020-12-15 20:39:51 --> Controller Class Initialized
INFO - 2020-12-15 20:39:51 --> Model Class Initialized
INFO - 2020-12-15 20:39:51 --> Model Class Initialized
DEBUG - 2020-12-15 20:39:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:39:51 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:39:51 --> Final output sent to browser
DEBUG - 2020-12-15 20:39:51 --> Total execution time: 0.1721
ERROR - 2020-12-15 20:39:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:39:56 --> Config Class Initialized
INFO - 2020-12-15 20:39:56 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:39:56 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:39:56 --> Utf8 Class Initialized
INFO - 2020-12-15 20:39:56 --> URI Class Initialized
DEBUG - 2020-12-15 20:39:56 --> No URI present. Default controller set.
INFO - 2020-12-15 20:39:56 --> Router Class Initialized
INFO - 2020-12-15 20:39:56 --> Output Class Initialized
INFO - 2020-12-15 20:39:56 --> Security Class Initialized
DEBUG - 2020-12-15 20:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:39:56 --> Input Class Initialized
INFO - 2020-12-15 20:39:56 --> Language Class Initialized
INFO - 2020-12-15 20:39:56 --> Loader Class Initialized
INFO - 2020-12-15 20:39:56 --> Helper loaded: url_helper
INFO - 2020-12-15 20:39:56 --> Database Driver Class Initialized
INFO - 2020-12-15 20:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:39:56 --> Email Class Initialized
INFO - 2020-12-15 20:39:56 --> Controller Class Initialized
INFO - 2020-12-15 20:39:56 --> Model Class Initialized
INFO - 2020-12-15 20:39:56 --> Model Class Initialized
DEBUG - 2020-12-15 20:39:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:39:56 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:39:56 --> Final output sent to browser
DEBUG - 2020-12-15 20:39:56 --> Total execution time: 0.0589
ERROR - 2020-12-15 20:39:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:39:57 --> Config Class Initialized
INFO - 2020-12-15 20:39:57 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:39:57 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:39:57 --> Utf8 Class Initialized
INFO - 2020-12-15 20:39:57 --> URI Class Initialized
DEBUG - 2020-12-15 20:39:57 --> No URI present. Default controller set.
INFO - 2020-12-15 20:39:57 --> Router Class Initialized
INFO - 2020-12-15 20:39:57 --> Output Class Initialized
INFO - 2020-12-15 20:39:57 --> Security Class Initialized
DEBUG - 2020-12-15 20:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:39:57 --> Input Class Initialized
INFO - 2020-12-15 20:39:57 --> Language Class Initialized
INFO - 2020-12-15 20:39:57 --> Loader Class Initialized
INFO - 2020-12-15 20:39:57 --> Helper loaded: url_helper
INFO - 2020-12-15 20:39:57 --> Database Driver Class Initialized
INFO - 2020-12-15 20:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:39:57 --> Email Class Initialized
INFO - 2020-12-15 20:39:57 --> Controller Class Initialized
INFO - 2020-12-15 20:39:57 --> Model Class Initialized
INFO - 2020-12-15 20:39:57 --> Model Class Initialized
DEBUG - 2020-12-15 20:39:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:39:57 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:39:57 --> Final output sent to browser
DEBUG - 2020-12-15 20:39:57 --> Total execution time: 0.0470
ERROR - 2020-12-15 20:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:39:59 --> Config Class Initialized
INFO - 2020-12-15 20:39:59 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:39:59 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:39:59 --> Utf8 Class Initialized
INFO - 2020-12-15 20:39:59 --> URI Class Initialized
DEBUG - 2020-12-15 20:39:59 --> No URI present. Default controller set.
INFO - 2020-12-15 20:39:59 --> Router Class Initialized
INFO - 2020-12-15 20:39:59 --> Output Class Initialized
INFO - 2020-12-15 20:39:59 --> Security Class Initialized
DEBUG - 2020-12-15 20:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:39:59 --> Input Class Initialized
INFO - 2020-12-15 20:39:59 --> Language Class Initialized
INFO - 2020-12-15 20:39:59 --> Loader Class Initialized
INFO - 2020-12-15 20:39:59 --> Helper loaded: url_helper
INFO - 2020-12-15 20:39:59 --> Database Driver Class Initialized
INFO - 2020-12-15 20:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:39:59 --> Email Class Initialized
INFO - 2020-12-15 20:39:59 --> Controller Class Initialized
INFO - 2020-12-15 20:39:59 --> Model Class Initialized
INFO - 2020-12-15 20:39:59 --> Model Class Initialized
DEBUG - 2020-12-15 20:39:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:39:59 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:39:59 --> Final output sent to browser
DEBUG - 2020-12-15 20:39:59 --> Total execution time: 0.0427
ERROR - 2020-12-15 20:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:08 --> Config Class Initialized
INFO - 2020-12-15 20:40:08 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:08 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:08 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:08 --> URI Class Initialized
DEBUG - 2020-12-15 20:40:08 --> No URI present. Default controller set.
INFO - 2020-12-15 20:40:08 --> Router Class Initialized
INFO - 2020-12-15 20:40:08 --> Output Class Initialized
INFO - 2020-12-15 20:40:08 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:08 --> Input Class Initialized
INFO - 2020-12-15 20:40:08 --> Language Class Initialized
INFO - 2020-12-15 20:40:08 --> Loader Class Initialized
INFO - 2020-12-15 20:40:08 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:08 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:08 --> Email Class Initialized
INFO - 2020-12-15 20:40:08 --> Controller Class Initialized
INFO - 2020-12-15 20:40:08 --> Model Class Initialized
INFO - 2020-12-15 20:40:08 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:08 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:40:08 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:08 --> Total execution time: 0.0434
ERROR - 2020-12-15 20:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:17 --> Config Class Initialized
INFO - 2020-12-15 20:40:17 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:17 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:17 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:17 --> URI Class Initialized
INFO - 2020-12-15 20:40:17 --> Router Class Initialized
ERROR - 2020-12-15 20:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:17 --> Config Class Initialized
INFO - 2020-12-15 20:40:17 --> Hooks Class Initialized
INFO - 2020-12-15 20:40:17 --> Output Class Initialized
INFO - 2020-12-15 20:40:17 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:17 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:17 --> Utf8 Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:17 --> Input Class Initialized
INFO - 2020-12-15 20:40:17 --> URI Class Initialized
INFO - 2020-12-15 20:40:17 --> Language Class Initialized
INFO - 2020-12-15 20:40:17 --> Router Class Initialized
INFO - 2020-12-15 20:40:17 --> Output Class Initialized
INFO - 2020-12-15 20:40:17 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:17 --> Input Class Initialized
INFO - 2020-12-15 20:40:17 --> Language Class Initialized
INFO - 2020-12-15 20:40:17 --> Loader Class Initialized
INFO - 2020-12-15 20:40:17 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:17 --> Loader Class Initialized
INFO - 2020-12-15 20:40:17 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:17 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:17 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:17 --> Email Class Initialized
INFO - 2020-12-15 20:40:17 --> Controller Class Initialized
INFO - 2020-12-15 20:40:17 --> Model Class Initialized
INFO - 2020-12-15 20:40:17 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:40:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:17 --> Email Class Initialized
INFO - 2020-12-15 20:40:17 --> Controller Class Initialized
INFO - 2020-12-15 20:40:17 --> Model Class Initialized
INFO - 2020-12-15 20:40:17 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-15 20:40:17 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-15 20:40:17 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-15 20:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:17 --> Config Class Initialized
INFO - 2020-12-15 20:40:17 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:17 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:17 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:17 --> URI Class Initialized
INFO - 2020-12-15 20:40:17 --> Router Class Initialized
INFO - 2020-12-15 20:40:17 --> Output Class Initialized
INFO - 2020-12-15 20:40:17 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:17 --> Input Class Initialized
INFO - 2020-12-15 20:40:17 --> Language Class Initialized
INFO - 2020-12-15 20:40:17 --> Loader Class Initialized
INFO - 2020-12-15 20:40:17 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:17 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:17 --> Email Class Initialized
INFO - 2020-12-15 20:40:17 --> Controller Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:40:17 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-12-15 20:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:17 --> Config Class Initialized
INFO - 2020-12-15 20:40:17 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:17 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:17 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:17 --> URI Class Initialized
DEBUG - 2020-12-15 20:40:17 --> No URI present. Default controller set.
INFO - 2020-12-15 20:40:17 --> Router Class Initialized
INFO - 2020-12-15 20:40:17 --> Output Class Initialized
INFO - 2020-12-15 20:40:17 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:17 --> Input Class Initialized
INFO - 2020-12-15 20:40:17 --> Language Class Initialized
INFO - 2020-12-15 20:40:17 --> Loader Class Initialized
INFO - 2020-12-15 20:40:17 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:17 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:17 --> Email Class Initialized
INFO - 2020-12-15 20:40:17 --> Controller Class Initialized
INFO - 2020-12-15 20:40:17 --> Model Class Initialized
INFO - 2020-12-15 20:40:17 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:17 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:40:17 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:17 --> Total execution time: 0.0566
ERROR - 2020-12-15 20:40:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:19 --> Config Class Initialized
INFO - 2020-12-15 20:40:19 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:19 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:19 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:19 --> URI Class Initialized
INFO - 2020-12-15 20:40:19 --> Router Class Initialized
INFO - 2020-12-15 20:40:19 --> Output Class Initialized
INFO - 2020-12-15 20:40:19 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:19 --> Input Class Initialized
INFO - 2020-12-15 20:40:19 --> Language Class Initialized
INFO - 2020-12-15 20:40:19 --> Loader Class Initialized
INFO - 2020-12-15 20:40:19 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:19 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:19 --> Email Class Initialized
INFO - 2020-12-15 20:40:19 --> Controller Class Initialized
INFO - 2020-12-15 20:40:19 --> Model Class Initialized
INFO - 2020-12-15 20:40:19 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-15 20:40:19 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-15 20:40:19 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-15 20:40:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:19 --> Config Class Initialized
INFO - 2020-12-15 20:40:19 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:19 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:19 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:19 --> URI Class Initialized
INFO - 2020-12-15 20:40:19 --> Router Class Initialized
INFO - 2020-12-15 20:40:19 --> Output Class Initialized
INFO - 2020-12-15 20:40:19 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:19 --> Input Class Initialized
INFO - 2020-12-15 20:40:19 --> Language Class Initialized
INFO - 2020-12-15 20:40:19 --> Loader Class Initialized
INFO - 2020-12-15 20:40:19 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:19 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:19 --> Email Class Initialized
INFO - 2020-12-15 20:40:19 --> Controller Class Initialized
DEBUG - 2020-12-15 20:40:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:40:19 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-12-15 20:40:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:19 --> Config Class Initialized
INFO - 2020-12-15 20:40:19 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:19 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:19 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:19 --> URI Class Initialized
DEBUG - 2020-12-15 20:40:19 --> No URI present. Default controller set.
INFO - 2020-12-15 20:40:19 --> Router Class Initialized
INFO - 2020-12-15 20:40:19 --> Output Class Initialized
INFO - 2020-12-15 20:40:19 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:20 --> Input Class Initialized
INFO - 2020-12-15 20:40:20 --> Language Class Initialized
INFO - 2020-12-15 20:40:20 --> Loader Class Initialized
INFO - 2020-12-15 20:40:20 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:20 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:20 --> Email Class Initialized
INFO - 2020-12-15 20:40:20 --> Controller Class Initialized
INFO - 2020-12-15 20:40:20 --> Model Class Initialized
INFO - 2020-12-15 20:40:20 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:20 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:40:20 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:20 --> Total execution time: 0.0563
ERROR - 2020-12-15 20:40:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:25 --> Config Class Initialized
INFO - 2020-12-15 20:40:25 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:25 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:25 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:25 --> URI Class Initialized
DEBUG - 2020-12-15 20:40:25 --> No URI present. Default controller set.
INFO - 2020-12-15 20:40:25 --> Router Class Initialized
INFO - 2020-12-15 20:40:25 --> Output Class Initialized
INFO - 2020-12-15 20:40:25 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:25 --> Input Class Initialized
INFO - 2020-12-15 20:40:25 --> Language Class Initialized
INFO - 2020-12-15 20:40:25 --> Loader Class Initialized
INFO - 2020-12-15 20:40:25 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:25 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:25 --> Email Class Initialized
INFO - 2020-12-15 20:40:25 --> Controller Class Initialized
INFO - 2020-12-15 20:40:25 --> Model Class Initialized
INFO - 2020-12-15 20:40:25 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:25 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:40:25 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:25 --> Total execution time: 0.0432
ERROR - 2020-12-15 20:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:37 --> Config Class Initialized
INFO - 2020-12-15 20:40:37 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:37 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:37 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:37 --> URI Class Initialized
INFO - 2020-12-15 20:40:37 --> Router Class Initialized
INFO - 2020-12-15 20:40:37 --> Output Class Initialized
INFO - 2020-12-15 20:40:37 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:37 --> Input Class Initialized
INFO - 2020-12-15 20:40:37 --> Language Class Initialized
INFO - 2020-12-15 20:40:37 --> Loader Class Initialized
INFO - 2020-12-15 20:40:37 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:37 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:37 --> Email Class Initialized
INFO - 2020-12-15 20:40:37 --> Controller Class Initialized
INFO - 2020-12-15 20:40:37 --> Model Class Initialized
INFO - 2020-12-15 20:40:37 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:37 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-15 20:40:37 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-15 20:40:37 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-15 20:40:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:37 --> Config Class Initialized
INFO - 2020-12-15 20:40:37 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:37 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:37 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:37 --> URI Class Initialized
INFO - 2020-12-15 20:40:37 --> Router Class Initialized
INFO - 2020-12-15 20:40:37 --> Output Class Initialized
INFO - 2020-12-15 20:40:37 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:37 --> Input Class Initialized
INFO - 2020-12-15 20:40:37 --> Language Class Initialized
INFO - 2020-12-15 20:40:37 --> Loader Class Initialized
INFO - 2020-12-15 20:40:37 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:37 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:37 --> Email Class Initialized
INFO - 2020-12-15 20:40:37 --> Controller Class Initialized
DEBUG - 2020-12-15 20:40:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:40:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:37 --> Model Class Initialized
INFO - 2020-12-15 20:40:37 --> Model Class Initialized
INFO - 2020-12-15 20:40:37 --> File loaded: /home/portaldev2020/public_html/application/views/dash.php
INFO - 2020-12-15 20:40:37 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:37 --> Total execution time: 0.1289
ERROR - 2020-12-15 20:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:49 --> Config Class Initialized
INFO - 2020-12-15 20:40:49 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:49 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:49 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:49 --> URI Class Initialized
INFO - 2020-12-15 20:40:49 --> Router Class Initialized
INFO - 2020-12-15 20:40:49 --> Output Class Initialized
INFO - 2020-12-15 20:40:49 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:49 --> Input Class Initialized
INFO - 2020-12-15 20:40:49 --> Language Class Initialized
INFO - 2020-12-15 20:40:49 --> Loader Class Initialized
ERROR - 2020-12-15 20:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:49 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:49 --> Config Class Initialized
INFO - 2020-12-15 20:40:49 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:49 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:49 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:49 --> URI Class Initialized
INFO - 2020-12-15 20:40:49 --> Router Class Initialized
INFO - 2020-12-15 20:40:49 --> Output Class Initialized
INFO - 2020-12-15 20:40:49 --> Security Class Initialized
INFO - 2020-12-15 20:40:49 --> Database Driver Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:49 --> Input Class Initialized
INFO - 2020-12-15 20:40:49 --> Language Class Initialized
INFO - 2020-12-15 20:40:49 --> Loader Class Initialized
INFO - 2020-12-15 20:40:49 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:49 --> Email Class Initialized
INFO - 2020-12-15 20:40:49 --> Controller Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:40:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:49 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:49 --> Email Class Initialized
INFO - 2020-12-15 20:40:49 --> Controller Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-15 20:40:49 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-15 20:40:49 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-15 20:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:49 --> Config Class Initialized
INFO - 2020-12-15 20:40:49 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:49 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:49 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:49 --> URI Class Initialized
DEBUG - 2020-12-15 20:40:49 --> No URI present. Default controller set.
INFO - 2020-12-15 20:40:49 --> Router Class Initialized
INFO - 2020-12-15 20:40:49 --> Output Class Initialized
INFO - 2020-12-15 20:40:49 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:49 --> Input Class Initialized
INFO - 2020-12-15 20:40:49 --> Language Class Initialized
INFO - 2020-12-15 20:40:49 --> Loader Class Initialized
INFO - 2020-12-15 20:40:49 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:49 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:49 --> Email Class Initialized
INFO - 2020-12-15 20:40:49 --> Controller Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:49 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-15 20:40:49 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:49 --> Total execution time: 0.0426
ERROR - 2020-12-15 20:40:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:40:49 --> Config Class Initialized
INFO - 2020-12-15 20:40:49 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:40:49 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:40:49 --> Utf8 Class Initialized
INFO - 2020-12-15 20:40:49 --> URI Class Initialized
INFO - 2020-12-15 20:40:49 --> Router Class Initialized
INFO - 2020-12-15 20:40:49 --> Output Class Initialized
INFO - 2020-12-15 20:40:49 --> Security Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:40:49 --> Input Class Initialized
INFO - 2020-12-15 20:40:49 --> Language Class Initialized
INFO - 2020-12-15 20:40:49 --> Loader Class Initialized
INFO - 2020-12-15 20:40:49 --> Helper loaded: url_helper
INFO - 2020-12-15 20:40:49 --> Database Driver Class Initialized
INFO - 2020-12-15 20:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:40:49 --> Email Class Initialized
INFO - 2020-12-15 20:40:49 --> Controller Class Initialized
DEBUG - 2020-12-15 20:40:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:40:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
INFO - 2020-12-15 20:40:49 --> Model Class Initialized
INFO - 2020-12-15 20:40:49 --> File loaded: /home/portaldev2020/public_html/application/views/dash.php
INFO - 2020-12-15 20:40:49 --> Final output sent to browser
DEBUG - 2020-12-15 20:40:49 --> Total execution time: 0.0542
ERROR - 2020-12-15 20:42:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:42:32 --> Config Class Initialized
INFO - 2020-12-15 20:42:32 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:42:32 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:42:32 --> Utf8 Class Initialized
INFO - 2020-12-15 20:42:32 --> URI Class Initialized
INFO - 2020-12-15 20:42:32 --> Router Class Initialized
INFO - 2020-12-15 20:42:32 --> Output Class Initialized
INFO - 2020-12-15 20:42:32 --> Security Class Initialized
DEBUG - 2020-12-15 20:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:42:32 --> Input Class Initialized
INFO - 2020-12-15 20:42:32 --> Language Class Initialized
INFO - 2020-12-15 20:42:32 --> Loader Class Initialized
INFO - 2020-12-15 20:42:32 --> Helper loaded: url_helper
INFO - 2020-12-15 20:42:32 --> Database Driver Class Initialized
INFO - 2020-12-15 20:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:42:32 --> Email Class Initialized
INFO - 2020-12-15 20:42:32 --> Controller Class Initialized
DEBUG - 2020-12-15 20:42:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:42:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:42:32 --> Model Class Initialized
INFO - 2020-12-15 20:42:32 --> Model Class Initialized
INFO - 2020-12-15 20:42:32 --> File loaded: /home/portaldev2020/public_html/application/views/client_master_list_admin_wise.php
INFO - 2020-12-15 20:42:32 --> Final output sent to browser
DEBUG - 2020-12-15 20:42:32 --> Total execution time: 0.0599
ERROR - 2020-12-15 20:42:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:42:39 --> Config Class Initialized
INFO - 2020-12-15 20:42:39 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:42:39 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:42:39 --> Utf8 Class Initialized
INFO - 2020-12-15 20:42:39 --> URI Class Initialized
INFO - 2020-12-15 20:42:39 --> Router Class Initialized
INFO - 2020-12-15 20:42:39 --> Output Class Initialized
INFO - 2020-12-15 20:42:39 --> Security Class Initialized
DEBUG - 2020-12-15 20:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:42:39 --> Input Class Initialized
INFO - 2020-12-15 20:42:39 --> Language Class Initialized
INFO - 2020-12-15 20:42:39 --> Loader Class Initialized
INFO - 2020-12-15 20:42:39 --> Helper loaded: url_helper
INFO - 2020-12-15 20:42:39 --> Database Driver Class Initialized
INFO - 2020-12-15 20:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:42:39 --> Email Class Initialized
INFO - 2020-12-15 20:42:39 --> Controller Class Initialized
DEBUG - 2020-12-15 20:42:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:42:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:42:39 --> Model Class Initialized
INFO - 2020-12-15 20:42:39 --> Model Class Initialized
INFO - 2020-12-15 20:42:39 --> File loaded: /home/portaldev2020/public_html/application/views/client_master_list_admin_wise.php
INFO - 2020-12-15 20:42:39 --> Final output sent to browser
DEBUG - 2020-12-15 20:42:39 --> Total execution time: 0.0511
ERROR - 2020-12-15 20:44:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:44:46 --> Config Class Initialized
INFO - 2020-12-15 20:44:46 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:44:46 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:44:46 --> Utf8 Class Initialized
INFO - 2020-12-15 20:44:46 --> URI Class Initialized
INFO - 2020-12-15 20:44:46 --> Router Class Initialized
INFO - 2020-12-15 20:44:46 --> Output Class Initialized
INFO - 2020-12-15 20:44:46 --> Security Class Initialized
DEBUG - 2020-12-15 20:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:44:46 --> Input Class Initialized
INFO - 2020-12-15 20:44:46 --> Language Class Initialized
INFO - 2020-12-15 20:44:46 --> Loader Class Initialized
INFO - 2020-12-15 20:44:46 --> Helper loaded: url_helper
INFO - 2020-12-15 20:44:46 --> Database Driver Class Initialized
INFO - 2020-12-15 20:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:44:46 --> Email Class Initialized
INFO - 2020-12-15 20:44:46 --> Controller Class Initialized
DEBUG - 2020-12-15 20:44:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:44:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:44:46 --> Model Class Initialized
INFO - 2020-12-15 20:44:46 --> Model Class Initialized
INFO - 2020-12-15 20:44:46 --> File loaded: /home/portaldev2020/public_html/application/views/campain_master_list.php
INFO - 2020-12-15 20:44:46 --> Final output sent to browser
DEBUG - 2020-12-15 20:44:46 --> Total execution time: 0.1011
ERROR - 2020-12-15 20:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:44:51 --> Config Class Initialized
INFO - 2020-12-15 20:44:51 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:44:51 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:44:51 --> Utf8 Class Initialized
INFO - 2020-12-15 20:44:51 --> URI Class Initialized
INFO - 2020-12-15 20:44:51 --> Router Class Initialized
INFO - 2020-12-15 20:44:51 --> Output Class Initialized
INFO - 2020-12-15 20:44:51 --> Security Class Initialized
DEBUG - 2020-12-15 20:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:44:51 --> Input Class Initialized
INFO - 2020-12-15 20:44:51 --> Language Class Initialized
INFO - 2020-12-15 20:44:51 --> Loader Class Initialized
INFO - 2020-12-15 20:44:51 --> Helper loaded: url_helper
INFO - 2020-12-15 20:44:51 --> Database Driver Class Initialized
INFO - 2020-12-15 20:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:44:51 --> Email Class Initialized
INFO - 2020-12-15 20:44:51 --> Controller Class Initialized
DEBUG - 2020-12-15 20:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:44:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:44:51 --> Model Class Initialized
INFO - 2020-12-15 20:44:51 --> Model Class Initialized
INFO - 2020-12-15 20:44:51 --> File loaded: /home/portaldev2020/public_html/application/views/campain_master_list.php
INFO - 2020-12-15 20:44:51 --> Final output sent to browser
DEBUG - 2020-12-15 20:44:51 --> Total execution time: 0.0641
ERROR - 2020-12-15 20:44:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:44:57 --> Config Class Initialized
INFO - 2020-12-15 20:44:57 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:44:57 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:44:57 --> Utf8 Class Initialized
INFO - 2020-12-15 20:44:57 --> URI Class Initialized
INFO - 2020-12-15 20:44:57 --> Router Class Initialized
INFO - 2020-12-15 20:44:57 --> Output Class Initialized
INFO - 2020-12-15 20:44:57 --> Security Class Initialized
DEBUG - 2020-12-15 20:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:44:57 --> Input Class Initialized
INFO - 2020-12-15 20:44:57 --> Language Class Initialized
INFO - 2020-12-15 20:44:57 --> Loader Class Initialized
INFO - 2020-12-15 20:44:57 --> Helper loaded: url_helper
INFO - 2020-12-15 20:44:57 --> Database Driver Class Initialized
INFO - 2020-12-15 20:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:44:57 --> Email Class Initialized
INFO - 2020-12-15 20:44:57 --> Controller Class Initialized
DEBUG - 2020-12-15 20:44:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:44:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:44:57 --> Model Class Initialized
INFO - 2020-12-15 20:44:57 --> Model Class Initialized
INFO - 2020-12-15 20:44:57 --> File loaded: /home/portaldev2020/public_html/application/views/all_camapaign_add.php
INFO - 2020-12-15 20:44:57 --> Final output sent to browser
DEBUG - 2020-12-15 20:44:57 --> Total execution time: 0.0711
ERROR - 2020-12-15 20:44:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:44:58 --> Config Class Initialized
INFO - 2020-12-15 20:44:58 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:44:58 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:44:58 --> Utf8 Class Initialized
INFO - 2020-12-15 20:44:58 --> URI Class Initialized
INFO - 2020-12-15 20:44:58 --> Router Class Initialized
INFO - 2020-12-15 20:44:58 --> Output Class Initialized
INFO - 2020-12-15 20:44:58 --> Security Class Initialized
DEBUG - 2020-12-15 20:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:44:58 --> Input Class Initialized
INFO - 2020-12-15 20:44:58 --> Language Class Initialized
INFO - 2020-12-15 20:44:58 --> Loader Class Initialized
INFO - 2020-12-15 20:44:58 --> Helper loaded: url_helper
INFO - 2020-12-15 20:44:58 --> Database Driver Class Initialized
INFO - 2020-12-15 20:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:44:58 --> Email Class Initialized
INFO - 2020-12-15 20:44:58 --> Controller Class Initialized
DEBUG - 2020-12-15 20:44:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:44:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:44:58 --> Model Class Initialized
INFO - 2020-12-15 20:44:58 --> Model Class Initialized
INFO - 2020-12-15 20:44:58 --> Final output sent to browser
DEBUG - 2020-12-15 20:44:58 --> Total execution time: 0.0581
ERROR - 2020-12-15 20:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:45:00 --> Config Class Initialized
INFO - 2020-12-15 20:45:00 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:45:00 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:45:00 --> Utf8 Class Initialized
INFO - 2020-12-15 20:45:00 --> URI Class Initialized
INFO - 2020-12-15 20:45:00 --> Router Class Initialized
INFO - 2020-12-15 20:45:00 --> Output Class Initialized
INFO - 2020-12-15 20:45:00 --> Security Class Initialized
DEBUG - 2020-12-15 20:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:45:00 --> Input Class Initialized
INFO - 2020-12-15 20:45:00 --> Language Class Initialized
INFO - 2020-12-15 20:45:00 --> Loader Class Initialized
INFO - 2020-12-15 20:45:00 --> Helper loaded: url_helper
INFO - 2020-12-15 20:45:00 --> Database Driver Class Initialized
INFO - 2020-12-15 20:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:45:00 --> Email Class Initialized
INFO - 2020-12-15 20:45:00 --> Controller Class Initialized
DEBUG - 2020-12-15 20:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:45:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:45:00 --> Model Class Initialized
INFO - 2020-12-15 20:45:00 --> Model Class Initialized
INFO - 2020-12-15 20:45:00 --> File loaded: /home/portaldev2020/public_html/application/views/campaign_data_upload.php
INFO - 2020-12-15 20:45:00 --> Final output sent to browser
DEBUG - 2020-12-15 20:45:00 --> Total execution time: 0.0604
ERROR - 2020-12-15 20:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:45:00 --> Config Class Initialized
INFO - 2020-12-15 20:45:00 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:45:00 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:45:00 --> Utf8 Class Initialized
INFO - 2020-12-15 20:45:00 --> URI Class Initialized
INFO - 2020-12-15 20:45:00 --> Router Class Initialized
INFO - 2020-12-15 20:45:00 --> Output Class Initialized
INFO - 2020-12-15 20:45:00 --> Security Class Initialized
DEBUG - 2020-12-15 20:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:45:00 --> Input Class Initialized
INFO - 2020-12-15 20:45:00 --> Language Class Initialized
INFO - 2020-12-15 20:45:00 --> Loader Class Initialized
INFO - 2020-12-15 20:45:00 --> Helper loaded: url_helper
INFO - 2020-12-15 20:45:00 --> Database Driver Class Initialized
INFO - 2020-12-15 20:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:45:00 --> Email Class Initialized
INFO - 2020-12-15 20:45:00 --> Controller Class Initialized
DEBUG - 2020-12-15 20:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:45:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:45:00 --> Model Class Initialized
INFO - 2020-12-15 20:45:00 --> Model Class Initialized
INFO - 2020-12-15 20:45:00 --> Final output sent to browser
DEBUG - 2020-12-15 20:45:00 --> Total execution time: 0.0545
ERROR - 2020-12-15 20:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:45:03 --> Config Class Initialized
INFO - 2020-12-15 20:45:03 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:45:03 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:45:03 --> Utf8 Class Initialized
INFO - 2020-12-15 20:45:03 --> URI Class Initialized
INFO - 2020-12-15 20:45:03 --> Router Class Initialized
INFO - 2020-12-15 20:45:03 --> Output Class Initialized
INFO - 2020-12-15 20:45:03 --> Security Class Initialized
DEBUG - 2020-12-15 20:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:45:03 --> Input Class Initialized
INFO - 2020-12-15 20:45:03 --> Language Class Initialized
INFO - 2020-12-15 20:45:03 --> Loader Class Initialized
INFO - 2020-12-15 20:45:03 --> Helper loaded: url_helper
INFO - 2020-12-15 20:45:03 --> Database Driver Class Initialized
INFO - 2020-12-15 20:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:45:03 --> Email Class Initialized
INFO - 2020-12-15 20:45:03 --> Controller Class Initialized
DEBUG - 2020-12-15 20:45:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:45:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:45:03 --> Model Class Initialized
INFO - 2020-12-15 20:45:03 --> Model Class Initialized
INFO - 2020-12-15 20:45:03 --> File loaded: /home/portaldev2020/public_html/application/views/dealer_master_list.php
INFO - 2020-12-15 20:45:03 --> Final output sent to browser
DEBUG - 2020-12-15 20:45:03 --> Total execution time: 0.0775
ERROR - 2020-12-15 20:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:45:08 --> Config Class Initialized
INFO - 2020-12-15 20:45:08 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:45:08 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:45:08 --> Utf8 Class Initialized
INFO - 2020-12-15 20:45:08 --> URI Class Initialized
INFO - 2020-12-15 20:45:08 --> Router Class Initialized
INFO - 2020-12-15 20:45:08 --> Output Class Initialized
INFO - 2020-12-15 20:45:08 --> Security Class Initialized
DEBUG - 2020-12-15 20:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:45:08 --> Input Class Initialized
INFO - 2020-12-15 20:45:08 --> Language Class Initialized
INFO - 2020-12-15 20:45:08 --> Loader Class Initialized
INFO - 2020-12-15 20:45:08 --> Helper loaded: url_helper
INFO - 2020-12-15 20:45:08 --> Database Driver Class Initialized
INFO - 2020-12-15 20:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:45:08 --> Email Class Initialized
INFO - 2020-12-15 20:45:08 --> Controller Class Initialized
DEBUG - 2020-12-15 20:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:45:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:45:08 --> Model Class Initialized
INFO - 2020-12-15 20:45:08 --> Model Class Initialized
INFO - 2020-12-15 20:45:08 --> File loaded: /home/portaldev2020/public_html/application/views/dealer_master_list.php
INFO - 2020-12-15 20:45:08 --> Final output sent to browser
DEBUG - 2020-12-15 20:45:08 --> Total execution time: 0.0573
ERROR - 2020-12-15 20:45:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-15 20:45:40 --> Config Class Initialized
INFO - 2020-12-15 20:45:40 --> Hooks Class Initialized
DEBUG - 2020-12-15 20:45:40 --> UTF-8 Support Enabled
INFO - 2020-12-15 20:45:40 --> Utf8 Class Initialized
INFO - 2020-12-15 20:45:40 --> URI Class Initialized
INFO - 2020-12-15 20:45:40 --> Router Class Initialized
INFO - 2020-12-15 20:45:40 --> Output Class Initialized
INFO - 2020-12-15 20:45:40 --> Security Class Initialized
DEBUG - 2020-12-15 20:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 20:45:40 --> Input Class Initialized
INFO - 2020-12-15 20:45:40 --> Language Class Initialized
INFO - 2020-12-15 20:45:40 --> Loader Class Initialized
INFO - 2020-12-15 20:45:40 --> Helper loaded: url_helper
INFO - 2020-12-15 20:45:40 --> Database Driver Class Initialized
INFO - 2020-12-15 20:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 20:45:40 --> Email Class Initialized
INFO - 2020-12-15 20:45:40 --> Controller Class Initialized
DEBUG - 2020-12-15 20:45:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-15 20:45:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-15 20:45:40 --> Model Class Initialized
INFO - 2020-12-15 20:45:40 --> Model Class Initialized
INFO - 2020-12-15 20:45:40 --> File loaded: /home/portaldev2020/public_html/application/views/dealer_view.php
INFO - 2020-12-15 20:45:40 --> Final output sent to browser
DEBUG - 2020-12-15 20:45:40 --> Total execution time: 0.0604
