<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-20 15:31:19 --> Config Class Initialized
INFO - 2020-08-20 15:31:19 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:31:19 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:31:19 --> Utf8 Class Initialized
INFO - 2020-08-20 15:31:19 --> URI Class Initialized
DEBUG - 2020-08-20 15:31:19 --> No URI present. Default controller set.
INFO - 2020-08-20 15:31:19 --> Router Class Initialized
INFO - 2020-08-20 15:31:19 --> Output Class Initialized
INFO - 2020-08-20 15:31:19 --> Security Class Initialized
DEBUG - 2020-08-20 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:31:19 --> Input Class Initialized
INFO - 2020-08-20 15:31:19 --> Language Class Initialized
INFO - 2020-08-20 15:31:19 --> Loader Class Initialized
INFO - 2020-08-20 15:31:19 --> Helper loaded: url_helper
INFO - 2020-08-20 15:31:19 --> Database Driver Class Initialized
INFO - 2020-08-20 15:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:31:19 --> Email Class Initialized
INFO - 2020-08-20 15:31:19 --> Controller Class Initialized
INFO - 2020-08-20 15:31:19 --> Model Class Initialized
INFO - 2020-08-20 15:31:19 --> Model Class Initialized
DEBUG - 2020-08-20 15:31:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:31:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:31:19 --> Final output sent to browser
DEBUG - 2020-08-20 15:31:19 --> Total execution time: 0.1329
INFO - 2020-08-20 15:31:20 --> Config Class Initialized
INFO - 2020-08-20 15:31:20 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:31:20 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:31:20 --> Utf8 Class Initialized
INFO - 2020-08-20 15:31:20 --> URI Class Initialized
DEBUG - 2020-08-20 15:31:20 --> No URI present. Default controller set.
INFO - 2020-08-20 15:31:20 --> Router Class Initialized
INFO - 2020-08-20 15:31:20 --> Output Class Initialized
INFO - 2020-08-20 15:31:20 --> Security Class Initialized
DEBUG - 2020-08-20 15:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:31:20 --> Input Class Initialized
INFO - 2020-08-20 15:31:20 --> Language Class Initialized
INFO - 2020-08-20 15:31:20 --> Loader Class Initialized
INFO - 2020-08-20 15:31:20 --> Helper loaded: url_helper
INFO - 2020-08-20 15:31:20 --> Database Driver Class Initialized
INFO - 2020-08-20 15:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:31:20 --> Email Class Initialized
INFO - 2020-08-20 15:31:20 --> Controller Class Initialized
INFO - 2020-08-20 15:31:20 --> Model Class Initialized
INFO - 2020-08-20 15:31:20 --> Model Class Initialized
DEBUG - 2020-08-20 15:31:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:31:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:31:20 --> Final output sent to browser
DEBUG - 2020-08-20 15:31:20 --> Total execution time: 0.0215
INFO - 2020-08-20 15:55:51 --> Config Class Initialized
INFO - 2020-08-20 15:55:51 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:55:51 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:55:51 --> Utf8 Class Initialized
INFO - 2020-08-20 15:55:51 --> URI Class Initialized
DEBUG - 2020-08-20 15:55:51 --> No URI present. Default controller set.
INFO - 2020-08-20 15:55:51 --> Router Class Initialized
INFO - 2020-08-20 15:55:51 --> Output Class Initialized
INFO - 2020-08-20 15:55:51 --> Security Class Initialized
DEBUG - 2020-08-20 15:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:55:51 --> Input Class Initialized
INFO - 2020-08-20 15:55:51 --> Language Class Initialized
INFO - 2020-08-20 15:55:51 --> Loader Class Initialized
INFO - 2020-08-20 15:55:51 --> Helper loaded: url_helper
INFO - 2020-08-20 15:55:51 --> Database Driver Class Initialized
INFO - 2020-08-20 15:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:55:51 --> Email Class Initialized
INFO - 2020-08-20 15:55:51 --> Controller Class Initialized
INFO - 2020-08-20 15:55:51 --> Model Class Initialized
INFO - 2020-08-20 15:55:51 --> Model Class Initialized
DEBUG - 2020-08-20 15:55:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:55:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:55:51 --> Final output sent to browser
DEBUG - 2020-08-20 15:55:51 --> Total execution time: 0.0246
INFO - 2020-08-20 15:56:06 --> Config Class Initialized
INFO - 2020-08-20 15:56:06 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:06 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:06 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:06 --> URI Class Initialized
INFO - 2020-08-20 15:56:06 --> Router Class Initialized
INFO - 2020-08-20 15:56:06 --> Output Class Initialized
INFO - 2020-08-20 15:56:06 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:06 --> Input Class Initialized
INFO - 2020-08-20 15:56:06 --> Language Class Initialized
INFO - 2020-08-20 15:56:06 --> Loader Class Initialized
INFO - 2020-08-20 15:56:06 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:06 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:06 --> Email Class Initialized
INFO - 2020-08-20 15:56:06 --> Controller Class Initialized
INFO - 2020-08-20 15:56:06 --> Model Class Initialized
INFO - 2020-08-20 15:56:06 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 15:56:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:06 --> Config Class Initialized
INFO - 2020-08-20 15:56:06 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:06 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:06 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:06 --> URI Class Initialized
INFO - 2020-08-20 15:56:06 --> Router Class Initialized
INFO - 2020-08-20 15:56:06 --> Output Class Initialized
INFO - 2020-08-20 15:56:06 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:06 --> Input Class Initialized
INFO - 2020-08-20 15:56:06 --> Language Class Initialized
INFO - 2020-08-20 15:56:06 --> Loader Class Initialized
INFO - 2020-08-20 15:56:06 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:06 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:06 --> Email Class Initialized
INFO - 2020-08-20 15:56:06 --> Controller Class Initialized
INFO - 2020-08-20 15:56:06 --> Model Class Initialized
INFO - 2020-08-20 15:56:06 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:06 --> Config Class Initialized
INFO - 2020-08-20 15:56:06 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:06 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:06 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:06 --> URI Class Initialized
DEBUG - 2020-08-20 15:56:06 --> No URI present. Default controller set.
INFO - 2020-08-20 15:56:06 --> Router Class Initialized
INFO - 2020-08-20 15:56:06 --> Output Class Initialized
INFO - 2020-08-20 15:56:06 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:06 --> Input Class Initialized
INFO - 2020-08-20 15:56:06 --> Language Class Initialized
INFO - 2020-08-20 15:56:06 --> Loader Class Initialized
INFO - 2020-08-20 15:56:06 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:06 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:06 --> Email Class Initialized
INFO - 2020-08-20 15:56:06 --> Controller Class Initialized
INFO - 2020-08-20 15:56:06 --> Model Class Initialized
INFO - 2020-08-20 15:56:06 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:56:06 --> Final output sent to browser
DEBUG - 2020-08-20 15:56:06 --> Total execution time: 0.0199
INFO - 2020-08-20 15:56:07 --> Config Class Initialized
INFO - 2020-08-20 15:56:07 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:07 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:07 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:07 --> URI Class Initialized
DEBUG - 2020-08-20 15:56:07 --> No URI present. Default controller set.
INFO - 2020-08-20 15:56:07 --> Router Class Initialized
INFO - 2020-08-20 15:56:07 --> Output Class Initialized
INFO - 2020-08-20 15:56:07 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:07 --> Input Class Initialized
INFO - 2020-08-20 15:56:07 --> Language Class Initialized
INFO - 2020-08-20 15:56:07 --> Loader Class Initialized
INFO - 2020-08-20 15:56:07 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:07 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:07 --> Email Class Initialized
INFO - 2020-08-20 15:56:07 --> Controller Class Initialized
INFO - 2020-08-20 15:56:07 --> Model Class Initialized
INFO - 2020-08-20 15:56:07 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:56:07 --> Final output sent to browser
DEBUG - 2020-08-20 15:56:07 --> Total execution time: 0.0228
INFO - 2020-08-20 15:56:19 --> Config Class Initialized
INFO - 2020-08-20 15:56:19 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:19 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:19 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:19 --> URI Class Initialized
INFO - 2020-08-20 15:56:19 --> Router Class Initialized
INFO - 2020-08-20 15:56:19 --> Output Class Initialized
INFO - 2020-08-20 15:56:19 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:19 --> Input Class Initialized
INFO - 2020-08-20 15:56:19 --> Language Class Initialized
INFO - 2020-08-20 15:56:19 --> Loader Class Initialized
INFO - 2020-08-20 15:56:19 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:19 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:19 --> Email Class Initialized
INFO - 2020-08-20 15:56:19 --> Controller Class Initialized
INFO - 2020-08-20 15:56:19 --> Model Class Initialized
INFO - 2020-08-20 15:56:19 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:20 --> Config Class Initialized
INFO - 2020-08-20 15:56:20 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:20 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:20 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:20 --> URI Class Initialized
INFO - 2020-08-20 15:56:20 --> Router Class Initialized
INFO - 2020-08-20 15:56:20 --> Output Class Initialized
INFO - 2020-08-20 15:56:20 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:20 --> Input Class Initialized
INFO - 2020-08-20 15:56:20 --> Language Class Initialized
INFO - 2020-08-20 15:56:20 --> Loader Class Initialized
INFO - 2020-08-20 15:56:20 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:20 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:20 --> Email Class Initialized
INFO - 2020-08-20 15:56:20 --> Controller Class Initialized
INFO - 2020-08-20 15:56:20 --> Model Class Initialized
INFO - 2020-08-20 15:56:20 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 15:56:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:20 --> Config Class Initialized
INFO - 2020-08-20 15:56:20 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:20 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:20 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:20 --> URI Class Initialized
DEBUG - 2020-08-20 15:56:20 --> No URI present. Default controller set.
INFO - 2020-08-20 15:56:20 --> Router Class Initialized
INFO - 2020-08-20 15:56:20 --> Output Class Initialized
INFO - 2020-08-20 15:56:20 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:20 --> Input Class Initialized
INFO - 2020-08-20 15:56:20 --> Language Class Initialized
INFO - 2020-08-20 15:56:20 --> Loader Class Initialized
INFO - 2020-08-20 15:56:20 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:20 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:20 --> Email Class Initialized
INFO - 2020-08-20 15:56:20 --> Controller Class Initialized
INFO - 2020-08-20 15:56:20 --> Model Class Initialized
INFO - 2020-08-20 15:56:20 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:56:20 --> Final output sent to browser
DEBUG - 2020-08-20 15:56:20 --> Total execution time: 0.0225
INFO - 2020-08-20 15:56:21 --> Config Class Initialized
INFO - 2020-08-20 15:56:21 --> Hooks Class Initialized
DEBUG - 2020-08-20 15:56:21 --> UTF-8 Support Enabled
INFO - 2020-08-20 15:56:21 --> Utf8 Class Initialized
INFO - 2020-08-20 15:56:21 --> URI Class Initialized
DEBUG - 2020-08-20 15:56:21 --> No URI present. Default controller set.
INFO - 2020-08-20 15:56:21 --> Router Class Initialized
INFO - 2020-08-20 15:56:21 --> Output Class Initialized
INFO - 2020-08-20 15:56:21 --> Security Class Initialized
DEBUG - 2020-08-20 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 15:56:21 --> Input Class Initialized
INFO - 2020-08-20 15:56:21 --> Language Class Initialized
INFO - 2020-08-20 15:56:21 --> Loader Class Initialized
INFO - 2020-08-20 15:56:21 --> Helper loaded: url_helper
INFO - 2020-08-20 15:56:21 --> Database Driver Class Initialized
INFO - 2020-08-20 15:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 15:56:21 --> Email Class Initialized
INFO - 2020-08-20 15:56:21 --> Controller Class Initialized
INFO - 2020-08-20 15:56:21 --> Model Class Initialized
INFO - 2020-08-20 15:56:21 --> Model Class Initialized
DEBUG - 2020-08-20 15:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 15:56:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 15:56:21 --> Final output sent to browser
DEBUG - 2020-08-20 15:56:21 --> Total execution time: 0.0225
INFO - 2020-08-20 21:02:17 --> Config Class Initialized
INFO - 2020-08-20 21:02:17 --> Hooks Class Initialized
DEBUG - 2020-08-20 21:02:17 --> UTF-8 Support Enabled
INFO - 2020-08-20 21:02:17 --> Utf8 Class Initialized
INFO - 2020-08-20 21:02:17 --> URI Class Initialized
DEBUG - 2020-08-20 21:02:17 --> No URI present. Default controller set.
INFO - 2020-08-20 21:02:17 --> Router Class Initialized
INFO - 2020-08-20 21:02:17 --> Output Class Initialized
INFO - 2020-08-20 21:02:17 --> Security Class Initialized
DEBUG - 2020-08-20 21:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 21:02:17 --> Input Class Initialized
INFO - 2020-08-20 21:02:17 --> Language Class Initialized
INFO - 2020-08-20 21:02:17 --> Loader Class Initialized
INFO - 2020-08-20 21:02:17 --> Helper loaded: url_helper
INFO - 2020-08-20 21:02:17 --> Database Driver Class Initialized
INFO - 2020-08-20 21:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 21:02:17 --> Email Class Initialized
INFO - 2020-08-20 21:02:17 --> Controller Class Initialized
INFO - 2020-08-20 21:02:17 --> Model Class Initialized
INFO - 2020-08-20 21:02:17 --> Model Class Initialized
DEBUG - 2020-08-20 21:02:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 21:02:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 21:02:17 --> Final output sent to browser
DEBUG - 2020-08-20 21:02:17 --> Total execution time: 0.0398
INFO - 2020-08-20 21:02:28 --> Config Class Initialized
INFO - 2020-08-20 21:02:28 --> Hooks Class Initialized
DEBUG - 2020-08-20 21:02:28 --> UTF-8 Support Enabled
INFO - 2020-08-20 21:02:28 --> Utf8 Class Initialized
INFO - 2020-08-20 21:02:28 --> URI Class Initialized
INFO - 2020-08-20 21:02:28 --> Router Class Initialized
INFO - 2020-08-20 21:02:28 --> Output Class Initialized
INFO - 2020-08-20 21:02:28 --> Security Class Initialized
DEBUG - 2020-08-20 21:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 21:02:28 --> Input Class Initialized
INFO - 2020-08-20 21:02:28 --> Language Class Initialized
INFO - 2020-08-20 21:02:28 --> Loader Class Initialized
INFO - 2020-08-20 21:02:28 --> Helper loaded: url_helper
INFO - 2020-08-20 21:02:28 --> Config Class Initialized
INFO - 2020-08-20 21:02:28 --> Hooks Class Initialized
INFO - 2020-08-20 21:02:28 --> Database Driver Class Initialized
DEBUG - 2020-08-20 21:02:28 --> UTF-8 Support Enabled
INFO - 2020-08-20 21:02:28 --> Utf8 Class Initialized
INFO - 2020-08-20 21:02:28 --> URI Class Initialized
INFO - 2020-08-20 21:02:28 --> Router Class Initialized
INFO - 2020-08-20 21:02:28 --> Output Class Initialized
INFO - 2020-08-20 21:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 21:02:28 --> Security Class Initialized
DEBUG - 2020-08-20 21:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 21:02:28 --> Input Class Initialized
INFO - 2020-08-20 21:02:28 --> Language Class Initialized
INFO - 2020-08-20 21:02:28 --> Loader Class Initialized
INFO - 2020-08-20 21:02:28 --> Helper loaded: url_helper
INFO - 2020-08-20 21:02:28 --> Email Class Initialized
INFO - 2020-08-20 21:02:28 --> Controller Class Initialized
INFO - 2020-08-20 21:02:28 --> Model Class Initialized
INFO - 2020-08-20 21:02:28 --> Model Class Initialized
DEBUG - 2020-08-20 21:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 21:02:28 --> Database Driver Class Initialized
INFO - 2020-08-20 21:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 21:02:28 --> Email Class Initialized
INFO - 2020-08-20 21:02:28 --> Controller Class Initialized
INFO - 2020-08-20 21:02:28 --> Model Class Initialized
INFO - 2020-08-20 21:02:28 --> Model Class Initialized
DEBUG - 2020-08-20 21:02:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-20 21:02:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-20 21:02:28 --> Config Class Initialized
INFO - 2020-08-20 21:02:28 --> Hooks Class Initialized
DEBUG - 2020-08-20 21:02:28 --> UTF-8 Support Enabled
INFO - 2020-08-20 21:02:28 --> Utf8 Class Initialized
INFO - 2020-08-20 21:02:28 --> URI Class Initialized
DEBUG - 2020-08-20 21:02:28 --> No URI present. Default controller set.
INFO - 2020-08-20 21:02:28 --> Router Class Initialized
INFO - 2020-08-20 21:02:28 --> Output Class Initialized
INFO - 2020-08-20 21:02:28 --> Security Class Initialized
DEBUG - 2020-08-20 21:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 21:02:28 --> Input Class Initialized
INFO - 2020-08-20 21:02:28 --> Language Class Initialized
INFO - 2020-08-20 21:02:28 --> Loader Class Initialized
INFO - 2020-08-20 21:02:28 --> Helper loaded: url_helper
INFO - 2020-08-20 21:02:28 --> Database Driver Class Initialized
INFO - 2020-08-20 21:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 21:02:28 --> Email Class Initialized
INFO - 2020-08-20 21:02:28 --> Controller Class Initialized
INFO - 2020-08-20 21:02:28 --> Model Class Initialized
INFO - 2020-08-20 21:02:28 --> Model Class Initialized
DEBUG - 2020-08-20 21:02:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 21:02:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 21:02:28 --> Final output sent to browser
DEBUG - 2020-08-20 21:02:28 --> Total execution time: 0.0200
INFO - 2020-08-20 21:02:29 --> Config Class Initialized
INFO - 2020-08-20 21:02:29 --> Hooks Class Initialized
DEBUG - 2020-08-20 21:02:29 --> UTF-8 Support Enabled
INFO - 2020-08-20 21:02:29 --> Utf8 Class Initialized
INFO - 2020-08-20 21:02:29 --> URI Class Initialized
DEBUG - 2020-08-20 21:02:29 --> No URI present. Default controller set.
INFO - 2020-08-20 21:02:29 --> Router Class Initialized
INFO - 2020-08-20 21:02:29 --> Output Class Initialized
INFO - 2020-08-20 21:02:29 --> Security Class Initialized
DEBUG - 2020-08-20 21:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-20 21:02:29 --> Input Class Initialized
INFO - 2020-08-20 21:02:29 --> Language Class Initialized
INFO - 2020-08-20 21:02:29 --> Loader Class Initialized
INFO - 2020-08-20 21:02:29 --> Helper loaded: url_helper
INFO - 2020-08-20 21:02:29 --> Database Driver Class Initialized
INFO - 2020-08-20 21:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-20 21:02:29 --> Email Class Initialized
INFO - 2020-08-20 21:02:29 --> Controller Class Initialized
INFO - 2020-08-20 21:02:29 --> Model Class Initialized
INFO - 2020-08-20 21:02:29 --> Model Class Initialized
DEBUG - 2020-08-20 21:02:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-20 21:02:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-20 21:02:29 --> Final output sent to browser
DEBUG - 2020-08-20 21:02:29 --> Total execution time: 0.0234
