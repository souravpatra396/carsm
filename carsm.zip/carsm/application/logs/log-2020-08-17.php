<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-17 05:59:17 --> Config Class Initialized
INFO - 2020-08-17 05:59:17 --> Hooks Class Initialized
DEBUG - 2020-08-17 05:59:17 --> UTF-8 Support Enabled
INFO - 2020-08-17 05:59:17 --> Utf8 Class Initialized
INFO - 2020-08-17 05:59:17 --> URI Class Initialized
DEBUG - 2020-08-17 05:59:17 --> No URI present. Default controller set.
INFO - 2020-08-17 05:59:17 --> Router Class Initialized
INFO - 2020-08-17 05:59:17 --> Output Class Initialized
INFO - 2020-08-17 05:59:17 --> Security Class Initialized
DEBUG - 2020-08-17 05:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 05:59:17 --> Input Class Initialized
INFO - 2020-08-17 05:59:17 --> Language Class Initialized
INFO - 2020-08-17 05:59:17 --> Loader Class Initialized
INFO - 2020-08-17 05:59:17 --> Helper loaded: url_helper
INFO - 2020-08-17 05:59:17 --> Database Driver Class Initialized
INFO - 2020-08-17 05:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 05:59:17 --> Email Class Initialized
INFO - 2020-08-17 05:59:17 --> Controller Class Initialized
INFO - 2020-08-17 05:59:17 --> Model Class Initialized
INFO - 2020-08-17 05:59:17 --> Model Class Initialized
DEBUG - 2020-08-17 05:59:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 05:59:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 05:59:18 --> Final output sent to browser
DEBUG - 2020-08-17 05:59:18 --> Total execution time: 0.1227
INFO - 2020-08-17 06:01:14 --> Config Class Initialized
INFO - 2020-08-17 06:01:14 --> Config Class Initialized
INFO - 2020-08-17 06:01:14 --> Hooks Class Initialized
INFO - 2020-08-17 06:01:14 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:01:14 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:14 --> Utf8 Class Initialized
DEBUG - 2020-08-17 06:01:14 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:14 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:14 --> URI Class Initialized
INFO - 2020-08-17 06:01:14 --> URI Class Initialized
INFO - 2020-08-17 06:01:14 --> Router Class Initialized
INFO - 2020-08-17 06:01:14 --> Router Class Initialized
INFO - 2020-08-17 06:01:14 --> Output Class Initialized
INFO - 2020-08-17 06:01:14 --> Output Class Initialized
INFO - 2020-08-17 06:01:14 --> Security Class Initialized
INFO - 2020-08-17 06:01:14 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:14 --> Input Class Initialized
DEBUG - 2020-08-17 06:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:14 --> Input Class Initialized
INFO - 2020-08-17 06:01:14 --> Language Class Initialized
INFO - 2020-08-17 06:01:14 --> Language Class Initialized
INFO - 2020-08-17 06:01:14 --> Loader Class Initialized
INFO - 2020-08-17 06:01:14 --> Loader Class Initialized
INFO - 2020-08-17 06:01:14 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:14 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:14 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:14 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:14 --> Email Class Initialized
INFO - 2020-08-17 06:01:14 --> Controller Class Initialized
INFO - 2020-08-17 06:01:14 --> Model Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 06:01:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:15 --> Email Class Initialized
INFO - 2020-08-17 06:01:15 --> Controller Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:15 --> Config Class Initialized
INFO - 2020-08-17 06:01:15 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:01:15 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:15 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:15 --> URI Class Initialized
DEBUG - 2020-08-17 06:01:15 --> No URI present. Default controller set.
INFO - 2020-08-17 06:01:15 --> Router Class Initialized
INFO - 2020-08-17 06:01:15 --> Output Class Initialized
INFO - 2020-08-17 06:01:15 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:15 --> Input Class Initialized
INFO - 2020-08-17 06:01:15 --> Language Class Initialized
INFO - 2020-08-17 06:01:15 --> Loader Class Initialized
INFO - 2020-08-17 06:01:15 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:15 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:15 --> Email Class Initialized
INFO - 2020-08-17 06:01:15 --> Controller Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 06:01:15 --> Final output sent to browser
DEBUG - 2020-08-17 06:01:15 --> Total execution time: 0.0376
INFO - 2020-08-17 06:01:15 --> Config Class Initialized
INFO - 2020-08-17 06:01:15 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:01:15 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:15 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:15 --> URI Class Initialized
DEBUG - 2020-08-17 06:01:15 --> No URI present. Default controller set.
INFO - 2020-08-17 06:01:15 --> Router Class Initialized
INFO - 2020-08-17 06:01:15 --> Output Class Initialized
INFO - 2020-08-17 06:01:15 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:15 --> Input Class Initialized
INFO - 2020-08-17 06:01:15 --> Language Class Initialized
INFO - 2020-08-17 06:01:15 --> Loader Class Initialized
INFO - 2020-08-17 06:01:15 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:15 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:15 --> Email Class Initialized
INFO - 2020-08-17 06:01:15 --> Controller Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
INFO - 2020-08-17 06:01:15 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 06:01:15 --> Final output sent to browser
DEBUG - 2020-08-17 06:01:15 --> Total execution time: 0.0202
INFO - 2020-08-17 06:01:38 --> Config Class Initialized
INFO - 2020-08-17 06:01:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:01:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:38 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:38 --> URI Class Initialized
INFO - 2020-08-17 06:01:38 --> Router Class Initialized
INFO - 2020-08-17 06:01:38 --> Output Class Initialized
INFO - 2020-08-17 06:01:38 --> Config Class Initialized
INFO - 2020-08-17 06:01:38 --> Hooks Class Initialized
INFO - 2020-08-17 06:01:38 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:38 --> Input Class Initialized
INFO - 2020-08-17 06:01:38 --> Language Class Initialized
DEBUG - 2020-08-17 06:01:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:38 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:38 --> URI Class Initialized
INFO - 2020-08-17 06:01:38 --> Router Class Initialized
INFO - 2020-08-17 06:01:38 --> Loader Class Initialized
INFO - 2020-08-17 06:01:38 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:38 --> Output Class Initialized
INFO - 2020-08-17 06:01:38 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:38 --> Input Class Initialized
INFO - 2020-08-17 06:01:38 --> Language Class Initialized
INFO - 2020-08-17 06:01:38 --> Loader Class Initialized
INFO - 2020-08-17 06:01:38 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:38 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:38 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:38 --> Email Class Initialized
INFO - 2020-08-17 06:01:38 --> Controller Class Initialized
INFO - 2020-08-17 06:01:38 --> Model Class Initialized
INFO - 2020-08-17 06:01:38 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 06:01:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:38 --> Email Class Initialized
INFO - 2020-08-17 06:01:38 --> Controller Class Initialized
INFO - 2020-08-17 06:01:38 --> Model Class Initialized
INFO - 2020-08-17 06:01:38 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:38 --> Config Class Initialized
INFO - 2020-08-17 06:01:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:01:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:38 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:38 --> URI Class Initialized
DEBUG - 2020-08-17 06:01:38 --> No URI present. Default controller set.
INFO - 2020-08-17 06:01:38 --> Router Class Initialized
INFO - 2020-08-17 06:01:38 --> Output Class Initialized
INFO - 2020-08-17 06:01:38 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:38 --> Input Class Initialized
INFO - 2020-08-17 06:01:38 --> Language Class Initialized
INFO - 2020-08-17 06:01:38 --> Loader Class Initialized
INFO - 2020-08-17 06:01:38 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:38 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:38 --> Email Class Initialized
INFO - 2020-08-17 06:01:38 --> Controller Class Initialized
INFO - 2020-08-17 06:01:38 --> Model Class Initialized
INFO - 2020-08-17 06:01:38 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 06:01:38 --> Final output sent to browser
DEBUG - 2020-08-17 06:01:38 --> Total execution time: 0.0195
INFO - 2020-08-17 06:01:39 --> Config Class Initialized
INFO - 2020-08-17 06:01:39 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:01:39 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:01:39 --> Utf8 Class Initialized
INFO - 2020-08-17 06:01:39 --> URI Class Initialized
DEBUG - 2020-08-17 06:01:39 --> No URI present. Default controller set.
INFO - 2020-08-17 06:01:39 --> Router Class Initialized
INFO - 2020-08-17 06:01:39 --> Output Class Initialized
INFO - 2020-08-17 06:01:39 --> Security Class Initialized
DEBUG - 2020-08-17 06:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:01:39 --> Input Class Initialized
INFO - 2020-08-17 06:01:39 --> Language Class Initialized
INFO - 2020-08-17 06:01:39 --> Loader Class Initialized
INFO - 2020-08-17 06:01:39 --> Helper loaded: url_helper
INFO - 2020-08-17 06:01:39 --> Database Driver Class Initialized
INFO - 2020-08-17 06:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:01:39 --> Email Class Initialized
INFO - 2020-08-17 06:01:39 --> Controller Class Initialized
INFO - 2020-08-17 06:01:39 --> Model Class Initialized
INFO - 2020-08-17 06:01:39 --> Model Class Initialized
DEBUG - 2020-08-17 06:01:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:01:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 06:01:39 --> Final output sent to browser
DEBUG - 2020-08-17 06:01:39 --> Total execution time: 0.0209
INFO - 2020-08-17 06:02:01 --> Config Class Initialized
INFO - 2020-08-17 06:02:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:02:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:02:01 --> Utf8 Class Initialized
INFO - 2020-08-17 06:02:01 --> URI Class Initialized
INFO - 2020-08-17 06:02:01 --> Router Class Initialized
INFO - 2020-08-17 06:02:01 --> Output Class Initialized
INFO - 2020-08-17 06:02:01 --> Security Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:02:01 --> Input Class Initialized
INFO - 2020-08-17 06:02:01 --> Language Class Initialized
INFO - 2020-08-17 06:02:01 --> Loader Class Initialized
INFO - 2020-08-17 06:02:01 --> Helper loaded: url_helper
INFO - 2020-08-17 06:02:01 --> Database Driver Class Initialized
INFO - 2020-08-17 06:02:01 --> Config Class Initialized
INFO - 2020-08-17 06:02:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:02:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:02:01 --> Utf8 Class Initialized
INFO - 2020-08-17 06:02:01 --> URI Class Initialized
INFO - 2020-08-17 06:02:01 --> Router Class Initialized
INFO - 2020-08-17 06:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:02:01 --> Output Class Initialized
INFO - 2020-08-17 06:02:01 --> Security Class Initialized
INFO - 2020-08-17 06:02:01 --> Email Class Initialized
INFO - 2020-08-17 06:02:01 --> Controller Class Initialized
INFO - 2020-08-17 06:02:01 --> Model Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:02:01 --> Input Class Initialized
INFO - 2020-08-17 06:02:01 --> Language Class Initialized
INFO - 2020-08-17 06:02:01 --> Model Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 06:02:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:02:01 --> Loader Class Initialized
INFO - 2020-08-17 06:02:01 --> Helper loaded: url_helper
INFO - 2020-08-17 06:02:01 --> Database Driver Class Initialized
INFO - 2020-08-17 06:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:02:01 --> Email Class Initialized
INFO - 2020-08-17 06:02:01 --> Controller Class Initialized
INFO - 2020-08-17 06:02:01 --> Model Class Initialized
INFO - 2020-08-17 06:02:01 --> Model Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:02:01 --> Config Class Initialized
INFO - 2020-08-17 06:02:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:02:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:02:01 --> Utf8 Class Initialized
INFO - 2020-08-17 06:02:01 --> URI Class Initialized
DEBUG - 2020-08-17 06:02:01 --> No URI present. Default controller set.
INFO - 2020-08-17 06:02:01 --> Router Class Initialized
INFO - 2020-08-17 06:02:01 --> Output Class Initialized
INFO - 2020-08-17 06:02:01 --> Security Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:02:01 --> Input Class Initialized
INFO - 2020-08-17 06:02:01 --> Language Class Initialized
INFO - 2020-08-17 06:02:01 --> Loader Class Initialized
INFO - 2020-08-17 06:02:01 --> Helper loaded: url_helper
INFO - 2020-08-17 06:02:01 --> Database Driver Class Initialized
INFO - 2020-08-17 06:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:02:01 --> Email Class Initialized
INFO - 2020-08-17 06:02:01 --> Controller Class Initialized
INFO - 2020-08-17 06:02:01 --> Model Class Initialized
INFO - 2020-08-17 06:02:01 --> Model Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:02:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 06:02:01 --> Final output sent to browser
DEBUG - 2020-08-17 06:02:01 --> Total execution time: 0.0247
INFO - 2020-08-17 06:02:01 --> Config Class Initialized
INFO - 2020-08-17 06:02:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:02:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:02:01 --> Utf8 Class Initialized
INFO - 2020-08-17 06:02:01 --> URI Class Initialized
INFO - 2020-08-17 06:02:01 --> Router Class Initialized
INFO - 2020-08-17 06:02:01 --> Output Class Initialized
INFO - 2020-08-17 06:02:01 --> Security Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:02:01 --> Input Class Initialized
INFO - 2020-08-17 06:02:01 --> Language Class Initialized
INFO - 2020-08-17 06:02:01 --> Loader Class Initialized
INFO - 2020-08-17 06:02:01 --> Helper loaded: url_helper
INFO - 2020-08-17 06:02:01 --> Database Driver Class Initialized
INFO - 2020-08-17 06:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:02:01 --> Email Class Initialized
INFO - 2020-08-17 06:02:01 --> Controller Class Initialized
DEBUG - 2020-08-17 06:02:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 06:02:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:02:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 06:02:01 --> Final output sent to browser
DEBUG - 2020-08-17 06:02:01 --> Total execution time: 0.0508
INFO - 2020-08-17 06:02:17 --> Config Class Initialized
INFO - 2020-08-17 06:02:17 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:02:17 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:02:17 --> Utf8 Class Initialized
INFO - 2020-08-17 06:02:17 --> URI Class Initialized
INFO - 2020-08-17 06:02:17 --> Router Class Initialized
INFO - 2020-08-17 06:02:17 --> Output Class Initialized
INFO - 2020-08-17 06:02:17 --> Security Class Initialized
DEBUG - 2020-08-17 06:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:02:17 --> Input Class Initialized
INFO - 2020-08-17 06:02:17 --> Language Class Initialized
INFO - 2020-08-17 06:02:17 --> Loader Class Initialized
INFO - 2020-08-17 06:02:17 --> Helper loaded: url_helper
INFO - 2020-08-17 06:02:17 --> Database Driver Class Initialized
INFO - 2020-08-17 06:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:02:17 --> Email Class Initialized
INFO - 2020-08-17 06:02:17 --> Controller Class Initialized
DEBUG - 2020-08-17 06:02:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 06:02:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:02:17 --> Model Class Initialized
INFO - 2020-08-17 06:02:17 --> Model Class Initialized
INFO - 2020-08-17 06:02:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 06:02:17 --> Final output sent to browser
DEBUG - 2020-08-17 06:02:17 --> Total execution time: 0.0592
INFO - 2020-08-17 06:02:36 --> Config Class Initialized
INFO - 2020-08-17 06:02:36 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:02:36 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:02:36 --> Utf8 Class Initialized
INFO - 2020-08-17 06:02:36 --> URI Class Initialized
INFO - 2020-08-17 06:02:36 --> Router Class Initialized
INFO - 2020-08-17 06:02:36 --> Output Class Initialized
INFO - 2020-08-17 06:02:36 --> Security Class Initialized
DEBUG - 2020-08-17 06:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:02:36 --> Input Class Initialized
INFO - 2020-08-17 06:02:36 --> Language Class Initialized
INFO - 2020-08-17 06:02:36 --> Loader Class Initialized
INFO - 2020-08-17 06:02:36 --> Helper loaded: url_helper
INFO - 2020-08-17 06:02:36 --> Database Driver Class Initialized
INFO - 2020-08-17 06:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:02:36 --> Email Class Initialized
INFO - 2020-08-17 06:02:36 --> Controller Class Initialized
DEBUG - 2020-08-17 06:02:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 06:02:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:02:36 --> Model Class Initialized
INFO - 2020-08-17 06:02:36 --> Model Class Initialized
INFO - 2020-08-17 06:02:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 06:02:36 --> Final output sent to browser
DEBUG - 2020-08-17 06:02:36 --> Total execution time: 0.0239
INFO - 2020-08-17 06:03:02 --> Config Class Initialized
INFO - 2020-08-17 06:03:02 --> Hooks Class Initialized
DEBUG - 2020-08-17 06:03:02 --> UTF-8 Support Enabled
INFO - 2020-08-17 06:03:02 --> Utf8 Class Initialized
INFO - 2020-08-17 06:03:02 --> URI Class Initialized
DEBUG - 2020-08-17 06:03:02 --> No URI present. Default controller set.
INFO - 2020-08-17 06:03:02 --> Router Class Initialized
INFO - 2020-08-17 06:03:02 --> Output Class Initialized
INFO - 2020-08-17 06:03:02 --> Security Class Initialized
DEBUG - 2020-08-17 06:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 06:03:02 --> Input Class Initialized
INFO - 2020-08-17 06:03:02 --> Language Class Initialized
INFO - 2020-08-17 06:03:02 --> Loader Class Initialized
INFO - 2020-08-17 06:03:02 --> Helper loaded: url_helper
INFO - 2020-08-17 06:03:02 --> Database Driver Class Initialized
INFO - 2020-08-17 06:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 06:03:02 --> Email Class Initialized
INFO - 2020-08-17 06:03:02 --> Controller Class Initialized
INFO - 2020-08-17 06:03:02 --> Model Class Initialized
INFO - 2020-08-17 06:03:02 --> Model Class Initialized
DEBUG - 2020-08-17 06:03:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 06:03:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 06:03:02 --> Final output sent to browser
DEBUG - 2020-08-17 06:03:02 --> Total execution time: 0.0240
INFO - 2020-08-17 15:06:28 --> Config Class Initialized
INFO - 2020-08-17 15:06:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:06:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:06:28 --> Utf8 Class Initialized
INFO - 2020-08-17 15:06:28 --> URI Class Initialized
DEBUG - 2020-08-17 15:06:28 --> No URI present. Default controller set.
INFO - 2020-08-17 15:06:28 --> Router Class Initialized
INFO - 2020-08-17 15:06:28 --> Output Class Initialized
INFO - 2020-08-17 15:06:28 --> Security Class Initialized
DEBUG - 2020-08-17 15:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:06:28 --> Input Class Initialized
INFO - 2020-08-17 15:06:28 --> Language Class Initialized
INFO - 2020-08-17 15:06:28 --> Loader Class Initialized
INFO - 2020-08-17 15:06:28 --> Helper loaded: url_helper
INFO - 2020-08-17 15:06:28 --> Database Driver Class Initialized
INFO - 2020-08-17 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:06:28 --> Email Class Initialized
INFO - 2020-08-17 15:06:28 --> Controller Class Initialized
INFO - 2020-08-17 15:06:28 --> Model Class Initialized
INFO - 2020-08-17 15:06:28 --> Model Class Initialized
DEBUG - 2020-08-17 15:06:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:06:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 15:06:28 --> Final output sent to browser
DEBUG - 2020-08-17 15:06:28 --> Total execution time: 0.1191
INFO - 2020-08-17 15:06:38 --> Config Class Initialized
INFO - 2020-08-17 15:06:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:06:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:06:38 --> Utf8 Class Initialized
INFO - 2020-08-17 15:06:38 --> URI Class Initialized
INFO - 2020-08-17 15:06:38 --> Router Class Initialized
INFO - 2020-08-17 15:06:38 --> Output Class Initialized
INFO - 2020-08-17 15:06:38 --> Security Class Initialized
DEBUG - 2020-08-17 15:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:06:38 --> Input Class Initialized
INFO - 2020-08-17 15:06:38 --> Language Class Initialized
INFO - 2020-08-17 15:06:38 --> Loader Class Initialized
INFO - 2020-08-17 15:06:38 --> Helper loaded: url_helper
INFO - 2020-08-17 15:06:38 --> Database Driver Class Initialized
INFO - 2020-08-17 15:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:06:38 --> Email Class Initialized
INFO - 2020-08-17 15:06:38 --> Controller Class Initialized
INFO - 2020-08-17 15:06:38 --> Model Class Initialized
INFO - 2020-08-17 15:06:38 --> Model Class Initialized
DEBUG - 2020-08-17 15:06:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:06:38 --> Config Class Initialized
INFO - 2020-08-17 15:06:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:06:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:06:38 --> Utf8 Class Initialized
INFO - 2020-08-17 15:06:38 --> URI Class Initialized
INFO - 2020-08-17 15:06:38 --> Router Class Initialized
INFO - 2020-08-17 15:06:38 --> Output Class Initialized
INFO - 2020-08-17 15:06:38 --> Security Class Initialized
DEBUG - 2020-08-17 15:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:06:38 --> Input Class Initialized
INFO - 2020-08-17 15:06:38 --> Language Class Initialized
INFO - 2020-08-17 15:06:38 --> Loader Class Initialized
INFO - 2020-08-17 15:06:38 --> Helper loaded: url_helper
INFO - 2020-08-17 15:06:38 --> Database Driver Class Initialized
INFO - 2020-08-17 15:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:06:38 --> Email Class Initialized
INFO - 2020-08-17 15:06:38 --> Controller Class Initialized
INFO - 2020-08-17 15:06:38 --> Model Class Initialized
INFO - 2020-08-17 15:06:38 --> Model Class Initialized
DEBUG - 2020-08-17 15:06:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:06:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:06:38 --> Model Class Initialized
INFO - 2020-08-17 15:06:38 --> Final output sent to browser
DEBUG - 2020-08-17 15:06:38 --> Total execution time: 0.0288
INFO - 2020-08-17 15:06:39 --> Config Class Initialized
INFO - 2020-08-17 15:06:39 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:06:39 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:06:39 --> Utf8 Class Initialized
INFO - 2020-08-17 15:06:39 --> URI Class Initialized
INFO - 2020-08-17 15:06:39 --> Router Class Initialized
INFO - 2020-08-17 15:06:39 --> Output Class Initialized
INFO - 2020-08-17 15:06:39 --> Security Class Initialized
DEBUG - 2020-08-17 15:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:06:39 --> Input Class Initialized
INFO - 2020-08-17 15:06:39 --> Language Class Initialized
INFO - 2020-08-17 15:06:39 --> Loader Class Initialized
INFO - 2020-08-17 15:06:39 --> Helper loaded: url_helper
INFO - 2020-08-17 15:06:39 --> Database Driver Class Initialized
INFO - 2020-08-17 15:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:06:39 --> Email Class Initialized
INFO - 2020-08-17 15:06:39 --> Controller Class Initialized
DEBUG - 2020-08-17 15:06:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:06:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:06:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:06:39 --> Final output sent to browser
DEBUG - 2020-08-17 15:06:39 --> Total execution time: 0.0600
INFO - 2020-08-17 15:06:49 --> Config Class Initialized
INFO - 2020-08-17 15:06:49 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:06:49 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:06:49 --> Utf8 Class Initialized
INFO - 2020-08-17 15:06:49 --> URI Class Initialized
INFO - 2020-08-17 15:06:49 --> Router Class Initialized
INFO - 2020-08-17 15:06:49 --> Output Class Initialized
INFO - 2020-08-17 15:06:49 --> Security Class Initialized
DEBUG - 2020-08-17 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:06:49 --> Input Class Initialized
INFO - 2020-08-17 15:06:49 --> Language Class Initialized
INFO - 2020-08-17 15:06:49 --> Loader Class Initialized
INFO - 2020-08-17 15:06:49 --> Helper loaded: url_helper
INFO - 2020-08-17 15:06:49 --> Database Driver Class Initialized
INFO - 2020-08-17 15:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:06:49 --> Email Class Initialized
INFO - 2020-08-17 15:06:49 --> Controller Class Initialized
DEBUG - 2020-08-17 15:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:06:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:06:49 --> Model Class Initialized
INFO - 2020-08-17 15:06:49 --> Model Class Initialized
INFO - 2020-08-17 15:06:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 15:06:49 --> Final output sent to browser
DEBUG - 2020-08-17 15:06:49 --> Total execution time: 0.0609
INFO - 2020-08-17 15:06:52 --> Config Class Initialized
INFO - 2020-08-17 15:06:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:06:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:06:52 --> Utf8 Class Initialized
INFO - 2020-08-17 15:06:52 --> URI Class Initialized
INFO - 2020-08-17 15:06:52 --> Router Class Initialized
INFO - 2020-08-17 15:06:52 --> Output Class Initialized
INFO - 2020-08-17 15:06:52 --> Security Class Initialized
DEBUG - 2020-08-17 15:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:06:52 --> Input Class Initialized
INFO - 2020-08-17 15:06:52 --> Language Class Initialized
INFO - 2020-08-17 15:06:52 --> Loader Class Initialized
INFO - 2020-08-17 15:06:52 --> Helper loaded: url_helper
INFO - 2020-08-17 15:06:52 --> Database Driver Class Initialized
INFO - 2020-08-17 15:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:06:52 --> Email Class Initialized
INFO - 2020-08-17 15:06:52 --> Controller Class Initialized
DEBUG - 2020-08-17 15:06:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:06:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:06:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:06:52 --> Final output sent to browser
DEBUG - 2020-08-17 15:06:52 --> Total execution time: 0.0216
INFO - 2020-08-17 15:09:50 --> Config Class Initialized
INFO - 2020-08-17 15:09:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:09:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:09:50 --> Utf8 Class Initialized
INFO - 2020-08-17 15:09:50 --> URI Class Initialized
INFO - 2020-08-17 15:09:50 --> Router Class Initialized
INFO - 2020-08-17 15:09:50 --> Output Class Initialized
INFO - 2020-08-17 15:09:50 --> Security Class Initialized
DEBUG - 2020-08-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:09:50 --> Input Class Initialized
INFO - 2020-08-17 15:09:50 --> Language Class Initialized
INFO - 2020-08-17 15:09:50 --> Loader Class Initialized
INFO - 2020-08-17 15:09:50 --> Helper loaded: url_helper
INFO - 2020-08-17 15:09:50 --> Database Driver Class Initialized
INFO - 2020-08-17 15:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:09:50 --> Email Class Initialized
INFO - 2020-08-17 15:09:50 --> Controller Class Initialized
DEBUG - 2020-08-17 15:09:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:09:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:09:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:09:50 --> Final output sent to browser
DEBUG - 2020-08-17 15:09:50 --> Total execution time: 0.0430
INFO - 2020-08-17 15:12:24 --> Config Class Initialized
INFO - 2020-08-17 15:12:24 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:12:24 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:12:24 --> Utf8 Class Initialized
INFO - 2020-08-17 15:12:24 --> URI Class Initialized
INFO - 2020-08-17 15:12:24 --> Router Class Initialized
INFO - 2020-08-17 15:12:24 --> Output Class Initialized
INFO - 2020-08-17 15:12:24 --> Security Class Initialized
DEBUG - 2020-08-17 15:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:12:24 --> Input Class Initialized
INFO - 2020-08-17 15:12:24 --> Language Class Initialized
INFO - 2020-08-17 15:12:24 --> Loader Class Initialized
INFO - 2020-08-17 15:12:24 --> Helper loaded: url_helper
INFO - 2020-08-17 15:12:24 --> Database Driver Class Initialized
INFO - 2020-08-17 15:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:12:24 --> Email Class Initialized
INFO - 2020-08-17 15:12:24 --> Controller Class Initialized
DEBUG - 2020-08-17 15:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:12:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:12:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:12:24 --> Final output sent to browser
DEBUG - 2020-08-17 15:12:24 --> Total execution time: 0.0280
INFO - 2020-08-17 15:15:14 --> Config Class Initialized
INFO - 2020-08-17 15:15:14 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:15:14 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:15:14 --> Utf8 Class Initialized
INFO - 2020-08-17 15:15:14 --> URI Class Initialized
INFO - 2020-08-17 15:15:14 --> Router Class Initialized
INFO - 2020-08-17 15:15:14 --> Output Class Initialized
INFO - 2020-08-17 15:15:14 --> Security Class Initialized
DEBUG - 2020-08-17 15:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:15:14 --> Input Class Initialized
INFO - 2020-08-17 15:15:14 --> Language Class Initialized
INFO - 2020-08-17 15:15:14 --> Loader Class Initialized
INFO - 2020-08-17 15:15:14 --> Helper loaded: url_helper
INFO - 2020-08-17 15:15:14 --> Database Driver Class Initialized
INFO - 2020-08-17 15:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:15:14 --> Email Class Initialized
INFO - 2020-08-17 15:15:14 --> Controller Class Initialized
DEBUG - 2020-08-17 15:15:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:15:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:15:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:15:14 --> Final output sent to browser
DEBUG - 2020-08-17 15:15:14 --> Total execution time: 0.0243
INFO - 2020-08-17 15:15:42 --> Config Class Initialized
INFO - 2020-08-17 15:15:42 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:15:42 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:15:42 --> Utf8 Class Initialized
INFO - 2020-08-17 15:15:42 --> URI Class Initialized
INFO - 2020-08-17 15:15:42 --> Router Class Initialized
INFO - 2020-08-17 15:15:42 --> Output Class Initialized
INFO - 2020-08-17 15:15:42 --> Security Class Initialized
DEBUG - 2020-08-17 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:15:42 --> Input Class Initialized
INFO - 2020-08-17 15:15:42 --> Language Class Initialized
INFO - 2020-08-17 15:15:42 --> Loader Class Initialized
INFO - 2020-08-17 15:15:42 --> Helper loaded: url_helper
INFO - 2020-08-17 15:15:42 --> Database Driver Class Initialized
INFO - 2020-08-17 15:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:15:42 --> Email Class Initialized
INFO - 2020-08-17 15:15:42 --> Controller Class Initialized
DEBUG - 2020-08-17 15:15:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:15:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:15:42 --> Model Class Initialized
INFO - 2020-08-17 15:15:42 --> Model Class Initialized
INFO - 2020-08-17 15:15:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 15:15:42 --> Final output sent to browser
DEBUG - 2020-08-17 15:15:42 --> Total execution time: 0.0539
INFO - 2020-08-17 15:15:47 --> Config Class Initialized
INFO - 2020-08-17 15:15:47 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:15:47 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:15:47 --> Utf8 Class Initialized
INFO - 2020-08-17 15:15:47 --> URI Class Initialized
INFO - 2020-08-17 15:15:47 --> Router Class Initialized
INFO - 2020-08-17 15:15:47 --> Output Class Initialized
INFO - 2020-08-17 15:15:47 --> Security Class Initialized
DEBUG - 2020-08-17 15:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:15:47 --> Input Class Initialized
INFO - 2020-08-17 15:15:47 --> Language Class Initialized
INFO - 2020-08-17 15:15:47 --> Loader Class Initialized
INFO - 2020-08-17 15:15:47 --> Helper loaded: url_helper
INFO - 2020-08-17 15:15:47 --> Database Driver Class Initialized
INFO - 2020-08-17 15:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:15:47 --> Email Class Initialized
INFO - 2020-08-17 15:15:47 --> Controller Class Initialized
DEBUG - 2020-08-17 15:15:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:15:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:15:47 --> Model Class Initialized
INFO - 2020-08-17 15:15:47 --> Model Class Initialized
INFO - 2020-08-17 15:15:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 15:15:47 --> Final output sent to browser
DEBUG - 2020-08-17 15:15:47 --> Total execution time: 0.0378
INFO - 2020-08-17 15:15:56 --> Config Class Initialized
INFO - 2020-08-17 15:15:56 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:15:56 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:15:56 --> Utf8 Class Initialized
INFO - 2020-08-17 15:15:56 --> URI Class Initialized
INFO - 2020-08-17 15:15:56 --> Router Class Initialized
INFO - 2020-08-17 15:15:56 --> Output Class Initialized
INFO - 2020-08-17 15:15:56 --> Security Class Initialized
DEBUG - 2020-08-17 15:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:15:56 --> Input Class Initialized
INFO - 2020-08-17 15:15:56 --> Language Class Initialized
INFO - 2020-08-17 15:15:56 --> Loader Class Initialized
INFO - 2020-08-17 15:15:56 --> Helper loaded: url_helper
INFO - 2020-08-17 15:15:56 --> Database Driver Class Initialized
INFO - 2020-08-17 15:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:15:56 --> Email Class Initialized
INFO - 2020-08-17 15:15:56 --> Controller Class Initialized
DEBUG - 2020-08-17 15:15:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:15:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:15:56 --> Model Class Initialized
INFO - 2020-08-17 15:15:56 --> Model Class Initialized
INFO - 2020-08-17 15:15:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 15:15:56 --> Final output sent to browser
DEBUG - 2020-08-17 15:15:56 --> Total execution time: 0.0262
INFO - 2020-08-17 15:15:58 --> Config Class Initialized
INFO - 2020-08-17 15:15:58 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:15:58 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:15:58 --> Utf8 Class Initialized
INFO - 2020-08-17 15:15:58 --> URI Class Initialized
INFO - 2020-08-17 15:15:58 --> Router Class Initialized
INFO - 2020-08-17 15:15:58 --> Output Class Initialized
INFO - 2020-08-17 15:15:58 --> Security Class Initialized
DEBUG - 2020-08-17 15:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:15:58 --> Input Class Initialized
INFO - 2020-08-17 15:15:58 --> Language Class Initialized
INFO - 2020-08-17 15:15:58 --> Loader Class Initialized
INFO - 2020-08-17 15:15:58 --> Helper loaded: url_helper
INFO - 2020-08-17 15:15:58 --> Database Driver Class Initialized
INFO - 2020-08-17 15:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:15:58 --> Email Class Initialized
INFO - 2020-08-17 15:15:58 --> Controller Class Initialized
DEBUG - 2020-08-17 15:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:15:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:15:58 --> Model Class Initialized
INFO - 2020-08-17 15:15:58 --> Model Class Initialized
INFO - 2020-08-17 15:15:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 15:15:58 --> Final output sent to browser
DEBUG - 2020-08-17 15:15:58 --> Total execution time: 0.0410
INFO - 2020-08-17 15:16:02 --> Config Class Initialized
INFO - 2020-08-17 15:16:02 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:16:02 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:16:02 --> Utf8 Class Initialized
INFO - 2020-08-17 15:16:02 --> URI Class Initialized
INFO - 2020-08-17 15:16:02 --> Router Class Initialized
INFO - 2020-08-17 15:16:02 --> Output Class Initialized
INFO - 2020-08-17 15:16:02 --> Security Class Initialized
DEBUG - 2020-08-17 15:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:16:02 --> Input Class Initialized
INFO - 2020-08-17 15:16:02 --> Language Class Initialized
INFO - 2020-08-17 15:16:02 --> Loader Class Initialized
INFO - 2020-08-17 15:16:02 --> Helper loaded: url_helper
INFO - 2020-08-17 15:16:02 --> Database Driver Class Initialized
INFO - 2020-08-17 15:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:16:02 --> Email Class Initialized
INFO - 2020-08-17 15:16:02 --> Controller Class Initialized
DEBUG - 2020-08-17 15:16:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:16:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:16:02 --> Model Class Initialized
INFO - 2020-08-17 15:16:02 --> Model Class Initialized
INFO - 2020-08-17 15:16:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 15:16:02 --> Final output sent to browser
DEBUG - 2020-08-17 15:16:02 --> Total execution time: 0.0262
INFO - 2020-08-17 15:16:13 --> Config Class Initialized
INFO - 2020-08-17 15:16:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:16:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:16:13 --> Utf8 Class Initialized
INFO - 2020-08-17 15:16:13 --> URI Class Initialized
INFO - 2020-08-17 15:16:13 --> Router Class Initialized
INFO - 2020-08-17 15:16:13 --> Output Class Initialized
INFO - 2020-08-17 15:16:13 --> Security Class Initialized
DEBUG - 2020-08-17 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:16:13 --> Input Class Initialized
INFO - 2020-08-17 15:16:13 --> Language Class Initialized
INFO - 2020-08-17 15:16:13 --> Loader Class Initialized
INFO - 2020-08-17 15:16:13 --> Helper loaded: url_helper
INFO - 2020-08-17 15:16:13 --> Database Driver Class Initialized
INFO - 2020-08-17 15:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:16:13 --> Email Class Initialized
INFO - 2020-08-17 15:16:13 --> Controller Class Initialized
DEBUG - 2020-08-17 15:16:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:16:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:16:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:16:13 --> Final output sent to browser
DEBUG - 2020-08-17 15:16:13 --> Total execution time: 0.0242
INFO - 2020-08-17 15:20:44 --> Config Class Initialized
INFO - 2020-08-17 15:20:44 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:20:44 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:20:44 --> Utf8 Class Initialized
INFO - 2020-08-17 15:20:44 --> URI Class Initialized
INFO - 2020-08-17 15:20:44 --> Router Class Initialized
INFO - 2020-08-17 15:20:44 --> Output Class Initialized
INFO - 2020-08-17 15:20:44 --> Security Class Initialized
DEBUG - 2020-08-17 15:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:20:44 --> Input Class Initialized
INFO - 2020-08-17 15:20:44 --> Language Class Initialized
INFO - 2020-08-17 15:20:44 --> Loader Class Initialized
INFO - 2020-08-17 15:20:44 --> Helper loaded: url_helper
INFO - 2020-08-17 15:20:44 --> Database Driver Class Initialized
INFO - 2020-08-17 15:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:20:44 --> Email Class Initialized
INFO - 2020-08-17 15:20:44 --> Controller Class Initialized
DEBUG - 2020-08-17 15:20:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:20:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:20:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:20:44 --> Final output sent to browser
DEBUG - 2020-08-17 15:20:44 --> Total execution time: 0.0306
INFO - 2020-08-17 15:21:54 --> Config Class Initialized
INFO - 2020-08-17 15:21:54 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:21:54 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:21:54 --> Utf8 Class Initialized
INFO - 2020-08-17 15:21:54 --> URI Class Initialized
INFO - 2020-08-17 15:21:54 --> Router Class Initialized
INFO - 2020-08-17 15:21:54 --> Output Class Initialized
INFO - 2020-08-17 15:21:54 --> Security Class Initialized
DEBUG - 2020-08-17 15:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:21:54 --> Input Class Initialized
INFO - 2020-08-17 15:21:54 --> Language Class Initialized
INFO - 2020-08-17 15:21:54 --> Loader Class Initialized
INFO - 2020-08-17 15:21:54 --> Helper loaded: url_helper
INFO - 2020-08-17 15:21:54 --> Database Driver Class Initialized
INFO - 2020-08-17 15:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:21:54 --> Email Class Initialized
INFO - 2020-08-17 15:21:54 --> Controller Class Initialized
DEBUG - 2020-08-17 15:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:21:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:21:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:21:54 --> Final output sent to browser
DEBUG - 2020-08-17 15:21:54 --> Total execution time: 0.0226
INFO - 2020-08-17 15:39:07 --> Config Class Initialized
INFO - 2020-08-17 15:39:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:39:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:39:07 --> Utf8 Class Initialized
INFO - 2020-08-17 15:39:07 --> URI Class Initialized
INFO - 2020-08-17 15:39:07 --> Router Class Initialized
INFO - 2020-08-17 15:39:07 --> Output Class Initialized
INFO - 2020-08-17 15:39:07 --> Security Class Initialized
DEBUG - 2020-08-17 15:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:39:07 --> Input Class Initialized
INFO - 2020-08-17 15:39:07 --> Language Class Initialized
INFO - 2020-08-17 15:39:07 --> Loader Class Initialized
INFO - 2020-08-17 15:39:07 --> Helper loaded: url_helper
INFO - 2020-08-17 15:39:07 --> Database Driver Class Initialized
INFO - 2020-08-17 15:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:39:07 --> Email Class Initialized
INFO - 2020-08-17 15:39:07 --> Controller Class Initialized
DEBUG - 2020-08-17 15:39:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:39:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:39:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:39:07 --> Final output sent to browser
DEBUG - 2020-08-17 15:39:07 --> Total execution time: 0.0212
INFO - 2020-08-17 15:39:11 --> Config Class Initialized
INFO - 2020-08-17 15:39:11 --> Hooks Class Initialized
DEBUG - 2020-08-17 15:39:11 --> UTF-8 Support Enabled
INFO - 2020-08-17 15:39:11 --> Utf8 Class Initialized
INFO - 2020-08-17 15:39:11 --> URI Class Initialized
INFO - 2020-08-17 15:39:11 --> Router Class Initialized
INFO - 2020-08-17 15:39:11 --> Output Class Initialized
INFO - 2020-08-17 15:39:11 --> Security Class Initialized
DEBUG - 2020-08-17 15:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 15:39:11 --> Input Class Initialized
INFO - 2020-08-17 15:39:11 --> Language Class Initialized
INFO - 2020-08-17 15:39:11 --> Loader Class Initialized
INFO - 2020-08-17 15:39:11 --> Helper loaded: url_helper
INFO - 2020-08-17 15:39:11 --> Database Driver Class Initialized
INFO - 2020-08-17 15:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 15:39:11 --> Email Class Initialized
INFO - 2020-08-17 15:39:11 --> Controller Class Initialized
DEBUG - 2020-08-17 15:39:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 15:39:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 15:39:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 15:39:11 --> Final output sent to browser
DEBUG - 2020-08-17 15:39:11 --> Total execution time: 0.0214
INFO - 2020-08-17 16:02:44 --> Config Class Initialized
INFO - 2020-08-17 16:02:44 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:02:44 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:02:44 --> Utf8 Class Initialized
INFO - 2020-08-17 16:02:44 --> URI Class Initialized
INFO - 2020-08-17 16:02:44 --> Router Class Initialized
INFO - 2020-08-17 16:02:44 --> Output Class Initialized
INFO - 2020-08-17 16:02:44 --> Security Class Initialized
DEBUG - 2020-08-17 16:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:02:44 --> Input Class Initialized
INFO - 2020-08-17 16:02:44 --> Language Class Initialized
INFO - 2020-08-17 16:02:44 --> Loader Class Initialized
INFO - 2020-08-17 16:02:44 --> Helper loaded: url_helper
INFO - 2020-08-17 16:02:44 --> Database Driver Class Initialized
INFO - 2020-08-17 16:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:02:44 --> Email Class Initialized
INFO - 2020-08-17 16:02:44 --> Controller Class Initialized
DEBUG - 2020-08-17 16:02:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:02:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:02:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:02:44 --> Final output sent to browser
DEBUG - 2020-08-17 16:02:44 --> Total execution time: 0.0391
INFO - 2020-08-17 16:02:47 --> Config Class Initialized
INFO - 2020-08-17 16:02:47 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:02:47 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:02:47 --> Utf8 Class Initialized
INFO - 2020-08-17 16:02:47 --> URI Class Initialized
INFO - 2020-08-17 16:02:47 --> Router Class Initialized
INFO - 2020-08-17 16:02:47 --> Output Class Initialized
INFO - 2020-08-17 16:02:47 --> Security Class Initialized
DEBUG - 2020-08-17 16:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:02:47 --> Input Class Initialized
INFO - 2020-08-17 16:02:47 --> Language Class Initialized
INFO - 2020-08-17 16:02:47 --> Loader Class Initialized
INFO - 2020-08-17 16:02:47 --> Helper loaded: url_helper
INFO - 2020-08-17 16:02:47 --> Database Driver Class Initialized
INFO - 2020-08-17 16:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:02:47 --> Email Class Initialized
INFO - 2020-08-17 16:02:47 --> Controller Class Initialized
DEBUG - 2020-08-17 16:02:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:02:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:02:47 --> Model Class Initialized
INFO - 2020-08-17 16:02:47 --> Model Class Initialized
INFO - 2020-08-17 16:02:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:02:47 --> Final output sent to browser
DEBUG - 2020-08-17 16:02:47 --> Total execution time: 0.0258
INFO - 2020-08-17 16:03:10 --> Config Class Initialized
INFO - 2020-08-17 16:03:10 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:03:10 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:03:10 --> Utf8 Class Initialized
INFO - 2020-08-17 16:03:10 --> URI Class Initialized
INFO - 2020-08-17 16:03:10 --> Router Class Initialized
INFO - 2020-08-17 16:03:10 --> Output Class Initialized
INFO - 2020-08-17 16:03:10 --> Security Class Initialized
DEBUG - 2020-08-17 16:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:03:10 --> Input Class Initialized
INFO - 2020-08-17 16:03:10 --> Language Class Initialized
INFO - 2020-08-17 16:03:10 --> Loader Class Initialized
INFO - 2020-08-17 16:03:10 --> Helper loaded: url_helper
INFO - 2020-08-17 16:03:10 --> Database Driver Class Initialized
INFO - 2020-08-17 16:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:03:10 --> Email Class Initialized
INFO - 2020-08-17 16:03:10 --> Controller Class Initialized
DEBUG - 2020-08-17 16:03:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:03:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:03:10 --> Model Class Initialized
INFO - 2020-08-17 16:03:10 --> Model Class Initialized
INFO - 2020-08-17 16:03:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:03:10 --> Final output sent to browser
DEBUG - 2020-08-17 16:03:10 --> Total execution time: 0.0262
INFO - 2020-08-17 16:04:04 --> Config Class Initialized
INFO - 2020-08-17 16:04:04 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:04:04 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:04:04 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:04 --> URI Class Initialized
INFO - 2020-08-17 16:04:04 --> Router Class Initialized
INFO - 2020-08-17 16:04:04 --> Output Class Initialized
INFO - 2020-08-17 16:04:04 --> Security Class Initialized
DEBUG - 2020-08-17 16:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:04:04 --> Input Class Initialized
INFO - 2020-08-17 16:04:04 --> Language Class Initialized
INFO - 2020-08-17 16:04:04 --> Loader Class Initialized
INFO - 2020-08-17 16:04:04 --> Helper loaded: url_helper
INFO - 2020-08-17 16:04:04 --> Database Driver Class Initialized
INFO - 2020-08-17 16:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:04:04 --> Email Class Initialized
INFO - 2020-08-17 16:04:04 --> Controller Class Initialized
DEBUG - 2020-08-17 16:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:04:04 --> Model Class Initialized
INFO - 2020-08-17 16:04:04 --> Model Class Initialized
INFO - 2020-08-17 16:04:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:04:04 --> Final output sent to browser
DEBUG - 2020-08-17 16:04:04 --> Total execution time: 0.0245
INFO - 2020-08-17 16:04:08 --> Config Class Initialized
INFO - 2020-08-17 16:04:08 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:04:08 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:04:08 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:08 --> URI Class Initialized
INFO - 2020-08-17 16:04:08 --> Router Class Initialized
INFO - 2020-08-17 16:04:08 --> Output Class Initialized
INFO - 2020-08-17 16:04:08 --> Security Class Initialized
DEBUG - 2020-08-17 16:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:04:08 --> Input Class Initialized
INFO - 2020-08-17 16:04:08 --> Language Class Initialized
ERROR - 2020-08-17 16:04:08 --> 404 Page Not Found: Dealer/dealer_master
INFO - 2020-08-17 16:04:21 --> Config Class Initialized
INFO - 2020-08-17 16:04:21 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:04:21 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:04:21 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:21 --> URI Class Initialized
INFO - 2020-08-17 16:04:21 --> Router Class Initialized
INFO - 2020-08-17 16:04:21 --> Output Class Initialized
INFO - 2020-08-17 16:04:21 --> Security Class Initialized
DEBUG - 2020-08-17 16:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:04:21 --> Input Class Initialized
INFO - 2020-08-17 16:04:21 --> Language Class Initialized
INFO - 2020-08-17 16:04:21 --> Loader Class Initialized
INFO - 2020-08-17 16:04:21 --> Helper loaded: url_helper
INFO - 2020-08-17 16:04:21 --> Database Driver Class Initialized
INFO - 2020-08-17 16:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:04:21 --> Email Class Initialized
INFO - 2020-08-17 16:04:21 --> Controller Class Initialized
DEBUG - 2020-08-17 16:04:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:04:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:04:21 --> Model Class Initialized
INFO - 2020-08-17 16:04:21 --> Model Class Initialized
INFO - 2020-08-17 16:04:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:04:21 --> Final output sent to browser
DEBUG - 2020-08-17 16:04:21 --> Total execution time: 0.0267
INFO - 2020-08-17 16:04:25 --> Config Class Initialized
INFO - 2020-08-17 16:04:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:04:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:04:25 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:25 --> URI Class Initialized
DEBUG - 2020-08-17 16:04:25 --> No URI present. Default controller set.
INFO - 2020-08-17 16:04:25 --> Router Class Initialized
INFO - 2020-08-17 16:04:25 --> Output Class Initialized
INFO - 2020-08-17 16:04:25 --> Security Class Initialized
DEBUG - 2020-08-17 16:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:04:25 --> Input Class Initialized
INFO - 2020-08-17 16:04:25 --> Language Class Initialized
INFO - 2020-08-17 16:04:25 --> Loader Class Initialized
INFO - 2020-08-17 16:04:25 --> Helper loaded: url_helper
INFO - 2020-08-17 16:04:25 --> Database Driver Class Initialized
INFO - 2020-08-17 16:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:04:25 --> Email Class Initialized
INFO - 2020-08-17 16:04:25 --> Controller Class Initialized
INFO - 2020-08-17 16:04:25 --> Model Class Initialized
INFO - 2020-08-17 16:04:25 --> Model Class Initialized
DEBUG - 2020-08-17 16:04:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:04:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 16:04:25 --> Final output sent to browser
DEBUG - 2020-08-17 16:04:25 --> Total execution time: 0.0224
INFO - 2020-08-17 16:04:35 --> Config Class Initialized
INFO - 2020-08-17 16:04:35 --> Hooks Class Initialized
INFO - 2020-08-17 16:04:35 --> Config Class Initialized
INFO - 2020-08-17 16:04:35 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:04:35 --> UTF-8 Support Enabled
DEBUG - 2020-08-17 16:04:35 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:04:35 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:35 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:35 --> URI Class Initialized
INFO - 2020-08-17 16:04:35 --> URI Class Initialized
INFO - 2020-08-17 16:04:35 --> Router Class Initialized
INFO - 2020-08-17 16:04:35 --> Router Class Initialized
INFO - 2020-08-17 16:04:35 --> Output Class Initialized
INFO - 2020-08-17 16:04:35 --> Output Class Initialized
INFO - 2020-08-17 16:04:35 --> Security Class Initialized
INFO - 2020-08-17 16:04:35 --> Security Class Initialized
DEBUG - 2020-08-17 16:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-08-17 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:04:35 --> Input Class Initialized
INFO - 2020-08-17 16:04:35 --> Input Class Initialized
INFO - 2020-08-17 16:04:35 --> Language Class Initialized
INFO - 2020-08-17 16:04:35 --> Language Class Initialized
INFO - 2020-08-17 16:04:35 --> Loader Class Initialized
INFO - 2020-08-17 16:04:35 --> Loader Class Initialized
INFO - 2020-08-17 16:04:35 --> Helper loaded: url_helper
INFO - 2020-08-17 16:04:35 --> Helper loaded: url_helper
INFO - 2020-08-17 16:04:35 --> Database Driver Class Initialized
INFO - 2020-08-17 16:04:35 --> Database Driver Class Initialized
INFO - 2020-08-17 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:04:35 --> Email Class Initialized
INFO - 2020-08-17 16:04:35 --> Controller Class Initialized
INFO - 2020-08-17 16:04:35 --> Model Class Initialized
INFO - 2020-08-17 16:04:35 --> Model Class Initialized
DEBUG - 2020-08-17 16:04:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:04:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:04:35 --> Model Class Initialized
INFO - 2020-08-17 16:04:35 --> Final output sent to browser
DEBUG - 2020-08-17 16:04:35 --> Total execution time: 0.0285
INFO - 2020-08-17 16:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:04:35 --> Email Class Initialized
INFO - 2020-08-17 16:04:35 --> Controller Class Initialized
INFO - 2020-08-17 16:04:35 --> Model Class Initialized
INFO - 2020-08-17 16:04:35 --> Model Class Initialized
DEBUG - 2020-08-17 16:04:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:04:36 --> Config Class Initialized
INFO - 2020-08-17 16:04:36 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:04:36 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:04:36 --> Utf8 Class Initialized
INFO - 2020-08-17 16:04:36 --> URI Class Initialized
INFO - 2020-08-17 16:04:36 --> Router Class Initialized
INFO - 2020-08-17 16:04:36 --> Output Class Initialized
INFO - 2020-08-17 16:04:36 --> Security Class Initialized
DEBUG - 2020-08-17 16:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:04:36 --> Input Class Initialized
INFO - 2020-08-17 16:04:36 --> Language Class Initialized
INFO - 2020-08-17 16:04:36 --> Loader Class Initialized
INFO - 2020-08-17 16:04:36 --> Helper loaded: url_helper
INFO - 2020-08-17 16:04:36 --> Database Driver Class Initialized
INFO - 2020-08-17 16:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:04:36 --> Email Class Initialized
INFO - 2020-08-17 16:04:36 --> Controller Class Initialized
DEBUG - 2020-08-17 16:04:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:04:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:04:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:04:36 --> Final output sent to browser
DEBUG - 2020-08-17 16:04:36 --> Total execution time: 0.0380
INFO - 2020-08-17 16:05:39 --> Config Class Initialized
INFO - 2020-08-17 16:05:39 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:05:39 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:05:39 --> Utf8 Class Initialized
INFO - 2020-08-17 16:05:39 --> URI Class Initialized
INFO - 2020-08-17 16:05:39 --> Router Class Initialized
INFO - 2020-08-17 16:05:39 --> Output Class Initialized
INFO - 2020-08-17 16:05:39 --> Security Class Initialized
DEBUG - 2020-08-17 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:05:39 --> Input Class Initialized
INFO - 2020-08-17 16:05:39 --> Language Class Initialized
INFO - 2020-08-17 16:05:39 --> Loader Class Initialized
INFO - 2020-08-17 16:05:39 --> Helper loaded: url_helper
INFO - 2020-08-17 16:05:39 --> Database Driver Class Initialized
INFO - 2020-08-17 16:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:05:39 --> Email Class Initialized
INFO - 2020-08-17 16:05:39 --> Controller Class Initialized
DEBUG - 2020-08-17 16:05:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:05:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:05:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:05:39 --> Final output sent to browser
DEBUG - 2020-08-17 16:05:39 --> Total execution time: 0.0379
INFO - 2020-08-17 16:05:41 --> Config Class Initialized
INFO - 2020-08-17 16:05:41 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:05:41 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:05:41 --> Utf8 Class Initialized
INFO - 2020-08-17 16:05:41 --> URI Class Initialized
INFO - 2020-08-17 16:05:41 --> Router Class Initialized
INFO - 2020-08-17 16:05:41 --> Output Class Initialized
INFO - 2020-08-17 16:05:41 --> Security Class Initialized
DEBUG - 2020-08-17 16:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:05:41 --> Input Class Initialized
INFO - 2020-08-17 16:05:41 --> Language Class Initialized
INFO - 2020-08-17 16:05:41 --> Loader Class Initialized
INFO - 2020-08-17 16:05:41 --> Helper loaded: url_helper
INFO - 2020-08-17 16:05:41 --> Database Driver Class Initialized
INFO - 2020-08-17 16:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:05:41 --> Email Class Initialized
INFO - 2020-08-17 16:05:41 --> Controller Class Initialized
DEBUG - 2020-08-17 16:05:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:05:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:05:41 --> Model Class Initialized
INFO - 2020-08-17 16:05:41 --> Model Class Initialized
INFO - 2020-08-17 16:05:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:05:41 --> Final output sent to browser
DEBUG - 2020-08-17 16:05:41 --> Total execution time: 0.0251
INFO - 2020-08-17 16:05:43 --> Config Class Initialized
INFO - 2020-08-17 16:05:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:05:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:05:43 --> Utf8 Class Initialized
INFO - 2020-08-17 16:05:43 --> URI Class Initialized
INFO - 2020-08-17 16:05:43 --> Router Class Initialized
INFO - 2020-08-17 16:05:43 --> Output Class Initialized
INFO - 2020-08-17 16:05:43 --> Security Class Initialized
DEBUG - 2020-08-17 16:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:05:43 --> Input Class Initialized
INFO - 2020-08-17 16:05:43 --> Language Class Initialized
INFO - 2020-08-17 16:05:43 --> Loader Class Initialized
INFO - 2020-08-17 16:05:43 --> Helper loaded: url_helper
INFO - 2020-08-17 16:05:43 --> Database Driver Class Initialized
INFO - 2020-08-17 16:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:05:43 --> Email Class Initialized
INFO - 2020-08-17 16:05:43 --> Controller Class Initialized
DEBUG - 2020-08-17 16:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:05:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:05:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:05:43 --> Final output sent to browser
DEBUG - 2020-08-17 16:05:43 --> Total execution time: 0.0234
INFO - 2020-08-17 16:34:18 --> Config Class Initialized
INFO - 2020-08-17 16:34:18 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:34:18 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:34:18 --> Utf8 Class Initialized
INFO - 2020-08-17 16:34:18 --> URI Class Initialized
INFO - 2020-08-17 16:34:18 --> Router Class Initialized
INFO - 2020-08-17 16:34:18 --> Output Class Initialized
INFO - 2020-08-17 16:34:18 --> Security Class Initialized
DEBUG - 2020-08-17 16:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:34:18 --> Input Class Initialized
INFO - 2020-08-17 16:34:18 --> Language Class Initialized
INFO - 2020-08-17 16:34:18 --> Loader Class Initialized
INFO - 2020-08-17 16:34:18 --> Helper loaded: url_helper
INFO - 2020-08-17 16:34:18 --> Database Driver Class Initialized
INFO - 2020-08-17 16:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:34:18 --> Email Class Initialized
INFO - 2020-08-17 16:34:18 --> Controller Class Initialized
DEBUG - 2020-08-17 16:34:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:34:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:34:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:34:18 --> Final output sent to browser
DEBUG - 2020-08-17 16:34:18 --> Total execution time: 0.0215
INFO - 2020-08-17 16:34:22 --> Config Class Initialized
INFO - 2020-08-17 16:34:22 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:34:22 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:34:22 --> Utf8 Class Initialized
INFO - 2020-08-17 16:34:22 --> URI Class Initialized
INFO - 2020-08-17 16:34:22 --> Router Class Initialized
INFO - 2020-08-17 16:34:22 --> Output Class Initialized
INFO - 2020-08-17 16:34:22 --> Security Class Initialized
DEBUG - 2020-08-17 16:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:34:22 --> Input Class Initialized
INFO - 2020-08-17 16:34:22 --> Language Class Initialized
INFO - 2020-08-17 16:34:22 --> Loader Class Initialized
INFO - 2020-08-17 16:34:22 --> Helper loaded: url_helper
INFO - 2020-08-17 16:34:22 --> Database Driver Class Initialized
INFO - 2020-08-17 16:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:34:22 --> Email Class Initialized
INFO - 2020-08-17 16:34:22 --> Controller Class Initialized
DEBUG - 2020-08-17 16:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:34:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:34:22 --> Model Class Initialized
INFO - 2020-08-17 16:34:22 --> Model Class Initialized
INFO - 2020-08-17 16:34:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:34:22 --> Final output sent to browser
DEBUG - 2020-08-17 16:34:22 --> Total execution time: 0.0239
INFO - 2020-08-17 16:34:25 --> Config Class Initialized
INFO - 2020-08-17 16:34:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:34:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:34:25 --> Utf8 Class Initialized
INFO - 2020-08-17 16:34:25 --> URI Class Initialized
INFO - 2020-08-17 16:34:25 --> Router Class Initialized
INFO - 2020-08-17 16:34:25 --> Output Class Initialized
INFO - 2020-08-17 16:34:25 --> Security Class Initialized
DEBUG - 2020-08-17 16:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:34:25 --> Input Class Initialized
INFO - 2020-08-17 16:34:25 --> Language Class Initialized
INFO - 2020-08-17 16:34:25 --> Loader Class Initialized
INFO - 2020-08-17 16:34:25 --> Helper loaded: url_helper
INFO - 2020-08-17 16:34:25 --> Database Driver Class Initialized
INFO - 2020-08-17 16:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:34:25 --> Email Class Initialized
INFO - 2020-08-17 16:34:25 --> Controller Class Initialized
DEBUG - 2020-08-17 16:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:34:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:34:25 --> Model Class Initialized
INFO - 2020-08-17 16:34:25 --> Model Class Initialized
INFO - 2020-08-17 16:34:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:34:25 --> Final output sent to browser
DEBUG - 2020-08-17 16:34:25 --> Total execution time: 0.0250
INFO - 2020-08-17 16:35:05 --> Config Class Initialized
INFO - 2020-08-17 16:35:05 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:35:05 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:35:05 --> Utf8 Class Initialized
INFO - 2020-08-17 16:35:05 --> URI Class Initialized
INFO - 2020-08-17 16:35:05 --> Router Class Initialized
INFO - 2020-08-17 16:35:05 --> Output Class Initialized
INFO - 2020-08-17 16:35:05 --> Security Class Initialized
DEBUG - 2020-08-17 16:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:35:05 --> Input Class Initialized
INFO - 2020-08-17 16:35:05 --> Language Class Initialized
INFO - 2020-08-17 16:35:05 --> Loader Class Initialized
INFO - 2020-08-17 16:35:05 --> Helper loaded: url_helper
INFO - 2020-08-17 16:35:05 --> Database Driver Class Initialized
INFO - 2020-08-17 16:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:35:05 --> Email Class Initialized
INFO - 2020-08-17 16:35:05 --> Controller Class Initialized
DEBUG - 2020-08-17 16:35:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:35:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:35:05 --> Model Class Initialized
INFO - 2020-08-17 16:35:05 --> Model Class Initialized
INFO - 2020-08-17 16:35:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:35:05 --> Final output sent to browser
DEBUG - 2020-08-17 16:35:05 --> Total execution time: 0.0259
INFO - 2020-08-17 16:50:18 --> Config Class Initialized
INFO - 2020-08-17 16:50:18 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:50:18 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:50:18 --> Utf8 Class Initialized
INFO - 2020-08-17 16:50:18 --> URI Class Initialized
INFO - 2020-08-17 16:50:18 --> Router Class Initialized
INFO - 2020-08-17 16:50:18 --> Output Class Initialized
INFO - 2020-08-17 16:50:18 --> Security Class Initialized
DEBUG - 2020-08-17 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:50:18 --> Input Class Initialized
INFO - 2020-08-17 16:50:18 --> Language Class Initialized
INFO - 2020-08-17 16:50:18 --> Loader Class Initialized
INFO - 2020-08-17 16:50:18 --> Helper loaded: url_helper
INFO - 2020-08-17 16:50:18 --> Database Driver Class Initialized
INFO - 2020-08-17 16:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:50:18 --> Email Class Initialized
INFO - 2020-08-17 16:50:18 --> Controller Class Initialized
DEBUG - 2020-08-17 16:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:50:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:50:18 --> Model Class Initialized
INFO - 2020-08-17 16:50:18 --> Model Class Initialized
INFO - 2020-08-17 16:50:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:50:18 --> Final output sent to browser
DEBUG - 2020-08-17 16:50:18 --> Total execution time: 0.0362
INFO - 2020-08-17 16:50:29 --> Config Class Initialized
INFO - 2020-08-17 16:50:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:50:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:50:29 --> Utf8 Class Initialized
INFO - 2020-08-17 16:50:29 --> URI Class Initialized
INFO - 2020-08-17 16:50:29 --> Router Class Initialized
INFO - 2020-08-17 16:50:29 --> Output Class Initialized
INFO - 2020-08-17 16:50:29 --> Security Class Initialized
DEBUG - 2020-08-17 16:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:50:29 --> Input Class Initialized
INFO - 2020-08-17 16:50:29 --> Language Class Initialized
INFO - 2020-08-17 16:50:29 --> Loader Class Initialized
INFO - 2020-08-17 16:50:29 --> Helper loaded: url_helper
INFO - 2020-08-17 16:50:29 --> Database Driver Class Initialized
INFO - 2020-08-17 16:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:50:29 --> Email Class Initialized
INFO - 2020-08-17 16:50:29 --> Controller Class Initialized
DEBUG - 2020-08-17 16:50:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:50:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:50:29 --> Model Class Initialized
INFO - 2020-08-17 16:50:29 --> Model Class Initialized
ERROR - 2020-08-17 16:50:29 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-17 16:50:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:50:29 --> Final output sent to browser
DEBUG - 2020-08-17 16:50:29 --> Total execution time: 0.0397
INFO - 2020-08-17 16:51:49 --> Config Class Initialized
INFO - 2020-08-17 16:51:49 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:51:49 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:51:49 --> Utf8 Class Initialized
INFO - 2020-08-17 16:51:49 --> URI Class Initialized
INFO - 2020-08-17 16:51:50 --> Router Class Initialized
INFO - 2020-08-17 16:51:50 --> Output Class Initialized
INFO - 2020-08-17 16:51:50 --> Security Class Initialized
DEBUG - 2020-08-17 16:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:51:50 --> Input Class Initialized
INFO - 2020-08-17 16:51:50 --> Language Class Initialized
INFO - 2020-08-17 16:51:50 --> Loader Class Initialized
INFO - 2020-08-17 16:51:50 --> Helper loaded: url_helper
INFO - 2020-08-17 16:51:50 --> Database Driver Class Initialized
INFO - 2020-08-17 16:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:51:50 --> Email Class Initialized
INFO - 2020-08-17 16:51:50 --> Controller Class Initialized
DEBUG - 2020-08-17 16:51:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:51:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:51:50 --> Model Class Initialized
INFO - 2020-08-17 16:51:50 --> Model Class Initialized
INFO - 2020-08-17 16:51:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:51:50 --> Final output sent to browser
DEBUG - 2020-08-17 16:51:50 --> Total execution time: 0.0232
INFO - 2020-08-17 16:51:52 --> Config Class Initialized
INFO - 2020-08-17 16:51:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:51:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:51:52 --> Utf8 Class Initialized
INFO - 2020-08-17 16:51:52 --> URI Class Initialized
INFO - 2020-08-17 16:51:52 --> Router Class Initialized
INFO - 2020-08-17 16:51:52 --> Output Class Initialized
INFO - 2020-08-17 16:51:52 --> Security Class Initialized
DEBUG - 2020-08-17 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:51:52 --> Input Class Initialized
INFO - 2020-08-17 16:51:52 --> Language Class Initialized
INFO - 2020-08-17 16:51:52 --> Loader Class Initialized
INFO - 2020-08-17 16:51:52 --> Helper loaded: url_helper
INFO - 2020-08-17 16:51:52 --> Database Driver Class Initialized
INFO - 2020-08-17 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:51:52 --> Email Class Initialized
INFO - 2020-08-17 16:51:52 --> Controller Class Initialized
DEBUG - 2020-08-17 16:51:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:51:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:51:52 --> Model Class Initialized
INFO - 2020-08-17 16:51:52 --> Model Class Initialized
INFO - 2020-08-17 16:51:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:51:52 --> Final output sent to browser
DEBUG - 2020-08-17 16:51:52 --> Total execution time: 0.0257
INFO - 2020-08-17 16:51:55 --> Config Class Initialized
INFO - 2020-08-17 16:51:55 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:51:55 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:51:55 --> Utf8 Class Initialized
INFO - 2020-08-17 16:51:55 --> URI Class Initialized
INFO - 2020-08-17 16:51:55 --> Router Class Initialized
INFO - 2020-08-17 16:51:55 --> Output Class Initialized
INFO - 2020-08-17 16:51:55 --> Security Class Initialized
DEBUG - 2020-08-17 16:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:51:55 --> Input Class Initialized
INFO - 2020-08-17 16:51:55 --> Language Class Initialized
INFO - 2020-08-17 16:51:55 --> Loader Class Initialized
INFO - 2020-08-17 16:51:55 --> Helper loaded: url_helper
INFO - 2020-08-17 16:51:55 --> Database Driver Class Initialized
INFO - 2020-08-17 16:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:51:55 --> Email Class Initialized
INFO - 2020-08-17 16:51:55 --> Controller Class Initialized
DEBUG - 2020-08-17 16:51:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:51:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:51:55 --> Model Class Initialized
INFO - 2020-08-17 16:51:55 --> Model Class Initialized
ERROR - 2020-08-17 16:51:55 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-08-17 16:51:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:51:55 --> Final output sent to browser
DEBUG - 2020-08-17 16:51:55 --> Total execution time: 0.0348
INFO - 2020-08-17 16:52:29 --> Config Class Initialized
INFO - 2020-08-17 16:52:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:52:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:52:29 --> Utf8 Class Initialized
INFO - 2020-08-17 16:52:29 --> URI Class Initialized
INFO - 2020-08-17 16:52:29 --> Router Class Initialized
INFO - 2020-08-17 16:52:29 --> Output Class Initialized
INFO - 2020-08-17 16:52:29 --> Security Class Initialized
DEBUG - 2020-08-17 16:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:52:29 --> Input Class Initialized
INFO - 2020-08-17 16:52:29 --> Language Class Initialized
INFO - 2020-08-17 16:52:29 --> Loader Class Initialized
INFO - 2020-08-17 16:52:29 --> Helper loaded: url_helper
INFO - 2020-08-17 16:52:29 --> Database Driver Class Initialized
INFO - 2020-08-17 16:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:52:29 --> Email Class Initialized
INFO - 2020-08-17 16:52:29 --> Controller Class Initialized
DEBUG - 2020-08-17 16:52:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:52:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:52:29 --> Model Class Initialized
INFO - 2020-08-17 16:52:29 --> Model Class Initialized
INFO - 2020-08-17 16:52:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:52:29 --> Final output sent to browser
DEBUG - 2020-08-17 16:52:29 --> Total execution time: 0.0306
INFO - 2020-08-17 16:52:31 --> Config Class Initialized
INFO - 2020-08-17 16:52:31 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:52:31 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:52:31 --> Utf8 Class Initialized
INFO - 2020-08-17 16:52:31 --> URI Class Initialized
INFO - 2020-08-17 16:52:31 --> Router Class Initialized
INFO - 2020-08-17 16:52:31 --> Output Class Initialized
INFO - 2020-08-17 16:52:31 --> Security Class Initialized
DEBUG - 2020-08-17 16:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:52:31 --> Input Class Initialized
INFO - 2020-08-17 16:52:31 --> Language Class Initialized
INFO - 2020-08-17 16:52:31 --> Loader Class Initialized
INFO - 2020-08-17 16:52:31 --> Helper loaded: url_helper
INFO - 2020-08-17 16:52:31 --> Database Driver Class Initialized
INFO - 2020-08-17 16:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:52:31 --> Email Class Initialized
INFO - 2020-08-17 16:52:31 --> Controller Class Initialized
DEBUG - 2020-08-17 16:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:52:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:52:31 --> Model Class Initialized
INFO - 2020-08-17 16:52:31 --> Model Class Initialized
INFO - 2020-08-17 16:52:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:52:31 --> Final output sent to browser
DEBUG - 2020-08-17 16:52:31 --> Total execution time: 0.0362
INFO - 2020-08-17 16:52:33 --> Config Class Initialized
INFO - 2020-08-17 16:52:33 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:52:33 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:52:33 --> Utf8 Class Initialized
INFO - 2020-08-17 16:52:33 --> URI Class Initialized
INFO - 2020-08-17 16:52:33 --> Router Class Initialized
INFO - 2020-08-17 16:52:33 --> Output Class Initialized
INFO - 2020-08-17 16:52:33 --> Security Class Initialized
DEBUG - 2020-08-17 16:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:52:33 --> Input Class Initialized
INFO - 2020-08-17 16:52:33 --> Language Class Initialized
INFO - 2020-08-17 16:52:33 --> Loader Class Initialized
INFO - 2020-08-17 16:52:33 --> Helper loaded: url_helper
INFO - 2020-08-17 16:52:33 --> Database Driver Class Initialized
INFO - 2020-08-17 16:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:52:33 --> Email Class Initialized
INFO - 2020-08-17 16:52:33 --> Controller Class Initialized
DEBUG - 2020-08-17 16:52:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:52:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:52:33 --> Model Class Initialized
INFO - 2020-08-17 16:52:33 --> Model Class Initialized
INFO - 2020-08-17 16:52:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:52:33 --> Final output sent to browser
DEBUG - 2020-08-17 16:52:33 --> Total execution time: 0.0248
INFO - 2020-08-17 16:53:58 --> Config Class Initialized
INFO - 2020-08-17 16:53:58 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:53:58 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:53:58 --> Utf8 Class Initialized
INFO - 2020-08-17 16:53:58 --> URI Class Initialized
INFO - 2020-08-17 16:53:58 --> Router Class Initialized
INFO - 2020-08-17 16:53:58 --> Output Class Initialized
INFO - 2020-08-17 16:53:58 --> Security Class Initialized
DEBUG - 2020-08-17 16:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:53:58 --> Input Class Initialized
INFO - 2020-08-17 16:53:58 --> Language Class Initialized
INFO - 2020-08-17 16:53:58 --> Loader Class Initialized
INFO - 2020-08-17 16:53:58 --> Helper loaded: url_helper
INFO - 2020-08-17 16:53:58 --> Database Driver Class Initialized
INFO - 2020-08-17 16:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:53:58 --> Email Class Initialized
INFO - 2020-08-17 16:53:58 --> Controller Class Initialized
DEBUG - 2020-08-17 16:53:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:53:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:53:58 --> Model Class Initialized
INFO - 2020-08-17 16:53:58 --> Model Class Initialized
INFO - 2020-08-17 16:53:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:53:58 --> Final output sent to browser
DEBUG - 2020-08-17 16:53:58 --> Total execution time: 0.0255
INFO - 2020-08-17 16:54:00 --> Config Class Initialized
INFO - 2020-08-17 16:54:00 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:54:00 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:54:00 --> Utf8 Class Initialized
INFO - 2020-08-17 16:54:00 --> URI Class Initialized
INFO - 2020-08-17 16:54:00 --> Router Class Initialized
INFO - 2020-08-17 16:54:00 --> Output Class Initialized
INFO - 2020-08-17 16:54:00 --> Security Class Initialized
DEBUG - 2020-08-17 16:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:54:00 --> Input Class Initialized
INFO - 2020-08-17 16:54:00 --> Language Class Initialized
INFO - 2020-08-17 16:54:00 --> Loader Class Initialized
INFO - 2020-08-17 16:54:00 --> Helper loaded: url_helper
INFO - 2020-08-17 16:54:00 --> Database Driver Class Initialized
INFO - 2020-08-17 16:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:54:00 --> Email Class Initialized
INFO - 2020-08-17 16:54:00 --> Controller Class Initialized
DEBUG - 2020-08-17 16:54:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:54:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:54:00 --> Model Class Initialized
INFO - 2020-08-17 16:54:00 --> Model Class Initialized
INFO - 2020-08-17 16:54:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:54:00 --> Final output sent to browser
DEBUG - 2020-08-17 16:54:00 --> Total execution time: 0.0272
INFO - 2020-08-17 16:54:13 --> Config Class Initialized
INFO - 2020-08-17 16:54:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:54:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:54:13 --> Utf8 Class Initialized
INFO - 2020-08-17 16:54:13 --> URI Class Initialized
INFO - 2020-08-17 16:54:13 --> Router Class Initialized
INFO - 2020-08-17 16:54:13 --> Output Class Initialized
INFO - 2020-08-17 16:54:13 --> Security Class Initialized
DEBUG - 2020-08-17 16:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:54:13 --> Input Class Initialized
INFO - 2020-08-17 16:54:13 --> Language Class Initialized
INFO - 2020-08-17 16:54:13 --> Loader Class Initialized
INFO - 2020-08-17 16:54:13 --> Helper loaded: url_helper
INFO - 2020-08-17 16:54:13 --> Database Driver Class Initialized
INFO - 2020-08-17 16:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:54:13 --> Email Class Initialized
INFO - 2020-08-17 16:54:13 --> Controller Class Initialized
DEBUG - 2020-08-17 16:54:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:54:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:54:13 --> Model Class Initialized
INFO - 2020-08-17 16:54:13 --> Model Class Initialized
INFO - 2020-08-17 16:54:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 16:54:13 --> Final output sent to browser
DEBUG - 2020-08-17 16:54:13 --> Total execution time: 0.0238
INFO - 2020-08-17 16:54:14 --> Config Class Initialized
INFO - 2020-08-17 16:54:14 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:54:14 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:54:14 --> Utf8 Class Initialized
INFO - 2020-08-17 16:54:14 --> URI Class Initialized
INFO - 2020-08-17 16:54:14 --> Router Class Initialized
INFO - 2020-08-17 16:54:14 --> Output Class Initialized
INFO - 2020-08-17 16:54:14 --> Security Class Initialized
DEBUG - 2020-08-17 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:54:14 --> Input Class Initialized
INFO - 2020-08-17 16:54:14 --> Language Class Initialized
INFO - 2020-08-17 16:54:14 --> Loader Class Initialized
INFO - 2020-08-17 16:54:14 --> Helper loaded: url_helper
INFO - 2020-08-17 16:54:14 --> Database Driver Class Initialized
INFO - 2020-08-17 16:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:54:14 --> Email Class Initialized
INFO - 2020-08-17 16:54:14 --> Controller Class Initialized
DEBUG - 2020-08-17 16:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:54:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:54:14 --> Model Class Initialized
INFO - 2020-08-17 16:54:14 --> Model Class Initialized
INFO - 2020-08-17 16:54:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 16:54:14 --> Final output sent to browser
DEBUG - 2020-08-17 16:54:14 --> Total execution time: 0.0316
INFO - 2020-08-17 16:54:19 --> Config Class Initialized
INFO - 2020-08-17 16:54:19 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:54:19 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:54:19 --> Utf8 Class Initialized
INFO - 2020-08-17 16:54:19 --> URI Class Initialized
INFO - 2020-08-17 16:54:19 --> Router Class Initialized
INFO - 2020-08-17 16:54:19 --> Output Class Initialized
INFO - 2020-08-17 16:54:19 --> Security Class Initialized
DEBUG - 2020-08-17 16:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:54:19 --> Input Class Initialized
INFO - 2020-08-17 16:54:19 --> Language Class Initialized
INFO - 2020-08-17 16:54:19 --> Loader Class Initialized
INFO - 2020-08-17 16:54:19 --> Helper loaded: url_helper
INFO - 2020-08-17 16:54:19 --> Database Driver Class Initialized
INFO - 2020-08-17 16:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:54:19 --> Email Class Initialized
INFO - 2020-08-17 16:54:19 --> Controller Class Initialized
DEBUG - 2020-08-17 16:54:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:54:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:54:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:54:19 --> Final output sent to browser
DEBUG - 2020-08-17 16:54:19 --> Total execution time: 0.0281
INFO - 2020-08-17 16:55:09 --> Config Class Initialized
INFO - 2020-08-17 16:55:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:55:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:55:09 --> Utf8 Class Initialized
INFO - 2020-08-17 16:55:09 --> URI Class Initialized
DEBUG - 2020-08-17 16:55:09 --> No URI present. Default controller set.
INFO - 2020-08-17 16:55:09 --> Router Class Initialized
INFO - 2020-08-17 16:55:09 --> Output Class Initialized
INFO - 2020-08-17 16:55:09 --> Security Class Initialized
DEBUG - 2020-08-17 16:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:55:09 --> Input Class Initialized
INFO - 2020-08-17 16:55:09 --> Language Class Initialized
INFO - 2020-08-17 16:55:09 --> Loader Class Initialized
INFO - 2020-08-17 16:55:09 --> Helper loaded: url_helper
INFO - 2020-08-17 16:55:09 --> Database Driver Class Initialized
INFO - 2020-08-17 16:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:55:09 --> Email Class Initialized
INFO - 2020-08-17 16:55:09 --> Controller Class Initialized
INFO - 2020-08-17 16:55:09 --> Model Class Initialized
INFO - 2020-08-17 16:55:09 --> Model Class Initialized
DEBUG - 2020-08-17 16:55:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:55:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 16:55:09 --> Final output sent to browser
DEBUG - 2020-08-17 16:55:09 --> Total execution time: 0.0223
INFO - 2020-08-17 16:56:25 --> Config Class Initialized
INFO - 2020-08-17 16:56:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:56:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:56:25 --> Utf8 Class Initialized
INFO - 2020-08-17 16:56:25 --> URI Class Initialized
DEBUG - 2020-08-17 16:56:25 --> No URI present. Default controller set.
INFO - 2020-08-17 16:56:25 --> Router Class Initialized
INFO - 2020-08-17 16:56:25 --> Output Class Initialized
INFO - 2020-08-17 16:56:25 --> Security Class Initialized
DEBUG - 2020-08-17 16:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:56:25 --> Input Class Initialized
INFO - 2020-08-17 16:56:25 --> Language Class Initialized
INFO - 2020-08-17 16:56:25 --> Loader Class Initialized
INFO - 2020-08-17 16:56:25 --> Helper loaded: url_helper
INFO - 2020-08-17 16:56:25 --> Database Driver Class Initialized
INFO - 2020-08-17 16:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:56:25 --> Email Class Initialized
INFO - 2020-08-17 16:56:25 --> Controller Class Initialized
INFO - 2020-08-17 16:56:25 --> Model Class Initialized
INFO - 2020-08-17 16:56:25 --> Model Class Initialized
DEBUG - 2020-08-17 16:56:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:56:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 16:56:25 --> Final output sent to browser
DEBUG - 2020-08-17 16:56:25 --> Total execution time: 0.0241
INFO - 2020-08-17 16:56:29 --> Config Class Initialized
INFO - 2020-08-17 16:56:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:56:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:56:29 --> Utf8 Class Initialized
INFO - 2020-08-17 16:56:29 --> URI Class Initialized
INFO - 2020-08-17 16:56:29 --> Router Class Initialized
INFO - 2020-08-17 16:56:29 --> Output Class Initialized
INFO - 2020-08-17 16:56:29 --> Security Class Initialized
DEBUG - 2020-08-17 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:56:29 --> Input Class Initialized
INFO - 2020-08-17 16:56:29 --> Language Class Initialized
INFO - 2020-08-17 16:56:29 --> Loader Class Initialized
INFO - 2020-08-17 16:56:29 --> Helper loaded: url_helper
INFO - 2020-08-17 16:56:29 --> Database Driver Class Initialized
INFO - 2020-08-17 16:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:56:29 --> Email Class Initialized
INFO - 2020-08-17 16:56:29 --> Controller Class Initialized
INFO - 2020-08-17 16:56:29 --> Model Class Initialized
INFO - 2020-08-17 16:56:29 --> Model Class Initialized
DEBUG - 2020-08-17 16:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:56:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:56:29 --> Model Class Initialized
INFO - 2020-08-17 16:56:29 --> Final output sent to browser
DEBUG - 2020-08-17 16:56:29 --> Total execution time: 0.0220
INFO - 2020-08-17 16:56:29 --> Config Class Initialized
INFO - 2020-08-17 16:56:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:56:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:56:29 --> Utf8 Class Initialized
INFO - 2020-08-17 16:56:29 --> URI Class Initialized
INFO - 2020-08-17 16:56:29 --> Router Class Initialized
INFO - 2020-08-17 16:56:29 --> Output Class Initialized
INFO - 2020-08-17 16:56:29 --> Security Class Initialized
DEBUG - 2020-08-17 16:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:56:29 --> Input Class Initialized
INFO - 2020-08-17 16:56:29 --> Language Class Initialized
INFO - 2020-08-17 16:56:29 --> Loader Class Initialized
INFO - 2020-08-17 16:56:29 --> Helper loaded: url_helper
INFO - 2020-08-17 16:56:29 --> Database Driver Class Initialized
INFO - 2020-08-17 16:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:56:29 --> Email Class Initialized
INFO - 2020-08-17 16:56:29 --> Controller Class Initialized
INFO - 2020-08-17 16:56:29 --> Model Class Initialized
INFO - 2020-08-17 16:56:29 --> Model Class Initialized
DEBUG - 2020-08-17 16:56:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:56:30 --> Config Class Initialized
INFO - 2020-08-17 16:56:30 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:56:30 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:56:30 --> Utf8 Class Initialized
INFO - 2020-08-17 16:56:30 --> URI Class Initialized
INFO - 2020-08-17 16:56:30 --> Router Class Initialized
INFO - 2020-08-17 16:56:30 --> Output Class Initialized
INFO - 2020-08-17 16:56:30 --> Security Class Initialized
DEBUG - 2020-08-17 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:56:30 --> Input Class Initialized
INFO - 2020-08-17 16:56:30 --> Language Class Initialized
INFO - 2020-08-17 16:56:30 --> Loader Class Initialized
INFO - 2020-08-17 16:56:30 --> Helper loaded: url_helper
INFO - 2020-08-17 16:56:30 --> Database Driver Class Initialized
INFO - 2020-08-17 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:56:30 --> Email Class Initialized
INFO - 2020-08-17 16:56:30 --> Controller Class Initialized
DEBUG - 2020-08-17 16:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:56:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:56:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:56:30 --> Final output sent to browser
DEBUG - 2020-08-17 16:56:30 --> Total execution time: 0.0214
INFO - 2020-08-17 16:59:29 --> Config Class Initialized
INFO - 2020-08-17 16:59:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:59:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:59:29 --> Utf8 Class Initialized
INFO - 2020-08-17 16:59:29 --> URI Class Initialized
INFO - 2020-08-17 16:59:29 --> Router Class Initialized
INFO - 2020-08-17 16:59:29 --> Output Class Initialized
INFO - 2020-08-17 16:59:29 --> Security Class Initialized
DEBUG - 2020-08-17 16:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:59:29 --> Input Class Initialized
INFO - 2020-08-17 16:59:29 --> Language Class Initialized
INFO - 2020-08-17 16:59:29 --> Loader Class Initialized
INFO - 2020-08-17 16:59:29 --> Helper loaded: url_helper
INFO - 2020-08-17 16:59:29 --> Database Driver Class Initialized
INFO - 2020-08-17 16:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:59:29 --> Email Class Initialized
INFO - 2020-08-17 16:59:29 --> Controller Class Initialized
DEBUG - 2020-08-17 16:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:59:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:59:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:59:29 --> Final output sent to browser
DEBUG - 2020-08-17 16:59:29 --> Total execution time: 0.0254
INFO - 2020-08-17 16:59:46 --> Config Class Initialized
INFO - 2020-08-17 16:59:46 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:59:46 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:59:46 --> Utf8 Class Initialized
INFO - 2020-08-17 16:59:46 --> URI Class Initialized
INFO - 2020-08-17 16:59:46 --> Router Class Initialized
INFO - 2020-08-17 16:59:46 --> Output Class Initialized
INFO - 2020-08-17 16:59:46 --> Security Class Initialized
DEBUG - 2020-08-17 16:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:59:46 --> Input Class Initialized
INFO - 2020-08-17 16:59:46 --> Language Class Initialized
INFO - 2020-08-17 16:59:46 --> Loader Class Initialized
INFO - 2020-08-17 16:59:46 --> Helper loaded: url_helper
INFO - 2020-08-17 16:59:46 --> Database Driver Class Initialized
INFO - 2020-08-17 16:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:59:46 --> Email Class Initialized
INFO - 2020-08-17 16:59:46 --> Controller Class Initialized
DEBUG - 2020-08-17 16:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:59:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:59:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 16:59:46 --> Final output sent to browser
DEBUG - 2020-08-17 16:59:46 --> Total execution time: 0.0246
INFO - 2020-08-17 16:59:58 --> Config Class Initialized
INFO - 2020-08-17 16:59:58 --> Hooks Class Initialized
DEBUG - 2020-08-17 16:59:58 --> UTF-8 Support Enabled
INFO - 2020-08-17 16:59:58 --> Utf8 Class Initialized
INFO - 2020-08-17 16:59:58 --> URI Class Initialized
INFO - 2020-08-17 16:59:58 --> Router Class Initialized
INFO - 2020-08-17 16:59:58 --> Output Class Initialized
INFO - 2020-08-17 16:59:58 --> Security Class Initialized
DEBUG - 2020-08-17 16:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 16:59:58 --> Input Class Initialized
INFO - 2020-08-17 16:59:58 --> Language Class Initialized
INFO - 2020-08-17 16:59:58 --> Loader Class Initialized
INFO - 2020-08-17 16:59:58 --> Helper loaded: url_helper
INFO - 2020-08-17 16:59:58 --> Database Driver Class Initialized
INFO - 2020-08-17 16:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 16:59:58 --> Email Class Initialized
INFO - 2020-08-17 16:59:58 --> Controller Class Initialized
DEBUG - 2020-08-17 16:59:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 16:59:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 16:59:58 --> Model Class Initialized
INFO - 2020-08-17 16:59:58 --> Model Class Initialized
INFO - 2020-08-17 16:59:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 16:59:58 --> Final output sent to browser
DEBUG - 2020-08-17 16:59:58 --> Total execution time: 0.0254
INFO - 2020-08-17 17:01:34 --> Config Class Initialized
INFO - 2020-08-17 17:01:34 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:01:34 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:01:34 --> Utf8 Class Initialized
INFO - 2020-08-17 17:01:34 --> URI Class Initialized
INFO - 2020-08-17 17:01:34 --> Router Class Initialized
INFO - 2020-08-17 17:01:34 --> Output Class Initialized
INFO - 2020-08-17 17:01:34 --> Security Class Initialized
DEBUG - 2020-08-17 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:01:34 --> Input Class Initialized
INFO - 2020-08-17 17:01:34 --> Language Class Initialized
INFO - 2020-08-17 17:01:34 --> Loader Class Initialized
INFO - 2020-08-17 17:01:34 --> Helper loaded: url_helper
INFO - 2020-08-17 17:01:34 --> Database Driver Class Initialized
INFO - 2020-08-17 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:01:34 --> Email Class Initialized
INFO - 2020-08-17 17:01:34 --> Controller Class Initialized
DEBUG - 2020-08-17 17:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:01:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:01:34 --> Model Class Initialized
INFO - 2020-08-17 17:01:34 --> Model Class Initialized
INFO - 2020-08-17 17:01:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:01:34 --> Final output sent to browser
DEBUG - 2020-08-17 17:01:34 --> Total execution time: 0.0271
INFO - 2020-08-17 17:01:38 --> Config Class Initialized
INFO - 2020-08-17 17:01:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:01:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:01:38 --> Utf8 Class Initialized
INFO - 2020-08-17 17:01:38 --> URI Class Initialized
INFO - 2020-08-17 17:01:38 --> Router Class Initialized
INFO - 2020-08-17 17:01:38 --> Output Class Initialized
INFO - 2020-08-17 17:01:38 --> Security Class Initialized
DEBUG - 2020-08-17 17:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:01:38 --> Input Class Initialized
INFO - 2020-08-17 17:01:38 --> Language Class Initialized
INFO - 2020-08-17 17:01:38 --> Loader Class Initialized
INFO - 2020-08-17 17:01:38 --> Helper loaded: url_helper
INFO - 2020-08-17 17:01:38 --> Database Driver Class Initialized
INFO - 2020-08-17 17:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:01:38 --> Email Class Initialized
INFO - 2020-08-17 17:01:38 --> Controller Class Initialized
DEBUG - 2020-08-17 17:01:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:01:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:01:38 --> Model Class Initialized
INFO - 2020-08-17 17:01:38 --> Model Class Initialized
INFO - 2020-08-17 17:01:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:01:38 --> Final output sent to browser
DEBUG - 2020-08-17 17:01:38 --> Total execution time: 0.0272
INFO - 2020-08-17 17:02:36 --> Config Class Initialized
INFO - 2020-08-17 17:02:36 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:02:36 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:02:36 --> Utf8 Class Initialized
INFO - 2020-08-17 17:02:36 --> URI Class Initialized
INFO - 2020-08-17 17:02:36 --> Router Class Initialized
INFO - 2020-08-17 17:02:36 --> Output Class Initialized
INFO - 2020-08-17 17:02:36 --> Security Class Initialized
DEBUG - 2020-08-17 17:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:02:36 --> Input Class Initialized
INFO - 2020-08-17 17:02:36 --> Language Class Initialized
INFO - 2020-08-17 17:02:36 --> Loader Class Initialized
INFO - 2020-08-17 17:02:36 --> Helper loaded: url_helper
INFO - 2020-08-17 17:02:36 --> Database Driver Class Initialized
INFO - 2020-08-17 17:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:02:36 --> Email Class Initialized
INFO - 2020-08-17 17:02:36 --> Controller Class Initialized
DEBUG - 2020-08-17 17:02:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:02:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:02:36 --> Model Class Initialized
INFO - 2020-08-17 17:02:36 --> Model Class Initialized
INFO - 2020-08-17 17:02:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:02:36 --> Final output sent to browser
DEBUG - 2020-08-17 17:02:36 --> Total execution time: 0.0276
INFO - 2020-08-17 17:02:42 --> Config Class Initialized
INFO - 2020-08-17 17:02:42 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:02:42 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:02:42 --> Utf8 Class Initialized
INFO - 2020-08-17 17:02:42 --> URI Class Initialized
INFO - 2020-08-17 17:02:42 --> Router Class Initialized
INFO - 2020-08-17 17:02:42 --> Output Class Initialized
INFO - 2020-08-17 17:02:42 --> Security Class Initialized
DEBUG - 2020-08-17 17:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:02:42 --> Input Class Initialized
INFO - 2020-08-17 17:02:42 --> Language Class Initialized
INFO - 2020-08-17 17:02:42 --> Loader Class Initialized
INFO - 2020-08-17 17:02:42 --> Helper loaded: url_helper
INFO - 2020-08-17 17:02:42 --> Database Driver Class Initialized
INFO - 2020-08-17 17:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:02:42 --> Email Class Initialized
INFO - 2020-08-17 17:02:42 --> Controller Class Initialized
DEBUG - 2020-08-17 17:02:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:02:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:02:42 --> Model Class Initialized
INFO - 2020-08-17 17:02:42 --> Model Class Initialized
INFO - 2020-08-17 17:02:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:02:42 --> Final output sent to browser
DEBUG - 2020-08-17 17:02:42 --> Total execution time: 0.0248
INFO - 2020-08-17 17:02:46 --> Config Class Initialized
INFO - 2020-08-17 17:02:46 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:02:46 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:02:46 --> Utf8 Class Initialized
INFO - 2020-08-17 17:02:46 --> URI Class Initialized
INFO - 2020-08-17 17:02:46 --> Router Class Initialized
INFO - 2020-08-17 17:02:46 --> Output Class Initialized
INFO - 2020-08-17 17:02:46 --> Security Class Initialized
DEBUG - 2020-08-17 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:02:46 --> Input Class Initialized
INFO - 2020-08-17 17:02:46 --> Language Class Initialized
INFO - 2020-08-17 17:02:46 --> Loader Class Initialized
INFO - 2020-08-17 17:02:46 --> Helper loaded: url_helper
INFO - 2020-08-17 17:02:46 --> Database Driver Class Initialized
INFO - 2020-08-17 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:02:46 --> Email Class Initialized
INFO - 2020-08-17 17:02:46 --> Controller Class Initialized
DEBUG - 2020-08-17 17:02:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:02:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:02:46 --> Model Class Initialized
INFO - 2020-08-17 17:02:46 --> Model Class Initialized
INFO - 2020-08-17 17:02:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:02:46 --> Final output sent to browser
DEBUG - 2020-08-17 17:02:46 --> Total execution time: 0.0250
INFO - 2020-08-17 17:03:12 --> Config Class Initialized
INFO - 2020-08-17 17:03:12 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:03:12 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:03:12 --> Utf8 Class Initialized
INFO - 2020-08-17 17:03:12 --> URI Class Initialized
INFO - 2020-08-17 17:03:12 --> Router Class Initialized
INFO - 2020-08-17 17:03:12 --> Output Class Initialized
INFO - 2020-08-17 17:03:12 --> Security Class Initialized
DEBUG - 2020-08-17 17:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:03:12 --> Input Class Initialized
INFO - 2020-08-17 17:03:12 --> Language Class Initialized
INFO - 2020-08-17 17:03:12 --> Loader Class Initialized
INFO - 2020-08-17 17:03:12 --> Helper loaded: url_helper
INFO - 2020-08-17 17:03:12 --> Database Driver Class Initialized
INFO - 2020-08-17 17:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:03:12 --> Email Class Initialized
INFO - 2020-08-17 17:03:12 --> Controller Class Initialized
DEBUG - 2020-08-17 17:03:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:03:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:03:12 --> Model Class Initialized
INFO - 2020-08-17 17:03:12 --> Model Class Initialized
INFO - 2020-08-17 17:03:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:03:12 --> Final output sent to browser
DEBUG - 2020-08-17 17:03:12 --> Total execution time: 0.0275
INFO - 2020-08-17 17:03:59 --> Config Class Initialized
INFO - 2020-08-17 17:03:59 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:03:59 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:03:59 --> Utf8 Class Initialized
INFO - 2020-08-17 17:03:59 --> URI Class Initialized
INFO - 2020-08-17 17:03:59 --> Router Class Initialized
INFO - 2020-08-17 17:03:59 --> Output Class Initialized
INFO - 2020-08-17 17:03:59 --> Security Class Initialized
DEBUG - 2020-08-17 17:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:03:59 --> Input Class Initialized
INFO - 2020-08-17 17:03:59 --> Language Class Initialized
INFO - 2020-08-17 17:03:59 --> Loader Class Initialized
INFO - 2020-08-17 17:03:59 --> Helper loaded: url_helper
INFO - 2020-08-17 17:03:59 --> Database Driver Class Initialized
INFO - 2020-08-17 17:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:03:59 --> Email Class Initialized
INFO - 2020-08-17 17:03:59 --> Controller Class Initialized
DEBUG - 2020-08-17 17:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:03:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:03:59 --> Model Class Initialized
INFO - 2020-08-17 17:03:59 --> Model Class Initialized
INFO - 2020-08-17 17:03:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:03:59 --> Final output sent to browser
DEBUG - 2020-08-17 17:03:59 --> Total execution time: 0.0300
INFO - 2020-08-17 17:04:01 --> Config Class Initialized
INFO - 2020-08-17 17:04:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:04:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:04:01 --> Utf8 Class Initialized
INFO - 2020-08-17 17:04:01 --> URI Class Initialized
INFO - 2020-08-17 17:04:01 --> Router Class Initialized
INFO - 2020-08-17 17:04:01 --> Output Class Initialized
INFO - 2020-08-17 17:04:01 --> Security Class Initialized
DEBUG - 2020-08-17 17:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:04:01 --> Input Class Initialized
INFO - 2020-08-17 17:04:01 --> Language Class Initialized
INFO - 2020-08-17 17:04:01 --> Loader Class Initialized
INFO - 2020-08-17 17:04:01 --> Helper loaded: url_helper
INFO - 2020-08-17 17:04:01 --> Database Driver Class Initialized
INFO - 2020-08-17 17:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:04:01 --> Email Class Initialized
INFO - 2020-08-17 17:04:01 --> Controller Class Initialized
DEBUG - 2020-08-17 17:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:04:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:04:01 --> Model Class Initialized
INFO - 2020-08-17 17:04:01 --> Model Class Initialized
INFO - 2020-08-17 17:04:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:04:01 --> Final output sent to browser
DEBUG - 2020-08-17 17:04:01 --> Total execution time: 0.0310
INFO - 2020-08-17 17:04:11 --> Config Class Initialized
INFO - 2020-08-17 17:04:11 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:04:11 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:04:11 --> Utf8 Class Initialized
INFO - 2020-08-17 17:04:11 --> URI Class Initialized
INFO - 2020-08-17 17:04:11 --> Router Class Initialized
INFO - 2020-08-17 17:04:11 --> Output Class Initialized
INFO - 2020-08-17 17:04:11 --> Security Class Initialized
DEBUG - 2020-08-17 17:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:04:11 --> Input Class Initialized
INFO - 2020-08-17 17:04:11 --> Language Class Initialized
INFO - 2020-08-17 17:04:11 --> Loader Class Initialized
INFO - 2020-08-17 17:04:11 --> Helper loaded: url_helper
INFO - 2020-08-17 17:04:11 --> Database Driver Class Initialized
INFO - 2020-08-17 17:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:04:11 --> Email Class Initialized
INFO - 2020-08-17 17:04:11 --> Controller Class Initialized
DEBUG - 2020-08-17 17:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:04:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:04:11 --> Model Class Initialized
INFO - 2020-08-17 17:04:11 --> Model Class Initialized
INFO - 2020-08-17 17:04:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:04:11 --> Final output sent to browser
DEBUG - 2020-08-17 17:04:11 --> Total execution time: 0.0250
INFO - 2020-08-17 17:04:17 --> Config Class Initialized
INFO - 2020-08-17 17:04:17 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:04:17 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:04:17 --> Utf8 Class Initialized
INFO - 2020-08-17 17:04:17 --> URI Class Initialized
INFO - 2020-08-17 17:04:17 --> Router Class Initialized
INFO - 2020-08-17 17:04:17 --> Output Class Initialized
INFO - 2020-08-17 17:04:17 --> Security Class Initialized
DEBUG - 2020-08-17 17:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:04:17 --> Input Class Initialized
INFO - 2020-08-17 17:04:17 --> Language Class Initialized
INFO - 2020-08-17 17:04:17 --> Loader Class Initialized
INFO - 2020-08-17 17:04:17 --> Helper loaded: url_helper
INFO - 2020-08-17 17:04:17 --> Database Driver Class Initialized
INFO - 2020-08-17 17:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:04:17 --> Email Class Initialized
INFO - 2020-08-17 17:04:17 --> Controller Class Initialized
DEBUG - 2020-08-17 17:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:04:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:04:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:04:17 --> Final output sent to browser
DEBUG - 2020-08-17 17:04:17 --> Total execution time: 0.0237
INFO - 2020-08-17 17:04:22 --> Config Class Initialized
INFO - 2020-08-17 17:04:22 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:04:22 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:04:22 --> Utf8 Class Initialized
INFO - 2020-08-17 17:04:22 --> URI Class Initialized
INFO - 2020-08-17 17:04:22 --> Router Class Initialized
INFO - 2020-08-17 17:04:22 --> Output Class Initialized
INFO - 2020-08-17 17:04:22 --> Security Class Initialized
DEBUG - 2020-08-17 17:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:04:22 --> Input Class Initialized
INFO - 2020-08-17 17:04:22 --> Language Class Initialized
INFO - 2020-08-17 17:04:22 --> Loader Class Initialized
INFO - 2020-08-17 17:04:22 --> Helper loaded: url_helper
INFO - 2020-08-17 17:04:22 --> Database Driver Class Initialized
INFO - 2020-08-17 17:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:04:22 --> Email Class Initialized
INFO - 2020-08-17 17:04:22 --> Controller Class Initialized
DEBUG - 2020-08-17 17:04:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:04:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:04:22 --> Model Class Initialized
INFO - 2020-08-17 17:04:22 --> Model Class Initialized
INFO - 2020-08-17 17:04:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:04:22 --> Final output sent to browser
DEBUG - 2020-08-17 17:04:22 --> Total execution time: 0.0228
INFO - 2020-08-17 17:04:47 --> Config Class Initialized
INFO - 2020-08-17 17:04:47 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:04:47 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:04:47 --> Utf8 Class Initialized
INFO - 2020-08-17 17:04:47 --> URI Class Initialized
INFO - 2020-08-17 17:04:47 --> Router Class Initialized
INFO - 2020-08-17 17:04:47 --> Output Class Initialized
INFO - 2020-08-17 17:04:47 --> Security Class Initialized
DEBUG - 2020-08-17 17:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:04:47 --> Input Class Initialized
INFO - 2020-08-17 17:04:47 --> Language Class Initialized
INFO - 2020-08-17 17:04:47 --> Loader Class Initialized
INFO - 2020-08-17 17:04:47 --> Helper loaded: url_helper
INFO - 2020-08-17 17:04:47 --> Database Driver Class Initialized
INFO - 2020-08-17 17:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:04:47 --> Email Class Initialized
INFO - 2020-08-17 17:04:47 --> Controller Class Initialized
DEBUG - 2020-08-17 17:04:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:04:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:04:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:04:47 --> Final output sent to browser
DEBUG - 2020-08-17 17:04:47 --> Total execution time: 0.0201
INFO - 2020-08-17 17:05:22 --> Config Class Initialized
INFO - 2020-08-17 17:05:22 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:05:22 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:05:22 --> Utf8 Class Initialized
INFO - 2020-08-17 17:05:22 --> URI Class Initialized
INFO - 2020-08-17 17:05:22 --> Router Class Initialized
INFO - 2020-08-17 17:05:22 --> Output Class Initialized
INFO - 2020-08-17 17:05:22 --> Security Class Initialized
DEBUG - 2020-08-17 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:05:22 --> Input Class Initialized
INFO - 2020-08-17 17:05:22 --> Language Class Initialized
INFO - 2020-08-17 17:05:22 --> Loader Class Initialized
INFO - 2020-08-17 17:05:22 --> Helper loaded: url_helper
INFO - 2020-08-17 17:05:22 --> Database Driver Class Initialized
INFO - 2020-08-17 17:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:05:22 --> Email Class Initialized
INFO - 2020-08-17 17:05:22 --> Controller Class Initialized
DEBUG - 2020-08-17 17:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:05:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:05:22 --> Model Class Initialized
INFO - 2020-08-17 17:05:22 --> Model Class Initialized
INFO - 2020-08-17 17:05:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:05:22 --> Final output sent to browser
DEBUG - 2020-08-17 17:05:22 --> Total execution time: 0.0276
INFO - 2020-08-17 17:05:42 --> Config Class Initialized
INFO - 2020-08-17 17:05:42 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:05:42 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:05:42 --> Utf8 Class Initialized
INFO - 2020-08-17 17:05:42 --> URI Class Initialized
INFO - 2020-08-17 17:05:42 --> Router Class Initialized
INFO - 2020-08-17 17:05:42 --> Output Class Initialized
INFO - 2020-08-17 17:05:42 --> Security Class Initialized
DEBUG - 2020-08-17 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:05:42 --> Input Class Initialized
INFO - 2020-08-17 17:05:42 --> Language Class Initialized
INFO - 2020-08-17 17:05:42 --> Loader Class Initialized
INFO - 2020-08-17 17:05:42 --> Helper loaded: url_helper
INFO - 2020-08-17 17:05:42 --> Database Driver Class Initialized
INFO - 2020-08-17 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:05:42 --> Email Class Initialized
INFO - 2020-08-17 17:05:42 --> Controller Class Initialized
DEBUG - 2020-08-17 17:05:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:05:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:05:42 --> Model Class Initialized
INFO - 2020-08-17 17:05:42 --> Model Class Initialized
INFO - 2020-08-17 17:05:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:05:42 --> Final output sent to browser
DEBUG - 2020-08-17 17:05:42 --> Total execution time: 0.0281
INFO - 2020-08-17 17:05:45 --> Config Class Initialized
INFO - 2020-08-17 17:05:45 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:05:45 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:05:45 --> Utf8 Class Initialized
INFO - 2020-08-17 17:05:45 --> URI Class Initialized
INFO - 2020-08-17 17:05:45 --> Router Class Initialized
INFO - 2020-08-17 17:05:45 --> Output Class Initialized
INFO - 2020-08-17 17:05:45 --> Security Class Initialized
DEBUG - 2020-08-17 17:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:05:45 --> Input Class Initialized
INFO - 2020-08-17 17:05:45 --> Language Class Initialized
INFO - 2020-08-17 17:05:45 --> Loader Class Initialized
INFO - 2020-08-17 17:05:45 --> Helper loaded: url_helper
INFO - 2020-08-17 17:05:45 --> Database Driver Class Initialized
INFO - 2020-08-17 17:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:05:45 --> Email Class Initialized
INFO - 2020-08-17 17:05:45 --> Controller Class Initialized
DEBUG - 2020-08-17 17:05:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:05:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:05:45 --> Model Class Initialized
INFO - 2020-08-17 17:05:45 --> Model Class Initialized
INFO - 2020-08-17 17:05:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:05:45 --> Final output sent to browser
DEBUG - 2020-08-17 17:05:45 --> Total execution time: 0.0260
INFO - 2020-08-17 17:06:20 --> Config Class Initialized
INFO - 2020-08-17 17:06:20 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:06:20 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:06:20 --> Utf8 Class Initialized
INFO - 2020-08-17 17:06:20 --> URI Class Initialized
DEBUG - 2020-08-17 17:06:20 --> No URI present. Default controller set.
INFO - 2020-08-17 17:06:20 --> Router Class Initialized
INFO - 2020-08-17 17:06:20 --> Output Class Initialized
INFO - 2020-08-17 17:06:20 --> Security Class Initialized
DEBUG - 2020-08-17 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:06:20 --> Input Class Initialized
INFO - 2020-08-17 17:06:20 --> Language Class Initialized
INFO - 2020-08-17 17:06:20 --> Loader Class Initialized
INFO - 2020-08-17 17:06:20 --> Helper loaded: url_helper
INFO - 2020-08-17 17:06:20 --> Database Driver Class Initialized
INFO - 2020-08-17 17:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:06:20 --> Email Class Initialized
INFO - 2020-08-17 17:06:20 --> Controller Class Initialized
INFO - 2020-08-17 17:06:20 --> Model Class Initialized
INFO - 2020-08-17 17:06:20 --> Model Class Initialized
DEBUG - 2020-08-17 17:06:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:06:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:06:20 --> Final output sent to browser
DEBUG - 2020-08-17 17:06:20 --> Total execution time: 0.0235
INFO - 2020-08-17 17:06:23 --> Config Class Initialized
INFO - 2020-08-17 17:06:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:06:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:06:23 --> Utf8 Class Initialized
INFO - 2020-08-17 17:06:23 --> URI Class Initialized
INFO - 2020-08-17 17:06:23 --> Router Class Initialized
INFO - 2020-08-17 17:06:23 --> Output Class Initialized
INFO - 2020-08-17 17:06:23 --> Security Class Initialized
DEBUG - 2020-08-17 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:06:23 --> Input Class Initialized
INFO - 2020-08-17 17:06:23 --> Language Class Initialized
INFO - 2020-08-17 17:06:23 --> Loader Class Initialized
INFO - 2020-08-17 17:06:23 --> Helper loaded: url_helper
INFO - 2020-08-17 17:06:23 --> Database Driver Class Initialized
INFO - 2020-08-17 17:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:06:23 --> Email Class Initialized
INFO - 2020-08-17 17:06:23 --> Controller Class Initialized
INFO - 2020-08-17 17:06:23 --> Model Class Initialized
INFO - 2020-08-17 17:06:23 --> Model Class Initialized
DEBUG - 2020-08-17 17:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:06:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:06:23 --> Model Class Initialized
INFO - 2020-08-17 17:06:23 --> Final output sent to browser
DEBUG - 2020-08-17 17:06:23 --> Total execution time: 0.0266
INFO - 2020-08-17 17:06:23 --> Config Class Initialized
INFO - 2020-08-17 17:06:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:06:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:06:23 --> Utf8 Class Initialized
INFO - 2020-08-17 17:06:23 --> URI Class Initialized
INFO - 2020-08-17 17:06:23 --> Router Class Initialized
INFO - 2020-08-17 17:06:23 --> Output Class Initialized
INFO - 2020-08-17 17:06:23 --> Security Class Initialized
DEBUG - 2020-08-17 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:06:23 --> Input Class Initialized
INFO - 2020-08-17 17:06:23 --> Language Class Initialized
INFO - 2020-08-17 17:06:23 --> Loader Class Initialized
INFO - 2020-08-17 17:06:23 --> Helper loaded: url_helper
INFO - 2020-08-17 17:06:23 --> Database Driver Class Initialized
INFO - 2020-08-17 17:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:06:23 --> Email Class Initialized
INFO - 2020-08-17 17:06:23 --> Controller Class Initialized
INFO - 2020-08-17 17:06:23 --> Model Class Initialized
INFO - 2020-08-17 17:06:23 --> Model Class Initialized
DEBUG - 2020-08-17 17:06:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:06:23 --> Config Class Initialized
INFO - 2020-08-17 17:06:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:06:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:06:23 --> Utf8 Class Initialized
INFO - 2020-08-17 17:06:23 --> URI Class Initialized
INFO - 2020-08-17 17:06:23 --> Router Class Initialized
INFO - 2020-08-17 17:06:23 --> Output Class Initialized
INFO - 2020-08-17 17:06:23 --> Security Class Initialized
DEBUG - 2020-08-17 17:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:06:23 --> Input Class Initialized
INFO - 2020-08-17 17:06:23 --> Language Class Initialized
INFO - 2020-08-17 17:06:23 --> Loader Class Initialized
INFO - 2020-08-17 17:06:23 --> Helper loaded: url_helper
INFO - 2020-08-17 17:06:23 --> Database Driver Class Initialized
INFO - 2020-08-17 17:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:06:23 --> Email Class Initialized
INFO - 2020-08-17 17:06:23 --> Controller Class Initialized
DEBUG - 2020-08-17 17:06:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:06:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:06:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:06:23 --> Final output sent to browser
DEBUG - 2020-08-17 17:06:23 --> Total execution time: 0.0229
INFO - 2020-08-17 17:07:10 --> Config Class Initialized
INFO - 2020-08-17 17:07:10 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:07:10 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:07:10 --> Utf8 Class Initialized
INFO - 2020-08-17 17:07:10 --> URI Class Initialized
INFO - 2020-08-17 17:07:10 --> Router Class Initialized
INFO - 2020-08-17 17:07:10 --> Output Class Initialized
INFO - 2020-08-17 17:07:10 --> Security Class Initialized
DEBUG - 2020-08-17 17:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:07:10 --> Input Class Initialized
INFO - 2020-08-17 17:07:10 --> Language Class Initialized
INFO - 2020-08-17 17:07:10 --> Loader Class Initialized
INFO - 2020-08-17 17:07:10 --> Helper loaded: url_helper
INFO - 2020-08-17 17:07:11 --> Database Driver Class Initialized
INFO - 2020-08-17 17:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:07:11 --> Email Class Initialized
INFO - 2020-08-17 17:07:11 --> Controller Class Initialized
DEBUG - 2020-08-17 17:07:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:07:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:07:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:07:11 --> Final output sent to browser
DEBUG - 2020-08-17 17:07:11 --> Total execution time: 0.0270
INFO - 2020-08-17 17:07:14 --> Config Class Initialized
INFO - 2020-08-17 17:07:14 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:07:14 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:07:14 --> Utf8 Class Initialized
INFO - 2020-08-17 17:07:14 --> URI Class Initialized
INFO - 2020-08-17 17:07:14 --> Router Class Initialized
INFO - 2020-08-17 17:07:14 --> Output Class Initialized
INFO - 2020-08-17 17:07:14 --> Security Class Initialized
DEBUG - 2020-08-17 17:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:07:14 --> Input Class Initialized
INFO - 2020-08-17 17:07:14 --> Language Class Initialized
INFO - 2020-08-17 17:07:14 --> Loader Class Initialized
INFO - 2020-08-17 17:07:14 --> Helper loaded: url_helper
INFO - 2020-08-17 17:07:14 --> Database Driver Class Initialized
INFO - 2020-08-17 17:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:07:14 --> Email Class Initialized
INFO - 2020-08-17 17:07:14 --> Controller Class Initialized
DEBUG - 2020-08-17 17:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:07:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:07:14 --> Model Class Initialized
INFO - 2020-08-17 17:07:14 --> Model Class Initialized
INFO - 2020-08-17 17:07:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:07:14 --> Final output sent to browser
DEBUG - 2020-08-17 17:07:14 --> Total execution time: 0.0206
INFO - 2020-08-17 17:07:18 --> Config Class Initialized
INFO - 2020-08-17 17:07:18 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:07:18 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:07:18 --> Utf8 Class Initialized
INFO - 2020-08-17 17:07:18 --> URI Class Initialized
INFO - 2020-08-17 17:07:18 --> Router Class Initialized
INFO - 2020-08-17 17:07:18 --> Output Class Initialized
INFO - 2020-08-17 17:07:18 --> Security Class Initialized
DEBUG - 2020-08-17 17:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:07:18 --> Input Class Initialized
INFO - 2020-08-17 17:07:18 --> Language Class Initialized
INFO - 2020-08-17 17:07:18 --> Loader Class Initialized
INFO - 2020-08-17 17:07:18 --> Helper loaded: url_helper
INFO - 2020-08-17 17:07:18 --> Database Driver Class Initialized
INFO - 2020-08-17 17:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:07:18 --> Email Class Initialized
INFO - 2020-08-17 17:07:18 --> Controller Class Initialized
DEBUG - 2020-08-17 17:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:07:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:07:18 --> Model Class Initialized
INFO - 2020-08-17 17:07:18 --> Model Class Initialized
INFO - 2020-08-17 17:07:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:07:18 --> Final output sent to browser
DEBUG - 2020-08-17 17:07:18 --> Total execution time: 0.0241
INFO - 2020-08-17 17:07:21 --> Config Class Initialized
INFO - 2020-08-17 17:07:21 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:07:21 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:07:21 --> Utf8 Class Initialized
INFO - 2020-08-17 17:07:21 --> URI Class Initialized
INFO - 2020-08-17 17:07:21 --> Router Class Initialized
INFO - 2020-08-17 17:07:21 --> Output Class Initialized
INFO - 2020-08-17 17:07:21 --> Security Class Initialized
DEBUG - 2020-08-17 17:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:07:21 --> Input Class Initialized
INFO - 2020-08-17 17:07:21 --> Language Class Initialized
INFO - 2020-08-17 17:07:21 --> Loader Class Initialized
INFO - 2020-08-17 17:07:21 --> Helper loaded: url_helper
INFO - 2020-08-17 17:07:21 --> Database Driver Class Initialized
INFO - 2020-08-17 17:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:07:21 --> Email Class Initialized
INFO - 2020-08-17 17:07:21 --> Controller Class Initialized
DEBUG - 2020-08-17 17:07:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:07:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:07:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:07:21 --> Final output sent to browser
DEBUG - 2020-08-17 17:07:21 --> Total execution time: 0.0235
INFO - 2020-08-17 17:07:35 --> Config Class Initialized
INFO - 2020-08-17 17:07:35 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:07:35 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:07:35 --> Utf8 Class Initialized
INFO - 2020-08-17 17:07:35 --> URI Class Initialized
INFO - 2020-08-17 17:07:35 --> Router Class Initialized
INFO - 2020-08-17 17:07:35 --> Output Class Initialized
INFO - 2020-08-17 17:07:35 --> Security Class Initialized
DEBUG - 2020-08-17 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:07:35 --> Input Class Initialized
INFO - 2020-08-17 17:07:35 --> Language Class Initialized
INFO - 2020-08-17 17:07:35 --> Loader Class Initialized
INFO - 2020-08-17 17:07:35 --> Helper loaded: url_helper
INFO - 2020-08-17 17:07:35 --> Database Driver Class Initialized
INFO - 2020-08-17 17:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:07:35 --> Email Class Initialized
INFO - 2020-08-17 17:07:35 --> Controller Class Initialized
DEBUG - 2020-08-17 17:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:07:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:07:35 --> Model Class Initialized
INFO - 2020-08-17 17:07:35 --> Model Class Initialized
INFO - 2020-08-17 17:07:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:07:35 --> Final output sent to browser
DEBUG - 2020-08-17 17:07:35 --> Total execution time: 0.0246
INFO - 2020-08-17 17:07:56 --> Config Class Initialized
INFO - 2020-08-17 17:07:56 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:07:56 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:07:56 --> Utf8 Class Initialized
INFO - 2020-08-17 17:07:56 --> URI Class Initialized
INFO - 2020-08-17 17:07:56 --> Router Class Initialized
INFO - 2020-08-17 17:07:56 --> Output Class Initialized
INFO - 2020-08-17 17:07:56 --> Security Class Initialized
DEBUG - 2020-08-17 17:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:07:56 --> Input Class Initialized
INFO - 2020-08-17 17:07:56 --> Language Class Initialized
INFO - 2020-08-17 17:07:56 --> Loader Class Initialized
INFO - 2020-08-17 17:07:56 --> Helper loaded: url_helper
INFO - 2020-08-17 17:07:56 --> Database Driver Class Initialized
INFO - 2020-08-17 17:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:07:56 --> Email Class Initialized
INFO - 2020-08-17 17:07:56 --> Controller Class Initialized
DEBUG - 2020-08-17 17:07:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:07:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:07:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:07:56 --> Final output sent to browser
DEBUG - 2020-08-17 17:07:56 --> Total execution time: 0.0263
INFO - 2020-08-17 17:08:00 --> Config Class Initialized
INFO - 2020-08-17 17:08:00 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:00 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:00 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:00 --> URI Class Initialized
INFO - 2020-08-17 17:08:00 --> Router Class Initialized
INFO - 2020-08-17 17:08:00 --> Output Class Initialized
INFO - 2020-08-17 17:08:00 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:00 --> Input Class Initialized
INFO - 2020-08-17 17:08:00 --> Language Class Initialized
INFO - 2020-08-17 17:08:00 --> Loader Class Initialized
INFO - 2020-08-17 17:08:00 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:00 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:00 --> Email Class Initialized
INFO - 2020-08-17 17:08:00 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:00 --> Model Class Initialized
INFO - 2020-08-17 17:08:00 --> Model Class Initialized
INFO - 2020-08-17 17:08:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:08:00 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:00 --> Total execution time: 0.0263
INFO - 2020-08-17 17:08:13 --> Config Class Initialized
INFO - 2020-08-17 17:08:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:13 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:13 --> URI Class Initialized
INFO - 2020-08-17 17:08:13 --> Router Class Initialized
INFO - 2020-08-17 17:08:13 --> Output Class Initialized
INFO - 2020-08-17 17:08:13 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:13 --> Input Class Initialized
INFO - 2020-08-17 17:08:13 --> Language Class Initialized
INFO - 2020-08-17 17:08:13 --> Loader Class Initialized
INFO - 2020-08-17 17:08:13 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:13 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:13 --> Email Class Initialized
INFO - 2020-08-17 17:08:13 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:13 --> Model Class Initialized
INFO - 2020-08-17 17:08:13 --> Model Class Initialized
INFO - 2020-08-17 17:08:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:08:13 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:13 --> Total execution time: 0.0230
INFO - 2020-08-17 17:08:41 --> Config Class Initialized
INFO - 2020-08-17 17:08:41 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:41 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:41 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:41 --> URI Class Initialized
INFO - 2020-08-17 17:08:41 --> Router Class Initialized
INFO - 2020-08-17 17:08:41 --> Output Class Initialized
INFO - 2020-08-17 17:08:41 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:41 --> Input Class Initialized
INFO - 2020-08-17 17:08:41 --> Language Class Initialized
INFO - 2020-08-17 17:08:41 --> Loader Class Initialized
INFO - 2020-08-17 17:08:41 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:41 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:41 --> Email Class Initialized
INFO - 2020-08-17 17:08:41 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:41 --> Model Class Initialized
INFO - 2020-08-17 17:08:41 --> Model Class Initialized
INFO - 2020-08-17 17:08:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:08:41 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:41 --> Total execution time: 0.0232
INFO - 2020-08-17 17:08:45 --> Config Class Initialized
INFO - 2020-08-17 17:08:45 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:45 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:45 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:45 --> URI Class Initialized
INFO - 2020-08-17 17:08:45 --> Router Class Initialized
INFO - 2020-08-17 17:08:45 --> Output Class Initialized
INFO - 2020-08-17 17:08:45 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:45 --> Input Class Initialized
INFO - 2020-08-17 17:08:45 --> Language Class Initialized
INFO - 2020-08-17 17:08:45 --> Loader Class Initialized
INFO - 2020-08-17 17:08:45 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:45 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:45 --> Email Class Initialized
INFO - 2020-08-17 17:08:45 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:45 --> Model Class Initialized
INFO - 2020-08-17 17:08:45 --> Model Class Initialized
INFO - 2020-08-17 17:08:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:08:45 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:45 --> Total execution time: 0.0240
INFO - 2020-08-17 17:08:48 --> Config Class Initialized
INFO - 2020-08-17 17:08:48 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:48 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:48 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:48 --> URI Class Initialized
INFO - 2020-08-17 17:08:48 --> Router Class Initialized
INFO - 2020-08-17 17:08:48 --> Output Class Initialized
INFO - 2020-08-17 17:08:48 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:48 --> Input Class Initialized
INFO - 2020-08-17 17:08:48 --> Language Class Initialized
INFO - 2020-08-17 17:08:48 --> Loader Class Initialized
INFO - 2020-08-17 17:08:48 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:48 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:48 --> Email Class Initialized
INFO - 2020-08-17 17:08:48 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:08:48 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:48 --> Total execution time: 0.0224
INFO - 2020-08-17 17:08:54 --> Config Class Initialized
INFO - 2020-08-17 17:08:54 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:54 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:54 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:54 --> URI Class Initialized
INFO - 2020-08-17 17:08:54 --> Router Class Initialized
INFO - 2020-08-17 17:08:54 --> Output Class Initialized
INFO - 2020-08-17 17:08:54 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:54 --> Input Class Initialized
INFO - 2020-08-17 17:08:54 --> Language Class Initialized
INFO - 2020-08-17 17:08:54 --> Loader Class Initialized
INFO - 2020-08-17 17:08:54 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:54 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:55 --> Email Class Initialized
INFO - 2020-08-17 17:08:55 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:55 --> Model Class Initialized
INFO - 2020-08-17 17:08:55 --> Model Class Initialized
INFO - 2020-08-17 17:08:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:08:55 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:55 --> Total execution time: 0.0285
INFO - 2020-08-17 17:08:58 --> Config Class Initialized
INFO - 2020-08-17 17:08:58 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:08:58 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:08:58 --> Utf8 Class Initialized
INFO - 2020-08-17 17:08:58 --> URI Class Initialized
INFO - 2020-08-17 17:08:58 --> Router Class Initialized
INFO - 2020-08-17 17:08:58 --> Output Class Initialized
INFO - 2020-08-17 17:08:58 --> Security Class Initialized
DEBUG - 2020-08-17 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:08:58 --> Input Class Initialized
INFO - 2020-08-17 17:08:58 --> Language Class Initialized
INFO - 2020-08-17 17:08:58 --> Loader Class Initialized
INFO - 2020-08-17 17:08:58 --> Helper loaded: url_helper
INFO - 2020-08-17 17:08:58 --> Database Driver Class Initialized
INFO - 2020-08-17 17:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:08:58 --> Email Class Initialized
INFO - 2020-08-17 17:08:58 --> Controller Class Initialized
DEBUG - 2020-08-17 17:08:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:08:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:08:58 --> Model Class Initialized
INFO - 2020-08-17 17:08:58 --> Model Class Initialized
INFO - 2020-08-17 17:08:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:08:58 --> Final output sent to browser
DEBUG - 2020-08-17 17:08:58 --> Total execution time: 0.0226
INFO - 2020-08-17 17:09:04 --> Config Class Initialized
INFO - 2020-08-17 17:09:04 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:04 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:04 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:04 --> URI Class Initialized
INFO - 2020-08-17 17:09:04 --> Router Class Initialized
INFO - 2020-08-17 17:09:04 --> Output Class Initialized
INFO - 2020-08-17 17:09:04 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:04 --> Input Class Initialized
INFO - 2020-08-17 17:09:04 --> Language Class Initialized
INFO - 2020-08-17 17:09:04 --> Loader Class Initialized
INFO - 2020-08-17 17:09:04 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:04 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:04 --> Email Class Initialized
INFO - 2020-08-17 17:09:04 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:04 --> Model Class Initialized
INFO - 2020-08-17 17:09:04 --> Model Class Initialized
INFO - 2020-08-17 17:09:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:09:04 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:04 --> Total execution time: 0.0248
INFO - 2020-08-17 17:09:07 --> Config Class Initialized
INFO - 2020-08-17 17:09:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:07 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:07 --> URI Class Initialized
INFO - 2020-08-17 17:09:07 --> Router Class Initialized
INFO - 2020-08-17 17:09:07 --> Output Class Initialized
INFO - 2020-08-17 17:09:07 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:07 --> Input Class Initialized
INFO - 2020-08-17 17:09:07 --> Language Class Initialized
INFO - 2020-08-17 17:09:07 --> Loader Class Initialized
INFO - 2020-08-17 17:09:07 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:07 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:07 --> Email Class Initialized
INFO - 2020-08-17 17:09:07 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 17:09:07 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:07 --> Total execution time: 0.0497
INFO - 2020-08-17 17:09:30 --> Config Class Initialized
INFO - 2020-08-17 17:09:30 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:30 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:30 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:30 --> URI Class Initialized
DEBUG - 2020-08-17 17:09:30 --> No URI present. Default controller set.
INFO - 2020-08-17 17:09:30 --> Router Class Initialized
INFO - 2020-08-17 17:09:30 --> Output Class Initialized
INFO - 2020-08-17 17:09:30 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:30 --> Input Class Initialized
INFO - 2020-08-17 17:09:30 --> Language Class Initialized
INFO - 2020-08-17 17:09:30 --> Loader Class Initialized
INFO - 2020-08-17 17:09:30 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:30 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:30 --> Email Class Initialized
INFO - 2020-08-17 17:09:30 --> Controller Class Initialized
INFO - 2020-08-17 17:09:30 --> Model Class Initialized
INFO - 2020-08-17 17:09:30 --> Model Class Initialized
DEBUG - 2020-08-17 17:09:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:09:30 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:30 --> Total execution time: 0.0235
INFO - 2020-08-17 17:09:32 --> Config Class Initialized
INFO - 2020-08-17 17:09:32 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:32 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:32 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:32 --> URI Class Initialized
INFO - 2020-08-17 17:09:32 --> Router Class Initialized
INFO - 2020-08-17 17:09:32 --> Output Class Initialized
INFO - 2020-08-17 17:09:32 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:32 --> Input Class Initialized
INFO - 2020-08-17 17:09:32 --> Language Class Initialized
INFO - 2020-08-17 17:09:32 --> Loader Class Initialized
INFO - 2020-08-17 17:09:32 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:32 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:32 --> Email Class Initialized
INFO - 2020-08-17 17:09:32 --> Controller Class Initialized
INFO - 2020-08-17 17:09:32 --> Model Class Initialized
INFO - 2020-08-17 17:09:32 --> Model Class Initialized
DEBUG - 2020-08-17 17:09:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:32 --> Model Class Initialized
INFO - 2020-08-17 17:09:32 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:32 --> Total execution time: 0.0261
INFO - 2020-08-17 17:09:33 --> Config Class Initialized
INFO - 2020-08-17 17:09:33 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:33 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:33 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:33 --> URI Class Initialized
INFO - 2020-08-17 17:09:33 --> Router Class Initialized
INFO - 2020-08-17 17:09:33 --> Output Class Initialized
INFO - 2020-08-17 17:09:33 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:33 --> Input Class Initialized
INFO - 2020-08-17 17:09:33 --> Language Class Initialized
INFO - 2020-08-17 17:09:33 --> Loader Class Initialized
INFO - 2020-08-17 17:09:33 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:33 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:33 --> Email Class Initialized
INFO - 2020-08-17 17:09:33 --> Controller Class Initialized
INFO - 2020-08-17 17:09:33 --> Model Class Initialized
INFO - 2020-08-17 17:09:33 --> Model Class Initialized
DEBUG - 2020-08-17 17:09:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:33 --> Config Class Initialized
INFO - 2020-08-17 17:09:33 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:33 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:33 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:33 --> URI Class Initialized
INFO - 2020-08-17 17:09:33 --> Router Class Initialized
INFO - 2020-08-17 17:09:33 --> Output Class Initialized
INFO - 2020-08-17 17:09:33 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:33 --> Input Class Initialized
INFO - 2020-08-17 17:09:33 --> Language Class Initialized
INFO - 2020-08-17 17:09:33 --> Loader Class Initialized
INFO - 2020-08-17 17:09:33 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:33 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:33 --> Email Class Initialized
INFO - 2020-08-17 17:09:33 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:09:33 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:33 --> Total execution time: 0.0198
INFO - 2020-08-17 17:09:39 --> Config Class Initialized
INFO - 2020-08-17 17:09:39 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:39 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:39 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:39 --> URI Class Initialized
INFO - 2020-08-17 17:09:39 --> Router Class Initialized
INFO - 2020-08-17 17:09:39 --> Output Class Initialized
INFO - 2020-08-17 17:09:39 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:39 --> Input Class Initialized
INFO - 2020-08-17 17:09:39 --> Language Class Initialized
INFO - 2020-08-17 17:09:39 --> Loader Class Initialized
INFO - 2020-08-17 17:09:39 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:39 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:39 --> Email Class Initialized
INFO - 2020-08-17 17:09:39 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:39 --> Model Class Initialized
INFO - 2020-08-17 17:09:39 --> Model Class Initialized
INFO - 2020-08-17 17:09:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:09:39 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:39 --> Total execution time: 0.0241
INFO - 2020-08-17 17:09:42 --> Config Class Initialized
INFO - 2020-08-17 17:09:42 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:42 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:42 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:42 --> URI Class Initialized
INFO - 2020-08-17 17:09:42 --> Router Class Initialized
INFO - 2020-08-17 17:09:42 --> Output Class Initialized
INFO - 2020-08-17 17:09:42 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:42 --> Input Class Initialized
INFO - 2020-08-17 17:09:42 --> Language Class Initialized
INFO - 2020-08-17 17:09:42 --> Loader Class Initialized
INFO - 2020-08-17 17:09:42 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:42 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:42 --> Email Class Initialized
INFO - 2020-08-17 17:09:42 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:42 --> Model Class Initialized
INFO - 2020-08-17 17:09:42 --> Model Class Initialized
INFO - 2020-08-17 17:09:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:09:42 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:42 --> Total execution time: 0.0230
INFO - 2020-08-17 17:09:45 --> Config Class Initialized
INFO - 2020-08-17 17:09:45 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:45 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:45 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:45 --> URI Class Initialized
INFO - 2020-08-17 17:09:45 --> Router Class Initialized
INFO - 2020-08-17 17:09:45 --> Output Class Initialized
INFO - 2020-08-17 17:09:45 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:45 --> Input Class Initialized
INFO - 2020-08-17 17:09:45 --> Language Class Initialized
INFO - 2020-08-17 17:09:45 --> Loader Class Initialized
INFO - 2020-08-17 17:09:45 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:45 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:45 --> Email Class Initialized
INFO - 2020-08-17 17:09:45 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:09:45 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:45 --> Total execution time: 0.0195
INFO - 2020-08-17 17:09:51 --> Config Class Initialized
INFO - 2020-08-17 17:09:51 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:51 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:51 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:51 --> URI Class Initialized
INFO - 2020-08-17 17:09:51 --> Router Class Initialized
INFO - 2020-08-17 17:09:51 --> Output Class Initialized
INFO - 2020-08-17 17:09:51 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:51 --> Input Class Initialized
INFO - 2020-08-17 17:09:51 --> Language Class Initialized
INFO - 2020-08-17 17:09:51 --> Loader Class Initialized
INFO - 2020-08-17 17:09:51 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:51 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:51 --> Email Class Initialized
INFO - 2020-08-17 17:09:51 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:51 --> Model Class Initialized
INFO - 2020-08-17 17:09:51 --> Model Class Initialized
INFO - 2020-08-17 17:09:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:09:51 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:51 --> Total execution time: 0.3977
INFO - 2020-08-17 17:09:53 --> Config Class Initialized
INFO - 2020-08-17 17:09:53 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:53 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:53 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:53 --> URI Class Initialized
INFO - 2020-08-17 17:09:53 --> Router Class Initialized
INFO - 2020-08-17 17:09:53 --> Output Class Initialized
INFO - 2020-08-17 17:09:53 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:53 --> Input Class Initialized
INFO - 2020-08-17 17:09:53 --> Language Class Initialized
INFO - 2020-08-17 17:09:53 --> Loader Class Initialized
INFO - 2020-08-17 17:09:53 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:53 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:53 --> Email Class Initialized
INFO - 2020-08-17 17:09:53 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:53 --> Model Class Initialized
INFO - 2020-08-17 17:09:53 --> Model Class Initialized
INFO - 2020-08-17 17:09:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:09:53 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:53 --> Total execution time: 0.0262
INFO - 2020-08-17 17:09:59 --> Config Class Initialized
INFO - 2020-08-17 17:09:59 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:09:59 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:09:59 --> Utf8 Class Initialized
INFO - 2020-08-17 17:09:59 --> URI Class Initialized
INFO - 2020-08-17 17:09:59 --> Router Class Initialized
INFO - 2020-08-17 17:09:59 --> Output Class Initialized
INFO - 2020-08-17 17:09:59 --> Security Class Initialized
DEBUG - 2020-08-17 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:09:59 --> Input Class Initialized
INFO - 2020-08-17 17:09:59 --> Language Class Initialized
INFO - 2020-08-17 17:09:59 --> Loader Class Initialized
INFO - 2020-08-17 17:09:59 --> Helper loaded: url_helper
INFO - 2020-08-17 17:09:59 --> Database Driver Class Initialized
INFO - 2020-08-17 17:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:09:59 --> Email Class Initialized
INFO - 2020-08-17 17:09:59 --> Controller Class Initialized
DEBUG - 2020-08-17 17:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:09:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:09:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:09:59 --> Final output sent to browser
DEBUG - 2020-08-17 17:09:59 --> Total execution time: 0.0225
INFO - 2020-08-17 17:10:03 --> Config Class Initialized
INFO - 2020-08-17 17:10:03 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:10:03 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:10:03 --> Utf8 Class Initialized
INFO - 2020-08-17 17:10:03 --> URI Class Initialized
INFO - 2020-08-17 17:10:03 --> Router Class Initialized
INFO - 2020-08-17 17:10:03 --> Output Class Initialized
INFO - 2020-08-17 17:10:03 --> Security Class Initialized
DEBUG - 2020-08-17 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:10:03 --> Input Class Initialized
INFO - 2020-08-17 17:10:03 --> Language Class Initialized
INFO - 2020-08-17 17:10:03 --> Loader Class Initialized
INFO - 2020-08-17 17:10:03 --> Helper loaded: url_helper
INFO - 2020-08-17 17:10:03 --> Database Driver Class Initialized
INFO - 2020-08-17 17:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:10:03 --> Email Class Initialized
INFO - 2020-08-17 17:10:03 --> Controller Class Initialized
DEBUG - 2020-08-17 17:10:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:10:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:10:03 --> Model Class Initialized
INFO - 2020-08-17 17:10:03 --> Model Class Initialized
INFO - 2020-08-17 17:10:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:10:03 --> Final output sent to browser
DEBUG - 2020-08-17 17:10:03 --> Total execution time: 0.0247
INFO - 2020-08-17 17:10:08 --> Config Class Initialized
INFO - 2020-08-17 17:10:08 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:10:08 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:10:08 --> Utf8 Class Initialized
INFO - 2020-08-17 17:10:08 --> URI Class Initialized
INFO - 2020-08-17 17:10:08 --> Router Class Initialized
INFO - 2020-08-17 17:10:08 --> Output Class Initialized
INFO - 2020-08-17 17:10:08 --> Security Class Initialized
DEBUG - 2020-08-17 17:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:10:08 --> Input Class Initialized
INFO - 2020-08-17 17:10:08 --> Language Class Initialized
INFO - 2020-08-17 17:10:08 --> Loader Class Initialized
INFO - 2020-08-17 17:10:08 --> Helper loaded: url_helper
INFO - 2020-08-17 17:10:08 --> Database Driver Class Initialized
INFO - 2020-08-17 17:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:10:08 --> Email Class Initialized
INFO - 2020-08-17 17:10:08 --> Controller Class Initialized
DEBUG - 2020-08-17 17:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:10:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:10:08 --> Model Class Initialized
INFO - 2020-08-17 17:10:08 --> Model Class Initialized
INFO - 2020-08-17 17:10:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:10:08 --> Final output sent to browser
DEBUG - 2020-08-17 17:10:08 --> Total execution time: 0.0241
INFO - 2020-08-17 17:10:37 --> Config Class Initialized
INFO - 2020-08-17 17:10:37 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:10:37 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:10:37 --> Utf8 Class Initialized
INFO - 2020-08-17 17:10:37 --> URI Class Initialized
INFO - 2020-08-17 17:10:37 --> Router Class Initialized
INFO - 2020-08-17 17:10:37 --> Output Class Initialized
INFO - 2020-08-17 17:10:37 --> Security Class Initialized
DEBUG - 2020-08-17 17:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:10:37 --> Input Class Initialized
INFO - 2020-08-17 17:10:37 --> Language Class Initialized
INFO - 2020-08-17 17:10:37 --> Loader Class Initialized
INFO - 2020-08-17 17:10:37 --> Helper loaded: url_helper
INFO - 2020-08-17 17:10:37 --> Database Driver Class Initialized
INFO - 2020-08-17 17:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:10:37 --> Email Class Initialized
INFO - 2020-08-17 17:10:37 --> Controller Class Initialized
DEBUG - 2020-08-17 17:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:10:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:10:37 --> Model Class Initialized
INFO - 2020-08-17 17:10:37 --> Model Class Initialized
INFO - 2020-08-17 17:10:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:10:37 --> Final output sent to browser
DEBUG - 2020-08-17 17:10:37 --> Total execution time: 0.0220
INFO - 2020-08-17 17:10:43 --> Config Class Initialized
INFO - 2020-08-17 17:10:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:10:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:10:43 --> Utf8 Class Initialized
INFO - 2020-08-17 17:10:43 --> URI Class Initialized
INFO - 2020-08-17 17:10:43 --> Router Class Initialized
INFO - 2020-08-17 17:10:43 --> Output Class Initialized
INFO - 2020-08-17 17:10:43 --> Security Class Initialized
DEBUG - 2020-08-17 17:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:10:43 --> Input Class Initialized
INFO - 2020-08-17 17:10:43 --> Language Class Initialized
INFO - 2020-08-17 17:10:43 --> Loader Class Initialized
INFO - 2020-08-17 17:10:43 --> Helper loaded: url_helper
INFO - 2020-08-17 17:10:43 --> Database Driver Class Initialized
INFO - 2020-08-17 17:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:10:43 --> Email Class Initialized
INFO - 2020-08-17 17:10:43 --> Controller Class Initialized
DEBUG - 2020-08-17 17:10:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:10:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:10:43 --> Model Class Initialized
INFO - 2020-08-17 17:10:43 --> Model Class Initialized
INFO - 2020-08-17 17:10:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:10:43 --> Final output sent to browser
DEBUG - 2020-08-17 17:10:43 --> Total execution time: 0.0271
INFO - 2020-08-17 17:15:43 --> Config Class Initialized
INFO - 2020-08-17 17:15:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:15:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:15:43 --> Utf8 Class Initialized
INFO - 2020-08-17 17:15:43 --> URI Class Initialized
INFO - 2020-08-17 17:15:43 --> Router Class Initialized
INFO - 2020-08-17 17:15:43 --> Output Class Initialized
INFO - 2020-08-17 17:15:43 --> Security Class Initialized
DEBUG - 2020-08-17 17:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:15:43 --> Input Class Initialized
INFO - 2020-08-17 17:15:43 --> Language Class Initialized
INFO - 2020-08-17 17:15:43 --> Loader Class Initialized
INFO - 2020-08-17 17:15:43 --> Helper loaded: url_helper
INFO - 2020-08-17 17:15:44 --> Database Driver Class Initialized
INFO - 2020-08-17 17:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:15:44 --> Email Class Initialized
INFO - 2020-08-17 17:15:44 --> Controller Class Initialized
DEBUG - 2020-08-17 17:15:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:15:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:15:44 --> Model Class Initialized
INFO - 2020-08-17 17:15:44 --> Model Class Initialized
INFO - 2020-08-17 17:15:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:15:44 --> Final output sent to browser
DEBUG - 2020-08-17 17:15:44 --> Total execution time: 0.0310
INFO - 2020-08-17 17:15:47 --> Config Class Initialized
INFO - 2020-08-17 17:15:47 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:15:47 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:15:47 --> Utf8 Class Initialized
INFO - 2020-08-17 17:15:47 --> URI Class Initialized
DEBUG - 2020-08-17 17:15:47 --> No URI present. Default controller set.
INFO - 2020-08-17 17:15:47 --> Router Class Initialized
INFO - 2020-08-17 17:15:47 --> Output Class Initialized
INFO - 2020-08-17 17:15:47 --> Security Class Initialized
DEBUG - 2020-08-17 17:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:15:47 --> Input Class Initialized
INFO - 2020-08-17 17:15:47 --> Language Class Initialized
INFO - 2020-08-17 17:15:47 --> Loader Class Initialized
INFO - 2020-08-17 17:15:47 --> Helper loaded: url_helper
INFO - 2020-08-17 17:15:47 --> Database Driver Class Initialized
INFO - 2020-08-17 17:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:15:47 --> Email Class Initialized
INFO - 2020-08-17 17:15:47 --> Controller Class Initialized
INFO - 2020-08-17 17:15:47 --> Model Class Initialized
INFO - 2020-08-17 17:15:47 --> Model Class Initialized
DEBUG - 2020-08-17 17:15:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:15:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:15:47 --> Final output sent to browser
DEBUG - 2020-08-17 17:15:47 --> Total execution time: 0.0204
INFO - 2020-08-17 17:15:50 --> Config Class Initialized
INFO - 2020-08-17 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:15:50 --> Utf8 Class Initialized
INFO - 2020-08-17 17:15:50 --> URI Class Initialized
INFO - 2020-08-17 17:15:50 --> Router Class Initialized
INFO - 2020-08-17 17:15:50 --> Output Class Initialized
INFO - 2020-08-17 17:15:50 --> Security Class Initialized
DEBUG - 2020-08-17 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:15:50 --> Input Class Initialized
INFO - 2020-08-17 17:15:50 --> Language Class Initialized
INFO - 2020-08-17 17:15:50 --> Loader Class Initialized
INFO - 2020-08-17 17:15:50 --> Helper loaded: url_helper
INFO - 2020-08-17 17:15:50 --> Database Driver Class Initialized
INFO - 2020-08-17 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:15:50 --> Email Class Initialized
INFO - 2020-08-17 17:15:50 --> Controller Class Initialized
INFO - 2020-08-17 17:15:50 --> Model Class Initialized
INFO - 2020-08-17 17:15:50 --> Model Class Initialized
DEBUG - 2020-08-17 17:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:15:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:15:50 --> Model Class Initialized
INFO - 2020-08-17 17:15:50 --> Final output sent to browser
DEBUG - 2020-08-17 17:15:50 --> Total execution time: 0.0251
INFO - 2020-08-17 17:15:50 --> Config Class Initialized
INFO - 2020-08-17 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:15:50 --> Utf8 Class Initialized
INFO - 2020-08-17 17:15:50 --> URI Class Initialized
INFO - 2020-08-17 17:15:50 --> Router Class Initialized
INFO - 2020-08-17 17:15:50 --> Output Class Initialized
INFO - 2020-08-17 17:15:50 --> Security Class Initialized
DEBUG - 2020-08-17 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:15:50 --> Input Class Initialized
INFO - 2020-08-17 17:15:50 --> Language Class Initialized
INFO - 2020-08-17 17:15:50 --> Loader Class Initialized
INFO - 2020-08-17 17:15:50 --> Helper loaded: url_helper
INFO - 2020-08-17 17:15:50 --> Database Driver Class Initialized
INFO - 2020-08-17 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:15:50 --> Email Class Initialized
INFO - 2020-08-17 17:15:50 --> Controller Class Initialized
INFO - 2020-08-17 17:15:50 --> Model Class Initialized
INFO - 2020-08-17 17:15:50 --> Model Class Initialized
DEBUG - 2020-08-17 17:15:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:15:50 --> Config Class Initialized
INFO - 2020-08-17 17:15:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:15:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:15:50 --> Utf8 Class Initialized
INFO - 2020-08-17 17:15:50 --> URI Class Initialized
INFO - 2020-08-17 17:15:50 --> Router Class Initialized
INFO - 2020-08-17 17:15:50 --> Output Class Initialized
INFO - 2020-08-17 17:15:50 --> Security Class Initialized
DEBUG - 2020-08-17 17:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:15:50 --> Input Class Initialized
INFO - 2020-08-17 17:15:50 --> Language Class Initialized
INFO - 2020-08-17 17:15:50 --> Loader Class Initialized
INFO - 2020-08-17 17:15:50 --> Helper loaded: url_helper
INFO - 2020-08-17 17:15:50 --> Database Driver Class Initialized
INFO - 2020-08-17 17:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:15:50 --> Email Class Initialized
INFO - 2020-08-17 17:15:50 --> Controller Class Initialized
DEBUG - 2020-08-17 17:15:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:15:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:15:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:15:50 --> Final output sent to browser
DEBUG - 2020-08-17 17:15:50 --> Total execution time: 0.0217
INFO - 2020-08-17 17:16:25 --> Config Class Initialized
INFO - 2020-08-17 17:16:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:16:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:16:25 --> Utf8 Class Initialized
INFO - 2020-08-17 17:16:25 --> URI Class Initialized
INFO - 2020-08-17 17:16:25 --> Router Class Initialized
INFO - 2020-08-17 17:16:25 --> Output Class Initialized
INFO - 2020-08-17 17:16:25 --> Security Class Initialized
DEBUG - 2020-08-17 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:16:25 --> Input Class Initialized
INFO - 2020-08-17 17:16:25 --> Language Class Initialized
INFO - 2020-08-17 17:16:25 --> Loader Class Initialized
INFO - 2020-08-17 17:16:25 --> Helper loaded: url_helper
INFO - 2020-08-17 17:16:25 --> Database Driver Class Initialized
INFO - 2020-08-17 17:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:16:25 --> Email Class Initialized
INFO - 2020-08-17 17:16:25 --> Controller Class Initialized
DEBUG - 2020-08-17 17:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:16:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:16:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:16:25 --> Final output sent to browser
DEBUG - 2020-08-17 17:16:25 --> Total execution time: 0.0237
INFO - 2020-08-17 17:16:28 --> Config Class Initialized
INFO - 2020-08-17 17:16:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:16:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:16:28 --> Utf8 Class Initialized
INFO - 2020-08-17 17:16:28 --> URI Class Initialized
INFO - 2020-08-17 17:16:28 --> Router Class Initialized
INFO - 2020-08-17 17:16:28 --> Output Class Initialized
INFO - 2020-08-17 17:16:28 --> Security Class Initialized
DEBUG - 2020-08-17 17:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:16:28 --> Input Class Initialized
INFO - 2020-08-17 17:16:28 --> Language Class Initialized
INFO - 2020-08-17 17:16:28 --> Loader Class Initialized
INFO - 2020-08-17 17:16:28 --> Helper loaded: url_helper
INFO - 2020-08-17 17:16:28 --> Database Driver Class Initialized
INFO - 2020-08-17 17:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:16:28 --> Email Class Initialized
INFO - 2020-08-17 17:16:28 --> Controller Class Initialized
DEBUG - 2020-08-17 17:16:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:16:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:16:28 --> Model Class Initialized
INFO - 2020-08-17 17:16:28 --> Model Class Initialized
INFO - 2020-08-17 17:16:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:16:28 --> Final output sent to browser
DEBUG - 2020-08-17 17:16:28 --> Total execution time: 0.0276
INFO - 2020-08-17 17:16:32 --> Config Class Initialized
INFO - 2020-08-17 17:16:32 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:16:32 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:16:32 --> Utf8 Class Initialized
INFO - 2020-08-17 17:16:32 --> URI Class Initialized
INFO - 2020-08-17 17:16:32 --> Router Class Initialized
INFO - 2020-08-17 17:16:32 --> Output Class Initialized
INFO - 2020-08-17 17:16:32 --> Security Class Initialized
DEBUG - 2020-08-17 17:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:16:32 --> Input Class Initialized
INFO - 2020-08-17 17:16:32 --> Language Class Initialized
INFO - 2020-08-17 17:16:32 --> Loader Class Initialized
INFO - 2020-08-17 17:16:32 --> Helper loaded: url_helper
INFO - 2020-08-17 17:16:32 --> Database Driver Class Initialized
INFO - 2020-08-17 17:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:16:32 --> Email Class Initialized
INFO - 2020-08-17 17:16:32 --> Controller Class Initialized
DEBUG - 2020-08-17 17:16:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:16:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:16:32 --> Model Class Initialized
INFO - 2020-08-17 17:16:32 --> Model Class Initialized
INFO - 2020-08-17 17:16:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:16:32 --> Final output sent to browser
DEBUG - 2020-08-17 17:16:32 --> Total execution time: 0.0225
INFO - 2020-08-17 17:16:36 --> Config Class Initialized
INFO - 2020-08-17 17:16:36 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:16:36 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:16:36 --> Utf8 Class Initialized
INFO - 2020-08-17 17:16:36 --> URI Class Initialized
INFO - 2020-08-17 17:16:36 --> Router Class Initialized
INFO - 2020-08-17 17:16:36 --> Output Class Initialized
INFO - 2020-08-17 17:16:36 --> Security Class Initialized
DEBUG - 2020-08-17 17:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:16:36 --> Input Class Initialized
INFO - 2020-08-17 17:16:36 --> Language Class Initialized
INFO - 2020-08-17 17:16:36 --> Loader Class Initialized
INFO - 2020-08-17 17:16:36 --> Helper loaded: url_helper
INFO - 2020-08-17 17:16:36 --> Database Driver Class Initialized
INFO - 2020-08-17 17:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:16:36 --> Email Class Initialized
INFO - 2020-08-17 17:16:36 --> Controller Class Initialized
DEBUG - 2020-08-17 17:16:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:16:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:16:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:16:36 --> Final output sent to browser
DEBUG - 2020-08-17 17:16:36 --> Total execution time: 0.0207
INFO - 2020-08-17 17:17:45 --> Config Class Initialized
INFO - 2020-08-17 17:17:45 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:17:45 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:17:45 --> Utf8 Class Initialized
INFO - 2020-08-17 17:17:45 --> URI Class Initialized
INFO - 2020-08-17 17:17:45 --> Router Class Initialized
INFO - 2020-08-17 17:17:45 --> Output Class Initialized
INFO - 2020-08-17 17:17:45 --> Security Class Initialized
DEBUG - 2020-08-17 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:17:45 --> Input Class Initialized
INFO - 2020-08-17 17:17:45 --> Language Class Initialized
INFO - 2020-08-17 17:17:45 --> Loader Class Initialized
INFO - 2020-08-17 17:17:45 --> Helper loaded: url_helper
INFO - 2020-08-17 17:17:45 --> Database Driver Class Initialized
INFO - 2020-08-17 17:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:17:45 --> Email Class Initialized
INFO - 2020-08-17 17:17:45 --> Controller Class Initialized
DEBUG - 2020-08-17 17:17:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:17:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:17:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:17:45 --> Final output sent to browser
DEBUG - 2020-08-17 17:17:45 --> Total execution time: 0.0233
INFO - 2020-08-17 17:17:51 --> Config Class Initialized
INFO - 2020-08-17 17:17:51 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:17:51 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:17:51 --> Utf8 Class Initialized
INFO - 2020-08-17 17:17:51 --> URI Class Initialized
INFO - 2020-08-17 17:17:51 --> Router Class Initialized
INFO - 2020-08-17 17:17:51 --> Output Class Initialized
INFO - 2020-08-17 17:17:51 --> Security Class Initialized
DEBUG - 2020-08-17 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:17:51 --> Input Class Initialized
INFO - 2020-08-17 17:17:51 --> Language Class Initialized
INFO - 2020-08-17 17:17:51 --> Loader Class Initialized
INFO - 2020-08-17 17:17:51 --> Helper loaded: url_helper
INFO - 2020-08-17 17:17:51 --> Database Driver Class Initialized
INFO - 2020-08-17 17:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:17:51 --> Email Class Initialized
INFO - 2020-08-17 17:17:51 --> Controller Class Initialized
DEBUG - 2020-08-17 17:17:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:17:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:17:51 --> Model Class Initialized
INFO - 2020-08-17 17:17:51 --> Model Class Initialized
INFO - 2020-08-17 17:17:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:17:51 --> Final output sent to browser
DEBUG - 2020-08-17 17:17:51 --> Total execution time: 0.0239
INFO - 2020-08-17 17:17:53 --> Config Class Initialized
INFO - 2020-08-17 17:17:53 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:17:53 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:17:53 --> Utf8 Class Initialized
INFO - 2020-08-17 17:17:53 --> URI Class Initialized
INFO - 2020-08-17 17:17:53 --> Router Class Initialized
INFO - 2020-08-17 17:17:53 --> Output Class Initialized
INFO - 2020-08-17 17:17:53 --> Security Class Initialized
DEBUG - 2020-08-17 17:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:17:53 --> Input Class Initialized
INFO - 2020-08-17 17:17:53 --> Language Class Initialized
INFO - 2020-08-17 17:17:53 --> Loader Class Initialized
INFO - 2020-08-17 17:17:53 --> Helper loaded: url_helper
INFO - 2020-08-17 17:17:53 --> Database Driver Class Initialized
INFO - 2020-08-17 17:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:17:53 --> Email Class Initialized
INFO - 2020-08-17 17:17:53 --> Controller Class Initialized
DEBUG - 2020-08-17 17:17:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:17:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:17:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:17:53 --> Final output sent to browser
DEBUG - 2020-08-17 17:17:53 --> Total execution time: 0.0231
INFO - 2020-08-17 17:18:03 --> Config Class Initialized
INFO - 2020-08-17 17:18:03 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:03 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:03 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:03 --> URI Class Initialized
INFO - 2020-08-17 17:18:03 --> Router Class Initialized
INFO - 2020-08-17 17:18:03 --> Output Class Initialized
INFO - 2020-08-17 17:18:03 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:03 --> Input Class Initialized
INFO - 2020-08-17 17:18:03 --> Language Class Initialized
INFO - 2020-08-17 17:18:03 --> Loader Class Initialized
INFO - 2020-08-17 17:18:03 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:03 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:03 --> Email Class Initialized
INFO - 2020-08-17 17:18:03 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:03 --> Model Class Initialized
INFO - 2020-08-17 17:18:03 --> Model Class Initialized
INFO - 2020-08-17 17:18:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:18:03 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:03 --> Total execution time: 0.0284
INFO - 2020-08-17 17:18:05 --> Config Class Initialized
INFO - 2020-08-17 17:18:05 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:05 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:05 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:05 --> URI Class Initialized
INFO - 2020-08-17 17:18:05 --> Router Class Initialized
INFO - 2020-08-17 17:18:05 --> Output Class Initialized
INFO - 2020-08-17 17:18:05 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:05 --> Input Class Initialized
INFO - 2020-08-17 17:18:05 --> Language Class Initialized
INFO - 2020-08-17 17:18:05 --> Loader Class Initialized
INFO - 2020-08-17 17:18:05 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:05 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:05 --> Email Class Initialized
INFO - 2020-08-17 17:18:05 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:05 --> Model Class Initialized
INFO - 2020-08-17 17:18:05 --> Model Class Initialized
INFO - 2020-08-17 17:18:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:18:05 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:05 --> Total execution time: 0.0240
INFO - 2020-08-17 17:18:07 --> Config Class Initialized
INFO - 2020-08-17 17:18:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:07 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:07 --> URI Class Initialized
INFO - 2020-08-17 17:18:07 --> Router Class Initialized
INFO - 2020-08-17 17:18:07 --> Output Class Initialized
INFO - 2020-08-17 17:18:07 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:07 --> Input Class Initialized
INFO - 2020-08-17 17:18:07 --> Language Class Initialized
INFO - 2020-08-17 17:18:07 --> Loader Class Initialized
INFO - 2020-08-17 17:18:07 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:07 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:07 --> Email Class Initialized
INFO - 2020-08-17 17:18:07 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:07 --> Model Class Initialized
INFO - 2020-08-17 17:18:07 --> Model Class Initialized
INFO - 2020-08-17 17:18:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 17:18:07 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:07 --> Total execution time: 0.0262
INFO - 2020-08-17 17:18:09 --> Config Class Initialized
INFO - 2020-08-17 17:18:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:09 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:09 --> URI Class Initialized
INFO - 2020-08-17 17:18:09 --> Router Class Initialized
INFO - 2020-08-17 17:18:09 --> Output Class Initialized
INFO - 2020-08-17 17:18:09 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:09 --> Input Class Initialized
INFO - 2020-08-17 17:18:09 --> Language Class Initialized
INFO - 2020-08-17 17:18:09 --> Loader Class Initialized
INFO - 2020-08-17 17:18:09 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:09 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:09 --> Email Class Initialized
INFO - 2020-08-17 17:18:09 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:18:09 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:09 --> Total execution time: 0.0269
INFO - 2020-08-17 17:18:29 --> Config Class Initialized
INFO - 2020-08-17 17:18:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:29 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:29 --> URI Class Initialized
INFO - 2020-08-17 17:18:29 --> Router Class Initialized
INFO - 2020-08-17 17:18:29 --> Output Class Initialized
INFO - 2020-08-17 17:18:29 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:29 --> Input Class Initialized
INFO - 2020-08-17 17:18:29 --> Language Class Initialized
INFO - 2020-08-17 17:18:29 --> Loader Class Initialized
INFO - 2020-08-17 17:18:29 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:29 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:29 --> Email Class Initialized
INFO - 2020-08-17 17:18:29 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:29 --> Model Class Initialized
INFO - 2020-08-17 17:18:29 --> Model Class Initialized
INFO - 2020-08-17 17:18:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:18:29 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:29 --> Total execution time: 0.0253
INFO - 2020-08-17 17:18:47 --> Config Class Initialized
INFO - 2020-08-17 17:18:47 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:47 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:47 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:47 --> URI Class Initialized
INFO - 2020-08-17 17:18:47 --> Router Class Initialized
INFO - 2020-08-17 17:18:47 --> Output Class Initialized
INFO - 2020-08-17 17:18:47 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:47 --> Input Class Initialized
INFO - 2020-08-17 17:18:47 --> Language Class Initialized
INFO - 2020-08-17 17:18:47 --> Loader Class Initialized
INFO - 2020-08-17 17:18:47 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:47 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:47 --> Email Class Initialized
INFO - 2020-08-17 17:18:47 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:47 --> Model Class Initialized
INFO - 2020-08-17 17:18:47 --> Model Class Initialized
INFO - 2020-08-17 17:18:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-17 17:18:47 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:47 --> Total execution time: 0.0304
INFO - 2020-08-17 17:18:50 --> Config Class Initialized
INFO - 2020-08-17 17:18:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:50 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:50 --> URI Class Initialized
INFO - 2020-08-17 17:18:50 --> Router Class Initialized
INFO - 2020-08-17 17:18:50 --> Output Class Initialized
INFO - 2020-08-17 17:18:50 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:50 --> Input Class Initialized
INFO - 2020-08-17 17:18:50 --> Language Class Initialized
INFO - 2020-08-17 17:18:50 --> Loader Class Initialized
INFO - 2020-08-17 17:18:50 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:50 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:50 --> Email Class Initialized
INFO - 2020-08-17 17:18:50 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:50 --> Model Class Initialized
INFO - 2020-08-17 17:18:50 --> Model Class Initialized
INFO - 2020-08-17 17:18:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:18:50 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:50 --> Total execution time: 0.0229
INFO - 2020-08-17 17:18:52 --> Config Class Initialized
INFO - 2020-08-17 17:18:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:52 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:52 --> URI Class Initialized
INFO - 2020-08-17 17:18:52 --> Router Class Initialized
INFO - 2020-08-17 17:18:52 --> Output Class Initialized
INFO - 2020-08-17 17:18:52 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:52 --> Input Class Initialized
INFO - 2020-08-17 17:18:52 --> Language Class Initialized
INFO - 2020-08-17 17:18:52 --> Loader Class Initialized
INFO - 2020-08-17 17:18:52 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:52 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:52 --> Email Class Initialized
INFO - 2020-08-17 17:18:52 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:52 --> Model Class Initialized
INFO - 2020-08-17 17:18:52 --> Model Class Initialized
INFO - 2020-08-17 17:18:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-17 17:18:52 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:52 --> Total execution time: 0.0285
INFO - 2020-08-17 17:18:56 --> Config Class Initialized
INFO - 2020-08-17 17:18:56 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:18:56 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:18:56 --> Utf8 Class Initialized
INFO - 2020-08-17 17:18:56 --> URI Class Initialized
INFO - 2020-08-17 17:18:56 --> Router Class Initialized
INFO - 2020-08-17 17:18:56 --> Output Class Initialized
INFO - 2020-08-17 17:18:56 --> Security Class Initialized
DEBUG - 2020-08-17 17:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:18:56 --> Input Class Initialized
INFO - 2020-08-17 17:18:56 --> Language Class Initialized
INFO - 2020-08-17 17:18:56 --> Loader Class Initialized
INFO - 2020-08-17 17:18:56 --> Helper loaded: url_helper
INFO - 2020-08-17 17:18:56 --> Database Driver Class Initialized
INFO - 2020-08-17 17:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:18:56 --> Email Class Initialized
INFO - 2020-08-17 17:18:56 --> Controller Class Initialized
DEBUG - 2020-08-17 17:18:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:18:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:18:56 --> Model Class Initialized
INFO - 2020-08-17 17:18:56 --> Model Class Initialized
INFO - 2020-08-17 17:18:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:18:56 --> Final output sent to browser
DEBUG - 2020-08-17 17:18:56 --> Total execution time: 0.0260
INFO - 2020-08-17 17:19:03 --> Config Class Initialized
INFO - 2020-08-17 17:19:03 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:19:03 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:19:03 --> Utf8 Class Initialized
INFO - 2020-08-17 17:19:03 --> URI Class Initialized
INFO - 2020-08-17 17:19:03 --> Router Class Initialized
INFO - 2020-08-17 17:19:03 --> Output Class Initialized
INFO - 2020-08-17 17:19:03 --> Security Class Initialized
DEBUG - 2020-08-17 17:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:19:03 --> Input Class Initialized
INFO - 2020-08-17 17:19:03 --> Language Class Initialized
INFO - 2020-08-17 17:19:03 --> Loader Class Initialized
INFO - 2020-08-17 17:19:03 --> Helper loaded: url_helper
INFO - 2020-08-17 17:19:03 --> Database Driver Class Initialized
INFO - 2020-08-17 17:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:19:03 --> Email Class Initialized
INFO - 2020-08-17 17:19:03 --> Controller Class Initialized
DEBUG - 2020-08-17 17:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:19:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:19:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:19:03 --> Final output sent to browser
DEBUG - 2020-08-17 17:19:03 --> Total execution time: 0.0222
INFO - 2020-08-17 17:19:11 --> Config Class Initialized
INFO - 2020-08-17 17:19:11 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:19:11 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:19:11 --> Utf8 Class Initialized
INFO - 2020-08-17 17:19:11 --> URI Class Initialized
DEBUG - 2020-08-17 17:19:11 --> No URI present. Default controller set.
INFO - 2020-08-17 17:19:11 --> Router Class Initialized
INFO - 2020-08-17 17:19:11 --> Output Class Initialized
INFO - 2020-08-17 17:19:11 --> Security Class Initialized
DEBUG - 2020-08-17 17:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:19:11 --> Input Class Initialized
INFO - 2020-08-17 17:19:11 --> Language Class Initialized
INFO - 2020-08-17 17:19:11 --> Loader Class Initialized
INFO - 2020-08-17 17:19:11 --> Helper loaded: url_helper
INFO - 2020-08-17 17:19:11 --> Database Driver Class Initialized
INFO - 2020-08-17 17:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:19:11 --> Email Class Initialized
INFO - 2020-08-17 17:19:11 --> Controller Class Initialized
INFO - 2020-08-17 17:19:11 --> Model Class Initialized
INFO - 2020-08-17 17:19:11 --> Model Class Initialized
DEBUG - 2020-08-17 17:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:19:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:19:11 --> Final output sent to browser
DEBUG - 2020-08-17 17:19:11 --> Total execution time: 0.0218
INFO - 2020-08-17 17:19:52 --> Config Class Initialized
INFO - 2020-08-17 17:19:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:19:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:19:52 --> Utf8 Class Initialized
INFO - 2020-08-17 17:19:52 --> URI Class Initialized
INFO - 2020-08-17 17:19:52 --> Router Class Initialized
INFO - 2020-08-17 17:19:52 --> Output Class Initialized
INFO - 2020-08-17 17:19:52 --> Security Class Initialized
DEBUG - 2020-08-17 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:19:52 --> Input Class Initialized
INFO - 2020-08-17 17:19:52 --> Language Class Initialized
INFO - 2020-08-17 17:19:52 --> Loader Class Initialized
INFO - 2020-08-17 17:19:52 --> Helper loaded: url_helper
INFO - 2020-08-17 17:19:52 --> Database Driver Class Initialized
INFO - 2020-08-17 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:19:52 --> Email Class Initialized
INFO - 2020-08-17 17:19:52 --> Controller Class Initialized
INFO - 2020-08-17 17:19:52 --> Model Class Initialized
INFO - 2020-08-17 17:19:52 --> Model Class Initialized
DEBUG - 2020-08-17 17:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:19:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:19:52 --> Model Class Initialized
INFO - 2020-08-17 17:19:52 --> Final output sent to browser
DEBUG - 2020-08-17 17:19:52 --> Total execution time: 0.0257
INFO - 2020-08-17 17:19:52 --> Config Class Initialized
INFO - 2020-08-17 17:19:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:19:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:19:52 --> Utf8 Class Initialized
INFO - 2020-08-17 17:19:52 --> URI Class Initialized
INFO - 2020-08-17 17:19:52 --> Router Class Initialized
INFO - 2020-08-17 17:19:52 --> Output Class Initialized
INFO - 2020-08-17 17:19:52 --> Security Class Initialized
DEBUG - 2020-08-17 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:19:52 --> Input Class Initialized
INFO - 2020-08-17 17:19:52 --> Language Class Initialized
INFO - 2020-08-17 17:19:52 --> Loader Class Initialized
INFO - 2020-08-17 17:19:52 --> Helper loaded: url_helper
INFO - 2020-08-17 17:19:52 --> Database Driver Class Initialized
INFO - 2020-08-17 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:19:52 --> Email Class Initialized
INFO - 2020-08-17 17:19:52 --> Controller Class Initialized
INFO - 2020-08-17 17:19:52 --> Model Class Initialized
INFO - 2020-08-17 17:19:52 --> Model Class Initialized
DEBUG - 2020-08-17 17:19:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:19:52 --> Config Class Initialized
INFO - 2020-08-17 17:19:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:19:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:19:52 --> Utf8 Class Initialized
INFO - 2020-08-17 17:19:52 --> URI Class Initialized
INFO - 2020-08-17 17:19:52 --> Router Class Initialized
INFO - 2020-08-17 17:19:52 --> Output Class Initialized
INFO - 2020-08-17 17:19:52 --> Security Class Initialized
DEBUG - 2020-08-17 17:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:19:52 --> Input Class Initialized
INFO - 2020-08-17 17:19:52 --> Language Class Initialized
INFO - 2020-08-17 17:19:52 --> Loader Class Initialized
INFO - 2020-08-17 17:19:52 --> Helper loaded: url_helper
INFO - 2020-08-17 17:19:52 --> Database Driver Class Initialized
INFO - 2020-08-17 17:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:19:52 --> Email Class Initialized
INFO - 2020-08-17 17:19:52 --> Controller Class Initialized
DEBUG - 2020-08-17 17:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:19:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:19:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:19:52 --> Final output sent to browser
DEBUG - 2020-08-17 17:19:52 --> Total execution time: 0.0198
INFO - 2020-08-17 17:40:44 --> Config Class Initialized
INFO - 2020-08-17 17:40:44 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:40:44 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:40:44 --> Utf8 Class Initialized
INFO - 2020-08-17 17:40:44 --> URI Class Initialized
INFO - 2020-08-17 17:40:44 --> Router Class Initialized
INFO - 2020-08-17 17:40:44 --> Output Class Initialized
INFO - 2020-08-17 17:40:44 --> Security Class Initialized
DEBUG - 2020-08-17 17:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:40:44 --> Input Class Initialized
INFO - 2020-08-17 17:40:44 --> Language Class Initialized
INFO - 2020-08-17 17:40:44 --> Loader Class Initialized
INFO - 2020-08-17 17:40:44 --> Helper loaded: url_helper
INFO - 2020-08-17 17:40:44 --> Database Driver Class Initialized
INFO - 2020-08-17 17:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:40:44 --> Email Class Initialized
INFO - 2020-08-17 17:40:44 --> Controller Class Initialized
DEBUG - 2020-08-17 17:40:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:40:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:40:44 --> Config Class Initialized
INFO - 2020-08-17 17:40:44 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:40:44 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:40:44 --> Utf8 Class Initialized
INFO - 2020-08-17 17:40:44 --> URI Class Initialized
DEBUG - 2020-08-17 17:40:44 --> No URI present. Default controller set.
INFO - 2020-08-17 17:40:44 --> Router Class Initialized
INFO - 2020-08-17 17:40:44 --> Output Class Initialized
INFO - 2020-08-17 17:40:44 --> Security Class Initialized
DEBUG - 2020-08-17 17:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:40:44 --> Input Class Initialized
INFO - 2020-08-17 17:40:44 --> Language Class Initialized
INFO - 2020-08-17 17:40:44 --> Loader Class Initialized
INFO - 2020-08-17 17:40:44 --> Helper loaded: url_helper
INFO - 2020-08-17 17:40:44 --> Database Driver Class Initialized
INFO - 2020-08-17 17:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:40:44 --> Email Class Initialized
INFO - 2020-08-17 17:40:44 --> Controller Class Initialized
INFO - 2020-08-17 17:40:44 --> Model Class Initialized
INFO - 2020-08-17 17:40:44 --> Model Class Initialized
DEBUG - 2020-08-17 17:40:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:40:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:40:44 --> Final output sent to browser
DEBUG - 2020-08-17 17:40:44 --> Total execution time: 0.0240
INFO - 2020-08-17 17:40:45 --> Config Class Initialized
INFO - 2020-08-17 17:40:45 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:40:45 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:40:45 --> Utf8 Class Initialized
INFO - 2020-08-17 17:40:45 --> URI Class Initialized
DEBUG - 2020-08-17 17:40:45 --> No URI present. Default controller set.
INFO - 2020-08-17 17:40:45 --> Router Class Initialized
INFO - 2020-08-17 17:40:45 --> Output Class Initialized
INFO - 2020-08-17 17:40:45 --> Security Class Initialized
DEBUG - 2020-08-17 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:40:45 --> Input Class Initialized
INFO - 2020-08-17 17:40:45 --> Language Class Initialized
INFO - 2020-08-17 17:40:45 --> Loader Class Initialized
INFO - 2020-08-17 17:40:45 --> Helper loaded: url_helper
INFO - 2020-08-17 17:40:45 --> Database Driver Class Initialized
INFO - 2020-08-17 17:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:40:45 --> Email Class Initialized
INFO - 2020-08-17 17:40:45 --> Controller Class Initialized
INFO - 2020-08-17 17:40:45 --> Model Class Initialized
INFO - 2020-08-17 17:40:45 --> Model Class Initialized
DEBUG - 2020-08-17 17:40:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:40:45 --> Final output sent to browser
DEBUG - 2020-08-17 17:40:45 --> Total execution time: 0.0230
INFO - 2020-08-17 17:41:26 --> Config Class Initialized
INFO - 2020-08-17 17:41:26 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:41:26 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:41:26 --> Utf8 Class Initialized
INFO - 2020-08-17 17:41:26 --> URI Class Initialized
DEBUG - 2020-08-17 17:41:26 --> No URI present. Default controller set.
INFO - 2020-08-17 17:41:26 --> Router Class Initialized
INFO - 2020-08-17 17:41:26 --> Output Class Initialized
INFO - 2020-08-17 17:41:26 --> Security Class Initialized
DEBUG - 2020-08-17 17:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:41:26 --> Input Class Initialized
INFO - 2020-08-17 17:41:26 --> Language Class Initialized
INFO - 2020-08-17 17:41:26 --> Loader Class Initialized
INFO - 2020-08-17 17:41:26 --> Helper loaded: url_helper
INFO - 2020-08-17 17:41:26 --> Database Driver Class Initialized
INFO - 2020-08-17 17:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:41:26 --> Email Class Initialized
INFO - 2020-08-17 17:41:26 --> Controller Class Initialized
INFO - 2020-08-17 17:41:26 --> Model Class Initialized
INFO - 2020-08-17 17:41:26 --> Model Class Initialized
DEBUG - 2020-08-17 17:41:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:41:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:41:26 --> Final output sent to browser
DEBUG - 2020-08-17 17:41:26 --> Total execution time: 0.0227
INFO - 2020-08-17 17:41:54 --> Config Class Initialized
INFO - 2020-08-17 17:41:54 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:41:54 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:41:54 --> Utf8 Class Initialized
INFO - 2020-08-17 17:41:54 --> URI Class Initialized
DEBUG - 2020-08-17 17:41:54 --> No URI present. Default controller set.
INFO - 2020-08-17 17:41:54 --> Router Class Initialized
INFO - 2020-08-17 17:41:54 --> Output Class Initialized
INFO - 2020-08-17 17:41:54 --> Security Class Initialized
DEBUG - 2020-08-17 17:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:41:54 --> Input Class Initialized
INFO - 2020-08-17 17:41:54 --> Language Class Initialized
INFO - 2020-08-17 17:41:54 --> Loader Class Initialized
INFO - 2020-08-17 17:41:54 --> Helper loaded: url_helper
INFO - 2020-08-17 17:41:54 --> Database Driver Class Initialized
INFO - 2020-08-17 17:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:41:54 --> Email Class Initialized
INFO - 2020-08-17 17:41:54 --> Controller Class Initialized
INFO - 2020-08-17 17:41:54 --> Model Class Initialized
INFO - 2020-08-17 17:41:54 --> Model Class Initialized
DEBUG - 2020-08-17 17:41:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:41:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:41:54 --> Final output sent to browser
DEBUG - 2020-08-17 17:41:54 --> Total execution time: 0.0194
INFO - 2020-08-17 17:42:31 --> Config Class Initialized
INFO - 2020-08-17 17:42:31 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:42:31 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:42:31 --> Utf8 Class Initialized
INFO - 2020-08-17 17:42:31 --> URI Class Initialized
DEBUG - 2020-08-17 17:42:31 --> No URI present. Default controller set.
INFO - 2020-08-17 17:42:31 --> Router Class Initialized
INFO - 2020-08-17 17:42:31 --> Output Class Initialized
INFO - 2020-08-17 17:42:31 --> Security Class Initialized
DEBUG - 2020-08-17 17:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:42:31 --> Input Class Initialized
INFO - 2020-08-17 17:42:31 --> Language Class Initialized
INFO - 2020-08-17 17:42:31 --> Loader Class Initialized
INFO - 2020-08-17 17:42:31 --> Helper loaded: url_helper
INFO - 2020-08-17 17:42:31 --> Database Driver Class Initialized
INFO - 2020-08-17 17:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:42:31 --> Email Class Initialized
INFO - 2020-08-17 17:42:31 --> Controller Class Initialized
INFO - 2020-08-17 17:42:31 --> Model Class Initialized
INFO - 2020-08-17 17:42:31 --> Model Class Initialized
DEBUG - 2020-08-17 17:42:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:42:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:42:31 --> Final output sent to browser
DEBUG - 2020-08-17 17:42:31 --> Total execution time: 0.0253
INFO - 2020-08-17 17:42:57 --> Config Class Initialized
INFO - 2020-08-17 17:42:57 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:42:57 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:42:57 --> Utf8 Class Initialized
INFO - 2020-08-17 17:42:57 --> URI Class Initialized
DEBUG - 2020-08-17 17:42:57 --> No URI present. Default controller set.
INFO - 2020-08-17 17:42:57 --> Router Class Initialized
INFO - 2020-08-17 17:42:57 --> Output Class Initialized
INFO - 2020-08-17 17:42:57 --> Security Class Initialized
DEBUG - 2020-08-17 17:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:42:57 --> Input Class Initialized
INFO - 2020-08-17 17:42:57 --> Language Class Initialized
INFO - 2020-08-17 17:42:57 --> Loader Class Initialized
INFO - 2020-08-17 17:42:57 --> Helper loaded: url_helper
INFO - 2020-08-17 17:42:57 --> Database Driver Class Initialized
INFO - 2020-08-17 17:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:42:57 --> Email Class Initialized
INFO - 2020-08-17 17:42:57 --> Controller Class Initialized
INFO - 2020-08-17 17:42:57 --> Model Class Initialized
INFO - 2020-08-17 17:42:57 --> Model Class Initialized
DEBUG - 2020-08-17 17:42:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:42:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:42:57 --> Final output sent to browser
DEBUG - 2020-08-17 17:42:57 --> Total execution time: 0.0245
INFO - 2020-08-17 17:43:09 --> Config Class Initialized
INFO - 2020-08-17 17:43:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:43:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:43:09 --> Utf8 Class Initialized
INFO - 2020-08-17 17:43:09 --> URI Class Initialized
INFO - 2020-08-17 17:43:09 --> Router Class Initialized
INFO - 2020-08-17 17:43:09 --> Output Class Initialized
INFO - 2020-08-17 17:43:09 --> Security Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:43:09 --> Input Class Initialized
INFO - 2020-08-17 17:43:09 --> Language Class Initialized
INFO - 2020-08-17 17:43:09 --> Loader Class Initialized
INFO - 2020-08-17 17:43:09 --> Helper loaded: url_helper
INFO - 2020-08-17 17:43:09 --> Database Driver Class Initialized
INFO - 2020-08-17 17:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:43:09 --> Email Class Initialized
INFO - 2020-08-17 17:43:09 --> Controller Class Initialized
INFO - 2020-08-17 17:43:09 --> Model Class Initialized
INFO - 2020-08-17 17:43:09 --> Model Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:43:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:43:09 --> Config Class Initialized
INFO - 2020-08-17 17:43:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:43:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:43:09 --> Utf8 Class Initialized
INFO - 2020-08-17 17:43:09 --> URI Class Initialized
INFO - 2020-08-17 17:43:09 --> Router Class Initialized
INFO - 2020-08-17 17:43:09 --> Output Class Initialized
INFO - 2020-08-17 17:43:09 --> Security Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:43:09 --> Input Class Initialized
INFO - 2020-08-17 17:43:09 --> Language Class Initialized
INFO - 2020-08-17 17:43:09 --> Loader Class Initialized
INFO - 2020-08-17 17:43:09 --> Helper loaded: url_helper
INFO - 2020-08-17 17:43:09 --> Database Driver Class Initialized
INFO - 2020-08-17 17:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:43:09 --> Email Class Initialized
INFO - 2020-08-17 17:43:09 --> Controller Class Initialized
INFO - 2020-08-17 17:43:09 --> Model Class Initialized
INFO - 2020-08-17 17:43:09 --> Model Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:43:09 --> Config Class Initialized
INFO - 2020-08-17 17:43:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:43:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:43:09 --> Utf8 Class Initialized
INFO - 2020-08-17 17:43:09 --> URI Class Initialized
INFO - 2020-08-17 17:43:09 --> Router Class Initialized
INFO - 2020-08-17 17:43:09 --> Output Class Initialized
INFO - 2020-08-17 17:43:09 --> Security Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:43:09 --> Input Class Initialized
INFO - 2020-08-17 17:43:09 --> Language Class Initialized
INFO - 2020-08-17 17:43:09 --> Loader Class Initialized
INFO - 2020-08-17 17:43:09 --> Helper loaded: url_helper
INFO - 2020-08-17 17:43:09 --> Config Class Initialized
INFO - 2020-08-17 17:43:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:43:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:43:09 --> Utf8 Class Initialized
INFO - 2020-08-17 17:43:09 --> URI Class Initialized
INFO - 2020-08-17 17:43:09 --> Database Driver Class Initialized
DEBUG - 2020-08-17 17:43:09 --> No URI present. Default controller set.
INFO - 2020-08-17 17:43:09 --> Router Class Initialized
INFO - 2020-08-17 17:43:09 --> Output Class Initialized
INFO - 2020-08-17 17:43:09 --> Security Class Initialized
INFO - 2020-08-17 17:43:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-17 17:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:43:09 --> Input Class Initialized
INFO - 2020-08-17 17:43:09 --> Language Class Initialized
INFO - 2020-08-17 17:43:09 --> Email Class Initialized
INFO - 2020-08-17 17:43:09 --> Controller Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:43:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:43:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:43:09 --> Loader Class Initialized
INFO - 2020-08-17 17:43:09 --> Final output sent to browser
DEBUG - 2020-08-17 17:43:09 --> Total execution time: 0.0205
INFO - 2020-08-17 17:43:09 --> Helper loaded: url_helper
INFO - 2020-08-17 17:43:09 --> Database Driver Class Initialized
INFO - 2020-08-17 17:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:43:09 --> Email Class Initialized
INFO - 2020-08-17 17:43:09 --> Controller Class Initialized
INFO - 2020-08-17 17:43:09 --> Model Class Initialized
INFO - 2020-08-17 17:43:09 --> Model Class Initialized
DEBUG - 2020-08-17 17:43:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:43:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:43:09 --> Final output sent to browser
DEBUG - 2020-08-17 17:43:09 --> Total execution time: 0.0215
INFO - 2020-08-17 17:43:13 --> Config Class Initialized
INFO - 2020-08-17 17:43:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:43:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:43:13 --> Utf8 Class Initialized
INFO - 2020-08-17 17:43:13 --> URI Class Initialized
DEBUG - 2020-08-17 17:43:13 --> No URI present. Default controller set.
INFO - 2020-08-17 17:43:13 --> Router Class Initialized
INFO - 2020-08-17 17:43:13 --> Output Class Initialized
INFO - 2020-08-17 17:43:13 --> Security Class Initialized
DEBUG - 2020-08-17 17:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:43:13 --> Input Class Initialized
INFO - 2020-08-17 17:43:13 --> Language Class Initialized
INFO - 2020-08-17 17:43:13 --> Loader Class Initialized
INFO - 2020-08-17 17:43:13 --> Helper loaded: url_helper
INFO - 2020-08-17 17:43:13 --> Database Driver Class Initialized
INFO - 2020-08-17 17:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:43:13 --> Email Class Initialized
INFO - 2020-08-17 17:43:13 --> Controller Class Initialized
INFO - 2020-08-17 17:43:13 --> Model Class Initialized
INFO - 2020-08-17 17:43:13 --> Model Class Initialized
DEBUG - 2020-08-17 17:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:43:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:43:13 --> Final output sent to browser
DEBUG - 2020-08-17 17:43:13 --> Total execution time: 0.0188
INFO - 2020-08-17 17:44:41 --> Config Class Initialized
INFO - 2020-08-17 17:44:41 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:44:41 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:44:41 --> Utf8 Class Initialized
INFO - 2020-08-17 17:44:41 --> URI Class Initialized
INFO - 2020-08-17 17:44:41 --> Router Class Initialized
INFO - 2020-08-17 17:44:41 --> Output Class Initialized
INFO - 2020-08-17 17:44:41 --> Security Class Initialized
DEBUG - 2020-08-17 17:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:44:41 --> Input Class Initialized
INFO - 2020-08-17 17:44:41 --> Language Class Initialized
INFO - 2020-08-17 17:44:41 --> Loader Class Initialized
INFO - 2020-08-17 17:44:41 --> Helper loaded: url_helper
INFO - 2020-08-17 17:44:41 --> Database Driver Class Initialized
INFO - 2020-08-17 17:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:44:41 --> Email Class Initialized
INFO - 2020-08-17 17:44:41 --> Controller Class Initialized
INFO - 2020-08-17 17:44:41 --> Model Class Initialized
INFO - 2020-08-17 17:44:41 --> Model Class Initialized
DEBUG - 2020-08-17 17:44:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:44:41 --> Config Class Initialized
INFO - 2020-08-17 17:44:41 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:44:41 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:44:41 --> Utf8 Class Initialized
INFO - 2020-08-17 17:44:41 --> URI Class Initialized
INFO - 2020-08-17 17:44:41 --> Router Class Initialized
INFO - 2020-08-17 17:44:41 --> Output Class Initialized
INFO - 2020-08-17 17:44:41 --> Security Class Initialized
DEBUG - 2020-08-17 17:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:44:41 --> Input Class Initialized
INFO - 2020-08-17 17:44:41 --> Language Class Initialized
INFO - 2020-08-17 17:44:41 --> Loader Class Initialized
INFO - 2020-08-17 17:44:41 --> Helper loaded: url_helper
INFO - 2020-08-17 17:44:41 --> Database Driver Class Initialized
INFO - 2020-08-17 17:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:44:41 --> Email Class Initialized
INFO - 2020-08-17 17:44:41 --> Controller Class Initialized
INFO - 2020-08-17 17:44:41 --> Model Class Initialized
INFO - 2020-08-17 17:44:41 --> Model Class Initialized
DEBUG - 2020-08-17 17:44:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:44:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:44:41 --> Model Class Initialized
INFO - 2020-08-17 17:44:41 --> Final output sent to browser
DEBUG - 2020-08-17 17:44:41 --> Total execution time: 0.0224
INFO - 2020-08-17 17:44:42 --> Config Class Initialized
INFO - 2020-08-17 17:44:42 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:44:42 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:44:42 --> Utf8 Class Initialized
INFO - 2020-08-17 17:44:42 --> URI Class Initialized
INFO - 2020-08-17 17:44:42 --> Router Class Initialized
INFO - 2020-08-17 17:44:42 --> Output Class Initialized
INFO - 2020-08-17 17:44:42 --> Security Class Initialized
DEBUG - 2020-08-17 17:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:44:42 --> Input Class Initialized
INFO - 2020-08-17 17:44:42 --> Language Class Initialized
INFO - 2020-08-17 17:44:42 --> Loader Class Initialized
INFO - 2020-08-17 17:44:42 --> Helper loaded: url_helper
INFO - 2020-08-17 17:44:42 --> Database Driver Class Initialized
INFO - 2020-08-17 17:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:44:42 --> Email Class Initialized
INFO - 2020-08-17 17:44:42 --> Controller Class Initialized
DEBUG - 2020-08-17 17:44:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:44:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:44:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:44:42 --> Final output sent to browser
DEBUG - 2020-08-17 17:44:42 --> Total execution time: 0.0202
INFO - 2020-08-17 17:45:13 --> Config Class Initialized
INFO - 2020-08-17 17:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:45:13 --> Utf8 Class Initialized
INFO - 2020-08-17 17:45:13 --> URI Class Initialized
INFO - 2020-08-17 17:45:13 --> Router Class Initialized
INFO - 2020-08-17 17:45:13 --> Output Class Initialized
INFO - 2020-08-17 17:45:13 --> Security Class Initialized
DEBUG - 2020-08-17 17:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:45:13 --> Input Class Initialized
INFO - 2020-08-17 17:45:13 --> Language Class Initialized
INFO - 2020-08-17 17:45:13 --> Loader Class Initialized
INFO - 2020-08-17 17:45:13 --> Helper loaded: url_helper
INFO - 2020-08-17 17:45:13 --> Database Driver Class Initialized
INFO - 2020-08-17 17:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:45:13 --> Email Class Initialized
INFO - 2020-08-17 17:45:13 --> Controller Class Initialized
DEBUG - 2020-08-17 17:45:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:45:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:45:13 --> Model Class Initialized
INFO - 2020-08-17 17:45:13 --> Model Class Initialized
INFO - 2020-08-17 17:45:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:45:13 --> Final output sent to browser
DEBUG - 2020-08-17 17:45:13 --> Total execution time: 0.0264
INFO - 2020-08-17 17:45:24 --> Config Class Initialized
INFO - 2020-08-17 17:45:24 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:45:24 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:45:24 --> Utf8 Class Initialized
INFO - 2020-08-17 17:45:24 --> URI Class Initialized
DEBUG - 2020-08-17 17:45:24 --> No URI present. Default controller set.
INFO - 2020-08-17 17:45:24 --> Router Class Initialized
INFO - 2020-08-17 17:45:24 --> Output Class Initialized
INFO - 2020-08-17 17:45:24 --> Security Class Initialized
DEBUG - 2020-08-17 17:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:45:24 --> Input Class Initialized
INFO - 2020-08-17 17:45:24 --> Language Class Initialized
INFO - 2020-08-17 17:45:24 --> Loader Class Initialized
INFO - 2020-08-17 17:45:24 --> Helper loaded: url_helper
INFO - 2020-08-17 17:45:24 --> Database Driver Class Initialized
INFO - 2020-08-17 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:45:24 --> Email Class Initialized
INFO - 2020-08-17 17:45:24 --> Controller Class Initialized
INFO - 2020-08-17 17:45:24 --> Model Class Initialized
INFO - 2020-08-17 17:45:24 --> Model Class Initialized
DEBUG - 2020-08-17 17:45:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:45:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:45:24 --> Final output sent to browser
DEBUG - 2020-08-17 17:45:24 --> Total execution time: 0.0209
INFO - 2020-08-17 17:45:28 --> Config Class Initialized
INFO - 2020-08-17 17:45:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:45:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:45:28 --> Utf8 Class Initialized
INFO - 2020-08-17 17:45:28 --> URI Class Initialized
INFO - 2020-08-17 17:45:28 --> Router Class Initialized
INFO - 2020-08-17 17:45:28 --> Output Class Initialized
INFO - 2020-08-17 17:45:28 --> Security Class Initialized
DEBUG - 2020-08-17 17:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:45:28 --> Input Class Initialized
INFO - 2020-08-17 17:45:28 --> Language Class Initialized
INFO - 2020-08-17 17:45:28 --> Loader Class Initialized
INFO - 2020-08-17 17:45:28 --> Helper loaded: url_helper
INFO - 2020-08-17 17:45:28 --> Database Driver Class Initialized
INFO - 2020-08-17 17:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:45:28 --> Email Class Initialized
INFO - 2020-08-17 17:45:28 --> Controller Class Initialized
INFO - 2020-08-17 17:45:28 --> Model Class Initialized
INFO - 2020-08-17 17:45:28 --> Model Class Initialized
DEBUG - 2020-08-17 17:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:45:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:45:28 --> Model Class Initialized
INFO - 2020-08-17 17:45:28 --> Final output sent to browser
DEBUG - 2020-08-17 17:45:28 --> Total execution time: 0.0244
INFO - 2020-08-17 17:45:28 --> Config Class Initialized
INFO - 2020-08-17 17:45:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:45:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:45:28 --> Utf8 Class Initialized
INFO - 2020-08-17 17:45:28 --> URI Class Initialized
INFO - 2020-08-17 17:45:28 --> Router Class Initialized
INFO - 2020-08-17 17:45:28 --> Output Class Initialized
INFO - 2020-08-17 17:45:28 --> Security Class Initialized
DEBUG - 2020-08-17 17:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:45:28 --> Input Class Initialized
INFO - 2020-08-17 17:45:28 --> Language Class Initialized
INFO - 2020-08-17 17:45:28 --> Loader Class Initialized
INFO - 2020-08-17 17:45:28 --> Helper loaded: url_helper
INFO - 2020-08-17 17:45:28 --> Database Driver Class Initialized
INFO - 2020-08-17 17:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:45:28 --> Email Class Initialized
INFO - 2020-08-17 17:45:28 --> Controller Class Initialized
INFO - 2020-08-17 17:45:28 --> Model Class Initialized
INFO - 2020-08-17 17:45:28 --> Model Class Initialized
DEBUG - 2020-08-17 17:45:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:45:29 --> Config Class Initialized
INFO - 2020-08-17 17:45:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:45:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:45:29 --> Utf8 Class Initialized
INFO - 2020-08-17 17:45:29 --> URI Class Initialized
INFO - 2020-08-17 17:45:29 --> Router Class Initialized
INFO - 2020-08-17 17:45:29 --> Output Class Initialized
INFO - 2020-08-17 17:45:29 --> Security Class Initialized
DEBUG - 2020-08-17 17:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:45:29 --> Input Class Initialized
INFO - 2020-08-17 17:45:29 --> Language Class Initialized
INFO - 2020-08-17 17:45:29 --> Loader Class Initialized
INFO - 2020-08-17 17:45:29 --> Helper loaded: url_helper
INFO - 2020-08-17 17:45:29 --> Database Driver Class Initialized
INFO - 2020-08-17 17:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:45:29 --> Email Class Initialized
INFO - 2020-08-17 17:45:29 --> Controller Class Initialized
DEBUG - 2020-08-17 17:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:45:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:45:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:45:29 --> Final output sent to browser
DEBUG - 2020-08-17 17:45:29 --> Total execution time: 0.0202
INFO - 2020-08-17 17:46:25 --> Config Class Initialized
INFO - 2020-08-17 17:46:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:46:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:46:25 --> Utf8 Class Initialized
INFO - 2020-08-17 17:46:25 --> URI Class Initialized
INFO - 2020-08-17 17:46:25 --> Router Class Initialized
INFO - 2020-08-17 17:46:25 --> Output Class Initialized
INFO - 2020-08-17 17:46:25 --> Security Class Initialized
DEBUG - 2020-08-17 17:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:46:25 --> Input Class Initialized
INFO - 2020-08-17 17:46:25 --> Language Class Initialized
INFO - 2020-08-17 17:46:25 --> Loader Class Initialized
INFO - 2020-08-17 17:46:25 --> Helper loaded: url_helper
INFO - 2020-08-17 17:46:25 --> Database Driver Class Initialized
INFO - 2020-08-17 17:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:46:25 --> Email Class Initialized
INFO - 2020-08-17 17:46:25 --> Controller Class Initialized
DEBUG - 2020-08-17 17:46:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:46:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:46:25 --> Model Class Initialized
INFO - 2020-08-17 17:46:25 --> Model Class Initialized
INFO - 2020-08-17 17:46:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 17:46:25 --> Final output sent to browser
DEBUG - 2020-08-17 17:46:25 --> Total execution time: 0.0253
INFO - 2020-08-17 17:46:27 --> Config Class Initialized
INFO - 2020-08-17 17:46:27 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:46:27 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:46:27 --> Utf8 Class Initialized
INFO - 2020-08-17 17:46:27 --> URI Class Initialized
INFO - 2020-08-17 17:46:27 --> Router Class Initialized
INFO - 2020-08-17 17:46:27 --> Output Class Initialized
INFO - 2020-08-17 17:46:27 --> Security Class Initialized
DEBUG - 2020-08-17 17:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:46:27 --> Input Class Initialized
INFO - 2020-08-17 17:46:27 --> Language Class Initialized
INFO - 2020-08-17 17:46:27 --> Loader Class Initialized
INFO - 2020-08-17 17:46:27 --> Helper loaded: url_helper
INFO - 2020-08-17 17:46:27 --> Database Driver Class Initialized
INFO - 2020-08-17 17:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:46:27 --> Email Class Initialized
INFO - 2020-08-17 17:46:27 --> Controller Class Initialized
DEBUG - 2020-08-17 17:46:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:46:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:46:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:46:27 --> Final output sent to browser
DEBUG - 2020-08-17 17:46:27 --> Total execution time: 0.0212
INFO - 2020-08-17 17:53:46 --> Config Class Initialized
INFO - 2020-08-17 17:53:46 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:53:46 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:53:46 --> Utf8 Class Initialized
INFO - 2020-08-17 17:53:46 --> URI Class Initialized
INFO - 2020-08-17 17:53:46 --> Router Class Initialized
INFO - 2020-08-17 17:53:46 --> Output Class Initialized
INFO - 2020-08-17 17:53:46 --> Security Class Initialized
DEBUG - 2020-08-17 17:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:53:46 --> Input Class Initialized
INFO - 2020-08-17 17:53:46 --> Language Class Initialized
INFO - 2020-08-17 17:53:46 --> Loader Class Initialized
INFO - 2020-08-17 17:53:46 --> Helper loaded: url_helper
INFO - 2020-08-17 17:53:46 --> Database Driver Class Initialized
INFO - 2020-08-17 17:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:53:46 --> Email Class Initialized
INFO - 2020-08-17 17:53:46 --> Controller Class Initialized
DEBUG - 2020-08-17 17:53:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:53:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:53:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:53:46 --> Final output sent to browser
DEBUG - 2020-08-17 17:53:46 --> Total execution time: 0.0192
INFO - 2020-08-17 17:55:52 --> Config Class Initialized
INFO - 2020-08-17 17:55:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:55:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:55:52 --> Utf8 Class Initialized
INFO - 2020-08-17 17:55:52 --> URI Class Initialized
INFO - 2020-08-17 17:55:52 --> Router Class Initialized
INFO - 2020-08-17 17:55:52 --> Output Class Initialized
INFO - 2020-08-17 17:55:52 --> Security Class Initialized
DEBUG - 2020-08-17 17:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:55:52 --> Input Class Initialized
INFO - 2020-08-17 17:55:52 --> Language Class Initialized
INFO - 2020-08-17 17:55:52 --> Loader Class Initialized
INFO - 2020-08-17 17:55:52 --> Helper loaded: url_helper
INFO - 2020-08-17 17:55:52 --> Database Driver Class Initialized
INFO - 2020-08-17 17:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:55:52 --> Email Class Initialized
INFO - 2020-08-17 17:55:52 --> Controller Class Initialized
DEBUG - 2020-08-17 17:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:55:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:55:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:55:52 --> Final output sent to browser
DEBUG - 2020-08-17 17:55:52 --> Total execution time: 0.0213
INFO - 2020-08-17 17:56:01 --> Config Class Initialized
INFO - 2020-08-17 17:56:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:56:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:56:01 --> Utf8 Class Initialized
INFO - 2020-08-17 17:56:01 --> URI Class Initialized
DEBUG - 2020-08-17 17:56:01 --> No URI present. Default controller set.
INFO - 2020-08-17 17:56:01 --> Router Class Initialized
INFO - 2020-08-17 17:56:01 --> Output Class Initialized
INFO - 2020-08-17 17:56:01 --> Security Class Initialized
DEBUG - 2020-08-17 17:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:56:01 --> Input Class Initialized
INFO - 2020-08-17 17:56:01 --> Language Class Initialized
INFO - 2020-08-17 17:56:01 --> Loader Class Initialized
INFO - 2020-08-17 17:56:01 --> Helper loaded: url_helper
INFO - 2020-08-17 17:56:01 --> Database Driver Class Initialized
INFO - 2020-08-17 17:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:56:01 --> Email Class Initialized
INFO - 2020-08-17 17:56:01 --> Controller Class Initialized
INFO - 2020-08-17 17:56:01 --> Model Class Initialized
INFO - 2020-08-17 17:56:01 --> Model Class Initialized
DEBUG - 2020-08-17 17:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:56:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:56:01 --> Final output sent to browser
DEBUG - 2020-08-17 17:56:01 --> Total execution time: 0.0215
INFO - 2020-08-17 17:56:23 --> Config Class Initialized
INFO - 2020-08-17 17:56:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:56:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:56:23 --> Utf8 Class Initialized
INFO - 2020-08-17 17:56:23 --> URI Class Initialized
DEBUG - 2020-08-17 17:56:23 --> No URI present. Default controller set.
INFO - 2020-08-17 17:56:23 --> Router Class Initialized
INFO - 2020-08-17 17:56:23 --> Output Class Initialized
INFO - 2020-08-17 17:56:23 --> Security Class Initialized
DEBUG - 2020-08-17 17:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:56:23 --> Input Class Initialized
INFO - 2020-08-17 17:56:23 --> Language Class Initialized
INFO - 2020-08-17 17:56:23 --> Loader Class Initialized
INFO - 2020-08-17 17:56:23 --> Helper loaded: url_helper
INFO - 2020-08-17 17:56:23 --> Database Driver Class Initialized
INFO - 2020-08-17 17:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:56:23 --> Email Class Initialized
INFO - 2020-08-17 17:56:23 --> Controller Class Initialized
INFO - 2020-08-17 17:56:23 --> Model Class Initialized
INFO - 2020-08-17 17:56:23 --> Model Class Initialized
DEBUG - 2020-08-17 17:56:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:56:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:56:23 --> Final output sent to browser
DEBUG - 2020-08-17 17:56:23 --> Total execution time: 0.0258
INFO - 2020-08-17 17:56:27 --> Config Class Initialized
INFO - 2020-08-17 17:56:27 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:56:27 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:56:27 --> Utf8 Class Initialized
INFO - 2020-08-17 17:56:27 --> URI Class Initialized
INFO - 2020-08-17 17:56:27 --> Router Class Initialized
INFO - 2020-08-17 17:56:27 --> Output Class Initialized
INFO - 2020-08-17 17:56:27 --> Config Class Initialized
INFO - 2020-08-17 17:56:27 --> Hooks Class Initialized
INFO - 2020-08-17 17:56:27 --> Security Class Initialized
DEBUG - 2020-08-17 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:56:27 --> Input Class Initialized
DEBUG - 2020-08-17 17:56:27 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:56:27 --> Utf8 Class Initialized
INFO - 2020-08-17 17:56:27 --> Language Class Initialized
INFO - 2020-08-17 17:56:27 --> URI Class Initialized
INFO - 2020-08-17 17:56:27 --> Router Class Initialized
INFO - 2020-08-17 17:56:27 --> Loader Class Initialized
INFO - 2020-08-17 17:56:27 --> Output Class Initialized
INFO - 2020-08-17 17:56:27 --> Security Class Initialized
INFO - 2020-08-17 17:56:27 --> Helper loaded: url_helper
DEBUG - 2020-08-17 17:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:56:27 --> Input Class Initialized
INFO - 2020-08-17 17:56:27 --> Language Class Initialized
INFO - 2020-08-17 17:56:27 --> Loader Class Initialized
INFO - 2020-08-17 17:56:27 --> Helper loaded: url_helper
INFO - 2020-08-17 17:56:27 --> Database Driver Class Initialized
INFO - 2020-08-17 17:56:27 --> Database Driver Class Initialized
INFO - 2020-08-17 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:56:27 --> Email Class Initialized
INFO - 2020-08-17 17:56:27 --> Controller Class Initialized
INFO - 2020-08-17 17:56:27 --> Model Class Initialized
INFO - 2020-08-17 17:56:27 --> Model Class Initialized
DEBUG - 2020-08-17 17:56:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:56:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:56:27 --> Email Class Initialized
INFO - 2020-08-17 17:56:27 --> Controller Class Initialized
INFO - 2020-08-17 17:56:27 --> Model Class Initialized
INFO - 2020-08-17 17:56:27 --> Model Class Initialized
DEBUG - 2020-08-17 17:56:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:56:28 --> Config Class Initialized
INFO - 2020-08-17 17:56:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:56:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:56:28 --> Utf8 Class Initialized
INFO - 2020-08-17 17:56:28 --> URI Class Initialized
DEBUG - 2020-08-17 17:56:28 --> No URI present. Default controller set.
INFO - 2020-08-17 17:56:28 --> Router Class Initialized
INFO - 2020-08-17 17:56:28 --> Output Class Initialized
INFO - 2020-08-17 17:56:28 --> Security Class Initialized
DEBUG - 2020-08-17 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:56:28 --> Input Class Initialized
INFO - 2020-08-17 17:56:28 --> Language Class Initialized
INFO - 2020-08-17 17:56:28 --> Loader Class Initialized
INFO - 2020-08-17 17:56:28 --> Helper loaded: url_helper
INFO - 2020-08-17 17:56:28 --> Database Driver Class Initialized
INFO - 2020-08-17 17:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:56:28 --> Email Class Initialized
INFO - 2020-08-17 17:56:28 --> Controller Class Initialized
INFO - 2020-08-17 17:56:28 --> Model Class Initialized
INFO - 2020-08-17 17:56:28 --> Model Class Initialized
DEBUG - 2020-08-17 17:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:56:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 17:56:28 --> Final output sent to browser
DEBUG - 2020-08-17 17:56:28 --> Total execution time: 0.0249
INFO - 2020-08-17 17:56:28 --> Config Class Initialized
INFO - 2020-08-17 17:56:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 17:56:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 17:56:28 --> Utf8 Class Initialized
INFO - 2020-08-17 17:56:28 --> URI Class Initialized
INFO - 2020-08-17 17:56:28 --> Router Class Initialized
INFO - 2020-08-17 17:56:28 --> Output Class Initialized
INFO - 2020-08-17 17:56:28 --> Security Class Initialized
DEBUG - 2020-08-17 17:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 17:56:28 --> Input Class Initialized
INFO - 2020-08-17 17:56:28 --> Language Class Initialized
INFO - 2020-08-17 17:56:28 --> Loader Class Initialized
INFO - 2020-08-17 17:56:28 --> Helper loaded: url_helper
INFO - 2020-08-17 17:56:28 --> Database Driver Class Initialized
INFO - 2020-08-17 17:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 17:56:28 --> Email Class Initialized
INFO - 2020-08-17 17:56:28 --> Controller Class Initialized
DEBUG - 2020-08-17 17:56:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 17:56:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 17:56:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 17:56:28 --> Final output sent to browser
DEBUG - 2020-08-17 17:56:28 --> Total execution time: 0.0254
INFO - 2020-08-17 18:00:28 --> Config Class Initialized
INFO - 2020-08-17 18:00:28 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:00:28 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:00:28 --> Utf8 Class Initialized
INFO - 2020-08-17 18:00:28 --> URI Class Initialized
INFO - 2020-08-17 18:00:28 --> Router Class Initialized
INFO - 2020-08-17 18:00:28 --> Output Class Initialized
INFO - 2020-08-17 18:00:28 --> Security Class Initialized
DEBUG - 2020-08-17 18:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:00:28 --> Input Class Initialized
INFO - 2020-08-17 18:00:28 --> Language Class Initialized
INFO - 2020-08-17 18:00:28 --> Loader Class Initialized
INFO - 2020-08-17 18:00:28 --> Helper loaded: url_helper
INFO - 2020-08-17 18:00:28 --> Database Driver Class Initialized
INFO - 2020-08-17 18:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:00:28 --> Email Class Initialized
INFO - 2020-08-17 18:00:28 --> Controller Class Initialized
DEBUG - 2020-08-17 18:00:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:00:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:00:28 --> Model Class Initialized
INFO - 2020-08-17 18:00:28 --> Model Class Initialized
INFO - 2020-08-17 18:00:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 18:00:28 --> Final output sent to browser
DEBUG - 2020-08-17 18:00:28 --> Total execution time: 0.0264
INFO - 2020-08-17 18:00:36 --> Config Class Initialized
INFO - 2020-08-17 18:00:36 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:00:36 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:00:36 --> Utf8 Class Initialized
INFO - 2020-08-17 18:00:36 --> URI Class Initialized
INFO - 2020-08-17 18:00:36 --> Router Class Initialized
INFO - 2020-08-17 18:00:36 --> Output Class Initialized
INFO - 2020-08-17 18:00:36 --> Security Class Initialized
DEBUG - 2020-08-17 18:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:00:36 --> Input Class Initialized
INFO - 2020-08-17 18:00:36 --> Language Class Initialized
INFO - 2020-08-17 18:00:36 --> Loader Class Initialized
INFO - 2020-08-17 18:00:36 --> Helper loaded: url_helper
INFO - 2020-08-17 18:00:36 --> Database Driver Class Initialized
INFO - 2020-08-17 18:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:00:36 --> Email Class Initialized
INFO - 2020-08-17 18:00:36 --> Controller Class Initialized
DEBUG - 2020-08-17 18:00:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:00:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:00:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:00:36 --> Final output sent to browser
DEBUG - 2020-08-17 18:00:36 --> Total execution time: 0.0224
INFO - 2020-08-17 18:08:38 --> Config Class Initialized
INFO - 2020-08-17 18:08:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:08:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:08:38 --> Utf8 Class Initialized
INFO - 2020-08-17 18:08:38 --> URI Class Initialized
INFO - 2020-08-17 18:08:38 --> Router Class Initialized
INFO - 2020-08-17 18:08:38 --> Output Class Initialized
INFO - 2020-08-17 18:08:38 --> Security Class Initialized
DEBUG - 2020-08-17 18:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:08:38 --> Input Class Initialized
INFO - 2020-08-17 18:08:38 --> Language Class Initialized
INFO - 2020-08-17 18:08:38 --> Loader Class Initialized
INFO - 2020-08-17 18:08:38 --> Helper loaded: url_helper
INFO - 2020-08-17 18:08:38 --> Database Driver Class Initialized
INFO - 2020-08-17 18:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:08:38 --> Email Class Initialized
INFO - 2020-08-17 18:08:38 --> Controller Class Initialized
DEBUG - 2020-08-17 18:08:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:08:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:08:38 --> Config Class Initialized
INFO - 2020-08-17 18:08:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:08:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:08:38 --> Utf8 Class Initialized
INFO - 2020-08-17 18:08:38 --> URI Class Initialized
DEBUG - 2020-08-17 18:08:38 --> No URI present. Default controller set.
INFO - 2020-08-17 18:08:38 --> Router Class Initialized
INFO - 2020-08-17 18:08:38 --> Output Class Initialized
INFO - 2020-08-17 18:08:38 --> Security Class Initialized
DEBUG - 2020-08-17 18:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:08:38 --> Input Class Initialized
INFO - 2020-08-17 18:08:38 --> Language Class Initialized
INFO - 2020-08-17 18:08:38 --> Loader Class Initialized
INFO - 2020-08-17 18:08:38 --> Helper loaded: url_helper
INFO - 2020-08-17 18:08:38 --> Database Driver Class Initialized
INFO - 2020-08-17 18:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:08:38 --> Email Class Initialized
INFO - 2020-08-17 18:08:38 --> Controller Class Initialized
INFO - 2020-08-17 18:08:38 --> Model Class Initialized
INFO - 2020-08-17 18:08:38 --> Model Class Initialized
DEBUG - 2020-08-17 18:08:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:08:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:08:38 --> Final output sent to browser
DEBUG - 2020-08-17 18:08:38 --> Total execution time: 0.0205
INFO - 2020-08-17 18:08:51 --> Config Class Initialized
INFO - 2020-08-17 18:08:51 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:08:51 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:08:51 --> Utf8 Class Initialized
INFO - 2020-08-17 18:08:51 --> URI Class Initialized
INFO - 2020-08-17 18:08:51 --> Router Class Initialized
INFO - 2020-08-17 18:08:51 --> Output Class Initialized
INFO - 2020-08-17 18:08:51 --> Security Class Initialized
DEBUG - 2020-08-17 18:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:08:51 --> Input Class Initialized
INFO - 2020-08-17 18:08:51 --> Language Class Initialized
INFO - 2020-08-17 18:08:51 --> Loader Class Initialized
INFO - 2020-08-17 18:08:51 --> Helper loaded: url_helper
INFO - 2020-08-17 18:08:51 --> Database Driver Class Initialized
INFO - 2020-08-17 18:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:08:51 --> Email Class Initialized
INFO - 2020-08-17 18:08:51 --> Controller Class Initialized
INFO - 2020-08-17 18:08:51 --> Model Class Initialized
INFO - 2020-08-17 18:08:51 --> Model Class Initialized
DEBUG - 2020-08-17 18:08:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:08:51 --> Config Class Initialized
INFO - 2020-08-17 18:08:51 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:08:51 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:08:51 --> Utf8 Class Initialized
INFO - 2020-08-17 18:08:51 --> URI Class Initialized
INFO - 2020-08-17 18:08:51 --> Router Class Initialized
INFO - 2020-08-17 18:08:51 --> Output Class Initialized
INFO - 2020-08-17 18:08:51 --> Security Class Initialized
DEBUG - 2020-08-17 18:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:08:51 --> Input Class Initialized
INFO - 2020-08-17 18:08:51 --> Language Class Initialized
INFO - 2020-08-17 18:08:51 --> Loader Class Initialized
INFO - 2020-08-17 18:08:51 --> Helper loaded: url_helper
INFO - 2020-08-17 18:08:51 --> Database Driver Class Initialized
INFO - 2020-08-17 18:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:08:51 --> Email Class Initialized
INFO - 2020-08-17 18:08:51 --> Controller Class Initialized
INFO - 2020-08-17 18:08:51 --> Model Class Initialized
INFO - 2020-08-17 18:08:51 --> Model Class Initialized
DEBUG - 2020-08-17 18:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:08:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:08:51 --> Model Class Initialized
INFO - 2020-08-17 18:08:51 --> Final output sent to browser
DEBUG - 2020-08-17 18:08:51 --> Total execution time: 0.0257
INFO - 2020-08-17 18:08:51 --> Config Class Initialized
INFO - 2020-08-17 18:08:51 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:08:51 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:08:51 --> Utf8 Class Initialized
INFO - 2020-08-17 18:08:51 --> URI Class Initialized
INFO - 2020-08-17 18:08:51 --> Router Class Initialized
INFO - 2020-08-17 18:08:51 --> Output Class Initialized
INFO - 2020-08-17 18:08:51 --> Security Class Initialized
DEBUG - 2020-08-17 18:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:08:51 --> Input Class Initialized
INFO - 2020-08-17 18:08:51 --> Language Class Initialized
INFO - 2020-08-17 18:08:51 --> Loader Class Initialized
INFO - 2020-08-17 18:08:51 --> Helper loaded: url_helper
INFO - 2020-08-17 18:08:51 --> Database Driver Class Initialized
INFO - 2020-08-17 18:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:08:51 --> Email Class Initialized
INFO - 2020-08-17 18:08:51 --> Controller Class Initialized
DEBUG - 2020-08-17 18:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:08:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:08:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:08:51 --> Final output sent to browser
DEBUG - 2020-08-17 18:08:51 --> Total execution time: 0.0232
INFO - 2020-08-17 18:09:01 --> Config Class Initialized
INFO - 2020-08-17 18:09:01 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:09:01 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:09:01 --> Utf8 Class Initialized
INFO - 2020-08-17 18:09:01 --> URI Class Initialized
INFO - 2020-08-17 18:09:01 --> Router Class Initialized
INFO - 2020-08-17 18:09:01 --> Output Class Initialized
INFO - 2020-08-17 18:09:01 --> Security Class Initialized
DEBUG - 2020-08-17 18:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:09:01 --> Input Class Initialized
INFO - 2020-08-17 18:09:01 --> Language Class Initialized
INFO - 2020-08-17 18:09:01 --> Loader Class Initialized
INFO - 2020-08-17 18:09:01 --> Helper loaded: url_helper
INFO - 2020-08-17 18:09:01 --> Database Driver Class Initialized
INFO - 2020-08-17 18:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:09:01 --> Email Class Initialized
INFO - 2020-08-17 18:09:01 --> Controller Class Initialized
DEBUG - 2020-08-17 18:09:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:09:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:09:01 --> Model Class Initialized
INFO - 2020-08-17 18:09:01 --> Model Class Initialized
INFO - 2020-08-17 18:09:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 18:09:01 --> Final output sent to browser
DEBUG - 2020-08-17 18:09:01 --> Total execution time: 0.0260
INFO - 2020-08-17 18:10:07 --> Config Class Initialized
INFO - 2020-08-17 18:10:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:10:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:10:07 --> Utf8 Class Initialized
INFO - 2020-08-17 18:10:07 --> URI Class Initialized
INFO - 2020-08-17 18:10:07 --> Router Class Initialized
INFO - 2020-08-17 18:10:07 --> Output Class Initialized
INFO - 2020-08-17 18:10:07 --> Security Class Initialized
DEBUG - 2020-08-17 18:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:10:07 --> Input Class Initialized
INFO - 2020-08-17 18:10:07 --> Language Class Initialized
INFO - 2020-08-17 18:10:07 --> Loader Class Initialized
INFO - 2020-08-17 18:10:07 --> Helper loaded: url_helper
INFO - 2020-08-17 18:10:07 --> Database Driver Class Initialized
INFO - 2020-08-17 18:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:10:07 --> Email Class Initialized
INFO - 2020-08-17 18:10:07 --> Controller Class Initialized
DEBUG - 2020-08-17 18:10:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:10:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:10:07 --> Model Class Initialized
INFO - 2020-08-17 18:10:07 --> Model Class Initialized
INFO - 2020-08-17 18:10:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 18:10:07 --> Final output sent to browser
DEBUG - 2020-08-17 18:10:07 --> Total execution time: 0.0262
INFO - 2020-08-17 18:10:43 --> Config Class Initialized
INFO - 2020-08-17 18:10:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:10:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:10:43 --> Utf8 Class Initialized
INFO - 2020-08-17 18:10:43 --> URI Class Initialized
DEBUG - 2020-08-17 18:10:43 --> No URI present. Default controller set.
INFO - 2020-08-17 18:10:43 --> Router Class Initialized
INFO - 2020-08-17 18:10:43 --> Output Class Initialized
INFO - 2020-08-17 18:10:43 --> Security Class Initialized
DEBUG - 2020-08-17 18:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:10:43 --> Input Class Initialized
INFO - 2020-08-17 18:10:43 --> Language Class Initialized
INFO - 2020-08-17 18:10:43 --> Loader Class Initialized
INFO - 2020-08-17 18:10:43 --> Helper loaded: url_helper
INFO - 2020-08-17 18:10:43 --> Database Driver Class Initialized
INFO - 2020-08-17 18:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:10:43 --> Email Class Initialized
INFO - 2020-08-17 18:10:43 --> Controller Class Initialized
INFO - 2020-08-17 18:10:43 --> Model Class Initialized
INFO - 2020-08-17 18:10:43 --> Model Class Initialized
DEBUG - 2020-08-17 18:10:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:10:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:10:43 --> Final output sent to browser
DEBUG - 2020-08-17 18:10:43 --> Total execution time: 0.0229
INFO - 2020-08-17 18:11:30 --> Config Class Initialized
INFO - 2020-08-17 18:11:30 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:11:30 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:11:30 --> Utf8 Class Initialized
INFO - 2020-08-17 18:11:30 --> URI Class Initialized
INFO - 2020-08-17 18:11:30 --> Router Class Initialized
INFO - 2020-08-17 18:11:30 --> Output Class Initialized
INFO - 2020-08-17 18:11:30 --> Security Class Initialized
DEBUG - 2020-08-17 18:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:11:30 --> Input Class Initialized
INFO - 2020-08-17 18:11:30 --> Language Class Initialized
INFO - 2020-08-17 18:11:30 --> Loader Class Initialized
INFO - 2020-08-17 18:11:30 --> Helper loaded: url_helper
INFO - 2020-08-17 18:11:30 --> Database Driver Class Initialized
INFO - 2020-08-17 18:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:11:30 --> Config Class Initialized
INFO - 2020-08-17 18:11:30 --> Hooks Class Initialized
INFO - 2020-08-17 18:11:30 --> Email Class Initialized
INFO - 2020-08-17 18:11:30 --> Controller Class Initialized
INFO - 2020-08-17 18:11:30 --> Model Class Initialized
DEBUG - 2020-08-17 18:11:30 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:11:30 --> Utf8 Class Initialized
INFO - 2020-08-17 18:11:30 --> Model Class Initialized
DEBUG - 2020-08-17 18:11:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:11:30 --> URI Class Initialized
INFO - 2020-08-17 18:11:30 --> Router Class Initialized
INFO - 2020-08-17 18:11:30 --> Output Class Initialized
INFO - 2020-08-17 18:11:30 --> Security Class Initialized
DEBUG - 2020-08-17 18:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:11:30 --> Input Class Initialized
INFO - 2020-08-17 18:11:30 --> Language Class Initialized
INFO - 2020-08-17 18:11:30 --> Loader Class Initialized
INFO - 2020-08-17 18:11:30 --> Helper loaded: url_helper
INFO - 2020-08-17 18:11:30 --> Database Driver Class Initialized
INFO - 2020-08-17 18:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:11:30 --> Email Class Initialized
INFO - 2020-08-17 18:11:30 --> Controller Class Initialized
INFO - 2020-08-17 18:11:30 --> Model Class Initialized
INFO - 2020-08-17 18:11:30 --> Model Class Initialized
DEBUG - 2020-08-17 18:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:11:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:11:30 --> Model Class Initialized
INFO - 2020-08-17 18:11:30 --> Final output sent to browser
DEBUG - 2020-08-17 18:11:30 --> Total execution time: 0.0244
INFO - 2020-08-17 18:11:31 --> Config Class Initialized
INFO - 2020-08-17 18:11:31 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:11:31 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:11:31 --> Utf8 Class Initialized
INFO - 2020-08-17 18:11:31 --> URI Class Initialized
INFO - 2020-08-17 18:11:31 --> Router Class Initialized
INFO - 2020-08-17 18:11:31 --> Output Class Initialized
INFO - 2020-08-17 18:11:31 --> Security Class Initialized
DEBUG - 2020-08-17 18:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:11:31 --> Input Class Initialized
INFO - 2020-08-17 18:11:31 --> Language Class Initialized
INFO - 2020-08-17 18:11:31 --> Loader Class Initialized
INFO - 2020-08-17 18:11:31 --> Helper loaded: url_helper
INFO - 2020-08-17 18:11:31 --> Database Driver Class Initialized
INFO - 2020-08-17 18:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:11:31 --> Email Class Initialized
INFO - 2020-08-17 18:11:31 --> Controller Class Initialized
DEBUG - 2020-08-17 18:11:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:11:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:11:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:11:31 --> Final output sent to browser
DEBUG - 2020-08-17 18:11:31 --> Total execution time: 0.0231
INFO - 2020-08-17 18:12:49 --> Config Class Initialized
INFO - 2020-08-17 18:12:49 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:12:49 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:12:49 --> Utf8 Class Initialized
INFO - 2020-08-17 18:12:49 --> URI Class Initialized
INFO - 2020-08-17 18:12:49 --> Router Class Initialized
INFO - 2020-08-17 18:12:49 --> Output Class Initialized
INFO - 2020-08-17 18:12:49 --> Security Class Initialized
DEBUG - 2020-08-17 18:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:12:49 --> Input Class Initialized
INFO - 2020-08-17 18:12:49 --> Language Class Initialized
INFO - 2020-08-17 18:12:49 --> Loader Class Initialized
INFO - 2020-08-17 18:12:49 --> Helper loaded: url_helper
INFO - 2020-08-17 18:12:49 --> Database Driver Class Initialized
INFO - 2020-08-17 18:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:12:49 --> Email Class Initialized
INFO - 2020-08-17 18:12:49 --> Controller Class Initialized
DEBUG - 2020-08-17 18:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:12:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:12:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:12:49 --> Final output sent to browser
DEBUG - 2020-08-17 18:12:49 --> Total execution time: 0.0219
INFO - 2020-08-17 18:12:51 --> Config Class Initialized
INFO - 2020-08-17 18:12:51 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:12:51 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:12:51 --> Utf8 Class Initialized
INFO - 2020-08-17 18:12:51 --> URI Class Initialized
INFO - 2020-08-17 18:12:51 --> Router Class Initialized
INFO - 2020-08-17 18:12:51 --> Output Class Initialized
INFO - 2020-08-17 18:12:51 --> Security Class Initialized
DEBUG - 2020-08-17 18:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:12:51 --> Input Class Initialized
INFO - 2020-08-17 18:12:51 --> Language Class Initialized
INFO - 2020-08-17 18:12:51 --> Loader Class Initialized
INFO - 2020-08-17 18:12:51 --> Helper loaded: url_helper
INFO - 2020-08-17 18:12:51 --> Database Driver Class Initialized
INFO - 2020-08-17 18:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:12:51 --> Email Class Initialized
INFO - 2020-08-17 18:12:51 --> Controller Class Initialized
DEBUG - 2020-08-17 18:12:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:12:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:12:51 --> Model Class Initialized
INFO - 2020-08-17 18:12:51 --> Model Class Initialized
INFO - 2020-08-17 18:12:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 18:12:51 --> Final output sent to browser
DEBUG - 2020-08-17 18:12:51 --> Total execution time: 0.0291
INFO - 2020-08-17 18:12:57 --> Config Class Initialized
INFO - 2020-08-17 18:12:57 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:12:57 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:12:57 --> Utf8 Class Initialized
INFO - 2020-08-17 18:12:57 --> URI Class Initialized
INFO - 2020-08-17 18:12:57 --> Router Class Initialized
INFO - 2020-08-17 18:12:57 --> Output Class Initialized
INFO - 2020-08-17 18:12:57 --> Security Class Initialized
DEBUG - 2020-08-17 18:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:12:57 --> Input Class Initialized
INFO - 2020-08-17 18:12:57 --> Language Class Initialized
INFO - 2020-08-17 18:12:57 --> Loader Class Initialized
INFO - 2020-08-17 18:12:57 --> Helper loaded: url_helper
INFO - 2020-08-17 18:12:57 --> Database Driver Class Initialized
INFO - 2020-08-17 18:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:12:57 --> Email Class Initialized
INFO - 2020-08-17 18:12:57 --> Controller Class Initialized
DEBUG - 2020-08-17 18:12:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:12:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:12:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:12:57 --> Final output sent to browser
DEBUG - 2020-08-17 18:12:57 --> Total execution time: 0.0213
INFO - 2020-08-17 18:13:03 --> Config Class Initialized
INFO - 2020-08-17 18:13:03 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:13:03 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:13:03 --> Utf8 Class Initialized
INFO - 2020-08-17 18:13:03 --> URI Class Initialized
INFO - 2020-08-17 18:13:03 --> Router Class Initialized
INFO - 2020-08-17 18:13:03 --> Output Class Initialized
INFO - 2020-08-17 18:13:03 --> Security Class Initialized
DEBUG - 2020-08-17 18:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:13:03 --> Input Class Initialized
INFO - 2020-08-17 18:13:03 --> Language Class Initialized
INFO - 2020-08-17 18:13:03 --> Loader Class Initialized
INFO - 2020-08-17 18:13:03 --> Helper loaded: url_helper
INFO - 2020-08-17 18:13:03 --> Database Driver Class Initialized
INFO - 2020-08-17 18:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:13:03 --> Email Class Initialized
INFO - 2020-08-17 18:13:03 --> Controller Class Initialized
DEBUG - 2020-08-17 18:13:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:13:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:13:03 --> Model Class Initialized
INFO - 2020-08-17 18:13:03 --> Model Class Initialized
INFO - 2020-08-17 18:13:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 18:13:03 --> Final output sent to browser
DEBUG - 2020-08-17 18:13:03 --> Total execution time: 0.0220
INFO - 2020-08-17 18:13:05 --> Config Class Initialized
INFO - 2020-08-17 18:13:05 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:13:05 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:13:05 --> Utf8 Class Initialized
INFO - 2020-08-17 18:13:05 --> URI Class Initialized
INFO - 2020-08-17 18:13:05 --> Router Class Initialized
INFO - 2020-08-17 18:13:05 --> Output Class Initialized
INFO - 2020-08-17 18:13:05 --> Security Class Initialized
DEBUG - 2020-08-17 18:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:13:05 --> Input Class Initialized
INFO - 2020-08-17 18:13:05 --> Language Class Initialized
INFO - 2020-08-17 18:13:05 --> Loader Class Initialized
INFO - 2020-08-17 18:13:05 --> Helper loaded: url_helper
INFO - 2020-08-17 18:13:05 --> Database Driver Class Initialized
INFO - 2020-08-17 18:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:13:05 --> Email Class Initialized
INFO - 2020-08-17 18:13:05 --> Controller Class Initialized
DEBUG - 2020-08-17 18:13:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:13:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:13:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:13:05 --> Final output sent to browser
DEBUG - 2020-08-17 18:13:05 --> Total execution time: 0.0222
INFO - 2020-08-17 18:13:33 --> Config Class Initialized
INFO - 2020-08-17 18:13:33 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:13:33 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:13:33 --> Utf8 Class Initialized
INFO - 2020-08-17 18:13:33 --> URI Class Initialized
INFO - 2020-08-17 18:13:33 --> Router Class Initialized
INFO - 2020-08-17 18:13:33 --> Output Class Initialized
INFO - 2020-08-17 18:13:33 --> Security Class Initialized
DEBUG - 2020-08-17 18:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:13:33 --> Input Class Initialized
INFO - 2020-08-17 18:13:33 --> Language Class Initialized
INFO - 2020-08-17 18:13:33 --> Loader Class Initialized
INFO - 2020-08-17 18:13:33 --> Helper loaded: url_helper
INFO - 2020-08-17 18:13:33 --> Database Driver Class Initialized
INFO - 2020-08-17 18:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:13:33 --> Email Class Initialized
INFO - 2020-08-17 18:13:33 --> Controller Class Initialized
DEBUG - 2020-08-17 18:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:13:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:13:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:13:33 --> Final output sent to browser
DEBUG - 2020-08-17 18:13:33 --> Total execution time: 0.0220
INFO - 2020-08-17 18:13:38 --> Config Class Initialized
INFO - 2020-08-17 18:13:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:13:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:13:38 --> Utf8 Class Initialized
INFO - 2020-08-17 18:13:38 --> URI Class Initialized
INFO - 2020-08-17 18:13:38 --> Router Class Initialized
INFO - 2020-08-17 18:13:38 --> Output Class Initialized
INFO - 2020-08-17 18:13:38 --> Security Class Initialized
DEBUG - 2020-08-17 18:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:13:38 --> Input Class Initialized
INFO - 2020-08-17 18:13:38 --> Language Class Initialized
INFO - 2020-08-17 18:13:38 --> Loader Class Initialized
INFO - 2020-08-17 18:13:38 --> Helper loaded: url_helper
INFO - 2020-08-17 18:13:38 --> Database Driver Class Initialized
INFO - 2020-08-17 18:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:13:38 --> Email Class Initialized
INFO - 2020-08-17 18:13:38 --> Controller Class Initialized
DEBUG - 2020-08-17 18:13:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:13:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:13:38 --> Model Class Initialized
INFO - 2020-08-17 18:13:38 --> Model Class Initialized
INFO - 2020-08-17 18:13:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:13:38 --> Final output sent to browser
DEBUG - 2020-08-17 18:13:38 --> Total execution time: 0.0382
INFO - 2020-08-17 18:14:43 --> Config Class Initialized
INFO - 2020-08-17 18:14:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:14:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:14:43 --> Utf8 Class Initialized
INFO - 2020-08-17 18:14:43 --> URI Class Initialized
INFO - 2020-08-17 18:14:43 --> Router Class Initialized
INFO - 2020-08-17 18:14:43 --> Output Class Initialized
INFO - 2020-08-17 18:14:43 --> Security Class Initialized
DEBUG - 2020-08-17 18:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:14:43 --> Input Class Initialized
INFO - 2020-08-17 18:14:43 --> Language Class Initialized
INFO - 2020-08-17 18:14:43 --> Loader Class Initialized
INFO - 2020-08-17 18:14:43 --> Helper loaded: url_helper
INFO - 2020-08-17 18:14:43 --> Database Driver Class Initialized
INFO - 2020-08-17 18:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:14:43 --> Email Class Initialized
INFO - 2020-08-17 18:14:43 --> Controller Class Initialized
DEBUG - 2020-08-17 18:14:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:14:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:14:43 --> Model Class Initialized
INFO - 2020-08-17 18:14:43 --> Model Class Initialized
INFO - 2020-08-17 18:14:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:14:43 --> Final output sent to browser
DEBUG - 2020-08-17 18:14:43 --> Total execution time: 0.0262
INFO - 2020-08-17 18:14:46 --> Config Class Initialized
INFO - 2020-08-17 18:14:46 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:14:46 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:14:46 --> Utf8 Class Initialized
INFO - 2020-08-17 18:14:46 --> URI Class Initialized
INFO - 2020-08-17 18:14:46 --> Router Class Initialized
INFO - 2020-08-17 18:14:46 --> Output Class Initialized
INFO - 2020-08-17 18:14:46 --> Security Class Initialized
DEBUG - 2020-08-17 18:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:14:46 --> Input Class Initialized
INFO - 2020-08-17 18:14:46 --> Language Class Initialized
INFO - 2020-08-17 18:14:46 --> Loader Class Initialized
INFO - 2020-08-17 18:14:46 --> Helper loaded: url_helper
INFO - 2020-08-17 18:14:46 --> Database Driver Class Initialized
INFO - 2020-08-17 18:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:14:46 --> Email Class Initialized
INFO - 2020-08-17 18:14:46 --> Controller Class Initialized
DEBUG - 2020-08-17 18:14:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:14:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:14:46 --> Model Class Initialized
INFO - 2020-08-17 18:14:46 --> Model Class Initialized
INFO - 2020-08-17 18:14:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-17 18:14:46 --> Final output sent to browser
DEBUG - 2020-08-17 18:14:46 --> Total execution time: 0.0263
INFO - 2020-08-17 18:15:39 --> Config Class Initialized
INFO - 2020-08-17 18:15:39 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:15:39 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:15:39 --> Utf8 Class Initialized
INFO - 2020-08-17 18:15:39 --> URI Class Initialized
INFO - 2020-08-17 18:15:39 --> Router Class Initialized
INFO - 2020-08-17 18:15:39 --> Output Class Initialized
INFO - 2020-08-17 18:15:39 --> Security Class Initialized
DEBUG - 2020-08-17 18:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:15:39 --> Input Class Initialized
INFO - 2020-08-17 18:15:39 --> Language Class Initialized
INFO - 2020-08-17 18:15:39 --> Loader Class Initialized
INFO - 2020-08-17 18:15:39 --> Helper loaded: url_helper
INFO - 2020-08-17 18:15:39 --> Database Driver Class Initialized
INFO - 2020-08-17 18:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:15:39 --> Email Class Initialized
INFO - 2020-08-17 18:15:39 --> Controller Class Initialized
DEBUG - 2020-08-17 18:15:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:15:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:15:39 --> Model Class Initialized
INFO - 2020-08-17 18:15:39 --> Model Class Initialized
INFO - 2020-08-17 18:15:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-17 18:15:39 --> Final output sent to browser
DEBUG - 2020-08-17 18:15:39 --> Total execution time: 0.0265
INFO - 2020-08-17 18:15:41 --> Config Class Initialized
INFO - 2020-08-17 18:15:41 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:15:41 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:15:41 --> Utf8 Class Initialized
INFO - 2020-08-17 18:15:41 --> URI Class Initialized
INFO - 2020-08-17 18:15:41 --> Router Class Initialized
INFO - 2020-08-17 18:15:41 --> Output Class Initialized
INFO - 2020-08-17 18:15:41 --> Security Class Initialized
DEBUG - 2020-08-17 18:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:15:41 --> Input Class Initialized
INFO - 2020-08-17 18:15:41 --> Language Class Initialized
INFO - 2020-08-17 18:15:41 --> Loader Class Initialized
INFO - 2020-08-17 18:15:41 --> Helper loaded: url_helper
INFO - 2020-08-17 18:15:41 --> Database Driver Class Initialized
INFO - 2020-08-17 18:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:15:41 --> Email Class Initialized
INFO - 2020-08-17 18:15:41 --> Controller Class Initialized
DEBUG - 2020-08-17 18:15:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:15:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:15:41 --> Model Class Initialized
INFO - 2020-08-17 18:15:41 --> Model Class Initialized
INFO - 2020-08-17 18:15:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 18:15:41 --> Final output sent to browser
DEBUG - 2020-08-17 18:15:41 --> Total execution time: 0.0254
INFO - 2020-08-17 18:15:48 --> Config Class Initialized
INFO - 2020-08-17 18:15:48 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:15:48 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:15:48 --> Utf8 Class Initialized
INFO - 2020-08-17 18:15:48 --> URI Class Initialized
INFO - 2020-08-17 18:15:48 --> Router Class Initialized
INFO - 2020-08-17 18:15:48 --> Output Class Initialized
INFO - 2020-08-17 18:15:48 --> Security Class Initialized
DEBUG - 2020-08-17 18:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:15:48 --> Input Class Initialized
INFO - 2020-08-17 18:15:48 --> Language Class Initialized
INFO - 2020-08-17 18:15:48 --> Loader Class Initialized
INFO - 2020-08-17 18:15:48 --> Helper loaded: url_helper
INFO - 2020-08-17 18:15:48 --> Database Driver Class Initialized
INFO - 2020-08-17 18:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:15:48 --> Email Class Initialized
INFO - 2020-08-17 18:15:48 --> Controller Class Initialized
DEBUG - 2020-08-17 18:15:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:15:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:15:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:15:48 --> Final output sent to browser
DEBUG - 2020-08-17 18:15:48 --> Total execution time: 0.0199
INFO - 2020-08-17 18:15:53 --> Config Class Initialized
INFO - 2020-08-17 18:15:53 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:15:53 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:15:53 --> Utf8 Class Initialized
INFO - 2020-08-17 18:15:53 --> URI Class Initialized
INFO - 2020-08-17 18:15:53 --> Router Class Initialized
INFO - 2020-08-17 18:15:53 --> Output Class Initialized
INFO - 2020-08-17 18:15:53 --> Security Class Initialized
DEBUG - 2020-08-17 18:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:15:53 --> Input Class Initialized
INFO - 2020-08-17 18:15:53 --> Language Class Initialized
INFO - 2020-08-17 18:15:53 --> Loader Class Initialized
INFO - 2020-08-17 18:15:53 --> Helper loaded: url_helper
INFO - 2020-08-17 18:15:53 --> Database Driver Class Initialized
INFO - 2020-08-17 18:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:15:53 --> Email Class Initialized
INFO - 2020-08-17 18:15:53 --> Controller Class Initialized
DEBUG - 2020-08-17 18:15:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:15:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:15:53 --> Model Class Initialized
INFO - 2020-08-17 18:15:53 --> Model Class Initialized
INFO - 2020-08-17 18:15:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:15:53 --> Final output sent to browser
DEBUG - 2020-08-17 18:15:53 --> Total execution time: 0.0219
INFO - 2020-08-17 18:15:58 --> Config Class Initialized
INFO - 2020-08-17 18:15:58 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:15:58 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:15:58 --> Utf8 Class Initialized
INFO - 2020-08-17 18:15:58 --> URI Class Initialized
INFO - 2020-08-17 18:15:58 --> Router Class Initialized
INFO - 2020-08-17 18:15:58 --> Output Class Initialized
INFO - 2020-08-17 18:15:58 --> Security Class Initialized
DEBUG - 2020-08-17 18:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:15:58 --> Input Class Initialized
INFO - 2020-08-17 18:15:58 --> Language Class Initialized
INFO - 2020-08-17 18:15:58 --> Loader Class Initialized
INFO - 2020-08-17 18:15:58 --> Helper loaded: url_helper
INFO - 2020-08-17 18:15:58 --> Database Driver Class Initialized
INFO - 2020-08-17 18:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:15:58 --> Email Class Initialized
INFO - 2020-08-17 18:15:58 --> Controller Class Initialized
DEBUG - 2020-08-17 18:15:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:15:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:15:58 --> Model Class Initialized
INFO - 2020-08-17 18:15:58 --> Model Class Initialized
INFO - 2020-08-17 18:15:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-17 18:15:58 --> Final output sent to browser
DEBUG - 2020-08-17 18:15:58 --> Total execution time: 0.0304
INFO - 2020-08-17 18:17:03 --> Config Class Initialized
INFO - 2020-08-17 18:17:03 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:17:03 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:17:03 --> Utf8 Class Initialized
INFO - 2020-08-17 18:17:03 --> URI Class Initialized
INFO - 2020-08-17 18:17:03 --> Router Class Initialized
INFO - 2020-08-17 18:17:03 --> Output Class Initialized
INFO - 2020-08-17 18:17:03 --> Security Class Initialized
DEBUG - 2020-08-17 18:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:17:03 --> Input Class Initialized
INFO - 2020-08-17 18:17:03 --> Language Class Initialized
INFO - 2020-08-17 18:17:03 --> Loader Class Initialized
INFO - 2020-08-17 18:17:03 --> Helper loaded: url_helper
INFO - 2020-08-17 18:17:03 --> Database Driver Class Initialized
INFO - 2020-08-17 18:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:17:03 --> Email Class Initialized
INFO - 2020-08-17 18:17:03 --> Controller Class Initialized
DEBUG - 2020-08-17 18:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:17:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:17:03 --> Model Class Initialized
INFO - 2020-08-17 18:17:03 --> Model Class Initialized
INFO - 2020-08-17 18:17:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-17 18:17:03 --> Final output sent to browser
DEBUG - 2020-08-17 18:17:03 --> Total execution time: 0.0223
INFO - 2020-08-17 18:17:06 --> Config Class Initialized
INFO - 2020-08-17 18:17:06 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:17:06 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:17:06 --> Utf8 Class Initialized
INFO - 2020-08-17 18:17:06 --> URI Class Initialized
INFO - 2020-08-17 18:17:06 --> Router Class Initialized
INFO - 2020-08-17 18:17:06 --> Output Class Initialized
INFO - 2020-08-17 18:17:06 --> Security Class Initialized
DEBUG - 2020-08-17 18:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:17:06 --> Input Class Initialized
INFO - 2020-08-17 18:17:06 --> Language Class Initialized
INFO - 2020-08-17 18:17:06 --> Loader Class Initialized
INFO - 2020-08-17 18:17:06 --> Helper loaded: url_helper
INFO - 2020-08-17 18:17:06 --> Database Driver Class Initialized
INFO - 2020-08-17 18:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:17:06 --> Email Class Initialized
INFO - 2020-08-17 18:17:06 --> Controller Class Initialized
DEBUG - 2020-08-17 18:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:17:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:17:06 --> Model Class Initialized
INFO - 2020-08-17 18:17:06 --> Model Class Initialized
INFO - 2020-08-17 18:17:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:17:06 --> Final output sent to browser
DEBUG - 2020-08-17 18:17:06 --> Total execution time: 0.0234
INFO - 2020-08-17 18:17:09 --> Config Class Initialized
INFO - 2020-08-17 18:17:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:17:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:17:09 --> Utf8 Class Initialized
INFO - 2020-08-17 18:17:09 --> URI Class Initialized
INFO - 2020-08-17 18:17:09 --> Router Class Initialized
INFO - 2020-08-17 18:17:09 --> Output Class Initialized
INFO - 2020-08-17 18:17:09 --> Security Class Initialized
DEBUG - 2020-08-17 18:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:17:09 --> Input Class Initialized
INFO - 2020-08-17 18:17:09 --> Language Class Initialized
INFO - 2020-08-17 18:17:09 --> Loader Class Initialized
INFO - 2020-08-17 18:17:09 --> Helper loaded: url_helper
INFO - 2020-08-17 18:17:09 --> Database Driver Class Initialized
INFO - 2020-08-17 18:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:17:09 --> Email Class Initialized
INFO - 2020-08-17 18:17:09 --> Controller Class Initialized
DEBUG - 2020-08-17 18:17:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:17:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:17:09 --> Model Class Initialized
INFO - 2020-08-17 18:17:09 --> Model Class Initialized
INFO - 2020-08-17 18:17:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-17 18:17:09 --> Final output sent to browser
DEBUG - 2020-08-17 18:17:09 --> Total execution time: 0.0230
INFO - 2020-08-17 18:18:23 --> Config Class Initialized
INFO - 2020-08-17 18:18:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:18:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:18:23 --> Utf8 Class Initialized
INFO - 2020-08-17 18:18:23 --> URI Class Initialized
INFO - 2020-08-17 18:18:23 --> Router Class Initialized
INFO - 2020-08-17 18:18:23 --> Output Class Initialized
INFO - 2020-08-17 18:18:23 --> Security Class Initialized
DEBUG - 2020-08-17 18:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:18:23 --> Input Class Initialized
INFO - 2020-08-17 18:18:23 --> Language Class Initialized
INFO - 2020-08-17 18:18:23 --> Loader Class Initialized
INFO - 2020-08-17 18:18:23 --> Helper loaded: url_helper
INFO - 2020-08-17 18:18:23 --> Database Driver Class Initialized
INFO - 2020-08-17 18:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:18:23 --> Email Class Initialized
INFO - 2020-08-17 18:18:23 --> Controller Class Initialized
DEBUG - 2020-08-17 18:18:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:18:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:18:23 --> Model Class Initialized
INFO - 2020-08-17 18:18:23 --> Model Class Initialized
INFO - 2020-08-17 18:18:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-17 18:18:23 --> Final output sent to browser
DEBUG - 2020-08-17 18:18:23 --> Total execution time: 0.0230
INFO - 2020-08-17 18:18:31 --> Config Class Initialized
INFO - 2020-08-17 18:18:31 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:18:31 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:18:31 --> Utf8 Class Initialized
INFO - 2020-08-17 18:18:31 --> URI Class Initialized
INFO - 2020-08-17 18:18:31 --> Router Class Initialized
INFO - 2020-08-17 18:18:31 --> Output Class Initialized
INFO - 2020-08-17 18:18:31 --> Security Class Initialized
DEBUG - 2020-08-17 18:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:18:31 --> Input Class Initialized
INFO - 2020-08-17 18:18:31 --> Language Class Initialized
INFO - 2020-08-17 18:18:31 --> Loader Class Initialized
INFO - 2020-08-17 18:18:31 --> Helper loaded: url_helper
INFO - 2020-08-17 18:18:31 --> Database Driver Class Initialized
INFO - 2020-08-17 18:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:18:31 --> Email Class Initialized
INFO - 2020-08-17 18:18:31 --> Controller Class Initialized
DEBUG - 2020-08-17 18:18:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:18:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:18:31 --> Model Class Initialized
INFO - 2020-08-17 18:18:31 --> Model Class Initialized
INFO - 2020-08-17 18:18:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:18:31 --> Final output sent to browser
DEBUG - 2020-08-17 18:18:31 --> Total execution time: 0.0266
INFO - 2020-08-17 18:19:16 --> Config Class Initialized
INFO - 2020-08-17 18:19:16 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:19:16 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:19:16 --> Utf8 Class Initialized
INFO - 2020-08-17 18:19:16 --> URI Class Initialized
DEBUG - 2020-08-17 18:19:16 --> No URI present. Default controller set.
INFO - 2020-08-17 18:19:16 --> Router Class Initialized
INFO - 2020-08-17 18:19:16 --> Output Class Initialized
INFO - 2020-08-17 18:19:16 --> Security Class Initialized
DEBUG - 2020-08-17 18:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:19:16 --> Input Class Initialized
INFO - 2020-08-17 18:19:16 --> Language Class Initialized
INFO - 2020-08-17 18:19:16 --> Loader Class Initialized
INFO - 2020-08-17 18:19:16 --> Helper loaded: url_helper
INFO - 2020-08-17 18:19:16 --> Database Driver Class Initialized
INFO - 2020-08-17 18:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:19:16 --> Email Class Initialized
INFO - 2020-08-17 18:19:16 --> Controller Class Initialized
INFO - 2020-08-17 18:19:16 --> Model Class Initialized
INFO - 2020-08-17 18:19:16 --> Model Class Initialized
DEBUG - 2020-08-17 18:19:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:19:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:19:16 --> Final output sent to browser
DEBUG - 2020-08-17 18:19:16 --> Total execution time: 0.0207
INFO - 2020-08-17 18:19:20 --> Config Class Initialized
INFO - 2020-08-17 18:19:20 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:19:20 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:19:20 --> Utf8 Class Initialized
INFO - 2020-08-17 18:19:20 --> URI Class Initialized
INFO - 2020-08-17 18:19:20 --> Router Class Initialized
INFO - 2020-08-17 18:19:20 --> Output Class Initialized
INFO - 2020-08-17 18:19:20 --> Security Class Initialized
DEBUG - 2020-08-17 18:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:19:20 --> Input Class Initialized
INFO - 2020-08-17 18:19:20 --> Language Class Initialized
INFO - 2020-08-17 18:19:20 --> Loader Class Initialized
INFO - 2020-08-17 18:19:20 --> Helper loaded: url_helper
INFO - 2020-08-17 18:19:20 --> Database Driver Class Initialized
INFO - 2020-08-17 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:19:20 --> Email Class Initialized
INFO - 2020-08-17 18:19:20 --> Controller Class Initialized
INFO - 2020-08-17 18:19:20 --> Model Class Initialized
INFO - 2020-08-17 18:19:20 --> Model Class Initialized
DEBUG - 2020-08-17 18:19:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:19:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:19:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-17 18:19:20 --> Final output sent to browser
DEBUG - 2020-08-17 18:19:20 --> Total execution time: 0.0297
INFO - 2020-08-17 18:20:19 --> Config Class Initialized
INFO - 2020-08-17 18:20:19 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:20:19 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:20:19 --> Utf8 Class Initialized
INFO - 2020-08-17 18:20:19 --> URI Class Initialized
INFO - 2020-08-17 18:20:19 --> Router Class Initialized
INFO - 2020-08-17 18:20:19 --> Output Class Initialized
INFO - 2020-08-17 18:20:19 --> Security Class Initialized
DEBUG - 2020-08-17 18:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:20:19 --> Input Class Initialized
INFO - 2020-08-17 18:20:19 --> Language Class Initialized
INFO - 2020-08-17 18:20:19 --> Loader Class Initialized
INFO - 2020-08-17 18:20:19 --> Helper loaded: url_helper
INFO - 2020-08-17 18:20:19 --> Database Driver Class Initialized
INFO - 2020-08-17 18:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:20:19 --> Email Class Initialized
INFO - 2020-08-17 18:20:19 --> Controller Class Initialized
INFO - 2020-08-17 18:20:19 --> Model Class Initialized
INFO - 2020-08-17 18:20:19 --> Model Class Initialized
DEBUG - 2020-08-17 18:20:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:20:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:20:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-17 18:20:19 --> Final output sent to browser
DEBUG - 2020-08-17 18:20:19 --> Total execution time: 0.0232
INFO - 2020-08-17 18:20:24 --> Config Class Initialized
INFO - 2020-08-17 18:20:24 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:20:24 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:20:24 --> Utf8 Class Initialized
INFO - 2020-08-17 18:20:24 --> URI Class Initialized
INFO - 2020-08-17 18:20:24 --> Router Class Initialized
INFO - 2020-08-17 18:20:24 --> Output Class Initialized
INFO - 2020-08-17 18:20:24 --> Security Class Initialized
DEBUG - 2020-08-17 18:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:20:24 --> Input Class Initialized
INFO - 2020-08-17 18:20:24 --> Language Class Initialized
INFO - 2020-08-17 18:20:24 --> Loader Class Initialized
INFO - 2020-08-17 18:20:24 --> Helper loaded: url_helper
INFO - 2020-08-17 18:20:24 --> Database Driver Class Initialized
INFO - 2020-08-17 18:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:20:24 --> Email Class Initialized
INFO - 2020-08-17 18:20:24 --> Controller Class Initialized
INFO - 2020-08-17 18:20:24 --> Model Class Initialized
INFO - 2020-08-17 18:20:24 --> Model Class Initialized
DEBUG - 2020-08-17 18:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:20:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:20:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-17 18:20:24 --> Final output sent to browser
DEBUG - 2020-08-17 18:20:24 --> Total execution time: 0.0195
INFO - 2020-08-17 18:21:13 --> Config Class Initialized
INFO - 2020-08-17 18:21:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:13 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:13 --> URI Class Initialized
INFO - 2020-08-17 18:21:13 --> Router Class Initialized
INFO - 2020-08-17 18:21:13 --> Output Class Initialized
INFO - 2020-08-17 18:21:13 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:13 --> Input Class Initialized
INFO - 2020-08-17 18:21:13 --> Language Class Initialized
INFO - 2020-08-17 18:21:13 --> Loader Class Initialized
INFO - 2020-08-17 18:21:13 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:13 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:13 --> Email Class Initialized
INFO - 2020-08-17 18:21:13 --> Controller Class Initialized
INFO - 2020-08-17 18:21:13 --> Model Class Initialized
INFO - 2020-08-17 18:21:13 --> Model Class Initialized
DEBUG - 2020-08-17 18:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:21:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-17 18:21:13 --> Final output sent to browser
DEBUG - 2020-08-17 18:21:13 --> Total execution time: 0.3136
INFO - 2020-08-17 18:21:16 --> Config Class Initialized
INFO - 2020-08-17 18:21:16 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:16 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:16 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:16 --> URI Class Initialized
DEBUG - 2020-08-17 18:21:16 --> No URI present. Default controller set.
INFO - 2020-08-17 18:21:16 --> Router Class Initialized
INFO - 2020-08-17 18:21:16 --> Output Class Initialized
INFO - 2020-08-17 18:21:16 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:16 --> Input Class Initialized
INFO - 2020-08-17 18:21:16 --> Language Class Initialized
INFO - 2020-08-17 18:21:16 --> Loader Class Initialized
INFO - 2020-08-17 18:21:16 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:16 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:16 --> Email Class Initialized
INFO - 2020-08-17 18:21:16 --> Controller Class Initialized
INFO - 2020-08-17 18:21:16 --> Model Class Initialized
INFO - 2020-08-17 18:21:16 --> Model Class Initialized
DEBUG - 2020-08-17 18:21:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:21:16 --> Final output sent to browser
DEBUG - 2020-08-17 18:21:16 --> Total execution time: 0.0214
INFO - 2020-08-17 18:21:23 --> Config Class Initialized
INFO - 2020-08-17 18:21:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:23 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:23 --> URI Class Initialized
INFO - 2020-08-17 18:21:23 --> Router Class Initialized
INFO - 2020-08-17 18:21:23 --> Output Class Initialized
INFO - 2020-08-17 18:21:23 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:23 --> Input Class Initialized
INFO - 2020-08-17 18:21:23 --> Language Class Initialized
INFO - 2020-08-17 18:21:23 --> Loader Class Initialized
INFO - 2020-08-17 18:21:23 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:23 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:23 --> Config Class Initialized
INFO - 2020-08-17 18:21:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:23 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:23 --> URI Class Initialized
INFO - 2020-08-17 18:21:23 --> Router Class Initialized
INFO - 2020-08-17 18:21:23 --> Output Class Initialized
INFO - 2020-08-17 18:21:23 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:23 --> Input Class Initialized
INFO - 2020-08-17 18:21:23 --> Language Class Initialized
INFO - 2020-08-17 18:21:23 --> Loader Class Initialized
INFO - 2020-08-17 18:21:23 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:23 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:23 --> Email Class Initialized
INFO - 2020-08-17 18:21:23 --> Controller Class Initialized
INFO - 2020-08-17 18:21:23 --> Model Class Initialized
INFO - 2020-08-17 18:21:23 --> Model Class Initialized
DEBUG - 2020-08-17 18:21:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:23 --> Email Class Initialized
INFO - 2020-08-17 18:21:23 --> Controller Class Initialized
INFO - 2020-08-17 18:21:23 --> Model Class Initialized
INFO - 2020-08-17 18:21:23 --> Model Class Initialized
DEBUG - 2020-08-17 18:21:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:21:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:23 --> Model Class Initialized
INFO - 2020-08-17 18:21:23 --> Final output sent to browser
DEBUG - 2020-08-17 18:21:23 --> Total execution time: 0.1528
INFO - 2020-08-17 18:21:23 --> Config Class Initialized
INFO - 2020-08-17 18:21:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:23 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:23 --> URI Class Initialized
INFO - 2020-08-17 18:21:23 --> Router Class Initialized
INFO - 2020-08-17 18:21:23 --> Output Class Initialized
INFO - 2020-08-17 18:21:23 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:23 --> Input Class Initialized
INFO - 2020-08-17 18:21:23 --> Language Class Initialized
INFO - 2020-08-17 18:21:23 --> Loader Class Initialized
INFO - 2020-08-17 18:21:23 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:23 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:23 --> Email Class Initialized
INFO - 2020-08-17 18:21:23 --> Controller Class Initialized
DEBUG - 2020-08-17 18:21:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:21:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:21:23 --> Final output sent to browser
DEBUG - 2020-08-17 18:21:23 --> Total execution time: 0.0232
INFO - 2020-08-17 18:21:41 --> Config Class Initialized
INFO - 2020-08-17 18:21:41 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:41 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:41 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:41 --> URI Class Initialized
INFO - 2020-08-17 18:21:41 --> Router Class Initialized
INFO - 2020-08-17 18:21:41 --> Output Class Initialized
INFO - 2020-08-17 18:21:41 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:41 --> Input Class Initialized
INFO - 2020-08-17 18:21:41 --> Language Class Initialized
INFO - 2020-08-17 18:21:41 --> Loader Class Initialized
INFO - 2020-08-17 18:21:41 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:41 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:41 --> Email Class Initialized
INFO - 2020-08-17 18:21:41 --> Controller Class Initialized
DEBUG - 2020-08-17 18:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:21:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:41 --> Model Class Initialized
INFO - 2020-08-17 18:21:41 --> Model Class Initialized
INFO - 2020-08-17 18:21:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 18:21:41 --> Final output sent to browser
DEBUG - 2020-08-17 18:21:41 --> Total execution time: 0.4915
INFO - 2020-08-17 18:21:44 --> Config Class Initialized
INFO - 2020-08-17 18:21:44 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:21:44 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:21:44 --> Utf8 Class Initialized
INFO - 2020-08-17 18:21:44 --> URI Class Initialized
INFO - 2020-08-17 18:21:44 --> Router Class Initialized
INFO - 2020-08-17 18:21:44 --> Output Class Initialized
INFO - 2020-08-17 18:21:44 --> Security Class Initialized
DEBUG - 2020-08-17 18:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:21:44 --> Input Class Initialized
INFO - 2020-08-17 18:21:44 --> Language Class Initialized
INFO - 2020-08-17 18:21:44 --> Loader Class Initialized
INFO - 2020-08-17 18:21:44 --> Helper loaded: url_helper
INFO - 2020-08-17 18:21:44 --> Database Driver Class Initialized
INFO - 2020-08-17 18:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:21:44 --> Email Class Initialized
INFO - 2020-08-17 18:21:44 --> Controller Class Initialized
DEBUG - 2020-08-17 18:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:21:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:21:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:21:44 --> Final output sent to browser
DEBUG - 2020-08-17 18:21:44 --> Total execution time: 0.0218
INFO - 2020-08-17 18:22:39 --> Config Class Initialized
INFO - 2020-08-17 18:22:39 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:22:39 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:22:39 --> Utf8 Class Initialized
INFO - 2020-08-17 18:22:39 --> URI Class Initialized
DEBUG - 2020-08-17 18:22:39 --> No URI present. Default controller set.
INFO - 2020-08-17 18:22:39 --> Router Class Initialized
INFO - 2020-08-17 18:22:39 --> Output Class Initialized
INFO - 2020-08-17 18:22:39 --> Security Class Initialized
DEBUG - 2020-08-17 18:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:22:39 --> Input Class Initialized
INFO - 2020-08-17 18:22:39 --> Language Class Initialized
INFO - 2020-08-17 18:22:39 --> Loader Class Initialized
INFO - 2020-08-17 18:22:39 --> Helper loaded: url_helper
INFO - 2020-08-17 18:22:39 --> Database Driver Class Initialized
INFO - 2020-08-17 18:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:22:39 --> Email Class Initialized
INFO - 2020-08-17 18:22:39 --> Controller Class Initialized
INFO - 2020-08-17 18:22:39 --> Model Class Initialized
INFO - 2020-08-17 18:22:39 --> Model Class Initialized
DEBUG - 2020-08-17 18:22:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:22:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:22:39 --> Final output sent to browser
DEBUG - 2020-08-17 18:22:39 --> Total execution time: 0.0230
INFO - 2020-08-17 18:22:43 --> Config Class Initialized
INFO - 2020-08-17 18:22:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:22:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:22:43 --> Utf8 Class Initialized
INFO - 2020-08-17 18:22:43 --> Config Class Initialized
INFO - 2020-08-17 18:22:43 --> Hooks Class Initialized
INFO - 2020-08-17 18:22:43 --> URI Class Initialized
INFO - 2020-08-17 18:22:43 --> Router Class Initialized
DEBUG - 2020-08-17 18:22:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:22:43 --> Utf8 Class Initialized
INFO - 2020-08-17 18:22:43 --> URI Class Initialized
INFO - 2020-08-17 18:22:43 --> Output Class Initialized
INFO - 2020-08-17 18:22:43 --> Router Class Initialized
INFO - 2020-08-17 18:22:43 --> Security Class Initialized
INFO - 2020-08-17 18:22:43 --> Output Class Initialized
DEBUG - 2020-08-17 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:22:43 --> Input Class Initialized
INFO - 2020-08-17 18:22:43 --> Language Class Initialized
INFO - 2020-08-17 18:22:43 --> Security Class Initialized
DEBUG - 2020-08-17 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:22:43 --> Input Class Initialized
INFO - 2020-08-17 18:22:43 --> Language Class Initialized
INFO - 2020-08-17 18:22:43 --> Loader Class Initialized
INFO - 2020-08-17 18:22:43 --> Helper loaded: url_helper
INFO - 2020-08-17 18:22:43 --> Loader Class Initialized
INFO - 2020-08-17 18:22:43 --> Helper loaded: url_helper
INFO - 2020-08-17 18:22:43 --> Database Driver Class Initialized
INFO - 2020-08-17 18:22:43 --> Database Driver Class Initialized
INFO - 2020-08-17 18:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:22:43 --> Email Class Initialized
INFO - 2020-08-17 18:22:43 --> Controller Class Initialized
INFO - 2020-08-17 18:22:43 --> Model Class Initialized
INFO - 2020-08-17 18:22:43 --> Model Class Initialized
DEBUG - 2020-08-17 18:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:22:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:22:43 --> Model Class Initialized
INFO - 2020-08-17 18:22:43 --> Final output sent to browser
DEBUG - 2020-08-17 18:22:43 --> Total execution time: 0.0253
INFO - 2020-08-17 18:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:22:43 --> Email Class Initialized
INFO - 2020-08-17 18:22:43 --> Controller Class Initialized
INFO - 2020-08-17 18:22:43 --> Model Class Initialized
INFO - 2020-08-17 18:22:43 --> Model Class Initialized
DEBUG - 2020-08-17 18:22:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:22:43 --> Config Class Initialized
INFO - 2020-08-17 18:22:43 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:22:43 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:22:43 --> Utf8 Class Initialized
INFO - 2020-08-17 18:22:43 --> URI Class Initialized
INFO - 2020-08-17 18:22:43 --> Router Class Initialized
INFO - 2020-08-17 18:22:43 --> Output Class Initialized
INFO - 2020-08-17 18:22:43 --> Security Class Initialized
DEBUG - 2020-08-17 18:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:22:43 --> Input Class Initialized
INFO - 2020-08-17 18:22:43 --> Language Class Initialized
INFO - 2020-08-17 18:22:43 --> Loader Class Initialized
INFO - 2020-08-17 18:22:43 --> Helper loaded: url_helper
INFO - 2020-08-17 18:22:43 --> Database Driver Class Initialized
INFO - 2020-08-17 18:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:22:43 --> Email Class Initialized
INFO - 2020-08-17 18:22:43 --> Controller Class Initialized
DEBUG - 2020-08-17 18:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:22:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:22:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:22:43 --> Final output sent to browser
DEBUG - 2020-08-17 18:22:43 --> Total execution time: 0.0219
INFO - 2020-08-17 18:26:52 --> Config Class Initialized
INFO - 2020-08-17 18:26:52 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:26:52 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:26:52 --> Utf8 Class Initialized
INFO - 2020-08-17 18:26:52 --> URI Class Initialized
DEBUG - 2020-08-17 18:26:52 --> No URI present. Default controller set.
INFO - 2020-08-17 18:26:52 --> Router Class Initialized
INFO - 2020-08-17 18:26:52 --> Output Class Initialized
INFO - 2020-08-17 18:26:52 --> Security Class Initialized
DEBUG - 2020-08-17 18:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:26:52 --> Input Class Initialized
INFO - 2020-08-17 18:26:52 --> Language Class Initialized
INFO - 2020-08-17 18:26:52 --> Loader Class Initialized
INFO - 2020-08-17 18:26:52 --> Helper loaded: url_helper
INFO - 2020-08-17 18:26:52 --> Database Driver Class Initialized
INFO - 2020-08-17 18:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:26:52 --> Email Class Initialized
INFO - 2020-08-17 18:26:52 --> Controller Class Initialized
INFO - 2020-08-17 18:26:52 --> Model Class Initialized
INFO - 2020-08-17 18:26:52 --> Model Class Initialized
DEBUG - 2020-08-17 18:26:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:26:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:26:52 --> Final output sent to browser
DEBUG - 2020-08-17 18:26:52 --> Total execution time: 0.0196
INFO - 2020-08-17 18:26:55 --> Config Class Initialized
INFO - 2020-08-17 18:26:55 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:26:55 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:26:55 --> Utf8 Class Initialized
INFO - 2020-08-17 18:26:55 --> URI Class Initialized
INFO - 2020-08-17 18:26:55 --> Router Class Initialized
INFO - 2020-08-17 18:26:55 --> Output Class Initialized
INFO - 2020-08-17 18:26:55 --> Security Class Initialized
DEBUG - 2020-08-17 18:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:26:55 --> Input Class Initialized
INFO - 2020-08-17 18:26:55 --> Language Class Initialized
INFO - 2020-08-17 18:26:55 --> Loader Class Initialized
INFO - 2020-08-17 18:26:55 --> Helper loaded: url_helper
INFO - 2020-08-17 18:26:55 --> Database Driver Class Initialized
INFO - 2020-08-17 18:26:55 --> Config Class Initialized
INFO - 2020-08-17 18:26:55 --> Hooks Class Initialized
INFO - 2020-08-17 18:26:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-17 18:26:55 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:26:55 --> Utf8 Class Initialized
INFO - 2020-08-17 18:26:55 --> URI Class Initialized
INFO - 2020-08-17 18:26:55 --> Router Class Initialized
INFO - 2020-08-17 18:26:55 --> Email Class Initialized
INFO - 2020-08-17 18:26:55 --> Controller Class Initialized
INFO - 2020-08-17 18:26:55 --> Model Class Initialized
INFO - 2020-08-17 18:26:55 --> Output Class Initialized
INFO - 2020-08-17 18:26:55 --> Model Class Initialized
DEBUG - 2020-08-17 18:26:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:26:55 --> Security Class Initialized
DEBUG - 2020-08-17 18:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:26:55 --> Input Class Initialized
INFO - 2020-08-17 18:26:55 --> Language Class Initialized
INFO - 2020-08-17 18:26:55 --> Loader Class Initialized
INFO - 2020-08-17 18:26:55 --> Helper loaded: url_helper
INFO - 2020-08-17 18:26:55 --> Database Driver Class Initialized
INFO - 2020-08-17 18:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:26:55 --> Email Class Initialized
INFO - 2020-08-17 18:26:55 --> Controller Class Initialized
INFO - 2020-08-17 18:26:55 --> Model Class Initialized
INFO - 2020-08-17 18:26:55 --> Model Class Initialized
DEBUG - 2020-08-17 18:26:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:26:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:26:55 --> Model Class Initialized
INFO - 2020-08-17 18:26:55 --> Final output sent to browser
DEBUG - 2020-08-17 18:26:55 --> Total execution time: 0.0271
INFO - 2020-08-17 18:26:55 --> Config Class Initialized
INFO - 2020-08-17 18:26:55 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:26:55 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:26:55 --> Utf8 Class Initialized
INFO - 2020-08-17 18:26:55 --> URI Class Initialized
INFO - 2020-08-17 18:26:55 --> Router Class Initialized
INFO - 2020-08-17 18:26:55 --> Output Class Initialized
INFO - 2020-08-17 18:26:55 --> Security Class Initialized
DEBUG - 2020-08-17 18:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:26:55 --> Input Class Initialized
INFO - 2020-08-17 18:26:55 --> Language Class Initialized
INFO - 2020-08-17 18:26:55 --> Loader Class Initialized
INFO - 2020-08-17 18:26:55 --> Helper loaded: url_helper
INFO - 2020-08-17 18:26:55 --> Database Driver Class Initialized
INFO - 2020-08-17 18:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:26:55 --> Email Class Initialized
INFO - 2020-08-17 18:26:55 --> Controller Class Initialized
DEBUG - 2020-08-17 18:26:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:26:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:26:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:26:55 --> Final output sent to browser
DEBUG - 2020-08-17 18:26:55 --> Total execution time: 0.0227
INFO - 2020-08-17 18:27:11 --> Config Class Initialized
INFO - 2020-08-17 18:27:11 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:27:11 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:27:11 --> Utf8 Class Initialized
INFO - 2020-08-17 18:27:11 --> URI Class Initialized
DEBUG - 2020-08-17 18:27:11 --> No URI present. Default controller set.
INFO - 2020-08-17 18:27:11 --> Router Class Initialized
INFO - 2020-08-17 18:27:11 --> Output Class Initialized
INFO - 2020-08-17 18:27:11 --> Security Class Initialized
DEBUG - 2020-08-17 18:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:27:11 --> Input Class Initialized
INFO - 2020-08-17 18:27:11 --> Language Class Initialized
INFO - 2020-08-17 18:27:11 --> Loader Class Initialized
INFO - 2020-08-17 18:27:11 --> Helper loaded: url_helper
INFO - 2020-08-17 18:27:11 --> Database Driver Class Initialized
INFO - 2020-08-17 18:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:27:11 --> Email Class Initialized
INFO - 2020-08-17 18:27:11 --> Controller Class Initialized
INFO - 2020-08-17 18:27:11 --> Model Class Initialized
INFO - 2020-08-17 18:27:11 --> Model Class Initialized
DEBUG - 2020-08-17 18:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:27:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:27:11 --> Final output sent to browser
DEBUG - 2020-08-17 18:27:11 --> Total execution time: 0.0230
INFO - 2020-08-17 18:27:34 --> Config Class Initialized
INFO - 2020-08-17 18:27:34 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:27:34 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:27:34 --> Utf8 Class Initialized
INFO - 2020-08-17 18:27:34 --> URI Class Initialized
INFO - 2020-08-17 18:27:34 --> Router Class Initialized
INFO - 2020-08-17 18:27:34 --> Output Class Initialized
INFO - 2020-08-17 18:27:34 --> Security Class Initialized
DEBUG - 2020-08-17 18:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:27:34 --> Input Class Initialized
INFO - 2020-08-17 18:27:34 --> Language Class Initialized
INFO - 2020-08-17 18:27:34 --> Loader Class Initialized
INFO - 2020-08-17 18:27:34 --> Helper loaded: url_helper
INFO - 2020-08-17 18:27:34 --> Database Driver Class Initialized
INFO - 2020-08-17 18:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:27:34 --> Email Class Initialized
INFO - 2020-08-17 18:27:34 --> Controller Class Initialized
INFO - 2020-08-17 18:27:34 --> Model Class Initialized
INFO - 2020-08-17 18:27:34 --> Model Class Initialized
DEBUG - 2020-08-17 18:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:27:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:27:34 --> Model Class Initialized
INFO - 2020-08-17 18:27:34 --> Final output sent to browser
DEBUG - 2020-08-17 18:27:34 --> Total execution time: 0.0240
INFO - 2020-08-17 18:27:34 --> Config Class Initialized
INFO - 2020-08-17 18:27:34 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:27:34 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:27:34 --> Utf8 Class Initialized
INFO - 2020-08-17 18:27:34 --> URI Class Initialized
INFO - 2020-08-17 18:27:34 --> Router Class Initialized
INFO - 2020-08-17 18:27:34 --> Output Class Initialized
INFO - 2020-08-17 18:27:34 --> Security Class Initialized
DEBUG - 2020-08-17 18:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:27:34 --> Input Class Initialized
INFO - 2020-08-17 18:27:34 --> Language Class Initialized
INFO - 2020-08-17 18:27:34 --> Loader Class Initialized
INFO - 2020-08-17 18:27:34 --> Helper loaded: url_helper
INFO - 2020-08-17 18:27:34 --> Database Driver Class Initialized
INFO - 2020-08-17 18:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:27:34 --> Email Class Initialized
INFO - 2020-08-17 18:27:34 --> Controller Class Initialized
INFO - 2020-08-17 18:27:34 --> Model Class Initialized
INFO - 2020-08-17 18:27:34 --> Model Class Initialized
DEBUG - 2020-08-17 18:27:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:27:34 --> Config Class Initialized
INFO - 2020-08-17 18:27:34 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:27:34 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:27:34 --> Utf8 Class Initialized
INFO - 2020-08-17 18:27:34 --> URI Class Initialized
INFO - 2020-08-17 18:27:34 --> Router Class Initialized
INFO - 2020-08-17 18:27:34 --> Output Class Initialized
INFO - 2020-08-17 18:27:34 --> Security Class Initialized
DEBUG - 2020-08-17 18:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:27:34 --> Input Class Initialized
INFO - 2020-08-17 18:27:34 --> Language Class Initialized
INFO - 2020-08-17 18:27:34 --> Loader Class Initialized
INFO - 2020-08-17 18:27:34 --> Helper loaded: url_helper
INFO - 2020-08-17 18:27:34 --> Database Driver Class Initialized
INFO - 2020-08-17 18:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:27:34 --> Email Class Initialized
INFO - 2020-08-17 18:27:34 --> Controller Class Initialized
DEBUG - 2020-08-17 18:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:27:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:27:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:27:34 --> Final output sent to browser
DEBUG - 2020-08-17 18:27:34 --> Total execution time: 0.0201
INFO - 2020-08-17 18:31:06 --> Config Class Initialized
INFO - 2020-08-17 18:31:06 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:31:06 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:31:06 --> Utf8 Class Initialized
INFO - 2020-08-17 18:31:06 --> URI Class Initialized
DEBUG - 2020-08-17 18:31:06 --> No URI present. Default controller set.
INFO - 2020-08-17 18:31:06 --> Router Class Initialized
INFO - 2020-08-17 18:31:06 --> Output Class Initialized
INFO - 2020-08-17 18:31:06 --> Security Class Initialized
DEBUG - 2020-08-17 18:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:31:06 --> Input Class Initialized
INFO - 2020-08-17 18:31:06 --> Language Class Initialized
INFO - 2020-08-17 18:31:06 --> Loader Class Initialized
INFO - 2020-08-17 18:31:06 --> Helper loaded: url_helper
INFO - 2020-08-17 18:31:06 --> Database Driver Class Initialized
INFO - 2020-08-17 18:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:31:06 --> Email Class Initialized
INFO - 2020-08-17 18:31:06 --> Controller Class Initialized
INFO - 2020-08-17 18:31:06 --> Model Class Initialized
INFO - 2020-08-17 18:31:06 --> Model Class Initialized
DEBUG - 2020-08-17 18:31:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:31:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:31:06 --> Final output sent to browser
DEBUG - 2020-08-17 18:31:06 --> Total execution time: 0.0220
INFO - 2020-08-17 18:31:09 --> Config Class Initialized
INFO - 2020-08-17 18:31:09 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:31:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:31:09 --> Utf8 Class Initialized
INFO - 2020-08-17 18:31:09 --> URI Class Initialized
INFO - 2020-08-17 18:31:09 --> Config Class Initialized
INFO - 2020-08-17 18:31:09 --> Hooks Class Initialized
INFO - 2020-08-17 18:31:09 --> Router Class Initialized
INFO - 2020-08-17 18:31:09 --> Output Class Initialized
DEBUG - 2020-08-17 18:31:09 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:31:09 --> Utf8 Class Initialized
INFO - 2020-08-17 18:31:09 --> Security Class Initialized
INFO - 2020-08-17 18:31:09 --> URI Class Initialized
INFO - 2020-08-17 18:31:09 --> Router Class Initialized
DEBUG - 2020-08-17 18:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:31:09 --> Input Class Initialized
INFO - 2020-08-17 18:31:09 --> Language Class Initialized
INFO - 2020-08-17 18:31:09 --> Output Class Initialized
INFO - 2020-08-17 18:31:09 --> Security Class Initialized
INFO - 2020-08-17 18:31:09 --> Loader Class Initialized
DEBUG - 2020-08-17 18:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:31:09 --> Input Class Initialized
INFO - 2020-08-17 18:31:09 --> Helper loaded: url_helper
INFO - 2020-08-17 18:31:09 --> Language Class Initialized
INFO - 2020-08-17 18:31:09 --> Loader Class Initialized
INFO - 2020-08-17 18:31:09 --> Helper loaded: url_helper
INFO - 2020-08-17 18:31:09 --> Database Driver Class Initialized
INFO - 2020-08-17 18:31:09 --> Database Driver Class Initialized
INFO - 2020-08-17 18:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:31:09 --> Email Class Initialized
INFO - 2020-08-17 18:31:09 --> Controller Class Initialized
INFO - 2020-08-17 18:31:09 --> Model Class Initialized
INFO - 2020-08-17 18:31:09 --> Model Class Initialized
DEBUG - 2020-08-17 18:31:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:31:09 --> Email Class Initialized
INFO - 2020-08-17 18:31:09 --> Controller Class Initialized
INFO - 2020-08-17 18:31:09 --> Model Class Initialized
INFO - 2020-08-17 18:31:09 --> Model Class Initialized
DEBUG - 2020-08-17 18:31:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:31:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:31:09 --> Model Class Initialized
INFO - 2020-08-17 18:31:09 --> Final output sent to browser
DEBUG - 2020-08-17 18:31:09 --> Total execution time: 0.0249
INFO - 2020-08-17 18:31:10 --> Config Class Initialized
INFO - 2020-08-17 18:31:10 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:31:10 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:31:10 --> Utf8 Class Initialized
INFO - 2020-08-17 18:31:10 --> URI Class Initialized
INFO - 2020-08-17 18:31:10 --> Router Class Initialized
INFO - 2020-08-17 18:31:10 --> Output Class Initialized
INFO - 2020-08-17 18:31:10 --> Security Class Initialized
DEBUG - 2020-08-17 18:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:31:10 --> Input Class Initialized
INFO - 2020-08-17 18:31:10 --> Language Class Initialized
INFO - 2020-08-17 18:31:10 --> Loader Class Initialized
INFO - 2020-08-17 18:31:10 --> Helper loaded: url_helper
INFO - 2020-08-17 18:31:10 --> Database Driver Class Initialized
INFO - 2020-08-17 18:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:31:10 --> Email Class Initialized
INFO - 2020-08-17 18:31:10 --> Controller Class Initialized
DEBUG - 2020-08-17 18:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:31:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:31:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 18:31:10 --> Final output sent to browser
DEBUG - 2020-08-17 18:31:10 --> Total execution time: 0.0226
INFO - 2020-08-17 18:32:50 --> Config Class Initialized
INFO - 2020-08-17 18:32:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:32:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:32:50 --> Utf8 Class Initialized
INFO - 2020-08-17 18:32:50 --> URI Class Initialized
DEBUG - 2020-08-17 18:32:50 --> No URI present. Default controller set.
INFO - 2020-08-17 18:32:50 --> Router Class Initialized
INFO - 2020-08-17 18:32:50 --> Output Class Initialized
INFO - 2020-08-17 18:32:50 --> Security Class Initialized
DEBUG - 2020-08-17 18:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:32:50 --> Input Class Initialized
INFO - 2020-08-17 18:32:50 --> Language Class Initialized
INFO - 2020-08-17 18:32:50 --> Loader Class Initialized
INFO - 2020-08-17 18:32:50 --> Helper loaded: url_helper
INFO - 2020-08-17 18:32:50 --> Database Driver Class Initialized
INFO - 2020-08-17 18:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:32:50 --> Email Class Initialized
INFO - 2020-08-17 18:32:50 --> Controller Class Initialized
INFO - 2020-08-17 18:32:50 --> Model Class Initialized
INFO - 2020-08-17 18:32:50 --> Model Class Initialized
DEBUG - 2020-08-17 18:32:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:32:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:32:50 --> Final output sent to browser
DEBUG - 2020-08-17 18:32:50 --> Total execution time: 0.0196
INFO - 2020-08-17 18:33:07 --> Config Class Initialized
INFO - 2020-08-17 18:33:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:07 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:07 --> URI Class Initialized
INFO - 2020-08-17 18:33:07 --> Router Class Initialized
INFO - 2020-08-17 18:33:07 --> Output Class Initialized
INFO - 2020-08-17 18:33:07 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:07 --> Input Class Initialized
INFO - 2020-08-17 18:33:07 --> Language Class Initialized
INFO - 2020-08-17 18:33:07 --> Loader Class Initialized
INFO - 2020-08-17 18:33:07 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:07 --> Config Class Initialized
INFO - 2020-08-17 18:33:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:07 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:07 --> URI Class Initialized
INFO - 2020-08-17 18:33:07 --> Router Class Initialized
INFO - 2020-08-17 18:33:07 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:07 --> Output Class Initialized
INFO - 2020-08-17 18:33:07 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:07 --> Input Class Initialized
INFO - 2020-08-17 18:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:07 --> Language Class Initialized
INFO - 2020-08-17 18:33:07 --> Loader Class Initialized
INFO - 2020-08-17 18:33:07 --> Email Class Initialized
INFO - 2020-08-17 18:33:07 --> Controller Class Initialized
INFO - 2020-08-17 18:33:07 --> Model Class Initialized
INFO - 2020-08-17 18:33:07 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:07 --> Model Class Initialized
DEBUG - 2020-08-17 18:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:33:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:07 --> Model Class Initialized
INFO - 2020-08-17 18:33:07 --> Final output sent to browser
DEBUG - 2020-08-17 18:33:07 --> Total execution time: 0.0233
INFO - 2020-08-17 18:33:07 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:07 --> Email Class Initialized
INFO - 2020-08-17 18:33:07 --> Controller Class Initialized
INFO - 2020-08-17 18:33:07 --> Model Class Initialized
INFO - 2020-08-17 18:33:07 --> Model Class Initialized
DEBUG - 2020-08-17 18:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:07 --> Config Class Initialized
INFO - 2020-08-17 18:33:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:07 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:07 --> URI Class Initialized
INFO - 2020-08-17 18:33:07 --> Router Class Initialized
INFO - 2020-08-17 18:33:07 --> Output Class Initialized
INFO - 2020-08-17 18:33:07 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:07 --> Input Class Initialized
INFO - 2020-08-17 18:33:07 --> Language Class Initialized
INFO - 2020-08-17 18:33:07 --> Loader Class Initialized
INFO - 2020-08-17 18:33:07 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:07 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:07 --> Email Class Initialized
INFO - 2020-08-17 18:33:07 --> Controller Class Initialized
DEBUG - 2020-08-17 18:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:33:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:33:07 --> Final output sent to browser
DEBUG - 2020-08-17 18:33:07 --> Total execution time: 0.0198
INFO - 2020-08-17 18:33:29 --> Config Class Initialized
INFO - 2020-08-17 18:33:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:29 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:29 --> URI Class Initialized
DEBUG - 2020-08-17 18:33:29 --> No URI present. Default controller set.
INFO - 2020-08-17 18:33:29 --> Router Class Initialized
INFO - 2020-08-17 18:33:29 --> Output Class Initialized
INFO - 2020-08-17 18:33:29 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:29 --> Input Class Initialized
INFO - 2020-08-17 18:33:29 --> Language Class Initialized
INFO - 2020-08-17 18:33:29 --> Loader Class Initialized
INFO - 2020-08-17 18:33:29 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:29 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:29 --> Email Class Initialized
INFO - 2020-08-17 18:33:29 --> Controller Class Initialized
INFO - 2020-08-17 18:33:29 --> Model Class Initialized
INFO - 2020-08-17 18:33:29 --> Model Class Initialized
DEBUG - 2020-08-17 18:33:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 18:33:29 --> Final output sent to browser
DEBUG - 2020-08-17 18:33:29 --> Total execution time: 0.0224
INFO - 2020-08-17 18:33:50 --> Config Class Initialized
INFO - 2020-08-17 18:33:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:50 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:50 --> URI Class Initialized
INFO - 2020-08-17 18:33:50 --> Router Class Initialized
INFO - 2020-08-17 18:33:50 --> Output Class Initialized
INFO - 2020-08-17 18:33:50 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:50 --> Input Class Initialized
INFO - 2020-08-17 18:33:50 --> Language Class Initialized
INFO - 2020-08-17 18:33:50 --> Loader Class Initialized
INFO - 2020-08-17 18:33:50 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:50 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:50 --> Email Class Initialized
INFO - 2020-08-17 18:33:50 --> Controller Class Initialized
INFO - 2020-08-17 18:33:50 --> Model Class Initialized
INFO - 2020-08-17 18:33:50 --> Model Class Initialized
DEBUG - 2020-08-17 18:33:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:50 --> Config Class Initialized
INFO - 2020-08-17 18:33:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:50 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:50 --> URI Class Initialized
INFO - 2020-08-17 18:33:50 --> Router Class Initialized
INFO - 2020-08-17 18:33:50 --> Output Class Initialized
INFO - 2020-08-17 18:33:50 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:50 --> Input Class Initialized
INFO - 2020-08-17 18:33:50 --> Language Class Initialized
INFO - 2020-08-17 18:33:50 --> Loader Class Initialized
INFO - 2020-08-17 18:33:50 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:50 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:50 --> Email Class Initialized
INFO - 2020-08-17 18:33:50 --> Controller Class Initialized
INFO - 2020-08-17 18:33:50 --> Model Class Initialized
INFO - 2020-08-17 18:33:50 --> Model Class Initialized
DEBUG - 2020-08-17 18:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:33:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:50 --> Model Class Initialized
INFO - 2020-08-17 18:33:50 --> Final output sent to browser
DEBUG - 2020-08-17 18:33:50 --> Total execution time: 0.0245
INFO - 2020-08-17 18:33:50 --> Config Class Initialized
INFO - 2020-08-17 18:33:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:33:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:33:50 --> Utf8 Class Initialized
INFO - 2020-08-17 18:33:50 --> URI Class Initialized
INFO - 2020-08-17 18:33:50 --> Router Class Initialized
INFO - 2020-08-17 18:33:50 --> Output Class Initialized
INFO - 2020-08-17 18:33:50 --> Security Class Initialized
DEBUG - 2020-08-17 18:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:33:50 --> Input Class Initialized
INFO - 2020-08-17 18:33:50 --> Language Class Initialized
INFO - 2020-08-17 18:33:50 --> Loader Class Initialized
INFO - 2020-08-17 18:33:50 --> Helper loaded: url_helper
INFO - 2020-08-17 18:33:50 --> Database Driver Class Initialized
INFO - 2020-08-17 18:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:33:50 --> Email Class Initialized
INFO - 2020-08-17 18:33:50 --> Controller Class Initialized
DEBUG - 2020-08-17 18:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:33:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:33:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 18:33:50 --> Final output sent to browser
DEBUG - 2020-08-17 18:33:50 --> Total execution time: 0.0211
INFO - 2020-08-17 18:34:13 --> Config Class Initialized
INFO - 2020-08-17 18:34:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:34:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:34:13 --> Utf8 Class Initialized
INFO - 2020-08-17 18:34:13 --> URI Class Initialized
INFO - 2020-08-17 18:34:13 --> Router Class Initialized
INFO - 2020-08-17 18:34:13 --> Output Class Initialized
INFO - 2020-08-17 18:34:13 --> Security Class Initialized
DEBUG - 2020-08-17 18:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:34:13 --> Input Class Initialized
INFO - 2020-08-17 18:34:13 --> Language Class Initialized
INFO - 2020-08-17 18:34:13 --> Loader Class Initialized
INFO - 2020-08-17 18:34:13 --> Helper loaded: url_helper
INFO - 2020-08-17 18:34:13 --> Database Driver Class Initialized
INFO - 2020-08-17 18:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:34:13 --> Email Class Initialized
INFO - 2020-08-17 18:34:13 --> Controller Class Initialized
DEBUG - 2020-08-17 18:34:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:34:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:34:13 --> Model Class Initialized
INFO - 2020-08-17 18:34:13 --> Model Class Initialized
INFO - 2020-08-17 18:34:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:34:13 --> Final output sent to browser
DEBUG - 2020-08-17 18:34:13 --> Total execution time: 0.0289
INFO - 2020-08-17 18:34:17 --> Config Class Initialized
INFO - 2020-08-17 18:34:17 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:34:17 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:34:17 --> Utf8 Class Initialized
INFO - 2020-08-17 18:34:17 --> URI Class Initialized
INFO - 2020-08-17 18:34:17 --> Router Class Initialized
INFO - 2020-08-17 18:34:17 --> Output Class Initialized
INFO - 2020-08-17 18:34:17 --> Security Class Initialized
DEBUG - 2020-08-17 18:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:34:17 --> Input Class Initialized
INFO - 2020-08-17 18:34:17 --> Language Class Initialized
INFO - 2020-08-17 18:34:17 --> Loader Class Initialized
INFO - 2020-08-17 18:34:17 --> Helper loaded: url_helper
INFO - 2020-08-17 18:34:17 --> Database Driver Class Initialized
INFO - 2020-08-17 18:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:34:17 --> Email Class Initialized
INFO - 2020-08-17 18:34:17 --> Controller Class Initialized
DEBUG - 2020-08-17 18:34:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:34:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:34:17 --> Model Class Initialized
INFO - 2020-08-17 18:34:17 --> Model Class Initialized
INFO - 2020-08-17 18:34:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-17 18:34:17 --> Final output sent to browser
DEBUG - 2020-08-17 18:34:17 --> Total execution time: 0.0241
INFO - 2020-08-17 18:34:20 --> Config Class Initialized
INFO - 2020-08-17 18:34:20 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:34:20 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:34:20 --> Utf8 Class Initialized
INFO - 2020-08-17 18:34:20 --> URI Class Initialized
INFO - 2020-08-17 18:34:20 --> Router Class Initialized
INFO - 2020-08-17 18:34:20 --> Output Class Initialized
INFO - 2020-08-17 18:34:20 --> Security Class Initialized
DEBUG - 2020-08-17 18:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:34:20 --> Input Class Initialized
INFO - 2020-08-17 18:34:20 --> Language Class Initialized
INFO - 2020-08-17 18:34:20 --> Loader Class Initialized
INFO - 2020-08-17 18:34:20 --> Helper loaded: url_helper
INFO - 2020-08-17 18:34:20 --> Database Driver Class Initialized
INFO - 2020-08-17 18:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:34:20 --> Email Class Initialized
INFO - 2020-08-17 18:34:20 --> Controller Class Initialized
DEBUG - 2020-08-17 18:34:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:34:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:34:20 --> Model Class Initialized
INFO - 2020-08-17 18:34:20 --> Model Class Initialized
INFO - 2020-08-17 18:34:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:34:20 --> Final output sent to browser
DEBUG - 2020-08-17 18:34:20 --> Total execution time: 0.0274
INFO - 2020-08-17 18:34:23 --> Config Class Initialized
INFO - 2020-08-17 18:34:23 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:34:23 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:34:23 --> Utf8 Class Initialized
INFO - 2020-08-17 18:34:23 --> URI Class Initialized
INFO - 2020-08-17 18:34:23 --> Router Class Initialized
INFO - 2020-08-17 18:34:23 --> Output Class Initialized
INFO - 2020-08-17 18:34:23 --> Security Class Initialized
DEBUG - 2020-08-17 18:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:34:23 --> Input Class Initialized
INFO - 2020-08-17 18:34:23 --> Language Class Initialized
INFO - 2020-08-17 18:34:23 --> Loader Class Initialized
INFO - 2020-08-17 18:34:23 --> Helper loaded: url_helper
INFO - 2020-08-17 18:34:23 --> Database Driver Class Initialized
INFO - 2020-08-17 18:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:34:23 --> Email Class Initialized
INFO - 2020-08-17 18:34:23 --> Controller Class Initialized
DEBUG - 2020-08-17 18:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:34:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:34:23 --> Model Class Initialized
INFO - 2020-08-17 18:34:23 --> Model Class Initialized
INFO - 2020-08-17 18:34:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-08-17 18:34:23 --> Final output sent to browser
DEBUG - 2020-08-17 18:34:23 --> Total execution time: 0.0259
INFO - 2020-08-17 18:34:27 --> Config Class Initialized
INFO - 2020-08-17 18:34:27 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:34:27 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:34:27 --> Utf8 Class Initialized
INFO - 2020-08-17 18:34:27 --> URI Class Initialized
INFO - 2020-08-17 18:34:27 --> Router Class Initialized
INFO - 2020-08-17 18:34:27 --> Output Class Initialized
INFO - 2020-08-17 18:34:27 --> Security Class Initialized
DEBUG - 2020-08-17 18:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:34:27 --> Input Class Initialized
INFO - 2020-08-17 18:34:27 --> Language Class Initialized
INFO - 2020-08-17 18:34:27 --> Loader Class Initialized
INFO - 2020-08-17 18:34:27 --> Helper loaded: url_helper
INFO - 2020-08-17 18:34:27 --> Database Driver Class Initialized
INFO - 2020-08-17 18:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:34:27 --> Email Class Initialized
INFO - 2020-08-17 18:34:27 --> Controller Class Initialized
DEBUG - 2020-08-17 18:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:34:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:34:27 --> Model Class Initialized
INFO - 2020-08-17 18:34:27 --> Model Class Initialized
INFO - 2020-08-17 18:34:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:34:27 --> Final output sent to browser
DEBUG - 2020-08-17 18:34:27 --> Total execution time: 0.0255
INFO - 2020-08-17 18:38:18 --> Config Class Initialized
INFO - 2020-08-17 18:38:18 --> Hooks Class Initialized
DEBUG - 2020-08-17 18:38:18 --> UTF-8 Support Enabled
INFO - 2020-08-17 18:38:18 --> Utf8 Class Initialized
INFO - 2020-08-17 18:38:18 --> URI Class Initialized
INFO - 2020-08-17 18:38:18 --> Router Class Initialized
INFO - 2020-08-17 18:38:18 --> Output Class Initialized
INFO - 2020-08-17 18:38:18 --> Security Class Initialized
DEBUG - 2020-08-17 18:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 18:38:18 --> Input Class Initialized
INFO - 2020-08-17 18:38:18 --> Language Class Initialized
INFO - 2020-08-17 18:38:18 --> Loader Class Initialized
INFO - 2020-08-17 18:38:18 --> Helper loaded: url_helper
INFO - 2020-08-17 18:38:18 --> Database Driver Class Initialized
INFO - 2020-08-17 18:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 18:38:18 --> Email Class Initialized
INFO - 2020-08-17 18:38:18 --> Controller Class Initialized
DEBUG - 2020-08-17 18:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 18:38:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 18:38:18 --> Model Class Initialized
INFO - 2020-08-17 18:38:18 --> Model Class Initialized
INFO - 2020-08-17 18:38:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-17 18:38:18 --> Final output sent to browser
DEBUG - 2020-08-17 18:38:18 --> Total execution time: 0.0235
INFO - 2020-08-17 19:02:33 --> Config Class Initialized
INFO - 2020-08-17 19:02:33 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:02:33 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:02:33 --> Utf8 Class Initialized
INFO - 2020-08-17 19:02:33 --> URI Class Initialized
INFO - 2020-08-17 19:02:33 --> Router Class Initialized
INFO - 2020-08-17 19:02:33 --> Output Class Initialized
INFO - 2020-08-17 19:02:33 --> Security Class Initialized
DEBUG - 2020-08-17 19:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:02:33 --> Input Class Initialized
INFO - 2020-08-17 19:02:33 --> Language Class Initialized
INFO - 2020-08-17 19:02:33 --> Loader Class Initialized
INFO - 2020-08-17 19:02:33 --> Helper loaded: url_helper
INFO - 2020-08-17 19:02:33 --> Database Driver Class Initialized
INFO - 2020-08-17 19:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:02:33 --> Email Class Initialized
INFO - 2020-08-17 19:02:33 --> Controller Class Initialized
DEBUG - 2020-08-17 19:02:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:02:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:02:33 --> Model Class Initialized
INFO - 2020-08-17 19:02:33 --> Model Class Initialized
INFO - 2020-08-17 19:02:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 19:02:33 --> Final output sent to browser
DEBUG - 2020-08-17 19:02:33 --> Total execution time: 0.0217
INFO - 2020-08-17 19:02:50 --> Config Class Initialized
INFO - 2020-08-17 19:02:50 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:02:50 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:02:50 --> Utf8 Class Initialized
INFO - 2020-08-17 19:02:50 --> URI Class Initialized
INFO - 2020-08-17 19:02:50 --> Router Class Initialized
INFO - 2020-08-17 19:02:50 --> Output Class Initialized
INFO - 2020-08-17 19:02:50 --> Security Class Initialized
DEBUG - 2020-08-17 19:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:02:50 --> Input Class Initialized
INFO - 2020-08-17 19:02:50 --> Language Class Initialized
INFO - 2020-08-17 19:02:50 --> Loader Class Initialized
INFO - 2020-08-17 19:02:50 --> Helper loaded: url_helper
INFO - 2020-08-17 19:02:50 --> Database Driver Class Initialized
INFO - 2020-08-17 19:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:02:50 --> Email Class Initialized
INFO - 2020-08-17 19:02:50 --> Controller Class Initialized
DEBUG - 2020-08-17 19:02:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:02:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:02:50 --> Model Class Initialized
INFO - 2020-08-17 19:02:50 --> Model Class Initialized
INFO - 2020-08-17 19:02:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 19:02:50 --> Final output sent to browser
DEBUG - 2020-08-17 19:02:50 --> Total execution time: 0.0240
INFO - 2020-08-17 19:04:07 --> Config Class Initialized
INFO - 2020-08-17 19:04:07 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:07 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:07 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:07 --> URI Class Initialized
INFO - 2020-08-17 19:04:07 --> Router Class Initialized
INFO - 2020-08-17 19:04:07 --> Output Class Initialized
INFO - 2020-08-17 19:04:07 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:07 --> Input Class Initialized
INFO - 2020-08-17 19:04:07 --> Language Class Initialized
INFO - 2020-08-17 19:04:07 --> Loader Class Initialized
INFO - 2020-08-17 19:04:07 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:07 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:07 --> Email Class Initialized
INFO - 2020-08-17 19:04:07 --> Controller Class Initialized
DEBUG - 2020-08-17 19:04:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:07 --> Model Class Initialized
INFO - 2020-08-17 19:04:07 --> Model Class Initialized
INFO - 2020-08-17 19:04:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-17 19:04:07 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:07 --> Total execution time: 0.0245
INFO - 2020-08-17 19:04:12 --> Config Class Initialized
INFO - 2020-08-17 19:04:12 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:12 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:12 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:12 --> URI Class Initialized
INFO - 2020-08-17 19:04:12 --> Router Class Initialized
INFO - 2020-08-17 19:04:12 --> Output Class Initialized
INFO - 2020-08-17 19:04:12 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:12 --> Input Class Initialized
INFO - 2020-08-17 19:04:12 --> Language Class Initialized
INFO - 2020-08-17 19:04:12 --> Loader Class Initialized
INFO - 2020-08-17 19:04:12 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:12 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:12 --> Email Class Initialized
INFO - 2020-08-17 19:04:12 --> Controller Class Initialized
DEBUG - 2020-08-17 19:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:12 --> Model Class Initialized
INFO - 2020-08-17 19:04:12 --> Model Class Initialized
INFO - 2020-08-17 19:04:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 19:04:12 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:12 --> Total execution time: 0.0274
INFO - 2020-08-17 19:04:15 --> Config Class Initialized
INFO - 2020-08-17 19:04:15 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:15 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:15 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:15 --> URI Class Initialized
INFO - 2020-08-17 19:04:15 --> Router Class Initialized
INFO - 2020-08-17 19:04:15 --> Output Class Initialized
INFO - 2020-08-17 19:04:15 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:15 --> Input Class Initialized
INFO - 2020-08-17 19:04:15 --> Language Class Initialized
INFO - 2020-08-17 19:04:15 --> Loader Class Initialized
INFO - 2020-08-17 19:04:15 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:15 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:15 --> Email Class Initialized
INFO - 2020-08-17 19:04:15 --> Controller Class Initialized
DEBUG - 2020-08-17 19:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-17 19:04:15 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:15 --> Total execution time: 0.0587
INFO - 2020-08-17 19:04:22 --> Config Class Initialized
INFO - 2020-08-17 19:04:22 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:22 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:22 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:22 --> URI Class Initialized
DEBUG - 2020-08-17 19:04:22 --> No URI present. Default controller set.
INFO - 2020-08-17 19:04:22 --> Router Class Initialized
INFO - 2020-08-17 19:04:22 --> Output Class Initialized
INFO - 2020-08-17 19:04:22 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:22 --> Input Class Initialized
INFO - 2020-08-17 19:04:22 --> Language Class Initialized
INFO - 2020-08-17 19:04:22 --> Loader Class Initialized
INFO - 2020-08-17 19:04:22 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:22 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:22 --> Email Class Initialized
INFO - 2020-08-17 19:04:22 --> Controller Class Initialized
INFO - 2020-08-17 19:04:22 --> Model Class Initialized
INFO - 2020-08-17 19:04:22 --> Model Class Initialized
DEBUG - 2020-08-17 19:04:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 19:04:22 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:22 --> Total execution time: 0.0235
INFO - 2020-08-17 19:04:26 --> Config Class Initialized
INFO - 2020-08-17 19:04:26 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:26 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:26 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:26 --> URI Class Initialized
INFO - 2020-08-17 19:04:26 --> Router Class Initialized
INFO - 2020-08-17 19:04:26 --> Output Class Initialized
INFO - 2020-08-17 19:04:26 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:26 --> Input Class Initialized
INFO - 2020-08-17 19:04:26 --> Language Class Initialized
INFO - 2020-08-17 19:04:26 --> Loader Class Initialized
INFO - 2020-08-17 19:04:26 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:26 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:26 --> Email Class Initialized
INFO - 2020-08-17 19:04:26 --> Controller Class Initialized
INFO - 2020-08-17 19:04:26 --> Model Class Initialized
INFO - 2020-08-17 19:04:26 --> Model Class Initialized
DEBUG - 2020-08-17 19:04:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:26 --> Model Class Initialized
INFO - 2020-08-17 19:04:26 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:26 --> Total execution time: 0.0263
INFO - 2020-08-17 19:04:26 --> Config Class Initialized
INFO - 2020-08-17 19:04:26 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:26 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:26 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:26 --> URI Class Initialized
INFO - 2020-08-17 19:04:26 --> Router Class Initialized
INFO - 2020-08-17 19:04:26 --> Output Class Initialized
INFO - 2020-08-17 19:04:26 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:26 --> Input Class Initialized
INFO - 2020-08-17 19:04:26 --> Language Class Initialized
INFO - 2020-08-17 19:04:26 --> Loader Class Initialized
INFO - 2020-08-17 19:04:26 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:26 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:26 --> Email Class Initialized
INFO - 2020-08-17 19:04:26 --> Controller Class Initialized
INFO - 2020-08-17 19:04:26 --> Model Class Initialized
INFO - 2020-08-17 19:04:26 --> Model Class Initialized
DEBUG - 2020-08-17 19:04:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:27 --> Config Class Initialized
INFO - 2020-08-17 19:04:27 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:27 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:27 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:27 --> URI Class Initialized
INFO - 2020-08-17 19:04:27 --> Router Class Initialized
INFO - 2020-08-17 19:04:27 --> Output Class Initialized
INFO - 2020-08-17 19:04:27 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:27 --> Input Class Initialized
INFO - 2020-08-17 19:04:27 --> Language Class Initialized
INFO - 2020-08-17 19:04:27 --> Loader Class Initialized
INFO - 2020-08-17 19:04:27 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:27 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:27 --> Email Class Initialized
INFO - 2020-08-17 19:04:27 --> Controller Class Initialized
DEBUG - 2020-08-17 19:04:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 19:04:27 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:27 --> Total execution time: 0.0224
INFO - 2020-08-17 19:04:34 --> Config Class Initialized
INFO - 2020-08-17 19:04:34 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:34 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:34 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:34 --> URI Class Initialized
INFO - 2020-08-17 19:04:34 --> Router Class Initialized
INFO - 2020-08-17 19:04:34 --> Output Class Initialized
INFO - 2020-08-17 19:04:34 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:34 --> Input Class Initialized
INFO - 2020-08-17 19:04:34 --> Language Class Initialized
INFO - 2020-08-17 19:04:34 --> Loader Class Initialized
INFO - 2020-08-17 19:04:34 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:34 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:34 --> Email Class Initialized
INFO - 2020-08-17 19:04:34 --> Controller Class Initialized
DEBUG - 2020-08-17 19:04:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:34 --> Model Class Initialized
INFO - 2020-08-17 19:04:34 --> Model Class Initialized
INFO - 2020-08-17 19:04:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-17 19:04:34 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:34 --> Total execution time: 0.0278
INFO - 2020-08-17 19:04:38 --> Config Class Initialized
INFO - 2020-08-17 19:04:38 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:04:38 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:04:38 --> Utf8 Class Initialized
INFO - 2020-08-17 19:04:38 --> URI Class Initialized
INFO - 2020-08-17 19:04:38 --> Router Class Initialized
INFO - 2020-08-17 19:04:38 --> Output Class Initialized
INFO - 2020-08-17 19:04:38 --> Security Class Initialized
DEBUG - 2020-08-17 19:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:04:38 --> Input Class Initialized
INFO - 2020-08-17 19:04:38 --> Language Class Initialized
INFO - 2020-08-17 19:04:38 --> Loader Class Initialized
INFO - 2020-08-17 19:04:38 --> Helper loaded: url_helper
INFO - 2020-08-17 19:04:38 --> Database Driver Class Initialized
INFO - 2020-08-17 19:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:04:38 --> Email Class Initialized
INFO - 2020-08-17 19:04:38 --> Controller Class Initialized
DEBUG - 2020-08-17 19:04:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:04:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:04:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 19:04:38 --> Final output sent to browser
DEBUG - 2020-08-17 19:04:38 --> Total execution time: 0.0248
INFO - 2020-08-17 19:05:13 --> Config Class Initialized
INFO - 2020-08-17 19:05:13 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:05:13 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:05:13 --> Utf8 Class Initialized
INFO - 2020-08-17 19:05:13 --> URI Class Initialized
DEBUG - 2020-08-17 19:05:13 --> No URI present. Default controller set.
INFO - 2020-08-17 19:05:13 --> Router Class Initialized
INFO - 2020-08-17 19:05:13 --> Output Class Initialized
INFO - 2020-08-17 19:05:13 --> Security Class Initialized
DEBUG - 2020-08-17 19:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:05:13 --> Input Class Initialized
INFO - 2020-08-17 19:05:13 --> Language Class Initialized
INFO - 2020-08-17 19:05:13 --> Loader Class Initialized
INFO - 2020-08-17 19:05:13 --> Helper loaded: url_helper
INFO - 2020-08-17 19:05:13 --> Database Driver Class Initialized
INFO - 2020-08-17 19:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:05:13 --> Email Class Initialized
INFO - 2020-08-17 19:05:13 --> Controller Class Initialized
INFO - 2020-08-17 19:05:13 --> Model Class Initialized
INFO - 2020-08-17 19:05:13 --> Model Class Initialized
DEBUG - 2020-08-17 19:05:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:05:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 19:05:13 --> Final output sent to browser
DEBUG - 2020-08-17 19:05:13 --> Total execution time: 0.0192
INFO - 2020-08-17 19:05:25 --> Config Class Initialized
INFO - 2020-08-17 19:05:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:05:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:05:25 --> Utf8 Class Initialized
INFO - 2020-08-17 19:05:25 --> URI Class Initialized
INFO - 2020-08-17 19:05:25 --> Router Class Initialized
INFO - 2020-08-17 19:05:25 --> Output Class Initialized
INFO - 2020-08-17 19:05:25 --> Security Class Initialized
DEBUG - 2020-08-17 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:05:25 --> Input Class Initialized
INFO - 2020-08-17 19:05:25 --> Language Class Initialized
INFO - 2020-08-17 19:05:25 --> Loader Class Initialized
INFO - 2020-08-17 19:05:25 --> Helper loaded: url_helper
INFO - 2020-08-17 19:05:25 --> Database Driver Class Initialized
INFO - 2020-08-17 19:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:05:25 --> Email Class Initialized
INFO - 2020-08-17 19:05:25 --> Controller Class Initialized
INFO - 2020-08-17 19:05:25 --> Model Class Initialized
INFO - 2020-08-17 19:05:25 --> Model Class Initialized
DEBUG - 2020-08-17 19:05:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:05:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:05:25 --> Model Class Initialized
INFO - 2020-08-17 19:05:25 --> Final output sent to browser
DEBUG - 2020-08-17 19:05:25 --> Total execution time: 0.0222
INFO - 2020-08-17 19:05:25 --> Config Class Initialized
INFO - 2020-08-17 19:05:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:05:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:05:25 --> Utf8 Class Initialized
INFO - 2020-08-17 19:05:25 --> URI Class Initialized
INFO - 2020-08-17 19:05:25 --> Router Class Initialized
INFO - 2020-08-17 19:05:25 --> Output Class Initialized
INFO - 2020-08-17 19:05:25 --> Security Class Initialized
DEBUG - 2020-08-17 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:05:25 --> Input Class Initialized
INFO - 2020-08-17 19:05:25 --> Language Class Initialized
INFO - 2020-08-17 19:05:25 --> Loader Class Initialized
INFO - 2020-08-17 19:05:25 --> Helper loaded: url_helper
INFO - 2020-08-17 19:05:25 --> Database Driver Class Initialized
INFO - 2020-08-17 19:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:05:25 --> Email Class Initialized
INFO - 2020-08-17 19:05:25 --> Controller Class Initialized
INFO - 2020-08-17 19:05:25 --> Model Class Initialized
INFO - 2020-08-17 19:05:25 --> Model Class Initialized
DEBUG - 2020-08-17 19:05:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:05:25 --> Config Class Initialized
INFO - 2020-08-17 19:05:25 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:05:25 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:05:25 --> Utf8 Class Initialized
INFO - 2020-08-17 19:05:25 --> URI Class Initialized
INFO - 2020-08-17 19:05:25 --> Router Class Initialized
INFO - 2020-08-17 19:05:25 --> Output Class Initialized
INFO - 2020-08-17 19:05:25 --> Security Class Initialized
DEBUG - 2020-08-17 19:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:05:25 --> Input Class Initialized
INFO - 2020-08-17 19:05:25 --> Language Class Initialized
INFO - 2020-08-17 19:05:25 --> Loader Class Initialized
INFO - 2020-08-17 19:05:25 --> Helper loaded: url_helper
INFO - 2020-08-17 19:05:25 --> Database Driver Class Initialized
INFO - 2020-08-17 19:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:05:25 --> Email Class Initialized
INFO - 2020-08-17 19:05:25 --> Controller Class Initialized
DEBUG - 2020-08-17 19:05:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:05:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:05:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-17 19:05:25 --> Final output sent to browser
DEBUG - 2020-08-17 19:05:25 --> Total execution time: 0.0225
INFO - 2020-08-17 19:05:29 --> Config Class Initialized
INFO - 2020-08-17 19:05:29 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:05:29 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:05:29 --> Utf8 Class Initialized
INFO - 2020-08-17 19:05:29 --> URI Class Initialized
INFO - 2020-08-17 19:05:29 --> Router Class Initialized
INFO - 2020-08-17 19:05:29 --> Output Class Initialized
INFO - 2020-08-17 19:05:29 --> Security Class Initialized
DEBUG - 2020-08-17 19:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:05:29 --> Input Class Initialized
INFO - 2020-08-17 19:05:29 --> Language Class Initialized
INFO - 2020-08-17 19:05:29 --> Loader Class Initialized
INFO - 2020-08-17 19:05:29 --> Helper loaded: url_helper
INFO - 2020-08-17 19:05:29 --> Database Driver Class Initialized
INFO - 2020-08-17 19:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:05:29 --> Email Class Initialized
INFO - 2020-08-17 19:05:29 --> Controller Class Initialized
DEBUG - 2020-08-17 19:05:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-17 19:05:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:05:29 --> Model Class Initialized
INFO - 2020-08-17 19:05:29 --> Model Class Initialized
INFO - 2020-08-17 19:05:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-17 19:05:29 --> Final output sent to browser
DEBUG - 2020-08-17 19:05:29 --> Total execution time: 0.0258
INFO - 2020-08-17 19:14:20 --> Config Class Initialized
INFO - 2020-08-17 19:14:20 --> Hooks Class Initialized
DEBUG - 2020-08-17 19:14:20 --> UTF-8 Support Enabled
INFO - 2020-08-17 19:14:20 --> Utf8 Class Initialized
INFO - 2020-08-17 19:14:20 --> URI Class Initialized
DEBUG - 2020-08-17 19:14:20 --> No URI present. Default controller set.
INFO - 2020-08-17 19:14:20 --> Router Class Initialized
INFO - 2020-08-17 19:14:20 --> Output Class Initialized
INFO - 2020-08-17 19:14:20 --> Security Class Initialized
DEBUG - 2020-08-17 19:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-17 19:14:20 --> Input Class Initialized
INFO - 2020-08-17 19:14:20 --> Language Class Initialized
INFO - 2020-08-17 19:14:20 --> Loader Class Initialized
INFO - 2020-08-17 19:14:20 --> Helper loaded: url_helper
INFO - 2020-08-17 19:14:20 --> Database Driver Class Initialized
INFO - 2020-08-17 19:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-17 19:14:20 --> Email Class Initialized
INFO - 2020-08-17 19:14:20 --> Controller Class Initialized
INFO - 2020-08-17 19:14:20 --> Model Class Initialized
INFO - 2020-08-17 19:14:20 --> Model Class Initialized
DEBUG - 2020-08-17 19:14:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-17 19:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-17 19:14:20 --> Final output sent to browser
DEBUG - 2020-08-17 19:14:20 --> Total execution time: 0.0388
