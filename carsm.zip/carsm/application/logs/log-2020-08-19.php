<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-19 03:49:25 --> Config Class Initialized
INFO - 2020-08-19 03:49:25 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:49:25 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:49:25 --> Utf8 Class Initialized
INFO - 2020-08-19 03:49:25 --> URI Class Initialized
DEBUG - 2020-08-19 03:49:25 --> No URI present. Default controller set.
INFO - 2020-08-19 03:49:25 --> Router Class Initialized
INFO - 2020-08-19 03:49:25 --> Output Class Initialized
INFO - 2020-08-19 03:49:25 --> Security Class Initialized
DEBUG - 2020-08-19 03:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:49:25 --> Input Class Initialized
INFO - 2020-08-19 03:49:25 --> Language Class Initialized
INFO - 2020-08-19 03:49:25 --> Loader Class Initialized
INFO - 2020-08-19 03:49:25 --> Helper loaded: url_helper
INFO - 2020-08-19 03:49:25 --> Database Driver Class Initialized
INFO - 2020-08-19 03:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:49:25 --> Email Class Initialized
INFO - 2020-08-19 03:49:25 --> Controller Class Initialized
INFO - 2020-08-19 03:49:25 --> Model Class Initialized
INFO - 2020-08-19 03:49:25 --> Model Class Initialized
DEBUG - 2020-08-19 03:49:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:49:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-19 03:49:25 --> Final output sent to browser
DEBUG - 2020-08-19 03:49:25 --> Total execution time: 0.0221
INFO - 2020-08-19 03:49:26 --> Config Class Initialized
INFO - 2020-08-19 03:49:26 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:49:26 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:49:26 --> Utf8 Class Initialized
INFO - 2020-08-19 03:49:26 --> URI Class Initialized
DEBUG - 2020-08-19 03:49:26 --> No URI present. Default controller set.
INFO - 2020-08-19 03:49:26 --> Router Class Initialized
INFO - 2020-08-19 03:49:26 --> Output Class Initialized
INFO - 2020-08-19 03:49:26 --> Security Class Initialized
DEBUG - 2020-08-19 03:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:49:26 --> Input Class Initialized
INFO - 2020-08-19 03:49:26 --> Language Class Initialized
INFO - 2020-08-19 03:49:26 --> Loader Class Initialized
INFO - 2020-08-19 03:49:26 --> Helper loaded: url_helper
INFO - 2020-08-19 03:49:26 --> Database Driver Class Initialized
INFO - 2020-08-19 03:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:49:26 --> Email Class Initialized
INFO - 2020-08-19 03:49:26 --> Controller Class Initialized
INFO - 2020-08-19 03:49:26 --> Model Class Initialized
INFO - 2020-08-19 03:49:26 --> Model Class Initialized
DEBUG - 2020-08-19 03:49:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:49:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-19 03:49:26 --> Final output sent to browser
DEBUG - 2020-08-19 03:49:26 --> Total execution time: 0.0204
INFO - 2020-08-19 03:49:38 --> Config Class Initialized
INFO - 2020-08-19 03:49:38 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:49:38 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:49:38 --> Utf8 Class Initialized
INFO - 2020-08-19 03:49:38 --> URI Class Initialized
INFO - 2020-08-19 03:49:38 --> Router Class Initialized
INFO - 2020-08-19 03:49:38 --> Output Class Initialized
INFO - 2020-08-19 03:49:38 --> Security Class Initialized
DEBUG - 2020-08-19 03:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:49:38 --> Input Class Initialized
INFO - 2020-08-19 03:49:38 --> Language Class Initialized
INFO - 2020-08-19 03:49:38 --> Loader Class Initialized
INFO - 2020-08-19 03:49:38 --> Helper loaded: url_helper
INFO - 2020-08-19 03:49:38 --> Database Driver Class Initialized
INFO - 2020-08-19 03:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:49:38 --> Email Class Initialized
INFO - 2020-08-19 03:49:38 --> Controller Class Initialized
INFO - 2020-08-19 03:49:38 --> Model Class Initialized
INFO - 2020-08-19 03:49:38 --> Model Class Initialized
DEBUG - 2020-08-19 03:49:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:49:38 --> Config Class Initialized
INFO - 2020-08-19 03:49:38 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:49:38 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:49:38 --> Utf8 Class Initialized
INFO - 2020-08-19 03:49:38 --> URI Class Initialized
INFO - 2020-08-19 03:49:38 --> Router Class Initialized
INFO - 2020-08-19 03:49:38 --> Output Class Initialized
INFO - 2020-08-19 03:49:38 --> Security Class Initialized
DEBUG - 2020-08-19 03:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:49:38 --> Input Class Initialized
INFO - 2020-08-19 03:49:38 --> Language Class Initialized
INFO - 2020-08-19 03:49:38 --> Loader Class Initialized
INFO - 2020-08-19 03:49:38 --> Helper loaded: url_helper
INFO - 2020-08-19 03:49:38 --> Database Driver Class Initialized
INFO - 2020-08-19 03:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:49:38 --> Email Class Initialized
INFO - 2020-08-19 03:49:38 --> Controller Class Initialized
INFO - 2020-08-19 03:49:38 --> Model Class Initialized
INFO - 2020-08-19 03:49:38 --> Model Class Initialized
DEBUG - 2020-08-19 03:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:49:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:49:38 --> Model Class Initialized
INFO - 2020-08-19 03:49:38 --> Final output sent to browser
DEBUG - 2020-08-19 03:49:38 --> Total execution time: 0.0258
INFO - 2020-08-19 03:49:38 --> Config Class Initialized
INFO - 2020-08-19 03:49:38 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:49:38 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:49:38 --> Utf8 Class Initialized
INFO - 2020-08-19 03:49:38 --> URI Class Initialized
INFO - 2020-08-19 03:49:38 --> Router Class Initialized
INFO - 2020-08-19 03:49:38 --> Output Class Initialized
INFO - 2020-08-19 03:49:38 --> Security Class Initialized
DEBUG - 2020-08-19 03:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:49:38 --> Input Class Initialized
INFO - 2020-08-19 03:49:38 --> Language Class Initialized
INFO - 2020-08-19 03:49:38 --> Loader Class Initialized
INFO - 2020-08-19 03:49:38 --> Helper loaded: url_helper
INFO - 2020-08-19 03:49:38 --> Database Driver Class Initialized
INFO - 2020-08-19 03:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:49:38 --> Email Class Initialized
INFO - 2020-08-19 03:49:38 --> Controller Class Initialized
DEBUG - 2020-08-19 03:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:49:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:49:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-19 03:49:38 --> Final output sent to browser
DEBUG - 2020-08-19 03:49:38 --> Total execution time: 0.0241
INFO - 2020-08-19 03:50:06 --> Config Class Initialized
INFO - 2020-08-19 03:50:06 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:06 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:06 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:06 --> URI Class Initialized
INFO - 2020-08-19 03:50:06 --> Router Class Initialized
INFO - 2020-08-19 03:50:06 --> Output Class Initialized
INFO - 2020-08-19 03:50:06 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:06 --> Input Class Initialized
INFO - 2020-08-19 03:50:06 --> Language Class Initialized
INFO - 2020-08-19 03:50:06 --> Loader Class Initialized
INFO - 2020-08-19 03:50:06 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:06 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:06 --> Email Class Initialized
INFO - 2020-08-19 03:50:06 --> Controller Class Initialized
DEBUG - 2020-08-19 03:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:50:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:06 --> Model Class Initialized
INFO - 2020-08-19 03:50:06 --> Model Class Initialized
INFO - 2020-08-19 03:50:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-19 03:50:06 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:06 --> Total execution time: 0.0240
INFO - 2020-08-19 03:50:35 --> Config Class Initialized
INFO - 2020-08-19 03:50:35 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:35 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:35 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:35 --> URI Class Initialized
INFO - 2020-08-19 03:50:35 --> Router Class Initialized
INFO - 2020-08-19 03:50:35 --> Output Class Initialized
INFO - 2020-08-19 03:50:35 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:35 --> Input Class Initialized
INFO - 2020-08-19 03:50:35 --> Language Class Initialized
INFO - 2020-08-19 03:50:35 --> Loader Class Initialized
INFO - 2020-08-19 03:50:35 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:35 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:35 --> Email Class Initialized
INFO - 2020-08-19 03:50:35 --> Controller Class Initialized
DEBUG - 2020-08-19 03:50:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:50:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-19 03:50:35 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:35 --> Total execution time: 0.0223
INFO - 2020-08-19 03:50:37 --> Config Class Initialized
INFO - 2020-08-19 03:50:37 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:37 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:37 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:37 --> URI Class Initialized
INFO - 2020-08-19 03:50:37 --> Router Class Initialized
INFO - 2020-08-19 03:50:37 --> Output Class Initialized
INFO - 2020-08-19 03:50:37 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:37 --> Input Class Initialized
INFO - 2020-08-19 03:50:37 --> Language Class Initialized
INFO - 2020-08-19 03:50:37 --> Loader Class Initialized
INFO - 2020-08-19 03:50:37 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:37 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:37 --> Email Class Initialized
INFO - 2020-08-19 03:50:37 --> Controller Class Initialized
DEBUG - 2020-08-19 03:50:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:50:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:37 --> Model Class Initialized
INFO - 2020-08-19 03:50:37 --> Model Class Initialized
INFO - 2020-08-19 03:50:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-19 03:50:37 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:37 --> Total execution time: 0.0310
INFO - 2020-08-19 03:50:42 --> Config Class Initialized
INFO - 2020-08-19 03:50:42 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:42 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:42 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:42 --> URI Class Initialized
INFO - 2020-08-19 03:50:42 --> Router Class Initialized
INFO - 2020-08-19 03:50:42 --> Output Class Initialized
INFO - 2020-08-19 03:50:42 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:42 --> Input Class Initialized
INFO - 2020-08-19 03:50:42 --> Language Class Initialized
INFO - 2020-08-19 03:50:42 --> Loader Class Initialized
INFO - 2020-08-19 03:50:42 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:42 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:42 --> Email Class Initialized
INFO - 2020-08-19 03:50:42 --> Controller Class Initialized
DEBUG - 2020-08-19 03:50:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:50:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:42 --> Model Class Initialized
INFO - 2020-08-19 03:50:42 --> Model Class Initialized
INFO - 2020-08-19 03:50:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-19 03:50:42 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:42 --> Total execution time: 0.0219
INFO - 2020-08-19 03:50:44 --> Config Class Initialized
INFO - 2020-08-19 03:50:44 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:44 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:44 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:44 --> URI Class Initialized
INFO - 2020-08-19 03:50:44 --> Router Class Initialized
INFO - 2020-08-19 03:50:44 --> Output Class Initialized
INFO - 2020-08-19 03:50:44 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:44 --> Input Class Initialized
INFO - 2020-08-19 03:50:44 --> Language Class Initialized
INFO - 2020-08-19 03:50:44 --> Loader Class Initialized
INFO - 2020-08-19 03:50:44 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:44 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:44 --> Email Class Initialized
INFO - 2020-08-19 03:50:44 --> Controller Class Initialized
DEBUG - 2020-08-19 03:50:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:50:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:44 --> Model Class Initialized
INFO - 2020-08-19 03:50:44 --> Model Class Initialized
INFO - 2020-08-19 03:50:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-19 03:50:44 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:44 --> Total execution time: 0.0271
INFO - 2020-08-19 03:50:47 --> Config Class Initialized
INFO - 2020-08-19 03:50:47 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:47 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:47 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:47 --> URI Class Initialized
INFO - 2020-08-19 03:50:47 --> Router Class Initialized
INFO - 2020-08-19 03:50:47 --> Output Class Initialized
INFO - 2020-08-19 03:50:47 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:47 --> Input Class Initialized
INFO - 2020-08-19 03:50:47 --> Language Class Initialized
INFO - 2020-08-19 03:50:47 --> Loader Class Initialized
INFO - 2020-08-19 03:50:47 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:47 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:47 --> Email Class Initialized
INFO - 2020-08-19 03:50:47 --> Controller Class Initialized
DEBUG - 2020-08-19 03:50:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-19 03:50:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-19 03:50:47 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:47 --> Total execution time: 0.0217
INFO - 2020-08-19 03:50:55 --> Config Class Initialized
INFO - 2020-08-19 03:50:55 --> Hooks Class Initialized
DEBUG - 2020-08-19 03:50:55 --> UTF-8 Support Enabled
INFO - 2020-08-19 03:50:55 --> Utf8 Class Initialized
INFO - 2020-08-19 03:50:55 --> URI Class Initialized
DEBUG - 2020-08-19 03:50:55 --> No URI present. Default controller set.
INFO - 2020-08-19 03:50:55 --> Router Class Initialized
INFO - 2020-08-19 03:50:55 --> Output Class Initialized
INFO - 2020-08-19 03:50:55 --> Security Class Initialized
DEBUG - 2020-08-19 03:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 03:50:55 --> Input Class Initialized
INFO - 2020-08-19 03:50:55 --> Language Class Initialized
INFO - 2020-08-19 03:50:55 --> Loader Class Initialized
INFO - 2020-08-19 03:50:55 --> Helper loaded: url_helper
INFO - 2020-08-19 03:50:55 --> Database Driver Class Initialized
INFO - 2020-08-19 03:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 03:50:55 --> Email Class Initialized
INFO - 2020-08-19 03:50:55 --> Controller Class Initialized
INFO - 2020-08-19 03:50:55 --> Model Class Initialized
INFO - 2020-08-19 03:50:55 --> Model Class Initialized
DEBUG - 2020-08-19 03:50:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-19 03:50:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-19 03:50:55 --> Final output sent to browser
DEBUG - 2020-08-19 03:50:55 --> Total execution time: 0.0233
INFO - 2020-08-19 08:23:03 --> Config Class Initialized
INFO - 2020-08-19 08:23:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:23:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:23:03 --> Utf8 Class Initialized
INFO - 2020-08-19 08:23:03 --> URI Class Initialized
DEBUG - 2020-08-19 08:23:03 --> No URI present. Default controller set.
INFO - 2020-08-19 08:23:03 --> Router Class Initialized
INFO - 2020-08-19 08:23:03 --> Output Class Initialized
INFO - 2020-08-19 08:23:03 --> Security Class Initialized
DEBUG - 2020-08-19 08:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:23:03 --> Input Class Initialized
INFO - 2020-08-19 08:23:03 --> Language Class Initialized
INFO - 2020-08-19 08:23:03 --> Loader Class Initialized
INFO - 2020-08-19 08:23:03 --> Helper loaded: url_helper
INFO - 2020-08-19 08:23:03 --> Database Driver Class Initialized
INFO - 2020-08-19 08:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:23:03 --> Email Class Initialized
INFO - 2020-08-19 08:23:03 --> Controller Class Initialized
INFO - 2020-08-19 08:23:03 --> Model Class Initialized
INFO - 2020-08-19 08:23:03 --> Model Class Initialized
DEBUG - 2020-08-19 08:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-19 08:23:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-19 08:23:03 --> Final output sent to browser
DEBUG - 2020-08-19 08:23:03 --> Total execution time: 0.1422
INFO - 2020-08-19 08:23:04 --> Config Class Initialized
INFO - 2020-08-19 08:23:04 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:23:04 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:23:04 --> Utf8 Class Initialized
INFO - 2020-08-19 08:23:04 --> URI Class Initialized
DEBUG - 2020-08-19 08:23:04 --> No URI present. Default controller set.
INFO - 2020-08-19 08:23:04 --> Router Class Initialized
INFO - 2020-08-19 08:23:04 --> Output Class Initialized
INFO - 2020-08-19 08:23:04 --> Security Class Initialized
DEBUG - 2020-08-19 08:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:23:04 --> Input Class Initialized
INFO - 2020-08-19 08:23:04 --> Language Class Initialized
INFO - 2020-08-19 08:23:04 --> Loader Class Initialized
INFO - 2020-08-19 08:23:04 --> Helper loaded: url_helper
INFO - 2020-08-19 08:23:04 --> Database Driver Class Initialized
INFO - 2020-08-19 08:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:23:04 --> Email Class Initialized
INFO - 2020-08-19 08:23:04 --> Controller Class Initialized
INFO - 2020-08-19 08:23:04 --> Model Class Initialized
INFO - 2020-08-19 08:23:04 --> Model Class Initialized
DEBUG - 2020-08-19 08:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-19 08:23:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-19 08:23:04 --> Final output sent to browser
DEBUG - 2020-08-19 08:23:04 --> Total execution time: 0.0223
