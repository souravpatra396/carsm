<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-04 06:15:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:15:03 --> Config Class Initialized
INFO - 2020-11-04 06:15:03 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:15:03 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:15:03 --> Utf8 Class Initialized
INFO - 2020-11-04 06:15:03 --> URI Class Initialized
DEBUG - 2020-11-04 06:15:03 --> No URI present. Default controller set.
INFO - 2020-11-04 06:15:03 --> Router Class Initialized
INFO - 2020-11-04 06:15:03 --> Output Class Initialized
INFO - 2020-11-04 06:15:03 --> Security Class Initialized
DEBUG - 2020-11-04 06:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:15:03 --> Input Class Initialized
INFO - 2020-11-04 06:15:03 --> Language Class Initialized
INFO - 2020-11-04 06:15:03 --> Loader Class Initialized
INFO - 2020-11-04 06:15:03 --> Helper loaded: url_helper
INFO - 2020-11-04 06:15:03 --> Database Driver Class Initialized
INFO - 2020-11-04 06:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:15:03 --> Email Class Initialized
INFO - 2020-11-04 06:15:03 --> Controller Class Initialized
INFO - 2020-11-04 06:15:03 --> Model Class Initialized
INFO - 2020-11-04 06:15:03 --> Model Class Initialized
DEBUG - 2020-11-04 06:15:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:15:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:15:03 --> Final output sent to browser
DEBUG - 2020-11-04 06:15:03 --> Total execution time: 0.1919
ERROR - 2020-11-04 06:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:27:58 --> Config Class Initialized
INFO - 2020-11-04 06:27:58 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:27:58 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:27:58 --> Utf8 Class Initialized
INFO - 2020-11-04 06:27:58 --> URI Class Initialized
INFO - 2020-11-04 06:27:58 --> Router Class Initialized
INFO - 2020-11-04 06:27:58 --> Output Class Initialized
INFO - 2020-11-04 06:27:58 --> Security Class Initialized
DEBUG - 2020-11-04 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:27:58 --> Input Class Initialized
INFO - 2020-11-04 06:27:58 --> Language Class Initialized
INFO - 2020-11-04 06:27:58 --> Loader Class Initialized
INFO - 2020-11-04 06:27:58 --> Helper loaded: url_helper
INFO - 2020-11-04 06:27:58 --> Database Driver Class Initialized
ERROR - 2020-11-04 06:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:27:58 --> Config Class Initialized
INFO - 2020-11-04 06:27:58 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:27:58 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:27:58 --> Utf8 Class Initialized
INFO - 2020-11-04 06:27:58 --> URI Class Initialized
INFO - 2020-11-04 06:27:58 --> Router Class Initialized
INFO - 2020-11-04 06:27:58 --> Output Class Initialized
INFO - 2020-11-04 06:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:27:58 --> Security Class Initialized
DEBUG - 2020-11-04 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:27:58 --> Input Class Initialized
INFO - 2020-11-04 06:27:58 --> Language Class Initialized
INFO - 2020-11-04 06:27:58 --> Email Class Initialized
INFO - 2020-11-04 06:27:58 --> Controller Class Initialized
INFO - 2020-11-04 06:27:58 --> Model Class Initialized
INFO - 2020-11-04 06:27:58 --> Model Class Initialized
DEBUG - 2020-11-04 06:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:27:58 --> Loader Class Initialized
INFO - 2020-11-04 06:27:58 --> Helper loaded: url_helper
INFO - 2020-11-04 06:27:58 --> Database Driver Class Initialized
INFO - 2020-11-04 06:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:27:58 --> Email Class Initialized
INFO - 2020-11-04 06:27:58 --> Controller Class Initialized
INFO - 2020-11-04 06:27:58 --> Model Class Initialized
INFO - 2020-11-04 06:27:58 --> Model Class Initialized
DEBUG - 2020-11-04 06:27:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:27:58 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:27:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:27:58 --> Config Class Initialized
INFO - 2020-11-04 06:27:58 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:27:58 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:27:58 --> Utf8 Class Initialized
INFO - 2020-11-04 06:27:58 --> URI Class Initialized
DEBUG - 2020-11-04 06:27:58 --> No URI present. Default controller set.
INFO - 2020-11-04 06:27:58 --> Router Class Initialized
INFO - 2020-11-04 06:27:58 --> Output Class Initialized
INFO - 2020-11-04 06:27:58 --> Security Class Initialized
DEBUG - 2020-11-04 06:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:27:58 --> Input Class Initialized
INFO - 2020-11-04 06:27:58 --> Language Class Initialized
INFO - 2020-11-04 06:27:58 --> Loader Class Initialized
INFO - 2020-11-04 06:27:58 --> Helper loaded: url_helper
INFO - 2020-11-04 06:27:58 --> Database Driver Class Initialized
INFO - 2020-11-04 06:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:27:58 --> Email Class Initialized
INFO - 2020-11-04 06:27:58 --> Controller Class Initialized
INFO - 2020-11-04 06:27:58 --> Model Class Initialized
INFO - 2020-11-04 06:27:58 --> Model Class Initialized
DEBUG - 2020-11-04 06:27:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:27:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:27:58 --> Final output sent to browser
DEBUG - 2020-11-04 06:27:58 --> Total execution time: 0.0194
ERROR - 2020-11-04 06:27:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:27:59 --> Config Class Initialized
INFO - 2020-11-04 06:27:59 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:27:59 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:27:59 --> Utf8 Class Initialized
INFO - 2020-11-04 06:27:59 --> URI Class Initialized
DEBUG - 2020-11-04 06:27:59 --> No URI present. Default controller set.
INFO - 2020-11-04 06:27:59 --> Router Class Initialized
INFO - 2020-11-04 06:27:59 --> Output Class Initialized
INFO - 2020-11-04 06:27:59 --> Security Class Initialized
DEBUG - 2020-11-04 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:27:59 --> Input Class Initialized
INFO - 2020-11-04 06:27:59 --> Language Class Initialized
INFO - 2020-11-04 06:27:59 --> Loader Class Initialized
INFO - 2020-11-04 06:27:59 --> Helper loaded: url_helper
INFO - 2020-11-04 06:27:59 --> Database Driver Class Initialized
INFO - 2020-11-04 06:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:27:59 --> Email Class Initialized
INFO - 2020-11-04 06:27:59 --> Controller Class Initialized
INFO - 2020-11-04 06:27:59 --> Model Class Initialized
INFO - 2020-11-04 06:27:59 --> Model Class Initialized
DEBUG - 2020-11-04 06:27:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:27:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:27:59 --> Final output sent to browser
DEBUG - 2020-11-04 06:27:59 --> Total execution time: 0.0237
ERROR - 2020-11-04 06:28:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:16 --> Config Class Initialized
INFO - 2020-11-04 06:28:16 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:16 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:16 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:16 --> URI Class Initialized
INFO - 2020-11-04 06:28:16 --> Router Class Initialized
INFO - 2020-11-04 06:28:16 --> Output Class Initialized
INFO - 2020-11-04 06:28:16 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:16 --> Input Class Initialized
INFO - 2020-11-04 06:28:16 --> Language Class Initialized
INFO - 2020-11-04 06:28:16 --> Loader Class Initialized
INFO - 2020-11-04 06:28:16 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:16 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:16 --> Email Class Initialized
INFO - 2020-11-04 06:28:16 --> Controller Class Initialized
INFO - 2020-11-04 06:28:16 --> Model Class Initialized
INFO - 2020-11-04 06:28:16 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:28:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:16 --> Config Class Initialized
INFO - 2020-11-04 06:28:16 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:16 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:16 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:16 --> URI Class Initialized
INFO - 2020-11-04 06:28:16 --> Router Class Initialized
INFO - 2020-11-04 06:28:16 --> Output Class Initialized
INFO - 2020-11-04 06:28:16 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:16 --> Input Class Initialized
INFO - 2020-11-04 06:28:16 --> Language Class Initialized
INFO - 2020-11-04 06:28:16 --> Loader Class Initialized
INFO - 2020-11-04 06:28:16 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:16 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:16 --> Email Class Initialized
INFO - 2020-11-04 06:28:16 --> Controller Class Initialized
INFO - 2020-11-04 06:28:16 --> Model Class Initialized
INFO - 2020-11-04 06:28:16 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:28:16 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:28:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:16 --> Config Class Initialized
INFO - 2020-11-04 06:28:16 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:16 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:16 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:16 --> URI Class Initialized
INFO - 2020-11-04 06:28:16 --> Router Class Initialized
INFO - 2020-11-04 06:28:16 --> Output Class Initialized
INFO - 2020-11-04 06:28:16 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:16 --> Input Class Initialized
INFO - 2020-11-04 06:28:16 --> Language Class Initialized
INFO - 2020-11-04 06:28:16 --> Loader Class Initialized
INFO - 2020-11-04 06:28:16 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:16 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:16 --> Email Class Initialized
INFO - 2020-11-04 06:28:16 --> Controller Class Initialized
DEBUG - 2020-11-04 06:28:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:28:16 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:28:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:17 --> Config Class Initialized
INFO - 2020-11-04 06:28:17 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:17 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:17 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:17 --> URI Class Initialized
DEBUG - 2020-11-04 06:28:17 --> No URI present. Default controller set.
INFO - 2020-11-04 06:28:17 --> Router Class Initialized
INFO - 2020-11-04 06:28:17 --> Output Class Initialized
INFO - 2020-11-04 06:28:17 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:17 --> Input Class Initialized
INFO - 2020-11-04 06:28:17 --> Language Class Initialized
INFO - 2020-11-04 06:28:17 --> Loader Class Initialized
INFO - 2020-11-04 06:28:17 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:17 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:17 --> Email Class Initialized
INFO - 2020-11-04 06:28:17 --> Controller Class Initialized
INFO - 2020-11-04 06:28:17 --> Model Class Initialized
INFO - 2020-11-04 06:28:17 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:28:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:28:17 --> Final output sent to browser
DEBUG - 2020-11-04 06:28:17 --> Total execution time: 0.0225
ERROR - 2020-11-04 06:28:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:18 --> Config Class Initialized
INFO - 2020-11-04 06:28:18 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:18 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:18 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:18 --> URI Class Initialized
DEBUG - 2020-11-04 06:28:18 --> No URI present. Default controller set.
INFO - 2020-11-04 06:28:18 --> Router Class Initialized
INFO - 2020-11-04 06:28:18 --> Output Class Initialized
INFO - 2020-11-04 06:28:18 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:18 --> Input Class Initialized
INFO - 2020-11-04 06:28:18 --> Language Class Initialized
INFO - 2020-11-04 06:28:18 --> Loader Class Initialized
INFO - 2020-11-04 06:28:18 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:18 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:18 --> Email Class Initialized
INFO - 2020-11-04 06:28:18 --> Controller Class Initialized
INFO - 2020-11-04 06:28:18 --> Model Class Initialized
INFO - 2020-11-04 06:28:18 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:28:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:28:18 --> Final output sent to browser
DEBUG - 2020-11-04 06:28:18 --> Total execution time: 0.0214
ERROR - 2020-11-04 06:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:39 --> Config Class Initialized
INFO - 2020-11-04 06:28:39 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:39 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:39 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:39 --> URI Class Initialized
INFO - 2020-11-04 06:28:39 --> Router Class Initialized
INFO - 2020-11-04 06:28:39 --> Output Class Initialized
INFO - 2020-11-04 06:28:39 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:39 --> Input Class Initialized
INFO - 2020-11-04 06:28:39 --> Language Class Initialized
ERROR - 2020-11-04 06:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:39 --> Config Class Initialized
INFO - 2020-11-04 06:28:39 --> Hooks Class Initialized
INFO - 2020-11-04 06:28:39 --> Loader Class Initialized
INFO - 2020-11-04 06:28:39 --> Helper loaded: url_helper
DEBUG - 2020-11-04 06:28:39 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:39 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:39 --> URI Class Initialized
INFO - 2020-11-04 06:28:39 --> Router Class Initialized
INFO - 2020-11-04 06:28:39 --> Output Class Initialized
INFO - 2020-11-04 06:28:39 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:39 --> Input Class Initialized
INFO - 2020-11-04 06:28:39 --> Language Class Initialized
INFO - 2020-11-04 06:28:39 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:39 --> Loader Class Initialized
INFO - 2020-11-04 06:28:39 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:39 --> Email Class Initialized
INFO - 2020-11-04 06:28:39 --> Controller Class Initialized
INFO - 2020-11-04 06:28:39 --> Model Class Initialized
INFO - 2020-11-04 06:28:39 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:28:39 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:39 --> Email Class Initialized
INFO - 2020-11-04 06:28:39 --> Controller Class Initialized
INFO - 2020-11-04 06:28:39 --> Model Class Initialized
INFO - 2020-11-04 06:28:39 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:28:39 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:39 --> Config Class Initialized
INFO - 2020-11-04 06:28:39 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:39 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:39 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:39 --> URI Class Initialized
INFO - 2020-11-04 06:28:39 --> Router Class Initialized
INFO - 2020-11-04 06:28:39 --> Output Class Initialized
INFO - 2020-11-04 06:28:39 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:39 --> Input Class Initialized
INFO - 2020-11-04 06:28:39 --> Language Class Initialized
INFO - 2020-11-04 06:28:39 --> Loader Class Initialized
INFO - 2020-11-04 06:28:39 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:39 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:39 --> Email Class Initialized
INFO - 2020-11-04 06:28:39 --> Controller Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:28:39 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:39 --> Config Class Initialized
INFO - 2020-11-04 06:28:39 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:39 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:39 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:39 --> URI Class Initialized
DEBUG - 2020-11-04 06:28:39 --> No URI present. Default controller set.
INFO - 2020-11-04 06:28:39 --> Router Class Initialized
INFO - 2020-11-04 06:28:39 --> Output Class Initialized
INFO - 2020-11-04 06:28:39 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:39 --> Input Class Initialized
INFO - 2020-11-04 06:28:39 --> Language Class Initialized
INFO - 2020-11-04 06:28:39 --> Loader Class Initialized
INFO - 2020-11-04 06:28:39 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:39 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:39 --> Email Class Initialized
INFO - 2020-11-04 06:28:39 --> Controller Class Initialized
INFO - 2020-11-04 06:28:39 --> Model Class Initialized
INFO - 2020-11-04 06:28:39 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:28:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:28:39 --> Final output sent to browser
DEBUG - 2020-11-04 06:28:39 --> Total execution time: 0.0207
ERROR - 2020-11-04 06:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:28:40 --> Config Class Initialized
INFO - 2020-11-04 06:28:40 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:28:40 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:28:40 --> Utf8 Class Initialized
INFO - 2020-11-04 06:28:40 --> URI Class Initialized
DEBUG - 2020-11-04 06:28:40 --> No URI present. Default controller set.
INFO - 2020-11-04 06:28:40 --> Router Class Initialized
INFO - 2020-11-04 06:28:40 --> Output Class Initialized
INFO - 2020-11-04 06:28:40 --> Security Class Initialized
DEBUG - 2020-11-04 06:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:28:40 --> Input Class Initialized
INFO - 2020-11-04 06:28:40 --> Language Class Initialized
INFO - 2020-11-04 06:28:40 --> Loader Class Initialized
INFO - 2020-11-04 06:28:40 --> Helper loaded: url_helper
INFO - 2020-11-04 06:28:40 --> Database Driver Class Initialized
INFO - 2020-11-04 06:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:28:40 --> Email Class Initialized
INFO - 2020-11-04 06:28:40 --> Controller Class Initialized
INFO - 2020-11-04 06:28:40 --> Model Class Initialized
INFO - 2020-11-04 06:28:40 --> Model Class Initialized
DEBUG - 2020-11-04 06:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:28:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:28:40 --> Final output sent to browser
DEBUG - 2020-11-04 06:28:40 --> Total execution time: 0.0205
ERROR - 2020-11-04 06:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-11-04 06:29:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:40 --> Config Class Initialized
INFO - 2020-11-04 06:29:40 --> Hooks Class Initialized
INFO - 2020-11-04 06:29:40 --> Config Class Initialized
INFO - 2020-11-04 06:29:40 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:40 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:40 --> Utf8 Class Initialized
DEBUG - 2020-11-04 06:29:40 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:40 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:40 --> URI Class Initialized
INFO - 2020-11-04 06:29:40 --> URI Class Initialized
INFO - 2020-11-04 06:29:40 --> Router Class Initialized
INFO - 2020-11-04 06:29:40 --> Router Class Initialized
INFO - 2020-11-04 06:29:40 --> Output Class Initialized
INFO - 2020-11-04 06:29:40 --> Output Class Initialized
INFO - 2020-11-04 06:29:40 --> Security Class Initialized
INFO - 2020-11-04 06:29:40 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:40 --> Input Class Initialized
DEBUG - 2020-11-04 06:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:40 --> Input Class Initialized
INFO - 2020-11-04 06:29:40 --> Language Class Initialized
INFO - 2020-11-04 06:29:40 --> Language Class Initialized
INFO - 2020-11-04 06:29:40 --> Loader Class Initialized
INFO - 2020-11-04 06:29:40 --> Loader Class Initialized
INFO - 2020-11-04 06:29:40 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:40 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:40 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:40 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:40 --> Email Class Initialized
INFO - 2020-11-04 06:29:40 --> Controller Class Initialized
INFO - 2020-11-04 06:29:40 --> Model Class Initialized
INFO - 2020-11-04 06:29:40 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:40 --> Email Class Initialized
INFO - 2020-11-04 06:29:40 --> Controller Class Initialized
INFO - 2020-11-04 06:29:40 --> Model Class Initialized
INFO - 2020-11-04 06:29:40 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:29:40 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:41 --> Config Class Initialized
INFO - 2020-11-04 06:29:41 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:41 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:41 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:41 --> URI Class Initialized
DEBUG - 2020-11-04 06:29:41 --> No URI present. Default controller set.
INFO - 2020-11-04 06:29:41 --> Router Class Initialized
INFO - 2020-11-04 06:29:41 --> Output Class Initialized
INFO - 2020-11-04 06:29:41 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:41 --> Input Class Initialized
INFO - 2020-11-04 06:29:41 --> Language Class Initialized
INFO - 2020-11-04 06:29:41 --> Loader Class Initialized
INFO - 2020-11-04 06:29:41 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:41 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:41 --> Email Class Initialized
INFO - 2020-11-04 06:29:41 --> Controller Class Initialized
INFO - 2020-11-04 06:29:41 --> Model Class Initialized
INFO - 2020-11-04 06:29:41 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:29:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:29:41 --> Final output sent to browser
DEBUG - 2020-11-04 06:29:41 --> Total execution time: 0.0204
ERROR - 2020-11-04 06:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:41 --> Config Class Initialized
INFO - 2020-11-04 06:29:41 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:41 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:41 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:41 --> URI Class Initialized
INFO - 2020-11-04 06:29:41 --> Router Class Initialized
INFO - 2020-11-04 06:29:41 --> Output Class Initialized
INFO - 2020-11-04 06:29:41 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:41 --> Input Class Initialized
INFO - 2020-11-04 06:29:41 --> Language Class Initialized
INFO - 2020-11-04 06:29:41 --> Loader Class Initialized
INFO - 2020-11-04 06:29:41 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:41 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:41 --> Email Class Initialized
INFO - 2020-11-04 06:29:41 --> Controller Class Initialized
DEBUG - 2020-11-04 06:29:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:29:41 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:29:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:41 --> Config Class Initialized
INFO - 2020-11-04 06:29:41 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:41 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:41 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:41 --> URI Class Initialized
DEBUG - 2020-11-04 06:29:41 --> No URI present. Default controller set.
INFO - 2020-11-04 06:29:41 --> Router Class Initialized
INFO - 2020-11-04 06:29:41 --> Output Class Initialized
INFO - 2020-11-04 06:29:41 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:41 --> Input Class Initialized
INFO - 2020-11-04 06:29:41 --> Language Class Initialized
INFO - 2020-11-04 06:29:41 --> Loader Class Initialized
INFO - 2020-11-04 06:29:41 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:41 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:41 --> Email Class Initialized
INFO - 2020-11-04 06:29:41 --> Controller Class Initialized
INFO - 2020-11-04 06:29:41 --> Model Class Initialized
INFO - 2020-11-04 06:29:41 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:29:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:29:41 --> Final output sent to browser
DEBUG - 2020-11-04 06:29:41 --> Total execution time: 0.0216
ERROR - 2020-11-04 06:29:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:45 --> Config Class Initialized
INFO - 2020-11-04 06:29:45 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:45 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:45 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:45 --> URI Class Initialized
DEBUG - 2020-11-04 06:29:45 --> No URI present. Default controller set.
INFO - 2020-11-04 06:29:45 --> Router Class Initialized
INFO - 2020-11-04 06:29:45 --> Output Class Initialized
INFO - 2020-11-04 06:29:45 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:45 --> Input Class Initialized
INFO - 2020-11-04 06:29:45 --> Language Class Initialized
INFO - 2020-11-04 06:29:45 --> Loader Class Initialized
INFO - 2020-11-04 06:29:45 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:45 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:45 --> Email Class Initialized
INFO - 2020-11-04 06:29:45 --> Controller Class Initialized
INFO - 2020-11-04 06:29:45 --> Model Class Initialized
INFO - 2020-11-04 06:29:45 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:29:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:29:45 --> Final output sent to browser
DEBUG - 2020-11-04 06:29:45 --> Total execution time: 0.0224
ERROR - 2020-11-04 06:29:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:48 --> Config Class Initialized
INFO - 2020-11-04 06:29:48 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:48 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:48 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:48 --> URI Class Initialized
DEBUG - 2020-11-04 06:29:48 --> No URI present. Default controller set.
INFO - 2020-11-04 06:29:48 --> Router Class Initialized
INFO - 2020-11-04 06:29:48 --> Output Class Initialized
INFO - 2020-11-04 06:29:48 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:48 --> Input Class Initialized
INFO - 2020-11-04 06:29:48 --> Language Class Initialized
INFO - 2020-11-04 06:29:48 --> Loader Class Initialized
INFO - 2020-11-04 06:29:48 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:48 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:48 --> Email Class Initialized
INFO - 2020-11-04 06:29:48 --> Controller Class Initialized
INFO - 2020-11-04 06:29:48 --> Model Class Initialized
INFO - 2020-11-04 06:29:48 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:29:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:29:48 --> Final output sent to browser
DEBUG - 2020-11-04 06:29:48 --> Total execution time: 0.0218
ERROR - 2020-11-04 06:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:29:50 --> Config Class Initialized
INFO - 2020-11-04 06:29:50 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:29:50 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:29:50 --> Utf8 Class Initialized
INFO - 2020-11-04 06:29:50 --> URI Class Initialized
DEBUG - 2020-11-04 06:29:50 --> No URI present. Default controller set.
INFO - 2020-11-04 06:29:50 --> Router Class Initialized
INFO - 2020-11-04 06:29:50 --> Output Class Initialized
INFO - 2020-11-04 06:29:50 --> Security Class Initialized
DEBUG - 2020-11-04 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:29:50 --> Input Class Initialized
INFO - 2020-11-04 06:29:50 --> Language Class Initialized
INFO - 2020-11-04 06:29:50 --> Loader Class Initialized
INFO - 2020-11-04 06:29:50 --> Helper loaded: url_helper
INFO - 2020-11-04 06:29:50 --> Database Driver Class Initialized
INFO - 2020-11-04 06:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:29:50 --> Email Class Initialized
INFO - 2020-11-04 06:29:50 --> Controller Class Initialized
INFO - 2020-11-04 06:29:50 --> Model Class Initialized
INFO - 2020-11-04 06:29:50 --> Model Class Initialized
DEBUG - 2020-11-04 06:29:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:29:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 06:29:50 --> Final output sent to browser
DEBUG - 2020-11-04 06:29:50 --> Total execution time: 0.0224
ERROR - 2020-11-04 06:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:30:03 --> Config Class Initialized
INFO - 2020-11-04 06:30:03 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:30:03 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:30:03 --> Utf8 Class Initialized
INFO - 2020-11-04 06:30:03 --> URI Class Initialized
INFO - 2020-11-04 06:30:03 --> Router Class Initialized
INFO - 2020-11-04 06:30:03 --> Output Class Initialized
INFO - 2020-11-04 06:30:03 --> Security Class Initialized
DEBUG - 2020-11-04 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:30:03 --> Input Class Initialized
INFO - 2020-11-04 06:30:03 --> Language Class Initialized
INFO - 2020-11-04 06:30:03 --> Loader Class Initialized
INFO - 2020-11-04 06:30:03 --> Helper loaded: url_helper
INFO - 2020-11-04 06:30:03 --> Database Driver Class Initialized
INFO - 2020-11-04 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:30:03 --> Email Class Initialized
INFO - 2020-11-04 06:30:03 --> Controller Class Initialized
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
DEBUG - 2020-11-04 06:30:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:30:03 --> Config Class Initialized
INFO - 2020-11-04 06:30:03 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:30:03 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:30:03 --> Utf8 Class Initialized
INFO - 2020-11-04 06:30:03 --> URI Class Initialized
INFO - 2020-11-04 06:30:03 --> Router Class Initialized
INFO - 2020-11-04 06:30:03 --> Output Class Initialized
INFO - 2020-11-04 06:30:03 --> Security Class Initialized
DEBUG - 2020-11-04 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:30:03 --> Input Class Initialized
INFO - 2020-11-04 06:30:03 --> Language Class Initialized
INFO - 2020-11-04 06:30:03 --> Loader Class Initialized
INFO - 2020-11-04 06:30:03 --> Helper loaded: url_helper
INFO - 2020-11-04 06:30:03 --> Database Driver Class Initialized
INFO - 2020-11-04 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:30:03 --> Email Class Initialized
INFO - 2020-11-04 06:30:03 --> Controller Class Initialized
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
DEBUG - 2020-11-04 06:30:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:30:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
INFO - 2020-11-04 06:30:03 --> Final output sent to browser
DEBUG - 2020-11-04 06:30:03 --> Total execution time: 0.0235
ERROR - 2020-11-04 06:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:30:03 --> Config Class Initialized
INFO - 2020-11-04 06:30:03 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:30:03 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:30:03 --> Utf8 Class Initialized
INFO - 2020-11-04 06:30:03 --> URI Class Initialized
INFO - 2020-11-04 06:30:03 --> Router Class Initialized
INFO - 2020-11-04 06:30:03 --> Output Class Initialized
INFO - 2020-11-04 06:30:03 --> Security Class Initialized
DEBUG - 2020-11-04 06:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:30:03 --> Input Class Initialized
INFO - 2020-11-04 06:30:03 --> Language Class Initialized
INFO - 2020-11-04 06:30:03 --> Loader Class Initialized
INFO - 2020-11-04 06:30:03 --> Helper loaded: url_helper
INFO - 2020-11-04 06:30:03 --> Database Driver Class Initialized
INFO - 2020-11-04 06:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:30:03 --> Email Class Initialized
INFO - 2020-11-04 06:30:03 --> Controller Class Initialized
DEBUG - 2020-11-04 06:30:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:30:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
INFO - 2020-11-04 06:30:03 --> Model Class Initialized
INFO - 2020-11-04 06:30:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-04 06:30:03 --> Final output sent to browser
DEBUG - 2020-11-04 06:30:03 --> Total execution time: 0.0620
ERROR - 2020-11-04 06:30:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:30:12 --> Config Class Initialized
INFO - 2020-11-04 06:30:12 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:30:12 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:30:12 --> Utf8 Class Initialized
INFO - 2020-11-04 06:30:12 --> URI Class Initialized
INFO - 2020-11-04 06:30:12 --> Router Class Initialized
INFO - 2020-11-04 06:30:12 --> Output Class Initialized
INFO - 2020-11-04 06:30:12 --> Security Class Initialized
DEBUG - 2020-11-04 06:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:30:12 --> Input Class Initialized
INFO - 2020-11-04 06:30:12 --> Language Class Initialized
ERROR - 2020-11-04 06:30:12 --> Severity: Warning --> require(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:30:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 06:30:12 --> Severity: Compile Error --> require(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:30:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:30:44 --> Config Class Initialized
INFO - 2020-11-04 06:30:44 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:30:44 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:30:44 --> Utf8 Class Initialized
INFO - 2020-11-04 06:30:44 --> URI Class Initialized
INFO - 2020-11-04 06:30:44 --> Router Class Initialized
INFO - 2020-11-04 06:30:44 --> Output Class Initialized
INFO - 2020-11-04 06:30:44 --> Security Class Initialized
DEBUG - 2020-11-04 06:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:30:44 --> Input Class Initialized
INFO - 2020-11-04 06:30:44 --> Language Class Initialized
INFO - 2020-11-04 06:30:44 --> Loader Class Initialized
INFO - 2020-11-04 06:30:44 --> Helper loaded: url_helper
INFO - 2020-11-04 06:30:44 --> Database Driver Class Initialized
INFO - 2020-11-04 06:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:30:44 --> Email Class Initialized
INFO - 2020-11-04 06:30:44 --> Controller Class Initialized
DEBUG - 2020-11-04 06:30:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:30:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:30:44 --> Model Class Initialized
INFO - 2020-11-04 06:30:44 --> Model Class Initialized
INFO - 2020-11-04 06:30:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-04 06:30:44 --> Final output sent to browser
DEBUG - 2020-11-04 06:30:44 --> Total execution time: 0.0485
ERROR - 2020-11-04 06:33:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:33:17 --> Config Class Initialized
INFO - 2020-11-04 06:33:17 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:33:17 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:33:17 --> Utf8 Class Initialized
INFO - 2020-11-04 06:33:17 --> URI Class Initialized
INFO - 2020-11-04 06:33:17 --> Router Class Initialized
INFO - 2020-11-04 06:33:17 --> Output Class Initialized
INFO - 2020-11-04 06:33:17 --> Security Class Initialized
DEBUG - 2020-11-04 06:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:33:17 --> Input Class Initialized
INFO - 2020-11-04 06:33:17 --> Language Class Initialized
ERROR - 2020-11-04 06:33:17 --> Severity: Warning --> require(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:33:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 06:33:17 --> Severity: Compile Error --> require(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:33:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:33:52 --> Config Class Initialized
INFO - 2020-11-04 06:33:52 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:33:52 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:33:52 --> Utf8 Class Initialized
INFO - 2020-11-04 06:33:52 --> URI Class Initialized
INFO - 2020-11-04 06:33:52 --> Router Class Initialized
INFO - 2020-11-04 06:33:52 --> Output Class Initialized
INFO - 2020-11-04 06:33:52 --> Security Class Initialized
DEBUG - 2020-11-04 06:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:33:52 --> Input Class Initialized
INFO - 2020-11-04 06:33:52 --> Language Class Initialized
INFO - 2020-11-04 06:33:52 --> Loader Class Initialized
INFO - 2020-11-04 06:33:52 --> Helper loaded: url_helper
INFO - 2020-11-04 06:33:52 --> Database Driver Class Initialized
INFO - 2020-11-04 06:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:33:52 --> Email Class Initialized
INFO - 2020-11-04 06:33:52 --> Controller Class Initialized
DEBUG - 2020-11-04 06:33:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:33:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:33:52 --> Model Class Initialized
INFO - 2020-11-04 06:33:52 --> Model Class Initialized
INFO - 2020-11-04 06:33:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-04 06:33:52 --> Final output sent to browser
DEBUG - 2020-11-04 06:33:52 --> Total execution time: 0.0332
ERROR - 2020-11-04 06:36:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:36:04 --> Config Class Initialized
INFO - 2020-11-04 06:36:04 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:36:04 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:36:04 --> Utf8 Class Initialized
INFO - 2020-11-04 06:36:04 --> URI Class Initialized
INFO - 2020-11-04 06:36:04 --> Router Class Initialized
INFO - 2020-11-04 06:36:04 --> Output Class Initialized
INFO - 2020-11-04 06:36:04 --> Security Class Initialized
DEBUG - 2020-11-04 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:36:04 --> Input Class Initialized
INFO - 2020-11-04 06:36:04 --> Language Class Initialized
INFO - 2020-11-04 06:36:04 --> Loader Class Initialized
INFO - 2020-11-04 06:36:04 --> Helper loaded: url_helper
INFO - 2020-11-04 06:36:04 --> Database Driver Class Initialized
INFO - 2020-11-04 06:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:36:04 --> Email Class Initialized
INFO - 2020-11-04 06:36:04 --> Controller Class Initialized
DEBUG - 2020-11-04 06:36:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:36:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 06:36:04 --> Model Class Initialized
INFO - 2020-11-04 06:36:04 --> Model Class Initialized
INFO - 2020-11-04 06:36:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-04 06:36:04 --> Final output sent to browser
DEBUG - 2020-11-04 06:36:04 --> Total execution time: 0.0249
ERROR - 2020-11-04 06:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:36:07 --> Config Class Initialized
INFO - 2020-11-04 06:36:07 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:36:07 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:36:07 --> Utf8 Class Initialized
INFO - 2020-11-04 06:36:07 --> URI Class Initialized
INFO - 2020-11-04 06:36:07 --> Router Class Initialized
INFO - 2020-11-04 06:36:07 --> Output Class Initialized
INFO - 2020-11-04 06:36:07 --> Security Class Initialized
DEBUG - 2020-11-04 06:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:36:07 --> Input Class Initialized
INFO - 2020-11-04 06:36:07 --> Language Class Initialized
INFO - 2020-11-04 06:36:07 --> Loader Class Initialized
INFO - 2020-11-04 06:36:07 --> Helper loaded: url_helper
INFO - 2020-11-04 06:36:07 --> Database Driver Class Initialized
INFO - 2020-11-04 06:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:36:07 --> Email Class Initialized
INFO - 2020-11-04 06:36:07 --> Controller Class Initialized
DEBUG - 2020-11-04 06:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:36:07 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:36:07 --> Unable to load the requested class: Purlapi
ERROR - 2020-11-04 06:36:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:36:44 --> Config Class Initialized
INFO - 2020-11-04 06:36:44 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:36:44 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:36:44 --> Utf8 Class Initialized
INFO - 2020-11-04 06:36:44 --> URI Class Initialized
INFO - 2020-11-04 06:36:44 --> Router Class Initialized
INFO - 2020-11-04 06:36:44 --> Output Class Initialized
INFO - 2020-11-04 06:36:44 --> Security Class Initialized
DEBUG - 2020-11-04 06:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:36:44 --> Input Class Initialized
INFO - 2020-11-04 06:36:44 --> Language Class Initialized
INFO - 2020-11-04 06:36:44 --> Loader Class Initialized
INFO - 2020-11-04 06:36:44 --> Helper loaded: url_helper
INFO - 2020-11-04 06:36:44 --> Database Driver Class Initialized
INFO - 2020-11-04 06:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 06:36:44 --> Email Class Initialized
INFO - 2020-11-04 06:36:44 --> Controller Class Initialized
DEBUG - 2020-11-04 06:36:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 06:36:44 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 06:36:44 --> Unable to load the requested class: Purlem
ERROR - 2020-11-04 06:39:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:39:40 --> Config Class Initialized
INFO - 2020-11-04 06:39:40 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:39:40 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:39:40 --> Utf8 Class Initialized
INFO - 2020-11-04 06:39:40 --> URI Class Initialized
INFO - 2020-11-04 06:39:40 --> Router Class Initialized
INFO - 2020-11-04 06:39:40 --> Output Class Initialized
INFO - 2020-11-04 06:39:40 --> Security Class Initialized
DEBUG - 2020-11-04 06:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:39:40 --> Input Class Initialized
INFO - 2020-11-04 06:39:40 --> Language Class Initialized
ERROR - 2020-11-04 06:39:40 --> Severity: Warning --> require(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:39:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 06:39:40 --> Severity: Compile Error --> require(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:40:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:40:59 --> Config Class Initialized
INFO - 2020-11-04 06:40:59 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:40:59 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:40:59 --> Utf8 Class Initialized
INFO - 2020-11-04 06:40:59 --> URI Class Initialized
INFO - 2020-11-04 06:40:59 --> Router Class Initialized
INFO - 2020-11-04 06:40:59 --> Output Class Initialized
INFO - 2020-11-04 06:40:59 --> Security Class Initialized
DEBUG - 2020-11-04 06:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:40:59 --> Input Class Initialized
INFO - 2020-11-04 06:40:59 --> Language Class Initialized
ERROR - 2020-11-04 06:40:59 --> Severity: Warning --> require(/libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:40:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 06:40:59 --> Severity: Compile Error --> require(): Failed opening required '/libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:50:50 --> Config Class Initialized
INFO - 2020-11-04 06:50:50 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:50:50 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:50:50 --> Utf8 Class Initialized
INFO - 2020-11-04 06:50:50 --> URI Class Initialized
INFO - 2020-11-04 06:50:50 --> Router Class Initialized
INFO - 2020-11-04 06:50:50 --> Output Class Initialized
INFO - 2020-11-04 06:50:50 --> Security Class Initialized
DEBUG - 2020-11-04 06:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:50:50 --> Input Class Initialized
INFO - 2020-11-04 06:50:50 --> Language Class Initialized
ERROR - 2020-11-04 06:50:50 --> Severity: Warning --> require_once(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:50:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 06:50:50 --> Severity: Compile Error --> require_once(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 06:50:53 --> Config Class Initialized
INFO - 2020-11-04 06:50:53 --> Hooks Class Initialized
DEBUG - 2020-11-04 06:50:53 --> UTF-8 Support Enabled
INFO - 2020-11-04 06:50:53 --> Utf8 Class Initialized
INFO - 2020-11-04 06:50:53 --> URI Class Initialized
INFO - 2020-11-04 06:50:53 --> Router Class Initialized
INFO - 2020-11-04 06:50:53 --> Output Class Initialized
INFO - 2020-11-04 06:50:53 --> Security Class Initialized
DEBUG - 2020-11-04 06:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 06:50:53 --> Input Class Initialized
INFO - 2020-11-04 06:50:53 --> Language Class Initialized
ERROR - 2020-11-04 06:50:53 --> Severity: Warning --> require_once(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 06:50:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 06:50:53 --> Severity: Compile Error --> require_once(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 07:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:06:13 --> Config Class Initialized
INFO - 2020-11-04 07:06:13 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:06:13 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:06:13 --> Utf8 Class Initialized
INFO - 2020-11-04 07:06:13 --> URI Class Initialized
INFO - 2020-11-04 07:06:13 --> Router Class Initialized
INFO - 2020-11-04 07:06:13 --> Output Class Initialized
INFO - 2020-11-04 07:06:13 --> Security Class Initialized
DEBUG - 2020-11-04 07:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:06:13 --> Input Class Initialized
INFO - 2020-11-04 07:06:13 --> Language Class Initialized
ERROR - 2020-11-04 07:06:13 --> Severity: Warning --> require_once(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 07:06:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:06:13 --> Severity: Compile Error --> require_once(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 07:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:06:52 --> Config Class Initialized
INFO - 2020-11-04 07:06:52 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:06:52 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:06:52 --> Utf8 Class Initialized
INFO - 2020-11-04 07:06:52 --> URI Class Initialized
INFO - 2020-11-04 07:06:52 --> Router Class Initialized
INFO - 2020-11-04 07:06:52 --> Output Class Initialized
INFO - 2020-11-04 07:06:52 --> Security Class Initialized
DEBUG - 2020-11-04 07:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:06:52 --> Input Class Initialized
INFO - 2020-11-04 07:06:52 --> Language Class Initialized
ERROR - 2020-11-04 07:06:52 --> Severity: Warning --> require_once(/libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 07:06:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:06:52 --> Severity: Compile Error --> require_once(): Failed opening required '/libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 3
ERROR - 2020-11-04 07:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:10:16 --> Config Class Initialized
INFO - 2020-11-04 07:10:16 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:10:16 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:10:16 --> Utf8 Class Initialized
INFO - 2020-11-04 07:10:16 --> URI Class Initialized
INFO - 2020-11-04 07:10:16 --> Router Class Initialized
INFO - 2020-11-04 07:10:16 --> Output Class Initialized
INFO - 2020-11-04 07:10:16 --> Security Class Initialized
DEBUG - 2020-11-04 07:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:10:16 --> Input Class Initialized
INFO - 2020-11-04 07:10:16 --> Language Class Initialized
ERROR - 2020-11-04 07:10:16 --> Severity: Warning --> require_once(/../libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:10:16 --> Severity: Compile Error --> require_once(): Failed opening required '/../libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:10:33 --> Config Class Initialized
INFO - 2020-11-04 07:10:33 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:10:33 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:10:33 --> Utf8 Class Initialized
INFO - 2020-11-04 07:10:33 --> URI Class Initialized
INFO - 2020-11-04 07:10:33 --> Router Class Initialized
INFO - 2020-11-04 07:10:33 --> Output Class Initialized
INFO - 2020-11-04 07:10:33 --> Security Class Initialized
DEBUG - 2020-11-04 07:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:10:33 --> Input Class Initialized
INFO - 2020-11-04 07:10:33 --> Language Class Initialized
ERROR - 2020-11-04 07:10:33 --> Severity: Warning --> require_once(../libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:10:33 --> Severity: Compile Error --> require_once(): Failed opening required '../libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:10:50 --> Config Class Initialized
INFO - 2020-11-04 07:10:50 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:10:50 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:10:50 --> Utf8 Class Initialized
INFO - 2020-11-04 07:10:50 --> URI Class Initialized
INFO - 2020-11-04 07:10:50 --> Router Class Initialized
INFO - 2020-11-04 07:10:50 --> Output Class Initialized
INFO - 2020-11-04 07:10:50 --> Security Class Initialized
DEBUG - 2020-11-04 07:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:10:50 --> Input Class Initialized
INFO - 2020-11-04 07:10:50 --> Language Class Initialized
ERROR - 2020-11-04 07:10:50 --> Severity: Warning --> require_once(./libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:10:50 --> Severity: Compile Error --> require_once(): Failed opening required './libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:10:52 --> Config Class Initialized
INFO - 2020-11-04 07:10:52 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:10:52 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:10:52 --> Utf8 Class Initialized
INFO - 2020-11-04 07:10:52 --> URI Class Initialized
INFO - 2020-11-04 07:10:52 --> Router Class Initialized
INFO - 2020-11-04 07:10:52 --> Output Class Initialized
INFO - 2020-11-04 07:10:52 --> Security Class Initialized
DEBUG - 2020-11-04 07:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:10:52 --> Input Class Initialized
INFO - 2020-11-04 07:10:52 --> Language Class Initialized
ERROR - 2020-11-04 07:10:52 --> Severity: Warning --> require_once(./libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:10:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:10:52 --> Severity: Compile Error --> require_once(): Failed opening required './libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:12:30 --> Config Class Initialized
INFO - 2020-11-04 07:12:30 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:12:30 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:12:30 --> Utf8 Class Initialized
INFO - 2020-11-04 07:12:30 --> URI Class Initialized
INFO - 2020-11-04 07:12:30 --> Router Class Initialized
INFO - 2020-11-04 07:12:30 --> Output Class Initialized
INFO - 2020-11-04 07:12:30 --> Security Class Initialized
DEBUG - 2020-11-04 07:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:12:30 --> Input Class Initialized
INFO - 2020-11-04 07:12:30 --> Language Class Initialized
ERROR - 2020-11-04 07:12:30 --> Severity: Warning --> require_once(&lt;?php echo base_url();?&gt;/libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:12:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:12:30 --> Severity: Compile Error --> require_once(): Failed opening required '&lt;?php echo base_url();?&gt;/libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:12:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:12:52 --> Config Class Initialized
INFO - 2020-11-04 07:12:52 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:12:52 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:12:52 --> Utf8 Class Initialized
INFO - 2020-11-04 07:12:52 --> URI Class Initialized
INFO - 2020-11-04 07:12:52 --> Router Class Initialized
INFO - 2020-11-04 07:12:52 --> Output Class Initialized
INFO - 2020-11-04 07:12:52 --> Security Class Initialized
DEBUG - 2020-11-04 07:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:12:52 --> Input Class Initialized
INFO - 2020-11-04 07:12:52 --> Language Class Initialized
ERROR - 2020-11-04 07:12:52 --> Severity: Warning --> require_once(/libraries/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:12:52 --> Severity: Compile Error --> require_once(): Failed opening required '/libraries/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:16:14 --> Config Class Initialized
INFO - 2020-11-04 07:16:14 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:16:14 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:16:14 --> Utf8 Class Initialized
INFO - 2020-11-04 07:16:14 --> URI Class Initialized
INFO - 2020-11-04 07:16:14 --> Router Class Initialized
INFO - 2020-11-04 07:16:14 --> Output Class Initialized
INFO - 2020-11-04 07:16:14 --> Security Class Initialized
DEBUG - 2020-11-04 07:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:16:14 --> Input Class Initialized
INFO - 2020-11-04 07:16:14 --> Language Class Initialized
ERROR - 2020-11-04 07:16:14 --> Severity: Warning --> require_once(/path/to/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:16:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:16:14 --> Severity: Compile Error --> require_once(): Failed opening required '/path/to/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:16:31 --> Config Class Initialized
INFO - 2020-11-04 07:16:31 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:16:31 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:16:31 --> Utf8 Class Initialized
INFO - 2020-11-04 07:16:31 --> URI Class Initialized
INFO - 2020-11-04 07:16:31 --> Router Class Initialized
INFO - 2020-11-04 07:16:31 --> Output Class Initialized
INFO - 2020-11-04 07:16:31 --> Security Class Initialized
DEBUG - 2020-11-04 07:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:16:31 --> Input Class Initialized
INFO - 2020-11-04 07:16:31 --> Language Class Initialized
ERROR - 2020-11-04 07:16:31 --> Severity: Warning --> require_once(/path/purlapi.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:16:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-04 07:16:31 --> Severity: Compile Error --> require_once(): Failed opening required '/path/purlapi.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 4
ERROR - 2020-11-04 07:23:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:23:46 --> Config Class Initialized
INFO - 2020-11-04 07:23:46 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:23:46 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:23:46 --> Utf8 Class Initialized
INFO - 2020-11-04 07:23:46 --> URI Class Initialized
INFO - 2020-11-04 07:23:46 --> Router Class Initialized
INFO - 2020-11-04 07:23:46 --> Output Class Initialized
INFO - 2020-11-04 07:23:46 --> Security Class Initialized
DEBUG - 2020-11-04 07:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:23:46 --> Input Class Initialized
INFO - 2020-11-04 07:23:46 --> Language Class Initialized
INFO - 2020-11-04 07:23:46 --> Loader Class Initialized
INFO - 2020-11-04 07:23:46 --> Helper loaded: url_helper
INFO - 2020-11-04 07:23:46 --> Database Driver Class Initialized
INFO - 2020-11-04 07:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 07:23:46 --> Email Class Initialized
INFO - 2020-11-04 07:23:46 --> Controller Class Initialized
DEBUG - 2020-11-04 07:23:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 07:23:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 07:23:46 --> Model Class Initialized
INFO - 2020-11-04 07:23:46 --> Model Class Initialized
INFO - 2020-11-04 07:23:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-04 07:23:46 --> Final output sent to browser
DEBUG - 2020-11-04 07:23:46 --> Total execution time: 0.0240
ERROR - 2020-11-04 07:24:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:24:03 --> Config Class Initialized
INFO - 2020-11-04 07:24:03 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:24:03 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:24:03 --> Utf8 Class Initialized
INFO - 2020-11-04 07:24:03 --> URI Class Initialized
INFO - 2020-11-04 07:24:03 --> Router Class Initialized
INFO - 2020-11-04 07:24:03 --> Output Class Initialized
INFO - 2020-11-04 07:24:03 --> Security Class Initialized
DEBUG - 2020-11-04 07:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:24:03 --> Input Class Initialized
INFO - 2020-11-04 07:24:03 --> Language Class Initialized
INFO - 2020-11-04 07:24:03 --> Loader Class Initialized
INFO - 2020-11-04 07:24:03 --> Helper loaded: url_helper
INFO - 2020-11-04 07:24:03 --> Database Driver Class Initialized
INFO - 2020-11-04 07:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 07:24:03 --> Email Class Initialized
INFO - 2020-11-04 07:24:03 --> Controller Class Initialized
DEBUG - 2020-11-04 07:24:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 07:24:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 07:24:03 --> Model Class Initialized
INFO - 2020-11-04 07:24:03 --> Model Class Initialized
ERROR - 2020-11-04 07:24:03 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-04 07:24:03 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-04 07:24:04 --> Final output sent to browser
DEBUG - 2020-11-04 07:24:04 --> Total execution time: 1.2996
ERROR - 2020-11-04 07:27:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:27:09 --> Config Class Initialized
INFO - 2020-11-04 07:27:09 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:27:09 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:27:09 --> Utf8 Class Initialized
INFO - 2020-11-04 07:27:09 --> URI Class Initialized
INFO - 2020-11-04 07:27:09 --> Router Class Initialized
INFO - 2020-11-04 07:27:09 --> Output Class Initialized
INFO - 2020-11-04 07:27:09 --> Security Class Initialized
DEBUG - 2020-11-04 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:27:09 --> Input Class Initialized
INFO - 2020-11-04 07:27:09 --> Language Class Initialized
INFO - 2020-11-04 07:27:09 --> Loader Class Initialized
INFO - 2020-11-04 07:27:09 --> Helper loaded: url_helper
INFO - 2020-11-04 07:27:09 --> Database Driver Class Initialized
INFO - 2020-11-04 07:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 07:27:09 --> Email Class Initialized
INFO - 2020-11-04 07:27:09 --> Controller Class Initialized
DEBUG - 2020-11-04 07:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 07:27:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 07:27:09 --> Model Class Initialized
INFO - 2020-11-04 07:27:09 --> Model Class Initialized
INFO - 2020-11-04 07:27:09 --> Final output sent to browser
DEBUG - 2020-11-04 07:27:09 --> Total execution time: 0.0210
ERROR - 2020-11-04 07:27:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 07:27:13 --> Config Class Initialized
INFO - 2020-11-04 07:27:13 --> Hooks Class Initialized
DEBUG - 2020-11-04 07:27:13 --> UTF-8 Support Enabled
INFO - 2020-11-04 07:27:13 --> Utf8 Class Initialized
INFO - 2020-11-04 07:27:13 --> URI Class Initialized
INFO - 2020-11-04 07:27:13 --> Router Class Initialized
INFO - 2020-11-04 07:27:13 --> Output Class Initialized
INFO - 2020-11-04 07:27:13 --> Security Class Initialized
DEBUG - 2020-11-04 07:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 07:27:13 --> Input Class Initialized
INFO - 2020-11-04 07:27:13 --> Language Class Initialized
INFO - 2020-11-04 07:27:13 --> Loader Class Initialized
INFO - 2020-11-04 07:27:13 --> Helper loaded: url_helper
INFO - 2020-11-04 07:27:13 --> Database Driver Class Initialized
INFO - 2020-11-04 07:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 07:27:13 --> Email Class Initialized
INFO - 2020-11-04 07:27:13 --> Controller Class Initialized
DEBUG - 2020-11-04 07:27:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 07:27:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 07:27:13 --> Model Class Initialized
INFO - 2020-11-04 07:27:13 --> Model Class Initialized
INFO - 2020-11-04 07:27:13 --> Final output sent to browser
DEBUG - 2020-11-04 07:27:13 --> Total execution time: 0.0222
ERROR - 2020-11-04 08:03:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 08:03:04 --> Config Class Initialized
INFO - 2020-11-04 08:03:04 --> Hooks Class Initialized
DEBUG - 2020-11-04 08:03:04 --> UTF-8 Support Enabled
INFO - 2020-11-04 08:03:04 --> Utf8 Class Initialized
INFO - 2020-11-04 08:03:04 --> URI Class Initialized
DEBUG - 2020-11-04 08:03:04 --> No URI present. Default controller set.
INFO - 2020-11-04 08:03:04 --> Router Class Initialized
INFO - 2020-11-04 08:03:04 --> Output Class Initialized
INFO - 2020-11-04 08:03:04 --> Security Class Initialized
DEBUG - 2020-11-04 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 08:03:04 --> Input Class Initialized
INFO - 2020-11-04 08:03:04 --> Language Class Initialized
INFO - 2020-11-04 08:03:04 --> Loader Class Initialized
INFO - 2020-11-04 08:03:04 --> Helper loaded: url_helper
INFO - 2020-11-04 08:03:04 --> Database Driver Class Initialized
INFO - 2020-11-04 08:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 08:03:04 --> Email Class Initialized
INFO - 2020-11-04 08:03:04 --> Controller Class Initialized
INFO - 2020-11-04 08:03:04 --> Model Class Initialized
INFO - 2020-11-04 08:03:04 --> Model Class Initialized
DEBUG - 2020-11-04 08:03:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 08:03:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 08:03:04 --> Final output sent to browser
DEBUG - 2020-11-04 08:03:04 --> Total execution time: 0.0222
ERROR - 2020-11-04 08:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 08:03:22 --> Config Class Initialized
INFO - 2020-11-04 08:03:22 --> Hooks Class Initialized
DEBUG - 2020-11-04 08:03:22 --> UTF-8 Support Enabled
INFO - 2020-11-04 08:03:22 --> Utf8 Class Initialized
INFO - 2020-11-04 08:03:22 --> URI Class Initialized
INFO - 2020-11-04 08:03:22 --> Router Class Initialized
INFO - 2020-11-04 08:03:22 --> Output Class Initialized
INFO - 2020-11-04 08:03:22 --> Security Class Initialized
DEBUG - 2020-11-04 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 08:03:22 --> Input Class Initialized
INFO - 2020-11-04 08:03:22 --> Language Class Initialized
INFO - 2020-11-04 08:03:22 --> Loader Class Initialized
INFO - 2020-11-04 08:03:22 --> Helper loaded: url_helper
INFO - 2020-11-04 08:03:22 --> Database Driver Class Initialized
INFO - 2020-11-04 08:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 08:03:22 --> Email Class Initialized
INFO - 2020-11-04 08:03:22 --> Controller Class Initialized
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
DEBUG - 2020-11-04 08:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 08:03:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
INFO - 2020-11-04 08:03:22 --> Final output sent to browser
DEBUG - 2020-11-04 08:03:22 --> Total execution time: 0.0226
ERROR - 2020-11-04 08:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 08:03:22 --> Config Class Initialized
INFO - 2020-11-04 08:03:22 --> Hooks Class Initialized
DEBUG - 2020-11-04 08:03:22 --> UTF-8 Support Enabled
INFO - 2020-11-04 08:03:22 --> Utf8 Class Initialized
INFO - 2020-11-04 08:03:22 --> URI Class Initialized
INFO - 2020-11-04 08:03:22 --> Router Class Initialized
INFO - 2020-11-04 08:03:22 --> Output Class Initialized
INFO - 2020-11-04 08:03:22 --> Security Class Initialized
DEBUG - 2020-11-04 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 08:03:22 --> Input Class Initialized
INFO - 2020-11-04 08:03:22 --> Language Class Initialized
INFO - 2020-11-04 08:03:22 --> Loader Class Initialized
INFO - 2020-11-04 08:03:22 --> Helper loaded: url_helper
INFO - 2020-11-04 08:03:22 --> Database Driver Class Initialized
INFO - 2020-11-04 08:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 08:03:22 --> Email Class Initialized
INFO - 2020-11-04 08:03:22 --> Controller Class Initialized
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
DEBUG - 2020-11-04 08:03:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-04 08:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 08:03:22 --> Config Class Initialized
INFO - 2020-11-04 08:03:22 --> Hooks Class Initialized
DEBUG - 2020-11-04 08:03:22 --> UTF-8 Support Enabled
INFO - 2020-11-04 08:03:22 --> Utf8 Class Initialized
INFO - 2020-11-04 08:03:22 --> URI Class Initialized
INFO - 2020-11-04 08:03:22 --> Router Class Initialized
INFO - 2020-11-04 08:03:22 --> Output Class Initialized
INFO - 2020-11-04 08:03:22 --> Security Class Initialized
DEBUG - 2020-11-04 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 08:03:22 --> Input Class Initialized
INFO - 2020-11-04 08:03:22 --> Language Class Initialized
INFO - 2020-11-04 08:03:22 --> Loader Class Initialized
INFO - 2020-11-04 08:03:22 --> Helper loaded: url_helper
INFO - 2020-11-04 08:03:22 --> Database Driver Class Initialized
INFO - 2020-11-04 08:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 08:03:22 --> Email Class Initialized
INFO - 2020-11-04 08:03:22 --> Controller Class Initialized
DEBUG - 2020-11-04 08:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 08:03:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
INFO - 2020-11-04 08:03:22 --> Model Class Initialized
INFO - 2020-11-04 08:03:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-04 08:03:22 --> Final output sent to browser
DEBUG - 2020-11-04 08:03:22 --> Total execution time: 0.0276
ERROR - 2020-11-04 08:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 08:03:29 --> Config Class Initialized
INFO - 2020-11-04 08:03:29 --> Hooks Class Initialized
DEBUG - 2020-11-04 08:03:29 --> UTF-8 Support Enabled
INFO - 2020-11-04 08:03:29 --> Utf8 Class Initialized
INFO - 2020-11-04 08:03:29 --> URI Class Initialized
INFO - 2020-11-04 08:03:29 --> Router Class Initialized
INFO - 2020-11-04 08:03:29 --> Output Class Initialized
INFO - 2020-11-04 08:03:29 --> Security Class Initialized
DEBUG - 2020-11-04 08:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 08:03:29 --> Input Class Initialized
INFO - 2020-11-04 08:03:29 --> Language Class Initialized
INFO - 2020-11-04 08:03:29 --> Loader Class Initialized
INFO - 2020-11-04 08:03:29 --> Helper loaded: url_helper
INFO - 2020-11-04 08:03:29 --> Database Driver Class Initialized
INFO - 2020-11-04 08:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 08:03:29 --> Email Class Initialized
INFO - 2020-11-04 08:03:29 --> Controller Class Initialized
DEBUG - 2020-11-04 08:03:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 08:03:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 08:03:29 --> Model Class Initialized
INFO - 2020-11-04 08:03:29 --> Model Class Initialized
INFO - 2020-11-04 08:03:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-04 08:03:29 --> Final output sent to browser
DEBUG - 2020-11-04 08:03:29 --> Total execution time: 0.0224
ERROR - 2020-11-04 08:03:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 08:03:43 --> Config Class Initialized
INFO - 2020-11-04 08:03:43 --> Hooks Class Initialized
DEBUG - 2020-11-04 08:03:43 --> UTF-8 Support Enabled
INFO - 2020-11-04 08:03:43 --> Utf8 Class Initialized
INFO - 2020-11-04 08:03:43 --> URI Class Initialized
INFO - 2020-11-04 08:03:43 --> Router Class Initialized
INFO - 2020-11-04 08:03:43 --> Output Class Initialized
INFO - 2020-11-04 08:03:43 --> Security Class Initialized
DEBUG - 2020-11-04 08:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 08:03:43 --> Input Class Initialized
INFO - 2020-11-04 08:03:43 --> Language Class Initialized
INFO - 2020-11-04 08:03:43 --> Loader Class Initialized
INFO - 2020-11-04 08:03:43 --> Helper loaded: url_helper
INFO - 2020-11-04 08:03:43 --> Database Driver Class Initialized
INFO - 2020-11-04 08:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 08:03:43 --> Email Class Initialized
INFO - 2020-11-04 08:03:43 --> Controller Class Initialized
DEBUG - 2020-11-04 08:03:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 08:03:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 08:03:43 --> Model Class Initialized
INFO - 2020-11-04 08:03:43 --> Model Class Initialized
ERROR - 2020-11-04 08:03:43 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-04 08:03:43 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-04 08:03:45 --> Final output sent to browser
DEBUG - 2020-11-04 08:03:45 --> Total execution time: 2.8209
ERROR - 2020-11-04 09:00:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 09:00:27 --> Config Class Initialized
INFO - 2020-11-04 09:00:27 --> Hooks Class Initialized
DEBUG - 2020-11-04 09:00:27 --> UTF-8 Support Enabled
INFO - 2020-11-04 09:00:27 --> Utf8 Class Initialized
INFO - 2020-11-04 09:00:27 --> URI Class Initialized
INFO - 2020-11-04 09:00:27 --> Router Class Initialized
INFO - 2020-11-04 09:00:27 --> Output Class Initialized
INFO - 2020-11-04 09:00:27 --> Security Class Initialized
DEBUG - 2020-11-04 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 09:00:27 --> Input Class Initialized
INFO - 2020-11-04 09:00:27 --> Language Class Initialized
INFO - 2020-11-04 09:00:27 --> Loader Class Initialized
INFO - 2020-11-04 09:00:27 --> Helper loaded: url_helper
INFO - 2020-11-04 09:00:27 --> Database Driver Class Initialized
INFO - 2020-11-04 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 09:00:27 --> Email Class Initialized
INFO - 2020-11-04 09:00:27 --> Controller Class Initialized
DEBUG - 2020-11-04 09:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 09:00:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-04 09:00:27 --> Model Class Initialized
INFO - 2020-11-04 09:00:27 --> Model Class Initialized
ERROR - 2020-11-04 09:00:27 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-04 09:00:27 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-04 09:00:29 --> Final output sent to browser
DEBUG - 2020-11-04 09:00:29 --> Total execution time: 1.2885
ERROR - 2020-11-04 10:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 10:03:38 --> Config Class Initialized
INFO - 2020-11-04 10:03:38 --> Hooks Class Initialized
DEBUG - 2020-11-04 10:03:38 --> UTF-8 Support Enabled
INFO - 2020-11-04 10:03:38 --> Utf8 Class Initialized
INFO - 2020-11-04 10:03:38 --> URI Class Initialized
INFO - 2020-11-04 10:03:38 --> Router Class Initialized
INFO - 2020-11-04 10:03:38 --> Output Class Initialized
INFO - 2020-11-04 10:03:38 --> Security Class Initialized
DEBUG - 2020-11-04 10:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 10:03:38 --> Input Class Initialized
INFO - 2020-11-04 10:03:38 --> Language Class Initialized
INFO - 2020-11-04 10:03:38 --> Loader Class Initialized
INFO - 2020-11-04 10:03:38 --> Helper loaded: url_helper
INFO - 2020-11-04 10:03:38 --> Database Driver Class Initialized
INFO - 2020-11-04 10:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 10:03:38 --> Email Class Initialized
INFO - 2020-11-04 10:03:38 --> Controller Class Initialized
DEBUG - 2020-11-04 10:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-04 10:03:38 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-04 10:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-04 10:03:38 --> Config Class Initialized
INFO - 2020-11-04 10:03:38 --> Hooks Class Initialized
DEBUG - 2020-11-04 10:03:38 --> UTF-8 Support Enabled
INFO - 2020-11-04 10:03:38 --> Utf8 Class Initialized
INFO - 2020-11-04 10:03:38 --> URI Class Initialized
DEBUG - 2020-11-04 10:03:38 --> No URI present. Default controller set.
INFO - 2020-11-04 10:03:38 --> Router Class Initialized
INFO - 2020-11-04 10:03:38 --> Output Class Initialized
INFO - 2020-11-04 10:03:38 --> Security Class Initialized
DEBUG - 2020-11-04 10:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-04 10:03:38 --> Input Class Initialized
INFO - 2020-11-04 10:03:38 --> Language Class Initialized
INFO - 2020-11-04 10:03:38 --> Loader Class Initialized
INFO - 2020-11-04 10:03:38 --> Helper loaded: url_helper
INFO - 2020-11-04 10:03:38 --> Database Driver Class Initialized
INFO - 2020-11-04 10:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-04 10:03:38 --> Email Class Initialized
INFO - 2020-11-04 10:03:38 --> Controller Class Initialized
INFO - 2020-11-04 10:03:38 --> Model Class Initialized
INFO - 2020-11-04 10:03:38 --> Model Class Initialized
DEBUG - 2020-11-04 10:03:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-04 10:03:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-04 10:03:38 --> Final output sent to browser
DEBUG - 2020-11-04 10:03:38 --> Total execution time: 0.0219
