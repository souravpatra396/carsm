<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-12 10:31:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:31:07 --> Config Class Initialized
INFO - 2020-10-12 10:31:07 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:31:07 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:31:07 --> Utf8 Class Initialized
INFO - 2020-10-12 10:31:07 --> URI Class Initialized
DEBUG - 2020-10-12 10:31:07 --> No URI present. Default controller set.
INFO - 2020-10-12 10:31:07 --> Router Class Initialized
INFO - 2020-10-12 10:31:07 --> Output Class Initialized
INFO - 2020-10-12 10:31:07 --> Security Class Initialized
DEBUG - 2020-10-12 10:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:31:07 --> Input Class Initialized
INFO - 2020-10-12 10:31:07 --> Language Class Initialized
INFO - 2020-10-12 10:31:07 --> Loader Class Initialized
INFO - 2020-10-12 10:31:07 --> Helper loaded: url_helper
INFO - 2020-10-12 10:31:07 --> Database Driver Class Initialized
INFO - 2020-10-12 10:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:31:07 --> Email Class Initialized
INFO - 2020-10-12 10:31:07 --> Controller Class Initialized
INFO - 2020-10-12 10:31:07 --> Model Class Initialized
INFO - 2020-10-12 10:31:07 --> Model Class Initialized
DEBUG - 2020-10-12 10:31:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:31:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:31:07 --> Final output sent to browser
DEBUG - 2020-10-12 10:31:07 --> Total execution time: 0.1971
ERROR - 2020-10-12 10:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:31:27 --> Config Class Initialized
INFO - 2020-10-12 10:31:27 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:31:27 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:31:27 --> Utf8 Class Initialized
INFO - 2020-10-12 10:31:27 --> URI Class Initialized
DEBUG - 2020-10-12 10:31:27 --> No URI present. Default controller set.
INFO - 2020-10-12 10:31:27 --> Router Class Initialized
INFO - 2020-10-12 10:31:27 --> Output Class Initialized
INFO - 2020-10-12 10:31:27 --> Security Class Initialized
DEBUG - 2020-10-12 10:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:31:27 --> Input Class Initialized
INFO - 2020-10-12 10:31:27 --> Language Class Initialized
INFO - 2020-10-12 10:31:27 --> Loader Class Initialized
INFO - 2020-10-12 10:31:27 --> Helper loaded: url_helper
INFO - 2020-10-12 10:31:27 --> Database Driver Class Initialized
INFO - 2020-10-12 10:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:31:27 --> Email Class Initialized
INFO - 2020-10-12 10:31:27 --> Controller Class Initialized
INFO - 2020-10-12 10:31:27 --> Model Class Initialized
INFO - 2020-10-12 10:31:27 --> Model Class Initialized
DEBUG - 2020-10-12 10:31:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:31:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:31:27 --> Final output sent to browser
DEBUG - 2020-10-12 10:31:27 --> Total execution time: 0.0214
ERROR - 2020-10-12 10:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:31:42 --> Config Class Initialized
INFO - 2020-10-12 10:31:42 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:31:42 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:31:42 --> Utf8 Class Initialized
INFO - 2020-10-12 10:31:42 --> URI Class Initialized
DEBUG - 2020-10-12 10:31:42 --> No URI present. Default controller set.
INFO - 2020-10-12 10:31:42 --> Router Class Initialized
INFO - 2020-10-12 10:31:42 --> Output Class Initialized
INFO - 2020-10-12 10:31:42 --> Security Class Initialized
DEBUG - 2020-10-12 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:31:42 --> Input Class Initialized
INFO - 2020-10-12 10:31:42 --> Language Class Initialized
INFO - 2020-10-12 10:31:42 --> Loader Class Initialized
INFO - 2020-10-12 10:31:42 --> Helper loaded: url_helper
INFO - 2020-10-12 10:31:42 --> Database Driver Class Initialized
INFO - 2020-10-12 10:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:31:42 --> Email Class Initialized
INFO - 2020-10-12 10:31:42 --> Controller Class Initialized
INFO - 2020-10-12 10:31:42 --> Model Class Initialized
INFO - 2020-10-12 10:31:42 --> Model Class Initialized
DEBUG - 2020-10-12 10:31:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:31:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:31:42 --> Final output sent to browser
DEBUG - 2020-10-12 10:31:42 --> Total execution time: 0.0211
ERROR - 2020-10-12 10:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:31:43 --> Config Class Initialized
INFO - 2020-10-12 10:31:43 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:31:43 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:31:43 --> Utf8 Class Initialized
INFO - 2020-10-12 10:31:43 --> URI Class Initialized
DEBUG - 2020-10-12 10:31:43 --> No URI present. Default controller set.
INFO - 2020-10-12 10:31:43 --> Router Class Initialized
INFO - 2020-10-12 10:31:43 --> Output Class Initialized
INFO - 2020-10-12 10:31:43 --> Security Class Initialized
DEBUG - 2020-10-12 10:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:31:43 --> Input Class Initialized
INFO - 2020-10-12 10:31:43 --> Language Class Initialized
INFO - 2020-10-12 10:31:43 --> Loader Class Initialized
INFO - 2020-10-12 10:31:43 --> Helper loaded: url_helper
INFO - 2020-10-12 10:31:43 --> Database Driver Class Initialized
INFO - 2020-10-12 10:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:31:43 --> Email Class Initialized
INFO - 2020-10-12 10:31:43 --> Controller Class Initialized
INFO - 2020-10-12 10:31:43 --> Model Class Initialized
INFO - 2020-10-12 10:31:43 --> Model Class Initialized
DEBUG - 2020-10-12 10:31:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:31:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:31:43 --> Final output sent to browser
DEBUG - 2020-10-12 10:31:43 --> Total execution time: 0.0216
ERROR - 2020-10-12 10:32:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:32:54 --> Config Class Initialized
INFO - 2020-10-12 10:32:54 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:32:54 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:32:54 --> Utf8 Class Initialized
INFO - 2020-10-12 10:32:54 --> URI Class Initialized
DEBUG - 2020-10-12 10:32:54 --> No URI present. Default controller set.
INFO - 2020-10-12 10:32:54 --> Router Class Initialized
INFO - 2020-10-12 10:32:54 --> Output Class Initialized
INFO - 2020-10-12 10:32:54 --> Security Class Initialized
DEBUG - 2020-10-12 10:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:32:54 --> Input Class Initialized
INFO - 2020-10-12 10:32:54 --> Language Class Initialized
INFO - 2020-10-12 10:32:54 --> Loader Class Initialized
INFO - 2020-10-12 10:32:54 --> Helper loaded: url_helper
INFO - 2020-10-12 10:32:54 --> Database Driver Class Initialized
INFO - 2020-10-12 10:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:32:54 --> Email Class Initialized
INFO - 2020-10-12 10:32:54 --> Controller Class Initialized
INFO - 2020-10-12 10:32:54 --> Model Class Initialized
INFO - 2020-10-12 10:32:54 --> Model Class Initialized
DEBUG - 2020-10-12 10:32:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:32:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:32:54 --> Final output sent to browser
DEBUG - 2020-10-12 10:32:54 --> Total execution time: 0.0199
ERROR - 2020-10-12 10:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:22 --> Config Class Initialized
INFO - 2020-10-12 10:34:22 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:22 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:22 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:22 --> URI Class Initialized
INFO - 2020-10-12 10:34:22 --> Router Class Initialized
INFO - 2020-10-12 10:34:22 --> Output Class Initialized
INFO - 2020-10-12 10:34:22 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:22 --> Input Class Initialized
INFO - 2020-10-12 10:34:22 --> Language Class Initialized
INFO - 2020-10-12 10:34:22 --> Loader Class Initialized
INFO - 2020-10-12 10:34:22 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:22 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:22 --> Email Class Initialized
INFO - 2020-10-12 10:34:22 --> Controller Class Initialized
INFO - 2020-10-12 10:34:22 --> Model Class Initialized
INFO - 2020-10-12 10:34:22 --> Model Class Initialized
DEBUG - 2020-10-12 10:34:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 10:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:22 --> Config Class Initialized
INFO - 2020-10-12 10:34:22 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:22 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:22 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:22 --> URI Class Initialized
INFO - 2020-10-12 10:34:22 --> Router Class Initialized
INFO - 2020-10-12 10:34:22 --> Output Class Initialized
INFO - 2020-10-12 10:34:22 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:22 --> Input Class Initialized
INFO - 2020-10-12 10:34:22 --> Language Class Initialized
INFO - 2020-10-12 10:34:22 --> Loader Class Initialized
INFO - 2020-10-12 10:34:22 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:22 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:22 --> Email Class Initialized
INFO - 2020-10-12 10:34:22 --> Controller Class Initialized
INFO - 2020-10-12 10:34:22 --> Model Class Initialized
INFO - 2020-10-12 10:34:22 --> Model Class Initialized
DEBUG - 2020-10-12 10:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:34:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:34:22 --> Model Class Initialized
INFO - 2020-10-12 10:34:22 --> Final output sent to browser
DEBUG - 2020-10-12 10:34:22 --> Total execution time: 0.0408
ERROR - 2020-10-12 10:34:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:23 --> Config Class Initialized
INFO - 2020-10-12 10:34:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:23 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:23 --> URI Class Initialized
INFO - 2020-10-12 10:34:23 --> Router Class Initialized
INFO - 2020-10-12 10:34:23 --> Output Class Initialized
INFO - 2020-10-12 10:34:23 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:23 --> Input Class Initialized
INFO - 2020-10-12 10:34:23 --> Language Class Initialized
INFO - 2020-10-12 10:34:23 --> Loader Class Initialized
INFO - 2020-10-12 10:34:23 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:23 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:23 --> Email Class Initialized
INFO - 2020-10-12 10:34:23 --> Controller Class Initialized
DEBUG - 2020-10-12 10:34:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:34:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:34:23 --> Model Class Initialized
INFO - 2020-10-12 10:34:23 --> Model Class Initialized
INFO - 2020-10-12 10:34:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-12 10:34:23 --> Final output sent to browser
DEBUG - 2020-10-12 10:34:23 --> Total execution time: 0.0841
ERROR - 2020-10-12 10:34:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:30 --> Config Class Initialized
INFO - 2020-10-12 10:34:30 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:30 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:30 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:30 --> URI Class Initialized
INFO - 2020-10-12 10:34:30 --> Router Class Initialized
INFO - 2020-10-12 10:34:30 --> Output Class Initialized
INFO - 2020-10-12 10:34:30 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:30 --> Input Class Initialized
INFO - 2020-10-12 10:34:30 --> Language Class Initialized
INFO - 2020-10-12 10:34:30 --> Loader Class Initialized
INFO - 2020-10-12 10:34:30 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:30 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:30 --> Email Class Initialized
INFO - 2020-10-12 10:34:30 --> Controller Class Initialized
DEBUG - 2020-10-12 10:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:34:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:34:30 --> Model Class Initialized
INFO - 2020-10-12 10:34:30 --> Model Class Initialized
INFO - 2020-10-12 10:34:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 10:34:30 --> Final output sent to browser
DEBUG - 2020-10-12 10:34:30 --> Total execution time: 0.0253
ERROR - 2020-10-12 10:34:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:42 --> Config Class Initialized
INFO - 2020-10-12 10:34:42 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:42 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:42 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:42 --> URI Class Initialized
INFO - 2020-10-12 10:34:42 --> Router Class Initialized
INFO - 2020-10-12 10:34:42 --> Output Class Initialized
INFO - 2020-10-12 10:34:42 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:42 --> Input Class Initialized
INFO - 2020-10-12 10:34:42 --> Language Class Initialized
INFO - 2020-10-12 10:34:42 --> Loader Class Initialized
INFO - 2020-10-12 10:34:42 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:42 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:42 --> Email Class Initialized
INFO - 2020-10-12 10:34:42 --> Controller Class Initialized
DEBUG - 2020-10-12 10:34:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:34:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:34:42 --> Model Class Initialized
INFO - 2020-10-12 10:34:42 --> Model Class Initialized
INFO - 2020-10-12 10:34:42 --> Model Class Initialized
INFO - 2020-10-12 10:34:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 10:34:42 --> Final output sent to browser
DEBUG - 2020-10-12 10:34:42 --> Total execution time: 0.0685
ERROR - 2020-10-12 10:34:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:47 --> Config Class Initialized
INFO - 2020-10-12 10:34:47 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:47 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:47 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:47 --> URI Class Initialized
INFO - 2020-10-12 10:34:47 --> Router Class Initialized
INFO - 2020-10-12 10:34:47 --> Output Class Initialized
INFO - 2020-10-12 10:34:47 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:47 --> Input Class Initialized
INFO - 2020-10-12 10:34:47 --> Language Class Initialized
INFO - 2020-10-12 10:34:47 --> Loader Class Initialized
INFO - 2020-10-12 10:34:47 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:47 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:47 --> Email Class Initialized
INFO - 2020-10-12 10:34:47 --> Controller Class Initialized
DEBUG - 2020-10-12 10:34:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:34:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:34:47 --> Model Class Initialized
INFO - 2020-10-12 10:34:47 --> Model Class Initialized
INFO - 2020-10-12 10:34:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 10:34:47 --> Final output sent to browser
DEBUG - 2020-10-12 10:34:47 --> Total execution time: 0.0251
ERROR - 2020-10-12 10:34:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:34:58 --> Config Class Initialized
INFO - 2020-10-12 10:34:58 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:34:58 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:34:58 --> Utf8 Class Initialized
INFO - 2020-10-12 10:34:58 --> URI Class Initialized
INFO - 2020-10-12 10:34:58 --> Router Class Initialized
INFO - 2020-10-12 10:34:58 --> Output Class Initialized
INFO - 2020-10-12 10:34:58 --> Security Class Initialized
DEBUG - 2020-10-12 10:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:34:58 --> Input Class Initialized
INFO - 2020-10-12 10:34:58 --> Language Class Initialized
INFO - 2020-10-12 10:34:58 --> Loader Class Initialized
INFO - 2020-10-12 10:34:58 --> Helper loaded: url_helper
INFO - 2020-10-12 10:34:58 --> Database Driver Class Initialized
INFO - 2020-10-12 10:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:34:58 --> Email Class Initialized
INFO - 2020-10-12 10:34:58 --> Controller Class Initialized
DEBUG - 2020-10-12 10:34:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:34:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:34:58 --> Model Class Initialized
INFO - 2020-10-12 10:34:58 --> Model Class Initialized
INFO - 2020-10-12 10:34:58 --> Model Class Initialized
INFO - 2020-10-12 10:34:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 10:34:58 --> Final output sent to browser
DEBUG - 2020-10-12 10:34:58 --> Total execution time: 0.0225
ERROR - 2020-10-12 10:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:35:28 --> Config Class Initialized
INFO - 2020-10-12 10:35:28 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:35:28 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:35:28 --> Utf8 Class Initialized
INFO - 2020-10-12 10:35:28 --> URI Class Initialized
DEBUG - 2020-10-12 10:35:28 --> No URI present. Default controller set.
INFO - 2020-10-12 10:35:28 --> Router Class Initialized
INFO - 2020-10-12 10:35:28 --> Output Class Initialized
INFO - 2020-10-12 10:35:28 --> Security Class Initialized
DEBUG - 2020-10-12 10:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:35:28 --> Input Class Initialized
INFO - 2020-10-12 10:35:28 --> Language Class Initialized
INFO - 2020-10-12 10:35:28 --> Loader Class Initialized
INFO - 2020-10-12 10:35:28 --> Helper loaded: url_helper
INFO - 2020-10-12 10:35:28 --> Database Driver Class Initialized
INFO - 2020-10-12 10:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:35:28 --> Email Class Initialized
INFO - 2020-10-12 10:35:28 --> Controller Class Initialized
INFO - 2020-10-12 10:35:28 --> Model Class Initialized
INFO - 2020-10-12 10:35:28 --> Model Class Initialized
DEBUG - 2020-10-12 10:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:35:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:35:28 --> Final output sent to browser
DEBUG - 2020-10-12 10:35:28 --> Total execution time: 0.0190
ERROR - 2020-10-12 10:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:35:31 --> Config Class Initialized
INFO - 2020-10-12 10:35:31 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:35:31 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:35:31 --> Utf8 Class Initialized
INFO - 2020-10-12 10:35:31 --> URI Class Initialized
INFO - 2020-10-12 10:35:31 --> Router Class Initialized
INFO - 2020-10-12 10:35:31 --> Output Class Initialized
INFO - 2020-10-12 10:35:31 --> Security Class Initialized
DEBUG - 2020-10-12 10:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:35:31 --> Input Class Initialized
INFO - 2020-10-12 10:35:31 --> Language Class Initialized
INFO - 2020-10-12 10:35:31 --> Loader Class Initialized
INFO - 2020-10-12 10:35:31 --> Helper loaded: url_helper
INFO - 2020-10-12 10:35:31 --> Database Driver Class Initialized
INFO - 2020-10-12 10:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:35:31 --> Email Class Initialized
INFO - 2020-10-12 10:35:31 --> Controller Class Initialized
INFO - 2020-10-12 10:35:31 --> Model Class Initialized
INFO - 2020-10-12 10:35:31 --> Model Class Initialized
DEBUG - 2020-10-12 10:35:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:35:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:35:31 --> Model Class Initialized
INFO - 2020-10-12 10:35:31 --> Final output sent to browser
DEBUG - 2020-10-12 10:35:31 --> Total execution time: 0.0197
ERROR - 2020-10-12 10:35:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:35:31 --> Config Class Initialized
INFO - 2020-10-12 10:35:31 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:35:31 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:35:31 --> Utf8 Class Initialized
INFO - 2020-10-12 10:35:31 --> URI Class Initialized
INFO - 2020-10-12 10:35:31 --> Router Class Initialized
INFO - 2020-10-12 10:35:31 --> Output Class Initialized
INFO - 2020-10-12 10:35:31 --> Security Class Initialized
DEBUG - 2020-10-12 10:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:35:31 --> Input Class Initialized
INFO - 2020-10-12 10:35:31 --> Language Class Initialized
INFO - 2020-10-12 10:35:31 --> Loader Class Initialized
INFO - 2020-10-12 10:35:31 --> Helper loaded: url_helper
INFO - 2020-10-12 10:35:31 --> Database Driver Class Initialized
INFO - 2020-10-12 10:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:35:31 --> Email Class Initialized
INFO - 2020-10-12 10:35:31 --> Controller Class Initialized
INFO - 2020-10-12 10:35:31 --> Model Class Initialized
INFO - 2020-10-12 10:35:31 --> Model Class Initialized
DEBUG - 2020-10-12 10:35:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 10:35:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:35:32 --> Config Class Initialized
INFO - 2020-10-12 10:35:32 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:35:32 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:35:32 --> Utf8 Class Initialized
INFO - 2020-10-12 10:35:32 --> URI Class Initialized
INFO - 2020-10-12 10:35:32 --> Router Class Initialized
INFO - 2020-10-12 10:35:32 --> Output Class Initialized
INFO - 2020-10-12 10:35:32 --> Security Class Initialized
DEBUG - 2020-10-12 10:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:35:32 --> Input Class Initialized
INFO - 2020-10-12 10:35:32 --> Language Class Initialized
INFO - 2020-10-12 10:35:32 --> Loader Class Initialized
INFO - 2020-10-12 10:35:32 --> Helper loaded: url_helper
INFO - 2020-10-12 10:35:32 --> Database Driver Class Initialized
INFO - 2020-10-12 10:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:35:32 --> Email Class Initialized
INFO - 2020-10-12 10:35:32 --> Controller Class Initialized
DEBUG - 2020-10-12 10:35:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:35:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:35:32 --> Model Class Initialized
INFO - 2020-10-12 10:35:32 --> Model Class Initialized
INFO - 2020-10-12 10:35:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 10:35:32 --> Final output sent to browser
DEBUG - 2020-10-12 10:35:32 --> Total execution time: 0.0331
ERROR - 2020-10-12 10:35:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:35:35 --> Config Class Initialized
INFO - 2020-10-12 10:35:35 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:35:35 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:35:35 --> Utf8 Class Initialized
INFO - 2020-10-12 10:35:35 --> URI Class Initialized
INFO - 2020-10-12 10:35:35 --> Router Class Initialized
INFO - 2020-10-12 10:35:35 --> Output Class Initialized
INFO - 2020-10-12 10:35:35 --> Security Class Initialized
DEBUG - 2020-10-12 10:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:35:35 --> Input Class Initialized
INFO - 2020-10-12 10:35:35 --> Language Class Initialized
INFO - 2020-10-12 10:35:35 --> Loader Class Initialized
INFO - 2020-10-12 10:35:35 --> Helper loaded: url_helper
INFO - 2020-10-12 10:35:35 --> Database Driver Class Initialized
INFO - 2020-10-12 10:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:35:35 --> Email Class Initialized
INFO - 2020-10-12 10:35:35 --> Controller Class Initialized
DEBUG - 2020-10-12 10:35:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:35:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:35:35 --> Model Class Initialized
INFO - 2020-10-12 10:35:35 --> Model Class Initialized
INFO - 2020-10-12 10:35:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 10:35:35 --> Final output sent to browser
DEBUG - 2020-10-12 10:35:35 --> Total execution time: 0.0305
ERROR - 2020-10-12 10:35:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:35:37 --> Config Class Initialized
INFO - 2020-10-12 10:35:37 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:35:37 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:35:37 --> Utf8 Class Initialized
INFO - 2020-10-12 10:35:37 --> URI Class Initialized
INFO - 2020-10-12 10:35:37 --> Router Class Initialized
INFO - 2020-10-12 10:35:37 --> Output Class Initialized
INFO - 2020-10-12 10:35:37 --> Security Class Initialized
DEBUG - 2020-10-12 10:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:35:37 --> Input Class Initialized
INFO - 2020-10-12 10:35:37 --> Language Class Initialized
INFO - 2020-10-12 10:35:37 --> Loader Class Initialized
INFO - 2020-10-12 10:35:37 --> Helper loaded: url_helper
INFO - 2020-10-12 10:35:37 --> Database Driver Class Initialized
INFO - 2020-10-12 10:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:35:37 --> Email Class Initialized
INFO - 2020-10-12 10:35:37 --> Controller Class Initialized
DEBUG - 2020-10-12 10:35:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:35:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:35:37 --> Model Class Initialized
INFO - 2020-10-12 10:35:37 --> Model Class Initialized
INFO - 2020-10-12 10:35:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 10:35:37 --> Final output sent to browser
DEBUG - 2020-10-12 10:35:37 --> Total execution time: 0.0314
ERROR - 2020-10-12 10:36:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:14 --> Config Class Initialized
INFO - 2020-10-12 10:36:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:14 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:14 --> URI Class Initialized
DEBUG - 2020-10-12 10:36:14 --> No URI present. Default controller set.
INFO - 2020-10-12 10:36:14 --> Router Class Initialized
INFO - 2020-10-12 10:36:14 --> Output Class Initialized
INFO - 2020-10-12 10:36:14 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:14 --> Input Class Initialized
INFO - 2020-10-12 10:36:14 --> Language Class Initialized
INFO - 2020-10-12 10:36:14 --> Loader Class Initialized
INFO - 2020-10-12 10:36:14 --> Helper loaded: url_helper
INFO - 2020-10-12 10:36:14 --> Database Driver Class Initialized
INFO - 2020-10-12 10:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:36:14 --> Email Class Initialized
INFO - 2020-10-12 10:36:14 --> Controller Class Initialized
INFO - 2020-10-12 10:36:14 --> Model Class Initialized
INFO - 2020-10-12 10:36:14 --> Model Class Initialized
DEBUG - 2020-10-12 10:36:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:36:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 10:36:14 --> Final output sent to browser
DEBUG - 2020-10-12 10:36:14 --> Total execution time: 0.0192
ERROR - 2020-10-12 10:36:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:32 --> Config Class Initialized
INFO - 2020-10-12 10:36:32 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:32 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:32 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:32 --> URI Class Initialized
INFO - 2020-10-12 10:36:32 --> Router Class Initialized
INFO - 2020-10-12 10:36:32 --> Output Class Initialized
INFO - 2020-10-12 10:36:32 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:32 --> Input Class Initialized
INFO - 2020-10-12 10:36:32 --> Language Class Initialized
INFO - 2020-10-12 10:36:32 --> Loader Class Initialized
INFO - 2020-10-12 10:36:32 --> Helper loaded: url_helper
INFO - 2020-10-12 10:36:32 --> Database Driver Class Initialized
INFO - 2020-10-12 10:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:36:32 --> Email Class Initialized
INFO - 2020-10-12 10:36:32 --> Controller Class Initialized
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
DEBUG - 2020-10-12 10:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:36:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
INFO - 2020-10-12 10:36:32 --> Final output sent to browser
DEBUG - 2020-10-12 10:36:32 --> Total execution time: 0.0233
ERROR - 2020-10-12 10:36:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:32 --> Config Class Initialized
INFO - 2020-10-12 10:36:32 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:32 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:32 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:32 --> URI Class Initialized
INFO - 2020-10-12 10:36:32 --> Router Class Initialized
INFO - 2020-10-12 10:36:32 --> Output Class Initialized
INFO - 2020-10-12 10:36:32 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:32 --> Input Class Initialized
INFO - 2020-10-12 10:36:32 --> Language Class Initialized
INFO - 2020-10-12 10:36:32 --> Loader Class Initialized
INFO - 2020-10-12 10:36:32 --> Helper loaded: url_helper
INFO - 2020-10-12 10:36:32 --> Database Driver Class Initialized
INFO - 2020-10-12 10:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:36:32 --> Email Class Initialized
INFO - 2020-10-12 10:36:32 --> Controller Class Initialized
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
DEBUG - 2020-10-12 10:36:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 10:36:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:32 --> Config Class Initialized
INFO - 2020-10-12 10:36:32 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:32 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:32 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:32 --> URI Class Initialized
INFO - 2020-10-12 10:36:32 --> Router Class Initialized
INFO - 2020-10-12 10:36:32 --> Output Class Initialized
INFO - 2020-10-12 10:36:32 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:32 --> Input Class Initialized
INFO - 2020-10-12 10:36:32 --> Language Class Initialized
INFO - 2020-10-12 10:36:32 --> Loader Class Initialized
INFO - 2020-10-12 10:36:32 --> Helper loaded: url_helper
INFO - 2020-10-12 10:36:32 --> Database Driver Class Initialized
INFO - 2020-10-12 10:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:36:32 --> Email Class Initialized
INFO - 2020-10-12 10:36:32 --> Controller Class Initialized
DEBUG - 2020-10-12 10:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:36:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
INFO - 2020-10-12 10:36:32 --> Model Class Initialized
INFO - 2020-10-12 10:36:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-12 10:36:32 --> Final output sent to browser
DEBUG - 2020-10-12 10:36:32 --> Total execution time: 0.0277
ERROR - 2020-10-12 10:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:47 --> Config Class Initialized
INFO - 2020-10-12 10:36:47 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:47 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:47 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:47 --> URI Class Initialized
INFO - 2020-10-12 10:36:47 --> Router Class Initialized
INFO - 2020-10-12 10:36:47 --> Output Class Initialized
INFO - 2020-10-12 10:36:47 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:47 --> Input Class Initialized
INFO - 2020-10-12 10:36:47 --> Language Class Initialized
INFO - 2020-10-12 10:36:47 --> Loader Class Initialized
INFO - 2020-10-12 10:36:47 --> Helper loaded: url_helper
INFO - 2020-10-12 10:36:47 --> Database Driver Class Initialized
INFO - 2020-10-12 10:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:36:47 --> Email Class Initialized
INFO - 2020-10-12 10:36:47 --> Controller Class Initialized
DEBUG - 2020-10-12 10:36:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:36:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:36:47 --> Model Class Initialized
INFO - 2020-10-12 10:36:47 --> Model Class Initialized
INFO - 2020-10-12 10:36:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 10:36:47 --> Final output sent to browser
DEBUG - 2020-10-12 10:36:47 --> Total execution time: 0.0418
ERROR - 2020-10-12 10:36:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:54 --> Config Class Initialized
INFO - 2020-10-12 10:36:54 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:54 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:54 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:54 --> URI Class Initialized
INFO - 2020-10-12 10:36:54 --> Router Class Initialized
INFO - 2020-10-12 10:36:54 --> Output Class Initialized
INFO - 2020-10-12 10:36:54 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:54 --> Input Class Initialized
INFO - 2020-10-12 10:36:54 --> Language Class Initialized
INFO - 2020-10-12 10:36:54 --> Loader Class Initialized
INFO - 2020-10-12 10:36:54 --> Helper loaded: url_helper
INFO - 2020-10-12 10:36:54 --> Database Driver Class Initialized
INFO - 2020-10-12 10:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:36:54 --> Email Class Initialized
INFO - 2020-10-12 10:36:54 --> Controller Class Initialized
DEBUG - 2020-10-12 10:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:36:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:36:54 --> Model Class Initialized
INFO - 2020-10-12 10:36:54 --> Model Class Initialized
INFO - 2020-10-12 10:36:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-12 10:36:54 --> Final output sent to browser
DEBUG - 2020-10-12 10:36:54 --> Total execution time: 0.0338
ERROR - 2020-10-12 10:36:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:36:55 --> Config Class Initialized
INFO - 2020-10-12 10:36:55 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:36:55 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:36:55 --> Utf8 Class Initialized
INFO - 2020-10-12 10:36:55 --> URI Class Initialized
INFO - 2020-10-12 10:36:55 --> Router Class Initialized
INFO - 2020-10-12 10:36:55 --> Output Class Initialized
INFO - 2020-10-12 10:36:55 --> Security Class Initialized
DEBUG - 2020-10-12 10:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:36:55 --> Input Class Initialized
INFO - 2020-10-12 10:36:55 --> Language Class Initialized
ERROR - 2020-10-12 10:36:55 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-12 10:37:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:37:01 --> Config Class Initialized
INFO - 2020-10-12 10:37:01 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:37:01 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:37:01 --> Utf8 Class Initialized
INFO - 2020-10-12 10:37:01 --> URI Class Initialized
INFO - 2020-10-12 10:37:01 --> Router Class Initialized
INFO - 2020-10-12 10:37:01 --> Output Class Initialized
INFO - 2020-10-12 10:37:01 --> Security Class Initialized
DEBUG - 2020-10-12 10:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:37:01 --> Input Class Initialized
INFO - 2020-10-12 10:37:01 --> Language Class Initialized
INFO - 2020-10-12 10:37:01 --> Loader Class Initialized
INFO - 2020-10-12 10:37:01 --> Helper loaded: url_helper
INFO - 2020-10-12 10:37:01 --> Database Driver Class Initialized
INFO - 2020-10-12 10:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:37:01 --> Email Class Initialized
INFO - 2020-10-12 10:37:01 --> Controller Class Initialized
DEBUG - 2020-10-12 10:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:37:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:37:01 --> Model Class Initialized
INFO - 2020-10-12 10:37:01 --> Model Class Initialized
INFO - 2020-10-12 10:37:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 10:37:01 --> Final output sent to browser
DEBUG - 2020-10-12 10:37:01 --> Total execution time: 0.0250
ERROR - 2020-10-12 10:44:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:44:11 --> Config Class Initialized
INFO - 2020-10-12 10:44:11 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:44:11 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:44:11 --> Utf8 Class Initialized
INFO - 2020-10-12 10:44:11 --> URI Class Initialized
INFO - 2020-10-12 10:44:11 --> Router Class Initialized
INFO - 2020-10-12 10:44:11 --> Output Class Initialized
INFO - 2020-10-12 10:44:11 --> Security Class Initialized
DEBUG - 2020-10-12 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:44:11 --> Input Class Initialized
INFO - 2020-10-12 10:44:11 --> Language Class Initialized
INFO - 2020-10-12 10:44:11 --> Loader Class Initialized
INFO - 2020-10-12 10:44:11 --> Helper loaded: url_helper
INFO - 2020-10-12 10:44:11 --> Database Driver Class Initialized
INFO - 2020-10-12 10:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:44:11 --> Email Class Initialized
INFO - 2020-10-12 10:44:11 --> Controller Class Initialized
DEBUG - 2020-10-12 10:44:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:44:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:44:11 --> Model Class Initialized
INFO - 2020-10-12 10:44:11 --> Model Class Initialized
INFO - 2020-10-12 10:44:11 --> Model Class Initialized
INFO - 2020-10-12 10:44:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 10:44:11 --> Final output sent to browser
DEBUG - 2020-10-12 10:44:11 --> Total execution time: 0.0254
ERROR - 2020-10-12 10:44:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 10:44:14 --> Config Class Initialized
INFO - 2020-10-12 10:44:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 10:44:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 10:44:14 --> Utf8 Class Initialized
INFO - 2020-10-12 10:44:14 --> URI Class Initialized
INFO - 2020-10-12 10:44:14 --> Router Class Initialized
INFO - 2020-10-12 10:44:14 --> Output Class Initialized
INFO - 2020-10-12 10:44:14 --> Security Class Initialized
DEBUG - 2020-10-12 10:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 10:44:14 --> Input Class Initialized
INFO - 2020-10-12 10:44:14 --> Language Class Initialized
INFO - 2020-10-12 10:44:14 --> Loader Class Initialized
INFO - 2020-10-12 10:44:14 --> Helper loaded: url_helper
INFO - 2020-10-12 10:44:14 --> Database Driver Class Initialized
INFO - 2020-10-12 10:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 10:44:14 --> Email Class Initialized
INFO - 2020-10-12 10:44:14 --> Controller Class Initialized
DEBUG - 2020-10-12 10:44:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 10:44:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 10:44:14 --> Model Class Initialized
INFO - 2020-10-12 10:44:14 --> Model Class Initialized
INFO - 2020-10-12 10:44:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 10:44:14 --> Final output sent to browser
DEBUG - 2020-10-12 10:44:14 --> Total execution time: 0.0247
ERROR - 2020-10-12 11:01:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:01:27 --> Config Class Initialized
INFO - 2020-10-12 11:01:27 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:01:27 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:01:27 --> Utf8 Class Initialized
INFO - 2020-10-12 11:01:27 --> URI Class Initialized
INFO - 2020-10-12 11:01:27 --> Router Class Initialized
INFO - 2020-10-12 11:01:27 --> Output Class Initialized
INFO - 2020-10-12 11:01:27 --> Security Class Initialized
DEBUG - 2020-10-12 11:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:01:27 --> Input Class Initialized
INFO - 2020-10-12 11:01:27 --> Language Class Initialized
INFO - 2020-10-12 11:01:27 --> Loader Class Initialized
INFO - 2020-10-12 11:01:27 --> Helper loaded: url_helper
INFO - 2020-10-12 11:01:27 --> Database Driver Class Initialized
INFO - 2020-10-12 11:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:01:27 --> Email Class Initialized
INFO - 2020-10-12 11:01:27 --> Controller Class Initialized
DEBUG - 2020-10-12 11:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:01:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:01:27 --> Model Class Initialized
INFO - 2020-10-12 11:01:27 --> Model Class Initialized
INFO - 2020-10-12 11:01:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:01:27 --> Final output sent to browser
DEBUG - 2020-10-12 11:01:27 --> Total execution time: 0.0263
ERROR - 2020-10-12 11:07:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:07:57 --> Config Class Initialized
INFO - 2020-10-12 11:07:57 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:07:57 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:07:57 --> Utf8 Class Initialized
INFO - 2020-10-12 11:07:57 --> URI Class Initialized
INFO - 2020-10-12 11:07:57 --> Router Class Initialized
INFO - 2020-10-12 11:07:57 --> Output Class Initialized
INFO - 2020-10-12 11:07:57 --> Security Class Initialized
DEBUG - 2020-10-12 11:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:07:57 --> Input Class Initialized
INFO - 2020-10-12 11:07:57 --> Language Class Initialized
INFO - 2020-10-12 11:07:57 --> Loader Class Initialized
INFO - 2020-10-12 11:07:57 --> Helper loaded: url_helper
INFO - 2020-10-12 11:07:57 --> Database Driver Class Initialized
INFO - 2020-10-12 11:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:07:57 --> Email Class Initialized
INFO - 2020-10-12 11:07:57 --> Controller Class Initialized
DEBUG - 2020-10-12 11:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:07:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:07:57 --> Model Class Initialized
INFO - 2020-10-12 11:07:57 --> Model Class Initialized
INFO - 2020-10-12 11:07:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:07:57 --> Final output sent to browser
DEBUG - 2020-10-12 11:07:57 --> Total execution time: 0.0283
ERROR - 2020-10-12 11:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:09:56 --> Config Class Initialized
INFO - 2020-10-12 11:09:56 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:09:56 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:09:56 --> Utf8 Class Initialized
INFO - 2020-10-12 11:09:56 --> URI Class Initialized
INFO - 2020-10-12 11:09:56 --> Router Class Initialized
INFO - 2020-10-12 11:09:56 --> Output Class Initialized
INFO - 2020-10-12 11:09:56 --> Security Class Initialized
DEBUG - 2020-10-12 11:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:09:56 --> Input Class Initialized
INFO - 2020-10-12 11:09:56 --> Language Class Initialized
INFO - 2020-10-12 11:09:56 --> Loader Class Initialized
INFO - 2020-10-12 11:09:56 --> Helper loaded: url_helper
INFO - 2020-10-12 11:09:56 --> Database Driver Class Initialized
INFO - 2020-10-12 11:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:09:56 --> Email Class Initialized
INFO - 2020-10-12 11:09:56 --> Controller Class Initialized
DEBUG - 2020-10-12 11:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:09:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:09:56 --> Model Class Initialized
INFO - 2020-10-12 11:09:56 --> Model Class Initialized
INFO - 2020-10-12 11:09:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:09:56 --> Final output sent to browser
DEBUG - 2020-10-12 11:09:56 --> Total execution time: 0.0260
ERROR - 2020-10-12 11:10:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:10:12 --> Config Class Initialized
INFO - 2020-10-12 11:10:12 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:10:12 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:10:12 --> Utf8 Class Initialized
INFO - 2020-10-12 11:10:12 --> URI Class Initialized
INFO - 2020-10-12 11:10:12 --> Router Class Initialized
INFO - 2020-10-12 11:10:12 --> Output Class Initialized
INFO - 2020-10-12 11:10:12 --> Security Class Initialized
DEBUG - 2020-10-12 11:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:10:12 --> Input Class Initialized
INFO - 2020-10-12 11:10:12 --> Language Class Initialized
ERROR - 2020-10-12 11:10:12 --> 404 Page Not Found: Admin/client_delete
ERROR - 2020-10-12 11:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:11:37 --> Config Class Initialized
INFO - 2020-10-12 11:11:37 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:11:37 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:11:37 --> Utf8 Class Initialized
INFO - 2020-10-12 11:11:37 --> URI Class Initialized
INFO - 2020-10-12 11:11:37 --> Router Class Initialized
INFO - 2020-10-12 11:11:37 --> Output Class Initialized
INFO - 2020-10-12 11:11:37 --> Security Class Initialized
DEBUG - 2020-10-12 11:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:11:37 --> Input Class Initialized
INFO - 2020-10-12 11:11:37 --> Language Class Initialized
INFO - 2020-10-12 11:11:37 --> Loader Class Initialized
INFO - 2020-10-12 11:11:37 --> Helper loaded: url_helper
INFO - 2020-10-12 11:11:37 --> Database Driver Class Initialized
INFO - 2020-10-12 11:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:11:37 --> Email Class Initialized
INFO - 2020-10-12 11:11:37 --> Controller Class Initialized
DEBUG - 2020-10-12 11:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:11:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:11:37 --> Model Class Initialized
INFO - 2020-10-12 11:11:37 --> Model Class Initialized
INFO - 2020-10-12 11:11:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:11:37 --> Final output sent to browser
DEBUG - 2020-10-12 11:11:37 --> Total execution time: 0.0263
ERROR - 2020-10-12 11:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:11:45 --> Config Class Initialized
INFO - 2020-10-12 11:11:45 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:11:45 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:11:45 --> Utf8 Class Initialized
INFO - 2020-10-12 11:11:45 --> URI Class Initialized
INFO - 2020-10-12 11:11:45 --> Router Class Initialized
INFO - 2020-10-12 11:11:45 --> Output Class Initialized
INFO - 2020-10-12 11:11:45 --> Security Class Initialized
DEBUG - 2020-10-12 11:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:11:45 --> Input Class Initialized
INFO - 2020-10-12 11:11:45 --> Language Class Initialized
INFO - 2020-10-12 11:11:45 --> Loader Class Initialized
INFO - 2020-10-12 11:11:45 --> Helper loaded: url_helper
INFO - 2020-10-12 11:11:45 --> Database Driver Class Initialized
INFO - 2020-10-12 11:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:11:45 --> Email Class Initialized
INFO - 2020-10-12 11:11:45 --> Controller Class Initialized
DEBUG - 2020-10-12 11:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:11:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:11:45 --> Model Class Initialized
INFO - 2020-10-12 11:11:45 --> Model Class Initialized
INFO - 2020-10-12 11:11:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:11:45 --> Final output sent to browser
DEBUG - 2020-10-12 11:11:45 --> Total execution time: 0.0297
ERROR - 2020-10-12 11:13:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:13:18 --> Config Class Initialized
INFO - 2020-10-12 11:13:18 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:13:18 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:13:18 --> Utf8 Class Initialized
INFO - 2020-10-12 11:13:18 --> URI Class Initialized
INFO - 2020-10-12 11:13:18 --> Router Class Initialized
INFO - 2020-10-12 11:13:18 --> Output Class Initialized
INFO - 2020-10-12 11:13:18 --> Security Class Initialized
DEBUG - 2020-10-12 11:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:13:18 --> Input Class Initialized
INFO - 2020-10-12 11:13:18 --> Language Class Initialized
INFO - 2020-10-12 11:13:18 --> Loader Class Initialized
INFO - 2020-10-12 11:13:18 --> Helper loaded: url_helper
INFO - 2020-10-12 11:13:18 --> Database Driver Class Initialized
INFO - 2020-10-12 11:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:13:18 --> Email Class Initialized
INFO - 2020-10-12 11:13:18 --> Controller Class Initialized
DEBUG - 2020-10-12 11:13:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:13:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:13:18 --> Model Class Initialized
INFO - 2020-10-12 11:13:18 --> Model Class Initialized
INFO - 2020-10-12 11:13:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:13:18 --> Final output sent to browser
DEBUG - 2020-10-12 11:13:18 --> Total execution time: 0.0276
ERROR - 2020-10-12 11:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:13:25 --> Config Class Initialized
INFO - 2020-10-12 11:13:25 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:13:25 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:13:25 --> Utf8 Class Initialized
ERROR - 2020-10-12 11:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:14:31 --> Config Class Initialized
INFO - 2020-10-12 11:14:31 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:14:31 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:14:31 --> Utf8 Class Initialized
INFO - 2020-10-12 11:14:31 --> URI Class Initialized
INFO - 2020-10-12 11:14:31 --> Router Class Initialized
INFO - 2020-10-12 11:14:31 --> Output Class Initialized
INFO - 2020-10-12 11:14:31 --> Security Class Initialized
DEBUG - 2020-10-12 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:14:31 --> Input Class Initialized
INFO - 2020-10-12 11:14:31 --> Language Class Initialized
INFO - 2020-10-12 11:14:31 --> Loader Class Initialized
INFO - 2020-10-12 11:14:31 --> Helper loaded: url_helper
INFO - 2020-10-12 11:14:31 --> Database Driver Class Initialized
INFO - 2020-10-12 11:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:14:31 --> Email Class Initialized
INFO - 2020-10-12 11:14:31 --> Controller Class Initialized
DEBUG - 2020-10-12 11:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:14:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:14:31 --> Model Class Initialized
INFO - 2020-10-12 11:14:31 --> Model Class Initialized
INFO - 2020-10-12 11:14:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:14:31 --> Final output sent to browser
DEBUG - 2020-10-12 11:14:31 --> Total execution time: 0.0296
ERROR - 2020-10-12 11:14:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:14:33 --> Config Class Initialized
INFO - 2020-10-12 11:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:14:33 --> Utf8 Class Initialized
INFO - 2020-10-12 11:14:33 --> URI Class Initialized
INFO - 2020-10-12 11:14:33 --> Router Class Initialized
INFO - 2020-10-12 11:14:33 --> Output Class Initialized
INFO - 2020-10-12 11:14:33 --> Security Class Initialized
DEBUG - 2020-10-12 11:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:14:33 --> Input Class Initialized
INFO - 2020-10-12 11:14:33 --> Language Class Initialized
INFO - 2020-10-12 11:14:33 --> Loader Class Initialized
INFO - 2020-10-12 11:14:33 --> Helper loaded: url_helper
INFO - 2020-10-12 11:14:33 --> Database Driver Class Initialized
INFO - 2020-10-12 11:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:14:33 --> Email Class Initialized
INFO - 2020-10-12 11:14:33 --> Controller Class Initialized
DEBUG - 2020-10-12 11:14:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:14:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:14:33 --> Model Class Initialized
INFO - 2020-10-12 11:14:33 --> Model Class Initialized
INFO - 2020-10-12 11:14:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:14:33 --> Final output sent to browser
DEBUG - 2020-10-12 11:14:33 --> Total execution time: 0.0235
ERROR - 2020-10-12 11:14:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:14:40 --> Config Class Initialized
INFO - 2020-10-12 11:14:40 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:14:40 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:14:40 --> Utf8 Class Initialized
INFO - 2020-10-12 11:14:40 --> URI Class Initialized
INFO - 2020-10-12 11:14:40 --> Router Class Initialized
INFO - 2020-10-12 11:14:40 --> Output Class Initialized
INFO - 2020-10-12 11:14:40 --> Security Class Initialized
DEBUG - 2020-10-12 11:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:14:40 --> Input Class Initialized
INFO - 2020-10-12 11:14:40 --> Language Class Initialized
INFO - 2020-10-12 11:14:40 --> Loader Class Initialized
INFO - 2020-10-12 11:14:40 --> Helper loaded: url_helper
INFO - 2020-10-12 11:14:40 --> Database Driver Class Initialized
INFO - 2020-10-12 11:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:14:40 --> Email Class Initialized
INFO - 2020-10-12 11:14:40 --> Controller Class Initialized
DEBUG - 2020-10-12 11:14:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:14:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:14:40 --> Model Class Initialized
INFO - 2020-10-12 11:14:40 --> Model Class Initialized
INFO - 2020-10-12 11:14:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:14:40 --> Final output sent to browser
DEBUG - 2020-10-12 11:14:40 --> Total execution time: 0.0244
ERROR - 2020-10-12 11:14:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:14:48 --> Config Class Initialized
INFO - 2020-10-12 11:14:48 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:14:48 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:14:48 --> Utf8 Class Initialized
INFO - 2020-10-12 11:14:48 --> URI Class Initialized
INFO - 2020-10-12 11:14:48 --> Router Class Initialized
INFO - 2020-10-12 11:14:48 --> Output Class Initialized
INFO - 2020-10-12 11:14:48 --> Security Class Initialized
DEBUG - 2020-10-12 11:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:14:48 --> Input Class Initialized
INFO - 2020-10-12 11:14:48 --> Language Class Initialized
INFO - 2020-10-12 11:14:48 --> Loader Class Initialized
INFO - 2020-10-12 11:14:48 --> Helper loaded: url_helper
INFO - 2020-10-12 11:14:48 --> Database Driver Class Initialized
INFO - 2020-10-12 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:14:48 --> Email Class Initialized
INFO - 2020-10-12 11:14:48 --> Controller Class Initialized
DEBUG - 2020-10-12 11:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:14:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:14:48 --> Model Class Initialized
INFO - 2020-10-12 11:14:48 --> Model Class Initialized
INFO - 2020-10-12 11:14:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:14:48 --> Final output sent to browser
DEBUG - 2020-10-12 11:14:48 --> Total execution time: 0.0270
ERROR - 2020-10-12 11:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:16:00 --> Config Class Initialized
INFO - 2020-10-12 11:16:00 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:16:00 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:16:00 --> Utf8 Class Initialized
INFO - 2020-10-12 11:16:00 --> URI Class Initialized
INFO - 2020-10-12 11:16:00 --> Router Class Initialized
INFO - 2020-10-12 11:16:00 --> Output Class Initialized
INFO - 2020-10-12 11:16:00 --> Security Class Initialized
DEBUG - 2020-10-12 11:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:16:00 --> Input Class Initialized
INFO - 2020-10-12 11:16:00 --> Language Class Initialized
INFO - 2020-10-12 11:16:00 --> Loader Class Initialized
INFO - 2020-10-12 11:16:00 --> Helper loaded: url_helper
INFO - 2020-10-12 11:16:00 --> Database Driver Class Initialized
INFO - 2020-10-12 11:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:16:00 --> Email Class Initialized
INFO - 2020-10-12 11:16:00 --> Controller Class Initialized
DEBUG - 2020-10-12 11:16:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:16:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:16:00 --> Model Class Initialized
INFO - 2020-10-12 11:16:00 --> Model Class Initialized
INFO - 2020-10-12 11:16:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:16:00 --> Final output sent to browser
DEBUG - 2020-10-12 11:16:00 --> Total execution time: 0.0303
ERROR - 2020-10-12 11:16:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:16:13 --> Config Class Initialized
INFO - 2020-10-12 11:16:13 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:16:13 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:16:13 --> Utf8 Class Initialized
INFO - 2020-10-12 11:16:13 --> URI Class Initialized
INFO - 2020-10-12 11:16:13 --> Router Class Initialized
INFO - 2020-10-12 11:16:13 --> Output Class Initialized
INFO - 2020-10-12 11:16:13 --> Security Class Initialized
DEBUG - 2020-10-12 11:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:16:13 --> Input Class Initialized
INFO - 2020-10-12 11:16:13 --> Language Class Initialized
INFO - 2020-10-12 11:16:13 --> Loader Class Initialized
INFO - 2020-10-12 11:16:13 --> Helper loaded: url_helper
INFO - 2020-10-12 11:16:13 --> Database Driver Class Initialized
INFO - 2020-10-12 11:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:16:13 --> Email Class Initialized
INFO - 2020-10-12 11:16:13 --> Controller Class Initialized
DEBUG - 2020-10-12 11:16:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:16:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:16:13 --> Model Class Initialized
INFO - 2020-10-12 11:16:13 --> Model Class Initialized
INFO - 2020-10-12 11:16:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:16:13 --> Final output sent to browser
DEBUG - 2020-10-12 11:16:13 --> Total execution time: 0.0396
ERROR - 2020-10-12 11:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:16:25 --> Config Class Initialized
INFO - 2020-10-12 11:16:25 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:16:25 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:16:25 --> Utf8 Class Initialized
INFO - 2020-10-12 11:16:25 --> URI Class Initialized
INFO - 2020-10-12 11:16:25 --> Router Class Initialized
INFO - 2020-10-12 11:16:25 --> Output Class Initialized
INFO - 2020-10-12 11:16:25 --> Security Class Initialized
DEBUG - 2020-10-12 11:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:16:25 --> Input Class Initialized
INFO - 2020-10-12 11:16:25 --> Language Class Initialized
INFO - 2020-10-12 11:16:25 --> Loader Class Initialized
INFO - 2020-10-12 11:16:25 --> Helper loaded: url_helper
INFO - 2020-10-12 11:16:25 --> Database Driver Class Initialized
INFO - 2020-10-12 11:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:16:25 --> Email Class Initialized
INFO - 2020-10-12 11:16:25 --> Controller Class Initialized
DEBUG - 2020-10-12 11:16:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:16:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:16:25 --> Model Class Initialized
INFO - 2020-10-12 11:16:25 --> Model Class Initialized
INFO - 2020-10-12 11:16:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:16:25 --> Final output sent to browser
DEBUG - 2020-10-12 11:16:25 --> Total execution time: 0.0286
ERROR - 2020-10-12 11:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:17:32 --> Config Class Initialized
INFO - 2020-10-12 11:17:32 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:17:32 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:17:32 --> Utf8 Class Initialized
INFO - 2020-10-12 11:17:32 --> URI Class Initialized
INFO - 2020-10-12 11:17:32 --> Router Class Initialized
INFO - 2020-10-12 11:17:32 --> Output Class Initialized
INFO - 2020-10-12 11:17:32 --> Security Class Initialized
DEBUG - 2020-10-12 11:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:17:32 --> Input Class Initialized
INFO - 2020-10-12 11:17:32 --> Language Class Initialized
INFO - 2020-10-12 11:17:32 --> Loader Class Initialized
INFO - 2020-10-12 11:17:32 --> Helper loaded: url_helper
INFO - 2020-10-12 11:17:32 --> Database Driver Class Initialized
INFO - 2020-10-12 11:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:17:32 --> Email Class Initialized
INFO - 2020-10-12 11:17:32 --> Controller Class Initialized
DEBUG - 2020-10-12 11:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:17:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:17:32 --> Model Class Initialized
INFO - 2020-10-12 11:17:32 --> Model Class Initialized
INFO - 2020-10-12 11:17:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:17:32 --> Final output sent to browser
DEBUG - 2020-10-12 11:17:32 --> Total execution time: 0.0278
ERROR - 2020-10-12 11:17:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:17:40 --> Config Class Initialized
INFO - 2020-10-12 11:17:40 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:17:40 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:17:40 --> Utf8 Class Initialized
INFO - 2020-10-12 11:17:40 --> URI Class Initialized
INFO - 2020-10-12 11:17:40 --> Router Class Initialized
INFO - 2020-10-12 11:17:40 --> Output Class Initialized
INFO - 2020-10-12 11:17:40 --> Security Class Initialized
DEBUG - 2020-10-12 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:17:40 --> Input Class Initialized
INFO - 2020-10-12 11:17:40 --> Language Class Initialized
INFO - 2020-10-12 11:17:40 --> Loader Class Initialized
INFO - 2020-10-12 11:17:40 --> Helper loaded: url_helper
INFO - 2020-10-12 11:17:40 --> Database Driver Class Initialized
INFO - 2020-10-12 11:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:17:40 --> Email Class Initialized
INFO - 2020-10-12 11:17:40 --> Controller Class Initialized
DEBUG - 2020-10-12 11:17:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:17:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:17:40 --> Model Class Initialized
INFO - 2020-10-12 11:17:40 --> Model Class Initialized
INFO - 2020-10-12 11:17:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:17:40 --> Final output sent to browser
DEBUG - 2020-10-12 11:17:40 --> Total execution time: 0.0253
ERROR - 2020-10-12 11:18:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:18:21 --> Config Class Initialized
INFO - 2020-10-12 11:18:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:18:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:18:21 --> Utf8 Class Initialized
INFO - 2020-10-12 11:18:21 --> URI Class Initialized
INFO - 2020-10-12 11:18:21 --> Router Class Initialized
INFO - 2020-10-12 11:18:21 --> Output Class Initialized
INFO - 2020-10-12 11:18:21 --> Security Class Initialized
DEBUG - 2020-10-12 11:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:18:21 --> Input Class Initialized
INFO - 2020-10-12 11:18:21 --> Language Class Initialized
INFO - 2020-10-12 11:18:21 --> Loader Class Initialized
INFO - 2020-10-12 11:18:21 --> Helper loaded: url_helper
INFO - 2020-10-12 11:18:21 --> Database Driver Class Initialized
INFO - 2020-10-12 11:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:18:21 --> Email Class Initialized
INFO - 2020-10-12 11:18:21 --> Controller Class Initialized
DEBUG - 2020-10-12 11:18:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:18:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:18:21 --> Model Class Initialized
INFO - 2020-10-12 11:18:21 --> Model Class Initialized
INFO - 2020-10-12 11:18:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:18:21 --> Final output sent to browser
DEBUG - 2020-10-12 11:18:21 --> Total execution time: 0.0260
ERROR - 2020-10-12 11:18:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:18:27 --> Config Class Initialized
INFO - 2020-10-12 11:18:27 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:18:27 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:18:27 --> Utf8 Class Initialized
INFO - 2020-10-12 11:18:27 --> URI Class Initialized
INFO - 2020-10-12 11:18:27 --> Router Class Initialized
INFO - 2020-10-12 11:18:27 --> Output Class Initialized
INFO - 2020-10-12 11:18:27 --> Security Class Initialized
DEBUG - 2020-10-12 11:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:18:27 --> Input Class Initialized
INFO - 2020-10-12 11:18:27 --> Language Class Initialized
INFO - 2020-10-12 11:18:27 --> Loader Class Initialized
INFO - 2020-10-12 11:18:27 --> Helper loaded: url_helper
INFO - 2020-10-12 11:18:27 --> Database Driver Class Initialized
INFO - 2020-10-12 11:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:18:27 --> Email Class Initialized
INFO - 2020-10-12 11:18:27 --> Controller Class Initialized
DEBUG - 2020-10-12 11:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:18:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:18:27 --> Model Class Initialized
INFO - 2020-10-12 11:18:27 --> Model Class Initialized
INFO - 2020-10-12 11:18:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:18:27 --> Final output sent to browser
DEBUG - 2020-10-12 11:18:27 --> Total execution time: 0.0278
ERROR - 2020-10-12 11:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:20:10 --> Config Class Initialized
INFO - 2020-10-12 11:20:10 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:20:10 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:20:10 --> Utf8 Class Initialized
INFO - 2020-10-12 11:20:10 --> URI Class Initialized
INFO - 2020-10-12 11:20:10 --> Router Class Initialized
INFO - 2020-10-12 11:20:10 --> Output Class Initialized
INFO - 2020-10-12 11:20:10 --> Security Class Initialized
DEBUG - 2020-10-12 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:20:10 --> Input Class Initialized
INFO - 2020-10-12 11:20:10 --> Language Class Initialized
INFO - 2020-10-12 11:20:10 --> Loader Class Initialized
INFO - 2020-10-12 11:20:10 --> Helper loaded: url_helper
INFO - 2020-10-12 11:20:10 --> Database Driver Class Initialized
INFO - 2020-10-12 11:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:20:10 --> Email Class Initialized
INFO - 2020-10-12 11:20:10 --> Controller Class Initialized
DEBUG - 2020-10-12 11:20:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:20:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:20:10 --> Model Class Initialized
INFO - 2020-10-12 11:20:10 --> Model Class Initialized
INFO - 2020-10-12 11:20:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:20:10 --> Final output sent to browser
DEBUG - 2020-10-12 11:20:10 --> Total execution time: 0.0249
ERROR - 2020-10-12 11:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:20:17 --> Config Class Initialized
INFO - 2020-10-12 11:20:17 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:20:17 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:20:17 --> Utf8 Class Initialized
INFO - 2020-10-12 11:20:17 --> URI Class Initialized
INFO - 2020-10-12 11:20:17 --> Router Class Initialized
INFO - 2020-10-12 11:20:17 --> Output Class Initialized
INFO - 2020-10-12 11:20:17 --> Security Class Initialized
DEBUG - 2020-10-12 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:20:17 --> Input Class Initialized
INFO - 2020-10-12 11:20:17 --> Language Class Initialized
INFO - 2020-10-12 11:20:17 --> Loader Class Initialized
INFO - 2020-10-12 11:20:17 --> Helper loaded: url_helper
INFO - 2020-10-12 11:20:17 --> Database Driver Class Initialized
INFO - 2020-10-12 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:20:17 --> Email Class Initialized
INFO - 2020-10-12 11:20:17 --> Controller Class Initialized
DEBUG - 2020-10-12 11:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:20:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:20:17 --> Model Class Initialized
INFO - 2020-10-12 11:20:17 --> Model Class Initialized
ERROR - 2020-10-12 11:20:17 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-10-12 11:20:17 --> Model Class Initialized
INFO - 2020-10-12 11:20:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:20:17 --> Final output sent to browser
DEBUG - 2020-10-12 11:20:17 --> Total execution time: 0.0363
ERROR - 2020-10-12 11:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:21:48 --> Config Class Initialized
INFO - 2020-10-12 11:21:48 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:21:48 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:21:48 --> Utf8 Class Initialized
INFO - 2020-10-12 11:21:48 --> URI Class Initialized
INFO - 2020-10-12 11:21:48 --> Router Class Initialized
INFO - 2020-10-12 11:21:48 --> Output Class Initialized
INFO - 2020-10-12 11:21:48 --> Security Class Initialized
DEBUG - 2020-10-12 11:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:21:48 --> Input Class Initialized
INFO - 2020-10-12 11:21:48 --> Language Class Initialized
INFO - 2020-10-12 11:21:48 --> Loader Class Initialized
INFO - 2020-10-12 11:21:48 --> Helper loaded: url_helper
INFO - 2020-10-12 11:21:48 --> Database Driver Class Initialized
INFO - 2020-10-12 11:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:21:48 --> Email Class Initialized
INFO - 2020-10-12 11:21:48 --> Controller Class Initialized
DEBUG - 2020-10-12 11:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:21:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:21:48 --> Model Class Initialized
INFO - 2020-10-12 11:21:48 --> Model Class Initialized
INFO - 2020-10-12 11:21:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:21:48 --> Final output sent to browser
DEBUG - 2020-10-12 11:21:48 --> Total execution time: 0.0260
ERROR - 2020-10-12 11:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:22:04 --> Config Class Initialized
INFO - 2020-10-12 11:22:04 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:22:04 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:22:04 --> Utf8 Class Initialized
INFO - 2020-10-12 11:22:04 --> URI Class Initialized
INFO - 2020-10-12 11:22:04 --> Router Class Initialized
INFO - 2020-10-12 11:22:04 --> Output Class Initialized
INFO - 2020-10-12 11:22:04 --> Security Class Initialized
DEBUG - 2020-10-12 11:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:22:04 --> Input Class Initialized
INFO - 2020-10-12 11:22:04 --> Language Class Initialized
INFO - 2020-10-12 11:22:04 --> Loader Class Initialized
INFO - 2020-10-12 11:22:04 --> Helper loaded: url_helper
INFO - 2020-10-12 11:22:04 --> Database Driver Class Initialized
INFO - 2020-10-12 11:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:22:04 --> Email Class Initialized
INFO - 2020-10-12 11:22:04 --> Controller Class Initialized
DEBUG - 2020-10-12 11:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:22:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:22:04 --> Model Class Initialized
INFO - 2020-10-12 11:22:04 --> Model Class Initialized
INFO - 2020-10-12 11:22:04 --> Model Class Initialized
INFO - 2020-10-12 11:22:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:22:04 --> Final output sent to browser
DEBUG - 2020-10-12 11:22:04 --> Total execution time: 0.0312
ERROR - 2020-10-12 11:22:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:22:55 --> Config Class Initialized
INFO - 2020-10-12 11:22:55 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:22:55 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:22:55 --> Utf8 Class Initialized
INFO - 2020-10-12 11:22:55 --> URI Class Initialized
INFO - 2020-10-12 11:22:55 --> Router Class Initialized
INFO - 2020-10-12 11:22:55 --> Output Class Initialized
INFO - 2020-10-12 11:22:55 --> Security Class Initialized
DEBUG - 2020-10-12 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:22:55 --> Input Class Initialized
INFO - 2020-10-12 11:22:55 --> Language Class Initialized
INFO - 2020-10-12 11:22:55 --> Loader Class Initialized
INFO - 2020-10-12 11:22:55 --> Helper loaded: url_helper
INFO - 2020-10-12 11:22:55 --> Database Driver Class Initialized
INFO - 2020-10-12 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:22:55 --> Email Class Initialized
INFO - 2020-10-12 11:22:55 --> Controller Class Initialized
DEBUG - 2020-10-12 11:22:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:22:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:22:55 --> Model Class Initialized
INFO - 2020-10-12 11:22:55 --> Model Class Initialized
INFO - 2020-10-12 11:22:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:22:55 --> Final output sent to browser
DEBUG - 2020-10-12 11:22:55 --> Total execution time: 0.0283
ERROR - 2020-10-12 11:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:23:22 --> Config Class Initialized
INFO - 2020-10-12 11:23:22 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:23:22 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:23:22 --> Utf8 Class Initialized
INFO - 2020-10-12 11:23:22 --> URI Class Initialized
INFO - 2020-10-12 11:23:22 --> Router Class Initialized
INFO - 2020-10-12 11:23:22 --> Output Class Initialized
INFO - 2020-10-12 11:23:22 --> Security Class Initialized
DEBUG - 2020-10-12 11:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:23:22 --> Input Class Initialized
INFO - 2020-10-12 11:23:22 --> Language Class Initialized
INFO - 2020-10-12 11:23:22 --> Loader Class Initialized
INFO - 2020-10-12 11:23:22 --> Helper loaded: url_helper
INFO - 2020-10-12 11:23:22 --> Database Driver Class Initialized
INFO - 2020-10-12 11:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:23:22 --> Email Class Initialized
INFO - 2020-10-12 11:23:22 --> Controller Class Initialized
DEBUG - 2020-10-12 11:23:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:23:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:23:22 --> Model Class Initialized
INFO - 2020-10-12 11:23:22 --> Model Class Initialized
INFO - 2020-10-12 11:23:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:23:22 --> Final output sent to browser
DEBUG - 2020-10-12 11:23:22 --> Total execution time: 0.0327
ERROR - 2020-10-12 11:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:23:48 --> Config Class Initialized
INFO - 2020-10-12 11:23:48 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:23:48 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:23:48 --> Utf8 Class Initialized
INFO - 2020-10-12 11:23:48 --> URI Class Initialized
INFO - 2020-10-12 11:23:48 --> Router Class Initialized
INFO - 2020-10-12 11:23:48 --> Output Class Initialized
INFO - 2020-10-12 11:23:48 --> Security Class Initialized
DEBUG - 2020-10-12 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:23:48 --> Input Class Initialized
INFO - 2020-10-12 11:23:48 --> Language Class Initialized
INFO - 2020-10-12 11:23:48 --> Loader Class Initialized
INFO - 2020-10-12 11:23:48 --> Helper loaded: url_helper
INFO - 2020-10-12 11:23:48 --> Database Driver Class Initialized
INFO - 2020-10-12 11:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:23:48 --> Email Class Initialized
INFO - 2020-10-12 11:23:48 --> Controller Class Initialized
DEBUG - 2020-10-12 11:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:23:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:23:48 --> Model Class Initialized
INFO - 2020-10-12 11:23:48 --> Model Class Initialized
INFO - 2020-10-12 11:23:48 --> Model Class Initialized
INFO - 2020-10-12 11:23:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:23:48 --> Final output sent to browser
DEBUG - 2020-10-12 11:23:48 --> Total execution time: 0.0236
ERROR - 2020-10-12 11:25:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:25:16 --> Config Class Initialized
INFO - 2020-10-12 11:25:16 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:25:16 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:25:16 --> Utf8 Class Initialized
INFO - 2020-10-12 11:25:16 --> URI Class Initialized
INFO - 2020-10-12 11:25:16 --> Router Class Initialized
INFO - 2020-10-12 11:25:16 --> Output Class Initialized
INFO - 2020-10-12 11:25:16 --> Security Class Initialized
DEBUG - 2020-10-12 11:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:25:16 --> Input Class Initialized
INFO - 2020-10-12 11:25:16 --> Language Class Initialized
INFO - 2020-10-12 11:25:16 --> Loader Class Initialized
INFO - 2020-10-12 11:25:16 --> Helper loaded: url_helper
INFO - 2020-10-12 11:25:16 --> Database Driver Class Initialized
INFO - 2020-10-12 11:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:25:16 --> Email Class Initialized
INFO - 2020-10-12 11:25:16 --> Controller Class Initialized
DEBUG - 2020-10-12 11:25:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:25:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:25:16 --> Model Class Initialized
INFO - 2020-10-12 11:25:16 --> Model Class Initialized
INFO - 2020-10-12 11:25:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:25:16 --> Final output sent to browser
DEBUG - 2020-10-12 11:25:16 --> Total execution time: 0.0226
ERROR - 2020-10-12 11:27:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:27:07 --> Config Class Initialized
INFO - 2020-10-12 11:27:07 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:27:07 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:27:07 --> Utf8 Class Initialized
INFO - 2020-10-12 11:27:07 --> URI Class Initialized
INFO - 2020-10-12 11:27:07 --> Router Class Initialized
INFO - 2020-10-12 11:27:07 --> Output Class Initialized
INFO - 2020-10-12 11:27:07 --> Security Class Initialized
DEBUG - 2020-10-12 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:27:07 --> Input Class Initialized
INFO - 2020-10-12 11:27:07 --> Language Class Initialized
INFO - 2020-10-12 11:27:07 --> Loader Class Initialized
INFO - 2020-10-12 11:27:07 --> Helper loaded: url_helper
INFO - 2020-10-12 11:27:07 --> Database Driver Class Initialized
INFO - 2020-10-12 11:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:27:08 --> Email Class Initialized
INFO - 2020-10-12 11:27:08 --> Controller Class Initialized
DEBUG - 2020-10-12 11:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:27:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:27:08 --> Model Class Initialized
INFO - 2020-10-12 11:27:08 --> Model Class Initialized
INFO - 2020-10-12 11:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:27:08 --> Final output sent to browser
DEBUG - 2020-10-12 11:27:08 --> Total execution time: 0.0245
ERROR - 2020-10-12 11:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:27:23 --> Config Class Initialized
INFO - 2020-10-12 11:27:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:27:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:27:23 --> Utf8 Class Initialized
INFO - 2020-10-12 11:27:23 --> URI Class Initialized
INFO - 2020-10-12 11:27:23 --> Router Class Initialized
INFO - 2020-10-12 11:27:23 --> Output Class Initialized
INFO - 2020-10-12 11:27:23 --> Security Class Initialized
DEBUG - 2020-10-12 11:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:27:23 --> Input Class Initialized
INFO - 2020-10-12 11:27:23 --> Language Class Initialized
INFO - 2020-10-12 11:27:23 --> Loader Class Initialized
INFO - 2020-10-12 11:27:23 --> Helper loaded: url_helper
INFO - 2020-10-12 11:27:23 --> Database Driver Class Initialized
INFO - 2020-10-12 11:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:27:23 --> Email Class Initialized
INFO - 2020-10-12 11:27:23 --> Controller Class Initialized
DEBUG - 2020-10-12 11:27:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:27:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:27:23 --> Model Class Initialized
INFO - 2020-10-12 11:27:23 --> Model Class Initialized
INFO - 2020-10-12 11:27:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-12 11:27:23 --> Final output sent to browser
DEBUG - 2020-10-12 11:27:23 --> Total execution time: 0.0594
ERROR - 2020-10-12 11:27:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:27:27 --> Config Class Initialized
INFO - 2020-10-12 11:27:27 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:27:27 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:27:27 --> Utf8 Class Initialized
INFO - 2020-10-12 11:27:27 --> URI Class Initialized
INFO - 2020-10-12 11:27:27 --> Router Class Initialized
INFO - 2020-10-12 11:27:27 --> Output Class Initialized
INFO - 2020-10-12 11:27:27 --> Security Class Initialized
DEBUG - 2020-10-12 11:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:27:27 --> Input Class Initialized
INFO - 2020-10-12 11:27:27 --> Language Class Initialized
INFO - 2020-10-12 11:27:27 --> Loader Class Initialized
INFO - 2020-10-12 11:27:27 --> Helper loaded: url_helper
INFO - 2020-10-12 11:27:27 --> Database Driver Class Initialized
INFO - 2020-10-12 11:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:27:27 --> Email Class Initialized
INFO - 2020-10-12 11:27:27 --> Controller Class Initialized
DEBUG - 2020-10-12 11:27:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:27:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:27:27 --> Model Class Initialized
INFO - 2020-10-12 11:27:27 --> Model Class Initialized
INFO - 2020-10-12 11:27:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 11:27:27 --> Final output sent to browser
DEBUG - 2020-10-12 11:27:27 --> Total execution time: 0.0227
ERROR - 2020-10-12 11:27:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:27:30 --> Config Class Initialized
INFO - 2020-10-12 11:27:30 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:27:30 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:27:30 --> Utf8 Class Initialized
INFO - 2020-10-12 11:27:30 --> URI Class Initialized
INFO - 2020-10-12 11:27:30 --> Router Class Initialized
INFO - 2020-10-12 11:27:30 --> Output Class Initialized
INFO - 2020-10-12 11:27:30 --> Security Class Initialized
DEBUG - 2020-10-12 11:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:27:30 --> Input Class Initialized
INFO - 2020-10-12 11:27:30 --> Language Class Initialized
INFO - 2020-10-12 11:27:30 --> Loader Class Initialized
INFO - 2020-10-12 11:27:30 --> Helper loaded: url_helper
INFO - 2020-10-12 11:27:30 --> Database Driver Class Initialized
INFO - 2020-10-12 11:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:27:30 --> Email Class Initialized
INFO - 2020-10-12 11:27:30 --> Controller Class Initialized
DEBUG - 2020-10-12 11:27:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:27:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:27:30 --> Model Class Initialized
INFO - 2020-10-12 11:27:30 --> Model Class Initialized
INFO - 2020-10-12 11:27:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:27:30 --> Final output sent to browser
DEBUG - 2020-10-12 11:27:30 --> Total execution time: 0.0240
ERROR - 2020-10-12 11:27:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:27:40 --> Config Class Initialized
INFO - 2020-10-12 11:27:40 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:27:40 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:27:40 --> Utf8 Class Initialized
INFO - 2020-10-12 11:27:40 --> URI Class Initialized
INFO - 2020-10-12 11:27:40 --> Router Class Initialized
INFO - 2020-10-12 11:27:40 --> Output Class Initialized
INFO - 2020-10-12 11:27:40 --> Security Class Initialized
DEBUG - 2020-10-12 11:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:27:40 --> Input Class Initialized
INFO - 2020-10-12 11:27:40 --> Language Class Initialized
INFO - 2020-10-12 11:27:40 --> Loader Class Initialized
INFO - 2020-10-12 11:27:40 --> Helper loaded: url_helper
INFO - 2020-10-12 11:27:40 --> Database Driver Class Initialized
INFO - 2020-10-12 11:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:27:40 --> Email Class Initialized
INFO - 2020-10-12 11:27:40 --> Controller Class Initialized
DEBUG - 2020-10-12 11:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:27:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:27:40 --> Model Class Initialized
INFO - 2020-10-12 11:27:40 --> Model Class Initialized
INFO - 2020-10-12 11:27:40 --> Model Class Initialized
INFO - 2020-10-12 11:27:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:27:40 --> Final output sent to browser
DEBUG - 2020-10-12 11:27:40 --> Total execution time: 0.0267
ERROR - 2020-10-12 11:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:29:57 --> Config Class Initialized
INFO - 2020-10-12 11:29:57 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:29:57 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:29:57 --> Utf8 Class Initialized
INFO - 2020-10-12 11:29:57 --> URI Class Initialized
INFO - 2020-10-12 11:29:57 --> Router Class Initialized
INFO - 2020-10-12 11:29:57 --> Output Class Initialized
INFO - 2020-10-12 11:29:57 --> Security Class Initialized
DEBUG - 2020-10-12 11:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:29:57 --> Input Class Initialized
INFO - 2020-10-12 11:29:57 --> Language Class Initialized
INFO - 2020-10-12 11:29:57 --> Loader Class Initialized
INFO - 2020-10-12 11:29:57 --> Helper loaded: url_helper
INFO - 2020-10-12 11:29:57 --> Database Driver Class Initialized
INFO - 2020-10-12 11:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:29:57 --> Email Class Initialized
INFO - 2020-10-12 11:29:57 --> Controller Class Initialized
DEBUG - 2020-10-12 11:29:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:29:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:29:57 --> Model Class Initialized
INFO - 2020-10-12 11:29:57 --> Model Class Initialized
INFO - 2020-10-12 11:29:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:29:57 --> Final output sent to browser
DEBUG - 2020-10-12 11:29:57 --> Total execution time: 0.0236
ERROR - 2020-10-12 11:30:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:30:03 --> Config Class Initialized
INFO - 2020-10-12 11:30:03 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:30:03 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:30:03 --> Utf8 Class Initialized
INFO - 2020-10-12 11:30:03 --> URI Class Initialized
INFO - 2020-10-12 11:30:03 --> Router Class Initialized
INFO - 2020-10-12 11:30:03 --> Output Class Initialized
INFO - 2020-10-12 11:30:03 --> Security Class Initialized
DEBUG - 2020-10-12 11:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:30:03 --> Input Class Initialized
INFO - 2020-10-12 11:30:03 --> Language Class Initialized
INFO - 2020-10-12 11:30:03 --> Loader Class Initialized
INFO - 2020-10-12 11:30:03 --> Helper loaded: url_helper
INFO - 2020-10-12 11:30:03 --> Database Driver Class Initialized
INFO - 2020-10-12 11:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:30:03 --> Email Class Initialized
INFO - 2020-10-12 11:30:03 --> Controller Class Initialized
DEBUG - 2020-10-12 11:30:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:30:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:30:03 --> Model Class Initialized
INFO - 2020-10-12 11:30:03 --> Model Class Initialized
INFO - 2020-10-12 11:30:03 --> Model Class Initialized
INFO - 2020-10-12 11:30:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:30:03 --> Final output sent to browser
DEBUG - 2020-10-12 11:30:03 --> Total execution time: 0.0265
ERROR - 2020-10-12 11:34:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:34:24 --> Config Class Initialized
INFO - 2020-10-12 11:34:24 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:34:24 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:34:24 --> Utf8 Class Initialized
INFO - 2020-10-12 11:34:24 --> URI Class Initialized
INFO - 2020-10-12 11:34:24 --> Router Class Initialized
INFO - 2020-10-12 11:34:24 --> Output Class Initialized
INFO - 2020-10-12 11:34:24 --> Security Class Initialized
DEBUG - 2020-10-12 11:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:34:24 --> Input Class Initialized
INFO - 2020-10-12 11:34:24 --> Language Class Initialized
INFO - 2020-10-12 11:34:24 --> Loader Class Initialized
INFO - 2020-10-12 11:34:24 --> Helper loaded: url_helper
INFO - 2020-10-12 11:34:24 --> Database Driver Class Initialized
INFO - 2020-10-12 11:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:34:24 --> Email Class Initialized
INFO - 2020-10-12 11:34:24 --> Controller Class Initialized
DEBUG - 2020-10-12 11:34:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:34:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:34:24 --> Model Class Initialized
INFO - 2020-10-12 11:34:24 --> Model Class Initialized
INFO - 2020-10-12 11:34:24 --> Model Class Initialized
INFO - 2020-10-12 11:34:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:34:24 --> Final output sent to browser
DEBUG - 2020-10-12 11:34:24 --> Total execution time: 0.0266
ERROR - 2020-10-12 11:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:38:21 --> Config Class Initialized
INFO - 2020-10-12 11:38:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:38:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:38:21 --> Utf8 Class Initialized
INFO - 2020-10-12 11:38:21 --> URI Class Initialized
INFO - 2020-10-12 11:38:21 --> Router Class Initialized
INFO - 2020-10-12 11:38:21 --> Output Class Initialized
INFO - 2020-10-12 11:38:21 --> Security Class Initialized
DEBUG - 2020-10-12 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:38:21 --> Input Class Initialized
INFO - 2020-10-12 11:38:21 --> Language Class Initialized
INFO - 2020-10-12 11:38:21 --> Loader Class Initialized
INFO - 2020-10-12 11:38:21 --> Helper loaded: url_helper
INFO - 2020-10-12 11:38:21 --> Database Driver Class Initialized
INFO - 2020-10-12 11:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:38:21 --> Email Class Initialized
INFO - 2020-10-12 11:38:21 --> Controller Class Initialized
DEBUG - 2020-10-12 11:38:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:38:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:38:21 --> Model Class Initialized
INFO - 2020-10-12 11:38:21 --> Model Class Initialized
INFO - 2020-10-12 11:38:21 --> Model Class Initialized
INFO - 2020-10-12 11:38:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:38:21 --> Final output sent to browser
DEBUG - 2020-10-12 11:38:21 --> Total execution time: 0.0275
ERROR - 2020-10-12 11:39:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:39:36 --> Config Class Initialized
INFO - 2020-10-12 11:39:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:39:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:39:36 --> Utf8 Class Initialized
INFO - 2020-10-12 11:39:36 --> URI Class Initialized
INFO - 2020-10-12 11:39:36 --> Router Class Initialized
INFO - 2020-10-12 11:39:36 --> Output Class Initialized
INFO - 2020-10-12 11:39:36 --> Security Class Initialized
DEBUG - 2020-10-12 11:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:39:36 --> Input Class Initialized
INFO - 2020-10-12 11:39:36 --> Language Class Initialized
INFO - 2020-10-12 11:39:36 --> Loader Class Initialized
INFO - 2020-10-12 11:39:36 --> Helper loaded: url_helper
INFO - 2020-10-12 11:39:36 --> Database Driver Class Initialized
INFO - 2020-10-12 11:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:39:36 --> Email Class Initialized
INFO - 2020-10-12 11:39:36 --> Controller Class Initialized
DEBUG - 2020-10-12 11:39:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:39:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:39:36 --> Model Class Initialized
INFO - 2020-10-12 11:39:36 --> Model Class Initialized
INFO - 2020-10-12 11:39:36 --> Model Class Initialized
INFO - 2020-10-12 11:39:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:39:36 --> Final output sent to browser
DEBUG - 2020-10-12 11:39:36 --> Total execution time: 0.0251
ERROR - 2020-10-12 11:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:40:43 --> Config Class Initialized
INFO - 2020-10-12 11:40:43 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:40:43 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:40:43 --> Utf8 Class Initialized
INFO - 2020-10-12 11:40:43 --> URI Class Initialized
INFO - 2020-10-12 11:40:43 --> Router Class Initialized
INFO - 2020-10-12 11:40:43 --> Output Class Initialized
INFO - 2020-10-12 11:40:43 --> Security Class Initialized
DEBUG - 2020-10-12 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:40:43 --> Input Class Initialized
INFO - 2020-10-12 11:40:43 --> Language Class Initialized
INFO - 2020-10-12 11:40:43 --> Loader Class Initialized
INFO - 2020-10-12 11:40:43 --> Helper loaded: url_helper
INFO - 2020-10-12 11:40:43 --> Database Driver Class Initialized
INFO - 2020-10-12 11:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:40:43 --> Email Class Initialized
INFO - 2020-10-12 11:40:43 --> Controller Class Initialized
DEBUG - 2020-10-12 11:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:40:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:40:43 --> Model Class Initialized
INFO - 2020-10-12 11:40:43 --> Model Class Initialized
INFO - 2020-10-12 11:40:43 --> Model Class Initialized
INFO - 2020-10-12 11:40:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:40:43 --> Final output sent to browser
DEBUG - 2020-10-12 11:40:43 --> Total execution time: 0.0266
ERROR - 2020-10-12 11:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:40:48 --> Config Class Initialized
INFO - 2020-10-12 11:40:48 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:40:48 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:40:48 --> Utf8 Class Initialized
INFO - 2020-10-12 11:40:48 --> URI Class Initialized
INFO - 2020-10-12 11:40:48 --> Router Class Initialized
INFO - 2020-10-12 11:40:48 --> Output Class Initialized
INFO - 2020-10-12 11:40:48 --> Security Class Initialized
DEBUG - 2020-10-12 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:40:48 --> Input Class Initialized
INFO - 2020-10-12 11:40:48 --> Language Class Initialized
INFO - 2020-10-12 11:40:48 --> Loader Class Initialized
INFO - 2020-10-12 11:40:48 --> Helper loaded: url_helper
INFO - 2020-10-12 11:40:48 --> Database Driver Class Initialized
INFO - 2020-10-12 11:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:40:48 --> Email Class Initialized
INFO - 2020-10-12 11:40:48 --> Controller Class Initialized
DEBUG - 2020-10-12 11:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:40:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:40:48 --> Model Class Initialized
INFO - 2020-10-12 11:40:48 --> Model Class Initialized
INFO - 2020-10-12 11:40:48 --> Model Class Initialized
INFO - 2020-10-12 11:40:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:40:48 --> Final output sent to browser
DEBUG - 2020-10-12 11:40:48 --> Total execution time: 0.0243
ERROR - 2020-10-12 11:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:41:02 --> Config Class Initialized
INFO - 2020-10-12 11:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:41:02 --> Utf8 Class Initialized
INFO - 2020-10-12 11:41:02 --> URI Class Initialized
INFO - 2020-10-12 11:41:02 --> Router Class Initialized
INFO - 2020-10-12 11:41:02 --> Output Class Initialized
INFO - 2020-10-12 11:41:02 --> Security Class Initialized
DEBUG - 2020-10-12 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:41:02 --> Input Class Initialized
INFO - 2020-10-12 11:41:02 --> Language Class Initialized
INFO - 2020-10-12 11:41:02 --> Loader Class Initialized
INFO - 2020-10-12 11:41:02 --> Helper loaded: url_helper
INFO - 2020-10-12 11:41:02 --> Database Driver Class Initialized
INFO - 2020-10-12 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:41:02 --> Email Class Initialized
INFO - 2020-10-12 11:41:02 --> Controller Class Initialized
DEBUG - 2020-10-12 11:41:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:41:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:41:02 --> Model Class Initialized
INFO - 2020-10-12 11:41:02 --> Model Class Initialized
INFO - 2020-10-12 11:41:02 --> Model Class Initialized
INFO - 2020-10-12 11:41:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:41:02 --> Final output sent to browser
DEBUG - 2020-10-12 11:41:02 --> Total execution time: 0.0307
ERROR - 2020-10-12 11:43:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:43:33 --> Config Class Initialized
INFO - 2020-10-12 11:43:33 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:43:33 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:43:33 --> Utf8 Class Initialized
INFO - 2020-10-12 11:43:33 --> URI Class Initialized
INFO - 2020-10-12 11:43:33 --> Router Class Initialized
INFO - 2020-10-12 11:43:33 --> Output Class Initialized
INFO - 2020-10-12 11:43:33 --> Security Class Initialized
DEBUG - 2020-10-12 11:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:43:33 --> Input Class Initialized
INFO - 2020-10-12 11:43:33 --> Language Class Initialized
INFO - 2020-10-12 11:43:33 --> Loader Class Initialized
INFO - 2020-10-12 11:43:33 --> Helper loaded: url_helper
INFO - 2020-10-12 11:43:33 --> Database Driver Class Initialized
INFO - 2020-10-12 11:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:43:33 --> Email Class Initialized
INFO - 2020-10-12 11:43:33 --> Controller Class Initialized
DEBUG - 2020-10-12 11:43:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:43:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:43:33 --> Model Class Initialized
INFO - 2020-10-12 11:43:33 --> Model Class Initialized
INFO - 2020-10-12 11:43:33 --> Model Class Initialized
INFO - 2020-10-12 11:43:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:43:33 --> Final output sent to browser
DEBUG - 2020-10-12 11:43:33 --> Total execution time: 0.0266
ERROR - 2020-10-12 11:44:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:44:24 --> Config Class Initialized
INFO - 2020-10-12 11:44:24 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:44:24 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:44:24 --> Utf8 Class Initialized
INFO - 2020-10-12 11:44:24 --> URI Class Initialized
INFO - 2020-10-12 11:44:24 --> Router Class Initialized
INFO - 2020-10-12 11:44:24 --> Output Class Initialized
INFO - 2020-10-12 11:44:24 --> Security Class Initialized
DEBUG - 2020-10-12 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:44:24 --> Input Class Initialized
INFO - 2020-10-12 11:44:24 --> Language Class Initialized
INFO - 2020-10-12 11:44:24 --> Loader Class Initialized
INFO - 2020-10-12 11:44:24 --> Helper loaded: url_helper
INFO - 2020-10-12 11:44:24 --> Database Driver Class Initialized
INFO - 2020-10-12 11:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:44:24 --> Email Class Initialized
INFO - 2020-10-12 11:44:24 --> Controller Class Initialized
DEBUG - 2020-10-12 11:44:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:44:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:44:24 --> Model Class Initialized
INFO - 2020-10-12 11:44:24 --> Model Class Initialized
INFO - 2020-10-12 11:44:24 --> Model Class Initialized
INFO - 2020-10-12 11:44:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:44:24 --> Final output sent to browser
DEBUG - 2020-10-12 11:44:24 --> Total execution time: 0.0278
ERROR - 2020-10-12 11:46:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:46:26 --> Config Class Initialized
INFO - 2020-10-12 11:46:26 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:46:26 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:46:26 --> Utf8 Class Initialized
INFO - 2020-10-12 11:46:26 --> URI Class Initialized
INFO - 2020-10-12 11:46:26 --> Router Class Initialized
INFO - 2020-10-12 11:46:26 --> Output Class Initialized
INFO - 2020-10-12 11:46:26 --> Security Class Initialized
DEBUG - 2020-10-12 11:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:46:26 --> Input Class Initialized
INFO - 2020-10-12 11:46:26 --> Language Class Initialized
INFO - 2020-10-12 11:46:26 --> Loader Class Initialized
INFO - 2020-10-12 11:46:26 --> Helper loaded: url_helper
INFO - 2020-10-12 11:46:26 --> Database Driver Class Initialized
INFO - 2020-10-12 11:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:46:26 --> Email Class Initialized
INFO - 2020-10-12 11:46:26 --> Controller Class Initialized
DEBUG - 2020-10-12 11:46:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:46:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:46:26 --> Model Class Initialized
INFO - 2020-10-12 11:46:26 --> Model Class Initialized
INFO - 2020-10-12 11:46:26 --> Model Class Initialized
INFO - 2020-10-12 11:46:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:46:26 --> Final output sent to browser
DEBUG - 2020-10-12 11:46:26 --> Total execution time: 0.0289
ERROR - 2020-10-12 11:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:47:03 --> Config Class Initialized
INFO - 2020-10-12 11:47:03 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:47:03 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:47:03 --> Utf8 Class Initialized
INFO - 2020-10-12 11:47:03 --> URI Class Initialized
INFO - 2020-10-12 11:47:03 --> Router Class Initialized
INFO - 2020-10-12 11:47:03 --> Output Class Initialized
INFO - 2020-10-12 11:47:03 --> Security Class Initialized
DEBUG - 2020-10-12 11:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:47:03 --> Input Class Initialized
INFO - 2020-10-12 11:47:03 --> Language Class Initialized
INFO - 2020-10-12 11:47:03 --> Loader Class Initialized
INFO - 2020-10-12 11:47:03 --> Helper loaded: url_helper
INFO - 2020-10-12 11:47:03 --> Database Driver Class Initialized
INFO - 2020-10-12 11:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:47:03 --> Email Class Initialized
INFO - 2020-10-12 11:47:03 --> Controller Class Initialized
DEBUG - 2020-10-12 11:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:47:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:47:03 --> Model Class Initialized
INFO - 2020-10-12 11:47:03 --> Model Class Initialized
INFO - 2020-10-12 11:47:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:47:03 --> Final output sent to browser
DEBUG - 2020-10-12 11:47:03 --> Total execution time: 0.0269
ERROR - 2020-10-12 11:47:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:47:07 --> Config Class Initialized
INFO - 2020-10-12 11:47:07 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:47:07 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:47:07 --> Utf8 Class Initialized
INFO - 2020-10-12 11:47:07 --> URI Class Initialized
INFO - 2020-10-12 11:47:07 --> Router Class Initialized
INFO - 2020-10-12 11:47:07 --> Output Class Initialized
INFO - 2020-10-12 11:47:07 --> Security Class Initialized
DEBUG - 2020-10-12 11:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:47:07 --> Input Class Initialized
INFO - 2020-10-12 11:47:07 --> Language Class Initialized
INFO - 2020-10-12 11:47:07 --> Loader Class Initialized
INFO - 2020-10-12 11:47:07 --> Helper loaded: url_helper
INFO - 2020-10-12 11:47:07 --> Database Driver Class Initialized
INFO - 2020-10-12 11:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:47:07 --> Email Class Initialized
INFO - 2020-10-12 11:47:07 --> Controller Class Initialized
DEBUG - 2020-10-12 11:47:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:47:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:47:07 --> Model Class Initialized
INFO - 2020-10-12 11:47:07 --> Model Class Initialized
INFO - 2020-10-12 11:47:07 --> Model Class Initialized
INFO - 2020-10-12 11:47:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:47:07 --> Final output sent to browser
DEBUG - 2020-10-12 11:47:07 --> Total execution time: 0.0236
ERROR - 2020-10-12 11:50:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:50:01 --> Config Class Initialized
INFO - 2020-10-12 11:50:01 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:50:01 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:50:01 --> Utf8 Class Initialized
INFO - 2020-10-12 11:50:01 --> URI Class Initialized
INFO - 2020-10-12 11:50:01 --> Router Class Initialized
INFO - 2020-10-12 11:50:01 --> Output Class Initialized
INFO - 2020-10-12 11:50:01 --> Security Class Initialized
DEBUG - 2020-10-12 11:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:50:01 --> Input Class Initialized
INFO - 2020-10-12 11:50:01 --> Language Class Initialized
INFO - 2020-10-12 11:50:01 --> Loader Class Initialized
INFO - 2020-10-12 11:50:01 --> Helper loaded: url_helper
INFO - 2020-10-12 11:50:01 --> Database Driver Class Initialized
INFO - 2020-10-12 11:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:50:01 --> Email Class Initialized
INFO - 2020-10-12 11:50:01 --> Controller Class Initialized
DEBUG - 2020-10-12 11:50:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:50:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:50:01 --> Model Class Initialized
INFO - 2020-10-12 11:50:01 --> Model Class Initialized
INFO - 2020-10-12 11:50:01 --> Model Class Initialized
INFO - 2020-10-12 11:50:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:50:01 --> Final output sent to browser
DEBUG - 2020-10-12 11:50:01 --> Total execution time: 0.0276
ERROR - 2020-10-12 11:53:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:53:33 --> Config Class Initialized
INFO - 2020-10-12 11:53:33 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:53:33 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:53:33 --> Utf8 Class Initialized
INFO - 2020-10-12 11:53:33 --> URI Class Initialized
INFO - 2020-10-12 11:53:33 --> Router Class Initialized
INFO - 2020-10-12 11:53:33 --> Output Class Initialized
INFO - 2020-10-12 11:53:33 --> Security Class Initialized
DEBUG - 2020-10-12 11:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:53:33 --> Input Class Initialized
INFO - 2020-10-12 11:53:33 --> Language Class Initialized
INFO - 2020-10-12 11:53:33 --> Loader Class Initialized
INFO - 2020-10-12 11:53:33 --> Helper loaded: url_helper
INFO - 2020-10-12 11:53:33 --> Database Driver Class Initialized
INFO - 2020-10-12 11:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:53:33 --> Email Class Initialized
INFO - 2020-10-12 11:53:33 --> Controller Class Initialized
DEBUG - 2020-10-12 11:53:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:53:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:53:33 --> Model Class Initialized
INFO - 2020-10-12 11:53:33 --> Model Class Initialized
INFO - 2020-10-12 11:53:33 --> Model Class Initialized
INFO - 2020-10-12 11:53:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:53:33 --> Final output sent to browser
DEBUG - 2020-10-12 11:53:33 --> Total execution time: 0.0320
ERROR - 2020-10-12 11:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:54:14 --> Config Class Initialized
INFO - 2020-10-12 11:54:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:54:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:54:14 --> Utf8 Class Initialized
INFO - 2020-10-12 11:54:14 --> URI Class Initialized
INFO - 2020-10-12 11:54:14 --> Router Class Initialized
INFO - 2020-10-12 11:54:14 --> Output Class Initialized
INFO - 2020-10-12 11:54:14 --> Security Class Initialized
DEBUG - 2020-10-12 11:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:54:14 --> Input Class Initialized
INFO - 2020-10-12 11:54:14 --> Language Class Initialized
INFO - 2020-10-12 11:54:14 --> Loader Class Initialized
INFO - 2020-10-12 11:54:14 --> Helper loaded: url_helper
INFO - 2020-10-12 11:54:14 --> Database Driver Class Initialized
INFO - 2020-10-12 11:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:54:14 --> Email Class Initialized
INFO - 2020-10-12 11:54:14 --> Controller Class Initialized
DEBUG - 2020-10-12 11:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:54:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:54:14 --> Model Class Initialized
INFO - 2020-10-12 11:54:14 --> Model Class Initialized
INFO - 2020-10-12 11:54:14 --> Model Class Initialized
INFO - 2020-10-12 11:54:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 11:54:14 --> Final output sent to browser
DEBUG - 2020-10-12 11:54:14 --> Total execution time: 0.0259
ERROR - 2020-10-12 11:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:54:46 --> Config Class Initialized
INFO - 2020-10-12 11:54:46 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:54:46 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:54:46 --> Utf8 Class Initialized
INFO - 2020-10-12 11:54:46 --> URI Class Initialized
INFO - 2020-10-12 11:54:46 --> Router Class Initialized
INFO - 2020-10-12 11:54:46 --> Output Class Initialized
INFO - 2020-10-12 11:54:46 --> Security Class Initialized
DEBUG - 2020-10-12 11:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:54:46 --> Input Class Initialized
INFO - 2020-10-12 11:54:46 --> Language Class Initialized
INFO - 2020-10-12 11:54:46 --> Loader Class Initialized
INFO - 2020-10-12 11:54:46 --> Helper loaded: url_helper
INFO - 2020-10-12 11:54:46 --> Database Driver Class Initialized
INFO - 2020-10-12 11:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:54:46 --> Email Class Initialized
INFO - 2020-10-12 11:54:46 --> Controller Class Initialized
DEBUG - 2020-10-12 11:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:54:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:54:46 --> Model Class Initialized
INFO - 2020-10-12 11:54:46 --> Model Class Initialized
INFO - 2020-10-12 11:54:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:54:46 --> Final output sent to browser
DEBUG - 2020-10-12 11:54:46 --> Total execution time: 0.0244
ERROR - 2020-10-12 11:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:55:01 --> Config Class Initialized
INFO - 2020-10-12 11:55:01 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:55:01 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:55:01 --> Utf8 Class Initialized
INFO - 2020-10-12 11:55:01 --> URI Class Initialized
DEBUG - 2020-10-12 11:55:01 --> No URI present. Default controller set.
INFO - 2020-10-12 11:55:01 --> Router Class Initialized
INFO - 2020-10-12 11:55:01 --> Output Class Initialized
INFO - 2020-10-12 11:55:01 --> Security Class Initialized
DEBUG - 2020-10-12 11:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:55:01 --> Input Class Initialized
INFO - 2020-10-12 11:55:01 --> Language Class Initialized
INFO - 2020-10-12 11:55:01 --> Loader Class Initialized
INFO - 2020-10-12 11:55:01 --> Helper loaded: url_helper
INFO - 2020-10-12 11:55:01 --> Database Driver Class Initialized
INFO - 2020-10-12 11:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:55:01 --> Email Class Initialized
INFO - 2020-10-12 11:55:01 --> Controller Class Initialized
INFO - 2020-10-12 11:55:01 --> Model Class Initialized
INFO - 2020-10-12 11:55:01 --> Model Class Initialized
DEBUG - 2020-10-12 11:55:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:55:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 11:55:01 --> Final output sent to browser
DEBUG - 2020-10-12 11:55:01 --> Total execution time: 0.0223
ERROR - 2020-10-12 11:58:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:58:04 --> Config Class Initialized
INFO - 2020-10-12 11:58:04 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:58:04 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:58:04 --> Utf8 Class Initialized
INFO - 2020-10-12 11:58:04 --> URI Class Initialized
INFO - 2020-10-12 11:58:04 --> Router Class Initialized
INFO - 2020-10-12 11:58:04 --> Output Class Initialized
INFO - 2020-10-12 11:58:04 --> Security Class Initialized
DEBUG - 2020-10-12 11:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:58:04 --> Input Class Initialized
INFO - 2020-10-12 11:58:04 --> Language Class Initialized
INFO - 2020-10-12 11:58:04 --> Loader Class Initialized
INFO - 2020-10-12 11:58:04 --> Helper loaded: url_helper
INFO - 2020-10-12 11:58:04 --> Database Driver Class Initialized
INFO - 2020-10-12 11:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:58:04 --> Email Class Initialized
INFO - 2020-10-12 11:58:04 --> Controller Class Initialized
INFO - 2020-10-12 11:58:04 --> Model Class Initialized
INFO - 2020-10-12 11:58:04 --> Model Class Initialized
DEBUG - 2020-10-12 11:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:58:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:58:04 --> Model Class Initialized
INFO - 2020-10-12 11:58:04 --> Final output sent to browser
DEBUG - 2020-10-12 11:58:04 --> Total execution time: 0.0284
ERROR - 2020-10-12 11:58:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:58:04 --> Config Class Initialized
INFO - 2020-10-12 11:58:04 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:58:04 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:58:04 --> Utf8 Class Initialized
INFO - 2020-10-12 11:58:04 --> URI Class Initialized
INFO - 2020-10-12 11:58:04 --> Router Class Initialized
INFO - 2020-10-12 11:58:04 --> Output Class Initialized
INFO - 2020-10-12 11:58:04 --> Security Class Initialized
DEBUG - 2020-10-12 11:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:58:04 --> Input Class Initialized
INFO - 2020-10-12 11:58:04 --> Language Class Initialized
INFO - 2020-10-12 11:58:04 --> Loader Class Initialized
INFO - 2020-10-12 11:58:04 --> Helper loaded: url_helper
INFO - 2020-10-12 11:58:04 --> Database Driver Class Initialized
INFO - 2020-10-12 11:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:58:04 --> Email Class Initialized
INFO - 2020-10-12 11:58:04 --> Controller Class Initialized
INFO - 2020-10-12 11:58:04 --> Model Class Initialized
INFO - 2020-10-12 11:58:04 --> Model Class Initialized
DEBUG - 2020-10-12 11:58:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 11:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:58:13 --> Config Class Initialized
INFO - 2020-10-12 11:58:13 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:58:13 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:58:13 --> Utf8 Class Initialized
INFO - 2020-10-12 11:58:13 --> URI Class Initialized
INFO - 2020-10-12 11:58:13 --> Router Class Initialized
INFO - 2020-10-12 11:58:13 --> Output Class Initialized
INFO - 2020-10-12 11:58:13 --> Security Class Initialized
DEBUG - 2020-10-12 11:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:58:13 --> Input Class Initialized
INFO - 2020-10-12 11:58:13 --> Language Class Initialized
INFO - 2020-10-12 11:58:13 --> Loader Class Initialized
INFO - 2020-10-12 11:58:13 --> Helper loaded: url_helper
INFO - 2020-10-12 11:58:13 --> Database Driver Class Initialized
INFO - 2020-10-12 11:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:58:13 --> Email Class Initialized
INFO - 2020-10-12 11:58:13 --> Controller Class Initialized
DEBUG - 2020-10-12 11:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:58:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:58:13 --> Model Class Initialized
INFO - 2020-10-12 11:58:13 --> Model Class Initialized
INFO - 2020-10-12 11:58:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-12 11:58:13 --> Final output sent to browser
DEBUG - 2020-10-12 11:58:13 --> Total execution time: 0.0310
ERROR - 2020-10-12 11:58:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 11:58:23 --> Config Class Initialized
INFO - 2020-10-12 11:58:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 11:58:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 11:58:23 --> Utf8 Class Initialized
INFO - 2020-10-12 11:58:23 --> URI Class Initialized
INFO - 2020-10-12 11:58:23 --> Router Class Initialized
INFO - 2020-10-12 11:58:23 --> Output Class Initialized
INFO - 2020-10-12 11:58:23 --> Security Class Initialized
DEBUG - 2020-10-12 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 11:58:23 --> Input Class Initialized
INFO - 2020-10-12 11:58:23 --> Language Class Initialized
INFO - 2020-10-12 11:58:23 --> Loader Class Initialized
INFO - 2020-10-12 11:58:23 --> Helper loaded: url_helper
INFO - 2020-10-12 11:58:23 --> Database Driver Class Initialized
INFO - 2020-10-12 11:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 11:58:23 --> Email Class Initialized
INFO - 2020-10-12 11:58:23 --> Controller Class Initialized
DEBUG - 2020-10-12 11:58:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 11:58:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 11:58:23 --> Model Class Initialized
INFO - 2020-10-12 11:58:23 --> Model Class Initialized
INFO - 2020-10-12 11:58:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 11:58:23 --> Final output sent to browser
DEBUG - 2020-10-12 11:58:23 --> Total execution time: 0.0267
ERROR - 2020-10-12 12:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:02:56 --> Config Class Initialized
INFO - 2020-10-12 12:02:56 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:02:56 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:02:56 --> Utf8 Class Initialized
INFO - 2020-10-12 12:02:56 --> URI Class Initialized
INFO - 2020-10-12 12:02:56 --> Router Class Initialized
INFO - 2020-10-12 12:02:56 --> Output Class Initialized
INFO - 2020-10-12 12:02:56 --> Security Class Initialized
DEBUG - 2020-10-12 12:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:02:56 --> Input Class Initialized
INFO - 2020-10-12 12:02:56 --> Language Class Initialized
INFO - 2020-10-12 12:02:56 --> Loader Class Initialized
INFO - 2020-10-12 12:02:56 --> Helper loaded: url_helper
INFO - 2020-10-12 12:02:56 --> Database Driver Class Initialized
INFO - 2020-10-12 12:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:02:56 --> Email Class Initialized
INFO - 2020-10-12 12:02:56 --> Controller Class Initialized
DEBUG - 2020-10-12 12:02:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:02:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:02:56 --> Model Class Initialized
INFO - 2020-10-12 12:02:56 --> Model Class Initialized
INFO - 2020-10-12 12:02:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 12:02:56 --> Final output sent to browser
DEBUG - 2020-10-12 12:02:56 --> Total execution time: 0.0253
ERROR - 2020-10-12 12:02:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:02:58 --> Config Class Initialized
INFO - 2020-10-12 12:02:58 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:02:58 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:02:58 --> Utf8 Class Initialized
INFO - 2020-10-12 12:02:58 --> URI Class Initialized
INFO - 2020-10-12 12:02:58 --> Router Class Initialized
INFO - 2020-10-12 12:02:58 --> Output Class Initialized
INFO - 2020-10-12 12:02:58 --> Security Class Initialized
DEBUG - 2020-10-12 12:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:02:58 --> Input Class Initialized
INFO - 2020-10-12 12:02:58 --> Language Class Initialized
INFO - 2020-10-12 12:02:58 --> Loader Class Initialized
INFO - 2020-10-12 12:02:58 --> Helper loaded: url_helper
INFO - 2020-10-12 12:02:58 --> Database Driver Class Initialized
INFO - 2020-10-12 12:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:02:58 --> Email Class Initialized
INFO - 2020-10-12 12:02:58 --> Controller Class Initialized
DEBUG - 2020-10-12 12:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:02:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:02:58 --> Model Class Initialized
INFO - 2020-10-12 12:02:58 --> Model Class Initialized
INFO - 2020-10-12 12:02:58 --> Model Class Initialized
INFO - 2020-10-12 12:02:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:02:58 --> Final output sent to browser
DEBUG - 2020-10-12 12:02:58 --> Total execution time: 0.0231
ERROR - 2020-10-12 12:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:03:59 --> Config Class Initialized
INFO - 2020-10-12 12:03:59 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:03:59 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:03:59 --> Utf8 Class Initialized
INFO - 2020-10-12 12:03:59 --> URI Class Initialized
INFO - 2020-10-12 12:03:59 --> Router Class Initialized
INFO - 2020-10-12 12:03:59 --> Output Class Initialized
INFO - 2020-10-12 12:03:59 --> Security Class Initialized
DEBUG - 2020-10-12 12:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:03:59 --> Input Class Initialized
INFO - 2020-10-12 12:03:59 --> Language Class Initialized
INFO - 2020-10-12 12:03:59 --> Loader Class Initialized
INFO - 2020-10-12 12:03:59 --> Helper loaded: url_helper
INFO - 2020-10-12 12:03:59 --> Database Driver Class Initialized
INFO - 2020-10-12 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:03:59 --> Email Class Initialized
INFO - 2020-10-12 12:03:59 --> Controller Class Initialized
DEBUG - 2020-10-12 12:03:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:03:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:03:59 --> Model Class Initialized
INFO - 2020-10-12 12:03:59 --> Model Class Initialized
INFO - 2020-10-12 12:03:59 --> Model Class Initialized
INFO - 2020-10-12 12:03:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:03:59 --> Final output sent to browser
DEBUG - 2020-10-12 12:03:59 --> Total execution time: 0.0273
ERROR - 2020-10-12 12:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:04:12 --> Config Class Initialized
INFO - 2020-10-12 12:04:12 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:04:12 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:04:12 --> Utf8 Class Initialized
INFO - 2020-10-12 12:04:12 --> URI Class Initialized
INFO - 2020-10-12 12:04:12 --> Router Class Initialized
INFO - 2020-10-12 12:04:12 --> Output Class Initialized
INFO - 2020-10-12 12:04:12 --> Security Class Initialized
DEBUG - 2020-10-12 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:04:12 --> Input Class Initialized
INFO - 2020-10-12 12:04:12 --> Language Class Initialized
INFO - 2020-10-12 12:04:12 --> Loader Class Initialized
INFO - 2020-10-12 12:04:12 --> Helper loaded: url_helper
INFO - 2020-10-12 12:04:12 --> Database Driver Class Initialized
INFO - 2020-10-12 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:04:12 --> Email Class Initialized
INFO - 2020-10-12 12:04:12 --> Controller Class Initialized
DEBUG - 2020-10-12 12:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:04:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:04:12 --> Model Class Initialized
INFO - 2020-10-12 12:04:12 --> Model Class Initialized
INFO - 2020-10-12 12:04:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 12:04:12 --> Final output sent to browser
DEBUG - 2020-10-12 12:04:12 --> Total execution time: 0.0334
ERROR - 2020-10-12 12:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:04:12 --> Config Class Initialized
INFO - 2020-10-12 12:04:12 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:04:12 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:04:12 --> Utf8 Class Initialized
INFO - 2020-10-12 12:04:12 --> URI Class Initialized
INFO - 2020-10-12 12:04:12 --> Router Class Initialized
INFO - 2020-10-12 12:04:12 --> Output Class Initialized
INFO - 2020-10-12 12:04:12 --> Security Class Initialized
DEBUG - 2020-10-12 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:04:12 --> Input Class Initialized
INFO - 2020-10-12 12:04:12 --> Language Class Initialized
INFO - 2020-10-12 12:04:12 --> Loader Class Initialized
INFO - 2020-10-12 12:04:12 --> Helper loaded: url_helper
INFO - 2020-10-12 12:04:12 --> Database Driver Class Initialized
INFO - 2020-10-12 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:04:12 --> Email Class Initialized
INFO - 2020-10-12 12:04:12 --> Controller Class Initialized
DEBUG - 2020-10-12 12:04:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:04:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:04:12 --> Model Class Initialized
INFO - 2020-10-12 12:04:12 --> Model Class Initialized
INFO - 2020-10-12 12:04:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 12:04:12 --> Final output sent to browser
DEBUG - 2020-10-12 12:04:12 --> Total execution time: 0.0287
ERROR - 2020-10-12 12:04:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:04:14 --> Config Class Initialized
INFO - 2020-10-12 12:04:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:04:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:04:14 --> Utf8 Class Initialized
INFO - 2020-10-12 12:04:14 --> URI Class Initialized
INFO - 2020-10-12 12:04:14 --> Router Class Initialized
INFO - 2020-10-12 12:04:14 --> Output Class Initialized
INFO - 2020-10-12 12:04:14 --> Security Class Initialized
DEBUG - 2020-10-12 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:04:14 --> Input Class Initialized
INFO - 2020-10-12 12:04:14 --> Language Class Initialized
INFO - 2020-10-12 12:04:14 --> Loader Class Initialized
INFO - 2020-10-12 12:04:14 --> Helper loaded: url_helper
INFO - 2020-10-12 12:04:14 --> Database Driver Class Initialized
INFO - 2020-10-12 12:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:04:14 --> Email Class Initialized
INFO - 2020-10-12 12:04:14 --> Controller Class Initialized
DEBUG - 2020-10-12 12:04:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:04:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:04:14 --> Model Class Initialized
INFO - 2020-10-12 12:04:14 --> Model Class Initialized
INFO - 2020-10-12 12:04:14 --> Model Class Initialized
INFO - 2020-10-12 12:04:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:04:14 --> Final output sent to browser
DEBUG - 2020-10-12 12:04:14 --> Total execution time: 0.0265
ERROR - 2020-10-12 12:05:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:05:17 --> Config Class Initialized
INFO - 2020-10-12 12:05:17 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:05:17 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:05:17 --> Utf8 Class Initialized
INFO - 2020-10-12 12:05:17 --> URI Class Initialized
INFO - 2020-10-12 12:05:17 --> Router Class Initialized
INFO - 2020-10-12 12:05:17 --> Output Class Initialized
INFO - 2020-10-12 12:05:17 --> Security Class Initialized
DEBUG - 2020-10-12 12:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:05:17 --> Input Class Initialized
INFO - 2020-10-12 12:05:17 --> Language Class Initialized
INFO - 2020-10-12 12:05:17 --> Loader Class Initialized
INFO - 2020-10-12 12:05:17 --> Helper loaded: url_helper
INFO - 2020-10-12 12:05:17 --> Database Driver Class Initialized
INFO - 2020-10-12 12:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:05:17 --> Email Class Initialized
INFO - 2020-10-12 12:05:17 --> Controller Class Initialized
DEBUG - 2020-10-12 12:05:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:05:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:05:17 --> Model Class Initialized
INFO - 2020-10-12 12:05:17 --> Model Class Initialized
INFO - 2020-10-12 12:05:17 --> Model Class Initialized
INFO - 2020-10-12 12:05:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:05:17 --> Final output sent to browser
DEBUG - 2020-10-12 12:05:17 --> Total execution time: 0.0260
ERROR - 2020-10-12 12:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:07:18 --> Config Class Initialized
INFO - 2020-10-12 12:07:18 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:07:18 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:07:18 --> Utf8 Class Initialized
INFO - 2020-10-12 12:07:18 --> URI Class Initialized
INFO - 2020-10-12 12:07:18 --> Router Class Initialized
INFO - 2020-10-12 12:07:18 --> Output Class Initialized
INFO - 2020-10-12 12:07:18 --> Security Class Initialized
DEBUG - 2020-10-12 12:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:07:18 --> Input Class Initialized
INFO - 2020-10-12 12:07:18 --> Language Class Initialized
INFO - 2020-10-12 12:07:18 --> Loader Class Initialized
INFO - 2020-10-12 12:07:18 --> Helper loaded: url_helper
INFO - 2020-10-12 12:07:18 --> Database Driver Class Initialized
INFO - 2020-10-12 12:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:07:18 --> Email Class Initialized
INFO - 2020-10-12 12:07:18 --> Controller Class Initialized
DEBUG - 2020-10-12 12:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:07:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:07:18 --> Model Class Initialized
INFO - 2020-10-12 12:07:18 --> Model Class Initialized
INFO - 2020-10-12 12:07:18 --> Model Class Initialized
INFO - 2020-10-12 12:07:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:07:18 --> Final output sent to browser
DEBUG - 2020-10-12 12:07:18 --> Total execution time: 0.0215
ERROR - 2020-10-12 12:07:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:07:35 --> Config Class Initialized
INFO - 2020-10-12 12:07:35 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:07:35 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:07:35 --> Utf8 Class Initialized
INFO - 2020-10-12 12:07:35 --> URI Class Initialized
INFO - 2020-10-12 12:07:35 --> Router Class Initialized
INFO - 2020-10-12 12:07:35 --> Output Class Initialized
INFO - 2020-10-12 12:07:35 --> Security Class Initialized
DEBUG - 2020-10-12 12:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:07:35 --> Input Class Initialized
INFO - 2020-10-12 12:07:35 --> Language Class Initialized
INFO - 2020-10-12 12:07:35 --> Loader Class Initialized
INFO - 2020-10-12 12:07:35 --> Helper loaded: url_helper
INFO - 2020-10-12 12:07:35 --> Database Driver Class Initialized
INFO - 2020-10-12 12:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:07:35 --> Email Class Initialized
INFO - 2020-10-12 12:07:35 --> Controller Class Initialized
DEBUG - 2020-10-12 12:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:07:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:07:35 --> Model Class Initialized
INFO - 2020-10-12 12:07:35 --> Model Class Initialized
INFO - 2020-10-12 12:07:35 --> Model Class Initialized
INFO - 2020-10-12 12:07:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:07:35 --> Final output sent to browser
DEBUG - 2020-10-12 12:07:35 --> Total execution time: 0.0302
ERROR - 2020-10-12 12:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:09:03 --> Config Class Initialized
INFO - 2020-10-12 12:09:03 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:09:03 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:09:03 --> Utf8 Class Initialized
INFO - 2020-10-12 12:09:03 --> URI Class Initialized
INFO - 2020-10-12 12:09:03 --> Router Class Initialized
INFO - 2020-10-12 12:09:03 --> Output Class Initialized
INFO - 2020-10-12 12:09:03 --> Security Class Initialized
DEBUG - 2020-10-12 12:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:09:03 --> Input Class Initialized
INFO - 2020-10-12 12:09:04 --> Language Class Initialized
INFO - 2020-10-12 12:09:04 --> Loader Class Initialized
INFO - 2020-10-12 12:09:04 --> Helper loaded: url_helper
INFO - 2020-10-12 12:09:04 --> Database Driver Class Initialized
INFO - 2020-10-12 12:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:09:04 --> Email Class Initialized
INFO - 2020-10-12 12:09:04 --> Controller Class Initialized
DEBUG - 2020-10-12 12:09:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:09:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:09:04 --> Model Class Initialized
INFO - 2020-10-12 12:09:04 --> Model Class Initialized
INFO - 2020-10-12 12:09:04 --> Model Class Initialized
INFO - 2020-10-12 12:09:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 12:09:04 --> Final output sent to browser
DEBUG - 2020-10-12 12:09:04 --> Total execution time: 0.0299
ERROR - 2020-10-12 12:09:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:09:24 --> Config Class Initialized
INFO - 2020-10-12 12:09:24 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:09:24 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:09:24 --> Utf8 Class Initialized
INFO - 2020-10-12 12:09:24 --> URI Class Initialized
INFO - 2020-10-12 12:09:24 --> Router Class Initialized
INFO - 2020-10-12 12:09:24 --> Output Class Initialized
INFO - 2020-10-12 12:09:24 --> Security Class Initialized
DEBUG - 2020-10-12 12:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:09:24 --> Input Class Initialized
INFO - 2020-10-12 12:09:24 --> Language Class Initialized
INFO - 2020-10-12 12:09:24 --> Loader Class Initialized
INFO - 2020-10-12 12:09:24 --> Helper loaded: url_helper
INFO - 2020-10-12 12:09:24 --> Database Driver Class Initialized
INFO - 2020-10-12 12:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:09:24 --> Email Class Initialized
INFO - 2020-10-12 12:09:24 --> Controller Class Initialized
DEBUG - 2020-10-12 12:09:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:09:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:09:24 --> Model Class Initialized
INFO - 2020-10-12 12:09:24 --> Model Class Initialized
INFO - 2020-10-12 12:09:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 12:09:24 --> Final output sent to browser
DEBUG - 2020-10-12 12:09:24 --> Total execution time: 0.0283
ERROR - 2020-10-12 12:09:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:09:51 --> Config Class Initialized
INFO - 2020-10-12 12:09:51 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:09:51 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:09:51 --> Utf8 Class Initialized
INFO - 2020-10-12 12:09:51 --> URI Class Initialized
INFO - 2020-10-12 12:09:51 --> Router Class Initialized
INFO - 2020-10-12 12:09:51 --> Output Class Initialized
INFO - 2020-10-12 12:09:51 --> Security Class Initialized
DEBUG - 2020-10-12 12:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:09:51 --> Input Class Initialized
INFO - 2020-10-12 12:09:51 --> Language Class Initialized
INFO - 2020-10-12 12:09:51 --> Loader Class Initialized
INFO - 2020-10-12 12:09:51 --> Helper loaded: url_helper
INFO - 2020-10-12 12:09:51 --> Database Driver Class Initialized
INFO - 2020-10-12 12:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:09:51 --> Email Class Initialized
INFO - 2020-10-12 12:09:51 --> Controller Class Initialized
DEBUG - 2020-10-12 12:09:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:09:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:09:51 --> Model Class Initialized
INFO - 2020-10-12 12:09:51 --> Model Class Initialized
INFO - 2020-10-12 12:09:51 --> Model Class Initialized
INFO - 2020-10-12 12:09:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 12:09:51 --> Final output sent to browser
DEBUG - 2020-10-12 12:09:51 --> Total execution time: 0.0300
ERROR - 2020-10-12 12:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:10:26 --> Config Class Initialized
INFO - 2020-10-12 12:10:26 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:10:26 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:10:26 --> Utf8 Class Initialized
INFO - 2020-10-12 12:10:26 --> URI Class Initialized
INFO - 2020-10-12 12:10:26 --> Router Class Initialized
INFO - 2020-10-12 12:10:26 --> Output Class Initialized
INFO - 2020-10-12 12:10:26 --> Security Class Initialized
DEBUG - 2020-10-12 12:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:10:26 --> Input Class Initialized
INFO - 2020-10-12 12:10:26 --> Language Class Initialized
INFO - 2020-10-12 12:10:26 --> Loader Class Initialized
INFO - 2020-10-12 12:10:26 --> Helper loaded: url_helper
INFO - 2020-10-12 12:10:26 --> Database Driver Class Initialized
INFO - 2020-10-12 12:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:10:26 --> Email Class Initialized
INFO - 2020-10-12 12:10:26 --> Controller Class Initialized
DEBUG - 2020-10-12 12:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:10:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:10:26 --> Model Class Initialized
INFO - 2020-10-12 12:10:26 --> Model Class Initialized
INFO - 2020-10-12 12:10:26 --> Model Class Initialized
INFO - 2020-10-12 12:10:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-10-12 12:10:26 --> Final output sent to browser
DEBUG - 2020-10-12 12:10:26 --> Total execution time: 0.0225
ERROR - 2020-10-12 12:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:10:52 --> Config Class Initialized
INFO - 2020-10-12 12:10:52 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:10:52 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:10:52 --> Utf8 Class Initialized
INFO - 2020-10-12 12:10:52 --> URI Class Initialized
DEBUG - 2020-10-12 12:10:52 --> No URI present. Default controller set.
INFO - 2020-10-12 12:10:52 --> Router Class Initialized
INFO - 2020-10-12 12:10:52 --> Output Class Initialized
INFO - 2020-10-12 12:10:52 --> Security Class Initialized
DEBUG - 2020-10-12 12:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:10:52 --> Input Class Initialized
INFO - 2020-10-12 12:10:52 --> Language Class Initialized
INFO - 2020-10-12 12:10:52 --> Loader Class Initialized
INFO - 2020-10-12 12:10:52 --> Helper loaded: url_helper
INFO - 2020-10-12 12:10:52 --> Database Driver Class Initialized
INFO - 2020-10-12 12:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:10:52 --> Email Class Initialized
INFO - 2020-10-12 12:10:52 --> Controller Class Initialized
INFO - 2020-10-12 12:10:52 --> Model Class Initialized
INFO - 2020-10-12 12:10:52 --> Model Class Initialized
DEBUG - 2020-10-12 12:10:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:10:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 12:10:52 --> Final output sent to browser
DEBUG - 2020-10-12 12:10:52 --> Total execution time: 0.0251
ERROR - 2020-10-12 12:10:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:10:59 --> Config Class Initialized
INFO - 2020-10-12 12:10:59 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:10:59 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:10:59 --> Utf8 Class Initialized
INFO - 2020-10-12 12:10:59 --> URI Class Initialized
INFO - 2020-10-12 12:10:59 --> Router Class Initialized
INFO - 2020-10-12 12:10:59 --> Output Class Initialized
INFO - 2020-10-12 12:10:59 --> Security Class Initialized
DEBUG - 2020-10-12 12:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:10:59 --> Input Class Initialized
INFO - 2020-10-12 12:10:59 --> Language Class Initialized
INFO - 2020-10-12 12:10:59 --> Loader Class Initialized
INFO - 2020-10-12 12:10:59 --> Helper loaded: url_helper
INFO - 2020-10-12 12:10:59 --> Database Driver Class Initialized
INFO - 2020-10-12 12:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:10:59 --> Email Class Initialized
INFO - 2020-10-12 12:10:59 --> Controller Class Initialized
INFO - 2020-10-12 12:10:59 --> Model Class Initialized
INFO - 2020-10-12 12:10:59 --> Model Class Initialized
DEBUG - 2020-10-12 12:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:10:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:10:59 --> Model Class Initialized
INFO - 2020-10-12 12:10:59 --> Final output sent to browser
DEBUG - 2020-10-12 12:10:59 --> Total execution time: 0.0241
ERROR - 2020-10-12 12:10:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:10:59 --> Config Class Initialized
INFO - 2020-10-12 12:10:59 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:10:59 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:10:59 --> Utf8 Class Initialized
INFO - 2020-10-12 12:10:59 --> URI Class Initialized
INFO - 2020-10-12 12:10:59 --> Router Class Initialized
INFO - 2020-10-12 12:10:59 --> Output Class Initialized
INFO - 2020-10-12 12:10:59 --> Security Class Initialized
DEBUG - 2020-10-12 12:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:10:59 --> Input Class Initialized
INFO - 2020-10-12 12:10:59 --> Language Class Initialized
INFO - 2020-10-12 12:10:59 --> Loader Class Initialized
INFO - 2020-10-12 12:10:59 --> Helper loaded: url_helper
INFO - 2020-10-12 12:10:59 --> Database Driver Class Initialized
INFO - 2020-10-12 12:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:10:59 --> Email Class Initialized
INFO - 2020-10-12 12:10:59 --> Controller Class Initialized
INFO - 2020-10-12 12:10:59 --> Model Class Initialized
INFO - 2020-10-12 12:10:59 --> Model Class Initialized
DEBUG - 2020-10-12 12:10:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 12:11:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:11:00 --> Config Class Initialized
INFO - 2020-10-12 12:11:00 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:11:00 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:11:00 --> Utf8 Class Initialized
INFO - 2020-10-12 12:11:00 --> URI Class Initialized
INFO - 2020-10-12 12:11:00 --> Router Class Initialized
INFO - 2020-10-12 12:11:00 --> Output Class Initialized
INFO - 2020-10-12 12:11:00 --> Security Class Initialized
DEBUG - 2020-10-12 12:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:11:00 --> Input Class Initialized
INFO - 2020-10-12 12:11:00 --> Language Class Initialized
INFO - 2020-10-12 12:11:00 --> Loader Class Initialized
INFO - 2020-10-12 12:11:00 --> Helper loaded: url_helper
INFO - 2020-10-12 12:11:00 --> Database Driver Class Initialized
INFO - 2020-10-12 12:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:11:00 --> Email Class Initialized
INFO - 2020-10-12 12:11:00 --> Controller Class Initialized
DEBUG - 2020-10-12 12:11:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:11:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:11:00 --> Model Class Initialized
INFO - 2020-10-12 12:11:00 --> Model Class Initialized
INFO - 2020-10-12 12:11:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 12:11:00 --> Final output sent to browser
DEBUG - 2020-10-12 12:11:00 --> Total execution time: 0.0238
ERROR - 2020-10-12 12:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:11:04 --> Config Class Initialized
INFO - 2020-10-12 12:11:04 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:11:04 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:11:04 --> Utf8 Class Initialized
INFO - 2020-10-12 12:11:04 --> URI Class Initialized
INFO - 2020-10-12 12:11:04 --> Router Class Initialized
INFO - 2020-10-12 12:11:04 --> Output Class Initialized
INFO - 2020-10-12 12:11:04 --> Security Class Initialized
DEBUG - 2020-10-12 12:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:11:04 --> Input Class Initialized
INFO - 2020-10-12 12:11:04 --> Language Class Initialized
INFO - 2020-10-12 12:11:04 --> Loader Class Initialized
INFO - 2020-10-12 12:11:04 --> Helper loaded: url_helper
INFO - 2020-10-12 12:11:04 --> Database Driver Class Initialized
INFO - 2020-10-12 12:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:11:04 --> Email Class Initialized
INFO - 2020-10-12 12:11:04 --> Controller Class Initialized
DEBUG - 2020-10-12 12:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:11:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:11:04 --> Model Class Initialized
INFO - 2020-10-12 12:11:04 --> Model Class Initialized
INFO - 2020-10-12 12:11:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:11:04 --> Final output sent to browser
DEBUG - 2020-10-12 12:11:04 --> Total execution time: 0.0220
ERROR - 2020-10-12 12:11:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:11:19 --> Config Class Initialized
INFO - 2020-10-12 12:11:19 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:11:19 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:11:19 --> Utf8 Class Initialized
INFO - 2020-10-12 12:11:19 --> URI Class Initialized
INFO - 2020-10-12 12:11:19 --> Router Class Initialized
INFO - 2020-10-12 12:11:19 --> Output Class Initialized
INFO - 2020-10-12 12:11:19 --> Security Class Initialized
DEBUG - 2020-10-12 12:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:11:19 --> Input Class Initialized
INFO - 2020-10-12 12:11:19 --> Language Class Initialized
INFO - 2020-10-12 12:11:19 --> Loader Class Initialized
INFO - 2020-10-12 12:11:19 --> Helper loaded: url_helper
INFO - 2020-10-12 12:11:19 --> Database Driver Class Initialized
INFO - 2020-10-12 12:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:11:19 --> Email Class Initialized
INFO - 2020-10-12 12:11:19 --> Controller Class Initialized
DEBUG - 2020-10-12 12:11:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:11:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:11:19 --> Model Class Initialized
INFO - 2020-10-12 12:11:19 --> Model Class Initialized
INFO - 2020-10-12 12:11:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 12:11:19 --> Final output sent to browser
DEBUG - 2020-10-12 12:11:19 --> Total execution time: 0.0242
ERROR - 2020-10-12 12:11:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:11:25 --> Config Class Initialized
INFO - 2020-10-12 12:11:25 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:11:25 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:11:25 --> Utf8 Class Initialized
INFO - 2020-10-12 12:11:25 --> URI Class Initialized
INFO - 2020-10-12 12:11:25 --> Router Class Initialized
INFO - 2020-10-12 12:11:25 --> Output Class Initialized
INFO - 2020-10-12 12:11:25 --> Security Class Initialized
DEBUG - 2020-10-12 12:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:11:25 --> Input Class Initialized
INFO - 2020-10-12 12:11:25 --> Language Class Initialized
INFO - 2020-10-12 12:11:25 --> Loader Class Initialized
INFO - 2020-10-12 12:11:25 --> Helper loaded: url_helper
INFO - 2020-10-12 12:11:25 --> Database Driver Class Initialized
INFO - 2020-10-12 12:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:11:25 --> Email Class Initialized
INFO - 2020-10-12 12:11:25 --> Controller Class Initialized
DEBUG - 2020-10-12 12:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:11:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:11:25 --> Model Class Initialized
INFO - 2020-10-12 12:11:25 --> Model Class Initialized
INFO - 2020-10-12 12:11:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:11:25 --> Final output sent to browser
DEBUG - 2020-10-12 12:11:25 --> Total execution time: 0.0231
ERROR - 2020-10-12 12:12:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:12:47 --> Config Class Initialized
INFO - 2020-10-12 12:12:47 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:12:47 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:12:47 --> Utf8 Class Initialized
INFO - 2020-10-12 12:12:47 --> URI Class Initialized
INFO - 2020-10-12 12:12:47 --> Router Class Initialized
INFO - 2020-10-12 12:12:47 --> Output Class Initialized
INFO - 2020-10-12 12:12:47 --> Security Class Initialized
DEBUG - 2020-10-12 12:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:12:47 --> Input Class Initialized
INFO - 2020-10-12 12:12:47 --> Language Class Initialized
INFO - 2020-10-12 12:12:47 --> Loader Class Initialized
INFO - 2020-10-12 12:12:47 --> Helper loaded: url_helper
INFO - 2020-10-12 12:12:47 --> Database Driver Class Initialized
INFO - 2020-10-12 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:12:47 --> Email Class Initialized
INFO - 2020-10-12 12:12:47 --> Controller Class Initialized
DEBUG - 2020-10-12 12:12:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:12:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:12:47 --> Model Class Initialized
INFO - 2020-10-12 12:12:47 --> Model Class Initialized
INFO - 2020-10-12 12:12:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:12:47 --> Final output sent to browser
DEBUG - 2020-10-12 12:12:47 --> Total execution time: 0.0298
ERROR - 2020-10-12 12:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:13:25 --> Config Class Initialized
INFO - 2020-10-12 12:13:25 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:13:25 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:13:25 --> Utf8 Class Initialized
INFO - 2020-10-12 12:13:25 --> URI Class Initialized
INFO - 2020-10-12 12:13:25 --> Router Class Initialized
INFO - 2020-10-12 12:13:25 --> Output Class Initialized
INFO - 2020-10-12 12:13:25 --> Security Class Initialized
DEBUG - 2020-10-12 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:13:25 --> Input Class Initialized
INFO - 2020-10-12 12:13:25 --> Language Class Initialized
INFO - 2020-10-12 12:13:25 --> Loader Class Initialized
INFO - 2020-10-12 12:13:25 --> Helper loaded: url_helper
INFO - 2020-10-12 12:13:25 --> Database Driver Class Initialized
INFO - 2020-10-12 12:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:13:25 --> Email Class Initialized
INFO - 2020-10-12 12:13:25 --> Controller Class Initialized
DEBUG - 2020-10-12 12:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:13:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:13:25 --> Model Class Initialized
INFO - 2020-10-12 12:13:25 --> Model Class Initialized
INFO - 2020-10-12 12:13:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:13:25 --> Final output sent to browser
DEBUG - 2020-10-12 12:13:25 --> Total execution time: 0.0241
ERROR - 2020-10-12 12:13:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:13:30 --> Config Class Initialized
INFO - 2020-10-12 12:13:30 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:13:30 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:13:30 --> Utf8 Class Initialized
INFO - 2020-10-12 12:13:30 --> URI Class Initialized
INFO - 2020-10-12 12:13:30 --> Router Class Initialized
INFO - 2020-10-12 12:13:30 --> Output Class Initialized
INFO - 2020-10-12 12:13:30 --> Security Class Initialized
DEBUG - 2020-10-12 12:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:13:30 --> Input Class Initialized
INFO - 2020-10-12 12:13:30 --> Language Class Initialized
INFO - 2020-10-12 12:13:30 --> Loader Class Initialized
INFO - 2020-10-12 12:13:30 --> Helper loaded: url_helper
INFO - 2020-10-12 12:13:30 --> Database Driver Class Initialized
INFO - 2020-10-12 12:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:13:30 --> Email Class Initialized
INFO - 2020-10-12 12:13:30 --> Controller Class Initialized
DEBUG - 2020-10-12 12:13:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:13:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:13:30 --> Model Class Initialized
INFO - 2020-10-12 12:13:30 --> Model Class Initialized
INFO - 2020-10-12 12:13:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-12 12:13:30 --> Final output sent to browser
DEBUG - 2020-10-12 12:13:30 --> Total execution time: 0.0315
ERROR - 2020-10-12 12:13:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:13:42 --> Config Class Initialized
INFO - 2020-10-12 12:13:42 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:13:42 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:13:42 --> Utf8 Class Initialized
INFO - 2020-10-12 12:13:42 --> URI Class Initialized
INFO - 2020-10-12 12:13:42 --> Router Class Initialized
INFO - 2020-10-12 12:13:42 --> Output Class Initialized
INFO - 2020-10-12 12:13:42 --> Security Class Initialized
DEBUG - 2020-10-12 12:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:13:42 --> Input Class Initialized
INFO - 2020-10-12 12:13:42 --> Language Class Initialized
INFO - 2020-10-12 12:13:42 --> Loader Class Initialized
INFO - 2020-10-12 12:13:42 --> Helper loaded: url_helper
INFO - 2020-10-12 12:13:42 --> Database Driver Class Initialized
INFO - 2020-10-12 12:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:13:42 --> Email Class Initialized
INFO - 2020-10-12 12:13:42 --> Controller Class Initialized
DEBUG - 2020-10-12 12:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:13:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:13:42 --> Model Class Initialized
INFO - 2020-10-12 12:13:42 --> Model Class Initialized
INFO - 2020-10-12 12:13:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:13:42 --> Final output sent to browser
DEBUG - 2020-10-12 12:13:42 --> Total execution time: 0.0258
ERROR - 2020-10-12 12:13:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:13:45 --> Config Class Initialized
INFO - 2020-10-12 12:13:45 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:13:45 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:13:45 --> Utf8 Class Initialized
INFO - 2020-10-12 12:13:45 --> URI Class Initialized
INFO - 2020-10-12 12:13:45 --> Router Class Initialized
INFO - 2020-10-12 12:13:45 --> Output Class Initialized
INFO - 2020-10-12 12:13:45 --> Security Class Initialized
DEBUG - 2020-10-12 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:13:45 --> Input Class Initialized
INFO - 2020-10-12 12:13:45 --> Language Class Initialized
INFO - 2020-10-12 12:13:45 --> Loader Class Initialized
INFO - 2020-10-12 12:13:45 --> Helper loaded: url_helper
INFO - 2020-10-12 12:13:45 --> Database Driver Class Initialized
INFO - 2020-10-12 12:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:13:45 --> Email Class Initialized
INFO - 2020-10-12 12:13:45 --> Controller Class Initialized
DEBUG - 2020-10-12 12:13:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:13:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:13:45 --> Model Class Initialized
INFO - 2020-10-12 12:13:45 --> Model Class Initialized
INFO - 2020-10-12 12:13:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 12:13:45 --> Final output sent to browser
DEBUG - 2020-10-12 12:13:45 --> Total execution time: 0.0197
ERROR - 2020-10-12 12:15:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:15:23 --> Config Class Initialized
INFO - 2020-10-12 12:15:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:15:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:15:23 --> Utf8 Class Initialized
INFO - 2020-10-12 12:15:23 --> URI Class Initialized
INFO - 2020-10-12 12:15:23 --> Router Class Initialized
INFO - 2020-10-12 12:15:23 --> Output Class Initialized
INFO - 2020-10-12 12:15:23 --> Security Class Initialized
DEBUG - 2020-10-12 12:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:15:23 --> Input Class Initialized
INFO - 2020-10-12 12:15:23 --> Language Class Initialized
INFO - 2020-10-12 12:15:23 --> Loader Class Initialized
INFO - 2020-10-12 12:15:23 --> Helper loaded: url_helper
INFO - 2020-10-12 12:15:23 --> Database Driver Class Initialized
INFO - 2020-10-12 12:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:15:23 --> Email Class Initialized
INFO - 2020-10-12 12:15:23 --> Controller Class Initialized
DEBUG - 2020-10-12 12:15:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:15:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:15:23 --> Model Class Initialized
INFO - 2020-10-12 12:15:23 --> Model Class Initialized
INFO - 2020-10-12 12:15:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 12:15:23 --> Final output sent to browser
DEBUG - 2020-10-12 12:15:23 --> Total execution time: 0.0246
ERROR - 2020-10-12 12:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:18:34 --> Config Class Initialized
INFO - 2020-10-12 12:18:34 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:18:34 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:18:34 --> Utf8 Class Initialized
INFO - 2020-10-12 12:18:34 --> URI Class Initialized
INFO - 2020-10-12 12:18:34 --> Router Class Initialized
INFO - 2020-10-12 12:18:34 --> Output Class Initialized
INFO - 2020-10-12 12:18:34 --> Security Class Initialized
DEBUG - 2020-10-12 12:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:18:34 --> Input Class Initialized
INFO - 2020-10-12 12:18:34 --> Language Class Initialized
INFO - 2020-10-12 12:18:34 --> Loader Class Initialized
INFO - 2020-10-12 12:18:34 --> Helper loaded: url_helper
INFO - 2020-10-12 12:18:34 --> Database Driver Class Initialized
INFO - 2020-10-12 12:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:18:34 --> Email Class Initialized
INFO - 2020-10-12 12:18:34 --> Controller Class Initialized
DEBUG - 2020-10-12 12:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:18:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:18:34 --> Model Class Initialized
INFO - 2020-10-12 12:18:34 --> Model Class Initialized
INFO - 2020-10-12 12:18:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 12:18:34 --> Final output sent to browser
DEBUG - 2020-10-12 12:18:34 --> Total execution time: 0.0235
ERROR - 2020-10-12 12:18:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:18:50 --> Config Class Initialized
INFO - 2020-10-12 12:18:50 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:18:50 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:18:50 --> Utf8 Class Initialized
INFO - 2020-10-12 12:18:50 --> URI Class Initialized
INFO - 2020-10-12 12:18:50 --> Router Class Initialized
INFO - 2020-10-12 12:18:50 --> Output Class Initialized
INFO - 2020-10-12 12:18:50 --> Security Class Initialized
DEBUG - 2020-10-12 12:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:18:50 --> Input Class Initialized
INFO - 2020-10-12 12:18:50 --> Language Class Initialized
INFO - 2020-10-12 12:18:51 --> Loader Class Initialized
INFO - 2020-10-12 12:18:51 --> Helper loaded: url_helper
INFO - 2020-10-12 12:18:51 --> Database Driver Class Initialized
INFO - 2020-10-12 12:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:18:51 --> Email Class Initialized
INFO - 2020-10-12 12:18:51 --> Controller Class Initialized
DEBUG - 2020-10-12 12:18:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:18:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:18:51 --> Model Class Initialized
INFO - 2020-10-12 12:18:51 --> Model Class Initialized
INFO - 2020-10-12 12:18:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:18:51 --> Final output sent to browser
DEBUG - 2020-10-12 12:18:51 --> Total execution time: 0.0214
ERROR - 2020-10-12 12:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:18:55 --> Config Class Initialized
INFO - 2020-10-12 12:18:55 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:18:55 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:18:55 --> Utf8 Class Initialized
INFO - 2020-10-12 12:18:55 --> URI Class Initialized
INFO - 2020-10-12 12:18:55 --> Router Class Initialized
INFO - 2020-10-12 12:18:55 --> Output Class Initialized
INFO - 2020-10-12 12:18:55 --> Security Class Initialized
DEBUG - 2020-10-12 12:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:18:55 --> Input Class Initialized
INFO - 2020-10-12 12:18:55 --> Language Class Initialized
INFO - 2020-10-12 12:18:55 --> Loader Class Initialized
INFO - 2020-10-12 12:18:55 --> Helper loaded: url_helper
INFO - 2020-10-12 12:18:55 --> Database Driver Class Initialized
INFO - 2020-10-12 12:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:18:55 --> Email Class Initialized
INFO - 2020-10-12 12:18:55 --> Controller Class Initialized
DEBUG - 2020-10-12 12:18:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:18:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:18:55 --> Model Class Initialized
INFO - 2020-10-12 12:18:55 --> Model Class Initialized
INFO - 2020-10-12 12:18:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 12:18:55 --> Final output sent to browser
DEBUG - 2020-10-12 12:18:55 --> Total execution time: 0.0225
ERROR - 2020-10-12 12:19:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:19:16 --> Config Class Initialized
INFO - 2020-10-12 12:19:16 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:19:16 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:19:16 --> Utf8 Class Initialized
INFO - 2020-10-12 12:19:16 --> URI Class Initialized
INFO - 2020-10-12 12:19:16 --> Router Class Initialized
INFO - 2020-10-12 12:19:16 --> Output Class Initialized
INFO - 2020-10-12 12:19:16 --> Security Class Initialized
DEBUG - 2020-10-12 12:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:19:16 --> Input Class Initialized
INFO - 2020-10-12 12:19:16 --> Language Class Initialized
INFO - 2020-10-12 12:19:16 --> Loader Class Initialized
INFO - 2020-10-12 12:19:16 --> Helper loaded: url_helper
INFO - 2020-10-12 12:19:16 --> Database Driver Class Initialized
INFO - 2020-10-12 12:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:19:16 --> Email Class Initialized
INFO - 2020-10-12 12:19:16 --> Controller Class Initialized
DEBUG - 2020-10-12 12:19:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:19:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:19:16 --> Model Class Initialized
INFO - 2020-10-12 12:19:16 --> Model Class Initialized
INFO - 2020-10-12 12:19:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:19:16 --> Final output sent to browser
DEBUG - 2020-10-12 12:19:16 --> Total execution time: 0.0320
ERROR - 2020-10-12 12:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:19:24 --> Config Class Initialized
INFO - 2020-10-12 12:19:24 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:19:24 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:19:24 --> Utf8 Class Initialized
INFO - 2020-10-12 12:19:24 --> URI Class Initialized
INFO - 2020-10-12 12:19:24 --> Router Class Initialized
INFO - 2020-10-12 12:19:24 --> Output Class Initialized
INFO - 2020-10-12 12:19:24 --> Security Class Initialized
DEBUG - 2020-10-12 12:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:19:24 --> Input Class Initialized
INFO - 2020-10-12 12:19:24 --> Language Class Initialized
INFO - 2020-10-12 12:19:24 --> Loader Class Initialized
INFO - 2020-10-12 12:19:24 --> Helper loaded: url_helper
INFO - 2020-10-12 12:19:24 --> Database Driver Class Initialized
INFO - 2020-10-12 12:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:19:24 --> Email Class Initialized
INFO - 2020-10-12 12:19:24 --> Controller Class Initialized
DEBUG - 2020-10-12 12:19:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:19:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:19:24 --> Model Class Initialized
INFO - 2020-10-12 12:19:24 --> Model Class Initialized
INFO - 2020-10-12 12:19:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-12 12:19:24 --> Final output sent to browser
DEBUG - 2020-10-12 12:19:24 --> Total execution time: 0.0226
ERROR - 2020-10-12 12:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:19:44 --> Config Class Initialized
INFO - 2020-10-12 12:19:44 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:19:44 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:19:44 --> Utf8 Class Initialized
INFO - 2020-10-12 12:19:44 --> URI Class Initialized
INFO - 2020-10-12 12:19:44 --> Router Class Initialized
INFO - 2020-10-12 12:19:44 --> Output Class Initialized
INFO - 2020-10-12 12:19:44 --> Security Class Initialized
DEBUG - 2020-10-12 12:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:19:44 --> Input Class Initialized
INFO - 2020-10-12 12:19:44 --> Language Class Initialized
INFO - 2020-10-12 12:19:44 --> Loader Class Initialized
INFO - 2020-10-12 12:19:44 --> Helper loaded: url_helper
INFO - 2020-10-12 12:19:44 --> Database Driver Class Initialized
INFO - 2020-10-12 12:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:19:44 --> Email Class Initialized
INFO - 2020-10-12 12:19:44 --> Controller Class Initialized
DEBUG - 2020-10-12 12:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 12:19:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:19:44 --> Model Class Initialized
INFO - 2020-10-12 12:19:44 --> Model Class Initialized
INFO - 2020-10-12 12:19:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 12:19:44 --> Final output sent to browser
DEBUG - 2020-10-12 12:19:44 --> Total execution time: 0.0269
ERROR - 2020-10-12 12:20:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 12:20:12 --> Config Class Initialized
INFO - 2020-10-12 12:20:12 --> Hooks Class Initialized
DEBUG - 2020-10-12 12:20:12 --> UTF-8 Support Enabled
INFO - 2020-10-12 12:20:12 --> Utf8 Class Initialized
INFO - 2020-10-12 12:20:12 --> URI Class Initialized
DEBUG - 2020-10-12 12:20:12 --> No URI present. Default controller set.
INFO - 2020-10-12 12:20:12 --> Router Class Initialized
INFO - 2020-10-12 12:20:12 --> Output Class Initialized
INFO - 2020-10-12 12:20:12 --> Security Class Initialized
DEBUG - 2020-10-12 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 12:20:12 --> Input Class Initialized
INFO - 2020-10-12 12:20:12 --> Language Class Initialized
INFO - 2020-10-12 12:20:12 --> Loader Class Initialized
INFO - 2020-10-12 12:20:12 --> Helper loaded: url_helper
INFO - 2020-10-12 12:20:12 --> Database Driver Class Initialized
INFO - 2020-10-12 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 12:20:12 --> Email Class Initialized
INFO - 2020-10-12 12:20:12 --> Controller Class Initialized
INFO - 2020-10-12 12:20:12 --> Model Class Initialized
INFO - 2020-10-12 12:20:12 --> Model Class Initialized
DEBUG - 2020-10-12 12:20:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 12:20:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 12:20:12 --> Final output sent to browser
DEBUG - 2020-10-12 12:20:12 --> Total execution time: 0.0252
ERROR - 2020-10-12 14:24:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:24:13 --> Config Class Initialized
INFO - 2020-10-12 14:24:13 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:24:13 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:24:13 --> Utf8 Class Initialized
INFO - 2020-10-12 14:24:13 --> URI Class Initialized
DEBUG - 2020-10-12 14:24:13 --> No URI present. Default controller set.
INFO - 2020-10-12 14:24:13 --> Router Class Initialized
INFO - 2020-10-12 14:24:13 --> Output Class Initialized
INFO - 2020-10-12 14:24:13 --> Security Class Initialized
DEBUG - 2020-10-12 14:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:24:13 --> Input Class Initialized
INFO - 2020-10-12 14:24:13 --> Language Class Initialized
INFO - 2020-10-12 14:24:13 --> Loader Class Initialized
INFO - 2020-10-12 14:24:13 --> Helper loaded: url_helper
INFO - 2020-10-12 14:24:13 --> Database Driver Class Initialized
INFO - 2020-10-12 14:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:24:13 --> Email Class Initialized
INFO - 2020-10-12 14:24:13 --> Controller Class Initialized
INFO - 2020-10-12 14:24:13 --> Model Class Initialized
INFO - 2020-10-12 14:24:13 --> Model Class Initialized
DEBUG - 2020-10-12 14:24:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:24:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:24:13 --> Final output sent to browser
DEBUG - 2020-10-12 14:24:13 --> Total execution time: 0.0190
ERROR - 2020-10-12 14:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:26:10 --> Config Class Initialized
INFO - 2020-10-12 14:26:10 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:26:10 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:26:10 --> Utf8 Class Initialized
INFO - 2020-10-12 14:26:10 --> URI Class Initialized
INFO - 2020-10-12 14:26:10 --> Router Class Initialized
INFO - 2020-10-12 14:26:10 --> Output Class Initialized
INFO - 2020-10-12 14:26:10 --> Security Class Initialized
DEBUG - 2020-10-12 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:26:10 --> Input Class Initialized
INFO - 2020-10-12 14:26:10 --> Language Class Initialized
INFO - 2020-10-12 14:26:10 --> Loader Class Initialized
INFO - 2020-10-12 14:26:10 --> Helper loaded: url_helper
INFO - 2020-10-12 14:26:10 --> Database Driver Class Initialized
INFO - 2020-10-12 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:26:10 --> Email Class Initialized
INFO - 2020-10-12 14:26:10 --> Controller Class Initialized
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
DEBUG - 2020-10-12 14:26:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:26:10 --> Config Class Initialized
INFO - 2020-10-12 14:26:10 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:26:10 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:26:10 --> Utf8 Class Initialized
INFO - 2020-10-12 14:26:10 --> URI Class Initialized
INFO - 2020-10-12 14:26:10 --> Router Class Initialized
INFO - 2020-10-12 14:26:10 --> Output Class Initialized
INFO - 2020-10-12 14:26:10 --> Security Class Initialized
DEBUG - 2020-10-12 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:26:10 --> Input Class Initialized
INFO - 2020-10-12 14:26:10 --> Language Class Initialized
INFO - 2020-10-12 14:26:10 --> Loader Class Initialized
INFO - 2020-10-12 14:26:10 --> Helper loaded: url_helper
INFO - 2020-10-12 14:26:10 --> Database Driver Class Initialized
INFO - 2020-10-12 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:26:10 --> Email Class Initialized
INFO - 2020-10-12 14:26:10 --> Controller Class Initialized
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
DEBUG - 2020-10-12 14:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:26:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
INFO - 2020-10-12 14:26:10 --> Final output sent to browser
DEBUG - 2020-10-12 14:26:10 --> Total execution time: 0.0319
ERROR - 2020-10-12 14:26:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:26:10 --> Config Class Initialized
INFO - 2020-10-12 14:26:10 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:26:10 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:26:10 --> Utf8 Class Initialized
INFO - 2020-10-12 14:26:10 --> URI Class Initialized
INFO - 2020-10-12 14:26:10 --> Router Class Initialized
INFO - 2020-10-12 14:26:10 --> Output Class Initialized
INFO - 2020-10-12 14:26:10 --> Security Class Initialized
DEBUG - 2020-10-12 14:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:26:10 --> Input Class Initialized
INFO - 2020-10-12 14:26:10 --> Language Class Initialized
INFO - 2020-10-12 14:26:10 --> Loader Class Initialized
INFO - 2020-10-12 14:26:10 --> Helper loaded: url_helper
INFO - 2020-10-12 14:26:10 --> Database Driver Class Initialized
INFO - 2020-10-12 14:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:26:10 --> Email Class Initialized
INFO - 2020-10-12 14:26:10 --> Controller Class Initialized
DEBUG - 2020-10-12 14:26:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:26:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
INFO - 2020-10-12 14:26:10 --> Model Class Initialized
INFO - 2020-10-12 14:26:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-12 14:26:10 --> Final output sent to browser
DEBUG - 2020-10-12 14:26:10 --> Total execution time: 0.0352
ERROR - 2020-10-12 14:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:26:17 --> Config Class Initialized
INFO - 2020-10-12 14:26:17 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:26:17 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:26:17 --> Utf8 Class Initialized
INFO - 2020-10-12 14:26:17 --> URI Class Initialized
INFO - 2020-10-12 14:26:17 --> Router Class Initialized
INFO - 2020-10-12 14:26:17 --> Output Class Initialized
INFO - 2020-10-12 14:26:17 --> Security Class Initialized
DEBUG - 2020-10-12 14:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:26:17 --> Input Class Initialized
INFO - 2020-10-12 14:26:17 --> Language Class Initialized
INFO - 2020-10-12 14:26:17 --> Loader Class Initialized
INFO - 2020-10-12 14:26:17 --> Helper loaded: url_helper
INFO - 2020-10-12 14:26:17 --> Database Driver Class Initialized
INFO - 2020-10-12 14:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:26:17 --> Email Class Initialized
INFO - 2020-10-12 14:26:17 --> Controller Class Initialized
DEBUG - 2020-10-12 14:26:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:26:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:26:17 --> Model Class Initialized
INFO - 2020-10-12 14:26:17 --> Model Class Initialized
INFO - 2020-10-12 14:26:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:26:17 --> Final output sent to browser
DEBUG - 2020-10-12 14:26:17 --> Total execution time: 0.0293
ERROR - 2020-10-12 14:26:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:26:57 --> Config Class Initialized
INFO - 2020-10-12 14:26:57 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:26:57 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:26:57 --> Utf8 Class Initialized
INFO - 2020-10-12 14:26:57 --> URI Class Initialized
INFO - 2020-10-12 14:26:57 --> Router Class Initialized
INFO - 2020-10-12 14:26:57 --> Output Class Initialized
INFO - 2020-10-12 14:26:57 --> Security Class Initialized
DEBUG - 2020-10-12 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:26:57 --> Input Class Initialized
INFO - 2020-10-12 14:26:57 --> Language Class Initialized
INFO - 2020-10-12 14:26:57 --> Loader Class Initialized
INFO - 2020-10-12 14:26:57 --> Helper loaded: url_helper
INFO - 2020-10-12 14:26:57 --> Database Driver Class Initialized
INFO - 2020-10-12 14:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:26:57 --> Email Class Initialized
INFO - 2020-10-12 14:26:57 --> Controller Class Initialized
DEBUG - 2020-10-12 14:26:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:26:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:26:57 --> Model Class Initialized
INFO - 2020-10-12 14:26:57 --> Model Class Initialized
INFO - 2020-10-12 14:26:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:26:57 --> Final output sent to browser
DEBUG - 2020-10-12 14:26:57 --> Total execution time: 0.0267
ERROR - 2020-10-12 14:27:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:27:37 --> Config Class Initialized
INFO - 2020-10-12 14:27:37 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:27:37 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:27:37 --> Utf8 Class Initialized
INFO - 2020-10-12 14:27:37 --> URI Class Initialized
INFO - 2020-10-12 14:27:37 --> Router Class Initialized
INFO - 2020-10-12 14:27:37 --> Output Class Initialized
INFO - 2020-10-12 14:27:37 --> Security Class Initialized
DEBUG - 2020-10-12 14:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:27:37 --> Input Class Initialized
INFO - 2020-10-12 14:27:37 --> Language Class Initialized
INFO - 2020-10-12 14:27:37 --> Loader Class Initialized
INFO - 2020-10-12 14:27:37 --> Helper loaded: url_helper
INFO - 2020-10-12 14:27:37 --> Database Driver Class Initialized
INFO - 2020-10-12 14:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:27:37 --> Email Class Initialized
INFO - 2020-10-12 14:27:37 --> Controller Class Initialized
DEBUG - 2020-10-12 14:27:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:27:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:27:37 --> Model Class Initialized
INFO - 2020-10-12 14:27:37 --> Model Class Initialized
INFO - 2020-10-12 14:27:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:27:37 --> Final output sent to browser
DEBUG - 2020-10-12 14:27:37 --> Total execution time: 0.0226
ERROR - 2020-10-12 14:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:27:42 --> Config Class Initialized
INFO - 2020-10-12 14:27:42 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:27:42 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:27:42 --> Utf8 Class Initialized
INFO - 2020-10-12 14:27:42 --> URI Class Initialized
INFO - 2020-10-12 14:27:42 --> Router Class Initialized
INFO - 2020-10-12 14:27:42 --> Output Class Initialized
INFO - 2020-10-12 14:27:42 --> Security Class Initialized
DEBUG - 2020-10-12 14:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:27:42 --> Input Class Initialized
INFO - 2020-10-12 14:27:42 --> Language Class Initialized
INFO - 2020-10-12 14:27:42 --> Loader Class Initialized
INFO - 2020-10-12 14:27:42 --> Helper loaded: url_helper
INFO - 2020-10-12 14:27:42 --> Database Driver Class Initialized
INFO - 2020-10-12 14:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:27:42 --> Email Class Initialized
INFO - 2020-10-12 14:27:42 --> Controller Class Initialized
DEBUG - 2020-10-12 14:27:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:27:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:27:42 --> Model Class Initialized
INFO - 2020-10-12 14:27:42 --> Model Class Initialized
INFO - 2020-10-12 14:27:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:27:42 --> Final output sent to browser
DEBUG - 2020-10-12 14:27:42 --> Total execution time: 0.0229
ERROR - 2020-10-12 14:28:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:28:22 --> Config Class Initialized
INFO - 2020-10-12 14:28:22 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:28:22 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:28:22 --> Utf8 Class Initialized
INFO - 2020-10-12 14:28:22 --> URI Class Initialized
INFO - 2020-10-12 14:28:22 --> Router Class Initialized
INFO - 2020-10-12 14:28:22 --> Output Class Initialized
INFO - 2020-10-12 14:28:22 --> Security Class Initialized
DEBUG - 2020-10-12 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:28:22 --> Input Class Initialized
INFO - 2020-10-12 14:28:22 --> Language Class Initialized
INFO - 2020-10-12 14:28:22 --> Loader Class Initialized
INFO - 2020-10-12 14:28:22 --> Helper loaded: url_helper
INFO - 2020-10-12 14:28:22 --> Database Driver Class Initialized
INFO - 2020-10-12 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:28:22 --> Email Class Initialized
INFO - 2020-10-12 14:28:22 --> Controller Class Initialized
DEBUG - 2020-10-12 14:28:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:28:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:28:22 --> Model Class Initialized
INFO - 2020-10-12 14:28:22 --> Model Class Initialized
INFO - 2020-10-12 14:28:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:28:22 --> Final output sent to browser
DEBUG - 2020-10-12 14:28:22 --> Total execution time: 0.0329
ERROR - 2020-10-12 14:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:28:46 --> Config Class Initialized
INFO - 2020-10-12 14:28:46 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:28:46 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:28:46 --> Utf8 Class Initialized
INFO - 2020-10-12 14:28:46 --> URI Class Initialized
INFO - 2020-10-12 14:28:46 --> Router Class Initialized
INFO - 2020-10-12 14:28:46 --> Output Class Initialized
INFO - 2020-10-12 14:28:46 --> Security Class Initialized
DEBUG - 2020-10-12 14:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:28:46 --> Input Class Initialized
INFO - 2020-10-12 14:28:46 --> Language Class Initialized
INFO - 2020-10-12 14:28:46 --> Loader Class Initialized
INFO - 2020-10-12 14:28:46 --> Helper loaded: url_helper
INFO - 2020-10-12 14:28:46 --> Database Driver Class Initialized
INFO - 2020-10-12 14:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:28:46 --> Email Class Initialized
INFO - 2020-10-12 14:28:46 --> Controller Class Initialized
DEBUG - 2020-10-12 14:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:28:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:28:46 --> Model Class Initialized
INFO - 2020-10-12 14:28:46 --> Model Class Initialized
INFO - 2020-10-12 14:28:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:28:46 --> Final output sent to browser
DEBUG - 2020-10-12 14:28:46 --> Total execution time: 0.0232
ERROR - 2020-10-12 14:28:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:28:53 --> Config Class Initialized
INFO - 2020-10-12 14:28:53 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:28:53 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:28:53 --> Utf8 Class Initialized
INFO - 2020-10-12 14:28:53 --> URI Class Initialized
DEBUG - 2020-10-12 14:28:53 --> No URI present. Default controller set.
INFO - 2020-10-12 14:28:53 --> Router Class Initialized
INFO - 2020-10-12 14:28:53 --> Output Class Initialized
INFO - 2020-10-12 14:28:53 --> Security Class Initialized
DEBUG - 2020-10-12 14:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:28:53 --> Input Class Initialized
INFO - 2020-10-12 14:28:53 --> Language Class Initialized
INFO - 2020-10-12 14:28:53 --> Loader Class Initialized
INFO - 2020-10-12 14:28:53 --> Helper loaded: url_helper
INFO - 2020-10-12 14:28:53 --> Database Driver Class Initialized
INFO - 2020-10-12 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:28:53 --> Email Class Initialized
INFO - 2020-10-12 14:28:53 --> Controller Class Initialized
INFO - 2020-10-12 14:28:53 --> Model Class Initialized
INFO - 2020-10-12 14:28:53 --> Model Class Initialized
DEBUG - 2020-10-12 14:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:28:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:28:53 --> Final output sent to browser
DEBUG - 2020-10-12 14:28:53 --> Total execution time: 0.0199
ERROR - 2020-10-12 14:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:28:56 --> Config Class Initialized
INFO - 2020-10-12 14:28:56 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:28:56 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:28:56 --> Utf8 Class Initialized
INFO - 2020-10-12 14:28:56 --> URI Class Initialized
INFO - 2020-10-12 14:28:56 --> Router Class Initialized
INFO - 2020-10-12 14:28:56 --> Output Class Initialized
INFO - 2020-10-12 14:28:56 --> Security Class Initialized
DEBUG - 2020-10-12 14:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:28:56 --> Input Class Initialized
INFO - 2020-10-12 14:28:56 --> Language Class Initialized
INFO - 2020-10-12 14:28:56 --> Loader Class Initialized
INFO - 2020-10-12 14:28:56 --> Helper loaded: url_helper
INFO - 2020-10-12 14:28:56 --> Database Driver Class Initialized
INFO - 2020-10-12 14:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:28:56 --> Email Class Initialized
INFO - 2020-10-12 14:28:56 --> Controller Class Initialized
INFO - 2020-10-12 14:28:56 --> Model Class Initialized
INFO - 2020-10-12 14:28:56 --> Model Class Initialized
DEBUG - 2020-10-12 14:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:28:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:28:56 --> Model Class Initialized
INFO - 2020-10-12 14:28:56 --> Final output sent to browser
DEBUG - 2020-10-12 14:28:56 --> Total execution time: 0.0203
ERROR - 2020-10-12 14:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:28:56 --> Config Class Initialized
INFO - 2020-10-12 14:28:56 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:28:56 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:28:56 --> Utf8 Class Initialized
INFO - 2020-10-12 14:28:56 --> URI Class Initialized
INFO - 2020-10-12 14:28:56 --> Router Class Initialized
INFO - 2020-10-12 14:28:56 --> Output Class Initialized
INFO - 2020-10-12 14:28:56 --> Security Class Initialized
DEBUG - 2020-10-12 14:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:28:56 --> Input Class Initialized
INFO - 2020-10-12 14:28:56 --> Language Class Initialized
INFO - 2020-10-12 14:28:56 --> Loader Class Initialized
INFO - 2020-10-12 14:28:56 --> Helper loaded: url_helper
INFO - 2020-10-12 14:28:56 --> Database Driver Class Initialized
INFO - 2020-10-12 14:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:28:56 --> Email Class Initialized
INFO - 2020-10-12 14:28:56 --> Controller Class Initialized
INFO - 2020-10-12 14:28:56 --> Model Class Initialized
INFO - 2020-10-12 14:28:56 --> Model Class Initialized
DEBUG - 2020-10-12 14:28:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:28:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:28:57 --> Config Class Initialized
INFO - 2020-10-12 14:28:57 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:28:57 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:28:57 --> Utf8 Class Initialized
INFO - 2020-10-12 14:28:57 --> URI Class Initialized
INFO - 2020-10-12 14:28:57 --> Router Class Initialized
INFO - 2020-10-12 14:28:57 --> Output Class Initialized
INFO - 2020-10-12 14:28:57 --> Security Class Initialized
DEBUG - 2020-10-12 14:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:28:57 --> Input Class Initialized
INFO - 2020-10-12 14:28:57 --> Language Class Initialized
INFO - 2020-10-12 14:28:57 --> Loader Class Initialized
INFO - 2020-10-12 14:28:57 --> Helper loaded: url_helper
INFO - 2020-10-12 14:28:57 --> Database Driver Class Initialized
INFO - 2020-10-12 14:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:28:57 --> Email Class Initialized
INFO - 2020-10-12 14:28:57 --> Controller Class Initialized
DEBUG - 2020-10-12 14:28:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:28:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:28:57 --> Model Class Initialized
INFO - 2020-10-12 14:28:57 --> Model Class Initialized
INFO - 2020-10-12 14:28:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 14:28:57 --> Final output sent to browser
DEBUG - 2020-10-12 14:28:57 --> Total execution time: 0.0248
ERROR - 2020-10-12 14:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:29:02 --> Config Class Initialized
INFO - 2020-10-12 14:29:02 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:29:02 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:29:02 --> Utf8 Class Initialized
INFO - 2020-10-12 14:29:02 --> URI Class Initialized
INFO - 2020-10-12 14:29:02 --> Router Class Initialized
INFO - 2020-10-12 14:29:02 --> Output Class Initialized
INFO - 2020-10-12 14:29:02 --> Security Class Initialized
DEBUG - 2020-10-12 14:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:29:02 --> Input Class Initialized
INFO - 2020-10-12 14:29:02 --> Language Class Initialized
INFO - 2020-10-12 14:29:02 --> Loader Class Initialized
INFO - 2020-10-12 14:29:02 --> Helper loaded: url_helper
INFO - 2020-10-12 14:29:02 --> Database Driver Class Initialized
INFO - 2020-10-12 14:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:29:02 --> Email Class Initialized
INFO - 2020-10-12 14:29:02 --> Controller Class Initialized
DEBUG - 2020-10-12 14:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:29:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:29:02 --> Model Class Initialized
INFO - 2020-10-12 14:29:02 --> Model Class Initialized
INFO - 2020-10-12 14:29:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 14:29:02 --> Final output sent to browser
DEBUG - 2020-10-12 14:29:02 --> Total execution time: 0.0247
ERROR - 2020-10-12 14:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:31:28 --> Config Class Initialized
INFO - 2020-10-12 14:31:28 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:31:28 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:31:28 --> Utf8 Class Initialized
INFO - 2020-10-12 14:31:28 --> URI Class Initialized
INFO - 2020-10-12 14:31:28 --> Router Class Initialized
INFO - 2020-10-12 14:31:28 --> Output Class Initialized
INFO - 2020-10-12 14:31:28 --> Security Class Initialized
DEBUG - 2020-10-12 14:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:31:28 --> Input Class Initialized
INFO - 2020-10-12 14:31:28 --> Language Class Initialized
INFO - 2020-10-12 14:31:28 --> Loader Class Initialized
INFO - 2020-10-12 14:31:28 --> Helper loaded: url_helper
INFO - 2020-10-12 14:31:28 --> Database Driver Class Initialized
INFO - 2020-10-12 14:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:31:28 --> Email Class Initialized
INFO - 2020-10-12 14:31:28 --> Controller Class Initialized
DEBUG - 2020-10-12 14:31:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:31:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:31:28 --> Model Class Initialized
INFO - 2020-10-12 14:31:28 --> Model Class Initialized
INFO - 2020-10-12 14:31:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 14:31:28 --> Final output sent to browser
DEBUG - 2020-10-12 14:31:28 --> Total execution time: 0.0266
ERROR - 2020-10-12 14:31:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:31:42 --> Config Class Initialized
INFO - 2020-10-12 14:31:42 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:31:42 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:31:42 --> Utf8 Class Initialized
INFO - 2020-10-12 14:31:42 --> URI Class Initialized
INFO - 2020-10-12 14:31:42 --> Router Class Initialized
INFO - 2020-10-12 14:31:42 --> Output Class Initialized
INFO - 2020-10-12 14:31:42 --> Security Class Initialized
DEBUG - 2020-10-12 14:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:31:42 --> Input Class Initialized
INFO - 2020-10-12 14:31:42 --> Language Class Initialized
INFO - 2020-10-12 14:31:42 --> Loader Class Initialized
INFO - 2020-10-12 14:31:42 --> Helper loaded: url_helper
INFO - 2020-10-12 14:31:42 --> Database Driver Class Initialized
INFO - 2020-10-12 14:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:31:42 --> Email Class Initialized
INFO - 2020-10-12 14:31:42 --> Controller Class Initialized
DEBUG - 2020-10-12 14:31:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:31:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:31:42 --> Model Class Initialized
INFO - 2020-10-12 14:31:42 --> Model Class Initialized
INFO - 2020-10-12 14:31:42 --> Model Class Initialized
INFO - 2020-10-12 14:31:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:31:42 --> Final output sent to browser
DEBUG - 2020-10-12 14:31:42 --> Total execution time: 0.0245
ERROR - 2020-10-12 14:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:32:33 --> Config Class Initialized
INFO - 2020-10-12 14:32:33 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:32:33 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:32:33 --> Utf8 Class Initialized
INFO - 2020-10-12 14:32:33 --> URI Class Initialized
DEBUG - 2020-10-12 14:32:33 --> No URI present. Default controller set.
INFO - 2020-10-12 14:32:33 --> Router Class Initialized
INFO - 2020-10-12 14:32:33 --> Output Class Initialized
INFO - 2020-10-12 14:32:33 --> Security Class Initialized
DEBUG - 2020-10-12 14:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:32:33 --> Input Class Initialized
INFO - 2020-10-12 14:32:33 --> Language Class Initialized
INFO - 2020-10-12 14:32:33 --> Loader Class Initialized
INFO - 2020-10-12 14:32:33 --> Helper loaded: url_helper
INFO - 2020-10-12 14:32:33 --> Database Driver Class Initialized
INFO - 2020-10-12 14:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:32:33 --> Email Class Initialized
INFO - 2020-10-12 14:32:33 --> Controller Class Initialized
INFO - 2020-10-12 14:32:33 --> Model Class Initialized
INFO - 2020-10-12 14:32:33 --> Model Class Initialized
DEBUG - 2020-10-12 14:32:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:32:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:32:33 --> Final output sent to browser
DEBUG - 2020-10-12 14:32:33 --> Total execution time: 0.0262
ERROR - 2020-10-12 14:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:32:36 --> Config Class Initialized
INFO - 2020-10-12 14:32:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:32:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:32:36 --> Utf8 Class Initialized
INFO - 2020-10-12 14:32:36 --> URI Class Initialized
INFO - 2020-10-12 14:32:36 --> Router Class Initialized
INFO - 2020-10-12 14:32:36 --> Output Class Initialized
INFO - 2020-10-12 14:32:36 --> Security Class Initialized
DEBUG - 2020-10-12 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:32:36 --> Input Class Initialized
INFO - 2020-10-12 14:32:36 --> Language Class Initialized
INFO - 2020-10-12 14:32:36 --> Loader Class Initialized
INFO - 2020-10-12 14:32:36 --> Helper loaded: url_helper
INFO - 2020-10-12 14:32:36 --> Database Driver Class Initialized
INFO - 2020-10-12 14:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:32:36 --> Email Class Initialized
INFO - 2020-10-12 14:32:36 --> Controller Class Initialized
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
DEBUG - 2020-10-12 14:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
INFO - 2020-10-12 14:32:36 --> Final output sent to browser
DEBUG - 2020-10-12 14:32:36 --> Total execution time: 0.0197
ERROR - 2020-10-12 14:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:32:36 --> Config Class Initialized
INFO - 2020-10-12 14:32:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:32:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:32:36 --> Utf8 Class Initialized
INFO - 2020-10-12 14:32:36 --> URI Class Initialized
INFO - 2020-10-12 14:32:36 --> Router Class Initialized
INFO - 2020-10-12 14:32:36 --> Output Class Initialized
INFO - 2020-10-12 14:32:36 --> Security Class Initialized
DEBUG - 2020-10-12 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:32:36 --> Input Class Initialized
INFO - 2020-10-12 14:32:36 --> Language Class Initialized
INFO - 2020-10-12 14:32:36 --> Loader Class Initialized
INFO - 2020-10-12 14:32:36 --> Helper loaded: url_helper
INFO - 2020-10-12 14:32:36 --> Database Driver Class Initialized
INFO - 2020-10-12 14:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:32:36 --> Email Class Initialized
INFO - 2020-10-12 14:32:36 --> Controller Class Initialized
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
DEBUG - 2020-10-12 14:32:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:32:36 --> Config Class Initialized
INFO - 2020-10-12 14:32:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:32:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:32:36 --> Utf8 Class Initialized
INFO - 2020-10-12 14:32:36 --> URI Class Initialized
INFO - 2020-10-12 14:32:36 --> Router Class Initialized
INFO - 2020-10-12 14:32:36 --> Output Class Initialized
INFO - 2020-10-12 14:32:36 --> Security Class Initialized
DEBUG - 2020-10-12 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:32:36 --> Input Class Initialized
INFO - 2020-10-12 14:32:36 --> Language Class Initialized
INFO - 2020-10-12 14:32:36 --> Loader Class Initialized
INFO - 2020-10-12 14:32:36 --> Helper loaded: url_helper
INFO - 2020-10-12 14:32:36 --> Database Driver Class Initialized
INFO - 2020-10-12 14:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:32:36 --> Email Class Initialized
INFO - 2020-10-12 14:32:36 --> Controller Class Initialized
DEBUG - 2020-10-12 14:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
INFO - 2020-10-12 14:32:36 --> Model Class Initialized
INFO - 2020-10-12 14:32:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 14:32:36 --> Final output sent to browser
DEBUG - 2020-10-12 14:32:36 --> Total execution time: 0.0195
ERROR - 2020-10-12 14:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:39:20 --> Config Class Initialized
INFO - 2020-10-12 14:39:20 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:39:20 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:39:20 --> Utf8 Class Initialized
INFO - 2020-10-12 14:39:20 --> URI Class Initialized
INFO - 2020-10-12 14:39:20 --> Router Class Initialized
INFO - 2020-10-12 14:39:20 --> Output Class Initialized
INFO - 2020-10-12 14:39:20 --> Security Class Initialized
DEBUG - 2020-10-12 14:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:39:20 --> Input Class Initialized
INFO - 2020-10-12 14:39:20 --> Language Class Initialized
INFO - 2020-10-12 14:39:20 --> Loader Class Initialized
INFO - 2020-10-12 14:39:20 --> Helper loaded: url_helper
INFO - 2020-10-12 14:39:20 --> Database Driver Class Initialized
INFO - 2020-10-12 14:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:39:20 --> Email Class Initialized
INFO - 2020-10-12 14:39:20 --> Controller Class Initialized
DEBUG - 2020-10-12 14:39:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:39:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:39:20 --> Model Class Initialized
INFO - 2020-10-12 14:39:20 --> Model Class Initialized
INFO - 2020-10-12 14:39:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 14:39:20 --> Final output sent to browser
DEBUG - 2020-10-12 14:39:20 --> Total execution time: 0.0235
ERROR - 2020-10-12 14:39:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:39:26 --> Config Class Initialized
INFO - 2020-10-12 14:39:26 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:39:26 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:39:26 --> Utf8 Class Initialized
INFO - 2020-10-12 14:39:26 --> URI Class Initialized
INFO - 2020-10-12 14:39:26 --> Router Class Initialized
INFO - 2020-10-12 14:39:26 --> Output Class Initialized
INFO - 2020-10-12 14:39:26 --> Security Class Initialized
DEBUG - 2020-10-12 14:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:39:26 --> Input Class Initialized
INFO - 2020-10-12 14:39:26 --> Language Class Initialized
INFO - 2020-10-12 14:39:26 --> Loader Class Initialized
INFO - 2020-10-12 14:39:26 --> Helper loaded: url_helper
INFO - 2020-10-12 14:39:26 --> Database Driver Class Initialized
INFO - 2020-10-12 14:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:39:26 --> Email Class Initialized
INFO - 2020-10-12 14:39:26 --> Controller Class Initialized
DEBUG - 2020-10-12 14:39:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:39:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:39:26 --> Model Class Initialized
INFO - 2020-10-12 14:39:26 --> Model Class Initialized
INFO - 2020-10-12 14:39:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 14:39:26 --> Final output sent to browser
DEBUG - 2020-10-12 14:39:26 --> Total execution time: 0.0246
ERROR - 2020-10-12 14:39:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:39:34 --> Config Class Initialized
INFO - 2020-10-12 14:39:34 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:39:34 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:39:34 --> Utf8 Class Initialized
INFO - 2020-10-12 14:39:34 --> URI Class Initialized
INFO - 2020-10-12 14:39:34 --> Router Class Initialized
INFO - 2020-10-12 14:39:34 --> Output Class Initialized
INFO - 2020-10-12 14:39:34 --> Security Class Initialized
DEBUG - 2020-10-12 14:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:39:34 --> Input Class Initialized
INFO - 2020-10-12 14:39:34 --> Language Class Initialized
INFO - 2020-10-12 14:39:34 --> Loader Class Initialized
INFO - 2020-10-12 14:39:34 --> Helper loaded: url_helper
INFO - 2020-10-12 14:39:34 --> Database Driver Class Initialized
INFO - 2020-10-12 14:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:39:34 --> Email Class Initialized
INFO - 2020-10-12 14:39:34 --> Controller Class Initialized
DEBUG - 2020-10-12 14:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:39:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:39:34 --> Model Class Initialized
INFO - 2020-10-12 14:39:34 --> Model Class Initialized
INFO - 2020-10-12 14:39:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 14:39:34 --> Final output sent to browser
DEBUG - 2020-10-12 14:39:34 --> Total execution time: 0.0322
ERROR - 2020-10-12 14:41:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:00 --> Config Class Initialized
INFO - 2020-10-12 14:41:00 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:00 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:00 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:00 --> URI Class Initialized
DEBUG - 2020-10-12 14:41:00 --> No URI present. Default controller set.
INFO - 2020-10-12 14:41:00 --> Router Class Initialized
INFO - 2020-10-12 14:41:00 --> Output Class Initialized
INFO - 2020-10-12 14:41:00 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:00 --> Input Class Initialized
INFO - 2020-10-12 14:41:00 --> Language Class Initialized
INFO - 2020-10-12 14:41:00 --> Loader Class Initialized
INFO - 2020-10-12 14:41:00 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:00 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:00 --> Email Class Initialized
INFO - 2020-10-12 14:41:00 --> Controller Class Initialized
INFO - 2020-10-12 14:41:00 --> Model Class Initialized
INFO - 2020-10-12 14:41:00 --> Model Class Initialized
DEBUG - 2020-10-12 14:41:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:41:00 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:00 --> Total execution time: 0.0171
ERROR - 2020-10-12 14:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:03 --> Config Class Initialized
INFO - 2020-10-12 14:41:03 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:03 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:03 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:03 --> URI Class Initialized
INFO - 2020-10-12 14:41:03 --> Router Class Initialized
INFO - 2020-10-12 14:41:03 --> Output Class Initialized
INFO - 2020-10-12 14:41:03 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:03 --> Input Class Initialized
INFO - 2020-10-12 14:41:03 --> Language Class Initialized
INFO - 2020-10-12 14:41:03 --> Loader Class Initialized
INFO - 2020-10-12 14:41:03 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:03 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:04 --> Email Class Initialized
INFO - 2020-10-12 14:41:04 --> Controller Class Initialized
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
DEBUG - 2020-10-12 14:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:41:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
INFO - 2020-10-12 14:41:04 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:04 --> Total execution time: 0.0228
ERROR - 2020-10-12 14:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:04 --> Config Class Initialized
INFO - 2020-10-12 14:41:04 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:04 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:04 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:04 --> URI Class Initialized
INFO - 2020-10-12 14:41:04 --> Router Class Initialized
INFO - 2020-10-12 14:41:04 --> Output Class Initialized
INFO - 2020-10-12 14:41:04 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:04 --> Input Class Initialized
INFO - 2020-10-12 14:41:04 --> Language Class Initialized
INFO - 2020-10-12 14:41:04 --> Loader Class Initialized
INFO - 2020-10-12 14:41:04 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:04 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:04 --> Email Class Initialized
INFO - 2020-10-12 14:41:04 --> Controller Class Initialized
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
DEBUG - 2020-10-12 14:41:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:41:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:04 --> Config Class Initialized
INFO - 2020-10-12 14:41:04 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:04 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:04 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:04 --> URI Class Initialized
INFO - 2020-10-12 14:41:04 --> Router Class Initialized
INFO - 2020-10-12 14:41:04 --> Output Class Initialized
INFO - 2020-10-12 14:41:04 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:04 --> Input Class Initialized
INFO - 2020-10-12 14:41:04 --> Language Class Initialized
INFO - 2020-10-12 14:41:04 --> Loader Class Initialized
INFO - 2020-10-12 14:41:04 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:04 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:04 --> Email Class Initialized
INFO - 2020-10-12 14:41:04 --> Controller Class Initialized
DEBUG - 2020-10-12 14:41:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:41:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
INFO - 2020-10-12 14:41:04 --> Model Class Initialized
INFO - 2020-10-12 14:41:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 14:41:04 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:04 --> Total execution time: 0.0235
ERROR - 2020-10-12 14:41:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:08 --> Config Class Initialized
INFO - 2020-10-12 14:41:08 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:08 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:08 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:08 --> URI Class Initialized
DEBUG - 2020-10-12 14:41:08 --> No URI present. Default controller set.
INFO - 2020-10-12 14:41:08 --> Router Class Initialized
INFO - 2020-10-12 14:41:08 --> Output Class Initialized
INFO - 2020-10-12 14:41:08 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:08 --> Input Class Initialized
INFO - 2020-10-12 14:41:08 --> Language Class Initialized
INFO - 2020-10-12 14:41:08 --> Loader Class Initialized
INFO - 2020-10-12 14:41:08 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:08 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:08 --> Email Class Initialized
INFO - 2020-10-12 14:41:08 --> Controller Class Initialized
INFO - 2020-10-12 14:41:08 --> Model Class Initialized
INFO - 2020-10-12 14:41:08 --> Model Class Initialized
DEBUG - 2020-10-12 14:41:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:41:08 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:08 --> Total execution time: 0.0169
ERROR - 2020-10-12 14:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:21 --> Config Class Initialized
INFO - 2020-10-12 14:41:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:21 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:21 --> URI Class Initialized
INFO - 2020-10-12 14:41:21 --> Router Class Initialized
INFO - 2020-10-12 14:41:21 --> Output Class Initialized
INFO - 2020-10-12 14:41:21 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:21 --> Input Class Initialized
INFO - 2020-10-12 14:41:21 --> Language Class Initialized
INFO - 2020-10-12 14:41:21 --> Loader Class Initialized
INFO - 2020-10-12 14:41:21 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:21 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:21 --> Email Class Initialized
INFO - 2020-10-12 14:41:21 --> Controller Class Initialized
INFO - 2020-10-12 14:41:21 --> Model Class Initialized
INFO - 2020-10-12 14:41:21 --> Model Class Initialized
DEBUG - 2020-10-12 14:41:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:41:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:21 --> Model Class Initialized
INFO - 2020-10-12 14:41:21 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:21 --> Total execution time: 0.0238
ERROR - 2020-10-12 14:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:21 --> Config Class Initialized
INFO - 2020-10-12 14:41:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:21 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:21 --> URI Class Initialized
INFO - 2020-10-12 14:41:21 --> Router Class Initialized
INFO - 2020-10-12 14:41:21 --> Output Class Initialized
INFO - 2020-10-12 14:41:21 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:21 --> Input Class Initialized
INFO - 2020-10-12 14:41:21 --> Language Class Initialized
INFO - 2020-10-12 14:41:21 --> Loader Class Initialized
INFO - 2020-10-12 14:41:21 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:21 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:21 --> Email Class Initialized
INFO - 2020-10-12 14:41:21 --> Controller Class Initialized
INFO - 2020-10-12 14:41:21 --> Model Class Initialized
INFO - 2020-10-12 14:41:21 --> Model Class Initialized
DEBUG - 2020-10-12 14:41:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:22 --> Config Class Initialized
INFO - 2020-10-12 14:41:22 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:22 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:22 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:22 --> URI Class Initialized
INFO - 2020-10-12 14:41:22 --> Router Class Initialized
INFO - 2020-10-12 14:41:22 --> Output Class Initialized
INFO - 2020-10-12 14:41:22 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:22 --> Input Class Initialized
INFO - 2020-10-12 14:41:22 --> Language Class Initialized
INFO - 2020-10-12 14:41:22 --> Loader Class Initialized
INFO - 2020-10-12 14:41:22 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:22 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:22 --> Email Class Initialized
INFO - 2020-10-12 14:41:22 --> Controller Class Initialized
DEBUG - 2020-10-12 14:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:41:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:22 --> Model Class Initialized
INFO - 2020-10-12 14:41:22 --> Model Class Initialized
INFO - 2020-10-12 14:41:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-12 14:41:22 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:22 --> Total execution time: 0.0277
ERROR - 2020-10-12 14:41:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:31 --> Config Class Initialized
INFO - 2020-10-12 14:41:31 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:31 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:31 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:31 --> URI Class Initialized
INFO - 2020-10-12 14:41:31 --> Router Class Initialized
INFO - 2020-10-12 14:41:31 --> Output Class Initialized
INFO - 2020-10-12 14:41:31 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:31 --> Input Class Initialized
INFO - 2020-10-12 14:41:31 --> Language Class Initialized
INFO - 2020-10-12 14:41:31 --> Loader Class Initialized
INFO - 2020-10-12 14:41:31 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:31 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:31 --> Email Class Initialized
INFO - 2020-10-12 14:41:31 --> Controller Class Initialized
DEBUG - 2020-10-12 14:41:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:41:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:31 --> Model Class Initialized
INFO - 2020-10-12 14:41:31 --> Model Class Initialized
INFO - 2020-10-12 14:41:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:41:31 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:31 --> Total execution time: 0.0225
ERROR - 2020-10-12 14:41:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:41:36 --> Config Class Initialized
INFO - 2020-10-12 14:41:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:41:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:41:36 --> Utf8 Class Initialized
INFO - 2020-10-12 14:41:36 --> URI Class Initialized
INFO - 2020-10-12 14:41:36 --> Router Class Initialized
INFO - 2020-10-12 14:41:36 --> Output Class Initialized
INFO - 2020-10-12 14:41:36 --> Security Class Initialized
DEBUG - 2020-10-12 14:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:41:36 --> Input Class Initialized
INFO - 2020-10-12 14:41:36 --> Language Class Initialized
INFO - 2020-10-12 14:41:36 --> Loader Class Initialized
INFO - 2020-10-12 14:41:36 --> Helper loaded: url_helper
INFO - 2020-10-12 14:41:36 --> Database Driver Class Initialized
INFO - 2020-10-12 14:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:41:36 --> Email Class Initialized
INFO - 2020-10-12 14:41:36 --> Controller Class Initialized
DEBUG - 2020-10-12 14:41:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:41:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:41:36 --> Model Class Initialized
INFO - 2020-10-12 14:41:36 --> Model Class Initialized
INFO - 2020-10-12 14:41:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-12 14:41:36 --> Final output sent to browser
DEBUG - 2020-10-12 14:41:36 --> Total execution time: 0.0302
ERROR - 2020-10-12 14:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:42:03 --> Config Class Initialized
INFO - 2020-10-12 14:42:03 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:42:03 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:42:03 --> Utf8 Class Initialized
INFO - 2020-10-12 14:42:03 --> URI Class Initialized
INFO - 2020-10-12 14:42:03 --> Router Class Initialized
INFO - 2020-10-12 14:42:03 --> Output Class Initialized
INFO - 2020-10-12 14:42:03 --> Security Class Initialized
DEBUG - 2020-10-12 14:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:42:03 --> Input Class Initialized
INFO - 2020-10-12 14:42:03 --> Language Class Initialized
INFO - 2020-10-12 14:42:03 --> Loader Class Initialized
INFO - 2020-10-12 14:42:03 --> Helper loaded: url_helper
INFO - 2020-10-12 14:42:03 --> Database Driver Class Initialized
INFO - 2020-10-12 14:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:42:03 --> Email Class Initialized
INFO - 2020-10-12 14:42:03 --> Controller Class Initialized
DEBUG - 2020-10-12 14:42:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:42:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:42:03 --> Model Class Initialized
INFO - 2020-10-12 14:42:03 --> Model Class Initialized
INFO - 2020-10-12 14:42:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:42:03 --> Final output sent to browser
DEBUG - 2020-10-12 14:42:03 --> Total execution time: 0.0232
ERROR - 2020-10-12 14:42:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:42:06 --> Config Class Initialized
INFO - 2020-10-12 14:42:06 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:42:06 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:42:06 --> Utf8 Class Initialized
INFO - 2020-10-12 14:42:06 --> URI Class Initialized
INFO - 2020-10-12 14:42:06 --> Router Class Initialized
INFO - 2020-10-12 14:42:06 --> Output Class Initialized
INFO - 2020-10-12 14:42:06 --> Security Class Initialized
DEBUG - 2020-10-12 14:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:42:06 --> Input Class Initialized
INFO - 2020-10-12 14:42:06 --> Language Class Initialized
INFO - 2020-10-12 14:42:06 --> Loader Class Initialized
INFO - 2020-10-12 14:42:06 --> Helper loaded: url_helper
INFO - 2020-10-12 14:42:06 --> Database Driver Class Initialized
INFO - 2020-10-12 14:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:42:06 --> Email Class Initialized
INFO - 2020-10-12 14:42:06 --> Controller Class Initialized
DEBUG - 2020-10-12 14:42:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:42:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:42:06 --> Model Class Initialized
INFO - 2020-10-12 14:42:06 --> Model Class Initialized
INFO - 2020-10-12 14:42:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-12 14:42:06 --> Final output sent to browser
DEBUG - 2020-10-12 14:42:06 --> Total execution time: 0.0379
ERROR - 2020-10-12 14:42:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:42:07 --> Config Class Initialized
INFO - 2020-10-12 14:42:07 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:42:07 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:42:07 --> Utf8 Class Initialized
INFO - 2020-10-12 14:42:07 --> URI Class Initialized
INFO - 2020-10-12 14:42:07 --> Router Class Initialized
INFO - 2020-10-12 14:42:07 --> Output Class Initialized
INFO - 2020-10-12 14:42:07 --> Security Class Initialized
DEBUG - 2020-10-12 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:42:07 --> Input Class Initialized
INFO - 2020-10-12 14:42:07 --> Language Class Initialized
INFO - 2020-10-12 14:42:07 --> Loader Class Initialized
INFO - 2020-10-12 14:42:07 --> Helper loaded: url_helper
INFO - 2020-10-12 14:42:07 --> Database Driver Class Initialized
INFO - 2020-10-12 14:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:42:07 --> Email Class Initialized
INFO - 2020-10-12 14:42:07 --> Controller Class Initialized
DEBUG - 2020-10-12 14:42:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:42:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:42:07 --> Model Class Initialized
INFO - 2020-10-12 14:42:07 --> Model Class Initialized
INFO - 2020-10-12 14:42:07 --> Final output sent to browser
DEBUG - 2020-10-12 14:42:07 --> Total execution time: 0.0256
ERROR - 2020-10-12 14:43:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:43:10 --> Config Class Initialized
INFO - 2020-10-12 14:43:10 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:43:10 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:43:10 --> Utf8 Class Initialized
INFO - 2020-10-12 14:43:10 --> URI Class Initialized
INFO - 2020-10-12 14:43:10 --> Router Class Initialized
INFO - 2020-10-12 14:43:10 --> Output Class Initialized
INFO - 2020-10-12 14:43:10 --> Security Class Initialized
DEBUG - 2020-10-12 14:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:43:10 --> Input Class Initialized
INFO - 2020-10-12 14:43:10 --> Language Class Initialized
INFO - 2020-10-12 14:43:10 --> Loader Class Initialized
INFO - 2020-10-12 14:43:10 --> Helper loaded: url_helper
INFO - 2020-10-12 14:43:10 --> Database Driver Class Initialized
INFO - 2020-10-12 14:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:43:10 --> Email Class Initialized
INFO - 2020-10-12 14:43:10 --> Controller Class Initialized
DEBUG - 2020-10-12 14:43:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:43:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:43:10 --> Model Class Initialized
INFO - 2020-10-12 14:43:10 --> Model Class Initialized
INFO - 2020-10-12 14:43:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:43:10 --> Final output sent to browser
DEBUG - 2020-10-12 14:43:10 --> Total execution time: 0.0212
ERROR - 2020-10-12 14:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:43:14 --> Config Class Initialized
INFO - 2020-10-12 14:43:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:43:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:43:14 --> Utf8 Class Initialized
INFO - 2020-10-12 14:43:14 --> URI Class Initialized
INFO - 2020-10-12 14:43:14 --> Router Class Initialized
INFO - 2020-10-12 14:43:14 --> Output Class Initialized
INFO - 2020-10-12 14:43:14 --> Security Class Initialized
DEBUG - 2020-10-12 14:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:43:14 --> Input Class Initialized
INFO - 2020-10-12 14:43:14 --> Language Class Initialized
INFO - 2020-10-12 14:43:14 --> Loader Class Initialized
INFO - 2020-10-12 14:43:14 --> Helper loaded: url_helper
INFO - 2020-10-12 14:43:14 --> Database Driver Class Initialized
INFO - 2020-10-12 14:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:43:14 --> Email Class Initialized
INFO - 2020-10-12 14:43:14 --> Controller Class Initialized
DEBUG - 2020-10-12 14:43:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:43:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:43:14 --> Model Class Initialized
INFO - 2020-10-12 14:43:14 --> Model Class Initialized
INFO - 2020-10-12 14:43:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-12 14:43:14 --> Final output sent to browser
DEBUG - 2020-10-12 14:43:14 --> Total execution time: 0.0224
ERROR - 2020-10-12 14:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:43:15 --> Config Class Initialized
INFO - 2020-10-12 14:43:15 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:43:15 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:43:15 --> Utf8 Class Initialized
INFO - 2020-10-12 14:43:15 --> URI Class Initialized
INFO - 2020-10-12 14:43:15 --> Router Class Initialized
INFO - 2020-10-12 14:43:15 --> Output Class Initialized
INFO - 2020-10-12 14:43:15 --> Security Class Initialized
DEBUG - 2020-10-12 14:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:43:15 --> Input Class Initialized
INFO - 2020-10-12 14:43:15 --> Language Class Initialized
ERROR - 2020-10-12 14:43:15 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-12 14:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:43:50 --> Config Class Initialized
INFO - 2020-10-12 14:43:50 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:43:50 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:43:50 --> Utf8 Class Initialized
INFO - 2020-10-12 14:43:50 --> URI Class Initialized
INFO - 2020-10-12 14:43:50 --> Router Class Initialized
INFO - 2020-10-12 14:43:50 --> Output Class Initialized
INFO - 2020-10-12 14:43:50 --> Security Class Initialized
DEBUG - 2020-10-12 14:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:43:50 --> Input Class Initialized
INFO - 2020-10-12 14:43:50 --> Language Class Initialized
INFO - 2020-10-12 14:43:50 --> Loader Class Initialized
INFO - 2020-10-12 14:43:50 --> Helper loaded: url_helper
INFO - 2020-10-12 14:43:50 --> Database Driver Class Initialized
INFO - 2020-10-12 14:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:43:50 --> Email Class Initialized
INFO - 2020-10-12 14:43:50 --> Controller Class Initialized
DEBUG - 2020-10-12 14:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:43:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:43:50 --> Model Class Initialized
INFO - 2020-10-12 14:43:50 --> Model Class Initialized
INFO - 2020-10-12 14:43:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-12 14:43:50 --> Final output sent to browser
DEBUG - 2020-10-12 14:43:50 --> Total execution time: 0.0263
ERROR - 2020-10-12 14:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:43:50 --> Config Class Initialized
INFO - 2020-10-12 14:43:50 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:43:50 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:43:50 --> Utf8 Class Initialized
INFO - 2020-10-12 14:43:50 --> URI Class Initialized
INFO - 2020-10-12 14:43:50 --> Router Class Initialized
INFO - 2020-10-12 14:43:50 --> Output Class Initialized
INFO - 2020-10-12 14:43:50 --> Security Class Initialized
DEBUG - 2020-10-12 14:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:43:50 --> Input Class Initialized
INFO - 2020-10-12 14:43:50 --> Language Class Initialized
ERROR - 2020-10-12 14:43:50 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-12 14:43:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:43:55 --> Config Class Initialized
INFO - 2020-10-12 14:43:55 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:43:55 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:43:55 --> Utf8 Class Initialized
INFO - 2020-10-12 14:43:55 --> URI Class Initialized
INFO - 2020-10-12 14:43:55 --> Router Class Initialized
INFO - 2020-10-12 14:43:55 --> Output Class Initialized
INFO - 2020-10-12 14:43:55 --> Security Class Initialized
DEBUG - 2020-10-12 14:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:43:55 --> Input Class Initialized
INFO - 2020-10-12 14:43:55 --> Language Class Initialized
INFO - 2020-10-12 14:43:55 --> Loader Class Initialized
INFO - 2020-10-12 14:43:55 --> Helper loaded: url_helper
INFO - 2020-10-12 14:43:55 --> Database Driver Class Initialized
INFO - 2020-10-12 14:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:43:55 --> Email Class Initialized
INFO - 2020-10-12 14:43:55 --> Controller Class Initialized
DEBUG - 2020-10-12 14:43:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:43:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:43:55 --> Model Class Initialized
INFO - 2020-10-12 14:43:55 --> Model Class Initialized
INFO - 2020-10-12 14:43:55 --> Final output sent to browser
DEBUG - 2020-10-12 14:43:55 --> Total execution time: 0.0269
ERROR - 2020-10-12 14:45:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:45:56 --> Config Class Initialized
INFO - 2020-10-12 14:45:56 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:45:56 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:45:56 --> Utf8 Class Initialized
INFO - 2020-10-12 14:45:56 --> URI Class Initialized
INFO - 2020-10-12 14:45:56 --> Router Class Initialized
INFO - 2020-10-12 14:45:56 --> Output Class Initialized
INFO - 2020-10-12 14:45:56 --> Security Class Initialized
DEBUG - 2020-10-12 14:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:45:56 --> Input Class Initialized
INFO - 2020-10-12 14:45:56 --> Language Class Initialized
INFO - 2020-10-12 14:45:56 --> Loader Class Initialized
INFO - 2020-10-12 14:45:56 --> Helper loaded: url_helper
INFO - 2020-10-12 14:45:56 --> Database Driver Class Initialized
INFO - 2020-10-12 14:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:45:56 --> Email Class Initialized
INFO - 2020-10-12 14:45:56 --> Controller Class Initialized
DEBUG - 2020-10-12 14:45:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:45:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:45:56 --> Model Class Initialized
INFO - 2020-10-12 14:45:56 --> Model Class Initialized
INFO - 2020-10-12 14:45:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-12 14:45:56 --> Final output sent to browser
DEBUG - 2020-10-12 14:45:56 --> Total execution time: 0.0204
ERROR - 2020-10-12 14:45:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:45:57 --> Config Class Initialized
INFO - 2020-10-12 14:45:57 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:45:57 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:45:57 --> Utf8 Class Initialized
INFO - 2020-10-12 14:45:57 --> URI Class Initialized
INFO - 2020-10-12 14:45:57 --> Router Class Initialized
INFO - 2020-10-12 14:45:57 --> Output Class Initialized
INFO - 2020-10-12 14:45:57 --> Security Class Initialized
DEBUG - 2020-10-12 14:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:45:57 --> Input Class Initialized
INFO - 2020-10-12 14:45:57 --> Language Class Initialized
ERROR - 2020-10-12 14:45:57 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-12 14:47:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:47:11 --> Config Class Initialized
INFO - 2020-10-12 14:47:11 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:47:11 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:47:11 --> Utf8 Class Initialized
INFO - 2020-10-12 14:47:11 --> URI Class Initialized
INFO - 2020-10-12 14:47:11 --> Router Class Initialized
INFO - 2020-10-12 14:47:11 --> Output Class Initialized
INFO - 2020-10-12 14:47:11 --> Security Class Initialized
DEBUG - 2020-10-12 14:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:47:11 --> Input Class Initialized
INFO - 2020-10-12 14:47:11 --> Language Class Initialized
INFO - 2020-10-12 14:47:11 --> Loader Class Initialized
INFO - 2020-10-12 14:47:11 --> Helper loaded: url_helper
INFO - 2020-10-12 14:47:11 --> Database Driver Class Initialized
INFO - 2020-10-12 14:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:47:11 --> Email Class Initialized
INFO - 2020-10-12 14:47:11 --> Controller Class Initialized
DEBUG - 2020-10-12 14:47:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:47:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:47:11 --> Model Class Initialized
INFO - 2020-10-12 14:47:11 --> Model Class Initialized
INFO - 2020-10-12 14:47:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:47:11 --> Final output sent to browser
DEBUG - 2020-10-12 14:47:11 --> Total execution time: 0.0221
ERROR - 2020-10-12 14:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:47:14 --> Config Class Initialized
INFO - 2020-10-12 14:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:47:14 --> Utf8 Class Initialized
INFO - 2020-10-12 14:47:14 --> URI Class Initialized
INFO - 2020-10-12 14:47:14 --> Router Class Initialized
INFO - 2020-10-12 14:47:14 --> Output Class Initialized
INFO - 2020-10-12 14:47:14 --> Security Class Initialized
DEBUG - 2020-10-12 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:47:14 --> Input Class Initialized
INFO - 2020-10-12 14:47:14 --> Language Class Initialized
INFO - 2020-10-12 14:47:14 --> Loader Class Initialized
INFO - 2020-10-12 14:47:14 --> Helper loaded: url_helper
INFO - 2020-10-12 14:47:14 --> Database Driver Class Initialized
INFO - 2020-10-12 14:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:47:14 --> Email Class Initialized
INFO - 2020-10-12 14:47:14 --> Controller Class Initialized
DEBUG - 2020-10-12 14:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:47:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:47:14 --> Model Class Initialized
INFO - 2020-10-12 14:47:14 --> Model Class Initialized
INFO - 2020-10-12 14:47:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-12 14:47:14 --> Final output sent to browser
DEBUG - 2020-10-12 14:47:14 --> Total execution time: 0.0261
ERROR - 2020-10-12 14:47:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:47:15 --> Config Class Initialized
INFO - 2020-10-12 14:47:15 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:47:15 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:47:15 --> Utf8 Class Initialized
INFO - 2020-10-12 14:47:15 --> URI Class Initialized
INFO - 2020-10-12 14:47:15 --> Router Class Initialized
INFO - 2020-10-12 14:47:15 --> Output Class Initialized
INFO - 2020-10-12 14:47:15 --> Security Class Initialized
DEBUG - 2020-10-12 14:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:47:15 --> Input Class Initialized
INFO - 2020-10-12 14:47:15 --> Language Class Initialized
INFO - 2020-10-12 14:47:15 --> Loader Class Initialized
INFO - 2020-10-12 14:47:15 --> Helper loaded: url_helper
INFO - 2020-10-12 14:47:15 --> Database Driver Class Initialized
INFO - 2020-10-12 14:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:47:15 --> Email Class Initialized
INFO - 2020-10-12 14:47:15 --> Controller Class Initialized
DEBUG - 2020-10-12 14:47:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:47:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:47:15 --> Model Class Initialized
INFO - 2020-10-12 14:47:15 --> Model Class Initialized
INFO - 2020-10-12 14:47:15 --> Final output sent to browser
DEBUG - 2020-10-12 14:47:15 --> Total execution time: 0.0272
ERROR - 2020-10-12 14:47:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:47:18 --> Config Class Initialized
INFO - 2020-10-12 14:47:18 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:47:18 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:47:18 --> Utf8 Class Initialized
INFO - 2020-10-12 14:47:18 --> URI Class Initialized
INFO - 2020-10-12 14:47:18 --> Router Class Initialized
INFO - 2020-10-12 14:47:18 --> Output Class Initialized
INFO - 2020-10-12 14:47:18 --> Security Class Initialized
DEBUG - 2020-10-12 14:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:47:18 --> Input Class Initialized
INFO - 2020-10-12 14:47:18 --> Language Class Initialized
INFO - 2020-10-12 14:47:18 --> Loader Class Initialized
INFO - 2020-10-12 14:47:18 --> Helper loaded: url_helper
INFO - 2020-10-12 14:47:18 --> Database Driver Class Initialized
INFO - 2020-10-12 14:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:47:18 --> Email Class Initialized
INFO - 2020-10-12 14:47:18 --> Controller Class Initialized
DEBUG - 2020-10-12 14:47:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:47:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:47:18 --> Model Class Initialized
INFO - 2020-10-12 14:47:18 --> Model Class Initialized
INFO - 2020-10-12 14:47:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:47:18 --> Final output sent to browser
DEBUG - 2020-10-12 14:47:18 --> Total execution time: 0.0243
ERROR - 2020-10-12 14:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:06 --> Config Class Initialized
INFO - 2020-10-12 14:48:06 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:06 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:06 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:06 --> URI Class Initialized
INFO - 2020-10-12 14:48:06 --> Router Class Initialized
INFO - 2020-10-12 14:48:06 --> Output Class Initialized
INFO - 2020-10-12 14:48:06 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:06 --> Input Class Initialized
INFO - 2020-10-12 14:48:06 --> Language Class Initialized
INFO - 2020-10-12 14:48:06 --> Loader Class Initialized
INFO - 2020-10-12 14:48:06 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:06 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:06 --> Email Class Initialized
INFO - 2020-10-12 14:48:06 --> Controller Class Initialized
DEBUG - 2020-10-12 14:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:48:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:48:06 --> Model Class Initialized
INFO - 2020-10-12 14:48:06 --> Model Class Initialized
INFO - 2020-10-12 14:48:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:48:06 --> Final output sent to browser
DEBUG - 2020-10-12 14:48:06 --> Total execution time: 0.0211
ERROR - 2020-10-12 14:48:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:46 --> Config Class Initialized
INFO - 2020-10-12 14:48:46 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:46 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:46 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:46 --> URI Class Initialized
INFO - 2020-10-12 14:48:46 --> Router Class Initialized
INFO - 2020-10-12 14:48:46 --> Output Class Initialized
INFO - 2020-10-12 14:48:46 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:46 --> Input Class Initialized
INFO - 2020-10-12 14:48:46 --> Language Class Initialized
INFO - 2020-10-12 14:48:46 --> Loader Class Initialized
INFO - 2020-10-12 14:48:46 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:46 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:46 --> Email Class Initialized
INFO - 2020-10-12 14:48:46 --> Controller Class Initialized
DEBUG - 2020-10-12 14:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:48:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:48:46 --> Model Class Initialized
INFO - 2020-10-12 14:48:46 --> Model Class Initialized
INFO - 2020-10-12 14:48:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 14:48:46 --> Final output sent to browser
DEBUG - 2020-10-12 14:48:46 --> Total execution time: 0.0247
ERROR - 2020-10-12 14:48:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:49 --> Config Class Initialized
INFO - 2020-10-12 14:48:49 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:49 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:49 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:49 --> URI Class Initialized
INFO - 2020-10-12 14:48:49 --> Router Class Initialized
INFO - 2020-10-12 14:48:49 --> Output Class Initialized
INFO - 2020-10-12 14:48:49 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:49 --> Input Class Initialized
INFO - 2020-10-12 14:48:49 --> Language Class Initialized
INFO - 2020-10-12 14:48:49 --> Loader Class Initialized
INFO - 2020-10-12 14:48:49 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:49 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:49 --> Email Class Initialized
INFO - 2020-10-12 14:48:49 --> Controller Class Initialized
DEBUG - 2020-10-12 14:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:48:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:48:49 --> Model Class Initialized
INFO - 2020-10-12 14:48:49 --> Model Class Initialized
INFO - 2020-10-12 14:48:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 14:48:49 --> Final output sent to browser
DEBUG - 2020-10-12 14:48:49 --> Total execution time: 0.0249
ERROR - 2020-10-12 14:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:52 --> Config Class Initialized
INFO - 2020-10-12 14:48:52 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:52 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:52 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:52 --> URI Class Initialized
INFO - 2020-10-12 14:48:52 --> Router Class Initialized
INFO - 2020-10-12 14:48:52 --> Output Class Initialized
INFO - 2020-10-12 14:48:52 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:52 --> Input Class Initialized
INFO - 2020-10-12 14:48:52 --> Language Class Initialized
INFO - 2020-10-12 14:48:52 --> Loader Class Initialized
INFO - 2020-10-12 14:48:52 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:52 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:52 --> Email Class Initialized
INFO - 2020-10-12 14:48:52 --> Controller Class Initialized
DEBUG - 2020-10-12 14:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:48:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:48:52 --> Model Class Initialized
INFO - 2020-10-12 14:48:52 --> Model Class Initialized
INFO - 2020-10-12 14:48:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-12 14:48:52 --> Final output sent to browser
DEBUG - 2020-10-12 14:48:52 --> Total execution time: 0.0218
ERROR - 2020-10-12 14:48:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:56 --> Config Class Initialized
INFO - 2020-10-12 14:48:56 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:56 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:56 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:56 --> URI Class Initialized
DEBUG - 2020-10-12 14:48:56 --> No URI present. Default controller set.
INFO - 2020-10-12 14:48:56 --> Router Class Initialized
INFO - 2020-10-12 14:48:56 --> Output Class Initialized
INFO - 2020-10-12 14:48:56 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:56 --> Input Class Initialized
INFO - 2020-10-12 14:48:56 --> Language Class Initialized
INFO - 2020-10-12 14:48:56 --> Loader Class Initialized
INFO - 2020-10-12 14:48:56 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:56 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:56 --> Email Class Initialized
INFO - 2020-10-12 14:48:56 --> Controller Class Initialized
INFO - 2020-10-12 14:48:56 --> Model Class Initialized
INFO - 2020-10-12 14:48:56 --> Model Class Initialized
DEBUG - 2020-10-12 14:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:48:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:48:56 --> Final output sent to browser
DEBUG - 2020-10-12 14:48:56 --> Total execution time: 0.0178
ERROR - 2020-10-12 14:48:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:59 --> Config Class Initialized
INFO - 2020-10-12 14:48:59 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:59 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:59 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:59 --> URI Class Initialized
INFO - 2020-10-12 14:48:59 --> Router Class Initialized
INFO - 2020-10-12 14:48:59 --> Output Class Initialized
INFO - 2020-10-12 14:48:59 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:59 --> Input Class Initialized
INFO - 2020-10-12 14:48:59 --> Language Class Initialized
INFO - 2020-10-12 14:48:59 --> Loader Class Initialized
INFO - 2020-10-12 14:48:59 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:59 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:59 --> Email Class Initialized
INFO - 2020-10-12 14:48:59 --> Controller Class Initialized
INFO - 2020-10-12 14:48:59 --> Model Class Initialized
INFO - 2020-10-12 14:48:59 --> Model Class Initialized
DEBUG - 2020-10-12 14:48:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:48:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:48:59 --> Model Class Initialized
INFO - 2020-10-12 14:48:59 --> Final output sent to browser
DEBUG - 2020-10-12 14:48:59 --> Total execution time: 0.0222
ERROR - 2020-10-12 14:48:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:48:59 --> Config Class Initialized
INFO - 2020-10-12 14:48:59 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:48:59 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:48:59 --> Utf8 Class Initialized
INFO - 2020-10-12 14:48:59 --> URI Class Initialized
INFO - 2020-10-12 14:48:59 --> Router Class Initialized
INFO - 2020-10-12 14:48:59 --> Output Class Initialized
INFO - 2020-10-12 14:48:59 --> Security Class Initialized
DEBUG - 2020-10-12 14:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:48:59 --> Input Class Initialized
INFO - 2020-10-12 14:48:59 --> Language Class Initialized
INFO - 2020-10-12 14:48:59 --> Loader Class Initialized
INFO - 2020-10-12 14:48:59 --> Helper loaded: url_helper
INFO - 2020-10-12 14:48:59 --> Database Driver Class Initialized
INFO - 2020-10-12 14:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:48:59 --> Email Class Initialized
INFO - 2020-10-12 14:48:59 --> Controller Class Initialized
INFO - 2020-10-12 14:48:59 --> Model Class Initialized
INFO - 2020-10-12 14:48:59 --> Model Class Initialized
DEBUG - 2020-10-12 14:48:59 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:49:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:00 --> Config Class Initialized
INFO - 2020-10-12 14:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:00 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:00 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:00 --> URI Class Initialized
INFO - 2020-10-12 14:49:00 --> Router Class Initialized
INFO - 2020-10-12 14:49:00 --> Output Class Initialized
INFO - 2020-10-12 14:49:00 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:00 --> Input Class Initialized
INFO - 2020-10-12 14:49:00 --> Language Class Initialized
INFO - 2020-10-12 14:49:00 --> Loader Class Initialized
INFO - 2020-10-12 14:49:00 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:00 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:00 --> Email Class Initialized
INFO - 2020-10-12 14:49:00 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:00 --> Model Class Initialized
INFO - 2020-10-12 14:49:00 --> Model Class Initialized
INFO - 2020-10-12 14:49:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 14:49:00 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:00 --> Total execution time: 0.0234
ERROR - 2020-10-12 14:49:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:05 --> Config Class Initialized
INFO - 2020-10-12 14:49:05 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:05 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:05 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:05 --> URI Class Initialized
INFO - 2020-10-12 14:49:05 --> Router Class Initialized
INFO - 2020-10-12 14:49:05 --> Output Class Initialized
INFO - 2020-10-12 14:49:05 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:05 --> Input Class Initialized
INFO - 2020-10-12 14:49:05 --> Language Class Initialized
INFO - 2020-10-12 14:49:05 --> Loader Class Initialized
INFO - 2020-10-12 14:49:05 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:05 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:05 --> Email Class Initialized
INFO - 2020-10-12 14:49:05 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:05 --> Model Class Initialized
INFO - 2020-10-12 14:49:05 --> Model Class Initialized
INFO - 2020-10-12 14:49:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-12 14:49:05 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:05 --> Total execution time: 0.0241
ERROR - 2020-10-12 14:49:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:19 --> Config Class Initialized
INFO - 2020-10-12 14:49:19 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:19 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:19 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:19 --> URI Class Initialized
INFO - 2020-10-12 14:49:19 --> Router Class Initialized
INFO - 2020-10-12 14:49:19 --> Output Class Initialized
INFO - 2020-10-12 14:49:19 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:19 --> Input Class Initialized
INFO - 2020-10-12 14:49:19 --> Language Class Initialized
INFO - 2020-10-12 14:49:19 --> Loader Class Initialized
INFO - 2020-10-12 14:49:19 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:19 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:19 --> Email Class Initialized
INFO - 2020-10-12 14:49:19 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:19 --> Model Class Initialized
INFO - 2020-10-12 14:49:19 --> Model Class Initialized
INFO - 2020-10-12 14:49:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-12 14:49:19 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:19 --> Total execution time: 0.0534
ERROR - 2020-10-12 14:49:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:21 --> Config Class Initialized
INFO - 2020-10-12 14:49:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:21 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:21 --> URI Class Initialized
INFO - 2020-10-12 14:49:21 --> Router Class Initialized
INFO - 2020-10-12 14:49:21 --> Output Class Initialized
INFO - 2020-10-12 14:49:21 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:21 --> Input Class Initialized
INFO - 2020-10-12 14:49:21 --> Language Class Initialized
INFO - 2020-10-12 14:49:21 --> Loader Class Initialized
INFO - 2020-10-12 14:49:21 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:21 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:21 --> Email Class Initialized
INFO - 2020-10-12 14:49:21 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:21 --> Model Class Initialized
INFO - 2020-10-12 14:49:21 --> Model Class Initialized
INFO - 2020-10-12 14:49:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-12 14:49:21 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:21 --> Total execution time: 0.0310
ERROR - 2020-10-12 14:49:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:23 --> Config Class Initialized
INFO - 2020-10-12 14:49:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:23 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:23 --> URI Class Initialized
INFO - 2020-10-12 14:49:23 --> Router Class Initialized
INFO - 2020-10-12 14:49:23 --> Output Class Initialized
INFO - 2020-10-12 14:49:23 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:23 --> Input Class Initialized
INFO - 2020-10-12 14:49:23 --> Language Class Initialized
INFO - 2020-10-12 14:49:23 --> Loader Class Initialized
INFO - 2020-10-12 14:49:23 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:23 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:23 --> Email Class Initialized
INFO - 2020-10-12 14:49:23 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:23 --> Model Class Initialized
INFO - 2020-10-12 14:49:23 --> Model Class Initialized
INFO - 2020-10-12 14:49:23 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:23 --> Total execution time: 0.0218
ERROR - 2020-10-12 14:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:25 --> Config Class Initialized
INFO - 2020-10-12 14:49:25 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:25 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:25 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:25 --> URI Class Initialized
INFO - 2020-10-12 14:49:25 --> Router Class Initialized
INFO - 2020-10-12 14:49:25 --> Output Class Initialized
INFO - 2020-10-12 14:49:25 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:25 --> Input Class Initialized
INFO - 2020-10-12 14:49:25 --> Language Class Initialized
INFO - 2020-10-12 14:49:25 --> Loader Class Initialized
INFO - 2020-10-12 14:49:25 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:25 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:25 --> Email Class Initialized
INFO - 2020-10-12 14:49:25 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:25 --> Model Class Initialized
INFO - 2020-10-12 14:49:25 --> Model Class Initialized
INFO - 2020-10-12 14:49:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:49:25 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:25 --> Total execution time: 0.0334
ERROR - 2020-10-12 14:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:49:25 --> Config Class Initialized
INFO - 2020-10-12 14:49:25 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:49:25 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:49:25 --> Utf8 Class Initialized
INFO - 2020-10-12 14:49:25 --> URI Class Initialized
INFO - 2020-10-12 14:49:25 --> Router Class Initialized
INFO - 2020-10-12 14:49:25 --> Output Class Initialized
INFO - 2020-10-12 14:49:25 --> Security Class Initialized
DEBUG - 2020-10-12 14:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:49:25 --> Input Class Initialized
INFO - 2020-10-12 14:49:25 --> Language Class Initialized
INFO - 2020-10-12 14:49:25 --> Loader Class Initialized
INFO - 2020-10-12 14:49:25 --> Helper loaded: url_helper
INFO - 2020-10-12 14:49:25 --> Database Driver Class Initialized
INFO - 2020-10-12 14:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:49:25 --> Email Class Initialized
INFO - 2020-10-12 14:49:25 --> Controller Class Initialized
DEBUG - 2020-10-12 14:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:49:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:49:25 --> Model Class Initialized
INFO - 2020-10-12 14:49:25 --> Model Class Initialized
INFO - 2020-10-12 14:49:25 --> Final output sent to browser
DEBUG - 2020-10-12 14:49:25 --> Total execution time: 0.0221
ERROR - 2020-10-12 14:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:41 --> Config Class Initialized
INFO - 2020-10-12 14:50:41 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:41 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:41 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:41 --> URI Class Initialized
INFO - 2020-10-12 14:50:41 --> Router Class Initialized
INFO - 2020-10-12 14:50:41 --> Output Class Initialized
INFO - 2020-10-12 14:50:41 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:41 --> Input Class Initialized
INFO - 2020-10-12 14:50:41 --> Language Class Initialized
INFO - 2020-10-12 14:50:41 --> Loader Class Initialized
INFO - 2020-10-12 14:50:41 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:41 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:41 --> Email Class Initialized
INFO - 2020-10-12 14:50:41 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:41 --> Model Class Initialized
INFO - 2020-10-12 14:50:41 --> Model Class Initialized
INFO - 2020-10-12 14:50:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:50:41 --> Final output sent to browser
DEBUG - 2020-10-12 14:50:41 --> Total execution time: 0.0231
ERROR - 2020-10-12 14:50:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:41 --> Config Class Initialized
INFO - 2020-10-12 14:50:41 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:41 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:41 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:41 --> URI Class Initialized
INFO - 2020-10-12 14:50:41 --> Router Class Initialized
INFO - 2020-10-12 14:50:41 --> Output Class Initialized
INFO - 2020-10-12 14:50:41 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:41 --> Input Class Initialized
INFO - 2020-10-12 14:50:41 --> Language Class Initialized
INFO - 2020-10-12 14:50:41 --> Loader Class Initialized
INFO - 2020-10-12 14:50:41 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:41 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:41 --> Email Class Initialized
INFO - 2020-10-12 14:50:41 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:41 --> Model Class Initialized
INFO - 2020-10-12 14:50:41 --> Model Class Initialized
INFO - 2020-10-12 14:50:41 --> Final output sent to browser
DEBUG - 2020-10-12 14:50:41 --> Total execution time: 0.0276
ERROR - 2020-10-12 14:50:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:46 --> Config Class Initialized
INFO - 2020-10-12 14:50:46 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:46 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:46 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:46 --> URI Class Initialized
INFO - 2020-10-12 14:50:46 --> Router Class Initialized
INFO - 2020-10-12 14:50:46 --> Output Class Initialized
INFO - 2020-10-12 14:50:46 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:46 --> Input Class Initialized
INFO - 2020-10-12 14:50:46 --> Language Class Initialized
INFO - 2020-10-12 14:50:46 --> Loader Class Initialized
INFO - 2020-10-12 14:50:46 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:46 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:46 --> Email Class Initialized
INFO - 2020-10-12 14:50:46 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:46 --> Model Class Initialized
INFO - 2020-10-12 14:50:46 --> Model Class Initialized
ERROR - 2020-10-12 14:50:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-12 14:50:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-12 14:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:49 --> Config Class Initialized
INFO - 2020-10-12 14:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:49 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:49 --> URI Class Initialized
INFO - 2020-10-12 14:50:49 --> Router Class Initialized
INFO - 2020-10-12 14:50:49 --> Output Class Initialized
INFO - 2020-10-12 14:50:49 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:49 --> Input Class Initialized
INFO - 2020-10-12 14:50:49 --> Language Class Initialized
INFO - 2020-10-12 14:50:49 --> Loader Class Initialized
INFO - 2020-10-12 14:50:49 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:49 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:49 --> Email Class Initialized
INFO - 2020-10-12 14:50:49 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:49 --> Model Class Initialized
INFO - 2020-10-12 14:50:49 --> Model Class Initialized
INFO - 2020-10-12 14:50:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:50:49 --> Final output sent to browser
DEBUG - 2020-10-12 14:50:49 --> Total execution time: 0.0234
ERROR - 2020-10-12 14:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:49 --> Config Class Initialized
INFO - 2020-10-12 14:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:49 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:49 --> URI Class Initialized
INFO - 2020-10-12 14:50:49 --> Router Class Initialized
INFO - 2020-10-12 14:50:49 --> Output Class Initialized
INFO - 2020-10-12 14:50:49 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:49 --> Input Class Initialized
INFO - 2020-10-12 14:50:49 --> Language Class Initialized
INFO - 2020-10-12 14:50:49 --> Loader Class Initialized
INFO - 2020-10-12 14:50:49 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:49 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:49 --> Email Class Initialized
INFO - 2020-10-12 14:50:49 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:49 --> Model Class Initialized
INFO - 2020-10-12 14:50:49 --> Model Class Initialized
INFO - 2020-10-12 14:50:49 --> Final output sent to browser
DEBUG - 2020-10-12 14:50:49 --> Total execution time: 0.0211
ERROR - 2020-10-12 14:50:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:50 --> Config Class Initialized
INFO - 2020-10-12 14:50:50 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:50 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:50 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:50 --> URI Class Initialized
INFO - 2020-10-12 14:50:50 --> Router Class Initialized
INFO - 2020-10-12 14:50:50 --> Output Class Initialized
INFO - 2020-10-12 14:50:50 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:50 --> Input Class Initialized
INFO - 2020-10-12 14:50:50 --> Language Class Initialized
INFO - 2020-10-12 14:50:50 --> Loader Class Initialized
INFO - 2020-10-12 14:50:50 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:50 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:50 --> Email Class Initialized
INFO - 2020-10-12 14:50:50 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:50 --> Model Class Initialized
INFO - 2020-10-12 14:50:50 --> Model Class Initialized
INFO - 2020-10-12 14:50:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:50:50 --> Final output sent to browser
DEBUG - 2020-10-12 14:50:50 --> Total execution time: 0.0244
ERROR - 2020-10-12 14:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:51 --> Config Class Initialized
INFO - 2020-10-12 14:50:51 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:51 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:51 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:51 --> URI Class Initialized
INFO - 2020-10-12 14:50:51 --> Router Class Initialized
INFO - 2020-10-12 14:50:51 --> Output Class Initialized
INFO - 2020-10-12 14:50:51 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:51 --> Input Class Initialized
INFO - 2020-10-12 14:50:51 --> Language Class Initialized
INFO - 2020-10-12 14:50:51 --> Loader Class Initialized
INFO - 2020-10-12 14:50:51 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:51 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:51 --> Email Class Initialized
INFO - 2020-10-12 14:50:51 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:51 --> Model Class Initialized
INFO - 2020-10-12 14:50:51 --> Model Class Initialized
INFO - 2020-10-12 14:50:51 --> Final output sent to browser
DEBUG - 2020-10-12 14:50:51 --> Total execution time: 0.0220
ERROR - 2020-10-12 14:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:50:55 --> Config Class Initialized
INFO - 2020-10-12 14:50:55 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:50:55 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:50:55 --> Utf8 Class Initialized
INFO - 2020-10-12 14:50:55 --> URI Class Initialized
INFO - 2020-10-12 14:50:55 --> Router Class Initialized
INFO - 2020-10-12 14:50:55 --> Output Class Initialized
INFO - 2020-10-12 14:50:55 --> Security Class Initialized
DEBUG - 2020-10-12 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:50:55 --> Input Class Initialized
INFO - 2020-10-12 14:50:55 --> Language Class Initialized
INFO - 2020-10-12 14:50:55 --> Loader Class Initialized
INFO - 2020-10-12 14:50:55 --> Helper loaded: url_helper
INFO - 2020-10-12 14:50:55 --> Database Driver Class Initialized
INFO - 2020-10-12 14:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:50:55 --> Email Class Initialized
INFO - 2020-10-12 14:50:55 --> Controller Class Initialized
DEBUG - 2020-10-12 14:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:50:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:50:55 --> Model Class Initialized
INFO - 2020-10-12 14:50:55 --> Model Class Initialized
ERROR - 2020-10-12 14:50:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-12 14:50:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-12 14:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:02 --> Config Class Initialized
INFO - 2020-10-12 14:51:02 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:02 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:02 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:02 --> URI Class Initialized
INFO - 2020-10-12 14:51:02 --> Router Class Initialized
INFO - 2020-10-12 14:51:02 --> Output Class Initialized
INFO - 2020-10-12 14:51:02 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:02 --> Input Class Initialized
INFO - 2020-10-12 14:51:02 --> Language Class Initialized
INFO - 2020-10-12 14:51:02 --> Loader Class Initialized
INFO - 2020-10-12 14:51:02 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:02 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:02 --> Email Class Initialized
INFO - 2020-10-12 14:51:02 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:02 --> Model Class Initialized
INFO - 2020-10-12 14:51:02 --> Model Class Initialized
INFO - 2020-10-12 14:51:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:51:02 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:02 --> Total execution time: 0.0225
ERROR - 2020-10-12 14:51:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:02 --> Config Class Initialized
INFO - 2020-10-12 14:51:02 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:02 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:02 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:02 --> URI Class Initialized
INFO - 2020-10-12 14:51:02 --> Router Class Initialized
INFO - 2020-10-12 14:51:02 --> Output Class Initialized
INFO - 2020-10-12 14:51:02 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:02 --> Input Class Initialized
INFO - 2020-10-12 14:51:02 --> Language Class Initialized
INFO - 2020-10-12 14:51:02 --> Loader Class Initialized
INFO - 2020-10-12 14:51:02 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:02 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:02 --> Email Class Initialized
INFO - 2020-10-12 14:51:02 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:02 --> Model Class Initialized
INFO - 2020-10-12 14:51:02 --> Model Class Initialized
INFO - 2020-10-12 14:51:02 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:02 --> Total execution time: 0.0198
ERROR - 2020-10-12 14:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:08 --> Config Class Initialized
INFO - 2020-10-12 14:51:08 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:08 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:08 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:08 --> URI Class Initialized
INFO - 2020-10-12 14:51:08 --> Router Class Initialized
INFO - 2020-10-12 14:51:08 --> Output Class Initialized
INFO - 2020-10-12 14:51:08 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:08 --> Input Class Initialized
INFO - 2020-10-12 14:51:08 --> Language Class Initialized
INFO - 2020-10-12 14:51:08 --> Loader Class Initialized
INFO - 2020-10-12 14:51:08 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:08 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:08 --> Email Class Initialized
INFO - 2020-10-12 14:51:08 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:08 --> Model Class Initialized
INFO - 2020-10-12 14:51:08 --> Model Class Initialized
INFO - 2020-10-12 14:51:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:51:08 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:08 --> Total execution time: 0.0257
ERROR - 2020-10-12 14:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:09 --> Config Class Initialized
INFO - 2020-10-12 14:51:09 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:09 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:09 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:09 --> URI Class Initialized
INFO - 2020-10-12 14:51:09 --> Router Class Initialized
INFO - 2020-10-12 14:51:09 --> Output Class Initialized
INFO - 2020-10-12 14:51:09 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:09 --> Input Class Initialized
INFO - 2020-10-12 14:51:09 --> Language Class Initialized
INFO - 2020-10-12 14:51:09 --> Loader Class Initialized
INFO - 2020-10-12 14:51:09 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:09 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:09 --> Email Class Initialized
INFO - 2020-10-12 14:51:09 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:09 --> Model Class Initialized
INFO - 2020-10-12 14:51:09 --> Model Class Initialized
INFO - 2020-10-12 14:51:09 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:09 --> Total execution time: 0.0237
ERROR - 2020-10-12 14:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:14 --> Config Class Initialized
INFO - 2020-10-12 14:51:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:14 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:14 --> URI Class Initialized
INFO - 2020-10-12 14:51:14 --> Router Class Initialized
INFO - 2020-10-12 14:51:14 --> Output Class Initialized
INFO - 2020-10-12 14:51:14 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:14 --> Input Class Initialized
INFO - 2020-10-12 14:51:14 --> Language Class Initialized
INFO - 2020-10-12 14:51:14 --> Loader Class Initialized
INFO - 2020-10-12 14:51:14 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:14 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:14 --> Email Class Initialized
INFO - 2020-10-12 14:51:14 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:14 --> Model Class Initialized
INFO - 2020-10-12 14:51:14 --> Model Class Initialized
INFO - 2020-10-12 14:51:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:51:14 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:14 --> Total execution time: 0.0292
ERROR - 2020-10-12 14:51:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:15 --> Config Class Initialized
INFO - 2020-10-12 14:51:15 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:15 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:15 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:15 --> URI Class Initialized
INFO - 2020-10-12 14:51:15 --> Router Class Initialized
INFO - 2020-10-12 14:51:15 --> Output Class Initialized
INFO - 2020-10-12 14:51:15 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:15 --> Input Class Initialized
INFO - 2020-10-12 14:51:15 --> Language Class Initialized
INFO - 2020-10-12 14:51:15 --> Loader Class Initialized
INFO - 2020-10-12 14:51:15 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:15 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:15 --> Email Class Initialized
INFO - 2020-10-12 14:51:15 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:15 --> Model Class Initialized
INFO - 2020-10-12 14:51:15 --> Model Class Initialized
INFO - 2020-10-12 14:51:15 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:15 --> Total execution time: 0.0224
ERROR - 2020-10-12 14:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:53 --> Config Class Initialized
INFO - 2020-10-12 14:51:53 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:53 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:53 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:53 --> URI Class Initialized
INFO - 2020-10-12 14:51:53 --> Router Class Initialized
INFO - 2020-10-12 14:51:53 --> Output Class Initialized
INFO - 2020-10-12 14:51:53 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:53 --> Input Class Initialized
INFO - 2020-10-12 14:51:53 --> Language Class Initialized
INFO - 2020-10-12 14:51:53 --> Loader Class Initialized
INFO - 2020-10-12 14:51:53 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:53 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:53 --> Email Class Initialized
INFO - 2020-10-12 14:51:53 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:53 --> Model Class Initialized
INFO - 2020-10-12 14:51:53 --> Model Class Initialized
INFO - 2020-10-12 14:51:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:51:53 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:53 --> Total execution time: 0.0238
ERROR - 2020-10-12 14:51:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:53 --> Config Class Initialized
INFO - 2020-10-12 14:51:53 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:53 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:53 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:53 --> URI Class Initialized
INFO - 2020-10-12 14:51:53 --> Router Class Initialized
INFO - 2020-10-12 14:51:53 --> Output Class Initialized
INFO - 2020-10-12 14:51:53 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:53 --> Input Class Initialized
INFO - 2020-10-12 14:51:53 --> Language Class Initialized
INFO - 2020-10-12 14:51:53 --> Loader Class Initialized
INFO - 2020-10-12 14:51:53 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:53 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:53 --> Email Class Initialized
INFO - 2020-10-12 14:51:53 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:53 --> Model Class Initialized
INFO - 2020-10-12 14:51:53 --> Model Class Initialized
INFO - 2020-10-12 14:51:53 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:53 --> Total execution time: 0.0190
ERROR - 2020-10-12 14:51:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:58 --> Config Class Initialized
INFO - 2020-10-12 14:51:58 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:58 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:58 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:58 --> URI Class Initialized
INFO - 2020-10-12 14:51:58 --> Router Class Initialized
INFO - 2020-10-12 14:51:58 --> Output Class Initialized
INFO - 2020-10-12 14:51:58 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:58 --> Input Class Initialized
INFO - 2020-10-12 14:51:58 --> Language Class Initialized
INFO - 2020-10-12 14:51:58 --> Loader Class Initialized
INFO - 2020-10-12 14:51:58 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:58 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:58 --> Email Class Initialized
INFO - 2020-10-12 14:51:58 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:58 --> Model Class Initialized
INFO - 2020-10-12 14:51:58 --> Model Class Initialized
INFO - 2020-10-12 14:51:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:51:58 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:58 --> Total execution time: 0.0214
ERROR - 2020-10-12 14:51:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:51:59 --> Config Class Initialized
INFO - 2020-10-12 14:51:59 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:51:59 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:51:59 --> Utf8 Class Initialized
INFO - 2020-10-12 14:51:59 --> URI Class Initialized
INFO - 2020-10-12 14:51:59 --> Router Class Initialized
INFO - 2020-10-12 14:51:59 --> Output Class Initialized
INFO - 2020-10-12 14:51:59 --> Security Class Initialized
DEBUG - 2020-10-12 14:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:51:59 --> Input Class Initialized
INFO - 2020-10-12 14:51:59 --> Language Class Initialized
INFO - 2020-10-12 14:51:59 --> Loader Class Initialized
INFO - 2020-10-12 14:51:59 --> Helper loaded: url_helper
INFO - 2020-10-12 14:51:59 --> Database Driver Class Initialized
INFO - 2020-10-12 14:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:51:59 --> Email Class Initialized
INFO - 2020-10-12 14:51:59 --> Controller Class Initialized
DEBUG - 2020-10-12 14:51:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:51:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:51:59 --> Model Class Initialized
INFO - 2020-10-12 14:51:59 --> Model Class Initialized
INFO - 2020-10-12 14:51:59 --> Final output sent to browser
DEBUG - 2020-10-12 14:51:59 --> Total execution time: 0.0215
ERROR - 2020-10-12 14:52:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:52:03 --> Config Class Initialized
INFO - 2020-10-12 14:52:03 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:52:03 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:52:03 --> Utf8 Class Initialized
INFO - 2020-10-12 14:52:03 --> URI Class Initialized
INFO - 2020-10-12 14:52:03 --> Router Class Initialized
INFO - 2020-10-12 14:52:03 --> Output Class Initialized
INFO - 2020-10-12 14:52:03 --> Security Class Initialized
DEBUG - 2020-10-12 14:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:52:03 --> Input Class Initialized
INFO - 2020-10-12 14:52:03 --> Language Class Initialized
INFO - 2020-10-12 14:52:03 --> Loader Class Initialized
INFO - 2020-10-12 14:52:03 --> Helper loaded: url_helper
INFO - 2020-10-12 14:52:03 --> Database Driver Class Initialized
INFO - 2020-10-12 14:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:52:03 --> Email Class Initialized
INFO - 2020-10-12 14:52:03 --> Controller Class Initialized
DEBUG - 2020-10-12 14:52:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:52:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:52:03 --> Model Class Initialized
INFO - 2020-10-12 14:52:03 --> Model Class Initialized
ERROR - 2020-10-12 14:52:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-12 14:52:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-12 14:52:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:52:06 --> Config Class Initialized
INFO - 2020-10-12 14:52:06 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:52:06 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:52:06 --> Utf8 Class Initialized
INFO - 2020-10-12 14:52:06 --> URI Class Initialized
INFO - 2020-10-12 14:52:06 --> Router Class Initialized
INFO - 2020-10-12 14:52:06 --> Output Class Initialized
INFO - 2020-10-12 14:52:06 --> Security Class Initialized
DEBUG - 2020-10-12 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:52:06 --> Input Class Initialized
INFO - 2020-10-12 14:52:06 --> Language Class Initialized
INFO - 2020-10-12 14:52:06 --> Loader Class Initialized
INFO - 2020-10-12 14:52:06 --> Helper loaded: url_helper
INFO - 2020-10-12 14:52:06 --> Database Driver Class Initialized
INFO - 2020-10-12 14:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:52:06 --> Email Class Initialized
INFO - 2020-10-12 14:52:06 --> Controller Class Initialized
DEBUG - 2020-10-12 14:52:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:52:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:52:06 --> Model Class Initialized
INFO - 2020-10-12 14:52:06 --> Model Class Initialized
INFO - 2020-10-12 14:52:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:52:06 --> Final output sent to browser
DEBUG - 2020-10-12 14:52:06 --> Total execution time: 0.0242
ERROR - 2020-10-12 14:52:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:52:06 --> Config Class Initialized
INFO - 2020-10-12 14:52:06 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:52:06 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:52:06 --> Utf8 Class Initialized
INFO - 2020-10-12 14:52:06 --> URI Class Initialized
INFO - 2020-10-12 14:52:06 --> Router Class Initialized
INFO - 2020-10-12 14:52:06 --> Output Class Initialized
INFO - 2020-10-12 14:52:06 --> Security Class Initialized
DEBUG - 2020-10-12 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:52:06 --> Input Class Initialized
INFO - 2020-10-12 14:52:06 --> Language Class Initialized
INFO - 2020-10-12 14:52:06 --> Loader Class Initialized
INFO - 2020-10-12 14:52:06 --> Helper loaded: url_helper
INFO - 2020-10-12 14:52:06 --> Database Driver Class Initialized
INFO - 2020-10-12 14:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:52:06 --> Email Class Initialized
INFO - 2020-10-12 14:52:06 --> Controller Class Initialized
DEBUG - 2020-10-12 14:52:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:52:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:52:06 --> Model Class Initialized
INFO - 2020-10-12 14:52:06 --> Model Class Initialized
INFO - 2020-10-12 14:52:06 --> Final output sent to browser
DEBUG - 2020-10-12 14:52:06 --> Total execution time: 0.0218
ERROR - 2020-10-12 14:53:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:53:15 --> Config Class Initialized
INFO - 2020-10-12 14:53:15 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:53:15 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:53:15 --> Utf8 Class Initialized
INFO - 2020-10-12 14:53:15 --> URI Class Initialized
INFO - 2020-10-12 14:53:15 --> Router Class Initialized
INFO - 2020-10-12 14:53:15 --> Output Class Initialized
INFO - 2020-10-12 14:53:15 --> Security Class Initialized
DEBUG - 2020-10-12 14:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:53:15 --> Input Class Initialized
INFO - 2020-10-12 14:53:15 --> Language Class Initialized
INFO - 2020-10-12 14:53:15 --> Loader Class Initialized
INFO - 2020-10-12 14:53:15 --> Helper loaded: url_helper
INFO - 2020-10-12 14:53:15 --> Database Driver Class Initialized
INFO - 2020-10-12 14:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:53:15 --> Email Class Initialized
INFO - 2020-10-12 14:53:15 --> Controller Class Initialized
DEBUG - 2020-10-12 14:53:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:53:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:53:15 --> Model Class Initialized
INFO - 2020-10-12 14:53:15 --> Model Class Initialized
INFO - 2020-10-12 14:53:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:53:15 --> Final output sent to browser
DEBUG - 2020-10-12 14:53:15 --> Total execution time: 0.0248
ERROR - 2020-10-12 14:53:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:53:16 --> Config Class Initialized
INFO - 2020-10-12 14:53:16 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:53:16 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:53:16 --> Utf8 Class Initialized
INFO - 2020-10-12 14:53:16 --> URI Class Initialized
INFO - 2020-10-12 14:53:16 --> Router Class Initialized
INFO - 2020-10-12 14:53:16 --> Output Class Initialized
INFO - 2020-10-12 14:53:16 --> Security Class Initialized
DEBUG - 2020-10-12 14:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:53:16 --> Input Class Initialized
INFO - 2020-10-12 14:53:16 --> Language Class Initialized
INFO - 2020-10-12 14:53:16 --> Loader Class Initialized
INFO - 2020-10-12 14:53:16 --> Helper loaded: url_helper
INFO - 2020-10-12 14:53:16 --> Database Driver Class Initialized
INFO - 2020-10-12 14:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:53:16 --> Email Class Initialized
INFO - 2020-10-12 14:53:16 --> Controller Class Initialized
DEBUG - 2020-10-12 14:53:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:53:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:53:16 --> Model Class Initialized
INFO - 2020-10-12 14:53:16 --> Model Class Initialized
INFO - 2020-10-12 14:53:16 --> Final output sent to browser
DEBUG - 2020-10-12 14:53:16 --> Total execution time: 0.0224
ERROR - 2020-10-12 14:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:53:21 --> Config Class Initialized
INFO - 2020-10-12 14:53:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:53:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:53:21 --> Utf8 Class Initialized
INFO - 2020-10-12 14:53:21 --> URI Class Initialized
INFO - 2020-10-12 14:53:21 --> Router Class Initialized
INFO - 2020-10-12 14:53:21 --> Output Class Initialized
INFO - 2020-10-12 14:53:21 --> Security Class Initialized
DEBUG - 2020-10-12 14:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:53:21 --> Input Class Initialized
INFO - 2020-10-12 14:53:21 --> Language Class Initialized
INFO - 2020-10-12 14:53:21 --> Loader Class Initialized
INFO - 2020-10-12 14:53:21 --> Helper loaded: url_helper
INFO - 2020-10-12 14:53:21 --> Database Driver Class Initialized
INFO - 2020-10-12 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:53:21 --> Email Class Initialized
INFO - 2020-10-12 14:53:21 --> Controller Class Initialized
DEBUG - 2020-10-12 14:53:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:53:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:53:21 --> Model Class Initialized
INFO - 2020-10-12 14:53:21 --> Model Class Initialized
INFO - 2020-10-12 14:53:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:53:21 --> Final output sent to browser
DEBUG - 2020-10-12 14:53:21 --> Total execution time: 0.0261
ERROR - 2020-10-12 14:53:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:53:21 --> Config Class Initialized
INFO - 2020-10-12 14:53:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:53:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:53:21 --> Utf8 Class Initialized
INFO - 2020-10-12 14:53:21 --> URI Class Initialized
INFO - 2020-10-12 14:53:21 --> Router Class Initialized
INFO - 2020-10-12 14:53:21 --> Output Class Initialized
INFO - 2020-10-12 14:53:21 --> Security Class Initialized
DEBUG - 2020-10-12 14:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:53:21 --> Input Class Initialized
INFO - 2020-10-12 14:53:21 --> Language Class Initialized
INFO - 2020-10-12 14:53:21 --> Loader Class Initialized
INFO - 2020-10-12 14:53:21 --> Helper loaded: url_helper
INFO - 2020-10-12 14:53:21 --> Database Driver Class Initialized
INFO - 2020-10-12 14:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:53:21 --> Email Class Initialized
INFO - 2020-10-12 14:53:21 --> Controller Class Initialized
DEBUG - 2020-10-12 14:53:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:53:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:53:21 --> Model Class Initialized
INFO - 2020-10-12 14:53:21 --> Model Class Initialized
INFO - 2020-10-12 14:53:21 --> Final output sent to browser
DEBUG - 2020-10-12 14:53:21 --> Total execution time: 0.0222
ERROR - 2020-10-12 14:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:53:29 --> Config Class Initialized
INFO - 2020-10-12 14:53:29 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:53:29 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:53:29 --> Utf8 Class Initialized
INFO - 2020-10-12 14:53:29 --> URI Class Initialized
INFO - 2020-10-12 14:53:29 --> Router Class Initialized
INFO - 2020-10-12 14:53:29 --> Output Class Initialized
INFO - 2020-10-12 14:53:29 --> Security Class Initialized
DEBUG - 2020-10-12 14:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:53:29 --> Input Class Initialized
INFO - 2020-10-12 14:53:29 --> Language Class Initialized
INFO - 2020-10-12 14:53:29 --> Loader Class Initialized
INFO - 2020-10-12 14:53:29 --> Helper loaded: url_helper
INFO - 2020-10-12 14:53:29 --> Database Driver Class Initialized
INFO - 2020-10-12 14:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:53:29 --> Email Class Initialized
INFO - 2020-10-12 14:53:29 --> Controller Class Initialized
DEBUG - 2020-10-12 14:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:53:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:53:29 --> Model Class Initialized
INFO - 2020-10-12 14:53:29 --> Model Class Initialized
INFO - 2020-10-12 14:53:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:53:29 --> Final output sent to browser
DEBUG - 2020-10-12 14:53:29 --> Total execution time: 0.0260
ERROR - 2020-10-12 14:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:53:29 --> Config Class Initialized
INFO - 2020-10-12 14:53:29 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:53:29 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:53:29 --> Utf8 Class Initialized
INFO - 2020-10-12 14:53:29 --> URI Class Initialized
INFO - 2020-10-12 14:53:29 --> Router Class Initialized
INFO - 2020-10-12 14:53:29 --> Output Class Initialized
INFO - 2020-10-12 14:53:29 --> Security Class Initialized
DEBUG - 2020-10-12 14:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:53:29 --> Input Class Initialized
INFO - 2020-10-12 14:53:29 --> Language Class Initialized
INFO - 2020-10-12 14:53:29 --> Loader Class Initialized
INFO - 2020-10-12 14:53:29 --> Helper loaded: url_helper
INFO - 2020-10-12 14:53:29 --> Database Driver Class Initialized
INFO - 2020-10-12 14:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:53:29 --> Email Class Initialized
INFO - 2020-10-12 14:53:29 --> Controller Class Initialized
DEBUG - 2020-10-12 14:53:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:53:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:53:29 --> Model Class Initialized
INFO - 2020-10-12 14:53:29 --> Model Class Initialized
INFO - 2020-10-12 14:53:29 --> Final output sent to browser
DEBUG - 2020-10-12 14:53:29 --> Total execution time: 0.0238
ERROR - 2020-10-12 14:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:56:36 --> Config Class Initialized
INFO - 2020-10-12 14:56:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:56:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:56:36 --> Utf8 Class Initialized
INFO - 2020-10-12 14:56:36 --> URI Class Initialized
INFO - 2020-10-12 14:56:36 --> Router Class Initialized
INFO - 2020-10-12 14:56:36 --> Output Class Initialized
INFO - 2020-10-12 14:56:36 --> Security Class Initialized
DEBUG - 2020-10-12 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:56:36 --> Input Class Initialized
INFO - 2020-10-12 14:56:36 --> Language Class Initialized
INFO - 2020-10-12 14:56:36 --> Loader Class Initialized
INFO - 2020-10-12 14:56:36 --> Helper loaded: url_helper
INFO - 2020-10-12 14:56:36 --> Database Driver Class Initialized
INFO - 2020-10-12 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:56:36 --> Email Class Initialized
INFO - 2020-10-12 14:56:36 --> Controller Class Initialized
DEBUG - 2020-10-12 14:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:56:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:56:36 --> Model Class Initialized
INFO - 2020-10-12 14:56:36 --> Model Class Initialized
INFO - 2020-10-12 14:56:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-12 14:56:36 --> Final output sent to browser
DEBUG - 2020-10-12 14:56:36 --> Total execution time: 0.0236
ERROR - 2020-10-12 14:56:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:56:36 --> Config Class Initialized
INFO - 2020-10-12 14:56:36 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:56:36 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:56:36 --> Utf8 Class Initialized
INFO - 2020-10-12 14:56:36 --> URI Class Initialized
INFO - 2020-10-12 14:56:36 --> Router Class Initialized
INFO - 2020-10-12 14:56:36 --> Output Class Initialized
INFO - 2020-10-12 14:56:36 --> Security Class Initialized
DEBUG - 2020-10-12 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:56:36 --> Input Class Initialized
INFO - 2020-10-12 14:56:36 --> Language Class Initialized
INFO - 2020-10-12 14:56:36 --> Loader Class Initialized
INFO - 2020-10-12 14:56:36 --> Helper loaded: url_helper
INFO - 2020-10-12 14:56:36 --> Database Driver Class Initialized
INFO - 2020-10-12 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:56:36 --> Email Class Initialized
INFO - 2020-10-12 14:56:36 --> Controller Class Initialized
DEBUG - 2020-10-12 14:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:56:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:56:36 --> Model Class Initialized
INFO - 2020-10-12 14:56:36 --> Model Class Initialized
INFO - 2020-10-12 14:56:36 --> Final output sent to browser
DEBUG - 2020-10-12 14:56:36 --> Total execution time: 0.0208
ERROR - 2020-10-12 14:57:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:57:20 --> Config Class Initialized
INFO - 2020-10-12 14:57:20 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:57:20 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:57:20 --> Utf8 Class Initialized
INFO - 2020-10-12 14:57:20 --> URI Class Initialized
INFO - 2020-10-12 14:57:20 --> Router Class Initialized
INFO - 2020-10-12 14:57:20 --> Output Class Initialized
INFO - 2020-10-12 14:57:20 --> Security Class Initialized
DEBUG - 2020-10-12 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:57:20 --> Input Class Initialized
INFO - 2020-10-12 14:57:20 --> Language Class Initialized
INFO - 2020-10-12 14:57:20 --> Loader Class Initialized
INFO - 2020-10-12 14:57:20 --> Helper loaded: url_helper
INFO - 2020-10-12 14:57:20 --> Database Driver Class Initialized
INFO - 2020-10-12 14:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:57:20 --> Email Class Initialized
INFO - 2020-10-12 14:57:20 --> Controller Class Initialized
DEBUG - 2020-10-12 14:57:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:57:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:57:20 --> Model Class Initialized
INFO - 2020-10-12 14:57:20 --> Model Class Initialized
INFO - 2020-10-12 14:57:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-12 14:57:20 --> Final output sent to browser
DEBUG - 2020-10-12 14:57:20 --> Total execution time: 0.0219
ERROR - 2020-10-12 14:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:57:21 --> Config Class Initialized
INFO - 2020-10-12 14:57:21 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:57:21 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:57:21 --> Utf8 Class Initialized
INFO - 2020-10-12 14:57:21 --> URI Class Initialized
INFO - 2020-10-12 14:57:21 --> Router Class Initialized
INFO - 2020-10-12 14:57:21 --> Output Class Initialized
INFO - 2020-10-12 14:57:21 --> Security Class Initialized
DEBUG - 2020-10-12 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:57:21 --> Input Class Initialized
INFO - 2020-10-12 14:57:21 --> Language Class Initialized
INFO - 2020-10-12 14:57:21 --> Loader Class Initialized
INFO - 2020-10-12 14:57:21 --> Helper loaded: url_helper
INFO - 2020-10-12 14:57:21 --> Database Driver Class Initialized
INFO - 2020-10-12 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:57:21 --> Email Class Initialized
INFO - 2020-10-12 14:57:21 --> Controller Class Initialized
DEBUG - 2020-10-12 14:57:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:57:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:57:21 --> Model Class Initialized
INFO - 2020-10-12 14:57:21 --> Model Class Initialized
INFO - 2020-10-12 14:57:21 --> Final output sent to browser
DEBUG - 2020-10-12 14:57:21 --> Total execution time: 0.0211
ERROR - 2020-10-12 14:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:57:42 --> Config Class Initialized
INFO - 2020-10-12 14:57:42 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:57:42 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:57:42 --> Utf8 Class Initialized
INFO - 2020-10-12 14:57:42 --> URI Class Initialized
INFO - 2020-10-12 14:57:42 --> Router Class Initialized
INFO - 2020-10-12 14:57:42 --> Output Class Initialized
INFO - 2020-10-12 14:57:42 --> Security Class Initialized
DEBUG - 2020-10-12 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:57:42 --> Input Class Initialized
INFO - 2020-10-12 14:57:42 --> Language Class Initialized
INFO - 2020-10-12 14:57:42 --> Loader Class Initialized
INFO - 2020-10-12 14:57:42 --> Helper loaded: url_helper
INFO - 2020-10-12 14:57:42 --> Database Driver Class Initialized
INFO - 2020-10-12 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:57:42 --> Email Class Initialized
INFO - 2020-10-12 14:57:42 --> Controller Class Initialized
DEBUG - 2020-10-12 14:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:57:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:57:42 --> Model Class Initialized
INFO - 2020-10-12 14:57:42 --> Model Class Initialized
INFO - 2020-10-12 14:57:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-12 14:57:42 --> Final output sent to browser
DEBUG - 2020-10-12 14:57:42 --> Total execution time: 0.3619
ERROR - 2020-10-12 14:57:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:57:43 --> Config Class Initialized
INFO - 2020-10-12 14:57:43 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:57:43 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:57:43 --> Utf8 Class Initialized
INFO - 2020-10-12 14:57:43 --> URI Class Initialized
INFO - 2020-10-12 14:57:43 --> Router Class Initialized
INFO - 2020-10-12 14:57:43 --> Output Class Initialized
INFO - 2020-10-12 14:57:43 --> Security Class Initialized
DEBUG - 2020-10-12 14:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:57:43 --> Input Class Initialized
INFO - 2020-10-12 14:57:43 --> Language Class Initialized
INFO - 2020-10-12 14:57:43 --> Loader Class Initialized
INFO - 2020-10-12 14:57:43 --> Helper loaded: url_helper
INFO - 2020-10-12 14:57:43 --> Database Driver Class Initialized
INFO - 2020-10-12 14:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:57:43 --> Email Class Initialized
INFO - 2020-10-12 14:57:43 --> Controller Class Initialized
DEBUG - 2020-10-12 14:57:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:57:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:57:43 --> Model Class Initialized
INFO - 2020-10-12 14:57:43 --> Model Class Initialized
INFO - 2020-10-12 14:57:43 --> Final output sent to browser
DEBUG - 2020-10-12 14:57:43 --> Total execution time: 0.0237
ERROR - 2020-10-12 14:58:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:58:15 --> Config Class Initialized
INFO - 2020-10-12 14:58:15 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:58:15 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:58:15 --> Utf8 Class Initialized
INFO - 2020-10-12 14:58:15 --> URI Class Initialized
DEBUG - 2020-10-12 14:58:15 --> No URI present. Default controller set.
INFO - 2020-10-12 14:58:15 --> Router Class Initialized
INFO - 2020-10-12 14:58:15 --> Output Class Initialized
INFO - 2020-10-12 14:58:15 --> Security Class Initialized
DEBUG - 2020-10-12 14:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:58:15 --> Input Class Initialized
INFO - 2020-10-12 14:58:15 --> Language Class Initialized
INFO - 2020-10-12 14:58:15 --> Loader Class Initialized
INFO - 2020-10-12 14:58:15 --> Helper loaded: url_helper
INFO - 2020-10-12 14:58:15 --> Database Driver Class Initialized
INFO - 2020-10-12 14:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:58:15 --> Email Class Initialized
INFO - 2020-10-12 14:58:15 --> Controller Class Initialized
INFO - 2020-10-12 14:58:15 --> Model Class Initialized
INFO - 2020-10-12 14:58:15 --> Model Class Initialized
DEBUG - 2020-10-12 14:58:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:58:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:58:15 --> Final output sent to browser
DEBUG - 2020-10-12 14:58:15 --> Total execution time: 0.0214
ERROR - 2020-10-12 14:58:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:58:35 --> Config Class Initialized
INFO - 2020-10-12 14:58:35 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:58:35 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:58:35 --> Utf8 Class Initialized
INFO - 2020-10-12 14:58:35 --> URI Class Initialized
INFO - 2020-10-12 14:58:35 --> Router Class Initialized
INFO - 2020-10-12 14:58:35 --> Output Class Initialized
INFO - 2020-10-12 14:58:35 --> Security Class Initialized
DEBUG - 2020-10-12 14:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:58:35 --> Input Class Initialized
INFO - 2020-10-12 14:58:35 --> Language Class Initialized
INFO - 2020-10-12 14:58:35 --> Loader Class Initialized
INFO - 2020-10-12 14:58:35 --> Helper loaded: url_helper
INFO - 2020-10-12 14:58:35 --> Database Driver Class Initialized
INFO - 2020-10-12 14:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:58:35 --> Email Class Initialized
INFO - 2020-10-12 14:58:35 --> Controller Class Initialized
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
DEBUG - 2020-10-12 14:58:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:58:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
INFO - 2020-10-12 14:58:35 --> Final output sent to browser
DEBUG - 2020-10-12 14:58:35 --> Total execution time: 0.0287
ERROR - 2020-10-12 14:58:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:58:35 --> Config Class Initialized
INFO - 2020-10-12 14:58:35 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:58:35 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:58:35 --> Utf8 Class Initialized
INFO - 2020-10-12 14:58:35 --> URI Class Initialized
INFO - 2020-10-12 14:58:35 --> Router Class Initialized
INFO - 2020-10-12 14:58:35 --> Output Class Initialized
INFO - 2020-10-12 14:58:35 --> Security Class Initialized
DEBUG - 2020-10-12 14:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:58:35 --> Input Class Initialized
INFO - 2020-10-12 14:58:35 --> Language Class Initialized
INFO - 2020-10-12 14:58:35 --> Loader Class Initialized
INFO - 2020-10-12 14:58:35 --> Helper loaded: url_helper
INFO - 2020-10-12 14:58:35 --> Database Driver Class Initialized
INFO - 2020-10-12 14:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:58:35 --> Email Class Initialized
INFO - 2020-10-12 14:58:35 --> Controller Class Initialized
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
DEBUG - 2020-10-12 14:58:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 14:58:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:58:35 --> Config Class Initialized
INFO - 2020-10-12 14:58:35 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:58:35 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:58:35 --> Utf8 Class Initialized
INFO - 2020-10-12 14:58:35 --> URI Class Initialized
INFO - 2020-10-12 14:58:35 --> Router Class Initialized
INFO - 2020-10-12 14:58:35 --> Output Class Initialized
INFO - 2020-10-12 14:58:35 --> Security Class Initialized
DEBUG - 2020-10-12 14:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:58:35 --> Input Class Initialized
INFO - 2020-10-12 14:58:35 --> Language Class Initialized
INFO - 2020-10-12 14:58:35 --> Loader Class Initialized
INFO - 2020-10-12 14:58:35 --> Helper loaded: url_helper
INFO - 2020-10-12 14:58:35 --> Database Driver Class Initialized
INFO - 2020-10-12 14:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:58:35 --> Email Class Initialized
INFO - 2020-10-12 14:58:35 --> Controller Class Initialized
DEBUG - 2020-10-12 14:58:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 14:58:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
INFO - 2020-10-12 14:58:35 --> Model Class Initialized
INFO - 2020-10-12 14:58:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-12 14:58:35 --> Final output sent to browser
DEBUG - 2020-10-12 14:58:35 --> Total execution time: 0.0241
ERROR - 2020-10-12 14:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 14:59:29 --> Config Class Initialized
INFO - 2020-10-12 14:59:29 --> Hooks Class Initialized
DEBUG - 2020-10-12 14:59:29 --> UTF-8 Support Enabled
INFO - 2020-10-12 14:59:29 --> Utf8 Class Initialized
INFO - 2020-10-12 14:59:29 --> URI Class Initialized
DEBUG - 2020-10-12 14:59:29 --> No URI present. Default controller set.
INFO - 2020-10-12 14:59:29 --> Router Class Initialized
INFO - 2020-10-12 14:59:29 --> Output Class Initialized
INFO - 2020-10-12 14:59:29 --> Security Class Initialized
DEBUG - 2020-10-12 14:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 14:59:29 --> Input Class Initialized
INFO - 2020-10-12 14:59:29 --> Language Class Initialized
INFO - 2020-10-12 14:59:29 --> Loader Class Initialized
INFO - 2020-10-12 14:59:29 --> Helper loaded: url_helper
INFO - 2020-10-12 14:59:29 --> Database Driver Class Initialized
INFO - 2020-10-12 14:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 14:59:29 --> Email Class Initialized
INFO - 2020-10-12 14:59:29 --> Controller Class Initialized
INFO - 2020-10-12 14:59:29 --> Model Class Initialized
INFO - 2020-10-12 14:59:29 --> Model Class Initialized
DEBUG - 2020-10-12 14:59:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 14:59:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 14:59:29 --> Final output sent to browser
DEBUG - 2020-10-12 14:59:29 --> Total execution time: 0.0258
ERROR - 2020-10-12 15:00:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:23 --> Config Class Initialized
INFO - 2020-10-12 15:00:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:23 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:23 --> URI Class Initialized
INFO - 2020-10-12 15:00:23 --> Router Class Initialized
INFO - 2020-10-12 15:00:23 --> Output Class Initialized
INFO - 2020-10-12 15:00:23 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:23 --> Input Class Initialized
INFO - 2020-10-12 15:00:23 --> Language Class Initialized
INFO - 2020-10-12 15:00:23 --> Loader Class Initialized
INFO - 2020-10-12 15:00:23 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:23 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:23 --> Email Class Initialized
INFO - 2020-10-12 15:00:23 --> Controller Class Initialized
INFO - 2020-10-12 15:00:23 --> Model Class Initialized
INFO - 2020-10-12 15:00:23 --> Model Class Initialized
DEBUG - 2020-10-12 15:00:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:23 --> Model Class Initialized
ERROR - 2020-10-12 15:00:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:23 --> Config Class Initialized
INFO - 2020-10-12 15:00:23 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:23 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:23 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:23 --> URI Class Initialized
INFO - 2020-10-12 15:00:23 --> Router Class Initialized
INFO - 2020-10-12 15:00:23 --> Output Class Initialized
INFO - 2020-10-12 15:00:23 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:23 --> Input Class Initialized
INFO - 2020-10-12 15:00:23 --> Language Class Initialized
INFO - 2020-10-12 15:00:23 --> Loader Class Initialized
INFO - 2020-10-12 15:00:23 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:23 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:23 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:23 --> Total execution time: 0.1579
INFO - 2020-10-12 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:23 --> Email Class Initialized
INFO - 2020-10-12 15:00:23 --> Controller Class Initialized
INFO - 2020-10-12 15:00:23 --> Model Class Initialized
INFO - 2020-10-12 15:00:23 --> Model Class Initialized
DEBUG - 2020-10-12 15:00:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-12 15:00:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:24 --> Config Class Initialized
INFO - 2020-10-12 15:00:24 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:24 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:24 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:24 --> URI Class Initialized
INFO - 2020-10-12 15:00:24 --> Router Class Initialized
INFO - 2020-10-12 15:00:24 --> Output Class Initialized
INFO - 2020-10-12 15:00:24 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:24 --> Input Class Initialized
INFO - 2020-10-12 15:00:24 --> Language Class Initialized
INFO - 2020-10-12 15:00:24 --> Loader Class Initialized
INFO - 2020-10-12 15:00:24 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:24 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:24 --> Email Class Initialized
INFO - 2020-10-12 15:00:24 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:24 --> Model Class Initialized
INFO - 2020-10-12 15:00:24 --> Model Class Initialized
INFO - 2020-10-12 15:00:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-12 15:00:24 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:24 --> Total execution time: 0.0257
ERROR - 2020-10-12 15:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:32 --> Config Class Initialized
INFO - 2020-10-12 15:00:32 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:32 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:32 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:32 --> URI Class Initialized
INFO - 2020-10-12 15:00:32 --> Router Class Initialized
INFO - 2020-10-12 15:00:32 --> Output Class Initialized
INFO - 2020-10-12 15:00:32 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:32 --> Input Class Initialized
INFO - 2020-10-12 15:00:32 --> Language Class Initialized
INFO - 2020-10-12 15:00:32 --> Loader Class Initialized
INFO - 2020-10-12 15:00:32 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:32 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:32 --> Email Class Initialized
INFO - 2020-10-12 15:00:32 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:32 --> Model Class Initialized
INFO - 2020-10-12 15:00:32 --> Model Class Initialized
INFO - 2020-10-12 15:00:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 15:00:32 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:32 --> Total execution time: 0.0261
ERROR - 2020-10-12 15:00:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:35 --> Config Class Initialized
INFO - 2020-10-12 15:00:35 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:35 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:35 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:35 --> URI Class Initialized
INFO - 2020-10-12 15:00:35 --> Router Class Initialized
INFO - 2020-10-12 15:00:35 --> Output Class Initialized
INFO - 2020-10-12 15:00:35 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:35 --> Input Class Initialized
INFO - 2020-10-12 15:00:35 --> Language Class Initialized
INFO - 2020-10-12 15:00:35 --> Loader Class Initialized
INFO - 2020-10-12 15:00:35 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:35 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:35 --> Email Class Initialized
INFO - 2020-10-12 15:00:35 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:35 --> Model Class Initialized
INFO - 2020-10-12 15:00:35 --> Model Class Initialized
INFO - 2020-10-12 15:00:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:00:35 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:35 --> Total execution time: 0.0277
ERROR - 2020-10-12 15:00:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:38 --> Config Class Initialized
INFO - 2020-10-12 15:00:38 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:38 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:38 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:38 --> URI Class Initialized
INFO - 2020-10-12 15:00:38 --> Router Class Initialized
INFO - 2020-10-12 15:00:38 --> Output Class Initialized
INFO - 2020-10-12 15:00:38 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:38 --> Input Class Initialized
INFO - 2020-10-12 15:00:38 --> Language Class Initialized
INFO - 2020-10-12 15:00:38 --> Loader Class Initialized
INFO - 2020-10-12 15:00:38 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:38 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:38 --> Email Class Initialized
INFO - 2020-10-12 15:00:38 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:38 --> Model Class Initialized
INFO - 2020-10-12 15:00:38 --> Model Class Initialized
INFO - 2020-10-12 15:00:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 15:00:38 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:38 --> Total execution time: 0.0242
ERROR - 2020-10-12 15:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:41 --> Config Class Initialized
INFO - 2020-10-12 15:00:41 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:41 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:41 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:41 --> URI Class Initialized
INFO - 2020-10-12 15:00:41 --> Router Class Initialized
INFO - 2020-10-12 15:00:41 --> Output Class Initialized
INFO - 2020-10-12 15:00:41 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:41 --> Input Class Initialized
INFO - 2020-10-12 15:00:41 --> Language Class Initialized
INFO - 2020-10-12 15:00:41 --> Loader Class Initialized
INFO - 2020-10-12 15:00:41 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:41 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:41 --> Email Class Initialized
INFO - 2020-10-12 15:00:41 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:41 --> Model Class Initialized
INFO - 2020-10-12 15:00:41 --> Model Class Initialized
INFO - 2020-10-12 15:00:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:00:41 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:41 --> Total execution time: 0.0241
ERROR - 2020-10-12 15:00:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:45 --> Config Class Initialized
INFO - 2020-10-12 15:00:45 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:45 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:45 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:45 --> URI Class Initialized
INFO - 2020-10-12 15:00:45 --> Router Class Initialized
INFO - 2020-10-12 15:00:45 --> Output Class Initialized
INFO - 2020-10-12 15:00:45 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:45 --> Input Class Initialized
INFO - 2020-10-12 15:00:45 --> Language Class Initialized
INFO - 2020-10-12 15:00:45 --> Loader Class Initialized
INFO - 2020-10-12 15:00:45 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:45 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:45 --> Email Class Initialized
INFO - 2020-10-12 15:00:45 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:45 --> Model Class Initialized
INFO - 2020-10-12 15:00:45 --> Model Class Initialized
INFO - 2020-10-12 15:00:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-12 15:00:45 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:45 --> Total execution time: 0.0234
ERROR - 2020-10-12 15:00:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:00:47 --> Config Class Initialized
INFO - 2020-10-12 15:00:47 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:00:47 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:00:47 --> Utf8 Class Initialized
INFO - 2020-10-12 15:00:47 --> URI Class Initialized
INFO - 2020-10-12 15:00:47 --> Router Class Initialized
INFO - 2020-10-12 15:00:47 --> Output Class Initialized
INFO - 2020-10-12 15:00:47 --> Security Class Initialized
DEBUG - 2020-10-12 15:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:00:47 --> Input Class Initialized
INFO - 2020-10-12 15:00:47 --> Language Class Initialized
INFO - 2020-10-12 15:00:48 --> Loader Class Initialized
INFO - 2020-10-12 15:00:48 --> Helper loaded: url_helper
INFO - 2020-10-12 15:00:48 --> Database Driver Class Initialized
INFO - 2020-10-12 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:00:48 --> Email Class Initialized
INFO - 2020-10-12 15:00:48 --> Controller Class Initialized
DEBUG - 2020-10-12 15:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:00:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:00:48 --> Model Class Initialized
INFO - 2020-10-12 15:00:48 --> Model Class Initialized
INFO - 2020-10-12 15:00:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:00:48 --> Final output sent to browser
DEBUG - 2020-10-12 15:00:48 --> Total execution time: 0.0257
ERROR - 2020-10-12 15:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:01:14 --> Config Class Initialized
INFO - 2020-10-12 15:01:14 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:01:14 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:01:14 --> Utf8 Class Initialized
INFO - 2020-10-12 15:01:14 --> URI Class Initialized
INFO - 2020-10-12 15:01:14 --> Router Class Initialized
INFO - 2020-10-12 15:01:14 --> Output Class Initialized
INFO - 2020-10-12 15:01:14 --> Security Class Initialized
DEBUG - 2020-10-12 15:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:01:14 --> Input Class Initialized
INFO - 2020-10-12 15:01:14 --> Language Class Initialized
INFO - 2020-10-12 15:01:14 --> Loader Class Initialized
INFO - 2020-10-12 15:01:14 --> Helper loaded: url_helper
INFO - 2020-10-12 15:01:14 --> Database Driver Class Initialized
INFO - 2020-10-12 15:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:01:14 --> Email Class Initialized
INFO - 2020-10-12 15:01:14 --> Controller Class Initialized
DEBUG - 2020-10-12 15:01:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:01:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:01:14 --> Model Class Initialized
INFO - 2020-10-12 15:01:14 --> Model Class Initialized
INFO - 2020-10-12 15:01:14 --> Model Class Initialized
INFO - 2020-10-12 15:01:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:01:14 --> Final output sent to browser
DEBUG - 2020-10-12 15:01:14 --> Total execution time: 0.0270
ERROR - 2020-10-12 15:04:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:04:15 --> Config Class Initialized
INFO - 2020-10-12 15:04:15 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:04:15 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:04:15 --> Utf8 Class Initialized
INFO - 2020-10-12 15:04:15 --> URI Class Initialized
INFO - 2020-10-12 15:04:15 --> Router Class Initialized
INFO - 2020-10-12 15:04:15 --> Output Class Initialized
INFO - 2020-10-12 15:04:15 --> Security Class Initialized
DEBUG - 2020-10-12 15:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:04:15 --> Input Class Initialized
INFO - 2020-10-12 15:04:15 --> Language Class Initialized
INFO - 2020-10-12 15:04:15 --> Loader Class Initialized
INFO - 2020-10-12 15:04:15 --> Helper loaded: url_helper
INFO - 2020-10-12 15:04:15 --> Database Driver Class Initialized
INFO - 2020-10-12 15:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:04:15 --> Email Class Initialized
INFO - 2020-10-12 15:04:15 --> Controller Class Initialized
DEBUG - 2020-10-12 15:04:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:04:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:04:15 --> Model Class Initialized
INFO - 2020-10-12 15:04:15 --> Model Class Initialized
INFO - 2020-10-12 15:04:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:04:15 --> Final output sent to browser
DEBUG - 2020-10-12 15:04:15 --> Total execution time: 0.0279
ERROR - 2020-10-12 15:04:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:04:57 --> Config Class Initialized
INFO - 2020-10-12 15:04:57 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:04:57 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:04:57 --> Utf8 Class Initialized
INFO - 2020-10-12 15:04:57 --> URI Class Initialized
INFO - 2020-10-12 15:04:57 --> Router Class Initialized
INFO - 2020-10-12 15:04:57 --> Output Class Initialized
INFO - 2020-10-12 15:04:57 --> Security Class Initialized
DEBUG - 2020-10-12 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:04:57 --> Input Class Initialized
INFO - 2020-10-12 15:04:57 --> Language Class Initialized
INFO - 2020-10-12 15:04:57 --> Loader Class Initialized
INFO - 2020-10-12 15:04:57 --> Helper loaded: url_helper
INFO - 2020-10-12 15:04:57 --> Database Driver Class Initialized
INFO - 2020-10-12 15:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:04:57 --> Email Class Initialized
INFO - 2020-10-12 15:04:57 --> Controller Class Initialized
DEBUG - 2020-10-12 15:04:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:04:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:04:57 --> Model Class Initialized
INFO - 2020-10-12 15:04:57 --> Model Class Initialized
INFO - 2020-10-12 15:04:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:04:57 --> Final output sent to browser
DEBUG - 2020-10-12 15:04:57 --> Total execution time: 0.0238
ERROR - 2020-10-12 15:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:07:43 --> Config Class Initialized
INFO - 2020-10-12 15:07:43 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:07:43 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:07:43 --> Utf8 Class Initialized
INFO - 2020-10-12 15:07:43 --> URI Class Initialized
INFO - 2020-10-12 15:07:43 --> Router Class Initialized
INFO - 2020-10-12 15:07:43 --> Output Class Initialized
INFO - 2020-10-12 15:07:43 --> Security Class Initialized
DEBUG - 2020-10-12 15:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:07:43 --> Input Class Initialized
INFO - 2020-10-12 15:07:43 --> Language Class Initialized
INFO - 2020-10-12 15:07:43 --> Loader Class Initialized
INFO - 2020-10-12 15:07:43 --> Helper loaded: url_helper
INFO - 2020-10-12 15:07:43 --> Database Driver Class Initialized
INFO - 2020-10-12 15:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:07:43 --> Email Class Initialized
INFO - 2020-10-12 15:07:43 --> Controller Class Initialized
DEBUG - 2020-10-12 15:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:07:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:07:43 --> Model Class Initialized
INFO - 2020-10-12 15:07:43 --> Model Class Initialized
INFO - 2020-10-12 15:07:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:07:43 --> Final output sent to browser
DEBUG - 2020-10-12 15:07:43 --> Total execution time: 0.0239
ERROR - 2020-10-12 15:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:08:08 --> Config Class Initialized
INFO - 2020-10-12 15:08:08 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:08:08 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:08:08 --> Utf8 Class Initialized
INFO - 2020-10-12 15:08:08 --> URI Class Initialized
INFO - 2020-10-12 15:08:08 --> Router Class Initialized
INFO - 2020-10-12 15:08:08 --> Output Class Initialized
INFO - 2020-10-12 15:08:08 --> Security Class Initialized
DEBUG - 2020-10-12 15:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:08:08 --> Input Class Initialized
INFO - 2020-10-12 15:08:08 --> Language Class Initialized
INFO - 2020-10-12 15:08:08 --> Loader Class Initialized
INFO - 2020-10-12 15:08:08 --> Helper loaded: url_helper
INFO - 2020-10-12 15:08:08 --> Database Driver Class Initialized
INFO - 2020-10-12 15:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:08:08 --> Email Class Initialized
INFO - 2020-10-12 15:08:08 --> Controller Class Initialized
DEBUG - 2020-10-12 15:08:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-12 15:08:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:08:08 --> Model Class Initialized
INFO - 2020-10-12 15:08:08 --> Model Class Initialized
INFO - 2020-10-12 15:08:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-12 15:08:08 --> Final output sent to browser
DEBUG - 2020-10-12 15:08:08 --> Total execution time: 0.0257
ERROR - 2020-10-12 15:09:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-12 15:09:18 --> Config Class Initialized
INFO - 2020-10-12 15:09:18 --> Hooks Class Initialized
DEBUG - 2020-10-12 15:09:18 --> UTF-8 Support Enabled
INFO - 2020-10-12 15:09:18 --> Utf8 Class Initialized
INFO - 2020-10-12 15:09:18 --> URI Class Initialized
DEBUG - 2020-10-12 15:09:18 --> No URI present. Default controller set.
INFO - 2020-10-12 15:09:18 --> Router Class Initialized
INFO - 2020-10-12 15:09:18 --> Output Class Initialized
INFO - 2020-10-12 15:09:18 --> Security Class Initialized
DEBUG - 2020-10-12 15:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 15:09:18 --> Input Class Initialized
INFO - 2020-10-12 15:09:18 --> Language Class Initialized
INFO - 2020-10-12 15:09:18 --> Loader Class Initialized
INFO - 2020-10-12 15:09:18 --> Helper loaded: url_helper
INFO - 2020-10-12 15:09:18 --> Database Driver Class Initialized
INFO - 2020-10-12 15:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 15:09:18 --> Email Class Initialized
INFO - 2020-10-12 15:09:18 --> Controller Class Initialized
INFO - 2020-10-12 15:09:18 --> Model Class Initialized
INFO - 2020-10-12 15:09:18 --> Model Class Initialized
DEBUG - 2020-10-12 15:09:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-12 15:09:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-12 15:09:18 --> Final output sent to browser
DEBUG - 2020-10-12 15:09:18 --> Total execution time: 0.0200
