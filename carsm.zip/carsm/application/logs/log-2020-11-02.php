<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-02 09:35:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:25 --> Config Class Initialized
INFO - 2020-11-02 09:35:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:25 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:25 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:25 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:25 --> Router Class Initialized
INFO - 2020-11-02 09:35:25 --> Output Class Initialized
INFO - 2020-11-02 09:35:25 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:25 --> Input Class Initialized
INFO - 2020-11-02 09:35:25 --> Language Class Initialized
INFO - 2020-11-02 09:35:25 --> Loader Class Initialized
INFO - 2020-11-02 09:35:25 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:25 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:25 --> Email Class Initialized
INFO - 2020-11-02 09:35:25 --> Controller Class Initialized
INFO - 2020-11-02 09:35:25 --> Model Class Initialized
INFO - 2020-11-02 09:35:25 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:25 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:25 --> Total execution time: 0.1549
ERROR - 2020-11-02 09:35:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:28 --> Config Class Initialized
INFO - 2020-11-02 09:35:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:28 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:28 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:28 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:28 --> Router Class Initialized
INFO - 2020-11-02 09:35:28 --> Output Class Initialized
INFO - 2020-11-02 09:35:28 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:28 --> Input Class Initialized
INFO - 2020-11-02 09:35:28 --> Language Class Initialized
INFO - 2020-11-02 09:35:28 --> Loader Class Initialized
INFO - 2020-11-02 09:35:28 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:28 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:28 --> Email Class Initialized
INFO - 2020-11-02 09:35:28 --> Controller Class Initialized
INFO - 2020-11-02 09:35:28 --> Model Class Initialized
INFO - 2020-11-02 09:35:28 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:28 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:28 --> Total execution time: 0.0224
ERROR - 2020-11-02 09:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:30 --> Config Class Initialized
INFO - 2020-11-02 09:35:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:30 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:30 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:30 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:30 --> Router Class Initialized
INFO - 2020-11-02 09:35:30 --> Output Class Initialized
INFO - 2020-11-02 09:35:30 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:30 --> Input Class Initialized
INFO - 2020-11-02 09:35:30 --> Language Class Initialized
INFO - 2020-11-02 09:35:30 --> Loader Class Initialized
INFO - 2020-11-02 09:35:30 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:30 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:30 --> Email Class Initialized
INFO - 2020-11-02 09:35:30 --> Controller Class Initialized
INFO - 2020-11-02 09:35:30 --> Model Class Initialized
INFO - 2020-11-02 09:35:30 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:30 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:30 --> Total execution time: 0.0285
ERROR - 2020-11-02 09:35:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:30 --> Config Class Initialized
INFO - 2020-11-02 09:35:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:30 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:30 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:30 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:30 --> Router Class Initialized
INFO - 2020-11-02 09:35:30 --> Output Class Initialized
INFO - 2020-11-02 09:35:30 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:30 --> Input Class Initialized
INFO - 2020-11-02 09:35:30 --> Language Class Initialized
INFO - 2020-11-02 09:35:30 --> Loader Class Initialized
INFO - 2020-11-02 09:35:30 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:30 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:30 --> Email Class Initialized
INFO - 2020-11-02 09:35:30 --> Controller Class Initialized
INFO - 2020-11-02 09:35:30 --> Model Class Initialized
INFO - 2020-11-02 09:35:30 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:30 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:30 --> Total execution time: 0.0225
ERROR - 2020-11-02 09:35:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:32 --> Config Class Initialized
INFO - 2020-11-02 09:35:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:32 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:32 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:32 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:32 --> Router Class Initialized
INFO - 2020-11-02 09:35:32 --> Output Class Initialized
INFO - 2020-11-02 09:35:32 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:32 --> Input Class Initialized
INFO - 2020-11-02 09:35:32 --> Language Class Initialized
INFO - 2020-11-02 09:35:32 --> Loader Class Initialized
INFO - 2020-11-02 09:35:32 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:32 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:32 --> Email Class Initialized
INFO - 2020-11-02 09:35:32 --> Controller Class Initialized
INFO - 2020-11-02 09:35:32 --> Model Class Initialized
INFO - 2020-11-02 09:35:32 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:32 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:32 --> Total execution time: 0.0217
ERROR - 2020-11-02 09:35:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:33 --> Config Class Initialized
INFO - 2020-11-02 09:35:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:33 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:33 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:33 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:33 --> Router Class Initialized
INFO - 2020-11-02 09:35:33 --> Output Class Initialized
INFO - 2020-11-02 09:35:33 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:33 --> Input Class Initialized
INFO - 2020-11-02 09:35:33 --> Language Class Initialized
INFO - 2020-11-02 09:35:33 --> Loader Class Initialized
INFO - 2020-11-02 09:35:33 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:33 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:33 --> Email Class Initialized
INFO - 2020-11-02 09:35:33 --> Controller Class Initialized
INFO - 2020-11-02 09:35:33 --> Model Class Initialized
INFO - 2020-11-02 09:35:33 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:33 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:33 --> Total execution time: 0.0197
ERROR - 2020-11-02 09:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:40 --> Config Class Initialized
INFO - 2020-11-02 09:35:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:40 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:40 --> URI Class Initialized
INFO - 2020-11-02 09:35:40 --> Router Class Initialized
INFO - 2020-11-02 09:35:40 --> Output Class Initialized
INFO - 2020-11-02 09:35:40 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:40 --> Input Class Initialized
INFO - 2020-11-02 09:35:40 --> Language Class Initialized
INFO - 2020-11-02 09:35:40 --> Loader Class Initialized
INFO - 2020-11-02 09:35:40 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:40 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:40 --> Email Class Initialized
INFO - 2020-11-02 09:35:40 --> Controller Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:35:40 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-02 09:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:40 --> Config Class Initialized
INFO - 2020-11-02 09:35:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:40 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:40 --> URI Class Initialized
INFO - 2020-11-02 09:35:40 --> Router Class Initialized
INFO - 2020-11-02 09:35:40 --> Output Class Initialized
INFO - 2020-11-02 09:35:40 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:40 --> Input Class Initialized
INFO - 2020-11-02 09:35:40 --> Language Class Initialized
INFO - 2020-11-02 09:35:40 --> Loader Class Initialized
INFO - 2020-11-02 09:35:40 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:40 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:40 --> Email Class Initialized
INFO - 2020-11-02 09:35:40 --> Controller Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-02 09:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:40 --> Config Class Initialized
INFO - 2020-11-02 09:35:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:40 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:40 --> URI Class Initialized
DEBUG - 2020-11-02 09:35:40 --> No URI present. Default controller set.
INFO - 2020-11-02 09:35:40 --> Router Class Initialized
INFO - 2020-11-02 09:35:40 --> Output Class Initialized
INFO - 2020-11-02 09:35:40 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:40 --> Input Class Initialized
INFO - 2020-11-02 09:35:40 --> Language Class Initialized
INFO - 2020-11-02 09:35:40 --> Loader Class Initialized
INFO - 2020-11-02 09:35:40 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:40 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:40 --> Email Class Initialized
INFO - 2020-11-02 09:35:40 --> Controller Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:35:40 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:40 --> Total execution time: 0.0195
ERROR - 2020-11-02 09:35:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:40 --> Config Class Initialized
INFO - 2020-11-02 09:35:40 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:40 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:40 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:40 --> URI Class Initialized
INFO - 2020-11-02 09:35:40 --> Router Class Initialized
INFO - 2020-11-02 09:35:40 --> Output Class Initialized
INFO - 2020-11-02 09:35:40 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:40 --> Input Class Initialized
INFO - 2020-11-02 09:35:40 --> Language Class Initialized
INFO - 2020-11-02 09:35:40 --> Loader Class Initialized
INFO - 2020-11-02 09:35:40 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:40 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:40 --> Email Class Initialized
INFO - 2020-11-02 09:35:40 --> Controller Class Initialized
DEBUG - 2020-11-02 09:35:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:35:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
INFO - 2020-11-02 09:35:40 --> Model Class Initialized
INFO - 2020-11-02 09:35:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-11-02 09:35:40 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:40 --> Total execution time: 0.0797
ERROR - 2020-11-02 09:35:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:35:49 --> Config Class Initialized
INFO - 2020-11-02 09:35:49 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:35:49 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:35:49 --> Utf8 Class Initialized
INFO - 2020-11-02 09:35:49 --> URI Class Initialized
INFO - 2020-11-02 09:35:49 --> Router Class Initialized
INFO - 2020-11-02 09:35:49 --> Output Class Initialized
INFO - 2020-11-02 09:35:49 --> Security Class Initialized
DEBUG - 2020-11-02 09:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:35:49 --> Input Class Initialized
INFO - 2020-11-02 09:35:49 --> Language Class Initialized
INFO - 2020-11-02 09:35:49 --> Loader Class Initialized
INFO - 2020-11-02 09:35:49 --> Helper loaded: url_helper
INFO - 2020-11-02 09:35:49 --> Database Driver Class Initialized
INFO - 2020-11-02 09:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:35:49 --> Email Class Initialized
INFO - 2020-11-02 09:35:49 --> Controller Class Initialized
DEBUG - 2020-11-02 09:35:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:35:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:35:49 --> Model Class Initialized
INFO - 2020-11-02 09:35:49 --> Model Class Initialized
INFO - 2020-11-02 09:35:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-11-02 09:35:49 --> Final output sent to browser
DEBUG - 2020-11-02 09:35:49 --> Total execution time: 0.0362
ERROR - 2020-11-02 09:36:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:36:07 --> Config Class Initialized
INFO - 2020-11-02 09:36:07 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:36:07 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:36:07 --> Utf8 Class Initialized
INFO - 2020-11-02 09:36:07 --> URI Class Initialized
INFO - 2020-11-02 09:36:07 --> Router Class Initialized
INFO - 2020-11-02 09:36:07 --> Output Class Initialized
INFO - 2020-11-02 09:36:07 --> Security Class Initialized
DEBUG - 2020-11-02 09:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:36:07 --> Input Class Initialized
INFO - 2020-11-02 09:36:07 --> Language Class Initialized
INFO - 2020-11-02 09:36:07 --> Loader Class Initialized
INFO - 2020-11-02 09:36:07 --> Helper loaded: url_helper
INFO - 2020-11-02 09:36:07 --> Database Driver Class Initialized
INFO - 2020-11-02 09:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:36:07 --> Email Class Initialized
INFO - 2020-11-02 09:36:07 --> Controller Class Initialized
DEBUG - 2020-11-02 09:36:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:36:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:36:07 --> Model Class Initialized
INFO - 2020-11-02 09:36:07 --> Model Class Initialized
INFO - 2020-11-02 09:36:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-11-02 09:36:07 --> Final output sent to browser
DEBUG - 2020-11-02 09:36:07 --> Total execution time: 0.0323
ERROR - 2020-11-02 09:36:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:36:47 --> Config Class Initialized
INFO - 2020-11-02 09:36:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:36:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:36:47 --> Utf8 Class Initialized
INFO - 2020-11-02 09:36:47 --> URI Class Initialized
DEBUG - 2020-11-02 09:36:47 --> No URI present. Default controller set.
INFO - 2020-11-02 09:36:47 --> Router Class Initialized
INFO - 2020-11-02 09:36:47 --> Output Class Initialized
INFO - 2020-11-02 09:36:47 --> Security Class Initialized
DEBUG - 2020-11-02 09:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:36:47 --> Input Class Initialized
INFO - 2020-11-02 09:36:47 --> Language Class Initialized
INFO - 2020-11-02 09:36:47 --> Loader Class Initialized
INFO - 2020-11-02 09:36:47 --> Helper loaded: url_helper
INFO - 2020-11-02 09:36:47 --> Database Driver Class Initialized
INFO - 2020-11-02 09:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:36:47 --> Email Class Initialized
INFO - 2020-11-02 09:36:47 --> Controller Class Initialized
INFO - 2020-11-02 09:36:47 --> Model Class Initialized
INFO - 2020-11-02 09:36:47 --> Model Class Initialized
DEBUG - 2020-11-02 09:36:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:36:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-02 09:36:47 --> Final output sent to browser
DEBUG - 2020-11-02 09:36:47 --> Total execution time: 0.0207
ERROR - 2020-11-02 09:37:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:00 --> Config Class Initialized
INFO - 2020-11-02 09:37:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:00 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:00 --> URI Class Initialized
INFO - 2020-11-02 09:37:00 --> Router Class Initialized
INFO - 2020-11-02 09:37:00 --> Output Class Initialized
INFO - 2020-11-02 09:37:00 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:00 --> Input Class Initialized
INFO - 2020-11-02 09:37:00 --> Language Class Initialized
INFO - 2020-11-02 09:37:00 --> Loader Class Initialized
INFO - 2020-11-02 09:37:00 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:00 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:00 --> Email Class Initialized
INFO - 2020-11-02 09:37:00 --> Controller Class Initialized
INFO - 2020-11-02 09:37:00 --> Model Class Initialized
INFO - 2020-11-02 09:37:00 --> Model Class Initialized
DEBUG - 2020-11-02 09:37:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:00 --> Model Class Initialized
INFO - 2020-11-02 09:37:00 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:00 --> Total execution time: 0.0233
ERROR - 2020-11-02 09:37:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:01 --> Config Class Initialized
INFO - 2020-11-02 09:37:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:01 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:01 --> URI Class Initialized
INFO - 2020-11-02 09:37:01 --> Router Class Initialized
INFO - 2020-11-02 09:37:01 --> Output Class Initialized
INFO - 2020-11-02 09:37:01 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:01 --> Input Class Initialized
INFO - 2020-11-02 09:37:01 --> Language Class Initialized
INFO - 2020-11-02 09:37:01 --> Loader Class Initialized
INFO - 2020-11-02 09:37:01 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:01 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:01 --> Email Class Initialized
INFO - 2020-11-02 09:37:01 --> Controller Class Initialized
INFO - 2020-11-02 09:37:01 --> Model Class Initialized
INFO - 2020-11-02 09:37:01 --> Model Class Initialized
DEBUG - 2020-11-02 09:37:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-02 09:37:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:01 --> Config Class Initialized
INFO - 2020-11-02 09:37:01 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:01 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:01 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:01 --> URI Class Initialized
INFO - 2020-11-02 09:37:01 --> Router Class Initialized
INFO - 2020-11-02 09:37:01 --> Output Class Initialized
INFO - 2020-11-02 09:37:01 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:01 --> Input Class Initialized
INFO - 2020-11-02 09:37:01 --> Language Class Initialized
INFO - 2020-11-02 09:37:01 --> Loader Class Initialized
INFO - 2020-11-02 09:37:01 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:01 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:01 --> Email Class Initialized
INFO - 2020-11-02 09:37:01 --> Controller Class Initialized
DEBUG - 2020-11-02 09:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:01 --> Model Class Initialized
INFO - 2020-11-02 09:37:01 --> Model Class Initialized
INFO - 2020-11-02 09:37:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-02 09:37:01 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:01 --> Total execution time: 0.0773
ERROR - 2020-11-02 09:37:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:13 --> Config Class Initialized
INFO - 2020-11-02 09:37:13 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:13 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:13 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:13 --> URI Class Initialized
INFO - 2020-11-02 09:37:13 --> Router Class Initialized
INFO - 2020-11-02 09:37:13 --> Output Class Initialized
INFO - 2020-11-02 09:37:13 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:13 --> Input Class Initialized
INFO - 2020-11-02 09:37:13 --> Language Class Initialized
INFO - 2020-11-02 09:37:13 --> Loader Class Initialized
INFO - 2020-11-02 09:37:13 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:13 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:13 --> Email Class Initialized
INFO - 2020-11-02 09:37:13 --> Controller Class Initialized
DEBUG - 2020-11-02 09:37:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:13 --> Model Class Initialized
INFO - 2020-11-02 09:37:13 --> Model Class Initialized
INFO - 2020-11-02 09:37:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-02 09:37:13 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:13 --> Total execution time: 0.0360
ERROR - 2020-11-02 09:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:25 --> Config Class Initialized
INFO - 2020-11-02 09:37:25 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:25 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:25 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:25 --> URI Class Initialized
INFO - 2020-11-02 09:37:25 --> Router Class Initialized
INFO - 2020-11-02 09:37:25 --> Output Class Initialized
INFO - 2020-11-02 09:37:25 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:25 --> Input Class Initialized
INFO - 2020-11-02 09:37:25 --> Language Class Initialized
INFO - 2020-11-02 09:37:25 --> Loader Class Initialized
INFO - 2020-11-02 09:37:25 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:25 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:25 --> Email Class Initialized
INFO - 2020-11-02 09:37:25 --> Controller Class Initialized
DEBUG - 2020-11-02 09:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:25 --> Model Class Initialized
INFO - 2020-11-02 09:37:25 --> Model Class Initialized
INFO - 2020-11-02 09:37:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-02 09:37:25 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:25 --> Total execution time: 0.0747
ERROR - 2020-11-02 09:37:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:33 --> Config Class Initialized
INFO - 2020-11-02 09:37:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:33 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:33 --> URI Class Initialized
INFO - 2020-11-02 09:37:33 --> Router Class Initialized
INFO - 2020-11-02 09:37:33 --> Output Class Initialized
INFO - 2020-11-02 09:37:33 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:33 --> Input Class Initialized
INFO - 2020-11-02 09:37:33 --> Language Class Initialized
INFO - 2020-11-02 09:37:33 --> Loader Class Initialized
INFO - 2020-11-02 09:37:33 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:33 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:33 --> Email Class Initialized
INFO - 2020-11-02 09:37:33 --> Controller Class Initialized
DEBUG - 2020-11-02 09:37:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:33 --> Model Class Initialized
INFO - 2020-11-02 09:37:33 --> Model Class Initialized
INFO - 2020-11-02 09:37:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-02 09:37:33 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:33 --> Total execution time: 0.0252
ERROR - 2020-11-02 09:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:47 --> Config Class Initialized
INFO - 2020-11-02 09:37:47 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:47 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:47 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:47 --> URI Class Initialized
INFO - 2020-11-02 09:37:47 --> Router Class Initialized
INFO - 2020-11-02 09:37:47 --> Output Class Initialized
INFO - 2020-11-02 09:37:47 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:47 --> Input Class Initialized
INFO - 2020-11-02 09:37:47 --> Language Class Initialized
INFO - 2020-11-02 09:37:47 --> Loader Class Initialized
INFO - 2020-11-02 09:37:47 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:47 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:47 --> Email Class Initialized
INFO - 2020-11-02 09:37:47 --> Controller Class Initialized
DEBUG - 2020-11-02 09:37:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:47 --> Model Class Initialized
INFO - 2020-11-02 09:37:47 --> Model Class Initialized
INFO - 2020-11-02 09:37:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-02 09:37:47 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:47 --> Total execution time: 0.0821
ERROR - 2020-11-02 09:37:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:37:50 --> Config Class Initialized
INFO - 2020-11-02 09:37:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:37:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:37:50 --> Utf8 Class Initialized
INFO - 2020-11-02 09:37:50 --> URI Class Initialized
INFO - 2020-11-02 09:37:50 --> Router Class Initialized
INFO - 2020-11-02 09:37:50 --> Output Class Initialized
INFO - 2020-11-02 09:37:50 --> Security Class Initialized
DEBUG - 2020-11-02 09:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:37:50 --> Input Class Initialized
INFO - 2020-11-02 09:37:50 --> Language Class Initialized
INFO - 2020-11-02 09:37:50 --> Loader Class Initialized
INFO - 2020-11-02 09:37:50 --> Helper loaded: url_helper
INFO - 2020-11-02 09:37:50 --> Database Driver Class Initialized
INFO - 2020-11-02 09:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:37:50 --> Email Class Initialized
INFO - 2020-11-02 09:37:50 --> Controller Class Initialized
DEBUG - 2020-11-02 09:37:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:37:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:37:50 --> Model Class Initialized
INFO - 2020-11-02 09:37:50 --> Model Class Initialized
INFO - 2020-11-02 09:37:50 --> Model Class Initialized
INFO - 2020-11-02 09:37:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-02 09:37:50 --> Final output sent to browser
DEBUG - 2020-11-02 09:37:50 --> Total execution time: 0.0433
ERROR - 2020-11-02 09:40:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:40:28 --> Config Class Initialized
INFO - 2020-11-02 09:40:28 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:40:28 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:40:28 --> Utf8 Class Initialized
INFO - 2020-11-02 09:40:28 --> URI Class Initialized
INFO - 2020-11-02 09:40:28 --> Router Class Initialized
INFO - 2020-11-02 09:40:28 --> Output Class Initialized
INFO - 2020-11-02 09:40:28 --> Security Class Initialized
DEBUG - 2020-11-02 09:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:40:28 --> Input Class Initialized
INFO - 2020-11-02 09:40:28 --> Language Class Initialized
INFO - 2020-11-02 09:40:28 --> Loader Class Initialized
INFO - 2020-11-02 09:40:28 --> Helper loaded: url_helper
INFO - 2020-11-02 09:40:28 --> Database Driver Class Initialized
INFO - 2020-11-02 09:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:40:28 --> Email Class Initialized
INFO - 2020-11-02 09:40:28 --> Controller Class Initialized
DEBUG - 2020-11-02 09:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:40:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:40:28 --> Model Class Initialized
INFO - 2020-11-02 09:40:28 --> Model Class Initialized
INFO - 2020-11-02 09:40:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-02 09:40:28 --> Final output sent to browser
DEBUG - 2020-11-02 09:40:28 --> Total execution time: 0.1588
ERROR - 2020-11-02 09:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:40:34 --> Config Class Initialized
INFO - 2020-11-02 09:40:34 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:40:34 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:40:34 --> Utf8 Class Initialized
INFO - 2020-11-02 09:40:34 --> URI Class Initialized
INFO - 2020-11-02 09:40:34 --> Router Class Initialized
INFO - 2020-11-02 09:40:34 --> Output Class Initialized
INFO - 2020-11-02 09:40:34 --> Security Class Initialized
DEBUG - 2020-11-02 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:40:34 --> Input Class Initialized
INFO - 2020-11-02 09:40:34 --> Language Class Initialized
INFO - 2020-11-02 09:40:34 --> Loader Class Initialized
INFO - 2020-11-02 09:40:34 --> Helper loaded: url_helper
INFO - 2020-11-02 09:40:34 --> Database Driver Class Initialized
INFO - 2020-11-02 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:40:34 --> Email Class Initialized
INFO - 2020-11-02 09:40:34 --> Controller Class Initialized
DEBUG - 2020-11-02 09:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:40:34 --> Model Class Initialized
INFO - 2020-11-02 09:40:34 --> Model Class Initialized
INFO - 2020-11-02 09:40:34 --> Model Class Initialized
INFO - 2020-11-02 09:40:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-02 09:40:34 --> Final output sent to browser
DEBUG - 2020-11-02 09:40:34 --> Total execution time: 0.0510
ERROR - 2020-11-02 09:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:40:54 --> Config Class Initialized
INFO - 2020-11-02 09:40:54 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:40:54 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:40:54 --> Utf8 Class Initialized
INFO - 2020-11-02 09:40:54 --> URI Class Initialized
INFO - 2020-11-02 09:40:54 --> Router Class Initialized
INFO - 2020-11-02 09:40:54 --> Output Class Initialized
INFO - 2020-11-02 09:40:54 --> Security Class Initialized
DEBUG - 2020-11-02 09:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:40:54 --> Input Class Initialized
INFO - 2020-11-02 09:40:54 --> Language Class Initialized
INFO - 2020-11-02 09:40:54 --> Loader Class Initialized
INFO - 2020-11-02 09:40:54 --> Helper loaded: url_helper
INFO - 2020-11-02 09:40:54 --> Database Driver Class Initialized
INFO - 2020-11-02 09:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:40:54 --> Email Class Initialized
INFO - 2020-11-02 09:40:54 --> Controller Class Initialized
INFO - 2020-11-02 09:40:54 --> Model Class Initialized
INFO - 2020-11-02 09:40:54 --> Model Class Initialized
INFO - 2020-11-02 09:40:54 --> Model Class Initialized
INFO - 2020-11-02 09:40:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-11-02 09:40:54 --> Final output sent to browser
DEBUG - 2020-11-02 09:40:54 --> Total execution time: 0.2013
ERROR - 2020-11-02 09:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:40:55 --> Config Class Initialized
INFO - 2020-11-02 09:40:55 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:40:55 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:40:55 --> Utf8 Class Initialized
INFO - 2020-11-02 09:40:55 --> URI Class Initialized
INFO - 2020-11-02 09:40:55 --> Router Class Initialized
INFO - 2020-11-02 09:40:55 --> Output Class Initialized
INFO - 2020-11-02 09:40:55 --> Security Class Initialized
DEBUG - 2020-11-02 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:40:55 --> Input Class Initialized
INFO - 2020-11-02 09:40:55 --> Language Class Initialized
INFO - 2020-11-02 09:40:55 --> Loader Class Initialized
INFO - 2020-11-02 09:40:55 --> Helper loaded: url_helper
INFO - 2020-11-02 09:40:55 --> Database Driver Class Initialized
INFO - 2020-11-02 09:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:40:55 --> Email Class Initialized
INFO - 2020-11-02 09:40:55 --> Controller Class Initialized
INFO - 2020-11-02 09:40:55 --> Model Class Initialized
INFO - 2020-11-02 09:40:55 --> Model Class Initialized
INFO - 2020-11-02 09:40:55 --> Final output sent to browser
DEBUG - 2020-11-02 09:40:55 --> Total execution time: 0.0488
ERROR - 2020-11-02 09:41:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:41:00 --> Config Class Initialized
INFO - 2020-11-02 09:41:00 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:41:00 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:41:00 --> Utf8 Class Initialized
INFO - 2020-11-02 09:41:00 --> URI Class Initialized
INFO - 2020-11-02 09:41:00 --> Router Class Initialized
INFO - 2020-11-02 09:41:00 --> Output Class Initialized
INFO - 2020-11-02 09:41:00 --> Security Class Initialized
DEBUG - 2020-11-02 09:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:41:00 --> Input Class Initialized
INFO - 2020-11-02 09:41:00 --> Language Class Initialized
INFO - 2020-11-02 09:41:00 --> Loader Class Initialized
INFO - 2020-11-02 09:41:00 --> Helper loaded: url_helper
INFO - 2020-11-02 09:41:00 --> Database Driver Class Initialized
INFO - 2020-11-02 09:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:41:00 --> Email Class Initialized
INFO - 2020-11-02 09:41:00 --> Controller Class Initialized
DEBUG - 2020-11-02 09:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:41:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:41:00 --> Model Class Initialized
INFO - 2020-11-02 09:41:00 --> Model Class Initialized
INFO - 2020-11-02 09:41:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-02 09:41:00 --> Final output sent to browser
DEBUG - 2020-11-02 09:41:00 --> Total execution time: 0.0628
ERROR - 2020-11-02 09:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:41:03 --> Config Class Initialized
INFO - 2020-11-02 09:41:03 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:41:03 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:41:03 --> Utf8 Class Initialized
INFO - 2020-11-02 09:41:03 --> URI Class Initialized
INFO - 2020-11-02 09:41:03 --> Router Class Initialized
INFO - 2020-11-02 09:41:03 --> Output Class Initialized
INFO - 2020-11-02 09:41:03 --> Security Class Initialized
DEBUG - 2020-11-02 09:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:41:03 --> Input Class Initialized
INFO - 2020-11-02 09:41:03 --> Language Class Initialized
INFO - 2020-11-02 09:41:03 --> Loader Class Initialized
INFO - 2020-11-02 09:41:03 --> Helper loaded: url_helper
INFO - 2020-11-02 09:41:03 --> Database Driver Class Initialized
INFO - 2020-11-02 09:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:41:03 --> Email Class Initialized
INFO - 2020-11-02 09:41:03 --> Controller Class Initialized
DEBUG - 2020-11-02 09:41:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:41:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:41:03 --> Model Class Initialized
INFO - 2020-11-02 09:41:03 --> Model Class Initialized
INFO - 2020-11-02 09:41:03 --> Model Class Initialized
INFO - 2020-11-02 09:41:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-11-02 09:41:03 --> Final output sent to browser
DEBUG - 2020-11-02 09:41:03 --> Total execution time: 0.0634
ERROR - 2020-11-02 09:44:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:44:16 --> Config Class Initialized
INFO - 2020-11-02 09:44:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:44:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:44:16 --> Utf8 Class Initialized
INFO - 2020-11-02 09:44:16 --> URI Class Initialized
INFO - 2020-11-02 09:44:16 --> Router Class Initialized
INFO - 2020-11-02 09:44:16 --> Output Class Initialized
INFO - 2020-11-02 09:44:16 --> Security Class Initialized
DEBUG - 2020-11-02 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:44:16 --> Input Class Initialized
INFO - 2020-11-02 09:44:16 --> Language Class Initialized
INFO - 2020-11-02 09:44:16 --> Loader Class Initialized
INFO - 2020-11-02 09:44:16 --> Helper loaded: url_helper
INFO - 2020-11-02 09:44:16 --> Database Driver Class Initialized
INFO - 2020-11-02 09:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:44:16 --> Email Class Initialized
INFO - 2020-11-02 09:44:16 --> Controller Class Initialized
DEBUG - 2020-11-02 09:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:44:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:44:16 --> Model Class Initialized
INFO - 2020-11-02 09:44:16 --> Model Class Initialized
INFO - 2020-11-02 09:44:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-02 09:44:16 --> Final output sent to browser
DEBUG - 2020-11-02 09:44:16 --> Total execution time: 0.0383
ERROR - 2020-11-02 09:44:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:44:19 --> Config Class Initialized
INFO - 2020-11-02 09:44:19 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:44:19 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:44:19 --> Utf8 Class Initialized
INFO - 2020-11-02 09:44:19 --> URI Class Initialized
INFO - 2020-11-02 09:44:19 --> Router Class Initialized
INFO - 2020-11-02 09:44:19 --> Output Class Initialized
INFO - 2020-11-02 09:44:19 --> Security Class Initialized
DEBUG - 2020-11-02 09:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:44:19 --> Input Class Initialized
INFO - 2020-11-02 09:44:19 --> Language Class Initialized
INFO - 2020-11-02 09:44:19 --> Loader Class Initialized
INFO - 2020-11-02 09:44:19 --> Helper loaded: url_helper
INFO - 2020-11-02 09:44:19 --> Database Driver Class Initialized
INFO - 2020-11-02 09:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:44:19 --> Email Class Initialized
INFO - 2020-11-02 09:44:19 --> Controller Class Initialized
DEBUG - 2020-11-02 09:44:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:44:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:44:19 --> Model Class Initialized
INFO - 2020-11-02 09:44:19 --> Model Class Initialized
INFO - 2020-11-02 09:44:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-11-02 09:44:19 --> Final output sent to browser
DEBUG - 2020-11-02 09:44:19 --> Total execution time: 0.0452
ERROR - 2020-11-02 09:44:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:44:20 --> Config Class Initialized
INFO - 2020-11-02 09:44:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:44:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:44:20 --> Utf8 Class Initialized
INFO - 2020-11-02 09:44:20 --> URI Class Initialized
INFO - 2020-11-02 09:44:20 --> Router Class Initialized
INFO - 2020-11-02 09:44:20 --> Output Class Initialized
INFO - 2020-11-02 09:44:20 --> Security Class Initialized
DEBUG - 2020-11-02 09:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:44:20 --> Input Class Initialized
INFO - 2020-11-02 09:44:20 --> Language Class Initialized
ERROR - 2020-11-02 09:44:20 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-11-02 09:47:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:47:14 --> Config Class Initialized
INFO - 2020-11-02 09:47:14 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:47:14 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:47:14 --> Utf8 Class Initialized
INFO - 2020-11-02 09:47:14 --> URI Class Initialized
INFO - 2020-11-02 09:47:14 --> Router Class Initialized
INFO - 2020-11-02 09:47:14 --> Output Class Initialized
INFO - 2020-11-02 09:47:14 --> Security Class Initialized
DEBUG - 2020-11-02 09:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:47:14 --> Input Class Initialized
INFO - 2020-11-02 09:47:14 --> Language Class Initialized
INFO - 2020-11-02 09:47:14 --> Loader Class Initialized
INFO - 2020-11-02 09:47:14 --> Helper loaded: url_helper
INFO - 2020-11-02 09:47:14 --> Database Driver Class Initialized
INFO - 2020-11-02 09:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:47:14 --> Email Class Initialized
INFO - 2020-11-02 09:47:14 --> Controller Class Initialized
DEBUG - 2020-11-02 09:47:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:47:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:47:14 --> Model Class Initialized
INFO - 2020-11-02 09:47:14 --> Model Class Initialized
INFO - 2020-11-02 09:47:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-02 09:47:14 --> Final output sent to browser
DEBUG - 2020-11-02 09:47:14 --> Total execution time: 0.0879
ERROR - 2020-11-02 09:47:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:47:16 --> Config Class Initialized
INFO - 2020-11-02 09:47:16 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:47:16 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:47:16 --> Utf8 Class Initialized
INFO - 2020-11-02 09:47:16 --> URI Class Initialized
INFO - 2020-11-02 09:47:16 --> Router Class Initialized
INFO - 2020-11-02 09:47:16 --> Output Class Initialized
INFO - 2020-11-02 09:47:16 --> Security Class Initialized
DEBUG - 2020-11-02 09:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:47:16 --> Input Class Initialized
INFO - 2020-11-02 09:47:16 --> Language Class Initialized
INFO - 2020-11-02 09:47:16 --> Loader Class Initialized
INFO - 2020-11-02 09:47:16 --> Helper loaded: url_helper
INFO - 2020-11-02 09:47:16 --> Database Driver Class Initialized
INFO - 2020-11-02 09:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:47:16 --> Email Class Initialized
INFO - 2020-11-02 09:47:16 --> Controller Class Initialized
DEBUG - 2020-11-02 09:47:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:47:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:47:16 --> Model Class Initialized
INFO - 2020-11-02 09:47:16 --> Model Class Initialized
INFO - 2020-11-02 09:47:16 --> Model Class Initialized
INFO - 2020-11-02 09:47:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-02 09:47:16 --> Final output sent to browser
DEBUG - 2020-11-02 09:47:16 --> Total execution time: 0.0448
ERROR - 2020-11-02 09:47:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:47:20 --> Config Class Initialized
INFO - 2020-11-02 09:47:20 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:47:20 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:47:20 --> Utf8 Class Initialized
INFO - 2020-11-02 09:47:20 --> URI Class Initialized
INFO - 2020-11-02 09:47:20 --> Router Class Initialized
INFO - 2020-11-02 09:47:20 --> Output Class Initialized
INFO - 2020-11-02 09:47:20 --> Security Class Initialized
DEBUG - 2020-11-02 09:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:47:20 --> Input Class Initialized
INFO - 2020-11-02 09:47:20 --> Language Class Initialized
INFO - 2020-11-02 09:47:20 --> Loader Class Initialized
INFO - 2020-11-02 09:47:20 --> Helper loaded: url_helper
INFO - 2020-11-02 09:47:20 --> Database Driver Class Initialized
INFO - 2020-11-02 09:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:47:20 --> Email Class Initialized
INFO - 2020-11-02 09:47:20 --> Controller Class Initialized
DEBUG - 2020-11-02 09:47:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:47:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:47:20 --> Model Class Initialized
INFO - 2020-11-02 09:47:20 --> Model Class Initialized
INFO - 2020-11-02 09:47:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-02 09:47:20 --> Final output sent to browser
DEBUG - 2020-11-02 09:47:20 --> Total execution time: 0.0373
ERROR - 2020-11-02 09:56:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:56:31 --> Config Class Initialized
INFO - 2020-11-02 09:56:31 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:56:31 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:56:31 --> Utf8 Class Initialized
INFO - 2020-11-02 09:56:31 --> URI Class Initialized
INFO - 2020-11-02 09:56:31 --> Router Class Initialized
INFO - 2020-11-02 09:56:31 --> Output Class Initialized
INFO - 2020-11-02 09:56:31 --> Security Class Initialized
DEBUG - 2020-11-02 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:56:31 --> Input Class Initialized
INFO - 2020-11-02 09:56:31 --> Language Class Initialized
INFO - 2020-11-02 09:56:31 --> Loader Class Initialized
INFO - 2020-11-02 09:56:31 --> Helper loaded: url_helper
INFO - 2020-11-02 09:56:31 --> Database Driver Class Initialized
INFO - 2020-11-02 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:56:31 --> Email Class Initialized
INFO - 2020-11-02 09:56:31 --> Controller Class Initialized
DEBUG - 2020-11-02 09:56:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:56:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:56:31 --> Model Class Initialized
INFO - 2020-11-02 09:56:31 --> Model Class Initialized
INFO - 2020-11-02 09:56:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-11-02 09:56:31 --> Final output sent to browser
DEBUG - 2020-11-02 09:56:31 --> Total execution time: 0.0718
ERROR - 2020-11-02 09:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:56:32 --> Config Class Initialized
INFO - 2020-11-02 09:56:32 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:56:32 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:56:32 --> Utf8 Class Initialized
INFO - 2020-11-02 09:56:32 --> URI Class Initialized
INFO - 2020-11-02 09:56:32 --> Router Class Initialized
INFO - 2020-11-02 09:56:32 --> Output Class Initialized
INFO - 2020-11-02 09:56:32 --> Security Class Initialized
DEBUG - 2020-11-02 09:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:56:32 --> Input Class Initialized
INFO - 2020-11-02 09:56:32 --> Language Class Initialized
ERROR - 2020-11-02 09:56:32 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-11-02 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:56:34 --> Config Class Initialized
INFO - 2020-11-02 09:56:34 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:56:34 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:56:34 --> Utf8 Class Initialized
INFO - 2020-11-02 09:56:34 --> URI Class Initialized
INFO - 2020-11-02 09:56:34 --> Router Class Initialized
INFO - 2020-11-02 09:56:34 --> Output Class Initialized
INFO - 2020-11-02 09:56:34 --> Security Class Initialized
DEBUG - 2020-11-02 09:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:56:34 --> Input Class Initialized
INFO - 2020-11-02 09:56:34 --> Language Class Initialized
INFO - 2020-11-02 09:56:34 --> Loader Class Initialized
INFO - 2020-11-02 09:56:34 --> Helper loaded: url_helper
INFO - 2020-11-02 09:56:34 --> Database Driver Class Initialized
INFO - 2020-11-02 09:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:56:34 --> Email Class Initialized
INFO - 2020-11-02 09:56:34 --> Controller Class Initialized
DEBUG - 2020-11-02 09:56:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:56:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:56:34 --> Model Class Initialized
INFO - 2020-11-02 09:56:34 --> Model Class Initialized
INFO - 2020-11-02 09:56:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-02 09:56:35 --> Final output sent to browser
DEBUG - 2020-11-02 09:56:35 --> Total execution time: 0.0421
ERROR - 2020-11-02 09:56:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:56:57 --> Config Class Initialized
INFO - 2020-11-02 09:56:57 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:56:57 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:56:57 --> Utf8 Class Initialized
INFO - 2020-11-02 09:56:57 --> URI Class Initialized
INFO - 2020-11-02 09:56:57 --> Router Class Initialized
INFO - 2020-11-02 09:56:57 --> Output Class Initialized
INFO - 2020-11-02 09:56:57 --> Security Class Initialized
DEBUG - 2020-11-02 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:56:57 --> Input Class Initialized
INFO - 2020-11-02 09:56:57 --> Language Class Initialized
INFO - 2020-11-02 09:56:57 --> Loader Class Initialized
INFO - 2020-11-02 09:56:57 --> Helper loaded: url_helper
INFO - 2020-11-02 09:56:57 --> Database Driver Class Initialized
INFO - 2020-11-02 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:56:57 --> Email Class Initialized
INFO - 2020-11-02 09:56:57 --> Controller Class Initialized
DEBUG - 2020-11-02 09:56:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:56:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:56:57 --> Model Class Initialized
INFO - 2020-11-02 09:56:57 --> Model Class Initialized
INFO - 2020-11-02 09:56:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-02 09:56:57 --> Final output sent to browser
DEBUG - 2020-11-02 09:56:57 --> Total execution time: 0.0368
ERROR - 2020-11-02 09:58:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:58:10 --> Config Class Initialized
INFO - 2020-11-02 09:58:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:58:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:58:10 --> Utf8 Class Initialized
INFO - 2020-11-02 09:58:10 --> URI Class Initialized
INFO - 2020-11-02 09:58:10 --> Router Class Initialized
INFO - 2020-11-02 09:58:10 --> Output Class Initialized
INFO - 2020-11-02 09:58:10 --> Security Class Initialized
DEBUG - 2020-11-02 09:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:58:10 --> Input Class Initialized
INFO - 2020-11-02 09:58:10 --> Language Class Initialized
INFO - 2020-11-02 09:58:10 --> Loader Class Initialized
INFO - 2020-11-02 09:58:10 --> Helper loaded: url_helper
INFO - 2020-11-02 09:58:10 --> Database Driver Class Initialized
INFO - 2020-11-02 09:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:58:10 --> Email Class Initialized
INFO - 2020-11-02 09:58:10 --> Controller Class Initialized
INFO - 2020-11-02 09:58:10 --> Model Class Initialized
INFO - 2020-11-02 09:58:10 --> Model Class Initialized
INFO - 2020-11-02 09:58:10 --> Model Class Initialized
INFO - 2020-11-02 09:58:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-11-02 09:58:10 --> Final output sent to browser
DEBUG - 2020-11-02 09:58:10 --> Total execution time: 0.2767
ERROR - 2020-11-02 09:58:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:58:11 --> Config Class Initialized
INFO - 2020-11-02 09:58:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:58:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:58:11 --> Utf8 Class Initialized
INFO - 2020-11-02 09:58:11 --> URI Class Initialized
INFO - 2020-11-02 09:58:11 --> Router Class Initialized
INFO - 2020-11-02 09:58:11 --> Output Class Initialized
INFO - 2020-11-02 09:58:11 --> Security Class Initialized
DEBUG - 2020-11-02 09:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:58:11 --> Input Class Initialized
INFO - 2020-11-02 09:58:11 --> Language Class Initialized
INFO - 2020-11-02 09:58:11 --> Loader Class Initialized
INFO - 2020-11-02 09:58:11 --> Helper loaded: url_helper
INFO - 2020-11-02 09:58:11 --> Database Driver Class Initialized
INFO - 2020-11-02 09:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:58:11 --> Email Class Initialized
INFO - 2020-11-02 09:58:11 --> Controller Class Initialized
INFO - 2020-11-02 09:58:11 --> Model Class Initialized
INFO - 2020-11-02 09:58:11 --> Model Class Initialized
INFO - 2020-11-02 09:58:11 --> Final output sent to browser
DEBUG - 2020-11-02 09:58:11 --> Total execution time: 0.0438
ERROR - 2020-11-02 09:58:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-02 09:58:21 --> Config Class Initialized
INFO - 2020-11-02 09:58:21 --> Hooks Class Initialized
DEBUG - 2020-11-02 09:58:21 --> UTF-8 Support Enabled
INFO - 2020-11-02 09:58:21 --> Utf8 Class Initialized
INFO - 2020-11-02 09:58:21 --> URI Class Initialized
INFO - 2020-11-02 09:58:21 --> Router Class Initialized
INFO - 2020-11-02 09:58:21 --> Output Class Initialized
INFO - 2020-11-02 09:58:21 --> Security Class Initialized
DEBUG - 2020-11-02 09:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 09:58:21 --> Input Class Initialized
INFO - 2020-11-02 09:58:21 --> Language Class Initialized
INFO - 2020-11-02 09:58:21 --> Loader Class Initialized
INFO - 2020-11-02 09:58:21 --> Helper loaded: url_helper
INFO - 2020-11-02 09:58:21 --> Database Driver Class Initialized
INFO - 2020-11-02 09:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 09:58:21 --> Email Class Initialized
INFO - 2020-11-02 09:58:21 --> Controller Class Initialized
DEBUG - 2020-11-02 09:58:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-02 09:58:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-02 09:58:21 --> Model Class Initialized
INFO - 2020-11-02 09:58:21 --> Model Class Initialized
INFO - 2020-11-02 09:58:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-02 09:58:21 --> Final output sent to browser
DEBUG - 2020-11-02 09:58:21 --> Total execution time: 0.0203
