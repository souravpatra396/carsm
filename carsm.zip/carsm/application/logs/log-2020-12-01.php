<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-01 08:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-01 08:06:43 --> Config Class Initialized
INFO - 2020-12-01 08:06:43 --> Hooks Class Initialized
DEBUG - 2020-12-01 08:06:43 --> UTF-8 Support Enabled
INFO - 2020-12-01 08:06:43 --> Utf8 Class Initialized
INFO - 2020-12-01 08:06:43 --> URI Class Initialized
DEBUG - 2020-12-01 08:06:43 --> No URI present. Default controller set.
INFO - 2020-12-01 08:06:43 --> Router Class Initialized
INFO - 2020-12-01 08:06:43 --> Output Class Initialized
INFO - 2020-12-01 08:06:43 --> Security Class Initialized
DEBUG - 2020-12-01 08:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 08:06:43 --> Input Class Initialized
INFO - 2020-12-01 08:06:43 --> Language Class Initialized
INFO - 2020-12-01 08:06:43 --> Loader Class Initialized
INFO - 2020-12-01 08:06:43 --> Helper loaded: url_helper
INFO - 2020-12-01 08:06:43 --> Database Driver Class Initialized
INFO - 2020-12-01 08:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 08:06:43 --> Email Class Initialized
INFO - 2020-12-01 08:06:43 --> Controller Class Initialized
INFO - 2020-12-01 08:06:43 --> Model Class Initialized
INFO - 2020-12-01 08:06:43 --> Model Class Initialized
DEBUG - 2020-12-01 08:06:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-01 08:06:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-01 08:06:43 --> Final output sent to browser
DEBUG - 2020-12-01 08:06:43 --> Total execution time: 0.1874
ERROR - 2020-12-01 14:06:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-01 14:06:18 --> Config Class Initialized
INFO - 2020-12-01 14:06:18 --> Hooks Class Initialized
DEBUG - 2020-12-01 14:06:18 --> UTF-8 Support Enabled
INFO - 2020-12-01 14:06:18 --> Utf8 Class Initialized
INFO - 2020-12-01 14:06:18 --> URI Class Initialized
DEBUG - 2020-12-01 14:06:18 --> No URI present. Default controller set.
INFO - 2020-12-01 14:06:18 --> Router Class Initialized
INFO - 2020-12-01 14:06:18 --> Output Class Initialized
INFO - 2020-12-01 14:06:18 --> Security Class Initialized
DEBUG - 2020-12-01 14:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 14:06:18 --> Input Class Initialized
INFO - 2020-12-01 14:06:18 --> Language Class Initialized
INFO - 2020-12-01 14:06:18 --> Loader Class Initialized
INFO - 2020-12-01 14:06:18 --> Helper loaded: url_helper
INFO - 2020-12-01 14:06:18 --> Database Driver Class Initialized
INFO - 2020-12-01 14:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 14:06:18 --> Email Class Initialized
INFO - 2020-12-01 14:06:18 --> Controller Class Initialized
INFO - 2020-12-01 14:06:18 --> Model Class Initialized
INFO - 2020-12-01 14:06:18 --> Model Class Initialized
DEBUG - 2020-12-01 14:06:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-01 14:06:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-01 14:06:18 --> Final output sent to browser
DEBUG - 2020-12-01 14:06:18 --> Total execution time: 0.1127
