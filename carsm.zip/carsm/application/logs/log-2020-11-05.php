<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-05 11:37:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:37:10 --> Config Class Initialized
INFO - 2020-11-05 11:37:10 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:37:10 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:37:10 --> Utf8 Class Initialized
INFO - 2020-11-05 11:37:10 --> URI Class Initialized
DEBUG - 2020-11-05 11:37:10 --> No URI present. Default controller set.
INFO - 2020-11-05 11:37:10 --> Router Class Initialized
INFO - 2020-11-05 11:37:10 --> Output Class Initialized
INFO - 2020-11-05 11:37:10 --> Security Class Initialized
DEBUG - 2020-11-05 11:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:37:10 --> Input Class Initialized
INFO - 2020-11-05 11:37:10 --> Language Class Initialized
INFO - 2020-11-05 11:37:10 --> Loader Class Initialized
INFO - 2020-11-05 11:37:10 --> Helper loaded: url_helper
INFO - 2020-11-05 11:37:11 --> Database Driver Class Initialized
INFO - 2020-11-05 11:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:37:11 --> Email Class Initialized
INFO - 2020-11-05 11:37:11 --> Controller Class Initialized
INFO - 2020-11-05 11:37:11 --> Model Class Initialized
INFO - 2020-11-05 11:37:11 --> Model Class Initialized
DEBUG - 2020-11-05 11:37:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:37:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-05 11:37:11 --> Final output sent to browser
DEBUG - 2020-11-05 11:37:11 --> Total execution time: 0.1610
ERROR - 2020-11-05 11:37:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:37:28 --> Config Class Initialized
INFO - 2020-11-05 11:37:28 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:37:28 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:37:28 --> Utf8 Class Initialized
INFO - 2020-11-05 11:37:28 --> URI Class Initialized
DEBUG - 2020-11-05 11:37:28 --> No URI present. Default controller set.
INFO - 2020-11-05 11:37:28 --> Router Class Initialized
INFO - 2020-11-05 11:37:28 --> Output Class Initialized
INFO - 2020-11-05 11:37:28 --> Security Class Initialized
DEBUG - 2020-11-05 11:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:37:28 --> Input Class Initialized
INFO - 2020-11-05 11:37:28 --> Language Class Initialized
INFO - 2020-11-05 11:37:28 --> Loader Class Initialized
INFO - 2020-11-05 11:37:28 --> Helper loaded: url_helper
INFO - 2020-11-05 11:37:28 --> Database Driver Class Initialized
INFO - 2020-11-05 11:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:37:28 --> Email Class Initialized
INFO - 2020-11-05 11:37:28 --> Controller Class Initialized
INFO - 2020-11-05 11:37:28 --> Model Class Initialized
INFO - 2020-11-05 11:37:28 --> Model Class Initialized
DEBUG - 2020-11-05 11:37:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:37:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-05 11:37:28 --> Final output sent to browser
DEBUG - 2020-11-05 11:37:28 --> Total execution time: 0.0195
ERROR - 2020-11-05 11:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:38:02 --> Config Class Initialized
INFO - 2020-11-05 11:38:02 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:38:02 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:38:02 --> Utf8 Class Initialized
INFO - 2020-11-05 11:38:02 --> URI Class Initialized
INFO - 2020-11-05 11:38:02 --> Router Class Initialized
INFO - 2020-11-05 11:38:02 --> Output Class Initialized
INFO - 2020-11-05 11:38:02 --> Security Class Initialized
DEBUG - 2020-11-05 11:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:38:02 --> Input Class Initialized
INFO - 2020-11-05 11:38:02 --> Language Class Initialized
INFO - 2020-11-05 11:38:02 --> Loader Class Initialized
ERROR - 2020-11-05 11:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:38:02 --> Helper loaded: url_helper
INFO - 2020-11-05 11:38:02 --> Config Class Initialized
INFO - 2020-11-05 11:38:02 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:38:02 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:38:02 --> Utf8 Class Initialized
INFO - 2020-11-05 11:38:02 --> URI Class Initialized
INFO - 2020-11-05 11:38:02 --> Router Class Initialized
INFO - 2020-11-05 11:38:02 --> Output Class Initialized
INFO - 2020-11-05 11:38:02 --> Database Driver Class Initialized
INFO - 2020-11-05 11:38:02 --> Security Class Initialized
DEBUG - 2020-11-05 11:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:38:02 --> Input Class Initialized
INFO - 2020-11-05 11:38:02 --> Language Class Initialized
INFO - 2020-11-05 11:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:38:02 --> Email Class Initialized
INFO - 2020-11-05 11:38:02 --> Controller Class Initialized
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
DEBUG - 2020-11-05 11:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:38:02 --> Loader Class Initialized
INFO - 2020-11-05 11:38:02 --> Helper loaded: url_helper
INFO - 2020-11-05 11:38:02 --> Database Driver Class Initialized
INFO - 2020-11-05 11:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:38:02 --> Email Class Initialized
INFO - 2020-11-05 11:38:02 --> Controller Class Initialized
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
DEBUG - 2020-11-05 11:38:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-05 11:38:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
INFO - 2020-11-05 11:38:02 --> Final output sent to browser
DEBUG - 2020-11-05 11:38:02 --> Total execution time: 0.0599
ERROR - 2020-11-05 11:38:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:38:02 --> Config Class Initialized
INFO - 2020-11-05 11:38:02 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:38:02 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:38:02 --> Utf8 Class Initialized
INFO - 2020-11-05 11:38:02 --> URI Class Initialized
INFO - 2020-11-05 11:38:02 --> Router Class Initialized
INFO - 2020-11-05 11:38:02 --> Output Class Initialized
INFO - 2020-11-05 11:38:02 --> Security Class Initialized
DEBUG - 2020-11-05 11:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:38:02 --> Input Class Initialized
INFO - 2020-11-05 11:38:02 --> Language Class Initialized
INFO - 2020-11-05 11:38:02 --> Loader Class Initialized
INFO - 2020-11-05 11:38:02 --> Helper loaded: url_helper
INFO - 2020-11-05 11:38:02 --> Database Driver Class Initialized
INFO - 2020-11-05 11:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:38:02 --> Email Class Initialized
INFO - 2020-11-05 11:38:02 --> Controller Class Initialized
DEBUG - 2020-11-05 11:38:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-05 11:38:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
INFO - 2020-11-05 11:38:02 --> Model Class Initialized
INFO - 2020-11-05 11:38:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-05 11:38:03 --> Final output sent to browser
DEBUG - 2020-11-05 11:38:03 --> Total execution time: 0.0700
ERROR - 2020-11-05 11:38:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:38:09 --> Config Class Initialized
INFO - 2020-11-05 11:38:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:38:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:38:09 --> Utf8 Class Initialized
INFO - 2020-11-05 11:38:09 --> URI Class Initialized
INFO - 2020-11-05 11:38:09 --> Router Class Initialized
INFO - 2020-11-05 11:38:09 --> Output Class Initialized
INFO - 2020-11-05 11:38:09 --> Security Class Initialized
DEBUG - 2020-11-05 11:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:38:09 --> Input Class Initialized
INFO - 2020-11-05 11:38:09 --> Language Class Initialized
INFO - 2020-11-05 11:38:09 --> Loader Class Initialized
INFO - 2020-11-05 11:38:09 --> Helper loaded: url_helper
INFO - 2020-11-05 11:38:09 --> Database Driver Class Initialized
INFO - 2020-11-05 11:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:38:09 --> Email Class Initialized
INFO - 2020-11-05 11:38:09 --> Controller Class Initialized
DEBUG - 2020-11-05 11:38:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-05 11:38:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:38:09 --> Model Class Initialized
INFO - 2020-11-05 11:38:09 --> Model Class Initialized
INFO - 2020-11-05 11:38:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-05 11:38:09 --> Final output sent to browser
DEBUG - 2020-11-05 11:38:09 --> Total execution time: 0.0798
ERROR - 2020-11-05 11:38:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 11:38:18 --> Config Class Initialized
INFO - 2020-11-05 11:38:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 11:38:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 11:38:18 --> Utf8 Class Initialized
INFO - 2020-11-05 11:38:18 --> URI Class Initialized
INFO - 2020-11-05 11:38:18 --> Router Class Initialized
INFO - 2020-11-05 11:38:18 --> Output Class Initialized
INFO - 2020-11-05 11:38:18 --> Security Class Initialized
DEBUG - 2020-11-05 11:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 11:38:18 --> Input Class Initialized
INFO - 2020-11-05 11:38:18 --> Language Class Initialized
INFO - 2020-11-05 11:38:18 --> Loader Class Initialized
INFO - 2020-11-05 11:38:18 --> Helper loaded: url_helper
INFO - 2020-11-05 11:38:18 --> Database Driver Class Initialized
INFO - 2020-11-05 11:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 11:38:18 --> Email Class Initialized
INFO - 2020-11-05 11:38:18 --> Controller Class Initialized
DEBUG - 2020-11-05 11:38:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-05 11:38:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-05 11:38:18 --> Model Class Initialized
INFO - 2020-11-05 11:38:18 --> Model Class Initialized
ERROR - 2020-11-05 11:38:18 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-05 11:38:18 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-05 11:38:19 --> Final output sent to browser
DEBUG - 2020-11-05 11:38:19 --> Total execution time: 1.2364
ERROR - 2020-11-05 16:35:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-05 16:35:03 --> Config Class Initialized
INFO - 2020-11-05 16:35:03 --> Hooks Class Initialized
DEBUG - 2020-11-05 16:35:03 --> UTF-8 Support Enabled
INFO - 2020-11-05 16:35:03 --> Utf8 Class Initialized
INFO - 2020-11-05 16:35:03 --> URI Class Initialized
DEBUG - 2020-11-05 16:35:03 --> No URI present. Default controller set.
INFO - 2020-11-05 16:35:03 --> Router Class Initialized
INFO - 2020-11-05 16:35:03 --> Output Class Initialized
INFO - 2020-11-05 16:35:03 --> Security Class Initialized
DEBUG - 2020-11-05 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 16:35:03 --> Input Class Initialized
INFO - 2020-11-05 16:35:03 --> Language Class Initialized
INFO - 2020-11-05 16:35:03 --> Loader Class Initialized
INFO - 2020-11-05 16:35:03 --> Helper loaded: url_helper
INFO - 2020-11-05 16:35:03 --> Database Driver Class Initialized
INFO - 2020-11-05 16:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 16:35:03 --> Email Class Initialized
INFO - 2020-11-05 16:35:03 --> Controller Class Initialized
INFO - 2020-11-05 16:35:03 --> Model Class Initialized
INFO - 2020-11-05 16:35:03 --> Model Class Initialized
DEBUG - 2020-11-05 16:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-05 16:35:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-05 16:35:03 --> Final output sent to browser
DEBUG - 2020-11-05 16:35:03 --> Total execution time: 0.1083
