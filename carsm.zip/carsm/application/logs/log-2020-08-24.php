<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-24 07:32:03 --> Config Class Initialized
INFO - 2020-08-24 07:32:03 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:03 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:03 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:03 --> URI Class Initialized
DEBUG - 2020-08-24 07:32:03 --> No URI present. Default controller set.
INFO - 2020-08-24 07:32:03 --> Router Class Initialized
INFO - 2020-08-24 07:32:03 --> Output Class Initialized
INFO - 2020-08-24 07:32:03 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:03 --> Input Class Initialized
INFO - 2020-08-24 07:32:03 --> Language Class Initialized
INFO - 2020-08-24 07:32:03 --> Loader Class Initialized
INFO - 2020-08-24 07:32:03 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:03 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:03 --> Email Class Initialized
INFO - 2020-08-24 07:32:03 --> Controller Class Initialized
INFO - 2020-08-24 07:32:03 --> Model Class Initialized
INFO - 2020-08-24 07:32:03 --> Model Class Initialized
DEBUG - 2020-08-24 07:32:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-24 07:32:03 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:03 --> Total execution time: 0.1437
INFO - 2020-08-24 07:32:10 --> Config Class Initialized
INFO - 2020-08-24 07:32:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:10 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:10 --> URI Class Initialized
INFO - 2020-08-24 07:32:10 --> Router Class Initialized
INFO - 2020-08-24 07:32:10 --> Output Class Initialized
INFO - 2020-08-24 07:32:10 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:10 --> Input Class Initialized
INFO - 2020-08-24 07:32:10 --> Language Class Initialized
INFO - 2020-08-24 07:32:10 --> Loader Class Initialized
INFO - 2020-08-24 07:32:10 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:10 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:10 --> Email Class Initialized
INFO - 2020-08-24 07:32:10 --> Controller Class Initialized
INFO - 2020-08-24 07:32:10 --> Model Class Initialized
INFO - 2020-08-24 07:32:10 --> Model Class Initialized
DEBUG - 2020-08-24 07:32:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:32:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:10 --> Config Class Initialized
INFO - 2020-08-24 07:32:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:10 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:10 --> URI Class Initialized
INFO - 2020-08-24 07:32:10 --> Router Class Initialized
INFO - 2020-08-24 07:32:10 --> Output Class Initialized
INFO - 2020-08-24 07:32:10 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:10 --> Input Class Initialized
INFO - 2020-08-24 07:32:10 --> Language Class Initialized
INFO - 2020-08-24 07:32:10 --> Loader Class Initialized
INFO - 2020-08-24 07:32:10 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:10 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:10 --> Email Class Initialized
INFO - 2020-08-24 07:32:10 --> Controller Class Initialized
INFO - 2020-08-24 07:32:10 --> Model Class Initialized
INFO - 2020-08-24 07:32:10 --> Model Class Initialized
DEBUG - 2020-08-24 07:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:10 --> Config Class Initialized
INFO - 2020-08-24 07:32:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:10 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:10 --> URI Class Initialized
DEBUG - 2020-08-24 07:32:10 --> No URI present. Default controller set.
INFO - 2020-08-24 07:32:10 --> Router Class Initialized
INFO - 2020-08-24 07:32:10 --> Output Class Initialized
INFO - 2020-08-24 07:32:10 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:10 --> Input Class Initialized
INFO - 2020-08-24 07:32:10 --> Language Class Initialized
INFO - 2020-08-24 07:32:10 --> Loader Class Initialized
INFO - 2020-08-24 07:32:10 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:10 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:10 --> Email Class Initialized
INFO - 2020-08-24 07:32:10 --> Controller Class Initialized
INFO - 2020-08-24 07:32:10 --> Model Class Initialized
INFO - 2020-08-24 07:32:10 --> Model Class Initialized
DEBUG - 2020-08-24 07:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-24 07:32:10 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:10 --> Total execution time: 0.0248
INFO - 2020-08-24 07:32:11 --> Config Class Initialized
INFO - 2020-08-24 07:32:11 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:11 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:11 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:11 --> URI Class Initialized
INFO - 2020-08-24 07:32:11 --> Router Class Initialized
INFO - 2020-08-24 07:32:11 --> Output Class Initialized
INFO - 2020-08-24 07:32:11 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:11 --> Input Class Initialized
INFO - 2020-08-24 07:32:11 --> Language Class Initialized
INFO - 2020-08-24 07:32:11 --> Loader Class Initialized
INFO - 2020-08-24 07:32:11 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:11 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:11 --> Email Class Initialized
INFO - 2020-08-24 07:32:11 --> Controller Class Initialized
DEBUG - 2020-08-24 07:32:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:32:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-24 07:32:11 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:11 --> Total execution time: 0.0432
INFO - 2020-08-24 07:32:21 --> Config Class Initialized
INFO - 2020-08-24 07:32:21 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:21 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:21 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:21 --> URI Class Initialized
INFO - 2020-08-24 07:32:21 --> Router Class Initialized
INFO - 2020-08-24 07:32:21 --> Output Class Initialized
INFO - 2020-08-24 07:32:21 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:21 --> Input Class Initialized
INFO - 2020-08-24 07:32:21 --> Language Class Initialized
INFO - 2020-08-24 07:32:21 --> Loader Class Initialized
INFO - 2020-08-24 07:32:21 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:21 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:21 --> Email Class Initialized
INFO - 2020-08-24 07:32:21 --> Controller Class Initialized
DEBUG - 2020-08-24 07:32:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:32:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:21 --> Model Class Initialized
INFO - 2020-08-24 07:32:21 --> Model Class Initialized
INFO - 2020-08-24 07:32:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-24 07:32:21 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:21 --> Total execution time: 0.0603
INFO - 2020-08-24 07:32:32 --> Config Class Initialized
INFO - 2020-08-24 07:32:32 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:32 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:32 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:32 --> URI Class Initialized
INFO - 2020-08-24 07:32:32 --> Router Class Initialized
INFO - 2020-08-24 07:32:32 --> Output Class Initialized
INFO - 2020-08-24 07:32:32 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:32 --> Input Class Initialized
INFO - 2020-08-24 07:32:32 --> Language Class Initialized
INFO - 2020-08-24 07:32:32 --> Loader Class Initialized
INFO - 2020-08-24 07:32:32 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:32 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:32 --> Email Class Initialized
INFO - 2020-08-24 07:32:32 --> Controller Class Initialized
DEBUG - 2020-08-24 07:32:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:32:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:32 --> Model Class Initialized
INFO - 2020-08-24 07:32:32 --> Model Class Initialized
INFO - 2020-08-24 07:32:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-24 07:32:32 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:32 --> Total execution time: 0.0305
INFO - 2020-08-24 07:32:38 --> Config Class Initialized
INFO - 2020-08-24 07:32:38 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:38 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:38 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:38 --> URI Class Initialized
INFO - 2020-08-24 07:32:38 --> Router Class Initialized
INFO - 2020-08-24 07:32:38 --> Output Class Initialized
INFO - 2020-08-24 07:32:38 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:38 --> Input Class Initialized
INFO - 2020-08-24 07:32:38 --> Language Class Initialized
INFO - 2020-08-24 07:32:38 --> Loader Class Initialized
INFO - 2020-08-24 07:32:38 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:38 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:38 --> Email Class Initialized
INFO - 2020-08-24 07:32:38 --> Controller Class Initialized
DEBUG - 2020-08-24 07:32:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:32:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:38 --> Model Class Initialized
INFO - 2020-08-24 07:32:38 --> Model Class Initialized
INFO - 2020-08-24 07:32:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-24 07:32:38 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:38 --> Total execution time: 0.0341
INFO - 2020-08-24 07:32:41 --> Config Class Initialized
INFO - 2020-08-24 07:32:41 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:41 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:41 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:41 --> URI Class Initialized
INFO - 2020-08-24 07:32:41 --> Router Class Initialized
INFO - 2020-08-24 07:32:41 --> Output Class Initialized
INFO - 2020-08-24 07:32:41 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:41 --> Input Class Initialized
INFO - 2020-08-24 07:32:41 --> Language Class Initialized
INFO - 2020-08-24 07:32:41 --> Loader Class Initialized
INFO - 2020-08-24 07:32:41 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:41 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:41 --> Email Class Initialized
INFO - 2020-08-24 07:32:41 --> Controller Class Initialized
DEBUG - 2020-08-24 07:32:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-24 07:32:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:41 --> Model Class Initialized
INFO - 2020-08-24 07:32:41 --> Model Class Initialized
INFO - 2020-08-24 07:32:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-24 07:32:41 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:41 --> Total execution time: 0.0262
INFO - 2020-08-24 07:32:43 --> Config Class Initialized
INFO - 2020-08-24 07:32:43 --> Hooks Class Initialized
DEBUG - 2020-08-24 07:32:43 --> UTF-8 Support Enabled
INFO - 2020-08-24 07:32:43 --> Utf8 Class Initialized
INFO - 2020-08-24 07:32:43 --> URI Class Initialized
DEBUG - 2020-08-24 07:32:43 --> No URI present. Default controller set.
INFO - 2020-08-24 07:32:43 --> Router Class Initialized
INFO - 2020-08-24 07:32:43 --> Output Class Initialized
INFO - 2020-08-24 07:32:43 --> Security Class Initialized
DEBUG - 2020-08-24 07:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 07:32:43 --> Input Class Initialized
INFO - 2020-08-24 07:32:43 --> Language Class Initialized
INFO - 2020-08-24 07:32:43 --> Loader Class Initialized
INFO - 2020-08-24 07:32:43 --> Helper loaded: url_helper
INFO - 2020-08-24 07:32:43 --> Database Driver Class Initialized
INFO - 2020-08-24 07:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 07:32:43 --> Email Class Initialized
INFO - 2020-08-24 07:32:43 --> Controller Class Initialized
INFO - 2020-08-24 07:32:43 --> Model Class Initialized
INFO - 2020-08-24 07:32:43 --> Model Class Initialized
DEBUG - 2020-08-24 07:32:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-24 07:32:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-24 07:32:43 --> Final output sent to browser
DEBUG - 2020-08-24 07:32:43 --> Total execution time: 0.0197
INFO - 2020-08-24 12:03:10 --> Config Class Initialized
INFO - 2020-08-24 12:03:10 --> Hooks Class Initialized
DEBUG - 2020-08-24 12:03:10 --> UTF-8 Support Enabled
INFO - 2020-08-24 12:03:10 --> Utf8 Class Initialized
INFO - 2020-08-24 12:03:10 --> URI Class Initialized
DEBUG - 2020-08-24 12:03:10 --> No URI present. Default controller set.
INFO - 2020-08-24 12:03:10 --> Router Class Initialized
INFO - 2020-08-24 12:03:10 --> Output Class Initialized
INFO - 2020-08-24 12:03:10 --> Security Class Initialized
DEBUG - 2020-08-24 12:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 12:03:10 --> Input Class Initialized
INFO - 2020-08-24 12:03:10 --> Language Class Initialized
INFO - 2020-08-24 12:03:10 --> Loader Class Initialized
INFO - 2020-08-24 12:03:10 --> Helper loaded: url_helper
INFO - 2020-08-24 12:03:10 --> Database Driver Class Initialized
INFO - 2020-08-24 12:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 12:03:10 --> Email Class Initialized
INFO - 2020-08-24 12:03:10 --> Controller Class Initialized
INFO - 2020-08-24 12:03:10 --> Model Class Initialized
INFO - 2020-08-24 12:03:10 --> Model Class Initialized
DEBUG - 2020-08-24 12:03:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-24 12:03:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-24 12:03:10 --> Final output sent to browser
DEBUG - 2020-08-24 12:03:10 --> Total execution time: 0.0256
INFO - 2020-08-24 15:26:06 --> Config Class Initialized
INFO - 2020-08-24 15:26:06 --> Hooks Class Initialized
DEBUG - 2020-08-24 15:26:06 --> UTF-8 Support Enabled
INFO - 2020-08-24 15:26:06 --> Utf8 Class Initialized
INFO - 2020-08-24 15:26:06 --> URI Class Initialized
DEBUG - 2020-08-24 15:26:06 --> No URI present. Default controller set.
INFO - 2020-08-24 15:26:06 --> Router Class Initialized
INFO - 2020-08-24 15:26:06 --> Output Class Initialized
INFO - 2020-08-24 15:26:06 --> Security Class Initialized
DEBUG - 2020-08-24 15:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-24 15:26:06 --> Input Class Initialized
INFO - 2020-08-24 15:26:06 --> Language Class Initialized
INFO - 2020-08-24 15:26:06 --> Loader Class Initialized
INFO - 2020-08-24 15:26:06 --> Helper loaded: url_helper
INFO - 2020-08-24 15:26:06 --> Database Driver Class Initialized
INFO - 2020-08-24 15:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-24 15:26:06 --> Email Class Initialized
INFO - 2020-08-24 15:26:06 --> Controller Class Initialized
INFO - 2020-08-24 15:26:06 --> Model Class Initialized
INFO - 2020-08-24 15:26:06 --> Model Class Initialized
DEBUG - 2020-08-24 15:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-24 15:26:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-24 15:26:06 --> Final output sent to browser
DEBUG - 2020-08-24 15:26:06 --> Total execution time: 0.0238
