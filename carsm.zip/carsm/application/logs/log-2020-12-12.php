<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-12 03:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 03:12:53 --> Config Class Initialized
INFO - 2020-12-12 03:12:53 --> Hooks Class Initialized
DEBUG - 2020-12-12 03:12:53 --> UTF-8 Support Enabled
INFO - 2020-12-12 03:12:53 --> Utf8 Class Initialized
INFO - 2020-12-12 03:12:53 --> URI Class Initialized
DEBUG - 2020-12-12 03:12:53 --> No URI present. Default controller set.
INFO - 2020-12-12 03:12:53 --> Router Class Initialized
INFO - 2020-12-12 03:12:53 --> Output Class Initialized
INFO - 2020-12-12 03:12:53 --> Security Class Initialized
DEBUG - 2020-12-12 03:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 03:12:53 --> Input Class Initialized
INFO - 2020-12-12 03:12:53 --> Language Class Initialized
INFO - 2020-12-12 03:12:53 --> Loader Class Initialized
INFO - 2020-12-12 03:12:53 --> Helper loaded: url_helper
INFO - 2020-12-12 03:12:53 --> Database Driver Class Initialized
INFO - 2020-12-12 03:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 03:12:53 --> Email Class Initialized
INFO - 2020-12-12 03:12:53 --> Controller Class Initialized
INFO - 2020-12-12 03:12:53 --> Model Class Initialized
INFO - 2020-12-12 03:12:53 --> Model Class Initialized
DEBUG - 2020-12-12 03:12:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 03:12:53 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-12 03:12:53 --> Final output sent to browser
DEBUG - 2020-12-12 03:12:53 --> Total execution time: 0.2115
ERROR - 2020-12-12 04:54:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:54:08 --> Config Class Initialized
INFO - 2020-12-12 04:54:08 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:54:08 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:54:08 --> Utf8 Class Initialized
INFO - 2020-12-12 04:54:08 --> URI Class Initialized
DEBUG - 2020-12-12 04:54:08 --> No URI present. Default controller set.
INFO - 2020-12-12 04:54:08 --> Router Class Initialized
INFO - 2020-12-12 04:54:08 --> Output Class Initialized
INFO - 2020-12-12 04:54:08 --> Security Class Initialized
DEBUG - 2020-12-12 04:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:54:08 --> Input Class Initialized
INFO - 2020-12-12 04:54:08 --> Language Class Initialized
INFO - 2020-12-12 04:54:08 --> Loader Class Initialized
INFO - 2020-12-12 04:54:08 --> Helper loaded: url_helper
INFO - 2020-12-12 04:54:08 --> Database Driver Class Initialized
INFO - 2020-12-12 04:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:54:08 --> Email Class Initialized
INFO - 2020-12-12 04:54:08 --> Controller Class Initialized
INFO - 2020-12-12 04:54:08 --> Model Class Initialized
INFO - 2020-12-12 04:54:08 --> Model Class Initialized
DEBUG - 2020-12-12 04:54:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 04:54:08 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-12 04:54:08 --> Final output sent to browser
DEBUG - 2020-12-12 04:54:08 --> Total execution time: 0.1983
ERROR - 2020-12-12 04:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:55:11 --> Config Class Initialized
INFO - 2020-12-12 04:55:11 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:55:11 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:55:11 --> Utf8 Class Initialized
INFO - 2020-12-12 04:55:11 --> URI Class Initialized
INFO - 2020-12-12 04:55:11 --> Router Class Initialized
INFO - 2020-12-12 04:55:11 --> Output Class Initialized
INFO - 2020-12-12 04:55:11 --> Security Class Initialized
ERROR - 2020-12-12 04:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2020-12-12 04:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:55:11 --> Input Class Initialized
INFO - 2020-12-12 04:55:11 --> Language Class Initialized
INFO - 2020-12-12 04:55:11 --> Config Class Initialized
INFO - 2020-12-12 04:55:11 --> Hooks Class Initialized
INFO - 2020-12-12 04:55:11 --> Loader Class Initialized
INFO - 2020-12-12 04:55:11 --> Helper loaded: url_helper
DEBUG - 2020-12-12 04:55:11 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:55:11 --> Utf8 Class Initialized
INFO - 2020-12-12 04:55:11 --> URI Class Initialized
INFO - 2020-12-12 04:55:11 --> Router Class Initialized
INFO - 2020-12-12 04:55:11 --> Output Class Initialized
INFO - 2020-12-12 04:55:11 --> Security Class Initialized
DEBUG - 2020-12-12 04:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:55:11 --> Input Class Initialized
INFO - 2020-12-12 04:55:11 --> Database Driver Class Initialized
INFO - 2020-12-12 04:55:11 --> Language Class Initialized
INFO - 2020-12-12 04:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:55:11 --> Email Class Initialized
INFO - 2020-12-12 04:55:11 --> Controller Class Initialized
INFO - 2020-12-12 04:55:11 --> Model Class Initialized
INFO - 2020-12-12 04:55:11 --> Model Class Initialized
DEBUG - 2020-12-12 04:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 04:55:11 --> Loader Class Initialized
INFO - 2020-12-12 04:55:11 --> Helper loaded: url_helper
ERROR - 2020-12-12 04:55:11 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-12 04:55:11 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
INFO - 2020-12-12 04:55:11 --> Database Driver Class Initialized
INFO - 2020-12-12 04:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:55:11 --> Email Class Initialized
INFO - 2020-12-12 04:55:11 --> Controller Class Initialized
INFO - 2020-12-12 04:55:11 --> Model Class Initialized
INFO - 2020-12-12 04:55:11 --> Model Class Initialized
DEBUG - 2020-12-12 04:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-12 04:55:11 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-12-12 04:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:55:12 --> Config Class Initialized
INFO - 2020-12-12 04:55:12 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:55:12 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:55:12 --> Utf8 Class Initialized
INFO - 2020-12-12 04:55:12 --> URI Class Initialized
INFO - 2020-12-12 04:55:12 --> Router Class Initialized
INFO - 2020-12-12 04:55:12 --> Output Class Initialized
INFO - 2020-12-12 04:55:12 --> Security Class Initialized
DEBUG - 2020-12-12 04:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:55:12 --> Input Class Initialized
INFO - 2020-12-12 04:55:12 --> Language Class Initialized
INFO - 2020-12-12 04:55:12 --> Loader Class Initialized
INFO - 2020-12-12 04:55:12 --> Helper loaded: url_helper
INFO - 2020-12-12 04:55:12 --> Database Driver Class Initialized
INFO - 2020-12-12 04:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:55:12 --> Email Class Initialized
INFO - 2020-12-12 04:55:12 --> Controller Class Initialized
DEBUG - 2020-12-12 04:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-12 04:55:12 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-12-12 04:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:55:12 --> Config Class Initialized
INFO - 2020-12-12 04:55:12 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:55:12 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:55:12 --> Utf8 Class Initialized
INFO - 2020-12-12 04:55:12 --> URI Class Initialized
DEBUG - 2020-12-12 04:55:12 --> No URI present. Default controller set.
INFO - 2020-12-12 04:55:12 --> Router Class Initialized
INFO - 2020-12-12 04:55:12 --> Output Class Initialized
INFO - 2020-12-12 04:55:12 --> Security Class Initialized
DEBUG - 2020-12-12 04:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:55:12 --> Input Class Initialized
INFO - 2020-12-12 04:55:12 --> Language Class Initialized
INFO - 2020-12-12 04:55:12 --> Loader Class Initialized
INFO - 2020-12-12 04:55:12 --> Helper loaded: url_helper
INFO - 2020-12-12 04:55:12 --> Database Driver Class Initialized
INFO - 2020-12-12 04:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:55:12 --> Email Class Initialized
INFO - 2020-12-12 04:55:12 --> Controller Class Initialized
INFO - 2020-12-12 04:55:12 --> Model Class Initialized
INFO - 2020-12-12 04:55:12 --> Model Class Initialized
DEBUG - 2020-12-12 04:55:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 04:55:12 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-12 04:55:12 --> Final output sent to browser
DEBUG - 2020-12-12 04:55:12 --> Total execution time: 0.0445
ERROR - 2020-12-12 04:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:56:43 --> Config Class Initialized
INFO - 2020-12-12 04:56:43 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:56:43 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:56:43 --> Utf8 Class Initialized
INFO - 2020-12-12 04:56:43 --> URI Class Initialized
INFO - 2020-12-12 04:56:43 --> Router Class Initialized
INFO - 2020-12-12 04:56:43 --> Output Class Initialized
INFO - 2020-12-12 04:56:43 --> Security Class Initialized
DEBUG - 2020-12-12 04:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:56:43 --> Input Class Initialized
INFO - 2020-12-12 04:56:43 --> Language Class Initialized
INFO - 2020-12-12 04:56:43 --> Loader Class Initialized
INFO - 2020-12-12 04:56:43 --> Helper loaded: url_helper
INFO - 2020-12-12 04:56:43 --> Database Driver Class Initialized
INFO - 2020-12-12 04:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:56:43 --> Email Class Initialized
INFO - 2020-12-12 04:56:43 --> Controller Class Initialized
INFO - 2020-12-12 04:56:43 --> Model Class Initialized
INFO - 2020-12-12 04:56:43 --> Model Class Initialized
DEBUG - 2020-12-12 04:56:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-12 04:56:43 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-12 04:56:43 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-12 04:56:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:56:43 --> Config Class Initialized
INFO - 2020-12-12 04:56:43 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:56:43 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:56:43 --> Utf8 Class Initialized
INFO - 2020-12-12 04:56:43 --> URI Class Initialized
INFO - 2020-12-12 04:56:43 --> Router Class Initialized
INFO - 2020-12-12 04:56:43 --> Output Class Initialized
INFO - 2020-12-12 04:56:43 --> Security Class Initialized
DEBUG - 2020-12-12 04:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:56:43 --> Input Class Initialized
INFO - 2020-12-12 04:56:43 --> Language Class Initialized
INFO - 2020-12-12 04:56:43 --> Loader Class Initialized
INFO - 2020-12-12 04:56:43 --> Helper loaded: url_helper
INFO - 2020-12-12 04:56:43 --> Database Driver Class Initialized
INFO - 2020-12-12 04:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:56:43 --> Email Class Initialized
INFO - 2020-12-12 04:56:43 --> Controller Class Initialized
INFO - 2020-12-12 04:56:43 --> Model Class Initialized
INFO - 2020-12-12 04:56:43 --> Model Class Initialized
DEBUG - 2020-12-12 04:56:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-12 04:56:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-12 04:56:43 --> Model Class Initialized
INFO - 2020-12-12 04:56:43 --> Final output sent to browser
DEBUG - 2020-12-12 04:56:43 --> Total execution time: 0.0459
ERROR - 2020-12-12 04:56:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:56:44 --> Config Class Initialized
INFO - 2020-12-12 04:56:44 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:56:44 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:56:44 --> Utf8 Class Initialized
INFO - 2020-12-12 04:56:44 --> URI Class Initialized
INFO - 2020-12-12 04:56:44 --> Router Class Initialized
INFO - 2020-12-12 04:56:44 --> Output Class Initialized
INFO - 2020-12-12 04:56:44 --> Security Class Initialized
DEBUG - 2020-12-12 04:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:56:44 --> Input Class Initialized
INFO - 2020-12-12 04:56:44 --> Language Class Initialized
INFO - 2020-12-12 04:56:44 --> Loader Class Initialized
INFO - 2020-12-12 04:56:44 --> Helper loaded: url_helper
INFO - 2020-12-12 04:56:44 --> Database Driver Class Initialized
INFO - 2020-12-12 04:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:56:44 --> Email Class Initialized
INFO - 2020-12-12 04:56:44 --> Controller Class Initialized
DEBUG - 2020-12-12 04:56:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-12 04:56:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-12 04:56:44 --> Model Class Initialized
INFO - 2020-12-12 04:56:44 --> Model Class Initialized
INFO - 2020-12-12 04:56:44 --> File loaded: /home/portaldev2020/public_html/application/views/dash.php
INFO - 2020-12-12 04:56:44 --> Final output sent to browser
DEBUG - 2020-12-12 04:56:44 --> Total execution time: 0.1038
ERROR - 2020-12-12 04:57:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 04:57:03 --> Config Class Initialized
INFO - 2020-12-12 04:57:03 --> Hooks Class Initialized
DEBUG - 2020-12-12 04:57:03 --> UTF-8 Support Enabled
INFO - 2020-12-12 04:57:03 --> Utf8 Class Initialized
INFO - 2020-12-12 04:57:03 --> URI Class Initialized
INFO - 2020-12-12 04:57:03 --> Router Class Initialized
INFO - 2020-12-12 04:57:03 --> Output Class Initialized
INFO - 2020-12-12 04:57:03 --> Security Class Initialized
DEBUG - 2020-12-12 04:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 04:57:04 --> Input Class Initialized
INFO - 2020-12-12 04:57:04 --> Language Class Initialized
INFO - 2020-12-12 04:57:04 --> Loader Class Initialized
INFO - 2020-12-12 04:57:04 --> Helper loaded: url_helper
INFO - 2020-12-12 04:57:04 --> Database Driver Class Initialized
INFO - 2020-12-12 04:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 04:57:04 --> Email Class Initialized
INFO - 2020-12-12 04:57:04 --> Controller Class Initialized
DEBUG - 2020-12-12 04:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-12 04:57:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-12 04:57:04 --> Model Class Initialized
INFO - 2020-12-12 04:57:04 --> Model Class Initialized
INFO - 2020-12-12 04:57:04 --> File loaded: /home/portaldev2020/public_html/application/views/dealer_master_list.php
INFO - 2020-12-12 04:57:04 --> Final output sent to browser
DEBUG - 2020-12-12 04:57:04 --> Total execution time: 0.0646
ERROR - 2020-12-12 05:08:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 05:08:01 --> Config Class Initialized
INFO - 2020-12-12 05:08:01 --> Hooks Class Initialized
DEBUG - 2020-12-12 05:08:01 --> UTF-8 Support Enabled
INFO - 2020-12-12 05:08:01 --> Utf8 Class Initialized
INFO - 2020-12-12 05:08:01 --> URI Class Initialized
DEBUG - 2020-12-12 05:08:01 --> No URI present. Default controller set.
INFO - 2020-12-12 05:08:01 --> Router Class Initialized
INFO - 2020-12-12 05:08:01 --> Output Class Initialized
INFO - 2020-12-12 05:08:01 --> Security Class Initialized
DEBUG - 2020-12-12 05:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 05:08:01 --> Input Class Initialized
INFO - 2020-12-12 05:08:01 --> Language Class Initialized
INFO - 2020-12-12 05:08:01 --> Loader Class Initialized
INFO - 2020-12-12 05:08:01 --> Helper loaded: url_helper
INFO - 2020-12-12 05:08:01 --> Database Driver Class Initialized
INFO - 2020-12-12 05:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 05:08:01 --> Email Class Initialized
INFO - 2020-12-12 05:08:01 --> Controller Class Initialized
INFO - 2020-12-12 05:08:01 --> Model Class Initialized
INFO - 2020-12-12 05:08:01 --> Model Class Initialized
DEBUG - 2020-12-12 05:08:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 05:08:01 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-12 05:08:01 --> Final output sent to browser
DEBUG - 2020-12-12 05:08:01 --> Total execution time: 0.0811
ERROR - 2020-12-12 05:08:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 05:08:02 --> Config Class Initialized
INFO - 2020-12-12 05:08:02 --> Hooks Class Initialized
DEBUG - 2020-12-12 05:08:02 --> UTF-8 Support Enabled
INFO - 2020-12-12 05:08:02 --> Utf8 Class Initialized
INFO - 2020-12-12 05:08:02 --> URI Class Initialized
DEBUG - 2020-12-12 05:08:02 --> No URI present. Default controller set.
INFO - 2020-12-12 05:08:02 --> Router Class Initialized
INFO - 2020-12-12 05:08:02 --> Output Class Initialized
INFO - 2020-12-12 05:08:02 --> Security Class Initialized
DEBUG - 2020-12-12 05:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 05:08:02 --> Input Class Initialized
INFO - 2020-12-12 05:08:02 --> Language Class Initialized
INFO - 2020-12-12 05:08:02 --> Loader Class Initialized
INFO - 2020-12-12 05:08:02 --> Helper loaded: url_helper
INFO - 2020-12-12 05:08:02 --> Database Driver Class Initialized
INFO - 2020-12-12 05:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 05:08:02 --> Email Class Initialized
INFO - 2020-12-12 05:08:02 --> Controller Class Initialized
INFO - 2020-12-12 05:08:02 --> Model Class Initialized
INFO - 2020-12-12 05:08:02 --> Model Class Initialized
DEBUG - 2020-12-12 05:08:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 05:08:02 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-12 05:08:02 --> Final output sent to browser
DEBUG - 2020-12-12 05:08:02 --> Total execution time: 0.0522
ERROR - 2020-12-12 05:39:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-12 05:39:18 --> Config Class Initialized
INFO - 2020-12-12 05:39:18 --> Hooks Class Initialized
DEBUG - 2020-12-12 05:39:18 --> UTF-8 Support Enabled
INFO - 2020-12-12 05:39:18 --> Utf8 Class Initialized
INFO - 2020-12-12 05:39:18 --> URI Class Initialized
DEBUG - 2020-12-12 05:39:18 --> No URI present. Default controller set.
INFO - 2020-12-12 05:39:18 --> Router Class Initialized
INFO - 2020-12-12 05:39:18 --> Output Class Initialized
INFO - 2020-12-12 05:39:18 --> Security Class Initialized
DEBUG - 2020-12-12 05:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-12 05:39:18 --> Input Class Initialized
INFO - 2020-12-12 05:39:18 --> Language Class Initialized
INFO - 2020-12-12 05:39:18 --> Loader Class Initialized
INFO - 2020-12-12 05:39:18 --> Helper loaded: url_helper
INFO - 2020-12-12 05:39:18 --> Database Driver Class Initialized
INFO - 2020-12-12 05:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-12 05:39:18 --> Email Class Initialized
INFO - 2020-12-12 05:39:18 --> Controller Class Initialized
INFO - 2020-12-12 05:39:18 --> Model Class Initialized
INFO - 2020-12-12 05:39:18 --> Model Class Initialized
DEBUG - 2020-12-12 05:39:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-12 05:39:18 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-12 05:39:18 --> Final output sent to browser
DEBUG - 2020-12-12 05:39:18 --> Total execution time: 0.1314
