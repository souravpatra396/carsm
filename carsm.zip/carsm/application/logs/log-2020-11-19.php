<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-19 09:57:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-19 09:57:24 --> Config Class Initialized
INFO - 2020-11-19 09:57:24 --> Hooks Class Initialized
DEBUG - 2020-11-19 09:57:24 --> UTF-8 Support Enabled
INFO - 2020-11-19 09:57:24 --> Utf8 Class Initialized
INFO - 2020-11-19 09:57:24 --> URI Class Initialized
DEBUG - 2020-11-19 09:57:24 --> No URI present. Default controller set.
INFO - 2020-11-19 09:57:24 --> Router Class Initialized
INFO - 2020-11-19 09:57:24 --> Output Class Initialized
INFO - 2020-11-19 09:57:24 --> Security Class Initialized
DEBUG - 2020-11-19 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 09:57:24 --> Input Class Initialized
INFO - 2020-11-19 09:57:24 --> Language Class Initialized
INFO - 2020-11-19 09:57:24 --> Loader Class Initialized
INFO - 2020-11-19 09:57:24 --> Helper loaded: url_helper
INFO - 2020-11-19 09:57:24 --> Database Driver Class Initialized
INFO - 2020-11-19 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 09:57:24 --> Email Class Initialized
INFO - 2020-11-19 09:57:24 --> Controller Class Initialized
INFO - 2020-11-19 09:57:24 --> Model Class Initialized
INFO - 2020-11-19 09:57:24 --> Model Class Initialized
DEBUG - 2020-11-19 09:57:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-19 09:57:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-19 09:57:24 --> Final output sent to browser
DEBUG - 2020-11-19 09:57:24 --> Total execution time: 0.1597
ERROR - 2020-11-19 09:57:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-19 09:57:25 --> Config Class Initialized
INFO - 2020-11-19 09:57:25 --> Hooks Class Initialized
DEBUG - 2020-11-19 09:57:25 --> UTF-8 Support Enabled
INFO - 2020-11-19 09:57:25 --> Utf8 Class Initialized
INFO - 2020-11-19 09:57:25 --> URI Class Initialized
DEBUG - 2020-11-19 09:57:25 --> No URI present. Default controller set.
INFO - 2020-11-19 09:57:25 --> Router Class Initialized
INFO - 2020-11-19 09:57:25 --> Output Class Initialized
INFO - 2020-11-19 09:57:25 --> Security Class Initialized
DEBUG - 2020-11-19 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 09:57:25 --> Input Class Initialized
INFO - 2020-11-19 09:57:25 --> Language Class Initialized
INFO - 2020-11-19 09:57:25 --> Loader Class Initialized
INFO - 2020-11-19 09:57:25 --> Helper loaded: url_helper
INFO - 2020-11-19 09:57:25 --> Database Driver Class Initialized
INFO - 2020-11-19 09:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 09:57:25 --> Email Class Initialized
INFO - 2020-11-19 09:57:25 --> Controller Class Initialized
INFO - 2020-11-19 09:57:25 --> Model Class Initialized
INFO - 2020-11-19 09:57:25 --> Model Class Initialized
DEBUG - 2020-11-19 09:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-19 09:57:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-19 09:57:25 --> Final output sent to browser
DEBUG - 2020-11-19 09:57:25 --> Total execution time: 0.0203
ERROR - 2020-11-19 09:57:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-19 09:57:29 --> Config Class Initialized
INFO - 2020-11-19 09:57:29 --> Hooks Class Initialized
DEBUG - 2020-11-19 09:57:29 --> UTF-8 Support Enabled
INFO - 2020-11-19 09:57:29 --> Utf8 Class Initialized
INFO - 2020-11-19 09:57:29 --> URI Class Initialized
DEBUG - 2020-11-19 09:57:29 --> No URI present. Default controller set.
INFO - 2020-11-19 09:57:29 --> Router Class Initialized
INFO - 2020-11-19 09:57:29 --> Output Class Initialized
INFO - 2020-11-19 09:57:29 --> Security Class Initialized
DEBUG - 2020-11-19 09:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-19 09:57:29 --> Input Class Initialized
INFO - 2020-11-19 09:57:29 --> Language Class Initialized
INFO - 2020-11-19 09:57:29 --> Loader Class Initialized
INFO - 2020-11-19 09:57:29 --> Helper loaded: url_helper
INFO - 2020-11-19 09:57:29 --> Database Driver Class Initialized
INFO - 2020-11-19 09:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-19 09:57:29 --> Email Class Initialized
INFO - 2020-11-19 09:57:29 --> Controller Class Initialized
INFO - 2020-11-19 09:57:29 --> Model Class Initialized
INFO - 2020-11-19 09:57:29 --> Model Class Initialized
DEBUG - 2020-11-19 09:57:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-19 09:57:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-19 09:57:29 --> Final output sent to browser
DEBUG - 2020-11-19 09:57:29 --> Total execution time: 0.0219
