<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-14 03:26:51 --> Config Class Initialized
INFO - 2020-08-14 03:26:51 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:26:51 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:26:51 --> Utf8 Class Initialized
INFO - 2020-08-14 03:26:51 --> URI Class Initialized
DEBUG - 2020-08-14 03:26:51 --> No URI present. Default controller set.
INFO - 2020-08-14 03:26:51 --> Router Class Initialized
INFO - 2020-08-14 03:26:51 --> Output Class Initialized
INFO - 2020-08-14 03:26:51 --> Security Class Initialized
DEBUG - 2020-08-14 03:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:26:51 --> Input Class Initialized
INFO - 2020-08-14 03:26:51 --> Language Class Initialized
INFO - 2020-08-14 03:26:51 --> Loader Class Initialized
INFO - 2020-08-14 03:26:51 --> Helper loaded: url_helper
INFO - 2020-08-14 03:26:51 --> Database Driver Class Initialized
INFO - 2020-08-14 03:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:26:51 --> Email Class Initialized
INFO - 2020-08-14 03:26:51 --> Controller Class Initialized
INFO - 2020-08-14 03:26:51 --> Model Class Initialized
INFO - 2020-08-14 03:26:51 --> Model Class Initialized
DEBUG - 2020-08-14 03:26:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:26:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 03:26:51 --> Final output sent to browser
DEBUG - 2020-08-14 03:26:51 --> Total execution time: 0.0226
INFO - 2020-08-14 03:27:31 --> Config Class Initialized
INFO - 2020-08-14 03:27:31 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:27:31 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:27:31 --> Utf8 Class Initialized
INFO - 2020-08-14 03:27:31 --> URI Class Initialized
INFO - 2020-08-14 03:27:31 --> Router Class Initialized
INFO - 2020-08-14 03:27:31 --> Output Class Initialized
INFO - 2020-08-14 03:27:31 --> Security Class Initialized
DEBUG - 2020-08-14 03:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:27:31 --> Input Class Initialized
INFO - 2020-08-14 03:27:31 --> Language Class Initialized
INFO - 2020-08-14 03:27:31 --> Loader Class Initialized
INFO - 2020-08-14 03:27:31 --> Helper loaded: url_helper
INFO - 2020-08-14 03:27:31 --> Database Driver Class Initialized
INFO - 2020-08-14 03:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:27:31 --> Email Class Initialized
INFO - 2020-08-14 03:27:31 --> Controller Class Initialized
INFO - 2020-08-14 03:27:31 --> Model Class Initialized
INFO - 2020-08-14 03:27:31 --> Model Class Initialized
DEBUG - 2020-08-14 03:27:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:27:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:27:31 --> Config Class Initialized
INFO - 2020-08-14 03:27:31 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:27:31 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:27:31 --> Utf8 Class Initialized
INFO - 2020-08-14 03:27:31 --> URI Class Initialized
INFO - 2020-08-14 03:27:31 --> Router Class Initialized
INFO - 2020-08-14 03:27:31 --> Output Class Initialized
INFO - 2020-08-14 03:27:31 --> Security Class Initialized
DEBUG - 2020-08-14 03:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:27:31 --> Input Class Initialized
INFO - 2020-08-14 03:27:31 --> Language Class Initialized
INFO - 2020-08-14 03:27:31 --> Loader Class Initialized
INFO - 2020-08-14 03:27:31 --> Helper loaded: url_helper
INFO - 2020-08-14 03:27:31 --> Database Driver Class Initialized
INFO - 2020-08-14 03:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:27:31 --> Email Class Initialized
INFO - 2020-08-14 03:27:31 --> Controller Class Initialized
INFO - 2020-08-14 03:27:31 --> Model Class Initialized
INFO - 2020-08-14 03:27:31 --> Model Class Initialized
DEBUG - 2020-08-14 03:27:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:27:32 --> Config Class Initialized
INFO - 2020-08-14 03:27:32 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:27:32 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:27:32 --> Utf8 Class Initialized
INFO - 2020-08-14 03:27:32 --> URI Class Initialized
DEBUG - 2020-08-14 03:27:32 --> No URI present. Default controller set.
INFO - 2020-08-14 03:27:32 --> Router Class Initialized
INFO - 2020-08-14 03:27:32 --> Output Class Initialized
INFO - 2020-08-14 03:27:32 --> Security Class Initialized
DEBUG - 2020-08-14 03:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:27:32 --> Input Class Initialized
INFO - 2020-08-14 03:27:32 --> Language Class Initialized
INFO - 2020-08-14 03:27:32 --> Loader Class Initialized
INFO - 2020-08-14 03:27:32 --> Helper loaded: url_helper
INFO - 2020-08-14 03:27:32 --> Database Driver Class Initialized
INFO - 2020-08-14 03:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:27:32 --> Email Class Initialized
INFO - 2020-08-14 03:27:32 --> Controller Class Initialized
INFO - 2020-08-14 03:27:32 --> Model Class Initialized
INFO - 2020-08-14 03:27:32 --> Model Class Initialized
DEBUG - 2020-08-14 03:27:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:27:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 03:27:32 --> Final output sent to browser
DEBUG - 2020-08-14 03:27:32 --> Total execution time: 0.0205
INFO - 2020-08-14 03:27:32 --> Config Class Initialized
INFO - 2020-08-14 03:27:32 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:27:32 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:27:32 --> Utf8 Class Initialized
INFO - 2020-08-14 03:27:32 --> URI Class Initialized
INFO - 2020-08-14 03:27:32 --> Router Class Initialized
INFO - 2020-08-14 03:27:32 --> Output Class Initialized
INFO - 2020-08-14 03:27:32 --> Security Class Initialized
DEBUG - 2020-08-14 03:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:27:32 --> Input Class Initialized
INFO - 2020-08-14 03:27:32 --> Language Class Initialized
INFO - 2020-08-14 03:27:32 --> Loader Class Initialized
INFO - 2020-08-14 03:27:32 --> Helper loaded: url_helper
INFO - 2020-08-14 03:27:32 --> Database Driver Class Initialized
INFO - 2020-08-14 03:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:27:32 --> Email Class Initialized
INFO - 2020-08-14 03:27:32 --> Controller Class Initialized
DEBUG - 2020-08-14 03:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:27:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:27:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 03:27:32 --> Final output sent to browser
DEBUG - 2020-08-14 03:27:32 --> Total execution time: 0.0228
INFO - 2020-08-14 03:27:36 --> Config Class Initialized
INFO - 2020-08-14 03:27:36 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:27:36 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:27:36 --> Utf8 Class Initialized
INFO - 2020-08-14 03:27:36 --> URI Class Initialized
INFO - 2020-08-14 03:27:36 --> Router Class Initialized
INFO - 2020-08-14 03:27:36 --> Output Class Initialized
INFO - 2020-08-14 03:27:36 --> Security Class Initialized
DEBUG - 2020-08-14 03:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:27:36 --> Input Class Initialized
INFO - 2020-08-14 03:27:36 --> Language Class Initialized
INFO - 2020-08-14 03:27:36 --> Loader Class Initialized
INFO - 2020-08-14 03:27:36 --> Helper loaded: url_helper
INFO - 2020-08-14 03:27:36 --> Database Driver Class Initialized
INFO - 2020-08-14 03:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:27:36 --> Email Class Initialized
INFO - 2020-08-14 03:27:36 --> Controller Class Initialized
DEBUG - 2020-08-14 03:27:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:27:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:27:36 --> Model Class Initialized
INFO - 2020-08-14 03:27:36 --> Model Class Initialized
INFO - 2020-08-14 03:27:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:27:36 --> Final output sent to browser
DEBUG - 2020-08-14 03:27:36 --> Total execution time: 0.0340
INFO - 2020-08-14 03:27:50 --> Config Class Initialized
INFO - 2020-08-14 03:27:50 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:27:50 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:27:50 --> Utf8 Class Initialized
INFO - 2020-08-14 03:27:50 --> URI Class Initialized
INFO - 2020-08-14 03:27:50 --> Router Class Initialized
INFO - 2020-08-14 03:27:50 --> Output Class Initialized
INFO - 2020-08-14 03:27:50 --> Security Class Initialized
DEBUG - 2020-08-14 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:27:50 --> Input Class Initialized
INFO - 2020-08-14 03:27:50 --> Language Class Initialized
INFO - 2020-08-14 03:27:50 --> Loader Class Initialized
INFO - 2020-08-14 03:27:50 --> Helper loaded: url_helper
INFO - 2020-08-14 03:27:50 --> Database Driver Class Initialized
INFO - 2020-08-14 03:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:27:50 --> Email Class Initialized
INFO - 2020-08-14 03:27:50 --> Controller Class Initialized
DEBUG - 2020-08-14 03:27:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:27:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:27:50 --> Model Class Initialized
INFO - 2020-08-14 03:27:50 --> Model Class Initialized
INFO - 2020-08-14 03:27:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-14 03:27:50 --> Final output sent to browser
DEBUG - 2020-08-14 03:27:50 --> Total execution time: 0.0226
INFO - 2020-08-14 03:28:00 --> Config Class Initialized
INFO - 2020-08-14 03:28:00 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:28:00 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:28:00 --> Utf8 Class Initialized
INFO - 2020-08-14 03:28:00 --> URI Class Initialized
INFO - 2020-08-14 03:28:00 --> Router Class Initialized
INFO - 2020-08-14 03:28:00 --> Output Class Initialized
INFO - 2020-08-14 03:28:00 --> Security Class Initialized
DEBUG - 2020-08-14 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:28:00 --> Input Class Initialized
INFO - 2020-08-14 03:28:00 --> Language Class Initialized
INFO - 2020-08-14 03:28:00 --> Loader Class Initialized
INFO - 2020-08-14 03:28:00 --> Helper loaded: url_helper
INFO - 2020-08-14 03:28:00 --> Database Driver Class Initialized
INFO - 2020-08-14 03:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:28:00 --> Email Class Initialized
INFO - 2020-08-14 03:28:00 --> Controller Class Initialized
DEBUG - 2020-08-14 03:28:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:28:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:28:00 --> Model Class Initialized
INFO - 2020-08-14 03:28:00 --> Model Class Initialized
INFO - 2020-08-14 03:28:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:28:00 --> Final output sent to browser
DEBUG - 2020-08-14 03:28:00 --> Total execution time: 0.0255
INFO - 2020-08-14 03:28:24 --> Config Class Initialized
INFO - 2020-08-14 03:28:24 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:28:24 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:28:24 --> Utf8 Class Initialized
INFO - 2020-08-14 03:28:24 --> URI Class Initialized
INFO - 2020-08-14 03:28:24 --> Router Class Initialized
INFO - 2020-08-14 03:28:24 --> Output Class Initialized
INFO - 2020-08-14 03:28:24 --> Security Class Initialized
DEBUG - 2020-08-14 03:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:28:24 --> Input Class Initialized
INFO - 2020-08-14 03:28:24 --> Language Class Initialized
INFO - 2020-08-14 03:28:24 --> Loader Class Initialized
INFO - 2020-08-14 03:28:24 --> Helper loaded: url_helper
INFO - 2020-08-14 03:28:24 --> Database Driver Class Initialized
INFO - 2020-08-14 03:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:28:24 --> Email Class Initialized
INFO - 2020-08-14 03:28:24 --> Controller Class Initialized
DEBUG - 2020-08-14 03:28:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:28:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:28:24 --> Model Class Initialized
INFO - 2020-08-14 03:28:24 --> Model Class Initialized
INFO - 2020-08-14 03:28:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-14 03:28:24 --> Final output sent to browser
DEBUG - 2020-08-14 03:28:24 --> Total execution time: 0.0266
INFO - 2020-08-14 03:28:33 --> Config Class Initialized
INFO - 2020-08-14 03:28:33 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:28:33 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:28:33 --> Utf8 Class Initialized
INFO - 2020-08-14 03:28:33 --> URI Class Initialized
INFO - 2020-08-14 03:28:33 --> Router Class Initialized
INFO - 2020-08-14 03:28:33 --> Output Class Initialized
INFO - 2020-08-14 03:28:33 --> Security Class Initialized
DEBUG - 2020-08-14 03:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:28:33 --> Input Class Initialized
INFO - 2020-08-14 03:28:33 --> Language Class Initialized
INFO - 2020-08-14 03:28:33 --> Loader Class Initialized
INFO - 2020-08-14 03:28:33 --> Helper loaded: url_helper
INFO - 2020-08-14 03:28:33 --> Database Driver Class Initialized
INFO - 2020-08-14 03:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:28:33 --> Email Class Initialized
INFO - 2020-08-14 03:28:33 --> Controller Class Initialized
DEBUG - 2020-08-14 03:28:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:28:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:28:33 --> Model Class Initialized
INFO - 2020-08-14 03:28:33 --> Model Class Initialized
INFO - 2020-08-14 03:28:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:28:33 --> Final output sent to browser
DEBUG - 2020-08-14 03:28:33 --> Total execution time: 0.0307
INFO - 2020-08-14 03:28:36 --> Config Class Initialized
INFO - 2020-08-14 03:28:36 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:28:36 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:28:36 --> Utf8 Class Initialized
INFO - 2020-08-14 03:28:36 --> URI Class Initialized
INFO - 2020-08-14 03:28:36 --> Router Class Initialized
INFO - 2020-08-14 03:28:36 --> Output Class Initialized
INFO - 2020-08-14 03:28:36 --> Security Class Initialized
DEBUG - 2020-08-14 03:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:28:36 --> Input Class Initialized
INFO - 2020-08-14 03:28:36 --> Language Class Initialized
INFO - 2020-08-14 03:28:36 --> Loader Class Initialized
INFO - 2020-08-14 03:28:36 --> Helper loaded: url_helper
INFO - 2020-08-14 03:28:36 --> Database Driver Class Initialized
INFO - 2020-08-14 03:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:28:36 --> Email Class Initialized
INFO - 2020-08-14 03:28:36 --> Controller Class Initialized
DEBUG - 2020-08-14 03:28:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:28:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:28:36 --> Model Class Initialized
INFO - 2020-08-14 03:28:36 --> Model Class Initialized
INFO - 2020-08-14 03:28:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-14 03:28:36 --> Final output sent to browser
DEBUG - 2020-08-14 03:28:36 --> Total execution time: 0.0277
INFO - 2020-08-14 03:28:39 --> Config Class Initialized
INFO - 2020-08-14 03:28:39 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:28:39 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:28:39 --> Utf8 Class Initialized
INFO - 2020-08-14 03:28:39 --> URI Class Initialized
INFO - 2020-08-14 03:28:39 --> Router Class Initialized
INFO - 2020-08-14 03:28:39 --> Output Class Initialized
INFO - 2020-08-14 03:28:39 --> Security Class Initialized
DEBUG - 2020-08-14 03:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:28:39 --> Input Class Initialized
INFO - 2020-08-14 03:28:39 --> Language Class Initialized
INFO - 2020-08-14 03:28:39 --> Loader Class Initialized
INFO - 2020-08-14 03:28:39 --> Helper loaded: url_helper
INFO - 2020-08-14 03:28:39 --> Database Driver Class Initialized
INFO - 2020-08-14 03:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:28:39 --> Email Class Initialized
INFO - 2020-08-14 03:28:39 --> Controller Class Initialized
DEBUG - 2020-08-14 03:28:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:28:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:28:39 --> Model Class Initialized
INFO - 2020-08-14 03:28:39 --> Model Class Initialized
INFO - 2020-08-14 03:28:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:28:39 --> Final output sent to browser
DEBUG - 2020-08-14 03:28:39 --> Total execution time: 0.0261
INFO - 2020-08-14 03:29:02 --> Config Class Initialized
INFO - 2020-08-14 03:29:02 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:29:02 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:29:02 --> Utf8 Class Initialized
INFO - 2020-08-14 03:29:02 --> URI Class Initialized
INFO - 2020-08-14 03:29:02 --> Router Class Initialized
INFO - 2020-08-14 03:29:02 --> Output Class Initialized
INFO - 2020-08-14 03:29:02 --> Security Class Initialized
DEBUG - 2020-08-14 03:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:29:02 --> Input Class Initialized
INFO - 2020-08-14 03:29:02 --> Language Class Initialized
INFO - 2020-08-14 03:29:02 --> Loader Class Initialized
INFO - 2020-08-14 03:29:02 --> Helper loaded: url_helper
INFO - 2020-08-14 03:29:02 --> Database Driver Class Initialized
INFO - 2020-08-14 03:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:29:02 --> Email Class Initialized
INFO - 2020-08-14 03:29:02 --> Controller Class Initialized
DEBUG - 2020-08-14 03:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:29:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:29:02 --> Model Class Initialized
INFO - 2020-08-14 03:29:02 --> Model Class Initialized
INFO - 2020-08-14 03:29:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:29:02 --> Final output sent to browser
DEBUG - 2020-08-14 03:29:02 --> Total execution time: 0.0271
INFO - 2020-08-14 03:32:15 --> Config Class Initialized
INFO - 2020-08-14 03:32:15 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:32:15 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:32:15 --> Utf8 Class Initialized
INFO - 2020-08-14 03:32:15 --> URI Class Initialized
INFO - 2020-08-14 03:32:15 --> Router Class Initialized
INFO - 2020-08-14 03:32:15 --> Output Class Initialized
INFO - 2020-08-14 03:32:15 --> Security Class Initialized
DEBUG - 2020-08-14 03:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:32:15 --> Input Class Initialized
INFO - 2020-08-14 03:32:15 --> Language Class Initialized
INFO - 2020-08-14 03:32:15 --> Loader Class Initialized
INFO - 2020-08-14 03:32:15 --> Helper loaded: url_helper
INFO - 2020-08-14 03:32:15 --> Database Driver Class Initialized
INFO - 2020-08-14 03:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:32:15 --> Email Class Initialized
INFO - 2020-08-14 03:32:15 --> Controller Class Initialized
DEBUG - 2020-08-14 03:32:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:32:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:32:15 --> Model Class Initialized
INFO - 2020-08-14 03:32:15 --> Model Class Initialized
INFO - 2020-08-14 03:32:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-14 03:32:15 --> Final output sent to browser
DEBUG - 2020-08-14 03:32:15 --> Total execution time: 0.0263
INFO - 2020-08-14 03:33:12 --> Config Class Initialized
INFO - 2020-08-14 03:33:12 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:33:12 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:33:12 --> Utf8 Class Initialized
INFO - 2020-08-14 03:33:12 --> URI Class Initialized
INFO - 2020-08-14 03:33:12 --> Router Class Initialized
INFO - 2020-08-14 03:33:12 --> Output Class Initialized
INFO - 2020-08-14 03:33:12 --> Security Class Initialized
DEBUG - 2020-08-14 03:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:33:12 --> Input Class Initialized
INFO - 2020-08-14 03:33:12 --> Language Class Initialized
INFO - 2020-08-14 03:33:12 --> Loader Class Initialized
INFO - 2020-08-14 03:33:12 --> Helper loaded: url_helper
INFO - 2020-08-14 03:33:12 --> Database Driver Class Initialized
INFO - 2020-08-14 03:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:33:12 --> Email Class Initialized
INFO - 2020-08-14 03:33:12 --> Controller Class Initialized
DEBUG - 2020-08-14 03:33:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:33:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:33:12 --> Model Class Initialized
INFO - 2020-08-14 03:33:12 --> Model Class Initialized
INFO - 2020-08-14 03:33:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:33:12 --> Final output sent to browser
DEBUG - 2020-08-14 03:33:12 --> Total execution time: 0.0280
INFO - 2020-08-14 03:33:41 --> Config Class Initialized
INFO - 2020-08-14 03:33:41 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:33:41 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:33:41 --> Utf8 Class Initialized
INFO - 2020-08-14 03:33:41 --> URI Class Initialized
INFO - 2020-08-14 03:33:41 --> Router Class Initialized
INFO - 2020-08-14 03:33:41 --> Output Class Initialized
INFO - 2020-08-14 03:33:41 --> Security Class Initialized
DEBUG - 2020-08-14 03:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:33:41 --> Input Class Initialized
INFO - 2020-08-14 03:33:41 --> Language Class Initialized
INFO - 2020-08-14 03:33:41 --> Loader Class Initialized
INFO - 2020-08-14 03:33:41 --> Helper loaded: url_helper
INFO - 2020-08-14 03:33:41 --> Database Driver Class Initialized
INFO - 2020-08-14 03:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:33:41 --> Email Class Initialized
INFO - 2020-08-14 03:33:41 --> Controller Class Initialized
DEBUG - 2020-08-14 03:33:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:33:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:33:41 --> Model Class Initialized
INFO - 2020-08-14 03:33:41 --> Model Class Initialized
INFO - 2020-08-14 03:33:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-14 03:33:41 --> Final output sent to browser
DEBUG - 2020-08-14 03:33:41 --> Total execution time: 0.0218
INFO - 2020-08-14 03:34:31 --> Config Class Initialized
INFO - 2020-08-14 03:34:31 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:34:31 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:34:31 --> Utf8 Class Initialized
INFO - 2020-08-14 03:34:31 --> URI Class Initialized
INFO - 2020-08-14 03:34:31 --> Router Class Initialized
INFO - 2020-08-14 03:34:31 --> Output Class Initialized
INFO - 2020-08-14 03:34:31 --> Security Class Initialized
DEBUG - 2020-08-14 03:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:34:31 --> Input Class Initialized
INFO - 2020-08-14 03:34:31 --> Language Class Initialized
INFO - 2020-08-14 03:34:31 --> Loader Class Initialized
INFO - 2020-08-14 03:34:31 --> Helper loaded: url_helper
INFO - 2020-08-14 03:34:31 --> Database Driver Class Initialized
INFO - 2020-08-14 03:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:34:31 --> Email Class Initialized
INFO - 2020-08-14 03:34:31 --> Controller Class Initialized
DEBUG - 2020-08-14 03:34:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 03:34:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:34:31 --> Model Class Initialized
INFO - 2020-08-14 03:34:31 --> Model Class Initialized
INFO - 2020-08-14 03:34:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 03:34:31 --> Final output sent to browser
DEBUG - 2020-08-14 03:34:31 --> Total execution time: 0.0260
INFO - 2020-08-14 03:42:28 --> Config Class Initialized
INFO - 2020-08-14 03:42:28 --> Hooks Class Initialized
DEBUG - 2020-08-14 03:42:28 --> UTF-8 Support Enabled
INFO - 2020-08-14 03:42:28 --> Utf8 Class Initialized
INFO - 2020-08-14 03:42:28 --> URI Class Initialized
DEBUG - 2020-08-14 03:42:28 --> No URI present. Default controller set.
INFO - 2020-08-14 03:42:28 --> Router Class Initialized
INFO - 2020-08-14 03:42:28 --> Output Class Initialized
INFO - 2020-08-14 03:42:28 --> Security Class Initialized
DEBUG - 2020-08-14 03:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 03:42:28 --> Input Class Initialized
INFO - 2020-08-14 03:42:28 --> Language Class Initialized
INFO - 2020-08-14 03:42:28 --> Loader Class Initialized
INFO - 2020-08-14 03:42:28 --> Helper loaded: url_helper
INFO - 2020-08-14 03:42:28 --> Database Driver Class Initialized
INFO - 2020-08-14 03:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 03:42:28 --> Email Class Initialized
INFO - 2020-08-14 03:42:28 --> Controller Class Initialized
INFO - 2020-08-14 03:42:28 --> Model Class Initialized
INFO - 2020-08-14 03:42:28 --> Model Class Initialized
DEBUG - 2020-08-14 03:42:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 03:42:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 03:42:28 --> Final output sent to browser
DEBUG - 2020-08-14 03:42:28 --> Total execution time: 0.0205
INFO - 2020-08-14 06:41:56 --> Config Class Initialized
INFO - 2020-08-14 06:41:56 --> Hooks Class Initialized
DEBUG - 2020-08-14 06:41:56 --> UTF-8 Support Enabled
INFO - 2020-08-14 06:41:56 --> Utf8 Class Initialized
INFO - 2020-08-14 06:41:56 --> URI Class Initialized
DEBUG - 2020-08-14 06:41:56 --> No URI present. Default controller set.
INFO - 2020-08-14 06:41:56 --> Router Class Initialized
INFO - 2020-08-14 06:41:56 --> Output Class Initialized
INFO - 2020-08-14 06:41:56 --> Security Class Initialized
DEBUG - 2020-08-14 06:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 06:41:56 --> Input Class Initialized
INFO - 2020-08-14 06:41:56 --> Language Class Initialized
INFO - 2020-08-14 06:41:56 --> Loader Class Initialized
INFO - 2020-08-14 06:41:56 --> Helper loaded: url_helper
INFO - 2020-08-14 06:41:57 --> Database Driver Class Initialized
INFO - 2020-08-14 06:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 06:41:57 --> Email Class Initialized
INFO - 2020-08-14 06:41:57 --> Controller Class Initialized
INFO - 2020-08-14 06:41:57 --> Model Class Initialized
INFO - 2020-08-14 06:41:57 --> Model Class Initialized
DEBUG - 2020-08-14 06:41:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 06:41:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 06:41:57 --> Final output sent to browser
DEBUG - 2020-08-14 06:41:57 --> Total execution time: 0.1594
INFO - 2020-08-14 06:42:00 --> Config Class Initialized
INFO - 2020-08-14 06:42:00 --> Hooks Class Initialized
DEBUG - 2020-08-14 06:42:00 --> UTF-8 Support Enabled
INFO - 2020-08-14 06:42:00 --> Utf8 Class Initialized
INFO - 2020-08-14 06:42:00 --> URI Class Initialized
INFO - 2020-08-14 06:42:00 --> Router Class Initialized
INFO - 2020-08-14 06:42:00 --> Output Class Initialized
INFO - 2020-08-14 06:42:00 --> Security Class Initialized
DEBUG - 2020-08-14 06:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 06:42:00 --> Input Class Initialized
INFO - 2020-08-14 06:42:00 --> Language Class Initialized
INFO - 2020-08-14 06:42:00 --> Loader Class Initialized
INFO - 2020-08-14 06:42:00 --> Helper loaded: url_helper
INFO - 2020-08-14 06:42:00 --> Database Driver Class Initialized
INFO - 2020-08-14 06:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 06:42:00 --> Email Class Initialized
INFO - 2020-08-14 06:42:00 --> Controller Class Initialized
INFO - 2020-08-14 06:42:00 --> Model Class Initialized
INFO - 2020-08-14 06:42:00 --> Model Class Initialized
DEBUG - 2020-08-14 06:42:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 06:42:00 --> Config Class Initialized
INFO - 2020-08-14 06:42:00 --> Hooks Class Initialized
DEBUG - 2020-08-14 06:42:00 --> UTF-8 Support Enabled
INFO - 2020-08-14 06:42:00 --> Utf8 Class Initialized
INFO - 2020-08-14 06:42:00 --> URI Class Initialized
INFO - 2020-08-14 06:42:00 --> Router Class Initialized
INFO - 2020-08-14 06:42:00 --> Output Class Initialized
INFO - 2020-08-14 06:42:00 --> Security Class Initialized
DEBUG - 2020-08-14 06:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 06:42:00 --> Input Class Initialized
INFO - 2020-08-14 06:42:00 --> Language Class Initialized
INFO - 2020-08-14 06:42:00 --> Loader Class Initialized
INFO - 2020-08-14 06:42:00 --> Helper loaded: url_helper
INFO - 2020-08-14 06:42:00 --> Database Driver Class Initialized
INFO - 2020-08-14 06:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 06:42:00 --> Email Class Initialized
INFO - 2020-08-14 06:42:00 --> Controller Class Initialized
INFO - 2020-08-14 06:42:00 --> Model Class Initialized
INFO - 2020-08-14 06:42:00 --> Model Class Initialized
DEBUG - 2020-08-14 06:42:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 06:42:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 06:42:00 --> Model Class Initialized
INFO - 2020-08-14 06:42:00 --> Final output sent to browser
DEBUG - 2020-08-14 06:42:00 --> Total execution time: 0.0372
INFO - 2020-08-14 06:42:00 --> Config Class Initialized
INFO - 2020-08-14 06:42:00 --> Hooks Class Initialized
DEBUG - 2020-08-14 06:42:00 --> UTF-8 Support Enabled
INFO - 2020-08-14 06:42:00 --> Utf8 Class Initialized
INFO - 2020-08-14 06:42:00 --> URI Class Initialized
INFO - 2020-08-14 06:42:00 --> Router Class Initialized
INFO - 2020-08-14 06:42:00 --> Output Class Initialized
INFO - 2020-08-14 06:42:00 --> Security Class Initialized
DEBUG - 2020-08-14 06:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 06:42:00 --> Input Class Initialized
INFO - 2020-08-14 06:42:00 --> Language Class Initialized
INFO - 2020-08-14 06:42:00 --> Loader Class Initialized
INFO - 2020-08-14 06:42:00 --> Helper loaded: url_helper
INFO - 2020-08-14 06:42:00 --> Database Driver Class Initialized
INFO - 2020-08-14 06:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 06:42:00 --> Email Class Initialized
INFO - 2020-08-14 06:42:00 --> Controller Class Initialized
DEBUG - 2020-08-14 06:42:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 06:42:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 06:42:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 06:42:00 --> Final output sent to browser
DEBUG - 2020-08-14 06:42:00 --> Total execution time: 0.0436
INFO - 2020-08-14 06:48:08 --> Config Class Initialized
INFO - 2020-08-14 06:48:08 --> Hooks Class Initialized
DEBUG - 2020-08-14 06:48:08 --> UTF-8 Support Enabled
INFO - 2020-08-14 06:48:08 --> Utf8 Class Initialized
INFO - 2020-08-14 06:48:08 --> URI Class Initialized
INFO - 2020-08-14 06:48:08 --> Router Class Initialized
INFO - 2020-08-14 06:48:08 --> Output Class Initialized
INFO - 2020-08-14 06:48:08 --> Security Class Initialized
DEBUG - 2020-08-14 06:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 06:48:08 --> Input Class Initialized
INFO - 2020-08-14 06:48:08 --> Language Class Initialized
INFO - 2020-08-14 06:48:08 --> Loader Class Initialized
INFO - 2020-08-14 06:48:08 --> Helper loaded: url_helper
INFO - 2020-08-14 06:48:08 --> Database Driver Class Initialized
INFO - 2020-08-14 06:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 06:48:08 --> Email Class Initialized
INFO - 2020-08-14 06:48:08 --> Controller Class Initialized
DEBUG - 2020-08-14 06:48:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 06:48:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 06:48:08 --> Model Class Initialized
INFO - 2020-08-14 06:48:08 --> Model Class Initialized
INFO - 2020-08-14 06:48:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-14 06:48:08 --> Final output sent to browser
DEBUG - 2020-08-14 06:48:08 --> Total execution time: 0.0658
INFO - 2020-08-14 06:48:57 --> Config Class Initialized
INFO - 2020-08-14 06:48:57 --> Hooks Class Initialized
DEBUG - 2020-08-14 06:48:57 --> UTF-8 Support Enabled
INFO - 2020-08-14 06:48:57 --> Utf8 Class Initialized
INFO - 2020-08-14 06:48:57 --> URI Class Initialized
INFO - 2020-08-14 06:48:57 --> Router Class Initialized
INFO - 2020-08-14 06:48:57 --> Output Class Initialized
INFO - 2020-08-14 06:48:57 --> Security Class Initialized
DEBUG - 2020-08-14 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 06:48:57 --> Input Class Initialized
INFO - 2020-08-14 06:48:57 --> Language Class Initialized
INFO - 2020-08-14 06:48:57 --> Loader Class Initialized
INFO - 2020-08-14 06:48:57 --> Helper loaded: url_helper
INFO - 2020-08-14 06:48:57 --> Database Driver Class Initialized
INFO - 2020-08-14 06:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 06:48:57 --> Email Class Initialized
INFO - 2020-08-14 06:48:57 --> Controller Class Initialized
DEBUG - 2020-08-14 06:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 06:48:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 06:48:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 06:48:57 --> Final output sent to browser
DEBUG - 2020-08-14 06:48:57 --> Total execution time: 0.0477
INFO - 2020-08-14 07:01:07 --> Config Class Initialized
INFO - 2020-08-14 07:01:07 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:01:07 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:01:07 --> Utf8 Class Initialized
INFO - 2020-08-14 07:01:07 --> URI Class Initialized
INFO - 2020-08-14 07:01:07 --> Router Class Initialized
INFO - 2020-08-14 07:01:07 --> Output Class Initialized
INFO - 2020-08-14 07:01:07 --> Security Class Initialized
DEBUG - 2020-08-14 07:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:01:07 --> Input Class Initialized
INFO - 2020-08-14 07:01:07 --> Language Class Initialized
INFO - 2020-08-14 07:01:07 --> Loader Class Initialized
INFO - 2020-08-14 07:01:07 --> Helper loaded: url_helper
INFO - 2020-08-14 07:01:07 --> Database Driver Class Initialized
INFO - 2020-08-14 07:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:01:07 --> Email Class Initialized
INFO - 2020-08-14 07:01:07 --> Controller Class Initialized
DEBUG - 2020-08-14 07:01:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:01:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:01:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:01:07 --> Final output sent to browser
DEBUG - 2020-08-14 07:01:07 --> Total execution time: 0.0386
INFO - 2020-08-14 07:02:24 --> Config Class Initialized
INFO - 2020-08-14 07:02:24 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:02:24 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:02:24 --> Utf8 Class Initialized
INFO - 2020-08-14 07:02:24 --> URI Class Initialized
INFO - 2020-08-14 07:02:24 --> Router Class Initialized
INFO - 2020-08-14 07:02:24 --> Output Class Initialized
INFO - 2020-08-14 07:02:24 --> Security Class Initialized
DEBUG - 2020-08-14 07:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:02:24 --> Input Class Initialized
INFO - 2020-08-14 07:02:24 --> Language Class Initialized
INFO - 2020-08-14 07:02:24 --> Loader Class Initialized
INFO - 2020-08-14 07:02:24 --> Helper loaded: url_helper
INFO - 2020-08-14 07:02:24 --> Database Driver Class Initialized
INFO - 2020-08-14 07:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:02:24 --> Email Class Initialized
INFO - 2020-08-14 07:02:24 --> Controller Class Initialized
DEBUG - 2020-08-14 07:02:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:02:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:02:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:02:24 --> Final output sent to browser
DEBUG - 2020-08-14 07:02:24 --> Total execution time: 0.0223
INFO - 2020-08-14 07:03:13 --> Config Class Initialized
INFO - 2020-08-14 07:03:13 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:03:13 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:03:13 --> Utf8 Class Initialized
INFO - 2020-08-14 07:03:13 --> URI Class Initialized
INFO - 2020-08-14 07:03:13 --> Router Class Initialized
INFO - 2020-08-14 07:03:13 --> Output Class Initialized
INFO - 2020-08-14 07:03:13 --> Security Class Initialized
DEBUG - 2020-08-14 07:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:03:13 --> Input Class Initialized
INFO - 2020-08-14 07:03:13 --> Language Class Initialized
INFO - 2020-08-14 07:03:13 --> Loader Class Initialized
INFO - 2020-08-14 07:03:13 --> Helper loaded: url_helper
INFO - 2020-08-14 07:03:13 --> Database Driver Class Initialized
INFO - 2020-08-14 07:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:03:13 --> Email Class Initialized
INFO - 2020-08-14 07:03:13 --> Controller Class Initialized
DEBUG - 2020-08-14 07:03:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:03:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:03:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:03:13 --> Final output sent to browser
DEBUG - 2020-08-14 07:03:13 --> Total execution time: 0.0213
INFO - 2020-08-14 07:04:18 --> Config Class Initialized
INFO - 2020-08-14 07:04:18 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:04:18 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:04:18 --> Utf8 Class Initialized
INFO - 2020-08-14 07:04:18 --> URI Class Initialized
INFO - 2020-08-14 07:04:18 --> Router Class Initialized
INFO - 2020-08-14 07:04:18 --> Output Class Initialized
INFO - 2020-08-14 07:04:18 --> Security Class Initialized
DEBUG - 2020-08-14 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:04:18 --> Input Class Initialized
INFO - 2020-08-14 07:04:18 --> Language Class Initialized
INFO - 2020-08-14 07:04:18 --> Loader Class Initialized
INFO - 2020-08-14 07:04:18 --> Helper loaded: url_helper
INFO - 2020-08-14 07:04:18 --> Database Driver Class Initialized
INFO - 2020-08-14 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:04:18 --> Email Class Initialized
INFO - 2020-08-14 07:04:18 --> Controller Class Initialized
DEBUG - 2020-08-14 07:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:04:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:04:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:04:18 --> Final output sent to browser
DEBUG - 2020-08-14 07:04:18 --> Total execution time: 0.0199
INFO - 2020-08-14 07:05:28 --> Config Class Initialized
INFO - 2020-08-14 07:05:28 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:05:28 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:05:28 --> Utf8 Class Initialized
INFO - 2020-08-14 07:05:28 --> URI Class Initialized
INFO - 2020-08-14 07:05:28 --> Router Class Initialized
INFO - 2020-08-14 07:05:28 --> Output Class Initialized
INFO - 2020-08-14 07:05:28 --> Security Class Initialized
DEBUG - 2020-08-14 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:05:28 --> Input Class Initialized
INFO - 2020-08-14 07:05:28 --> Language Class Initialized
INFO - 2020-08-14 07:05:28 --> Loader Class Initialized
INFO - 2020-08-14 07:05:28 --> Helper loaded: url_helper
INFO - 2020-08-14 07:05:28 --> Database Driver Class Initialized
INFO - 2020-08-14 07:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:05:28 --> Email Class Initialized
INFO - 2020-08-14 07:05:28 --> Controller Class Initialized
DEBUG - 2020-08-14 07:05:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:05:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:05:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:05:28 --> Final output sent to browser
DEBUG - 2020-08-14 07:05:28 --> Total execution time: 0.0341
INFO - 2020-08-14 07:11:04 --> Config Class Initialized
INFO - 2020-08-14 07:11:04 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:11:04 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:11:04 --> Utf8 Class Initialized
INFO - 2020-08-14 07:11:04 --> URI Class Initialized
INFO - 2020-08-14 07:11:04 --> Router Class Initialized
INFO - 2020-08-14 07:11:04 --> Output Class Initialized
INFO - 2020-08-14 07:11:04 --> Security Class Initialized
DEBUG - 2020-08-14 07:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:11:04 --> Input Class Initialized
INFO - 2020-08-14 07:11:04 --> Language Class Initialized
INFO - 2020-08-14 07:11:04 --> Loader Class Initialized
INFO - 2020-08-14 07:11:04 --> Helper loaded: url_helper
INFO - 2020-08-14 07:11:04 --> Database Driver Class Initialized
INFO - 2020-08-14 07:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:11:04 --> Email Class Initialized
INFO - 2020-08-14 07:11:04 --> Controller Class Initialized
DEBUG - 2020-08-14 07:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:11:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:11:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:11:04 --> Final output sent to browser
DEBUG - 2020-08-14 07:11:04 --> Total execution time: 0.0195
INFO - 2020-08-14 07:12:30 --> Config Class Initialized
INFO - 2020-08-14 07:12:30 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:12:30 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:12:30 --> Utf8 Class Initialized
INFO - 2020-08-14 07:12:30 --> URI Class Initialized
INFO - 2020-08-14 07:12:30 --> Router Class Initialized
INFO - 2020-08-14 07:12:30 --> Output Class Initialized
INFO - 2020-08-14 07:12:30 --> Security Class Initialized
DEBUG - 2020-08-14 07:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:12:30 --> Input Class Initialized
INFO - 2020-08-14 07:12:30 --> Language Class Initialized
INFO - 2020-08-14 07:12:30 --> Loader Class Initialized
INFO - 2020-08-14 07:12:30 --> Helper loaded: url_helper
INFO - 2020-08-14 07:12:30 --> Database Driver Class Initialized
INFO - 2020-08-14 07:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:12:30 --> Email Class Initialized
INFO - 2020-08-14 07:12:30 --> Controller Class Initialized
DEBUG - 2020-08-14 07:12:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:12:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:12:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:12:30 --> Final output sent to browser
DEBUG - 2020-08-14 07:12:30 --> Total execution time: 0.0235
INFO - 2020-08-14 07:13:42 --> Config Class Initialized
INFO - 2020-08-14 07:13:42 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:13:42 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:13:42 --> Utf8 Class Initialized
INFO - 2020-08-14 07:13:42 --> URI Class Initialized
INFO - 2020-08-14 07:13:42 --> Router Class Initialized
INFO - 2020-08-14 07:13:42 --> Output Class Initialized
INFO - 2020-08-14 07:13:42 --> Security Class Initialized
DEBUG - 2020-08-14 07:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:13:42 --> Input Class Initialized
INFO - 2020-08-14 07:13:42 --> Language Class Initialized
INFO - 2020-08-14 07:13:42 --> Loader Class Initialized
INFO - 2020-08-14 07:13:42 --> Helper loaded: url_helper
INFO - 2020-08-14 07:13:42 --> Database Driver Class Initialized
INFO - 2020-08-14 07:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:13:42 --> Email Class Initialized
INFO - 2020-08-14 07:13:42 --> Controller Class Initialized
DEBUG - 2020-08-14 07:13:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:13:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:13:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:13:42 --> Final output sent to browser
DEBUG - 2020-08-14 07:13:42 --> Total execution time: 0.0237
INFO - 2020-08-14 07:15:37 --> Config Class Initialized
INFO - 2020-08-14 07:15:37 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:15:37 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:15:37 --> Utf8 Class Initialized
INFO - 2020-08-14 07:15:37 --> URI Class Initialized
INFO - 2020-08-14 07:15:37 --> Router Class Initialized
INFO - 2020-08-14 07:15:37 --> Output Class Initialized
INFO - 2020-08-14 07:15:37 --> Security Class Initialized
DEBUG - 2020-08-14 07:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:15:37 --> Input Class Initialized
INFO - 2020-08-14 07:15:37 --> Language Class Initialized
INFO - 2020-08-14 07:15:37 --> Loader Class Initialized
INFO - 2020-08-14 07:15:37 --> Helper loaded: url_helper
INFO - 2020-08-14 07:15:37 --> Database Driver Class Initialized
INFO - 2020-08-14 07:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:15:37 --> Email Class Initialized
INFO - 2020-08-14 07:15:37 --> Controller Class Initialized
DEBUG - 2020-08-14 07:15:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:15:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:15:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:15:37 --> Final output sent to browser
DEBUG - 2020-08-14 07:15:37 --> Total execution time: 0.0236
INFO - 2020-08-14 07:16:06 --> Config Class Initialized
INFO - 2020-08-14 07:16:06 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:16:06 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:16:06 --> Utf8 Class Initialized
INFO - 2020-08-14 07:16:06 --> URI Class Initialized
INFO - 2020-08-14 07:16:06 --> Router Class Initialized
INFO - 2020-08-14 07:16:06 --> Output Class Initialized
INFO - 2020-08-14 07:16:06 --> Security Class Initialized
DEBUG - 2020-08-14 07:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:16:06 --> Input Class Initialized
INFO - 2020-08-14 07:16:06 --> Language Class Initialized
INFO - 2020-08-14 07:16:06 --> Loader Class Initialized
INFO - 2020-08-14 07:16:06 --> Helper loaded: url_helper
INFO - 2020-08-14 07:16:06 --> Database Driver Class Initialized
INFO - 2020-08-14 07:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:16:06 --> Email Class Initialized
INFO - 2020-08-14 07:16:06 --> Controller Class Initialized
DEBUG - 2020-08-14 07:16:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:16:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:16:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:16:06 --> Final output sent to browser
DEBUG - 2020-08-14 07:16:06 --> Total execution time: 0.0206
INFO - 2020-08-14 07:16:31 --> Config Class Initialized
INFO - 2020-08-14 07:16:31 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:16:31 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:16:31 --> Utf8 Class Initialized
INFO - 2020-08-14 07:16:31 --> URI Class Initialized
INFO - 2020-08-14 07:16:31 --> Router Class Initialized
INFO - 2020-08-14 07:16:31 --> Output Class Initialized
INFO - 2020-08-14 07:16:31 --> Security Class Initialized
DEBUG - 2020-08-14 07:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:16:31 --> Input Class Initialized
INFO - 2020-08-14 07:16:31 --> Language Class Initialized
INFO - 2020-08-14 07:16:31 --> Loader Class Initialized
INFO - 2020-08-14 07:16:31 --> Helper loaded: url_helper
INFO - 2020-08-14 07:16:31 --> Database Driver Class Initialized
INFO - 2020-08-14 07:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:16:31 --> Email Class Initialized
INFO - 2020-08-14 07:16:31 --> Controller Class Initialized
DEBUG - 2020-08-14 07:16:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:16:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:16:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:16:31 --> Final output sent to browser
DEBUG - 2020-08-14 07:16:31 --> Total execution time: 0.0200
INFO - 2020-08-14 07:50:42 --> Config Class Initialized
INFO - 2020-08-14 07:50:42 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:50:42 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:50:42 --> Utf8 Class Initialized
INFO - 2020-08-14 07:50:42 --> URI Class Initialized
DEBUG - 2020-08-14 07:50:42 --> No URI present. Default controller set.
INFO - 2020-08-14 07:50:42 --> Router Class Initialized
INFO - 2020-08-14 07:50:42 --> Output Class Initialized
INFO - 2020-08-14 07:50:42 --> Security Class Initialized
DEBUG - 2020-08-14 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:50:42 --> Input Class Initialized
INFO - 2020-08-14 07:50:42 --> Language Class Initialized
INFO - 2020-08-14 07:50:42 --> Loader Class Initialized
INFO - 2020-08-14 07:50:42 --> Helper loaded: url_helper
INFO - 2020-08-14 07:50:42 --> Database Driver Class Initialized
INFO - 2020-08-14 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:50:42 --> Email Class Initialized
INFO - 2020-08-14 07:50:42 --> Controller Class Initialized
INFO - 2020-08-14 07:50:42 --> Model Class Initialized
INFO - 2020-08-14 07:50:42 --> Model Class Initialized
DEBUG - 2020-08-14 07:50:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:50:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 07:50:42 --> Final output sent to browser
DEBUG - 2020-08-14 07:50:42 --> Total execution time: 0.0239
INFO - 2020-08-14 07:52:14 --> Config Class Initialized
INFO - 2020-08-14 07:52:14 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:52:14 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:52:14 --> Utf8 Class Initialized
INFO - 2020-08-14 07:52:14 --> URI Class Initialized
INFO - 2020-08-14 07:52:14 --> Router Class Initialized
INFO - 2020-08-14 07:52:14 --> Output Class Initialized
INFO - 2020-08-14 07:52:14 --> Security Class Initialized
DEBUG - 2020-08-14 07:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:52:14 --> Input Class Initialized
INFO - 2020-08-14 07:52:14 --> Language Class Initialized
INFO - 2020-08-14 07:52:14 --> Loader Class Initialized
INFO - 2020-08-14 07:52:14 --> Helper loaded: url_helper
INFO - 2020-08-14 07:52:14 --> Database Driver Class Initialized
INFO - 2020-08-14 07:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:52:14 --> Email Class Initialized
INFO - 2020-08-14 07:52:14 --> Controller Class Initialized
INFO - 2020-08-14 07:52:14 --> Model Class Initialized
INFO - 2020-08-14 07:52:14 --> Model Class Initialized
DEBUG - 2020-08-14 07:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:52:14 --> Config Class Initialized
INFO - 2020-08-14 07:52:14 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:52:14 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:52:14 --> Utf8 Class Initialized
INFO - 2020-08-14 07:52:14 --> URI Class Initialized
INFO - 2020-08-14 07:52:14 --> Router Class Initialized
INFO - 2020-08-14 07:52:14 --> Output Class Initialized
INFO - 2020-08-14 07:52:14 --> Security Class Initialized
DEBUG - 2020-08-14 07:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:52:14 --> Input Class Initialized
INFO - 2020-08-14 07:52:14 --> Language Class Initialized
INFO - 2020-08-14 07:52:14 --> Loader Class Initialized
INFO - 2020-08-14 07:52:14 --> Helper loaded: url_helper
INFO - 2020-08-14 07:52:14 --> Database Driver Class Initialized
INFO - 2020-08-14 07:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:52:14 --> Email Class Initialized
INFO - 2020-08-14 07:52:14 --> Controller Class Initialized
INFO - 2020-08-14 07:52:14 --> Model Class Initialized
INFO - 2020-08-14 07:52:14 --> Model Class Initialized
DEBUG - 2020-08-14 07:52:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:52:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:52:14 --> Model Class Initialized
INFO - 2020-08-14 07:52:14 --> Final output sent to browser
DEBUG - 2020-08-14 07:52:14 --> Total execution time: 0.0302
INFO - 2020-08-14 07:52:15 --> Config Class Initialized
INFO - 2020-08-14 07:52:15 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:52:15 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:52:15 --> Utf8 Class Initialized
INFO - 2020-08-14 07:52:15 --> URI Class Initialized
INFO - 2020-08-14 07:52:15 --> Router Class Initialized
INFO - 2020-08-14 07:52:15 --> Output Class Initialized
INFO - 2020-08-14 07:52:15 --> Security Class Initialized
DEBUG - 2020-08-14 07:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:52:15 --> Input Class Initialized
INFO - 2020-08-14 07:52:15 --> Language Class Initialized
INFO - 2020-08-14 07:52:15 --> Loader Class Initialized
INFO - 2020-08-14 07:52:15 --> Helper loaded: url_helper
INFO - 2020-08-14 07:52:15 --> Database Driver Class Initialized
INFO - 2020-08-14 07:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:52:15 --> Email Class Initialized
INFO - 2020-08-14 07:52:15 --> Controller Class Initialized
DEBUG - 2020-08-14 07:52:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:52:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:52:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:52:15 --> Final output sent to browser
DEBUG - 2020-08-14 07:52:15 --> Total execution time: 0.0190
INFO - 2020-08-14 07:54:29 --> Config Class Initialized
INFO - 2020-08-14 07:54:29 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:54:29 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:54:29 --> Utf8 Class Initialized
INFO - 2020-08-14 07:54:29 --> URI Class Initialized
INFO - 2020-08-14 07:54:29 --> Router Class Initialized
INFO - 2020-08-14 07:54:29 --> Output Class Initialized
INFO - 2020-08-14 07:54:29 --> Security Class Initialized
DEBUG - 2020-08-14 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:54:29 --> Input Class Initialized
INFO - 2020-08-14 07:54:29 --> Language Class Initialized
INFO - 2020-08-14 07:54:29 --> Loader Class Initialized
INFO - 2020-08-14 07:54:29 --> Helper loaded: url_helper
INFO - 2020-08-14 07:54:29 --> Database Driver Class Initialized
INFO - 2020-08-14 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:54:29 --> Email Class Initialized
INFO - 2020-08-14 07:54:29 --> Controller Class Initialized
DEBUG - 2020-08-14 07:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:54:29 --> Final output sent to browser
DEBUG - 2020-08-14 07:54:29 --> Total execution time: 0.0243
INFO - 2020-08-14 07:54:49 --> Config Class Initialized
INFO - 2020-08-14 07:54:49 --> Hooks Class Initialized
DEBUG - 2020-08-14 07:54:49 --> UTF-8 Support Enabled
INFO - 2020-08-14 07:54:49 --> Utf8 Class Initialized
INFO - 2020-08-14 07:54:49 --> URI Class Initialized
INFO - 2020-08-14 07:54:49 --> Router Class Initialized
INFO - 2020-08-14 07:54:49 --> Output Class Initialized
INFO - 2020-08-14 07:54:49 --> Security Class Initialized
DEBUG - 2020-08-14 07:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 07:54:49 --> Input Class Initialized
INFO - 2020-08-14 07:54:49 --> Language Class Initialized
INFO - 2020-08-14 07:54:49 --> Loader Class Initialized
INFO - 2020-08-14 07:54:49 --> Helper loaded: url_helper
INFO - 2020-08-14 07:54:49 --> Database Driver Class Initialized
INFO - 2020-08-14 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 07:54:49 --> Email Class Initialized
INFO - 2020-08-14 07:54:49 --> Controller Class Initialized
DEBUG - 2020-08-14 07:54:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 07:54:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 07:54:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 07:54:49 --> Final output sent to browser
DEBUG - 2020-08-14 07:54:49 --> Total execution time: 0.0245
INFO - 2020-08-14 08:05:59 --> Config Class Initialized
INFO - 2020-08-14 08:05:59 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:05:59 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:05:59 --> Utf8 Class Initialized
INFO - 2020-08-14 08:05:59 --> URI Class Initialized
INFO - 2020-08-14 08:05:59 --> Router Class Initialized
INFO - 2020-08-14 08:05:59 --> Output Class Initialized
INFO - 2020-08-14 08:05:59 --> Security Class Initialized
DEBUG - 2020-08-14 08:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:05:59 --> Input Class Initialized
INFO - 2020-08-14 08:05:59 --> Language Class Initialized
INFO - 2020-08-14 08:05:59 --> Loader Class Initialized
INFO - 2020-08-14 08:05:59 --> Helper loaded: url_helper
INFO - 2020-08-14 08:05:59 --> Database Driver Class Initialized
INFO - 2020-08-14 08:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:05:59 --> Email Class Initialized
INFO - 2020-08-14 08:05:59 --> Controller Class Initialized
DEBUG - 2020-08-14 08:05:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:05:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:05:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:05:59 --> Final output sent to browser
DEBUG - 2020-08-14 08:05:59 --> Total execution time: 0.0211
INFO - 2020-08-14 08:08:04 --> Config Class Initialized
INFO - 2020-08-14 08:08:04 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:08:04 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:08:04 --> Utf8 Class Initialized
INFO - 2020-08-14 08:08:04 --> URI Class Initialized
INFO - 2020-08-14 08:08:04 --> Router Class Initialized
INFO - 2020-08-14 08:08:04 --> Output Class Initialized
INFO - 2020-08-14 08:08:04 --> Security Class Initialized
DEBUG - 2020-08-14 08:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:08:04 --> Input Class Initialized
INFO - 2020-08-14 08:08:04 --> Language Class Initialized
INFO - 2020-08-14 08:08:04 --> Loader Class Initialized
INFO - 2020-08-14 08:08:04 --> Helper loaded: url_helper
INFO - 2020-08-14 08:08:04 --> Database Driver Class Initialized
INFO - 2020-08-14 08:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:08:04 --> Email Class Initialized
INFO - 2020-08-14 08:08:04 --> Controller Class Initialized
DEBUG - 2020-08-14 08:08:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:08:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:08:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:08:04 --> Final output sent to browser
DEBUG - 2020-08-14 08:08:04 --> Total execution time: 0.0315
INFO - 2020-08-14 08:12:49 --> Config Class Initialized
INFO - 2020-08-14 08:12:49 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:12:49 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:12:49 --> Utf8 Class Initialized
INFO - 2020-08-14 08:12:49 --> URI Class Initialized
INFO - 2020-08-14 08:12:49 --> Router Class Initialized
INFO - 2020-08-14 08:12:49 --> Output Class Initialized
INFO - 2020-08-14 08:12:49 --> Security Class Initialized
DEBUG - 2020-08-14 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:12:49 --> Input Class Initialized
INFO - 2020-08-14 08:12:49 --> Language Class Initialized
INFO - 2020-08-14 08:12:49 --> Loader Class Initialized
INFO - 2020-08-14 08:12:49 --> Helper loaded: url_helper
INFO - 2020-08-14 08:12:49 --> Database Driver Class Initialized
INFO - 2020-08-14 08:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:12:49 --> Email Class Initialized
INFO - 2020-08-14 08:12:49 --> Controller Class Initialized
DEBUG - 2020-08-14 08:12:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:12:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:12:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:12:49 --> Final output sent to browser
DEBUG - 2020-08-14 08:12:49 --> Total execution time: 0.0207
INFO - 2020-08-14 08:13:21 --> Config Class Initialized
INFO - 2020-08-14 08:13:21 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:13:21 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:13:21 --> Utf8 Class Initialized
INFO - 2020-08-14 08:13:21 --> URI Class Initialized
INFO - 2020-08-14 08:13:21 --> Router Class Initialized
INFO - 2020-08-14 08:13:21 --> Output Class Initialized
INFO - 2020-08-14 08:13:21 --> Security Class Initialized
DEBUG - 2020-08-14 08:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:13:21 --> Input Class Initialized
INFO - 2020-08-14 08:13:21 --> Language Class Initialized
INFO - 2020-08-14 08:13:21 --> Loader Class Initialized
INFO - 2020-08-14 08:13:21 --> Helper loaded: url_helper
INFO - 2020-08-14 08:13:21 --> Database Driver Class Initialized
INFO - 2020-08-14 08:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:13:21 --> Email Class Initialized
INFO - 2020-08-14 08:13:21 --> Controller Class Initialized
DEBUG - 2020-08-14 08:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:13:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:13:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:13:21 --> Final output sent to browser
DEBUG - 2020-08-14 08:13:21 --> Total execution time: 0.0216
INFO - 2020-08-14 08:14:58 --> Config Class Initialized
INFO - 2020-08-14 08:14:58 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:14:58 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:14:58 --> Utf8 Class Initialized
INFO - 2020-08-14 08:14:58 --> URI Class Initialized
INFO - 2020-08-14 08:14:58 --> Router Class Initialized
INFO - 2020-08-14 08:14:58 --> Output Class Initialized
INFO - 2020-08-14 08:14:58 --> Security Class Initialized
DEBUG - 2020-08-14 08:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:14:58 --> Input Class Initialized
INFO - 2020-08-14 08:14:58 --> Language Class Initialized
INFO - 2020-08-14 08:14:58 --> Loader Class Initialized
INFO - 2020-08-14 08:14:58 --> Helper loaded: url_helper
INFO - 2020-08-14 08:14:58 --> Database Driver Class Initialized
INFO - 2020-08-14 08:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:14:58 --> Email Class Initialized
INFO - 2020-08-14 08:14:58 --> Controller Class Initialized
DEBUG - 2020-08-14 08:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:14:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:14:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:14:58 --> Final output sent to browser
DEBUG - 2020-08-14 08:14:58 --> Total execution time: 0.0294
INFO - 2020-08-14 08:15:16 --> Config Class Initialized
INFO - 2020-08-14 08:15:16 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:15:16 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:15:16 --> Utf8 Class Initialized
INFO - 2020-08-14 08:15:16 --> URI Class Initialized
INFO - 2020-08-14 08:15:16 --> Router Class Initialized
INFO - 2020-08-14 08:15:16 --> Output Class Initialized
INFO - 2020-08-14 08:15:16 --> Security Class Initialized
DEBUG - 2020-08-14 08:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:15:16 --> Input Class Initialized
INFO - 2020-08-14 08:15:16 --> Language Class Initialized
INFO - 2020-08-14 08:15:16 --> Loader Class Initialized
INFO - 2020-08-14 08:15:16 --> Helper loaded: url_helper
INFO - 2020-08-14 08:15:16 --> Database Driver Class Initialized
INFO - 2020-08-14 08:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:15:16 --> Email Class Initialized
INFO - 2020-08-14 08:15:16 --> Controller Class Initialized
DEBUG - 2020-08-14 08:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:15:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:15:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:15:16 --> Final output sent to browser
DEBUG - 2020-08-14 08:15:16 --> Total execution time: 0.0220
INFO - 2020-08-14 08:15:56 --> Config Class Initialized
INFO - 2020-08-14 08:15:56 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:15:56 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:15:56 --> Utf8 Class Initialized
INFO - 2020-08-14 08:15:56 --> URI Class Initialized
INFO - 2020-08-14 08:15:56 --> Router Class Initialized
INFO - 2020-08-14 08:15:56 --> Output Class Initialized
INFO - 2020-08-14 08:15:56 --> Security Class Initialized
DEBUG - 2020-08-14 08:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:15:56 --> Input Class Initialized
INFO - 2020-08-14 08:15:56 --> Language Class Initialized
INFO - 2020-08-14 08:15:56 --> Loader Class Initialized
INFO - 2020-08-14 08:15:56 --> Helper loaded: url_helper
INFO - 2020-08-14 08:15:56 --> Database Driver Class Initialized
INFO - 2020-08-14 08:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:15:56 --> Email Class Initialized
INFO - 2020-08-14 08:15:56 --> Controller Class Initialized
DEBUG - 2020-08-14 08:15:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:15:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:15:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:15:56 --> Final output sent to browser
DEBUG - 2020-08-14 08:15:56 --> Total execution time: 0.0190
INFO - 2020-08-14 08:17:22 --> Config Class Initialized
INFO - 2020-08-14 08:17:22 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:17:22 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:17:22 --> Utf8 Class Initialized
INFO - 2020-08-14 08:17:22 --> URI Class Initialized
INFO - 2020-08-14 08:17:22 --> Router Class Initialized
INFO - 2020-08-14 08:17:22 --> Output Class Initialized
INFO - 2020-08-14 08:17:22 --> Security Class Initialized
DEBUG - 2020-08-14 08:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:17:22 --> Input Class Initialized
INFO - 2020-08-14 08:17:22 --> Language Class Initialized
INFO - 2020-08-14 08:17:22 --> Loader Class Initialized
INFO - 2020-08-14 08:17:22 --> Helper loaded: url_helper
INFO - 2020-08-14 08:17:22 --> Database Driver Class Initialized
INFO - 2020-08-14 08:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:17:22 --> Email Class Initialized
INFO - 2020-08-14 08:17:22 --> Controller Class Initialized
DEBUG - 2020-08-14 08:17:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:17:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:17:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:17:22 --> Final output sent to browser
DEBUG - 2020-08-14 08:17:22 --> Total execution time: 0.0239
INFO - 2020-08-14 08:17:57 --> Config Class Initialized
INFO - 2020-08-14 08:17:57 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:17:57 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:17:57 --> Utf8 Class Initialized
INFO - 2020-08-14 08:17:57 --> URI Class Initialized
INFO - 2020-08-14 08:17:57 --> Router Class Initialized
INFO - 2020-08-14 08:17:57 --> Output Class Initialized
INFO - 2020-08-14 08:17:57 --> Security Class Initialized
DEBUG - 2020-08-14 08:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:17:57 --> Input Class Initialized
INFO - 2020-08-14 08:17:57 --> Language Class Initialized
INFO - 2020-08-14 08:17:57 --> Loader Class Initialized
INFO - 2020-08-14 08:17:57 --> Helper loaded: url_helper
INFO - 2020-08-14 08:17:57 --> Database Driver Class Initialized
INFO - 2020-08-14 08:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:17:57 --> Email Class Initialized
INFO - 2020-08-14 08:17:57 --> Controller Class Initialized
DEBUG - 2020-08-14 08:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:17:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:17:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:17:57 --> Final output sent to browser
DEBUG - 2020-08-14 08:17:57 --> Total execution time: 0.0234
INFO - 2020-08-14 08:18:14 --> Config Class Initialized
INFO - 2020-08-14 08:18:14 --> Hooks Class Initialized
DEBUG - 2020-08-14 08:18:14 --> UTF-8 Support Enabled
INFO - 2020-08-14 08:18:14 --> Utf8 Class Initialized
INFO - 2020-08-14 08:18:14 --> URI Class Initialized
INFO - 2020-08-14 08:18:14 --> Router Class Initialized
INFO - 2020-08-14 08:18:14 --> Output Class Initialized
INFO - 2020-08-14 08:18:14 --> Security Class Initialized
DEBUG - 2020-08-14 08:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 08:18:14 --> Input Class Initialized
INFO - 2020-08-14 08:18:14 --> Language Class Initialized
INFO - 2020-08-14 08:18:14 --> Loader Class Initialized
INFO - 2020-08-14 08:18:14 --> Helper loaded: url_helper
INFO - 2020-08-14 08:18:14 --> Database Driver Class Initialized
INFO - 2020-08-14 08:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 08:18:14 --> Email Class Initialized
INFO - 2020-08-14 08:18:14 --> Controller Class Initialized
DEBUG - 2020-08-14 08:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-14 08:18:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-14 08:18:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-14 08:18:14 --> Final output sent to browser
DEBUG - 2020-08-14 08:18:14 --> Total execution time: 0.0226
INFO - 2020-08-14 10:13:41 --> Config Class Initialized
INFO - 2020-08-14 10:13:41 --> Hooks Class Initialized
DEBUG - 2020-08-14 10:13:41 --> UTF-8 Support Enabled
INFO - 2020-08-14 10:13:41 --> Utf8 Class Initialized
INFO - 2020-08-14 10:13:41 --> URI Class Initialized
DEBUG - 2020-08-14 10:13:41 --> No URI present. Default controller set.
INFO - 2020-08-14 10:13:41 --> Router Class Initialized
INFO - 2020-08-14 10:13:41 --> Output Class Initialized
INFO - 2020-08-14 10:13:41 --> Security Class Initialized
DEBUG - 2020-08-14 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 10:13:41 --> Input Class Initialized
INFO - 2020-08-14 10:13:41 --> Language Class Initialized
INFO - 2020-08-14 10:13:41 --> Loader Class Initialized
INFO - 2020-08-14 10:13:41 --> Helper loaded: url_helper
INFO - 2020-08-14 10:13:41 --> Database Driver Class Initialized
INFO - 2020-08-14 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 10:13:41 --> Email Class Initialized
INFO - 2020-08-14 10:13:41 --> Controller Class Initialized
INFO - 2020-08-14 10:13:41 --> Model Class Initialized
INFO - 2020-08-14 10:13:41 --> Model Class Initialized
DEBUG - 2020-08-14 10:13:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 10:13:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 10:13:41 --> Final output sent to browser
DEBUG - 2020-08-14 10:13:41 --> Total execution time: 0.1464
INFO - 2020-08-14 10:13:44 --> Config Class Initialized
INFO - 2020-08-14 10:13:44 --> Hooks Class Initialized
DEBUG - 2020-08-14 10:13:44 --> UTF-8 Support Enabled
INFO - 2020-08-14 10:13:44 --> Utf8 Class Initialized
INFO - 2020-08-14 10:13:44 --> URI Class Initialized
DEBUG - 2020-08-14 10:13:44 --> No URI present. Default controller set.
INFO - 2020-08-14 10:13:44 --> Router Class Initialized
INFO - 2020-08-14 10:13:44 --> Output Class Initialized
INFO - 2020-08-14 10:13:44 --> Security Class Initialized
DEBUG - 2020-08-14 10:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-14 10:13:44 --> Input Class Initialized
INFO - 2020-08-14 10:13:44 --> Language Class Initialized
INFO - 2020-08-14 10:13:44 --> Loader Class Initialized
INFO - 2020-08-14 10:13:44 --> Helper loaded: url_helper
INFO - 2020-08-14 10:13:45 --> Database Driver Class Initialized
INFO - 2020-08-14 10:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-14 10:13:45 --> Email Class Initialized
INFO - 2020-08-14 10:13:45 --> Controller Class Initialized
INFO - 2020-08-14 10:13:45 --> Model Class Initialized
INFO - 2020-08-14 10:13:45 --> Model Class Initialized
DEBUG - 2020-08-14 10:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-14 10:13:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-14 10:13:45 --> Final output sent to browser
DEBUG - 2020-08-14 10:13:45 --> Total execution time: 0.0237
