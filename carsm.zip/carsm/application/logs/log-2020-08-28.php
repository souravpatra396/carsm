<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-28 02:28:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:28:35 --> Config Class Initialized
INFO - 2020-08-28 02:28:35 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:28:35 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:28:35 --> Utf8 Class Initialized
INFO - 2020-08-28 02:28:35 --> URI Class Initialized
DEBUG - 2020-08-28 02:28:35 --> No URI present. Default controller set.
INFO - 2020-08-28 02:28:35 --> Router Class Initialized
INFO - 2020-08-28 02:28:35 --> Output Class Initialized
INFO - 2020-08-28 02:28:35 --> Security Class Initialized
DEBUG - 2020-08-28 02:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:28:35 --> Input Class Initialized
INFO - 2020-08-28 02:28:35 --> Language Class Initialized
INFO - 2020-08-28 02:28:35 --> Loader Class Initialized
INFO - 2020-08-28 02:28:35 --> Helper loaded: url_helper
INFO - 2020-08-28 02:28:35 --> Database Driver Class Initialized
INFO - 2020-08-28 02:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:28:35 --> Email Class Initialized
INFO - 2020-08-28 02:28:35 --> Controller Class Initialized
INFO - 2020-08-28 02:28:35 --> Model Class Initialized
INFO - 2020-08-28 02:28:35 --> Model Class Initialized
DEBUG - 2020-08-28 02:28:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 02:28:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 02:28:35 --> Final output sent to browser
DEBUG - 2020-08-28 02:28:35 --> Total execution time: 0.0180
ERROR - 2020-08-28 02:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:08 --> Config Class Initialized
INFO - 2020-08-28 02:29:08 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:08 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:08 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:08 --> URI Class Initialized
INFO - 2020-08-28 02:29:08 --> Router Class Initialized
INFO - 2020-08-28 02:29:08 --> Output Class Initialized
INFO - 2020-08-28 02:29:08 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:08 --> Input Class Initialized
INFO - 2020-08-28 02:29:08 --> Language Class Initialized
INFO - 2020-08-28 02:29:08 --> Loader Class Initialized
INFO - 2020-08-28 02:29:08 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:08 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:08 --> Email Class Initialized
INFO - 2020-08-28 02:29:08 --> Controller Class Initialized
INFO - 2020-08-28 02:29:08 --> Model Class Initialized
INFO - 2020-08-28 02:29:08 --> Model Class Initialized
DEBUG - 2020-08-28 02:29:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 02:29:08 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-28 02:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:08 --> Config Class Initialized
INFO - 2020-08-28 02:29:08 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:08 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:08 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:08 --> URI Class Initialized
INFO - 2020-08-28 02:29:08 --> Router Class Initialized
INFO - 2020-08-28 02:29:08 --> Output Class Initialized
INFO - 2020-08-28 02:29:08 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:08 --> Input Class Initialized
INFO - 2020-08-28 02:29:08 --> Language Class Initialized
INFO - 2020-08-28 02:29:08 --> Loader Class Initialized
INFO - 2020-08-28 02:29:08 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:08 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:08 --> Email Class Initialized
INFO - 2020-08-28 02:29:08 --> Controller Class Initialized
INFO - 2020-08-28 02:29:08 --> Model Class Initialized
INFO - 2020-08-28 02:29:08 --> Model Class Initialized
DEBUG - 2020-08-28 02:29:08 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 02:29:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:08 --> Config Class Initialized
INFO - 2020-08-28 02:29:08 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:08 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:08 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:08 --> URI Class Initialized
DEBUG - 2020-08-28 02:29:08 --> No URI present. Default controller set.
INFO - 2020-08-28 02:29:08 --> Router Class Initialized
INFO - 2020-08-28 02:29:08 --> Output Class Initialized
INFO - 2020-08-28 02:29:08 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:08 --> Input Class Initialized
INFO - 2020-08-28 02:29:08 --> Language Class Initialized
INFO - 2020-08-28 02:29:08 --> Loader Class Initialized
INFO - 2020-08-28 02:29:08 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:08 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:08 --> Email Class Initialized
INFO - 2020-08-28 02:29:08 --> Controller Class Initialized
INFO - 2020-08-28 02:29:08 --> Model Class Initialized
INFO - 2020-08-28 02:29:08 --> Model Class Initialized
DEBUG - 2020-08-28 02:29:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 02:29:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 02:29:08 --> Final output sent to browser
DEBUG - 2020-08-28 02:29:08 --> Total execution time: 0.0208
ERROR - 2020-08-28 02:29:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:09 --> Config Class Initialized
INFO - 2020-08-28 02:29:09 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:09 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:09 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:09 --> URI Class Initialized
INFO - 2020-08-28 02:29:09 --> Router Class Initialized
INFO - 2020-08-28 02:29:09 --> Output Class Initialized
INFO - 2020-08-28 02:29:09 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:09 --> Input Class Initialized
INFO - 2020-08-28 02:29:09 --> Language Class Initialized
INFO - 2020-08-28 02:29:09 --> Loader Class Initialized
INFO - 2020-08-28 02:29:09 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:09 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:09 --> Email Class Initialized
INFO - 2020-08-28 02:29:09 --> Controller Class Initialized
DEBUG - 2020-08-28 02:29:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 02:29:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 02:29:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-28 02:29:09 --> Final output sent to browser
DEBUG - 2020-08-28 02:29:09 --> Total execution time: 0.0202
ERROR - 2020-08-28 02:29:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:27 --> Config Class Initialized
INFO - 2020-08-28 02:29:27 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:27 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:27 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:27 --> URI Class Initialized
INFO - 2020-08-28 02:29:27 --> Router Class Initialized
INFO - 2020-08-28 02:29:27 --> Output Class Initialized
INFO - 2020-08-28 02:29:27 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:27 --> Input Class Initialized
INFO - 2020-08-28 02:29:27 --> Language Class Initialized
INFO - 2020-08-28 02:29:27 --> Loader Class Initialized
INFO - 2020-08-28 02:29:27 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:27 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:27 --> Email Class Initialized
INFO - 2020-08-28 02:29:27 --> Controller Class Initialized
DEBUG - 2020-08-28 02:29:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 02:29:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 02:29:27 --> Model Class Initialized
INFO - 2020-08-28 02:29:27 --> Model Class Initialized
INFO - 2020-08-28 02:29:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-28 02:29:27 --> Final output sent to browser
DEBUG - 2020-08-28 02:29:27 --> Total execution time: 0.0260
ERROR - 2020-08-28 02:29:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:35 --> Config Class Initialized
INFO - 2020-08-28 02:29:35 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:35 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:35 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:35 --> URI Class Initialized
INFO - 2020-08-28 02:29:35 --> Router Class Initialized
INFO - 2020-08-28 02:29:35 --> Output Class Initialized
INFO - 2020-08-28 02:29:35 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:35 --> Input Class Initialized
INFO - 2020-08-28 02:29:35 --> Language Class Initialized
INFO - 2020-08-28 02:29:35 --> Loader Class Initialized
INFO - 2020-08-28 02:29:35 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:35 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:35 --> Email Class Initialized
INFO - 2020-08-28 02:29:35 --> Controller Class Initialized
DEBUG - 2020-08-28 02:29:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 02:29:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 02:29:35 --> Model Class Initialized
INFO - 2020-08-28 02:29:35 --> Model Class Initialized
INFO - 2020-08-28 02:29:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-28 02:29:35 --> Final output sent to browser
DEBUG - 2020-08-28 02:29:35 --> Total execution time: 0.0336
ERROR - 2020-08-28 02:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 02:29:39 --> Config Class Initialized
INFO - 2020-08-28 02:29:39 --> Hooks Class Initialized
DEBUG - 2020-08-28 02:29:39 --> UTF-8 Support Enabled
INFO - 2020-08-28 02:29:39 --> Utf8 Class Initialized
INFO - 2020-08-28 02:29:39 --> URI Class Initialized
INFO - 2020-08-28 02:29:39 --> Router Class Initialized
INFO - 2020-08-28 02:29:39 --> Output Class Initialized
INFO - 2020-08-28 02:29:39 --> Security Class Initialized
DEBUG - 2020-08-28 02:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 02:29:39 --> Input Class Initialized
INFO - 2020-08-28 02:29:39 --> Language Class Initialized
INFO - 2020-08-28 02:29:39 --> Loader Class Initialized
INFO - 2020-08-28 02:29:39 --> Helper loaded: url_helper
INFO - 2020-08-28 02:29:39 --> Database Driver Class Initialized
INFO - 2020-08-28 02:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 02:29:39 --> Email Class Initialized
INFO - 2020-08-28 02:29:39 --> Controller Class Initialized
DEBUG - 2020-08-28 02:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 02:29:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 02:29:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-28 02:29:39 --> Final output sent to browser
DEBUG - 2020-08-28 02:29:39 --> Total execution time: 0.0165
ERROR - 2020-08-28 06:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 06:53:40 --> Config Class Initialized
INFO - 2020-08-28 06:53:40 --> Hooks Class Initialized
DEBUG - 2020-08-28 06:53:40 --> UTF-8 Support Enabled
INFO - 2020-08-28 06:53:40 --> Utf8 Class Initialized
INFO - 2020-08-28 06:53:40 --> URI Class Initialized
DEBUG - 2020-08-28 06:53:40 --> No URI present. Default controller set.
INFO - 2020-08-28 06:53:40 --> Router Class Initialized
INFO - 2020-08-28 06:53:40 --> Output Class Initialized
INFO - 2020-08-28 06:53:40 --> Security Class Initialized
DEBUG - 2020-08-28 06:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 06:53:40 --> Input Class Initialized
INFO - 2020-08-28 06:53:40 --> Language Class Initialized
INFO - 2020-08-28 06:53:40 --> Loader Class Initialized
INFO - 2020-08-28 06:53:40 --> Helper loaded: url_helper
INFO - 2020-08-28 06:53:41 --> Database Driver Class Initialized
INFO - 2020-08-28 06:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 06:53:41 --> Email Class Initialized
INFO - 2020-08-28 06:53:41 --> Controller Class Initialized
INFO - 2020-08-28 06:53:41 --> Model Class Initialized
INFO - 2020-08-28 06:53:41 --> Model Class Initialized
DEBUG - 2020-08-28 06:53:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 06:53:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 06:53:41 --> Final output sent to browser
DEBUG - 2020-08-28 06:53:41 --> Total execution time: 0.1311
ERROR - 2020-08-28 07:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:31 --> Config Class Initialized
INFO - 2020-08-28 07:06:31 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:31 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:31 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:31 --> URI Class Initialized
INFO - 2020-08-28 07:06:31 --> Router Class Initialized
INFO - 2020-08-28 07:06:31 --> Output Class Initialized
INFO - 2020-08-28 07:06:31 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:31 --> Input Class Initialized
INFO - 2020-08-28 07:06:31 --> Language Class Initialized
INFO - 2020-08-28 07:06:31 --> Loader Class Initialized
INFO - 2020-08-28 07:06:31 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:31 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:31 --> Email Class Initialized
INFO - 2020-08-28 07:06:31 --> Controller Class Initialized
INFO - 2020-08-28 07:06:31 --> Model Class Initialized
INFO - 2020-08-28 07:06:31 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:31 --> Config Class Initialized
INFO - 2020-08-28 07:06:31 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:31 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:31 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:31 --> URI Class Initialized
INFO - 2020-08-28 07:06:31 --> Router Class Initialized
INFO - 2020-08-28 07:06:31 --> Output Class Initialized
INFO - 2020-08-28 07:06:31 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:31 --> Input Class Initialized
INFO - 2020-08-28 07:06:31 --> Language Class Initialized
INFO - 2020-08-28 07:06:31 --> Loader Class Initialized
INFO - 2020-08-28 07:06:31 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:31 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:31 --> Email Class Initialized
INFO - 2020-08-28 07:06:31 --> Controller Class Initialized
INFO - 2020-08-28 07:06:31 --> Model Class Initialized
INFO - 2020-08-28 07:06:31 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:06:31 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:31 --> Config Class Initialized
INFO - 2020-08-28 07:06:31 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:31 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:31 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:31 --> URI Class Initialized
DEBUG - 2020-08-28 07:06:31 --> No URI present. Default controller set.
INFO - 2020-08-28 07:06:31 --> Router Class Initialized
INFO - 2020-08-28 07:06:31 --> Output Class Initialized
INFO - 2020-08-28 07:06:31 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:31 --> Input Class Initialized
INFO - 2020-08-28 07:06:31 --> Language Class Initialized
INFO - 2020-08-28 07:06:31 --> Loader Class Initialized
INFO - 2020-08-28 07:06:31 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:31 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:31 --> Email Class Initialized
INFO - 2020-08-28 07:06:31 --> Controller Class Initialized
INFO - 2020-08-28 07:06:31 --> Model Class Initialized
INFO - 2020-08-28 07:06:31 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:06:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 07:06:31 --> Final output sent to browser
DEBUG - 2020-08-28 07:06:31 --> Total execution time: 0.0215
ERROR - 2020-08-28 07:06:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:31 --> Config Class Initialized
INFO - 2020-08-28 07:06:31 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:31 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:31 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:31 --> URI Class Initialized
INFO - 2020-08-28 07:06:31 --> Router Class Initialized
INFO - 2020-08-28 07:06:31 --> Output Class Initialized
INFO - 2020-08-28 07:06:31 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:31 --> Input Class Initialized
INFO - 2020-08-28 07:06:31 --> Language Class Initialized
INFO - 2020-08-28 07:06:31 --> Loader Class Initialized
INFO - 2020-08-28 07:06:31 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:31 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:31 --> Email Class Initialized
INFO - 2020-08-28 07:06:31 --> Controller Class Initialized
DEBUG - 2020-08-28 07:06:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:06:31 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:06:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:32 --> Config Class Initialized
INFO - 2020-08-28 07:06:32 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:32 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:32 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:32 --> URI Class Initialized
DEBUG - 2020-08-28 07:06:32 --> No URI present. Default controller set.
INFO - 2020-08-28 07:06:32 --> Router Class Initialized
INFO - 2020-08-28 07:06:32 --> Output Class Initialized
INFO - 2020-08-28 07:06:32 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:32 --> Input Class Initialized
INFO - 2020-08-28 07:06:32 --> Language Class Initialized
INFO - 2020-08-28 07:06:32 --> Loader Class Initialized
INFO - 2020-08-28 07:06:32 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:32 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:32 --> Email Class Initialized
INFO - 2020-08-28 07:06:32 --> Controller Class Initialized
INFO - 2020-08-28 07:06:32 --> Model Class Initialized
INFO - 2020-08-28 07:06:32 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:06:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 07:06:32 --> Final output sent to browser
DEBUG - 2020-08-28 07:06:32 --> Total execution time: 0.4169
ERROR - 2020-08-28 07:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:34 --> Config Class Initialized
INFO - 2020-08-28 07:06:34 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:34 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:34 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:34 --> URI Class Initialized
INFO - 2020-08-28 07:06:34 --> Router Class Initialized
INFO - 2020-08-28 07:06:34 --> Output Class Initialized
INFO - 2020-08-28 07:06:34 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:34 --> Input Class Initialized
INFO - 2020-08-28 07:06:34 --> Language Class Initialized
INFO - 2020-08-28 07:06:34 --> Loader Class Initialized
INFO - 2020-08-28 07:06:34 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:34 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:34 --> Email Class Initialized
INFO - 2020-08-28 07:06:34 --> Controller Class Initialized
INFO - 2020-08-28 07:06:34 --> Model Class Initialized
INFO - 2020-08-28 07:06:34 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:06:34 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:06:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:34 --> Config Class Initialized
INFO - 2020-08-28 07:06:34 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:34 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:34 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:34 --> URI Class Initialized
INFO - 2020-08-28 07:06:34 --> Router Class Initialized
INFO - 2020-08-28 07:06:34 --> Output Class Initialized
INFO - 2020-08-28 07:06:34 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:34 --> Input Class Initialized
INFO - 2020-08-28 07:06:34 --> Language Class Initialized
INFO - 2020-08-28 07:06:34 --> Loader Class Initialized
INFO - 2020-08-28 07:06:34 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:34 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:35 --> Email Class Initialized
INFO - 2020-08-28 07:06:35 --> Controller Class Initialized
INFO - 2020-08-28 07:06:35 --> Model Class Initialized
INFO - 2020-08-28 07:06:35 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:35 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:35 --> Config Class Initialized
INFO - 2020-08-28 07:06:35 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:35 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:35 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:35 --> URI Class Initialized
DEBUG - 2020-08-28 07:06:35 --> No URI present. Default controller set.
INFO - 2020-08-28 07:06:35 --> Router Class Initialized
INFO - 2020-08-28 07:06:35 --> Output Class Initialized
INFO - 2020-08-28 07:06:35 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:35 --> Input Class Initialized
INFO - 2020-08-28 07:06:35 --> Language Class Initialized
INFO - 2020-08-28 07:06:35 --> Loader Class Initialized
INFO - 2020-08-28 07:06:35 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:35 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:35 --> Email Class Initialized
INFO - 2020-08-28 07:06:35 --> Controller Class Initialized
INFO - 2020-08-28 07:06:35 --> Model Class Initialized
INFO - 2020-08-28 07:06:35 --> Model Class Initialized
DEBUG - 2020-08-28 07:06:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:06:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 07:06:35 --> Final output sent to browser
DEBUG - 2020-08-28 07:06:35 --> Total execution time: 0.0435
ERROR - 2020-08-28 07:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:35 --> Config Class Initialized
INFO - 2020-08-28 07:06:35 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:35 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:35 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:35 --> URI Class Initialized
INFO - 2020-08-28 07:06:35 --> Router Class Initialized
INFO - 2020-08-28 07:06:35 --> Output Class Initialized
INFO - 2020-08-28 07:06:35 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:35 --> Input Class Initialized
INFO - 2020-08-28 07:06:35 --> Language Class Initialized
INFO - 2020-08-28 07:06:35 --> Loader Class Initialized
INFO - 2020-08-28 07:06:35 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:35 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:35 --> Email Class Initialized
INFO - 2020-08-28 07:06:35 --> Controller Class Initialized
DEBUG - 2020-08-28 07:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:06:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:06:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-28 07:06:35 --> Final output sent to browser
DEBUG - 2020-08-28 07:06:35 --> Total execution time: 0.0350
ERROR - 2020-08-28 07:06:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:06:59 --> Config Class Initialized
INFO - 2020-08-28 07:06:59 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:06:59 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:06:59 --> Utf8 Class Initialized
INFO - 2020-08-28 07:06:59 --> URI Class Initialized
INFO - 2020-08-28 07:06:59 --> Router Class Initialized
INFO - 2020-08-28 07:06:59 --> Output Class Initialized
INFO - 2020-08-28 07:06:59 --> Security Class Initialized
DEBUG - 2020-08-28 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:06:59 --> Input Class Initialized
INFO - 2020-08-28 07:06:59 --> Language Class Initialized
INFO - 2020-08-28 07:06:59 --> Loader Class Initialized
INFO - 2020-08-28 07:06:59 --> Helper loaded: url_helper
INFO - 2020-08-28 07:06:59 --> Database Driver Class Initialized
INFO - 2020-08-28 07:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:06:59 --> Email Class Initialized
INFO - 2020-08-28 07:06:59 --> Controller Class Initialized
DEBUG - 2020-08-28 07:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:06:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:06:59 --> Helper loaded: form_helper
INFO - 2020-08-28 07:06:59 --> Form Validation Class Initialized
INFO - 2020-08-28 07:06:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-28 07:06:59 --> Final output sent to browser
DEBUG - 2020-08-28 07:06:59 --> Total execution time: 0.0732
ERROR - 2020-08-28 07:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:07:25 --> Config Class Initialized
INFO - 2020-08-28 07:07:25 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:07:25 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:07:25 --> Utf8 Class Initialized
INFO - 2020-08-28 07:07:25 --> URI Class Initialized
INFO - 2020-08-28 07:07:25 --> Router Class Initialized
INFO - 2020-08-28 07:07:25 --> Output Class Initialized
INFO - 2020-08-28 07:07:25 --> Security Class Initialized
DEBUG - 2020-08-28 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:07:25 --> Input Class Initialized
INFO - 2020-08-28 07:07:25 --> Language Class Initialized
INFO - 2020-08-28 07:07:25 --> Loader Class Initialized
INFO - 2020-08-28 07:07:25 --> Helper loaded: url_helper
INFO - 2020-08-28 07:07:25 --> Database Driver Class Initialized
INFO - 2020-08-28 07:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:07:25 --> Email Class Initialized
INFO - 2020-08-28 07:07:25 --> Controller Class Initialized
DEBUG - 2020-08-28 07:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:07:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:07:25 --> Helper loaded: form_helper
INFO - 2020-08-28 07:07:25 --> Form Validation Class Initialized
INFO - 2020-08-28 07:07:25 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 07:07:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 07:07:25 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 07:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:24:40 --> Config Class Initialized
INFO - 2020-08-28 07:24:40 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:24:40 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:24:40 --> Utf8 Class Initialized
INFO - 2020-08-28 07:24:40 --> URI Class Initialized
INFO - 2020-08-28 07:24:40 --> Router Class Initialized
INFO - 2020-08-28 07:24:40 --> Output Class Initialized
INFO - 2020-08-28 07:24:40 --> Security Class Initialized
DEBUG - 2020-08-28 07:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:24:40 --> Input Class Initialized
INFO - 2020-08-28 07:24:40 --> Language Class Initialized
INFO - 2020-08-28 07:24:40 --> Loader Class Initialized
INFO - 2020-08-28 07:24:40 --> Helper loaded: url_helper
INFO - 2020-08-28 07:24:40 --> Database Driver Class Initialized
INFO - 2020-08-28 07:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:24:40 --> Email Class Initialized
INFO - 2020-08-28 07:24:40 --> Controller Class Initialized
DEBUG - 2020-08-28 07:24:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:24:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:24:40 --> Helper loaded: form_helper
INFO - 2020-08-28 07:24:40 --> Form Validation Class Initialized
INFO - 2020-08-28 07:24:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 07:24:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 07:24:40 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 07:24:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:24:43 --> Config Class Initialized
INFO - 2020-08-28 07:24:43 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:24:43 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:24:43 --> Utf8 Class Initialized
INFO - 2020-08-28 07:24:43 --> URI Class Initialized
INFO - 2020-08-28 07:24:43 --> Router Class Initialized
INFO - 2020-08-28 07:24:43 --> Output Class Initialized
INFO - 2020-08-28 07:24:43 --> Security Class Initialized
DEBUG - 2020-08-28 07:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:24:43 --> Input Class Initialized
INFO - 2020-08-28 07:24:43 --> Language Class Initialized
INFO - 2020-08-28 07:24:43 --> Loader Class Initialized
INFO - 2020-08-28 07:24:43 --> Helper loaded: url_helper
INFO - 2020-08-28 07:24:43 --> Database Driver Class Initialized
INFO - 2020-08-28 07:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:24:43 --> Email Class Initialized
INFO - 2020-08-28 07:24:43 --> Controller Class Initialized
DEBUG - 2020-08-28 07:24:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:24:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:24:43 --> Helper loaded: form_helper
INFO - 2020-08-28 07:24:43 --> Form Validation Class Initialized
INFO - 2020-08-28 07:24:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 07:24:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 07:24:43 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 07:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:24:49 --> Config Class Initialized
INFO - 2020-08-28 07:24:49 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:24:49 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:24:49 --> Utf8 Class Initialized
INFO - 2020-08-28 07:24:49 --> URI Class Initialized
INFO - 2020-08-28 07:24:49 --> Router Class Initialized
INFO - 2020-08-28 07:24:49 --> Output Class Initialized
INFO - 2020-08-28 07:24:49 --> Security Class Initialized
DEBUG - 2020-08-28 07:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:24:49 --> Input Class Initialized
INFO - 2020-08-28 07:24:49 --> Language Class Initialized
INFO - 2020-08-28 07:24:49 --> Loader Class Initialized
INFO - 2020-08-28 07:24:49 --> Helper loaded: url_helper
INFO - 2020-08-28 07:24:49 --> Database Driver Class Initialized
INFO - 2020-08-28 07:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:24:49 --> Email Class Initialized
INFO - 2020-08-28 07:24:49 --> Controller Class Initialized
DEBUG - 2020-08-28 07:24:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:24:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:24:49 --> Helper loaded: form_helper
INFO - 2020-08-28 07:24:49 --> Form Validation Class Initialized
INFO - 2020-08-28 07:24:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-28 07:24:49 --> Final output sent to browser
DEBUG - 2020-08-28 07:24:49 --> Total execution time: 0.0195
ERROR - 2020-08-28 07:24:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:24:59 --> Config Class Initialized
INFO - 2020-08-28 07:24:59 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:24:59 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:24:59 --> Utf8 Class Initialized
INFO - 2020-08-28 07:24:59 --> URI Class Initialized
INFO - 2020-08-28 07:24:59 --> Router Class Initialized
INFO - 2020-08-28 07:24:59 --> Output Class Initialized
INFO - 2020-08-28 07:24:59 --> Security Class Initialized
DEBUG - 2020-08-28 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:24:59 --> Input Class Initialized
INFO - 2020-08-28 07:24:59 --> Language Class Initialized
INFO - 2020-08-28 07:24:59 --> Loader Class Initialized
INFO - 2020-08-28 07:24:59 --> Helper loaded: url_helper
INFO - 2020-08-28 07:24:59 --> Database Driver Class Initialized
INFO - 2020-08-28 07:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:24:59 --> Email Class Initialized
INFO - 2020-08-28 07:24:59 --> Controller Class Initialized
DEBUG - 2020-08-28 07:24:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:24:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:24:59 --> Helper loaded: form_helper
INFO - 2020-08-28 07:24:59 --> Form Validation Class Initialized
INFO - 2020-08-28 07:24:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 07:24:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 07:24:59 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 07:29:05 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:29:36 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:29:38 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:29:39 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:29:42 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:30:27 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:38:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:38:04 --> Config Class Initialized
INFO - 2020-08-28 07:38:04 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:38:04 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:38:04 --> Utf8 Class Initialized
INFO - 2020-08-28 07:38:04 --> URI Class Initialized
DEBUG - 2020-08-28 07:38:04 --> No URI present. Default controller set.
INFO - 2020-08-28 07:38:04 --> Router Class Initialized
INFO - 2020-08-28 07:38:04 --> Output Class Initialized
INFO - 2020-08-28 07:38:04 --> Security Class Initialized
DEBUG - 2020-08-28 07:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:38:04 --> Input Class Initialized
INFO - 2020-08-28 07:38:04 --> Language Class Initialized
INFO - 2020-08-28 07:38:04 --> Loader Class Initialized
INFO - 2020-08-28 07:38:04 --> Helper loaded: url_helper
INFO - 2020-08-28 07:38:04 --> Database Driver Class Initialized
INFO - 2020-08-28 07:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:38:04 --> Email Class Initialized
INFO - 2020-08-28 07:38:04 --> Controller Class Initialized
INFO - 2020-08-28 07:38:04 --> Model Class Initialized
INFO - 2020-08-28 07:38:04 --> Model Class Initialized
DEBUG - 2020-08-28 07:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:38:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 07:38:04 --> Final output sent to browser
DEBUG - 2020-08-28 07:38:04 --> Total execution time: 0.0318
ERROR - 2020-08-28 07:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:38:06 --> Config Class Initialized
INFO - 2020-08-28 07:38:06 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:38:06 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:38:06 --> Utf8 Class Initialized
INFO - 2020-08-28 07:38:06 --> URI Class Initialized
INFO - 2020-08-28 07:38:06 --> Router Class Initialized
INFO - 2020-08-28 07:38:06 --> Output Class Initialized
INFO - 2020-08-28 07:38:06 --> Security Class Initialized
DEBUG - 2020-08-28 07:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:38:06 --> Input Class Initialized
INFO - 2020-08-28 07:38:06 --> Language Class Initialized
INFO - 2020-08-28 07:38:06 --> Loader Class Initialized
INFO - 2020-08-28 07:38:06 --> Helper loaded: url_helper
INFO - 2020-08-28 07:38:06 --> Database Driver Class Initialized
INFO - 2020-08-28 07:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:38:06 --> Email Class Initialized
INFO - 2020-08-28 07:38:06 --> Controller Class Initialized
INFO - 2020-08-28 07:38:06 --> Model Class Initialized
INFO - 2020-08-28 07:38:06 --> Model Class Initialized
DEBUG - 2020-08-28 07:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:38:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:38:06 --> Model Class Initialized
INFO - 2020-08-28 07:38:06 --> Final output sent to browser
DEBUG - 2020-08-28 07:38:06 --> Total execution time: 0.0240
ERROR - 2020-08-28 07:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:38:06 --> Config Class Initialized
INFO - 2020-08-28 07:38:06 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:38:06 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:38:06 --> Utf8 Class Initialized
INFO - 2020-08-28 07:38:06 --> URI Class Initialized
INFO - 2020-08-28 07:38:06 --> Router Class Initialized
INFO - 2020-08-28 07:38:06 --> Output Class Initialized
INFO - 2020-08-28 07:38:06 --> Security Class Initialized
DEBUG - 2020-08-28 07:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:38:06 --> Input Class Initialized
INFO - 2020-08-28 07:38:06 --> Language Class Initialized
INFO - 2020-08-28 07:38:06 --> Loader Class Initialized
INFO - 2020-08-28 07:38:06 --> Helper loaded: url_helper
INFO - 2020-08-28 07:38:06 --> Database Driver Class Initialized
INFO - 2020-08-28 07:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:38:06 --> Email Class Initialized
INFO - 2020-08-28 07:38:06 --> Controller Class Initialized
INFO - 2020-08-28 07:38:06 --> Model Class Initialized
INFO - 2020-08-28 07:38:06 --> Model Class Initialized
DEBUG - 2020-08-28 07:38:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:38:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:38:06 --> Config Class Initialized
INFO - 2020-08-28 07:38:06 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:38:06 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:38:06 --> Utf8 Class Initialized
INFO - 2020-08-28 07:38:06 --> URI Class Initialized
INFO - 2020-08-28 07:38:06 --> Router Class Initialized
INFO - 2020-08-28 07:38:06 --> Output Class Initialized
INFO - 2020-08-28 07:38:06 --> Security Class Initialized
DEBUG - 2020-08-28 07:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:38:06 --> Input Class Initialized
INFO - 2020-08-28 07:38:06 --> Language Class Initialized
INFO - 2020-08-28 07:38:06 --> Loader Class Initialized
INFO - 2020-08-28 07:38:06 --> Helper loaded: url_helper
INFO - 2020-08-28 07:38:06 --> Database Driver Class Initialized
INFO - 2020-08-28 07:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:38:06 --> Email Class Initialized
INFO - 2020-08-28 07:38:06 --> Controller Class Initialized
DEBUG - 2020-08-28 07:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:38:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:38:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-28 07:38:06 --> Final output sent to browser
DEBUG - 2020-08-28 07:38:06 --> Total execution time: 0.0201
ERROR - 2020-08-28 07:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:46:20 --> Config Class Initialized
INFO - 2020-08-28 07:46:20 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:46:20 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:46:20 --> Utf8 Class Initialized
INFO - 2020-08-28 07:46:20 --> URI Class Initialized
DEBUG - 2020-08-28 07:46:20 --> No URI present. Default controller set.
INFO - 2020-08-28 07:46:20 --> Router Class Initialized
INFO - 2020-08-28 07:46:20 --> Output Class Initialized
INFO - 2020-08-28 07:46:20 --> Security Class Initialized
DEBUG - 2020-08-28 07:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:46:20 --> Input Class Initialized
INFO - 2020-08-28 07:46:20 --> Language Class Initialized
INFO - 2020-08-28 07:46:20 --> Loader Class Initialized
INFO - 2020-08-28 07:46:20 --> Helper loaded: url_helper
INFO - 2020-08-28 07:46:20 --> Database Driver Class Initialized
INFO - 2020-08-28 07:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:46:20 --> Email Class Initialized
INFO - 2020-08-28 07:46:20 --> Controller Class Initialized
INFO - 2020-08-28 07:46:20 --> Model Class Initialized
INFO - 2020-08-28 07:46:20 --> Model Class Initialized
DEBUG - 2020-08-28 07:46:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:46:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 07:46:20 --> Final output sent to browser
DEBUG - 2020-08-28 07:46:20 --> Total execution time: 0.0216
ERROR - 2020-08-28 07:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:46:23 --> Config Class Initialized
INFO - 2020-08-28 07:46:23 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:46:23 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:46:23 --> Utf8 Class Initialized
INFO - 2020-08-28 07:46:23 --> URI Class Initialized
INFO - 2020-08-28 07:46:23 --> Router Class Initialized
INFO - 2020-08-28 07:46:23 --> Output Class Initialized
INFO - 2020-08-28 07:46:23 --> Security Class Initialized
DEBUG - 2020-08-28 07:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:46:23 --> Input Class Initialized
INFO - 2020-08-28 07:46:23 --> Language Class Initialized
INFO - 2020-08-28 07:46:23 --> Loader Class Initialized
INFO - 2020-08-28 07:46:23 --> Helper loaded: url_helper
ERROR - 2020-08-28 07:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:46:23 --> Config Class Initialized
INFO - 2020-08-28 07:46:23 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:46:23 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:46:23 --> Utf8 Class Initialized
INFO - 2020-08-28 07:46:23 --> URI Class Initialized
INFO - 2020-08-28 07:46:23 --> Database Driver Class Initialized
INFO - 2020-08-28 07:46:23 --> Router Class Initialized
INFO - 2020-08-28 07:46:23 --> Output Class Initialized
INFO - 2020-08-28 07:46:23 --> Security Class Initialized
INFO - 2020-08-28 07:46:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-28 07:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:46:23 --> Input Class Initialized
INFO - 2020-08-28 07:46:23 --> Language Class Initialized
INFO - 2020-08-28 07:46:23 --> Email Class Initialized
INFO - 2020-08-28 07:46:23 --> Controller Class Initialized
INFO - 2020-08-28 07:46:23 --> Model Class Initialized
INFO - 2020-08-28 07:46:23 --> Loader Class Initialized
INFO - 2020-08-28 07:46:23 --> Model Class Initialized
INFO - 2020-08-28 07:46:23 --> Helper loaded: url_helper
DEBUG - 2020-08-28 07:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:46:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:46:23 --> Model Class Initialized
INFO - 2020-08-28 07:46:23 --> Final output sent to browser
DEBUG - 2020-08-28 07:46:23 --> Total execution time: 0.0233
INFO - 2020-08-28 07:46:23 --> Database Driver Class Initialized
INFO - 2020-08-28 07:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:46:23 --> Email Class Initialized
INFO - 2020-08-28 07:46:23 --> Controller Class Initialized
INFO - 2020-08-28 07:46:23 --> Model Class Initialized
INFO - 2020-08-28 07:46:23 --> Model Class Initialized
DEBUG - 2020-08-28 07:46:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-28 07:46:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:46:23 --> Config Class Initialized
INFO - 2020-08-28 07:46:23 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:46:23 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:46:23 --> Utf8 Class Initialized
INFO - 2020-08-28 07:46:23 --> URI Class Initialized
INFO - 2020-08-28 07:46:23 --> Router Class Initialized
INFO - 2020-08-28 07:46:23 --> Output Class Initialized
INFO - 2020-08-28 07:46:23 --> Security Class Initialized
DEBUG - 2020-08-28 07:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:46:23 --> Input Class Initialized
INFO - 2020-08-28 07:46:23 --> Language Class Initialized
INFO - 2020-08-28 07:46:23 --> Loader Class Initialized
INFO - 2020-08-28 07:46:23 --> Helper loaded: url_helper
INFO - 2020-08-28 07:46:23 --> Database Driver Class Initialized
INFO - 2020-08-28 07:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:46:23 --> Email Class Initialized
INFO - 2020-08-28 07:46:23 --> Controller Class Initialized
DEBUG - 2020-08-28 07:46:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:46:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:46:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-28 07:46:23 --> Final output sent to browser
DEBUG - 2020-08-28 07:46:23 --> Total execution time: 0.0189
ERROR - 2020-08-28 07:46:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:46:42 --> Config Class Initialized
INFO - 2020-08-28 07:46:42 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:46:42 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:46:42 --> Utf8 Class Initialized
INFO - 2020-08-28 07:46:42 --> URI Class Initialized
INFO - 2020-08-28 07:46:42 --> Router Class Initialized
INFO - 2020-08-28 07:46:42 --> Output Class Initialized
INFO - 2020-08-28 07:46:42 --> Security Class Initialized
DEBUG - 2020-08-28 07:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:46:42 --> Input Class Initialized
INFO - 2020-08-28 07:46:42 --> Language Class Initialized
INFO - 2020-08-28 07:46:42 --> Loader Class Initialized
INFO - 2020-08-28 07:46:42 --> Helper loaded: url_helper
INFO - 2020-08-28 07:46:42 --> Database Driver Class Initialized
INFO - 2020-08-28 07:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:46:42 --> Email Class Initialized
INFO - 2020-08-28 07:46:42 --> Controller Class Initialized
DEBUG - 2020-08-28 07:46:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:46:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:46:42 --> Helper loaded: form_helper
INFO - 2020-08-28 07:46:42 --> Form Validation Class Initialized
INFO - 2020-08-28 07:46:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-28 07:46:42 --> Final output sent to browser
DEBUG - 2020-08-28 07:46:42 --> Total execution time: 0.0196
ERROR - 2020-08-28 07:46:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:46:50 --> Config Class Initialized
INFO - 2020-08-28 07:46:50 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:46:50 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:46:50 --> Utf8 Class Initialized
INFO - 2020-08-28 07:46:50 --> URI Class Initialized
INFO - 2020-08-28 07:46:50 --> Router Class Initialized
INFO - 2020-08-28 07:46:50 --> Output Class Initialized
INFO - 2020-08-28 07:46:50 --> Security Class Initialized
DEBUG - 2020-08-28 07:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:46:50 --> Input Class Initialized
INFO - 2020-08-28 07:46:50 --> Language Class Initialized
INFO - 2020-08-28 07:46:50 --> Loader Class Initialized
INFO - 2020-08-28 07:46:50 --> Helper loaded: url_helper
INFO - 2020-08-28 07:46:50 --> Database Driver Class Initialized
INFO - 2020-08-28 07:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:46:50 --> Email Class Initialized
INFO - 2020-08-28 07:46:50 --> Controller Class Initialized
DEBUG - 2020-08-28 07:46:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:46:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:46:50 --> Helper loaded: form_helper
INFO - 2020-08-28 07:46:50 --> Form Validation Class Initialized
INFO - 2020-08-28 07:46:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 07:46:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 07:46:50 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 07:48:33 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:48:41 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-08-28 07:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:52:18 --> Config Class Initialized
INFO - 2020-08-28 07:52:18 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:52:18 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:52:18 --> Utf8 Class Initialized
INFO - 2020-08-28 07:52:18 --> URI Class Initialized
DEBUG - 2020-08-28 07:52:18 --> No URI present. Default controller set.
INFO - 2020-08-28 07:52:18 --> Router Class Initialized
INFO - 2020-08-28 07:52:18 --> Output Class Initialized
INFO - 2020-08-28 07:52:18 --> Security Class Initialized
DEBUG - 2020-08-28 07:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:52:18 --> Input Class Initialized
INFO - 2020-08-28 07:52:18 --> Language Class Initialized
INFO - 2020-08-28 07:52:18 --> Loader Class Initialized
INFO - 2020-08-28 07:52:18 --> Helper loaded: url_helper
INFO - 2020-08-28 07:52:18 --> Database Driver Class Initialized
INFO - 2020-08-28 07:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:52:18 --> Email Class Initialized
INFO - 2020-08-28 07:52:18 --> Controller Class Initialized
INFO - 2020-08-28 07:52:18 --> Model Class Initialized
INFO - 2020-08-28 07:52:18 --> Model Class Initialized
DEBUG - 2020-08-28 07:52:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:52:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-28 07:52:18 --> Final output sent to browser
DEBUG - 2020-08-28 07:52:18 --> Total execution time: 0.0184
ERROR - 2020-08-28 07:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:52:20 --> Config Class Initialized
INFO - 2020-08-28 07:52:20 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:52:20 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:52:20 --> Utf8 Class Initialized
INFO - 2020-08-28 07:52:20 --> URI Class Initialized
INFO - 2020-08-28 07:52:20 --> Router Class Initialized
INFO - 2020-08-28 07:52:20 --> Output Class Initialized
INFO - 2020-08-28 07:52:20 --> Security Class Initialized
DEBUG - 2020-08-28 07:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:52:20 --> Input Class Initialized
INFO - 2020-08-28 07:52:20 --> Language Class Initialized
INFO - 2020-08-28 07:52:20 --> Loader Class Initialized
INFO - 2020-08-28 07:52:20 --> Helper loaded: url_helper
INFO - 2020-08-28 07:52:20 --> Database Driver Class Initialized
ERROR - 2020-08-28 07:52:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:52:20 --> Config Class Initialized
INFO - 2020-08-28 07:52:20 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:52:20 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:52:20 --> Utf8 Class Initialized
INFO - 2020-08-28 07:52:20 --> URI Class Initialized
INFO - 2020-08-28 07:52:20 --> Router Class Initialized
INFO - 2020-08-28 07:52:20 --> Output Class Initialized
INFO - 2020-08-28 07:52:20 --> Security Class Initialized
DEBUG - 2020-08-28 07:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:52:20 --> Input Class Initialized
INFO - 2020-08-28 07:52:20 --> Language Class Initialized
INFO - 2020-08-28 07:52:20 --> Loader Class Initialized
INFO - 2020-08-28 07:52:20 --> Helper loaded: url_helper
INFO - 2020-08-28 07:52:20 --> Database Driver Class Initialized
INFO - 2020-08-28 07:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:52:20 --> Email Class Initialized
INFO - 2020-08-28 07:52:20 --> Controller Class Initialized
INFO - 2020-08-28 07:52:20 --> Model Class Initialized
INFO - 2020-08-28 07:52:20 --> Model Class Initialized
DEBUG - 2020-08-28 07:52:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:52:20 --> Email Class Initialized
INFO - 2020-08-28 07:52:20 --> Controller Class Initialized
INFO - 2020-08-28 07:52:20 --> Model Class Initialized
INFO - 2020-08-28 07:52:20 --> Model Class Initialized
DEBUG - 2020-08-28 07:52:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:52:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:52:20 --> Model Class Initialized
INFO - 2020-08-28 07:52:20 --> Final output sent to browser
DEBUG - 2020-08-28 07:52:20 --> Total execution time: 0.2735
ERROR - 2020-08-28 07:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:52:21 --> Config Class Initialized
INFO - 2020-08-28 07:52:21 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:52:21 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:52:21 --> Utf8 Class Initialized
INFO - 2020-08-28 07:52:21 --> URI Class Initialized
INFO - 2020-08-28 07:52:21 --> Router Class Initialized
INFO - 2020-08-28 07:52:21 --> Output Class Initialized
INFO - 2020-08-28 07:52:21 --> Security Class Initialized
DEBUG - 2020-08-28 07:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:52:21 --> Input Class Initialized
INFO - 2020-08-28 07:52:21 --> Language Class Initialized
INFO - 2020-08-28 07:52:21 --> Loader Class Initialized
INFO - 2020-08-28 07:52:21 --> Helper loaded: url_helper
INFO - 2020-08-28 07:52:21 --> Database Driver Class Initialized
INFO - 2020-08-28 07:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:52:21 --> Email Class Initialized
INFO - 2020-08-28 07:52:21 --> Controller Class Initialized
DEBUG - 2020-08-28 07:52:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:52:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:52:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-28 07:52:21 --> Final output sent to browser
DEBUG - 2020-08-28 07:52:21 --> Total execution time: 0.0225
ERROR - 2020-08-28 07:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:53:48 --> Config Class Initialized
INFO - 2020-08-28 07:53:48 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:53:48 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:53:48 --> Utf8 Class Initialized
INFO - 2020-08-28 07:53:48 --> URI Class Initialized
INFO - 2020-08-28 07:53:48 --> Router Class Initialized
INFO - 2020-08-28 07:53:48 --> Output Class Initialized
INFO - 2020-08-28 07:53:48 --> Security Class Initialized
DEBUG - 2020-08-28 07:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:53:48 --> Input Class Initialized
INFO - 2020-08-28 07:53:48 --> Language Class Initialized
INFO - 2020-08-28 07:53:48 --> Loader Class Initialized
INFO - 2020-08-28 07:53:48 --> Helper loaded: url_helper
INFO - 2020-08-28 07:53:48 --> Database Driver Class Initialized
INFO - 2020-08-28 07:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:53:48 --> Email Class Initialized
INFO - 2020-08-28 07:53:48 --> Controller Class Initialized
DEBUG - 2020-08-28 07:53:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:53:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:53:48 --> Helper loaded: form_helper
INFO - 2020-08-28 07:53:48 --> Form Validation Class Initialized
INFO - 2020-08-28 07:53:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-28 07:53:48 --> Final output sent to browser
DEBUG - 2020-08-28 07:53:48 --> Total execution time: 0.0229
ERROR - 2020-08-28 07:53:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 07:53:57 --> Config Class Initialized
INFO - 2020-08-28 07:53:57 --> Hooks Class Initialized
DEBUG - 2020-08-28 07:53:57 --> UTF-8 Support Enabled
INFO - 2020-08-28 07:53:57 --> Utf8 Class Initialized
INFO - 2020-08-28 07:53:57 --> URI Class Initialized
INFO - 2020-08-28 07:53:57 --> Router Class Initialized
INFO - 2020-08-28 07:53:57 --> Output Class Initialized
INFO - 2020-08-28 07:53:57 --> Security Class Initialized
DEBUG - 2020-08-28 07:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 07:53:57 --> Input Class Initialized
INFO - 2020-08-28 07:53:57 --> Language Class Initialized
INFO - 2020-08-28 07:53:57 --> Loader Class Initialized
INFO - 2020-08-28 07:53:57 --> Helper loaded: url_helper
INFO - 2020-08-28 07:53:57 --> Database Driver Class Initialized
INFO - 2020-08-28 07:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 07:53:57 --> Email Class Initialized
INFO - 2020-08-28 07:53:57 --> Controller Class Initialized
DEBUG - 2020-08-28 07:53:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 07:53:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 07:53:57 --> Helper loaded: form_helper
INFO - 2020-08-28 07:53:57 --> Form Validation Class Initialized
INFO - 2020-08-28 07:53:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 07:53:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 07:53:57 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 08:10:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 08:10:29 --> Config Class Initialized
INFO - 2020-08-28 08:10:29 --> Hooks Class Initialized
DEBUG - 2020-08-28 08:10:29 --> UTF-8 Support Enabled
INFO - 2020-08-28 08:10:29 --> Utf8 Class Initialized
INFO - 2020-08-28 08:10:29 --> URI Class Initialized
INFO - 2020-08-28 08:10:29 --> Router Class Initialized
INFO - 2020-08-28 08:10:29 --> Output Class Initialized
INFO - 2020-08-28 08:10:29 --> Security Class Initialized
DEBUG - 2020-08-28 08:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 08:10:29 --> Input Class Initialized
INFO - 2020-08-28 08:10:29 --> Language Class Initialized
INFO - 2020-08-28 08:10:29 --> Loader Class Initialized
INFO - 2020-08-28 08:10:29 --> Helper loaded: url_helper
INFO - 2020-08-28 08:10:29 --> Database Driver Class Initialized
INFO - 2020-08-28 08:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 08:10:29 --> Email Class Initialized
INFO - 2020-08-28 08:10:29 --> Controller Class Initialized
DEBUG - 2020-08-28 08:10:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:10:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 08:10:29 --> Helper loaded: form_helper
INFO - 2020-08-28 08:10:29 --> Form Validation Class Initialized
INFO - 2020-08-28 08:10:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-28 08:10:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-28 08:10:29 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-28 08:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-28 08:10:52 --> Config Class Initialized
INFO - 2020-08-28 08:10:52 --> Hooks Class Initialized
DEBUG - 2020-08-28 08:10:52 --> UTF-8 Support Enabled
INFO - 2020-08-28 08:10:52 --> Utf8 Class Initialized
INFO - 2020-08-28 08:10:52 --> URI Class Initialized
INFO - 2020-08-28 08:10:52 --> Router Class Initialized
INFO - 2020-08-28 08:10:52 --> Output Class Initialized
INFO - 2020-08-28 08:10:52 --> Security Class Initialized
DEBUG - 2020-08-28 08:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-28 08:10:52 --> Input Class Initialized
INFO - 2020-08-28 08:10:52 --> Language Class Initialized
INFO - 2020-08-28 08:10:52 --> Loader Class Initialized
INFO - 2020-08-28 08:10:52 --> Helper loaded: url_helper
INFO - 2020-08-28 08:10:52 --> Database Driver Class Initialized
INFO - 2020-08-28 08:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-28 08:10:52 --> Email Class Initialized
INFO - 2020-08-28 08:10:52 --> Controller Class Initialized
DEBUG - 2020-08-28 08:10:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-28 08:10:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-28 08:10:52 --> Helper loaded: form_helper
INFO - 2020-08-28 08:10:52 --> Form Validation Class Initialized
INFO - 2020-08-28 08:10:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-28 08:10:52 --> Final output sent to browser
DEBUG - 2020-08-28 08:10:52 --> Total execution time: 0.0198
