<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-25 14:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 14:27:24 --> Config Class Initialized
INFO - 2020-11-25 14:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-25 14:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-25 14:27:24 --> Utf8 Class Initialized
INFO - 2020-11-25 14:27:24 --> URI Class Initialized
DEBUG - 2020-11-25 14:27:24 --> No URI present. Default controller set.
INFO - 2020-11-25 14:27:24 --> Router Class Initialized
INFO - 2020-11-25 14:27:24 --> Output Class Initialized
INFO - 2020-11-25 14:27:24 --> Security Class Initialized
DEBUG - 2020-11-25 14:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 14:27:24 --> Input Class Initialized
INFO - 2020-11-25 14:27:24 --> Language Class Initialized
INFO - 2020-11-25 14:27:24 --> Loader Class Initialized
INFO - 2020-11-25 14:27:24 --> Helper loaded: url_helper
INFO - 2020-11-25 14:27:24 --> Database Driver Class Initialized
INFO - 2020-11-25 14:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 14:27:24 --> Email Class Initialized
INFO - 2020-11-25 14:27:24 --> Controller Class Initialized
INFO - 2020-11-25 14:27:24 --> Model Class Initialized
INFO - 2020-11-25 14:27:24 --> Model Class Initialized
DEBUG - 2020-11-25 14:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 14:27:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 14:27:24 --> Final output sent to browser
DEBUG - 2020-11-25 14:27:24 --> Total execution time: 0.1618
ERROR - 2020-11-25 21:19:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:23 --> Config Class Initialized
INFO - 2020-11-25 21:19:23 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:23 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:23 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:23 --> URI Class Initialized
DEBUG - 2020-11-25 21:19:23 --> No URI present. Default controller set.
INFO - 2020-11-25 21:19:23 --> Router Class Initialized
INFO - 2020-11-25 21:19:23 --> Output Class Initialized
INFO - 2020-11-25 21:19:23 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:23 --> Input Class Initialized
INFO - 2020-11-25 21:19:23 --> Language Class Initialized
INFO - 2020-11-25 21:19:23 --> Loader Class Initialized
INFO - 2020-11-25 21:19:23 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:23 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:23 --> Email Class Initialized
INFO - 2020-11-25 21:19:23 --> Controller Class Initialized
INFO - 2020-11-25 21:19:23 --> Model Class Initialized
INFO - 2020-11-25 21:19:23 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:19:23 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:23 --> Total execution time: 0.0170
ERROR - 2020-11-25 21:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-11-25 21:19:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:26 --> Config Class Initialized
INFO - 2020-11-25 21:19:26 --> Hooks Class Initialized
INFO - 2020-11-25 21:19:26 --> Config Class Initialized
INFO - 2020-11-25 21:19:26 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:26 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:26 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:26 --> URI Class Initialized
DEBUG - 2020-11-25 21:19:26 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:26 --> Utf8 Class Initialized
DEBUG - 2020-11-25 21:19:26 --> No URI present. Default controller set.
INFO - 2020-11-25 21:19:26 --> Router Class Initialized
INFO - 2020-11-25 21:19:26 --> URI Class Initialized
INFO - 2020-11-25 21:19:26 --> Output Class Initialized
DEBUG - 2020-11-25 21:19:26 --> No URI present. Default controller set.
INFO - 2020-11-25 21:19:26 --> Router Class Initialized
INFO - 2020-11-25 21:19:26 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:26 --> Input Class Initialized
INFO - 2020-11-25 21:19:26 --> Output Class Initialized
INFO - 2020-11-25 21:19:26 --> Language Class Initialized
INFO - 2020-11-25 21:19:26 --> Security Class Initialized
INFO - 2020-11-25 21:19:26 --> Loader Class Initialized
DEBUG - 2020-11-25 21:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:26 --> Input Class Initialized
INFO - 2020-11-25 21:19:26 --> Language Class Initialized
INFO - 2020-11-25 21:19:26 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:26 --> Loader Class Initialized
INFO - 2020-11-25 21:19:26 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:26 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:26 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:26 --> Email Class Initialized
INFO - 2020-11-25 21:19:26 --> Controller Class Initialized
INFO - 2020-11-25 21:19:26 --> Model Class Initialized
INFO - 2020-11-25 21:19:26 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:19:26 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:26 --> Total execution time: 0.0171
INFO - 2020-11-25 21:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:26 --> Email Class Initialized
INFO - 2020-11-25 21:19:26 --> Controller Class Initialized
INFO - 2020-11-25 21:19:26 --> Model Class Initialized
INFO - 2020-11-25 21:19:26 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:19:26 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:26 --> Total execution time: 0.0209
ERROR - 2020-11-25 21:19:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:43 --> Config Class Initialized
INFO - 2020-11-25 21:19:43 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:43 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:43 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:43 --> URI Class Initialized
INFO - 2020-11-25 21:19:43 --> Router Class Initialized
INFO - 2020-11-25 21:19:43 --> Output Class Initialized
INFO - 2020-11-25 21:19:43 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:43 --> Input Class Initialized
INFO - 2020-11-25 21:19:43 --> Language Class Initialized
INFO - 2020-11-25 21:19:43 --> Loader Class Initialized
INFO - 2020-11-25 21:19:43 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:43 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:43 --> Email Class Initialized
INFO - 2020-11-25 21:19:43 --> Controller Class Initialized
INFO - 2020-11-25 21:19:43 --> Model Class Initialized
INFO - 2020-11-25 21:19:43 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:43 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:19:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:44 --> Config Class Initialized
INFO - 2020-11-25 21:19:44 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:44 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:44 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:44 --> URI Class Initialized
INFO - 2020-11-25 21:19:44 --> Router Class Initialized
INFO - 2020-11-25 21:19:44 --> Output Class Initialized
INFO - 2020-11-25 21:19:44 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:44 --> Input Class Initialized
INFO - 2020-11-25 21:19:44 --> Language Class Initialized
INFO - 2020-11-25 21:19:44 --> Loader Class Initialized
INFO - 2020-11-25 21:19:44 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:44 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:44 --> Email Class Initialized
INFO - 2020-11-25 21:19:44 --> Controller Class Initialized
DEBUG - 2020-11-25 21:19:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:19:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:44 --> Model Class Initialized
INFO - 2020-11-25 21:19:44 --> Model Class Initialized
INFO - 2020-11-25 21:19:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-25 21:19:44 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:44 --> Total execution time: 0.0667
ERROR - 2020-11-25 21:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:45 --> Config Class Initialized
INFO - 2020-11-25 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:45 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:45 --> URI Class Initialized
INFO - 2020-11-25 21:19:45 --> Router Class Initialized
INFO - 2020-11-25 21:19:45 --> Output Class Initialized
INFO - 2020-11-25 21:19:45 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:45 --> Input Class Initialized
INFO - 2020-11-25 21:19:45 --> Language Class Initialized
INFO - 2020-11-25 21:19:45 --> Loader Class Initialized
INFO - 2020-11-25 21:19:45 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:45 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:45 --> Email Class Initialized
INFO - 2020-11-25 21:19:45 --> Controller Class Initialized
INFO - 2020-11-25 21:19:45 --> Model Class Initialized
INFO - 2020-11-25 21:19:45 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:19:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:45 --> Config Class Initialized
INFO - 2020-11-25 21:19:45 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:45 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:45 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:45 --> URI Class Initialized
INFO - 2020-11-25 21:19:45 --> Router Class Initialized
INFO - 2020-11-25 21:19:45 --> Output Class Initialized
INFO - 2020-11-25 21:19:45 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:45 --> Input Class Initialized
INFO - 2020-11-25 21:19:45 --> Language Class Initialized
INFO - 2020-11-25 21:19:45 --> Loader Class Initialized
INFO - 2020-11-25 21:19:45 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:45 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:45 --> Email Class Initialized
INFO - 2020-11-25 21:19:45 --> Controller Class Initialized
DEBUG - 2020-11-25 21:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:19:45 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:46 --> Config Class Initialized
INFO - 2020-11-25 21:19:46 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:46 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:46 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:46 --> URI Class Initialized
DEBUG - 2020-11-25 21:19:46 --> No URI present. Default controller set.
INFO - 2020-11-25 21:19:46 --> Router Class Initialized
INFO - 2020-11-25 21:19:46 --> Output Class Initialized
INFO - 2020-11-25 21:19:46 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:46 --> Input Class Initialized
INFO - 2020-11-25 21:19:46 --> Language Class Initialized
INFO - 2020-11-25 21:19:46 --> Loader Class Initialized
INFO - 2020-11-25 21:19:46 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:46 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:46 --> Email Class Initialized
INFO - 2020-11-25 21:19:46 --> Controller Class Initialized
INFO - 2020-11-25 21:19:46 --> Model Class Initialized
INFO - 2020-11-25 21:19:46 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:19:46 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:46 --> Total execution time: 0.0208
ERROR - 2020-11-25 21:19:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:46 --> Config Class Initialized
INFO - 2020-11-25 21:19:46 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:46 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:46 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:46 --> URI Class Initialized
DEBUG - 2020-11-25 21:19:46 --> No URI present. Default controller set.
INFO - 2020-11-25 21:19:46 --> Router Class Initialized
INFO - 2020-11-25 21:19:46 --> Output Class Initialized
INFO - 2020-11-25 21:19:46 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:46 --> Input Class Initialized
INFO - 2020-11-25 21:19:46 --> Language Class Initialized
INFO - 2020-11-25 21:19:46 --> Loader Class Initialized
INFO - 2020-11-25 21:19:46 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:46 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:46 --> Email Class Initialized
INFO - 2020-11-25 21:19:46 --> Controller Class Initialized
INFO - 2020-11-25 21:19:46 --> Model Class Initialized
INFO - 2020-11-25 21:19:46 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:19:46 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:46 --> Total execution time: 0.0198
ERROR - 2020-11-25 21:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:54 --> Config Class Initialized
INFO - 2020-11-25 21:19:54 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:54 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:54 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:54 --> URI Class Initialized
INFO - 2020-11-25 21:19:54 --> Router Class Initialized
INFO - 2020-11-25 21:19:54 --> Output Class Initialized
INFO - 2020-11-25 21:19:54 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:54 --> Input Class Initialized
INFO - 2020-11-25 21:19:54 --> Language Class Initialized
INFO - 2020-11-25 21:19:54 --> Loader Class Initialized
INFO - 2020-11-25 21:19:54 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:54 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:54 --> Email Class Initialized
INFO - 2020-11-25 21:19:54 --> Controller Class Initialized
DEBUG - 2020-11-25 21:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:54 --> Model Class Initialized
INFO - 2020-11-25 21:19:54 --> Model Class Initialized
INFO - 2020-11-25 21:19:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-25 21:19:54 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:54 --> Total execution time: 0.0314
ERROR - 2020-11-25 21:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:55 --> Config Class Initialized
INFO - 2020-11-25 21:19:55 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:55 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:55 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:55 --> URI Class Initialized
INFO - 2020-11-25 21:19:55 --> Router Class Initialized
INFO - 2020-11-25 21:19:55 --> Output Class Initialized
INFO - 2020-11-25 21:19:55 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:55 --> Input Class Initialized
INFO - 2020-11-25 21:19:55 --> Language Class Initialized
INFO - 2020-11-25 21:19:55 --> Loader Class Initialized
INFO - 2020-11-25 21:19:55 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:55 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:55 --> Email Class Initialized
INFO - 2020-11-25 21:19:55 --> Controller Class Initialized
DEBUG - 2020-11-25 21:19:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:19:55 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:19:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:19:56 --> Config Class Initialized
INFO - 2020-11-25 21:19:56 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:19:56 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:19:56 --> Utf8 Class Initialized
INFO - 2020-11-25 21:19:56 --> URI Class Initialized
DEBUG - 2020-11-25 21:19:56 --> No URI present. Default controller set.
INFO - 2020-11-25 21:19:56 --> Router Class Initialized
INFO - 2020-11-25 21:19:56 --> Output Class Initialized
INFO - 2020-11-25 21:19:56 --> Security Class Initialized
DEBUG - 2020-11-25 21:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:19:56 --> Input Class Initialized
INFO - 2020-11-25 21:19:56 --> Language Class Initialized
INFO - 2020-11-25 21:19:56 --> Loader Class Initialized
INFO - 2020-11-25 21:19:56 --> Helper loaded: url_helper
INFO - 2020-11-25 21:19:56 --> Database Driver Class Initialized
INFO - 2020-11-25 21:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:19:56 --> Email Class Initialized
INFO - 2020-11-25 21:19:56 --> Controller Class Initialized
INFO - 2020-11-25 21:19:56 --> Model Class Initialized
INFO - 2020-11-25 21:19:56 --> Model Class Initialized
DEBUG - 2020-11-25 21:19:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:19:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:19:56 --> Final output sent to browser
DEBUG - 2020-11-25 21:19:56 --> Total execution time: 0.0188
ERROR - 2020-11-25 21:20:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:06 --> Config Class Initialized
INFO - 2020-11-25 21:20:06 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:06 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:06 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:06 --> URI Class Initialized
INFO - 2020-11-25 21:20:06 --> Router Class Initialized
INFO - 2020-11-25 21:20:06 --> Output Class Initialized
INFO - 2020-11-25 21:20:06 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:06 --> Input Class Initialized
INFO - 2020-11-25 21:20:06 --> Language Class Initialized
INFO - 2020-11-25 21:20:06 --> Loader Class Initialized
INFO - 2020-11-25 21:20:06 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:06 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:06 --> Email Class Initialized
INFO - 2020-11-25 21:20:06 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:06 --> Model Class Initialized
INFO - 2020-11-25 21:20:06 --> Model Class Initialized
INFO - 2020-11-25 21:20:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-11-25 21:20:06 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:06 --> Total execution time: 0.0370
ERROR - 2020-11-25 21:20:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:07 --> Config Class Initialized
INFO - 2020-11-25 21:20:07 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:07 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:07 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:07 --> URI Class Initialized
INFO - 2020-11-25 21:20:07 --> Router Class Initialized
INFO - 2020-11-25 21:20:07 --> Output Class Initialized
INFO - 2020-11-25 21:20:07 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:07 --> Input Class Initialized
INFO - 2020-11-25 21:20:07 --> Language Class Initialized
INFO - 2020-11-25 21:20:07 --> Loader Class Initialized
INFO - 2020-11-25 21:20:07 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:07 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:07 --> Email Class Initialized
INFO - 2020-11-25 21:20:07 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:07 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:20:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:08 --> Config Class Initialized
INFO - 2020-11-25 21:20:08 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:08 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:08 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:08 --> URI Class Initialized
DEBUG - 2020-11-25 21:20:08 --> No URI present. Default controller set.
INFO - 2020-11-25 21:20:08 --> Router Class Initialized
INFO - 2020-11-25 21:20:08 --> Output Class Initialized
INFO - 2020-11-25 21:20:08 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:08 --> Input Class Initialized
INFO - 2020-11-25 21:20:08 --> Language Class Initialized
INFO - 2020-11-25 21:20:08 --> Loader Class Initialized
INFO - 2020-11-25 21:20:08 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:08 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:08 --> Email Class Initialized
INFO - 2020-11-25 21:20:08 --> Controller Class Initialized
INFO - 2020-11-25 21:20:08 --> Model Class Initialized
INFO - 2020-11-25 21:20:08 --> Model Class Initialized
DEBUG - 2020-11-25 21:20:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:20:08 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:08 --> Total execution time: 0.0166
ERROR - 2020-11-25 21:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:13 --> Config Class Initialized
INFO - 2020-11-25 21:20:13 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:13 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:13 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:13 --> URI Class Initialized
INFO - 2020-11-25 21:20:13 --> Router Class Initialized
INFO - 2020-11-25 21:20:13 --> Output Class Initialized
INFO - 2020-11-25 21:20:13 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:13 --> Input Class Initialized
INFO - 2020-11-25 21:20:13 --> Language Class Initialized
INFO - 2020-11-25 21:20:13 --> Loader Class Initialized
INFO - 2020-11-25 21:20:13 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:13 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:13 --> Email Class Initialized
INFO - 2020-11-25 21:20:13 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:13 --> Model Class Initialized
INFO - 2020-11-25 21:20:13 --> Model Class Initialized
INFO - 2020-11-25 21:20:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-25 21:20:13 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:13 --> Total execution time: 0.0366
ERROR - 2020-11-25 21:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:14 --> Config Class Initialized
INFO - 2020-11-25 21:20:14 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:14 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:14 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:14 --> URI Class Initialized
INFO - 2020-11-25 21:20:14 --> Router Class Initialized
INFO - 2020-11-25 21:20:14 --> Output Class Initialized
INFO - 2020-11-25 21:20:14 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:14 --> Input Class Initialized
INFO - 2020-11-25 21:20:14 --> Language Class Initialized
INFO - 2020-11-25 21:20:14 --> Loader Class Initialized
INFO - 2020-11-25 21:20:14 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:14 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:14 --> Email Class Initialized
INFO - 2020-11-25 21:20:14 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:14 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:20:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:15 --> Config Class Initialized
INFO - 2020-11-25 21:20:15 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:15 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:15 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:15 --> URI Class Initialized
DEBUG - 2020-11-25 21:20:15 --> No URI present. Default controller set.
INFO - 2020-11-25 21:20:15 --> Router Class Initialized
INFO - 2020-11-25 21:20:15 --> Output Class Initialized
INFO - 2020-11-25 21:20:15 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:15 --> Input Class Initialized
INFO - 2020-11-25 21:20:15 --> Language Class Initialized
INFO - 2020-11-25 21:20:15 --> Loader Class Initialized
INFO - 2020-11-25 21:20:15 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:15 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:15 --> Email Class Initialized
INFO - 2020-11-25 21:20:15 --> Controller Class Initialized
INFO - 2020-11-25 21:20:15 --> Model Class Initialized
INFO - 2020-11-25 21:20:15 --> Model Class Initialized
DEBUG - 2020-11-25 21:20:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:20:15 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:15 --> Total execution time: 0.0177
ERROR - 2020-11-25 21:20:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:48 --> Config Class Initialized
INFO - 2020-11-25 21:20:48 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:48 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:48 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:48 --> URI Class Initialized
INFO - 2020-11-25 21:20:48 --> Router Class Initialized
INFO - 2020-11-25 21:20:48 --> Output Class Initialized
INFO - 2020-11-25 21:20:48 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:48 --> Input Class Initialized
INFO - 2020-11-25 21:20:48 --> Language Class Initialized
INFO - 2020-11-25 21:20:48 --> Loader Class Initialized
INFO - 2020-11-25 21:20:48 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:48 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:48 --> Email Class Initialized
INFO - 2020-11-25 21:20:48 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:48 --> Model Class Initialized
INFO - 2020-11-25 21:20:49 --> Model Class Initialized
INFO - 2020-11-25 21:20:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-25 21:20:49 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:49 --> Total execution time: 0.0680
ERROR - 2020-11-25 21:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:50 --> Config Class Initialized
INFO - 2020-11-25 21:20:50 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:50 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:50 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:50 --> URI Class Initialized
INFO - 2020-11-25 21:20:50 --> Router Class Initialized
INFO - 2020-11-25 21:20:50 --> Output Class Initialized
INFO - 2020-11-25 21:20:50 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:50 --> Input Class Initialized
INFO - 2020-11-25 21:20:50 --> Language Class Initialized
INFO - 2020-11-25 21:20:50 --> Loader Class Initialized
INFO - 2020-11-25 21:20:50 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:50 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:50 --> Email Class Initialized
INFO - 2020-11-25 21:20:50 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:50 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:20:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:50 --> Config Class Initialized
INFO - 2020-11-25 21:20:50 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:50 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:50 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:50 --> URI Class Initialized
DEBUG - 2020-11-25 21:20:50 --> No URI present. Default controller set.
INFO - 2020-11-25 21:20:50 --> Router Class Initialized
INFO - 2020-11-25 21:20:50 --> Output Class Initialized
INFO - 2020-11-25 21:20:50 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:50 --> Input Class Initialized
INFO - 2020-11-25 21:20:50 --> Language Class Initialized
INFO - 2020-11-25 21:20:50 --> Loader Class Initialized
INFO - 2020-11-25 21:20:50 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:50 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:50 --> Email Class Initialized
INFO - 2020-11-25 21:20:50 --> Controller Class Initialized
INFO - 2020-11-25 21:20:50 --> Model Class Initialized
INFO - 2020-11-25 21:20:50 --> Model Class Initialized
DEBUG - 2020-11-25 21:20:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:20:50 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:50 --> Total execution time: 0.0198
ERROR - 2020-11-25 21:20:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:20:59 --> Config Class Initialized
INFO - 2020-11-25 21:20:59 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:20:59 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:20:59 --> Utf8 Class Initialized
INFO - 2020-11-25 21:20:59 --> URI Class Initialized
INFO - 2020-11-25 21:20:59 --> Router Class Initialized
INFO - 2020-11-25 21:20:59 --> Output Class Initialized
INFO - 2020-11-25 21:20:59 --> Security Class Initialized
DEBUG - 2020-11-25 21:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:20:59 --> Input Class Initialized
INFO - 2020-11-25 21:20:59 --> Language Class Initialized
INFO - 2020-11-25 21:20:59 --> Loader Class Initialized
INFO - 2020-11-25 21:20:59 --> Helper loaded: url_helper
INFO - 2020-11-25 21:20:59 --> Database Driver Class Initialized
INFO - 2020-11-25 21:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:20:59 --> Email Class Initialized
INFO - 2020-11-25 21:20:59 --> Controller Class Initialized
DEBUG - 2020-11-25 21:20:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:20:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:20:59 --> Model Class Initialized
INFO - 2020-11-25 21:20:59 --> Model Class Initialized
INFO - 2020-11-25 21:20:59 --> Model Class Initialized
INFO - 2020-11-25 21:20:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-11-25 21:20:59 --> Final output sent to browser
DEBUG - 2020-11-25 21:20:59 --> Total execution time: 0.0345
ERROR - 2020-11-25 21:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:00 --> Config Class Initialized
INFO - 2020-11-25 21:21:00 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:00 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:00 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:00 --> URI Class Initialized
INFO - 2020-11-25 21:21:00 --> Router Class Initialized
INFO - 2020-11-25 21:21:00 --> Output Class Initialized
INFO - 2020-11-25 21:21:00 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:00 --> Input Class Initialized
INFO - 2020-11-25 21:21:00 --> Language Class Initialized
INFO - 2020-11-25 21:21:00 --> Loader Class Initialized
INFO - 2020-11-25 21:21:00 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:00 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:00 --> Email Class Initialized
INFO - 2020-11-25 21:21:00 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:00 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:00 --> Config Class Initialized
INFO - 2020-11-25 21:21:00 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:00 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:00 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:00 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:00 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:00 --> Router Class Initialized
INFO - 2020-11-25 21:21:00 --> Output Class Initialized
INFO - 2020-11-25 21:21:00 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:00 --> Input Class Initialized
INFO - 2020-11-25 21:21:00 --> Language Class Initialized
INFO - 2020-11-25 21:21:00 --> Loader Class Initialized
INFO - 2020-11-25 21:21:00 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:00 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:00 --> Email Class Initialized
INFO - 2020-11-25 21:21:00 --> Controller Class Initialized
INFO - 2020-11-25 21:21:00 --> Model Class Initialized
INFO - 2020-11-25 21:21:00 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:00 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:00 --> Total execution time: 0.0188
ERROR - 2020-11-25 21:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:05 --> Config Class Initialized
INFO - 2020-11-25 21:21:05 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:05 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:05 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:05 --> URI Class Initialized
INFO - 2020-11-25 21:21:05 --> Router Class Initialized
INFO - 2020-11-25 21:21:05 --> Output Class Initialized
INFO - 2020-11-25 21:21:05 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:05 --> Input Class Initialized
INFO - 2020-11-25 21:21:05 --> Language Class Initialized
INFO - 2020-11-25 21:21:05 --> Loader Class Initialized
INFO - 2020-11-25 21:21:05 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:05 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:05 --> Email Class Initialized
INFO - 2020-11-25 21:21:05 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:05 --> Model Class Initialized
INFO - 2020-11-25 21:21:05 --> Model Class Initialized
INFO - 2020-11-25 21:21:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-25 21:21:05 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:05 --> Total execution time: 0.0243
ERROR - 2020-11-25 21:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:06 --> Config Class Initialized
INFO - 2020-11-25 21:21:06 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:06 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:06 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:06 --> URI Class Initialized
INFO - 2020-11-25 21:21:06 --> Router Class Initialized
INFO - 2020-11-25 21:21:06 --> Output Class Initialized
INFO - 2020-11-25 21:21:06 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:06 --> Input Class Initialized
INFO - 2020-11-25 21:21:06 --> Language Class Initialized
INFO - 2020-11-25 21:21:06 --> Loader Class Initialized
INFO - 2020-11-25 21:21:06 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:06 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:06 --> Email Class Initialized
INFO - 2020-11-25 21:21:06 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:06 --> Model Class Initialized
INFO - 2020-11-25 21:21:06 --> Model Class Initialized
INFO - 2020-11-25 21:21:06 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:06 --> Total execution time: 0.0404
ERROR - 2020-11-25 21:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:06 --> Config Class Initialized
INFO - 2020-11-25 21:21:06 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:06 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:06 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:06 --> URI Class Initialized
INFO - 2020-11-25 21:21:06 --> Router Class Initialized
INFO - 2020-11-25 21:21:06 --> Output Class Initialized
INFO - 2020-11-25 21:21:06 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:06 --> Input Class Initialized
INFO - 2020-11-25 21:21:06 --> Language Class Initialized
INFO - 2020-11-25 21:21:06 --> Loader Class Initialized
INFO - 2020-11-25 21:21:06 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:06 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:06 --> Email Class Initialized
INFO - 2020-11-25 21:21:06 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:06 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:07 --> Config Class Initialized
INFO - 2020-11-25 21:21:07 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:07 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:07 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:07 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:07 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:07 --> Router Class Initialized
INFO - 2020-11-25 21:21:07 --> Output Class Initialized
INFO - 2020-11-25 21:21:07 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:07 --> Input Class Initialized
INFO - 2020-11-25 21:21:07 --> Language Class Initialized
INFO - 2020-11-25 21:21:07 --> Loader Class Initialized
INFO - 2020-11-25 21:21:07 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:07 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:07 --> Email Class Initialized
INFO - 2020-11-25 21:21:07 --> Controller Class Initialized
INFO - 2020-11-25 21:21:07 --> Model Class Initialized
INFO - 2020-11-25 21:21:07 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:07 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:07 --> Total execution time: 0.0163
ERROR - 2020-11-25 21:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:08 --> Config Class Initialized
INFO - 2020-11-25 21:21:08 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:08 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:08 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:08 --> URI Class Initialized
INFO - 2020-11-25 21:21:08 --> Router Class Initialized
INFO - 2020-11-25 21:21:08 --> Output Class Initialized
INFO - 2020-11-25 21:21:08 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:08 --> Input Class Initialized
INFO - 2020-11-25 21:21:08 --> Language Class Initialized
INFO - 2020-11-25 21:21:08 --> Loader Class Initialized
INFO - 2020-11-25 21:21:08 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:08 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:08 --> Email Class Initialized
INFO - 2020-11-25 21:21:08 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:08 --> Model Class Initialized
INFO - 2020-11-25 21:21:08 --> Model Class Initialized
INFO - 2020-11-25 21:21:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-25 21:21:10 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:10 --> Total execution time: 1.5080
ERROR - 2020-11-25 21:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:11 --> Config Class Initialized
INFO - 2020-11-25 21:21:11 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:11 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:11 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:11 --> URI Class Initialized
INFO - 2020-11-25 21:21:11 --> Router Class Initialized
INFO - 2020-11-25 21:21:11 --> Output Class Initialized
INFO - 2020-11-25 21:21:11 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:11 --> Input Class Initialized
INFO - 2020-11-25 21:21:11 --> Language Class Initialized
INFO - 2020-11-25 21:21:11 --> Loader Class Initialized
INFO - 2020-11-25 21:21:11 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:11 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:11 --> Email Class Initialized
INFO - 2020-11-25 21:21:11 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:11 --> Model Class Initialized
INFO - 2020-11-25 21:21:11 --> Model Class Initialized
INFO - 2020-11-25 21:21:11 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:11 --> Total execution time: 0.0219
ERROR - 2020-11-25 21:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:11 --> Config Class Initialized
INFO - 2020-11-25 21:21:11 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:11 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:11 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:11 --> URI Class Initialized
INFO - 2020-11-25 21:21:11 --> Router Class Initialized
INFO - 2020-11-25 21:21:11 --> Output Class Initialized
INFO - 2020-11-25 21:21:11 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:11 --> Input Class Initialized
INFO - 2020-11-25 21:21:11 --> Language Class Initialized
INFO - 2020-11-25 21:21:11 --> Loader Class Initialized
INFO - 2020-11-25 21:21:11 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:11 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:11 --> Email Class Initialized
INFO - 2020-11-25 21:21:11 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:11 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:11 --> Config Class Initialized
INFO - 2020-11-25 21:21:11 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:11 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:11 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:11 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:11 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:11 --> Router Class Initialized
INFO - 2020-11-25 21:21:11 --> Output Class Initialized
INFO - 2020-11-25 21:21:11 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:11 --> Input Class Initialized
INFO - 2020-11-25 21:21:11 --> Language Class Initialized
INFO - 2020-11-25 21:21:11 --> Loader Class Initialized
INFO - 2020-11-25 21:21:11 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:11 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:11 --> Email Class Initialized
INFO - 2020-11-25 21:21:11 --> Controller Class Initialized
INFO - 2020-11-25 21:21:11 --> Model Class Initialized
INFO - 2020-11-25 21:21:11 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:11 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:11 --> Total execution time: 0.0206
ERROR - 2020-11-25 21:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:12 --> Config Class Initialized
INFO - 2020-11-25 21:21:12 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:12 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:12 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:12 --> URI Class Initialized
INFO - 2020-11-25 21:21:12 --> Router Class Initialized
INFO - 2020-11-25 21:21:12 --> Output Class Initialized
INFO - 2020-11-25 21:21:12 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:12 --> Input Class Initialized
INFO - 2020-11-25 21:21:12 --> Language Class Initialized
INFO - 2020-11-25 21:21:12 --> Loader Class Initialized
INFO - 2020-11-25 21:21:12 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:12 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:13 --> Email Class Initialized
INFO - 2020-11-25 21:21:13 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:13 --> Model Class Initialized
INFO - 2020-11-25 21:21:13 --> Model Class Initialized
INFO - 2020-11-25 21:21:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-25 21:21:13 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:13 --> Total execution time: 0.0445
ERROR - 2020-11-25 21:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:13 --> Config Class Initialized
INFO - 2020-11-25 21:21:13 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:13 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:13 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:13 --> URI Class Initialized
INFO - 2020-11-25 21:21:13 --> Router Class Initialized
INFO - 2020-11-25 21:21:13 --> Output Class Initialized
INFO - 2020-11-25 21:21:13 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:13 --> Input Class Initialized
INFO - 2020-11-25 21:21:13 --> Language Class Initialized
INFO - 2020-11-25 21:21:13 --> Loader Class Initialized
INFO - 2020-11-25 21:21:13 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:13 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:13 --> Email Class Initialized
INFO - 2020-11-25 21:21:13 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:13 --> Model Class Initialized
INFO - 2020-11-25 21:21:13 --> Model Class Initialized
INFO - 2020-11-25 21:21:13 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:13 --> Total execution time: 0.0224
ERROR - 2020-11-25 21:21:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:13 --> Config Class Initialized
INFO - 2020-11-25 21:21:13 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:13 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:13 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:13 --> URI Class Initialized
INFO - 2020-11-25 21:21:13 --> Router Class Initialized
INFO - 2020-11-25 21:21:13 --> Output Class Initialized
INFO - 2020-11-25 21:21:13 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:13 --> Input Class Initialized
INFO - 2020-11-25 21:21:13 --> Language Class Initialized
INFO - 2020-11-25 21:21:13 --> Loader Class Initialized
INFO - 2020-11-25 21:21:13 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:13 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:13 --> Email Class Initialized
INFO - 2020-11-25 21:21:13 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:13 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:18 --> Config Class Initialized
INFO - 2020-11-25 21:21:18 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:18 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:18 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:18 --> URI Class Initialized
INFO - 2020-11-25 21:21:18 --> Router Class Initialized
INFO - 2020-11-25 21:21:18 --> Output Class Initialized
INFO - 2020-11-25 21:21:18 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:18 --> Input Class Initialized
INFO - 2020-11-25 21:21:18 --> Language Class Initialized
INFO - 2020-11-25 21:21:18 --> Loader Class Initialized
INFO - 2020-11-25 21:21:18 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:18 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:18 --> Email Class Initialized
INFO - 2020-11-25 21:21:18 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:18 --> Model Class Initialized
INFO - 2020-11-25 21:21:18 --> Model Class Initialized
INFO - 2020-11-25 21:21:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-25 21:21:19 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:19 --> Total execution time: 1.4326
ERROR - 2020-11-25 21:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:20 --> Config Class Initialized
INFO - 2020-11-25 21:21:20 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:20 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:20 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:20 --> URI Class Initialized
INFO - 2020-11-25 21:21:20 --> Router Class Initialized
INFO - 2020-11-25 21:21:20 --> Output Class Initialized
INFO - 2020-11-25 21:21:20 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:20 --> Input Class Initialized
INFO - 2020-11-25 21:21:20 --> Language Class Initialized
INFO - 2020-11-25 21:21:20 --> Loader Class Initialized
INFO - 2020-11-25 21:21:20 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:20 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:20 --> Email Class Initialized
INFO - 2020-11-25 21:21:20 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:20 --> Model Class Initialized
INFO - 2020-11-25 21:21:20 --> Model Class Initialized
INFO - 2020-11-25 21:21:20 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:20 --> Total execution time: 0.0221
ERROR - 2020-11-25 21:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:20 --> Config Class Initialized
INFO - 2020-11-25 21:21:20 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:20 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:20 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:20 --> URI Class Initialized
INFO - 2020-11-25 21:21:20 --> Router Class Initialized
INFO - 2020-11-25 21:21:20 --> Output Class Initialized
INFO - 2020-11-25 21:21:20 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:20 --> Input Class Initialized
INFO - 2020-11-25 21:21:20 --> Language Class Initialized
INFO - 2020-11-25 21:21:20 --> Loader Class Initialized
INFO - 2020-11-25 21:21:20 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:20 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:20 --> Email Class Initialized
INFO - 2020-11-25 21:21:20 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:20 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:21 --> Config Class Initialized
INFO - 2020-11-25 21:21:21 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:21 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:21 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:21 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:21 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:21 --> Router Class Initialized
INFO - 2020-11-25 21:21:21 --> Output Class Initialized
INFO - 2020-11-25 21:21:21 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:21 --> Input Class Initialized
INFO - 2020-11-25 21:21:21 --> Language Class Initialized
INFO - 2020-11-25 21:21:21 --> Loader Class Initialized
INFO - 2020-11-25 21:21:21 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:21 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:21 --> Email Class Initialized
INFO - 2020-11-25 21:21:21 --> Controller Class Initialized
INFO - 2020-11-25 21:21:21 --> Model Class Initialized
INFO - 2020-11-25 21:21:21 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:21 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:21 --> Total execution time: 0.0184
ERROR - 2020-11-25 21:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:24 --> Config Class Initialized
INFO - 2020-11-25 21:21:24 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:24 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:24 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:24 --> URI Class Initialized
INFO - 2020-11-25 21:21:24 --> Router Class Initialized
INFO - 2020-11-25 21:21:24 --> Output Class Initialized
INFO - 2020-11-25 21:21:24 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:24 --> Input Class Initialized
INFO - 2020-11-25 21:21:24 --> Language Class Initialized
INFO - 2020-11-25 21:21:24 --> Loader Class Initialized
INFO - 2020-11-25 21:21:24 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:24 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:24 --> Email Class Initialized
INFO - 2020-11-25 21:21:24 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:24 --> Model Class Initialized
INFO - 2020-11-25 21:21:24 --> Model Class Initialized
INFO - 2020-11-25 21:21:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-25 21:21:24 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:24 --> Total execution time: 0.0197
ERROR - 2020-11-25 21:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:25 --> Config Class Initialized
INFO - 2020-11-25 21:21:25 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:25 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:25 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:25 --> URI Class Initialized
INFO - 2020-11-25 21:21:25 --> Router Class Initialized
INFO - 2020-11-25 21:21:25 --> Output Class Initialized
INFO - 2020-11-25 21:21:25 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:25 --> Input Class Initialized
INFO - 2020-11-25 21:21:25 --> Language Class Initialized
INFO - 2020-11-25 21:21:25 --> Loader Class Initialized
INFO - 2020-11-25 21:21:25 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:25 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:25 --> Email Class Initialized
INFO - 2020-11-25 21:21:25 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:25 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:25 --> Config Class Initialized
INFO - 2020-11-25 21:21:25 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:25 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:25 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:25 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:25 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:25 --> Router Class Initialized
INFO - 2020-11-25 21:21:25 --> Output Class Initialized
INFO - 2020-11-25 21:21:25 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:25 --> Input Class Initialized
INFO - 2020-11-25 21:21:25 --> Language Class Initialized
INFO - 2020-11-25 21:21:25 --> Loader Class Initialized
INFO - 2020-11-25 21:21:25 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:25 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:25 --> Email Class Initialized
INFO - 2020-11-25 21:21:25 --> Controller Class Initialized
INFO - 2020-11-25 21:21:25 --> Model Class Initialized
INFO - 2020-11-25 21:21:25 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:25 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:25 --> Total execution time: 0.0170
ERROR - 2020-11-25 21:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:27 --> Config Class Initialized
INFO - 2020-11-25 21:21:27 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:27 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:27 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:27 --> URI Class Initialized
INFO - 2020-11-25 21:21:27 --> Router Class Initialized
INFO - 2020-11-25 21:21:27 --> Output Class Initialized
INFO - 2020-11-25 21:21:27 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:27 --> Input Class Initialized
INFO - 2020-11-25 21:21:27 --> Language Class Initialized
INFO - 2020-11-25 21:21:27 --> Loader Class Initialized
INFO - 2020-11-25 21:21:27 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:27 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:27 --> Email Class Initialized
INFO - 2020-11-25 21:21:27 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:27 --> Model Class Initialized
INFO - 2020-11-25 21:21:27 --> Model Class Initialized
INFO - 2020-11-25 21:21:27 --> Model Class Initialized
INFO - 2020-11-25 21:21:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-11-25 21:21:27 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:27 --> Total execution time: 0.0252
ERROR - 2020-11-25 21:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:28 --> Config Class Initialized
INFO - 2020-11-25 21:21:28 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:28 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:28 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:28 --> URI Class Initialized
INFO - 2020-11-25 21:21:28 --> Router Class Initialized
INFO - 2020-11-25 21:21:28 --> Output Class Initialized
INFO - 2020-11-25 21:21:28 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:28 --> Input Class Initialized
INFO - 2020-11-25 21:21:28 --> Language Class Initialized
INFO - 2020-11-25 21:21:28 --> Loader Class Initialized
INFO - 2020-11-25 21:21:28 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:28 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:28 --> Email Class Initialized
INFO - 2020-11-25 21:21:28 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:28 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:29 --> Config Class Initialized
INFO - 2020-11-25 21:21:29 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:29 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:29 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:29 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:29 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:29 --> Router Class Initialized
INFO - 2020-11-25 21:21:29 --> Output Class Initialized
INFO - 2020-11-25 21:21:29 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:29 --> Input Class Initialized
INFO - 2020-11-25 21:21:29 --> Language Class Initialized
INFO - 2020-11-25 21:21:29 --> Loader Class Initialized
INFO - 2020-11-25 21:21:29 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:29 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:29 --> Email Class Initialized
INFO - 2020-11-25 21:21:29 --> Controller Class Initialized
INFO - 2020-11-25 21:21:29 --> Model Class Initialized
INFO - 2020-11-25 21:21:29 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:29 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:29 --> Total execution time: 0.0161
ERROR - 2020-11-25 21:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:30 --> Config Class Initialized
INFO - 2020-11-25 21:21:30 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:30 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:30 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:30 --> URI Class Initialized
INFO - 2020-11-25 21:21:30 --> Router Class Initialized
INFO - 2020-11-25 21:21:30 --> Output Class Initialized
INFO - 2020-11-25 21:21:30 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:30 --> Input Class Initialized
INFO - 2020-11-25 21:21:30 --> Language Class Initialized
INFO - 2020-11-25 21:21:30 --> Loader Class Initialized
INFO - 2020-11-25 21:21:30 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:30 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:30 --> Email Class Initialized
INFO - 2020-11-25 21:21:30 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:30 --> Model Class Initialized
INFO - 2020-11-25 21:21:30 --> Model Class Initialized
INFO - 2020-11-25 21:21:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-25 21:21:30 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:30 --> Total execution time: 0.0230
ERROR - 2020-11-25 21:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:33 --> Config Class Initialized
INFO - 2020-11-25 21:21:33 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:33 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:33 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:33 --> URI Class Initialized
INFO - 2020-11-25 21:21:33 --> Router Class Initialized
INFO - 2020-11-25 21:21:33 --> Output Class Initialized
INFO - 2020-11-25 21:21:33 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:33 --> Input Class Initialized
INFO - 2020-11-25 21:21:33 --> Language Class Initialized
INFO - 2020-11-25 21:21:33 --> Loader Class Initialized
INFO - 2020-11-25 21:21:33 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:33 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:33 --> Email Class Initialized
INFO - 2020-11-25 21:21:33 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:33 --> Model Class Initialized
INFO - 2020-11-25 21:21:33 --> Model Class Initialized
INFO - 2020-11-25 21:21:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-25 21:21:33 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:33 --> Total execution time: 0.0186
ERROR - 2020-11-25 21:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:33 --> Config Class Initialized
INFO - 2020-11-25 21:21:33 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:33 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:33 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:33 --> URI Class Initialized
INFO - 2020-11-25 21:21:33 --> Router Class Initialized
INFO - 2020-11-25 21:21:33 --> Output Class Initialized
INFO - 2020-11-25 21:21:33 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:33 --> Input Class Initialized
INFO - 2020-11-25 21:21:33 --> Language Class Initialized
INFO - 2020-11-25 21:21:33 --> Loader Class Initialized
INFO - 2020-11-25 21:21:33 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:33 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:33 --> Email Class Initialized
INFO - 2020-11-25 21:21:33 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:33 --> Model Class Initialized
INFO - 2020-11-25 21:21:33 --> Model Class Initialized
INFO - 2020-11-25 21:21:33 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:33 --> Total execution time: 0.1733
ERROR - 2020-11-25 21:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:43 --> Config Class Initialized
INFO - 2020-11-25 21:21:43 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:43 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:43 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:43 --> URI Class Initialized
INFO - 2020-11-25 21:21:43 --> Router Class Initialized
INFO - 2020-11-25 21:21:43 --> Output Class Initialized
INFO - 2020-11-25 21:21:43 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:43 --> Input Class Initialized
INFO - 2020-11-25 21:21:43 --> Language Class Initialized
INFO - 2020-11-25 21:21:43 --> Loader Class Initialized
INFO - 2020-11-25 21:21:43 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:43 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:43 --> Email Class Initialized
INFO - 2020-11-25 21:21:43 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:43 --> Model Class Initialized
INFO - 2020-11-25 21:21:43 --> Model Class Initialized
INFO - 2020-11-25 21:21:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-25 21:21:43 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:43 --> Total execution time: 0.0252
ERROR - 2020-11-25 21:21:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:43 --> Config Class Initialized
INFO - 2020-11-25 21:21:43 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:43 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:43 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:43 --> URI Class Initialized
INFO - 2020-11-25 21:21:43 --> Router Class Initialized
INFO - 2020-11-25 21:21:43 --> Output Class Initialized
INFO - 2020-11-25 21:21:43 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:43 --> Input Class Initialized
INFO - 2020-11-25 21:21:43 --> Language Class Initialized
INFO - 2020-11-25 21:21:43 --> Loader Class Initialized
INFO - 2020-11-25 21:21:43 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:43 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:43 --> Email Class Initialized
INFO - 2020-11-25 21:21:43 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:43 --> Model Class Initialized
INFO - 2020-11-25 21:21:43 --> Model Class Initialized
INFO - 2020-11-25 21:21:43 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:43 --> Total execution time: 0.0229
ERROR - 2020-11-25 21:21:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:48 --> Config Class Initialized
INFO - 2020-11-25 21:21:48 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:48 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:48 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:48 --> URI Class Initialized
INFO - 2020-11-25 21:21:48 --> Router Class Initialized
INFO - 2020-11-25 21:21:48 --> Output Class Initialized
INFO - 2020-11-25 21:21:48 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:48 --> Input Class Initialized
INFO - 2020-11-25 21:21:48 --> Language Class Initialized
INFO - 2020-11-25 21:21:48 --> Loader Class Initialized
INFO - 2020-11-25 21:21:48 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:48 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:48 --> Email Class Initialized
INFO - 2020-11-25 21:21:48 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:48 --> Model Class Initialized
INFO - 2020-11-25 21:21:48 --> Model Class Initialized
INFO - 2020-11-25 21:21:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-25 21:21:50 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:50 --> Total execution time: 1.4574
ERROR - 2020-11-25 21:21:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:50 --> Config Class Initialized
INFO - 2020-11-25 21:21:50 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:50 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:50 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:50 --> URI Class Initialized
INFO - 2020-11-25 21:21:50 --> Router Class Initialized
INFO - 2020-11-25 21:21:50 --> Output Class Initialized
INFO - 2020-11-25 21:21:50 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:50 --> Input Class Initialized
INFO - 2020-11-25 21:21:50 --> Language Class Initialized
INFO - 2020-11-25 21:21:50 --> Loader Class Initialized
INFO - 2020-11-25 21:21:50 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:50 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:50 --> Email Class Initialized
INFO - 2020-11-25 21:21:50 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:50 --> Model Class Initialized
INFO - 2020-11-25 21:21:50 --> Model Class Initialized
INFO - 2020-11-25 21:21:50 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:50 --> Total execution time: 0.0216
ERROR - 2020-11-25 21:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:54 --> Config Class Initialized
INFO - 2020-11-25 21:21:54 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:54 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:54 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:54 --> URI Class Initialized
INFO - 2020-11-25 21:21:54 --> Router Class Initialized
INFO - 2020-11-25 21:21:54 --> Output Class Initialized
INFO - 2020-11-25 21:21:54 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:54 --> Input Class Initialized
INFO - 2020-11-25 21:21:54 --> Language Class Initialized
INFO - 2020-11-25 21:21:54 --> Loader Class Initialized
INFO - 2020-11-25 21:21:54 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:54 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:54 --> Email Class Initialized
INFO - 2020-11-25 21:21:54 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:54 --> Model Class Initialized
INFO - 2020-11-25 21:21:54 --> Model Class Initialized
INFO - 2020-11-25 21:21:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-25 21:21:55 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:55 --> Total execution time: 0.0213
ERROR - 2020-11-25 21:21:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:55 --> Config Class Initialized
INFO - 2020-11-25 21:21:55 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:55 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:55 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:55 --> URI Class Initialized
INFO - 2020-11-25 21:21:55 --> Router Class Initialized
INFO - 2020-11-25 21:21:55 --> Output Class Initialized
INFO - 2020-11-25 21:21:55 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:55 --> Input Class Initialized
INFO - 2020-11-25 21:21:55 --> Language Class Initialized
INFO - 2020-11-25 21:21:55 --> Loader Class Initialized
INFO - 2020-11-25 21:21:55 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:55 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:55 --> Email Class Initialized
INFO - 2020-11-25 21:21:55 --> Controller Class Initialized
DEBUG - 2020-11-25 21:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:21:55 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:21:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:21:56 --> Config Class Initialized
INFO - 2020-11-25 21:21:56 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:21:56 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:21:56 --> Utf8 Class Initialized
INFO - 2020-11-25 21:21:56 --> URI Class Initialized
DEBUG - 2020-11-25 21:21:56 --> No URI present. Default controller set.
INFO - 2020-11-25 21:21:56 --> Router Class Initialized
INFO - 2020-11-25 21:21:56 --> Output Class Initialized
INFO - 2020-11-25 21:21:56 --> Security Class Initialized
DEBUG - 2020-11-25 21:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:21:56 --> Input Class Initialized
INFO - 2020-11-25 21:21:56 --> Language Class Initialized
INFO - 2020-11-25 21:21:56 --> Loader Class Initialized
INFO - 2020-11-25 21:21:56 --> Helper loaded: url_helper
INFO - 2020-11-25 21:21:56 --> Database Driver Class Initialized
INFO - 2020-11-25 21:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:21:56 --> Email Class Initialized
INFO - 2020-11-25 21:21:56 --> Controller Class Initialized
INFO - 2020-11-25 21:21:56 --> Model Class Initialized
INFO - 2020-11-25 21:21:56 --> Model Class Initialized
DEBUG - 2020-11-25 21:21:56 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:21:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:21:56 --> Final output sent to browser
DEBUG - 2020-11-25 21:21:56 --> Total execution time: 0.0180
ERROR - 2020-11-25 21:22:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:02 --> Config Class Initialized
INFO - 2020-11-25 21:22:02 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:02 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:02 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:02 --> URI Class Initialized
INFO - 2020-11-25 21:22:02 --> Router Class Initialized
INFO - 2020-11-25 21:22:02 --> Output Class Initialized
INFO - 2020-11-25 21:22:02 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:02 --> Input Class Initialized
INFO - 2020-11-25 21:22:02 --> Language Class Initialized
INFO - 2020-11-25 21:22:02 --> Loader Class Initialized
INFO - 2020-11-25 21:22:02 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:02 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:02 --> Email Class Initialized
INFO - 2020-11-25 21:22:02 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:02 --> Model Class Initialized
INFO - 2020-11-25 21:22:02 --> Model Class Initialized
INFO - 2020-11-25 21:22:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-11-25 21:22:02 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:02 --> Total execution time: 0.0396
ERROR - 2020-11-25 21:22:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:03 --> Config Class Initialized
INFO - 2020-11-25 21:22:03 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:03 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:03 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:03 --> URI Class Initialized
INFO - 2020-11-25 21:22:03 --> Router Class Initialized
INFO - 2020-11-25 21:22:03 --> Output Class Initialized
INFO - 2020-11-25 21:22:03 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:03 --> Input Class Initialized
INFO - 2020-11-25 21:22:03 --> Language Class Initialized
INFO - 2020-11-25 21:22:03 --> Loader Class Initialized
INFO - 2020-11-25 21:22:03 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:03 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:03 --> Email Class Initialized
INFO - 2020-11-25 21:22:03 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:03 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-25 21:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:04 --> Config Class Initialized
INFO - 2020-11-25 21:22:04 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:04 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:04 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:04 --> URI Class Initialized
INFO - 2020-11-25 21:22:04 --> Router Class Initialized
INFO - 2020-11-25 21:22:04 --> Output Class Initialized
INFO - 2020-11-25 21:22:04 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:04 --> Input Class Initialized
INFO - 2020-11-25 21:22:04 --> Language Class Initialized
INFO - 2020-11-25 21:22:04 --> Loader Class Initialized
INFO - 2020-11-25 21:22:04 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:04 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:04 --> Email Class Initialized
INFO - 2020-11-25 21:22:04 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:04 --> Model Class Initialized
INFO - 2020-11-25 21:22:04 --> Model Class Initialized
INFO - 2020-11-25 21:22:04 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:04 --> Total execution time: 0.0243
ERROR - 2020-11-25 21:22:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:04 --> Config Class Initialized
INFO - 2020-11-25 21:22:04 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:04 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:04 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:04 --> URI Class Initialized
DEBUG - 2020-11-25 21:22:04 --> No URI present. Default controller set.
INFO - 2020-11-25 21:22:04 --> Router Class Initialized
INFO - 2020-11-25 21:22:04 --> Output Class Initialized
INFO - 2020-11-25 21:22:04 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:04 --> Input Class Initialized
INFO - 2020-11-25 21:22:04 --> Language Class Initialized
INFO - 2020-11-25 21:22:04 --> Loader Class Initialized
INFO - 2020-11-25 21:22:04 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:04 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:04 --> Email Class Initialized
INFO - 2020-11-25 21:22:04 --> Controller Class Initialized
INFO - 2020-11-25 21:22:04 --> Model Class Initialized
INFO - 2020-11-25 21:22:04 --> Model Class Initialized
DEBUG - 2020-11-25 21:22:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:22:04 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:04 --> Total execution time: 0.0184
ERROR - 2020-11-25 21:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:06 --> Config Class Initialized
INFO - 2020-11-25 21:22:06 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:06 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:06 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:06 --> URI Class Initialized
INFO - 2020-11-25 21:22:06 --> Router Class Initialized
INFO - 2020-11-25 21:22:06 --> Output Class Initialized
INFO - 2020-11-25 21:22:06 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:06 --> Input Class Initialized
INFO - 2020-11-25 21:22:06 --> Language Class Initialized
INFO - 2020-11-25 21:22:06 --> Loader Class Initialized
INFO - 2020-11-25 21:22:06 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:06 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:06 --> Email Class Initialized
INFO - 2020-11-25 21:22:06 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:06 --> Model Class Initialized
INFO - 2020-11-25 21:22:06 --> Model Class Initialized
INFO - 2020-11-25 21:22:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-25 21:22:06 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:06 --> Total execution time: 0.0222
ERROR - 2020-11-25 21:22:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:10 --> Config Class Initialized
INFO - 2020-11-25 21:22:10 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:10 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:10 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:10 --> URI Class Initialized
INFO - 2020-11-25 21:22:10 --> Router Class Initialized
INFO - 2020-11-25 21:22:10 --> Output Class Initialized
INFO - 2020-11-25 21:22:10 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:10 --> Input Class Initialized
INFO - 2020-11-25 21:22:10 --> Language Class Initialized
INFO - 2020-11-25 21:22:10 --> Loader Class Initialized
INFO - 2020-11-25 21:22:10 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:10 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:10 --> Email Class Initialized
INFO - 2020-11-25 21:22:10 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:10 --> Model Class Initialized
INFO - 2020-11-25 21:22:10 --> Model Class Initialized
INFO - 2020-11-25 21:22:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-25 21:22:10 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:10 --> Total execution time: 0.0238
ERROR - 2020-11-25 21:22:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:20 --> Config Class Initialized
INFO - 2020-11-25 21:22:20 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:20 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:20 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:20 --> URI Class Initialized
INFO - 2020-11-25 21:22:20 --> Router Class Initialized
INFO - 2020-11-25 21:22:20 --> Output Class Initialized
INFO - 2020-11-25 21:22:20 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:20 --> Input Class Initialized
INFO - 2020-11-25 21:22:20 --> Language Class Initialized
INFO - 2020-11-25 21:22:20 --> Loader Class Initialized
INFO - 2020-11-25 21:22:20 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:20 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:20 --> Email Class Initialized
INFO - 2020-11-25 21:22:20 --> Controller Class Initialized
INFO - 2020-11-25 21:22:20 --> Model Class Initialized
INFO - 2020-11-25 21:22:20 --> Model Class Initialized
INFO - 2020-11-25 21:22:20 --> Model Class Initialized
INFO - 2020-11-25 21:22:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-11-25 21:22:20 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:20 --> Total execution time: 0.2136
ERROR - 2020-11-25 21:22:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:21 --> Config Class Initialized
INFO - 2020-11-25 21:22:21 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:21 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:21 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:21 --> URI Class Initialized
INFO - 2020-11-25 21:22:21 --> Router Class Initialized
INFO - 2020-11-25 21:22:21 --> Output Class Initialized
INFO - 2020-11-25 21:22:21 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:21 --> Input Class Initialized
INFO - 2020-11-25 21:22:21 --> Language Class Initialized
INFO - 2020-11-25 21:22:21 --> Loader Class Initialized
INFO - 2020-11-25 21:22:21 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:21 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:21 --> Email Class Initialized
INFO - 2020-11-25 21:22:21 --> Controller Class Initialized
INFO - 2020-11-25 21:22:21 --> Model Class Initialized
INFO - 2020-11-25 21:22:21 --> Model Class Initialized
ERROR - 2020-11-25 21:22:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:21 --> Config Class Initialized
INFO - 2020-11-25 21:22:21 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:21 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:21 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:21 --> URI Class Initialized
INFO - 2020-11-25 21:22:21 --> Router Class Initialized
INFO - 2020-11-25 21:22:21 --> Output Class Initialized
INFO - 2020-11-25 21:22:21 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:21 --> Input Class Initialized
INFO - 2020-11-25 21:22:21 --> Language Class Initialized
INFO - 2020-11-25 21:22:21 --> Loader Class Initialized
INFO - 2020-11-25 21:22:21 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:21 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:21 --> Email Class Initialized
INFO - 2020-11-25 21:22:21 --> Controller Class Initialized
INFO - 2020-11-25 21:22:21 --> Model Class Initialized
INFO - 2020-11-25 21:22:21 --> Model Class Initialized
INFO - 2020-11-25 21:22:21 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:21 --> Total execution time: 0.0413
ERROR - 2020-11-25 21:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:22 --> Config Class Initialized
INFO - 2020-11-25 21:22:22 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:22 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:22 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:22 --> URI Class Initialized
DEBUG - 2020-11-25 21:22:22 --> No URI present. Default controller set.
INFO - 2020-11-25 21:22:22 --> Router Class Initialized
INFO - 2020-11-25 21:22:22 --> Output Class Initialized
INFO - 2020-11-25 21:22:22 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:22 --> Input Class Initialized
INFO - 2020-11-25 21:22:22 --> Language Class Initialized
INFO - 2020-11-25 21:22:22 --> Loader Class Initialized
INFO - 2020-11-25 21:22:22 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:22 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:22 --> Email Class Initialized
INFO - 2020-11-25 21:22:22 --> Controller Class Initialized
INFO - 2020-11-25 21:22:22 --> Model Class Initialized
INFO - 2020-11-25 21:22:22 --> Model Class Initialized
DEBUG - 2020-11-25 21:22:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-25 21:22:22 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:22 --> Total execution time: 0.0194
ERROR - 2020-11-25 21:22:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:23 --> Config Class Initialized
INFO - 2020-11-25 21:22:23 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:23 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:23 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:23 --> URI Class Initialized
INFO - 2020-11-25 21:22:23 --> Router Class Initialized
INFO - 2020-11-25 21:22:23 --> Output Class Initialized
INFO - 2020-11-25 21:22:23 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:23 --> Input Class Initialized
INFO - 2020-11-25 21:22:23 --> Language Class Initialized
INFO - 2020-11-25 21:22:23 --> Loader Class Initialized
INFO - 2020-11-25 21:22:23 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:23 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:23 --> Email Class Initialized
INFO - 2020-11-25 21:22:23 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:23 --> Model Class Initialized
INFO - 2020-11-25 21:22:23 --> Model Class Initialized
INFO - 2020-11-25 21:22:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-25 21:22:23 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:23 --> Total execution time: 0.0235
ERROR - 2020-11-25 21:22:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:27 --> Config Class Initialized
INFO - 2020-11-25 21:22:27 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:27 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:27 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:27 --> URI Class Initialized
INFO - 2020-11-25 21:22:27 --> Router Class Initialized
INFO - 2020-11-25 21:22:27 --> Output Class Initialized
INFO - 2020-11-25 21:22:27 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:27 --> Input Class Initialized
INFO - 2020-11-25 21:22:27 --> Language Class Initialized
INFO - 2020-11-25 21:22:27 --> Loader Class Initialized
INFO - 2020-11-25 21:22:27 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:27 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:27 --> Email Class Initialized
INFO - 2020-11-25 21:22:27 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:27 --> Model Class Initialized
INFO - 2020-11-25 21:22:27 --> Model Class Initialized
INFO - 2020-11-25 21:22:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-25 21:22:27 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:27 --> Total execution time: 0.0262
ERROR - 2020-11-25 21:22:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:46 --> Config Class Initialized
INFO - 2020-11-25 21:22:46 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:46 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:46 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:46 --> URI Class Initialized
INFO - 2020-11-25 21:22:46 --> Router Class Initialized
INFO - 2020-11-25 21:22:46 --> Output Class Initialized
INFO - 2020-11-25 21:22:46 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:46 --> Input Class Initialized
INFO - 2020-11-25 21:22:46 --> Language Class Initialized
INFO - 2020-11-25 21:22:46 --> Loader Class Initialized
INFO - 2020-11-25 21:22:46 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:46 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:46 --> Email Class Initialized
INFO - 2020-11-25 21:22:46 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:46 --> Model Class Initialized
INFO - 2020-11-25 21:22:46 --> Model Class Initialized
INFO - 2020-11-25 21:22:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-25 21:22:46 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:46 --> Total execution time: 0.0206
ERROR - 2020-11-25 21:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:49 --> Config Class Initialized
INFO - 2020-11-25 21:22:49 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:49 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:49 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:49 --> URI Class Initialized
INFO - 2020-11-25 21:22:49 --> Router Class Initialized
INFO - 2020-11-25 21:22:49 --> Output Class Initialized
INFO - 2020-11-25 21:22:49 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:49 --> Input Class Initialized
INFO - 2020-11-25 21:22:49 --> Language Class Initialized
INFO - 2020-11-25 21:22:49 --> Loader Class Initialized
INFO - 2020-11-25 21:22:49 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:49 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:49 --> Email Class Initialized
INFO - 2020-11-25 21:22:49 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:49 --> Model Class Initialized
INFO - 2020-11-25 21:22:49 --> Model Class Initialized
INFO - 2020-11-25 21:22:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-25 21:22:49 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:49 --> Total execution time: 0.0223
ERROR - 2020-11-25 21:22:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:49 --> Config Class Initialized
INFO - 2020-11-25 21:22:49 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:49 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:49 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:49 --> URI Class Initialized
INFO - 2020-11-25 21:22:49 --> Router Class Initialized
INFO - 2020-11-25 21:22:49 --> Output Class Initialized
INFO - 2020-11-25 21:22:49 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:49 --> Input Class Initialized
INFO - 2020-11-25 21:22:49 --> Language Class Initialized
INFO - 2020-11-25 21:22:49 --> Loader Class Initialized
INFO - 2020-11-25 21:22:49 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:49 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:49 --> Email Class Initialized
INFO - 2020-11-25 21:22:49 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:49 --> Model Class Initialized
INFO - 2020-11-25 21:22:49 --> Model Class Initialized
INFO - 2020-11-25 21:22:49 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:49 --> Total execution time: 0.0209
ERROR - 2020-11-25 21:22:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-25 21:22:52 --> Config Class Initialized
INFO - 2020-11-25 21:22:52 --> Hooks Class Initialized
DEBUG - 2020-11-25 21:22:52 --> UTF-8 Support Enabled
INFO - 2020-11-25 21:22:52 --> Utf8 Class Initialized
INFO - 2020-11-25 21:22:52 --> URI Class Initialized
INFO - 2020-11-25 21:22:52 --> Router Class Initialized
INFO - 2020-11-25 21:22:52 --> Output Class Initialized
INFO - 2020-11-25 21:22:52 --> Security Class Initialized
DEBUG - 2020-11-25 21:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 21:22:52 --> Input Class Initialized
INFO - 2020-11-25 21:22:52 --> Language Class Initialized
INFO - 2020-11-25 21:22:52 --> Loader Class Initialized
INFO - 2020-11-25 21:22:52 --> Helper loaded: url_helper
INFO - 2020-11-25 21:22:52 --> Database Driver Class Initialized
INFO - 2020-11-25 21:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 21:22:52 --> Email Class Initialized
INFO - 2020-11-25 21:22:52 --> Controller Class Initialized
DEBUG - 2020-11-25 21:22:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-25 21:22:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-25 21:22:52 --> Model Class Initialized
INFO - 2020-11-25 21:22:52 --> Model Class Initialized
INFO - 2020-11-25 21:22:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-25 21:22:52 --> Final output sent to browser
DEBUG - 2020-11-25 21:22:52 --> Total execution time: 0.0245
