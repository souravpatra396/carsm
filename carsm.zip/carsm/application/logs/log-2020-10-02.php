<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-02 03:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-02 03:40:43 --> Config Class Initialized
INFO - 2020-10-02 03:40:43 --> Hooks Class Initialized
DEBUG - 2020-10-02 03:40:43 --> UTF-8 Support Enabled
INFO - 2020-10-02 03:40:43 --> Utf8 Class Initialized
INFO - 2020-10-02 03:40:43 --> URI Class Initialized
DEBUG - 2020-10-02 03:40:43 --> No URI present. Default controller set.
INFO - 2020-10-02 03:40:43 --> Router Class Initialized
INFO - 2020-10-02 03:40:43 --> Output Class Initialized
INFO - 2020-10-02 03:40:43 --> Security Class Initialized
DEBUG - 2020-10-02 03:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 03:40:43 --> Input Class Initialized
INFO - 2020-10-02 03:40:43 --> Language Class Initialized
INFO - 2020-10-02 03:40:43 --> Loader Class Initialized
INFO - 2020-10-02 03:40:43 --> Helper loaded: url_helper
INFO - 2020-10-02 03:40:43 --> Database Driver Class Initialized
INFO - 2020-10-02 03:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 03:40:43 --> Email Class Initialized
INFO - 2020-10-02 03:40:43 --> Controller Class Initialized
INFO - 2020-10-02 03:40:43 --> Model Class Initialized
INFO - 2020-10-02 03:40:43 --> Model Class Initialized
DEBUG - 2020-10-02 03:40:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-02 03:40:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-02 03:40:43 --> Final output sent to browser
DEBUG - 2020-10-02 03:40:43 --> Total execution time: 0.0176
ERROR - 2020-10-02 14:23:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-02 14:23:16 --> Config Class Initialized
INFO - 2020-10-02 14:23:16 --> Hooks Class Initialized
DEBUG - 2020-10-02 14:23:16 --> UTF-8 Support Enabled
INFO - 2020-10-02 14:23:16 --> Utf8 Class Initialized
INFO - 2020-10-02 14:23:16 --> URI Class Initialized
DEBUG - 2020-10-02 14:23:16 --> No URI present. Default controller set.
INFO - 2020-10-02 14:23:16 --> Router Class Initialized
INFO - 2020-10-02 14:23:16 --> Output Class Initialized
INFO - 2020-10-02 14:23:16 --> Security Class Initialized
DEBUG - 2020-10-02 14:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 14:23:16 --> Input Class Initialized
INFO - 2020-10-02 14:23:16 --> Language Class Initialized
INFO - 2020-10-02 14:23:16 --> Loader Class Initialized
INFO - 2020-10-02 14:23:16 --> Helper loaded: url_helper
INFO - 2020-10-02 14:23:16 --> Database Driver Class Initialized
INFO - 2020-10-02 14:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 14:23:16 --> Email Class Initialized
INFO - 2020-10-02 14:23:16 --> Controller Class Initialized
INFO - 2020-10-02 14:23:16 --> Model Class Initialized
INFO - 2020-10-02 14:23:16 --> Model Class Initialized
DEBUG - 2020-10-02 14:23:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-02 14:23:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-02 14:23:16 --> Final output sent to browser
DEBUG - 2020-10-02 14:23:16 --> Total execution time: 0.1175
ERROR - 2020-10-02 17:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-02 17:18:54 --> Config Class Initialized
INFO - 2020-10-02 17:18:54 --> Hooks Class Initialized
DEBUG - 2020-10-02 17:18:54 --> UTF-8 Support Enabled
INFO - 2020-10-02 17:18:54 --> Utf8 Class Initialized
INFO - 2020-10-02 17:18:54 --> URI Class Initialized
DEBUG - 2020-10-02 17:18:54 --> No URI present. Default controller set.
INFO - 2020-10-02 17:18:54 --> Router Class Initialized
INFO - 2020-10-02 17:18:54 --> Output Class Initialized
INFO - 2020-10-02 17:18:54 --> Security Class Initialized
DEBUG - 2020-10-02 17:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-02 17:18:54 --> Input Class Initialized
INFO - 2020-10-02 17:18:54 --> Language Class Initialized
INFO - 2020-10-02 17:18:54 --> Loader Class Initialized
INFO - 2020-10-02 17:18:54 --> Helper loaded: url_helper
INFO - 2020-10-02 17:18:54 --> Database Driver Class Initialized
INFO - 2020-10-02 17:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-02 17:18:54 --> Email Class Initialized
INFO - 2020-10-02 17:18:54 --> Controller Class Initialized
INFO - 2020-10-02 17:18:54 --> Model Class Initialized
INFO - 2020-10-02 17:18:54 --> Model Class Initialized
DEBUG - 2020-10-02 17:18:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-02 17:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-02 17:18:54 --> Final output sent to browser
DEBUG - 2020-10-02 17:18:54 --> Total execution time: 0.0253
