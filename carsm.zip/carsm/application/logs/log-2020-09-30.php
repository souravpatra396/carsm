<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-30 20:24:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:35 --> Config Class Initialized
INFO - 2020-09-30 20:24:35 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:36 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:36 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:36 --> URI Class Initialized
DEBUG - 2020-09-30 20:24:36 --> No URI present. Default controller set.
INFO - 2020-09-30 20:24:36 --> Router Class Initialized
INFO - 2020-09-30 20:24:36 --> Output Class Initialized
INFO - 2020-09-30 20:24:36 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:36 --> Input Class Initialized
INFO - 2020-09-30 20:24:36 --> Language Class Initialized
INFO - 2020-09-30 20:24:36 --> Loader Class Initialized
INFO - 2020-09-30 20:24:36 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:36 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:36 --> Email Class Initialized
INFO - 2020-09-30 20:24:36 --> Controller Class Initialized
INFO - 2020-09-30 20:24:36 --> Model Class Initialized
INFO - 2020-09-30 20:24:36 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:24:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:24:36 --> Final output sent to browser
DEBUG - 2020-09-30 20:24:36 --> Total execution time: 0.1427
ERROR - 2020-09-30 20:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:38 --> Config Class Initialized
INFO - 2020-09-30 20:24:38 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:38 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:38 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:38 --> URI Class Initialized
DEBUG - 2020-09-30 20:24:38 --> No URI present. Default controller set.
INFO - 2020-09-30 20:24:38 --> Router Class Initialized
INFO - 2020-09-30 20:24:38 --> Output Class Initialized
INFO - 2020-09-30 20:24:38 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:38 --> Input Class Initialized
INFO - 2020-09-30 20:24:38 --> Language Class Initialized
INFO - 2020-09-30 20:24:38 --> Loader Class Initialized
INFO - 2020-09-30 20:24:38 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:38 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:38 --> Email Class Initialized
INFO - 2020-09-30 20:24:38 --> Controller Class Initialized
INFO - 2020-09-30 20:24:38 --> Model Class Initialized
INFO - 2020-09-30 20:24:38 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:24:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:24:38 --> Final output sent to browser
DEBUG - 2020-09-30 20:24:38 --> Total execution time: 0.0187
ERROR - 2020-09-30 20:24:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:38 --> Config Class Initialized
INFO - 2020-09-30 20:24:38 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:38 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:38 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:38 --> URI Class Initialized
DEBUG - 2020-09-30 20:24:38 --> No URI present. Default controller set.
INFO - 2020-09-30 20:24:38 --> Router Class Initialized
INFO - 2020-09-30 20:24:38 --> Output Class Initialized
INFO - 2020-09-30 20:24:38 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:38 --> Input Class Initialized
INFO - 2020-09-30 20:24:38 --> Language Class Initialized
INFO - 2020-09-30 20:24:38 --> Loader Class Initialized
INFO - 2020-09-30 20:24:38 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:38 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:38 --> Email Class Initialized
INFO - 2020-09-30 20:24:38 --> Controller Class Initialized
INFO - 2020-09-30 20:24:38 --> Model Class Initialized
INFO - 2020-09-30 20:24:38 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:24:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:24:38 --> Final output sent to browser
DEBUG - 2020-09-30 20:24:38 --> Total execution time: 0.0173
ERROR - 2020-09-30 20:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:55 --> Config Class Initialized
INFO - 2020-09-30 20:24:55 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:55 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:55 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:55 --> URI Class Initialized
INFO - 2020-09-30 20:24:55 --> Router Class Initialized
INFO - 2020-09-30 20:24:55 --> Output Class Initialized
INFO - 2020-09-30 20:24:55 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:55 --> Input Class Initialized
INFO - 2020-09-30 20:24:55 --> Language Class Initialized
INFO - 2020-09-30 20:24:55 --> Loader Class Initialized
INFO - 2020-09-30 20:24:55 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:55 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:55 --> Email Class Initialized
INFO - 2020-09-30 20:24:55 --> Controller Class Initialized
INFO - 2020-09-30 20:24:55 --> Model Class Initialized
INFO - 2020-09-30 20:24:55 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:55 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:24:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:55 --> Config Class Initialized
INFO - 2020-09-30 20:24:55 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:55 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:55 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:55 --> URI Class Initialized
INFO - 2020-09-30 20:24:55 --> Router Class Initialized
INFO - 2020-09-30 20:24:55 --> Output Class Initialized
INFO - 2020-09-30 20:24:55 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:55 --> Input Class Initialized
INFO - 2020-09-30 20:24:55 --> Language Class Initialized
INFO - 2020-09-30 20:24:55 --> Loader Class Initialized
INFO - 2020-09-30 20:24:55 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:55 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:55 --> Email Class Initialized
INFO - 2020-09-30 20:24:55 --> Controller Class Initialized
DEBUG - 2020-09-30 20:24:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:24:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:24:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-30 20:24:55 --> Final output sent to browser
DEBUG - 2020-09-30 20:24:55 --> Total execution time: 0.0415
ERROR - 2020-09-30 20:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:56 --> Config Class Initialized
INFO - 2020-09-30 20:24:56 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:56 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:56 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:56 --> URI Class Initialized
INFO - 2020-09-30 20:24:56 --> Router Class Initialized
INFO - 2020-09-30 20:24:56 --> Output Class Initialized
INFO - 2020-09-30 20:24:56 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:56 --> Input Class Initialized
INFO - 2020-09-30 20:24:56 --> Language Class Initialized
INFO - 2020-09-30 20:24:56 --> Loader Class Initialized
INFO - 2020-09-30 20:24:56 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:56 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:56 --> Email Class Initialized
INFO - 2020-09-30 20:24:56 --> Controller Class Initialized
INFO - 2020-09-30 20:24:56 --> Model Class Initialized
INFO - 2020-09-30 20:24:56 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:57 --> Config Class Initialized
INFO - 2020-09-30 20:24:57 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:57 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:57 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:57 --> URI Class Initialized
INFO - 2020-09-30 20:24:57 --> Router Class Initialized
INFO - 2020-09-30 20:24:57 --> Output Class Initialized
INFO - 2020-09-30 20:24:57 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:57 --> Input Class Initialized
INFO - 2020-09-30 20:24:57 --> Language Class Initialized
INFO - 2020-09-30 20:24:57 --> Loader Class Initialized
INFO - 2020-09-30 20:24:57 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:57 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:57 --> Email Class Initialized
INFO - 2020-09-30 20:24:57 --> Controller Class Initialized
DEBUG - 2020-09-30 20:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:24:57 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:24:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:57 --> Config Class Initialized
INFO - 2020-09-30 20:24:57 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:57 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:57 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:57 --> URI Class Initialized
DEBUG - 2020-09-30 20:24:57 --> No URI present. Default controller set.
INFO - 2020-09-30 20:24:57 --> Router Class Initialized
INFO - 2020-09-30 20:24:57 --> Output Class Initialized
INFO - 2020-09-30 20:24:57 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:57 --> Input Class Initialized
INFO - 2020-09-30 20:24:57 --> Language Class Initialized
INFO - 2020-09-30 20:24:57 --> Loader Class Initialized
INFO - 2020-09-30 20:24:57 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:57 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:57 --> Email Class Initialized
INFO - 2020-09-30 20:24:57 --> Controller Class Initialized
INFO - 2020-09-30 20:24:57 --> Model Class Initialized
INFO - 2020-09-30 20:24:57 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:24:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:24:57 --> Final output sent to browser
DEBUG - 2020-09-30 20:24:57 --> Total execution time: 0.0227
ERROR - 2020-09-30 20:24:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:24:58 --> Config Class Initialized
INFO - 2020-09-30 20:24:58 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:24:58 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:24:58 --> Utf8 Class Initialized
INFO - 2020-09-30 20:24:58 --> URI Class Initialized
DEBUG - 2020-09-30 20:24:58 --> No URI present. Default controller set.
INFO - 2020-09-30 20:24:58 --> Router Class Initialized
INFO - 2020-09-30 20:24:58 --> Output Class Initialized
INFO - 2020-09-30 20:24:58 --> Security Class Initialized
DEBUG - 2020-09-30 20:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:24:58 --> Input Class Initialized
INFO - 2020-09-30 20:24:58 --> Language Class Initialized
INFO - 2020-09-30 20:24:58 --> Loader Class Initialized
INFO - 2020-09-30 20:24:58 --> Helper loaded: url_helper
INFO - 2020-09-30 20:24:58 --> Database Driver Class Initialized
INFO - 2020-09-30 20:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:24:58 --> Email Class Initialized
INFO - 2020-09-30 20:24:58 --> Controller Class Initialized
INFO - 2020-09-30 20:24:58 --> Model Class Initialized
INFO - 2020-09-30 20:24:58 --> Model Class Initialized
DEBUG - 2020-09-30 20:24:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:24:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:24:58 --> Final output sent to browser
DEBUG - 2020-09-30 20:24:58 --> Total execution time: 0.0201
ERROR - 2020-09-30 20:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:08 --> Config Class Initialized
INFO - 2020-09-30 20:25:08 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:08 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:08 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:08 --> URI Class Initialized
INFO - 2020-09-30 20:25:08 --> Router Class Initialized
INFO - 2020-09-30 20:25:08 --> Output Class Initialized
INFO - 2020-09-30 20:25:08 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:08 --> Input Class Initialized
INFO - 2020-09-30 20:25:08 --> Language Class Initialized
INFO - 2020-09-30 20:25:08 --> Loader Class Initialized
INFO - 2020-09-30 20:25:08 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:08 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:08 --> Email Class Initialized
INFO - 2020-09-30 20:25:08 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:08 --> Model Class Initialized
INFO - 2020-09-30 20:25:08 --> Model Class Initialized
INFO - 2020-09-30 20:25:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-30 20:25:08 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:08 --> Total execution time: 0.0340
ERROR - 2020-09-30 20:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:09 --> Config Class Initialized
INFO - 2020-09-30 20:25:09 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:09 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:09 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:09 --> URI Class Initialized
INFO - 2020-09-30 20:25:09 --> Router Class Initialized
INFO - 2020-09-30 20:25:09 --> Output Class Initialized
INFO - 2020-09-30 20:25:09 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:09 --> Input Class Initialized
INFO - 2020-09-30 20:25:09 --> Language Class Initialized
INFO - 2020-09-30 20:25:09 --> Loader Class Initialized
INFO - 2020-09-30 20:25:09 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:09 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:09 --> Email Class Initialized
INFO - 2020-09-30 20:25:09 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:09 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:10 --> Config Class Initialized
INFO - 2020-09-30 20:25:10 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:10 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:10 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:10 --> URI Class Initialized
DEBUG - 2020-09-30 20:25:10 --> No URI present. Default controller set.
INFO - 2020-09-30 20:25:10 --> Router Class Initialized
INFO - 2020-09-30 20:25:10 --> Output Class Initialized
INFO - 2020-09-30 20:25:10 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:10 --> Input Class Initialized
INFO - 2020-09-30 20:25:10 --> Language Class Initialized
INFO - 2020-09-30 20:25:10 --> Loader Class Initialized
INFO - 2020-09-30 20:25:10 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:10 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:10 --> Email Class Initialized
INFO - 2020-09-30 20:25:10 --> Controller Class Initialized
INFO - 2020-09-30 20:25:10 --> Model Class Initialized
INFO - 2020-09-30 20:25:10 --> Model Class Initialized
DEBUG - 2020-09-30 20:25:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:25:10 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:10 --> Total execution time: 0.0194
ERROR - 2020-09-30 20:25:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:13 --> Config Class Initialized
INFO - 2020-09-30 20:25:13 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:13 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:13 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:13 --> URI Class Initialized
INFO - 2020-09-30 20:25:13 --> Router Class Initialized
INFO - 2020-09-30 20:25:13 --> Output Class Initialized
INFO - 2020-09-30 20:25:13 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:13 --> Input Class Initialized
INFO - 2020-09-30 20:25:13 --> Language Class Initialized
INFO - 2020-09-30 20:25:13 --> Loader Class Initialized
INFO - 2020-09-30 20:25:13 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:13 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:13 --> Email Class Initialized
INFO - 2020-09-30 20:25:13 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:13 --> Model Class Initialized
INFO - 2020-09-30 20:25:13 --> Model Class Initialized
INFO - 2020-09-30 20:25:13 --> Model Class Initialized
INFO - 2020-09-30 20:25:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-30 20:25:13 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:13 --> Total execution time: 0.0347
ERROR - 2020-09-30 20:25:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:14 --> Config Class Initialized
INFO - 2020-09-30 20:25:14 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:14 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:14 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:14 --> URI Class Initialized
INFO - 2020-09-30 20:25:14 --> Router Class Initialized
INFO - 2020-09-30 20:25:14 --> Output Class Initialized
INFO - 2020-09-30 20:25:14 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:14 --> Input Class Initialized
INFO - 2020-09-30 20:25:14 --> Language Class Initialized
INFO - 2020-09-30 20:25:14 --> Loader Class Initialized
INFO - 2020-09-30 20:25:14 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:14 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:14 --> Email Class Initialized
INFO - 2020-09-30 20:25:14 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:14 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:15 --> Config Class Initialized
INFO - 2020-09-30 20:25:15 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:15 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:15 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:15 --> URI Class Initialized
DEBUG - 2020-09-30 20:25:15 --> No URI present. Default controller set.
INFO - 2020-09-30 20:25:15 --> Router Class Initialized
INFO - 2020-09-30 20:25:15 --> Output Class Initialized
INFO - 2020-09-30 20:25:15 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:15 --> Input Class Initialized
INFO - 2020-09-30 20:25:15 --> Language Class Initialized
INFO - 2020-09-30 20:25:15 --> Loader Class Initialized
INFO - 2020-09-30 20:25:15 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:15 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:15 --> Email Class Initialized
INFO - 2020-09-30 20:25:15 --> Controller Class Initialized
INFO - 2020-09-30 20:25:15 --> Model Class Initialized
INFO - 2020-09-30 20:25:15 --> Model Class Initialized
DEBUG - 2020-09-30 20:25:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:25:15 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:15 --> Total execution time: 0.0208
ERROR - 2020-09-30 20:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:22 --> Config Class Initialized
INFO - 2020-09-30 20:25:22 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:22 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:22 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:22 --> URI Class Initialized
INFO - 2020-09-30 20:25:22 --> Router Class Initialized
INFO - 2020-09-30 20:25:22 --> Output Class Initialized
INFO - 2020-09-30 20:25:22 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:22 --> Input Class Initialized
INFO - 2020-09-30 20:25:22 --> Language Class Initialized
INFO - 2020-09-30 20:25:22 --> Loader Class Initialized
INFO - 2020-09-30 20:25:22 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:22 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:22 --> Email Class Initialized
INFO - 2020-09-30 20:25:22 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:22 --> Model Class Initialized
INFO - 2020-09-30 20:25:22 --> Model Class Initialized
INFO - 2020-09-30 20:25:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-30 20:25:22 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:22 --> Total execution time: 0.0408
ERROR - 2020-09-30 20:25:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:23 --> Config Class Initialized
INFO - 2020-09-30 20:25:23 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:23 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:23 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:23 --> URI Class Initialized
INFO - 2020-09-30 20:25:23 --> Router Class Initialized
INFO - 2020-09-30 20:25:23 --> Output Class Initialized
INFO - 2020-09-30 20:25:23 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:23 --> Input Class Initialized
INFO - 2020-09-30 20:25:23 --> Language Class Initialized
INFO - 2020-09-30 20:25:23 --> Loader Class Initialized
INFO - 2020-09-30 20:25:23 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:23 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:23 --> Email Class Initialized
INFO - 2020-09-30 20:25:23 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:23 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:24 --> Config Class Initialized
INFO - 2020-09-30 20:25:24 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:24 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:24 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:24 --> URI Class Initialized
INFO - 2020-09-30 20:25:24 --> Router Class Initialized
INFO - 2020-09-30 20:25:24 --> Output Class Initialized
INFO - 2020-09-30 20:25:24 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:24 --> Input Class Initialized
INFO - 2020-09-30 20:25:24 --> Language Class Initialized
INFO - 2020-09-30 20:25:24 --> Loader Class Initialized
INFO - 2020-09-30 20:25:24 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:24 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:24 --> Email Class Initialized
INFO - 2020-09-30 20:25:24 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:24 --> Model Class Initialized
INFO - 2020-09-30 20:25:24 --> Model Class Initialized
INFO - 2020-09-30 20:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-30 20:25:24 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:24 --> Total execution time: 0.0335
ERROR - 2020-09-30 20:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:24 --> Config Class Initialized
INFO - 2020-09-30 20:25:24 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:24 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:24 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:24 --> URI Class Initialized
DEBUG - 2020-09-30 20:25:24 --> No URI present. Default controller set.
INFO - 2020-09-30 20:25:24 --> Router Class Initialized
INFO - 2020-09-30 20:25:24 --> Output Class Initialized
INFO - 2020-09-30 20:25:24 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:24 --> Input Class Initialized
INFO - 2020-09-30 20:25:24 --> Language Class Initialized
INFO - 2020-09-30 20:25:24 --> Loader Class Initialized
INFO - 2020-09-30 20:25:24 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:24 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:24 --> Email Class Initialized
INFO - 2020-09-30 20:25:24 --> Controller Class Initialized
INFO - 2020-09-30 20:25:24 --> Model Class Initialized
INFO - 2020-09-30 20:25:24 --> Model Class Initialized
DEBUG - 2020-09-30 20:25:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:25:24 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:24 --> Total execution time: 0.0203
ERROR - 2020-09-30 20:25:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:25 --> Config Class Initialized
INFO - 2020-09-30 20:25:25 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:25 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:25 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:25 --> URI Class Initialized
INFO - 2020-09-30 20:25:25 --> Router Class Initialized
INFO - 2020-09-30 20:25:25 --> Output Class Initialized
INFO - 2020-09-30 20:25:25 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:25 --> Input Class Initialized
INFO - 2020-09-30 20:25:25 --> Language Class Initialized
INFO - 2020-09-30 20:25:25 --> Loader Class Initialized
INFO - 2020-09-30 20:25:25 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:25 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:25 --> Email Class Initialized
INFO - 2020-09-30 20:25:25 --> Controller Class Initialized
DEBUG - 2020-09-30 20:25:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:25:25 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:25:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:25:26 --> Config Class Initialized
INFO - 2020-09-30 20:25:26 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:25:26 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:25:26 --> Utf8 Class Initialized
INFO - 2020-09-30 20:25:26 --> URI Class Initialized
DEBUG - 2020-09-30 20:25:26 --> No URI present. Default controller set.
INFO - 2020-09-30 20:25:26 --> Router Class Initialized
INFO - 2020-09-30 20:25:26 --> Output Class Initialized
INFO - 2020-09-30 20:25:26 --> Security Class Initialized
DEBUG - 2020-09-30 20:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:25:26 --> Input Class Initialized
INFO - 2020-09-30 20:25:26 --> Language Class Initialized
INFO - 2020-09-30 20:25:26 --> Loader Class Initialized
INFO - 2020-09-30 20:25:26 --> Helper loaded: url_helper
INFO - 2020-09-30 20:25:26 --> Database Driver Class Initialized
INFO - 2020-09-30 20:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:25:26 --> Email Class Initialized
INFO - 2020-09-30 20:25:26 --> Controller Class Initialized
INFO - 2020-09-30 20:25:26 --> Model Class Initialized
INFO - 2020-09-30 20:25:26 --> Model Class Initialized
DEBUG - 2020-09-30 20:25:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:25:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:25:26 --> Final output sent to browser
DEBUG - 2020-09-30 20:25:26 --> Total execution time: 0.0196
ERROR - 2020-09-30 20:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:43:26 --> Config Class Initialized
INFO - 2020-09-30 20:43:26 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:43:26 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:43:26 --> Utf8 Class Initialized
INFO - 2020-09-30 20:43:26 --> URI Class Initialized
INFO - 2020-09-30 20:43:26 --> Router Class Initialized
INFO - 2020-09-30 20:43:26 --> Output Class Initialized
INFO - 2020-09-30 20:43:26 --> Security Class Initialized
DEBUG - 2020-09-30 20:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:43:26 --> Input Class Initialized
INFO - 2020-09-30 20:43:26 --> Language Class Initialized
INFO - 2020-09-30 20:43:26 --> Loader Class Initialized
INFO - 2020-09-30 20:43:26 --> Helper loaded: url_helper
INFO - 2020-09-30 20:43:26 --> Database Driver Class Initialized
INFO - 2020-09-30 20:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:43:26 --> Email Class Initialized
INFO - 2020-09-30 20:43:26 --> Controller Class Initialized
DEBUG - 2020-09-30 20:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:43:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:43:26 --> Model Class Initialized
INFO - 2020-09-30 20:43:26 --> Model Class Initialized
INFO - 2020-09-30 20:43:26 --> Model Class Initialized
ERROR - 2020-09-30 20:43:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('sales@genericevent.com','Generic Hyundai','5195551212','123 Main Street','bd4b1e80',3,)
INFO - 2020-09-30 20:43:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-30 20:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:43:28 --> Config Class Initialized
INFO - 2020-09-30 20:43:28 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:43:28 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:43:28 --> Utf8 Class Initialized
INFO - 2020-09-30 20:43:28 --> URI Class Initialized
INFO - 2020-09-30 20:43:28 --> Router Class Initialized
INFO - 2020-09-30 20:43:28 --> Output Class Initialized
INFO - 2020-09-30 20:43:28 --> Security Class Initialized
DEBUG - 2020-09-30 20:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:43:28 --> Input Class Initialized
INFO - 2020-09-30 20:43:28 --> Language Class Initialized
INFO - 2020-09-30 20:43:28 --> Loader Class Initialized
INFO - 2020-09-30 20:43:28 --> Helper loaded: url_helper
INFO - 2020-09-30 20:43:28 --> Database Driver Class Initialized
INFO - 2020-09-30 20:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:43:28 --> Email Class Initialized
INFO - 2020-09-30 20:43:28 --> Controller Class Initialized
DEBUG - 2020-09-30 20:43:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:43:28 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:43:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:43:28 --> Config Class Initialized
INFO - 2020-09-30 20:43:28 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:43:28 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:43:28 --> Utf8 Class Initialized
INFO - 2020-09-30 20:43:28 --> URI Class Initialized
DEBUG - 2020-09-30 20:43:28 --> No URI present. Default controller set.
INFO - 2020-09-30 20:43:28 --> Router Class Initialized
INFO - 2020-09-30 20:43:28 --> Output Class Initialized
INFO - 2020-09-30 20:43:28 --> Security Class Initialized
DEBUG - 2020-09-30 20:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:43:28 --> Input Class Initialized
INFO - 2020-09-30 20:43:28 --> Language Class Initialized
INFO - 2020-09-30 20:43:28 --> Loader Class Initialized
INFO - 2020-09-30 20:43:28 --> Helper loaded: url_helper
INFO - 2020-09-30 20:43:28 --> Database Driver Class Initialized
INFO - 2020-09-30 20:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:43:28 --> Email Class Initialized
INFO - 2020-09-30 20:43:28 --> Controller Class Initialized
INFO - 2020-09-30 20:43:28 --> Model Class Initialized
INFO - 2020-09-30 20:43:28 --> Model Class Initialized
DEBUG - 2020-09-30 20:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:43:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:43:28 --> Final output sent to browser
DEBUG - 2020-09-30 20:43:28 --> Total execution time: 0.0202
ERROR - 2020-09-30 20:44:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:44:16 --> Config Class Initialized
INFO - 2020-09-30 20:44:16 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:44:16 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:44:16 --> Utf8 Class Initialized
INFO - 2020-09-30 20:44:16 --> URI Class Initialized
INFO - 2020-09-30 20:44:16 --> Router Class Initialized
INFO - 2020-09-30 20:44:16 --> Output Class Initialized
INFO - 2020-09-30 20:44:16 --> Security Class Initialized
DEBUG - 2020-09-30 20:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:44:16 --> Input Class Initialized
INFO - 2020-09-30 20:44:16 --> Language Class Initialized
INFO - 2020-09-30 20:44:16 --> Loader Class Initialized
INFO - 2020-09-30 20:44:16 --> Helper loaded: url_helper
INFO - 2020-09-30 20:44:16 --> Database Driver Class Initialized
INFO - 2020-09-30 20:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:44:16 --> Email Class Initialized
INFO - 2020-09-30 20:44:16 --> Controller Class Initialized
DEBUG - 2020-09-30 20:44:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:44:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:44:16 --> Model Class Initialized
INFO - 2020-09-30 20:44:16 --> Model Class Initialized
INFO - 2020-09-30 20:44:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-30 20:44:16 --> Final output sent to browser
DEBUG - 2020-09-30 20:44:16 --> Total execution time: 0.0208
ERROR - 2020-09-30 20:44:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:44:17 --> Config Class Initialized
INFO - 2020-09-30 20:44:17 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:44:17 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:44:17 --> Utf8 Class Initialized
INFO - 2020-09-30 20:44:17 --> URI Class Initialized
INFO - 2020-09-30 20:44:17 --> Router Class Initialized
INFO - 2020-09-30 20:44:17 --> Output Class Initialized
INFO - 2020-09-30 20:44:17 --> Security Class Initialized
DEBUG - 2020-09-30 20:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:44:17 --> Input Class Initialized
INFO - 2020-09-30 20:44:17 --> Language Class Initialized
INFO - 2020-09-30 20:44:17 --> Loader Class Initialized
INFO - 2020-09-30 20:44:17 --> Helper loaded: url_helper
INFO - 2020-09-30 20:44:17 --> Database Driver Class Initialized
INFO - 2020-09-30 20:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:44:17 --> Email Class Initialized
INFO - 2020-09-30 20:44:17 --> Controller Class Initialized
DEBUG - 2020-09-30 20:44:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 20:44:17 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 20:44:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 20:44:18 --> Config Class Initialized
INFO - 2020-09-30 20:44:18 --> Hooks Class Initialized
DEBUG - 2020-09-30 20:44:18 --> UTF-8 Support Enabled
INFO - 2020-09-30 20:44:18 --> Utf8 Class Initialized
INFO - 2020-09-30 20:44:18 --> URI Class Initialized
DEBUG - 2020-09-30 20:44:18 --> No URI present. Default controller set.
INFO - 2020-09-30 20:44:18 --> Router Class Initialized
INFO - 2020-09-30 20:44:18 --> Output Class Initialized
INFO - 2020-09-30 20:44:18 --> Security Class Initialized
DEBUG - 2020-09-30 20:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 20:44:18 --> Input Class Initialized
INFO - 2020-09-30 20:44:18 --> Language Class Initialized
INFO - 2020-09-30 20:44:18 --> Loader Class Initialized
INFO - 2020-09-30 20:44:18 --> Helper loaded: url_helper
INFO - 2020-09-30 20:44:18 --> Database Driver Class Initialized
INFO - 2020-09-30 20:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 20:44:18 --> Email Class Initialized
INFO - 2020-09-30 20:44:18 --> Controller Class Initialized
INFO - 2020-09-30 20:44:18 --> Model Class Initialized
INFO - 2020-09-30 20:44:18 --> Model Class Initialized
DEBUG - 2020-09-30 20:44:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 20:44:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 20:44:18 --> Final output sent to browser
DEBUG - 2020-09-30 20:44:18 --> Total execution time: 0.0211
ERROR - 2020-09-30 21:19:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:08 --> Config Class Initialized
INFO - 2020-09-30 21:19:08 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:08 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:08 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:08 --> URI Class Initialized
INFO - 2020-09-30 21:19:08 --> Router Class Initialized
INFO - 2020-09-30 21:19:08 --> Output Class Initialized
INFO - 2020-09-30 21:19:08 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:08 --> Input Class Initialized
INFO - 2020-09-30 21:19:08 --> Language Class Initialized
INFO - 2020-09-30 21:19:08 --> Loader Class Initialized
INFO - 2020-09-30 21:19:08 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:08 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:08 --> Email Class Initialized
INFO - 2020-09-30 21:19:08 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:08 --> Model Class Initialized
INFO - 2020-09-30 21:19:08 --> Model Class Initialized
INFO - 2020-09-30 21:19:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-30 21:19:08 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:08 --> Total execution time: 0.0253
ERROR - 2020-09-30 21:19:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:10 --> Config Class Initialized
INFO - 2020-09-30 21:19:10 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:10 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:10 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:10 --> URI Class Initialized
INFO - 2020-09-30 21:19:10 --> Router Class Initialized
INFO - 2020-09-30 21:19:10 --> Output Class Initialized
INFO - 2020-09-30 21:19:10 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:10 --> Input Class Initialized
INFO - 2020-09-30 21:19:10 --> Language Class Initialized
INFO - 2020-09-30 21:19:10 --> Loader Class Initialized
INFO - 2020-09-30 21:19:10 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:10 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:10 --> Email Class Initialized
INFO - 2020-09-30 21:19:10 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:10 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 21:19:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:11 --> Config Class Initialized
INFO - 2020-09-30 21:19:11 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:11 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:11 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:11 --> URI Class Initialized
DEBUG - 2020-09-30 21:19:11 --> No URI present. Default controller set.
INFO - 2020-09-30 21:19:11 --> Router Class Initialized
INFO - 2020-09-30 21:19:11 --> Output Class Initialized
INFO - 2020-09-30 21:19:11 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:11 --> Input Class Initialized
INFO - 2020-09-30 21:19:11 --> Language Class Initialized
INFO - 2020-09-30 21:19:11 --> Loader Class Initialized
INFO - 2020-09-30 21:19:11 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:11 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:11 --> Email Class Initialized
INFO - 2020-09-30 21:19:11 --> Controller Class Initialized
INFO - 2020-09-30 21:19:11 --> Model Class Initialized
INFO - 2020-09-30 21:19:11 --> Model Class Initialized
DEBUG - 2020-09-30 21:19:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 21:19:11 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:11 --> Total execution time: 0.0182
ERROR - 2020-09-30 21:19:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:12 --> Config Class Initialized
INFO - 2020-09-30 21:19:12 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:12 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:12 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:12 --> URI Class Initialized
INFO - 2020-09-30 21:19:12 --> Router Class Initialized
INFO - 2020-09-30 21:19:12 --> Output Class Initialized
INFO - 2020-09-30 21:19:12 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:12 --> Input Class Initialized
INFO - 2020-09-30 21:19:12 --> Language Class Initialized
INFO - 2020-09-30 21:19:12 --> Loader Class Initialized
INFO - 2020-09-30 21:19:12 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:12 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:12 --> Email Class Initialized
INFO - 2020-09-30 21:19:12 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:12 --> Model Class Initialized
INFO - 2020-09-30 21:19:12 --> Model Class Initialized
INFO - 2020-09-30 21:19:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-30 21:19:12 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:12 --> Total execution time: 0.0186
ERROR - 2020-09-30 21:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:13 --> Config Class Initialized
INFO - 2020-09-30 21:19:13 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:13 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:13 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:13 --> URI Class Initialized
INFO - 2020-09-30 21:19:13 --> Router Class Initialized
INFO - 2020-09-30 21:19:13 --> Output Class Initialized
INFO - 2020-09-30 21:19:13 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:13 --> Input Class Initialized
INFO - 2020-09-30 21:19:13 --> Language Class Initialized
INFO - 2020-09-30 21:19:13 --> Loader Class Initialized
INFO - 2020-09-30 21:19:13 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:13 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:13 --> Email Class Initialized
INFO - 2020-09-30 21:19:13 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:13 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-30 21:19:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:13 --> Config Class Initialized
INFO - 2020-09-30 21:19:13 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:13 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:13 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:13 --> URI Class Initialized
DEBUG - 2020-09-30 21:19:13 --> No URI present. Default controller set.
INFO - 2020-09-30 21:19:13 --> Router Class Initialized
INFO - 2020-09-30 21:19:13 --> Output Class Initialized
INFO - 2020-09-30 21:19:13 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:13 --> Input Class Initialized
INFO - 2020-09-30 21:19:13 --> Language Class Initialized
INFO - 2020-09-30 21:19:13 --> Loader Class Initialized
INFO - 2020-09-30 21:19:13 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:13 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:13 --> Email Class Initialized
INFO - 2020-09-30 21:19:13 --> Controller Class Initialized
INFO - 2020-09-30 21:19:13 --> Model Class Initialized
INFO - 2020-09-30 21:19:13 --> Model Class Initialized
DEBUG - 2020-09-30 21:19:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-30 21:19:13 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:13 --> Total execution time: 0.0218
ERROR - 2020-09-30 21:19:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:15 --> Config Class Initialized
INFO - 2020-09-30 21:19:15 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:15 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:15 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:15 --> URI Class Initialized
INFO - 2020-09-30 21:19:15 --> Router Class Initialized
INFO - 2020-09-30 21:19:15 --> Output Class Initialized
INFO - 2020-09-30 21:19:15 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:15 --> Input Class Initialized
INFO - 2020-09-30 21:19:15 --> Language Class Initialized
INFO - 2020-09-30 21:19:15 --> Loader Class Initialized
INFO - 2020-09-30 21:19:15 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:15 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:15 --> Email Class Initialized
INFO - 2020-09-30 21:19:15 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:15 --> Model Class Initialized
INFO - 2020-09-30 21:19:15 --> Model Class Initialized
INFO - 2020-09-30 21:19:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-30 21:19:15 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:15 --> Total execution time: 0.0220
ERROR - 2020-09-30 21:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:17 --> Config Class Initialized
INFO - 2020-09-30 21:19:17 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:17 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:17 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:17 --> URI Class Initialized
INFO - 2020-09-30 21:19:17 --> Router Class Initialized
INFO - 2020-09-30 21:19:17 --> Output Class Initialized
INFO - 2020-09-30 21:19:17 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:17 --> Input Class Initialized
INFO - 2020-09-30 21:19:17 --> Language Class Initialized
INFO - 2020-09-30 21:19:17 --> Loader Class Initialized
INFO - 2020-09-30 21:19:17 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:17 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:17 --> Email Class Initialized
INFO - 2020-09-30 21:19:17 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:17 --> Model Class Initialized
INFO - 2020-09-30 21:19:17 --> Model Class Initialized
INFO - 2020-09-30 21:19:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-30 21:19:17 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:17 --> Total execution time: 0.0254
ERROR - 2020-09-30 21:19:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-30 21:19:34 --> Config Class Initialized
INFO - 2020-09-30 21:19:34 --> Hooks Class Initialized
DEBUG - 2020-09-30 21:19:34 --> UTF-8 Support Enabled
INFO - 2020-09-30 21:19:34 --> Utf8 Class Initialized
INFO - 2020-09-30 21:19:34 --> URI Class Initialized
INFO - 2020-09-30 21:19:34 --> Router Class Initialized
INFO - 2020-09-30 21:19:34 --> Output Class Initialized
INFO - 2020-09-30 21:19:34 --> Security Class Initialized
DEBUG - 2020-09-30 21:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-30 21:19:34 --> Input Class Initialized
INFO - 2020-09-30 21:19:34 --> Language Class Initialized
INFO - 2020-09-30 21:19:34 --> Loader Class Initialized
INFO - 2020-09-30 21:19:34 --> Helper loaded: url_helper
INFO - 2020-09-30 21:19:34 --> Database Driver Class Initialized
INFO - 2020-09-30 21:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-30 21:19:34 --> Email Class Initialized
INFO - 2020-09-30 21:19:34 --> Controller Class Initialized
DEBUG - 2020-09-30 21:19:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-30 21:19:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-30 21:19:34 --> Model Class Initialized
INFO - 2020-09-30 21:19:34 --> Model Class Initialized
INFO - 2020-09-30 21:19:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-30 21:19:34 --> Final output sent to browser
DEBUG - 2020-09-30 21:19:34 --> Total execution time: 0.0359
