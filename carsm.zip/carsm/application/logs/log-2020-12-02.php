<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-02 11:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-02 11:14:25 --> Config Class Initialized
INFO - 2020-12-02 11:14:25 --> Hooks Class Initialized
DEBUG - 2020-12-02 11:14:25 --> UTF-8 Support Enabled
INFO - 2020-12-02 11:14:25 --> Utf8 Class Initialized
INFO - 2020-12-02 11:14:25 --> URI Class Initialized
DEBUG - 2020-12-02 11:14:25 --> No URI present. Default controller set.
INFO - 2020-12-02 11:14:25 --> Router Class Initialized
INFO - 2020-12-02 11:14:25 --> Output Class Initialized
INFO - 2020-12-02 11:14:25 --> Security Class Initialized
DEBUG - 2020-12-02 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-02 11:14:25 --> Input Class Initialized
INFO - 2020-12-02 11:14:25 --> Language Class Initialized
INFO - 2020-12-02 11:14:25 --> Loader Class Initialized
INFO - 2020-12-02 11:14:25 --> Helper loaded: url_helper
INFO - 2020-12-02 11:14:25 --> Database Driver Class Initialized
INFO - 2020-12-02 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-02 11:14:25 --> Email Class Initialized
INFO - 2020-12-02 11:14:25 --> Controller Class Initialized
INFO - 2020-12-02 11:14:25 --> Model Class Initialized
INFO - 2020-12-02 11:14:25 --> Model Class Initialized
DEBUG - 2020-12-02 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-02 11:14:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-02 11:14:25 --> Final output sent to browser
DEBUG - 2020-12-02 11:14:25 --> Total execution time: 0.2868
