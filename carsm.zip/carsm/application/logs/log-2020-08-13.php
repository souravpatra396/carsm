<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-13 07:40:59 --> Config Class Initialized
INFO - 2020-08-13 07:40:59 --> Hooks Class Initialized
DEBUG - 2020-08-13 07:40:59 --> UTF-8 Support Enabled
INFO - 2020-08-13 07:40:59 --> Utf8 Class Initialized
INFO - 2020-08-13 07:40:59 --> URI Class Initialized
DEBUG - 2020-08-13 07:40:59 --> No URI present. Default controller set.
INFO - 2020-08-13 07:40:59 --> Router Class Initialized
INFO - 2020-08-13 07:40:59 --> Output Class Initialized
INFO - 2020-08-13 07:40:59 --> Security Class Initialized
DEBUG - 2020-08-13 07:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 07:40:59 --> Input Class Initialized
INFO - 2020-08-13 07:40:59 --> Language Class Initialized
INFO - 2020-08-13 07:40:59 --> Loader Class Initialized
INFO - 2020-08-13 07:40:59 --> Helper loaded: url_helper
INFO - 2020-08-13 07:40:59 --> Database Driver Class Initialized
INFO - 2020-08-13 07:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 07:40:59 --> Email Class Initialized
INFO - 2020-08-13 07:40:59 --> Controller Class Initialized
INFO - 2020-08-13 07:40:59 --> Model Class Initialized
INFO - 2020-08-13 07:40:59 --> Model Class Initialized
DEBUG - 2020-08-13 07:40:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 07:40:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 07:40:59 --> Final output sent to browser
DEBUG - 2020-08-13 07:40:59 --> Total execution time: 0.1389
INFO - 2020-08-13 07:41:07 --> Config Class Initialized
INFO - 2020-08-13 07:41:07 --> Hooks Class Initialized
DEBUG - 2020-08-13 07:41:07 --> UTF-8 Support Enabled
INFO - 2020-08-13 07:41:07 --> Utf8 Class Initialized
INFO - 2020-08-13 07:41:07 --> URI Class Initialized
INFO - 2020-08-13 07:41:07 --> Router Class Initialized
INFO - 2020-08-13 07:41:07 --> Output Class Initialized
INFO - 2020-08-13 07:41:07 --> Config Class Initialized
INFO - 2020-08-13 07:41:07 --> Hooks Class Initialized
INFO - 2020-08-13 07:41:07 --> Security Class Initialized
DEBUG - 2020-08-13 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 07:41:07 --> Input Class Initialized
INFO - 2020-08-13 07:41:07 --> Language Class Initialized
DEBUG - 2020-08-13 07:41:07 --> UTF-8 Support Enabled
INFO - 2020-08-13 07:41:07 --> Utf8 Class Initialized
INFO - 2020-08-13 07:41:07 --> URI Class Initialized
INFO - 2020-08-13 07:41:07 --> Router Class Initialized
INFO - 2020-08-13 07:41:07 --> Output Class Initialized
INFO - 2020-08-13 07:41:07 --> Security Class Initialized
DEBUG - 2020-08-13 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 07:41:07 --> Input Class Initialized
INFO - 2020-08-13 07:41:07 --> Language Class Initialized
INFO - 2020-08-13 07:41:07 --> Loader Class Initialized
INFO - 2020-08-13 07:41:07 --> Helper loaded: url_helper
INFO - 2020-08-13 07:41:07 --> Loader Class Initialized
INFO - 2020-08-13 07:41:07 --> Helper loaded: url_helper
INFO - 2020-08-13 07:41:07 --> Database Driver Class Initialized
INFO - 2020-08-13 07:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 07:41:07 --> Database Driver Class Initialized
INFO - 2020-08-13 07:41:07 --> Email Class Initialized
INFO - 2020-08-13 07:41:07 --> Controller Class Initialized
INFO - 2020-08-13 07:41:07 --> Model Class Initialized
INFO - 2020-08-13 07:41:07 --> Model Class Initialized
DEBUG - 2020-08-13 07:41:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 07:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 07:41:07 --> Email Class Initialized
INFO - 2020-08-13 07:41:07 --> Controller Class Initialized
INFO - 2020-08-13 07:41:07 --> Model Class Initialized
INFO - 2020-08-13 07:41:07 --> Model Class Initialized
DEBUG - 2020-08-13 07:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 07:41:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 07:41:07 --> Model Class Initialized
INFO - 2020-08-13 07:41:07 --> Final output sent to browser
DEBUG - 2020-08-13 07:41:07 --> Total execution time: 0.0581
INFO - 2020-08-13 07:41:07 --> Config Class Initialized
INFO - 2020-08-13 07:41:07 --> Hooks Class Initialized
DEBUG - 2020-08-13 07:41:07 --> UTF-8 Support Enabled
INFO - 2020-08-13 07:41:07 --> Utf8 Class Initialized
INFO - 2020-08-13 07:41:07 --> URI Class Initialized
INFO - 2020-08-13 07:41:07 --> Router Class Initialized
INFO - 2020-08-13 07:41:07 --> Output Class Initialized
INFO - 2020-08-13 07:41:07 --> Security Class Initialized
DEBUG - 2020-08-13 07:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 07:41:07 --> Input Class Initialized
INFO - 2020-08-13 07:41:07 --> Language Class Initialized
INFO - 2020-08-13 07:41:07 --> Loader Class Initialized
INFO - 2020-08-13 07:41:07 --> Helper loaded: url_helper
INFO - 2020-08-13 07:41:07 --> Database Driver Class Initialized
INFO - 2020-08-13 07:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 07:41:07 --> Email Class Initialized
INFO - 2020-08-13 07:41:07 --> Controller Class Initialized
DEBUG - 2020-08-13 07:41:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 07:41:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 07:41:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-13 07:41:07 --> Final output sent to browser
DEBUG - 2020-08-13 07:41:07 --> Total execution time: 0.0468
INFO - 2020-08-13 07:41:13 --> Config Class Initialized
INFO - 2020-08-13 07:41:13 --> Hooks Class Initialized
DEBUG - 2020-08-13 07:41:13 --> UTF-8 Support Enabled
INFO - 2020-08-13 07:41:13 --> Utf8 Class Initialized
INFO - 2020-08-13 07:41:13 --> URI Class Initialized
INFO - 2020-08-13 07:41:13 --> Router Class Initialized
INFO - 2020-08-13 07:41:13 --> Output Class Initialized
INFO - 2020-08-13 07:41:13 --> Security Class Initialized
DEBUG - 2020-08-13 07:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 07:41:13 --> Input Class Initialized
INFO - 2020-08-13 07:41:13 --> Language Class Initialized
INFO - 2020-08-13 07:41:13 --> Loader Class Initialized
INFO - 2020-08-13 07:41:13 --> Helper loaded: url_helper
INFO - 2020-08-13 07:41:13 --> Database Driver Class Initialized
INFO - 2020-08-13 07:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 07:41:13 --> Email Class Initialized
INFO - 2020-08-13 07:41:13 --> Controller Class Initialized
DEBUG - 2020-08-13 07:41:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 07:41:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 07:41:13 --> Model Class Initialized
INFO - 2020-08-13 07:41:13 --> Model Class Initialized
INFO - 2020-08-13 07:41:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 07:41:13 --> Final output sent to browser
DEBUG - 2020-08-13 07:41:13 --> Total execution time: 0.0464
INFO - 2020-08-13 07:41:19 --> Config Class Initialized
INFO - 2020-08-13 07:41:19 --> Hooks Class Initialized
DEBUG - 2020-08-13 07:41:19 --> UTF-8 Support Enabled
INFO - 2020-08-13 07:41:19 --> Utf8 Class Initialized
INFO - 2020-08-13 07:41:19 --> URI Class Initialized
INFO - 2020-08-13 07:41:19 --> Router Class Initialized
INFO - 2020-08-13 07:41:19 --> Output Class Initialized
INFO - 2020-08-13 07:41:19 --> Security Class Initialized
DEBUG - 2020-08-13 07:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 07:41:19 --> Input Class Initialized
INFO - 2020-08-13 07:41:19 --> Language Class Initialized
INFO - 2020-08-13 07:41:19 --> Loader Class Initialized
INFO - 2020-08-13 07:41:19 --> Helper loaded: url_helper
INFO - 2020-08-13 07:41:19 --> Database Driver Class Initialized
INFO - 2020-08-13 07:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 07:41:19 --> Email Class Initialized
INFO - 2020-08-13 07:41:19 --> Controller Class Initialized
DEBUG - 2020-08-13 07:41:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 07:41:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 07:41:19 --> Model Class Initialized
INFO - 2020-08-13 07:41:19 --> Model Class Initialized
INFO - 2020-08-13 07:41:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 07:41:19 --> Final output sent to browser
DEBUG - 2020-08-13 07:41:19 --> Total execution time: 0.0351
INFO - 2020-08-13 09:10:59 --> Config Class Initialized
INFO - 2020-08-13 09:10:59 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:10:59 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:10:59 --> Utf8 Class Initialized
INFO - 2020-08-13 09:10:59 --> URI Class Initialized
INFO - 2020-08-13 09:10:59 --> Router Class Initialized
INFO - 2020-08-13 09:10:59 --> Output Class Initialized
INFO - 2020-08-13 09:10:59 --> Security Class Initialized
DEBUG - 2020-08-13 09:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:10:59 --> Input Class Initialized
INFO - 2020-08-13 09:10:59 --> Language Class Initialized
INFO - 2020-08-13 09:10:59 --> Loader Class Initialized
INFO - 2020-08-13 09:10:59 --> Helper loaded: url_helper
INFO - 2020-08-13 09:10:59 --> Database Driver Class Initialized
INFO - 2020-08-13 09:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:10:59 --> Email Class Initialized
INFO - 2020-08-13 09:10:59 --> Controller Class Initialized
DEBUG - 2020-08-13 09:10:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:10:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:00 --> Config Class Initialized
INFO - 2020-08-13 09:11:00 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:11:00 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:00 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:00 --> URI Class Initialized
DEBUG - 2020-08-13 09:11:00 --> No URI present. Default controller set.
INFO - 2020-08-13 09:11:00 --> Router Class Initialized
INFO - 2020-08-13 09:11:00 --> Output Class Initialized
INFO - 2020-08-13 09:11:00 --> Security Class Initialized
DEBUG - 2020-08-13 09:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:00 --> Input Class Initialized
INFO - 2020-08-13 09:11:00 --> Language Class Initialized
INFO - 2020-08-13 09:11:00 --> Loader Class Initialized
INFO - 2020-08-13 09:11:00 --> Helper loaded: url_helper
INFO - 2020-08-13 09:11:00 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:00 --> Email Class Initialized
INFO - 2020-08-13 09:11:00 --> Controller Class Initialized
INFO - 2020-08-13 09:11:00 --> Model Class Initialized
INFO - 2020-08-13 09:11:00 --> Model Class Initialized
DEBUG - 2020-08-13 09:11:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 09:11:00 --> Final output sent to browser
DEBUG - 2020-08-13 09:11:00 --> Total execution time: 0.0248
INFO - 2020-08-13 09:11:03 --> Config Class Initialized
INFO - 2020-08-13 09:11:03 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:11:03 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:03 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:03 --> URI Class Initialized
INFO - 2020-08-13 09:11:03 --> Router Class Initialized
INFO - 2020-08-13 09:11:03 --> Output Class Initialized
INFO - 2020-08-13 09:11:03 --> Security Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:03 --> Input Class Initialized
INFO - 2020-08-13 09:11:03 --> Language Class Initialized
INFO - 2020-08-13 09:11:03 --> Loader Class Initialized
INFO - 2020-08-13 09:11:03 --> Helper loaded: url_helper
INFO - 2020-08-13 09:11:03 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:03 --> Email Class Initialized
INFO - 2020-08-13 09:11:03 --> Controller Class Initialized
INFO - 2020-08-13 09:11:03 --> Model Class Initialized
INFO - 2020-08-13 09:11:03 --> Config Class Initialized
INFO - 2020-08-13 09:11:03 --> Hooks Class Initialized
INFO - 2020-08-13 09:11:03 --> Model Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:11:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:11:03 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:03 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:03 --> URI Class Initialized
INFO - 2020-08-13 09:11:03 --> Router Class Initialized
INFO - 2020-08-13 09:11:03 --> Output Class Initialized
INFO - 2020-08-13 09:11:03 --> Security Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:03 --> Input Class Initialized
INFO - 2020-08-13 09:11:03 --> Language Class Initialized
INFO - 2020-08-13 09:11:03 --> Loader Class Initialized
INFO - 2020-08-13 09:11:03 --> Helper loaded: url_helper
INFO - 2020-08-13 09:11:03 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:03 --> Email Class Initialized
INFO - 2020-08-13 09:11:03 --> Controller Class Initialized
INFO - 2020-08-13 09:11:03 --> Model Class Initialized
INFO - 2020-08-13 09:11:03 --> Model Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:03 --> Config Class Initialized
INFO - 2020-08-13 09:11:03 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:11:03 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:03 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:03 --> URI Class Initialized
INFO - 2020-08-13 09:11:03 --> Config Class Initialized
INFO - 2020-08-13 09:11:03 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:11:03 --> No URI present. Default controller set.
INFO - 2020-08-13 09:11:03 --> Router Class Initialized
INFO - 2020-08-13 09:11:03 --> Output Class Initialized
DEBUG - 2020-08-13 09:11:03 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:03 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:03 --> Security Class Initialized
INFO - 2020-08-13 09:11:03 --> URI Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:03 --> Input Class Initialized
INFO - 2020-08-13 09:11:03 --> Language Class Initialized
INFO - 2020-08-13 09:11:03 --> Router Class Initialized
INFO - 2020-08-13 09:11:03 --> Output Class Initialized
INFO - 2020-08-13 09:11:03 --> Loader Class Initialized
INFO - 2020-08-13 09:11:03 --> Security Class Initialized
INFO - 2020-08-13 09:11:03 --> Helper loaded: url_helper
DEBUG - 2020-08-13 09:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:03 --> Input Class Initialized
INFO - 2020-08-13 09:11:03 --> Language Class Initialized
INFO - 2020-08-13 09:11:03 --> Loader Class Initialized
INFO - 2020-08-13 09:11:03 --> Helper loaded: url_helper
INFO - 2020-08-13 09:11:03 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:03 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:03 --> Email Class Initialized
INFO - 2020-08-13 09:11:03 --> Controller Class Initialized
INFO - 2020-08-13 09:11:03 --> Model Class Initialized
INFO - 2020-08-13 09:11:03 --> Model Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 09:11:03 --> Final output sent to browser
DEBUG - 2020-08-13 09:11:03 --> Total execution time: 0.0238
INFO - 2020-08-13 09:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:03 --> Email Class Initialized
INFO - 2020-08-13 09:11:03 --> Controller Class Initialized
DEBUG - 2020-08-13 09:11:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:11:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-13 09:11:03 --> Final output sent to browser
DEBUG - 2020-08-13 09:11:03 --> Total execution time: 0.0258
INFO - 2020-08-13 09:11:06 --> Config Class Initialized
INFO - 2020-08-13 09:11:06 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:11:06 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:06 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:06 --> URI Class Initialized
INFO - 2020-08-13 09:11:06 --> Router Class Initialized
INFO - 2020-08-13 09:11:06 --> Output Class Initialized
INFO - 2020-08-13 09:11:06 --> Security Class Initialized
DEBUG - 2020-08-13 09:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:06 --> Input Class Initialized
INFO - 2020-08-13 09:11:06 --> Language Class Initialized
INFO - 2020-08-13 09:11:06 --> Loader Class Initialized
INFO - 2020-08-13 09:11:06 --> Helper loaded: url_helper
INFO - 2020-08-13 09:11:06 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:06 --> Email Class Initialized
INFO - 2020-08-13 09:11:06 --> Controller Class Initialized
DEBUG - 2020-08-13 09:11:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:11:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:06 --> Model Class Initialized
INFO - 2020-08-13 09:11:06 --> Model Class Initialized
INFO - 2020-08-13 09:11:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 09:11:06 --> Final output sent to browser
DEBUG - 2020-08-13 09:11:06 --> Total execution time: 0.0290
INFO - 2020-08-13 09:11:11 --> Config Class Initialized
INFO - 2020-08-13 09:11:11 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:11:11 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:11:11 --> Utf8 Class Initialized
INFO - 2020-08-13 09:11:11 --> URI Class Initialized
INFO - 2020-08-13 09:11:11 --> Router Class Initialized
INFO - 2020-08-13 09:11:11 --> Output Class Initialized
INFO - 2020-08-13 09:11:11 --> Security Class Initialized
DEBUG - 2020-08-13 09:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:11:11 --> Input Class Initialized
INFO - 2020-08-13 09:11:11 --> Language Class Initialized
INFO - 2020-08-13 09:11:11 --> Loader Class Initialized
INFO - 2020-08-13 09:11:11 --> Helper loaded: url_helper
INFO - 2020-08-13 09:11:11 --> Database Driver Class Initialized
INFO - 2020-08-13 09:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:11:11 --> Email Class Initialized
INFO - 2020-08-13 09:11:11 --> Controller Class Initialized
DEBUG - 2020-08-13 09:11:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:11:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:11:11 --> Model Class Initialized
INFO - 2020-08-13 09:11:11 --> Model Class Initialized
INFO - 2020-08-13 09:11:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 09:11:11 --> Final output sent to browser
DEBUG - 2020-08-13 09:11:11 --> Total execution time: 0.0288
INFO - 2020-08-13 09:13:01 --> Config Class Initialized
INFO - 2020-08-13 09:13:01 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:13:01 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:13:01 --> Utf8 Class Initialized
INFO - 2020-08-13 09:13:01 --> URI Class Initialized
INFO - 2020-08-13 09:13:01 --> Router Class Initialized
INFO - 2020-08-13 09:13:01 --> Output Class Initialized
INFO - 2020-08-13 09:13:01 --> Security Class Initialized
DEBUG - 2020-08-13 09:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:13:01 --> Input Class Initialized
INFO - 2020-08-13 09:13:01 --> Language Class Initialized
INFO - 2020-08-13 09:13:01 --> Loader Class Initialized
INFO - 2020-08-13 09:13:01 --> Helper loaded: url_helper
INFO - 2020-08-13 09:13:01 --> Database Driver Class Initialized
INFO - 2020-08-13 09:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:13:01 --> Email Class Initialized
INFO - 2020-08-13 09:13:01 --> Controller Class Initialized
DEBUG - 2020-08-13 09:13:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:13:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:13:01 --> Model Class Initialized
INFO - 2020-08-13 09:13:01 --> Model Class Initialized
INFO - 2020-08-13 09:13:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 09:13:01 --> Final output sent to browser
DEBUG - 2020-08-13 09:13:01 --> Total execution time: 0.0284
INFO - 2020-08-13 09:14:29 --> Config Class Initialized
INFO - 2020-08-13 09:14:29 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:14:29 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:14:29 --> Utf8 Class Initialized
INFO - 2020-08-13 09:14:29 --> URI Class Initialized
INFO - 2020-08-13 09:14:29 --> Router Class Initialized
INFO - 2020-08-13 09:14:29 --> Output Class Initialized
INFO - 2020-08-13 09:14:29 --> Security Class Initialized
DEBUG - 2020-08-13 09:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:14:29 --> Input Class Initialized
INFO - 2020-08-13 09:14:29 --> Language Class Initialized
INFO - 2020-08-13 09:14:29 --> Loader Class Initialized
INFO - 2020-08-13 09:14:29 --> Helper loaded: url_helper
INFO - 2020-08-13 09:14:29 --> Database Driver Class Initialized
INFO - 2020-08-13 09:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:14:29 --> Email Class Initialized
INFO - 2020-08-13 09:14:29 --> Controller Class Initialized
DEBUG - 2020-08-13 09:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:14:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:14:29 --> Model Class Initialized
INFO - 2020-08-13 09:14:29 --> Model Class Initialized
INFO - 2020-08-13 09:14:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 09:14:29 --> Final output sent to browser
DEBUG - 2020-08-13 09:14:29 --> Total execution time: 0.0249
INFO - 2020-08-13 09:18:49 --> Config Class Initialized
INFO - 2020-08-13 09:18:49 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:18:49 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:18:49 --> Utf8 Class Initialized
INFO - 2020-08-13 09:18:49 --> URI Class Initialized
INFO - 2020-08-13 09:18:49 --> Router Class Initialized
INFO - 2020-08-13 09:18:49 --> Output Class Initialized
INFO - 2020-08-13 09:18:49 --> Security Class Initialized
DEBUG - 2020-08-13 09:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:18:49 --> Input Class Initialized
INFO - 2020-08-13 09:18:49 --> Language Class Initialized
INFO - 2020-08-13 09:18:49 --> Loader Class Initialized
INFO - 2020-08-13 09:18:49 --> Helper loaded: url_helper
INFO - 2020-08-13 09:18:49 --> Database Driver Class Initialized
INFO - 2020-08-13 09:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:18:49 --> Email Class Initialized
INFO - 2020-08-13 09:18:49 --> Controller Class Initialized
DEBUG - 2020-08-13 09:18:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:18:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:18:49 --> Model Class Initialized
INFO - 2020-08-13 09:18:49 --> Model Class Initialized
INFO - 2020-08-13 09:18:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 09:18:49 --> Final output sent to browser
DEBUG - 2020-08-13 09:18:49 --> Total execution time: 0.0702
INFO - 2020-08-13 09:22:18 --> Config Class Initialized
INFO - 2020-08-13 09:22:18 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:22:18 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:22:18 --> Utf8 Class Initialized
INFO - 2020-08-13 09:22:18 --> URI Class Initialized
INFO - 2020-08-13 09:22:18 --> Router Class Initialized
INFO - 2020-08-13 09:22:18 --> Output Class Initialized
INFO - 2020-08-13 09:22:18 --> Security Class Initialized
DEBUG - 2020-08-13 09:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:22:18 --> Input Class Initialized
INFO - 2020-08-13 09:22:18 --> Language Class Initialized
INFO - 2020-08-13 09:22:18 --> Loader Class Initialized
INFO - 2020-08-13 09:22:18 --> Helper loaded: url_helper
INFO - 2020-08-13 09:22:18 --> Database Driver Class Initialized
INFO - 2020-08-13 09:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:22:18 --> Email Class Initialized
INFO - 2020-08-13 09:22:18 --> Controller Class Initialized
DEBUG - 2020-08-13 09:22:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:22:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:22:18 --> Model Class Initialized
INFO - 2020-08-13 09:22:18 --> Model Class Initialized
INFO - 2020-08-13 09:22:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 09:22:18 --> Final output sent to browser
DEBUG - 2020-08-13 09:22:18 --> Total execution time: 0.0250
INFO - 2020-08-13 09:42:54 --> Config Class Initialized
INFO - 2020-08-13 09:42:54 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:42:54 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:42:54 --> Utf8 Class Initialized
INFO - 2020-08-13 09:42:54 --> URI Class Initialized
INFO - 2020-08-13 09:42:54 --> Router Class Initialized
INFO - 2020-08-13 09:42:54 --> Output Class Initialized
INFO - 2020-08-13 09:42:54 --> Security Class Initialized
DEBUG - 2020-08-13 09:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:42:54 --> Input Class Initialized
INFO - 2020-08-13 09:42:54 --> Language Class Initialized
INFO - 2020-08-13 09:42:54 --> Loader Class Initialized
INFO - 2020-08-13 09:42:54 --> Helper loaded: url_helper
INFO - 2020-08-13 09:42:54 --> Database Driver Class Initialized
INFO - 2020-08-13 09:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:42:54 --> Email Class Initialized
INFO - 2020-08-13 09:42:54 --> Controller Class Initialized
DEBUG - 2020-08-13 09:42:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:42:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:42:54 --> Model Class Initialized
INFO - 2020-08-13 09:42:54 --> Model Class Initialized
INFO - 2020-08-13 09:42:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 09:42:54 --> Final output sent to browser
DEBUG - 2020-08-13 09:42:54 --> Total execution time: 0.0973
INFO - 2020-08-13 09:44:03 --> Config Class Initialized
INFO - 2020-08-13 09:44:03 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:44:03 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:44:03 --> Utf8 Class Initialized
INFO - 2020-08-13 09:44:03 --> URI Class Initialized
INFO - 2020-08-13 09:44:03 --> Router Class Initialized
INFO - 2020-08-13 09:44:03 --> Output Class Initialized
INFO - 2020-08-13 09:44:03 --> Security Class Initialized
DEBUG - 2020-08-13 09:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:44:03 --> Input Class Initialized
INFO - 2020-08-13 09:44:03 --> Language Class Initialized
INFO - 2020-08-13 09:44:03 --> Loader Class Initialized
INFO - 2020-08-13 09:44:03 --> Helper loaded: url_helper
INFO - 2020-08-13 09:44:03 --> Database Driver Class Initialized
INFO - 2020-08-13 09:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:44:03 --> Email Class Initialized
INFO - 2020-08-13 09:44:03 --> Controller Class Initialized
DEBUG - 2020-08-13 09:44:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:44:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:44:03 --> Model Class Initialized
INFO - 2020-08-13 09:44:03 --> Model Class Initialized
INFO - 2020-08-13 09:44:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 09:44:03 --> Final output sent to browser
DEBUG - 2020-08-13 09:44:03 --> Total execution time: 0.0253
INFO - 2020-08-13 09:44:05 --> Config Class Initialized
INFO - 2020-08-13 09:44:05 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:44:05 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:44:05 --> Utf8 Class Initialized
INFO - 2020-08-13 09:44:05 --> URI Class Initialized
INFO - 2020-08-13 09:44:05 --> Router Class Initialized
INFO - 2020-08-13 09:44:05 --> Output Class Initialized
INFO - 2020-08-13 09:44:05 --> Security Class Initialized
DEBUG - 2020-08-13 09:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:44:05 --> Input Class Initialized
INFO - 2020-08-13 09:44:05 --> Language Class Initialized
INFO - 2020-08-13 09:44:05 --> Loader Class Initialized
INFO - 2020-08-13 09:44:05 --> Helper loaded: url_helper
INFO - 2020-08-13 09:44:05 --> Database Driver Class Initialized
INFO - 2020-08-13 09:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:44:05 --> Email Class Initialized
INFO - 2020-08-13 09:44:05 --> Controller Class Initialized
DEBUG - 2020-08-13 09:44:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:44:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:44:05 --> Model Class Initialized
INFO - 2020-08-13 09:44:05 --> Model Class Initialized
INFO - 2020-08-13 09:44:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 09:44:05 --> Final output sent to browser
DEBUG - 2020-08-13 09:44:05 --> Total execution time: 0.0397
INFO - 2020-08-13 09:46:13 --> Config Class Initialized
INFO - 2020-08-13 09:46:13 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:46:13 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:46:13 --> Utf8 Class Initialized
INFO - 2020-08-13 09:46:13 --> URI Class Initialized
INFO - 2020-08-13 09:46:13 --> Router Class Initialized
INFO - 2020-08-13 09:46:13 --> Output Class Initialized
INFO - 2020-08-13 09:46:13 --> Security Class Initialized
DEBUG - 2020-08-13 09:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:46:13 --> Input Class Initialized
INFO - 2020-08-13 09:46:13 --> Language Class Initialized
INFO - 2020-08-13 09:46:13 --> Loader Class Initialized
INFO - 2020-08-13 09:46:13 --> Helper loaded: url_helper
INFO - 2020-08-13 09:46:13 --> Database Driver Class Initialized
INFO - 2020-08-13 09:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:46:13 --> Email Class Initialized
INFO - 2020-08-13 09:46:13 --> Controller Class Initialized
DEBUG - 2020-08-13 09:46:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:46:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:46:13 --> Model Class Initialized
INFO - 2020-08-13 09:46:13 --> Model Class Initialized
INFO - 2020-08-13 09:46:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 09:46:13 --> Final output sent to browser
DEBUG - 2020-08-13 09:46:13 --> Total execution time: 0.0279
INFO - 2020-08-13 09:58:09 --> Config Class Initialized
INFO - 2020-08-13 09:58:09 --> Hooks Class Initialized
DEBUG - 2020-08-13 09:58:09 --> UTF-8 Support Enabled
INFO - 2020-08-13 09:58:09 --> Utf8 Class Initialized
INFO - 2020-08-13 09:58:09 --> URI Class Initialized
INFO - 2020-08-13 09:58:09 --> Router Class Initialized
INFO - 2020-08-13 09:58:09 --> Output Class Initialized
INFO - 2020-08-13 09:58:09 --> Security Class Initialized
DEBUG - 2020-08-13 09:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 09:58:09 --> Input Class Initialized
INFO - 2020-08-13 09:58:09 --> Language Class Initialized
INFO - 2020-08-13 09:58:09 --> Loader Class Initialized
INFO - 2020-08-13 09:58:09 --> Helper loaded: url_helper
INFO - 2020-08-13 09:58:09 --> Database Driver Class Initialized
INFO - 2020-08-13 09:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 09:58:09 --> Email Class Initialized
INFO - 2020-08-13 09:58:09 --> Controller Class Initialized
DEBUG - 2020-08-13 09:58:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 09:58:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 09:58:09 --> Model Class Initialized
INFO - 2020-08-13 09:58:09 --> Model Class Initialized
INFO - 2020-08-13 09:58:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 09:58:09 --> Final output sent to browser
DEBUG - 2020-08-13 09:58:09 --> Total execution time: 0.0229
INFO - 2020-08-13 10:21:02 --> Config Class Initialized
INFO - 2020-08-13 10:21:02 --> Hooks Class Initialized
DEBUG - 2020-08-13 10:21:02 --> UTF-8 Support Enabled
INFO - 2020-08-13 10:21:02 --> Utf8 Class Initialized
INFO - 2020-08-13 10:21:02 --> URI Class Initialized
INFO - 2020-08-13 10:21:02 --> Router Class Initialized
INFO - 2020-08-13 10:21:02 --> Output Class Initialized
INFO - 2020-08-13 10:21:02 --> Security Class Initialized
DEBUG - 2020-08-13 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 10:21:02 --> Input Class Initialized
INFO - 2020-08-13 10:21:02 --> Language Class Initialized
INFO - 2020-08-13 10:21:02 --> Loader Class Initialized
INFO - 2020-08-13 10:21:02 --> Helper loaded: url_helper
INFO - 2020-08-13 10:21:02 --> Database Driver Class Initialized
INFO - 2020-08-13 10:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 10:21:02 --> Email Class Initialized
INFO - 2020-08-13 10:21:02 --> Controller Class Initialized
DEBUG - 2020-08-13 10:21:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 10:21:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 10:21:02 --> Model Class Initialized
INFO - 2020-08-13 10:21:02 --> Model Class Initialized
INFO - 2020-08-13 10:21:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 10:21:02 --> Final output sent to browser
DEBUG - 2020-08-13 10:21:02 --> Total execution time: 0.0275
INFO - 2020-08-13 16:48:55 --> Config Class Initialized
INFO - 2020-08-13 16:48:55 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:48:55 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:48:55 --> Utf8 Class Initialized
INFO - 2020-08-13 16:48:55 --> URI Class Initialized
DEBUG - 2020-08-13 16:48:55 --> No URI present. Default controller set.
INFO - 2020-08-13 16:48:55 --> Router Class Initialized
INFO - 2020-08-13 16:48:55 --> Output Class Initialized
INFO - 2020-08-13 16:48:55 --> Security Class Initialized
DEBUG - 2020-08-13 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:48:55 --> Input Class Initialized
INFO - 2020-08-13 16:48:55 --> Language Class Initialized
INFO - 2020-08-13 16:48:55 --> Loader Class Initialized
INFO - 2020-08-13 16:48:55 --> Helper loaded: url_helper
INFO - 2020-08-13 16:48:55 --> Database Driver Class Initialized
INFO - 2020-08-13 16:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:48:55 --> Email Class Initialized
INFO - 2020-08-13 16:48:55 --> Controller Class Initialized
INFO - 2020-08-13 16:48:55 --> Model Class Initialized
INFO - 2020-08-13 16:48:55 --> Model Class Initialized
DEBUG - 2020-08-13 16:48:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:48:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 16:48:55 --> Final output sent to browser
DEBUG - 2020-08-13 16:48:55 --> Total execution time: 0.0318
INFO - 2020-08-13 16:49:14 --> Config Class Initialized
INFO - 2020-08-13 16:49:14 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:49:14 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:49:14 --> Utf8 Class Initialized
INFO - 2020-08-13 16:49:14 --> URI Class Initialized
INFO - 2020-08-13 16:49:14 --> Router Class Initialized
INFO - 2020-08-13 16:49:14 --> Output Class Initialized
INFO - 2020-08-13 16:49:14 --> Security Class Initialized
DEBUG - 2020-08-13 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:49:14 --> Input Class Initialized
INFO - 2020-08-13 16:49:14 --> Language Class Initialized
INFO - 2020-08-13 16:49:14 --> Loader Class Initialized
INFO - 2020-08-13 16:49:14 --> Helper loaded: url_helper
INFO - 2020-08-13 16:49:14 --> Database Driver Class Initialized
INFO - 2020-08-13 16:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:49:14 --> Email Class Initialized
INFO - 2020-08-13 16:49:14 --> Controller Class Initialized
INFO - 2020-08-13 16:49:14 --> Model Class Initialized
INFO - 2020-08-13 16:49:14 --> Model Class Initialized
DEBUG - 2020-08-13 16:49:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 16:49:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:49:14 --> Config Class Initialized
INFO - 2020-08-13 16:49:14 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:49:14 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:49:14 --> Utf8 Class Initialized
INFO - 2020-08-13 16:49:14 --> URI Class Initialized
INFO - 2020-08-13 16:49:14 --> Router Class Initialized
INFO - 2020-08-13 16:49:14 --> Output Class Initialized
INFO - 2020-08-13 16:49:14 --> Security Class Initialized
DEBUG - 2020-08-13 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:49:14 --> Input Class Initialized
INFO - 2020-08-13 16:49:14 --> Language Class Initialized
INFO - 2020-08-13 16:49:14 --> Loader Class Initialized
INFO - 2020-08-13 16:49:14 --> Helper loaded: url_helper
INFO - 2020-08-13 16:49:14 --> Database Driver Class Initialized
INFO - 2020-08-13 16:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:49:14 --> Email Class Initialized
INFO - 2020-08-13 16:49:14 --> Controller Class Initialized
INFO - 2020-08-13 16:49:14 --> Model Class Initialized
INFO - 2020-08-13 16:49:14 --> Model Class Initialized
DEBUG - 2020-08-13 16:49:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:49:15 --> Config Class Initialized
INFO - 2020-08-13 16:49:15 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:49:15 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:49:15 --> Utf8 Class Initialized
INFO - 2020-08-13 16:49:15 --> URI Class Initialized
DEBUG - 2020-08-13 16:49:15 --> No URI present. Default controller set.
INFO - 2020-08-13 16:49:15 --> Router Class Initialized
INFO - 2020-08-13 16:49:15 --> Output Class Initialized
INFO - 2020-08-13 16:49:15 --> Security Class Initialized
DEBUG - 2020-08-13 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:49:15 --> Input Class Initialized
INFO - 2020-08-13 16:49:15 --> Language Class Initialized
INFO - 2020-08-13 16:49:15 --> Loader Class Initialized
INFO - 2020-08-13 16:49:15 --> Helper loaded: url_helper
INFO - 2020-08-13 16:49:15 --> Database Driver Class Initialized
INFO - 2020-08-13 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:49:15 --> Email Class Initialized
INFO - 2020-08-13 16:49:15 --> Controller Class Initialized
INFO - 2020-08-13 16:49:15 --> Model Class Initialized
INFO - 2020-08-13 16:49:15 --> Model Class Initialized
DEBUG - 2020-08-13 16:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:49:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 16:49:15 --> Final output sent to browser
DEBUG - 2020-08-13 16:49:15 --> Total execution time: 0.0225
INFO - 2020-08-13 16:49:15 --> Config Class Initialized
INFO - 2020-08-13 16:49:15 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:49:15 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:49:15 --> Utf8 Class Initialized
INFO - 2020-08-13 16:49:15 --> URI Class Initialized
INFO - 2020-08-13 16:49:15 --> Router Class Initialized
INFO - 2020-08-13 16:49:15 --> Output Class Initialized
INFO - 2020-08-13 16:49:15 --> Security Class Initialized
DEBUG - 2020-08-13 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:49:15 --> Input Class Initialized
INFO - 2020-08-13 16:49:15 --> Language Class Initialized
INFO - 2020-08-13 16:49:15 --> Loader Class Initialized
INFO - 2020-08-13 16:49:15 --> Helper loaded: url_helper
INFO - 2020-08-13 16:49:15 --> Database Driver Class Initialized
INFO - 2020-08-13 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:49:15 --> Email Class Initialized
INFO - 2020-08-13 16:49:15 --> Controller Class Initialized
DEBUG - 2020-08-13 16:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 16:49:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:49:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-13 16:49:15 --> Final output sent to browser
DEBUG - 2020-08-13 16:49:15 --> Total execution time: 0.0212
INFO - 2020-08-13 16:49:22 --> Config Class Initialized
INFO - 2020-08-13 16:49:22 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:49:22 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:49:22 --> Utf8 Class Initialized
INFO - 2020-08-13 16:49:22 --> URI Class Initialized
INFO - 2020-08-13 16:49:22 --> Router Class Initialized
INFO - 2020-08-13 16:49:22 --> Output Class Initialized
INFO - 2020-08-13 16:49:22 --> Security Class Initialized
DEBUG - 2020-08-13 16:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:49:22 --> Input Class Initialized
INFO - 2020-08-13 16:49:22 --> Language Class Initialized
INFO - 2020-08-13 16:49:22 --> Loader Class Initialized
INFO - 2020-08-13 16:49:22 --> Helper loaded: url_helper
INFO - 2020-08-13 16:49:22 --> Database Driver Class Initialized
INFO - 2020-08-13 16:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:49:23 --> Email Class Initialized
INFO - 2020-08-13 16:49:23 --> Controller Class Initialized
DEBUG - 2020-08-13 16:49:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 16:49:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:49:23 --> Model Class Initialized
INFO - 2020-08-13 16:49:23 --> Model Class Initialized
INFO - 2020-08-13 16:49:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 16:49:23 --> Final output sent to browser
DEBUG - 2020-08-13 16:49:23 --> Total execution time: 0.0289
INFO - 2020-08-13 16:49:27 --> Config Class Initialized
INFO - 2020-08-13 16:49:27 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:49:27 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:49:27 --> Utf8 Class Initialized
INFO - 2020-08-13 16:49:27 --> URI Class Initialized
INFO - 2020-08-13 16:49:27 --> Router Class Initialized
INFO - 2020-08-13 16:49:27 --> Output Class Initialized
INFO - 2020-08-13 16:49:27 --> Security Class Initialized
DEBUG - 2020-08-13 16:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:49:27 --> Input Class Initialized
INFO - 2020-08-13 16:49:27 --> Language Class Initialized
INFO - 2020-08-13 16:49:27 --> Loader Class Initialized
INFO - 2020-08-13 16:49:27 --> Helper loaded: url_helper
INFO - 2020-08-13 16:49:27 --> Database Driver Class Initialized
INFO - 2020-08-13 16:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:49:27 --> Email Class Initialized
INFO - 2020-08-13 16:49:27 --> Controller Class Initialized
DEBUG - 2020-08-13 16:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 16:49:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:49:27 --> Model Class Initialized
INFO - 2020-08-13 16:49:27 --> Model Class Initialized
INFO - 2020-08-13 16:49:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 16:49:27 --> Final output sent to browser
DEBUG - 2020-08-13 16:49:27 --> Total execution time: 0.0252
INFO - 2020-08-13 16:52:02 --> Config Class Initialized
INFO - 2020-08-13 16:52:02 --> Hooks Class Initialized
DEBUG - 2020-08-13 16:52:02 --> UTF-8 Support Enabled
INFO - 2020-08-13 16:52:02 --> Utf8 Class Initialized
INFO - 2020-08-13 16:52:02 --> URI Class Initialized
INFO - 2020-08-13 16:52:02 --> Router Class Initialized
INFO - 2020-08-13 16:52:02 --> Output Class Initialized
INFO - 2020-08-13 16:52:02 --> Security Class Initialized
DEBUG - 2020-08-13 16:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 16:52:02 --> Input Class Initialized
INFO - 2020-08-13 16:52:02 --> Language Class Initialized
INFO - 2020-08-13 16:52:02 --> Loader Class Initialized
INFO - 2020-08-13 16:52:02 --> Helper loaded: url_helper
INFO - 2020-08-13 16:52:02 --> Database Driver Class Initialized
INFO - 2020-08-13 16:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 16:52:02 --> Email Class Initialized
INFO - 2020-08-13 16:52:02 --> Controller Class Initialized
DEBUG - 2020-08-13 16:52:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 16:52:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 16:52:02 --> Model Class Initialized
INFO - 2020-08-13 16:52:02 --> Model Class Initialized
INFO - 2020-08-13 16:52:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 16:52:02 --> Final output sent to browser
DEBUG - 2020-08-13 16:52:02 --> Total execution time: 0.0261
INFO - 2020-08-13 17:01:02 --> Config Class Initialized
INFO - 2020-08-13 17:01:02 --> Hooks Class Initialized
DEBUG - 2020-08-13 17:01:02 --> UTF-8 Support Enabled
INFO - 2020-08-13 17:01:02 --> Utf8 Class Initialized
INFO - 2020-08-13 17:01:02 --> URI Class Initialized
INFO - 2020-08-13 17:01:02 --> Router Class Initialized
INFO - 2020-08-13 17:01:02 --> Output Class Initialized
INFO - 2020-08-13 17:01:02 --> Security Class Initialized
DEBUG - 2020-08-13 17:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 17:01:02 --> Input Class Initialized
INFO - 2020-08-13 17:01:02 --> Language Class Initialized
INFO - 2020-08-13 17:01:02 --> Loader Class Initialized
INFO - 2020-08-13 17:01:02 --> Helper loaded: url_helper
INFO - 2020-08-13 17:01:02 --> Database Driver Class Initialized
INFO - 2020-08-13 17:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 17:01:02 --> Email Class Initialized
INFO - 2020-08-13 17:01:02 --> Controller Class Initialized
DEBUG - 2020-08-13 17:01:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 17:01:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 17:01:02 --> Model Class Initialized
INFO - 2020-08-13 17:01:02 --> Model Class Initialized
INFO - 2020-08-13 17:01:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 17:01:02 --> Final output sent to browser
DEBUG - 2020-08-13 17:01:02 --> Total execution time: 0.0302
INFO - 2020-08-13 17:02:32 --> Config Class Initialized
INFO - 2020-08-13 17:02:32 --> Hooks Class Initialized
DEBUG - 2020-08-13 17:02:32 --> UTF-8 Support Enabled
INFO - 2020-08-13 17:02:32 --> Utf8 Class Initialized
INFO - 2020-08-13 17:02:32 --> URI Class Initialized
INFO - 2020-08-13 17:02:32 --> Router Class Initialized
INFO - 2020-08-13 17:02:32 --> Output Class Initialized
INFO - 2020-08-13 17:02:32 --> Security Class Initialized
DEBUG - 2020-08-13 17:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 17:02:32 --> Input Class Initialized
INFO - 2020-08-13 17:02:32 --> Language Class Initialized
INFO - 2020-08-13 17:02:32 --> Loader Class Initialized
INFO - 2020-08-13 17:02:32 --> Helper loaded: url_helper
INFO - 2020-08-13 17:02:32 --> Database Driver Class Initialized
INFO - 2020-08-13 17:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 17:02:32 --> Email Class Initialized
INFO - 2020-08-13 17:02:32 --> Controller Class Initialized
DEBUG - 2020-08-13 17:02:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 17:02:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 17:02:32 --> Model Class Initialized
INFO - 2020-08-13 17:02:32 --> Model Class Initialized
INFO - 2020-08-13 17:02:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 17:02:32 --> Final output sent to browser
DEBUG - 2020-08-13 17:02:32 --> Total execution time: 0.0242
INFO - 2020-08-13 17:06:37 --> Config Class Initialized
INFO - 2020-08-13 17:06:37 --> Hooks Class Initialized
DEBUG - 2020-08-13 17:06:37 --> UTF-8 Support Enabled
INFO - 2020-08-13 17:06:37 --> Utf8 Class Initialized
INFO - 2020-08-13 17:06:37 --> URI Class Initialized
INFO - 2020-08-13 17:06:37 --> Router Class Initialized
INFO - 2020-08-13 17:06:37 --> Output Class Initialized
INFO - 2020-08-13 17:06:37 --> Security Class Initialized
DEBUG - 2020-08-13 17:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 17:06:37 --> Input Class Initialized
INFO - 2020-08-13 17:06:37 --> Language Class Initialized
INFO - 2020-08-13 17:06:37 --> Loader Class Initialized
INFO - 2020-08-13 17:06:37 --> Helper loaded: url_helper
INFO - 2020-08-13 17:06:37 --> Database Driver Class Initialized
INFO - 2020-08-13 17:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 17:06:37 --> Email Class Initialized
INFO - 2020-08-13 17:06:37 --> Controller Class Initialized
DEBUG - 2020-08-13 17:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 17:06:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 17:06:37 --> Model Class Initialized
INFO - 2020-08-13 17:06:37 --> Model Class Initialized
INFO - 2020-08-13 17:06:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 17:06:37 --> Final output sent to browser
DEBUG - 2020-08-13 17:06:37 --> Total execution time: 0.0250
INFO - 2020-08-13 17:09:17 --> Config Class Initialized
INFO - 2020-08-13 17:09:17 --> Hooks Class Initialized
DEBUG - 2020-08-13 17:09:17 --> UTF-8 Support Enabled
INFO - 2020-08-13 17:09:17 --> Utf8 Class Initialized
INFO - 2020-08-13 17:09:17 --> URI Class Initialized
INFO - 2020-08-13 17:09:17 --> Router Class Initialized
INFO - 2020-08-13 17:09:17 --> Output Class Initialized
INFO - 2020-08-13 17:09:17 --> Security Class Initialized
DEBUG - 2020-08-13 17:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 17:09:17 --> Input Class Initialized
INFO - 2020-08-13 17:09:17 --> Language Class Initialized
INFO - 2020-08-13 17:09:17 --> Loader Class Initialized
INFO - 2020-08-13 17:09:17 --> Helper loaded: url_helper
INFO - 2020-08-13 17:09:17 --> Database Driver Class Initialized
INFO - 2020-08-13 17:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 17:09:17 --> Email Class Initialized
INFO - 2020-08-13 17:09:17 --> Controller Class Initialized
DEBUG - 2020-08-13 17:09:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 17:09:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 17:09:17 --> Model Class Initialized
INFO - 2020-08-13 17:09:17 --> Model Class Initialized
INFO - 2020-08-13 17:09:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-13 17:09:17 --> Final output sent to browser
DEBUG - 2020-08-13 17:09:17 --> Total execution time: 0.0253
INFO - 2020-08-13 18:21:40 --> Config Class Initialized
INFO - 2020-08-13 18:21:40 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:21:40 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:21:40 --> Utf8 Class Initialized
INFO - 2020-08-13 18:21:40 --> URI Class Initialized
INFO - 2020-08-13 18:21:40 --> Router Class Initialized
INFO - 2020-08-13 18:21:40 --> Output Class Initialized
INFO - 2020-08-13 18:21:40 --> Security Class Initialized
DEBUG - 2020-08-13 18:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:21:40 --> Input Class Initialized
INFO - 2020-08-13 18:21:40 --> Language Class Initialized
INFO - 2020-08-13 18:21:40 --> Loader Class Initialized
INFO - 2020-08-13 18:21:40 --> Helper loaded: url_helper
INFO - 2020-08-13 18:21:40 --> Database Driver Class Initialized
INFO - 2020-08-13 18:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:21:40 --> Email Class Initialized
INFO - 2020-08-13 18:21:40 --> Controller Class Initialized
DEBUG - 2020-08-13 18:21:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:21:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:21:40 --> Model Class Initialized
INFO - 2020-08-13 18:21:40 --> Model Class Initialized
INFO - 2020-08-13 18:21:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 18:21:40 --> Final output sent to browser
DEBUG - 2020-08-13 18:21:40 --> Total execution time: 0.0241
INFO - 2020-08-13 18:21:43 --> Config Class Initialized
INFO - 2020-08-13 18:21:43 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:21:43 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:21:43 --> Utf8 Class Initialized
INFO - 2020-08-13 18:21:43 --> URI Class Initialized
INFO - 2020-08-13 18:21:43 --> Router Class Initialized
INFO - 2020-08-13 18:21:43 --> Output Class Initialized
INFO - 2020-08-13 18:21:43 --> Security Class Initialized
DEBUG - 2020-08-13 18:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:21:43 --> Input Class Initialized
INFO - 2020-08-13 18:21:43 --> Language Class Initialized
INFO - 2020-08-13 18:21:43 --> Loader Class Initialized
INFO - 2020-08-13 18:21:43 --> Helper loaded: url_helper
INFO - 2020-08-13 18:21:43 --> Database Driver Class Initialized
INFO - 2020-08-13 18:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:21:43 --> Email Class Initialized
INFO - 2020-08-13 18:21:43 --> Controller Class Initialized
DEBUG - 2020-08-13 18:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:21:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:21:43 --> Model Class Initialized
INFO - 2020-08-13 18:21:43 --> Model Class Initialized
INFO - 2020-08-13 18:21:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 18:21:43 --> Final output sent to browser
DEBUG - 2020-08-13 18:21:43 --> Total execution time: 0.0269
INFO - 2020-08-13 18:24:54 --> Config Class Initialized
INFO - 2020-08-13 18:24:54 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:24:54 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:24:54 --> Utf8 Class Initialized
INFO - 2020-08-13 18:24:54 --> URI Class Initialized
INFO - 2020-08-13 18:24:54 --> Router Class Initialized
INFO - 2020-08-13 18:24:54 --> Output Class Initialized
INFO - 2020-08-13 18:24:54 --> Security Class Initialized
DEBUG - 2020-08-13 18:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:24:54 --> Input Class Initialized
INFO - 2020-08-13 18:24:54 --> Language Class Initialized
INFO - 2020-08-13 18:24:54 --> Loader Class Initialized
INFO - 2020-08-13 18:24:54 --> Helper loaded: url_helper
INFO - 2020-08-13 18:24:54 --> Database Driver Class Initialized
INFO - 2020-08-13 18:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:24:54 --> Email Class Initialized
INFO - 2020-08-13 18:24:54 --> Controller Class Initialized
DEBUG - 2020-08-13 18:24:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:24:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:24:54 --> Model Class Initialized
INFO - 2020-08-13 18:24:54 --> Model Class Initialized
ERROR - 2020-08-13 18:24:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Dealer.php:289) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-13 18:24:54 --> Severity: Error --> Call to undefined method Dealer_model::client_update() /home/purpu1ex/public_html/carsm/application/controllers/Dealer.php 289
INFO - 2020-08-13 18:26:13 --> Config Class Initialized
INFO - 2020-08-13 18:26:13 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:26:13 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:26:13 --> Utf8 Class Initialized
INFO - 2020-08-13 18:26:13 --> URI Class Initialized
INFO - 2020-08-13 18:26:13 --> Router Class Initialized
INFO - 2020-08-13 18:26:13 --> Output Class Initialized
INFO - 2020-08-13 18:26:13 --> Security Class Initialized
DEBUG - 2020-08-13 18:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:26:13 --> Input Class Initialized
INFO - 2020-08-13 18:26:13 --> Language Class Initialized
INFO - 2020-08-13 18:26:13 --> Loader Class Initialized
INFO - 2020-08-13 18:26:13 --> Helper loaded: url_helper
INFO - 2020-08-13 18:26:13 --> Database Driver Class Initialized
INFO - 2020-08-13 18:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:26:13 --> Email Class Initialized
INFO - 2020-08-13 18:26:13 --> Controller Class Initialized
DEBUG - 2020-08-13 18:26:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:26:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:26:13 --> Model Class Initialized
INFO - 2020-08-13 18:26:13 --> Model Class Initialized
INFO - 2020-08-13 18:26:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 18:26:13 --> Final output sent to browser
DEBUG - 2020-08-13 18:26:13 --> Total execution time: 0.0262
INFO - 2020-08-13 18:26:16 --> Config Class Initialized
INFO - 2020-08-13 18:26:16 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:26:16 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:26:16 --> Utf8 Class Initialized
INFO - 2020-08-13 18:26:16 --> URI Class Initialized
INFO - 2020-08-13 18:26:16 --> Router Class Initialized
INFO - 2020-08-13 18:26:16 --> Output Class Initialized
INFO - 2020-08-13 18:26:16 --> Security Class Initialized
DEBUG - 2020-08-13 18:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:26:16 --> Input Class Initialized
INFO - 2020-08-13 18:26:16 --> Language Class Initialized
INFO - 2020-08-13 18:26:16 --> Loader Class Initialized
INFO - 2020-08-13 18:26:16 --> Helper loaded: url_helper
INFO - 2020-08-13 18:26:16 --> Database Driver Class Initialized
INFO - 2020-08-13 18:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:26:16 --> Email Class Initialized
INFO - 2020-08-13 18:26:16 --> Controller Class Initialized
DEBUG - 2020-08-13 18:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:26:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:26:16 --> Model Class Initialized
INFO - 2020-08-13 18:26:16 --> Model Class Initialized
INFO - 2020-08-13 18:26:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 18:26:16 --> Final output sent to browser
DEBUG - 2020-08-13 18:26:16 --> Total execution time: 0.0260
INFO - 2020-08-13 18:26:50 --> Config Class Initialized
INFO - 2020-08-13 18:26:50 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:26:50 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:26:50 --> Utf8 Class Initialized
INFO - 2020-08-13 18:26:50 --> URI Class Initialized
INFO - 2020-08-13 18:26:50 --> Router Class Initialized
INFO - 2020-08-13 18:26:50 --> Output Class Initialized
INFO - 2020-08-13 18:26:50 --> Security Class Initialized
DEBUG - 2020-08-13 18:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:26:50 --> Input Class Initialized
INFO - 2020-08-13 18:26:50 --> Language Class Initialized
INFO - 2020-08-13 18:26:50 --> Loader Class Initialized
INFO - 2020-08-13 18:26:50 --> Helper loaded: url_helper
INFO - 2020-08-13 18:26:50 --> Database Driver Class Initialized
INFO - 2020-08-13 18:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:26:50 --> Email Class Initialized
INFO - 2020-08-13 18:26:50 --> Controller Class Initialized
DEBUG - 2020-08-13 18:26:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:26:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:26:50 --> Model Class Initialized
INFO - 2020-08-13 18:26:50 --> Model Class Initialized
ERROR - 2020-08-13 18:26:50 --> Query error: Unknown column 'p_cl_address' in 'field list' - Invalid query: CALL client_details_update('sourav','patra','3','4','5',
        '6','7','8','','','','','',
        '','','','','',
        '','','','','',
        '','','','',
        '','','','',
        '1','2','',1)
INFO - 2020-08-13 18:26:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-08-13 18:27:40 --> Config Class Initialized
INFO - 2020-08-13 18:27:40 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:27:40 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:27:40 --> Utf8 Class Initialized
INFO - 2020-08-13 18:27:40 --> URI Class Initialized
INFO - 2020-08-13 18:27:40 --> Router Class Initialized
INFO - 2020-08-13 18:27:40 --> Output Class Initialized
INFO - 2020-08-13 18:27:40 --> Security Class Initialized
DEBUG - 2020-08-13 18:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:27:40 --> Input Class Initialized
INFO - 2020-08-13 18:27:40 --> Language Class Initialized
INFO - 2020-08-13 18:27:40 --> Loader Class Initialized
INFO - 2020-08-13 18:27:40 --> Helper loaded: url_helper
INFO - 2020-08-13 18:27:40 --> Database Driver Class Initialized
INFO - 2020-08-13 18:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:27:40 --> Email Class Initialized
INFO - 2020-08-13 18:27:40 --> Controller Class Initialized
DEBUG - 2020-08-13 18:27:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:27:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:27:40 --> Model Class Initialized
INFO - 2020-08-13 18:27:40 --> Model Class Initialized
INFO - 2020-08-13 18:27:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 18:27:40 --> Final output sent to browser
DEBUG - 2020-08-13 18:27:40 --> Total execution time: 0.0216
INFO - 2020-08-13 18:27:43 --> Config Class Initialized
INFO - 2020-08-13 18:27:43 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:27:43 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:27:43 --> Utf8 Class Initialized
INFO - 2020-08-13 18:27:43 --> URI Class Initialized
INFO - 2020-08-13 18:27:43 --> Router Class Initialized
INFO - 2020-08-13 18:27:43 --> Output Class Initialized
INFO - 2020-08-13 18:27:43 --> Security Class Initialized
DEBUG - 2020-08-13 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:27:43 --> Input Class Initialized
INFO - 2020-08-13 18:27:43 --> Language Class Initialized
INFO - 2020-08-13 18:27:43 --> Loader Class Initialized
INFO - 2020-08-13 18:27:43 --> Helper loaded: url_helper
INFO - 2020-08-13 18:27:43 --> Database Driver Class Initialized
INFO - 2020-08-13 18:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:27:43 --> Email Class Initialized
INFO - 2020-08-13 18:27:43 --> Controller Class Initialized
DEBUG - 2020-08-13 18:27:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:27:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:27:43 --> Model Class Initialized
INFO - 2020-08-13 18:27:43 --> Model Class Initialized
INFO - 2020-08-13 18:27:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 18:27:43 --> Final output sent to browser
DEBUG - 2020-08-13 18:27:43 --> Total execution time: 0.0256
INFO - 2020-08-13 18:27:52 --> Config Class Initialized
INFO - 2020-08-13 18:27:52 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:27:52 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:27:52 --> Utf8 Class Initialized
INFO - 2020-08-13 18:27:52 --> URI Class Initialized
INFO - 2020-08-13 18:27:52 --> Router Class Initialized
INFO - 2020-08-13 18:27:52 --> Output Class Initialized
INFO - 2020-08-13 18:27:52 --> Security Class Initialized
DEBUG - 2020-08-13 18:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:27:52 --> Input Class Initialized
INFO - 2020-08-13 18:27:52 --> Language Class Initialized
INFO - 2020-08-13 18:27:52 --> Loader Class Initialized
INFO - 2020-08-13 18:27:52 --> Helper loaded: url_helper
INFO - 2020-08-13 18:27:52 --> Database Driver Class Initialized
INFO - 2020-08-13 18:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:27:52 --> Email Class Initialized
INFO - 2020-08-13 18:27:52 --> Controller Class Initialized
DEBUG - 2020-08-13 18:27:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:27:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:27:52 --> Model Class Initialized
INFO - 2020-08-13 18:27:52 --> Model Class Initialized
INFO - 2020-08-13 18:27:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 18:27:52 --> Final output sent to browser
DEBUG - 2020-08-13 18:27:52 --> Total execution time: 0.0440
INFO - 2020-08-13 18:27:57 --> Config Class Initialized
INFO - 2020-08-13 18:27:57 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:27:57 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:27:57 --> Utf8 Class Initialized
INFO - 2020-08-13 18:27:57 --> URI Class Initialized
INFO - 2020-08-13 18:27:57 --> Router Class Initialized
INFO - 2020-08-13 18:27:57 --> Output Class Initialized
INFO - 2020-08-13 18:27:57 --> Security Class Initialized
DEBUG - 2020-08-13 18:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:27:57 --> Input Class Initialized
INFO - 2020-08-13 18:27:57 --> Language Class Initialized
INFO - 2020-08-13 18:27:57 --> Loader Class Initialized
INFO - 2020-08-13 18:27:57 --> Helper loaded: url_helper
INFO - 2020-08-13 18:27:57 --> Database Driver Class Initialized
INFO - 2020-08-13 18:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:27:57 --> Email Class Initialized
INFO - 2020-08-13 18:27:57 --> Controller Class Initialized
DEBUG - 2020-08-13 18:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:27:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:27:57 --> Model Class Initialized
INFO - 2020-08-13 18:27:57 --> Model Class Initialized
INFO - 2020-08-13 18:27:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 18:27:58 --> Final output sent to browser
DEBUG - 2020-08-13 18:27:58 --> Total execution time: 0.3243
INFO - 2020-08-13 18:30:24 --> Config Class Initialized
INFO - 2020-08-13 18:30:24 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:30:24 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:30:24 --> Utf8 Class Initialized
INFO - 2020-08-13 18:30:24 --> URI Class Initialized
INFO - 2020-08-13 18:30:24 --> Router Class Initialized
INFO - 2020-08-13 18:30:24 --> Output Class Initialized
INFO - 2020-08-13 18:30:24 --> Security Class Initialized
DEBUG - 2020-08-13 18:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:30:24 --> Input Class Initialized
INFO - 2020-08-13 18:30:24 --> Language Class Initialized
INFO - 2020-08-13 18:30:24 --> Loader Class Initialized
INFO - 2020-08-13 18:30:24 --> Helper loaded: url_helper
INFO - 2020-08-13 18:30:24 --> Database Driver Class Initialized
INFO - 2020-08-13 18:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:30:24 --> Email Class Initialized
INFO - 2020-08-13 18:30:24 --> Controller Class Initialized
DEBUG - 2020-08-13 18:30:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:30:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:30:24 --> Model Class Initialized
INFO - 2020-08-13 18:30:24 --> Model Class Initialized
INFO - 2020-08-13 18:30:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 18:30:24 --> Final output sent to browser
DEBUG - 2020-08-13 18:30:24 --> Total execution time: 0.0272
INFO - 2020-08-13 18:30:28 --> Config Class Initialized
INFO - 2020-08-13 18:30:28 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:30:28 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:30:28 --> Utf8 Class Initialized
INFO - 2020-08-13 18:30:28 --> URI Class Initialized
INFO - 2020-08-13 18:30:28 --> Router Class Initialized
INFO - 2020-08-13 18:30:28 --> Output Class Initialized
INFO - 2020-08-13 18:30:28 --> Security Class Initialized
DEBUG - 2020-08-13 18:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:30:28 --> Input Class Initialized
INFO - 2020-08-13 18:30:28 --> Language Class Initialized
INFO - 2020-08-13 18:30:28 --> Loader Class Initialized
INFO - 2020-08-13 18:30:28 --> Helper loaded: url_helper
INFO - 2020-08-13 18:30:28 --> Database Driver Class Initialized
INFO - 2020-08-13 18:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:30:28 --> Email Class Initialized
INFO - 2020-08-13 18:30:28 --> Controller Class Initialized
DEBUG - 2020-08-13 18:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:30:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:30:28 --> Model Class Initialized
INFO - 2020-08-13 18:30:28 --> Model Class Initialized
INFO - 2020-08-13 18:30:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-13 18:30:28 --> Final output sent to browser
DEBUG - 2020-08-13 18:30:28 --> Total execution time: 0.0234
INFO - 2020-08-13 18:30:39 --> Config Class Initialized
INFO - 2020-08-13 18:30:39 --> Hooks Class Initialized
DEBUG - 2020-08-13 18:30:39 --> UTF-8 Support Enabled
INFO - 2020-08-13 18:30:39 --> Utf8 Class Initialized
INFO - 2020-08-13 18:30:39 --> URI Class Initialized
INFO - 2020-08-13 18:30:39 --> Router Class Initialized
INFO - 2020-08-13 18:30:39 --> Output Class Initialized
INFO - 2020-08-13 18:30:39 --> Security Class Initialized
DEBUG - 2020-08-13 18:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 18:30:39 --> Input Class Initialized
INFO - 2020-08-13 18:30:39 --> Language Class Initialized
INFO - 2020-08-13 18:30:39 --> Loader Class Initialized
INFO - 2020-08-13 18:30:39 --> Helper loaded: url_helper
INFO - 2020-08-13 18:30:39 --> Database Driver Class Initialized
INFO - 2020-08-13 18:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 18:30:39 --> Email Class Initialized
INFO - 2020-08-13 18:30:39 --> Controller Class Initialized
DEBUG - 2020-08-13 18:30:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 18:30:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 18:30:39 --> Model Class Initialized
INFO - 2020-08-13 18:30:39 --> Model Class Initialized
INFO - 2020-08-13 18:30:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-13 18:30:39 --> Final output sent to browser
DEBUG - 2020-08-13 18:30:39 --> Total execution time: 0.0212
INFO - 2020-08-13 20:32:48 --> Config Class Initialized
INFO - 2020-08-13 20:32:48 --> Hooks Class Initialized
DEBUG - 2020-08-13 20:32:48 --> UTF-8 Support Enabled
INFO - 2020-08-13 20:32:48 --> Utf8 Class Initialized
INFO - 2020-08-13 20:32:48 --> URI Class Initialized
DEBUG - 2020-08-13 20:32:48 --> No URI present. Default controller set.
INFO - 2020-08-13 20:32:48 --> Router Class Initialized
INFO - 2020-08-13 20:32:48 --> Output Class Initialized
INFO - 2020-08-13 20:32:48 --> Security Class Initialized
DEBUG - 2020-08-13 20:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 20:32:48 --> Input Class Initialized
INFO - 2020-08-13 20:32:48 --> Language Class Initialized
INFO - 2020-08-13 20:32:48 --> Loader Class Initialized
INFO - 2020-08-13 20:32:48 --> Helper loaded: url_helper
INFO - 2020-08-13 20:32:48 --> Database Driver Class Initialized
INFO - 2020-08-13 20:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 20:32:48 --> Email Class Initialized
INFO - 2020-08-13 20:32:48 --> Controller Class Initialized
INFO - 2020-08-13 20:32:48 --> Model Class Initialized
INFO - 2020-08-13 20:32:48 --> Model Class Initialized
DEBUG - 2020-08-13 20:32:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 20:32:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 20:32:48 --> Final output sent to browser
DEBUG - 2020-08-13 20:32:48 --> Total execution time: 0.0452
INFO - 2020-08-13 20:33:06 --> Config Class Initialized
INFO - 2020-08-13 20:33:06 --> Hooks Class Initialized
DEBUG - 2020-08-13 20:33:06 --> UTF-8 Support Enabled
INFO - 2020-08-13 20:33:06 --> Utf8 Class Initialized
INFO - 2020-08-13 20:33:06 --> URI Class Initialized
INFO - 2020-08-13 20:33:06 --> Router Class Initialized
INFO - 2020-08-13 20:33:06 --> Output Class Initialized
INFO - 2020-08-13 20:33:06 --> Security Class Initialized
INFO - 2020-08-13 20:33:06 --> Config Class Initialized
INFO - 2020-08-13 20:33:06 --> Hooks Class Initialized
DEBUG - 2020-08-13 20:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 20:33:06 --> Input Class Initialized
INFO - 2020-08-13 20:33:06 --> Language Class Initialized
DEBUG - 2020-08-13 20:33:06 --> UTF-8 Support Enabled
INFO - 2020-08-13 20:33:06 --> Utf8 Class Initialized
INFO - 2020-08-13 20:33:06 --> URI Class Initialized
INFO - 2020-08-13 20:33:06 --> Loader Class Initialized
INFO - 2020-08-13 20:33:06 --> Router Class Initialized
INFO - 2020-08-13 20:33:06 --> Helper loaded: url_helper
INFO - 2020-08-13 20:33:06 --> Output Class Initialized
INFO - 2020-08-13 20:33:06 --> Security Class Initialized
DEBUG - 2020-08-13 20:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 20:33:06 --> Input Class Initialized
INFO - 2020-08-13 20:33:06 --> Language Class Initialized
INFO - 2020-08-13 20:33:06 --> Loader Class Initialized
INFO - 2020-08-13 20:33:06 --> Database Driver Class Initialized
INFO - 2020-08-13 20:33:06 --> Helper loaded: url_helper
INFO - 2020-08-13 20:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 20:33:06 --> Email Class Initialized
INFO - 2020-08-13 20:33:06 --> Controller Class Initialized
INFO - 2020-08-13 20:33:06 --> Model Class Initialized
INFO - 2020-08-13 20:33:06 --> Database Driver Class Initialized
INFO - 2020-08-13 20:33:06 --> Model Class Initialized
DEBUG - 2020-08-13 20:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 20:33:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 20:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 20:33:06 --> Email Class Initialized
INFO - 2020-08-13 20:33:06 --> Controller Class Initialized
INFO - 2020-08-13 20:33:06 --> Model Class Initialized
INFO - 2020-08-13 20:33:06 --> Model Class Initialized
DEBUG - 2020-08-13 20:33:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 20:33:07 --> Config Class Initialized
INFO - 2020-08-13 20:33:07 --> Hooks Class Initialized
DEBUG - 2020-08-13 20:33:07 --> UTF-8 Support Enabled
INFO - 2020-08-13 20:33:07 --> Utf8 Class Initialized
INFO - 2020-08-13 20:33:07 --> URI Class Initialized
DEBUG - 2020-08-13 20:33:07 --> No URI present. Default controller set.
INFO - 2020-08-13 20:33:07 --> Router Class Initialized
INFO - 2020-08-13 20:33:07 --> Output Class Initialized
INFO - 2020-08-13 20:33:07 --> Security Class Initialized
DEBUG - 2020-08-13 20:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 20:33:07 --> Input Class Initialized
INFO - 2020-08-13 20:33:07 --> Language Class Initialized
INFO - 2020-08-13 20:33:07 --> Loader Class Initialized
INFO - 2020-08-13 20:33:07 --> Helper loaded: url_helper
INFO - 2020-08-13 20:33:07 --> Database Driver Class Initialized
INFO - 2020-08-13 20:33:07 --> Config Class Initialized
INFO - 2020-08-13 20:33:07 --> Hooks Class Initialized
INFO - 2020-08-13 20:33:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-13 20:33:07 --> UTF-8 Support Enabled
INFO - 2020-08-13 20:33:07 --> Utf8 Class Initialized
INFO - 2020-08-13 20:33:07 --> URI Class Initialized
INFO - 2020-08-13 20:33:07 --> Email Class Initialized
INFO - 2020-08-13 20:33:07 --> Controller Class Initialized
INFO - 2020-08-13 20:33:07 --> Router Class Initialized
INFO - 2020-08-13 20:33:07 --> Model Class Initialized
INFO - 2020-08-13 20:33:07 --> Model Class Initialized
DEBUG - 2020-08-13 20:33:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-13 20:33:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-13 20:33:07 --> Output Class Initialized
INFO - 2020-08-13 20:33:07 --> Final output sent to browser
DEBUG - 2020-08-13 20:33:07 --> Total execution time: 0.0220
INFO - 2020-08-13 20:33:07 --> Security Class Initialized
DEBUG - 2020-08-13 20:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 20:33:07 --> Input Class Initialized
INFO - 2020-08-13 20:33:07 --> Language Class Initialized
INFO - 2020-08-13 20:33:07 --> Loader Class Initialized
INFO - 2020-08-13 20:33:07 --> Helper loaded: url_helper
INFO - 2020-08-13 20:33:07 --> Database Driver Class Initialized
INFO - 2020-08-13 20:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 20:33:07 --> Email Class Initialized
INFO - 2020-08-13 20:33:07 --> Controller Class Initialized
DEBUG - 2020-08-13 20:33:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 20:33:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 20:33:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-13 20:33:07 --> Final output sent to browser
DEBUG - 2020-08-13 20:33:07 --> Total execution time: 0.0497
INFO - 2020-08-13 20:33:15 --> Config Class Initialized
INFO - 2020-08-13 20:33:15 --> Hooks Class Initialized
DEBUG - 2020-08-13 20:33:15 --> UTF-8 Support Enabled
INFO - 2020-08-13 20:33:15 --> Utf8 Class Initialized
INFO - 2020-08-13 20:33:15 --> URI Class Initialized
INFO - 2020-08-13 20:33:15 --> Router Class Initialized
INFO - 2020-08-13 20:33:15 --> Output Class Initialized
INFO - 2020-08-13 20:33:15 --> Security Class Initialized
DEBUG - 2020-08-13 20:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-13 20:33:15 --> Input Class Initialized
INFO - 2020-08-13 20:33:15 --> Language Class Initialized
INFO - 2020-08-13 20:33:15 --> Loader Class Initialized
INFO - 2020-08-13 20:33:15 --> Helper loaded: url_helper
INFO - 2020-08-13 20:33:15 --> Database Driver Class Initialized
INFO - 2020-08-13 20:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-13 20:33:15 --> Email Class Initialized
INFO - 2020-08-13 20:33:15 --> Controller Class Initialized
DEBUG - 2020-08-13 20:33:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-13 20:33:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-13 20:33:15 --> Model Class Initialized
INFO - 2020-08-13 20:33:15 --> Model Class Initialized
INFO - 2020-08-13 20:33:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-13 20:33:15 --> Final output sent to browser
DEBUG - 2020-08-13 20:33:15 --> Total execution time: 0.0307
