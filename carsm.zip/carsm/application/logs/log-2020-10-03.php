<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-03 15:56:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-03 15:56:19 --> Config Class Initialized
INFO - 2020-10-03 15:56:19 --> Hooks Class Initialized
DEBUG - 2020-10-03 15:56:19 --> UTF-8 Support Enabled
INFO - 2020-10-03 15:56:19 --> Utf8 Class Initialized
INFO - 2020-10-03 15:56:19 --> URI Class Initialized
DEBUG - 2020-10-03 15:56:20 --> No URI present. Default controller set.
INFO - 2020-10-03 15:56:20 --> Router Class Initialized
INFO - 2020-10-03 15:56:20 --> Output Class Initialized
INFO - 2020-10-03 15:56:20 --> Security Class Initialized
DEBUG - 2020-10-03 15:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-03 15:56:20 --> Input Class Initialized
INFO - 2020-10-03 15:56:20 --> Language Class Initialized
INFO - 2020-10-03 15:56:20 --> Loader Class Initialized
INFO - 2020-10-03 15:56:20 --> Helper loaded: url_helper
INFO - 2020-10-03 15:56:20 --> Database Driver Class Initialized
INFO - 2020-10-03 15:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-03 15:56:20 --> Email Class Initialized
INFO - 2020-10-03 15:56:20 --> Controller Class Initialized
INFO - 2020-10-03 15:56:20 --> Model Class Initialized
INFO - 2020-10-03 15:56:20 --> Model Class Initialized
DEBUG - 2020-10-03 15:56:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-03 15:56:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-03 15:56:20 --> Final output sent to browser
DEBUG - 2020-10-03 15:56:20 --> Total execution time: 0.1561
