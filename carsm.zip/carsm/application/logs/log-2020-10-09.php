<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-09 06:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:20:16 --> Config Class Initialized
INFO - 2020-10-09 06:20:16 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:20:16 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:20:16 --> Utf8 Class Initialized
INFO - 2020-10-09 06:20:16 --> URI Class Initialized
DEBUG - 2020-10-09 06:20:16 --> No URI present. Default controller set.
INFO - 2020-10-09 06:20:16 --> Router Class Initialized
INFO - 2020-10-09 06:20:16 --> Output Class Initialized
INFO - 2020-10-09 06:20:16 --> Security Class Initialized
DEBUG - 2020-10-09 06:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:20:16 --> Input Class Initialized
INFO - 2020-10-09 06:20:16 --> Language Class Initialized
INFO - 2020-10-09 06:20:16 --> Loader Class Initialized
INFO - 2020-10-09 06:20:16 --> Helper loaded: url_helper
INFO - 2020-10-09 06:20:16 --> Database Driver Class Initialized
INFO - 2020-10-09 06:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:20:16 --> Email Class Initialized
INFO - 2020-10-09 06:20:16 --> Controller Class Initialized
INFO - 2020-10-09 06:20:16 --> Model Class Initialized
INFO - 2020-10-09 06:20:16 --> Model Class Initialized
DEBUG - 2020-10-09 06:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:20:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:20:16 --> Final output sent to browser
DEBUG - 2020-10-09 06:20:16 --> Total execution time: 0.1305
ERROR - 2020-10-09 06:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:12 --> Config Class Initialized
INFO - 2020-10-09 06:21:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:12 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:12 --> URI Class Initialized
INFO - 2020-10-09 06:21:12 --> Router Class Initialized
INFO - 2020-10-09 06:21:12 --> Output Class Initialized
INFO - 2020-10-09 06:21:12 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:12 --> Input Class Initialized
INFO - 2020-10-09 06:21:12 --> Language Class Initialized
INFO - 2020-10-09 06:21:12 --> Loader Class Initialized
INFO - 2020-10-09 06:21:12 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:12 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:12 --> Email Class Initialized
INFO - 2020-10-09 06:21:12 --> Controller Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:21:12 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:12 --> Config Class Initialized
INFO - 2020-10-09 06:21:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:12 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:12 --> URI Class Initialized
INFO - 2020-10-09 06:21:12 --> Router Class Initialized
INFO - 2020-10-09 06:21:12 --> Output Class Initialized
INFO - 2020-10-09 06:21:12 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:12 --> Input Class Initialized
INFO - 2020-10-09 06:21:12 --> Language Class Initialized
INFO - 2020-10-09 06:21:12 --> Loader Class Initialized
INFO - 2020-10-09 06:21:12 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:12 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:12 --> Email Class Initialized
INFO - 2020-10-09 06:21:12 --> Controller Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:12 --> Config Class Initialized
INFO - 2020-10-09 06:21:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:12 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:12 --> URI Class Initialized
DEBUG - 2020-10-09 06:21:12 --> No URI present. Default controller set.
INFO - 2020-10-09 06:21:12 --> Router Class Initialized
INFO - 2020-10-09 06:21:12 --> Output Class Initialized
INFO - 2020-10-09 06:21:12 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:12 --> Input Class Initialized
INFO - 2020-10-09 06:21:12 --> Language Class Initialized
INFO - 2020-10-09 06:21:12 --> Loader Class Initialized
INFO - 2020-10-09 06:21:12 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:12 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:12 --> Email Class Initialized
INFO - 2020-10-09 06:21:12 --> Controller Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:21:12 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:12 --> Total execution time: 0.0190
ERROR - 2020-10-09 06:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:12 --> Config Class Initialized
INFO - 2020-10-09 06:21:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:12 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:12 --> URI Class Initialized
INFO - 2020-10-09 06:21:12 --> Router Class Initialized
INFO - 2020-10-09 06:21:12 --> Output Class Initialized
INFO - 2020-10-09 06:21:12 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:12 --> Input Class Initialized
INFO - 2020-10-09 06:21:12 --> Language Class Initialized
INFO - 2020-10-09 06:21:12 --> Loader Class Initialized
INFO - 2020-10-09 06:21:12 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:12 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:12 --> Email Class Initialized
INFO - 2020-10-09 06:21:12 --> Controller Class Initialized
DEBUG - 2020-10-09 06:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:21:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
INFO - 2020-10-09 06:21:12 --> Model Class Initialized
INFO - 2020-10-09 06:21:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 06:21:12 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:12 --> Total execution time: 0.0651
ERROR - 2020-10-09 06:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:20 --> Config Class Initialized
INFO - 2020-10-09 06:21:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:20 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:20 --> URI Class Initialized
INFO - 2020-10-09 06:21:20 --> Router Class Initialized
INFO - 2020-10-09 06:21:20 --> Output Class Initialized
INFO - 2020-10-09 06:21:20 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:20 --> Input Class Initialized
INFO - 2020-10-09 06:21:20 --> Language Class Initialized
INFO - 2020-10-09 06:21:20 --> Loader Class Initialized
INFO - 2020-10-09 06:21:20 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:20 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:20 --> Email Class Initialized
INFO - 2020-10-09 06:21:20 --> Controller Class Initialized
DEBUG - 2020-10-09 06:21:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:21:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:20 --> Model Class Initialized
INFO - 2020-10-09 06:21:20 --> Model Class Initialized
INFO - 2020-10-09 06:21:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-09 06:21:20 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:20 --> Total execution time: 0.0284
ERROR - 2020-10-09 06:21:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:31 --> Config Class Initialized
INFO - 2020-10-09 06:21:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:31 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:31 --> URI Class Initialized
INFO - 2020-10-09 06:21:31 --> Router Class Initialized
INFO - 2020-10-09 06:21:31 --> Output Class Initialized
INFO - 2020-10-09 06:21:31 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:31 --> Input Class Initialized
INFO - 2020-10-09 06:21:31 --> Language Class Initialized
INFO - 2020-10-09 06:21:31 --> Loader Class Initialized
INFO - 2020-10-09 06:21:31 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:31 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:31 --> Email Class Initialized
INFO - 2020-10-09 06:21:31 --> Controller Class Initialized
DEBUG - 2020-10-09 06:21:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:21:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:31 --> Model Class Initialized
INFO - 2020-10-09 06:21:31 --> Model Class Initialized
INFO - 2020-10-09 06:21:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 06:21:31 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:31 --> Total execution time: 0.0545
ERROR - 2020-10-09 06:21:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:40 --> Config Class Initialized
INFO - 2020-10-09 06:21:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:40 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:40 --> URI Class Initialized
DEBUG - 2020-10-09 06:21:40 --> No URI present. Default controller set.
INFO - 2020-10-09 06:21:40 --> Router Class Initialized
INFO - 2020-10-09 06:21:40 --> Output Class Initialized
INFO - 2020-10-09 06:21:40 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:40 --> Input Class Initialized
INFO - 2020-10-09 06:21:40 --> Language Class Initialized
INFO - 2020-10-09 06:21:40 --> Loader Class Initialized
INFO - 2020-10-09 06:21:40 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:40 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:40 --> Email Class Initialized
INFO - 2020-10-09 06:21:40 --> Controller Class Initialized
INFO - 2020-10-09 06:21:40 --> Model Class Initialized
INFO - 2020-10-09 06:21:40 --> Model Class Initialized
DEBUG - 2020-10-09 06:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:21:40 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:40 --> Total execution time: 0.0195
ERROR - 2020-10-09 06:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:53 --> Config Class Initialized
INFO - 2020-10-09 06:21:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:53 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:53 --> URI Class Initialized
INFO - 2020-10-09 06:21:53 --> Router Class Initialized
INFO - 2020-10-09 06:21:53 --> Output Class Initialized
INFO - 2020-10-09 06:21:53 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:53 --> Input Class Initialized
INFO - 2020-10-09 06:21:53 --> Language Class Initialized
INFO - 2020-10-09 06:21:53 --> Loader Class Initialized
INFO - 2020-10-09 06:21:53 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:53 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:53 --> Email Class Initialized
INFO - 2020-10-09 06:21:53 --> Controller Class Initialized
INFO - 2020-10-09 06:21:53 --> Model Class Initialized
INFO - 2020-10-09 06:21:53 --> Model Class Initialized
DEBUG - 2020-10-09 06:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:21:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:53 --> Model Class Initialized
INFO - 2020-10-09 06:21:53 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:53 --> Total execution time: 0.0233
ERROR - 2020-10-09 06:21:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:53 --> Config Class Initialized
INFO - 2020-10-09 06:21:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:53 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:53 --> URI Class Initialized
INFO - 2020-10-09 06:21:53 --> Router Class Initialized
INFO - 2020-10-09 06:21:53 --> Output Class Initialized
INFO - 2020-10-09 06:21:53 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:53 --> Input Class Initialized
INFO - 2020-10-09 06:21:53 --> Language Class Initialized
INFO - 2020-10-09 06:21:53 --> Loader Class Initialized
INFO - 2020-10-09 06:21:53 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:53 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:53 --> Email Class Initialized
INFO - 2020-10-09 06:21:53 --> Controller Class Initialized
INFO - 2020-10-09 06:21:53 --> Model Class Initialized
INFO - 2020-10-09 06:21:53 --> Model Class Initialized
DEBUG - 2020-10-09 06:21:53 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:21:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:21:54 --> Config Class Initialized
INFO - 2020-10-09 06:21:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:21:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:21:54 --> Utf8 Class Initialized
INFO - 2020-10-09 06:21:54 --> URI Class Initialized
INFO - 2020-10-09 06:21:54 --> Router Class Initialized
INFO - 2020-10-09 06:21:54 --> Output Class Initialized
INFO - 2020-10-09 06:21:54 --> Security Class Initialized
DEBUG - 2020-10-09 06:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:21:54 --> Input Class Initialized
INFO - 2020-10-09 06:21:54 --> Language Class Initialized
INFO - 2020-10-09 06:21:54 --> Loader Class Initialized
INFO - 2020-10-09 06:21:54 --> Helper loaded: url_helper
INFO - 2020-10-09 06:21:54 --> Database Driver Class Initialized
INFO - 2020-10-09 06:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:21:54 --> Email Class Initialized
INFO - 2020-10-09 06:21:54 --> Controller Class Initialized
DEBUG - 2020-10-09 06:21:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:21:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:21:54 --> Model Class Initialized
INFO - 2020-10-09 06:21:54 --> Model Class Initialized
INFO - 2020-10-09 06:21:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-09 06:21:54 --> Final output sent to browser
DEBUG - 2020-10-09 06:21:54 --> Total execution time: 0.0632
ERROR - 2020-10-09 06:22:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:22:51 --> Config Class Initialized
INFO - 2020-10-09 06:22:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:22:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:22:51 --> Utf8 Class Initialized
INFO - 2020-10-09 06:22:51 --> URI Class Initialized
INFO - 2020-10-09 06:22:51 --> Router Class Initialized
INFO - 2020-10-09 06:22:51 --> Output Class Initialized
INFO - 2020-10-09 06:22:51 --> Security Class Initialized
DEBUG - 2020-10-09 06:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:22:51 --> Input Class Initialized
INFO - 2020-10-09 06:22:51 --> Language Class Initialized
INFO - 2020-10-09 06:22:51 --> Loader Class Initialized
INFO - 2020-10-09 06:22:51 --> Helper loaded: url_helper
INFO - 2020-10-09 06:22:51 --> Database Driver Class Initialized
INFO - 2020-10-09 06:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:22:51 --> Email Class Initialized
INFO - 2020-10-09 06:22:51 --> Controller Class Initialized
DEBUG - 2020-10-09 06:22:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:22:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:22:51 --> Model Class Initialized
INFO - 2020-10-09 06:22:51 --> Model Class Initialized
INFO - 2020-10-09 06:22:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-09 06:22:51 --> Final output sent to browser
DEBUG - 2020-10-09 06:22:51 --> Total execution time: 0.0345
ERROR - 2020-10-09 06:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:41:54 --> Config Class Initialized
INFO - 2020-10-09 06:41:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:41:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:41:54 --> Utf8 Class Initialized
INFO - 2020-10-09 06:41:54 --> URI Class Initialized
INFO - 2020-10-09 06:41:54 --> Router Class Initialized
INFO - 2020-10-09 06:41:54 --> Output Class Initialized
INFO - 2020-10-09 06:41:54 --> Security Class Initialized
DEBUG - 2020-10-09 06:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:41:54 --> Input Class Initialized
INFO - 2020-10-09 06:41:54 --> Language Class Initialized
INFO - 2020-10-09 06:41:54 --> Loader Class Initialized
INFO - 2020-10-09 06:41:54 --> Helper loaded: url_helper
INFO - 2020-10-09 06:41:54 --> Database Driver Class Initialized
INFO - 2020-10-09 06:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:41:54 --> Email Class Initialized
INFO - 2020-10-09 06:41:54 --> Controller Class Initialized
DEBUG - 2020-10-09 06:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:41:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:41:54 --> Model Class Initialized
INFO - 2020-10-09 06:41:54 --> Model Class Initialized
INFO - 2020-10-09 06:41:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-09 06:41:54 --> Final output sent to browser
DEBUG - 2020-10-09 06:41:54 --> Total execution time: 0.0259
ERROR - 2020-10-09 06:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:43:04 --> Config Class Initialized
INFO - 2020-10-09 06:43:04 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:43:04 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:43:04 --> Utf8 Class Initialized
INFO - 2020-10-09 06:43:04 --> URI Class Initialized
INFO - 2020-10-09 06:43:04 --> Router Class Initialized
INFO - 2020-10-09 06:43:04 --> Output Class Initialized
INFO - 2020-10-09 06:43:04 --> Security Class Initialized
DEBUG - 2020-10-09 06:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:43:04 --> Input Class Initialized
INFO - 2020-10-09 06:43:04 --> Language Class Initialized
INFO - 2020-10-09 06:43:04 --> Loader Class Initialized
INFO - 2020-10-09 06:43:04 --> Helper loaded: url_helper
INFO - 2020-10-09 06:43:05 --> Database Driver Class Initialized
INFO - 2020-10-09 06:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:43:05 --> Email Class Initialized
INFO - 2020-10-09 06:43:05 --> Controller Class Initialized
DEBUG - 2020-10-09 06:43:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:43:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:43:05 --> Model Class Initialized
INFO - 2020-10-09 06:43:05 --> Model Class Initialized
INFO - 2020-10-09 06:43:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-09 06:43:05 --> Final output sent to browser
DEBUG - 2020-10-09 06:43:05 --> Total execution time: 0.0219
ERROR - 2020-10-09 06:43:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:43:57 --> Config Class Initialized
INFO - 2020-10-09 06:43:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:43:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:43:57 --> Utf8 Class Initialized
INFO - 2020-10-09 06:43:57 --> URI Class Initialized
INFO - 2020-10-09 06:43:57 --> Router Class Initialized
INFO - 2020-10-09 06:43:57 --> Output Class Initialized
INFO - 2020-10-09 06:43:57 --> Security Class Initialized
DEBUG - 2020-10-09 06:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:43:57 --> Input Class Initialized
INFO - 2020-10-09 06:43:57 --> Language Class Initialized
INFO - 2020-10-09 06:43:57 --> Loader Class Initialized
INFO - 2020-10-09 06:43:57 --> Helper loaded: url_helper
INFO - 2020-10-09 06:43:57 --> Database Driver Class Initialized
INFO - 2020-10-09 06:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:43:57 --> Email Class Initialized
INFO - 2020-10-09 06:43:57 --> Controller Class Initialized
DEBUG - 2020-10-09 06:43:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:43:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:43:57 --> Model Class Initialized
INFO - 2020-10-09 06:43:57 --> Model Class Initialized
INFO - 2020-10-09 06:43:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-09 06:43:58 --> Final output sent to browser
DEBUG - 2020-10-09 06:43:58 --> Total execution time: 0.0366
ERROR - 2020-10-09 06:43:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:43:59 --> Config Class Initialized
INFO - 2020-10-09 06:43:59 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:43:59 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:43:59 --> Utf8 Class Initialized
INFO - 2020-10-09 06:43:59 --> URI Class Initialized
INFO - 2020-10-09 06:43:59 --> Router Class Initialized
INFO - 2020-10-09 06:43:59 --> Output Class Initialized
INFO - 2020-10-09 06:43:59 --> Security Class Initialized
DEBUG - 2020-10-09 06:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:43:59 --> Input Class Initialized
INFO - 2020-10-09 06:43:59 --> Language Class Initialized
INFO - 2020-10-09 06:43:59 --> Loader Class Initialized
INFO - 2020-10-09 06:43:59 --> Helper loaded: url_helper
INFO - 2020-10-09 06:43:59 --> Database Driver Class Initialized
INFO - 2020-10-09 06:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:43:59 --> Email Class Initialized
INFO - 2020-10-09 06:43:59 --> Controller Class Initialized
DEBUG - 2020-10-09 06:43:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:43:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:43:59 --> Model Class Initialized
INFO - 2020-10-09 06:43:59 --> Model Class Initialized
INFO - 2020-10-09 06:43:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-09 06:43:59 --> Final output sent to browser
DEBUG - 2020-10-09 06:43:59 --> Total execution time: 0.0327
ERROR - 2020-10-09 06:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:44:00 --> Config Class Initialized
INFO - 2020-10-09 06:44:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:44:00 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:44:00 --> Utf8 Class Initialized
INFO - 2020-10-09 06:44:00 --> URI Class Initialized
INFO - 2020-10-09 06:44:00 --> Router Class Initialized
INFO - 2020-10-09 06:44:00 --> Output Class Initialized
INFO - 2020-10-09 06:44:00 --> Security Class Initialized
DEBUG - 2020-10-09 06:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:44:00 --> Input Class Initialized
INFO - 2020-10-09 06:44:00 --> Language Class Initialized
ERROR - 2020-10-09 06:44:00 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-09 06:44:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:44:48 --> Config Class Initialized
INFO - 2020-10-09 06:44:48 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:44:48 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:44:48 --> Utf8 Class Initialized
INFO - 2020-10-09 06:44:48 --> URI Class Initialized
INFO - 2020-10-09 06:44:48 --> Router Class Initialized
INFO - 2020-10-09 06:44:48 --> Output Class Initialized
INFO - 2020-10-09 06:44:48 --> Security Class Initialized
DEBUG - 2020-10-09 06:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:44:48 --> Input Class Initialized
INFO - 2020-10-09 06:44:48 --> Language Class Initialized
INFO - 2020-10-09 06:44:48 --> Loader Class Initialized
INFO - 2020-10-09 06:44:48 --> Helper loaded: url_helper
INFO - 2020-10-09 06:44:48 --> Database Driver Class Initialized
INFO - 2020-10-09 06:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:44:48 --> Email Class Initialized
INFO - 2020-10-09 06:44:48 --> Controller Class Initialized
DEBUG - 2020-10-09 06:44:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:44:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:44:48 --> Model Class Initialized
INFO - 2020-10-09 06:44:48 --> Model Class Initialized
INFO - 2020-10-09 06:44:48 --> Final output sent to browser
DEBUG - 2020-10-09 06:44:48 --> Total execution time: 0.0257
ERROR - 2020-10-09 06:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:45:29 --> Config Class Initialized
INFO - 2020-10-09 06:45:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:45:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:45:29 --> Utf8 Class Initialized
INFO - 2020-10-09 06:45:29 --> URI Class Initialized
INFO - 2020-10-09 06:45:29 --> Router Class Initialized
INFO - 2020-10-09 06:45:29 --> Output Class Initialized
INFO - 2020-10-09 06:45:29 --> Security Class Initialized
DEBUG - 2020-10-09 06:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:45:29 --> Input Class Initialized
INFO - 2020-10-09 06:45:29 --> Language Class Initialized
INFO - 2020-10-09 06:45:29 --> Loader Class Initialized
INFO - 2020-10-09 06:45:29 --> Helper loaded: url_helper
INFO - 2020-10-09 06:45:29 --> Database Driver Class Initialized
INFO - 2020-10-09 06:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:45:29 --> Email Class Initialized
INFO - 2020-10-09 06:45:29 --> Controller Class Initialized
DEBUG - 2020-10-09 06:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:45:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:45:29 --> Model Class Initialized
INFO - 2020-10-09 06:45:29 --> Model Class Initialized
INFO - 2020-10-09 06:45:29 --> Model Class Initialized
INFO - 2020-10-09 06:45:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-09 06:45:29 --> Final output sent to browser
DEBUG - 2020-10-09 06:45:29 --> Total execution time: 0.1045
ERROR - 2020-10-09 06:45:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:45:53 --> Config Class Initialized
INFO - 2020-10-09 06:45:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:45:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:45:53 --> Utf8 Class Initialized
INFO - 2020-10-09 06:45:53 --> URI Class Initialized
INFO - 2020-10-09 06:45:53 --> Router Class Initialized
INFO - 2020-10-09 06:45:53 --> Output Class Initialized
INFO - 2020-10-09 06:45:53 --> Security Class Initialized
DEBUG - 2020-10-09 06:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:45:53 --> Input Class Initialized
INFO - 2020-10-09 06:45:53 --> Language Class Initialized
INFO - 2020-10-09 06:45:53 --> Loader Class Initialized
INFO - 2020-10-09 06:45:53 --> Helper loaded: url_helper
INFO - 2020-10-09 06:45:53 --> Database Driver Class Initialized
INFO - 2020-10-09 06:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:45:53 --> Email Class Initialized
INFO - 2020-10-09 06:45:53 --> Controller Class Initialized
INFO - 2020-10-09 06:45:53 --> Model Class Initialized
INFO - 2020-10-09 06:45:53 --> Model Class Initialized
DEBUG - 2020-10-09 06:45:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:45:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:45:53 --> Model Class Initialized
INFO - 2020-10-09 06:45:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-10-09 06:45:53 --> Final output sent to browser
DEBUG - 2020-10-09 06:45:53 --> Total execution time: 0.0334
ERROR - 2020-10-09 06:46:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:46:14 --> Config Class Initialized
INFO - 2020-10-09 06:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:46:14 --> Utf8 Class Initialized
INFO - 2020-10-09 06:46:14 --> URI Class Initialized
INFO - 2020-10-09 06:46:14 --> Router Class Initialized
INFO - 2020-10-09 06:46:14 --> Output Class Initialized
INFO - 2020-10-09 06:46:14 --> Security Class Initialized
DEBUG - 2020-10-09 06:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:46:14 --> Input Class Initialized
INFO - 2020-10-09 06:46:14 --> Language Class Initialized
INFO - 2020-10-09 06:46:14 --> Loader Class Initialized
INFO - 2020-10-09 06:46:14 --> Helper loaded: url_helper
INFO - 2020-10-09 06:46:14 --> Database Driver Class Initialized
INFO - 2020-10-09 06:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:46:14 --> Email Class Initialized
INFO - 2020-10-09 06:46:14 --> Controller Class Initialized
INFO - 2020-10-09 06:46:14 --> Model Class Initialized
INFO - 2020-10-09 06:46:14 --> Model Class Initialized
DEBUG - 2020-10-09 06:46:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:46:14 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:46:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:46:14 --> Config Class Initialized
INFO - 2020-10-09 06:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:46:14 --> Utf8 Class Initialized
INFO - 2020-10-09 06:46:14 --> URI Class Initialized
DEBUG - 2020-10-09 06:46:14 --> No URI present. Default controller set.
INFO - 2020-10-09 06:46:14 --> Router Class Initialized
INFO - 2020-10-09 06:46:14 --> Output Class Initialized
INFO - 2020-10-09 06:46:14 --> Security Class Initialized
DEBUG - 2020-10-09 06:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:46:14 --> Input Class Initialized
INFO - 2020-10-09 06:46:14 --> Language Class Initialized
INFO - 2020-10-09 06:46:14 --> Loader Class Initialized
INFO - 2020-10-09 06:46:14 --> Helper loaded: url_helper
INFO - 2020-10-09 06:46:14 --> Database Driver Class Initialized
INFO - 2020-10-09 06:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:46:14 --> Email Class Initialized
INFO - 2020-10-09 06:46:14 --> Controller Class Initialized
INFO - 2020-10-09 06:46:14 --> Model Class Initialized
INFO - 2020-10-09 06:46:14 --> Model Class Initialized
DEBUG - 2020-10-09 06:46:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:46:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:46:14 --> Final output sent to browser
DEBUG - 2020-10-09 06:46:14 --> Total execution time: 0.0206
ERROR - 2020-10-09 06:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:47:06 --> Config Class Initialized
INFO - 2020-10-09 06:47:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:47:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:47:06 --> Utf8 Class Initialized
INFO - 2020-10-09 06:47:06 --> URI Class Initialized
INFO - 2020-10-09 06:47:06 --> Router Class Initialized
INFO - 2020-10-09 06:47:06 --> Output Class Initialized
INFO - 2020-10-09 06:47:06 --> Security Class Initialized
DEBUG - 2020-10-09 06:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:47:06 --> Input Class Initialized
INFO - 2020-10-09 06:47:06 --> Language Class Initialized
INFO - 2020-10-09 06:47:06 --> Loader Class Initialized
INFO - 2020-10-09 06:47:06 --> Helper loaded: url_helper
INFO - 2020-10-09 06:47:06 --> Database Driver Class Initialized
INFO - 2020-10-09 06:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:47:06 --> Email Class Initialized
INFO - 2020-10-09 06:47:06 --> Controller Class Initialized
INFO - 2020-10-09 06:47:06 --> Model Class Initialized
INFO - 2020-10-09 06:47:06 --> Model Class Initialized
DEBUG - 2020-10-09 06:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:47:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:47:06 --> Model Class Initialized
ERROR - 2020-10-09 06:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:47:06 --> Config Class Initialized
INFO - 2020-10-09 06:47:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:47:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:47:06 --> Utf8 Class Initialized
INFO - 2020-10-09 06:47:06 --> URI Class Initialized
DEBUG - 2020-10-09 06:47:06 --> No URI present. Default controller set.
INFO - 2020-10-09 06:47:06 --> Router Class Initialized
INFO - 2020-10-09 06:47:06 --> Output Class Initialized
INFO - 2020-10-09 06:47:06 --> Security Class Initialized
DEBUG - 2020-10-09 06:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:47:06 --> Input Class Initialized
INFO - 2020-10-09 06:47:06 --> Language Class Initialized
INFO - 2020-10-09 06:47:06 --> Loader Class Initialized
INFO - 2020-10-09 06:47:06 --> Helper loaded: url_helper
INFO - 2020-10-09 06:47:06 --> Database Driver Class Initialized
INFO - 2020-10-09 06:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:47:06 --> Email Class Initialized
INFO - 2020-10-09 06:47:06 --> Controller Class Initialized
INFO - 2020-10-09 06:47:06 --> Model Class Initialized
INFO - 2020-10-09 06:47:06 --> Model Class Initialized
DEBUG - 2020-10-09 06:47:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:47:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:47:06 --> Final output sent to browser
DEBUG - 2020-10-09 06:47:06 --> Total execution time: 0.0202
ERROR - 2020-10-09 06:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:48:39 --> Config Class Initialized
INFO - 2020-10-09 06:48:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:48:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:48:39 --> Utf8 Class Initialized
INFO - 2020-10-09 06:48:39 --> URI Class Initialized
INFO - 2020-10-09 06:48:39 --> Router Class Initialized
INFO - 2020-10-09 06:48:39 --> Output Class Initialized
INFO - 2020-10-09 06:48:39 --> Security Class Initialized
DEBUG - 2020-10-09 06:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:48:39 --> Input Class Initialized
INFO - 2020-10-09 06:48:39 --> Language Class Initialized
INFO - 2020-10-09 06:48:39 --> Loader Class Initialized
INFO - 2020-10-09 06:48:39 --> Helper loaded: url_helper
INFO - 2020-10-09 06:48:39 --> Database Driver Class Initialized
INFO - 2020-10-09 06:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:48:39 --> Email Class Initialized
INFO - 2020-10-09 06:48:39 --> Controller Class Initialized
DEBUG - 2020-10-09 06:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:48:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:48:39 --> Model Class Initialized
INFO - 2020-10-09 06:48:39 --> Model Class Initialized
INFO - 2020-10-09 06:48:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-09 06:48:39 --> Final output sent to browser
DEBUG - 2020-10-09 06:48:39 --> Total execution time: 0.0279
ERROR - 2020-10-09 06:48:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:48:44 --> Config Class Initialized
INFO - 2020-10-09 06:48:44 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:48:44 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:48:44 --> Utf8 Class Initialized
INFO - 2020-10-09 06:48:44 --> URI Class Initialized
DEBUG - 2020-10-09 06:48:44 --> No URI present. Default controller set.
INFO - 2020-10-09 06:48:44 --> Router Class Initialized
INFO - 2020-10-09 06:48:44 --> Output Class Initialized
INFO - 2020-10-09 06:48:44 --> Security Class Initialized
DEBUG - 2020-10-09 06:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:48:44 --> Input Class Initialized
INFO - 2020-10-09 06:48:44 --> Language Class Initialized
INFO - 2020-10-09 06:48:44 --> Loader Class Initialized
INFO - 2020-10-09 06:48:44 --> Helper loaded: url_helper
INFO - 2020-10-09 06:48:44 --> Database Driver Class Initialized
INFO - 2020-10-09 06:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:48:44 --> Email Class Initialized
INFO - 2020-10-09 06:48:44 --> Controller Class Initialized
INFO - 2020-10-09 06:48:44 --> Model Class Initialized
INFO - 2020-10-09 06:48:44 --> Model Class Initialized
DEBUG - 2020-10-09 06:48:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:48:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:48:44 --> Final output sent to browser
DEBUG - 2020-10-09 06:48:44 --> Total execution time: 0.0193
ERROR - 2020-10-09 06:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:08 --> Config Class Initialized
INFO - 2020-10-09 06:49:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:08 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:08 --> URI Class Initialized
INFO - 2020-10-09 06:49:08 --> Router Class Initialized
INFO - 2020-10-09 06:49:08 --> Output Class Initialized
INFO - 2020-10-09 06:49:08 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:08 --> Input Class Initialized
INFO - 2020-10-09 06:49:08 --> Language Class Initialized
INFO - 2020-10-09 06:49:08 --> Loader Class Initialized
INFO - 2020-10-09 06:49:08 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:08 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:08 --> Email Class Initialized
INFO - 2020-10-09 06:49:08 --> Controller Class Initialized
INFO - 2020-10-09 06:49:08 --> Model Class Initialized
INFO - 2020-10-09 06:49:08 --> Model Class Initialized
DEBUG - 2020-10-09 06:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:49:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:49:08 --> Model Class Initialized
INFO - 2020-10-09 06:49:08 --> Final output sent to browser
DEBUG - 2020-10-09 06:49:08 --> Total execution time: 0.0289
ERROR - 2020-10-09 06:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:09 --> Config Class Initialized
INFO - 2020-10-09 06:49:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:09 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:09 --> URI Class Initialized
INFO - 2020-10-09 06:49:09 --> Router Class Initialized
INFO - 2020-10-09 06:49:09 --> Output Class Initialized
INFO - 2020-10-09 06:49:09 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:09 --> Input Class Initialized
INFO - 2020-10-09 06:49:09 --> Language Class Initialized
INFO - 2020-10-09 06:49:09 --> Loader Class Initialized
INFO - 2020-10-09 06:49:09 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:09 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:09 --> Email Class Initialized
INFO - 2020-10-09 06:49:09 --> Controller Class Initialized
INFO - 2020-10-09 06:49:09 --> Model Class Initialized
INFO - 2020-10-09 06:49:09 --> Model Class Initialized
DEBUG - 2020-10-09 06:49:09 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:49:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:09 --> Config Class Initialized
INFO - 2020-10-09 06:49:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:09 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:09 --> URI Class Initialized
DEBUG - 2020-10-09 06:49:09 --> No URI present. Default controller set.
INFO - 2020-10-09 06:49:09 --> Router Class Initialized
INFO - 2020-10-09 06:49:09 --> Output Class Initialized
INFO - 2020-10-09 06:49:09 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:09 --> Input Class Initialized
INFO - 2020-10-09 06:49:09 --> Language Class Initialized
INFO - 2020-10-09 06:49:09 --> Loader Class Initialized
INFO - 2020-10-09 06:49:09 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:09 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:09 --> Email Class Initialized
INFO - 2020-10-09 06:49:09 --> Controller Class Initialized
INFO - 2020-10-09 06:49:09 --> Model Class Initialized
INFO - 2020-10-09 06:49:09 --> Model Class Initialized
DEBUG - 2020-10-09 06:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:49:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:49:09 --> Final output sent to browser
DEBUG - 2020-10-09 06:49:09 --> Total execution time: 0.0229
ERROR - 2020-10-09 06:49:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:15 --> Config Class Initialized
INFO - 2020-10-09 06:49:15 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:15 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:15 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:15 --> URI Class Initialized
DEBUG - 2020-10-09 06:49:15 --> No URI present. Default controller set.
INFO - 2020-10-09 06:49:15 --> Router Class Initialized
INFO - 2020-10-09 06:49:15 --> Output Class Initialized
INFO - 2020-10-09 06:49:15 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:15 --> Input Class Initialized
INFO - 2020-10-09 06:49:15 --> Language Class Initialized
INFO - 2020-10-09 06:49:15 --> Loader Class Initialized
INFO - 2020-10-09 06:49:15 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:15 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:15 --> Email Class Initialized
INFO - 2020-10-09 06:49:15 --> Controller Class Initialized
INFO - 2020-10-09 06:49:15 --> Model Class Initialized
INFO - 2020-10-09 06:49:15 --> Model Class Initialized
DEBUG - 2020-10-09 06:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:49:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:49:15 --> Final output sent to browser
DEBUG - 2020-10-09 06:49:15 --> Total execution time: 0.0208
ERROR - 2020-10-09 06:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:38 --> Config Class Initialized
INFO - 2020-10-09 06:49:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:38 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:38 --> URI Class Initialized
INFO - 2020-10-09 06:49:38 --> Router Class Initialized
INFO - 2020-10-09 06:49:38 --> Output Class Initialized
INFO - 2020-10-09 06:49:38 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:38 --> Input Class Initialized
INFO - 2020-10-09 06:49:38 --> Language Class Initialized
INFO - 2020-10-09 06:49:38 --> Loader Class Initialized
INFO - 2020-10-09 06:49:38 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:38 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:38 --> Email Class Initialized
INFO - 2020-10-09 06:49:38 --> Controller Class Initialized
INFO - 2020-10-09 06:49:38 --> Model Class Initialized
INFO - 2020-10-09 06:49:38 --> Model Class Initialized
DEBUG - 2020-10-09 06:49:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:49:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:49:38 --> Model Class Initialized
INFO - 2020-10-09 06:49:38 --> Final output sent to browser
DEBUG - 2020-10-09 06:49:38 --> Total execution time: 0.0237
ERROR - 2020-10-09 06:49:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:38 --> Config Class Initialized
INFO - 2020-10-09 06:49:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:38 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:38 --> URI Class Initialized
INFO - 2020-10-09 06:49:38 --> Router Class Initialized
INFO - 2020-10-09 06:49:38 --> Output Class Initialized
INFO - 2020-10-09 06:49:38 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:38 --> Input Class Initialized
INFO - 2020-10-09 06:49:38 --> Language Class Initialized
INFO - 2020-10-09 06:49:38 --> Loader Class Initialized
INFO - 2020-10-09 06:49:38 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:38 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:38 --> Email Class Initialized
INFO - 2020-10-09 06:49:38 --> Controller Class Initialized
INFO - 2020-10-09 06:49:38 --> Model Class Initialized
INFO - 2020-10-09 06:49:38 --> Model Class Initialized
DEBUG - 2020-10-09 06:49:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:49:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:39 --> Config Class Initialized
INFO - 2020-10-09 06:49:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:39 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:39 --> URI Class Initialized
INFO - 2020-10-09 06:49:39 --> Router Class Initialized
INFO - 2020-10-09 06:49:39 --> Output Class Initialized
INFO - 2020-10-09 06:49:39 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:39 --> Input Class Initialized
INFO - 2020-10-09 06:49:39 --> Language Class Initialized
INFO - 2020-10-09 06:49:39 --> Loader Class Initialized
INFO - 2020-10-09 06:49:39 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:39 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:39 --> Email Class Initialized
INFO - 2020-10-09 06:49:39 --> Controller Class Initialized
DEBUG - 2020-10-09 06:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:49:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:49:39 --> Model Class Initialized
INFO - 2020-10-09 06:49:39 --> Model Class Initialized
INFO - 2020-10-09 06:49:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 06:49:39 --> Final output sent to browser
DEBUG - 2020-10-09 06:49:39 --> Total execution time: 0.0232
ERROR - 2020-10-09 06:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:49:47 --> Config Class Initialized
INFO - 2020-10-09 06:49:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:49:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:49:47 --> Utf8 Class Initialized
INFO - 2020-10-09 06:49:47 --> URI Class Initialized
INFO - 2020-10-09 06:49:47 --> Router Class Initialized
INFO - 2020-10-09 06:49:47 --> Output Class Initialized
INFO - 2020-10-09 06:49:47 --> Security Class Initialized
DEBUG - 2020-10-09 06:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:49:47 --> Input Class Initialized
INFO - 2020-10-09 06:49:47 --> Language Class Initialized
INFO - 2020-10-09 06:49:47 --> Loader Class Initialized
INFO - 2020-10-09 06:49:47 --> Helper loaded: url_helper
INFO - 2020-10-09 06:49:47 --> Database Driver Class Initialized
INFO - 2020-10-09 06:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:49:47 --> Email Class Initialized
INFO - 2020-10-09 06:49:47 --> Controller Class Initialized
DEBUG - 2020-10-09 06:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:49:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:49:47 --> Model Class Initialized
INFO - 2020-10-09 06:49:47 --> Model Class Initialized
INFO - 2020-10-09 06:49:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-09 06:49:47 --> Final output sent to browser
DEBUG - 2020-10-09 06:49:47 --> Total execution time: 0.0233
ERROR - 2020-10-09 06:50:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:50:01 --> Config Class Initialized
INFO - 2020-10-09 06:50:01 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:50:01 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:50:01 --> Utf8 Class Initialized
INFO - 2020-10-09 06:50:01 --> URI Class Initialized
INFO - 2020-10-09 06:50:01 --> Router Class Initialized
INFO - 2020-10-09 06:50:01 --> Output Class Initialized
INFO - 2020-10-09 06:50:01 --> Security Class Initialized
DEBUG - 2020-10-09 06:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:50:01 --> Input Class Initialized
INFO - 2020-10-09 06:50:01 --> Language Class Initialized
INFO - 2020-10-09 06:50:01 --> Loader Class Initialized
INFO - 2020-10-09 06:50:01 --> Helper loaded: url_helper
INFO - 2020-10-09 06:50:01 --> Database Driver Class Initialized
INFO - 2020-10-09 06:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:50:01 --> Email Class Initialized
INFO - 2020-10-09 06:50:01 --> Controller Class Initialized
DEBUG - 2020-10-09 06:50:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:50:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:50:01 --> Model Class Initialized
INFO - 2020-10-09 06:50:01 --> Model Class Initialized
INFO - 2020-10-09 06:50:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 06:50:01 --> Final output sent to browser
DEBUG - 2020-10-09 06:50:01 --> Total execution time: 0.0430
ERROR - 2020-10-09 06:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:50:03 --> Config Class Initialized
INFO - 2020-10-09 06:50:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:50:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:50:03 --> Utf8 Class Initialized
INFO - 2020-10-09 06:50:03 --> URI Class Initialized
INFO - 2020-10-09 06:50:03 --> Router Class Initialized
INFO - 2020-10-09 06:50:03 --> Output Class Initialized
INFO - 2020-10-09 06:50:03 --> Security Class Initialized
DEBUG - 2020-10-09 06:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:50:03 --> Input Class Initialized
INFO - 2020-10-09 06:50:03 --> Language Class Initialized
INFO - 2020-10-09 06:50:03 --> Loader Class Initialized
INFO - 2020-10-09 06:50:03 --> Helper loaded: url_helper
INFO - 2020-10-09 06:50:03 --> Database Driver Class Initialized
INFO - 2020-10-09 06:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:50:03 --> Email Class Initialized
INFO - 2020-10-09 06:50:03 --> Controller Class Initialized
DEBUG - 2020-10-09 06:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:50:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:50:03 --> Model Class Initialized
INFO - 2020-10-09 06:50:03 --> Model Class Initialized
INFO - 2020-10-09 06:50:03 --> Final output sent to browser
DEBUG - 2020-10-09 06:50:03 --> Total execution time: 0.0234
ERROR - 2020-10-09 06:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:50:07 --> Config Class Initialized
INFO - 2020-10-09 06:50:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:50:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:50:07 --> Utf8 Class Initialized
INFO - 2020-10-09 06:50:07 --> URI Class Initialized
INFO - 2020-10-09 06:50:07 --> Router Class Initialized
INFO - 2020-10-09 06:50:07 --> Output Class Initialized
INFO - 2020-10-09 06:50:07 --> Security Class Initialized
DEBUG - 2020-10-09 06:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:50:07 --> Input Class Initialized
INFO - 2020-10-09 06:50:07 --> Language Class Initialized
INFO - 2020-10-09 06:50:07 --> Loader Class Initialized
INFO - 2020-10-09 06:50:07 --> Helper loaded: url_helper
INFO - 2020-10-09 06:50:07 --> Database Driver Class Initialized
INFO - 2020-10-09 06:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:50:07 --> Email Class Initialized
INFO - 2020-10-09 06:50:07 --> Controller Class Initialized
DEBUG - 2020-10-09 06:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:50:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:50:07 --> Model Class Initialized
INFO - 2020-10-09 06:50:07 --> Model Class Initialized
INFO - 2020-10-09 06:50:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 06:50:07 --> Final output sent to browser
DEBUG - 2020-10-09 06:50:07 --> Total execution time: 0.0281
ERROR - 2020-10-09 06:50:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:50:08 --> Config Class Initialized
INFO - 2020-10-09 06:50:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:50:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:50:08 --> Utf8 Class Initialized
INFO - 2020-10-09 06:50:08 --> URI Class Initialized
INFO - 2020-10-09 06:50:08 --> Router Class Initialized
INFO - 2020-10-09 06:50:08 --> Output Class Initialized
INFO - 2020-10-09 06:50:08 --> Security Class Initialized
DEBUG - 2020-10-09 06:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:50:08 --> Input Class Initialized
INFO - 2020-10-09 06:50:08 --> Language Class Initialized
INFO - 2020-10-09 06:50:08 --> Loader Class Initialized
INFO - 2020-10-09 06:50:08 --> Helper loaded: url_helper
INFO - 2020-10-09 06:50:08 --> Database Driver Class Initialized
INFO - 2020-10-09 06:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:50:08 --> Email Class Initialized
INFO - 2020-10-09 06:50:08 --> Controller Class Initialized
DEBUG - 2020-10-09 06:50:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:50:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:50:08 --> Model Class Initialized
INFO - 2020-10-09 06:50:08 --> Model Class Initialized
INFO - 2020-10-09 06:50:08 --> Final output sent to browser
DEBUG - 2020-10-09 06:50:08 --> Total execution time: 0.0226
ERROR - 2020-10-09 06:50:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:50:11 --> Config Class Initialized
INFO - 2020-10-09 06:50:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:50:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:50:11 --> Utf8 Class Initialized
INFO - 2020-10-09 06:50:11 --> URI Class Initialized
INFO - 2020-10-09 06:50:11 --> Router Class Initialized
INFO - 2020-10-09 06:50:11 --> Output Class Initialized
INFO - 2020-10-09 06:50:11 --> Security Class Initialized
DEBUG - 2020-10-09 06:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:50:11 --> Input Class Initialized
INFO - 2020-10-09 06:50:11 --> Language Class Initialized
INFO - 2020-10-09 06:50:11 --> Loader Class Initialized
INFO - 2020-10-09 06:50:11 --> Helper loaded: url_helper
INFO - 2020-10-09 06:50:11 --> Database Driver Class Initialized
INFO - 2020-10-09 06:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:50:11 --> Email Class Initialized
INFO - 2020-10-09 06:50:11 --> Controller Class Initialized
DEBUG - 2020-10-09 06:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:50:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:50:11 --> Model Class Initialized
INFO - 2020-10-09 06:50:11 --> Model Class Initialized
INFO - 2020-10-09 06:50:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 06:50:11 --> Final output sent to browser
DEBUG - 2020-10-09 06:50:11 --> Total execution time: 0.0250
ERROR - 2020-10-09 06:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:50:13 --> Config Class Initialized
INFO - 2020-10-09 06:50:13 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:50:13 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:50:13 --> Utf8 Class Initialized
INFO - 2020-10-09 06:50:13 --> URI Class Initialized
INFO - 2020-10-09 06:50:13 --> Router Class Initialized
INFO - 2020-10-09 06:50:13 --> Output Class Initialized
INFO - 2020-10-09 06:50:13 --> Security Class Initialized
DEBUG - 2020-10-09 06:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:50:13 --> Input Class Initialized
INFO - 2020-10-09 06:50:13 --> Language Class Initialized
INFO - 2020-10-09 06:50:13 --> Loader Class Initialized
INFO - 2020-10-09 06:50:13 --> Helper loaded: url_helper
INFO - 2020-10-09 06:50:13 --> Database Driver Class Initialized
INFO - 2020-10-09 06:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:50:13 --> Email Class Initialized
INFO - 2020-10-09 06:50:13 --> Controller Class Initialized
DEBUG - 2020-10-09 06:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:50:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:50:13 --> Model Class Initialized
INFO - 2020-10-09 06:50:13 --> Model Class Initialized
INFO - 2020-10-09 06:50:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-09 06:50:13 --> Final output sent to browser
DEBUG - 2020-10-09 06:50:13 --> Total execution time: 0.0294
ERROR - 2020-10-09 06:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:10 --> Config Class Initialized
INFO - 2020-10-09 06:51:10 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:10 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:10 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:10 --> URI Class Initialized
INFO - 2020-10-09 06:51:10 --> Router Class Initialized
INFO - 2020-10-09 06:51:10 --> Output Class Initialized
INFO - 2020-10-09 06:51:10 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:10 --> Input Class Initialized
INFO - 2020-10-09 06:51:10 --> Language Class Initialized
INFO - 2020-10-09 06:51:10 --> Loader Class Initialized
INFO - 2020-10-09 06:51:10 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:10 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:10 --> Email Class Initialized
INFO - 2020-10-09 06:51:10 --> Controller Class Initialized
DEBUG - 2020-10-09 06:51:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:51:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:51:10 --> Model Class Initialized
INFO - 2020-10-09 06:51:10 --> Model Class Initialized
INFO - 2020-10-09 06:51:10 --> Model Class Initialized
INFO - 2020-10-09 06:51:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 06:51:10 --> Final output sent to browser
DEBUG - 2020-10-09 06:51:10 --> Total execution time: 0.0797
ERROR - 2020-10-09 06:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:30 --> Config Class Initialized
INFO - 2020-10-09 06:51:30 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:30 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:30 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:30 --> URI Class Initialized
INFO - 2020-10-09 06:51:30 --> Router Class Initialized
INFO - 2020-10-09 06:51:30 --> Output Class Initialized
INFO - 2020-10-09 06:51:30 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:30 --> Input Class Initialized
INFO - 2020-10-09 06:51:30 --> Language Class Initialized
INFO - 2020-10-09 06:51:30 --> Loader Class Initialized
INFO - 2020-10-09 06:51:30 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:30 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:30 --> Email Class Initialized
INFO - 2020-10-09 06:51:30 --> Controller Class Initialized
INFO - 2020-10-09 06:51:30 --> Model Class Initialized
INFO - 2020-10-09 06:51:30 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:51:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:51:30 --> Model Class Initialized
INFO - 2020-10-09 06:51:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-10-09 06:51:30 --> Final output sent to browser
DEBUG - 2020-10-09 06:51:30 --> Total execution time: 0.0264
ERROR - 2020-10-09 06:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:36 --> Config Class Initialized
INFO - 2020-10-09 06:51:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:36 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:36 --> URI Class Initialized
INFO - 2020-10-09 06:51:36 --> Router Class Initialized
INFO - 2020-10-09 06:51:36 --> Output Class Initialized
INFO - 2020-10-09 06:51:36 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:36 --> Input Class Initialized
INFO - 2020-10-09 06:51:36 --> Language Class Initialized
INFO - 2020-10-09 06:51:36 --> Loader Class Initialized
INFO - 2020-10-09 06:51:36 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:36 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:36 --> Email Class Initialized
INFO - 2020-10-09 06:51:36 --> Controller Class Initialized
INFO - 2020-10-09 06:51:36 --> Model Class Initialized
INFO - 2020-10-09 06:51:36 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:51:36 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:36 --> Config Class Initialized
INFO - 2020-10-09 06:51:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:36 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:36 --> URI Class Initialized
INFO - 2020-10-09 06:51:36 --> Router Class Initialized
INFO - 2020-10-09 06:51:36 --> Output Class Initialized
INFO - 2020-10-09 06:51:36 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:36 --> Input Class Initialized
INFO - 2020-10-09 06:51:36 --> Language Class Initialized
INFO - 2020-10-09 06:51:36 --> Loader Class Initialized
INFO - 2020-10-09 06:51:36 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:36 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:36 --> Email Class Initialized
INFO - 2020-10-09 06:51:36 --> Controller Class Initialized
INFO - 2020-10-09 06:51:36 --> Model Class Initialized
INFO - 2020-10-09 06:51:36 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:51:36 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 06:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:36 --> Config Class Initialized
INFO - 2020-10-09 06:51:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:36 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:36 --> URI Class Initialized
DEBUG - 2020-10-09 06:51:36 --> No URI present. Default controller set.
INFO - 2020-10-09 06:51:36 --> Router Class Initialized
INFO - 2020-10-09 06:51:36 --> Output Class Initialized
INFO - 2020-10-09 06:51:36 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:36 --> Input Class Initialized
INFO - 2020-10-09 06:51:36 --> Language Class Initialized
INFO - 2020-10-09 06:51:36 --> Loader Class Initialized
INFO - 2020-10-09 06:51:36 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:36 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:36 --> Email Class Initialized
INFO - 2020-10-09 06:51:36 --> Controller Class Initialized
INFO - 2020-10-09 06:51:36 --> Model Class Initialized
INFO - 2020-10-09 06:51:36 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:51:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:51:36 --> Final output sent to browser
DEBUG - 2020-10-09 06:51:36 --> Total execution time: 0.0209
ERROR - 2020-10-09 06:51:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:37 --> Config Class Initialized
INFO - 2020-10-09 06:51:37 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:37 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:37 --> URI Class Initialized
DEBUG - 2020-10-09 06:51:37 --> No URI present. Default controller set.
INFO - 2020-10-09 06:51:37 --> Router Class Initialized
INFO - 2020-10-09 06:51:37 --> Output Class Initialized
INFO - 2020-10-09 06:51:37 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:37 --> Input Class Initialized
INFO - 2020-10-09 06:51:37 --> Language Class Initialized
INFO - 2020-10-09 06:51:37 --> Loader Class Initialized
INFO - 2020-10-09 06:51:37 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:37 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:37 --> Email Class Initialized
INFO - 2020-10-09 06:51:37 --> Controller Class Initialized
INFO - 2020-10-09 06:51:37 --> Model Class Initialized
INFO - 2020-10-09 06:51:37 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:51:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:51:37 --> Final output sent to browser
DEBUG - 2020-10-09 06:51:37 --> Total execution time: 0.0185
ERROR - 2020-10-09 06:51:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:50 --> Config Class Initialized
INFO - 2020-10-09 06:51:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:50 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:50 --> URI Class Initialized
INFO - 2020-10-09 06:51:50 --> Router Class Initialized
INFO - 2020-10-09 06:51:50 --> Output Class Initialized
INFO - 2020-10-09 06:51:50 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:50 --> Input Class Initialized
INFO - 2020-10-09 06:51:50 --> Language Class Initialized
INFO - 2020-10-09 06:51:50 --> Loader Class Initialized
INFO - 2020-10-09 06:51:50 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:50 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:50 --> Email Class Initialized
INFO - 2020-10-09 06:51:50 --> Controller Class Initialized
INFO - 2020-10-09 06:51:50 --> Model Class Initialized
INFO - 2020-10-09 06:51:50 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 06:51:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:51:50 --> Model Class Initialized
ERROR - 2020-10-09 06:51:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 06:51:50 --> Config Class Initialized
INFO - 2020-10-09 06:51:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 06:51:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 06:51:50 --> Utf8 Class Initialized
INFO - 2020-10-09 06:51:50 --> URI Class Initialized
DEBUG - 2020-10-09 06:51:50 --> No URI present. Default controller set.
INFO - 2020-10-09 06:51:50 --> Router Class Initialized
INFO - 2020-10-09 06:51:50 --> Output Class Initialized
INFO - 2020-10-09 06:51:50 --> Security Class Initialized
DEBUG - 2020-10-09 06:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 06:51:50 --> Input Class Initialized
INFO - 2020-10-09 06:51:50 --> Language Class Initialized
INFO - 2020-10-09 06:51:50 --> Loader Class Initialized
INFO - 2020-10-09 06:51:50 --> Helper loaded: url_helper
INFO - 2020-10-09 06:51:50 --> Database Driver Class Initialized
INFO - 2020-10-09 06:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 06:51:50 --> Email Class Initialized
INFO - 2020-10-09 06:51:50 --> Controller Class Initialized
INFO - 2020-10-09 06:51:50 --> Model Class Initialized
INFO - 2020-10-09 06:51:50 --> Model Class Initialized
DEBUG - 2020-10-09 06:51:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 06:51:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 06:51:50 --> Final output sent to browser
DEBUG - 2020-10-09 06:51:50 --> Total execution time: 0.0206
ERROR - 2020-10-09 07:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-10-09 07:00:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:00:53 --> Config Class Initialized
INFO - 2020-10-09 07:00:53 --> Hooks Class Initialized
INFO - 2020-10-09 07:00:53 --> Config Class Initialized
INFO - 2020-10-09 07:00:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:00:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:00:53 --> Utf8 Class Initialized
DEBUG - 2020-10-09 07:00:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:00:53 --> Utf8 Class Initialized
INFO - 2020-10-09 07:00:53 --> URI Class Initialized
INFO - 2020-10-09 07:00:53 --> URI Class Initialized
INFO - 2020-10-09 07:00:53 --> Router Class Initialized
INFO - 2020-10-09 07:00:53 --> Router Class Initialized
INFO - 2020-10-09 07:00:53 --> Output Class Initialized
INFO - 2020-10-09 07:00:53 --> Output Class Initialized
INFO - 2020-10-09 07:00:53 --> Security Class Initialized
INFO - 2020-10-09 07:00:53 --> Security Class Initialized
DEBUG - 2020-10-09 07:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-09 07:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:00:53 --> Input Class Initialized
INFO - 2020-10-09 07:00:53 --> Input Class Initialized
INFO - 2020-10-09 07:00:53 --> Language Class Initialized
INFO - 2020-10-09 07:00:53 --> Language Class Initialized
INFO - 2020-10-09 07:00:53 --> Loader Class Initialized
INFO - 2020-10-09 07:00:53 --> Loader Class Initialized
INFO - 2020-10-09 07:00:53 --> Helper loaded: url_helper
INFO - 2020-10-09 07:00:53 --> Helper loaded: url_helper
INFO - 2020-10-09 07:00:53 --> Database Driver Class Initialized
INFO - 2020-10-09 07:00:53 --> Database Driver Class Initialized
INFO - 2020-10-09 07:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:00:53 --> Email Class Initialized
INFO - 2020-10-09 07:00:53 --> Controller Class Initialized
INFO - 2020-10-09 07:00:53 --> Model Class Initialized
INFO - 2020-10-09 07:00:53 --> Model Class Initialized
DEBUG - 2020-10-09 07:00:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:00:53 --> Email Class Initialized
INFO - 2020-10-09 07:00:53 --> Controller Class Initialized
INFO - 2020-10-09 07:00:53 --> Model Class Initialized
INFO - 2020-10-09 07:00:53 --> Model Class Initialized
DEBUG - 2020-10-09 07:00:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:00:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:00:53 --> Model Class Initialized
INFO - 2020-10-09 07:00:53 --> Final output sent to browser
DEBUG - 2020-10-09 07:00:53 --> Total execution time: 0.0303
ERROR - 2020-10-09 07:00:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:00:54 --> Config Class Initialized
INFO - 2020-10-09 07:00:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:00:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:00:54 --> Utf8 Class Initialized
INFO - 2020-10-09 07:00:54 --> URI Class Initialized
INFO - 2020-10-09 07:00:54 --> Router Class Initialized
INFO - 2020-10-09 07:00:54 --> Output Class Initialized
INFO - 2020-10-09 07:00:54 --> Security Class Initialized
DEBUG - 2020-10-09 07:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:00:54 --> Input Class Initialized
INFO - 2020-10-09 07:00:54 --> Language Class Initialized
INFO - 2020-10-09 07:00:54 --> Loader Class Initialized
INFO - 2020-10-09 07:00:54 --> Helper loaded: url_helper
INFO - 2020-10-09 07:00:54 --> Database Driver Class Initialized
INFO - 2020-10-09 07:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:00:54 --> Email Class Initialized
INFO - 2020-10-09 07:00:54 --> Controller Class Initialized
DEBUG - 2020-10-09 07:00:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:00:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:00:54 --> Model Class Initialized
INFO - 2020-10-09 07:00:54 --> Model Class Initialized
INFO - 2020-10-09 07:00:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:00:54 --> Final output sent to browser
DEBUG - 2020-10-09 07:00:54 --> Total execution time: 0.0319
ERROR - 2020-10-09 07:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:01:14 --> Config Class Initialized
INFO - 2020-10-09 07:01:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:01:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:01:14 --> Utf8 Class Initialized
INFO - 2020-10-09 07:01:14 --> URI Class Initialized
DEBUG - 2020-10-09 07:01:14 --> No URI present. Default controller set.
INFO - 2020-10-09 07:01:14 --> Router Class Initialized
INFO - 2020-10-09 07:01:14 --> Output Class Initialized
INFO - 2020-10-09 07:01:14 --> Security Class Initialized
DEBUG - 2020-10-09 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:01:14 --> Input Class Initialized
INFO - 2020-10-09 07:01:14 --> Language Class Initialized
INFO - 2020-10-09 07:01:14 --> Loader Class Initialized
INFO - 2020-10-09 07:01:14 --> Helper loaded: url_helper
INFO - 2020-10-09 07:01:14 --> Database Driver Class Initialized
INFO - 2020-10-09 07:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:01:14 --> Email Class Initialized
INFO - 2020-10-09 07:01:14 --> Controller Class Initialized
INFO - 2020-10-09 07:01:14 --> Model Class Initialized
INFO - 2020-10-09 07:01:14 --> Model Class Initialized
DEBUG - 2020-10-09 07:01:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:01:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:01:14 --> Final output sent to browser
DEBUG - 2020-10-09 07:01:14 --> Total execution time: 0.0200
ERROR - 2020-10-09 07:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:01:49 --> Config Class Initialized
INFO - 2020-10-09 07:01:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:01:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:01:49 --> Utf8 Class Initialized
INFO - 2020-10-09 07:01:49 --> URI Class Initialized
DEBUG - 2020-10-09 07:01:49 --> No URI present. Default controller set.
INFO - 2020-10-09 07:01:49 --> Router Class Initialized
INFO - 2020-10-09 07:01:49 --> Output Class Initialized
INFO - 2020-10-09 07:01:49 --> Security Class Initialized
DEBUG - 2020-10-09 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:01:49 --> Input Class Initialized
INFO - 2020-10-09 07:01:49 --> Language Class Initialized
INFO - 2020-10-09 07:01:49 --> Loader Class Initialized
INFO - 2020-10-09 07:01:49 --> Helper loaded: url_helper
INFO - 2020-10-09 07:01:49 --> Database Driver Class Initialized
INFO - 2020-10-09 07:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:01:49 --> Email Class Initialized
INFO - 2020-10-09 07:01:49 --> Controller Class Initialized
INFO - 2020-10-09 07:01:49 --> Model Class Initialized
INFO - 2020-10-09 07:01:49 --> Model Class Initialized
DEBUG - 2020-10-09 07:01:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:01:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:01:49 --> Final output sent to browser
DEBUG - 2020-10-09 07:01:49 --> Total execution time: 0.0234
ERROR - 2020-10-09 07:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:02:39 --> Config Class Initialized
INFO - 2020-10-09 07:02:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:02:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:02:39 --> Utf8 Class Initialized
INFO - 2020-10-09 07:02:39 --> URI Class Initialized
INFO - 2020-10-09 07:02:39 --> Router Class Initialized
INFO - 2020-10-09 07:02:39 --> Output Class Initialized
INFO - 2020-10-09 07:02:39 --> Security Class Initialized
DEBUG - 2020-10-09 07:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:02:39 --> Input Class Initialized
INFO - 2020-10-09 07:02:39 --> Language Class Initialized
INFO - 2020-10-09 07:02:39 --> Loader Class Initialized
INFO - 2020-10-09 07:02:39 --> Helper loaded: url_helper
INFO - 2020-10-09 07:02:39 --> Database Driver Class Initialized
INFO - 2020-10-09 07:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:02:39 --> Email Class Initialized
INFO - 2020-10-09 07:02:39 --> Controller Class Initialized
INFO - 2020-10-09 07:02:39 --> Model Class Initialized
INFO - 2020-10-09 07:02:39 --> Model Class Initialized
DEBUG - 2020-10-09 07:02:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:02:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:02:39 --> Model Class Initialized
INFO - 2020-10-09 07:02:39 --> Final output sent to browser
DEBUG - 2020-10-09 07:02:39 --> Total execution time: 0.0215
ERROR - 2020-10-09 07:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:02:40 --> Config Class Initialized
INFO - 2020-10-09 07:02:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:02:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:02:40 --> Utf8 Class Initialized
INFO - 2020-10-09 07:02:40 --> URI Class Initialized
INFO - 2020-10-09 07:02:40 --> Router Class Initialized
INFO - 2020-10-09 07:02:40 --> Output Class Initialized
INFO - 2020-10-09 07:02:40 --> Security Class Initialized
DEBUG - 2020-10-09 07:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:02:40 --> Input Class Initialized
INFO - 2020-10-09 07:02:40 --> Language Class Initialized
INFO - 2020-10-09 07:02:40 --> Loader Class Initialized
INFO - 2020-10-09 07:02:40 --> Helper loaded: url_helper
INFO - 2020-10-09 07:02:40 --> Database Driver Class Initialized
INFO - 2020-10-09 07:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:02:40 --> Email Class Initialized
INFO - 2020-10-09 07:02:40 --> Controller Class Initialized
INFO - 2020-10-09 07:02:40 --> Model Class Initialized
INFO - 2020-10-09 07:02:40 --> Model Class Initialized
DEBUG - 2020-10-09 07:02:40 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 07:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:02:41 --> Config Class Initialized
INFO - 2020-10-09 07:02:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:02:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:02:41 --> Utf8 Class Initialized
INFO - 2020-10-09 07:02:41 --> URI Class Initialized
INFO - 2020-10-09 07:02:41 --> Router Class Initialized
INFO - 2020-10-09 07:02:41 --> Output Class Initialized
INFO - 2020-10-09 07:02:41 --> Security Class Initialized
DEBUG - 2020-10-09 07:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:02:41 --> Input Class Initialized
INFO - 2020-10-09 07:02:41 --> Language Class Initialized
INFO - 2020-10-09 07:02:41 --> Loader Class Initialized
INFO - 2020-10-09 07:02:41 --> Helper loaded: url_helper
INFO - 2020-10-09 07:02:41 --> Database Driver Class Initialized
INFO - 2020-10-09 07:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:02:41 --> Email Class Initialized
INFO - 2020-10-09 07:02:41 --> Controller Class Initialized
DEBUG - 2020-10-09 07:02:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:02:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:02:41 --> Model Class Initialized
INFO - 2020-10-09 07:02:41 --> Model Class Initialized
INFO - 2020-10-09 07:02:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-09 07:02:41 --> Final output sent to browser
DEBUG - 2020-10-09 07:02:41 --> Total execution time: 0.0214
ERROR - 2020-10-09 07:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:02:52 --> Config Class Initialized
INFO - 2020-10-09 07:02:52 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:02:52 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:02:52 --> Utf8 Class Initialized
INFO - 2020-10-09 07:02:52 --> URI Class Initialized
INFO - 2020-10-09 07:02:52 --> Router Class Initialized
INFO - 2020-10-09 07:02:52 --> Output Class Initialized
INFO - 2020-10-09 07:02:52 --> Security Class Initialized
DEBUG - 2020-10-09 07:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:02:52 --> Input Class Initialized
INFO - 2020-10-09 07:02:52 --> Language Class Initialized
INFO - 2020-10-09 07:02:52 --> Loader Class Initialized
INFO - 2020-10-09 07:02:52 --> Helper loaded: url_helper
INFO - 2020-10-09 07:02:52 --> Database Driver Class Initialized
INFO - 2020-10-09 07:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:02:52 --> Email Class Initialized
INFO - 2020-10-09 07:02:52 --> Controller Class Initialized
DEBUG - 2020-10-09 07:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:02:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:02:52 --> Model Class Initialized
INFO - 2020-10-09 07:02:52 --> Model Class Initialized
INFO - 2020-10-09 07:02:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-09 07:02:52 --> Final output sent to browser
DEBUG - 2020-10-09 07:02:52 --> Total execution time: 0.0290
ERROR - 2020-10-09 07:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:02:54 --> Config Class Initialized
INFO - 2020-10-09 07:02:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:02:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:02:54 --> Utf8 Class Initialized
INFO - 2020-10-09 07:02:54 --> URI Class Initialized
INFO - 2020-10-09 07:02:54 --> Router Class Initialized
INFO - 2020-10-09 07:02:54 --> Output Class Initialized
INFO - 2020-10-09 07:02:54 --> Security Class Initialized
DEBUG - 2020-10-09 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:02:54 --> Input Class Initialized
INFO - 2020-10-09 07:02:54 --> Language Class Initialized
INFO - 2020-10-09 07:02:54 --> Loader Class Initialized
INFO - 2020-10-09 07:02:54 --> Helper loaded: url_helper
INFO - 2020-10-09 07:02:54 --> Database Driver Class Initialized
INFO - 2020-10-09 07:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:02:54 --> Email Class Initialized
INFO - 2020-10-09 07:02:54 --> Controller Class Initialized
INFO - 2020-10-09 07:02:54 --> Model Class Initialized
INFO - 2020-10-09 07:02:54 --> Model Class Initialized
INFO - 2020-10-09 07:02:54 --> Model Class Initialized
INFO - 2020-10-09 07:02:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-09 07:02:54 --> Final output sent to browser
DEBUG - 2020-10-09 07:02:54 --> Total execution time: 0.3957
ERROR - 2020-10-09 07:02:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:02:55 --> Config Class Initialized
INFO - 2020-10-09 07:02:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:02:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:02:55 --> Utf8 Class Initialized
INFO - 2020-10-09 07:02:55 --> URI Class Initialized
INFO - 2020-10-09 07:02:55 --> Router Class Initialized
INFO - 2020-10-09 07:02:55 --> Output Class Initialized
INFO - 2020-10-09 07:02:55 --> Security Class Initialized
DEBUG - 2020-10-09 07:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:02:55 --> Input Class Initialized
INFO - 2020-10-09 07:02:55 --> Language Class Initialized
INFO - 2020-10-09 07:02:55 --> Loader Class Initialized
INFO - 2020-10-09 07:02:55 --> Helper loaded: url_helper
INFO - 2020-10-09 07:02:55 --> Database Driver Class Initialized
INFO - 2020-10-09 07:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:02:55 --> Email Class Initialized
INFO - 2020-10-09 07:02:55 --> Controller Class Initialized
INFO - 2020-10-09 07:02:55 --> Model Class Initialized
INFO - 2020-10-09 07:02:55 --> Model Class Initialized
INFO - 2020-10-09 07:02:55 --> Final output sent to browser
DEBUG - 2020-10-09 07:02:55 --> Total execution time: 0.0401
ERROR - 2020-10-09 07:03:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:18 --> Config Class Initialized
INFO - 2020-10-09 07:03:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:18 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:18 --> URI Class Initialized
INFO - 2020-10-09 07:03:18 --> Router Class Initialized
INFO - 2020-10-09 07:03:18 --> Output Class Initialized
INFO - 2020-10-09 07:03:18 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:18 --> Input Class Initialized
INFO - 2020-10-09 07:03:18 --> Language Class Initialized
INFO - 2020-10-09 07:03:18 --> Loader Class Initialized
INFO - 2020-10-09 07:03:18 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:18 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:18 --> Email Class Initialized
INFO - 2020-10-09 07:03:18 --> Controller Class Initialized
INFO - 2020-10-09 07:03:18 --> Model Class Initialized
INFO - 2020-10-09 07:03:18 --> Model Class Initialized
INFO - 2020-10-09 07:03:19 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:19 --> Total execution time: 0.2573
ERROR - 2020-10-09 07:03:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:19 --> Config Class Initialized
INFO - 2020-10-09 07:03:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:19 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:19 --> URI Class Initialized
INFO - 2020-10-09 07:03:19 --> Router Class Initialized
INFO - 2020-10-09 07:03:19 --> Output Class Initialized
INFO - 2020-10-09 07:03:19 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:19 --> Input Class Initialized
INFO - 2020-10-09 07:03:19 --> Language Class Initialized
INFO - 2020-10-09 07:03:19 --> Loader Class Initialized
INFO - 2020-10-09 07:03:19 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:19 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:19 --> Email Class Initialized
INFO - 2020-10-09 07:03:19 --> Controller Class Initialized
INFO - 2020-10-09 07:03:19 --> Model Class Initialized
INFO - 2020-10-09 07:03:19 --> Model Class Initialized
INFO - 2020-10-09 07:03:19 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:19 --> Total execution time: 0.0421
ERROR - 2020-10-09 07:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:25 --> Config Class Initialized
INFO - 2020-10-09 07:03:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:25 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:25 --> URI Class Initialized
INFO - 2020-10-09 07:03:25 --> Router Class Initialized
INFO - 2020-10-09 07:03:25 --> Output Class Initialized
INFO - 2020-10-09 07:03:25 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:25 --> Input Class Initialized
INFO - 2020-10-09 07:03:25 --> Language Class Initialized
INFO - 2020-10-09 07:03:25 --> Loader Class Initialized
INFO - 2020-10-09 07:03:25 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:25 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:25 --> Email Class Initialized
INFO - 2020-10-09 07:03:25 --> Controller Class Initialized
INFO - 2020-10-09 07:03:25 --> Model Class Initialized
INFO - 2020-10-09 07:03:25 --> Model Class Initialized
INFO - 2020-10-09 07:03:26 --> Model Class Initialized
INFO - 2020-10-09 07:03:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-10-09 07:03:26 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:26 --> Total execution time: 0.0539
ERROR - 2020-10-09 07:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:32 --> Config Class Initialized
INFO - 2020-10-09 07:03:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:32 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:32 --> URI Class Initialized
INFO - 2020-10-09 07:03:32 --> Router Class Initialized
INFO - 2020-10-09 07:03:32 --> Output Class Initialized
INFO - 2020-10-09 07:03:32 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:32 --> Input Class Initialized
INFO - 2020-10-09 07:03:32 --> Language Class Initialized
INFO - 2020-10-09 07:03:32 --> Loader Class Initialized
INFO - 2020-10-09 07:03:32 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:32 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:32 --> Email Class Initialized
INFO - 2020-10-09 07:03:32 --> Controller Class Initialized
INFO - 2020-10-09 07:03:32 --> Model Class Initialized
INFO - 2020-10-09 07:03:32 --> Model Class Initialized
INFO - 2020-10-09 07:03:32 --> Model Class Initialized
INFO - 2020-10-09 07:03:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-09 07:03:32 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:32 --> Total execution time: 0.1129
ERROR - 2020-10-09 07:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:32 --> Config Class Initialized
INFO - 2020-10-09 07:03:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:32 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:32 --> URI Class Initialized
INFO - 2020-10-09 07:03:32 --> Router Class Initialized
INFO - 2020-10-09 07:03:32 --> Output Class Initialized
INFO - 2020-10-09 07:03:32 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:32 --> Input Class Initialized
INFO - 2020-10-09 07:03:32 --> Language Class Initialized
INFO - 2020-10-09 07:03:32 --> Loader Class Initialized
INFO - 2020-10-09 07:03:32 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:32 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:32 --> Email Class Initialized
INFO - 2020-10-09 07:03:32 --> Controller Class Initialized
INFO - 2020-10-09 07:03:32 --> Model Class Initialized
INFO - 2020-10-09 07:03:32 --> Model Class Initialized
INFO - 2020-10-09 07:03:32 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:32 --> Total execution time: 0.0447
ERROR - 2020-10-09 07:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:39 --> Config Class Initialized
INFO - 2020-10-09 07:03:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:39 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:39 --> URI Class Initialized
INFO - 2020-10-09 07:03:39 --> Router Class Initialized
INFO - 2020-10-09 07:03:39 --> Output Class Initialized
INFO - 2020-10-09 07:03:39 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:39 --> Input Class Initialized
INFO - 2020-10-09 07:03:39 --> Language Class Initialized
INFO - 2020-10-09 07:03:39 --> Loader Class Initialized
INFO - 2020-10-09 07:03:39 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:39 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:39 --> Email Class Initialized
INFO - 2020-10-09 07:03:39 --> Controller Class Initialized
DEBUG - 2020-10-09 07:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:03:39 --> Model Class Initialized
INFO - 2020-10-09 07:03:39 --> Model Class Initialized
INFO - 2020-10-09 07:03:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-09 07:03:39 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:39 --> Total execution time: 0.0230
ERROR - 2020-10-09 07:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:47 --> Config Class Initialized
INFO - 2020-10-09 07:03:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:47 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:47 --> URI Class Initialized
INFO - 2020-10-09 07:03:47 --> Router Class Initialized
INFO - 2020-10-09 07:03:47 --> Output Class Initialized
INFO - 2020-10-09 07:03:47 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:47 --> Input Class Initialized
INFO - 2020-10-09 07:03:47 --> Language Class Initialized
INFO - 2020-10-09 07:03:47 --> Loader Class Initialized
INFO - 2020-10-09 07:03:47 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:47 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:47 --> Email Class Initialized
INFO - 2020-10-09 07:03:47 --> Controller Class Initialized
DEBUG - 2020-10-09 07:03:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:03:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:03:47 --> Model Class Initialized
INFO - 2020-10-09 07:03:47 --> Model Class Initialized
INFO - 2020-10-09 07:03:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-09 07:03:47 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:47 --> Total execution time: 0.0513
ERROR - 2020-10-09 07:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:54 --> Config Class Initialized
INFO - 2020-10-09 07:03:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:54 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:54 --> URI Class Initialized
INFO - 2020-10-09 07:03:54 --> Router Class Initialized
INFO - 2020-10-09 07:03:54 --> Output Class Initialized
INFO - 2020-10-09 07:03:54 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:54 --> Input Class Initialized
INFO - 2020-10-09 07:03:54 --> Language Class Initialized
INFO - 2020-10-09 07:03:54 --> Loader Class Initialized
INFO - 2020-10-09 07:03:54 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:54 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:54 --> Email Class Initialized
INFO - 2020-10-09 07:03:54 --> Controller Class Initialized
DEBUG - 2020-10-09 07:03:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:03:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:03:54 --> Model Class Initialized
INFO - 2020-10-09 07:03:54 --> Model Class Initialized
INFO - 2020-10-09 07:03:54 --> Model Class Initialized
INFO - 2020-10-09 07:03:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-09 07:03:54 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:54 --> Total execution time: 0.0468
ERROR - 2020-10-09 07:03:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:03:58 --> Config Class Initialized
INFO - 2020-10-09 07:03:58 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:03:58 --> Utf8 Class Initialized
INFO - 2020-10-09 07:03:58 --> URI Class Initialized
INFO - 2020-10-09 07:03:58 --> Router Class Initialized
INFO - 2020-10-09 07:03:58 --> Output Class Initialized
INFO - 2020-10-09 07:03:58 --> Security Class Initialized
DEBUG - 2020-10-09 07:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:03:58 --> Input Class Initialized
INFO - 2020-10-09 07:03:58 --> Language Class Initialized
INFO - 2020-10-09 07:03:58 --> Loader Class Initialized
INFO - 2020-10-09 07:03:58 --> Helper loaded: url_helper
INFO - 2020-10-09 07:03:58 --> Database Driver Class Initialized
INFO - 2020-10-09 07:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:03:58 --> Email Class Initialized
INFO - 2020-10-09 07:03:58 --> Controller Class Initialized
DEBUG - 2020-10-09 07:03:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:03:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:03:58 --> Model Class Initialized
INFO - 2020-10-09 07:03:58 --> Model Class Initialized
INFO - 2020-10-09 07:03:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-09 07:03:58 --> Final output sent to browser
DEBUG - 2020-10-09 07:03:58 --> Total execution time: 0.0247
ERROR - 2020-10-09 07:04:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:04:04 --> Config Class Initialized
INFO - 2020-10-09 07:04:04 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:04:04 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:04:04 --> Utf8 Class Initialized
INFO - 2020-10-09 07:04:04 --> URI Class Initialized
INFO - 2020-10-09 07:04:04 --> Router Class Initialized
INFO - 2020-10-09 07:04:04 --> Output Class Initialized
INFO - 2020-10-09 07:04:04 --> Security Class Initialized
DEBUG - 2020-10-09 07:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:04:04 --> Input Class Initialized
INFO - 2020-10-09 07:04:04 --> Language Class Initialized
INFO - 2020-10-09 07:04:04 --> Loader Class Initialized
INFO - 2020-10-09 07:04:04 --> Helper loaded: url_helper
INFO - 2020-10-09 07:04:04 --> Database Driver Class Initialized
INFO - 2020-10-09 07:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:04:04 --> Email Class Initialized
INFO - 2020-10-09 07:04:04 --> Controller Class Initialized
DEBUG - 2020-10-09 07:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:04:04 --> Model Class Initialized
INFO - 2020-10-09 07:04:04 --> Model Class Initialized
INFO - 2020-10-09 07:04:04 --> Model Class Initialized
INFO - 2020-10-09 07:04:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-09 07:04:04 --> Final output sent to browser
DEBUG - 2020-10-09 07:04:04 --> Total execution time: 0.0230
ERROR - 2020-10-09 07:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:04:25 --> Config Class Initialized
INFO - 2020-10-09 07:04:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:04:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:04:25 --> Utf8 Class Initialized
INFO - 2020-10-09 07:04:25 --> URI Class Initialized
INFO - 2020-10-09 07:04:25 --> Router Class Initialized
INFO - 2020-10-09 07:04:25 --> Output Class Initialized
INFO - 2020-10-09 07:04:25 --> Security Class Initialized
DEBUG - 2020-10-09 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:04:25 --> Input Class Initialized
INFO - 2020-10-09 07:04:25 --> Language Class Initialized
INFO - 2020-10-09 07:04:25 --> Loader Class Initialized
INFO - 2020-10-09 07:04:25 --> Helper loaded: url_helper
INFO - 2020-10-09 07:04:25 --> Database Driver Class Initialized
INFO - 2020-10-09 07:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:04:25 --> Email Class Initialized
INFO - 2020-10-09 07:04:25 --> Controller Class Initialized
DEBUG - 2020-10-09 07:04:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:04:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:04:25 --> Model Class Initialized
INFO - 2020-10-09 07:04:25 --> Model Class Initialized
INFO - 2020-10-09 07:04:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-09 07:04:25 --> Final output sent to browser
DEBUG - 2020-10-09 07:04:25 --> Total execution time: 0.0256
ERROR - 2020-10-09 07:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:04:32 --> Config Class Initialized
INFO - 2020-10-09 07:04:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:04:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:04:32 --> Utf8 Class Initialized
INFO - 2020-10-09 07:04:32 --> URI Class Initialized
INFO - 2020-10-09 07:04:32 --> Router Class Initialized
INFO - 2020-10-09 07:04:32 --> Output Class Initialized
INFO - 2020-10-09 07:04:32 --> Security Class Initialized
DEBUG - 2020-10-09 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:04:32 --> Input Class Initialized
INFO - 2020-10-09 07:04:32 --> Language Class Initialized
INFO - 2020-10-09 07:04:32 --> Loader Class Initialized
INFO - 2020-10-09 07:04:32 --> Helper loaded: url_helper
INFO - 2020-10-09 07:04:32 --> Database Driver Class Initialized
INFO - 2020-10-09 07:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:04:32 --> Email Class Initialized
INFO - 2020-10-09 07:04:32 --> Controller Class Initialized
DEBUG - 2020-10-09 07:04:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:04:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:04:32 --> Model Class Initialized
INFO - 2020-10-09 07:04:32 --> Model Class Initialized
INFO - 2020-10-09 07:04:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-09 07:04:32 --> Final output sent to browser
DEBUG - 2020-10-09 07:04:32 --> Total execution time: 0.0245
ERROR - 2020-10-09 07:04:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:04:37 --> Config Class Initialized
INFO - 2020-10-09 07:04:37 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:04:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:04:37 --> Utf8 Class Initialized
INFO - 2020-10-09 07:04:37 --> URI Class Initialized
INFO - 2020-10-09 07:04:37 --> Router Class Initialized
INFO - 2020-10-09 07:04:37 --> Output Class Initialized
INFO - 2020-10-09 07:04:37 --> Security Class Initialized
DEBUG - 2020-10-09 07:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:04:37 --> Input Class Initialized
INFO - 2020-10-09 07:04:37 --> Language Class Initialized
INFO - 2020-10-09 07:04:37 --> Loader Class Initialized
INFO - 2020-10-09 07:04:37 --> Helper loaded: url_helper
INFO - 2020-10-09 07:04:37 --> Database Driver Class Initialized
INFO - 2020-10-09 07:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:04:37 --> Email Class Initialized
INFO - 2020-10-09 07:04:37 --> Controller Class Initialized
DEBUG - 2020-10-09 07:04:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:04:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:04:37 --> Model Class Initialized
INFO - 2020-10-09 07:04:37 --> Model Class Initialized
INFO - 2020-10-09 07:04:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-09 07:04:37 --> Final output sent to browser
DEBUG - 2020-10-09 07:04:37 --> Total execution time: 0.0238
ERROR - 2020-10-09 07:05:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:01 --> Config Class Initialized
INFO - 2020-10-09 07:05:01 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:01 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:01 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:01 --> URI Class Initialized
DEBUG - 2020-10-09 07:05:01 --> No URI present. Default controller set.
INFO - 2020-10-09 07:05:01 --> Router Class Initialized
INFO - 2020-10-09 07:05:01 --> Output Class Initialized
INFO - 2020-10-09 07:05:01 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:01 --> Input Class Initialized
INFO - 2020-10-09 07:05:01 --> Language Class Initialized
INFO - 2020-10-09 07:05:01 --> Loader Class Initialized
INFO - 2020-10-09 07:05:01 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:01 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:01 --> Email Class Initialized
INFO - 2020-10-09 07:05:01 --> Controller Class Initialized
INFO - 2020-10-09 07:05:01 --> Model Class Initialized
INFO - 2020-10-09 07:05:01 --> Model Class Initialized
DEBUG - 2020-10-09 07:05:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:05:01 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:01 --> Total execution time: 0.0224
ERROR - 2020-10-09 07:05:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:21 --> Config Class Initialized
INFO - 2020-10-09 07:05:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:21 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:21 --> URI Class Initialized
INFO - 2020-10-09 07:05:21 --> Router Class Initialized
INFO - 2020-10-09 07:05:21 --> Output Class Initialized
INFO - 2020-10-09 07:05:21 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:21 --> Input Class Initialized
INFO - 2020-10-09 07:05:21 --> Language Class Initialized
INFO - 2020-10-09 07:05:21 --> Loader Class Initialized
INFO - 2020-10-09 07:05:21 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:21 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:21 --> Email Class Initialized
INFO - 2020-10-09 07:05:21 --> Controller Class Initialized
INFO - 2020-10-09 07:05:21 --> Model Class Initialized
INFO - 2020-10-09 07:05:21 --> Model Class Initialized
DEBUG - 2020-10-09 07:05:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:05:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:21 --> Model Class Initialized
INFO - 2020-10-09 07:05:21 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:21 --> Total execution time: 0.0241
ERROR - 2020-10-09 07:05:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:22 --> Config Class Initialized
INFO - 2020-10-09 07:05:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:22 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:22 --> URI Class Initialized
INFO - 2020-10-09 07:05:22 --> Router Class Initialized
INFO - 2020-10-09 07:05:22 --> Output Class Initialized
INFO - 2020-10-09 07:05:22 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:22 --> Input Class Initialized
INFO - 2020-10-09 07:05:22 --> Language Class Initialized
INFO - 2020-10-09 07:05:22 --> Loader Class Initialized
INFO - 2020-10-09 07:05:22 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:22 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:22 --> Email Class Initialized
INFO - 2020-10-09 07:05:22 --> Controller Class Initialized
INFO - 2020-10-09 07:05:22 --> Model Class Initialized
INFO - 2020-10-09 07:05:22 --> Model Class Initialized
DEBUG - 2020-10-09 07:05:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 07:05:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:22 --> Config Class Initialized
INFO - 2020-10-09 07:05:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:22 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:22 --> URI Class Initialized
INFO - 2020-10-09 07:05:22 --> Router Class Initialized
INFO - 2020-10-09 07:05:22 --> Output Class Initialized
INFO - 2020-10-09 07:05:22 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:22 --> Input Class Initialized
INFO - 2020-10-09 07:05:22 --> Language Class Initialized
INFO - 2020-10-09 07:05:22 --> Loader Class Initialized
INFO - 2020-10-09 07:05:22 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:22 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:22 --> Email Class Initialized
INFO - 2020-10-09 07:05:22 --> Controller Class Initialized
DEBUG - 2020-10-09 07:05:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:05:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:22 --> Model Class Initialized
INFO - 2020-10-09 07:05:22 --> Model Class Initialized
INFO - 2020-10-09 07:05:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 07:05:22 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:22 --> Total execution time: 0.0311
ERROR - 2020-10-09 07:05:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:32 --> Config Class Initialized
INFO - 2020-10-09 07:05:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:32 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:32 --> URI Class Initialized
INFO - 2020-10-09 07:05:32 --> Router Class Initialized
INFO - 2020-10-09 07:05:32 --> Output Class Initialized
INFO - 2020-10-09 07:05:32 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:32 --> Input Class Initialized
INFO - 2020-10-09 07:05:32 --> Language Class Initialized
INFO - 2020-10-09 07:05:32 --> Loader Class Initialized
INFO - 2020-10-09 07:05:32 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:32 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:32 --> Email Class Initialized
INFO - 2020-10-09 07:05:32 --> Controller Class Initialized
DEBUG - 2020-10-09 07:05:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:05:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:32 --> Model Class Initialized
INFO - 2020-10-09 07:05:32 --> Model Class Initialized
INFO - 2020-10-09 07:05:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-09 07:05:33 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:33 --> Total execution time: 0.0286
ERROR - 2020-10-09 07:05:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:44 --> Config Class Initialized
INFO - 2020-10-09 07:05:44 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:44 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:44 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:44 --> URI Class Initialized
INFO - 2020-10-09 07:05:44 --> Router Class Initialized
INFO - 2020-10-09 07:05:44 --> Output Class Initialized
INFO - 2020-10-09 07:05:44 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:44 --> Input Class Initialized
INFO - 2020-10-09 07:05:44 --> Language Class Initialized
INFO - 2020-10-09 07:05:44 --> Loader Class Initialized
INFO - 2020-10-09 07:05:44 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:44 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:44 --> Email Class Initialized
INFO - 2020-10-09 07:05:44 --> Controller Class Initialized
DEBUG - 2020-10-09 07:05:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:05:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:44 --> Model Class Initialized
INFO - 2020-10-09 07:05:44 --> Model Class Initialized
INFO - 2020-10-09 07:05:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 07:05:44 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:44 --> Total execution time: 0.0242
ERROR - 2020-10-09 07:05:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:50 --> Config Class Initialized
INFO - 2020-10-09 07:05:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:50 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:50 --> URI Class Initialized
INFO - 2020-10-09 07:05:50 --> Router Class Initialized
INFO - 2020-10-09 07:05:50 --> Output Class Initialized
INFO - 2020-10-09 07:05:50 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:50 --> Input Class Initialized
INFO - 2020-10-09 07:05:50 --> Language Class Initialized
INFO - 2020-10-09 07:05:50 --> Loader Class Initialized
INFO - 2020-10-09 07:05:50 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:50 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:50 --> Email Class Initialized
INFO - 2020-10-09 07:05:50 --> Controller Class Initialized
DEBUG - 2020-10-09 07:05:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:05:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:50 --> Model Class Initialized
INFO - 2020-10-09 07:05:50 --> Model Class Initialized
INFO - 2020-10-09 07:05:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 07:05:50 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:50 --> Total execution time: 0.0269
ERROR - 2020-10-09 07:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:05:51 --> Config Class Initialized
INFO - 2020-10-09 07:05:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:05:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:05:51 --> Utf8 Class Initialized
INFO - 2020-10-09 07:05:51 --> URI Class Initialized
INFO - 2020-10-09 07:05:51 --> Router Class Initialized
INFO - 2020-10-09 07:05:51 --> Output Class Initialized
INFO - 2020-10-09 07:05:51 --> Security Class Initialized
DEBUG - 2020-10-09 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:05:51 --> Input Class Initialized
INFO - 2020-10-09 07:05:51 --> Language Class Initialized
INFO - 2020-10-09 07:05:51 --> Loader Class Initialized
INFO - 2020-10-09 07:05:51 --> Helper loaded: url_helper
INFO - 2020-10-09 07:05:51 --> Database Driver Class Initialized
INFO - 2020-10-09 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:05:51 --> Email Class Initialized
INFO - 2020-10-09 07:05:51 --> Controller Class Initialized
DEBUG - 2020-10-09 07:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:05:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:05:51 --> Model Class Initialized
INFO - 2020-10-09 07:05:51 --> Model Class Initialized
INFO - 2020-10-09 07:05:51 --> Final output sent to browser
DEBUG - 2020-10-09 07:05:51 --> Total execution time: 0.0253
ERROR - 2020-10-09 07:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:02 --> Config Class Initialized
INFO - 2020-10-09 07:06:02 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:02 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:02 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:02 --> URI Class Initialized
INFO - 2020-10-09 07:06:02 --> Router Class Initialized
INFO - 2020-10-09 07:06:02 --> Output Class Initialized
INFO - 2020-10-09 07:06:02 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:02 --> Input Class Initialized
INFO - 2020-10-09 07:06:02 --> Language Class Initialized
INFO - 2020-10-09 07:06:02 --> Loader Class Initialized
INFO - 2020-10-09 07:06:02 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:02 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:02 --> Email Class Initialized
INFO - 2020-10-09 07:06:02 --> Controller Class Initialized
DEBUG - 2020-10-09 07:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:06:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:02 --> Model Class Initialized
INFO - 2020-10-09 07:06:02 --> Model Class Initialized
INFO - 2020-10-09 07:06:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 07:06:02 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:02 --> Total execution time: 0.0423
ERROR - 2020-10-09 07:06:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:03 --> Config Class Initialized
INFO - 2020-10-09 07:06:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:03 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:03 --> URI Class Initialized
INFO - 2020-10-09 07:06:03 --> Router Class Initialized
INFO - 2020-10-09 07:06:03 --> Output Class Initialized
INFO - 2020-10-09 07:06:03 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:03 --> Input Class Initialized
INFO - 2020-10-09 07:06:03 --> Language Class Initialized
INFO - 2020-10-09 07:06:03 --> Loader Class Initialized
INFO - 2020-10-09 07:06:03 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:03 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:03 --> Email Class Initialized
INFO - 2020-10-09 07:06:03 --> Controller Class Initialized
DEBUG - 2020-10-09 07:06:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:06:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:03 --> Model Class Initialized
INFO - 2020-10-09 07:06:03 --> Model Class Initialized
INFO - 2020-10-09 07:06:03 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:03 --> Total execution time: 0.0241
ERROR - 2020-10-09 07:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:19 --> Config Class Initialized
INFO - 2020-10-09 07:06:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:19 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:19 --> URI Class Initialized
INFO - 2020-10-09 07:06:19 --> Router Class Initialized
INFO - 2020-10-09 07:06:19 --> Output Class Initialized
INFO - 2020-10-09 07:06:19 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:19 --> Input Class Initialized
INFO - 2020-10-09 07:06:19 --> Language Class Initialized
INFO - 2020-10-09 07:06:19 --> Loader Class Initialized
INFO - 2020-10-09 07:06:19 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:19 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:19 --> Email Class Initialized
INFO - 2020-10-09 07:06:19 --> Controller Class Initialized
DEBUG - 2020-10-09 07:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:06:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:19 --> Model Class Initialized
INFO - 2020-10-09 07:06:19 --> Model Class Initialized
INFO - 2020-10-09 07:06:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 07:06:19 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:19 --> Total execution time: 0.0272
ERROR - 2020-10-09 07:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:20 --> Config Class Initialized
INFO - 2020-10-09 07:06:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:20 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:20 --> URI Class Initialized
INFO - 2020-10-09 07:06:20 --> Router Class Initialized
INFO - 2020-10-09 07:06:20 --> Output Class Initialized
INFO - 2020-10-09 07:06:20 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:20 --> Input Class Initialized
INFO - 2020-10-09 07:06:20 --> Language Class Initialized
INFO - 2020-10-09 07:06:20 --> Loader Class Initialized
INFO - 2020-10-09 07:06:20 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:20 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:20 --> Email Class Initialized
INFO - 2020-10-09 07:06:20 --> Controller Class Initialized
DEBUG - 2020-10-09 07:06:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:06:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:20 --> Model Class Initialized
INFO - 2020-10-09 07:06:20 --> Model Class Initialized
INFO - 2020-10-09 07:06:20 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:20 --> Total execution time: 0.0236
ERROR - 2020-10-09 07:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:29 --> Config Class Initialized
INFO - 2020-10-09 07:06:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:29 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:29 --> URI Class Initialized
INFO - 2020-10-09 07:06:29 --> Router Class Initialized
INFO - 2020-10-09 07:06:29 --> Output Class Initialized
INFO - 2020-10-09 07:06:29 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:29 --> Input Class Initialized
INFO - 2020-10-09 07:06:29 --> Language Class Initialized
INFO - 2020-10-09 07:06:29 --> Loader Class Initialized
INFO - 2020-10-09 07:06:29 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:29 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:29 --> Email Class Initialized
INFO - 2020-10-09 07:06:29 --> Controller Class Initialized
DEBUG - 2020-10-09 07:06:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:06:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:29 --> Model Class Initialized
INFO - 2020-10-09 07:06:29 --> Model Class Initialized
INFO - 2020-10-09 07:06:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 07:06:29 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:29 --> Total execution time: 0.0262
ERROR - 2020-10-09 07:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:30 --> Config Class Initialized
INFO - 2020-10-09 07:06:30 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:30 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:30 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:30 --> URI Class Initialized
INFO - 2020-10-09 07:06:30 --> Router Class Initialized
INFO - 2020-10-09 07:06:30 --> Output Class Initialized
INFO - 2020-10-09 07:06:30 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:30 --> Input Class Initialized
INFO - 2020-10-09 07:06:30 --> Language Class Initialized
INFO - 2020-10-09 07:06:30 --> Loader Class Initialized
INFO - 2020-10-09 07:06:30 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:30 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:30 --> Email Class Initialized
INFO - 2020-10-09 07:06:30 --> Controller Class Initialized
DEBUG - 2020-10-09 07:06:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:06:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:30 --> Model Class Initialized
INFO - 2020-10-09 07:06:30 --> Model Class Initialized
INFO - 2020-10-09 07:06:30 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:30 --> Total execution time: 0.0208
ERROR - 2020-10-09 07:06:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:06:58 --> Config Class Initialized
INFO - 2020-10-09 07:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:06:58 --> Utf8 Class Initialized
INFO - 2020-10-09 07:06:58 --> URI Class Initialized
DEBUG - 2020-10-09 07:06:58 --> No URI present. Default controller set.
INFO - 2020-10-09 07:06:58 --> Router Class Initialized
INFO - 2020-10-09 07:06:58 --> Output Class Initialized
INFO - 2020-10-09 07:06:58 --> Security Class Initialized
DEBUG - 2020-10-09 07:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:06:58 --> Input Class Initialized
INFO - 2020-10-09 07:06:58 --> Language Class Initialized
INFO - 2020-10-09 07:06:58 --> Loader Class Initialized
INFO - 2020-10-09 07:06:58 --> Helper loaded: url_helper
INFO - 2020-10-09 07:06:58 --> Database Driver Class Initialized
INFO - 2020-10-09 07:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:06:58 --> Email Class Initialized
INFO - 2020-10-09 07:06:58 --> Controller Class Initialized
INFO - 2020-10-09 07:06:58 --> Model Class Initialized
INFO - 2020-10-09 07:06:58 --> Model Class Initialized
DEBUG - 2020-10-09 07:06:58 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:06:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:06:58 --> Final output sent to browser
DEBUG - 2020-10-09 07:06:58 --> Total execution time: 0.0176
ERROR - 2020-10-09 07:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:18 --> Config Class Initialized
INFO - 2020-10-09 07:07:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:18 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:18 --> URI Class Initialized
INFO - 2020-10-09 07:07:18 --> Router Class Initialized
INFO - 2020-10-09 07:07:18 --> Output Class Initialized
INFO - 2020-10-09 07:07:18 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:18 --> Input Class Initialized
INFO - 2020-10-09 07:07:18 --> Language Class Initialized
INFO - 2020-10-09 07:07:18 --> Loader Class Initialized
INFO - 2020-10-09 07:07:18 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:18 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:18 --> Email Class Initialized
INFO - 2020-10-09 07:07:18 --> Controller Class Initialized
INFO - 2020-10-09 07:07:18 --> Model Class Initialized
INFO - 2020-10-09 07:07:18 --> Model Class Initialized
DEBUG - 2020-10-09 07:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:07:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:18 --> Model Class Initialized
INFO - 2020-10-09 07:07:18 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:18 --> Total execution time: 0.0219
ERROR - 2020-10-09 07:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:18 --> Config Class Initialized
INFO - 2020-10-09 07:07:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:18 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:18 --> URI Class Initialized
INFO - 2020-10-09 07:07:18 --> Router Class Initialized
INFO - 2020-10-09 07:07:18 --> Output Class Initialized
INFO - 2020-10-09 07:07:18 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:18 --> Input Class Initialized
INFO - 2020-10-09 07:07:18 --> Language Class Initialized
INFO - 2020-10-09 07:07:18 --> Loader Class Initialized
INFO - 2020-10-09 07:07:18 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:18 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:18 --> Email Class Initialized
INFO - 2020-10-09 07:07:18 --> Controller Class Initialized
INFO - 2020-10-09 07:07:18 --> Model Class Initialized
INFO - 2020-10-09 07:07:18 --> Model Class Initialized
DEBUG - 2020-10-09 07:07:18 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 07:07:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:19 --> Config Class Initialized
INFO - 2020-10-09 07:07:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:19 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:19 --> URI Class Initialized
INFO - 2020-10-09 07:07:19 --> Router Class Initialized
INFO - 2020-10-09 07:07:19 --> Output Class Initialized
INFO - 2020-10-09 07:07:19 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:19 --> Input Class Initialized
INFO - 2020-10-09 07:07:19 --> Language Class Initialized
INFO - 2020-10-09 07:07:19 --> Loader Class Initialized
INFO - 2020-10-09 07:07:19 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:19 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:19 --> Email Class Initialized
INFO - 2020-10-09 07:07:19 --> Controller Class Initialized
DEBUG - 2020-10-09 07:07:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:07:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:19 --> Model Class Initialized
INFO - 2020-10-09 07:07:19 --> Model Class Initialized
INFO - 2020-10-09 07:07:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 07:07:19 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:19 --> Total execution time: 0.0255
ERROR - 2020-10-09 07:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:25 --> Config Class Initialized
INFO - 2020-10-09 07:07:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:25 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:25 --> URI Class Initialized
INFO - 2020-10-09 07:07:25 --> Router Class Initialized
INFO - 2020-10-09 07:07:25 --> Output Class Initialized
INFO - 2020-10-09 07:07:25 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:25 --> Input Class Initialized
INFO - 2020-10-09 07:07:25 --> Language Class Initialized
INFO - 2020-10-09 07:07:25 --> Loader Class Initialized
INFO - 2020-10-09 07:07:25 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:25 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:25 --> Email Class Initialized
INFO - 2020-10-09 07:07:25 --> Controller Class Initialized
DEBUG - 2020-10-09 07:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:07:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:25 --> Model Class Initialized
INFO - 2020-10-09 07:07:25 --> Model Class Initialized
INFO - 2020-10-09 07:07:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-09 07:07:25 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:25 --> Total execution time: 0.0360
ERROR - 2020-10-09 07:07:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:28 --> Config Class Initialized
INFO - 2020-10-09 07:07:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:28 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:28 --> URI Class Initialized
INFO - 2020-10-09 07:07:28 --> Router Class Initialized
INFO - 2020-10-09 07:07:28 --> Output Class Initialized
INFO - 2020-10-09 07:07:28 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:28 --> Input Class Initialized
INFO - 2020-10-09 07:07:28 --> Language Class Initialized
INFO - 2020-10-09 07:07:28 --> Loader Class Initialized
INFO - 2020-10-09 07:07:28 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:28 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:28 --> Email Class Initialized
INFO - 2020-10-09 07:07:28 --> Controller Class Initialized
DEBUG - 2020-10-09 07:07:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:07:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:28 --> Model Class Initialized
INFO - 2020-10-09 07:07:28 --> Model Class Initialized
INFO - 2020-10-09 07:07:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 07:07:28 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:28 --> Total execution time: 0.0260
ERROR - 2020-10-09 07:07:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:36 --> Config Class Initialized
INFO - 2020-10-09 07:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:36 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:36 --> URI Class Initialized
DEBUG - 2020-10-09 07:07:36 --> No URI present. Default controller set.
INFO - 2020-10-09 07:07:36 --> Router Class Initialized
INFO - 2020-10-09 07:07:36 --> Output Class Initialized
INFO - 2020-10-09 07:07:36 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:36 --> Input Class Initialized
INFO - 2020-10-09 07:07:36 --> Language Class Initialized
INFO - 2020-10-09 07:07:36 --> Loader Class Initialized
INFO - 2020-10-09 07:07:36 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:37 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:37 --> Email Class Initialized
INFO - 2020-10-09 07:07:37 --> Controller Class Initialized
INFO - 2020-10-09 07:07:37 --> Model Class Initialized
INFO - 2020-10-09 07:07:37 --> Model Class Initialized
DEBUG - 2020-10-09 07:07:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:07:37 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:37 --> Total execution time: 0.0160
ERROR - 2020-10-09 07:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:50 --> Config Class Initialized
INFO - 2020-10-09 07:07:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:50 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:50 --> URI Class Initialized
INFO - 2020-10-09 07:07:50 --> Router Class Initialized
INFO - 2020-10-09 07:07:50 --> Output Class Initialized
INFO - 2020-10-09 07:07:50 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:50 --> Input Class Initialized
INFO - 2020-10-09 07:07:50 --> Language Class Initialized
INFO - 2020-10-09 07:07:50 --> Loader Class Initialized
INFO - 2020-10-09 07:07:50 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:50 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:50 --> Email Class Initialized
INFO - 2020-10-09 07:07:50 --> Controller Class Initialized
INFO - 2020-10-09 07:07:50 --> Model Class Initialized
INFO - 2020-10-09 07:07:50 --> Model Class Initialized
DEBUG - 2020-10-09 07:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:07:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:50 --> Model Class Initialized
INFO - 2020-10-09 07:07:50 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:50 --> Total execution time: 0.0192
ERROR - 2020-10-09 07:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:51 --> Config Class Initialized
INFO - 2020-10-09 07:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:51 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:51 --> URI Class Initialized
INFO - 2020-10-09 07:07:51 --> Router Class Initialized
INFO - 2020-10-09 07:07:51 --> Output Class Initialized
INFO - 2020-10-09 07:07:51 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:51 --> Input Class Initialized
INFO - 2020-10-09 07:07:51 --> Language Class Initialized
INFO - 2020-10-09 07:07:51 --> Loader Class Initialized
INFO - 2020-10-09 07:07:51 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:51 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:51 --> Email Class Initialized
INFO - 2020-10-09 07:07:51 --> Controller Class Initialized
INFO - 2020-10-09 07:07:51 --> Model Class Initialized
INFO - 2020-10-09 07:07:51 --> Model Class Initialized
DEBUG - 2020-10-09 07:07:51 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 07:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:07:51 --> Config Class Initialized
INFO - 2020-10-09 07:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:07:51 --> Utf8 Class Initialized
INFO - 2020-10-09 07:07:51 --> URI Class Initialized
INFO - 2020-10-09 07:07:51 --> Router Class Initialized
INFO - 2020-10-09 07:07:51 --> Output Class Initialized
INFO - 2020-10-09 07:07:51 --> Security Class Initialized
DEBUG - 2020-10-09 07:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:07:51 --> Input Class Initialized
INFO - 2020-10-09 07:07:51 --> Language Class Initialized
INFO - 2020-10-09 07:07:51 --> Loader Class Initialized
INFO - 2020-10-09 07:07:51 --> Helper loaded: url_helper
INFO - 2020-10-09 07:07:51 --> Database Driver Class Initialized
INFO - 2020-10-09 07:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:07:51 --> Email Class Initialized
INFO - 2020-10-09 07:07:51 --> Controller Class Initialized
DEBUG - 2020-10-09 07:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:07:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:07:51 --> Model Class Initialized
INFO - 2020-10-09 07:07:51 --> Model Class Initialized
INFO - 2020-10-09 07:07:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:07:51 --> Final output sent to browser
DEBUG - 2020-10-09 07:07:51 --> Total execution time: 0.0240
ERROR - 2020-10-09 07:08:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:08:08 --> Config Class Initialized
INFO - 2020-10-09 07:08:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:08:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:08:08 --> Utf8 Class Initialized
INFO - 2020-10-09 07:08:08 --> URI Class Initialized
INFO - 2020-10-09 07:08:08 --> Router Class Initialized
INFO - 2020-10-09 07:08:08 --> Output Class Initialized
INFO - 2020-10-09 07:08:08 --> Security Class Initialized
DEBUG - 2020-10-09 07:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:08:08 --> Input Class Initialized
INFO - 2020-10-09 07:08:08 --> Language Class Initialized
INFO - 2020-10-09 07:08:08 --> Loader Class Initialized
INFO - 2020-10-09 07:08:08 --> Helper loaded: url_helper
INFO - 2020-10-09 07:08:08 --> Database Driver Class Initialized
INFO - 2020-10-09 07:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:08:08 --> Email Class Initialized
INFO - 2020-10-09 07:08:08 --> Controller Class Initialized
DEBUG - 2020-10-09 07:08:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:08:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:08:08 --> Model Class Initialized
INFO - 2020-10-09 07:08:08 --> Model Class Initialized
INFO - 2020-10-09 07:08:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:08:08 --> Final output sent to browser
DEBUG - 2020-10-09 07:08:08 --> Total execution time: 0.0410
ERROR - 2020-10-09 07:08:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:08:27 --> Config Class Initialized
INFO - 2020-10-09 07:08:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:08:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:08:27 --> Utf8 Class Initialized
INFO - 2020-10-09 07:08:27 --> URI Class Initialized
INFO - 2020-10-09 07:08:27 --> Router Class Initialized
INFO - 2020-10-09 07:08:27 --> Output Class Initialized
INFO - 2020-10-09 07:08:27 --> Security Class Initialized
DEBUG - 2020-10-09 07:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:08:27 --> Input Class Initialized
INFO - 2020-10-09 07:08:27 --> Language Class Initialized
INFO - 2020-10-09 07:08:27 --> Loader Class Initialized
INFO - 2020-10-09 07:08:27 --> Helper loaded: url_helper
INFO - 2020-10-09 07:08:27 --> Database Driver Class Initialized
INFO - 2020-10-09 07:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:08:27 --> Email Class Initialized
INFO - 2020-10-09 07:08:27 --> Controller Class Initialized
DEBUG - 2020-10-09 07:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:08:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:08:27 --> Model Class Initialized
INFO - 2020-10-09 07:08:27 --> Model Class Initialized
INFO - 2020-10-09 07:08:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:08:27 --> Final output sent to browser
DEBUG - 2020-10-09 07:08:27 --> Total execution time: 0.0275
ERROR - 2020-10-09 07:08:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:08:31 --> Config Class Initialized
INFO - 2020-10-09 07:08:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:08:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:08:31 --> Utf8 Class Initialized
INFO - 2020-10-09 07:08:31 --> URI Class Initialized
INFO - 2020-10-09 07:08:31 --> Router Class Initialized
INFO - 2020-10-09 07:08:31 --> Output Class Initialized
INFO - 2020-10-09 07:08:31 --> Security Class Initialized
DEBUG - 2020-10-09 07:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:08:31 --> Input Class Initialized
INFO - 2020-10-09 07:08:31 --> Language Class Initialized
INFO - 2020-10-09 07:08:31 --> Loader Class Initialized
INFO - 2020-10-09 07:08:31 --> Helper loaded: url_helper
INFO - 2020-10-09 07:08:31 --> Database Driver Class Initialized
INFO - 2020-10-09 07:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:08:31 --> Email Class Initialized
INFO - 2020-10-09 07:08:31 --> Controller Class Initialized
DEBUG - 2020-10-09 07:08:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:08:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:08:31 --> Model Class Initialized
INFO - 2020-10-09 07:08:31 --> Model Class Initialized
INFO - 2020-10-09 07:08:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 07:08:31 --> Final output sent to browser
DEBUG - 2020-10-09 07:08:31 --> Total execution time: 0.0361
ERROR - 2020-10-09 07:08:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:08:39 --> Config Class Initialized
INFO - 2020-10-09 07:08:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:08:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:08:39 --> Utf8 Class Initialized
INFO - 2020-10-09 07:08:39 --> URI Class Initialized
INFO - 2020-10-09 07:08:39 --> Router Class Initialized
INFO - 2020-10-09 07:08:39 --> Output Class Initialized
INFO - 2020-10-09 07:08:39 --> Security Class Initialized
DEBUG - 2020-10-09 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:08:39 --> Input Class Initialized
INFO - 2020-10-09 07:08:39 --> Language Class Initialized
INFO - 2020-10-09 07:08:39 --> Loader Class Initialized
INFO - 2020-10-09 07:08:39 --> Helper loaded: url_helper
INFO - 2020-10-09 07:08:39 --> Database Driver Class Initialized
INFO - 2020-10-09 07:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:08:39 --> Email Class Initialized
INFO - 2020-10-09 07:08:39 --> Controller Class Initialized
DEBUG - 2020-10-09 07:08:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:08:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:08:39 --> Model Class Initialized
INFO - 2020-10-09 07:08:39 --> Model Class Initialized
INFO - 2020-10-09 07:08:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:08:39 --> Final output sent to browser
DEBUG - 2020-10-09 07:08:39 --> Total execution time: 0.0270
ERROR - 2020-10-09 07:08:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:08:44 --> Config Class Initialized
INFO - 2020-10-09 07:08:44 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:08:44 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:08:44 --> Utf8 Class Initialized
INFO - 2020-10-09 07:08:44 --> URI Class Initialized
INFO - 2020-10-09 07:08:44 --> Router Class Initialized
INFO - 2020-10-09 07:08:44 --> Output Class Initialized
INFO - 2020-10-09 07:08:44 --> Security Class Initialized
DEBUG - 2020-10-09 07:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:08:44 --> Input Class Initialized
INFO - 2020-10-09 07:08:44 --> Language Class Initialized
INFO - 2020-10-09 07:08:44 --> Loader Class Initialized
INFO - 2020-10-09 07:08:44 --> Helper loaded: url_helper
INFO - 2020-10-09 07:08:44 --> Database Driver Class Initialized
INFO - 2020-10-09 07:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:08:44 --> Email Class Initialized
INFO - 2020-10-09 07:08:44 --> Controller Class Initialized
DEBUG - 2020-10-09 07:08:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:08:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:08:44 --> Model Class Initialized
INFO - 2020-10-09 07:08:44 --> Model Class Initialized
INFO - 2020-10-09 07:08:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 07:08:44 --> Final output sent to browser
DEBUG - 2020-10-09 07:08:44 --> Total execution time: 0.0265
ERROR - 2020-10-09 07:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:09:07 --> Config Class Initialized
INFO - 2020-10-09 07:09:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:09:07 --> Utf8 Class Initialized
INFO - 2020-10-09 07:09:07 --> URI Class Initialized
INFO - 2020-10-09 07:09:07 --> Router Class Initialized
INFO - 2020-10-09 07:09:07 --> Output Class Initialized
INFO - 2020-10-09 07:09:07 --> Security Class Initialized
DEBUG - 2020-10-09 07:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:09:07 --> Input Class Initialized
INFO - 2020-10-09 07:09:07 --> Language Class Initialized
INFO - 2020-10-09 07:09:07 --> Loader Class Initialized
INFO - 2020-10-09 07:09:07 --> Helper loaded: url_helper
INFO - 2020-10-09 07:09:07 --> Database Driver Class Initialized
INFO - 2020-10-09 07:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:09:07 --> Email Class Initialized
INFO - 2020-10-09 07:09:07 --> Controller Class Initialized
DEBUG - 2020-10-09 07:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:09:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:09:07 --> Model Class Initialized
INFO - 2020-10-09 07:09:07 --> Model Class Initialized
INFO - 2020-10-09 07:09:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:09:07 --> Final output sent to browser
DEBUG - 2020-10-09 07:09:07 --> Total execution time: 0.0251
ERROR - 2020-10-09 07:09:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:09:23 --> Config Class Initialized
INFO - 2020-10-09 07:09:23 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:09:23 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:09:23 --> Utf8 Class Initialized
INFO - 2020-10-09 07:09:23 --> URI Class Initialized
INFO - 2020-10-09 07:09:23 --> Router Class Initialized
INFO - 2020-10-09 07:09:23 --> Output Class Initialized
INFO - 2020-10-09 07:09:23 --> Security Class Initialized
DEBUG - 2020-10-09 07:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:09:23 --> Input Class Initialized
INFO - 2020-10-09 07:09:23 --> Language Class Initialized
INFO - 2020-10-09 07:09:23 --> Loader Class Initialized
INFO - 2020-10-09 07:09:23 --> Helper loaded: url_helper
INFO - 2020-10-09 07:09:23 --> Database Driver Class Initialized
INFO - 2020-10-09 07:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:09:23 --> Email Class Initialized
INFO - 2020-10-09 07:09:23 --> Controller Class Initialized
DEBUG - 2020-10-09 07:09:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:09:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:09:23 --> Model Class Initialized
INFO - 2020-10-09 07:09:23 --> Model Class Initialized
INFO - 2020-10-09 07:09:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:09:23 --> Final output sent to browser
DEBUG - 2020-10-09 07:09:23 --> Total execution time: 0.0214
ERROR - 2020-10-09 07:09:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:09:27 --> Config Class Initialized
INFO - 2020-10-09 07:09:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:09:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:09:27 --> Utf8 Class Initialized
INFO - 2020-10-09 07:09:27 --> URI Class Initialized
INFO - 2020-10-09 07:09:27 --> Router Class Initialized
INFO - 2020-10-09 07:09:27 --> Output Class Initialized
INFO - 2020-10-09 07:09:27 --> Security Class Initialized
DEBUG - 2020-10-09 07:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:09:27 --> Input Class Initialized
INFO - 2020-10-09 07:09:27 --> Language Class Initialized
INFO - 2020-10-09 07:09:27 --> Loader Class Initialized
INFO - 2020-10-09 07:09:27 --> Helper loaded: url_helper
INFO - 2020-10-09 07:09:27 --> Database Driver Class Initialized
INFO - 2020-10-09 07:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:09:27 --> Email Class Initialized
INFO - 2020-10-09 07:09:27 --> Controller Class Initialized
DEBUG - 2020-10-09 07:09:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:09:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:09:27 --> Model Class Initialized
INFO - 2020-10-09 07:09:27 --> Model Class Initialized
INFO - 2020-10-09 07:09:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:09:27 --> Final output sent to browser
DEBUG - 2020-10-09 07:09:27 --> Total execution time: 0.0241
ERROR - 2020-10-09 07:09:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:09:55 --> Config Class Initialized
INFO - 2020-10-09 07:09:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:09:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:09:55 --> Utf8 Class Initialized
INFO - 2020-10-09 07:09:55 --> URI Class Initialized
INFO - 2020-10-09 07:09:55 --> Router Class Initialized
INFO - 2020-10-09 07:09:55 --> Output Class Initialized
INFO - 2020-10-09 07:09:55 --> Security Class Initialized
DEBUG - 2020-10-09 07:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:09:55 --> Input Class Initialized
INFO - 2020-10-09 07:09:55 --> Language Class Initialized
INFO - 2020-10-09 07:09:55 --> Loader Class Initialized
INFO - 2020-10-09 07:09:55 --> Helper loaded: url_helper
INFO - 2020-10-09 07:09:55 --> Database Driver Class Initialized
INFO - 2020-10-09 07:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:09:55 --> Email Class Initialized
INFO - 2020-10-09 07:09:55 --> Controller Class Initialized
DEBUG - 2020-10-09 07:09:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:09:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:09:55 --> Model Class Initialized
INFO - 2020-10-09 07:09:55 --> Model Class Initialized
INFO - 2020-10-09 07:09:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:09:55 --> Final output sent to browser
DEBUG - 2020-10-09 07:09:55 --> Total execution time: 0.0251
ERROR - 2020-10-09 07:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:10:05 --> Config Class Initialized
INFO - 2020-10-09 07:10:05 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:10:05 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:10:05 --> Utf8 Class Initialized
INFO - 2020-10-09 07:10:05 --> URI Class Initialized
INFO - 2020-10-09 07:10:05 --> Router Class Initialized
INFO - 2020-10-09 07:10:05 --> Output Class Initialized
INFO - 2020-10-09 07:10:05 --> Security Class Initialized
DEBUG - 2020-10-09 07:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:10:05 --> Input Class Initialized
INFO - 2020-10-09 07:10:05 --> Language Class Initialized
INFO - 2020-10-09 07:10:05 --> Loader Class Initialized
INFO - 2020-10-09 07:10:05 --> Helper loaded: url_helper
INFO - 2020-10-09 07:10:05 --> Database Driver Class Initialized
INFO - 2020-10-09 07:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:10:05 --> Email Class Initialized
INFO - 2020-10-09 07:10:05 --> Controller Class Initialized
DEBUG - 2020-10-09 07:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:10:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:10:05 --> Model Class Initialized
INFO - 2020-10-09 07:10:05 --> Model Class Initialized
INFO - 2020-10-09 07:10:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 07:10:05 --> Final output sent to browser
DEBUG - 2020-10-09 07:10:05 --> Total execution time: 0.0259
ERROR - 2020-10-09 07:10:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:10:29 --> Config Class Initialized
INFO - 2020-10-09 07:10:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:10:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:10:29 --> Utf8 Class Initialized
INFO - 2020-10-09 07:10:29 --> URI Class Initialized
INFO - 2020-10-09 07:10:29 --> Router Class Initialized
INFO - 2020-10-09 07:10:29 --> Output Class Initialized
INFO - 2020-10-09 07:10:29 --> Security Class Initialized
DEBUG - 2020-10-09 07:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:10:29 --> Input Class Initialized
INFO - 2020-10-09 07:10:29 --> Language Class Initialized
INFO - 2020-10-09 07:10:29 --> Loader Class Initialized
INFO - 2020-10-09 07:10:29 --> Helper loaded: url_helper
INFO - 2020-10-09 07:10:29 --> Database Driver Class Initialized
INFO - 2020-10-09 07:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:10:29 --> Email Class Initialized
INFO - 2020-10-09 07:10:29 --> Controller Class Initialized
DEBUG - 2020-10-09 07:10:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:10:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:10:29 --> Model Class Initialized
INFO - 2020-10-09 07:10:29 --> Model Class Initialized
INFO - 2020-10-09 07:10:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:10:29 --> Final output sent to browser
DEBUG - 2020-10-09 07:10:29 --> Total execution time: 0.0316
ERROR - 2020-10-09 07:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:10:32 --> Config Class Initialized
INFO - 2020-10-09 07:10:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:10:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:10:32 --> Utf8 Class Initialized
INFO - 2020-10-09 07:10:32 --> URI Class Initialized
INFO - 2020-10-09 07:10:32 --> Router Class Initialized
INFO - 2020-10-09 07:10:32 --> Output Class Initialized
INFO - 2020-10-09 07:10:32 --> Security Class Initialized
DEBUG - 2020-10-09 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:10:32 --> Input Class Initialized
INFO - 2020-10-09 07:10:32 --> Language Class Initialized
INFO - 2020-10-09 07:10:32 --> Loader Class Initialized
INFO - 2020-10-09 07:10:32 --> Helper loaded: url_helper
INFO - 2020-10-09 07:10:32 --> Database Driver Class Initialized
INFO - 2020-10-09 07:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:10:32 --> Email Class Initialized
INFO - 2020-10-09 07:10:32 --> Controller Class Initialized
DEBUG - 2020-10-09 07:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:10:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:10:32 --> Model Class Initialized
INFO - 2020-10-09 07:10:32 --> Model Class Initialized
INFO - 2020-10-09 07:10:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:10:32 --> Final output sent to browser
DEBUG - 2020-10-09 07:10:32 --> Total execution time: 0.0253
ERROR - 2020-10-09 07:10:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:10:38 --> Config Class Initialized
INFO - 2020-10-09 07:10:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:10:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:10:38 --> Utf8 Class Initialized
INFO - 2020-10-09 07:10:38 --> URI Class Initialized
INFO - 2020-10-09 07:10:38 --> Router Class Initialized
INFO - 2020-10-09 07:10:38 --> Output Class Initialized
INFO - 2020-10-09 07:10:38 --> Security Class Initialized
DEBUG - 2020-10-09 07:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:10:38 --> Input Class Initialized
INFO - 2020-10-09 07:10:38 --> Language Class Initialized
INFO - 2020-10-09 07:10:38 --> Loader Class Initialized
INFO - 2020-10-09 07:10:38 --> Helper loaded: url_helper
INFO - 2020-10-09 07:10:38 --> Database Driver Class Initialized
INFO - 2020-10-09 07:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:10:38 --> Email Class Initialized
INFO - 2020-10-09 07:10:38 --> Controller Class Initialized
DEBUG - 2020-10-09 07:10:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:10:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:10:38 --> Model Class Initialized
INFO - 2020-10-09 07:10:38 --> Model Class Initialized
INFO - 2020-10-09 07:10:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:10:38 --> Final output sent to browser
DEBUG - 2020-10-09 07:10:38 --> Total execution time: 0.0249
ERROR - 2020-10-09 07:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:10:51 --> Config Class Initialized
INFO - 2020-10-09 07:10:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:10:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:10:51 --> Utf8 Class Initialized
INFO - 2020-10-09 07:10:51 --> URI Class Initialized
INFO - 2020-10-09 07:10:51 --> Router Class Initialized
INFO - 2020-10-09 07:10:51 --> Output Class Initialized
INFO - 2020-10-09 07:10:51 --> Security Class Initialized
DEBUG - 2020-10-09 07:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:10:51 --> Input Class Initialized
INFO - 2020-10-09 07:10:51 --> Language Class Initialized
INFO - 2020-10-09 07:10:51 --> Loader Class Initialized
INFO - 2020-10-09 07:10:51 --> Helper loaded: url_helper
INFO - 2020-10-09 07:10:51 --> Database Driver Class Initialized
INFO - 2020-10-09 07:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:10:51 --> Email Class Initialized
INFO - 2020-10-09 07:10:51 --> Controller Class Initialized
DEBUG - 2020-10-09 07:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:10:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:10:51 --> Model Class Initialized
INFO - 2020-10-09 07:10:51 --> Model Class Initialized
INFO - 2020-10-09 07:10:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:10:51 --> Final output sent to browser
DEBUG - 2020-10-09 07:10:51 --> Total execution time: 0.0268
ERROR - 2020-10-09 07:17:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:17:43 --> Config Class Initialized
INFO - 2020-10-09 07:17:43 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:17:43 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:17:43 --> Utf8 Class Initialized
INFO - 2020-10-09 07:17:43 --> URI Class Initialized
INFO - 2020-10-09 07:17:43 --> Router Class Initialized
INFO - 2020-10-09 07:17:43 --> Output Class Initialized
INFO - 2020-10-09 07:17:43 --> Security Class Initialized
DEBUG - 2020-10-09 07:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:17:43 --> Input Class Initialized
INFO - 2020-10-09 07:17:43 --> Language Class Initialized
INFO - 2020-10-09 07:17:43 --> Loader Class Initialized
INFO - 2020-10-09 07:17:43 --> Helper loaded: url_helper
INFO - 2020-10-09 07:17:43 --> Database Driver Class Initialized
INFO - 2020-10-09 07:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:17:43 --> Email Class Initialized
INFO - 2020-10-09 07:17:43 --> Controller Class Initialized
DEBUG - 2020-10-09 07:17:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:17:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:17:43 --> Model Class Initialized
INFO - 2020-10-09 07:17:43 --> Model Class Initialized
INFO - 2020-10-09 07:17:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:17:43 --> Final output sent to browser
DEBUG - 2020-10-09 07:17:43 --> Total execution time: 0.0355
ERROR - 2020-10-09 07:17:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:17:46 --> Config Class Initialized
INFO - 2020-10-09 07:17:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:17:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:17:46 --> Utf8 Class Initialized
INFO - 2020-10-09 07:17:46 --> URI Class Initialized
INFO - 2020-10-09 07:17:46 --> Router Class Initialized
INFO - 2020-10-09 07:17:46 --> Output Class Initialized
INFO - 2020-10-09 07:17:46 --> Security Class Initialized
DEBUG - 2020-10-09 07:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:17:46 --> Input Class Initialized
INFO - 2020-10-09 07:17:46 --> Language Class Initialized
INFO - 2020-10-09 07:17:46 --> Loader Class Initialized
INFO - 2020-10-09 07:17:46 --> Helper loaded: url_helper
INFO - 2020-10-09 07:17:46 --> Database Driver Class Initialized
INFO - 2020-10-09 07:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:17:46 --> Email Class Initialized
INFO - 2020-10-09 07:17:46 --> Controller Class Initialized
DEBUG - 2020-10-09 07:17:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:17:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:17:46 --> Model Class Initialized
INFO - 2020-10-09 07:17:46 --> Model Class Initialized
INFO - 2020-10-09 07:17:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 07:17:46 --> Final output sent to browser
DEBUG - 2020-10-09 07:17:46 --> Total execution time: 0.0257
ERROR - 2020-10-09 07:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:17:57 --> Config Class Initialized
INFO - 2020-10-09 07:17:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:17:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:17:57 --> Utf8 Class Initialized
INFO - 2020-10-09 07:17:57 --> URI Class Initialized
INFO - 2020-10-09 07:17:57 --> Router Class Initialized
INFO - 2020-10-09 07:17:57 --> Output Class Initialized
INFO - 2020-10-09 07:17:57 --> Security Class Initialized
DEBUG - 2020-10-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:17:57 --> Input Class Initialized
INFO - 2020-10-09 07:17:57 --> Language Class Initialized
INFO - 2020-10-09 07:17:57 --> Loader Class Initialized
INFO - 2020-10-09 07:17:57 --> Helper loaded: url_helper
INFO - 2020-10-09 07:17:57 --> Database Driver Class Initialized
INFO - 2020-10-09 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:17:57 --> Email Class Initialized
INFO - 2020-10-09 07:17:57 --> Controller Class Initialized
DEBUG - 2020-10-09 07:17:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:17:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:17:57 --> Model Class Initialized
INFO - 2020-10-09 07:17:57 --> Model Class Initialized
INFO - 2020-10-09 07:17:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:17:57 --> Final output sent to browser
DEBUG - 2020-10-09 07:17:57 --> Total execution time: 0.0262
ERROR - 2020-10-09 07:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:18:09 --> Config Class Initialized
INFO - 2020-10-09 07:18:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:18:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:18:09 --> Utf8 Class Initialized
INFO - 2020-10-09 07:18:09 --> URI Class Initialized
INFO - 2020-10-09 07:18:09 --> Router Class Initialized
INFO - 2020-10-09 07:18:09 --> Output Class Initialized
INFO - 2020-10-09 07:18:09 --> Security Class Initialized
DEBUG - 2020-10-09 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:18:09 --> Input Class Initialized
INFO - 2020-10-09 07:18:09 --> Language Class Initialized
INFO - 2020-10-09 07:18:09 --> Loader Class Initialized
INFO - 2020-10-09 07:18:09 --> Helper loaded: url_helper
INFO - 2020-10-09 07:18:09 --> Database Driver Class Initialized
INFO - 2020-10-09 07:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:18:09 --> Email Class Initialized
INFO - 2020-10-09 07:18:09 --> Controller Class Initialized
DEBUG - 2020-10-09 07:18:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:18:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:18:09 --> Model Class Initialized
INFO - 2020-10-09 07:18:09 --> Model Class Initialized
INFO - 2020-10-09 07:18:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 07:18:09 --> Final output sent to browser
DEBUG - 2020-10-09 07:18:09 --> Total execution time: 0.0241
ERROR - 2020-10-09 07:18:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:18:14 --> Config Class Initialized
INFO - 2020-10-09 07:18:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:18:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:18:14 --> Utf8 Class Initialized
INFO - 2020-10-09 07:18:14 --> URI Class Initialized
INFO - 2020-10-09 07:18:14 --> Router Class Initialized
INFO - 2020-10-09 07:18:14 --> Output Class Initialized
INFO - 2020-10-09 07:18:14 --> Security Class Initialized
DEBUG - 2020-10-09 07:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:18:14 --> Input Class Initialized
INFO - 2020-10-09 07:18:14 --> Language Class Initialized
INFO - 2020-10-09 07:18:14 --> Loader Class Initialized
INFO - 2020-10-09 07:18:14 --> Helper loaded: url_helper
INFO - 2020-10-09 07:18:14 --> Database Driver Class Initialized
INFO - 2020-10-09 07:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:18:14 --> Email Class Initialized
INFO - 2020-10-09 07:18:14 --> Controller Class Initialized
DEBUG - 2020-10-09 07:18:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:18:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:18:14 --> Model Class Initialized
INFO - 2020-10-09 07:18:14 --> Model Class Initialized
INFO - 2020-10-09 07:18:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:18:14 --> Final output sent to browser
DEBUG - 2020-10-09 07:18:14 --> Total execution time: 0.0217
ERROR - 2020-10-09 07:18:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:18:47 --> Config Class Initialized
INFO - 2020-10-09 07:18:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:18:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:18:47 --> Utf8 Class Initialized
INFO - 2020-10-09 07:18:47 --> URI Class Initialized
DEBUG - 2020-10-09 07:18:47 --> No URI present. Default controller set.
INFO - 2020-10-09 07:18:47 --> Router Class Initialized
INFO - 2020-10-09 07:18:47 --> Output Class Initialized
INFO - 2020-10-09 07:18:47 --> Security Class Initialized
DEBUG - 2020-10-09 07:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:18:47 --> Input Class Initialized
INFO - 2020-10-09 07:18:47 --> Language Class Initialized
INFO - 2020-10-09 07:18:47 --> Loader Class Initialized
INFO - 2020-10-09 07:18:47 --> Helper loaded: url_helper
INFO - 2020-10-09 07:18:47 --> Database Driver Class Initialized
INFO - 2020-10-09 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:18:47 --> Email Class Initialized
INFO - 2020-10-09 07:18:47 --> Controller Class Initialized
INFO - 2020-10-09 07:18:47 --> Model Class Initialized
INFO - 2020-10-09 07:18:47 --> Model Class Initialized
DEBUG - 2020-10-09 07:18:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:18:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:18:47 --> Final output sent to browser
DEBUG - 2020-10-09 07:18:47 --> Total execution time: 0.0204
ERROR - 2020-10-09 07:37:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:37:34 --> Config Class Initialized
INFO - 2020-10-09 07:37:34 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:37:34 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:37:34 --> Utf8 Class Initialized
INFO - 2020-10-09 07:37:34 --> URI Class Initialized
DEBUG - 2020-10-09 07:37:34 --> No URI present. Default controller set.
INFO - 2020-10-09 07:37:34 --> Router Class Initialized
INFO - 2020-10-09 07:37:34 --> Output Class Initialized
INFO - 2020-10-09 07:37:34 --> Security Class Initialized
DEBUG - 2020-10-09 07:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:37:34 --> Input Class Initialized
INFO - 2020-10-09 07:37:34 --> Language Class Initialized
INFO - 2020-10-09 07:37:34 --> Loader Class Initialized
INFO - 2020-10-09 07:37:34 --> Helper loaded: url_helper
INFO - 2020-10-09 07:37:34 --> Database Driver Class Initialized
INFO - 2020-10-09 07:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:37:34 --> Email Class Initialized
INFO - 2020-10-09 07:37:34 --> Controller Class Initialized
INFO - 2020-10-09 07:37:34 --> Model Class Initialized
INFO - 2020-10-09 07:37:34 --> Model Class Initialized
DEBUG - 2020-10-09 07:37:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:37:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:37:34 --> Final output sent to browser
DEBUG - 2020-10-09 07:37:34 --> Total execution time: 0.0235
ERROR - 2020-10-09 07:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:37:49 --> Config Class Initialized
INFO - 2020-10-09 07:37:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:37:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:37:49 --> Utf8 Class Initialized
INFO - 2020-10-09 07:37:49 --> URI Class Initialized
INFO - 2020-10-09 07:37:49 --> Router Class Initialized
INFO - 2020-10-09 07:37:49 --> Output Class Initialized
INFO - 2020-10-09 07:37:49 --> Security Class Initialized
DEBUG - 2020-10-09 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:37:49 --> Input Class Initialized
INFO - 2020-10-09 07:37:49 --> Language Class Initialized
INFO - 2020-10-09 07:37:49 --> Loader Class Initialized
INFO - 2020-10-09 07:37:49 --> Helper loaded: url_helper
INFO - 2020-10-09 07:37:49 --> Database Driver Class Initialized
INFO - 2020-10-09 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:37:49 --> Email Class Initialized
INFO - 2020-10-09 07:37:49 --> Controller Class Initialized
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
DEBUG - 2020-10-09 07:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:37:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
INFO - 2020-10-09 07:37:49 --> Final output sent to browser
DEBUG - 2020-10-09 07:37:49 --> Total execution time: 0.0214
ERROR - 2020-10-09 07:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:37:49 --> Config Class Initialized
INFO - 2020-10-09 07:37:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:37:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:37:49 --> Utf8 Class Initialized
INFO - 2020-10-09 07:37:49 --> URI Class Initialized
INFO - 2020-10-09 07:37:49 --> Router Class Initialized
INFO - 2020-10-09 07:37:49 --> Output Class Initialized
INFO - 2020-10-09 07:37:49 --> Security Class Initialized
DEBUG - 2020-10-09 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:37:49 --> Input Class Initialized
INFO - 2020-10-09 07:37:49 --> Language Class Initialized
INFO - 2020-10-09 07:37:49 --> Loader Class Initialized
INFO - 2020-10-09 07:37:49 --> Helper loaded: url_helper
INFO - 2020-10-09 07:37:49 --> Database Driver Class Initialized
INFO - 2020-10-09 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:37:49 --> Email Class Initialized
INFO - 2020-10-09 07:37:49 --> Controller Class Initialized
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
DEBUG - 2020-10-09 07:37:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 07:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:37:49 --> Config Class Initialized
INFO - 2020-10-09 07:37:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:37:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:37:49 --> Utf8 Class Initialized
INFO - 2020-10-09 07:37:49 --> URI Class Initialized
INFO - 2020-10-09 07:37:49 --> Router Class Initialized
INFO - 2020-10-09 07:37:49 --> Output Class Initialized
INFO - 2020-10-09 07:37:49 --> Security Class Initialized
DEBUG - 2020-10-09 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:37:49 --> Input Class Initialized
INFO - 2020-10-09 07:37:49 --> Language Class Initialized
INFO - 2020-10-09 07:37:49 --> Loader Class Initialized
INFO - 2020-10-09 07:37:49 --> Helper loaded: url_helper
INFO - 2020-10-09 07:37:49 --> Database Driver Class Initialized
INFO - 2020-10-09 07:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:37:49 --> Email Class Initialized
INFO - 2020-10-09 07:37:49 --> Controller Class Initialized
DEBUG - 2020-10-09 07:37:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 07:37:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
INFO - 2020-10-09 07:37:49 --> Model Class Initialized
INFO - 2020-10-09 07:37:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 07:37:49 --> Final output sent to browser
DEBUG - 2020-10-09 07:37:49 --> Total execution time: 0.1710
ERROR - 2020-10-09 07:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 07:38:07 --> Config Class Initialized
INFO - 2020-10-09 07:38:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 07:38:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 07:38:07 --> Utf8 Class Initialized
INFO - 2020-10-09 07:38:07 --> URI Class Initialized
DEBUG - 2020-10-09 07:38:07 --> No URI present. Default controller set.
INFO - 2020-10-09 07:38:07 --> Router Class Initialized
INFO - 2020-10-09 07:38:07 --> Output Class Initialized
INFO - 2020-10-09 07:38:07 --> Security Class Initialized
DEBUG - 2020-10-09 07:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 07:38:07 --> Input Class Initialized
INFO - 2020-10-09 07:38:07 --> Language Class Initialized
INFO - 2020-10-09 07:38:07 --> Loader Class Initialized
INFO - 2020-10-09 07:38:07 --> Helper loaded: url_helper
INFO - 2020-10-09 07:38:07 --> Database Driver Class Initialized
INFO - 2020-10-09 07:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 07:38:07 --> Email Class Initialized
INFO - 2020-10-09 07:38:07 --> Controller Class Initialized
INFO - 2020-10-09 07:38:07 --> Model Class Initialized
INFO - 2020-10-09 07:38:07 --> Model Class Initialized
DEBUG - 2020-10-09 07:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 07:38:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 07:38:07 --> Final output sent to browser
DEBUG - 2020-10-09 07:38:07 --> Total execution time: 0.0222
ERROR - 2020-10-09 09:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:47:27 --> Config Class Initialized
INFO - 2020-10-09 09:47:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:47:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:47:27 --> Utf8 Class Initialized
INFO - 2020-10-09 09:47:27 --> URI Class Initialized
DEBUG - 2020-10-09 09:47:27 --> No URI present. Default controller set.
INFO - 2020-10-09 09:47:27 --> Router Class Initialized
INFO - 2020-10-09 09:47:27 --> Output Class Initialized
INFO - 2020-10-09 09:47:27 --> Security Class Initialized
DEBUG - 2020-10-09 09:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:47:27 --> Input Class Initialized
INFO - 2020-10-09 09:47:27 --> Language Class Initialized
INFO - 2020-10-09 09:47:27 --> Loader Class Initialized
INFO - 2020-10-09 09:47:27 --> Helper loaded: url_helper
INFO - 2020-10-09 09:47:27 --> Database Driver Class Initialized
INFO - 2020-10-09 09:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:47:27 --> Email Class Initialized
INFO - 2020-10-09 09:47:27 --> Controller Class Initialized
INFO - 2020-10-09 09:47:27 --> Model Class Initialized
INFO - 2020-10-09 09:47:27 --> Model Class Initialized
DEBUG - 2020-10-09 09:47:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:47:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 09:47:27 --> Final output sent to browser
DEBUG - 2020-10-09 09:47:27 --> Total execution time: 0.0178
ERROR - 2020-10-09 09:47:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:47:54 --> Config Class Initialized
INFO - 2020-10-09 09:47:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:47:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:47:54 --> Utf8 Class Initialized
INFO - 2020-10-09 09:47:54 --> URI Class Initialized
INFO - 2020-10-09 09:47:54 --> Router Class Initialized
INFO - 2020-10-09 09:47:54 --> Output Class Initialized
INFO - 2020-10-09 09:47:54 --> Security Class Initialized
DEBUG - 2020-10-09 09:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:47:54 --> Input Class Initialized
INFO - 2020-10-09 09:47:54 --> Language Class Initialized
INFO - 2020-10-09 09:47:54 --> Loader Class Initialized
INFO - 2020-10-09 09:47:54 --> Helper loaded: url_helper
INFO - 2020-10-09 09:47:54 --> Database Driver Class Initialized
INFO - 2020-10-09 09:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:47:54 --> Email Class Initialized
INFO - 2020-10-09 09:47:54 --> Controller Class Initialized
INFO - 2020-10-09 09:47:54 --> Model Class Initialized
INFO - 2020-10-09 09:47:54 --> Model Class Initialized
DEBUG - 2020-10-09 09:47:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 09:47:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:47:55 --> Config Class Initialized
INFO - 2020-10-09 09:47:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:47:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:47:55 --> Utf8 Class Initialized
INFO - 2020-10-09 09:47:55 --> URI Class Initialized
INFO - 2020-10-09 09:47:55 --> Router Class Initialized
INFO - 2020-10-09 09:47:55 --> Output Class Initialized
INFO - 2020-10-09 09:47:55 --> Security Class Initialized
DEBUG - 2020-10-09 09:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:47:55 --> Input Class Initialized
INFO - 2020-10-09 09:47:55 --> Language Class Initialized
INFO - 2020-10-09 09:47:55 --> Loader Class Initialized
INFO - 2020-10-09 09:47:55 --> Helper loaded: url_helper
INFO - 2020-10-09 09:47:55 --> Database Driver Class Initialized
INFO - 2020-10-09 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:47:55 --> Email Class Initialized
INFO - 2020-10-09 09:47:55 --> Controller Class Initialized
INFO - 2020-10-09 09:47:55 --> Model Class Initialized
INFO - 2020-10-09 09:47:55 --> Model Class Initialized
DEBUG - 2020-10-09 09:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:47:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:47:55 --> Model Class Initialized
INFO - 2020-10-09 09:47:55 --> Final output sent to browser
DEBUG - 2020-10-09 09:47:55 --> Total execution time: 0.0222
ERROR - 2020-10-09 09:47:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:47:55 --> Config Class Initialized
INFO - 2020-10-09 09:47:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:47:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:47:55 --> Utf8 Class Initialized
INFO - 2020-10-09 09:47:55 --> URI Class Initialized
INFO - 2020-10-09 09:47:55 --> Router Class Initialized
INFO - 2020-10-09 09:47:55 --> Output Class Initialized
INFO - 2020-10-09 09:47:55 --> Security Class Initialized
DEBUG - 2020-10-09 09:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:47:55 --> Input Class Initialized
INFO - 2020-10-09 09:47:55 --> Language Class Initialized
INFO - 2020-10-09 09:47:55 --> Loader Class Initialized
INFO - 2020-10-09 09:47:55 --> Helper loaded: url_helper
INFO - 2020-10-09 09:47:55 --> Database Driver Class Initialized
INFO - 2020-10-09 09:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:47:55 --> Email Class Initialized
INFO - 2020-10-09 09:47:55 --> Controller Class Initialized
DEBUG - 2020-10-09 09:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:47:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:47:55 --> Model Class Initialized
INFO - 2020-10-09 09:47:55 --> Model Class Initialized
INFO - 2020-10-09 09:47:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 09:47:55 --> Final output sent to browser
DEBUG - 2020-10-09 09:47:55 --> Total execution time: 0.0362
ERROR - 2020-10-09 09:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:06 --> Config Class Initialized
INFO - 2020-10-09 09:48:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:06 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:06 --> URI Class Initialized
INFO - 2020-10-09 09:48:06 --> Router Class Initialized
INFO - 2020-10-09 09:48:06 --> Output Class Initialized
INFO - 2020-10-09 09:48:06 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:06 --> Input Class Initialized
INFO - 2020-10-09 09:48:06 --> Language Class Initialized
INFO - 2020-10-09 09:48:06 --> Loader Class Initialized
INFO - 2020-10-09 09:48:06 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:06 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:06 --> Email Class Initialized
INFO - 2020-10-09 09:48:06 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:06 --> Model Class Initialized
INFO - 2020-10-09 09:48:06 --> Model Class Initialized
INFO - 2020-10-09 09:48:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 09:48:06 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:06 --> Total execution time: 0.0242
ERROR - 2020-10-09 09:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:11 --> Config Class Initialized
INFO - 2020-10-09 09:48:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:11 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:11 --> URI Class Initialized
INFO - 2020-10-09 09:48:11 --> Router Class Initialized
INFO - 2020-10-09 09:48:11 --> Output Class Initialized
INFO - 2020-10-09 09:48:11 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:11 --> Input Class Initialized
INFO - 2020-10-09 09:48:11 --> Language Class Initialized
INFO - 2020-10-09 09:48:11 --> Loader Class Initialized
INFO - 2020-10-09 09:48:11 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:11 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:11 --> Email Class Initialized
INFO - 2020-10-09 09:48:11 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:11 --> Model Class Initialized
INFO - 2020-10-09 09:48:11 --> Model Class Initialized
INFO - 2020-10-09 09:48:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 09:48:11 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:11 --> Total execution time: 0.0249
ERROR - 2020-10-09 09:48:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:11 --> Config Class Initialized
INFO - 2020-10-09 09:48:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:11 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:11 --> URI Class Initialized
INFO - 2020-10-09 09:48:11 --> Router Class Initialized
INFO - 2020-10-09 09:48:11 --> Output Class Initialized
INFO - 2020-10-09 09:48:11 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:11 --> Input Class Initialized
INFO - 2020-10-09 09:48:11 --> Language Class Initialized
INFO - 2020-10-09 09:48:11 --> Loader Class Initialized
INFO - 2020-10-09 09:48:11 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:11 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:11 --> Email Class Initialized
INFO - 2020-10-09 09:48:11 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:11 --> Model Class Initialized
INFO - 2020-10-09 09:48:11 --> Model Class Initialized
INFO - 2020-10-09 09:48:11 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:11 --> Total execution time: 0.2322
ERROR - 2020-10-09 09:48:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:24 --> Config Class Initialized
INFO - 2020-10-09 09:48:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:24 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:24 --> URI Class Initialized
INFO - 2020-10-09 09:48:24 --> Router Class Initialized
INFO - 2020-10-09 09:48:24 --> Output Class Initialized
INFO - 2020-10-09 09:48:24 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:24 --> Input Class Initialized
INFO - 2020-10-09 09:48:24 --> Language Class Initialized
INFO - 2020-10-09 09:48:24 --> Loader Class Initialized
INFO - 2020-10-09 09:48:24 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:24 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:24 --> Email Class Initialized
INFO - 2020-10-09 09:48:24 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:24 --> Model Class Initialized
INFO - 2020-10-09 09:48:24 --> Model Class Initialized
INFO - 2020-10-09 09:48:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 09:48:24 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:24 --> Total execution time: 0.0300
ERROR - 2020-10-09 09:48:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:25 --> Config Class Initialized
INFO - 2020-10-09 09:48:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:25 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:25 --> URI Class Initialized
INFO - 2020-10-09 09:48:25 --> Router Class Initialized
INFO - 2020-10-09 09:48:25 --> Output Class Initialized
INFO - 2020-10-09 09:48:25 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:25 --> Input Class Initialized
INFO - 2020-10-09 09:48:25 --> Language Class Initialized
INFO - 2020-10-09 09:48:25 --> Loader Class Initialized
INFO - 2020-10-09 09:48:25 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:25 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:25 --> Email Class Initialized
INFO - 2020-10-09 09:48:25 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:25 --> Model Class Initialized
INFO - 2020-10-09 09:48:25 --> Model Class Initialized
INFO - 2020-10-09 09:48:25 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:25 --> Total execution time: 0.0209
ERROR - 2020-10-09 09:48:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:38 --> Config Class Initialized
INFO - 2020-10-09 09:48:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:38 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:38 --> URI Class Initialized
INFO - 2020-10-09 09:48:38 --> Router Class Initialized
INFO - 2020-10-09 09:48:38 --> Output Class Initialized
INFO - 2020-10-09 09:48:38 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:38 --> Input Class Initialized
INFO - 2020-10-09 09:48:38 --> Language Class Initialized
INFO - 2020-10-09 09:48:38 --> Loader Class Initialized
INFO - 2020-10-09 09:48:38 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:38 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:38 --> Email Class Initialized
INFO - 2020-10-09 09:48:38 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:38 --> Model Class Initialized
INFO - 2020-10-09 09:48:38 --> Model Class Initialized
INFO - 2020-10-09 09:48:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 09:48:38 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:38 --> Total execution time: 0.0245
ERROR - 2020-10-09 09:48:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:38 --> Config Class Initialized
INFO - 2020-10-09 09:48:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:38 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:38 --> URI Class Initialized
INFO - 2020-10-09 09:48:38 --> Router Class Initialized
INFO - 2020-10-09 09:48:38 --> Output Class Initialized
INFO - 2020-10-09 09:48:38 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:38 --> Input Class Initialized
INFO - 2020-10-09 09:48:38 --> Language Class Initialized
INFO - 2020-10-09 09:48:38 --> Loader Class Initialized
INFO - 2020-10-09 09:48:38 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:38 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:38 --> Email Class Initialized
INFO - 2020-10-09 09:48:38 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:38 --> Model Class Initialized
INFO - 2020-10-09 09:48:38 --> Model Class Initialized
INFO - 2020-10-09 09:48:38 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:38 --> Total execution time: 0.0225
ERROR - 2020-10-09 09:48:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:46 --> Config Class Initialized
INFO - 2020-10-09 09:48:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:46 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:46 --> URI Class Initialized
INFO - 2020-10-09 09:48:46 --> Router Class Initialized
INFO - 2020-10-09 09:48:46 --> Output Class Initialized
INFO - 2020-10-09 09:48:46 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:46 --> Input Class Initialized
INFO - 2020-10-09 09:48:46 --> Language Class Initialized
INFO - 2020-10-09 09:48:46 --> Loader Class Initialized
INFO - 2020-10-09 09:48:46 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:46 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:46 --> Email Class Initialized
INFO - 2020-10-09 09:48:46 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:46 --> Model Class Initialized
INFO - 2020-10-09 09:48:46 --> Model Class Initialized
INFO - 2020-10-09 09:48:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 09:48:46 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:46 --> Total execution time: 0.0281
ERROR - 2020-10-09 09:48:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:47 --> Config Class Initialized
INFO - 2020-10-09 09:48:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:47 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:47 --> URI Class Initialized
INFO - 2020-10-09 09:48:47 --> Router Class Initialized
INFO - 2020-10-09 09:48:47 --> Output Class Initialized
INFO - 2020-10-09 09:48:47 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:47 --> Input Class Initialized
INFO - 2020-10-09 09:48:47 --> Language Class Initialized
INFO - 2020-10-09 09:48:47 --> Loader Class Initialized
INFO - 2020-10-09 09:48:47 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:47 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:47 --> Email Class Initialized
INFO - 2020-10-09 09:48:47 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:47 --> Model Class Initialized
INFO - 2020-10-09 09:48:47 --> Model Class Initialized
INFO - 2020-10-09 09:48:47 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:47 --> Total execution time: 0.0644
ERROR - 2020-10-09 09:48:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:49 --> Config Class Initialized
INFO - 2020-10-09 09:48:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:49 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:49 --> URI Class Initialized
INFO - 2020-10-09 09:48:49 --> Router Class Initialized
INFO - 2020-10-09 09:48:49 --> Output Class Initialized
INFO - 2020-10-09 09:48:49 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:49 --> Input Class Initialized
INFO - 2020-10-09 09:48:49 --> Language Class Initialized
INFO - 2020-10-09 09:48:49 --> Loader Class Initialized
INFO - 2020-10-09 09:48:49 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:49 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:49 --> Email Class Initialized
INFO - 2020-10-09 09:48:49 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:49 --> Model Class Initialized
INFO - 2020-10-09 09:48:49 --> Model Class Initialized
INFO - 2020-10-09 09:48:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 09:48:49 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:49 --> Total execution time: 0.0233
ERROR - 2020-10-09 09:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:52 --> Config Class Initialized
INFO - 2020-10-09 09:48:52 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:52 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:52 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:52 --> URI Class Initialized
INFO - 2020-10-09 09:48:52 --> Router Class Initialized
INFO - 2020-10-09 09:48:52 --> Output Class Initialized
INFO - 2020-10-09 09:48:52 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:52 --> Input Class Initialized
INFO - 2020-10-09 09:48:52 --> Language Class Initialized
INFO - 2020-10-09 09:48:52 --> Loader Class Initialized
INFO - 2020-10-09 09:48:52 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:52 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:52 --> Email Class Initialized
INFO - 2020-10-09 09:48:52 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:52 --> Model Class Initialized
INFO - 2020-10-09 09:48:52 --> Model Class Initialized
INFO - 2020-10-09 09:48:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 09:48:52 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:52 --> Total execution time: 0.0289
ERROR - 2020-10-09 09:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:52 --> Config Class Initialized
INFO - 2020-10-09 09:48:52 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:52 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:52 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:52 --> URI Class Initialized
INFO - 2020-10-09 09:48:52 --> Router Class Initialized
INFO - 2020-10-09 09:48:52 --> Output Class Initialized
INFO - 2020-10-09 09:48:52 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:52 --> Input Class Initialized
INFO - 2020-10-09 09:48:52 --> Language Class Initialized
INFO - 2020-10-09 09:48:52 --> Loader Class Initialized
INFO - 2020-10-09 09:48:52 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:52 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:52 --> Email Class Initialized
INFO - 2020-10-09 09:48:52 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:52 --> Model Class Initialized
INFO - 2020-10-09 09:48:52 --> Model Class Initialized
INFO - 2020-10-09 09:48:52 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:52 --> Total execution time: 0.0247
ERROR - 2020-10-09 09:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:55 --> Config Class Initialized
INFO - 2020-10-09 09:48:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:55 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:55 --> URI Class Initialized
INFO - 2020-10-09 09:48:55 --> Router Class Initialized
INFO - 2020-10-09 09:48:55 --> Output Class Initialized
INFO - 2020-10-09 09:48:55 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:55 --> Input Class Initialized
INFO - 2020-10-09 09:48:55 --> Language Class Initialized
INFO - 2020-10-09 09:48:55 --> Loader Class Initialized
INFO - 2020-10-09 09:48:55 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:55 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:55 --> Email Class Initialized
INFO - 2020-10-09 09:48:55 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:55 --> Model Class Initialized
INFO - 2020-10-09 09:48:55 --> Model Class Initialized
INFO - 2020-10-09 09:48:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 09:48:55 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:55 --> Total execution time: 0.0222
ERROR - 2020-10-09 09:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:48:55 --> Config Class Initialized
INFO - 2020-10-09 09:48:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:48:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:48:55 --> Utf8 Class Initialized
INFO - 2020-10-09 09:48:55 --> URI Class Initialized
INFO - 2020-10-09 09:48:55 --> Router Class Initialized
INFO - 2020-10-09 09:48:55 --> Output Class Initialized
INFO - 2020-10-09 09:48:55 --> Security Class Initialized
DEBUG - 2020-10-09 09:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:48:55 --> Input Class Initialized
INFO - 2020-10-09 09:48:55 --> Language Class Initialized
INFO - 2020-10-09 09:48:55 --> Loader Class Initialized
INFO - 2020-10-09 09:48:55 --> Helper loaded: url_helper
INFO - 2020-10-09 09:48:55 --> Database Driver Class Initialized
INFO - 2020-10-09 09:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:48:55 --> Email Class Initialized
INFO - 2020-10-09 09:48:55 --> Controller Class Initialized
DEBUG - 2020-10-09 09:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:48:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:48:55 --> Model Class Initialized
INFO - 2020-10-09 09:48:55 --> Model Class Initialized
INFO - 2020-10-09 09:48:56 --> Final output sent to browser
DEBUG - 2020-10-09 09:48:56 --> Total execution time: 0.0240
ERROR - 2020-10-09 09:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:02 --> Config Class Initialized
INFO - 2020-10-09 09:49:02 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:02 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:02 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:02 --> URI Class Initialized
INFO - 2020-10-09 09:49:02 --> Router Class Initialized
INFO - 2020-10-09 09:49:02 --> Output Class Initialized
INFO - 2020-10-09 09:49:02 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:02 --> Input Class Initialized
INFO - 2020-10-09 09:49:02 --> Language Class Initialized
INFO - 2020-10-09 09:49:02 --> Loader Class Initialized
INFO - 2020-10-09 09:49:02 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:02 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:03 --> Email Class Initialized
INFO - 2020-10-09 09:49:03 --> Controller Class Initialized
DEBUG - 2020-10-09 09:49:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:49:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:03 --> Model Class Initialized
INFO - 2020-10-09 09:49:03 --> Model Class Initialized
INFO - 2020-10-09 09:49:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 09:49:03 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:03 --> Total execution time: 0.0244
ERROR - 2020-10-09 09:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:03 --> Config Class Initialized
INFO - 2020-10-09 09:49:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:03 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:03 --> URI Class Initialized
INFO - 2020-10-09 09:49:03 --> Router Class Initialized
INFO - 2020-10-09 09:49:03 --> Output Class Initialized
INFO - 2020-10-09 09:49:03 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:03 --> Input Class Initialized
INFO - 2020-10-09 09:49:03 --> Language Class Initialized
INFO - 2020-10-09 09:49:03 --> Loader Class Initialized
INFO - 2020-10-09 09:49:03 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:03 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:03 --> Email Class Initialized
INFO - 2020-10-09 09:49:03 --> Controller Class Initialized
DEBUG - 2020-10-09 09:49:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:49:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:03 --> Model Class Initialized
INFO - 2020-10-09 09:49:03 --> Model Class Initialized
INFO - 2020-10-09 09:49:03 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:03 --> Total execution time: 0.0217
ERROR - 2020-10-09 09:49:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:11 --> Config Class Initialized
INFO - 2020-10-09 09:49:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:11 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:11 --> URI Class Initialized
DEBUG - 2020-10-09 09:49:11 --> No URI present. Default controller set.
INFO - 2020-10-09 09:49:11 --> Router Class Initialized
INFO - 2020-10-09 09:49:11 --> Output Class Initialized
INFO - 2020-10-09 09:49:11 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:11 --> Input Class Initialized
INFO - 2020-10-09 09:49:11 --> Language Class Initialized
INFO - 2020-10-09 09:49:11 --> Loader Class Initialized
INFO - 2020-10-09 09:49:11 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:11 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:11 --> Email Class Initialized
INFO - 2020-10-09 09:49:11 --> Controller Class Initialized
INFO - 2020-10-09 09:49:11 --> Model Class Initialized
INFO - 2020-10-09 09:49:11 --> Model Class Initialized
DEBUG - 2020-10-09 09:49:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 09:49:11 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:11 --> Total execution time: 0.0185
ERROR - 2020-10-09 09:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:28 --> Config Class Initialized
INFO - 2020-10-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:28 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:28 --> URI Class Initialized
INFO - 2020-10-09 09:49:28 --> Router Class Initialized
INFO - 2020-10-09 09:49:28 --> Output Class Initialized
INFO - 2020-10-09 09:49:28 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:28 --> Input Class Initialized
INFO - 2020-10-09 09:49:28 --> Language Class Initialized
INFO - 2020-10-09 09:49:28 --> Loader Class Initialized
INFO - 2020-10-09 09:49:28 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:28 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:28 --> Email Class Initialized
INFO - 2020-10-09 09:49:28 --> Controller Class Initialized
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
DEBUG - 2020-10-09 09:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:49:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
INFO - 2020-10-09 09:49:28 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:28 --> Total execution time: 0.0202
ERROR - 2020-10-09 09:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:28 --> Config Class Initialized
INFO - 2020-10-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:28 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:28 --> URI Class Initialized
INFO - 2020-10-09 09:49:28 --> Router Class Initialized
INFO - 2020-10-09 09:49:28 --> Output Class Initialized
INFO - 2020-10-09 09:49:28 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:28 --> Input Class Initialized
INFO - 2020-10-09 09:49:28 --> Language Class Initialized
INFO - 2020-10-09 09:49:28 --> Loader Class Initialized
INFO - 2020-10-09 09:49:28 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:28 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:28 --> Email Class Initialized
INFO - 2020-10-09 09:49:28 --> Controller Class Initialized
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
DEBUG - 2020-10-09 09:49:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 09:49:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:28 --> Config Class Initialized
INFO - 2020-10-09 09:49:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:28 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:28 --> URI Class Initialized
INFO - 2020-10-09 09:49:28 --> Router Class Initialized
INFO - 2020-10-09 09:49:28 --> Output Class Initialized
INFO - 2020-10-09 09:49:28 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:28 --> Input Class Initialized
INFO - 2020-10-09 09:49:28 --> Language Class Initialized
INFO - 2020-10-09 09:49:28 --> Loader Class Initialized
INFO - 2020-10-09 09:49:28 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:28 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:28 --> Email Class Initialized
INFO - 2020-10-09 09:49:28 --> Controller Class Initialized
DEBUG - 2020-10-09 09:49:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:49:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
INFO - 2020-10-09 09:49:28 --> Model Class Initialized
INFO - 2020-10-09 09:49:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-09 09:49:28 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:28 --> Total execution time: 0.0554
ERROR - 2020-10-09 09:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:41 --> Config Class Initialized
INFO - 2020-10-09 09:49:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:41 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:41 --> URI Class Initialized
INFO - 2020-10-09 09:49:41 --> Router Class Initialized
INFO - 2020-10-09 09:49:41 --> Output Class Initialized
INFO - 2020-10-09 09:49:41 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:41 --> Input Class Initialized
INFO - 2020-10-09 09:49:41 --> Language Class Initialized
INFO - 2020-10-09 09:49:41 --> Loader Class Initialized
INFO - 2020-10-09 09:49:41 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:41 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:41 --> Email Class Initialized
INFO - 2020-10-09 09:49:41 --> Controller Class Initialized
DEBUG - 2020-10-09 09:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:49:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:41 --> Model Class Initialized
INFO - 2020-10-09 09:49:41 --> Model Class Initialized
INFO - 2020-10-09 09:49:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-09 09:49:41 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:41 --> Total execution time: 0.0303
ERROR - 2020-10-09 09:49:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:49:47 --> Config Class Initialized
INFO - 2020-10-09 09:49:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:49:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:49:47 --> Utf8 Class Initialized
INFO - 2020-10-09 09:49:47 --> URI Class Initialized
INFO - 2020-10-09 09:49:47 --> Router Class Initialized
INFO - 2020-10-09 09:49:47 --> Output Class Initialized
INFO - 2020-10-09 09:49:47 --> Security Class Initialized
DEBUG - 2020-10-09 09:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:49:47 --> Input Class Initialized
INFO - 2020-10-09 09:49:47 --> Language Class Initialized
INFO - 2020-10-09 09:49:47 --> Loader Class Initialized
INFO - 2020-10-09 09:49:47 --> Helper loaded: url_helper
INFO - 2020-10-09 09:49:47 --> Database Driver Class Initialized
INFO - 2020-10-09 09:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:49:47 --> Email Class Initialized
INFO - 2020-10-09 09:49:47 --> Controller Class Initialized
DEBUG - 2020-10-09 09:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:49:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:49:47 --> Model Class Initialized
INFO - 2020-10-09 09:49:47 --> Model Class Initialized
INFO - 2020-10-09 09:49:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-09 09:49:47 --> Final output sent to browser
DEBUG - 2020-10-09 09:49:47 --> Total execution time: 0.0272
ERROR - 2020-10-09 09:51:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:51:10 --> Config Class Initialized
INFO - 2020-10-09 09:51:10 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:51:10 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:51:10 --> Utf8 Class Initialized
INFO - 2020-10-09 09:51:10 --> URI Class Initialized
DEBUG - 2020-10-09 09:51:10 --> No URI present. Default controller set.
INFO - 2020-10-09 09:51:10 --> Router Class Initialized
INFO - 2020-10-09 09:51:10 --> Output Class Initialized
INFO - 2020-10-09 09:51:10 --> Security Class Initialized
DEBUG - 2020-10-09 09:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:51:10 --> Input Class Initialized
INFO - 2020-10-09 09:51:10 --> Language Class Initialized
INFO - 2020-10-09 09:51:10 --> Loader Class Initialized
INFO - 2020-10-09 09:51:10 --> Helper loaded: url_helper
INFO - 2020-10-09 09:51:10 --> Database Driver Class Initialized
INFO - 2020-10-09 09:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:51:10 --> Email Class Initialized
INFO - 2020-10-09 09:51:10 --> Controller Class Initialized
INFO - 2020-10-09 09:51:10 --> Model Class Initialized
INFO - 2020-10-09 09:51:10 --> Model Class Initialized
DEBUG - 2020-10-09 09:51:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:51:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 09:51:10 --> Final output sent to browser
DEBUG - 2020-10-09 09:51:10 --> Total execution time: 0.0286
ERROR - 2020-10-09 09:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:51:33 --> Config Class Initialized
INFO - 2020-10-09 09:51:33 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:51:33 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:51:33 --> Utf8 Class Initialized
INFO - 2020-10-09 09:51:33 --> URI Class Initialized
INFO - 2020-10-09 09:51:33 --> Router Class Initialized
INFO - 2020-10-09 09:51:33 --> Output Class Initialized
INFO - 2020-10-09 09:51:33 --> Security Class Initialized
DEBUG - 2020-10-09 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:51:33 --> Input Class Initialized
INFO - 2020-10-09 09:51:33 --> Language Class Initialized
INFO - 2020-10-09 09:51:33 --> Loader Class Initialized
INFO - 2020-10-09 09:51:33 --> Helper loaded: url_helper
INFO - 2020-10-09 09:51:33 --> Database Driver Class Initialized
INFO - 2020-10-09 09:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:51:33 --> Email Class Initialized
INFO - 2020-10-09 09:51:33 --> Controller Class Initialized
INFO - 2020-10-09 09:51:33 --> Model Class Initialized
INFO - 2020-10-09 09:51:33 --> Model Class Initialized
DEBUG - 2020-10-09 09:51:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:51:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:51:33 --> Model Class Initialized
INFO - 2020-10-09 09:51:33 --> Final output sent to browser
DEBUG - 2020-10-09 09:51:33 --> Total execution time: 0.0230
ERROR - 2020-10-09 09:51:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:51:33 --> Config Class Initialized
INFO - 2020-10-09 09:51:33 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:51:33 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:51:33 --> Utf8 Class Initialized
INFO - 2020-10-09 09:51:33 --> URI Class Initialized
INFO - 2020-10-09 09:51:33 --> Router Class Initialized
INFO - 2020-10-09 09:51:33 --> Output Class Initialized
INFO - 2020-10-09 09:51:33 --> Security Class Initialized
DEBUG - 2020-10-09 09:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:51:33 --> Input Class Initialized
INFO - 2020-10-09 09:51:33 --> Language Class Initialized
INFO - 2020-10-09 09:51:33 --> Loader Class Initialized
INFO - 2020-10-09 09:51:33 --> Helper loaded: url_helper
INFO - 2020-10-09 09:51:33 --> Database Driver Class Initialized
INFO - 2020-10-09 09:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:51:33 --> Email Class Initialized
INFO - 2020-10-09 09:51:33 --> Controller Class Initialized
INFO - 2020-10-09 09:51:33 --> Model Class Initialized
INFO - 2020-10-09 09:51:33 --> Model Class Initialized
DEBUG - 2020-10-09 09:51:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 09:51:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:51:34 --> Config Class Initialized
INFO - 2020-10-09 09:51:34 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:51:34 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:51:34 --> Utf8 Class Initialized
INFO - 2020-10-09 09:51:34 --> URI Class Initialized
INFO - 2020-10-09 09:51:34 --> Router Class Initialized
INFO - 2020-10-09 09:51:34 --> Output Class Initialized
INFO - 2020-10-09 09:51:34 --> Security Class Initialized
DEBUG - 2020-10-09 09:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:51:34 --> Input Class Initialized
INFO - 2020-10-09 09:51:34 --> Language Class Initialized
INFO - 2020-10-09 09:51:34 --> Loader Class Initialized
INFO - 2020-10-09 09:51:34 --> Helper loaded: url_helper
INFO - 2020-10-09 09:51:34 --> Database Driver Class Initialized
INFO - 2020-10-09 09:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:51:34 --> Email Class Initialized
INFO - 2020-10-09 09:51:34 --> Controller Class Initialized
DEBUG - 2020-10-09 09:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:51:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:51:34 --> Model Class Initialized
INFO - 2020-10-09 09:51:34 --> Model Class Initialized
INFO - 2020-10-09 09:51:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 09:51:34 --> Final output sent to browser
DEBUG - 2020-10-09 09:51:34 --> Total execution time: 0.0311
ERROR - 2020-10-09 09:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:52:18 --> Config Class Initialized
INFO - 2020-10-09 09:52:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:52:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:52:18 --> Utf8 Class Initialized
INFO - 2020-10-09 09:52:18 --> URI Class Initialized
INFO - 2020-10-09 09:52:18 --> Router Class Initialized
INFO - 2020-10-09 09:52:18 --> Output Class Initialized
INFO - 2020-10-09 09:52:18 --> Security Class Initialized
DEBUG - 2020-10-09 09:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:52:18 --> Input Class Initialized
INFO - 2020-10-09 09:52:18 --> Language Class Initialized
INFO - 2020-10-09 09:52:18 --> Loader Class Initialized
INFO - 2020-10-09 09:52:18 --> Helper loaded: url_helper
INFO - 2020-10-09 09:52:18 --> Database Driver Class Initialized
INFO - 2020-10-09 09:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:52:18 --> Email Class Initialized
INFO - 2020-10-09 09:52:18 --> Controller Class Initialized
DEBUG - 2020-10-09 09:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:52:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:52:18 --> Model Class Initialized
INFO - 2020-10-09 09:52:18 --> Model Class Initialized
INFO - 2020-10-09 09:52:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 09:52:18 --> Final output sent to browser
DEBUG - 2020-10-09 09:52:18 --> Total execution time: 0.0222
ERROR - 2020-10-09 09:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:52:24 --> Config Class Initialized
INFO - 2020-10-09 09:52:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:52:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:52:24 --> Utf8 Class Initialized
INFO - 2020-10-09 09:52:24 --> URI Class Initialized
INFO - 2020-10-09 09:52:24 --> Router Class Initialized
INFO - 2020-10-09 09:52:24 --> Output Class Initialized
INFO - 2020-10-09 09:52:24 --> Security Class Initialized
DEBUG - 2020-10-09 09:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:52:24 --> Input Class Initialized
INFO - 2020-10-09 09:52:24 --> Language Class Initialized
INFO - 2020-10-09 09:52:24 --> Loader Class Initialized
INFO - 2020-10-09 09:52:24 --> Helper loaded: url_helper
INFO - 2020-10-09 09:52:24 --> Database Driver Class Initialized
INFO - 2020-10-09 09:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:52:24 --> Email Class Initialized
INFO - 2020-10-09 09:52:24 --> Controller Class Initialized
DEBUG - 2020-10-09 09:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:52:24 --> Model Class Initialized
INFO - 2020-10-09 09:52:24 --> Model Class Initialized
INFO - 2020-10-09 09:52:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 09:52:24 --> Final output sent to browser
DEBUG - 2020-10-09 09:52:24 --> Total execution time: 0.0231
ERROR - 2020-10-09 09:52:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:52:31 --> Config Class Initialized
INFO - 2020-10-09 09:52:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:52:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:52:31 --> Utf8 Class Initialized
INFO - 2020-10-09 09:52:31 --> URI Class Initialized
INFO - 2020-10-09 09:52:31 --> Router Class Initialized
INFO - 2020-10-09 09:52:31 --> Output Class Initialized
INFO - 2020-10-09 09:52:31 --> Security Class Initialized
DEBUG - 2020-10-09 09:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:52:31 --> Input Class Initialized
INFO - 2020-10-09 09:52:31 --> Language Class Initialized
INFO - 2020-10-09 09:52:31 --> Loader Class Initialized
INFO - 2020-10-09 09:52:31 --> Helper loaded: url_helper
INFO - 2020-10-09 09:52:31 --> Database Driver Class Initialized
INFO - 2020-10-09 09:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:52:31 --> Email Class Initialized
INFO - 2020-10-09 09:52:31 --> Controller Class Initialized
DEBUG - 2020-10-09 09:52:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:52:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:52:31 --> Model Class Initialized
INFO - 2020-10-09 09:52:31 --> Model Class Initialized
INFO - 2020-10-09 09:52:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 09:52:31 --> Final output sent to browser
DEBUG - 2020-10-09 09:52:31 --> Total execution time: 0.0256
ERROR - 2020-10-09 09:52:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:52:52 --> Config Class Initialized
INFO - 2020-10-09 09:52:52 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:52:52 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:52:52 --> Utf8 Class Initialized
INFO - 2020-10-09 09:52:52 --> URI Class Initialized
INFO - 2020-10-09 09:52:52 --> Router Class Initialized
INFO - 2020-10-09 09:52:52 --> Output Class Initialized
INFO - 2020-10-09 09:52:52 --> Security Class Initialized
DEBUG - 2020-10-09 09:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:52:52 --> Input Class Initialized
INFO - 2020-10-09 09:52:52 --> Language Class Initialized
INFO - 2020-10-09 09:52:52 --> Loader Class Initialized
INFO - 2020-10-09 09:52:52 --> Helper loaded: url_helper
INFO - 2020-10-09 09:52:52 --> Database Driver Class Initialized
INFO - 2020-10-09 09:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:52:52 --> Email Class Initialized
INFO - 2020-10-09 09:52:52 --> Controller Class Initialized
DEBUG - 2020-10-09 09:52:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:52:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:52:52 --> Model Class Initialized
INFO - 2020-10-09 09:52:52 --> Model Class Initialized
INFO - 2020-10-09 09:52:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 09:52:52 --> Final output sent to browser
DEBUG - 2020-10-09 09:52:52 --> Total execution time: 0.0248
ERROR - 2020-10-09 09:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:52:54 --> Config Class Initialized
INFO - 2020-10-09 09:52:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:52:54 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:52:54 --> Utf8 Class Initialized
INFO - 2020-10-09 09:52:54 --> URI Class Initialized
INFO - 2020-10-09 09:52:54 --> Router Class Initialized
INFO - 2020-10-09 09:52:54 --> Output Class Initialized
INFO - 2020-10-09 09:52:54 --> Security Class Initialized
DEBUG - 2020-10-09 09:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:52:54 --> Input Class Initialized
INFO - 2020-10-09 09:52:54 --> Language Class Initialized
INFO - 2020-10-09 09:52:54 --> Loader Class Initialized
INFO - 2020-10-09 09:52:54 --> Helper loaded: url_helper
INFO - 2020-10-09 09:52:54 --> Database Driver Class Initialized
INFO - 2020-10-09 09:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:52:54 --> Email Class Initialized
INFO - 2020-10-09 09:52:54 --> Controller Class Initialized
DEBUG - 2020-10-09 09:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:52:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:52:54 --> Model Class Initialized
INFO - 2020-10-09 09:52:54 --> Model Class Initialized
INFO - 2020-10-09 09:52:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 09:52:54 --> Final output sent to browser
DEBUG - 2020-10-09 09:52:54 --> Total execution time: 0.0262
ERROR - 2020-10-09 09:52:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:52:56 --> Config Class Initialized
INFO - 2020-10-09 09:52:56 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:52:56 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:52:56 --> Utf8 Class Initialized
INFO - 2020-10-09 09:52:56 --> URI Class Initialized
INFO - 2020-10-09 09:52:56 --> Router Class Initialized
INFO - 2020-10-09 09:52:56 --> Output Class Initialized
INFO - 2020-10-09 09:52:56 --> Security Class Initialized
DEBUG - 2020-10-09 09:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:52:56 --> Input Class Initialized
INFO - 2020-10-09 09:52:56 --> Language Class Initialized
INFO - 2020-10-09 09:52:56 --> Loader Class Initialized
INFO - 2020-10-09 09:52:56 --> Helper loaded: url_helper
INFO - 2020-10-09 09:52:56 --> Database Driver Class Initialized
INFO - 2020-10-09 09:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:52:56 --> Email Class Initialized
INFO - 2020-10-09 09:52:56 --> Controller Class Initialized
DEBUG - 2020-10-09 09:52:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:52:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:52:56 --> Model Class Initialized
INFO - 2020-10-09 09:52:56 --> Model Class Initialized
INFO - 2020-10-09 09:52:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 09:52:56 --> Final output sent to browser
DEBUG - 2020-10-09 09:52:56 --> Total execution time: 0.0272
ERROR - 2020-10-09 09:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:53:40 --> Config Class Initialized
INFO - 2020-10-09 09:53:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:53:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:53:40 --> Utf8 Class Initialized
INFO - 2020-10-09 09:53:40 --> URI Class Initialized
INFO - 2020-10-09 09:53:40 --> Router Class Initialized
INFO - 2020-10-09 09:53:40 --> Output Class Initialized
INFO - 2020-10-09 09:53:40 --> Security Class Initialized
DEBUG - 2020-10-09 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:53:40 --> Input Class Initialized
INFO - 2020-10-09 09:53:40 --> Language Class Initialized
INFO - 2020-10-09 09:53:40 --> Loader Class Initialized
INFO - 2020-10-09 09:53:40 --> Helper loaded: url_helper
INFO - 2020-10-09 09:53:40 --> Database Driver Class Initialized
INFO - 2020-10-09 09:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:53:40 --> Email Class Initialized
INFO - 2020-10-09 09:53:40 --> Controller Class Initialized
DEBUG - 2020-10-09 09:53:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:53:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:53:40 --> Model Class Initialized
INFO - 2020-10-09 09:53:40 --> Model Class Initialized
INFO - 2020-10-09 09:53:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 09:53:40 --> Final output sent to browser
DEBUG - 2020-10-09 09:53:40 --> Total execution time: 0.0251
ERROR - 2020-10-09 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:53:46 --> Config Class Initialized
INFO - 2020-10-09 09:53:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:53:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:53:46 --> Utf8 Class Initialized
INFO - 2020-10-09 09:53:46 --> URI Class Initialized
INFO - 2020-10-09 09:53:46 --> Router Class Initialized
INFO - 2020-10-09 09:53:46 --> Output Class Initialized
INFO - 2020-10-09 09:53:46 --> Security Class Initialized
DEBUG - 2020-10-09 09:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:53:46 --> Input Class Initialized
INFO - 2020-10-09 09:53:46 --> Language Class Initialized
INFO - 2020-10-09 09:53:46 --> Loader Class Initialized
INFO - 2020-10-09 09:53:46 --> Helper loaded: url_helper
INFO - 2020-10-09 09:53:46 --> Database Driver Class Initialized
INFO - 2020-10-09 09:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:53:46 --> Email Class Initialized
INFO - 2020-10-09 09:53:46 --> Controller Class Initialized
DEBUG - 2020-10-09 09:53:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:53:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:53:46 --> Model Class Initialized
INFO - 2020-10-09 09:53:46 --> Model Class Initialized
INFO - 2020-10-09 09:53:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 09:53:46 --> Final output sent to browser
DEBUG - 2020-10-09 09:53:46 --> Total execution time: 0.0243
ERROR - 2020-10-09 09:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:54:14 --> Config Class Initialized
INFO - 2020-10-09 09:54:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:54:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:54:14 --> Utf8 Class Initialized
INFO - 2020-10-09 09:54:14 --> URI Class Initialized
INFO - 2020-10-09 09:54:14 --> Router Class Initialized
INFO - 2020-10-09 09:54:14 --> Output Class Initialized
INFO - 2020-10-09 09:54:14 --> Security Class Initialized
DEBUG - 2020-10-09 09:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:54:14 --> Input Class Initialized
INFO - 2020-10-09 09:54:14 --> Language Class Initialized
INFO - 2020-10-09 09:54:14 --> Loader Class Initialized
INFO - 2020-10-09 09:54:14 --> Helper loaded: url_helper
INFO - 2020-10-09 09:54:14 --> Database Driver Class Initialized
INFO - 2020-10-09 09:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:54:14 --> Email Class Initialized
INFO - 2020-10-09 09:54:14 --> Controller Class Initialized
DEBUG - 2020-10-09 09:54:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:54:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:54:14 --> Model Class Initialized
INFO - 2020-10-09 09:54:14 --> Model Class Initialized
INFO - 2020-10-09 09:54:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-09 09:54:14 --> Final output sent to browser
DEBUG - 2020-10-09 09:54:14 --> Total execution time: 0.0221
ERROR - 2020-10-09 09:54:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:54:46 --> Config Class Initialized
INFO - 2020-10-09 09:54:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:54:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:54:46 --> Utf8 Class Initialized
INFO - 2020-10-09 09:54:46 --> URI Class Initialized
INFO - 2020-10-09 09:54:46 --> Router Class Initialized
INFO - 2020-10-09 09:54:46 --> Output Class Initialized
INFO - 2020-10-09 09:54:46 --> Security Class Initialized
DEBUG - 2020-10-09 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:54:46 --> Input Class Initialized
INFO - 2020-10-09 09:54:46 --> Language Class Initialized
INFO - 2020-10-09 09:54:46 --> Loader Class Initialized
INFO - 2020-10-09 09:54:46 --> Helper loaded: url_helper
INFO - 2020-10-09 09:54:46 --> Database Driver Class Initialized
INFO - 2020-10-09 09:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:54:46 --> Email Class Initialized
INFO - 2020-10-09 09:54:46 --> Controller Class Initialized
DEBUG - 2020-10-09 09:54:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:54:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:54:46 --> Model Class Initialized
INFO - 2020-10-09 09:54:46 --> Model Class Initialized
INFO - 2020-10-09 09:54:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-09 09:54:47 --> Final output sent to browser
DEBUG - 2020-10-09 09:54:47 --> Total execution time: 0.0291
ERROR - 2020-10-09 09:54:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:54:53 --> Config Class Initialized
INFO - 2020-10-09 09:54:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:54:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:54:53 --> Utf8 Class Initialized
INFO - 2020-10-09 09:54:53 --> URI Class Initialized
INFO - 2020-10-09 09:54:53 --> Router Class Initialized
INFO - 2020-10-09 09:54:53 --> Output Class Initialized
INFO - 2020-10-09 09:54:53 --> Security Class Initialized
DEBUG - 2020-10-09 09:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:54:53 --> Input Class Initialized
INFO - 2020-10-09 09:54:53 --> Language Class Initialized
INFO - 2020-10-09 09:54:53 --> Loader Class Initialized
INFO - 2020-10-09 09:54:53 --> Helper loaded: url_helper
INFO - 2020-10-09 09:54:53 --> Database Driver Class Initialized
INFO - 2020-10-09 09:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:54:53 --> Email Class Initialized
INFO - 2020-10-09 09:54:53 --> Controller Class Initialized
DEBUG - 2020-10-09 09:54:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:54:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:54:53 --> Model Class Initialized
INFO - 2020-10-09 09:54:53 --> Model Class Initialized
INFO - 2020-10-09 09:54:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-09 09:54:53 --> Final output sent to browser
DEBUG - 2020-10-09 09:54:53 --> Total execution time: 0.0243
ERROR - 2020-10-09 09:55:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:55:03 --> Config Class Initialized
INFO - 2020-10-09 09:55:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:55:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:55:03 --> Utf8 Class Initialized
INFO - 2020-10-09 09:55:03 --> URI Class Initialized
INFO - 2020-10-09 09:55:03 --> Router Class Initialized
INFO - 2020-10-09 09:55:03 --> Output Class Initialized
INFO - 2020-10-09 09:55:03 --> Security Class Initialized
DEBUG - 2020-10-09 09:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:55:03 --> Input Class Initialized
INFO - 2020-10-09 09:55:03 --> Language Class Initialized
INFO - 2020-10-09 09:55:03 --> Loader Class Initialized
INFO - 2020-10-09 09:55:03 --> Helper loaded: url_helper
INFO - 2020-10-09 09:55:03 --> Database Driver Class Initialized
INFO - 2020-10-09 09:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:55:03 --> Email Class Initialized
INFO - 2020-10-09 09:55:03 --> Controller Class Initialized
DEBUG - 2020-10-09 09:55:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 09:55:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:55:03 --> Model Class Initialized
INFO - 2020-10-09 09:55:03 --> Model Class Initialized
INFO - 2020-10-09 09:55:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 09:55:03 --> Final output sent to browser
DEBUG - 2020-10-09 09:55:03 --> Total execution time: 0.0199
ERROR - 2020-10-09 09:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 09:55:57 --> Config Class Initialized
INFO - 2020-10-09 09:55:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 09:55:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 09:55:57 --> Utf8 Class Initialized
INFO - 2020-10-09 09:55:57 --> URI Class Initialized
DEBUG - 2020-10-09 09:55:57 --> No URI present. Default controller set.
INFO - 2020-10-09 09:55:57 --> Router Class Initialized
INFO - 2020-10-09 09:55:57 --> Output Class Initialized
INFO - 2020-10-09 09:55:57 --> Security Class Initialized
DEBUG - 2020-10-09 09:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 09:55:57 --> Input Class Initialized
INFO - 2020-10-09 09:55:57 --> Language Class Initialized
INFO - 2020-10-09 09:55:57 --> Loader Class Initialized
INFO - 2020-10-09 09:55:57 --> Helper loaded: url_helper
INFO - 2020-10-09 09:55:57 --> Database Driver Class Initialized
INFO - 2020-10-09 09:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 09:55:57 --> Email Class Initialized
INFO - 2020-10-09 09:55:57 --> Controller Class Initialized
INFO - 2020-10-09 09:55:57 --> Model Class Initialized
INFO - 2020-10-09 09:55:57 --> Model Class Initialized
DEBUG - 2020-10-09 09:55:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 09:55:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 09:55:57 --> Final output sent to browser
DEBUG - 2020-10-09 09:55:57 --> Total execution time: 0.0199
ERROR - 2020-10-09 11:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:37:36 --> Config Class Initialized
INFO - 2020-10-09 11:37:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:37:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:37:37 --> Utf8 Class Initialized
INFO - 2020-10-09 11:37:37 --> URI Class Initialized
DEBUG - 2020-10-09 11:37:37 --> No URI present. Default controller set.
INFO - 2020-10-09 11:37:37 --> Router Class Initialized
INFO - 2020-10-09 11:37:37 --> Output Class Initialized
INFO - 2020-10-09 11:37:37 --> Security Class Initialized
DEBUG - 2020-10-09 11:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:37:37 --> Input Class Initialized
INFO - 2020-10-09 11:37:37 --> Language Class Initialized
INFO - 2020-10-09 11:37:37 --> Loader Class Initialized
INFO - 2020-10-09 11:37:37 --> Helper loaded: url_helper
INFO - 2020-10-09 11:37:37 --> Database Driver Class Initialized
INFO - 2020-10-09 11:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:37:37 --> Email Class Initialized
INFO - 2020-10-09 11:37:37 --> Controller Class Initialized
INFO - 2020-10-09 11:37:37 --> Model Class Initialized
INFO - 2020-10-09 11:37:37 --> Model Class Initialized
DEBUG - 2020-10-09 11:37:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:37:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 11:37:37 --> Final output sent to browser
DEBUG - 2020-10-09 11:37:37 --> Total execution time: 0.0210
ERROR - 2020-10-09 11:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:38:07 --> Config Class Initialized
INFO - 2020-10-09 11:38:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:38:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:38:07 --> Utf8 Class Initialized
INFO - 2020-10-09 11:38:07 --> URI Class Initialized
INFO - 2020-10-09 11:38:07 --> Router Class Initialized
INFO - 2020-10-09 11:38:07 --> Output Class Initialized
INFO - 2020-10-09 11:38:07 --> Security Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:38:07 --> Input Class Initialized
INFO - 2020-10-09 11:38:07 --> Language Class Initialized
INFO - 2020-10-09 11:38:07 --> Loader Class Initialized
INFO - 2020-10-09 11:38:07 --> Helper loaded: url_helper
INFO - 2020-10-09 11:38:07 --> Database Driver Class Initialized
INFO - 2020-10-09 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:38:07 --> Email Class Initialized
INFO - 2020-10-09 11:38:07 --> Controller Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:38:07 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 11:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:38:07 --> Config Class Initialized
INFO - 2020-10-09 11:38:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:38:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:38:07 --> Utf8 Class Initialized
INFO - 2020-10-09 11:38:07 --> URI Class Initialized
INFO - 2020-10-09 11:38:07 --> Router Class Initialized
INFO - 2020-10-09 11:38:07 --> Output Class Initialized
INFO - 2020-10-09 11:38:07 --> Security Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:38:07 --> Input Class Initialized
INFO - 2020-10-09 11:38:07 --> Language Class Initialized
INFO - 2020-10-09 11:38:07 --> Loader Class Initialized
INFO - 2020-10-09 11:38:07 --> Helper loaded: url_helper
INFO - 2020-10-09 11:38:07 --> Database Driver Class Initialized
INFO - 2020-10-09 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:38:07 --> Email Class Initialized
INFO - 2020-10-09 11:38:07 --> Controller Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 11:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:38:07 --> Config Class Initialized
INFO - 2020-10-09 11:38:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:38:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:38:07 --> Utf8 Class Initialized
INFO - 2020-10-09 11:38:07 --> URI Class Initialized
DEBUG - 2020-10-09 11:38:07 --> No URI present. Default controller set.
INFO - 2020-10-09 11:38:07 --> Router Class Initialized
INFO - 2020-10-09 11:38:07 --> Output Class Initialized
INFO - 2020-10-09 11:38:07 --> Security Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:38:07 --> Input Class Initialized
INFO - 2020-10-09 11:38:07 --> Language Class Initialized
INFO - 2020-10-09 11:38:07 --> Loader Class Initialized
INFO - 2020-10-09 11:38:07 --> Helper loaded: url_helper
INFO - 2020-10-09 11:38:07 --> Database Driver Class Initialized
INFO - 2020-10-09 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:38:07 --> Email Class Initialized
INFO - 2020-10-09 11:38:07 --> Controller Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:38:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 11:38:07 --> Final output sent to browser
DEBUG - 2020-10-09 11:38:07 --> Total execution time: 0.0193
ERROR - 2020-10-09 11:38:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:38:07 --> Config Class Initialized
INFO - 2020-10-09 11:38:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:38:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:38:07 --> Utf8 Class Initialized
INFO - 2020-10-09 11:38:07 --> URI Class Initialized
INFO - 2020-10-09 11:38:07 --> Router Class Initialized
INFO - 2020-10-09 11:38:07 --> Output Class Initialized
INFO - 2020-10-09 11:38:07 --> Security Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:38:07 --> Input Class Initialized
INFO - 2020-10-09 11:38:07 --> Language Class Initialized
INFO - 2020-10-09 11:38:07 --> Loader Class Initialized
INFO - 2020-10-09 11:38:07 --> Helper loaded: url_helper
INFO - 2020-10-09 11:38:07 --> Database Driver Class Initialized
INFO - 2020-10-09 11:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:38:07 --> Email Class Initialized
INFO - 2020-10-09 11:38:07 --> Controller Class Initialized
DEBUG - 2020-10-09 11:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:38:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
INFO - 2020-10-09 11:38:07 --> Model Class Initialized
INFO - 2020-10-09 11:38:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:38:07 --> Final output sent to browser
DEBUG - 2020-10-09 11:38:07 --> Total execution time: 0.0290
ERROR - 2020-10-09 11:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:40:32 --> Config Class Initialized
INFO - 2020-10-09 11:40:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:40:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:40:32 --> Utf8 Class Initialized
INFO - 2020-10-09 11:40:32 --> URI Class Initialized
INFO - 2020-10-09 11:40:32 --> Router Class Initialized
INFO - 2020-10-09 11:40:32 --> Output Class Initialized
INFO - 2020-10-09 11:40:32 --> Security Class Initialized
DEBUG - 2020-10-09 11:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:40:32 --> Input Class Initialized
INFO - 2020-10-09 11:40:32 --> Language Class Initialized
INFO - 2020-10-09 11:40:32 --> Loader Class Initialized
INFO - 2020-10-09 11:40:32 --> Helper loaded: url_helper
INFO - 2020-10-09 11:40:32 --> Database Driver Class Initialized
INFO - 2020-10-09 11:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:40:32 --> Email Class Initialized
INFO - 2020-10-09 11:40:32 --> Controller Class Initialized
DEBUG - 2020-10-09 11:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:40:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:40:32 --> Model Class Initialized
INFO - 2020-10-09 11:40:32 --> Model Class Initialized
INFO - 2020-10-09 11:40:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:40:32 --> Final output sent to browser
DEBUG - 2020-10-09 11:40:32 --> Total execution time: 0.0217
ERROR - 2020-10-09 11:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:41:03 --> Config Class Initialized
INFO - 2020-10-09 11:41:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:41:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:41:03 --> Utf8 Class Initialized
INFO - 2020-10-09 11:41:03 --> URI Class Initialized
INFO - 2020-10-09 11:41:03 --> Router Class Initialized
INFO - 2020-10-09 11:41:03 --> Output Class Initialized
INFO - 2020-10-09 11:41:03 --> Security Class Initialized
DEBUG - 2020-10-09 11:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:41:03 --> Input Class Initialized
INFO - 2020-10-09 11:41:03 --> Language Class Initialized
INFO - 2020-10-09 11:41:03 --> Loader Class Initialized
INFO - 2020-10-09 11:41:03 --> Helper loaded: url_helper
INFO - 2020-10-09 11:41:03 --> Database Driver Class Initialized
INFO - 2020-10-09 11:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:41:03 --> Email Class Initialized
INFO - 2020-10-09 11:41:03 --> Controller Class Initialized
DEBUG - 2020-10-09 11:41:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:41:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:41:03 --> Model Class Initialized
INFO - 2020-10-09 11:41:03 --> Model Class Initialized
INFO - 2020-10-09 11:41:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:41:03 --> Final output sent to browser
DEBUG - 2020-10-09 11:41:03 --> Total execution time: 0.0226
ERROR - 2020-10-09 11:41:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:41:26 --> Config Class Initialized
INFO - 2020-10-09 11:41:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:41:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:41:26 --> Utf8 Class Initialized
INFO - 2020-10-09 11:41:26 --> URI Class Initialized
INFO - 2020-10-09 11:41:26 --> Router Class Initialized
INFO - 2020-10-09 11:41:26 --> Output Class Initialized
INFO - 2020-10-09 11:41:26 --> Security Class Initialized
DEBUG - 2020-10-09 11:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:41:26 --> Input Class Initialized
INFO - 2020-10-09 11:41:26 --> Language Class Initialized
INFO - 2020-10-09 11:41:26 --> Loader Class Initialized
INFO - 2020-10-09 11:41:26 --> Helper loaded: url_helper
INFO - 2020-10-09 11:41:26 --> Database Driver Class Initialized
INFO - 2020-10-09 11:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:41:26 --> Email Class Initialized
INFO - 2020-10-09 11:41:26 --> Controller Class Initialized
DEBUG - 2020-10-09 11:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:41:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:41:26 --> Model Class Initialized
INFO - 2020-10-09 11:41:26 --> Model Class Initialized
INFO - 2020-10-09 11:41:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:41:26 --> Final output sent to browser
DEBUG - 2020-10-09 11:41:26 --> Total execution time: 0.0219
ERROR - 2020-10-09 11:42:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:42:23 --> Config Class Initialized
INFO - 2020-10-09 11:42:23 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:42:23 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:42:23 --> Utf8 Class Initialized
INFO - 2020-10-09 11:42:23 --> URI Class Initialized
INFO - 2020-10-09 11:42:23 --> Router Class Initialized
INFO - 2020-10-09 11:42:23 --> Output Class Initialized
INFO - 2020-10-09 11:42:23 --> Security Class Initialized
DEBUG - 2020-10-09 11:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:42:23 --> Input Class Initialized
INFO - 2020-10-09 11:42:23 --> Language Class Initialized
INFO - 2020-10-09 11:42:23 --> Loader Class Initialized
INFO - 2020-10-09 11:42:23 --> Helper loaded: url_helper
INFO - 2020-10-09 11:42:23 --> Database Driver Class Initialized
INFO - 2020-10-09 11:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:42:23 --> Email Class Initialized
INFO - 2020-10-09 11:42:23 --> Controller Class Initialized
DEBUG - 2020-10-09 11:42:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:42:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:42:23 --> Model Class Initialized
INFO - 2020-10-09 11:42:23 --> Model Class Initialized
INFO - 2020-10-09 11:42:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:42:23 --> Final output sent to browser
DEBUG - 2020-10-09 11:42:23 --> Total execution time: 0.0244
ERROR - 2020-10-09 11:42:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:42:28 --> Config Class Initialized
INFO - 2020-10-09 11:42:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:42:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:42:28 --> Utf8 Class Initialized
INFO - 2020-10-09 11:42:28 --> URI Class Initialized
INFO - 2020-10-09 11:42:28 --> Router Class Initialized
INFO - 2020-10-09 11:42:28 --> Output Class Initialized
INFO - 2020-10-09 11:42:28 --> Security Class Initialized
DEBUG - 2020-10-09 11:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:42:28 --> Input Class Initialized
INFO - 2020-10-09 11:42:28 --> Language Class Initialized
INFO - 2020-10-09 11:42:28 --> Loader Class Initialized
INFO - 2020-10-09 11:42:28 --> Helper loaded: url_helper
INFO - 2020-10-09 11:42:28 --> Database Driver Class Initialized
INFO - 2020-10-09 11:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:42:28 --> Email Class Initialized
INFO - 2020-10-09 11:42:28 --> Controller Class Initialized
DEBUG - 2020-10-09 11:42:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:42:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:42:28 --> Model Class Initialized
INFO - 2020-10-09 11:42:28 --> Model Class Initialized
INFO - 2020-10-09 11:42:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:42:28 --> Final output sent to browser
DEBUG - 2020-10-09 11:42:28 --> Total execution time: 0.0290
ERROR - 2020-10-09 11:42:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:42:31 --> Config Class Initialized
INFO - 2020-10-09 11:42:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:42:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:42:31 --> Utf8 Class Initialized
INFO - 2020-10-09 11:42:31 --> URI Class Initialized
INFO - 2020-10-09 11:42:31 --> Router Class Initialized
INFO - 2020-10-09 11:42:31 --> Output Class Initialized
INFO - 2020-10-09 11:42:31 --> Security Class Initialized
DEBUG - 2020-10-09 11:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:42:31 --> Input Class Initialized
INFO - 2020-10-09 11:42:31 --> Language Class Initialized
INFO - 2020-10-09 11:42:31 --> Loader Class Initialized
INFO - 2020-10-09 11:42:31 --> Helper loaded: url_helper
INFO - 2020-10-09 11:42:31 --> Database Driver Class Initialized
INFO - 2020-10-09 11:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:42:31 --> Email Class Initialized
INFO - 2020-10-09 11:42:31 --> Controller Class Initialized
DEBUG - 2020-10-09 11:42:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:42:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:42:31 --> Model Class Initialized
INFO - 2020-10-09 11:42:31 --> Model Class Initialized
INFO - 2020-10-09 11:42:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:42:31 --> Final output sent to browser
DEBUG - 2020-10-09 11:42:31 --> Total execution time: 0.0230
ERROR - 2020-10-09 11:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:15 --> Config Class Initialized
INFO - 2020-10-09 11:43:15 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:15 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:15 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:15 --> URI Class Initialized
INFO - 2020-10-09 11:43:15 --> Router Class Initialized
INFO - 2020-10-09 11:43:15 --> Output Class Initialized
INFO - 2020-10-09 11:43:15 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:15 --> Input Class Initialized
INFO - 2020-10-09 11:43:15 --> Language Class Initialized
INFO - 2020-10-09 11:43:15 --> Loader Class Initialized
INFO - 2020-10-09 11:43:15 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:15 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:15 --> Email Class Initialized
INFO - 2020-10-09 11:43:15 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:15 --> Model Class Initialized
INFO - 2020-10-09 11:43:15 --> Model Class Initialized
INFO - 2020-10-09 11:43:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:43:15 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:15 --> Total execution time: 0.0272
ERROR - 2020-10-09 11:43:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:26 --> Config Class Initialized
INFO - 2020-10-09 11:43:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:26 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:26 --> URI Class Initialized
INFO - 2020-10-09 11:43:26 --> Router Class Initialized
INFO - 2020-10-09 11:43:26 --> Output Class Initialized
INFO - 2020-10-09 11:43:26 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:26 --> Input Class Initialized
INFO - 2020-10-09 11:43:26 --> Language Class Initialized
INFO - 2020-10-09 11:43:26 --> Loader Class Initialized
INFO - 2020-10-09 11:43:26 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:26 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:26 --> Email Class Initialized
INFO - 2020-10-09 11:43:26 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:26 --> Model Class Initialized
INFO - 2020-10-09 11:43:26 --> Model Class Initialized
INFO - 2020-10-09 11:43:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:43:26 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:26 --> Total execution time: 0.0320
ERROR - 2020-10-09 11:43:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:29 --> Config Class Initialized
INFO - 2020-10-09 11:43:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:29 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:29 --> URI Class Initialized
INFO - 2020-10-09 11:43:29 --> Router Class Initialized
INFO - 2020-10-09 11:43:29 --> Output Class Initialized
INFO - 2020-10-09 11:43:29 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:29 --> Input Class Initialized
INFO - 2020-10-09 11:43:29 --> Language Class Initialized
INFO - 2020-10-09 11:43:29 --> Loader Class Initialized
INFO - 2020-10-09 11:43:29 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:29 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:29 --> Email Class Initialized
INFO - 2020-10-09 11:43:29 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:29 --> Model Class Initialized
INFO - 2020-10-09 11:43:29 --> Model Class Initialized
INFO - 2020-10-09 11:43:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:43:29 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:29 --> Total execution time: 0.0284
ERROR - 2020-10-09 11:43:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:43 --> Config Class Initialized
INFO - 2020-10-09 11:43:43 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:43 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:43 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:43 --> URI Class Initialized
INFO - 2020-10-09 11:43:43 --> Router Class Initialized
INFO - 2020-10-09 11:43:43 --> Output Class Initialized
INFO - 2020-10-09 11:43:43 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:43 --> Input Class Initialized
INFO - 2020-10-09 11:43:43 --> Language Class Initialized
INFO - 2020-10-09 11:43:43 --> Loader Class Initialized
INFO - 2020-10-09 11:43:43 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:43 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:43 --> Email Class Initialized
INFO - 2020-10-09 11:43:43 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:43 --> Model Class Initialized
INFO - 2020-10-09 11:43:43 --> Model Class Initialized
INFO - 2020-10-09 11:43:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:43:43 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:43 --> Total execution time: 0.0229
ERROR - 2020-10-09 11:43:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:48 --> Config Class Initialized
INFO - 2020-10-09 11:43:48 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:48 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:48 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:48 --> URI Class Initialized
INFO - 2020-10-09 11:43:48 --> Router Class Initialized
INFO - 2020-10-09 11:43:48 --> Output Class Initialized
INFO - 2020-10-09 11:43:48 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:48 --> Input Class Initialized
INFO - 2020-10-09 11:43:48 --> Language Class Initialized
INFO - 2020-10-09 11:43:48 --> Loader Class Initialized
INFO - 2020-10-09 11:43:48 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:48 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:48 --> Email Class Initialized
INFO - 2020-10-09 11:43:48 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:48 --> Model Class Initialized
INFO - 2020-10-09 11:43:48 --> Model Class Initialized
INFO - 2020-10-09 11:43:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:43:48 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:48 --> Total execution time: 0.0265
ERROR - 2020-10-09 11:43:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:50 --> Config Class Initialized
INFO - 2020-10-09 11:43:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:50 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:50 --> URI Class Initialized
INFO - 2020-10-09 11:43:50 --> Router Class Initialized
INFO - 2020-10-09 11:43:50 --> Output Class Initialized
INFO - 2020-10-09 11:43:50 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:50 --> Input Class Initialized
INFO - 2020-10-09 11:43:50 --> Language Class Initialized
INFO - 2020-10-09 11:43:50 --> Loader Class Initialized
INFO - 2020-10-09 11:43:50 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:50 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:50 --> Email Class Initialized
INFO - 2020-10-09 11:43:50 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:50 --> Model Class Initialized
INFO - 2020-10-09 11:43:50 --> Model Class Initialized
INFO - 2020-10-09 11:43:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 11:43:50 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:50 --> Total execution time: 0.0276
ERROR - 2020-10-09 11:43:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:52 --> Config Class Initialized
INFO - 2020-10-09 11:43:52 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:52 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:52 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:52 --> URI Class Initialized
INFO - 2020-10-09 11:43:52 --> Router Class Initialized
INFO - 2020-10-09 11:43:52 --> Output Class Initialized
INFO - 2020-10-09 11:43:52 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:52 --> Input Class Initialized
INFO - 2020-10-09 11:43:52 --> Language Class Initialized
INFO - 2020-10-09 11:43:52 --> Loader Class Initialized
INFO - 2020-10-09 11:43:52 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:52 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:52 --> Email Class Initialized
INFO - 2020-10-09 11:43:52 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:52 --> Model Class Initialized
INFO - 2020-10-09 11:43:52 --> Model Class Initialized
INFO - 2020-10-09 11:43:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:43:52 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:52 --> Total execution time: 0.0277
ERROR - 2020-10-09 11:43:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:43:56 --> Config Class Initialized
INFO - 2020-10-09 11:43:56 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:43:56 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:43:56 --> Utf8 Class Initialized
INFO - 2020-10-09 11:43:56 --> URI Class Initialized
INFO - 2020-10-09 11:43:56 --> Router Class Initialized
INFO - 2020-10-09 11:43:56 --> Output Class Initialized
INFO - 2020-10-09 11:43:56 --> Security Class Initialized
DEBUG - 2020-10-09 11:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:43:56 --> Input Class Initialized
INFO - 2020-10-09 11:43:56 --> Language Class Initialized
INFO - 2020-10-09 11:43:56 --> Loader Class Initialized
INFO - 2020-10-09 11:43:56 --> Helper loaded: url_helper
INFO - 2020-10-09 11:43:56 --> Database Driver Class Initialized
INFO - 2020-10-09 11:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:43:56 --> Email Class Initialized
INFO - 2020-10-09 11:43:56 --> Controller Class Initialized
DEBUG - 2020-10-09 11:43:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:43:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:43:56 --> Model Class Initialized
INFO - 2020-10-09 11:43:56 --> Model Class Initialized
INFO - 2020-10-09 11:43:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:43:56 --> Final output sent to browser
DEBUG - 2020-10-09 11:43:56 --> Total execution time: 0.0237
ERROR - 2020-10-09 11:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:44:02 --> Config Class Initialized
INFO - 2020-10-09 11:44:02 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:44:02 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:44:02 --> Utf8 Class Initialized
INFO - 2020-10-09 11:44:02 --> URI Class Initialized
INFO - 2020-10-09 11:44:02 --> Router Class Initialized
INFO - 2020-10-09 11:44:02 --> Output Class Initialized
INFO - 2020-10-09 11:44:02 --> Security Class Initialized
DEBUG - 2020-10-09 11:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:44:02 --> Input Class Initialized
INFO - 2020-10-09 11:44:02 --> Language Class Initialized
INFO - 2020-10-09 11:44:02 --> Loader Class Initialized
INFO - 2020-10-09 11:44:02 --> Helper loaded: url_helper
INFO - 2020-10-09 11:44:02 --> Database Driver Class Initialized
INFO - 2020-10-09 11:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:44:02 --> Email Class Initialized
INFO - 2020-10-09 11:44:02 --> Controller Class Initialized
DEBUG - 2020-10-09 11:44:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:44:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:44:02 --> Model Class Initialized
INFO - 2020-10-09 11:44:02 --> Model Class Initialized
INFO - 2020-10-09 11:44:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:44:02 --> Final output sent to browser
DEBUG - 2020-10-09 11:44:02 --> Total execution time: 0.0269
ERROR - 2020-10-09 11:44:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:44:38 --> Config Class Initialized
INFO - 2020-10-09 11:44:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:44:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:44:38 --> Utf8 Class Initialized
INFO - 2020-10-09 11:44:38 --> URI Class Initialized
INFO - 2020-10-09 11:44:38 --> Router Class Initialized
INFO - 2020-10-09 11:44:38 --> Output Class Initialized
INFO - 2020-10-09 11:44:38 --> Security Class Initialized
DEBUG - 2020-10-09 11:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:44:38 --> Input Class Initialized
INFO - 2020-10-09 11:44:38 --> Language Class Initialized
INFO - 2020-10-09 11:44:38 --> Loader Class Initialized
INFO - 2020-10-09 11:44:38 --> Helper loaded: url_helper
INFO - 2020-10-09 11:44:38 --> Database Driver Class Initialized
INFO - 2020-10-09 11:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:44:38 --> Email Class Initialized
INFO - 2020-10-09 11:44:38 --> Controller Class Initialized
DEBUG - 2020-10-09 11:44:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:44:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:44:38 --> Model Class Initialized
INFO - 2020-10-09 11:44:38 --> Model Class Initialized
INFO - 2020-10-09 11:44:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:44:38 --> Final output sent to browser
DEBUG - 2020-10-09 11:44:38 --> Total execution time: 0.0240
ERROR - 2020-10-09 11:46:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:46:24 --> Config Class Initialized
INFO - 2020-10-09 11:46:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:46:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:46:24 --> Utf8 Class Initialized
INFO - 2020-10-09 11:46:24 --> URI Class Initialized
INFO - 2020-10-09 11:46:24 --> Router Class Initialized
INFO - 2020-10-09 11:46:24 --> Output Class Initialized
INFO - 2020-10-09 11:46:24 --> Security Class Initialized
DEBUG - 2020-10-09 11:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:46:24 --> Input Class Initialized
INFO - 2020-10-09 11:46:24 --> Language Class Initialized
INFO - 2020-10-09 11:46:24 --> Loader Class Initialized
INFO - 2020-10-09 11:46:24 --> Helper loaded: url_helper
INFO - 2020-10-09 11:46:24 --> Database Driver Class Initialized
INFO - 2020-10-09 11:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:46:24 --> Email Class Initialized
INFO - 2020-10-09 11:46:24 --> Controller Class Initialized
DEBUG - 2020-10-09 11:46:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:46:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:46:24 --> Model Class Initialized
INFO - 2020-10-09 11:46:24 --> Model Class Initialized
INFO - 2020-10-09 11:46:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:46:24 --> Final output sent to browser
DEBUG - 2020-10-09 11:46:24 --> Total execution time: 0.0251
ERROR - 2020-10-09 11:47:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:47:00 --> Config Class Initialized
INFO - 2020-10-09 11:47:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:47:00 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:47:00 --> Utf8 Class Initialized
INFO - 2020-10-09 11:47:00 --> URI Class Initialized
INFO - 2020-10-09 11:47:00 --> Router Class Initialized
INFO - 2020-10-09 11:47:00 --> Output Class Initialized
INFO - 2020-10-09 11:47:00 --> Security Class Initialized
DEBUG - 2020-10-09 11:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:47:00 --> Input Class Initialized
INFO - 2020-10-09 11:47:00 --> Language Class Initialized
INFO - 2020-10-09 11:47:00 --> Loader Class Initialized
INFO - 2020-10-09 11:47:00 --> Helper loaded: url_helper
INFO - 2020-10-09 11:47:00 --> Database Driver Class Initialized
INFO - 2020-10-09 11:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:47:00 --> Email Class Initialized
INFO - 2020-10-09 11:47:00 --> Controller Class Initialized
DEBUG - 2020-10-09 11:47:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:47:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:47:00 --> Model Class Initialized
INFO - 2020-10-09 11:47:00 --> Model Class Initialized
INFO - 2020-10-09 11:47:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:47:00 --> Final output sent to browser
DEBUG - 2020-10-09 11:47:00 --> Total execution time: 0.0266
ERROR - 2020-10-09 11:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:47:09 --> Config Class Initialized
INFO - 2020-10-09 11:47:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:47:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:47:09 --> Utf8 Class Initialized
INFO - 2020-10-09 11:47:09 --> URI Class Initialized
INFO - 2020-10-09 11:47:09 --> Router Class Initialized
INFO - 2020-10-09 11:47:09 --> Output Class Initialized
INFO - 2020-10-09 11:47:09 --> Security Class Initialized
DEBUG - 2020-10-09 11:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:47:09 --> Input Class Initialized
INFO - 2020-10-09 11:47:09 --> Language Class Initialized
INFO - 2020-10-09 11:47:09 --> Loader Class Initialized
INFO - 2020-10-09 11:47:09 --> Helper loaded: url_helper
INFO - 2020-10-09 11:47:09 --> Database Driver Class Initialized
INFO - 2020-10-09 11:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:47:09 --> Email Class Initialized
INFO - 2020-10-09 11:47:09 --> Controller Class Initialized
DEBUG - 2020-10-09 11:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:47:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:47:09 --> Model Class Initialized
INFO - 2020-10-09 11:47:09 --> Model Class Initialized
INFO - 2020-10-09 11:47:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:47:09 --> Final output sent to browser
DEBUG - 2020-10-09 11:47:09 --> Total execution time: 0.0260
ERROR - 2020-10-09 11:47:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:47:13 --> Config Class Initialized
INFO - 2020-10-09 11:47:13 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:47:13 --> Utf8 Class Initialized
INFO - 2020-10-09 11:47:13 --> URI Class Initialized
INFO - 2020-10-09 11:47:13 --> Router Class Initialized
INFO - 2020-10-09 11:47:13 --> Output Class Initialized
INFO - 2020-10-09 11:47:13 --> Security Class Initialized
DEBUG - 2020-10-09 11:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:47:13 --> Input Class Initialized
INFO - 2020-10-09 11:47:13 --> Language Class Initialized
INFO - 2020-10-09 11:47:13 --> Loader Class Initialized
INFO - 2020-10-09 11:47:13 --> Helper loaded: url_helper
INFO - 2020-10-09 11:47:13 --> Database Driver Class Initialized
INFO - 2020-10-09 11:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:47:13 --> Email Class Initialized
INFO - 2020-10-09 11:47:13 --> Controller Class Initialized
DEBUG - 2020-10-09 11:47:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:47:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:47:13 --> Model Class Initialized
INFO - 2020-10-09 11:47:13 --> Model Class Initialized
INFO - 2020-10-09 11:47:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:47:13 --> Final output sent to browser
DEBUG - 2020-10-09 11:47:13 --> Total execution time: 0.0329
ERROR - 2020-10-09 11:47:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:47:15 --> Config Class Initialized
INFO - 2020-10-09 11:47:15 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:47:15 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:47:15 --> Utf8 Class Initialized
INFO - 2020-10-09 11:47:15 --> URI Class Initialized
INFO - 2020-10-09 11:47:15 --> Router Class Initialized
INFO - 2020-10-09 11:47:15 --> Output Class Initialized
INFO - 2020-10-09 11:47:15 --> Security Class Initialized
DEBUG - 2020-10-09 11:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:47:15 --> Input Class Initialized
INFO - 2020-10-09 11:47:15 --> Language Class Initialized
INFO - 2020-10-09 11:47:15 --> Loader Class Initialized
INFO - 2020-10-09 11:47:15 --> Helper loaded: url_helper
INFO - 2020-10-09 11:47:15 --> Database Driver Class Initialized
INFO - 2020-10-09 11:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:47:15 --> Email Class Initialized
INFO - 2020-10-09 11:47:15 --> Controller Class Initialized
DEBUG - 2020-10-09 11:47:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:47:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:47:15 --> Model Class Initialized
INFO - 2020-10-09 11:47:15 --> Model Class Initialized
INFO - 2020-10-09 11:47:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:47:15 --> Final output sent to browser
DEBUG - 2020-10-09 11:47:15 --> Total execution time: 0.0249
ERROR - 2020-10-09 11:47:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:47:19 --> Config Class Initialized
INFO - 2020-10-09 11:47:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:47:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:47:19 --> Utf8 Class Initialized
INFO - 2020-10-09 11:47:19 --> URI Class Initialized
INFO - 2020-10-09 11:47:19 --> Router Class Initialized
INFO - 2020-10-09 11:47:19 --> Output Class Initialized
INFO - 2020-10-09 11:47:19 --> Security Class Initialized
DEBUG - 2020-10-09 11:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:47:19 --> Input Class Initialized
INFO - 2020-10-09 11:47:19 --> Language Class Initialized
INFO - 2020-10-09 11:47:19 --> Loader Class Initialized
INFO - 2020-10-09 11:47:19 --> Helper loaded: url_helper
INFO - 2020-10-09 11:47:19 --> Database Driver Class Initialized
INFO - 2020-10-09 11:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:47:19 --> Email Class Initialized
INFO - 2020-10-09 11:47:19 --> Controller Class Initialized
DEBUG - 2020-10-09 11:47:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:47:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:47:19 --> Model Class Initialized
INFO - 2020-10-09 11:47:19 --> Model Class Initialized
INFO - 2020-10-09 11:47:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 11:47:19 --> Final output sent to browser
DEBUG - 2020-10-09 11:47:19 --> Total execution time: 0.0232
ERROR - 2020-10-09 11:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:48:41 --> Config Class Initialized
INFO - 2020-10-09 11:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:48:41 --> Utf8 Class Initialized
INFO - 2020-10-09 11:48:41 --> URI Class Initialized
INFO - 2020-10-09 11:48:41 --> Router Class Initialized
INFO - 2020-10-09 11:48:41 --> Output Class Initialized
INFO - 2020-10-09 11:48:41 --> Security Class Initialized
DEBUG - 2020-10-09 11:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:48:41 --> Input Class Initialized
INFO - 2020-10-09 11:48:41 --> Language Class Initialized
INFO - 2020-10-09 11:48:41 --> Loader Class Initialized
INFO - 2020-10-09 11:48:41 --> Helper loaded: url_helper
INFO - 2020-10-09 11:48:41 --> Database Driver Class Initialized
INFO - 2020-10-09 11:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:48:41 --> Email Class Initialized
INFO - 2020-10-09 11:48:41 --> Controller Class Initialized
DEBUG - 2020-10-09 11:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:48:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:48:41 --> Model Class Initialized
INFO - 2020-10-09 11:48:41 --> Model Class Initialized
INFO - 2020-10-09 11:48:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 11:48:41 --> Final output sent to browser
DEBUG - 2020-10-09 11:48:41 --> Total execution time: 0.0297
ERROR - 2020-10-09 11:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:48:42 --> Config Class Initialized
INFO - 2020-10-09 11:48:42 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:48:42 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:48:42 --> Utf8 Class Initialized
INFO - 2020-10-09 11:48:42 --> URI Class Initialized
INFO - 2020-10-09 11:48:42 --> Router Class Initialized
INFO - 2020-10-09 11:48:42 --> Output Class Initialized
INFO - 2020-10-09 11:48:42 --> Security Class Initialized
DEBUG - 2020-10-09 11:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:48:42 --> Input Class Initialized
INFO - 2020-10-09 11:48:42 --> Language Class Initialized
INFO - 2020-10-09 11:48:42 --> Loader Class Initialized
INFO - 2020-10-09 11:48:42 --> Helper loaded: url_helper
INFO - 2020-10-09 11:48:42 --> Database Driver Class Initialized
INFO - 2020-10-09 11:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:48:42 --> Email Class Initialized
INFO - 2020-10-09 11:48:42 --> Controller Class Initialized
DEBUG - 2020-10-09 11:48:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:48:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:48:42 --> Model Class Initialized
INFO - 2020-10-09 11:48:42 --> Model Class Initialized
INFO - 2020-10-09 11:48:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:48:42 --> Final output sent to browser
DEBUG - 2020-10-09 11:48:42 --> Total execution time: 0.0245
ERROR - 2020-10-09 11:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:49:20 --> Config Class Initialized
INFO - 2020-10-09 11:49:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:49:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:49:20 --> Utf8 Class Initialized
INFO - 2020-10-09 11:49:20 --> URI Class Initialized
INFO - 2020-10-09 11:49:20 --> Router Class Initialized
INFO - 2020-10-09 11:49:20 --> Output Class Initialized
INFO - 2020-10-09 11:49:20 --> Security Class Initialized
DEBUG - 2020-10-09 11:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:49:20 --> Input Class Initialized
INFO - 2020-10-09 11:49:20 --> Language Class Initialized
INFO - 2020-10-09 11:49:20 --> Loader Class Initialized
INFO - 2020-10-09 11:49:20 --> Helper loaded: url_helper
INFO - 2020-10-09 11:49:20 --> Database Driver Class Initialized
INFO - 2020-10-09 11:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:49:20 --> Email Class Initialized
INFO - 2020-10-09 11:49:20 --> Controller Class Initialized
DEBUG - 2020-10-09 11:49:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:49:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:49:20 --> Model Class Initialized
INFO - 2020-10-09 11:49:20 --> Model Class Initialized
INFO - 2020-10-09 11:49:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:49:20 --> Final output sent to browser
DEBUG - 2020-10-09 11:49:20 --> Total execution time: 0.0259
ERROR - 2020-10-09 11:49:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:49:27 --> Config Class Initialized
INFO - 2020-10-09 11:49:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:49:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:49:27 --> Utf8 Class Initialized
INFO - 2020-10-09 11:49:27 --> URI Class Initialized
INFO - 2020-10-09 11:49:27 --> Router Class Initialized
INFO - 2020-10-09 11:49:27 --> Output Class Initialized
INFO - 2020-10-09 11:49:27 --> Security Class Initialized
DEBUG - 2020-10-09 11:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:49:27 --> Input Class Initialized
INFO - 2020-10-09 11:49:27 --> Language Class Initialized
INFO - 2020-10-09 11:49:27 --> Loader Class Initialized
INFO - 2020-10-09 11:49:27 --> Helper loaded: url_helper
INFO - 2020-10-09 11:49:27 --> Database Driver Class Initialized
INFO - 2020-10-09 11:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:49:27 --> Email Class Initialized
INFO - 2020-10-09 11:49:27 --> Controller Class Initialized
DEBUG - 2020-10-09 11:49:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:49:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:49:27 --> Model Class Initialized
INFO - 2020-10-09 11:49:27 --> Model Class Initialized
INFO - 2020-10-09 11:49:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:49:27 --> Final output sent to browser
DEBUG - 2020-10-09 11:49:27 --> Total execution time: 0.0235
ERROR - 2020-10-09 11:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:50:26 --> Config Class Initialized
INFO - 2020-10-09 11:50:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:50:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:50:26 --> Utf8 Class Initialized
INFO - 2020-10-09 11:50:26 --> URI Class Initialized
INFO - 2020-10-09 11:50:26 --> Router Class Initialized
INFO - 2020-10-09 11:50:26 --> Output Class Initialized
INFO - 2020-10-09 11:50:26 --> Security Class Initialized
DEBUG - 2020-10-09 11:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:50:26 --> Input Class Initialized
INFO - 2020-10-09 11:50:26 --> Language Class Initialized
INFO - 2020-10-09 11:50:26 --> Loader Class Initialized
INFO - 2020-10-09 11:50:26 --> Helper loaded: url_helper
INFO - 2020-10-09 11:50:26 --> Database Driver Class Initialized
INFO - 2020-10-09 11:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:50:26 --> Email Class Initialized
INFO - 2020-10-09 11:50:26 --> Controller Class Initialized
DEBUG - 2020-10-09 11:50:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:50:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:50:26 --> Model Class Initialized
INFO - 2020-10-09 11:50:26 --> Model Class Initialized
INFO - 2020-10-09 11:50:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:50:26 --> Final output sent to browser
DEBUG - 2020-10-09 11:50:26 --> Total execution time: 0.0237
ERROR - 2020-10-09 11:50:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:50:28 --> Config Class Initialized
INFO - 2020-10-09 11:50:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:50:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:50:28 --> Utf8 Class Initialized
INFO - 2020-10-09 11:50:28 --> URI Class Initialized
INFO - 2020-10-09 11:50:28 --> Router Class Initialized
INFO - 2020-10-09 11:50:28 --> Output Class Initialized
INFO - 2020-10-09 11:50:28 --> Security Class Initialized
DEBUG - 2020-10-09 11:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:50:28 --> Input Class Initialized
INFO - 2020-10-09 11:50:28 --> Language Class Initialized
INFO - 2020-10-09 11:50:28 --> Loader Class Initialized
INFO - 2020-10-09 11:50:28 --> Helper loaded: url_helper
INFO - 2020-10-09 11:50:28 --> Database Driver Class Initialized
INFO - 2020-10-09 11:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:50:28 --> Email Class Initialized
INFO - 2020-10-09 11:50:28 --> Controller Class Initialized
DEBUG - 2020-10-09 11:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:50:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:50:28 --> Model Class Initialized
INFO - 2020-10-09 11:50:29 --> Model Class Initialized
INFO - 2020-10-09 11:50:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 11:50:29 --> Final output sent to browser
DEBUG - 2020-10-09 11:50:29 --> Total execution time: 0.0259
ERROR - 2020-10-09 11:51:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 11:51:09 --> Config Class Initialized
INFO - 2020-10-09 11:51:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 11:51:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 11:51:09 --> Utf8 Class Initialized
INFO - 2020-10-09 11:51:09 --> URI Class Initialized
INFO - 2020-10-09 11:51:09 --> Router Class Initialized
INFO - 2020-10-09 11:51:09 --> Output Class Initialized
INFO - 2020-10-09 11:51:09 --> Security Class Initialized
DEBUG - 2020-10-09 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 11:51:09 --> Input Class Initialized
INFO - 2020-10-09 11:51:09 --> Language Class Initialized
INFO - 2020-10-09 11:51:09 --> Loader Class Initialized
INFO - 2020-10-09 11:51:09 --> Helper loaded: url_helper
INFO - 2020-10-09 11:51:09 --> Database Driver Class Initialized
INFO - 2020-10-09 11:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 11:51:09 --> Email Class Initialized
INFO - 2020-10-09 11:51:09 --> Controller Class Initialized
DEBUG - 2020-10-09 11:51:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 11:51:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 11:51:09 --> Model Class Initialized
INFO - 2020-10-09 11:51:09 --> Model Class Initialized
INFO - 2020-10-09 11:51:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 11:51:09 --> Final output sent to browser
DEBUG - 2020-10-09 11:51:09 --> Total execution time: 0.0278
ERROR - 2020-10-09 12:07:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:07:36 --> Config Class Initialized
INFO - 2020-10-09 12:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:07:36 --> Utf8 Class Initialized
INFO - 2020-10-09 12:07:36 --> URI Class Initialized
INFO - 2020-10-09 12:07:36 --> Router Class Initialized
INFO - 2020-10-09 12:07:36 --> Output Class Initialized
INFO - 2020-10-09 12:07:36 --> Security Class Initialized
DEBUG - 2020-10-09 12:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:07:36 --> Input Class Initialized
INFO - 2020-10-09 12:07:36 --> Language Class Initialized
INFO - 2020-10-09 12:07:36 --> Loader Class Initialized
INFO - 2020-10-09 12:07:36 --> Helper loaded: url_helper
INFO - 2020-10-09 12:07:36 --> Database Driver Class Initialized
INFO - 2020-10-09 12:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:07:36 --> Email Class Initialized
INFO - 2020-10-09 12:07:36 --> Controller Class Initialized
DEBUG - 2020-10-09 12:07:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:07:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:07:36 --> Model Class Initialized
INFO - 2020-10-09 12:07:36 --> Model Class Initialized
INFO - 2020-10-09 12:07:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:07:36 --> Final output sent to browser
DEBUG - 2020-10-09 12:07:36 --> Total execution time: 0.0254
ERROR - 2020-10-09 12:09:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:09:07 --> Config Class Initialized
INFO - 2020-10-09 12:09:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:09:07 --> Utf8 Class Initialized
INFO - 2020-10-09 12:09:07 --> URI Class Initialized
INFO - 2020-10-09 12:09:07 --> Router Class Initialized
INFO - 2020-10-09 12:09:07 --> Output Class Initialized
INFO - 2020-10-09 12:09:07 --> Security Class Initialized
DEBUG - 2020-10-09 12:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:09:07 --> Input Class Initialized
INFO - 2020-10-09 12:09:07 --> Language Class Initialized
INFO - 2020-10-09 12:09:07 --> Loader Class Initialized
INFO - 2020-10-09 12:09:07 --> Helper loaded: url_helper
INFO - 2020-10-09 12:09:07 --> Database Driver Class Initialized
INFO - 2020-10-09 12:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:09:07 --> Email Class Initialized
INFO - 2020-10-09 12:09:07 --> Controller Class Initialized
DEBUG - 2020-10-09 12:09:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:09:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:09:07 --> Model Class Initialized
INFO - 2020-10-09 12:09:07 --> Model Class Initialized
INFO - 2020-10-09 12:09:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:09:07 --> Final output sent to browser
DEBUG - 2020-10-09 12:09:07 --> Total execution time: 0.0202
ERROR - 2020-10-09 12:09:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:09:09 --> Config Class Initialized
INFO - 2020-10-09 12:09:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:09:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:09:09 --> Utf8 Class Initialized
INFO - 2020-10-09 12:09:09 --> URI Class Initialized
INFO - 2020-10-09 12:09:09 --> Router Class Initialized
INFO - 2020-10-09 12:09:09 --> Output Class Initialized
INFO - 2020-10-09 12:09:09 --> Security Class Initialized
DEBUG - 2020-10-09 12:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:09:09 --> Input Class Initialized
INFO - 2020-10-09 12:09:09 --> Language Class Initialized
INFO - 2020-10-09 12:09:09 --> Loader Class Initialized
INFO - 2020-10-09 12:09:09 --> Helper loaded: url_helper
INFO - 2020-10-09 12:09:09 --> Database Driver Class Initialized
INFO - 2020-10-09 12:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:09:09 --> Email Class Initialized
INFO - 2020-10-09 12:09:09 --> Controller Class Initialized
DEBUG - 2020-10-09 12:09:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:09:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:09:09 --> Model Class Initialized
INFO - 2020-10-09 12:09:09 --> Model Class Initialized
INFO - 2020-10-09 12:09:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:09:09 --> Final output sent to browser
DEBUG - 2020-10-09 12:09:09 --> Total execution time: 0.0230
ERROR - 2020-10-09 12:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:14:24 --> Config Class Initialized
INFO - 2020-10-09 12:14:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:14:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:14:24 --> Utf8 Class Initialized
INFO - 2020-10-09 12:14:24 --> URI Class Initialized
INFO - 2020-10-09 12:14:24 --> Router Class Initialized
INFO - 2020-10-09 12:14:24 --> Output Class Initialized
INFO - 2020-10-09 12:14:24 --> Security Class Initialized
DEBUG - 2020-10-09 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:14:24 --> Input Class Initialized
INFO - 2020-10-09 12:14:24 --> Language Class Initialized
INFO - 2020-10-09 12:14:24 --> Loader Class Initialized
INFO - 2020-10-09 12:14:24 --> Helper loaded: url_helper
INFO - 2020-10-09 12:14:24 --> Database Driver Class Initialized
INFO - 2020-10-09 12:14:24 --> Session: Class initialized using 'files' driver.
ERROR - 2020-10-09 12:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:14:24 --> Email Class Initialized
INFO - 2020-10-09 12:14:24 --> Controller Class Initialized
DEBUG - 2020-10-09 12:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:14:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:14:24 --> Model Class Initialized
INFO - 2020-10-09 12:14:24 --> Config Class Initialized
INFO - 2020-10-09 12:14:24 --> Hooks Class Initialized
INFO - 2020-10-09 12:14:24 --> Model Class Initialized
DEBUG - 2020-10-09 12:14:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:14:24 --> Utf8 Class Initialized
INFO - 2020-10-09 12:14:24 --> URI Class Initialized
INFO - 2020-10-09 12:14:24 --> Router Class Initialized
INFO - 2020-10-09 12:14:24 --> Output Class Initialized
INFO - 2020-10-09 12:14:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:14:24 --> Final output sent to browser
DEBUG - 2020-10-09 12:14:24 --> Total execution time: 0.0379
INFO - 2020-10-09 12:14:24 --> Security Class Initialized
DEBUG - 2020-10-09 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:14:24 --> Input Class Initialized
INFO - 2020-10-09 12:14:24 --> Language Class Initialized
INFO - 2020-10-09 12:14:24 --> Loader Class Initialized
INFO - 2020-10-09 12:14:24 --> Helper loaded: url_helper
INFO - 2020-10-09 12:14:24 --> Database Driver Class Initialized
INFO - 2020-10-09 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:14:24 --> Email Class Initialized
INFO - 2020-10-09 12:14:24 --> Controller Class Initialized
DEBUG - 2020-10-09 12:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:14:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:14:24 --> Model Class Initialized
INFO - 2020-10-09 12:14:24 --> Model Class Initialized
INFO - 2020-10-09 12:14:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:14:24 --> Final output sent to browser
DEBUG - 2020-10-09 12:14:24 --> Total execution time: 0.0415
ERROR - 2020-10-09 12:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:14:24 --> Config Class Initialized
INFO - 2020-10-09 12:14:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:14:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:14:24 --> Utf8 Class Initialized
INFO - 2020-10-09 12:14:24 --> URI Class Initialized
INFO - 2020-10-09 12:14:24 --> Router Class Initialized
INFO - 2020-10-09 12:14:24 --> Output Class Initialized
INFO - 2020-10-09 12:14:24 --> Security Class Initialized
DEBUG - 2020-10-09 12:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:14:24 --> Input Class Initialized
INFO - 2020-10-09 12:14:24 --> Language Class Initialized
INFO - 2020-10-09 12:14:24 --> Loader Class Initialized
INFO - 2020-10-09 12:14:24 --> Helper loaded: url_helper
INFO - 2020-10-09 12:14:24 --> Database Driver Class Initialized
INFO - 2020-10-09 12:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:14:24 --> Email Class Initialized
INFO - 2020-10-09 12:14:24 --> Controller Class Initialized
DEBUG - 2020-10-09 12:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:14:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:14:24 --> Model Class Initialized
INFO - 2020-10-09 12:14:24 --> Model Class Initialized
INFO - 2020-10-09 12:14:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:14:24 --> Final output sent to browser
DEBUG - 2020-10-09 12:14:24 --> Total execution time: 0.0425
ERROR - 2020-10-09 12:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:14:27 --> Config Class Initialized
INFO - 2020-10-09 12:14:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:14:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:14:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:14:27 --> URI Class Initialized
INFO - 2020-10-09 12:14:27 --> Router Class Initialized
INFO - 2020-10-09 12:14:27 --> Output Class Initialized
INFO - 2020-10-09 12:14:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:14:27 --> Input Class Initialized
INFO - 2020-10-09 12:14:27 --> Language Class Initialized
INFO - 2020-10-09 12:14:27 --> Loader Class Initialized
INFO - 2020-10-09 12:14:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:14:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:14:27 --> Email Class Initialized
INFO - 2020-10-09 12:14:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:14:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:14:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:14:27 --> Model Class Initialized
INFO - 2020-10-09 12:14:27 --> Model Class Initialized
INFO - 2020-10-09 12:14:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:14:27 --> Final output sent to browser
DEBUG - 2020-10-09 12:14:27 --> Total execution time: 0.0277
ERROR - 2020-10-09 12:14:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:14:32 --> Config Class Initialized
INFO - 2020-10-09 12:14:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:14:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:14:32 --> Utf8 Class Initialized
INFO - 2020-10-09 12:14:32 --> URI Class Initialized
INFO - 2020-10-09 12:14:32 --> Router Class Initialized
INFO - 2020-10-09 12:14:32 --> Output Class Initialized
INFO - 2020-10-09 12:14:32 --> Security Class Initialized
DEBUG - 2020-10-09 12:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:14:32 --> Input Class Initialized
INFO - 2020-10-09 12:14:32 --> Language Class Initialized
INFO - 2020-10-09 12:14:32 --> Loader Class Initialized
INFO - 2020-10-09 12:14:32 --> Helper loaded: url_helper
INFO - 2020-10-09 12:14:32 --> Database Driver Class Initialized
INFO - 2020-10-09 12:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:14:32 --> Email Class Initialized
INFO - 2020-10-09 12:14:32 --> Controller Class Initialized
DEBUG - 2020-10-09 12:14:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:14:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:14:32 --> Model Class Initialized
INFO - 2020-10-09 12:14:32 --> Model Class Initialized
ERROR - 2020-10-09 12:14:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL rep_wise_client_status_update_master_list(36,)
INFO - 2020-10-09 12:14:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 12:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:17:58 --> Config Class Initialized
INFO - 2020-10-09 12:17:58 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:17:58 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:17:58 --> Utf8 Class Initialized
INFO - 2020-10-09 12:17:58 --> URI Class Initialized
INFO - 2020-10-09 12:17:58 --> Router Class Initialized
INFO - 2020-10-09 12:17:58 --> Output Class Initialized
INFO - 2020-10-09 12:17:58 --> Security Class Initialized
DEBUG - 2020-10-09 12:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:17:58 --> Input Class Initialized
INFO - 2020-10-09 12:17:58 --> Language Class Initialized
INFO - 2020-10-09 12:17:58 --> Loader Class Initialized
INFO - 2020-10-09 12:17:58 --> Helper loaded: url_helper
INFO - 2020-10-09 12:17:58 --> Database Driver Class Initialized
INFO - 2020-10-09 12:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:17:58 --> Email Class Initialized
INFO - 2020-10-09 12:17:58 --> Controller Class Initialized
DEBUG - 2020-10-09 12:17:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:17:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:17:58 --> Model Class Initialized
INFO - 2020-10-09 12:17:58 --> Model Class Initialized
INFO - 2020-10-09 12:17:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:17:58 --> Final output sent to browser
DEBUG - 2020-10-09 12:17:58 --> Total execution time: 0.0290
ERROR - 2020-10-09 12:18:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:18:01 --> Config Class Initialized
INFO - 2020-10-09 12:18:01 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:18:01 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:18:01 --> Utf8 Class Initialized
INFO - 2020-10-09 12:18:01 --> URI Class Initialized
INFO - 2020-10-09 12:18:01 --> Router Class Initialized
INFO - 2020-10-09 12:18:01 --> Output Class Initialized
INFO - 2020-10-09 12:18:01 --> Security Class Initialized
DEBUG - 2020-10-09 12:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:18:01 --> Input Class Initialized
INFO - 2020-10-09 12:18:01 --> Language Class Initialized
INFO - 2020-10-09 12:18:01 --> Loader Class Initialized
INFO - 2020-10-09 12:18:01 --> Helper loaded: url_helper
INFO - 2020-10-09 12:18:01 --> Database Driver Class Initialized
INFO - 2020-10-09 12:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:18:01 --> Email Class Initialized
INFO - 2020-10-09 12:18:01 --> Controller Class Initialized
DEBUG - 2020-10-09 12:18:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:18:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:18:01 --> Model Class Initialized
INFO - 2020-10-09 12:18:01 --> Model Class Initialized
INFO - 2020-10-09 12:18:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:18:01 --> Final output sent to browser
DEBUG - 2020-10-09 12:18:01 --> Total execution time: 0.0282
ERROR - 2020-10-09 12:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:18:06 --> Config Class Initialized
INFO - 2020-10-09 12:18:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:18:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:18:06 --> Utf8 Class Initialized
INFO - 2020-10-09 12:18:06 --> URI Class Initialized
INFO - 2020-10-09 12:18:06 --> Router Class Initialized
INFO - 2020-10-09 12:18:06 --> Output Class Initialized
INFO - 2020-10-09 12:18:06 --> Security Class Initialized
DEBUG - 2020-10-09 12:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:18:06 --> Input Class Initialized
INFO - 2020-10-09 12:18:06 --> Language Class Initialized
INFO - 2020-10-09 12:18:06 --> Loader Class Initialized
INFO - 2020-10-09 12:18:06 --> Helper loaded: url_helper
INFO - 2020-10-09 12:18:06 --> Database Driver Class Initialized
INFO - 2020-10-09 12:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:18:06 --> Email Class Initialized
INFO - 2020-10-09 12:18:06 --> Controller Class Initialized
DEBUG - 2020-10-09 12:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:18:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:18:06 --> Model Class Initialized
INFO - 2020-10-09 12:18:06 --> Model Class Initialized
INFO - 2020-10-09 12:18:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:18:06 --> Final output sent to browser
DEBUG - 2020-10-09 12:18:06 --> Total execution time: 0.0253
ERROR - 2020-10-09 12:18:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:18:08 --> Config Class Initialized
INFO - 2020-10-09 12:18:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:18:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:18:08 --> Utf8 Class Initialized
INFO - 2020-10-09 12:18:08 --> URI Class Initialized
INFO - 2020-10-09 12:18:08 --> Router Class Initialized
INFO - 2020-10-09 12:18:08 --> Output Class Initialized
INFO - 2020-10-09 12:18:08 --> Security Class Initialized
DEBUG - 2020-10-09 12:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:18:08 --> Input Class Initialized
INFO - 2020-10-09 12:18:08 --> Language Class Initialized
INFO - 2020-10-09 12:18:08 --> Loader Class Initialized
INFO - 2020-10-09 12:18:08 --> Helper loaded: url_helper
INFO - 2020-10-09 12:18:08 --> Database Driver Class Initialized
INFO - 2020-10-09 12:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:18:08 --> Email Class Initialized
INFO - 2020-10-09 12:18:08 --> Controller Class Initialized
DEBUG - 2020-10-09 12:18:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:18:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:18:08 --> Model Class Initialized
INFO - 2020-10-09 12:18:08 --> Model Class Initialized
INFO - 2020-10-09 12:18:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:18:08 --> Final output sent to browser
DEBUG - 2020-10-09 12:18:08 --> Total execution time: 0.0229
ERROR - 2020-10-09 12:18:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:18:11 --> Config Class Initialized
INFO - 2020-10-09 12:18:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:18:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:18:11 --> Utf8 Class Initialized
INFO - 2020-10-09 12:18:11 --> URI Class Initialized
INFO - 2020-10-09 12:18:11 --> Router Class Initialized
INFO - 2020-10-09 12:18:11 --> Output Class Initialized
INFO - 2020-10-09 12:18:11 --> Security Class Initialized
DEBUG - 2020-10-09 12:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:18:11 --> Input Class Initialized
INFO - 2020-10-09 12:18:11 --> Language Class Initialized
INFO - 2020-10-09 12:18:11 --> Loader Class Initialized
INFO - 2020-10-09 12:18:11 --> Helper loaded: url_helper
INFO - 2020-10-09 12:18:11 --> Database Driver Class Initialized
INFO - 2020-10-09 12:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:18:11 --> Email Class Initialized
INFO - 2020-10-09 12:18:11 --> Controller Class Initialized
DEBUG - 2020-10-09 12:18:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:18:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:18:11 --> Model Class Initialized
INFO - 2020-10-09 12:18:11 --> Model Class Initialized
INFO - 2020-10-09 12:18:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:18:11 --> Final output sent to browser
DEBUG - 2020-10-09 12:18:11 --> Total execution time: 0.0262
ERROR - 2020-10-09 12:18:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:18:30 --> Config Class Initialized
INFO - 2020-10-09 12:18:30 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:18:30 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:18:30 --> Utf8 Class Initialized
INFO - 2020-10-09 12:18:30 --> URI Class Initialized
INFO - 2020-10-09 12:18:30 --> Router Class Initialized
INFO - 2020-10-09 12:18:30 --> Output Class Initialized
INFO - 2020-10-09 12:18:30 --> Security Class Initialized
DEBUG - 2020-10-09 12:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:18:30 --> Input Class Initialized
INFO - 2020-10-09 12:18:30 --> Language Class Initialized
INFO - 2020-10-09 12:18:30 --> Loader Class Initialized
INFO - 2020-10-09 12:18:30 --> Helper loaded: url_helper
INFO - 2020-10-09 12:18:30 --> Database Driver Class Initialized
INFO - 2020-10-09 12:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:18:30 --> Email Class Initialized
INFO - 2020-10-09 12:18:30 --> Controller Class Initialized
DEBUG - 2020-10-09 12:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:18:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:18:30 --> Model Class Initialized
INFO - 2020-10-09 12:18:30 --> Model Class Initialized
ERROR - 2020-10-09 12:18:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL rep_wise_client_status_update_master_list(36,)
INFO - 2020-10-09 12:18:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 12:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:20:27 --> Config Class Initialized
INFO - 2020-10-09 12:20:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:20:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:20:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:20:27 --> URI Class Initialized
INFO - 2020-10-09 12:20:27 --> Router Class Initialized
INFO - 2020-10-09 12:20:27 --> Output Class Initialized
INFO - 2020-10-09 12:20:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:20:27 --> Input Class Initialized
INFO - 2020-10-09 12:20:27 --> Language Class Initialized
INFO - 2020-10-09 12:20:27 --> Loader Class Initialized
INFO - 2020-10-09 12:20:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:20:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:20:27 --> Email Class Initialized
INFO - 2020-10-09 12:20:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:20:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:20:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:20:27 --> Model Class Initialized
INFO - 2020-10-09 12:20:27 --> Model Class Initialized
ERROR - 2020-10-09 12:20:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL rep_wise_client_status_update_master_list(36,)
INFO - 2020-10-09 12:20:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 12:20:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:20:37 --> Config Class Initialized
INFO - 2020-10-09 12:20:37 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:20:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:20:37 --> Utf8 Class Initialized
INFO - 2020-10-09 12:20:37 --> URI Class Initialized
INFO - 2020-10-09 12:20:37 --> Router Class Initialized
INFO - 2020-10-09 12:20:37 --> Output Class Initialized
INFO - 2020-10-09 12:20:37 --> Security Class Initialized
DEBUG - 2020-10-09 12:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:20:37 --> Input Class Initialized
INFO - 2020-10-09 12:20:37 --> Language Class Initialized
INFO - 2020-10-09 12:20:37 --> Loader Class Initialized
INFO - 2020-10-09 12:20:37 --> Helper loaded: url_helper
INFO - 2020-10-09 12:20:37 --> Database Driver Class Initialized
INFO - 2020-10-09 12:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:20:37 --> Email Class Initialized
INFO - 2020-10-09 12:20:37 --> Controller Class Initialized
DEBUG - 2020-10-09 12:20:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:20:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:20:37 --> Model Class Initialized
INFO - 2020-10-09 12:20:37 --> Model Class Initialized
INFO - 2020-10-09 12:20:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:20:37 --> Final output sent to browser
DEBUG - 2020-10-09 12:20:37 --> Total execution time: 0.0254
ERROR - 2020-10-09 12:21:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:21:09 --> Config Class Initialized
INFO - 2020-10-09 12:21:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:21:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:21:09 --> Utf8 Class Initialized
INFO - 2020-10-09 12:21:09 --> URI Class Initialized
INFO - 2020-10-09 12:21:09 --> Router Class Initialized
INFO - 2020-10-09 12:21:09 --> Output Class Initialized
INFO - 2020-10-09 12:21:09 --> Security Class Initialized
DEBUG - 2020-10-09 12:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:21:09 --> Input Class Initialized
INFO - 2020-10-09 12:21:09 --> Language Class Initialized
INFO - 2020-10-09 12:21:09 --> Loader Class Initialized
INFO - 2020-10-09 12:21:09 --> Helper loaded: url_helper
INFO - 2020-10-09 12:21:09 --> Database Driver Class Initialized
INFO - 2020-10-09 12:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:21:09 --> Email Class Initialized
INFO - 2020-10-09 12:21:09 --> Controller Class Initialized
DEBUG - 2020-10-09 12:21:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:21:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:21:09 --> Model Class Initialized
INFO - 2020-10-09 12:21:09 --> Model Class Initialized
INFO - 2020-10-09 12:21:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:21:09 --> Final output sent to browser
DEBUG - 2020-10-09 12:21:09 --> Total execution time: 0.0245
ERROR - 2020-10-09 12:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:21:18 --> Config Class Initialized
INFO - 2020-10-09 12:21:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:21:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:21:18 --> Utf8 Class Initialized
INFO - 2020-10-09 12:21:18 --> URI Class Initialized
INFO - 2020-10-09 12:21:18 --> Router Class Initialized
INFO - 2020-10-09 12:21:18 --> Output Class Initialized
INFO - 2020-10-09 12:21:18 --> Security Class Initialized
DEBUG - 2020-10-09 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:21:18 --> Input Class Initialized
INFO - 2020-10-09 12:21:18 --> Language Class Initialized
INFO - 2020-10-09 12:21:18 --> Loader Class Initialized
INFO - 2020-10-09 12:21:18 --> Helper loaded: url_helper
INFO - 2020-10-09 12:21:18 --> Database Driver Class Initialized
INFO - 2020-10-09 12:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:21:18 --> Email Class Initialized
INFO - 2020-10-09 12:21:18 --> Controller Class Initialized
DEBUG - 2020-10-09 12:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:21:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:21:18 --> Model Class Initialized
INFO - 2020-10-09 12:21:18 --> Model Class Initialized
INFO - 2020-10-09 12:21:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:21:18 --> Final output sent to browser
DEBUG - 2020-10-09 12:21:18 --> Total execution time: 0.0259
ERROR - 2020-10-09 12:21:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:21:21 --> Config Class Initialized
INFO - 2020-10-09 12:21:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:21:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:21:21 --> Utf8 Class Initialized
INFO - 2020-10-09 12:21:21 --> URI Class Initialized
INFO - 2020-10-09 12:21:21 --> Router Class Initialized
INFO - 2020-10-09 12:21:21 --> Output Class Initialized
INFO - 2020-10-09 12:21:21 --> Security Class Initialized
DEBUG - 2020-10-09 12:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:21:21 --> Input Class Initialized
INFO - 2020-10-09 12:21:21 --> Language Class Initialized
INFO - 2020-10-09 12:21:21 --> Loader Class Initialized
INFO - 2020-10-09 12:21:21 --> Helper loaded: url_helper
INFO - 2020-10-09 12:21:21 --> Database Driver Class Initialized
INFO - 2020-10-09 12:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:21:21 --> Email Class Initialized
INFO - 2020-10-09 12:21:21 --> Controller Class Initialized
DEBUG - 2020-10-09 12:21:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:21:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:21:21 --> Model Class Initialized
INFO - 2020-10-09 12:21:21 --> Model Class Initialized
INFO - 2020-10-09 12:21:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:21:21 --> Final output sent to browser
DEBUG - 2020-10-09 12:21:21 --> Total execution time: 0.0249
ERROR - 2020-10-09 12:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:21:33 --> Config Class Initialized
INFO - 2020-10-09 12:21:33 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:21:33 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:21:33 --> Utf8 Class Initialized
INFO - 2020-10-09 12:21:33 --> URI Class Initialized
INFO - 2020-10-09 12:21:33 --> Router Class Initialized
INFO - 2020-10-09 12:21:33 --> Output Class Initialized
INFO - 2020-10-09 12:21:33 --> Security Class Initialized
DEBUG - 2020-10-09 12:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:21:33 --> Input Class Initialized
INFO - 2020-10-09 12:21:33 --> Language Class Initialized
INFO - 2020-10-09 12:21:33 --> Loader Class Initialized
INFO - 2020-10-09 12:21:33 --> Helper loaded: url_helper
INFO - 2020-10-09 12:21:33 --> Database Driver Class Initialized
INFO - 2020-10-09 12:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:21:33 --> Email Class Initialized
INFO - 2020-10-09 12:21:33 --> Controller Class Initialized
DEBUG - 2020-10-09 12:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:21:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:21:33 --> Model Class Initialized
INFO - 2020-10-09 12:21:33 --> Model Class Initialized
INFO - 2020-10-09 12:21:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:21:33 --> Final output sent to browser
DEBUG - 2020-10-09 12:21:33 --> Total execution time: 0.0278
ERROR - 2020-10-09 12:21:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:21:38 --> Config Class Initialized
INFO - 2020-10-09 12:21:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:21:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:21:38 --> Utf8 Class Initialized
INFO - 2020-10-09 12:21:38 --> URI Class Initialized
INFO - 2020-10-09 12:21:38 --> Router Class Initialized
INFO - 2020-10-09 12:21:38 --> Output Class Initialized
INFO - 2020-10-09 12:21:38 --> Security Class Initialized
DEBUG - 2020-10-09 12:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:21:38 --> Input Class Initialized
INFO - 2020-10-09 12:21:38 --> Language Class Initialized
INFO - 2020-10-09 12:21:38 --> Loader Class Initialized
INFO - 2020-10-09 12:21:38 --> Helper loaded: url_helper
INFO - 2020-10-09 12:21:38 --> Database Driver Class Initialized
INFO - 2020-10-09 12:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:21:38 --> Email Class Initialized
INFO - 2020-10-09 12:21:38 --> Controller Class Initialized
DEBUG - 2020-10-09 12:21:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:21:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:21:38 --> Model Class Initialized
INFO - 2020-10-09 12:21:38 --> Model Class Initialized
ERROR - 2020-10-09 12:21:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL rep_wise_client_status_update_master_list(36,)
INFO - 2020-10-09 12:21:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 12:21:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php:518) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-09 12:24:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:24:21 --> Config Class Initialized
INFO - 2020-10-09 12:24:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:24:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:24:21 --> Utf8 Class Initialized
INFO - 2020-10-09 12:24:21 --> URI Class Initialized
INFO - 2020-10-09 12:24:21 --> Router Class Initialized
INFO - 2020-10-09 12:24:21 --> Output Class Initialized
INFO - 2020-10-09 12:24:21 --> Security Class Initialized
DEBUG - 2020-10-09 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:24:21 --> Input Class Initialized
INFO - 2020-10-09 12:24:21 --> Language Class Initialized
INFO - 2020-10-09 12:24:21 --> Loader Class Initialized
INFO - 2020-10-09 12:24:21 --> Helper loaded: url_helper
INFO - 2020-10-09 12:24:21 --> Database Driver Class Initialized
INFO - 2020-10-09 12:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:24:21 --> Email Class Initialized
INFO - 2020-10-09 12:24:21 --> Controller Class Initialized
DEBUG - 2020-10-09 12:24:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:24:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:24:21 --> Model Class Initialized
INFO - 2020-10-09 12:24:21 --> Model Class Initialized
INFO - 2020-10-09 12:24:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:24:21 --> Final output sent to browser
DEBUG - 2020-10-09 12:24:21 --> Total execution time: 0.0275
ERROR - 2020-10-09 12:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:24:24 --> Config Class Initialized
INFO - 2020-10-09 12:24:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:24:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:24:24 --> Utf8 Class Initialized
INFO - 2020-10-09 12:24:24 --> URI Class Initialized
INFO - 2020-10-09 12:24:24 --> Router Class Initialized
INFO - 2020-10-09 12:24:24 --> Output Class Initialized
INFO - 2020-10-09 12:24:24 --> Security Class Initialized
DEBUG - 2020-10-09 12:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:24:24 --> Input Class Initialized
INFO - 2020-10-09 12:24:24 --> Language Class Initialized
INFO - 2020-10-09 12:24:24 --> Loader Class Initialized
INFO - 2020-10-09 12:24:24 --> Helper loaded: url_helper
INFO - 2020-10-09 12:24:24 --> Database Driver Class Initialized
INFO - 2020-10-09 12:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:24:24 --> Email Class Initialized
INFO - 2020-10-09 12:24:24 --> Controller Class Initialized
DEBUG - 2020-10-09 12:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:24:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:24:24 --> Model Class Initialized
INFO - 2020-10-09 12:24:24 --> Model Class Initialized
INFO - 2020-10-09 12:24:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:24:24 --> Final output sent to browser
DEBUG - 2020-10-09 12:24:24 --> Total execution time: 0.0239
ERROR - 2020-10-09 12:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:24:27 --> Config Class Initialized
INFO - 2020-10-09 12:24:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:24:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:24:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:24:27 --> URI Class Initialized
INFO - 2020-10-09 12:24:27 --> Router Class Initialized
INFO - 2020-10-09 12:24:27 --> Output Class Initialized
INFO - 2020-10-09 12:24:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:24:27 --> Input Class Initialized
INFO - 2020-10-09 12:24:27 --> Language Class Initialized
INFO - 2020-10-09 12:24:27 --> Loader Class Initialized
INFO - 2020-10-09 12:24:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:24:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:24:27 --> Email Class Initialized
INFO - 2020-10-09 12:24:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:24:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:24:27 --> Model Class Initialized
INFO - 2020-10-09 12:24:27 --> Model Class Initialized
INFO - 2020-10-09 12:24:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:24:27 --> Final output sent to browser
DEBUG - 2020-10-09 12:24:27 --> Total execution time: 0.0300
ERROR - 2020-10-09 12:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:24:29 --> Config Class Initialized
INFO - 2020-10-09 12:24:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:24:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:24:29 --> Utf8 Class Initialized
INFO - 2020-10-09 12:24:29 --> URI Class Initialized
INFO - 2020-10-09 12:24:29 --> Router Class Initialized
INFO - 2020-10-09 12:24:29 --> Output Class Initialized
INFO - 2020-10-09 12:24:29 --> Security Class Initialized
DEBUG - 2020-10-09 12:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:24:29 --> Input Class Initialized
INFO - 2020-10-09 12:24:29 --> Language Class Initialized
INFO - 2020-10-09 12:24:29 --> Loader Class Initialized
INFO - 2020-10-09 12:24:29 --> Helper loaded: url_helper
INFO - 2020-10-09 12:24:29 --> Database Driver Class Initialized
INFO - 2020-10-09 12:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:24:29 --> Email Class Initialized
INFO - 2020-10-09 12:24:29 --> Controller Class Initialized
DEBUG - 2020-10-09 12:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:24:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:24:29 --> Model Class Initialized
INFO - 2020-10-09 12:24:29 --> Model Class Initialized
INFO - 2020-10-09 12:24:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:24:29 --> Final output sent to browser
DEBUG - 2020-10-09 12:24:29 --> Total execution time: 0.0277
ERROR - 2020-10-09 12:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:24:37 --> Config Class Initialized
INFO - 2020-10-09 12:24:37 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:24:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:24:37 --> Utf8 Class Initialized
INFO - 2020-10-09 12:24:37 --> URI Class Initialized
INFO - 2020-10-09 12:24:37 --> Router Class Initialized
INFO - 2020-10-09 12:24:37 --> Output Class Initialized
INFO - 2020-10-09 12:24:37 --> Security Class Initialized
DEBUG - 2020-10-09 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:24:37 --> Input Class Initialized
INFO - 2020-10-09 12:24:37 --> Language Class Initialized
INFO - 2020-10-09 12:24:37 --> Loader Class Initialized
INFO - 2020-10-09 12:24:37 --> Helper loaded: url_helper
INFO - 2020-10-09 12:24:37 --> Database Driver Class Initialized
INFO - 2020-10-09 12:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:24:37 --> Email Class Initialized
INFO - 2020-10-09 12:24:37 --> Controller Class Initialized
DEBUG - 2020-10-09 12:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:24:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:24:37 --> Model Class Initialized
INFO - 2020-10-09 12:24:37 --> Model Class Initialized
INFO - 2020-10-09 12:24:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:24:37 --> Final output sent to browser
DEBUG - 2020-10-09 12:24:37 --> Total execution time: 0.0229
ERROR - 2020-10-09 12:25:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:25:20 --> Config Class Initialized
INFO - 2020-10-09 12:25:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:25:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:25:20 --> Utf8 Class Initialized
INFO - 2020-10-09 12:25:20 --> URI Class Initialized
INFO - 2020-10-09 12:25:20 --> Router Class Initialized
INFO - 2020-10-09 12:25:20 --> Output Class Initialized
INFO - 2020-10-09 12:25:20 --> Security Class Initialized
DEBUG - 2020-10-09 12:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:25:20 --> Input Class Initialized
INFO - 2020-10-09 12:25:20 --> Language Class Initialized
INFO - 2020-10-09 12:25:20 --> Loader Class Initialized
INFO - 2020-10-09 12:25:20 --> Helper loaded: url_helper
INFO - 2020-10-09 12:25:20 --> Database Driver Class Initialized
INFO - 2020-10-09 12:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:25:20 --> Email Class Initialized
INFO - 2020-10-09 12:25:20 --> Controller Class Initialized
DEBUG - 2020-10-09 12:25:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:25:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:25:20 --> Model Class Initialized
INFO - 2020-10-09 12:25:20 --> Model Class Initialized
INFO - 2020-10-09 12:25:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:25:20 --> Final output sent to browser
DEBUG - 2020-10-09 12:25:20 --> Total execution time: 0.0257
ERROR - 2020-10-09 12:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:25:24 --> Config Class Initialized
INFO - 2020-10-09 12:25:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:25:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:25:24 --> Utf8 Class Initialized
INFO - 2020-10-09 12:25:24 --> URI Class Initialized
INFO - 2020-10-09 12:25:24 --> Router Class Initialized
INFO - 2020-10-09 12:25:24 --> Output Class Initialized
INFO - 2020-10-09 12:25:24 --> Security Class Initialized
DEBUG - 2020-10-09 12:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:25:24 --> Input Class Initialized
INFO - 2020-10-09 12:25:24 --> Language Class Initialized
INFO - 2020-10-09 12:25:24 --> Loader Class Initialized
INFO - 2020-10-09 12:25:24 --> Helper loaded: url_helper
INFO - 2020-10-09 12:25:24 --> Database Driver Class Initialized
INFO - 2020-10-09 12:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:25:24 --> Email Class Initialized
INFO - 2020-10-09 12:25:24 --> Controller Class Initialized
DEBUG - 2020-10-09 12:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:25:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:25:24 --> Model Class Initialized
INFO - 2020-10-09 12:25:24 --> Model Class Initialized
INFO - 2020-10-09 12:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:25:24 --> Final output sent to browser
DEBUG - 2020-10-09 12:25:24 --> Total execution time: 0.0251
ERROR - 2020-10-09 12:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:25:27 --> Config Class Initialized
INFO - 2020-10-09 12:25:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:25:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:25:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:25:27 --> URI Class Initialized
INFO - 2020-10-09 12:25:27 --> Router Class Initialized
INFO - 2020-10-09 12:25:27 --> Output Class Initialized
INFO - 2020-10-09 12:25:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:25:27 --> Input Class Initialized
INFO - 2020-10-09 12:25:27 --> Language Class Initialized
INFO - 2020-10-09 12:25:27 --> Loader Class Initialized
INFO - 2020-10-09 12:25:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:25:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:25:27 --> Email Class Initialized
INFO - 2020-10-09 12:25:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:25:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:25:27 --> Model Class Initialized
INFO - 2020-10-09 12:25:27 --> Model Class Initialized
INFO - 2020-10-09 12:25:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:25:27 --> Final output sent to browser
DEBUG - 2020-10-09 12:25:27 --> Total execution time: 0.0292
ERROR - 2020-10-09 12:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:25:42 --> Config Class Initialized
INFO - 2020-10-09 12:25:42 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:25:42 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:25:42 --> Utf8 Class Initialized
INFO - 2020-10-09 12:25:42 --> URI Class Initialized
INFO - 2020-10-09 12:25:42 --> Router Class Initialized
INFO - 2020-10-09 12:25:42 --> Output Class Initialized
INFO - 2020-10-09 12:25:42 --> Security Class Initialized
DEBUG - 2020-10-09 12:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:25:42 --> Input Class Initialized
INFO - 2020-10-09 12:25:42 --> Language Class Initialized
INFO - 2020-10-09 12:25:42 --> Loader Class Initialized
INFO - 2020-10-09 12:25:42 --> Helper loaded: url_helper
INFO - 2020-10-09 12:25:42 --> Database Driver Class Initialized
INFO - 2020-10-09 12:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:25:42 --> Email Class Initialized
INFO - 2020-10-09 12:25:42 --> Controller Class Initialized
DEBUG - 2020-10-09 12:25:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:25:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:25:42 --> Model Class Initialized
INFO - 2020-10-09 12:25:42 --> Model Class Initialized
INFO - 2020-10-09 12:25:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:25:42 --> Final output sent to browser
DEBUG - 2020-10-09 12:25:42 --> Total execution time: 0.0248
ERROR - 2020-10-09 12:25:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:25:45 --> Config Class Initialized
INFO - 2020-10-09 12:25:45 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:25:45 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:25:45 --> Utf8 Class Initialized
INFO - 2020-10-09 12:25:45 --> URI Class Initialized
INFO - 2020-10-09 12:25:45 --> Router Class Initialized
INFO - 2020-10-09 12:25:45 --> Output Class Initialized
INFO - 2020-10-09 12:25:45 --> Security Class Initialized
DEBUG - 2020-10-09 12:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:25:45 --> Input Class Initialized
INFO - 2020-10-09 12:25:45 --> Language Class Initialized
INFO - 2020-10-09 12:25:45 --> Loader Class Initialized
INFO - 2020-10-09 12:25:45 --> Helper loaded: url_helper
INFO - 2020-10-09 12:25:45 --> Database Driver Class Initialized
INFO - 2020-10-09 12:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:25:45 --> Email Class Initialized
INFO - 2020-10-09 12:25:45 --> Controller Class Initialized
DEBUG - 2020-10-09 12:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:25:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:25:45 --> Model Class Initialized
INFO - 2020-10-09 12:25:45 --> Model Class Initialized
INFO - 2020-10-09 12:25:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:25:45 --> Final output sent to browser
DEBUG - 2020-10-09 12:25:45 --> Total execution time: 0.0296
ERROR - 2020-10-09 12:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:27:35 --> Config Class Initialized
INFO - 2020-10-09 12:27:35 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:27:35 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:27:35 --> Utf8 Class Initialized
INFO - 2020-10-09 12:27:35 --> URI Class Initialized
INFO - 2020-10-09 12:27:35 --> Router Class Initialized
INFO - 2020-10-09 12:27:35 --> Output Class Initialized
INFO - 2020-10-09 12:27:35 --> Security Class Initialized
DEBUG - 2020-10-09 12:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:27:35 --> Input Class Initialized
INFO - 2020-10-09 12:27:35 --> Language Class Initialized
INFO - 2020-10-09 12:27:35 --> Loader Class Initialized
INFO - 2020-10-09 12:27:35 --> Helper loaded: url_helper
INFO - 2020-10-09 12:27:35 --> Database Driver Class Initialized
INFO - 2020-10-09 12:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:27:35 --> Email Class Initialized
INFO - 2020-10-09 12:27:35 --> Controller Class Initialized
DEBUG - 2020-10-09 12:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:27:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:27:35 --> Model Class Initialized
INFO - 2020-10-09 12:27:35 --> Model Class Initialized
INFO - 2020-10-09 12:27:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:27:35 --> Final output sent to browser
DEBUG - 2020-10-09 12:27:35 --> Total execution time: 0.0245
ERROR - 2020-10-09 12:27:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:27:37 --> Config Class Initialized
INFO - 2020-10-09 12:27:37 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:27:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:27:37 --> Utf8 Class Initialized
INFO - 2020-10-09 12:27:37 --> URI Class Initialized
INFO - 2020-10-09 12:27:37 --> Router Class Initialized
INFO - 2020-10-09 12:27:37 --> Output Class Initialized
INFO - 2020-10-09 12:27:37 --> Security Class Initialized
DEBUG - 2020-10-09 12:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:27:37 --> Input Class Initialized
INFO - 2020-10-09 12:27:37 --> Language Class Initialized
INFO - 2020-10-09 12:27:37 --> Loader Class Initialized
INFO - 2020-10-09 12:27:37 --> Helper loaded: url_helper
INFO - 2020-10-09 12:27:37 --> Database Driver Class Initialized
INFO - 2020-10-09 12:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:27:37 --> Email Class Initialized
INFO - 2020-10-09 12:27:37 --> Controller Class Initialized
DEBUG - 2020-10-09 12:27:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:27:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:27:37 --> Model Class Initialized
INFO - 2020-10-09 12:27:37 --> Model Class Initialized
INFO - 2020-10-09 12:27:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:27:37 --> Final output sent to browser
DEBUG - 2020-10-09 12:27:37 --> Total execution time: 0.0235
ERROR - 2020-10-09 12:27:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:27:39 --> Config Class Initialized
INFO - 2020-10-09 12:27:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:27:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:27:39 --> Utf8 Class Initialized
INFO - 2020-10-09 12:27:39 --> URI Class Initialized
INFO - 2020-10-09 12:27:39 --> Router Class Initialized
INFO - 2020-10-09 12:27:39 --> Output Class Initialized
INFO - 2020-10-09 12:27:39 --> Security Class Initialized
DEBUG - 2020-10-09 12:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:27:39 --> Input Class Initialized
INFO - 2020-10-09 12:27:39 --> Language Class Initialized
INFO - 2020-10-09 12:27:39 --> Loader Class Initialized
INFO - 2020-10-09 12:27:39 --> Helper loaded: url_helper
INFO - 2020-10-09 12:27:39 --> Database Driver Class Initialized
INFO - 2020-10-09 12:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:27:39 --> Email Class Initialized
INFO - 2020-10-09 12:27:39 --> Controller Class Initialized
DEBUG - 2020-10-09 12:27:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:27:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:27:39 --> Model Class Initialized
INFO - 2020-10-09 12:27:39 --> Model Class Initialized
INFO - 2020-10-09 12:27:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:27:39 --> Final output sent to browser
DEBUG - 2020-10-09 12:27:39 --> Total execution time: 0.0274
ERROR - 2020-10-09 12:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:27:42 --> Config Class Initialized
INFO - 2020-10-09 12:27:42 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:27:42 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:27:42 --> Utf8 Class Initialized
INFO - 2020-10-09 12:27:42 --> URI Class Initialized
INFO - 2020-10-09 12:27:42 --> Router Class Initialized
INFO - 2020-10-09 12:27:42 --> Output Class Initialized
INFO - 2020-10-09 12:27:42 --> Security Class Initialized
DEBUG - 2020-10-09 12:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:27:42 --> Input Class Initialized
INFO - 2020-10-09 12:27:42 --> Language Class Initialized
INFO - 2020-10-09 12:27:42 --> Loader Class Initialized
INFO - 2020-10-09 12:27:42 --> Helper loaded: url_helper
INFO - 2020-10-09 12:27:42 --> Database Driver Class Initialized
INFO - 2020-10-09 12:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:27:42 --> Email Class Initialized
INFO - 2020-10-09 12:27:42 --> Controller Class Initialized
DEBUG - 2020-10-09 12:27:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:27:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:27:42 --> Model Class Initialized
INFO - 2020-10-09 12:27:42 --> Model Class Initialized
INFO - 2020-10-09 12:27:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:27:42 --> Final output sent to browser
DEBUG - 2020-10-09 12:27:42 --> Total execution time: 0.0268
ERROR - 2020-10-09 12:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:28:01 --> Config Class Initialized
INFO - 2020-10-09 12:28:01 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:28:01 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:28:01 --> Utf8 Class Initialized
INFO - 2020-10-09 12:28:01 --> URI Class Initialized
INFO - 2020-10-09 12:28:01 --> Router Class Initialized
INFO - 2020-10-09 12:28:01 --> Output Class Initialized
INFO - 2020-10-09 12:28:01 --> Security Class Initialized
DEBUG - 2020-10-09 12:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:28:01 --> Input Class Initialized
INFO - 2020-10-09 12:28:01 --> Language Class Initialized
INFO - 2020-10-09 12:28:01 --> Loader Class Initialized
INFO - 2020-10-09 12:28:01 --> Helper loaded: url_helper
INFO - 2020-10-09 12:28:01 --> Database Driver Class Initialized
INFO - 2020-10-09 12:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:28:01 --> Email Class Initialized
INFO - 2020-10-09 12:28:01 --> Controller Class Initialized
DEBUG - 2020-10-09 12:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:28:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:28:01 --> Model Class Initialized
INFO - 2020-10-09 12:28:01 --> Model Class Initialized
INFO - 2020-10-09 12:28:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:28:01 --> Final output sent to browser
DEBUG - 2020-10-09 12:28:01 --> Total execution time: 0.0248
ERROR - 2020-10-09 12:31:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:31:40 --> Config Class Initialized
INFO - 2020-10-09 12:31:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:31:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:31:40 --> Utf8 Class Initialized
INFO - 2020-10-09 12:31:40 --> URI Class Initialized
INFO - 2020-10-09 12:31:40 --> Router Class Initialized
INFO - 2020-10-09 12:31:40 --> Output Class Initialized
INFO - 2020-10-09 12:31:40 --> Security Class Initialized
DEBUG - 2020-10-09 12:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:31:40 --> Input Class Initialized
INFO - 2020-10-09 12:31:40 --> Language Class Initialized
INFO - 2020-10-09 12:31:40 --> Loader Class Initialized
INFO - 2020-10-09 12:31:40 --> Helper loaded: url_helper
INFO - 2020-10-09 12:31:40 --> Database Driver Class Initialized
INFO - 2020-10-09 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:31:40 --> Email Class Initialized
INFO - 2020-10-09 12:31:40 --> Controller Class Initialized
DEBUG - 2020-10-09 12:31:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:31:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:31:40 --> Model Class Initialized
INFO - 2020-10-09 12:31:40 --> Model Class Initialized
INFO - 2020-10-09 12:31:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:31:40 --> Final output sent to browser
DEBUG - 2020-10-09 12:31:40 --> Total execution time: 0.0228
ERROR - 2020-10-09 12:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:31:50 --> Config Class Initialized
INFO - 2020-10-09 12:31:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:31:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:31:50 --> Utf8 Class Initialized
INFO - 2020-10-09 12:31:50 --> URI Class Initialized
INFO - 2020-10-09 12:31:50 --> Router Class Initialized
INFO - 2020-10-09 12:31:50 --> Output Class Initialized
INFO - 2020-10-09 12:31:50 --> Security Class Initialized
DEBUG - 2020-10-09 12:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:31:50 --> Input Class Initialized
INFO - 2020-10-09 12:31:50 --> Language Class Initialized
INFO - 2020-10-09 12:31:50 --> Loader Class Initialized
INFO - 2020-10-09 12:31:50 --> Helper loaded: url_helper
INFO - 2020-10-09 12:31:50 --> Database Driver Class Initialized
INFO - 2020-10-09 12:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:31:50 --> Email Class Initialized
INFO - 2020-10-09 12:31:50 --> Controller Class Initialized
DEBUG - 2020-10-09 12:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:31:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:31:50 --> Model Class Initialized
INFO - 2020-10-09 12:31:50 --> Model Class Initialized
INFO - 2020-10-09 12:31:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:31:50 --> Final output sent to browser
DEBUG - 2020-10-09 12:31:50 --> Total execution time: 0.0235
ERROR - 2020-10-09 12:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:31:53 --> Config Class Initialized
INFO - 2020-10-09 12:31:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:31:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:31:53 --> Utf8 Class Initialized
INFO - 2020-10-09 12:31:53 --> URI Class Initialized
INFO - 2020-10-09 12:31:53 --> Router Class Initialized
INFO - 2020-10-09 12:31:53 --> Output Class Initialized
INFO - 2020-10-09 12:31:53 --> Security Class Initialized
DEBUG - 2020-10-09 12:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:31:53 --> Input Class Initialized
INFO - 2020-10-09 12:31:53 --> Language Class Initialized
INFO - 2020-10-09 12:31:53 --> Loader Class Initialized
INFO - 2020-10-09 12:31:53 --> Helper loaded: url_helper
INFO - 2020-10-09 12:31:53 --> Database Driver Class Initialized
INFO - 2020-10-09 12:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:31:53 --> Email Class Initialized
INFO - 2020-10-09 12:31:53 --> Controller Class Initialized
DEBUG - 2020-10-09 12:31:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:31:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:31:53 --> Model Class Initialized
INFO - 2020-10-09 12:31:53 --> Model Class Initialized
INFO - 2020-10-09 12:31:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:31:53 --> Final output sent to browser
DEBUG - 2020-10-09 12:31:53 --> Total execution time: 0.0276
ERROR - 2020-10-09 12:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:31:57 --> Config Class Initialized
INFO - 2020-10-09 12:31:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:31:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:31:57 --> Utf8 Class Initialized
INFO - 2020-10-09 12:31:57 --> URI Class Initialized
INFO - 2020-10-09 12:31:57 --> Router Class Initialized
INFO - 2020-10-09 12:31:57 --> Output Class Initialized
INFO - 2020-10-09 12:31:57 --> Security Class Initialized
DEBUG - 2020-10-09 12:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:31:57 --> Input Class Initialized
INFO - 2020-10-09 12:31:57 --> Language Class Initialized
INFO - 2020-10-09 12:31:57 --> Loader Class Initialized
INFO - 2020-10-09 12:31:57 --> Helper loaded: url_helper
INFO - 2020-10-09 12:31:57 --> Database Driver Class Initialized
INFO - 2020-10-09 12:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:31:57 --> Email Class Initialized
INFO - 2020-10-09 12:31:57 --> Controller Class Initialized
DEBUG - 2020-10-09 12:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:31:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:31:57 --> Model Class Initialized
INFO - 2020-10-09 12:31:57 --> Model Class Initialized
INFO - 2020-10-09 12:31:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:31:57 --> Final output sent to browser
DEBUG - 2020-10-09 12:31:57 --> Total execution time: 0.0292
ERROR - 2020-10-09 12:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:03 --> Config Class Initialized
INFO - 2020-10-09 12:32:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:03 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:03 --> URI Class Initialized
INFO - 2020-10-09 12:32:03 --> Router Class Initialized
INFO - 2020-10-09 12:32:03 --> Output Class Initialized
INFO - 2020-10-09 12:32:03 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:03 --> Input Class Initialized
INFO - 2020-10-09 12:32:03 --> Language Class Initialized
INFO - 2020-10-09 12:32:03 --> Loader Class Initialized
INFO - 2020-10-09 12:32:03 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:03 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:03 --> Email Class Initialized
INFO - 2020-10-09 12:32:03 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:03 --> Model Class Initialized
INFO - 2020-10-09 12:32:03 --> Model Class Initialized
INFO - 2020-10-09 12:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:32:03 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:03 --> Total execution time: 0.0344
ERROR - 2020-10-09 12:32:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:07 --> Config Class Initialized
INFO - 2020-10-09 12:32:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:07 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:07 --> URI Class Initialized
INFO - 2020-10-09 12:32:07 --> Router Class Initialized
INFO - 2020-10-09 12:32:07 --> Output Class Initialized
INFO - 2020-10-09 12:32:07 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:07 --> Input Class Initialized
INFO - 2020-10-09 12:32:07 --> Language Class Initialized
INFO - 2020-10-09 12:32:07 --> Loader Class Initialized
INFO - 2020-10-09 12:32:07 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:07 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:07 --> Email Class Initialized
INFO - 2020-10-09 12:32:07 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:07 --> Model Class Initialized
INFO - 2020-10-09 12:32:07 --> Model Class Initialized
INFO - 2020-10-09 12:32:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:07 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:07 --> Total execution time: 0.0212
ERROR - 2020-10-09 12:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:14 --> Config Class Initialized
INFO - 2020-10-09 12:32:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:14 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:14 --> URI Class Initialized
INFO - 2020-10-09 12:32:14 --> Router Class Initialized
INFO - 2020-10-09 12:32:14 --> Output Class Initialized
INFO - 2020-10-09 12:32:14 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:14 --> Input Class Initialized
INFO - 2020-10-09 12:32:14 --> Language Class Initialized
INFO - 2020-10-09 12:32:14 --> Loader Class Initialized
INFO - 2020-10-09 12:32:14 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:14 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:14 --> Email Class Initialized
INFO - 2020-10-09 12:32:14 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:14 --> Model Class Initialized
INFO - 2020-10-09 12:32:14 --> Model Class Initialized
INFO - 2020-10-09 12:32:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:32:14 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:14 --> Total execution time: 0.0236
ERROR - 2020-10-09 12:32:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:18 --> Config Class Initialized
INFO - 2020-10-09 12:32:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:18 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:18 --> URI Class Initialized
INFO - 2020-10-09 12:32:18 --> Router Class Initialized
INFO - 2020-10-09 12:32:18 --> Output Class Initialized
INFO - 2020-10-09 12:32:18 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:18 --> Input Class Initialized
INFO - 2020-10-09 12:32:18 --> Language Class Initialized
INFO - 2020-10-09 12:32:18 --> Loader Class Initialized
INFO - 2020-10-09 12:32:18 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:18 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:18 --> Email Class Initialized
INFO - 2020-10-09 12:32:18 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:18 --> Model Class Initialized
INFO - 2020-10-09 12:32:18 --> Model Class Initialized
INFO - 2020-10-09 12:32:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:18 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:18 --> Total execution time: 0.0205
ERROR - 2020-10-09 12:32:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:20 --> Config Class Initialized
INFO - 2020-10-09 12:32:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:20 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:20 --> URI Class Initialized
INFO - 2020-10-09 12:32:20 --> Router Class Initialized
INFO - 2020-10-09 12:32:20 --> Output Class Initialized
INFO - 2020-10-09 12:32:20 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:20 --> Input Class Initialized
INFO - 2020-10-09 12:32:20 --> Language Class Initialized
INFO - 2020-10-09 12:32:20 --> Loader Class Initialized
INFO - 2020-10-09 12:32:20 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:20 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:20 --> Email Class Initialized
INFO - 2020-10-09 12:32:20 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:20 --> Model Class Initialized
INFO - 2020-10-09 12:32:20 --> Model Class Initialized
INFO - 2020-10-09 12:32:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:32:20 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:20 --> Total execution time: 0.0235
ERROR - 2020-10-09 12:32:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:27 --> Config Class Initialized
INFO - 2020-10-09 12:32:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:27 --> URI Class Initialized
INFO - 2020-10-09 12:32:27 --> Router Class Initialized
INFO - 2020-10-09 12:32:27 --> Output Class Initialized
INFO - 2020-10-09 12:32:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:27 --> Input Class Initialized
INFO - 2020-10-09 12:32:27 --> Language Class Initialized
INFO - 2020-10-09 12:32:27 --> Loader Class Initialized
INFO - 2020-10-09 12:32:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:27 --> Email Class Initialized
INFO - 2020-10-09 12:32:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:27 --> Model Class Initialized
INFO - 2020-10-09 12:32:27 --> Model Class Initialized
INFO - 2020-10-09 12:32:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:27 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:27 --> Total execution time: 0.0264
ERROR - 2020-10-09 12:32:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:34 --> Config Class Initialized
INFO - 2020-10-09 12:32:34 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:34 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:34 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:34 --> URI Class Initialized
INFO - 2020-10-09 12:32:34 --> Router Class Initialized
INFO - 2020-10-09 12:32:34 --> Output Class Initialized
INFO - 2020-10-09 12:32:34 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:34 --> Input Class Initialized
INFO - 2020-10-09 12:32:34 --> Language Class Initialized
INFO - 2020-10-09 12:32:34 --> Loader Class Initialized
INFO - 2020-10-09 12:32:34 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:34 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:34 --> Email Class Initialized
INFO - 2020-10-09 12:32:34 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:34 --> Model Class Initialized
INFO - 2020-10-09 12:32:34 --> Model Class Initialized
INFO - 2020-10-09 12:32:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:32:34 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:34 --> Total execution time: 0.0245
ERROR - 2020-10-09 12:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:39 --> Config Class Initialized
INFO - 2020-10-09 12:32:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:39 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:39 --> URI Class Initialized
INFO - 2020-10-09 12:32:39 --> Router Class Initialized
INFO - 2020-10-09 12:32:39 --> Output Class Initialized
INFO - 2020-10-09 12:32:39 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:39 --> Input Class Initialized
INFO - 2020-10-09 12:32:39 --> Language Class Initialized
INFO - 2020-10-09 12:32:39 --> Loader Class Initialized
INFO - 2020-10-09 12:32:39 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:39 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:39 --> Email Class Initialized
INFO - 2020-10-09 12:32:39 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:39 --> Model Class Initialized
INFO - 2020-10-09 12:32:39 --> Model Class Initialized
INFO - 2020-10-09 12:32:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:39 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:39 --> Total execution time: 0.0326
ERROR - 2020-10-09 12:32:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:42 --> Config Class Initialized
INFO - 2020-10-09 12:32:42 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:42 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:42 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:42 --> URI Class Initialized
INFO - 2020-10-09 12:32:42 --> Router Class Initialized
INFO - 2020-10-09 12:32:42 --> Output Class Initialized
INFO - 2020-10-09 12:32:42 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:42 --> Input Class Initialized
INFO - 2020-10-09 12:32:42 --> Language Class Initialized
INFO - 2020-10-09 12:32:42 --> Loader Class Initialized
INFO - 2020-10-09 12:32:42 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:42 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:42 --> Email Class Initialized
INFO - 2020-10-09 12:32:42 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:42 --> Model Class Initialized
INFO - 2020-10-09 12:32:42 --> Model Class Initialized
INFO - 2020-10-09 12:32:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:32:42 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:42 --> Total execution time: 0.0256
ERROR - 2020-10-09 12:32:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:46 --> Config Class Initialized
INFO - 2020-10-09 12:32:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:46 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:46 --> URI Class Initialized
INFO - 2020-10-09 12:32:46 --> Router Class Initialized
INFO - 2020-10-09 12:32:46 --> Output Class Initialized
INFO - 2020-10-09 12:32:46 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:46 --> Input Class Initialized
INFO - 2020-10-09 12:32:46 --> Language Class Initialized
INFO - 2020-10-09 12:32:46 --> Loader Class Initialized
INFO - 2020-10-09 12:32:46 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:46 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:46 --> Email Class Initialized
INFO - 2020-10-09 12:32:46 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:46 --> Model Class Initialized
INFO - 2020-10-09 12:32:46 --> Model Class Initialized
INFO - 2020-10-09 12:32:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:46 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:46 --> Total execution time: 0.0276
ERROR - 2020-10-09 12:32:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:49 --> Config Class Initialized
INFO - 2020-10-09 12:32:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:49 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:49 --> URI Class Initialized
INFO - 2020-10-09 12:32:49 --> Router Class Initialized
INFO - 2020-10-09 12:32:49 --> Output Class Initialized
INFO - 2020-10-09 12:32:49 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:49 --> Input Class Initialized
INFO - 2020-10-09 12:32:49 --> Language Class Initialized
INFO - 2020-10-09 12:32:49 --> Loader Class Initialized
INFO - 2020-10-09 12:32:49 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:49 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:49 --> Email Class Initialized
INFO - 2020-10-09 12:32:49 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:49 --> Model Class Initialized
INFO - 2020-10-09 12:32:49 --> Model Class Initialized
INFO - 2020-10-09 12:32:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:32:49 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:49 --> Total execution time: 0.0217
ERROR - 2020-10-09 12:32:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:51 --> Config Class Initialized
INFO - 2020-10-09 12:32:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:51 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:51 --> URI Class Initialized
INFO - 2020-10-09 12:32:51 --> Router Class Initialized
INFO - 2020-10-09 12:32:51 --> Output Class Initialized
INFO - 2020-10-09 12:32:51 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:51 --> Input Class Initialized
INFO - 2020-10-09 12:32:51 --> Language Class Initialized
INFO - 2020-10-09 12:32:51 --> Loader Class Initialized
INFO - 2020-10-09 12:32:51 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:51 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:51 --> Email Class Initialized
INFO - 2020-10-09 12:32:51 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:51 --> Model Class Initialized
INFO - 2020-10-09 12:32:51 --> Model Class Initialized
INFO - 2020-10-09 12:32:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:51 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:51 --> Total execution time: 0.0293
ERROR - 2020-10-09 12:32:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:53 --> Config Class Initialized
INFO - 2020-10-09 12:32:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:53 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:53 --> URI Class Initialized
INFO - 2020-10-09 12:32:53 --> Router Class Initialized
INFO - 2020-10-09 12:32:53 --> Output Class Initialized
INFO - 2020-10-09 12:32:53 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:53 --> Input Class Initialized
INFO - 2020-10-09 12:32:53 --> Language Class Initialized
INFO - 2020-10-09 12:32:53 --> Loader Class Initialized
INFO - 2020-10-09 12:32:53 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:53 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:53 --> Email Class Initialized
INFO - 2020-10-09 12:32:53 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:53 --> Model Class Initialized
INFO - 2020-10-09 12:32:53 --> Model Class Initialized
INFO - 2020-10-09 12:32:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:32:53 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:53 --> Total execution time: 0.0262
ERROR - 2020-10-09 12:32:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:32:59 --> Config Class Initialized
INFO - 2020-10-09 12:32:59 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:32:59 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:32:59 --> Utf8 Class Initialized
INFO - 2020-10-09 12:32:59 --> URI Class Initialized
INFO - 2020-10-09 12:32:59 --> Router Class Initialized
INFO - 2020-10-09 12:32:59 --> Output Class Initialized
INFO - 2020-10-09 12:32:59 --> Security Class Initialized
DEBUG - 2020-10-09 12:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:32:59 --> Input Class Initialized
INFO - 2020-10-09 12:32:59 --> Language Class Initialized
INFO - 2020-10-09 12:32:59 --> Loader Class Initialized
INFO - 2020-10-09 12:32:59 --> Helper loaded: url_helper
INFO - 2020-10-09 12:32:59 --> Database Driver Class Initialized
INFO - 2020-10-09 12:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:32:59 --> Email Class Initialized
INFO - 2020-10-09 12:32:59 --> Controller Class Initialized
DEBUG - 2020-10-09 12:32:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:32:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:32:59 --> Model Class Initialized
INFO - 2020-10-09 12:32:59 --> Model Class Initialized
INFO - 2020-10-09 12:32:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:32:59 --> Final output sent to browser
DEBUG - 2020-10-09 12:32:59 --> Total execution time: 0.0295
ERROR - 2020-10-09 12:40:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:20 --> Config Class Initialized
INFO - 2020-10-09 12:40:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:20 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:20 --> URI Class Initialized
INFO - 2020-10-09 12:40:20 --> Router Class Initialized
INFO - 2020-10-09 12:40:20 --> Output Class Initialized
INFO - 2020-10-09 12:40:20 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:20 --> Input Class Initialized
INFO - 2020-10-09 12:40:20 --> Language Class Initialized
INFO - 2020-10-09 12:40:20 --> Loader Class Initialized
INFO - 2020-10-09 12:40:20 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:20 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:20 --> Email Class Initialized
INFO - 2020-10-09 12:40:20 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:20 --> Model Class Initialized
INFO - 2020-10-09 12:40:20 --> Model Class Initialized
INFO - 2020-10-09 12:40:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:40:20 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:20 --> Total execution time: 0.0280
ERROR - 2020-10-09 12:40:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:24 --> Config Class Initialized
INFO - 2020-10-09 12:40:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:24 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:24 --> URI Class Initialized
INFO - 2020-10-09 12:40:24 --> Router Class Initialized
INFO - 2020-10-09 12:40:24 --> Output Class Initialized
INFO - 2020-10-09 12:40:24 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:24 --> Input Class Initialized
INFO - 2020-10-09 12:40:24 --> Language Class Initialized
INFO - 2020-10-09 12:40:24 --> Loader Class Initialized
INFO - 2020-10-09 12:40:24 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:24 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:24 --> Email Class Initialized
INFO - 2020-10-09 12:40:24 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:24 --> Model Class Initialized
INFO - 2020-10-09 12:40:24 --> Model Class Initialized
INFO - 2020-10-09 12:40:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:40:24 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:24 --> Total execution time: 0.0232
ERROR - 2020-10-09 12:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:27 --> Config Class Initialized
INFO - 2020-10-09 12:40:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:27 --> URI Class Initialized
INFO - 2020-10-09 12:40:27 --> Router Class Initialized
INFO - 2020-10-09 12:40:27 --> Output Class Initialized
INFO - 2020-10-09 12:40:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:27 --> Input Class Initialized
INFO - 2020-10-09 12:40:27 --> Language Class Initialized
INFO - 2020-10-09 12:40:27 --> Loader Class Initialized
INFO - 2020-10-09 12:40:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:27 --> Email Class Initialized
INFO - 2020-10-09 12:40:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:27 --> Model Class Initialized
INFO - 2020-10-09 12:40:27 --> Model Class Initialized
INFO - 2020-10-09 12:40:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:40:27 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:27 --> Total execution time: 0.0212
ERROR - 2020-10-09 12:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:29 --> Config Class Initialized
INFO - 2020-10-09 12:40:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:29 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:29 --> URI Class Initialized
INFO - 2020-10-09 12:40:29 --> Router Class Initialized
INFO - 2020-10-09 12:40:29 --> Output Class Initialized
INFO - 2020-10-09 12:40:29 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:29 --> Input Class Initialized
INFO - 2020-10-09 12:40:29 --> Language Class Initialized
INFO - 2020-10-09 12:40:29 --> Loader Class Initialized
INFO - 2020-10-09 12:40:29 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:29 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:29 --> Email Class Initialized
INFO - 2020-10-09 12:40:29 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:29 --> Model Class Initialized
INFO - 2020-10-09 12:40:29 --> Model Class Initialized
INFO - 2020-10-09 12:40:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:40:29 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:29 --> Total execution time: 0.0243
ERROR - 2020-10-09 12:40:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:31 --> Config Class Initialized
INFO - 2020-10-09 12:40:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:31 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:31 --> URI Class Initialized
INFO - 2020-10-09 12:40:31 --> Router Class Initialized
INFO - 2020-10-09 12:40:31 --> Output Class Initialized
INFO - 2020-10-09 12:40:31 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:31 --> Input Class Initialized
INFO - 2020-10-09 12:40:31 --> Language Class Initialized
INFO - 2020-10-09 12:40:31 --> Loader Class Initialized
INFO - 2020-10-09 12:40:31 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:31 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:31 --> Email Class Initialized
INFO - 2020-10-09 12:40:31 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:31 --> Model Class Initialized
INFO - 2020-10-09 12:40:31 --> Model Class Initialized
INFO - 2020-10-09 12:40:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:40:31 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:31 --> Total execution time: 0.2182
ERROR - 2020-10-09 12:40:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:33 --> Config Class Initialized
INFO - 2020-10-09 12:40:33 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:33 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:33 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:33 --> URI Class Initialized
INFO - 2020-10-09 12:40:33 --> Router Class Initialized
INFO - 2020-10-09 12:40:33 --> Output Class Initialized
INFO - 2020-10-09 12:40:33 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:33 --> Input Class Initialized
INFO - 2020-10-09 12:40:33 --> Language Class Initialized
INFO - 2020-10-09 12:40:33 --> Loader Class Initialized
INFO - 2020-10-09 12:40:33 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:33 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:33 --> Email Class Initialized
INFO - 2020-10-09 12:40:33 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:33 --> Model Class Initialized
INFO - 2020-10-09 12:40:33 --> Model Class Initialized
INFO - 2020-10-09 12:40:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:40:33 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:33 --> Total execution time: 0.0261
ERROR - 2020-10-09 12:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:40:36 --> Config Class Initialized
INFO - 2020-10-09 12:40:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:40:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:40:36 --> Utf8 Class Initialized
INFO - 2020-10-09 12:40:36 --> URI Class Initialized
INFO - 2020-10-09 12:40:36 --> Router Class Initialized
INFO - 2020-10-09 12:40:36 --> Output Class Initialized
INFO - 2020-10-09 12:40:36 --> Security Class Initialized
DEBUG - 2020-10-09 12:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:40:36 --> Input Class Initialized
INFO - 2020-10-09 12:40:36 --> Language Class Initialized
INFO - 2020-10-09 12:40:36 --> Loader Class Initialized
INFO - 2020-10-09 12:40:36 --> Helper loaded: url_helper
INFO - 2020-10-09 12:40:36 --> Database Driver Class Initialized
INFO - 2020-10-09 12:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:40:36 --> Email Class Initialized
INFO - 2020-10-09 12:40:36 --> Controller Class Initialized
DEBUG - 2020-10-09 12:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:40:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:40:36 --> Model Class Initialized
INFO - 2020-10-09 12:40:36 --> Model Class Initialized
INFO - 2020-10-09 12:40:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:40:36 --> Final output sent to browser
DEBUG - 2020-10-09 12:40:36 --> Total execution time: 0.0271
ERROR - 2020-10-09 12:41:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:41:21 --> Config Class Initialized
INFO - 2020-10-09 12:41:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:41:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:41:21 --> Utf8 Class Initialized
INFO - 2020-10-09 12:41:21 --> URI Class Initialized
DEBUG - 2020-10-09 12:41:21 --> No URI present. Default controller set.
INFO - 2020-10-09 12:41:21 --> Router Class Initialized
INFO - 2020-10-09 12:41:21 --> Output Class Initialized
INFO - 2020-10-09 12:41:21 --> Security Class Initialized
DEBUG - 2020-10-09 12:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:41:21 --> Input Class Initialized
INFO - 2020-10-09 12:41:21 --> Language Class Initialized
INFO - 2020-10-09 12:41:21 --> Loader Class Initialized
INFO - 2020-10-09 12:41:21 --> Helper loaded: url_helper
INFO - 2020-10-09 12:41:21 --> Database Driver Class Initialized
INFO - 2020-10-09 12:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:41:21 --> Email Class Initialized
INFO - 2020-10-09 12:41:21 --> Controller Class Initialized
INFO - 2020-10-09 12:41:21 --> Model Class Initialized
INFO - 2020-10-09 12:41:21 --> Model Class Initialized
DEBUG - 2020-10-09 12:41:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:41:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 12:41:21 --> Final output sent to browser
DEBUG - 2020-10-09 12:41:21 --> Total execution time: 0.0171
ERROR - 2020-10-09 12:42:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:42:26 --> Config Class Initialized
INFO - 2020-10-09 12:42:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:42:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:42:26 --> Utf8 Class Initialized
INFO - 2020-10-09 12:42:26 --> URI Class Initialized
INFO - 2020-10-09 12:42:26 --> Router Class Initialized
INFO - 2020-10-09 12:42:26 --> Output Class Initialized
INFO - 2020-10-09 12:42:26 --> Security Class Initialized
DEBUG - 2020-10-09 12:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:42:26 --> Input Class Initialized
INFO - 2020-10-09 12:42:26 --> Language Class Initialized
INFO - 2020-10-09 12:42:26 --> Loader Class Initialized
INFO - 2020-10-09 12:42:26 --> Helper loaded: url_helper
INFO - 2020-10-09 12:42:26 --> Database Driver Class Initialized
INFO - 2020-10-09 12:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:42:26 --> Email Class Initialized
INFO - 2020-10-09 12:42:26 --> Controller Class Initialized
INFO - 2020-10-09 12:42:26 --> Model Class Initialized
INFO - 2020-10-09 12:42:26 --> Model Class Initialized
DEBUG - 2020-10-09 12:42:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:42:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:42:26 --> Model Class Initialized
INFO - 2020-10-09 12:42:26 --> Final output sent to browser
DEBUG - 2020-10-09 12:42:26 --> Total execution time: 0.0212
ERROR - 2020-10-09 12:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:42:27 --> Config Class Initialized
INFO - 2020-10-09 12:42:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:42:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:42:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:42:27 --> URI Class Initialized
INFO - 2020-10-09 12:42:27 --> Router Class Initialized
INFO - 2020-10-09 12:42:27 --> Output Class Initialized
INFO - 2020-10-09 12:42:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:42:27 --> Input Class Initialized
INFO - 2020-10-09 12:42:27 --> Language Class Initialized
INFO - 2020-10-09 12:42:27 --> Loader Class Initialized
INFO - 2020-10-09 12:42:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:42:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:42:27 --> Email Class Initialized
INFO - 2020-10-09 12:42:27 --> Controller Class Initialized
INFO - 2020-10-09 12:42:27 --> Model Class Initialized
INFO - 2020-10-09 12:42:27 --> Model Class Initialized
DEBUG - 2020-10-09 12:42:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 12:42:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:42:27 --> Config Class Initialized
INFO - 2020-10-09 12:42:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:42:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:42:27 --> Utf8 Class Initialized
INFO - 2020-10-09 12:42:27 --> URI Class Initialized
INFO - 2020-10-09 12:42:27 --> Router Class Initialized
INFO - 2020-10-09 12:42:27 --> Output Class Initialized
INFO - 2020-10-09 12:42:27 --> Security Class Initialized
DEBUG - 2020-10-09 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:42:27 --> Input Class Initialized
INFO - 2020-10-09 12:42:27 --> Language Class Initialized
INFO - 2020-10-09 12:42:27 --> Loader Class Initialized
INFO - 2020-10-09 12:42:27 --> Helper loaded: url_helper
INFO - 2020-10-09 12:42:27 --> Database Driver Class Initialized
INFO - 2020-10-09 12:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:42:27 --> Email Class Initialized
INFO - 2020-10-09 12:42:27 --> Controller Class Initialized
DEBUG - 2020-10-09 12:42:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:42:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:42:27 --> Model Class Initialized
INFO - 2020-10-09 12:42:27 --> Model Class Initialized
INFO - 2020-10-09 12:42:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:42:27 --> Final output sent to browser
DEBUG - 2020-10-09 12:42:27 --> Total execution time: 0.0233
ERROR - 2020-10-09 12:42:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:42:33 --> Config Class Initialized
INFO - 2020-10-09 12:42:33 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:42:33 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:42:33 --> Utf8 Class Initialized
INFO - 2020-10-09 12:42:33 --> URI Class Initialized
INFO - 2020-10-09 12:42:33 --> Router Class Initialized
INFO - 2020-10-09 12:42:33 --> Output Class Initialized
INFO - 2020-10-09 12:42:33 --> Security Class Initialized
DEBUG - 2020-10-09 12:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:42:33 --> Input Class Initialized
INFO - 2020-10-09 12:42:33 --> Language Class Initialized
INFO - 2020-10-09 12:42:33 --> Loader Class Initialized
INFO - 2020-10-09 12:42:33 --> Helper loaded: url_helper
INFO - 2020-10-09 12:42:33 --> Database Driver Class Initialized
INFO - 2020-10-09 12:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:42:33 --> Email Class Initialized
INFO - 2020-10-09 12:42:33 --> Controller Class Initialized
DEBUG - 2020-10-09 12:42:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:42:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:42:33 --> Model Class Initialized
INFO - 2020-10-09 12:42:33 --> Model Class Initialized
INFO - 2020-10-09 12:42:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 12:42:33 --> Final output sent to browser
DEBUG - 2020-10-09 12:42:33 --> Total execution time: 0.0242
ERROR - 2020-10-09 12:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:42:40 --> Config Class Initialized
INFO - 2020-10-09 12:42:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:42:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:42:40 --> Utf8 Class Initialized
INFO - 2020-10-09 12:42:40 --> URI Class Initialized
INFO - 2020-10-09 12:42:40 --> Router Class Initialized
INFO - 2020-10-09 12:42:40 --> Output Class Initialized
INFO - 2020-10-09 12:42:40 --> Security Class Initialized
DEBUG - 2020-10-09 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:42:40 --> Input Class Initialized
INFO - 2020-10-09 12:42:40 --> Language Class Initialized
INFO - 2020-10-09 12:42:40 --> Loader Class Initialized
INFO - 2020-10-09 12:42:40 --> Helper loaded: url_helper
INFO - 2020-10-09 12:42:40 --> Database Driver Class Initialized
INFO - 2020-10-09 12:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:42:40 --> Email Class Initialized
INFO - 2020-10-09 12:42:40 --> Controller Class Initialized
DEBUG - 2020-10-09 12:42:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:42:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:42:40 --> Model Class Initialized
INFO - 2020-10-09 12:42:40 --> Model Class Initialized
INFO - 2020-10-09 12:42:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:42:40 --> Final output sent to browser
DEBUG - 2020-10-09 12:42:40 --> Total execution time: 0.0245
ERROR - 2020-10-09 12:54:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:54:07 --> Config Class Initialized
INFO - 2020-10-09 12:54:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:54:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:54:07 --> Utf8 Class Initialized
INFO - 2020-10-09 12:54:07 --> URI Class Initialized
INFO - 2020-10-09 12:54:07 --> Router Class Initialized
INFO - 2020-10-09 12:54:07 --> Output Class Initialized
INFO - 2020-10-09 12:54:07 --> Security Class Initialized
DEBUG - 2020-10-09 12:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:54:07 --> Input Class Initialized
INFO - 2020-10-09 12:54:07 --> Language Class Initialized
INFO - 2020-10-09 12:54:07 --> Loader Class Initialized
INFO - 2020-10-09 12:54:07 --> Helper loaded: url_helper
INFO - 2020-10-09 12:54:07 --> Database Driver Class Initialized
INFO - 2020-10-09 12:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:54:07 --> Email Class Initialized
INFO - 2020-10-09 12:54:07 --> Controller Class Initialized
DEBUG - 2020-10-09 12:54:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:54:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:54:07 --> Model Class Initialized
INFO - 2020-10-09 12:54:07 --> Model Class Initialized
INFO - 2020-10-09 12:54:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 12:54:07 --> Final output sent to browser
DEBUG - 2020-10-09 12:54:07 --> Total execution time: 0.0260
ERROR - 2020-10-09 12:54:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:54:16 --> Config Class Initialized
INFO - 2020-10-09 12:54:16 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:54:16 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:54:16 --> Utf8 Class Initialized
INFO - 2020-10-09 12:54:16 --> URI Class Initialized
INFO - 2020-10-09 12:54:16 --> Router Class Initialized
INFO - 2020-10-09 12:54:16 --> Output Class Initialized
INFO - 2020-10-09 12:54:16 --> Security Class Initialized
DEBUG - 2020-10-09 12:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:54:16 --> Input Class Initialized
INFO - 2020-10-09 12:54:16 --> Language Class Initialized
INFO - 2020-10-09 12:54:16 --> Loader Class Initialized
INFO - 2020-10-09 12:54:16 --> Helper loaded: url_helper
INFO - 2020-10-09 12:54:16 --> Database Driver Class Initialized
INFO - 2020-10-09 12:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:54:16 --> Email Class Initialized
INFO - 2020-10-09 12:54:16 --> Controller Class Initialized
DEBUG - 2020-10-09 12:54:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:54:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:54:16 --> Model Class Initialized
INFO - 2020-10-09 12:54:16 --> Model Class Initialized
INFO - 2020-10-09 12:54:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:54:16 --> Final output sent to browser
DEBUG - 2020-10-09 12:54:16 --> Total execution time: 0.0227
ERROR - 2020-10-09 12:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:56:03 --> Config Class Initialized
INFO - 2020-10-09 12:56:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:56:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:56:03 --> Utf8 Class Initialized
INFO - 2020-10-09 12:56:03 --> URI Class Initialized
INFO - 2020-10-09 12:56:03 --> Router Class Initialized
INFO - 2020-10-09 12:56:03 --> Output Class Initialized
INFO - 2020-10-09 12:56:03 --> Security Class Initialized
DEBUG - 2020-10-09 12:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:56:03 --> Input Class Initialized
INFO - 2020-10-09 12:56:03 --> Language Class Initialized
INFO - 2020-10-09 12:56:03 --> Loader Class Initialized
INFO - 2020-10-09 12:56:03 --> Helper loaded: url_helper
INFO - 2020-10-09 12:56:03 --> Database Driver Class Initialized
INFO - 2020-10-09 12:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:56:03 --> Email Class Initialized
INFO - 2020-10-09 12:56:03 --> Controller Class Initialized
DEBUG - 2020-10-09 12:56:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:56:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:56:03 --> Model Class Initialized
INFO - 2020-10-09 12:56:03 --> Model Class Initialized
INFO - 2020-10-09 12:56:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:56:03 --> Final output sent to browser
DEBUG - 2020-10-09 12:56:03 --> Total execution time: 0.0264
ERROR - 2020-10-09 12:59:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 12:59:38 --> Config Class Initialized
INFO - 2020-10-09 12:59:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 12:59:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 12:59:38 --> Utf8 Class Initialized
INFO - 2020-10-09 12:59:38 --> URI Class Initialized
INFO - 2020-10-09 12:59:38 --> Router Class Initialized
INFO - 2020-10-09 12:59:38 --> Output Class Initialized
INFO - 2020-10-09 12:59:38 --> Security Class Initialized
DEBUG - 2020-10-09 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 12:59:38 --> Input Class Initialized
INFO - 2020-10-09 12:59:38 --> Language Class Initialized
INFO - 2020-10-09 12:59:38 --> Loader Class Initialized
INFO - 2020-10-09 12:59:38 --> Helper loaded: url_helper
INFO - 2020-10-09 12:59:38 --> Database Driver Class Initialized
INFO - 2020-10-09 12:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 12:59:38 --> Email Class Initialized
INFO - 2020-10-09 12:59:38 --> Controller Class Initialized
DEBUG - 2020-10-09 12:59:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 12:59:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 12:59:38 --> Model Class Initialized
INFO - 2020-10-09 12:59:38 --> Model Class Initialized
INFO - 2020-10-09 12:59:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 12:59:38 --> Final output sent to browser
DEBUG - 2020-10-09 12:59:38 --> Total execution time: 0.0233
ERROR - 2020-10-09 13:01:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:01:39 --> Config Class Initialized
INFO - 2020-10-09 13:01:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:01:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:01:39 --> Utf8 Class Initialized
INFO - 2020-10-09 13:01:39 --> URI Class Initialized
INFO - 2020-10-09 13:01:39 --> Router Class Initialized
INFO - 2020-10-09 13:01:39 --> Output Class Initialized
INFO - 2020-10-09 13:01:39 --> Security Class Initialized
DEBUG - 2020-10-09 13:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:01:39 --> Input Class Initialized
INFO - 2020-10-09 13:01:39 --> Language Class Initialized
INFO - 2020-10-09 13:01:39 --> Loader Class Initialized
INFO - 2020-10-09 13:01:39 --> Helper loaded: url_helper
INFO - 2020-10-09 13:01:39 --> Database Driver Class Initialized
INFO - 2020-10-09 13:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:01:39 --> Email Class Initialized
INFO - 2020-10-09 13:01:39 --> Controller Class Initialized
DEBUG - 2020-10-09 13:01:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:01:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:01:39 --> Model Class Initialized
INFO - 2020-10-09 13:01:39 --> Model Class Initialized
INFO - 2020-10-09 13:01:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:01:39 --> Final output sent to browser
DEBUG - 2020-10-09 13:01:39 --> Total execution time: 0.0258
ERROR - 2020-10-09 13:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:02:22 --> Config Class Initialized
INFO - 2020-10-09 13:02:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:02:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:02:22 --> Utf8 Class Initialized
INFO - 2020-10-09 13:02:22 --> URI Class Initialized
INFO - 2020-10-09 13:02:22 --> Router Class Initialized
INFO - 2020-10-09 13:02:22 --> Output Class Initialized
INFO - 2020-10-09 13:02:22 --> Security Class Initialized
DEBUG - 2020-10-09 13:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:02:22 --> Input Class Initialized
INFO - 2020-10-09 13:02:22 --> Language Class Initialized
INFO - 2020-10-09 13:02:22 --> Loader Class Initialized
INFO - 2020-10-09 13:02:22 --> Helper loaded: url_helper
INFO - 2020-10-09 13:02:22 --> Database Driver Class Initialized
INFO - 2020-10-09 13:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:02:22 --> Email Class Initialized
INFO - 2020-10-09 13:02:22 --> Controller Class Initialized
DEBUG - 2020-10-09 13:02:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:02:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:02:22 --> Model Class Initialized
INFO - 2020-10-09 13:02:22 --> Model Class Initialized
INFO - 2020-10-09 13:02:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:02:22 --> Final output sent to browser
DEBUG - 2020-10-09 13:02:22 --> Total execution time: 0.0251
ERROR - 2020-10-09 13:02:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:02:27 --> Config Class Initialized
INFO - 2020-10-09 13:02:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:02:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:02:27 --> Utf8 Class Initialized
INFO - 2020-10-09 13:02:27 --> URI Class Initialized
INFO - 2020-10-09 13:02:27 --> Router Class Initialized
INFO - 2020-10-09 13:02:27 --> Output Class Initialized
INFO - 2020-10-09 13:02:27 --> Security Class Initialized
DEBUG - 2020-10-09 13:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:02:27 --> Input Class Initialized
INFO - 2020-10-09 13:02:27 --> Language Class Initialized
INFO - 2020-10-09 13:02:27 --> Loader Class Initialized
INFO - 2020-10-09 13:02:27 --> Helper loaded: url_helper
INFO - 2020-10-09 13:02:27 --> Database Driver Class Initialized
INFO - 2020-10-09 13:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:02:27 --> Email Class Initialized
INFO - 2020-10-09 13:02:27 --> Controller Class Initialized
DEBUG - 2020-10-09 13:02:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:02:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:02:27 --> Model Class Initialized
INFO - 2020-10-09 13:02:27 --> Model Class Initialized
INFO - 2020-10-09 13:02:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:02:27 --> Final output sent to browser
DEBUG - 2020-10-09 13:02:27 --> Total execution time: 0.0246
ERROR - 2020-10-09 13:02:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:02:32 --> Config Class Initialized
INFO - 2020-10-09 13:02:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:02:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:02:32 --> Utf8 Class Initialized
INFO - 2020-10-09 13:02:32 --> URI Class Initialized
INFO - 2020-10-09 13:02:32 --> Router Class Initialized
INFO - 2020-10-09 13:02:32 --> Output Class Initialized
INFO - 2020-10-09 13:02:32 --> Security Class Initialized
DEBUG - 2020-10-09 13:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:02:32 --> Input Class Initialized
INFO - 2020-10-09 13:02:32 --> Language Class Initialized
INFO - 2020-10-09 13:02:32 --> Loader Class Initialized
INFO - 2020-10-09 13:02:32 --> Helper loaded: url_helper
INFO - 2020-10-09 13:02:32 --> Database Driver Class Initialized
INFO - 2020-10-09 13:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:02:32 --> Email Class Initialized
INFO - 2020-10-09 13:02:32 --> Controller Class Initialized
DEBUG - 2020-10-09 13:02:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:02:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:02:32 --> Model Class Initialized
INFO - 2020-10-09 13:02:32 --> Model Class Initialized
INFO - 2020-10-09 13:02:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:02:32 --> Final output sent to browser
DEBUG - 2020-10-09 13:02:32 --> Total execution time: 0.0244
ERROR - 2020-10-09 13:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:04:00 --> Config Class Initialized
INFO - 2020-10-09 13:04:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:04:01 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:04:01 --> Utf8 Class Initialized
INFO - 2020-10-09 13:04:01 --> URI Class Initialized
INFO - 2020-10-09 13:04:01 --> Router Class Initialized
INFO - 2020-10-09 13:04:01 --> Output Class Initialized
INFO - 2020-10-09 13:04:01 --> Security Class Initialized
DEBUG - 2020-10-09 13:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:04:01 --> Input Class Initialized
INFO - 2020-10-09 13:04:01 --> Language Class Initialized
INFO - 2020-10-09 13:04:01 --> Loader Class Initialized
INFO - 2020-10-09 13:04:01 --> Helper loaded: url_helper
INFO - 2020-10-09 13:04:01 --> Database Driver Class Initialized
INFO - 2020-10-09 13:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:04:01 --> Email Class Initialized
INFO - 2020-10-09 13:04:01 --> Controller Class Initialized
DEBUG - 2020-10-09 13:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:04:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:04:01 --> Model Class Initialized
INFO - 2020-10-09 13:04:01 --> Model Class Initialized
INFO - 2020-10-09 13:04:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:04:01 --> Final output sent to browser
DEBUG - 2020-10-09 13:04:01 --> Total execution time: 0.0276
ERROR - 2020-10-09 13:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:06:41 --> Config Class Initialized
INFO - 2020-10-09 13:06:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:06:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:06:41 --> Utf8 Class Initialized
INFO - 2020-10-09 13:06:41 --> URI Class Initialized
INFO - 2020-10-09 13:06:41 --> Router Class Initialized
INFO - 2020-10-09 13:06:41 --> Output Class Initialized
INFO - 2020-10-09 13:06:41 --> Security Class Initialized
DEBUG - 2020-10-09 13:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:06:41 --> Input Class Initialized
INFO - 2020-10-09 13:06:41 --> Language Class Initialized
INFO - 2020-10-09 13:06:41 --> Loader Class Initialized
INFO - 2020-10-09 13:06:41 --> Helper loaded: url_helper
INFO - 2020-10-09 13:06:41 --> Database Driver Class Initialized
INFO - 2020-10-09 13:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:06:41 --> Email Class Initialized
INFO - 2020-10-09 13:06:41 --> Controller Class Initialized
DEBUG - 2020-10-09 13:06:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:06:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:06:41 --> Model Class Initialized
INFO - 2020-10-09 13:06:41 --> Model Class Initialized
INFO - 2020-10-09 13:06:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:06:41 --> Final output sent to browser
DEBUG - 2020-10-09 13:06:41 --> Total execution time: 0.0235
ERROR - 2020-10-09 13:06:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:06:49 --> Config Class Initialized
INFO - 2020-10-09 13:06:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:06:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:06:49 --> Utf8 Class Initialized
INFO - 2020-10-09 13:06:49 --> URI Class Initialized
INFO - 2020-10-09 13:06:49 --> Router Class Initialized
INFO - 2020-10-09 13:06:49 --> Output Class Initialized
INFO - 2020-10-09 13:06:49 --> Security Class Initialized
DEBUG - 2020-10-09 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:06:49 --> Input Class Initialized
INFO - 2020-10-09 13:06:49 --> Language Class Initialized
INFO - 2020-10-09 13:06:49 --> Loader Class Initialized
INFO - 2020-10-09 13:06:49 --> Helper loaded: url_helper
INFO - 2020-10-09 13:06:49 --> Database Driver Class Initialized
INFO - 2020-10-09 13:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:06:49 --> Email Class Initialized
INFO - 2020-10-09 13:06:49 --> Controller Class Initialized
DEBUG - 2020-10-09 13:06:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:06:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:06:49 --> Model Class Initialized
INFO - 2020-10-09 13:06:49 --> Model Class Initialized
INFO - 2020-10-09 13:06:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:06:49 --> Final output sent to browser
DEBUG - 2020-10-09 13:06:49 --> Total execution time: 0.0277
ERROR - 2020-10-09 13:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:12:08 --> Config Class Initialized
INFO - 2020-10-09 13:12:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:12:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:12:08 --> Utf8 Class Initialized
INFO - 2020-10-09 13:12:08 --> URI Class Initialized
INFO - 2020-10-09 13:12:08 --> Router Class Initialized
INFO - 2020-10-09 13:12:08 --> Output Class Initialized
INFO - 2020-10-09 13:12:08 --> Security Class Initialized
DEBUG - 2020-10-09 13:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:12:08 --> Input Class Initialized
INFO - 2020-10-09 13:12:08 --> Language Class Initialized
INFO - 2020-10-09 13:12:08 --> Loader Class Initialized
INFO - 2020-10-09 13:12:08 --> Helper loaded: url_helper
INFO - 2020-10-09 13:12:08 --> Database Driver Class Initialized
INFO - 2020-10-09 13:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:12:08 --> Email Class Initialized
INFO - 2020-10-09 13:12:08 --> Controller Class Initialized
DEBUG - 2020-10-09 13:12:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:12:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:12:08 --> Model Class Initialized
INFO - 2020-10-09 13:12:08 --> Model Class Initialized
INFO - 2020-10-09 13:12:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:12:08 --> Final output sent to browser
DEBUG - 2020-10-09 13:12:08 --> Total execution time: 0.0243
ERROR - 2020-10-09 13:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:12:56 --> Config Class Initialized
INFO - 2020-10-09 13:12:56 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:12:56 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:12:56 --> Utf8 Class Initialized
INFO - 2020-10-09 13:12:56 --> URI Class Initialized
INFO - 2020-10-09 13:12:56 --> Router Class Initialized
INFO - 2020-10-09 13:12:56 --> Output Class Initialized
INFO - 2020-10-09 13:12:56 --> Security Class Initialized
DEBUG - 2020-10-09 13:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:12:56 --> Input Class Initialized
INFO - 2020-10-09 13:12:56 --> Language Class Initialized
INFO - 2020-10-09 13:12:56 --> Loader Class Initialized
INFO - 2020-10-09 13:12:56 --> Helper loaded: url_helper
INFO - 2020-10-09 13:12:56 --> Database Driver Class Initialized
INFO - 2020-10-09 13:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:12:56 --> Email Class Initialized
INFO - 2020-10-09 13:12:56 --> Controller Class Initialized
DEBUG - 2020-10-09 13:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:12:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:12:56 --> Model Class Initialized
INFO - 2020-10-09 13:12:56 --> Model Class Initialized
INFO - 2020-10-09 13:12:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:12:56 --> Final output sent to browser
DEBUG - 2020-10-09 13:12:56 --> Total execution time: 0.0248
ERROR - 2020-10-09 13:13:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:13:00 --> Config Class Initialized
INFO - 2020-10-09 13:13:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:13:00 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:13:00 --> Utf8 Class Initialized
INFO - 2020-10-09 13:13:00 --> URI Class Initialized
INFO - 2020-10-09 13:13:00 --> Router Class Initialized
INFO - 2020-10-09 13:13:00 --> Output Class Initialized
INFO - 2020-10-09 13:13:00 --> Security Class Initialized
DEBUG - 2020-10-09 13:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:13:00 --> Input Class Initialized
INFO - 2020-10-09 13:13:00 --> Language Class Initialized
INFO - 2020-10-09 13:13:00 --> Loader Class Initialized
INFO - 2020-10-09 13:13:00 --> Helper loaded: url_helper
INFO - 2020-10-09 13:13:00 --> Database Driver Class Initialized
INFO - 2020-10-09 13:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:13:00 --> Email Class Initialized
INFO - 2020-10-09 13:13:00 --> Controller Class Initialized
DEBUG - 2020-10-09 13:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:13:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:13:00 --> Model Class Initialized
INFO - 2020-10-09 13:13:00 --> Model Class Initialized
INFO - 2020-10-09 13:13:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:13:00 --> Final output sent to browser
DEBUG - 2020-10-09 13:13:00 --> Total execution time: 0.0248
ERROR - 2020-10-09 13:13:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:13:17 --> Config Class Initialized
INFO - 2020-10-09 13:13:17 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:13:17 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:13:17 --> Utf8 Class Initialized
INFO - 2020-10-09 13:13:17 --> URI Class Initialized
INFO - 2020-10-09 13:13:17 --> Router Class Initialized
INFO - 2020-10-09 13:13:17 --> Output Class Initialized
INFO - 2020-10-09 13:13:17 --> Security Class Initialized
DEBUG - 2020-10-09 13:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:13:17 --> Input Class Initialized
INFO - 2020-10-09 13:13:17 --> Language Class Initialized
INFO - 2020-10-09 13:13:17 --> Loader Class Initialized
INFO - 2020-10-09 13:13:17 --> Helper loaded: url_helper
INFO - 2020-10-09 13:13:17 --> Database Driver Class Initialized
INFO - 2020-10-09 13:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:13:17 --> Email Class Initialized
INFO - 2020-10-09 13:13:17 --> Controller Class Initialized
DEBUG - 2020-10-09 13:13:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:13:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:13:17 --> Model Class Initialized
INFO - 2020-10-09 13:13:17 --> Model Class Initialized
INFO - 2020-10-09 13:13:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:13:17 --> Final output sent to browser
DEBUG - 2020-10-09 13:13:17 --> Total execution time: 0.0272
ERROR - 2020-10-09 13:13:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:13:37 --> Config Class Initialized
INFO - 2020-10-09 13:13:37 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:13:37 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:13:37 --> Utf8 Class Initialized
INFO - 2020-10-09 13:13:37 --> URI Class Initialized
INFO - 2020-10-09 13:13:37 --> Router Class Initialized
INFO - 2020-10-09 13:13:37 --> Output Class Initialized
INFO - 2020-10-09 13:13:37 --> Security Class Initialized
DEBUG - 2020-10-09 13:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:13:37 --> Input Class Initialized
INFO - 2020-10-09 13:13:37 --> Language Class Initialized
INFO - 2020-10-09 13:13:37 --> Loader Class Initialized
INFO - 2020-10-09 13:13:37 --> Helper loaded: url_helper
INFO - 2020-10-09 13:13:37 --> Database Driver Class Initialized
INFO - 2020-10-09 13:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:13:37 --> Email Class Initialized
INFO - 2020-10-09 13:13:37 --> Controller Class Initialized
DEBUG - 2020-10-09 13:13:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:13:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:13:37 --> Model Class Initialized
INFO - 2020-10-09 13:13:37 --> Model Class Initialized
INFO - 2020-10-09 13:13:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 13:13:37 --> Final output sent to browser
DEBUG - 2020-10-09 13:13:37 --> Total execution time: 0.0268
ERROR - 2020-10-09 13:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:13:50 --> Config Class Initialized
INFO - 2020-10-09 13:13:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:13:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:13:50 --> Utf8 Class Initialized
INFO - 2020-10-09 13:13:50 --> URI Class Initialized
INFO - 2020-10-09 13:13:50 --> Router Class Initialized
INFO - 2020-10-09 13:13:50 --> Output Class Initialized
INFO - 2020-10-09 13:13:50 --> Security Class Initialized
DEBUG - 2020-10-09 13:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:13:50 --> Input Class Initialized
INFO - 2020-10-09 13:13:50 --> Language Class Initialized
INFO - 2020-10-09 13:13:50 --> Loader Class Initialized
INFO - 2020-10-09 13:13:50 --> Helper loaded: url_helper
INFO - 2020-10-09 13:13:50 --> Database Driver Class Initialized
INFO - 2020-10-09 13:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:13:50 --> Email Class Initialized
INFO - 2020-10-09 13:13:50 --> Controller Class Initialized
DEBUG - 2020-10-09 13:13:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:13:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:13:50 --> Model Class Initialized
INFO - 2020-10-09 13:13:50 --> Model Class Initialized
INFO - 2020-10-09 13:13:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:13:50 --> Final output sent to browser
DEBUG - 2020-10-09 13:13:50 --> Total execution time: 0.0251
ERROR - 2020-10-09 13:13:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:13:59 --> Config Class Initialized
INFO - 2020-10-09 13:13:59 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:13:59 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:13:59 --> Utf8 Class Initialized
INFO - 2020-10-09 13:13:59 --> URI Class Initialized
INFO - 2020-10-09 13:13:59 --> Router Class Initialized
INFO - 2020-10-09 13:13:59 --> Output Class Initialized
INFO - 2020-10-09 13:13:59 --> Security Class Initialized
DEBUG - 2020-10-09 13:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:13:59 --> Input Class Initialized
INFO - 2020-10-09 13:13:59 --> Language Class Initialized
INFO - 2020-10-09 13:13:59 --> Loader Class Initialized
INFO - 2020-10-09 13:13:59 --> Helper loaded: url_helper
INFO - 2020-10-09 13:13:59 --> Database Driver Class Initialized
INFO - 2020-10-09 13:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:13:59 --> Email Class Initialized
INFO - 2020-10-09 13:13:59 --> Controller Class Initialized
DEBUG - 2020-10-09 13:13:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:13:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:13:59 --> Model Class Initialized
INFO - 2020-10-09 13:13:59 --> Model Class Initialized
INFO - 2020-10-09 13:13:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:13:59 --> Final output sent to browser
DEBUG - 2020-10-09 13:13:59 --> Total execution time: 0.0276
ERROR - 2020-10-09 13:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:14:03 --> Config Class Initialized
INFO - 2020-10-09 13:14:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:14:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:14:03 --> Utf8 Class Initialized
INFO - 2020-10-09 13:14:03 --> URI Class Initialized
INFO - 2020-10-09 13:14:03 --> Router Class Initialized
INFO - 2020-10-09 13:14:03 --> Output Class Initialized
INFO - 2020-10-09 13:14:03 --> Security Class Initialized
DEBUG - 2020-10-09 13:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:14:03 --> Input Class Initialized
INFO - 2020-10-09 13:14:03 --> Language Class Initialized
INFO - 2020-10-09 13:14:03 --> Loader Class Initialized
INFO - 2020-10-09 13:14:03 --> Helper loaded: url_helper
INFO - 2020-10-09 13:14:03 --> Database Driver Class Initialized
INFO - 2020-10-09 13:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:14:03 --> Email Class Initialized
INFO - 2020-10-09 13:14:03 --> Controller Class Initialized
DEBUG - 2020-10-09 13:14:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:14:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:14:03 --> Model Class Initialized
INFO - 2020-10-09 13:14:03 --> Model Class Initialized
INFO - 2020-10-09 13:14:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 13:14:03 --> Final output sent to browser
DEBUG - 2020-10-09 13:14:03 --> Total execution time: 0.0258
ERROR - 2020-10-09 13:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:14:20 --> Config Class Initialized
INFO - 2020-10-09 13:14:20 --> Hooks Class Initialized
ERROR - 2020-10-09 13:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2020-10-09 13:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:14:20 --> Utf8 Class Initialized
INFO - 2020-10-09 13:14:20 --> Config Class Initialized
INFO - 2020-10-09 13:14:20 --> URI Class Initialized
INFO - 2020-10-09 13:14:20 --> Hooks Class Initialized
INFO - 2020-10-09 13:14:20 --> Router Class Initialized
DEBUG - 2020-10-09 13:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:14:20 --> Utf8 Class Initialized
INFO - 2020-10-09 13:14:20 --> Output Class Initialized
INFO - 2020-10-09 13:14:20 --> URI Class Initialized
INFO - 2020-10-09 13:14:20 --> Security Class Initialized
INFO - 2020-10-09 13:14:20 --> Router Class Initialized
DEBUG - 2020-10-09 13:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:14:20 --> Input Class Initialized
INFO - 2020-10-09 13:14:20 --> Output Class Initialized
INFO - 2020-10-09 13:14:20 --> Language Class Initialized
INFO - 2020-10-09 13:14:20 --> Security Class Initialized
DEBUG - 2020-10-09 13:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:14:20 --> Input Class Initialized
INFO - 2020-10-09 13:14:20 --> Language Class Initialized
INFO - 2020-10-09 13:14:20 --> Loader Class Initialized
INFO - 2020-10-09 13:14:20 --> Helper loaded: url_helper
INFO - 2020-10-09 13:14:20 --> Loader Class Initialized
INFO - 2020-10-09 13:14:20 --> Helper loaded: url_helper
INFO - 2020-10-09 13:14:20 --> Database Driver Class Initialized
INFO - 2020-10-09 13:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:14:20 --> Database Driver Class Initialized
INFO - 2020-10-09 13:14:20 --> Email Class Initialized
INFO - 2020-10-09 13:14:20 --> Controller Class Initialized
DEBUG - 2020-10-09 13:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:14:20 --> Model Class Initialized
INFO - 2020-10-09 13:14:20 --> Model Class Initialized
INFO - 2020-10-09 13:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:14:20 --> Final output sent to browser
DEBUG - 2020-10-09 13:14:20 --> Total execution time: 0.0434
INFO - 2020-10-09 13:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:14:20 --> Email Class Initialized
INFO - 2020-10-09 13:14:20 --> Controller Class Initialized
DEBUG - 2020-10-09 13:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 13:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:14:20 --> Model Class Initialized
INFO - 2020-10-09 13:14:20 --> Model Class Initialized
INFO - 2020-10-09 13:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 13:14:20 --> Final output sent to browser
DEBUG - 2020-10-09 13:14:20 --> Total execution time: 0.0616
ERROR - 2020-10-09 13:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 13:14:29 --> Config Class Initialized
INFO - 2020-10-09 13:14:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 13:14:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 13:14:29 --> Utf8 Class Initialized
INFO - 2020-10-09 13:14:29 --> URI Class Initialized
DEBUG - 2020-10-09 13:14:29 --> No URI present. Default controller set.
INFO - 2020-10-09 13:14:29 --> Router Class Initialized
INFO - 2020-10-09 13:14:29 --> Output Class Initialized
INFO - 2020-10-09 13:14:29 --> Security Class Initialized
DEBUG - 2020-10-09 13:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 13:14:29 --> Input Class Initialized
INFO - 2020-10-09 13:14:29 --> Language Class Initialized
INFO - 2020-10-09 13:14:29 --> Loader Class Initialized
INFO - 2020-10-09 13:14:29 --> Helper loaded: url_helper
INFO - 2020-10-09 13:14:29 --> Database Driver Class Initialized
INFO - 2020-10-09 13:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 13:14:29 --> Email Class Initialized
INFO - 2020-10-09 13:14:29 --> Controller Class Initialized
INFO - 2020-10-09 13:14:29 --> Model Class Initialized
INFO - 2020-10-09 13:14:29 --> Model Class Initialized
DEBUG - 2020-10-09 13:14:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 13:14:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 13:14:29 --> Final output sent to browser
DEBUG - 2020-10-09 13:14:29 --> Total execution time: 0.0204
ERROR - 2020-10-09 16:03:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:21 --> Config Class Initialized
INFO - 2020-10-09 16:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:21 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:21 --> URI Class Initialized
DEBUG - 2020-10-09 16:03:21 --> No URI present. Default controller set.
INFO - 2020-10-09 16:03:21 --> Router Class Initialized
INFO - 2020-10-09 16:03:21 --> Output Class Initialized
INFO - 2020-10-09 16:03:21 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:21 --> Input Class Initialized
INFO - 2020-10-09 16:03:21 --> Language Class Initialized
INFO - 2020-10-09 16:03:21 --> Loader Class Initialized
INFO - 2020-10-09 16:03:21 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:21 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:21 --> Email Class Initialized
INFO - 2020-10-09 16:03:21 --> Controller Class Initialized
INFO - 2020-10-09 16:03:21 --> Model Class Initialized
INFO - 2020-10-09 16:03:21 --> Model Class Initialized
DEBUG - 2020-10-09 16:03:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 16:03:21 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:21 --> Total execution time: 0.0190
ERROR - 2020-10-09 16:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:25 --> Config Class Initialized
INFO - 2020-10-09 16:03:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:25 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:25 --> URI Class Initialized
INFO - 2020-10-09 16:03:25 --> Router Class Initialized
INFO - 2020-10-09 16:03:25 --> Output Class Initialized
INFO - 2020-10-09 16:03:25 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:25 --> Input Class Initialized
INFO - 2020-10-09 16:03:25 --> Language Class Initialized
INFO - 2020-10-09 16:03:25 --> Loader Class Initialized
INFO - 2020-10-09 16:03:25 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:25 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:25 --> Email Class Initialized
INFO - 2020-10-09 16:03:25 --> Controller Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:25 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 16:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:25 --> Config Class Initialized
INFO - 2020-10-09 16:03:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:25 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:25 --> URI Class Initialized
INFO - 2020-10-09 16:03:25 --> Router Class Initialized
INFO - 2020-10-09 16:03:25 --> Output Class Initialized
INFO - 2020-10-09 16:03:25 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:25 --> Input Class Initialized
INFO - 2020-10-09 16:03:25 --> Language Class Initialized
INFO - 2020-10-09 16:03:25 --> Loader Class Initialized
INFO - 2020-10-09 16:03:25 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:25 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:25 --> Email Class Initialized
INFO - 2020-10-09 16:03:25 --> Controller Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 16:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:25 --> Config Class Initialized
INFO - 2020-10-09 16:03:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:25 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:25 --> URI Class Initialized
DEBUG - 2020-10-09 16:03:25 --> No URI present. Default controller set.
INFO - 2020-10-09 16:03:25 --> Router Class Initialized
INFO - 2020-10-09 16:03:25 --> Output Class Initialized
INFO - 2020-10-09 16:03:25 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:25 --> Input Class Initialized
INFO - 2020-10-09 16:03:25 --> Language Class Initialized
INFO - 2020-10-09 16:03:25 --> Loader Class Initialized
INFO - 2020-10-09 16:03:25 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:25 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:25 --> Email Class Initialized
INFO - 2020-10-09 16:03:25 --> Controller Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 16:03:25 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:25 --> Total execution time: 0.0203
ERROR - 2020-10-09 16:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:25 --> Config Class Initialized
INFO - 2020-10-09 16:03:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:25 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:25 --> URI Class Initialized
INFO - 2020-10-09 16:03:25 --> Router Class Initialized
INFO - 2020-10-09 16:03:25 --> Output Class Initialized
INFO - 2020-10-09 16:03:25 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:25 --> Input Class Initialized
INFO - 2020-10-09 16:03:25 --> Language Class Initialized
INFO - 2020-10-09 16:03:25 --> Loader Class Initialized
INFO - 2020-10-09 16:03:25 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:25 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:25 --> Email Class Initialized
INFO - 2020-10-09 16:03:25 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
INFO - 2020-10-09 16:03:25 --> Model Class Initialized
INFO - 2020-10-09 16:03:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 16:03:25 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:25 --> Total execution time: 0.0311
ERROR - 2020-10-09 16:03:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:34 --> Config Class Initialized
INFO - 2020-10-09 16:03:34 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:34 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:34 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:34 --> URI Class Initialized
INFO - 2020-10-09 16:03:34 --> Router Class Initialized
INFO - 2020-10-09 16:03:34 --> Output Class Initialized
INFO - 2020-10-09 16:03:34 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:34 --> Input Class Initialized
INFO - 2020-10-09 16:03:34 --> Language Class Initialized
INFO - 2020-10-09 16:03:34 --> Loader Class Initialized
INFO - 2020-10-09 16:03:34 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:34 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:34 --> Email Class Initialized
INFO - 2020-10-09 16:03:34 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:34 --> Model Class Initialized
INFO - 2020-10-09 16:03:34 --> Model Class Initialized
INFO - 2020-10-09 16:03:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 16:03:34 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:34 --> Total execution time: 0.0265
ERROR - 2020-10-09 16:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:38 --> Config Class Initialized
INFO - 2020-10-09 16:03:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:38 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:38 --> URI Class Initialized
INFO - 2020-10-09 16:03:38 --> Router Class Initialized
INFO - 2020-10-09 16:03:38 --> Output Class Initialized
INFO - 2020-10-09 16:03:38 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:38 --> Input Class Initialized
INFO - 2020-10-09 16:03:38 --> Language Class Initialized
INFO - 2020-10-09 16:03:38 --> Loader Class Initialized
INFO - 2020-10-09 16:03:38 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:38 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:38 --> Email Class Initialized
INFO - 2020-10-09 16:03:38 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:38 --> Model Class Initialized
INFO - 2020-10-09 16:03:38 --> Model Class Initialized
INFO - 2020-10-09 16:03:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 16:03:38 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:38 --> Total execution time: 0.0383
ERROR - 2020-10-09 16:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:38 --> Config Class Initialized
INFO - 2020-10-09 16:03:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:38 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:38 --> URI Class Initialized
INFO - 2020-10-09 16:03:38 --> Router Class Initialized
INFO - 2020-10-09 16:03:38 --> Output Class Initialized
INFO - 2020-10-09 16:03:38 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:38 --> Input Class Initialized
INFO - 2020-10-09 16:03:38 --> Language Class Initialized
INFO - 2020-10-09 16:03:38 --> Loader Class Initialized
INFO - 2020-10-09 16:03:38 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:38 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:38 --> Email Class Initialized
INFO - 2020-10-09 16:03:38 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:38 --> Model Class Initialized
INFO - 2020-10-09 16:03:38 --> Model Class Initialized
INFO - 2020-10-09 16:03:38 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:38 --> Total execution time: 0.0216
ERROR - 2020-10-09 16:03:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:40 --> Config Class Initialized
INFO - 2020-10-09 16:03:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:40 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:40 --> URI Class Initialized
INFO - 2020-10-09 16:03:40 --> Router Class Initialized
INFO - 2020-10-09 16:03:40 --> Output Class Initialized
INFO - 2020-10-09 16:03:40 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:40 --> Input Class Initialized
INFO - 2020-10-09 16:03:40 --> Language Class Initialized
INFO - 2020-10-09 16:03:40 --> Loader Class Initialized
INFO - 2020-10-09 16:03:40 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:40 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:40 --> Email Class Initialized
INFO - 2020-10-09 16:03:40 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:40 --> Model Class Initialized
INFO - 2020-10-09 16:03:40 --> Model Class Initialized
INFO - 2020-10-09 16:03:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 16:03:41 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:41 --> Total execution time: 0.2987
ERROR - 2020-10-09 16:03:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:41 --> Config Class Initialized
INFO - 2020-10-09 16:03:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:41 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:41 --> URI Class Initialized
INFO - 2020-10-09 16:03:41 --> Router Class Initialized
INFO - 2020-10-09 16:03:41 --> Output Class Initialized
INFO - 2020-10-09 16:03:41 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:41 --> Input Class Initialized
INFO - 2020-10-09 16:03:41 --> Language Class Initialized
INFO - 2020-10-09 16:03:41 --> Loader Class Initialized
INFO - 2020-10-09 16:03:41 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:41 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:41 --> Email Class Initialized
INFO - 2020-10-09 16:03:41 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:41 --> Model Class Initialized
INFO - 2020-10-09 16:03:41 --> Model Class Initialized
INFO - 2020-10-09 16:03:41 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:41 --> Total execution time: 0.0212
ERROR - 2020-10-09 16:03:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:54 --> Config Class Initialized
INFO - 2020-10-09 16:03:54 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:55 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:55 --> URI Class Initialized
INFO - 2020-10-09 16:03:55 --> Router Class Initialized
INFO - 2020-10-09 16:03:55 --> Output Class Initialized
INFO - 2020-10-09 16:03:55 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:55 --> Input Class Initialized
INFO - 2020-10-09 16:03:55 --> Language Class Initialized
INFO - 2020-10-09 16:03:55 --> Loader Class Initialized
INFO - 2020-10-09 16:03:55 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:55 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:55 --> Email Class Initialized
INFO - 2020-10-09 16:03:55 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:55 --> Model Class Initialized
INFO - 2020-10-09 16:03:55 --> Model Class Initialized
INFO - 2020-10-09 16:03:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 16:03:55 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:55 --> Total execution time: 0.0261
ERROR - 2020-10-09 16:03:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:03:55 --> Config Class Initialized
INFO - 2020-10-09 16:03:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:03:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:03:55 --> Utf8 Class Initialized
INFO - 2020-10-09 16:03:55 --> URI Class Initialized
INFO - 2020-10-09 16:03:55 --> Router Class Initialized
INFO - 2020-10-09 16:03:55 --> Output Class Initialized
INFO - 2020-10-09 16:03:55 --> Security Class Initialized
DEBUG - 2020-10-09 16:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:03:55 --> Input Class Initialized
INFO - 2020-10-09 16:03:55 --> Language Class Initialized
INFO - 2020-10-09 16:03:55 --> Loader Class Initialized
INFO - 2020-10-09 16:03:55 --> Helper loaded: url_helper
INFO - 2020-10-09 16:03:55 --> Database Driver Class Initialized
INFO - 2020-10-09 16:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:03:55 --> Email Class Initialized
INFO - 2020-10-09 16:03:55 --> Controller Class Initialized
DEBUG - 2020-10-09 16:03:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:03:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:03:55 --> Model Class Initialized
INFO - 2020-10-09 16:03:55 --> Model Class Initialized
INFO - 2020-10-09 16:03:55 --> Final output sent to browser
DEBUG - 2020-10-09 16:03:55 --> Total execution time: 0.0203
ERROR - 2020-10-09 16:04:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:04:20 --> Config Class Initialized
INFO - 2020-10-09 16:04:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:04:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:04:20 --> Utf8 Class Initialized
INFO - 2020-10-09 16:04:20 --> URI Class Initialized
INFO - 2020-10-09 16:04:20 --> Router Class Initialized
INFO - 2020-10-09 16:04:20 --> Output Class Initialized
INFO - 2020-10-09 16:04:20 --> Security Class Initialized
DEBUG - 2020-10-09 16:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:04:20 --> Input Class Initialized
INFO - 2020-10-09 16:04:20 --> Language Class Initialized
INFO - 2020-10-09 16:04:20 --> Loader Class Initialized
INFO - 2020-10-09 16:04:20 --> Helper loaded: url_helper
INFO - 2020-10-09 16:04:20 --> Database Driver Class Initialized
INFO - 2020-10-09 16:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:04:20 --> Email Class Initialized
INFO - 2020-10-09 16:04:20 --> Controller Class Initialized
DEBUG - 2020-10-09 16:04:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:04:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:04:20 --> Model Class Initialized
INFO - 2020-10-09 16:04:20 --> Model Class Initialized
INFO - 2020-10-09 16:04:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-09 16:04:20 --> Final output sent to browser
DEBUG - 2020-10-09 16:04:20 --> Total execution time: 0.0270
ERROR - 2020-10-09 16:04:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:04:38 --> Config Class Initialized
INFO - 2020-10-09 16:04:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:04:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:04:38 --> Utf8 Class Initialized
INFO - 2020-10-09 16:04:38 --> URI Class Initialized
INFO - 2020-10-09 16:04:38 --> Router Class Initialized
INFO - 2020-10-09 16:04:38 --> Output Class Initialized
INFO - 2020-10-09 16:04:38 --> Security Class Initialized
DEBUG - 2020-10-09 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:04:38 --> Input Class Initialized
INFO - 2020-10-09 16:04:38 --> Language Class Initialized
INFO - 2020-10-09 16:04:38 --> Loader Class Initialized
INFO - 2020-10-09 16:04:38 --> Helper loaded: url_helper
INFO - 2020-10-09 16:04:38 --> Database Driver Class Initialized
INFO - 2020-10-09 16:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:04:38 --> Email Class Initialized
INFO - 2020-10-09 16:04:38 --> Controller Class Initialized
DEBUG - 2020-10-09 16:04:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:04:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:04:38 --> Model Class Initialized
INFO - 2020-10-09 16:04:38 --> Model Class Initialized
INFO - 2020-10-09 16:04:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-09 16:04:38 --> Final output sent to browser
DEBUG - 2020-10-09 16:04:38 --> Total execution time: 0.0270
ERROR - 2020-10-09 16:04:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:04:42 --> Config Class Initialized
INFO - 2020-10-09 16:04:42 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:04:42 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:04:42 --> Utf8 Class Initialized
INFO - 2020-10-09 16:04:42 --> URI Class Initialized
INFO - 2020-10-09 16:04:42 --> Router Class Initialized
INFO - 2020-10-09 16:04:42 --> Output Class Initialized
INFO - 2020-10-09 16:04:42 --> Security Class Initialized
DEBUG - 2020-10-09 16:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:04:42 --> Input Class Initialized
INFO - 2020-10-09 16:04:42 --> Language Class Initialized
INFO - 2020-10-09 16:04:42 --> Loader Class Initialized
INFO - 2020-10-09 16:04:42 --> Helper loaded: url_helper
INFO - 2020-10-09 16:04:42 --> Database Driver Class Initialized
INFO - 2020-10-09 16:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:04:42 --> Email Class Initialized
INFO - 2020-10-09 16:04:42 --> Controller Class Initialized
DEBUG - 2020-10-09 16:04:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:04:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:04:42 --> Model Class Initialized
INFO - 2020-10-09 16:04:42 --> Model Class Initialized
INFO - 2020-10-09 16:04:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 16:04:42 --> Final output sent to browser
DEBUG - 2020-10-09 16:04:42 --> Total execution time: 0.0257
ERROR - 2020-10-09 16:04:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:04:43 --> Config Class Initialized
INFO - 2020-10-09 16:04:43 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:04:43 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:04:43 --> Utf8 Class Initialized
INFO - 2020-10-09 16:04:43 --> URI Class Initialized
INFO - 2020-10-09 16:04:43 --> Router Class Initialized
INFO - 2020-10-09 16:04:43 --> Output Class Initialized
INFO - 2020-10-09 16:04:43 --> Security Class Initialized
DEBUG - 2020-10-09 16:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:04:43 --> Input Class Initialized
INFO - 2020-10-09 16:04:43 --> Language Class Initialized
INFO - 2020-10-09 16:04:43 --> Loader Class Initialized
INFO - 2020-10-09 16:04:43 --> Helper loaded: url_helper
INFO - 2020-10-09 16:04:43 --> Database Driver Class Initialized
INFO - 2020-10-09 16:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:04:43 --> Email Class Initialized
INFO - 2020-10-09 16:04:43 --> Controller Class Initialized
DEBUG - 2020-10-09 16:04:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:04:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:04:43 --> Model Class Initialized
INFO - 2020-10-09 16:04:43 --> Model Class Initialized
INFO - 2020-10-09 16:04:43 --> Final output sent to browser
DEBUG - 2020-10-09 16:04:43 --> Total execution time: 0.0231
ERROR - 2020-10-09 16:04:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:04:48 --> Config Class Initialized
INFO - 2020-10-09 16:04:48 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:04:48 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:04:48 --> Utf8 Class Initialized
INFO - 2020-10-09 16:04:48 --> URI Class Initialized
INFO - 2020-10-09 16:04:48 --> Router Class Initialized
INFO - 2020-10-09 16:04:48 --> Output Class Initialized
INFO - 2020-10-09 16:04:48 --> Security Class Initialized
DEBUG - 2020-10-09 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:04:48 --> Input Class Initialized
INFO - 2020-10-09 16:04:48 --> Language Class Initialized
INFO - 2020-10-09 16:04:48 --> Loader Class Initialized
INFO - 2020-10-09 16:04:48 --> Helper loaded: url_helper
INFO - 2020-10-09 16:04:48 --> Database Driver Class Initialized
INFO - 2020-10-09 16:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:04:48 --> Email Class Initialized
INFO - 2020-10-09 16:04:48 --> Controller Class Initialized
DEBUG - 2020-10-09 16:04:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:04:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:04:48 --> Model Class Initialized
INFO - 2020-10-09 16:04:48 --> Model Class Initialized
INFO - 2020-10-09 16:04:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 16:04:48 --> Final output sent to browser
DEBUG - 2020-10-09 16:04:48 --> Total execution time: 0.0217
ERROR - 2020-10-09 16:10:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:10:29 --> Config Class Initialized
INFO - 2020-10-09 16:10:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:10:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:10:29 --> Utf8 Class Initialized
INFO - 2020-10-09 16:10:29 --> URI Class Initialized
DEBUG - 2020-10-09 16:10:29 --> No URI present. Default controller set.
INFO - 2020-10-09 16:10:29 --> Router Class Initialized
INFO - 2020-10-09 16:10:29 --> Output Class Initialized
INFO - 2020-10-09 16:10:29 --> Security Class Initialized
DEBUG - 2020-10-09 16:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:10:29 --> Input Class Initialized
INFO - 2020-10-09 16:10:29 --> Language Class Initialized
INFO - 2020-10-09 16:10:29 --> Loader Class Initialized
INFO - 2020-10-09 16:10:29 --> Helper loaded: url_helper
INFO - 2020-10-09 16:10:29 --> Database Driver Class Initialized
INFO - 2020-10-09 16:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:10:29 --> Email Class Initialized
INFO - 2020-10-09 16:10:29 --> Controller Class Initialized
INFO - 2020-10-09 16:10:29 --> Model Class Initialized
INFO - 2020-10-09 16:10:29 --> Model Class Initialized
DEBUG - 2020-10-09 16:10:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:10:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 16:10:29 --> Final output sent to browser
DEBUG - 2020-10-09 16:10:29 --> Total execution time: 0.0182
ERROR - 2020-10-09 16:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:12:19 --> Config Class Initialized
INFO - 2020-10-09 16:12:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:12:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:12:19 --> Utf8 Class Initialized
INFO - 2020-10-09 16:12:19 --> URI Class Initialized
INFO - 2020-10-09 16:12:19 --> Router Class Initialized
INFO - 2020-10-09 16:12:19 --> Output Class Initialized
INFO - 2020-10-09 16:12:19 --> Security Class Initialized
DEBUG - 2020-10-09 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:12:19 --> Input Class Initialized
INFO - 2020-10-09 16:12:19 --> Language Class Initialized
INFO - 2020-10-09 16:12:19 --> Loader Class Initialized
INFO - 2020-10-09 16:12:19 --> Helper loaded: url_helper
INFO - 2020-10-09 16:12:19 --> Database Driver Class Initialized
INFO - 2020-10-09 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:12:19 --> Email Class Initialized
INFO - 2020-10-09 16:12:19 --> Controller Class Initialized
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
DEBUG - 2020-10-09 16:12:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 16:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:12:19 --> Config Class Initialized
INFO - 2020-10-09 16:12:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:12:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:12:19 --> Utf8 Class Initialized
INFO - 2020-10-09 16:12:19 --> URI Class Initialized
INFO - 2020-10-09 16:12:19 --> Router Class Initialized
INFO - 2020-10-09 16:12:19 --> Output Class Initialized
INFO - 2020-10-09 16:12:19 --> Security Class Initialized
DEBUG - 2020-10-09 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:12:19 --> Input Class Initialized
INFO - 2020-10-09 16:12:19 --> Language Class Initialized
INFO - 2020-10-09 16:12:19 --> Loader Class Initialized
INFO - 2020-10-09 16:12:19 --> Helper loaded: url_helper
INFO - 2020-10-09 16:12:19 --> Database Driver Class Initialized
INFO - 2020-10-09 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:12:19 --> Email Class Initialized
INFO - 2020-10-09 16:12:19 --> Controller Class Initialized
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
DEBUG - 2020-10-09 16:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:12:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
INFO - 2020-10-09 16:12:19 --> Final output sent to browser
DEBUG - 2020-10-09 16:12:19 --> Total execution time: 0.0213
ERROR - 2020-10-09 16:12:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:12:19 --> Config Class Initialized
INFO - 2020-10-09 16:12:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:12:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:12:19 --> Utf8 Class Initialized
INFO - 2020-10-09 16:12:19 --> URI Class Initialized
INFO - 2020-10-09 16:12:19 --> Router Class Initialized
INFO - 2020-10-09 16:12:19 --> Output Class Initialized
INFO - 2020-10-09 16:12:19 --> Security Class Initialized
DEBUG - 2020-10-09 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:12:19 --> Input Class Initialized
INFO - 2020-10-09 16:12:19 --> Language Class Initialized
INFO - 2020-10-09 16:12:19 --> Loader Class Initialized
INFO - 2020-10-09 16:12:19 --> Helper loaded: url_helper
INFO - 2020-10-09 16:12:19 --> Database Driver Class Initialized
INFO - 2020-10-09 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:12:19 --> Email Class Initialized
INFO - 2020-10-09 16:12:19 --> Controller Class Initialized
DEBUG - 2020-10-09 16:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:12:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
INFO - 2020-10-09 16:12:19 --> Model Class Initialized
INFO - 2020-10-09 16:12:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:12:19 --> Final output sent to browser
DEBUG - 2020-10-09 16:12:19 --> Total execution time: 0.0244
ERROR - 2020-10-09 16:12:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:12:25 --> Config Class Initialized
INFO - 2020-10-09 16:12:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:12:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:12:25 --> Utf8 Class Initialized
INFO - 2020-10-09 16:12:25 --> URI Class Initialized
INFO - 2020-10-09 16:12:25 --> Router Class Initialized
INFO - 2020-10-09 16:12:25 --> Output Class Initialized
INFO - 2020-10-09 16:12:25 --> Security Class Initialized
DEBUG - 2020-10-09 16:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:12:25 --> Input Class Initialized
INFO - 2020-10-09 16:12:25 --> Language Class Initialized
INFO - 2020-10-09 16:12:25 --> Loader Class Initialized
INFO - 2020-10-09 16:12:25 --> Helper loaded: url_helper
INFO - 2020-10-09 16:12:25 --> Database Driver Class Initialized
INFO - 2020-10-09 16:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:12:25 --> Email Class Initialized
INFO - 2020-10-09 16:12:25 --> Controller Class Initialized
DEBUG - 2020-10-09 16:12:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:12:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:12:25 --> Model Class Initialized
INFO - 2020-10-09 16:12:25 --> Model Class Initialized
INFO - 2020-10-09 16:12:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:12:25 --> Final output sent to browser
DEBUG - 2020-10-09 16:12:25 --> Total execution time: 0.0233
ERROR - 2020-10-09 16:12:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:12:50 --> Config Class Initialized
INFO - 2020-10-09 16:12:50 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:12:50 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:12:50 --> Utf8 Class Initialized
INFO - 2020-10-09 16:12:50 --> URI Class Initialized
INFO - 2020-10-09 16:12:50 --> Router Class Initialized
INFO - 2020-10-09 16:12:50 --> Output Class Initialized
INFO - 2020-10-09 16:12:50 --> Security Class Initialized
DEBUG - 2020-10-09 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:12:50 --> Input Class Initialized
INFO - 2020-10-09 16:12:50 --> Language Class Initialized
INFO - 2020-10-09 16:12:50 --> Loader Class Initialized
INFO - 2020-10-09 16:12:50 --> Helper loaded: url_helper
INFO - 2020-10-09 16:12:50 --> Database Driver Class Initialized
INFO - 2020-10-09 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:12:50 --> Email Class Initialized
INFO - 2020-10-09 16:12:50 --> Controller Class Initialized
DEBUG - 2020-10-09 16:12:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:12:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:12:50 --> Model Class Initialized
INFO - 2020-10-09 16:12:50 --> Model Class Initialized
INFO - 2020-10-09 16:12:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:12:50 --> Final output sent to browser
DEBUG - 2020-10-09 16:12:50 --> Total execution time: 0.0212
ERROR - 2020-10-09 16:13:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:13:04 --> Config Class Initialized
INFO - 2020-10-09 16:13:04 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:13:04 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:13:04 --> Utf8 Class Initialized
INFO - 2020-10-09 16:13:04 --> URI Class Initialized
INFO - 2020-10-09 16:13:04 --> Router Class Initialized
INFO - 2020-10-09 16:13:04 --> Output Class Initialized
INFO - 2020-10-09 16:13:04 --> Security Class Initialized
DEBUG - 2020-10-09 16:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:13:04 --> Input Class Initialized
INFO - 2020-10-09 16:13:04 --> Language Class Initialized
INFO - 2020-10-09 16:13:04 --> Loader Class Initialized
INFO - 2020-10-09 16:13:04 --> Helper loaded: url_helper
INFO - 2020-10-09 16:13:04 --> Database Driver Class Initialized
INFO - 2020-10-09 16:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:13:04 --> Email Class Initialized
INFO - 2020-10-09 16:13:04 --> Controller Class Initialized
DEBUG - 2020-10-09 16:13:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:13:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:13:04 --> Model Class Initialized
INFO - 2020-10-09 16:13:04 --> Model Class Initialized
INFO - 2020-10-09 16:13:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:13:04 --> Final output sent to browser
DEBUG - 2020-10-09 16:13:04 --> Total execution time: 0.0283
ERROR - 2020-10-09 16:23:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:23:40 --> Config Class Initialized
INFO - 2020-10-09 16:23:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:23:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:23:40 --> Utf8 Class Initialized
INFO - 2020-10-09 16:23:40 --> URI Class Initialized
DEBUG - 2020-10-09 16:23:40 --> No URI present. Default controller set.
INFO - 2020-10-09 16:23:40 --> Router Class Initialized
INFO - 2020-10-09 16:23:40 --> Output Class Initialized
INFO - 2020-10-09 16:23:40 --> Security Class Initialized
DEBUG - 2020-10-09 16:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:23:40 --> Input Class Initialized
INFO - 2020-10-09 16:23:40 --> Language Class Initialized
INFO - 2020-10-09 16:23:40 --> Loader Class Initialized
INFO - 2020-10-09 16:23:40 --> Helper loaded: url_helper
INFO - 2020-10-09 16:23:40 --> Database Driver Class Initialized
INFO - 2020-10-09 16:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:23:40 --> Email Class Initialized
INFO - 2020-10-09 16:23:40 --> Controller Class Initialized
INFO - 2020-10-09 16:23:40 --> Model Class Initialized
INFO - 2020-10-09 16:23:40 --> Model Class Initialized
DEBUG - 2020-10-09 16:23:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:23:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 16:23:40 --> Final output sent to browser
DEBUG - 2020-10-09 16:23:40 --> Total execution time: 0.0450
ERROR - 2020-10-09 16:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:24:11 --> Config Class Initialized
INFO - 2020-10-09 16:24:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:24:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:24:11 --> Utf8 Class Initialized
INFO - 2020-10-09 16:24:11 --> URI Class Initialized
INFO - 2020-10-09 16:24:11 --> Router Class Initialized
INFO - 2020-10-09 16:24:11 --> Output Class Initialized
INFO - 2020-10-09 16:24:11 --> Security Class Initialized
DEBUG - 2020-10-09 16:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:24:11 --> Input Class Initialized
INFO - 2020-10-09 16:24:11 --> Language Class Initialized
INFO - 2020-10-09 16:24:11 --> Loader Class Initialized
INFO - 2020-10-09 16:24:11 --> Helper loaded: url_helper
INFO - 2020-10-09 16:24:11 --> Database Driver Class Initialized
INFO - 2020-10-09 16:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:24:11 --> Email Class Initialized
INFO - 2020-10-09 16:24:11 --> Controller Class Initialized
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
DEBUG - 2020-10-09 16:24:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 16:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:24:11 --> Config Class Initialized
INFO - 2020-10-09 16:24:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:24:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:24:11 --> Utf8 Class Initialized
INFO - 2020-10-09 16:24:11 --> URI Class Initialized
INFO - 2020-10-09 16:24:11 --> Router Class Initialized
INFO - 2020-10-09 16:24:11 --> Output Class Initialized
INFO - 2020-10-09 16:24:11 --> Security Class Initialized
DEBUG - 2020-10-09 16:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:24:11 --> Input Class Initialized
INFO - 2020-10-09 16:24:11 --> Language Class Initialized
INFO - 2020-10-09 16:24:11 --> Loader Class Initialized
INFO - 2020-10-09 16:24:11 --> Helper loaded: url_helper
INFO - 2020-10-09 16:24:11 --> Database Driver Class Initialized
INFO - 2020-10-09 16:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:24:11 --> Email Class Initialized
INFO - 2020-10-09 16:24:11 --> Controller Class Initialized
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
DEBUG - 2020-10-09 16:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:24:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
INFO - 2020-10-09 16:24:11 --> Final output sent to browser
DEBUG - 2020-10-09 16:24:11 --> Total execution time: 0.0283
ERROR - 2020-10-09 16:24:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:24:11 --> Config Class Initialized
INFO - 2020-10-09 16:24:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:24:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:24:11 --> Utf8 Class Initialized
INFO - 2020-10-09 16:24:11 --> URI Class Initialized
INFO - 2020-10-09 16:24:11 --> Router Class Initialized
INFO - 2020-10-09 16:24:11 --> Output Class Initialized
INFO - 2020-10-09 16:24:11 --> Security Class Initialized
DEBUG - 2020-10-09 16:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:24:11 --> Input Class Initialized
INFO - 2020-10-09 16:24:11 --> Language Class Initialized
INFO - 2020-10-09 16:24:11 --> Loader Class Initialized
INFO - 2020-10-09 16:24:11 --> Helper loaded: url_helper
INFO - 2020-10-09 16:24:11 --> Database Driver Class Initialized
INFO - 2020-10-09 16:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:24:11 --> Email Class Initialized
INFO - 2020-10-09 16:24:11 --> Controller Class Initialized
DEBUG - 2020-10-09 16:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:24:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
INFO - 2020-10-09 16:24:11 --> Model Class Initialized
INFO - 2020-10-09 16:24:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:24:11 --> Final output sent to browser
DEBUG - 2020-10-09 16:24:11 --> Total execution time: 0.0226
ERROR - 2020-10-09 16:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:25:28 --> Config Class Initialized
INFO - 2020-10-09 16:25:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:25:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:25:28 --> Utf8 Class Initialized
INFO - 2020-10-09 16:25:28 --> URI Class Initialized
INFO - 2020-10-09 16:25:28 --> Router Class Initialized
INFO - 2020-10-09 16:25:28 --> Output Class Initialized
INFO - 2020-10-09 16:25:28 --> Security Class Initialized
DEBUG - 2020-10-09 16:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:25:28 --> Input Class Initialized
INFO - 2020-10-09 16:25:28 --> Language Class Initialized
INFO - 2020-10-09 16:25:28 --> Loader Class Initialized
INFO - 2020-10-09 16:25:28 --> Helper loaded: url_helper
INFO - 2020-10-09 16:25:28 --> Database Driver Class Initialized
INFO - 2020-10-09 16:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:25:28 --> Email Class Initialized
INFO - 2020-10-09 16:25:28 --> Controller Class Initialized
DEBUG - 2020-10-09 16:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:25:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:25:28 --> Model Class Initialized
INFO - 2020-10-09 16:25:28 --> Model Class Initialized
INFO - 2020-10-09 16:25:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:25:28 --> Final output sent to browser
DEBUG - 2020-10-09 16:25:28 --> Total execution time: 0.0276
ERROR - 2020-10-09 16:30:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:30:19 --> Config Class Initialized
INFO - 2020-10-09 16:30:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:30:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:30:19 --> Utf8 Class Initialized
INFO - 2020-10-09 16:30:19 --> URI Class Initialized
INFO - 2020-10-09 16:30:19 --> Router Class Initialized
INFO - 2020-10-09 16:30:19 --> Output Class Initialized
INFO - 2020-10-09 16:30:19 --> Security Class Initialized
DEBUG - 2020-10-09 16:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:30:19 --> Input Class Initialized
INFO - 2020-10-09 16:30:19 --> Language Class Initialized
INFO - 2020-10-09 16:30:19 --> Loader Class Initialized
INFO - 2020-10-09 16:30:19 --> Helper loaded: url_helper
INFO - 2020-10-09 16:30:19 --> Database Driver Class Initialized
INFO - 2020-10-09 16:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:30:19 --> Email Class Initialized
INFO - 2020-10-09 16:30:19 --> Controller Class Initialized
DEBUG - 2020-10-09 16:30:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:30:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:30:19 --> Model Class Initialized
INFO - 2020-10-09 16:30:19 --> Model Class Initialized
INFO - 2020-10-09 16:30:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:30:19 --> Final output sent to browser
DEBUG - 2020-10-09 16:30:19 --> Total execution time: 0.0269
ERROR - 2020-10-09 16:34:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:34:13 --> Config Class Initialized
INFO - 2020-10-09 16:34:13 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:34:13 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:34:13 --> Utf8 Class Initialized
INFO - 2020-10-09 16:34:13 --> URI Class Initialized
INFO - 2020-10-09 16:34:13 --> Router Class Initialized
INFO - 2020-10-09 16:34:13 --> Output Class Initialized
INFO - 2020-10-09 16:34:13 --> Security Class Initialized
DEBUG - 2020-10-09 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:34:13 --> Input Class Initialized
INFO - 2020-10-09 16:34:13 --> Language Class Initialized
INFO - 2020-10-09 16:34:13 --> Loader Class Initialized
INFO - 2020-10-09 16:34:13 --> Helper loaded: url_helper
INFO - 2020-10-09 16:34:13 --> Database Driver Class Initialized
INFO - 2020-10-09 16:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:34:13 --> Email Class Initialized
INFO - 2020-10-09 16:34:13 --> Controller Class Initialized
DEBUG - 2020-10-09 16:34:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:34:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:34:13 --> Model Class Initialized
INFO - 2020-10-09 16:34:13 --> Model Class Initialized
INFO - 2020-10-09 16:34:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:34:13 --> Final output sent to browser
DEBUG - 2020-10-09 16:34:13 --> Total execution time: 0.0205
ERROR - 2020-10-09 16:34:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:34:24 --> Config Class Initialized
INFO - 2020-10-09 16:34:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:34:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:34:24 --> Utf8 Class Initialized
INFO - 2020-10-09 16:34:24 --> URI Class Initialized
INFO - 2020-10-09 16:34:24 --> Router Class Initialized
INFO - 2020-10-09 16:34:24 --> Output Class Initialized
INFO - 2020-10-09 16:34:24 --> Security Class Initialized
DEBUG - 2020-10-09 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:34:24 --> Input Class Initialized
INFO - 2020-10-09 16:34:24 --> Language Class Initialized
INFO - 2020-10-09 16:34:24 --> Loader Class Initialized
INFO - 2020-10-09 16:34:24 --> Helper loaded: url_helper
INFO - 2020-10-09 16:34:24 --> Database Driver Class Initialized
INFO - 2020-10-09 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:34:24 --> Email Class Initialized
INFO - 2020-10-09 16:34:24 --> Controller Class Initialized
DEBUG - 2020-10-09 16:34:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:34:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:34:24 --> Model Class Initialized
INFO - 2020-10-09 16:34:24 --> Model Class Initialized
INFO - 2020-10-09 16:34:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:34:24 --> Final output sent to browser
DEBUG - 2020-10-09 16:34:24 --> Total execution time: 0.0394
ERROR - 2020-10-09 16:35:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:35:23 --> Config Class Initialized
INFO - 2020-10-09 16:35:23 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:35:23 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:35:23 --> Utf8 Class Initialized
INFO - 2020-10-09 16:35:23 --> URI Class Initialized
INFO - 2020-10-09 16:35:23 --> Router Class Initialized
INFO - 2020-10-09 16:35:23 --> Output Class Initialized
INFO - 2020-10-09 16:35:23 --> Security Class Initialized
DEBUG - 2020-10-09 16:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:35:23 --> Input Class Initialized
INFO - 2020-10-09 16:35:23 --> Language Class Initialized
INFO - 2020-10-09 16:35:23 --> Loader Class Initialized
INFO - 2020-10-09 16:35:23 --> Helper loaded: url_helper
INFO - 2020-10-09 16:35:23 --> Database Driver Class Initialized
INFO - 2020-10-09 16:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:35:23 --> Email Class Initialized
INFO - 2020-10-09 16:35:23 --> Controller Class Initialized
DEBUG - 2020-10-09 16:35:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:35:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:35:23 --> Model Class Initialized
INFO - 2020-10-09 16:35:23 --> Model Class Initialized
INFO - 2020-10-09 16:35:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:35:23 --> Final output sent to browser
DEBUG - 2020-10-09 16:35:23 --> Total execution time: 0.0321
ERROR - 2020-10-09 16:39:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:39:13 --> Config Class Initialized
INFO - 2020-10-09 16:39:13 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:39:13 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:39:13 --> Utf8 Class Initialized
INFO - 2020-10-09 16:39:13 --> URI Class Initialized
INFO - 2020-10-09 16:39:13 --> Router Class Initialized
INFO - 2020-10-09 16:39:13 --> Output Class Initialized
INFO - 2020-10-09 16:39:13 --> Security Class Initialized
DEBUG - 2020-10-09 16:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:39:13 --> Input Class Initialized
INFO - 2020-10-09 16:39:13 --> Language Class Initialized
INFO - 2020-10-09 16:39:13 --> Loader Class Initialized
INFO - 2020-10-09 16:39:13 --> Helper loaded: url_helper
INFO - 2020-10-09 16:39:13 --> Database Driver Class Initialized
INFO - 2020-10-09 16:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:39:13 --> Email Class Initialized
INFO - 2020-10-09 16:39:13 --> Controller Class Initialized
DEBUG - 2020-10-09 16:39:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:39:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:39:13 --> Model Class Initialized
INFO - 2020-10-09 16:39:13 --> Model Class Initialized
INFO - 2020-10-09 16:39:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:39:13 --> Final output sent to browser
DEBUG - 2020-10-09 16:39:13 --> Total execution time: 0.0283
ERROR - 2020-10-09 16:43:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:43:13 --> Config Class Initialized
INFO - 2020-10-09 16:43:13 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:43:13 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:43:13 --> Utf8 Class Initialized
INFO - 2020-10-09 16:43:13 --> URI Class Initialized
INFO - 2020-10-09 16:43:13 --> Router Class Initialized
INFO - 2020-10-09 16:43:13 --> Output Class Initialized
INFO - 2020-10-09 16:43:13 --> Security Class Initialized
DEBUG - 2020-10-09 16:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:43:13 --> Input Class Initialized
INFO - 2020-10-09 16:43:13 --> Language Class Initialized
INFO - 2020-10-09 16:43:13 --> Loader Class Initialized
INFO - 2020-10-09 16:43:13 --> Helper loaded: url_helper
INFO - 2020-10-09 16:43:13 --> Database Driver Class Initialized
INFO - 2020-10-09 16:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:43:13 --> Email Class Initialized
INFO - 2020-10-09 16:43:13 --> Controller Class Initialized
DEBUG - 2020-10-09 16:43:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:43:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:43:13 --> Model Class Initialized
INFO - 2020-10-09 16:43:13 --> Model Class Initialized
INFO - 2020-10-09 16:43:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:43:13 --> Final output sent to browser
DEBUG - 2020-10-09 16:43:13 --> Total execution time: 0.0331
ERROR - 2020-10-09 16:43:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:43:36 --> Config Class Initialized
INFO - 2020-10-09 16:43:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:43:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:43:36 --> Utf8 Class Initialized
INFO - 2020-10-09 16:43:36 --> URI Class Initialized
INFO - 2020-10-09 16:43:36 --> Router Class Initialized
INFO - 2020-10-09 16:43:36 --> Output Class Initialized
INFO - 2020-10-09 16:43:36 --> Security Class Initialized
DEBUG - 2020-10-09 16:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:43:36 --> Input Class Initialized
INFO - 2020-10-09 16:43:36 --> Language Class Initialized
INFO - 2020-10-09 16:43:36 --> Loader Class Initialized
INFO - 2020-10-09 16:43:36 --> Helper loaded: url_helper
INFO - 2020-10-09 16:43:36 --> Database Driver Class Initialized
INFO - 2020-10-09 16:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:43:36 --> Email Class Initialized
INFO - 2020-10-09 16:43:36 --> Controller Class Initialized
DEBUG - 2020-10-09 16:43:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:43:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:43:36 --> Model Class Initialized
INFO - 2020-10-09 16:43:37 --> Model Class Initialized
INFO - 2020-10-09 16:43:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:43:37 --> Final output sent to browser
DEBUG - 2020-10-09 16:43:37 --> Total execution time: 0.0280
ERROR - 2020-10-09 16:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:43:40 --> Config Class Initialized
INFO - 2020-10-09 16:43:40 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:43:40 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:43:40 --> Utf8 Class Initialized
INFO - 2020-10-09 16:43:40 --> URI Class Initialized
INFO - 2020-10-09 16:43:40 --> Router Class Initialized
INFO - 2020-10-09 16:43:40 --> Output Class Initialized
INFO - 2020-10-09 16:43:40 --> Security Class Initialized
DEBUG - 2020-10-09 16:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:43:40 --> Input Class Initialized
INFO - 2020-10-09 16:43:40 --> Language Class Initialized
INFO - 2020-10-09 16:43:40 --> Loader Class Initialized
INFO - 2020-10-09 16:43:40 --> Helper loaded: url_helper
INFO - 2020-10-09 16:43:40 --> Database Driver Class Initialized
INFO - 2020-10-09 16:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:43:40 --> Email Class Initialized
INFO - 2020-10-09 16:43:40 --> Controller Class Initialized
DEBUG - 2020-10-09 16:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:43:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:43:40 --> Model Class Initialized
INFO - 2020-10-09 16:43:40 --> Model Class Initialized
INFO - 2020-10-09 16:43:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:43:40 --> Final output sent to browser
DEBUG - 2020-10-09 16:43:40 --> Total execution time: 0.0246
ERROR - 2020-10-09 16:43:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:43:58 --> Config Class Initialized
INFO - 2020-10-09 16:43:58 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:43:58 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:43:58 --> Utf8 Class Initialized
INFO - 2020-10-09 16:43:58 --> URI Class Initialized
INFO - 2020-10-09 16:43:58 --> Router Class Initialized
INFO - 2020-10-09 16:43:58 --> Output Class Initialized
INFO - 2020-10-09 16:43:58 --> Security Class Initialized
DEBUG - 2020-10-09 16:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:43:58 --> Input Class Initialized
INFO - 2020-10-09 16:43:58 --> Language Class Initialized
INFO - 2020-10-09 16:43:58 --> Loader Class Initialized
INFO - 2020-10-09 16:43:58 --> Helper loaded: url_helper
INFO - 2020-10-09 16:43:58 --> Database Driver Class Initialized
INFO - 2020-10-09 16:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:43:58 --> Email Class Initialized
INFO - 2020-10-09 16:43:58 --> Controller Class Initialized
DEBUG - 2020-10-09 16:43:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:43:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:43:58 --> Model Class Initialized
INFO - 2020-10-09 16:43:58 --> Model Class Initialized
INFO - 2020-10-09 16:43:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:43:58 --> Final output sent to browser
DEBUG - 2020-10-09 16:43:58 --> Total execution time: 0.0289
ERROR - 2020-10-09 16:45:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:00 --> Config Class Initialized
INFO - 2020-10-09 16:45:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:00 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:00 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:00 --> URI Class Initialized
INFO - 2020-10-09 16:45:00 --> Router Class Initialized
INFO - 2020-10-09 16:45:00 --> Output Class Initialized
INFO - 2020-10-09 16:45:00 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:00 --> Input Class Initialized
INFO - 2020-10-09 16:45:00 --> Language Class Initialized
INFO - 2020-10-09 16:45:00 --> Loader Class Initialized
INFO - 2020-10-09 16:45:00 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:00 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:00 --> Email Class Initialized
INFO - 2020-10-09 16:45:00 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:00 --> Model Class Initialized
INFO - 2020-10-09 16:45:00 --> Model Class Initialized
INFO - 2020-10-09 16:45:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:45:00 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:00 --> Total execution time: 0.0272
ERROR - 2020-10-09 16:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:02 --> Config Class Initialized
INFO - 2020-10-09 16:45:02 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:02 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:02 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:02 --> URI Class Initialized
INFO - 2020-10-09 16:45:02 --> Router Class Initialized
INFO - 2020-10-09 16:45:02 --> Output Class Initialized
INFO - 2020-10-09 16:45:02 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:02 --> Input Class Initialized
INFO - 2020-10-09 16:45:02 --> Language Class Initialized
INFO - 2020-10-09 16:45:02 --> Loader Class Initialized
INFO - 2020-10-09 16:45:02 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:02 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:02 --> Email Class Initialized
INFO - 2020-10-09 16:45:02 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:02 --> Model Class Initialized
INFO - 2020-10-09 16:45:02 --> Model Class Initialized
INFO - 2020-10-09 16:45:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:45:02 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:02 --> Total execution time: 0.0280
ERROR - 2020-10-09 16:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:08 --> Config Class Initialized
INFO - 2020-10-09 16:45:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:08 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:08 --> URI Class Initialized
INFO - 2020-10-09 16:45:08 --> Router Class Initialized
INFO - 2020-10-09 16:45:08 --> Output Class Initialized
INFO - 2020-10-09 16:45:08 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:08 --> Input Class Initialized
INFO - 2020-10-09 16:45:08 --> Language Class Initialized
INFO - 2020-10-09 16:45:08 --> Loader Class Initialized
INFO - 2020-10-09 16:45:08 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:08 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:08 --> Email Class Initialized
INFO - 2020-10-09 16:45:08 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:08 --> Model Class Initialized
INFO - 2020-10-09 16:45:08 --> Model Class Initialized
INFO - 2020-10-09 16:45:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:45:08 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:08 --> Total execution time: 0.0241
ERROR - 2020-10-09 16:45:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:22 --> Config Class Initialized
INFO - 2020-10-09 16:45:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:22 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:22 --> URI Class Initialized
INFO - 2020-10-09 16:45:22 --> Router Class Initialized
INFO - 2020-10-09 16:45:22 --> Output Class Initialized
INFO - 2020-10-09 16:45:22 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:22 --> Input Class Initialized
INFO - 2020-10-09 16:45:22 --> Language Class Initialized
INFO - 2020-10-09 16:45:22 --> Loader Class Initialized
INFO - 2020-10-09 16:45:22 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:22 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:22 --> Email Class Initialized
INFO - 2020-10-09 16:45:22 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:22 --> Model Class Initialized
INFO - 2020-10-09 16:45:22 --> Model Class Initialized
INFO - 2020-10-09 16:45:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:45:22 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:22 --> Total execution time: 0.0239
ERROR - 2020-10-09 16:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:28 --> Config Class Initialized
INFO - 2020-10-09 16:45:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:28 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:28 --> URI Class Initialized
INFO - 2020-10-09 16:45:28 --> Router Class Initialized
INFO - 2020-10-09 16:45:28 --> Output Class Initialized
INFO - 2020-10-09 16:45:28 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:28 --> Input Class Initialized
INFO - 2020-10-09 16:45:28 --> Language Class Initialized
INFO - 2020-10-09 16:45:28 --> Loader Class Initialized
INFO - 2020-10-09 16:45:28 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:28 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:28 --> Email Class Initialized
INFO - 2020-10-09 16:45:28 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:28 --> Model Class Initialized
INFO - 2020-10-09 16:45:28 --> Model Class Initialized
INFO - 2020-10-09 16:45:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:45:28 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:28 --> Total execution time: 0.0205
ERROR - 2020-10-09 16:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:31 --> Config Class Initialized
INFO - 2020-10-09 16:45:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:31 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:31 --> URI Class Initialized
INFO - 2020-10-09 16:45:31 --> Router Class Initialized
INFO - 2020-10-09 16:45:31 --> Output Class Initialized
INFO - 2020-10-09 16:45:31 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:31 --> Input Class Initialized
INFO - 2020-10-09 16:45:31 --> Language Class Initialized
INFO - 2020-10-09 16:45:31 --> Loader Class Initialized
INFO - 2020-10-09 16:45:31 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:31 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:31 --> Email Class Initialized
INFO - 2020-10-09 16:45:31 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:31 --> Model Class Initialized
INFO - 2020-10-09 16:45:31 --> Model Class Initialized
INFO - 2020-10-09 16:45:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:45:31 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:31 --> Total execution time: 0.0242
ERROR - 2020-10-09 16:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:45:41 --> Config Class Initialized
INFO - 2020-10-09 16:45:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:45:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:45:41 --> Utf8 Class Initialized
INFO - 2020-10-09 16:45:41 --> URI Class Initialized
INFO - 2020-10-09 16:45:41 --> Router Class Initialized
INFO - 2020-10-09 16:45:41 --> Output Class Initialized
INFO - 2020-10-09 16:45:41 --> Security Class Initialized
DEBUG - 2020-10-09 16:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:45:41 --> Input Class Initialized
INFO - 2020-10-09 16:45:41 --> Language Class Initialized
INFO - 2020-10-09 16:45:41 --> Loader Class Initialized
INFO - 2020-10-09 16:45:41 --> Helper loaded: url_helper
INFO - 2020-10-09 16:45:41 --> Database Driver Class Initialized
INFO - 2020-10-09 16:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:45:41 --> Email Class Initialized
INFO - 2020-10-09 16:45:41 --> Controller Class Initialized
DEBUG - 2020-10-09 16:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:45:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:45:41 --> Model Class Initialized
INFO - 2020-10-09 16:45:41 --> Model Class Initialized
INFO - 2020-10-09 16:45:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:45:42 --> Final output sent to browser
DEBUG - 2020-10-09 16:45:42 --> Total execution time: 0.0297
ERROR - 2020-10-09 16:46:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:46:43 --> Config Class Initialized
INFO - 2020-10-09 16:46:43 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:46:43 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:46:43 --> Utf8 Class Initialized
INFO - 2020-10-09 16:46:43 --> URI Class Initialized
INFO - 2020-10-09 16:46:43 --> Router Class Initialized
INFO - 2020-10-09 16:46:43 --> Output Class Initialized
INFO - 2020-10-09 16:46:43 --> Security Class Initialized
DEBUG - 2020-10-09 16:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:46:43 --> Input Class Initialized
INFO - 2020-10-09 16:46:43 --> Language Class Initialized
INFO - 2020-10-09 16:46:43 --> Loader Class Initialized
INFO - 2020-10-09 16:46:43 --> Helper loaded: url_helper
INFO - 2020-10-09 16:46:43 --> Database Driver Class Initialized
INFO - 2020-10-09 16:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:46:43 --> Email Class Initialized
INFO - 2020-10-09 16:46:43 --> Controller Class Initialized
DEBUG - 2020-10-09 16:46:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:46:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:46:43 --> Model Class Initialized
INFO - 2020-10-09 16:46:43 --> Model Class Initialized
INFO - 2020-10-09 16:46:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:46:43 --> Final output sent to browser
DEBUG - 2020-10-09 16:46:43 --> Total execution time: 0.0261
ERROR - 2020-10-09 16:46:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:46:46 --> Config Class Initialized
INFO - 2020-10-09 16:46:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:46:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:46:46 --> Utf8 Class Initialized
INFO - 2020-10-09 16:46:46 --> URI Class Initialized
INFO - 2020-10-09 16:46:46 --> Router Class Initialized
INFO - 2020-10-09 16:46:46 --> Output Class Initialized
INFO - 2020-10-09 16:46:46 --> Security Class Initialized
DEBUG - 2020-10-09 16:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:46:46 --> Input Class Initialized
INFO - 2020-10-09 16:46:46 --> Language Class Initialized
INFO - 2020-10-09 16:46:46 --> Loader Class Initialized
INFO - 2020-10-09 16:46:46 --> Helper loaded: url_helper
INFO - 2020-10-09 16:46:46 --> Database Driver Class Initialized
INFO - 2020-10-09 16:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:46:46 --> Email Class Initialized
INFO - 2020-10-09 16:46:46 --> Controller Class Initialized
DEBUG - 2020-10-09 16:46:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:46:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:46:46 --> Model Class Initialized
INFO - 2020-10-09 16:46:46 --> Model Class Initialized
INFO - 2020-10-09 16:46:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:46:46 --> Final output sent to browser
DEBUG - 2020-10-09 16:46:46 --> Total execution time: 0.0243
ERROR - 2020-10-09 16:46:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:46:53 --> Config Class Initialized
INFO - 2020-10-09 16:46:53 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:46:53 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:46:53 --> Utf8 Class Initialized
INFO - 2020-10-09 16:46:53 --> URI Class Initialized
INFO - 2020-10-09 16:46:53 --> Router Class Initialized
INFO - 2020-10-09 16:46:53 --> Output Class Initialized
INFO - 2020-10-09 16:46:53 --> Security Class Initialized
DEBUG - 2020-10-09 16:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:46:53 --> Input Class Initialized
INFO - 2020-10-09 16:46:53 --> Language Class Initialized
INFO - 2020-10-09 16:46:53 --> Loader Class Initialized
INFO - 2020-10-09 16:46:53 --> Helper loaded: url_helper
INFO - 2020-10-09 16:46:54 --> Database Driver Class Initialized
INFO - 2020-10-09 16:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:46:54 --> Email Class Initialized
INFO - 2020-10-09 16:46:54 --> Controller Class Initialized
DEBUG - 2020-10-09 16:46:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:46:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:46:54 --> Model Class Initialized
INFO - 2020-10-09 16:46:54 --> Model Class Initialized
INFO - 2020-10-09 16:46:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:46:54 --> Final output sent to browser
DEBUG - 2020-10-09 16:46:54 --> Total execution time: 0.0257
ERROR - 2020-10-09 16:46:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:46:59 --> Config Class Initialized
INFO - 2020-10-09 16:46:59 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:46:59 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:46:59 --> Utf8 Class Initialized
INFO - 2020-10-09 16:46:59 --> URI Class Initialized
INFO - 2020-10-09 16:46:59 --> Router Class Initialized
INFO - 2020-10-09 16:46:59 --> Output Class Initialized
INFO - 2020-10-09 16:46:59 --> Security Class Initialized
DEBUG - 2020-10-09 16:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:46:59 --> Input Class Initialized
INFO - 2020-10-09 16:46:59 --> Language Class Initialized
INFO - 2020-10-09 16:46:59 --> Loader Class Initialized
INFO - 2020-10-09 16:46:59 --> Helper loaded: url_helper
INFO - 2020-10-09 16:46:59 --> Database Driver Class Initialized
INFO - 2020-10-09 16:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:46:59 --> Email Class Initialized
INFO - 2020-10-09 16:46:59 --> Controller Class Initialized
DEBUG - 2020-10-09 16:46:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:46:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:46:59 --> Model Class Initialized
INFO - 2020-10-09 16:46:59 --> Model Class Initialized
INFO - 2020-10-09 16:46:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:46:59 --> Final output sent to browser
DEBUG - 2020-10-09 16:46:59 --> Total execution time: 0.0213
ERROR - 2020-10-09 16:47:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:03 --> Config Class Initialized
INFO - 2020-10-09 16:47:03 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:03 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:03 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:03 --> URI Class Initialized
INFO - 2020-10-09 16:47:03 --> Router Class Initialized
INFO - 2020-10-09 16:47:03 --> Output Class Initialized
INFO - 2020-10-09 16:47:03 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:03 --> Input Class Initialized
INFO - 2020-10-09 16:47:03 --> Language Class Initialized
INFO - 2020-10-09 16:47:03 --> Loader Class Initialized
INFO - 2020-10-09 16:47:03 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:03 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:03 --> Email Class Initialized
INFO - 2020-10-09 16:47:03 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:03 --> Model Class Initialized
INFO - 2020-10-09 16:47:03 --> Model Class Initialized
INFO - 2020-10-09 16:47:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:47:03 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:03 --> Total execution time: 0.0228
ERROR - 2020-10-09 16:47:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:06 --> Config Class Initialized
INFO - 2020-10-09 16:47:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:06 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:06 --> URI Class Initialized
INFO - 2020-10-09 16:47:06 --> Router Class Initialized
INFO - 2020-10-09 16:47:06 --> Output Class Initialized
INFO - 2020-10-09 16:47:06 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:06 --> Input Class Initialized
INFO - 2020-10-09 16:47:06 --> Language Class Initialized
INFO - 2020-10-09 16:47:06 --> Loader Class Initialized
INFO - 2020-10-09 16:47:06 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:06 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:06 --> Email Class Initialized
INFO - 2020-10-09 16:47:06 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:06 --> Model Class Initialized
INFO - 2020-10-09 16:47:06 --> Model Class Initialized
INFO - 2020-10-09 16:47:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:47:06 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:06 --> Total execution time: 0.0235
ERROR - 2020-10-09 16:47:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:09 --> Config Class Initialized
INFO - 2020-10-09 16:47:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:09 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:09 --> URI Class Initialized
INFO - 2020-10-09 16:47:09 --> Router Class Initialized
INFO - 2020-10-09 16:47:09 --> Output Class Initialized
INFO - 2020-10-09 16:47:09 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:09 --> Input Class Initialized
INFO - 2020-10-09 16:47:09 --> Language Class Initialized
INFO - 2020-10-09 16:47:09 --> Loader Class Initialized
INFO - 2020-10-09 16:47:09 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:09 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:09 --> Email Class Initialized
INFO - 2020-10-09 16:47:09 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:09 --> Model Class Initialized
INFO - 2020-10-09 16:47:09 --> Model Class Initialized
INFO - 2020-10-09 16:47:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:47:09 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:09 --> Total execution time: 0.0275
ERROR - 2020-10-09 16:47:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:32 --> Config Class Initialized
INFO - 2020-10-09 16:47:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:32 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:32 --> URI Class Initialized
INFO - 2020-10-09 16:47:32 --> Router Class Initialized
INFO - 2020-10-09 16:47:32 --> Output Class Initialized
INFO - 2020-10-09 16:47:32 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:32 --> Input Class Initialized
INFO - 2020-10-09 16:47:32 --> Language Class Initialized
INFO - 2020-10-09 16:47:32 --> Loader Class Initialized
INFO - 2020-10-09 16:47:32 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:32 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:32 --> Email Class Initialized
INFO - 2020-10-09 16:47:32 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:32 --> Model Class Initialized
INFO - 2020-10-09 16:47:32 --> Model Class Initialized
INFO - 2020-10-09 16:47:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:47:32 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:32 --> Total execution time: 0.0207
ERROR - 2020-10-09 16:47:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:43 --> Config Class Initialized
INFO - 2020-10-09 16:47:43 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:43 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:43 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:43 --> URI Class Initialized
INFO - 2020-10-09 16:47:43 --> Router Class Initialized
INFO - 2020-10-09 16:47:43 --> Output Class Initialized
INFO - 2020-10-09 16:47:43 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:43 --> Input Class Initialized
INFO - 2020-10-09 16:47:43 --> Language Class Initialized
INFO - 2020-10-09 16:47:43 --> Loader Class Initialized
INFO - 2020-10-09 16:47:43 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:43 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:43 --> Email Class Initialized
INFO - 2020-10-09 16:47:43 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:43 --> Model Class Initialized
INFO - 2020-10-09 16:47:43 --> Model Class Initialized
INFO - 2020-10-09 16:47:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:47:43 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:43 --> Total execution time: 0.0240
ERROR - 2020-10-09 16:47:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:55 --> Config Class Initialized
INFO - 2020-10-09 16:47:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:55 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:55 --> URI Class Initialized
INFO - 2020-10-09 16:47:55 --> Router Class Initialized
INFO - 2020-10-09 16:47:55 --> Output Class Initialized
INFO - 2020-10-09 16:47:55 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:55 --> Input Class Initialized
INFO - 2020-10-09 16:47:55 --> Language Class Initialized
INFO - 2020-10-09 16:47:55 --> Loader Class Initialized
INFO - 2020-10-09 16:47:55 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:55 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:55 --> Email Class Initialized
INFO - 2020-10-09 16:47:55 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:55 --> Model Class Initialized
INFO - 2020-10-09 16:47:55 --> Model Class Initialized
INFO - 2020-10-09 16:47:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:47:55 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:55 --> Total execution time: 0.0252
ERROR - 2020-10-09 16:47:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:47:57 --> Config Class Initialized
INFO - 2020-10-09 16:47:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:47:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:47:57 --> Utf8 Class Initialized
INFO - 2020-10-09 16:47:57 --> URI Class Initialized
INFO - 2020-10-09 16:47:57 --> Router Class Initialized
INFO - 2020-10-09 16:47:57 --> Output Class Initialized
INFO - 2020-10-09 16:47:57 --> Security Class Initialized
DEBUG - 2020-10-09 16:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:47:57 --> Input Class Initialized
INFO - 2020-10-09 16:47:57 --> Language Class Initialized
INFO - 2020-10-09 16:47:57 --> Loader Class Initialized
INFO - 2020-10-09 16:47:57 --> Helper loaded: url_helper
INFO - 2020-10-09 16:47:57 --> Database Driver Class Initialized
INFO - 2020-10-09 16:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:47:57 --> Email Class Initialized
INFO - 2020-10-09 16:47:57 --> Controller Class Initialized
DEBUG - 2020-10-09 16:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:47:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:47:57 --> Model Class Initialized
INFO - 2020-10-09 16:47:57 --> Model Class Initialized
INFO - 2020-10-09 16:47:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:47:57 --> Final output sent to browser
DEBUG - 2020-10-09 16:47:57 --> Total execution time: 0.0272
ERROR - 2020-10-09 16:48:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:48:27 --> Config Class Initialized
INFO - 2020-10-09 16:48:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:48:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:48:27 --> Utf8 Class Initialized
INFO - 2020-10-09 16:48:27 --> URI Class Initialized
INFO - 2020-10-09 16:48:27 --> Router Class Initialized
INFO - 2020-10-09 16:48:27 --> Output Class Initialized
INFO - 2020-10-09 16:48:27 --> Security Class Initialized
DEBUG - 2020-10-09 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:48:27 --> Input Class Initialized
INFO - 2020-10-09 16:48:27 --> Language Class Initialized
INFO - 2020-10-09 16:48:27 --> Loader Class Initialized
INFO - 2020-10-09 16:48:27 --> Helper loaded: url_helper
INFO - 2020-10-09 16:48:27 --> Database Driver Class Initialized
INFO - 2020-10-09 16:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:48:27 --> Email Class Initialized
INFO - 2020-10-09 16:48:27 --> Controller Class Initialized
DEBUG - 2020-10-09 16:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:48:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:48:27 --> Model Class Initialized
INFO - 2020-10-09 16:48:27 --> Model Class Initialized
INFO - 2020-10-09 16:48:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:48:27 --> Final output sent to browser
DEBUG - 2020-10-09 16:48:27 --> Total execution time: 0.0200
ERROR - 2020-10-09 16:48:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:48:31 --> Config Class Initialized
INFO - 2020-10-09 16:48:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:48:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:48:31 --> Utf8 Class Initialized
INFO - 2020-10-09 16:48:31 --> URI Class Initialized
INFO - 2020-10-09 16:48:31 --> Router Class Initialized
INFO - 2020-10-09 16:48:31 --> Output Class Initialized
INFO - 2020-10-09 16:48:31 --> Security Class Initialized
DEBUG - 2020-10-09 16:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:48:31 --> Input Class Initialized
INFO - 2020-10-09 16:48:31 --> Language Class Initialized
INFO - 2020-10-09 16:48:31 --> Loader Class Initialized
INFO - 2020-10-09 16:48:31 --> Helper loaded: url_helper
INFO - 2020-10-09 16:48:31 --> Database Driver Class Initialized
INFO - 2020-10-09 16:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:48:31 --> Email Class Initialized
INFO - 2020-10-09 16:48:31 --> Controller Class Initialized
DEBUG - 2020-10-09 16:48:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:48:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:48:31 --> Model Class Initialized
INFO - 2020-10-09 16:48:31 --> Model Class Initialized
INFO - 2020-10-09 16:48:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:48:31 --> Final output sent to browser
DEBUG - 2020-10-09 16:48:31 --> Total execution time: 0.0263
ERROR - 2020-10-09 16:48:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:48:36 --> Config Class Initialized
INFO - 2020-10-09 16:48:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:48:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:48:36 --> Utf8 Class Initialized
INFO - 2020-10-09 16:48:36 --> URI Class Initialized
INFO - 2020-10-09 16:48:36 --> Router Class Initialized
INFO - 2020-10-09 16:48:36 --> Output Class Initialized
INFO - 2020-10-09 16:48:36 --> Security Class Initialized
DEBUG - 2020-10-09 16:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:48:36 --> Input Class Initialized
INFO - 2020-10-09 16:48:36 --> Language Class Initialized
INFO - 2020-10-09 16:48:36 --> Loader Class Initialized
INFO - 2020-10-09 16:48:36 --> Helper loaded: url_helper
INFO - 2020-10-09 16:48:36 --> Database Driver Class Initialized
INFO - 2020-10-09 16:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:48:36 --> Email Class Initialized
INFO - 2020-10-09 16:48:36 --> Controller Class Initialized
DEBUG - 2020-10-09 16:48:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:48:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:48:36 --> Model Class Initialized
INFO - 2020-10-09 16:48:36 --> Model Class Initialized
INFO - 2020-10-09 16:48:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:48:36 --> Final output sent to browser
DEBUG - 2020-10-09 16:48:36 --> Total execution time: 0.0239
ERROR - 2020-10-09 16:50:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:50:17 --> Config Class Initialized
INFO - 2020-10-09 16:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:50:17 --> Utf8 Class Initialized
INFO - 2020-10-09 16:50:17 --> URI Class Initialized
INFO - 2020-10-09 16:50:17 --> Router Class Initialized
INFO - 2020-10-09 16:50:17 --> Output Class Initialized
INFO - 2020-10-09 16:50:17 --> Security Class Initialized
DEBUG - 2020-10-09 16:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:50:17 --> Input Class Initialized
INFO - 2020-10-09 16:50:17 --> Language Class Initialized
INFO - 2020-10-09 16:50:17 --> Loader Class Initialized
INFO - 2020-10-09 16:50:17 --> Helper loaded: url_helper
INFO - 2020-10-09 16:50:17 --> Database Driver Class Initialized
INFO - 2020-10-09 16:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:50:17 --> Email Class Initialized
INFO - 2020-10-09 16:50:17 --> Controller Class Initialized
DEBUG - 2020-10-09 16:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:50:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:50:17 --> Model Class Initialized
INFO - 2020-10-09 16:50:17 --> Model Class Initialized
INFO - 2020-10-09 16:50:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:50:17 --> Final output sent to browser
DEBUG - 2020-10-09 16:50:17 --> Total execution time: 0.0261
ERROR - 2020-10-09 16:50:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:50:22 --> Config Class Initialized
INFO - 2020-10-09 16:50:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:50:22 --> Utf8 Class Initialized
INFO - 2020-10-09 16:50:22 --> URI Class Initialized
INFO - 2020-10-09 16:50:22 --> Router Class Initialized
INFO - 2020-10-09 16:50:22 --> Output Class Initialized
INFO - 2020-10-09 16:50:22 --> Security Class Initialized
DEBUG - 2020-10-09 16:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:50:22 --> Input Class Initialized
INFO - 2020-10-09 16:50:22 --> Language Class Initialized
INFO - 2020-10-09 16:50:22 --> Loader Class Initialized
INFO - 2020-10-09 16:50:22 --> Helper loaded: url_helper
INFO - 2020-10-09 16:50:22 --> Database Driver Class Initialized
INFO - 2020-10-09 16:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:50:22 --> Email Class Initialized
INFO - 2020-10-09 16:50:22 --> Controller Class Initialized
DEBUG - 2020-10-09 16:50:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:50:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:50:22 --> Model Class Initialized
INFO - 2020-10-09 16:50:22 --> Model Class Initialized
INFO - 2020-10-09 16:50:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:50:22 --> Final output sent to browser
DEBUG - 2020-10-09 16:50:22 --> Total execution time: 0.0245
ERROR - 2020-10-09 16:50:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:50:26 --> Config Class Initialized
INFO - 2020-10-09 16:50:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:50:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:50:26 --> Utf8 Class Initialized
INFO - 2020-10-09 16:50:26 --> URI Class Initialized
INFO - 2020-10-09 16:50:26 --> Router Class Initialized
INFO - 2020-10-09 16:50:26 --> Output Class Initialized
INFO - 2020-10-09 16:50:26 --> Security Class Initialized
DEBUG - 2020-10-09 16:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:50:26 --> Input Class Initialized
INFO - 2020-10-09 16:50:26 --> Language Class Initialized
INFO - 2020-10-09 16:50:26 --> Loader Class Initialized
INFO - 2020-10-09 16:50:26 --> Helper loaded: url_helper
INFO - 2020-10-09 16:50:26 --> Database Driver Class Initialized
INFO - 2020-10-09 16:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:50:26 --> Email Class Initialized
INFO - 2020-10-09 16:50:26 --> Controller Class Initialized
DEBUG - 2020-10-09 16:50:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:50:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:50:26 --> Model Class Initialized
INFO - 2020-10-09 16:50:26 --> Model Class Initialized
INFO - 2020-10-09 16:50:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:50:26 --> Final output sent to browser
DEBUG - 2020-10-09 16:50:26 --> Total execution time: 0.0263
ERROR - 2020-10-09 16:50:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:50:28 --> Config Class Initialized
INFO - 2020-10-09 16:50:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:50:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:50:28 --> Utf8 Class Initialized
INFO - 2020-10-09 16:50:28 --> URI Class Initialized
INFO - 2020-10-09 16:50:28 --> Router Class Initialized
INFO - 2020-10-09 16:50:28 --> Output Class Initialized
INFO - 2020-10-09 16:50:28 --> Security Class Initialized
DEBUG - 2020-10-09 16:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:50:28 --> Input Class Initialized
INFO - 2020-10-09 16:50:28 --> Language Class Initialized
INFO - 2020-10-09 16:50:28 --> Loader Class Initialized
INFO - 2020-10-09 16:50:28 --> Helper loaded: url_helper
INFO - 2020-10-09 16:50:28 --> Database Driver Class Initialized
INFO - 2020-10-09 16:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:50:28 --> Email Class Initialized
INFO - 2020-10-09 16:50:28 --> Controller Class Initialized
DEBUG - 2020-10-09 16:50:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:50:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:50:28 --> Model Class Initialized
INFO - 2020-10-09 16:50:28 --> Model Class Initialized
ERROR - 2020-10-09 16:50:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL client_status_update2(14,)
INFO - 2020-10-09 16:50:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 16:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:50:49 --> Config Class Initialized
INFO - 2020-10-09 16:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:50:49 --> Utf8 Class Initialized
INFO - 2020-10-09 16:50:49 --> URI Class Initialized
INFO - 2020-10-09 16:50:49 --> Router Class Initialized
INFO - 2020-10-09 16:50:49 --> Output Class Initialized
INFO - 2020-10-09 16:50:49 --> Security Class Initialized
DEBUG - 2020-10-09 16:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:50:49 --> Input Class Initialized
INFO - 2020-10-09 16:50:49 --> Language Class Initialized
INFO - 2020-10-09 16:50:49 --> Loader Class Initialized
INFO - 2020-10-09 16:50:49 --> Helper loaded: url_helper
INFO - 2020-10-09 16:50:49 --> Database Driver Class Initialized
INFO - 2020-10-09 16:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:50:49 --> Email Class Initialized
INFO - 2020-10-09 16:50:49 --> Controller Class Initialized
DEBUG - 2020-10-09 16:50:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:50:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:50:49 --> Model Class Initialized
INFO - 2020-10-09 16:50:49 --> Model Class Initialized
INFO - 2020-10-09 16:50:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:50:49 --> Final output sent to browser
DEBUG - 2020-10-09 16:50:49 --> Total execution time: 0.0204
ERROR - 2020-10-09 16:54:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:54:48 --> Config Class Initialized
INFO - 2020-10-09 16:54:48 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:54:48 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:54:48 --> Utf8 Class Initialized
INFO - 2020-10-09 16:54:48 --> URI Class Initialized
INFO - 2020-10-09 16:54:48 --> Router Class Initialized
INFO - 2020-10-09 16:54:48 --> Output Class Initialized
INFO - 2020-10-09 16:54:48 --> Security Class Initialized
DEBUG - 2020-10-09 16:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:54:48 --> Input Class Initialized
INFO - 2020-10-09 16:54:48 --> Language Class Initialized
INFO - 2020-10-09 16:54:48 --> Loader Class Initialized
INFO - 2020-10-09 16:54:48 --> Helper loaded: url_helper
INFO - 2020-10-09 16:54:48 --> Database Driver Class Initialized
INFO - 2020-10-09 16:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:54:48 --> Email Class Initialized
INFO - 2020-10-09 16:54:48 --> Controller Class Initialized
DEBUG - 2020-10-09 16:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:54:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:54:48 --> Model Class Initialized
INFO - 2020-10-09 16:54:48 --> Model Class Initialized
INFO - 2020-10-09 16:54:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:54:48 --> Final output sent to browser
DEBUG - 2020-10-09 16:54:48 --> Total execution time: 0.0217
ERROR - 2020-10-09 16:54:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:54:57 --> Config Class Initialized
INFO - 2020-10-09 16:54:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:54:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:54:57 --> Utf8 Class Initialized
INFO - 2020-10-09 16:54:57 --> URI Class Initialized
INFO - 2020-10-09 16:54:57 --> Router Class Initialized
INFO - 2020-10-09 16:54:57 --> Output Class Initialized
INFO - 2020-10-09 16:54:57 --> Security Class Initialized
DEBUG - 2020-10-09 16:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:54:57 --> Input Class Initialized
INFO - 2020-10-09 16:54:57 --> Language Class Initialized
INFO - 2020-10-09 16:54:57 --> Loader Class Initialized
INFO - 2020-10-09 16:54:57 --> Helper loaded: url_helper
INFO - 2020-10-09 16:54:57 --> Database Driver Class Initialized
INFO - 2020-10-09 16:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:54:57 --> Email Class Initialized
INFO - 2020-10-09 16:54:57 --> Controller Class Initialized
DEBUG - 2020-10-09 16:54:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:54:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:54:57 --> Model Class Initialized
INFO - 2020-10-09 16:54:57 --> Model Class Initialized
INFO - 2020-10-09 16:54:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:54:57 --> Final output sent to browser
DEBUG - 2020-10-09 16:54:57 --> Total execution time: 0.0249
ERROR - 2020-10-09 16:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:57:47 --> Config Class Initialized
INFO - 2020-10-09 16:57:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:57:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:57:47 --> Utf8 Class Initialized
INFO - 2020-10-09 16:57:47 --> URI Class Initialized
INFO - 2020-10-09 16:57:47 --> Router Class Initialized
INFO - 2020-10-09 16:57:47 --> Output Class Initialized
INFO - 2020-10-09 16:57:47 --> Security Class Initialized
DEBUG - 2020-10-09 16:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:57:47 --> Input Class Initialized
INFO - 2020-10-09 16:57:47 --> Language Class Initialized
INFO - 2020-10-09 16:57:47 --> Loader Class Initialized
INFO - 2020-10-09 16:57:47 --> Helper loaded: url_helper
INFO - 2020-10-09 16:57:47 --> Database Driver Class Initialized
INFO - 2020-10-09 16:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:57:47 --> Email Class Initialized
INFO - 2020-10-09 16:57:47 --> Controller Class Initialized
DEBUG - 2020-10-09 16:57:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:57:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:57:47 --> Model Class Initialized
INFO - 2020-10-09 16:57:47 --> Model Class Initialized
INFO - 2020-10-09 16:57:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:57:47 --> Final output sent to browser
DEBUG - 2020-10-09 16:57:47 --> Total execution time: 0.0270
ERROR - 2020-10-09 16:57:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:57:52 --> Config Class Initialized
INFO - 2020-10-09 16:57:52 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:57:52 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:57:52 --> Utf8 Class Initialized
INFO - 2020-10-09 16:57:52 --> URI Class Initialized
INFO - 2020-10-09 16:57:52 --> Router Class Initialized
INFO - 2020-10-09 16:57:52 --> Output Class Initialized
INFO - 2020-10-09 16:57:52 --> Security Class Initialized
DEBUG - 2020-10-09 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:57:52 --> Input Class Initialized
INFO - 2020-10-09 16:57:52 --> Language Class Initialized
INFO - 2020-10-09 16:57:52 --> Loader Class Initialized
INFO - 2020-10-09 16:57:52 --> Helper loaded: url_helper
INFO - 2020-10-09 16:57:52 --> Database Driver Class Initialized
INFO - 2020-10-09 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:57:52 --> Email Class Initialized
INFO - 2020-10-09 16:57:52 --> Controller Class Initialized
DEBUG - 2020-10-09 16:57:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:57:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:57:52 --> Model Class Initialized
INFO - 2020-10-09 16:57:52 --> Model Class Initialized
INFO - 2020-10-09 16:57:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:57:52 --> Final output sent to browser
DEBUG - 2020-10-09 16:57:52 --> Total execution time: 0.0219
ERROR - 2020-10-09 16:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:58:00 --> Config Class Initialized
INFO - 2020-10-09 16:58:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:58:00 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:58:00 --> Utf8 Class Initialized
INFO - 2020-10-09 16:58:00 --> URI Class Initialized
INFO - 2020-10-09 16:58:00 --> Router Class Initialized
INFO - 2020-10-09 16:58:00 --> Output Class Initialized
INFO - 2020-10-09 16:58:00 --> Security Class Initialized
DEBUG - 2020-10-09 16:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:58:00 --> Input Class Initialized
INFO - 2020-10-09 16:58:00 --> Language Class Initialized
INFO - 2020-10-09 16:58:00 --> Loader Class Initialized
INFO - 2020-10-09 16:58:00 --> Helper loaded: url_helper
INFO - 2020-10-09 16:58:00 --> Database Driver Class Initialized
INFO - 2020-10-09 16:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:58:00 --> Email Class Initialized
INFO - 2020-10-09 16:58:00 --> Controller Class Initialized
DEBUG - 2020-10-09 16:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:58:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:58:00 --> Model Class Initialized
INFO - 2020-10-09 16:58:00 --> Model Class Initialized
INFO - 2020-10-09 16:58:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:58:00 --> Final output sent to browser
DEBUG - 2020-10-09 16:58:00 --> Total execution time: 0.0256
ERROR - 2020-10-09 16:58:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:58:24 --> Config Class Initialized
INFO - 2020-10-09 16:58:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:58:24 --> Utf8 Class Initialized
INFO - 2020-10-09 16:58:24 --> URI Class Initialized
INFO - 2020-10-09 16:58:24 --> Router Class Initialized
INFO - 2020-10-09 16:58:24 --> Output Class Initialized
INFO - 2020-10-09 16:58:24 --> Security Class Initialized
DEBUG - 2020-10-09 16:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:58:24 --> Input Class Initialized
INFO - 2020-10-09 16:58:24 --> Language Class Initialized
INFO - 2020-10-09 16:58:24 --> Loader Class Initialized
INFO - 2020-10-09 16:58:24 --> Helper loaded: url_helper
INFO - 2020-10-09 16:58:24 --> Database Driver Class Initialized
INFO - 2020-10-09 16:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:58:24 --> Email Class Initialized
INFO - 2020-10-09 16:58:24 --> Controller Class Initialized
DEBUG - 2020-10-09 16:58:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:58:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:58:24 --> Model Class Initialized
INFO - 2020-10-09 16:58:24 --> Model Class Initialized
INFO - 2020-10-09 16:58:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:58:24 --> Final output sent to browser
DEBUG - 2020-10-09 16:58:24 --> Total execution time: 0.0236
ERROR - 2020-10-09 16:58:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:58:27 --> Config Class Initialized
INFO - 2020-10-09 16:58:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:58:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:58:27 --> Utf8 Class Initialized
INFO - 2020-10-09 16:58:27 --> URI Class Initialized
INFO - 2020-10-09 16:58:27 --> Router Class Initialized
INFO - 2020-10-09 16:58:27 --> Output Class Initialized
INFO - 2020-10-09 16:58:27 --> Security Class Initialized
DEBUG - 2020-10-09 16:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:58:27 --> Input Class Initialized
INFO - 2020-10-09 16:58:27 --> Language Class Initialized
INFO - 2020-10-09 16:58:27 --> Loader Class Initialized
INFO - 2020-10-09 16:58:27 --> Helper loaded: url_helper
INFO - 2020-10-09 16:58:27 --> Database Driver Class Initialized
INFO - 2020-10-09 16:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:58:27 --> Email Class Initialized
INFO - 2020-10-09 16:58:27 --> Controller Class Initialized
DEBUG - 2020-10-09 16:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:58:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:58:27 --> Model Class Initialized
INFO - 2020-10-09 16:58:27 --> Model Class Initialized
INFO - 2020-10-09 16:58:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:58:27 --> Final output sent to browser
DEBUG - 2020-10-09 16:58:27 --> Total execution time: 0.0227
ERROR - 2020-10-09 16:58:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:58:48 --> Config Class Initialized
INFO - 2020-10-09 16:58:48 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:58:48 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:58:48 --> Utf8 Class Initialized
INFO - 2020-10-09 16:58:48 --> URI Class Initialized
INFO - 2020-10-09 16:58:48 --> Router Class Initialized
INFO - 2020-10-09 16:58:48 --> Output Class Initialized
INFO - 2020-10-09 16:58:48 --> Security Class Initialized
DEBUG - 2020-10-09 16:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:58:48 --> Input Class Initialized
INFO - 2020-10-09 16:58:48 --> Language Class Initialized
INFO - 2020-10-09 16:58:48 --> Loader Class Initialized
INFO - 2020-10-09 16:58:48 --> Helper loaded: url_helper
INFO - 2020-10-09 16:58:48 --> Database Driver Class Initialized
INFO - 2020-10-09 16:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:58:48 --> Email Class Initialized
INFO - 2020-10-09 16:58:48 --> Controller Class Initialized
DEBUG - 2020-10-09 16:58:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:58:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:58:48 --> Model Class Initialized
INFO - 2020-10-09 16:58:48 --> Model Class Initialized
INFO - 2020-10-09 16:58:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:58:48 --> Final output sent to browser
DEBUG - 2020-10-09 16:58:48 --> Total execution time: 0.0210
ERROR - 2020-10-09 16:59:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:02 --> Config Class Initialized
INFO - 2020-10-09 16:59:02 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:02 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:02 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:02 --> URI Class Initialized
INFO - 2020-10-09 16:59:02 --> Router Class Initialized
INFO - 2020-10-09 16:59:02 --> Output Class Initialized
INFO - 2020-10-09 16:59:02 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:02 --> Input Class Initialized
INFO - 2020-10-09 16:59:02 --> Language Class Initialized
INFO - 2020-10-09 16:59:02 --> Loader Class Initialized
INFO - 2020-10-09 16:59:02 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:02 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:02 --> Email Class Initialized
INFO - 2020-10-09 16:59:02 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:02 --> Model Class Initialized
INFO - 2020-10-09 16:59:02 --> Model Class Initialized
INFO - 2020-10-09 16:59:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:59:02 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:02 --> Total execution time: 0.0244
ERROR - 2020-10-09 16:59:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:10 --> Config Class Initialized
INFO - 2020-10-09 16:59:10 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:10 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:10 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:10 --> URI Class Initialized
INFO - 2020-10-09 16:59:10 --> Router Class Initialized
INFO - 2020-10-09 16:59:10 --> Output Class Initialized
INFO - 2020-10-09 16:59:10 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:10 --> Input Class Initialized
INFO - 2020-10-09 16:59:10 --> Language Class Initialized
INFO - 2020-10-09 16:59:10 --> Loader Class Initialized
INFO - 2020-10-09 16:59:10 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:10 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:10 --> Email Class Initialized
INFO - 2020-10-09 16:59:10 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:10 --> Model Class Initialized
INFO - 2020-10-09 16:59:10 --> Model Class Initialized
INFO - 2020-10-09 16:59:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:59:10 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:10 --> Total execution time: 0.0259
ERROR - 2020-10-09 16:59:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:19 --> Config Class Initialized
INFO - 2020-10-09 16:59:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:19 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:19 --> URI Class Initialized
INFO - 2020-10-09 16:59:19 --> Router Class Initialized
INFO - 2020-10-09 16:59:19 --> Output Class Initialized
INFO - 2020-10-09 16:59:19 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:19 --> Input Class Initialized
INFO - 2020-10-09 16:59:19 --> Language Class Initialized
INFO - 2020-10-09 16:59:19 --> Loader Class Initialized
INFO - 2020-10-09 16:59:19 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:19 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:19 --> Email Class Initialized
INFO - 2020-10-09 16:59:19 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:19 --> Model Class Initialized
INFO - 2020-10-09 16:59:19 --> Model Class Initialized
INFO - 2020-10-09 16:59:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 16:59:19 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:19 --> Total execution time: 0.0259
ERROR - 2020-10-09 16:59:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:22 --> Config Class Initialized
INFO - 2020-10-09 16:59:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:22 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:22 --> URI Class Initialized
INFO - 2020-10-09 16:59:22 --> Router Class Initialized
INFO - 2020-10-09 16:59:22 --> Output Class Initialized
INFO - 2020-10-09 16:59:22 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:22 --> Input Class Initialized
INFO - 2020-10-09 16:59:22 --> Language Class Initialized
INFO - 2020-10-09 16:59:22 --> Loader Class Initialized
INFO - 2020-10-09 16:59:22 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:22 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:22 --> Email Class Initialized
INFO - 2020-10-09 16:59:22 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:22 --> Model Class Initialized
INFO - 2020-10-09 16:59:22 --> Model Class Initialized
INFO - 2020-10-09 16:59:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 16:59:22 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:22 --> Total execution time: 0.0255
ERROR - 2020-10-09 16:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:25 --> Config Class Initialized
INFO - 2020-10-09 16:59:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:25 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:25 --> URI Class Initialized
INFO - 2020-10-09 16:59:25 --> Router Class Initialized
INFO - 2020-10-09 16:59:25 --> Output Class Initialized
INFO - 2020-10-09 16:59:25 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:25 --> Input Class Initialized
INFO - 2020-10-09 16:59:25 --> Language Class Initialized
INFO - 2020-10-09 16:59:25 --> Loader Class Initialized
INFO - 2020-10-09 16:59:25 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:25 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:25 --> Email Class Initialized
INFO - 2020-10-09 16:59:25 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:25 --> Model Class Initialized
INFO - 2020-10-09 16:59:25 --> Model Class Initialized
INFO - 2020-10-09 16:59:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 16:59:25 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:25 --> Total execution time: 0.0223
ERROR - 2020-10-09 16:59:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:31 --> Config Class Initialized
INFO - 2020-10-09 16:59:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:31 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:31 --> URI Class Initialized
INFO - 2020-10-09 16:59:31 --> Router Class Initialized
INFO - 2020-10-09 16:59:31 --> Output Class Initialized
INFO - 2020-10-09 16:59:31 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:31 --> Input Class Initialized
INFO - 2020-10-09 16:59:31 --> Language Class Initialized
INFO - 2020-10-09 16:59:31 --> Loader Class Initialized
INFO - 2020-10-09 16:59:31 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:31 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:31 --> Email Class Initialized
INFO - 2020-10-09 16:59:31 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:32 --> Model Class Initialized
INFO - 2020-10-09 16:59:32 --> Model Class Initialized
INFO - 2020-10-09 16:59:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 16:59:32 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:32 --> Total execution time: 0.0256
ERROR - 2020-10-09 16:59:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 16:59:55 --> Config Class Initialized
INFO - 2020-10-09 16:59:55 --> Hooks Class Initialized
DEBUG - 2020-10-09 16:59:55 --> UTF-8 Support Enabled
INFO - 2020-10-09 16:59:55 --> Utf8 Class Initialized
INFO - 2020-10-09 16:59:55 --> URI Class Initialized
INFO - 2020-10-09 16:59:55 --> Router Class Initialized
INFO - 2020-10-09 16:59:55 --> Output Class Initialized
INFO - 2020-10-09 16:59:55 --> Security Class Initialized
DEBUG - 2020-10-09 16:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 16:59:55 --> Input Class Initialized
INFO - 2020-10-09 16:59:55 --> Language Class Initialized
INFO - 2020-10-09 16:59:55 --> Loader Class Initialized
INFO - 2020-10-09 16:59:55 --> Helper loaded: url_helper
INFO - 2020-10-09 16:59:55 --> Database Driver Class Initialized
INFO - 2020-10-09 16:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 16:59:55 --> Email Class Initialized
INFO - 2020-10-09 16:59:55 --> Controller Class Initialized
DEBUG - 2020-10-09 16:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 16:59:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 16:59:55 --> Model Class Initialized
INFO - 2020-10-09 16:59:55 --> Model Class Initialized
INFO - 2020-10-09 16:59:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 16:59:55 --> Final output sent to browser
DEBUG - 2020-10-09 16:59:55 --> Total execution time: 0.0239
ERROR - 2020-10-09 17:00:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:01 --> Config Class Initialized
INFO - 2020-10-09 17:00:01 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:01 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:01 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:01 --> URI Class Initialized
INFO - 2020-10-09 17:00:01 --> Router Class Initialized
INFO - 2020-10-09 17:00:01 --> Output Class Initialized
INFO - 2020-10-09 17:00:01 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:01 --> Input Class Initialized
INFO - 2020-10-09 17:00:01 --> Language Class Initialized
INFO - 2020-10-09 17:00:01 --> Loader Class Initialized
INFO - 2020-10-09 17:00:01 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:01 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:01 --> Email Class Initialized
INFO - 2020-10-09 17:00:01 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:01 --> Model Class Initialized
INFO - 2020-10-09 17:00:01 --> Model Class Initialized
INFO - 2020-10-09 17:00:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:00:01 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:01 --> Total execution time: 0.0272
ERROR - 2020-10-09 17:00:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:06 --> Config Class Initialized
INFO - 2020-10-09 17:00:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:06 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:06 --> URI Class Initialized
INFO - 2020-10-09 17:00:06 --> Router Class Initialized
INFO - 2020-10-09 17:00:06 --> Output Class Initialized
INFO - 2020-10-09 17:00:06 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:06 --> Input Class Initialized
INFO - 2020-10-09 17:00:06 --> Language Class Initialized
INFO - 2020-10-09 17:00:06 --> Loader Class Initialized
INFO - 2020-10-09 17:00:06 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:06 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:06 --> Email Class Initialized
INFO - 2020-10-09 17:00:06 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:06 --> Model Class Initialized
INFO - 2020-10-09 17:00:06 --> Model Class Initialized
INFO - 2020-10-09 17:00:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 17:00:06 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:06 --> Total execution time: 0.0257
ERROR - 2020-10-09 17:00:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:09 --> Config Class Initialized
INFO - 2020-10-09 17:00:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:09 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:09 --> URI Class Initialized
INFO - 2020-10-09 17:00:09 --> Router Class Initialized
INFO - 2020-10-09 17:00:09 --> Output Class Initialized
INFO - 2020-10-09 17:00:09 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:09 --> Input Class Initialized
INFO - 2020-10-09 17:00:09 --> Language Class Initialized
INFO - 2020-10-09 17:00:09 --> Loader Class Initialized
INFO - 2020-10-09 17:00:09 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:09 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:09 --> Email Class Initialized
INFO - 2020-10-09 17:00:09 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:09 --> Model Class Initialized
INFO - 2020-10-09 17:00:09 --> Model Class Initialized
INFO - 2020-10-09 17:00:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 17:00:09 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:09 --> Total execution time: 0.0234
ERROR - 2020-10-09 17:00:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:15 --> Config Class Initialized
INFO - 2020-10-09 17:00:15 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:15 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:15 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:15 --> URI Class Initialized
INFO - 2020-10-09 17:00:15 --> Router Class Initialized
INFO - 2020-10-09 17:00:15 --> Output Class Initialized
INFO - 2020-10-09 17:00:15 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:15 --> Input Class Initialized
INFO - 2020-10-09 17:00:15 --> Language Class Initialized
INFO - 2020-10-09 17:00:15 --> Loader Class Initialized
INFO - 2020-10-09 17:00:15 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:15 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:15 --> Email Class Initialized
INFO - 2020-10-09 17:00:15 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:15 --> Model Class Initialized
INFO - 2020-10-09 17:00:15 --> Model Class Initialized
INFO - 2020-10-09 17:00:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:00:15 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:15 --> Total execution time: 0.0214
ERROR - 2020-10-09 17:00:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:18 --> Config Class Initialized
INFO - 2020-10-09 17:00:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:18 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:18 --> URI Class Initialized
INFO - 2020-10-09 17:00:18 --> Router Class Initialized
INFO - 2020-10-09 17:00:18 --> Output Class Initialized
INFO - 2020-10-09 17:00:18 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:18 --> Input Class Initialized
INFO - 2020-10-09 17:00:18 --> Language Class Initialized
INFO - 2020-10-09 17:00:18 --> Loader Class Initialized
INFO - 2020-10-09 17:00:18 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:18 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:18 --> Email Class Initialized
INFO - 2020-10-09 17:00:18 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:18 --> Model Class Initialized
INFO - 2020-10-09 17:00:18 --> Model Class Initialized
INFO - 2020-10-09 17:00:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 17:00:18 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:18 --> Total execution time: 0.0249
ERROR - 2020-10-09 17:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:20 --> Config Class Initialized
INFO - 2020-10-09 17:00:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:20 --> URI Class Initialized
INFO - 2020-10-09 17:00:20 --> Router Class Initialized
INFO - 2020-10-09 17:00:20 --> Output Class Initialized
INFO - 2020-10-09 17:00:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:20 --> Input Class Initialized
INFO - 2020-10-09 17:00:20 --> Language Class Initialized
INFO - 2020-10-09 17:00:20 --> Loader Class Initialized
INFO - 2020-10-09 17:00:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:20 --> Email Class Initialized
INFO - 2020-10-09 17:00:20 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:20 --> Model Class Initialized
INFO - 2020-10-09 17:00:20 --> Model Class Initialized
INFO - 2020-10-09 17:00:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 17:00:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:20 --> Total execution time: 0.0227
ERROR - 2020-10-09 17:00:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:24 --> Config Class Initialized
INFO - 2020-10-09 17:00:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:24 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:24 --> URI Class Initialized
INFO - 2020-10-09 17:00:24 --> Router Class Initialized
INFO - 2020-10-09 17:00:24 --> Output Class Initialized
INFO - 2020-10-09 17:00:24 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:24 --> Input Class Initialized
INFO - 2020-10-09 17:00:24 --> Language Class Initialized
INFO - 2020-10-09 17:00:24 --> Loader Class Initialized
INFO - 2020-10-09 17:00:24 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:24 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:24 --> Email Class Initialized
INFO - 2020-10-09 17:00:24 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:24 --> Model Class Initialized
INFO - 2020-10-09 17:00:24 --> Model Class Initialized
INFO - 2020-10-09 17:00:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:00:24 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:24 --> Total execution time: 0.0259
ERROR - 2020-10-09 17:00:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:00:51 --> Config Class Initialized
INFO - 2020-10-09 17:00:51 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:00:51 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:00:51 --> Utf8 Class Initialized
INFO - 2020-10-09 17:00:51 --> URI Class Initialized
INFO - 2020-10-09 17:00:51 --> Router Class Initialized
INFO - 2020-10-09 17:00:51 --> Output Class Initialized
INFO - 2020-10-09 17:00:51 --> Security Class Initialized
DEBUG - 2020-10-09 17:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:00:51 --> Input Class Initialized
INFO - 2020-10-09 17:00:51 --> Language Class Initialized
INFO - 2020-10-09 17:00:51 --> Loader Class Initialized
INFO - 2020-10-09 17:00:51 --> Helper loaded: url_helper
INFO - 2020-10-09 17:00:51 --> Database Driver Class Initialized
INFO - 2020-10-09 17:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:00:51 --> Email Class Initialized
INFO - 2020-10-09 17:00:51 --> Controller Class Initialized
DEBUG - 2020-10-09 17:00:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:00:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:00:51 --> Model Class Initialized
INFO - 2020-10-09 17:00:51 --> Model Class Initialized
INFO - 2020-10-09 17:00:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:00:51 --> Final output sent to browser
DEBUG - 2020-10-09 17:00:51 --> Total execution time: 0.0191
ERROR - 2020-10-09 17:07:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:00 --> Config Class Initialized
INFO - 2020-10-09 17:07:00 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:00 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:00 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:00 --> URI Class Initialized
INFO - 2020-10-09 17:07:00 --> Router Class Initialized
INFO - 2020-10-09 17:07:00 --> Output Class Initialized
INFO - 2020-10-09 17:07:00 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:00 --> Input Class Initialized
INFO - 2020-10-09 17:07:00 --> Language Class Initialized
INFO - 2020-10-09 17:07:00 --> Loader Class Initialized
INFO - 2020-10-09 17:07:00 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:00 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:00 --> Email Class Initialized
INFO - 2020-10-09 17:07:00 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:00 --> Model Class Initialized
INFO - 2020-10-09 17:07:00 --> Model Class Initialized
INFO - 2020-10-09 17:07:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:07:00 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:00 --> Total execution time: 0.0266
ERROR - 2020-10-09 17:07:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:07 --> Config Class Initialized
INFO - 2020-10-09 17:07:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:07 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:07 --> URI Class Initialized
INFO - 2020-10-09 17:07:07 --> Router Class Initialized
INFO - 2020-10-09 17:07:07 --> Output Class Initialized
INFO - 2020-10-09 17:07:07 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:07 --> Input Class Initialized
INFO - 2020-10-09 17:07:07 --> Language Class Initialized
INFO - 2020-10-09 17:07:07 --> Loader Class Initialized
INFO - 2020-10-09 17:07:07 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:07 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:07 --> Email Class Initialized
INFO - 2020-10-09 17:07:07 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:07 --> Model Class Initialized
INFO - 2020-10-09 17:07:07 --> Model Class Initialized
INFO - 2020-10-09 17:07:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 17:07:07 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:07 --> Total execution time: 0.0250
ERROR - 2020-10-09 17:07:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:14 --> Config Class Initialized
INFO - 2020-10-09 17:07:14 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:14 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:14 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:14 --> URI Class Initialized
INFO - 2020-10-09 17:07:14 --> Router Class Initialized
INFO - 2020-10-09 17:07:14 --> Output Class Initialized
INFO - 2020-10-09 17:07:14 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:14 --> Input Class Initialized
INFO - 2020-10-09 17:07:14 --> Language Class Initialized
INFO - 2020-10-09 17:07:14 --> Loader Class Initialized
INFO - 2020-10-09 17:07:14 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:14 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:14 --> Email Class Initialized
INFO - 2020-10-09 17:07:14 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:14 --> Model Class Initialized
INFO - 2020-10-09 17:07:14 --> Model Class Initialized
INFO - 2020-10-09 17:07:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:07:14 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:14 --> Total execution time: 0.0291
ERROR - 2020-10-09 17:07:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:27 --> Config Class Initialized
INFO - 2020-10-09 17:07:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:27 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:27 --> URI Class Initialized
INFO - 2020-10-09 17:07:27 --> Router Class Initialized
INFO - 2020-10-09 17:07:27 --> Output Class Initialized
INFO - 2020-10-09 17:07:27 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:27 --> Input Class Initialized
INFO - 2020-10-09 17:07:27 --> Language Class Initialized
INFO - 2020-10-09 17:07:27 --> Loader Class Initialized
INFO - 2020-10-09 17:07:27 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:27 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:27 --> Email Class Initialized
INFO - 2020-10-09 17:07:27 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:27 --> Model Class Initialized
INFO - 2020-10-09 17:07:27 --> Model Class Initialized
INFO - 2020-10-09 17:07:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:07:27 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:27 --> Total execution time: 0.0230
ERROR - 2020-10-09 17:07:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:31 --> Config Class Initialized
INFO - 2020-10-09 17:07:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:31 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:31 --> URI Class Initialized
INFO - 2020-10-09 17:07:31 --> Router Class Initialized
INFO - 2020-10-09 17:07:31 --> Output Class Initialized
INFO - 2020-10-09 17:07:31 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:31 --> Input Class Initialized
INFO - 2020-10-09 17:07:31 --> Language Class Initialized
INFO - 2020-10-09 17:07:31 --> Loader Class Initialized
INFO - 2020-10-09 17:07:31 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:31 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:31 --> Email Class Initialized
INFO - 2020-10-09 17:07:31 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:31 --> Model Class Initialized
INFO - 2020-10-09 17:07:31 --> Model Class Initialized
INFO - 2020-10-09 17:07:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 17:07:31 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:31 --> Total execution time: 0.0435
ERROR - 2020-10-09 17:07:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:35 --> Config Class Initialized
INFO - 2020-10-09 17:07:35 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:35 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:35 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:35 --> URI Class Initialized
INFO - 2020-10-09 17:07:35 --> Router Class Initialized
INFO - 2020-10-09 17:07:35 --> Output Class Initialized
INFO - 2020-10-09 17:07:35 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:35 --> Input Class Initialized
INFO - 2020-10-09 17:07:35 --> Language Class Initialized
INFO - 2020-10-09 17:07:35 --> Loader Class Initialized
INFO - 2020-10-09 17:07:35 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:35 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:35 --> Email Class Initialized
INFO - 2020-10-09 17:07:35 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:35 --> Model Class Initialized
INFO - 2020-10-09 17:07:35 --> Model Class Initialized
INFO - 2020-10-09 17:07:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 17:07:35 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:35 --> Total execution time: 0.0295
ERROR - 2020-10-09 17:07:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:07:38 --> Config Class Initialized
INFO - 2020-10-09 17:07:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:07:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:07:38 --> Utf8 Class Initialized
INFO - 2020-10-09 17:07:38 --> URI Class Initialized
INFO - 2020-10-09 17:07:38 --> Router Class Initialized
INFO - 2020-10-09 17:07:38 --> Output Class Initialized
INFO - 2020-10-09 17:07:38 --> Security Class Initialized
DEBUG - 2020-10-09 17:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:07:38 --> Input Class Initialized
INFO - 2020-10-09 17:07:38 --> Language Class Initialized
INFO - 2020-10-09 17:07:38 --> Loader Class Initialized
INFO - 2020-10-09 17:07:38 --> Helper loaded: url_helper
INFO - 2020-10-09 17:07:38 --> Database Driver Class Initialized
INFO - 2020-10-09 17:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:07:38 --> Email Class Initialized
INFO - 2020-10-09 17:07:38 --> Controller Class Initialized
DEBUG - 2020-10-09 17:07:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:07:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:07:38 --> Model Class Initialized
INFO - 2020-10-09 17:07:38 --> Model Class Initialized
INFO - 2020-10-09 17:07:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:07:38 --> Final output sent to browser
DEBUG - 2020-10-09 17:07:38 --> Total execution time: 0.0246
ERROR - 2020-10-09 17:09:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:09:05 --> Config Class Initialized
INFO - 2020-10-09 17:09:05 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:09:05 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:09:05 --> Utf8 Class Initialized
INFO - 2020-10-09 17:09:05 --> URI Class Initialized
INFO - 2020-10-09 17:09:05 --> Router Class Initialized
INFO - 2020-10-09 17:09:05 --> Output Class Initialized
INFO - 2020-10-09 17:09:05 --> Security Class Initialized
DEBUG - 2020-10-09 17:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:09:05 --> Input Class Initialized
INFO - 2020-10-09 17:09:05 --> Language Class Initialized
INFO - 2020-10-09 17:09:05 --> Loader Class Initialized
INFO - 2020-10-09 17:09:05 --> Helper loaded: url_helper
INFO - 2020-10-09 17:09:05 --> Database Driver Class Initialized
INFO - 2020-10-09 17:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:09:05 --> Email Class Initialized
INFO - 2020-10-09 17:09:05 --> Controller Class Initialized
DEBUG - 2020-10-09 17:09:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:09:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:09:05 --> Model Class Initialized
INFO - 2020-10-09 17:09:05 --> Model Class Initialized
INFO - 2020-10-09 17:09:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:09:05 --> Final output sent to browser
DEBUG - 2020-10-09 17:09:05 --> Total execution time: 0.0232
ERROR - 2020-10-09 17:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:09:08 --> Config Class Initialized
INFO - 2020-10-09 17:09:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:09:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:09:08 --> Utf8 Class Initialized
INFO - 2020-10-09 17:09:08 --> URI Class Initialized
INFO - 2020-10-09 17:09:08 --> Router Class Initialized
INFO - 2020-10-09 17:09:08 --> Output Class Initialized
INFO - 2020-10-09 17:09:08 --> Security Class Initialized
DEBUG - 2020-10-09 17:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:09:08 --> Input Class Initialized
INFO - 2020-10-09 17:09:08 --> Language Class Initialized
INFO - 2020-10-09 17:09:08 --> Loader Class Initialized
INFO - 2020-10-09 17:09:08 --> Helper loaded: url_helper
INFO - 2020-10-09 17:09:08 --> Database Driver Class Initialized
INFO - 2020-10-09 17:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:09:08 --> Email Class Initialized
INFO - 2020-10-09 17:09:08 --> Controller Class Initialized
DEBUG - 2020-10-09 17:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:09:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:09:08 --> Model Class Initialized
INFO - 2020-10-09 17:09:08 --> Model Class Initialized
INFO - 2020-10-09 17:09:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 17:09:08 --> Final output sent to browser
DEBUG - 2020-10-09 17:09:08 --> Total execution time: 0.0231
ERROR - 2020-10-09 17:09:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:09:57 --> Config Class Initialized
INFO - 2020-10-09 17:09:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:09:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:09:57 --> Utf8 Class Initialized
INFO - 2020-10-09 17:09:57 --> URI Class Initialized
INFO - 2020-10-09 17:09:57 --> Router Class Initialized
INFO - 2020-10-09 17:09:57 --> Output Class Initialized
INFO - 2020-10-09 17:09:57 --> Security Class Initialized
DEBUG - 2020-10-09 17:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:09:57 --> Input Class Initialized
INFO - 2020-10-09 17:09:57 --> Language Class Initialized
INFO - 2020-10-09 17:09:57 --> Loader Class Initialized
INFO - 2020-10-09 17:09:57 --> Helper loaded: url_helper
INFO - 2020-10-09 17:09:57 --> Database Driver Class Initialized
INFO - 2020-10-09 17:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:09:57 --> Email Class Initialized
INFO - 2020-10-09 17:09:57 --> Controller Class Initialized
DEBUG - 2020-10-09 17:09:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:09:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:09:57 --> Model Class Initialized
INFO - 2020-10-09 17:09:57 --> Model Class Initialized
INFO - 2020-10-09 17:09:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 17:09:57 --> Final output sent to browser
DEBUG - 2020-10-09 17:09:57 --> Total execution time: 0.0245
ERROR - 2020-10-09 17:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:09:59 --> Config Class Initialized
INFO - 2020-10-09 17:09:59 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:09:59 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:09:59 --> Utf8 Class Initialized
INFO - 2020-10-09 17:09:59 --> URI Class Initialized
INFO - 2020-10-09 17:09:59 --> Router Class Initialized
INFO - 2020-10-09 17:09:59 --> Output Class Initialized
INFO - 2020-10-09 17:09:59 --> Security Class Initialized
DEBUG - 2020-10-09 17:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:09:59 --> Input Class Initialized
INFO - 2020-10-09 17:09:59 --> Language Class Initialized
INFO - 2020-10-09 17:09:59 --> Loader Class Initialized
INFO - 2020-10-09 17:09:59 --> Helper loaded: url_helper
INFO - 2020-10-09 17:09:59 --> Database Driver Class Initialized
INFO - 2020-10-09 17:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:09:59 --> Email Class Initialized
INFO - 2020-10-09 17:09:59 --> Controller Class Initialized
DEBUG - 2020-10-09 17:09:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:09:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:09:59 --> Model Class Initialized
INFO - 2020-10-09 17:09:59 --> Model Class Initialized
INFO - 2020-10-09 17:09:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:09:59 --> Final output sent to browser
DEBUG - 2020-10-09 17:09:59 --> Total execution time: 0.0231
ERROR - 2020-10-09 17:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:10:05 --> Config Class Initialized
INFO - 2020-10-09 17:10:05 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:10:05 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:10:05 --> Utf8 Class Initialized
INFO - 2020-10-09 17:10:05 --> URI Class Initialized
INFO - 2020-10-09 17:10:05 --> Router Class Initialized
INFO - 2020-10-09 17:10:05 --> Output Class Initialized
INFO - 2020-10-09 17:10:05 --> Security Class Initialized
DEBUG - 2020-10-09 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:10:05 --> Input Class Initialized
INFO - 2020-10-09 17:10:05 --> Language Class Initialized
INFO - 2020-10-09 17:10:05 --> Loader Class Initialized
INFO - 2020-10-09 17:10:05 --> Helper loaded: url_helper
INFO - 2020-10-09 17:10:05 --> Database Driver Class Initialized
INFO - 2020-10-09 17:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:10:05 --> Email Class Initialized
INFO - 2020-10-09 17:10:05 --> Controller Class Initialized
DEBUG - 2020-10-09 17:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:10:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:10:05 --> Model Class Initialized
INFO - 2020-10-09 17:10:05 --> Model Class Initialized
INFO - 2020-10-09 17:10:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise2.php
INFO - 2020-10-09 17:10:05 --> Final output sent to browser
DEBUG - 2020-10-09 17:10:05 --> Total execution time: 0.0262
ERROR - 2020-10-09 17:10:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:10:08 --> Config Class Initialized
INFO - 2020-10-09 17:10:08 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:10:08 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:10:08 --> Utf8 Class Initialized
INFO - 2020-10-09 17:10:08 --> URI Class Initialized
INFO - 2020-10-09 17:10:08 --> Router Class Initialized
INFO - 2020-10-09 17:10:08 --> Output Class Initialized
INFO - 2020-10-09 17:10:08 --> Security Class Initialized
DEBUG - 2020-10-09 17:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:10:08 --> Input Class Initialized
INFO - 2020-10-09 17:10:08 --> Language Class Initialized
INFO - 2020-10-09 17:10:08 --> Loader Class Initialized
INFO - 2020-10-09 17:10:08 --> Helper loaded: url_helper
INFO - 2020-10-09 17:10:08 --> Database Driver Class Initialized
INFO - 2020-10-09 17:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:10:08 --> Email Class Initialized
INFO - 2020-10-09 17:10:08 --> Controller Class Initialized
DEBUG - 2020-10-09 17:10:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:10:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:10:08 --> Model Class Initialized
INFO - 2020-10-09 17:10:08 --> Model Class Initialized
INFO - 2020-10-09 17:10:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit2.php
INFO - 2020-10-09 17:10:08 --> Final output sent to browser
DEBUG - 2020-10-09 17:10:08 --> Total execution time: 0.0238
ERROR - 2020-10-09 17:10:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:10:15 --> Config Class Initialized
INFO - 2020-10-09 17:10:15 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:10:15 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:10:15 --> Utf8 Class Initialized
INFO - 2020-10-09 17:10:15 --> URI Class Initialized
INFO - 2020-10-09 17:10:15 --> Router Class Initialized
INFO - 2020-10-09 17:10:15 --> Output Class Initialized
INFO - 2020-10-09 17:10:15 --> Security Class Initialized
DEBUG - 2020-10-09 17:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:10:15 --> Input Class Initialized
INFO - 2020-10-09 17:10:15 --> Language Class Initialized
INFO - 2020-10-09 17:10:15 --> Loader Class Initialized
INFO - 2020-10-09 17:10:15 --> Helper loaded: url_helper
INFO - 2020-10-09 17:10:15 --> Database Driver Class Initialized
INFO - 2020-10-09 17:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:10:15 --> Email Class Initialized
INFO - 2020-10-09 17:10:15 --> Controller Class Initialized
DEBUG - 2020-10-09 17:10:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:10:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:10:15 --> Model Class Initialized
INFO - 2020-10-09 17:10:15 --> Model Class Initialized
INFO - 2020-10-09 17:10:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:10:15 --> Final output sent to browser
DEBUG - 2020-10-09 17:10:15 --> Total execution time: 0.0264
ERROR - 2020-10-09 17:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:10:20 --> Config Class Initialized
INFO - 2020-10-09 17:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:10:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:10:20 --> URI Class Initialized
INFO - 2020-10-09 17:10:20 --> Router Class Initialized
INFO - 2020-10-09 17:10:20 --> Output Class Initialized
INFO - 2020-10-09 17:10:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:10:20 --> Input Class Initialized
INFO - 2020-10-09 17:10:20 --> Language Class Initialized
INFO - 2020-10-09 17:10:20 --> Loader Class Initialized
INFO - 2020-10-09 17:10:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:10:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:10:20 --> Email Class Initialized
INFO - 2020-10-09 17:10:20 --> Controller Class Initialized
DEBUG - 2020-10-09 17:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:10:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:10:20 --> Model Class Initialized
INFO - 2020-10-09 17:10:20 --> Model Class Initialized
INFO - 2020-10-09 17:10:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:10:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:10:20 --> Total execution time: 0.0234
ERROR - 2020-10-09 17:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:10:27 --> Config Class Initialized
INFO - 2020-10-09 17:10:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:10:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:10:27 --> Utf8 Class Initialized
INFO - 2020-10-09 17:10:27 --> URI Class Initialized
INFO - 2020-10-09 17:10:27 --> Router Class Initialized
INFO - 2020-10-09 17:10:27 --> Output Class Initialized
INFO - 2020-10-09 17:10:27 --> Security Class Initialized
DEBUG - 2020-10-09 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:10:27 --> Input Class Initialized
INFO - 2020-10-09 17:10:27 --> Language Class Initialized
INFO - 2020-10-09 17:10:27 --> Loader Class Initialized
INFO - 2020-10-09 17:10:27 --> Helper loaded: url_helper
INFO - 2020-10-09 17:10:27 --> Database Driver Class Initialized
INFO - 2020-10-09 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:10:27 --> Email Class Initialized
INFO - 2020-10-09 17:10:27 --> Controller Class Initialized
DEBUG - 2020-10-09 17:10:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:10:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:10:27 --> Model Class Initialized
INFO - 2020-10-09 17:10:27 --> Model Class Initialized
INFO - 2020-10-09 17:10:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-09 17:10:27 --> Final output sent to browser
DEBUG - 2020-10-09 17:10:27 --> Total execution time: 0.0245
ERROR - 2020-10-09 17:10:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:10:32 --> Config Class Initialized
INFO - 2020-10-09 17:10:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:10:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:10:32 --> Utf8 Class Initialized
INFO - 2020-10-09 17:10:32 --> URI Class Initialized
INFO - 2020-10-09 17:10:32 --> Router Class Initialized
INFO - 2020-10-09 17:10:32 --> Output Class Initialized
INFO - 2020-10-09 17:10:32 --> Security Class Initialized
DEBUG - 2020-10-09 17:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:10:32 --> Input Class Initialized
INFO - 2020-10-09 17:10:32 --> Language Class Initialized
INFO - 2020-10-09 17:10:32 --> Loader Class Initialized
INFO - 2020-10-09 17:10:32 --> Helper loaded: url_helper
INFO - 2020-10-09 17:10:32 --> Database Driver Class Initialized
INFO - 2020-10-09 17:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:10:32 --> Email Class Initialized
INFO - 2020-10-09 17:10:32 --> Controller Class Initialized
DEBUG - 2020-10-09 17:10:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:10:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:10:32 --> Model Class Initialized
INFO - 2020-10-09 17:10:32 --> Model Class Initialized
INFO - 2020-10-09 17:10:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-09 17:10:32 --> Final output sent to browser
DEBUG - 2020-10-09 17:10:32 --> Total execution time: 0.0229
ERROR - 2020-10-09 17:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:09 --> Config Class Initialized
INFO - 2020-10-09 17:11:09 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:09 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:09 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:09 --> URI Class Initialized
INFO - 2020-10-09 17:11:09 --> Router Class Initialized
INFO - 2020-10-09 17:11:09 --> Output Class Initialized
INFO - 2020-10-09 17:11:09 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:09 --> Input Class Initialized
INFO - 2020-10-09 17:11:09 --> Language Class Initialized
INFO - 2020-10-09 17:11:09 --> Loader Class Initialized
INFO - 2020-10-09 17:11:09 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:09 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:09 --> Email Class Initialized
INFO - 2020-10-09 17:11:09 --> Controller Class Initialized
DEBUG - 2020-10-09 17:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:09 --> Model Class Initialized
INFO - 2020-10-09 17:11:09 --> Model Class Initialized
INFO - 2020-10-09 17:11:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-09 17:11:09 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:09 --> Total execution time: 0.0249
ERROR - 2020-10-09 17:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:16 --> Config Class Initialized
INFO - 2020-10-09 17:11:16 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:16 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:16 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:16 --> URI Class Initialized
DEBUG - 2020-10-09 17:11:16 --> No URI present. Default controller set.
INFO - 2020-10-09 17:11:16 --> Router Class Initialized
INFO - 2020-10-09 17:11:16 --> Output Class Initialized
INFO - 2020-10-09 17:11:16 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:16 --> Input Class Initialized
INFO - 2020-10-09 17:11:16 --> Language Class Initialized
INFO - 2020-10-09 17:11:16 --> Loader Class Initialized
INFO - 2020-10-09 17:11:16 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:16 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:16 --> Email Class Initialized
INFO - 2020-10-09 17:11:16 --> Controller Class Initialized
INFO - 2020-10-09 17:11:16 --> Model Class Initialized
INFO - 2020-10-09 17:11:16 --> Model Class Initialized
DEBUG - 2020-10-09 17:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 17:11:16 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:16 --> Total execution time: 0.0183
ERROR - 2020-10-09 17:11:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:20 --> Config Class Initialized
INFO - 2020-10-09 17:11:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:20 --> URI Class Initialized
INFO - 2020-10-09 17:11:20 --> Router Class Initialized
INFO - 2020-10-09 17:11:20 --> Output Class Initialized
INFO - 2020-10-09 17:11:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:20 --> Input Class Initialized
INFO - 2020-10-09 17:11:20 --> Language Class Initialized
INFO - 2020-10-09 17:11:20 --> Loader Class Initialized
INFO - 2020-10-09 17:11:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:20 --> Email Class Initialized
INFO - 2020-10-09 17:11:20 --> Controller Class Initialized
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
DEBUG - 2020-10-09 17:11:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
INFO - 2020-10-09 17:11:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:20 --> Total execution time: 0.0268
ERROR - 2020-10-09 17:11:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:20 --> Config Class Initialized
INFO - 2020-10-09 17:11:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:20 --> URI Class Initialized
INFO - 2020-10-09 17:11:20 --> Router Class Initialized
INFO - 2020-10-09 17:11:20 --> Output Class Initialized
INFO - 2020-10-09 17:11:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:20 --> Input Class Initialized
INFO - 2020-10-09 17:11:20 --> Language Class Initialized
INFO - 2020-10-09 17:11:20 --> Loader Class Initialized
INFO - 2020-10-09 17:11:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:20 --> Email Class Initialized
INFO - 2020-10-09 17:11:20 --> Controller Class Initialized
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
DEBUG - 2020-10-09 17:11:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-09 17:11:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:20 --> Config Class Initialized
INFO - 2020-10-09 17:11:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:20 --> URI Class Initialized
INFO - 2020-10-09 17:11:20 --> Router Class Initialized
INFO - 2020-10-09 17:11:20 --> Output Class Initialized
INFO - 2020-10-09 17:11:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:20 --> Input Class Initialized
INFO - 2020-10-09 17:11:20 --> Language Class Initialized
INFO - 2020-10-09 17:11:20 --> Loader Class Initialized
INFO - 2020-10-09 17:11:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:20 --> Email Class Initialized
INFO - 2020-10-09 17:11:20 --> Controller Class Initialized
DEBUG - 2020-10-09 17:11:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
INFO - 2020-10-09 17:11:20 --> Model Class Initialized
INFO - 2020-10-09 17:11:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-09 17:11:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:20 --> Total execution time: 0.0257
ERROR - 2020-10-09 17:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:27 --> Config Class Initialized
INFO - 2020-10-09 17:11:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:27 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:27 --> URI Class Initialized
INFO - 2020-10-09 17:11:27 --> Router Class Initialized
INFO - 2020-10-09 17:11:27 --> Output Class Initialized
INFO - 2020-10-09 17:11:27 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:27 --> Input Class Initialized
INFO - 2020-10-09 17:11:27 --> Language Class Initialized
INFO - 2020-10-09 17:11:27 --> Loader Class Initialized
INFO - 2020-10-09 17:11:27 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:27 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:27 --> Email Class Initialized
INFO - 2020-10-09 17:11:27 --> Controller Class Initialized
DEBUG - 2020-10-09 17:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:27 --> Model Class Initialized
INFO - 2020-10-09 17:11:27 --> Model Class Initialized
INFO - 2020-10-09 17:11:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-09 17:11:27 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:27 --> Total execution time: 0.0256
ERROR - 2020-10-09 17:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:32 --> Config Class Initialized
INFO - 2020-10-09 17:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:32 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:32 --> URI Class Initialized
INFO - 2020-10-09 17:11:32 --> Router Class Initialized
INFO - 2020-10-09 17:11:32 --> Output Class Initialized
INFO - 2020-10-09 17:11:32 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:32 --> Input Class Initialized
INFO - 2020-10-09 17:11:32 --> Language Class Initialized
INFO - 2020-10-09 17:11:32 --> Loader Class Initialized
INFO - 2020-10-09 17:11:32 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:32 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:32 --> Email Class Initialized
INFO - 2020-10-09 17:11:32 --> Controller Class Initialized
DEBUG - 2020-10-09 17:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:32 --> Model Class Initialized
INFO - 2020-10-09 17:11:32 --> Model Class Initialized
INFO - 2020-10-09 17:11:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-09 17:11:32 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:32 --> Total execution time: 0.0286
ERROR - 2020-10-09 17:11:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:34 --> Config Class Initialized
INFO - 2020-10-09 17:11:34 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:34 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:34 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:34 --> URI Class Initialized
INFO - 2020-10-09 17:11:34 --> Router Class Initialized
INFO - 2020-10-09 17:11:34 --> Output Class Initialized
INFO - 2020-10-09 17:11:34 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:34 --> Input Class Initialized
INFO - 2020-10-09 17:11:34 --> Language Class Initialized
INFO - 2020-10-09 17:11:34 --> Loader Class Initialized
INFO - 2020-10-09 17:11:34 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:34 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:34 --> Email Class Initialized
INFO - 2020-10-09 17:11:34 --> Controller Class Initialized
DEBUG - 2020-10-09 17:11:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:34 --> Model Class Initialized
INFO - 2020-10-09 17:11:34 --> Model Class Initialized
INFO - 2020-10-09 17:11:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 17:11:34 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:34 --> Total execution time: 0.0266
ERROR - 2020-10-09 17:11:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:11:36 --> Config Class Initialized
INFO - 2020-10-09 17:11:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:11:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:11:36 --> Utf8 Class Initialized
INFO - 2020-10-09 17:11:36 --> URI Class Initialized
INFO - 2020-10-09 17:11:36 --> Router Class Initialized
INFO - 2020-10-09 17:11:36 --> Output Class Initialized
INFO - 2020-10-09 17:11:36 --> Security Class Initialized
DEBUG - 2020-10-09 17:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:11:36 --> Input Class Initialized
INFO - 2020-10-09 17:11:36 --> Language Class Initialized
INFO - 2020-10-09 17:11:36 --> Loader Class Initialized
INFO - 2020-10-09 17:11:36 --> Helper loaded: url_helper
INFO - 2020-10-09 17:11:36 --> Database Driver Class Initialized
INFO - 2020-10-09 17:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:11:36 --> Email Class Initialized
INFO - 2020-10-09 17:11:36 --> Controller Class Initialized
DEBUG - 2020-10-09 17:11:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:11:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:11:36 --> Model Class Initialized
INFO - 2020-10-09 17:11:36 --> Model Class Initialized
INFO - 2020-10-09 17:11:36 --> Final output sent to browser
DEBUG - 2020-10-09 17:11:36 --> Total execution time: 0.0224
ERROR - 2020-10-09 17:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:12:05 --> Config Class Initialized
INFO - 2020-10-09 17:12:05 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:12:05 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:12:05 --> Utf8 Class Initialized
INFO - 2020-10-09 17:12:05 --> URI Class Initialized
INFO - 2020-10-09 17:12:05 --> Router Class Initialized
INFO - 2020-10-09 17:12:05 --> Output Class Initialized
INFO - 2020-10-09 17:12:05 --> Security Class Initialized
DEBUG - 2020-10-09 17:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:12:05 --> Input Class Initialized
INFO - 2020-10-09 17:12:05 --> Language Class Initialized
INFO - 2020-10-09 17:12:05 --> Loader Class Initialized
INFO - 2020-10-09 17:12:05 --> Helper loaded: url_helper
INFO - 2020-10-09 17:12:05 --> Database Driver Class Initialized
INFO - 2020-10-09 17:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:12:05 --> Email Class Initialized
INFO - 2020-10-09 17:12:05 --> Controller Class Initialized
DEBUG - 2020-10-09 17:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:12:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:12:05 --> Model Class Initialized
INFO - 2020-10-09 17:12:05 --> Model Class Initialized
INFO - 2020-10-09 17:12:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:12:05 --> Final output sent to browser
DEBUG - 2020-10-09 17:12:05 --> Total execution time: 0.0351
ERROR - 2020-10-09 17:12:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:12:06 --> Config Class Initialized
INFO - 2020-10-09 17:12:06 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:12:06 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:12:06 --> Utf8 Class Initialized
INFO - 2020-10-09 17:12:06 --> URI Class Initialized
INFO - 2020-10-09 17:12:06 --> Router Class Initialized
INFO - 2020-10-09 17:12:06 --> Output Class Initialized
INFO - 2020-10-09 17:12:06 --> Security Class Initialized
DEBUG - 2020-10-09 17:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:12:06 --> Input Class Initialized
INFO - 2020-10-09 17:12:06 --> Language Class Initialized
INFO - 2020-10-09 17:12:06 --> Loader Class Initialized
INFO - 2020-10-09 17:12:06 --> Helper loaded: url_helper
INFO - 2020-10-09 17:12:06 --> Database Driver Class Initialized
INFO - 2020-10-09 17:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:12:06 --> Email Class Initialized
INFO - 2020-10-09 17:12:06 --> Controller Class Initialized
DEBUG - 2020-10-09 17:12:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:12:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:12:06 --> Model Class Initialized
INFO - 2020-10-09 17:12:06 --> Model Class Initialized
INFO - 2020-10-09 17:12:06 --> Final output sent to browser
DEBUG - 2020-10-09 17:12:06 --> Total execution time: 0.0225
ERROR - 2020-10-09 17:12:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:12:10 --> Config Class Initialized
INFO - 2020-10-09 17:12:10 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:12:10 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:12:10 --> Utf8 Class Initialized
INFO - 2020-10-09 17:12:10 --> URI Class Initialized
INFO - 2020-10-09 17:12:10 --> Router Class Initialized
INFO - 2020-10-09 17:12:10 --> Output Class Initialized
INFO - 2020-10-09 17:12:10 --> Security Class Initialized
DEBUG - 2020-10-09 17:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:12:10 --> Input Class Initialized
INFO - 2020-10-09 17:12:10 --> Language Class Initialized
INFO - 2020-10-09 17:12:10 --> Loader Class Initialized
INFO - 2020-10-09 17:12:10 --> Helper loaded: url_helper
INFO - 2020-10-09 17:12:10 --> Database Driver Class Initialized
INFO - 2020-10-09 17:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:12:10 --> Email Class Initialized
INFO - 2020-10-09 17:12:10 --> Controller Class Initialized
DEBUG - 2020-10-09 17:12:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:12:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:12:10 --> Model Class Initialized
INFO - 2020-10-09 17:12:10 --> Model Class Initialized
ERROR - 2020-10-09 17:12:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-09 17:12:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:12:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:12:23 --> Config Class Initialized
INFO - 2020-10-09 17:12:23 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:12:23 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:12:23 --> Utf8 Class Initialized
INFO - 2020-10-09 17:12:23 --> URI Class Initialized
INFO - 2020-10-09 17:12:23 --> Router Class Initialized
INFO - 2020-10-09 17:12:23 --> Output Class Initialized
INFO - 2020-10-09 17:12:23 --> Security Class Initialized
DEBUG - 2020-10-09 17:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:12:23 --> Input Class Initialized
INFO - 2020-10-09 17:12:23 --> Language Class Initialized
INFO - 2020-10-09 17:12:23 --> Loader Class Initialized
INFO - 2020-10-09 17:12:23 --> Helper loaded: url_helper
INFO - 2020-10-09 17:12:23 --> Database Driver Class Initialized
INFO - 2020-10-09 17:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:12:23 --> Email Class Initialized
INFO - 2020-10-09 17:12:23 --> Controller Class Initialized
DEBUG - 2020-10-09 17:12:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:12:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:12:23 --> Model Class Initialized
INFO - 2020-10-09 17:12:23 --> Model Class Initialized
INFO - 2020-10-09 17:12:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:12:23 --> Final output sent to browser
DEBUG - 2020-10-09 17:12:23 --> Total execution time: 0.0236
ERROR - 2020-10-09 17:12:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:12:24 --> Config Class Initialized
INFO - 2020-10-09 17:12:24 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:12:24 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:12:24 --> Utf8 Class Initialized
INFO - 2020-10-09 17:12:24 --> URI Class Initialized
INFO - 2020-10-09 17:12:24 --> Router Class Initialized
INFO - 2020-10-09 17:12:24 --> Output Class Initialized
INFO - 2020-10-09 17:12:24 --> Security Class Initialized
DEBUG - 2020-10-09 17:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:12:24 --> Input Class Initialized
INFO - 2020-10-09 17:12:24 --> Language Class Initialized
INFO - 2020-10-09 17:12:24 --> Loader Class Initialized
INFO - 2020-10-09 17:12:24 --> Helper loaded: url_helper
INFO - 2020-10-09 17:12:24 --> Database Driver Class Initialized
INFO - 2020-10-09 17:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:12:24 --> Email Class Initialized
INFO - 2020-10-09 17:12:24 --> Controller Class Initialized
DEBUG - 2020-10-09 17:12:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:12:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:12:24 --> Model Class Initialized
INFO - 2020-10-09 17:12:24 --> Model Class Initialized
INFO - 2020-10-09 17:12:24 --> Final output sent to browser
DEBUG - 2020-10-09 17:12:24 --> Total execution time: 0.0206
ERROR - 2020-10-09 17:16:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:16:12 --> Config Class Initialized
INFO - 2020-10-09 17:16:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:16:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:16:12 --> Utf8 Class Initialized
INFO - 2020-10-09 17:16:12 --> URI Class Initialized
INFO - 2020-10-09 17:16:12 --> Router Class Initialized
INFO - 2020-10-09 17:16:12 --> Output Class Initialized
INFO - 2020-10-09 17:16:12 --> Security Class Initialized
DEBUG - 2020-10-09 17:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:16:12 --> Input Class Initialized
INFO - 2020-10-09 17:16:12 --> Language Class Initialized
INFO - 2020-10-09 17:16:12 --> Loader Class Initialized
INFO - 2020-10-09 17:16:12 --> Helper loaded: url_helper
INFO - 2020-10-09 17:16:12 --> Database Driver Class Initialized
INFO - 2020-10-09 17:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:16:12 --> Email Class Initialized
INFO - 2020-10-09 17:16:12 --> Controller Class Initialized
DEBUG - 2020-10-09 17:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:16:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:16:12 --> Model Class Initialized
INFO - 2020-10-09 17:16:12 --> Model Class Initialized
INFO - 2020-10-09 17:16:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 17:16:12 --> Final output sent to browser
DEBUG - 2020-10-09 17:16:12 --> Total execution time: 0.0253
ERROR - 2020-10-09 17:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:16:15 --> Config Class Initialized
INFO - 2020-10-09 17:16:15 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:16:15 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:16:15 --> Utf8 Class Initialized
INFO - 2020-10-09 17:16:15 --> URI Class Initialized
INFO - 2020-10-09 17:16:15 --> Router Class Initialized
INFO - 2020-10-09 17:16:15 --> Output Class Initialized
INFO - 2020-10-09 17:16:15 --> Security Class Initialized
DEBUG - 2020-10-09 17:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:16:15 --> Input Class Initialized
INFO - 2020-10-09 17:16:15 --> Language Class Initialized
INFO - 2020-10-09 17:16:15 --> Loader Class Initialized
INFO - 2020-10-09 17:16:15 --> Helper loaded: url_helper
INFO - 2020-10-09 17:16:15 --> Database Driver Class Initialized
INFO - 2020-10-09 17:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:16:15 --> Email Class Initialized
INFO - 2020-10-09 17:16:15 --> Controller Class Initialized
DEBUG - 2020-10-09 17:16:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:16:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:16:15 --> Model Class Initialized
INFO - 2020-10-09 17:16:15 --> Model Class Initialized
INFO - 2020-10-09 17:16:15 --> Final output sent to browser
DEBUG - 2020-10-09 17:16:15 --> Total execution time: 0.0235
ERROR - 2020-10-09 17:21:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:21:11 --> Config Class Initialized
INFO - 2020-10-09 17:21:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:21:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:21:11 --> Utf8 Class Initialized
INFO - 2020-10-09 17:21:11 --> URI Class Initialized
INFO - 2020-10-09 17:21:11 --> Router Class Initialized
INFO - 2020-10-09 17:21:11 --> Output Class Initialized
INFO - 2020-10-09 17:21:11 --> Security Class Initialized
DEBUG - 2020-10-09 17:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:21:11 --> Input Class Initialized
INFO - 2020-10-09 17:21:11 --> Language Class Initialized
INFO - 2020-10-09 17:21:11 --> Loader Class Initialized
INFO - 2020-10-09 17:21:11 --> Helper loaded: url_helper
INFO - 2020-10-09 17:21:11 --> Database Driver Class Initialized
INFO - 2020-10-09 17:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:21:11 --> Email Class Initialized
INFO - 2020-10-09 17:21:11 --> Controller Class Initialized
DEBUG - 2020-10-09 17:21:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:21:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:21:11 --> Model Class Initialized
INFO - 2020-10-09 17:21:11 --> Model Class Initialized
INFO - 2020-10-09 17:21:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:21:11 --> Final output sent to browser
DEBUG - 2020-10-09 17:21:11 --> Total execution time: 0.0244
ERROR - 2020-10-09 17:21:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:21:12 --> Config Class Initialized
INFO - 2020-10-09 17:21:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:21:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:21:12 --> Utf8 Class Initialized
INFO - 2020-10-09 17:21:12 --> URI Class Initialized
INFO - 2020-10-09 17:21:12 --> Router Class Initialized
INFO - 2020-10-09 17:21:12 --> Output Class Initialized
INFO - 2020-10-09 17:21:12 --> Security Class Initialized
DEBUG - 2020-10-09 17:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:21:12 --> Input Class Initialized
INFO - 2020-10-09 17:21:12 --> Language Class Initialized
INFO - 2020-10-09 17:21:12 --> Loader Class Initialized
INFO - 2020-10-09 17:21:12 --> Helper loaded: url_helper
INFO - 2020-10-09 17:21:12 --> Database Driver Class Initialized
INFO - 2020-10-09 17:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:21:12 --> Email Class Initialized
INFO - 2020-10-09 17:21:12 --> Controller Class Initialized
DEBUG - 2020-10-09 17:21:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:21:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:21:12 --> Model Class Initialized
INFO - 2020-10-09 17:21:12 --> Model Class Initialized
INFO - 2020-10-09 17:21:12 --> Final output sent to browser
DEBUG - 2020-10-09 17:21:12 --> Total execution time: 0.0213
ERROR - 2020-10-09 17:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:21:18 --> Config Class Initialized
INFO - 2020-10-09 17:21:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:21:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:21:18 --> Utf8 Class Initialized
INFO - 2020-10-09 17:21:18 --> URI Class Initialized
INFO - 2020-10-09 17:21:18 --> Router Class Initialized
INFO - 2020-10-09 17:21:18 --> Output Class Initialized
INFO - 2020-10-09 17:21:18 --> Security Class Initialized
DEBUG - 2020-10-09 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:21:18 --> Input Class Initialized
INFO - 2020-10-09 17:21:18 --> Language Class Initialized
INFO - 2020-10-09 17:21:18 --> Loader Class Initialized
INFO - 2020-10-09 17:21:18 --> Helper loaded: url_helper
INFO - 2020-10-09 17:21:18 --> Database Driver Class Initialized
INFO - 2020-10-09 17:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:21:18 --> Email Class Initialized
INFO - 2020-10-09 17:21:18 --> Controller Class Initialized
DEBUG - 2020-10-09 17:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:21:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:21:18 --> Model Class Initialized
INFO - 2020-10-09 17:21:18 --> Model Class Initialized
ERROR - 2020-10-09 17:21:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(1,Select Status)
INFO - 2020-10-09 17:21:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:21:25 --> Config Class Initialized
INFO - 2020-10-09 17:21:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:21:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:21:25 --> Utf8 Class Initialized
INFO - 2020-10-09 17:21:25 --> URI Class Initialized
INFO - 2020-10-09 17:21:25 --> Router Class Initialized
INFO - 2020-10-09 17:21:25 --> Output Class Initialized
INFO - 2020-10-09 17:21:25 --> Security Class Initialized
DEBUG - 2020-10-09 17:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:21:25 --> Input Class Initialized
INFO - 2020-10-09 17:21:25 --> Language Class Initialized
INFO - 2020-10-09 17:21:25 --> Loader Class Initialized
INFO - 2020-10-09 17:21:25 --> Helper loaded: url_helper
INFO - 2020-10-09 17:21:25 --> Database Driver Class Initialized
INFO - 2020-10-09 17:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:21:25 --> Email Class Initialized
INFO - 2020-10-09 17:21:25 --> Controller Class Initialized
DEBUG - 2020-10-09 17:21:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:21:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:21:25 --> Model Class Initialized
INFO - 2020-10-09 17:21:25 --> Model Class Initialized
INFO - 2020-10-09 17:21:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:21:25 --> Final output sent to browser
DEBUG - 2020-10-09 17:21:25 --> Total execution time: 0.0283
ERROR - 2020-10-09 17:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:21:26 --> Config Class Initialized
INFO - 2020-10-09 17:21:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:21:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:21:26 --> Utf8 Class Initialized
INFO - 2020-10-09 17:21:26 --> URI Class Initialized
INFO - 2020-10-09 17:21:26 --> Router Class Initialized
INFO - 2020-10-09 17:21:26 --> Output Class Initialized
INFO - 2020-10-09 17:21:26 --> Security Class Initialized
DEBUG - 2020-10-09 17:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:21:26 --> Input Class Initialized
INFO - 2020-10-09 17:21:26 --> Language Class Initialized
INFO - 2020-10-09 17:21:26 --> Loader Class Initialized
INFO - 2020-10-09 17:21:26 --> Helper loaded: url_helper
INFO - 2020-10-09 17:21:26 --> Database Driver Class Initialized
INFO - 2020-10-09 17:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:21:26 --> Email Class Initialized
INFO - 2020-10-09 17:21:26 --> Controller Class Initialized
DEBUG - 2020-10-09 17:21:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:21:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:21:26 --> Model Class Initialized
INFO - 2020-10-09 17:21:26 --> Model Class Initialized
INFO - 2020-10-09 17:21:26 --> Final output sent to browser
DEBUG - 2020-10-09 17:21:26 --> Total execution time: 0.0247
ERROR - 2020-10-09 17:22:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:07 --> Config Class Initialized
INFO - 2020-10-09 17:22:07 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:07 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:07 --> URI Class Initialized
INFO - 2020-10-09 17:22:07 --> Router Class Initialized
INFO - 2020-10-09 17:22:07 --> Output Class Initialized
INFO - 2020-10-09 17:22:07 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:07 --> Input Class Initialized
INFO - 2020-10-09 17:22:07 --> Language Class Initialized
INFO - 2020-10-09 17:22:07 --> Loader Class Initialized
INFO - 2020-10-09 17:22:07 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:07 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:07 --> Email Class Initialized
INFO - 2020-10-09 17:22:07 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:07 --> Model Class Initialized
INFO - 2020-10-09 17:22:07 --> Model Class Initialized
ERROR - 2020-10-09 17:22:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-09 17:22:07 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:22:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:11 --> Config Class Initialized
INFO - 2020-10-09 17:22:11 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:11 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:11 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:11 --> URI Class Initialized
INFO - 2020-10-09 17:22:11 --> Router Class Initialized
INFO - 2020-10-09 17:22:11 --> Output Class Initialized
INFO - 2020-10-09 17:22:11 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:11 --> Input Class Initialized
INFO - 2020-10-09 17:22:11 --> Language Class Initialized
INFO - 2020-10-09 17:22:11 --> Loader Class Initialized
INFO - 2020-10-09 17:22:11 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:11 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:11 --> Email Class Initialized
INFO - 2020-10-09 17:22:11 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:11 --> Model Class Initialized
INFO - 2020-10-09 17:22:11 --> Model Class Initialized
INFO - 2020-10-09 17:22:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:22:11 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:11 --> Total execution time: 0.0228
ERROR - 2020-10-09 17:22:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:12 --> Config Class Initialized
INFO - 2020-10-09 17:22:12 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:12 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:12 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:12 --> URI Class Initialized
INFO - 2020-10-09 17:22:12 --> Router Class Initialized
INFO - 2020-10-09 17:22:12 --> Output Class Initialized
INFO - 2020-10-09 17:22:12 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:12 --> Input Class Initialized
INFO - 2020-10-09 17:22:12 --> Language Class Initialized
INFO - 2020-10-09 17:22:12 --> Loader Class Initialized
INFO - 2020-10-09 17:22:12 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:12 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:12 --> Email Class Initialized
INFO - 2020-10-09 17:22:12 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:12 --> Model Class Initialized
INFO - 2020-10-09 17:22:12 --> Model Class Initialized
INFO - 2020-10-09 17:22:12 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:12 --> Total execution time: 0.0256
ERROR - 2020-10-09 17:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:17 --> Config Class Initialized
INFO - 2020-10-09 17:22:17 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:17 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:17 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:17 --> URI Class Initialized
INFO - 2020-10-09 17:22:17 --> Router Class Initialized
INFO - 2020-10-09 17:22:17 --> Output Class Initialized
INFO - 2020-10-09 17:22:17 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:17 --> Input Class Initialized
INFO - 2020-10-09 17:22:17 --> Language Class Initialized
INFO - 2020-10-09 17:22:17 --> Loader Class Initialized
INFO - 2020-10-09 17:22:17 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:17 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:17 --> Email Class Initialized
INFO - 2020-10-09 17:22:17 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:17 --> Model Class Initialized
INFO - 2020-10-09 17:22:17 --> Model Class Initialized
ERROR - 2020-10-09 17:22:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-09 17:22:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:22:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:21 --> Config Class Initialized
INFO - 2020-10-09 17:22:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:21 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:21 --> URI Class Initialized
INFO - 2020-10-09 17:22:21 --> Router Class Initialized
INFO - 2020-10-09 17:22:21 --> Output Class Initialized
INFO - 2020-10-09 17:22:21 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:21 --> Input Class Initialized
INFO - 2020-10-09 17:22:21 --> Language Class Initialized
INFO - 2020-10-09 17:22:21 --> Loader Class Initialized
INFO - 2020-10-09 17:22:21 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:21 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:21 --> Email Class Initialized
INFO - 2020-10-09 17:22:21 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:21 --> Model Class Initialized
INFO - 2020-10-09 17:22:21 --> Model Class Initialized
INFO - 2020-10-09 17:22:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:22:21 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:21 --> Total execution time: 0.0260
ERROR - 2020-10-09 17:22:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:22 --> Config Class Initialized
INFO - 2020-10-09 17:22:22 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:22 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:22 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:22 --> URI Class Initialized
INFO - 2020-10-09 17:22:22 --> Router Class Initialized
INFO - 2020-10-09 17:22:22 --> Output Class Initialized
INFO - 2020-10-09 17:22:22 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:22 --> Input Class Initialized
INFO - 2020-10-09 17:22:22 --> Language Class Initialized
INFO - 2020-10-09 17:22:22 --> Loader Class Initialized
INFO - 2020-10-09 17:22:22 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:22 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:22 --> Email Class Initialized
INFO - 2020-10-09 17:22:22 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:22 --> Model Class Initialized
INFO - 2020-10-09 17:22:22 --> Model Class Initialized
INFO - 2020-10-09 17:22:22 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:22 --> Total execution time: 0.0246
ERROR - 2020-10-09 17:22:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:29 --> Config Class Initialized
INFO - 2020-10-09 17:22:29 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:29 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:29 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:29 --> URI Class Initialized
INFO - 2020-10-09 17:22:29 --> Router Class Initialized
INFO - 2020-10-09 17:22:29 --> Output Class Initialized
INFO - 2020-10-09 17:22:29 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:29 --> Input Class Initialized
INFO - 2020-10-09 17:22:29 --> Language Class Initialized
INFO - 2020-10-09 17:22:29 --> Loader Class Initialized
INFO - 2020-10-09 17:22:29 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:29 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:29 --> Email Class Initialized
INFO - 2020-10-09 17:22:29 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:29 --> Model Class Initialized
INFO - 2020-10-09 17:22:29 --> Model Class Initialized
INFO - 2020-10-09 17:22:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:22:29 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:29 --> Total execution time: 0.0252
ERROR - 2020-10-09 17:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:31 --> Config Class Initialized
INFO - 2020-10-09 17:22:31 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:31 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:31 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:31 --> URI Class Initialized
INFO - 2020-10-09 17:22:31 --> Router Class Initialized
INFO - 2020-10-09 17:22:31 --> Output Class Initialized
INFO - 2020-10-09 17:22:31 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:31 --> Input Class Initialized
INFO - 2020-10-09 17:22:31 --> Language Class Initialized
INFO - 2020-10-09 17:22:31 --> Loader Class Initialized
INFO - 2020-10-09 17:22:31 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:31 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:31 --> Email Class Initialized
INFO - 2020-10-09 17:22:31 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:31 --> Model Class Initialized
INFO - 2020-10-09 17:22:31 --> Model Class Initialized
INFO - 2020-10-09 17:22:31 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:31 --> Total execution time: 0.0212
ERROR - 2020-10-09 17:22:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:38 --> Config Class Initialized
INFO - 2020-10-09 17:22:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:38 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:38 --> URI Class Initialized
INFO - 2020-10-09 17:22:38 --> Router Class Initialized
INFO - 2020-10-09 17:22:38 --> Output Class Initialized
INFO - 2020-10-09 17:22:38 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:38 --> Input Class Initialized
INFO - 2020-10-09 17:22:38 --> Language Class Initialized
INFO - 2020-10-09 17:22:38 --> Loader Class Initialized
INFO - 2020-10-09 17:22:38 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:38 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:38 --> Email Class Initialized
INFO - 2020-10-09 17:22:38 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:38 --> Model Class Initialized
INFO - 2020-10-09 17:22:38 --> Model Class Initialized
INFO - 2020-10-09 17:22:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:22:38 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:38 --> Total execution time: 0.0238
ERROR - 2020-10-09 17:22:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:22:41 --> Config Class Initialized
INFO - 2020-10-09 17:22:41 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:22:41 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:22:41 --> Utf8 Class Initialized
INFO - 2020-10-09 17:22:41 --> URI Class Initialized
INFO - 2020-10-09 17:22:41 --> Router Class Initialized
INFO - 2020-10-09 17:22:41 --> Output Class Initialized
INFO - 2020-10-09 17:22:41 --> Security Class Initialized
DEBUG - 2020-10-09 17:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:22:41 --> Input Class Initialized
INFO - 2020-10-09 17:22:41 --> Language Class Initialized
INFO - 2020-10-09 17:22:41 --> Loader Class Initialized
INFO - 2020-10-09 17:22:41 --> Helper loaded: url_helper
INFO - 2020-10-09 17:22:41 --> Database Driver Class Initialized
INFO - 2020-10-09 17:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:22:41 --> Email Class Initialized
INFO - 2020-10-09 17:22:41 --> Controller Class Initialized
DEBUG - 2020-10-09 17:22:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:22:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:22:41 --> Model Class Initialized
INFO - 2020-10-09 17:22:41 --> Model Class Initialized
INFO - 2020-10-09 17:22:41 --> Final output sent to browser
DEBUG - 2020-10-09 17:22:41 --> Total execution time: 0.0210
ERROR - 2020-10-09 17:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:23:35 --> Config Class Initialized
INFO - 2020-10-09 17:23:35 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:23:35 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:23:35 --> Utf8 Class Initialized
INFO - 2020-10-09 17:23:35 --> URI Class Initialized
INFO - 2020-10-09 17:23:35 --> Router Class Initialized
INFO - 2020-10-09 17:23:35 --> Output Class Initialized
INFO - 2020-10-09 17:23:35 --> Security Class Initialized
DEBUG - 2020-10-09 17:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:23:35 --> Input Class Initialized
INFO - 2020-10-09 17:23:35 --> Language Class Initialized
INFO - 2020-10-09 17:23:35 --> Loader Class Initialized
INFO - 2020-10-09 17:23:35 --> Helper loaded: url_helper
INFO - 2020-10-09 17:23:35 --> Database Driver Class Initialized
INFO - 2020-10-09 17:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:23:35 --> Email Class Initialized
INFO - 2020-10-09 17:23:35 --> Controller Class Initialized
DEBUG - 2020-10-09 17:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:23:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:23:35 --> Model Class Initialized
INFO - 2020-10-09 17:23:35 --> Model Class Initialized
INFO - 2020-10-09 17:23:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:23:35 --> Final output sent to browser
DEBUG - 2020-10-09 17:23:35 --> Total execution time: 0.0225
ERROR - 2020-10-09 17:23:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:23:36 --> Config Class Initialized
INFO - 2020-10-09 17:23:36 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:23:36 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:23:36 --> Utf8 Class Initialized
INFO - 2020-10-09 17:23:36 --> URI Class Initialized
INFO - 2020-10-09 17:23:36 --> Router Class Initialized
INFO - 2020-10-09 17:23:36 --> Output Class Initialized
INFO - 2020-10-09 17:23:36 --> Security Class Initialized
DEBUG - 2020-10-09 17:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:23:36 --> Input Class Initialized
INFO - 2020-10-09 17:23:36 --> Language Class Initialized
INFO - 2020-10-09 17:23:36 --> Loader Class Initialized
INFO - 2020-10-09 17:23:36 --> Helper loaded: url_helper
INFO - 2020-10-09 17:23:36 --> Database Driver Class Initialized
INFO - 2020-10-09 17:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:23:36 --> Email Class Initialized
INFO - 2020-10-09 17:23:36 --> Controller Class Initialized
DEBUG - 2020-10-09 17:23:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:23:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:23:36 --> Model Class Initialized
INFO - 2020-10-09 17:23:36 --> Model Class Initialized
INFO - 2020-10-09 17:23:36 --> Final output sent to browser
DEBUG - 2020-10-09 17:23:36 --> Total execution time: 0.0233
ERROR - 2020-10-09 17:23:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:23:57 --> Config Class Initialized
INFO - 2020-10-09 17:23:57 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:23:57 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:23:57 --> Utf8 Class Initialized
INFO - 2020-10-09 17:23:57 --> URI Class Initialized
INFO - 2020-10-09 17:23:57 --> Router Class Initialized
INFO - 2020-10-09 17:23:57 --> Output Class Initialized
INFO - 2020-10-09 17:23:57 --> Security Class Initialized
DEBUG - 2020-10-09 17:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:23:57 --> Input Class Initialized
INFO - 2020-10-09 17:23:57 --> Language Class Initialized
INFO - 2020-10-09 17:23:57 --> Loader Class Initialized
INFO - 2020-10-09 17:23:57 --> Helper loaded: url_helper
INFO - 2020-10-09 17:23:57 --> Database Driver Class Initialized
INFO - 2020-10-09 17:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:23:57 --> Email Class Initialized
INFO - 2020-10-09 17:23:57 --> Controller Class Initialized
DEBUG - 2020-10-09 17:23:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:23:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:23:57 --> Model Class Initialized
INFO - 2020-10-09 17:23:57 --> Model Class Initialized
INFO - 2020-10-09 17:23:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 17:23:57 --> Final output sent to browser
DEBUG - 2020-10-09 17:23:57 --> Total execution time: 0.0326
ERROR - 2020-10-09 17:23:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:23:59 --> Config Class Initialized
INFO - 2020-10-09 17:23:59 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:23:59 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:23:59 --> Utf8 Class Initialized
INFO - 2020-10-09 17:23:59 --> URI Class Initialized
INFO - 2020-10-09 17:23:59 --> Router Class Initialized
INFO - 2020-10-09 17:23:59 --> Output Class Initialized
INFO - 2020-10-09 17:23:59 --> Security Class Initialized
DEBUG - 2020-10-09 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:23:59 --> Input Class Initialized
INFO - 2020-10-09 17:23:59 --> Language Class Initialized
INFO - 2020-10-09 17:23:59 --> Loader Class Initialized
INFO - 2020-10-09 17:23:59 --> Helper loaded: url_helper
INFO - 2020-10-09 17:23:59 --> Database Driver Class Initialized
INFO - 2020-10-09 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:23:59 --> Email Class Initialized
INFO - 2020-10-09 17:23:59 --> Controller Class Initialized
DEBUG - 2020-10-09 17:23:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:23:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:23:59 --> Model Class Initialized
INFO - 2020-10-09 17:23:59 --> Model Class Initialized
INFO - 2020-10-09 17:23:59 --> Final output sent to browser
DEBUG - 2020-10-09 17:23:59 --> Total execution time: 0.0247
ERROR - 2020-10-09 17:24:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:24:18 --> Config Class Initialized
INFO - 2020-10-09 17:24:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:24:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:24:18 --> Utf8 Class Initialized
INFO - 2020-10-09 17:24:18 --> URI Class Initialized
INFO - 2020-10-09 17:24:18 --> Router Class Initialized
INFO - 2020-10-09 17:24:18 --> Output Class Initialized
INFO - 2020-10-09 17:24:18 --> Security Class Initialized
DEBUG - 2020-10-09 17:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:24:18 --> Input Class Initialized
INFO - 2020-10-09 17:24:18 --> Language Class Initialized
INFO - 2020-10-09 17:24:18 --> Loader Class Initialized
INFO - 2020-10-09 17:24:18 --> Helper loaded: url_helper
INFO - 2020-10-09 17:24:18 --> Database Driver Class Initialized
INFO - 2020-10-09 17:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:24:18 --> Email Class Initialized
INFO - 2020-10-09 17:24:18 --> Controller Class Initialized
DEBUG - 2020-10-09 17:24:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:24:18 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-09 17:24:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/purpu1ex/public_html/carsm/application/controllers/Sale_rep.php 312
INFO - 2020-10-09 17:24:18 --> Model Class Initialized
INFO - 2020-10-09 17:24:18 --> Model Class Initialized
ERROR - 2020-10-09 17:24:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL rep_assign_update('',)
INFO - 2020-10-09 17:24:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:24:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-09 17:24:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:24:27 --> Config Class Initialized
INFO - 2020-10-09 17:24:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:24:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:24:27 --> Utf8 Class Initialized
INFO - 2020-10-09 17:24:27 --> URI Class Initialized
INFO - 2020-10-09 17:24:27 --> Router Class Initialized
INFO - 2020-10-09 17:24:27 --> Output Class Initialized
INFO - 2020-10-09 17:24:27 --> Security Class Initialized
DEBUG - 2020-10-09 17:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:24:27 --> Input Class Initialized
INFO - 2020-10-09 17:24:27 --> Language Class Initialized
INFO - 2020-10-09 17:24:27 --> Loader Class Initialized
INFO - 2020-10-09 17:24:27 --> Helper loaded: url_helper
INFO - 2020-10-09 17:24:27 --> Database Driver Class Initialized
INFO - 2020-10-09 17:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:24:27 --> Email Class Initialized
INFO - 2020-10-09 17:24:27 --> Controller Class Initialized
DEBUG - 2020-10-09 17:24:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:24:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:24:27 --> Model Class Initialized
INFO - 2020-10-09 17:24:27 --> Model Class Initialized
INFO - 2020-10-09 17:24:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 17:24:27 --> Final output sent to browser
DEBUG - 2020-10-09 17:24:27 --> Total execution time: 0.0241
ERROR - 2020-10-09 17:24:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:24:28 --> Config Class Initialized
INFO - 2020-10-09 17:24:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:24:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:24:28 --> Utf8 Class Initialized
INFO - 2020-10-09 17:24:28 --> URI Class Initialized
INFO - 2020-10-09 17:24:28 --> Router Class Initialized
INFO - 2020-10-09 17:24:28 --> Output Class Initialized
INFO - 2020-10-09 17:24:28 --> Security Class Initialized
DEBUG - 2020-10-09 17:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:24:28 --> Input Class Initialized
INFO - 2020-10-09 17:24:28 --> Language Class Initialized
INFO - 2020-10-09 17:24:28 --> Loader Class Initialized
INFO - 2020-10-09 17:24:28 --> Helper loaded: url_helper
INFO - 2020-10-09 17:24:28 --> Database Driver Class Initialized
INFO - 2020-10-09 17:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:24:28 --> Email Class Initialized
INFO - 2020-10-09 17:24:28 --> Controller Class Initialized
DEBUG - 2020-10-09 17:24:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:24:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:24:28 --> Model Class Initialized
INFO - 2020-10-09 17:24:28 --> Model Class Initialized
INFO - 2020-10-09 17:24:28 --> Final output sent to browser
DEBUG - 2020-10-09 17:24:28 --> Total execution time: 0.0238
ERROR - 2020-10-09 17:27:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:27:46 --> Config Class Initialized
INFO - 2020-10-09 17:27:46 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:27:46 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:27:46 --> Utf8 Class Initialized
INFO - 2020-10-09 17:27:46 --> URI Class Initialized
INFO - 2020-10-09 17:27:46 --> Router Class Initialized
INFO - 2020-10-09 17:27:46 --> Output Class Initialized
INFO - 2020-10-09 17:27:46 --> Security Class Initialized
DEBUG - 2020-10-09 17:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:27:46 --> Input Class Initialized
INFO - 2020-10-09 17:27:46 --> Language Class Initialized
INFO - 2020-10-09 17:27:46 --> Loader Class Initialized
INFO - 2020-10-09 17:27:46 --> Helper loaded: url_helper
INFO - 2020-10-09 17:27:46 --> Database Driver Class Initialized
INFO - 2020-10-09 17:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:27:46 --> Email Class Initialized
INFO - 2020-10-09 17:27:46 --> Controller Class Initialized
DEBUG - 2020-10-09 17:27:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:27:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:27:46 --> Model Class Initialized
INFO - 2020-10-09 17:27:46 --> Model Class Initialized
INFO - 2020-10-09 17:27:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-09 17:27:46 --> Final output sent to browser
DEBUG - 2020-10-09 17:27:46 --> Total execution time: 0.0344
ERROR - 2020-10-09 17:27:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:27:47 --> Config Class Initialized
INFO - 2020-10-09 17:27:47 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:27:47 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:27:47 --> Utf8 Class Initialized
INFO - 2020-10-09 17:27:47 --> URI Class Initialized
INFO - 2020-10-09 17:27:47 --> Router Class Initialized
INFO - 2020-10-09 17:27:47 --> Output Class Initialized
INFO - 2020-10-09 17:27:47 --> Security Class Initialized
DEBUG - 2020-10-09 17:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:27:47 --> Input Class Initialized
INFO - 2020-10-09 17:27:47 --> Language Class Initialized
INFO - 2020-10-09 17:27:47 --> Loader Class Initialized
INFO - 2020-10-09 17:27:47 --> Helper loaded: url_helper
INFO - 2020-10-09 17:27:47 --> Database Driver Class Initialized
INFO - 2020-10-09 17:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:27:47 --> Email Class Initialized
INFO - 2020-10-09 17:27:47 --> Controller Class Initialized
DEBUG - 2020-10-09 17:27:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:27:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:27:47 --> Model Class Initialized
INFO - 2020-10-09 17:27:47 --> Model Class Initialized
INFO - 2020-10-09 17:27:47 --> Final output sent to browser
DEBUG - 2020-10-09 17:27:47 --> Total execution time: 0.0230
ERROR - 2020-10-09 17:31:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:18 --> Config Class Initialized
INFO - 2020-10-09 17:31:18 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:18 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:18 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:18 --> URI Class Initialized
INFO - 2020-10-09 17:31:18 --> Router Class Initialized
INFO - 2020-10-09 17:31:18 --> Output Class Initialized
INFO - 2020-10-09 17:31:18 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:18 --> Input Class Initialized
INFO - 2020-10-09 17:31:18 --> Language Class Initialized
INFO - 2020-10-09 17:31:18 --> Loader Class Initialized
INFO - 2020-10-09 17:31:18 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:18 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:18 --> Email Class Initialized
INFO - 2020-10-09 17:31:18 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:18 --> Model Class Initialized
INFO - 2020-10-09 17:31:18 --> Model Class Initialized
INFO - 2020-10-09 17:31:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:31:18 --> Final output sent to browser
DEBUG - 2020-10-09 17:31:18 --> Total execution time: 0.0232
ERROR - 2020-10-09 17:31:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:19 --> Config Class Initialized
INFO - 2020-10-09 17:31:19 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:19 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:19 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:19 --> URI Class Initialized
INFO - 2020-10-09 17:31:19 --> Router Class Initialized
INFO - 2020-10-09 17:31:19 --> Output Class Initialized
INFO - 2020-10-09 17:31:19 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:19 --> Input Class Initialized
INFO - 2020-10-09 17:31:19 --> Language Class Initialized
INFO - 2020-10-09 17:31:19 --> Loader Class Initialized
INFO - 2020-10-09 17:31:19 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:19 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:19 --> Email Class Initialized
INFO - 2020-10-09 17:31:19 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:19 --> Model Class Initialized
INFO - 2020-10-09 17:31:19 --> Model Class Initialized
INFO - 2020-10-09 17:31:19 --> Final output sent to browser
DEBUG - 2020-10-09 17:31:19 --> Total execution time: 0.0255
ERROR - 2020-10-09 17:31:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:23 --> Config Class Initialized
INFO - 2020-10-09 17:31:23 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:23 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:23 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:23 --> URI Class Initialized
INFO - 2020-10-09 17:31:23 --> Router Class Initialized
INFO - 2020-10-09 17:31:23 --> Output Class Initialized
INFO - 2020-10-09 17:31:23 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:23 --> Input Class Initialized
INFO - 2020-10-09 17:31:23 --> Language Class Initialized
INFO - 2020-10-09 17:31:23 --> Loader Class Initialized
INFO - 2020-10-09 17:31:23 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:23 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:23 --> Email Class Initialized
INFO - 2020-10-09 17:31:23 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:23 --> Model Class Initialized
INFO - 2020-10-09 17:31:23 --> Model Class Initialized
ERROR - 2020-10-09 17:31:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(2,Select Status)
INFO - 2020-10-09 17:31:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:26 --> Config Class Initialized
INFO - 2020-10-09 17:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:26 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:26 --> URI Class Initialized
INFO - 2020-10-09 17:31:26 --> Router Class Initialized
INFO - 2020-10-09 17:31:26 --> Output Class Initialized
INFO - 2020-10-09 17:31:26 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:26 --> Input Class Initialized
INFO - 2020-10-09 17:31:26 --> Language Class Initialized
INFO - 2020-10-09 17:31:26 --> Loader Class Initialized
INFO - 2020-10-09 17:31:26 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:26 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:26 --> Email Class Initialized
INFO - 2020-10-09 17:31:26 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:26 --> Model Class Initialized
INFO - 2020-10-09 17:31:26 --> Model Class Initialized
INFO - 2020-10-09 17:31:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:31:26 --> Final output sent to browser
DEBUG - 2020-10-09 17:31:26 --> Total execution time: 0.0200
ERROR - 2020-10-09 17:31:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:26 --> Config Class Initialized
INFO - 2020-10-09 17:31:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:26 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:26 --> URI Class Initialized
INFO - 2020-10-09 17:31:26 --> Router Class Initialized
INFO - 2020-10-09 17:31:26 --> Output Class Initialized
INFO - 2020-10-09 17:31:26 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:26 --> Input Class Initialized
INFO - 2020-10-09 17:31:26 --> Language Class Initialized
INFO - 2020-10-09 17:31:26 --> Loader Class Initialized
INFO - 2020-10-09 17:31:26 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:26 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:26 --> Email Class Initialized
INFO - 2020-10-09 17:31:26 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:26 --> Model Class Initialized
INFO - 2020-10-09 17:31:26 --> Model Class Initialized
INFO - 2020-10-09 17:31:26 --> Final output sent to browser
DEBUG - 2020-10-09 17:31:26 --> Total execution time: 0.0213
ERROR - 2020-10-09 17:31:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:35 --> Config Class Initialized
INFO - 2020-10-09 17:31:35 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:35 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:35 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:35 --> URI Class Initialized
INFO - 2020-10-09 17:31:35 --> Router Class Initialized
INFO - 2020-10-09 17:31:35 --> Output Class Initialized
INFO - 2020-10-09 17:31:35 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:35 --> Input Class Initialized
INFO - 2020-10-09 17:31:35 --> Language Class Initialized
INFO - 2020-10-09 17:31:35 --> Loader Class Initialized
INFO - 2020-10-09 17:31:35 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:35 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:35 --> Email Class Initialized
INFO - 2020-10-09 17:31:35 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:35 --> Model Class Initialized
INFO - 2020-10-09 17:31:35 --> Model Class Initialized
ERROR - 2020-10-09 17:31:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,1)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,1)
INFO - 2020-10-09 17:31:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:31:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:38 --> Config Class Initialized
INFO - 2020-10-09 17:31:38 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:38 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:38 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:38 --> URI Class Initialized
INFO - 2020-10-09 17:31:38 --> Router Class Initialized
INFO - 2020-10-09 17:31:38 --> Output Class Initialized
INFO - 2020-10-09 17:31:38 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:38 --> Input Class Initialized
INFO - 2020-10-09 17:31:38 --> Language Class Initialized
INFO - 2020-10-09 17:31:38 --> Loader Class Initialized
INFO - 2020-10-09 17:31:38 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:38 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:38 --> Email Class Initialized
INFO - 2020-10-09 17:31:38 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:38 --> Model Class Initialized
INFO - 2020-10-09 17:31:38 --> Model Class Initialized
INFO - 2020-10-09 17:31:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:31:38 --> Final output sent to browser
DEBUG - 2020-10-09 17:31:38 --> Total execution time: 0.0212
ERROR - 2020-10-09 17:31:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:31:39 --> Config Class Initialized
INFO - 2020-10-09 17:31:39 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:31:39 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:31:39 --> Utf8 Class Initialized
INFO - 2020-10-09 17:31:39 --> URI Class Initialized
INFO - 2020-10-09 17:31:39 --> Router Class Initialized
INFO - 2020-10-09 17:31:39 --> Output Class Initialized
INFO - 2020-10-09 17:31:39 --> Security Class Initialized
DEBUG - 2020-10-09 17:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:31:39 --> Input Class Initialized
INFO - 2020-10-09 17:31:39 --> Language Class Initialized
INFO - 2020-10-09 17:31:39 --> Loader Class Initialized
INFO - 2020-10-09 17:31:39 --> Helper loaded: url_helper
INFO - 2020-10-09 17:31:39 --> Database Driver Class Initialized
INFO - 2020-10-09 17:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:31:39 --> Email Class Initialized
INFO - 2020-10-09 17:31:39 --> Controller Class Initialized
DEBUG - 2020-10-09 17:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:31:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:31:39 --> Model Class Initialized
INFO - 2020-10-09 17:31:39 --> Model Class Initialized
INFO - 2020-10-09 17:31:39 --> Final output sent to browser
DEBUG - 2020-10-09 17:31:39 --> Total execution time: 0.0208
ERROR - 2020-10-09 17:34:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:34:20 --> Config Class Initialized
INFO - 2020-10-09 17:34:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:34:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:34:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:34:20 --> URI Class Initialized
INFO - 2020-10-09 17:34:20 --> Router Class Initialized
INFO - 2020-10-09 17:34:20 --> Output Class Initialized
INFO - 2020-10-09 17:34:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:34:20 --> Input Class Initialized
INFO - 2020-10-09 17:34:20 --> Language Class Initialized
INFO - 2020-10-09 17:34:20 --> Loader Class Initialized
INFO - 2020-10-09 17:34:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:34:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:34:20 --> Email Class Initialized
INFO - 2020-10-09 17:34:20 --> Controller Class Initialized
DEBUG - 2020-10-09 17:34:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:34:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:34:20 --> Model Class Initialized
INFO - 2020-10-09 17:34:20 --> Model Class Initialized
INFO - 2020-10-09 17:34:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:34:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:34:20 --> Total execution time: 0.0407
ERROR - 2020-10-09 17:34:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:34:21 --> Config Class Initialized
INFO - 2020-10-09 17:34:21 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:34:21 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:34:21 --> Utf8 Class Initialized
INFO - 2020-10-09 17:34:21 --> URI Class Initialized
INFO - 2020-10-09 17:34:21 --> Router Class Initialized
INFO - 2020-10-09 17:34:21 --> Output Class Initialized
INFO - 2020-10-09 17:34:21 --> Security Class Initialized
DEBUG - 2020-10-09 17:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:34:21 --> Input Class Initialized
INFO - 2020-10-09 17:34:21 --> Language Class Initialized
INFO - 2020-10-09 17:34:21 --> Loader Class Initialized
INFO - 2020-10-09 17:34:21 --> Helper loaded: url_helper
INFO - 2020-10-09 17:34:21 --> Database Driver Class Initialized
INFO - 2020-10-09 17:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:34:21 --> Email Class Initialized
INFO - 2020-10-09 17:34:21 --> Controller Class Initialized
DEBUG - 2020-10-09 17:34:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:34:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:34:21 --> Model Class Initialized
INFO - 2020-10-09 17:34:21 --> Model Class Initialized
INFO - 2020-10-09 17:34:21 --> Final output sent to browser
DEBUG - 2020-10-09 17:34:21 --> Total execution time: 0.0242
ERROR - 2020-10-09 17:34:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:34:25 --> Config Class Initialized
INFO - 2020-10-09 17:34:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:34:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:34:25 --> Utf8 Class Initialized
INFO - 2020-10-09 17:34:25 --> URI Class Initialized
INFO - 2020-10-09 17:34:25 --> Router Class Initialized
INFO - 2020-10-09 17:34:25 --> Output Class Initialized
INFO - 2020-10-09 17:34:25 --> Security Class Initialized
DEBUG - 2020-10-09 17:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:34:25 --> Input Class Initialized
INFO - 2020-10-09 17:34:25 --> Language Class Initialized
INFO - 2020-10-09 17:34:25 --> Loader Class Initialized
INFO - 2020-10-09 17:34:25 --> Helper loaded: url_helper
INFO - 2020-10-09 17:34:25 --> Database Driver Class Initialized
INFO - 2020-10-09 17:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:34:25 --> Email Class Initialized
INFO - 2020-10-09 17:34:25 --> Controller Class Initialized
DEBUG - 2020-10-09 17:34:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:34:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:34:25 --> Model Class Initialized
INFO - 2020-10-09 17:34:25 --> Model Class Initialized
ERROR - 2020-10-09 17:34:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'Select SR Name,Select Status)' at line 1 - Invalid query: CALL client_rep_status_wise_view(Select SR Name,Select Status)
INFO - 2020-10-09 17:34:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-09 17:34:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:34:27 --> Config Class Initialized
INFO - 2020-10-09 17:34:27 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:34:27 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:34:27 --> Utf8 Class Initialized
INFO - 2020-10-09 17:34:27 --> URI Class Initialized
INFO - 2020-10-09 17:34:27 --> Router Class Initialized
INFO - 2020-10-09 17:34:27 --> Output Class Initialized
INFO - 2020-10-09 17:34:27 --> Security Class Initialized
DEBUG - 2020-10-09 17:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:34:27 --> Input Class Initialized
INFO - 2020-10-09 17:34:27 --> Language Class Initialized
INFO - 2020-10-09 17:34:27 --> Loader Class Initialized
INFO - 2020-10-09 17:34:27 --> Helper loaded: url_helper
INFO - 2020-10-09 17:34:27 --> Database Driver Class Initialized
INFO - 2020-10-09 17:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:34:27 --> Email Class Initialized
INFO - 2020-10-09 17:34:27 --> Controller Class Initialized
DEBUG - 2020-10-09 17:34:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:34:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:34:27 --> Model Class Initialized
INFO - 2020-10-09 17:34:27 --> Model Class Initialized
INFO - 2020-10-09 17:34:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:34:27 --> Final output sent to browser
DEBUG - 2020-10-09 17:34:27 --> Total execution time: 0.0235
ERROR - 2020-10-09 17:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:34:28 --> Config Class Initialized
INFO - 2020-10-09 17:34:28 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:34:28 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:34:28 --> Utf8 Class Initialized
INFO - 2020-10-09 17:34:28 --> URI Class Initialized
INFO - 2020-10-09 17:34:28 --> Router Class Initialized
INFO - 2020-10-09 17:34:28 --> Output Class Initialized
INFO - 2020-10-09 17:34:28 --> Security Class Initialized
DEBUG - 2020-10-09 17:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:34:28 --> Input Class Initialized
INFO - 2020-10-09 17:34:28 --> Language Class Initialized
INFO - 2020-10-09 17:34:28 --> Loader Class Initialized
INFO - 2020-10-09 17:34:28 --> Helper loaded: url_helper
INFO - 2020-10-09 17:34:28 --> Database Driver Class Initialized
INFO - 2020-10-09 17:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:34:28 --> Email Class Initialized
INFO - 2020-10-09 17:34:28 --> Controller Class Initialized
DEBUG - 2020-10-09 17:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:34:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:34:28 --> Model Class Initialized
INFO - 2020-10-09 17:34:28 --> Model Class Initialized
INFO - 2020-10-09 17:34:28 --> Final output sent to browser
DEBUG - 2020-10-09 17:34:28 --> Total execution time: 0.0194
ERROR - 2020-10-09 17:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:35:20 --> Config Class Initialized
INFO - 2020-10-09 17:35:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:35:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:35:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:35:20 --> URI Class Initialized
INFO - 2020-10-09 17:35:20 --> Router Class Initialized
INFO - 2020-10-09 17:35:20 --> Output Class Initialized
INFO - 2020-10-09 17:35:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:35:20 --> Input Class Initialized
INFO - 2020-10-09 17:35:20 --> Language Class Initialized
INFO - 2020-10-09 17:35:20 --> Loader Class Initialized
INFO - 2020-10-09 17:35:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:35:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:35:20 --> Email Class Initialized
INFO - 2020-10-09 17:35:20 --> Controller Class Initialized
DEBUG - 2020-10-09 17:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:35:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:35:20 --> Model Class Initialized
INFO - 2020-10-09 17:35:20 --> Model Class Initialized
INFO - 2020-10-09 17:35:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:35:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:35:20 --> Total execution time: 0.0224
ERROR - 2020-10-09 17:35:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:35:20 --> Config Class Initialized
INFO - 2020-10-09 17:35:20 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:35:20 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:35:20 --> Utf8 Class Initialized
INFO - 2020-10-09 17:35:20 --> URI Class Initialized
INFO - 2020-10-09 17:35:20 --> Router Class Initialized
INFO - 2020-10-09 17:35:20 --> Output Class Initialized
INFO - 2020-10-09 17:35:20 --> Security Class Initialized
DEBUG - 2020-10-09 17:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:35:20 --> Input Class Initialized
INFO - 2020-10-09 17:35:20 --> Language Class Initialized
INFO - 2020-10-09 17:35:20 --> Loader Class Initialized
INFO - 2020-10-09 17:35:20 --> Helper loaded: url_helper
INFO - 2020-10-09 17:35:20 --> Database Driver Class Initialized
INFO - 2020-10-09 17:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:35:20 --> Email Class Initialized
INFO - 2020-10-09 17:35:20 --> Controller Class Initialized
DEBUG - 2020-10-09 17:35:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:35:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:35:20 --> Model Class Initialized
INFO - 2020-10-09 17:35:20 --> Model Class Initialized
INFO - 2020-10-09 17:35:20 --> Final output sent to browser
DEBUG - 2020-10-09 17:35:20 --> Total execution time: 0.0204
ERROR - 2020-10-09 17:35:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:35:25 --> Config Class Initialized
INFO - 2020-10-09 17:35:25 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:35:25 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:35:25 --> Utf8 Class Initialized
INFO - 2020-10-09 17:35:25 --> URI Class Initialized
INFO - 2020-10-09 17:35:25 --> Router Class Initialized
INFO - 2020-10-09 17:35:25 --> Output Class Initialized
INFO - 2020-10-09 17:35:25 --> Security Class Initialized
DEBUG - 2020-10-09 17:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:35:25 --> Input Class Initialized
INFO - 2020-10-09 17:35:25 --> Language Class Initialized
INFO - 2020-10-09 17:35:25 --> Loader Class Initialized
INFO - 2020-10-09 17:35:25 --> Helper loaded: url_helper
INFO - 2020-10-09 17:35:25 --> Database Driver Class Initialized
INFO - 2020-10-09 17:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:35:25 --> Email Class Initialized
INFO - 2020-10-09 17:35:25 --> Controller Class Initialized
DEBUG - 2020-10-09 17:35:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:35:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:35:25 --> Model Class Initialized
INFO - 2020-10-09 17:35:25 --> Model Class Initialized
INFO - 2020-10-09 17:35:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-09 17:35:25 --> Final output sent to browser
DEBUG - 2020-10-09 17:35:25 --> Total execution time: 0.2160
ERROR - 2020-10-09 17:35:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:35:26 --> Config Class Initialized
INFO - 2020-10-09 17:35:26 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:35:26 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:35:26 --> Utf8 Class Initialized
INFO - 2020-10-09 17:35:26 --> URI Class Initialized
INFO - 2020-10-09 17:35:26 --> Router Class Initialized
INFO - 2020-10-09 17:35:26 --> Output Class Initialized
INFO - 2020-10-09 17:35:26 --> Security Class Initialized
DEBUG - 2020-10-09 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:35:26 --> Input Class Initialized
INFO - 2020-10-09 17:35:26 --> Language Class Initialized
INFO - 2020-10-09 17:35:26 --> Loader Class Initialized
INFO - 2020-10-09 17:35:26 --> Helper loaded: url_helper
INFO - 2020-10-09 17:35:26 --> Database Driver Class Initialized
INFO - 2020-10-09 17:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:35:26 --> Email Class Initialized
INFO - 2020-10-09 17:35:26 --> Controller Class Initialized
DEBUG - 2020-10-09 17:35:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-09 17:35:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:35:26 --> Model Class Initialized
INFO - 2020-10-09 17:35:26 --> Model Class Initialized
INFO - 2020-10-09 17:35:26 --> Final output sent to browser
DEBUG - 2020-10-09 17:35:26 --> Total execution time: 0.0237
ERROR - 2020-10-09 17:35:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-09 17:35:43 --> Config Class Initialized
INFO - 2020-10-09 17:35:43 --> Hooks Class Initialized
DEBUG - 2020-10-09 17:35:43 --> UTF-8 Support Enabled
INFO - 2020-10-09 17:35:43 --> Utf8 Class Initialized
INFO - 2020-10-09 17:35:43 --> URI Class Initialized
DEBUG - 2020-10-09 17:35:43 --> No URI present. Default controller set.
INFO - 2020-10-09 17:35:43 --> Router Class Initialized
INFO - 2020-10-09 17:35:43 --> Output Class Initialized
INFO - 2020-10-09 17:35:43 --> Security Class Initialized
DEBUG - 2020-10-09 17:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-09 17:35:43 --> Input Class Initialized
INFO - 2020-10-09 17:35:43 --> Language Class Initialized
INFO - 2020-10-09 17:35:43 --> Loader Class Initialized
INFO - 2020-10-09 17:35:43 --> Helper loaded: url_helper
INFO - 2020-10-09 17:35:43 --> Database Driver Class Initialized
INFO - 2020-10-09 17:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-09 17:35:43 --> Email Class Initialized
INFO - 2020-10-09 17:35:43 --> Controller Class Initialized
INFO - 2020-10-09 17:35:43 --> Model Class Initialized
INFO - 2020-10-09 17:35:43 --> Model Class Initialized
DEBUG - 2020-10-09 17:35:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-09 17:35:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-09 17:35:43 --> Final output sent to browser
DEBUG - 2020-10-09 17:35:43 --> Total execution time: 0.0211
