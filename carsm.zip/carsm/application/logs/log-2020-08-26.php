<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-26 09:28:30 --> Config Class Initialized
INFO - 2020-08-26 09:28:30 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:28:30 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:28:30 --> Utf8 Class Initialized
INFO - 2020-08-26 09:28:30 --> URI Class Initialized
DEBUG - 2020-08-26 09:28:30 --> No URI present. Default controller set.
INFO - 2020-08-26 09:28:30 --> Router Class Initialized
INFO - 2020-08-26 09:28:30 --> Output Class Initialized
INFO - 2020-08-26 09:28:30 --> Security Class Initialized
DEBUG - 2020-08-26 09:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:28:30 --> Input Class Initialized
INFO - 2020-08-26 09:28:30 --> Language Class Initialized
INFO - 2020-08-26 09:28:30 --> Loader Class Initialized
INFO - 2020-08-26 09:28:30 --> Helper loaded: url_helper
INFO - 2020-08-26 09:28:30 --> Database Driver Class Initialized
INFO - 2020-08-26 09:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:28:30 --> Email Class Initialized
INFO - 2020-08-26 09:28:30 --> Controller Class Initialized
INFO - 2020-08-26 09:28:30 --> Model Class Initialized
INFO - 2020-08-26 09:28:30 --> Model Class Initialized
DEBUG - 2020-08-26 09:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:28:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-26 09:28:30 --> Final output sent to browser
DEBUG - 2020-08-26 09:28:30 --> Total execution time: 0.1260
INFO - 2020-08-26 09:28:41 --> Config Class Initialized
INFO - 2020-08-26 09:28:41 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:28:41 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:28:41 --> Utf8 Class Initialized
INFO - 2020-08-26 09:28:41 --> URI Class Initialized
INFO - 2020-08-26 09:28:41 --> Router Class Initialized
INFO - 2020-08-26 09:28:41 --> Output Class Initialized
INFO - 2020-08-26 09:28:41 --> Security Class Initialized
DEBUG - 2020-08-26 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:28:41 --> Input Class Initialized
INFO - 2020-08-26 09:28:41 --> Language Class Initialized
INFO - 2020-08-26 09:28:41 --> Loader Class Initialized
INFO - 2020-08-26 09:28:41 --> Helper loaded: url_helper
INFO - 2020-08-26 09:28:41 --> Database Driver Class Initialized
INFO - 2020-08-26 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:28:41 --> Email Class Initialized
INFO - 2020-08-26 09:28:41 --> Controller Class Initialized
INFO - 2020-08-26 09:28:41 --> Model Class Initialized
INFO - 2020-08-26 09:28:41 --> Model Class Initialized
DEBUG - 2020-08-26 09:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:28:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:28:41 --> Config Class Initialized
INFO - 2020-08-26 09:28:41 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:28:41 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:28:41 --> Utf8 Class Initialized
INFO - 2020-08-26 09:28:41 --> URI Class Initialized
INFO - 2020-08-26 09:28:41 --> Router Class Initialized
INFO - 2020-08-26 09:28:41 --> Output Class Initialized
INFO - 2020-08-26 09:28:41 --> Security Class Initialized
DEBUG - 2020-08-26 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:28:41 --> Input Class Initialized
INFO - 2020-08-26 09:28:41 --> Language Class Initialized
INFO - 2020-08-26 09:28:41 --> Loader Class Initialized
INFO - 2020-08-26 09:28:41 --> Helper loaded: url_helper
INFO - 2020-08-26 09:28:41 --> Database Driver Class Initialized
INFO - 2020-08-26 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:28:41 --> Email Class Initialized
INFO - 2020-08-26 09:28:41 --> Controller Class Initialized
INFO - 2020-08-26 09:28:41 --> Model Class Initialized
INFO - 2020-08-26 09:28:41 --> Model Class Initialized
DEBUG - 2020-08-26 09:28:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:28:42 --> Config Class Initialized
INFO - 2020-08-26 09:28:42 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:28:42 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:28:42 --> Utf8 Class Initialized
INFO - 2020-08-26 09:28:42 --> URI Class Initialized
DEBUG - 2020-08-26 09:28:42 --> No URI present. Default controller set.
INFO - 2020-08-26 09:28:42 --> Router Class Initialized
INFO - 2020-08-26 09:28:42 --> Output Class Initialized
INFO - 2020-08-26 09:28:42 --> Security Class Initialized
DEBUG - 2020-08-26 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:28:42 --> Config Class Initialized
INFO - 2020-08-26 09:28:42 --> Input Class Initialized
INFO - 2020-08-26 09:28:42 --> Hooks Class Initialized
INFO - 2020-08-26 09:28:42 --> Language Class Initialized
DEBUG - 2020-08-26 09:28:42 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:28:42 --> Utf8 Class Initialized
INFO - 2020-08-26 09:28:42 --> Loader Class Initialized
INFO - 2020-08-26 09:28:42 --> URI Class Initialized
INFO - 2020-08-26 09:28:42 --> Helper loaded: url_helper
INFO - 2020-08-26 09:28:42 --> Router Class Initialized
INFO - 2020-08-26 09:28:42 --> Output Class Initialized
INFO - 2020-08-26 09:28:42 --> Security Class Initialized
DEBUG - 2020-08-26 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:28:42 --> Input Class Initialized
INFO - 2020-08-26 09:28:42 --> Language Class Initialized
INFO - 2020-08-26 09:28:42 --> Database Driver Class Initialized
INFO - 2020-08-26 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:28:42 --> Email Class Initialized
INFO - 2020-08-26 09:28:42 --> Controller Class Initialized
INFO - 2020-08-26 09:28:42 --> Model Class Initialized
INFO - 2020-08-26 09:28:42 --> Model Class Initialized
DEBUG - 2020-08-26 09:28:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:28:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-26 09:28:42 --> Final output sent to browser
DEBUG - 2020-08-26 09:28:42 --> Total execution time: 0.0238
INFO - 2020-08-26 09:28:42 --> Loader Class Initialized
INFO - 2020-08-26 09:28:42 --> Helper loaded: url_helper
INFO - 2020-08-26 09:28:42 --> Database Driver Class Initialized
INFO - 2020-08-26 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:28:42 --> Email Class Initialized
INFO - 2020-08-26 09:28:42 --> Controller Class Initialized
DEBUG - 2020-08-26 09:28:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:28:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:28:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-26 09:28:42 --> Final output sent to browser
DEBUG - 2020-08-26 09:28:42 --> Total execution time: 0.0463
INFO - 2020-08-26 09:28:50 --> Config Class Initialized
INFO - 2020-08-26 09:28:50 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:28:50 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:28:50 --> Utf8 Class Initialized
INFO - 2020-08-26 09:28:50 --> URI Class Initialized
INFO - 2020-08-26 09:28:50 --> Router Class Initialized
INFO - 2020-08-26 09:28:50 --> Output Class Initialized
INFO - 2020-08-26 09:28:50 --> Security Class Initialized
DEBUG - 2020-08-26 09:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:28:50 --> Input Class Initialized
INFO - 2020-08-26 09:28:50 --> Language Class Initialized
INFO - 2020-08-26 09:28:50 --> Loader Class Initialized
INFO - 2020-08-26 09:28:50 --> Helper loaded: url_helper
INFO - 2020-08-26 09:28:50 --> Database Driver Class Initialized
INFO - 2020-08-26 09:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:28:50 --> Email Class Initialized
INFO - 2020-08-26 09:28:50 --> Controller Class Initialized
DEBUG - 2020-08-26 09:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:28:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:28:50 --> Model Class Initialized
INFO - 2020-08-26 09:28:50 --> Model Class Initialized
INFO - 2020-08-26 09:28:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-26 09:28:50 --> Final output sent to browser
DEBUG - 2020-08-26 09:28:50 --> Total execution time: 0.0422
INFO - 2020-08-26 09:29:19 --> Config Class Initialized
INFO - 2020-08-26 09:29:19 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:29:19 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:29:19 --> Utf8 Class Initialized
INFO - 2020-08-26 09:29:19 --> URI Class Initialized
INFO - 2020-08-26 09:29:19 --> Router Class Initialized
INFO - 2020-08-26 09:29:19 --> Output Class Initialized
INFO - 2020-08-26 09:29:19 --> Security Class Initialized
DEBUG - 2020-08-26 09:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:29:19 --> Input Class Initialized
INFO - 2020-08-26 09:29:19 --> Language Class Initialized
INFO - 2020-08-26 09:29:19 --> Loader Class Initialized
INFO - 2020-08-26 09:29:19 --> Helper loaded: url_helper
INFO - 2020-08-26 09:29:19 --> Database Driver Class Initialized
INFO - 2020-08-26 09:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:29:19 --> Email Class Initialized
INFO - 2020-08-26 09:29:19 --> Controller Class Initialized
DEBUG - 2020-08-26 09:29:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:29:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:29:19 --> Model Class Initialized
INFO - 2020-08-26 09:29:19 --> Model Class Initialized
INFO - 2020-08-26 09:29:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-26 09:29:19 --> Final output sent to browser
DEBUG - 2020-08-26 09:29:19 --> Total execution time: 0.0305
INFO - 2020-08-26 09:29:39 --> Config Class Initialized
INFO - 2020-08-26 09:29:39 --> Hooks Class Initialized
DEBUG - 2020-08-26 09:29:39 --> UTF-8 Support Enabled
INFO - 2020-08-26 09:29:39 --> Utf8 Class Initialized
INFO - 2020-08-26 09:29:39 --> URI Class Initialized
INFO - 2020-08-26 09:29:39 --> Router Class Initialized
INFO - 2020-08-26 09:29:39 --> Output Class Initialized
INFO - 2020-08-26 09:29:39 --> Security Class Initialized
DEBUG - 2020-08-26 09:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-26 09:29:39 --> Input Class Initialized
INFO - 2020-08-26 09:29:39 --> Language Class Initialized
INFO - 2020-08-26 09:29:39 --> Loader Class Initialized
INFO - 2020-08-26 09:29:39 --> Helper loaded: url_helper
INFO - 2020-08-26 09:29:39 --> Database Driver Class Initialized
INFO - 2020-08-26 09:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-26 09:29:39 --> Email Class Initialized
INFO - 2020-08-26 09:29:39 --> Controller Class Initialized
DEBUG - 2020-08-26 09:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-26 09:29:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-26 09:29:39 --> Model Class Initialized
INFO - 2020-08-26 09:29:39 --> Model Class Initialized
INFO - 2020-08-26 09:29:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-26 09:29:39 --> Final output sent to browser
DEBUG - 2020-08-26 09:29:39 --> Total execution time: 0.0777
