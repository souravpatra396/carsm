<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-18 05:46:40 --> Config Class Initialized
INFO - 2020-08-18 05:46:40 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:46:40 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:46:40 --> Utf8 Class Initialized
INFO - 2020-08-18 05:46:40 --> URI Class Initialized
DEBUG - 2020-08-18 05:46:40 --> No URI present. Default controller set.
INFO - 2020-08-18 05:46:40 --> Router Class Initialized
INFO - 2020-08-18 05:46:40 --> Output Class Initialized
INFO - 2020-08-18 05:46:40 --> Security Class Initialized
DEBUG - 2020-08-18 05:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:46:40 --> Input Class Initialized
INFO - 2020-08-18 05:46:40 --> Language Class Initialized
INFO - 2020-08-18 05:46:40 --> Loader Class Initialized
INFO - 2020-08-18 05:46:40 --> Helper loaded: url_helper
INFO - 2020-08-18 05:46:40 --> Database Driver Class Initialized
INFO - 2020-08-18 05:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:46:40 --> Email Class Initialized
INFO - 2020-08-18 05:46:40 --> Controller Class Initialized
INFO - 2020-08-18 05:46:40 --> Model Class Initialized
INFO - 2020-08-18 05:46:40 --> Model Class Initialized
DEBUG - 2020-08-18 05:46:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:46:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 05:46:40 --> Final output sent to browser
DEBUG - 2020-08-18 05:46:40 --> Total execution time: 0.1940
INFO - 2020-08-18 05:46:44 --> Config Class Initialized
INFO - 2020-08-18 05:46:44 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:46:44 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:46:44 --> Utf8 Class Initialized
INFO - 2020-08-18 05:46:44 --> URI Class Initialized
DEBUG - 2020-08-18 05:46:44 --> No URI present. Default controller set.
INFO - 2020-08-18 05:46:44 --> Router Class Initialized
INFO - 2020-08-18 05:46:44 --> Output Class Initialized
INFO - 2020-08-18 05:46:44 --> Security Class Initialized
DEBUG - 2020-08-18 05:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:46:44 --> Input Class Initialized
INFO - 2020-08-18 05:46:44 --> Language Class Initialized
INFO - 2020-08-18 05:46:44 --> Loader Class Initialized
INFO - 2020-08-18 05:46:44 --> Helper loaded: url_helper
INFO - 2020-08-18 05:46:44 --> Database Driver Class Initialized
INFO - 2020-08-18 05:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:46:44 --> Email Class Initialized
INFO - 2020-08-18 05:46:44 --> Controller Class Initialized
INFO - 2020-08-18 05:46:44 --> Model Class Initialized
INFO - 2020-08-18 05:46:44 --> Model Class Initialized
DEBUG - 2020-08-18 05:46:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:46:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 05:46:44 --> Final output sent to browser
DEBUG - 2020-08-18 05:46:44 --> Total execution time: 0.0209
INFO - 2020-08-18 05:47:37 --> Config Class Initialized
INFO - 2020-08-18 05:47:37 --> Hooks Class Initialized
INFO - 2020-08-18 05:47:37 --> Config Class Initialized
INFO - 2020-08-18 05:47:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:47:37 --> UTF-8 Support Enabled
DEBUG - 2020-08-18 05:47:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:37 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:37 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:37 --> URI Class Initialized
INFO - 2020-08-18 05:47:37 --> URI Class Initialized
INFO - 2020-08-18 05:47:37 --> Router Class Initialized
INFO - 2020-08-18 05:47:37 --> Router Class Initialized
INFO - 2020-08-18 05:47:37 --> Output Class Initialized
INFO - 2020-08-18 05:47:37 --> Output Class Initialized
INFO - 2020-08-18 05:47:37 --> Security Class Initialized
INFO - 2020-08-18 05:47:37 --> Security Class Initialized
DEBUG - 2020-08-18 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:37 --> Input Class Initialized
DEBUG - 2020-08-18 05:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:37 --> Input Class Initialized
INFO - 2020-08-18 05:47:37 --> Language Class Initialized
INFO - 2020-08-18 05:47:37 --> Language Class Initialized
INFO - 2020-08-18 05:47:37 --> Loader Class Initialized
INFO - 2020-08-18 05:47:37 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:37 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:37 --> Email Class Initialized
INFO - 2020-08-18 05:47:37 --> Controller Class Initialized
INFO - 2020-08-18 05:47:37 --> Model Class Initialized
INFO - 2020-08-18 05:47:37 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 05:47:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:37 --> Loader Class Initialized
INFO - 2020-08-18 05:47:37 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:37 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:37 --> Email Class Initialized
INFO - 2020-08-18 05:47:37 --> Controller Class Initialized
INFO - 2020-08-18 05:47:37 --> Model Class Initialized
INFO - 2020-08-18 05:47:37 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:38 --> Config Class Initialized
INFO - 2020-08-18 05:47:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:47:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:38 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:38 --> URI Class Initialized
DEBUG - 2020-08-18 05:47:38 --> No URI present. Default controller set.
INFO - 2020-08-18 05:47:38 --> Router Class Initialized
INFO - 2020-08-18 05:47:38 --> Output Class Initialized
INFO - 2020-08-18 05:47:38 --> Security Class Initialized
DEBUG - 2020-08-18 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:38 --> Input Class Initialized
INFO - 2020-08-18 05:47:38 --> Language Class Initialized
INFO - 2020-08-18 05:47:38 --> Loader Class Initialized
INFO - 2020-08-18 05:47:38 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:38 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:38 --> Email Class Initialized
INFO - 2020-08-18 05:47:38 --> Controller Class Initialized
INFO - 2020-08-18 05:47:38 --> Model Class Initialized
INFO - 2020-08-18 05:47:38 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 05:47:38 --> Final output sent to browser
DEBUG - 2020-08-18 05:47:38 --> Total execution time: 0.0241
INFO - 2020-08-18 05:47:38 --> Config Class Initialized
INFO - 2020-08-18 05:47:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:47:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:38 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:38 --> URI Class Initialized
DEBUG - 2020-08-18 05:47:38 --> No URI present. Default controller set.
INFO - 2020-08-18 05:47:38 --> Router Class Initialized
INFO - 2020-08-18 05:47:38 --> Output Class Initialized
INFO - 2020-08-18 05:47:38 --> Security Class Initialized
DEBUG - 2020-08-18 05:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:38 --> Input Class Initialized
INFO - 2020-08-18 05:47:38 --> Language Class Initialized
INFO - 2020-08-18 05:47:38 --> Loader Class Initialized
INFO - 2020-08-18 05:47:38 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:38 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:38 --> Email Class Initialized
INFO - 2020-08-18 05:47:38 --> Controller Class Initialized
INFO - 2020-08-18 05:47:38 --> Model Class Initialized
INFO - 2020-08-18 05:47:38 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 05:47:38 --> Final output sent to browser
DEBUG - 2020-08-18 05:47:38 --> Total execution time: 0.0233
INFO - 2020-08-18 05:47:50 --> Config Class Initialized
INFO - 2020-08-18 05:47:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:47:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:50 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:50 --> URI Class Initialized
INFO - 2020-08-18 05:47:50 --> Router Class Initialized
INFO - 2020-08-18 05:47:50 --> Output Class Initialized
INFO - 2020-08-18 05:47:50 --> Security Class Initialized
DEBUG - 2020-08-18 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:50 --> Input Class Initialized
INFO - 2020-08-18 05:47:50 --> Language Class Initialized
INFO - 2020-08-18 05:47:50 --> Loader Class Initialized
INFO - 2020-08-18 05:47:50 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:50 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:50 --> Email Class Initialized
INFO - 2020-08-18 05:47:50 --> Controller Class Initialized
INFO - 2020-08-18 05:47:50 --> Model Class Initialized
INFO - 2020-08-18 05:47:50 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:50 --> Config Class Initialized
INFO - 2020-08-18 05:47:50 --> Config Class Initialized
INFO - 2020-08-18 05:47:50 --> Hooks Class Initialized
INFO - 2020-08-18 05:47:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:47:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:50 --> Utf8 Class Initialized
DEBUG - 2020-08-18 05:47:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:50 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:50 --> URI Class Initialized
INFO - 2020-08-18 05:47:50 --> URI Class Initialized
DEBUG - 2020-08-18 05:47:50 --> No URI present. Default controller set.
INFO - 2020-08-18 05:47:50 --> Router Class Initialized
INFO - 2020-08-18 05:47:50 --> Router Class Initialized
INFO - 2020-08-18 05:47:50 --> Output Class Initialized
INFO - 2020-08-18 05:47:50 --> Output Class Initialized
INFO - 2020-08-18 05:47:50 --> Security Class Initialized
INFO - 2020-08-18 05:47:50 --> Security Class Initialized
DEBUG - 2020-08-18 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:50 --> Input Class Initialized
DEBUG - 2020-08-18 05:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:50 --> Input Class Initialized
INFO - 2020-08-18 05:47:50 --> Language Class Initialized
INFO - 2020-08-18 05:47:50 --> Language Class Initialized
INFO - 2020-08-18 05:47:50 --> Loader Class Initialized
INFO - 2020-08-18 05:47:50 --> Loader Class Initialized
INFO - 2020-08-18 05:47:50 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:50 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:50 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:50 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:50 --> Email Class Initialized
INFO - 2020-08-18 05:47:50 --> Controller Class Initialized
INFO - 2020-08-18 05:47:50 --> Model Class Initialized
INFO - 2020-08-18 05:47:50 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 05:47:50 --> Final output sent to browser
DEBUG - 2020-08-18 05:47:50 --> Total execution time: 0.0236
INFO - 2020-08-18 05:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:50 --> Email Class Initialized
INFO - 2020-08-18 05:47:50 --> Controller Class Initialized
INFO - 2020-08-18 05:47:50 --> Model Class Initialized
INFO - 2020-08-18 05:47:50 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 05:47:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:51 --> Config Class Initialized
INFO - 2020-08-18 05:47:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 05:47:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 05:47:51 --> Utf8 Class Initialized
INFO - 2020-08-18 05:47:51 --> URI Class Initialized
DEBUG - 2020-08-18 05:47:51 --> No URI present. Default controller set.
INFO - 2020-08-18 05:47:51 --> Router Class Initialized
INFO - 2020-08-18 05:47:51 --> Output Class Initialized
INFO - 2020-08-18 05:47:51 --> Security Class Initialized
DEBUG - 2020-08-18 05:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 05:47:51 --> Input Class Initialized
INFO - 2020-08-18 05:47:51 --> Language Class Initialized
INFO - 2020-08-18 05:47:51 --> Loader Class Initialized
INFO - 2020-08-18 05:47:51 --> Helper loaded: url_helper
INFO - 2020-08-18 05:47:51 --> Database Driver Class Initialized
INFO - 2020-08-18 05:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 05:47:51 --> Email Class Initialized
INFO - 2020-08-18 05:47:51 --> Controller Class Initialized
INFO - 2020-08-18 05:47:51 --> Model Class Initialized
INFO - 2020-08-18 05:47:51 --> Model Class Initialized
DEBUG - 2020-08-18 05:47:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 05:47:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 05:47:51 --> Final output sent to browser
DEBUG - 2020-08-18 05:47:51 --> Total execution time: 0.0238
INFO - 2020-08-18 07:09:42 --> Config Class Initialized
INFO - 2020-08-18 07:09:42 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:09:42 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:09:42 --> Utf8 Class Initialized
INFO - 2020-08-18 07:09:42 --> URI Class Initialized
DEBUG - 2020-08-18 07:09:42 --> No URI present. Default controller set.
INFO - 2020-08-18 07:09:42 --> Router Class Initialized
INFO - 2020-08-18 07:09:42 --> Output Class Initialized
INFO - 2020-08-18 07:09:42 --> Security Class Initialized
DEBUG - 2020-08-18 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:09:42 --> Input Class Initialized
INFO - 2020-08-18 07:09:42 --> Language Class Initialized
INFO - 2020-08-18 07:09:42 --> Loader Class Initialized
INFO - 2020-08-18 07:09:42 --> Helper loaded: url_helper
INFO - 2020-08-18 07:09:42 --> Database Driver Class Initialized
INFO - 2020-08-18 07:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:09:42 --> Email Class Initialized
INFO - 2020-08-18 07:09:42 --> Controller Class Initialized
INFO - 2020-08-18 07:09:42 --> Model Class Initialized
INFO - 2020-08-18 07:09:42 --> Model Class Initialized
DEBUG - 2020-08-18 07:09:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:09:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:09:42 --> Final output sent to browser
DEBUG - 2020-08-18 07:09:42 --> Total execution time: 0.1858
INFO - 2020-08-18 07:09:43 --> Config Class Initialized
INFO - 2020-08-18 07:09:43 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:09:43 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:09:43 --> Utf8 Class Initialized
INFO - 2020-08-18 07:09:43 --> URI Class Initialized
DEBUG - 2020-08-18 07:09:43 --> No URI present. Default controller set.
INFO - 2020-08-18 07:09:43 --> Router Class Initialized
INFO - 2020-08-18 07:09:43 --> Output Class Initialized
INFO - 2020-08-18 07:09:43 --> Security Class Initialized
DEBUG - 2020-08-18 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:09:43 --> Input Class Initialized
INFO - 2020-08-18 07:09:43 --> Language Class Initialized
INFO - 2020-08-18 07:09:43 --> Loader Class Initialized
INFO - 2020-08-18 07:09:43 --> Helper loaded: url_helper
INFO - 2020-08-18 07:09:43 --> Database Driver Class Initialized
INFO - 2020-08-18 07:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:09:43 --> Email Class Initialized
INFO - 2020-08-18 07:09:43 --> Controller Class Initialized
INFO - 2020-08-18 07:09:43 --> Model Class Initialized
INFO - 2020-08-18 07:09:43 --> Model Class Initialized
DEBUG - 2020-08-18 07:09:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:09:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:09:43 --> Final output sent to browser
DEBUG - 2020-08-18 07:09:43 --> Total execution time: 0.0245
INFO - 2020-08-18 07:10:11 --> Config Class Initialized
INFO - 2020-08-18 07:10:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:11 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:11 --> URI Class Initialized
INFO - 2020-08-18 07:10:11 --> Router Class Initialized
INFO - 2020-08-18 07:10:11 --> Output Class Initialized
INFO - 2020-08-18 07:10:11 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:11 --> Input Class Initialized
INFO - 2020-08-18 07:10:11 --> Language Class Initialized
INFO - 2020-08-18 07:10:11 --> Loader Class Initialized
INFO - 2020-08-18 07:10:11 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:11 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:11 --> Email Class Initialized
INFO - 2020-08-18 07:10:11 --> Controller Class Initialized
INFO - 2020-08-18 07:10:11 --> Model Class Initialized
INFO - 2020-08-18 07:10:11 --> Model Class Initialized
DEBUG - 2020-08-18 07:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:11 --> Config Class Initialized
INFO - 2020-08-18 07:10:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:11 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:11 --> URI Class Initialized
INFO - 2020-08-18 07:10:11 --> Router Class Initialized
INFO - 2020-08-18 07:10:11 --> Output Class Initialized
INFO - 2020-08-18 07:10:11 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:11 --> Input Class Initialized
INFO - 2020-08-18 07:10:11 --> Language Class Initialized
INFO - 2020-08-18 07:10:11 --> Loader Class Initialized
INFO - 2020-08-18 07:10:11 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:11 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:11 --> Email Class Initialized
INFO - 2020-08-18 07:10:11 --> Controller Class Initialized
INFO - 2020-08-18 07:10:11 --> Model Class Initialized
INFO - 2020-08-18 07:10:11 --> Model Class Initialized
DEBUG - 2020-08-18 07:10:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:10:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:11 --> Config Class Initialized
INFO - 2020-08-18 07:10:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:11 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:11 --> URI Class Initialized
DEBUG - 2020-08-18 07:10:11 --> No URI present. Default controller set.
INFO - 2020-08-18 07:10:11 --> Router Class Initialized
INFO - 2020-08-18 07:10:11 --> Output Class Initialized
INFO - 2020-08-18 07:10:11 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:11 --> Input Class Initialized
INFO - 2020-08-18 07:10:11 --> Language Class Initialized
INFO - 2020-08-18 07:10:11 --> Loader Class Initialized
INFO - 2020-08-18 07:10:11 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:11 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:11 --> Email Class Initialized
INFO - 2020-08-18 07:10:11 --> Controller Class Initialized
INFO - 2020-08-18 07:10:11 --> Model Class Initialized
INFO - 2020-08-18 07:10:11 --> Model Class Initialized
DEBUG - 2020-08-18 07:10:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:10:11 --> Final output sent to browser
DEBUG - 2020-08-18 07:10:11 --> Total execution time: 0.0291
INFO - 2020-08-18 07:10:12 --> Config Class Initialized
INFO - 2020-08-18 07:10:12 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:12 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:12 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:12 --> URI Class Initialized
DEBUG - 2020-08-18 07:10:12 --> No URI present. Default controller set.
INFO - 2020-08-18 07:10:12 --> Router Class Initialized
INFO - 2020-08-18 07:10:12 --> Output Class Initialized
INFO - 2020-08-18 07:10:12 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:12 --> Input Class Initialized
INFO - 2020-08-18 07:10:12 --> Language Class Initialized
INFO - 2020-08-18 07:10:12 --> Loader Class Initialized
INFO - 2020-08-18 07:10:12 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:12 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:12 --> Email Class Initialized
INFO - 2020-08-18 07:10:12 --> Controller Class Initialized
INFO - 2020-08-18 07:10:12 --> Model Class Initialized
INFO - 2020-08-18 07:10:12 --> Model Class Initialized
DEBUG - 2020-08-18 07:10:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:10:12 --> Final output sent to browser
DEBUG - 2020-08-18 07:10:12 --> Total execution time: 0.0228
INFO - 2020-08-18 07:10:37 --> Config Class Initialized
INFO - 2020-08-18 07:10:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:37 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:37 --> URI Class Initialized
INFO - 2020-08-18 07:10:37 --> Router Class Initialized
INFO - 2020-08-18 07:10:37 --> Output Class Initialized
INFO - 2020-08-18 07:10:37 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:37 --> Input Class Initialized
INFO - 2020-08-18 07:10:37 --> Language Class Initialized
INFO - 2020-08-18 07:10:37 --> Loader Class Initialized
INFO - 2020-08-18 07:10:37 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:37 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:37 --> Email Class Initialized
INFO - 2020-08-18 07:10:37 --> Controller Class Initialized
INFO - 2020-08-18 07:10:37 --> Model Class Initialized
INFO - 2020-08-18 07:10:37 --> Model Class Initialized
DEBUG - 2020-08-18 07:10:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:37 --> Config Class Initialized
INFO - 2020-08-18 07:10:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:37 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:37 --> URI Class Initialized
INFO - 2020-08-18 07:10:37 --> Router Class Initialized
INFO - 2020-08-18 07:10:37 --> Output Class Initialized
INFO - 2020-08-18 07:10:37 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:37 --> Input Class Initialized
INFO - 2020-08-18 07:10:37 --> Language Class Initialized
INFO - 2020-08-18 07:10:37 --> Loader Class Initialized
INFO - 2020-08-18 07:10:37 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:37 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:37 --> Email Class Initialized
INFO - 2020-08-18 07:10:37 --> Controller Class Initialized
INFO - 2020-08-18 07:10:37 --> Model Class Initialized
INFO - 2020-08-18 07:10:37 --> Model Class Initialized
DEBUG - 2020-08-18 07:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:10:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:37 --> Model Class Initialized
INFO - 2020-08-18 07:10:37 --> Final output sent to browser
DEBUG - 2020-08-18 07:10:37 --> Total execution time: 0.0241
INFO - 2020-08-18 07:10:37 --> Config Class Initialized
INFO - 2020-08-18 07:10:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:10:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:10:37 --> Utf8 Class Initialized
INFO - 2020-08-18 07:10:37 --> URI Class Initialized
INFO - 2020-08-18 07:10:37 --> Router Class Initialized
INFO - 2020-08-18 07:10:37 --> Output Class Initialized
INFO - 2020-08-18 07:10:37 --> Security Class Initialized
DEBUG - 2020-08-18 07:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:10:37 --> Input Class Initialized
INFO - 2020-08-18 07:10:37 --> Language Class Initialized
INFO - 2020-08-18 07:10:37 --> Loader Class Initialized
INFO - 2020-08-18 07:10:37 --> Helper loaded: url_helper
INFO - 2020-08-18 07:10:37 --> Database Driver Class Initialized
INFO - 2020-08-18 07:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:10:37 --> Email Class Initialized
INFO - 2020-08-18 07:10:37 --> Controller Class Initialized
DEBUG - 2020-08-18 07:10:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:10:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:10:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:10:37 --> Final output sent to browser
DEBUG - 2020-08-18 07:10:37 --> Total execution time: 0.0398
INFO - 2020-08-18 07:11:13 --> Config Class Initialized
INFO - 2020-08-18 07:11:13 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:11:13 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:11:13 --> Utf8 Class Initialized
INFO - 2020-08-18 07:11:13 --> URI Class Initialized
INFO - 2020-08-18 07:11:13 --> Router Class Initialized
INFO - 2020-08-18 07:11:13 --> Output Class Initialized
INFO - 2020-08-18 07:11:13 --> Security Class Initialized
DEBUG - 2020-08-18 07:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:11:13 --> Input Class Initialized
INFO - 2020-08-18 07:11:13 --> Language Class Initialized
INFO - 2020-08-18 07:11:13 --> Loader Class Initialized
INFO - 2020-08-18 07:11:13 --> Helper loaded: url_helper
INFO - 2020-08-18 07:11:13 --> Database Driver Class Initialized
INFO - 2020-08-18 07:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:11:13 --> Email Class Initialized
INFO - 2020-08-18 07:11:13 --> Controller Class Initialized
DEBUG - 2020-08-18 07:11:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:11:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:11:13 --> Model Class Initialized
INFO - 2020-08-18 07:11:13 --> Model Class Initialized
INFO - 2020-08-18 07:11:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:11:14 --> Final output sent to browser
DEBUG - 2020-08-18 07:11:14 --> Total execution time: 0.4631
INFO - 2020-08-18 07:11:20 --> Config Class Initialized
INFO - 2020-08-18 07:11:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:11:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:11:20 --> Utf8 Class Initialized
INFO - 2020-08-18 07:11:20 --> URI Class Initialized
INFO - 2020-08-18 07:11:20 --> Router Class Initialized
INFO - 2020-08-18 07:11:20 --> Output Class Initialized
INFO - 2020-08-18 07:11:20 --> Security Class Initialized
DEBUG - 2020-08-18 07:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:11:20 --> Input Class Initialized
INFO - 2020-08-18 07:11:20 --> Language Class Initialized
INFO - 2020-08-18 07:11:20 --> Loader Class Initialized
INFO - 2020-08-18 07:11:20 --> Helper loaded: url_helper
INFO - 2020-08-18 07:11:20 --> Database Driver Class Initialized
INFO - 2020-08-18 07:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:11:20 --> Email Class Initialized
INFO - 2020-08-18 07:11:20 --> Controller Class Initialized
DEBUG - 2020-08-18 07:11:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:11:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:11:20 --> Model Class Initialized
INFO - 2020-08-18 07:11:20 --> Model Class Initialized
INFO - 2020-08-18 07:11:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-18 07:11:20 --> Final output sent to browser
DEBUG - 2020-08-18 07:11:20 --> Total execution time: 0.0357
INFO - 2020-08-18 07:11:23 --> Config Class Initialized
INFO - 2020-08-18 07:11:23 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:11:23 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:11:23 --> Utf8 Class Initialized
INFO - 2020-08-18 07:11:23 --> URI Class Initialized
INFO - 2020-08-18 07:11:23 --> Router Class Initialized
INFO - 2020-08-18 07:11:23 --> Output Class Initialized
INFO - 2020-08-18 07:11:23 --> Security Class Initialized
DEBUG - 2020-08-18 07:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:11:23 --> Input Class Initialized
INFO - 2020-08-18 07:11:23 --> Language Class Initialized
INFO - 2020-08-18 07:11:23 --> Loader Class Initialized
INFO - 2020-08-18 07:11:23 --> Helper loaded: url_helper
INFO - 2020-08-18 07:11:24 --> Database Driver Class Initialized
INFO - 2020-08-18 07:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:11:24 --> Email Class Initialized
INFO - 2020-08-18 07:11:24 --> Controller Class Initialized
DEBUG - 2020-08-18 07:11:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:11:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:11:24 --> Model Class Initialized
INFO - 2020-08-18 07:11:24 --> Model Class Initialized
INFO - 2020-08-18 07:11:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:11:24 --> Final output sent to browser
DEBUG - 2020-08-18 07:11:24 --> Total execution time: 0.0267
INFO - 2020-08-18 07:11:25 --> Config Class Initialized
INFO - 2020-08-18 07:11:25 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:11:25 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:11:25 --> Utf8 Class Initialized
INFO - 2020-08-18 07:11:25 --> URI Class Initialized
INFO - 2020-08-18 07:11:25 --> Router Class Initialized
INFO - 2020-08-18 07:11:25 --> Output Class Initialized
INFO - 2020-08-18 07:11:25 --> Security Class Initialized
DEBUG - 2020-08-18 07:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:11:25 --> Input Class Initialized
INFO - 2020-08-18 07:11:25 --> Language Class Initialized
INFO - 2020-08-18 07:11:25 --> Loader Class Initialized
INFO - 2020-08-18 07:11:25 --> Helper loaded: url_helper
INFO - 2020-08-18 07:11:25 --> Database Driver Class Initialized
INFO - 2020-08-18 07:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:11:25 --> Email Class Initialized
INFO - 2020-08-18 07:11:25 --> Controller Class Initialized
DEBUG - 2020-08-18 07:11:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:11:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:11:25 --> Model Class Initialized
INFO - 2020-08-18 07:11:25 --> Model Class Initialized
INFO - 2020-08-18 07:11:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 07:11:25 --> Final output sent to browser
DEBUG - 2020-08-18 07:11:25 --> Total execution time: 0.0402
INFO - 2020-08-18 07:11:29 --> Config Class Initialized
INFO - 2020-08-18 07:11:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:11:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:11:29 --> Utf8 Class Initialized
INFO - 2020-08-18 07:11:29 --> URI Class Initialized
INFO - 2020-08-18 07:11:29 --> Router Class Initialized
INFO - 2020-08-18 07:11:29 --> Output Class Initialized
INFO - 2020-08-18 07:11:29 --> Security Class Initialized
DEBUG - 2020-08-18 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:11:29 --> Input Class Initialized
INFO - 2020-08-18 07:11:29 --> Language Class Initialized
INFO - 2020-08-18 07:11:29 --> Loader Class Initialized
INFO - 2020-08-18 07:11:29 --> Helper loaded: url_helper
INFO - 2020-08-18 07:11:29 --> Database Driver Class Initialized
INFO - 2020-08-18 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:11:29 --> Email Class Initialized
INFO - 2020-08-18 07:11:29 --> Controller Class Initialized
DEBUG - 2020-08-18 07:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:11:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:11:29 --> Model Class Initialized
INFO - 2020-08-18 07:11:29 --> Model Class Initialized
INFO - 2020-08-18 07:11:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:11:29 --> Final output sent to browser
DEBUG - 2020-08-18 07:11:29 --> Total execution time: 0.0310
INFO - 2020-08-18 07:11:48 --> Config Class Initialized
INFO - 2020-08-18 07:11:48 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:11:48 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:11:48 --> Utf8 Class Initialized
INFO - 2020-08-18 07:11:48 --> URI Class Initialized
INFO - 2020-08-18 07:11:48 --> Router Class Initialized
INFO - 2020-08-18 07:11:48 --> Output Class Initialized
INFO - 2020-08-18 07:11:48 --> Security Class Initialized
DEBUG - 2020-08-18 07:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:11:48 --> Input Class Initialized
INFO - 2020-08-18 07:11:48 --> Language Class Initialized
INFO - 2020-08-18 07:11:48 --> Loader Class Initialized
INFO - 2020-08-18 07:11:48 --> Helper loaded: url_helper
INFO - 2020-08-18 07:11:48 --> Database Driver Class Initialized
INFO - 2020-08-18 07:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:11:48 --> Email Class Initialized
INFO - 2020-08-18 07:11:48 --> Controller Class Initialized
DEBUG - 2020-08-18 07:11:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:11:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:11:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:11:48 --> Final output sent to browser
DEBUG - 2020-08-18 07:11:48 --> Total execution time: 0.0237
INFO - 2020-08-18 07:12:48 --> Config Class Initialized
INFO - 2020-08-18 07:12:48 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:12:48 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:12:48 --> Utf8 Class Initialized
INFO - 2020-08-18 07:12:48 --> URI Class Initialized
INFO - 2020-08-18 07:12:48 --> Router Class Initialized
INFO - 2020-08-18 07:12:48 --> Output Class Initialized
INFO - 2020-08-18 07:12:48 --> Security Class Initialized
DEBUG - 2020-08-18 07:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:12:48 --> Input Class Initialized
INFO - 2020-08-18 07:12:48 --> Language Class Initialized
INFO - 2020-08-18 07:12:48 --> Loader Class Initialized
INFO - 2020-08-18 07:12:48 --> Helper loaded: url_helper
INFO - 2020-08-18 07:12:48 --> Database Driver Class Initialized
INFO - 2020-08-18 07:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:12:48 --> Email Class Initialized
INFO - 2020-08-18 07:12:48 --> Controller Class Initialized
DEBUG - 2020-08-18 07:12:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:12:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:12:48 --> Model Class Initialized
INFO - 2020-08-18 07:12:48 --> Model Class Initialized
INFO - 2020-08-18 07:12:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:12:48 --> Final output sent to browser
DEBUG - 2020-08-18 07:12:48 --> Total execution time: 0.0264
INFO - 2020-08-18 07:12:52 --> Config Class Initialized
INFO - 2020-08-18 07:12:52 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:12:52 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:12:52 --> Utf8 Class Initialized
INFO - 2020-08-18 07:12:52 --> URI Class Initialized
DEBUG - 2020-08-18 07:12:52 --> No URI present. Default controller set.
INFO - 2020-08-18 07:12:52 --> Router Class Initialized
INFO - 2020-08-18 07:12:52 --> Output Class Initialized
INFO - 2020-08-18 07:12:52 --> Security Class Initialized
DEBUG - 2020-08-18 07:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:12:52 --> Input Class Initialized
INFO - 2020-08-18 07:12:52 --> Language Class Initialized
INFO - 2020-08-18 07:12:52 --> Loader Class Initialized
INFO - 2020-08-18 07:12:52 --> Helper loaded: url_helper
INFO - 2020-08-18 07:12:52 --> Database Driver Class Initialized
INFO - 2020-08-18 07:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:12:52 --> Email Class Initialized
INFO - 2020-08-18 07:12:52 --> Controller Class Initialized
INFO - 2020-08-18 07:12:52 --> Model Class Initialized
INFO - 2020-08-18 07:12:52 --> Model Class Initialized
DEBUG - 2020-08-18 07:12:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:12:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:12:52 --> Final output sent to browser
DEBUG - 2020-08-18 07:12:52 --> Total execution time: 0.0270
INFO - 2020-08-18 07:13:04 --> Config Class Initialized
INFO - 2020-08-18 07:13:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:04 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:04 --> URI Class Initialized
INFO - 2020-08-18 07:13:04 --> Router Class Initialized
INFO - 2020-08-18 07:13:04 --> Output Class Initialized
INFO - 2020-08-18 07:13:04 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:04 --> Input Class Initialized
INFO - 2020-08-18 07:13:04 --> Language Class Initialized
INFO - 2020-08-18 07:13:04 --> Loader Class Initialized
INFO - 2020-08-18 07:13:04 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:04 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:04 --> Email Class Initialized
INFO - 2020-08-18 07:13:04 --> Controller Class Initialized
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
INFO - 2020-08-18 07:13:04 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:04 --> Total execution time: 0.0319
INFO - 2020-08-18 07:13:04 --> Config Class Initialized
INFO - 2020-08-18 07:13:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:04 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:04 --> URI Class Initialized
INFO - 2020-08-18 07:13:04 --> Router Class Initialized
INFO - 2020-08-18 07:13:04 --> Output Class Initialized
INFO - 2020-08-18 07:13:04 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:04 --> Input Class Initialized
INFO - 2020-08-18 07:13:04 --> Language Class Initialized
INFO - 2020-08-18 07:13:04 --> Loader Class Initialized
INFO - 2020-08-18 07:13:04 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:04 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:04 --> Email Class Initialized
INFO - 2020-08-18 07:13:04 --> Controller Class Initialized
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:04 --> Config Class Initialized
INFO - 2020-08-18 07:13:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:04 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:04 --> URI Class Initialized
DEBUG - 2020-08-18 07:13:04 --> No URI present. Default controller set.
INFO - 2020-08-18 07:13:04 --> Router Class Initialized
INFO - 2020-08-18 07:13:04 --> Output Class Initialized
INFO - 2020-08-18 07:13:04 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:04 --> Input Class Initialized
INFO - 2020-08-18 07:13:04 --> Language Class Initialized
INFO - 2020-08-18 07:13:04 --> Loader Class Initialized
INFO - 2020-08-18 07:13:04 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:04 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:04 --> Email Class Initialized
INFO - 2020-08-18 07:13:04 --> Controller Class Initialized
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
INFO - 2020-08-18 07:13:04 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:13:04 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:04 --> Total execution time: 0.0208
INFO - 2020-08-18 07:13:13 --> Config Class Initialized
INFO - 2020-08-18 07:13:13 --> Hooks Class Initialized
INFO - 2020-08-18 07:13:13 --> Config Class Initialized
INFO - 2020-08-18 07:13:13 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:13 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:13 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:13 --> URI Class Initialized
DEBUG - 2020-08-18 07:13:13 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:13 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:13 --> Router Class Initialized
INFO - 2020-08-18 07:13:13 --> URI Class Initialized
INFO - 2020-08-18 07:13:13 --> Output Class Initialized
INFO - 2020-08-18 07:13:13 --> Router Class Initialized
INFO - 2020-08-18 07:13:13 --> Security Class Initialized
INFO - 2020-08-18 07:13:13 --> Output Class Initialized
DEBUG - 2020-08-18 07:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:13 --> Input Class Initialized
INFO - 2020-08-18 07:13:13 --> Language Class Initialized
INFO - 2020-08-18 07:13:13 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:13 --> Input Class Initialized
INFO - 2020-08-18 07:13:13 --> Language Class Initialized
INFO - 2020-08-18 07:13:13 --> Loader Class Initialized
INFO - 2020-08-18 07:13:13 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:13 --> Loader Class Initialized
INFO - 2020-08-18 07:13:13 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:13 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:13 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:13 --> Email Class Initialized
INFO - 2020-08-18 07:13:13 --> Controller Class Initialized
INFO - 2020-08-18 07:13:13 --> Model Class Initialized
INFO - 2020-08-18 07:13:13 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:13 --> Model Class Initialized
INFO - 2020-08-18 07:13:13 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:13 --> Total execution time: 0.0262
INFO - 2020-08-18 07:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:13 --> Email Class Initialized
INFO - 2020-08-18 07:13:13 --> Controller Class Initialized
INFO - 2020-08-18 07:13:13 --> Model Class Initialized
INFO - 2020-08-18 07:13:13 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:14 --> Config Class Initialized
INFO - 2020-08-18 07:13:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:14 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:14 --> URI Class Initialized
INFO - 2020-08-18 07:13:14 --> Router Class Initialized
INFO - 2020-08-18 07:13:14 --> Output Class Initialized
INFO - 2020-08-18 07:13:14 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:14 --> Input Class Initialized
INFO - 2020-08-18 07:13:14 --> Language Class Initialized
INFO - 2020-08-18 07:13:14 --> Loader Class Initialized
INFO - 2020-08-18 07:13:14 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:14 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:14 --> Email Class Initialized
INFO - 2020-08-18 07:13:14 --> Controller Class Initialized
DEBUG - 2020-08-18 07:13:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:13:14 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:14 --> Total execution time: 0.0225
INFO - 2020-08-18 07:13:21 --> Config Class Initialized
INFO - 2020-08-18 07:13:21 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:21 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:21 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:21 --> URI Class Initialized
DEBUG - 2020-08-18 07:13:21 --> No URI present. Default controller set.
INFO - 2020-08-18 07:13:21 --> Router Class Initialized
INFO - 2020-08-18 07:13:21 --> Output Class Initialized
INFO - 2020-08-18 07:13:21 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:21 --> Input Class Initialized
INFO - 2020-08-18 07:13:21 --> Language Class Initialized
INFO - 2020-08-18 07:13:21 --> Loader Class Initialized
INFO - 2020-08-18 07:13:21 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:21 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:21 --> Email Class Initialized
INFO - 2020-08-18 07:13:21 --> Controller Class Initialized
INFO - 2020-08-18 07:13:21 --> Model Class Initialized
INFO - 2020-08-18 07:13:21 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:13:21 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:21 --> Total execution time: 0.0214
INFO - 2020-08-18 07:13:29 --> Config Class Initialized
INFO - 2020-08-18 07:13:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:29 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:29 --> Config Class Initialized
INFO - 2020-08-18 07:13:29 --> Hooks Class Initialized
INFO - 2020-08-18 07:13:29 --> URI Class Initialized
INFO - 2020-08-18 07:13:29 --> Router Class Initialized
DEBUG - 2020-08-18 07:13:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:29 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:29 --> Output Class Initialized
INFO - 2020-08-18 07:13:29 --> URI Class Initialized
INFO - 2020-08-18 07:13:29 --> Security Class Initialized
INFO - 2020-08-18 07:13:29 --> Router Class Initialized
DEBUG - 2020-08-18 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:29 --> Input Class Initialized
INFO - 2020-08-18 07:13:29 --> Language Class Initialized
INFO - 2020-08-18 07:13:29 --> Output Class Initialized
INFO - 2020-08-18 07:13:29 --> Loader Class Initialized
INFO - 2020-08-18 07:13:29 --> Security Class Initialized
INFO - 2020-08-18 07:13:29 --> Helper loaded: url_helper
DEBUG - 2020-08-18 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:29 --> Input Class Initialized
INFO - 2020-08-18 07:13:29 --> Language Class Initialized
INFO - 2020-08-18 07:13:29 --> Loader Class Initialized
INFO - 2020-08-18 07:13:29 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:29 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:29 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:29 --> Email Class Initialized
INFO - 2020-08-18 07:13:29 --> Controller Class Initialized
INFO - 2020-08-18 07:13:29 --> Model Class Initialized
INFO - 2020-08-18 07:13:29 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:29 --> Model Class Initialized
INFO - 2020-08-18 07:13:29 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:29 --> Total execution time: 0.0211
INFO - 2020-08-18 07:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:29 --> Email Class Initialized
INFO - 2020-08-18 07:13:29 --> Controller Class Initialized
INFO - 2020-08-18 07:13:29 --> Model Class Initialized
INFO - 2020-08-18 07:13:29 --> Model Class Initialized
DEBUG - 2020-08-18 07:13:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:29 --> Config Class Initialized
INFO - 2020-08-18 07:13:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:29 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:29 --> URI Class Initialized
INFO - 2020-08-18 07:13:29 --> Router Class Initialized
INFO - 2020-08-18 07:13:29 --> Output Class Initialized
INFO - 2020-08-18 07:13:29 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:29 --> Input Class Initialized
INFO - 2020-08-18 07:13:29 --> Language Class Initialized
INFO - 2020-08-18 07:13:29 --> Loader Class Initialized
INFO - 2020-08-18 07:13:29 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:29 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:29 --> Email Class Initialized
INFO - 2020-08-18 07:13:29 --> Controller Class Initialized
DEBUG - 2020-08-18 07:13:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:13:29 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:29 --> Total execution time: 0.0230
INFO - 2020-08-18 07:13:39 --> Config Class Initialized
INFO - 2020-08-18 07:13:39 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:39 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:39 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:39 --> URI Class Initialized
INFO - 2020-08-18 07:13:39 --> Router Class Initialized
INFO - 2020-08-18 07:13:39 --> Output Class Initialized
INFO - 2020-08-18 07:13:39 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:39 --> Input Class Initialized
INFO - 2020-08-18 07:13:39 --> Language Class Initialized
INFO - 2020-08-18 07:13:39 --> Loader Class Initialized
INFO - 2020-08-18 07:13:39 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:39 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:39 --> Email Class Initialized
INFO - 2020-08-18 07:13:39 --> Controller Class Initialized
DEBUG - 2020-08-18 07:13:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:39 --> Model Class Initialized
INFO - 2020-08-18 07:13:39 --> Model Class Initialized
INFO - 2020-08-18 07:13:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:13:39 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:39 --> Total execution time: 0.0352
INFO - 2020-08-18 07:13:51 --> Config Class Initialized
INFO - 2020-08-18 07:13:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:51 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:51 --> URI Class Initialized
INFO - 2020-08-18 07:13:51 --> Router Class Initialized
INFO - 2020-08-18 07:13:51 --> Output Class Initialized
INFO - 2020-08-18 07:13:51 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:51 --> Input Class Initialized
INFO - 2020-08-18 07:13:51 --> Language Class Initialized
INFO - 2020-08-18 07:13:51 --> Loader Class Initialized
INFO - 2020-08-18 07:13:51 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:51 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:51 --> Email Class Initialized
INFO - 2020-08-18 07:13:51 --> Controller Class Initialized
DEBUG - 2020-08-18 07:13:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:51 --> Model Class Initialized
INFO - 2020-08-18 07:13:51 --> Model Class Initialized
INFO - 2020-08-18 07:13:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 07:13:51 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:51 --> Total execution time: 0.0275
INFO - 2020-08-18 07:13:55 --> Config Class Initialized
INFO - 2020-08-18 07:13:55 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:13:55 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:13:55 --> Utf8 Class Initialized
INFO - 2020-08-18 07:13:55 --> URI Class Initialized
INFO - 2020-08-18 07:13:55 --> Router Class Initialized
INFO - 2020-08-18 07:13:55 --> Output Class Initialized
INFO - 2020-08-18 07:13:55 --> Security Class Initialized
DEBUG - 2020-08-18 07:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:13:55 --> Input Class Initialized
INFO - 2020-08-18 07:13:55 --> Language Class Initialized
INFO - 2020-08-18 07:13:55 --> Loader Class Initialized
INFO - 2020-08-18 07:13:55 --> Helper loaded: url_helper
INFO - 2020-08-18 07:13:55 --> Database Driver Class Initialized
INFO - 2020-08-18 07:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:13:55 --> Email Class Initialized
INFO - 2020-08-18 07:13:55 --> Controller Class Initialized
DEBUG - 2020-08-18 07:13:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:13:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:13:55 --> Model Class Initialized
INFO - 2020-08-18 07:13:55 --> Model Class Initialized
INFO - 2020-08-18 07:13:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:13:55 --> Final output sent to browser
DEBUG - 2020-08-18 07:13:55 --> Total execution time: 0.0235
INFO - 2020-08-18 07:14:36 --> Config Class Initialized
INFO - 2020-08-18 07:14:36 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:14:36 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:14:36 --> Utf8 Class Initialized
INFO - 2020-08-18 07:14:36 --> URI Class Initialized
INFO - 2020-08-18 07:14:36 --> Router Class Initialized
INFO - 2020-08-18 07:14:36 --> Output Class Initialized
INFO - 2020-08-18 07:14:36 --> Security Class Initialized
DEBUG - 2020-08-18 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:14:36 --> Input Class Initialized
INFO - 2020-08-18 07:14:36 --> Language Class Initialized
INFO - 2020-08-18 07:14:36 --> Loader Class Initialized
INFO - 2020-08-18 07:14:36 --> Helper loaded: url_helper
INFO - 2020-08-18 07:14:36 --> Database Driver Class Initialized
INFO - 2020-08-18 07:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:14:36 --> Email Class Initialized
INFO - 2020-08-18 07:14:36 --> Controller Class Initialized
DEBUG - 2020-08-18 07:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:14:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:14:36 --> Model Class Initialized
INFO - 2020-08-18 07:14:36 --> Model Class Initialized
INFO - 2020-08-18 07:14:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 07:14:36 --> Final output sent to browser
DEBUG - 2020-08-18 07:14:36 --> Total execution time: 0.0507
INFO - 2020-08-18 07:14:48 --> Config Class Initialized
INFO - 2020-08-18 07:14:48 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:14:48 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:14:48 --> Utf8 Class Initialized
INFO - 2020-08-18 07:14:48 --> URI Class Initialized
INFO - 2020-08-18 07:14:48 --> Router Class Initialized
INFO - 2020-08-18 07:14:48 --> Output Class Initialized
INFO - 2020-08-18 07:14:48 --> Security Class Initialized
DEBUG - 2020-08-18 07:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:14:48 --> Input Class Initialized
INFO - 2020-08-18 07:14:48 --> Language Class Initialized
INFO - 2020-08-18 07:14:48 --> Loader Class Initialized
INFO - 2020-08-18 07:14:48 --> Helper loaded: url_helper
INFO - 2020-08-18 07:14:48 --> Database Driver Class Initialized
INFO - 2020-08-18 07:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:14:48 --> Email Class Initialized
INFO - 2020-08-18 07:14:48 --> Controller Class Initialized
DEBUG - 2020-08-18 07:14:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:14:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:14:48 --> Model Class Initialized
INFO - 2020-08-18 07:14:48 --> Model Class Initialized
INFO - 2020-08-18 07:14:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-18 07:14:48 --> Final output sent to browser
DEBUG - 2020-08-18 07:14:48 --> Total execution time: 0.0311
INFO - 2020-08-18 07:14:59 --> Config Class Initialized
INFO - 2020-08-18 07:14:59 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:14:59 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:14:59 --> Utf8 Class Initialized
INFO - 2020-08-18 07:14:59 --> URI Class Initialized
INFO - 2020-08-18 07:14:59 --> Router Class Initialized
INFO - 2020-08-18 07:14:59 --> Output Class Initialized
INFO - 2020-08-18 07:14:59 --> Security Class Initialized
DEBUG - 2020-08-18 07:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:14:59 --> Input Class Initialized
INFO - 2020-08-18 07:14:59 --> Language Class Initialized
INFO - 2020-08-18 07:14:59 --> Loader Class Initialized
INFO - 2020-08-18 07:14:59 --> Helper loaded: url_helper
INFO - 2020-08-18 07:14:59 --> Database Driver Class Initialized
INFO - 2020-08-18 07:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:14:59 --> Email Class Initialized
INFO - 2020-08-18 07:14:59 --> Controller Class Initialized
DEBUG - 2020-08-18 07:14:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:14:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:14:59 --> Model Class Initialized
INFO - 2020-08-18 07:14:59 --> Model Class Initialized
INFO - 2020-08-18 07:14:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 07:14:59 --> Final output sent to browser
DEBUG - 2020-08-18 07:14:59 --> Total execution time: 0.0244
INFO - 2020-08-18 07:15:02 --> Config Class Initialized
INFO - 2020-08-18 07:15:02 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:02 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:02 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:02 --> URI Class Initialized
INFO - 2020-08-18 07:15:02 --> Router Class Initialized
INFO - 2020-08-18 07:15:02 --> Output Class Initialized
INFO - 2020-08-18 07:15:02 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:02 --> Input Class Initialized
INFO - 2020-08-18 07:15:02 --> Language Class Initialized
INFO - 2020-08-18 07:15:02 --> Loader Class Initialized
INFO - 2020-08-18 07:15:02 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:02 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:02 --> Email Class Initialized
INFO - 2020-08-18 07:15:02 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:02 --> Model Class Initialized
INFO - 2020-08-18 07:15:02 --> Model Class Initialized
INFO - 2020-08-18 07:15:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-18 07:15:02 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:02 --> Total execution time: 0.0208
INFO - 2020-08-18 07:15:04 --> Config Class Initialized
INFO - 2020-08-18 07:15:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:04 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:04 --> URI Class Initialized
INFO - 2020-08-18 07:15:04 --> Router Class Initialized
INFO - 2020-08-18 07:15:04 --> Output Class Initialized
INFO - 2020-08-18 07:15:04 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:04 --> Input Class Initialized
INFO - 2020-08-18 07:15:04 --> Language Class Initialized
INFO - 2020-08-18 07:15:04 --> Loader Class Initialized
INFO - 2020-08-18 07:15:04 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:04 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:04 --> Email Class Initialized
INFO - 2020-08-18 07:15:04 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:04 --> Model Class Initialized
INFO - 2020-08-18 07:15:04 --> Model Class Initialized
INFO - 2020-08-18 07:15:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 07:15:04 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:04 --> Total execution time: 0.0229
INFO - 2020-08-18 07:15:06 --> Config Class Initialized
INFO - 2020-08-18 07:15:06 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:06 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:06 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:06 --> URI Class Initialized
INFO - 2020-08-18 07:15:06 --> Router Class Initialized
INFO - 2020-08-18 07:15:06 --> Output Class Initialized
INFO - 2020-08-18 07:15:06 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:06 --> Input Class Initialized
INFO - 2020-08-18 07:15:06 --> Language Class Initialized
INFO - 2020-08-18 07:15:06 --> Loader Class Initialized
INFO - 2020-08-18 07:15:06 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:06 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:06 --> Email Class Initialized
INFO - 2020-08-18 07:15:06 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 07:15:06 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:06 --> Total execution time: 0.0405
INFO - 2020-08-18 07:15:18 --> Config Class Initialized
INFO - 2020-08-18 07:15:18 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:18 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:18 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:18 --> URI Class Initialized
INFO - 2020-08-18 07:15:18 --> Router Class Initialized
INFO - 2020-08-18 07:15:18 --> Output Class Initialized
INFO - 2020-08-18 07:15:18 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:18 --> Input Class Initialized
INFO - 2020-08-18 07:15:18 --> Language Class Initialized
INFO - 2020-08-18 07:15:18 --> Loader Class Initialized
INFO - 2020-08-18 07:15:18 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:18 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:18 --> Email Class Initialized
INFO - 2020-08-18 07:15:18 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:18 --> Model Class Initialized
INFO - 2020-08-18 07:15:18 --> Model Class Initialized
INFO - 2020-08-18 07:15:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 07:15:18 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:18 --> Total execution time: 0.0272
INFO - 2020-08-18 07:15:21 --> Config Class Initialized
INFO - 2020-08-18 07:15:21 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:21 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:21 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:21 --> URI Class Initialized
INFO - 2020-08-18 07:15:21 --> Router Class Initialized
INFO - 2020-08-18 07:15:21 --> Output Class Initialized
INFO - 2020-08-18 07:15:21 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:21 --> Input Class Initialized
INFO - 2020-08-18 07:15:21 --> Language Class Initialized
INFO - 2020-08-18 07:15:21 --> Loader Class Initialized
INFO - 2020-08-18 07:15:21 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:21 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:21 --> Email Class Initialized
INFO - 2020-08-18 07:15:21 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:21 --> Model Class Initialized
INFO - 2020-08-18 07:15:21 --> Model Class Initialized
INFO - 2020-08-18 07:15:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-08-18 07:15:21 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:21 --> Total execution time: 0.0244
INFO - 2020-08-18 07:15:23 --> Config Class Initialized
INFO - 2020-08-18 07:15:23 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:23 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:23 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:23 --> URI Class Initialized
INFO - 2020-08-18 07:15:23 --> Router Class Initialized
INFO - 2020-08-18 07:15:23 --> Output Class Initialized
INFO - 2020-08-18 07:15:23 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:23 --> Input Class Initialized
INFO - 2020-08-18 07:15:23 --> Language Class Initialized
INFO - 2020-08-18 07:15:23 --> Loader Class Initialized
INFO - 2020-08-18 07:15:23 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:23 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:23 --> Email Class Initialized
INFO - 2020-08-18 07:15:23 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 07:15:23 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:23 --> Total execution time: 0.0229
INFO - 2020-08-18 07:15:29 --> Config Class Initialized
INFO - 2020-08-18 07:15:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:29 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:29 --> URI Class Initialized
INFO - 2020-08-18 07:15:29 --> Router Class Initialized
INFO - 2020-08-18 07:15:29 --> Output Class Initialized
INFO - 2020-08-18 07:15:29 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:29 --> Input Class Initialized
INFO - 2020-08-18 07:15:29 --> Language Class Initialized
INFO - 2020-08-18 07:15:29 --> Loader Class Initialized
INFO - 2020-08-18 07:15:29 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:29 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:29 --> Email Class Initialized
INFO - 2020-08-18 07:15:29 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:29 --> Model Class Initialized
INFO - 2020-08-18 07:15:29 --> Model Class Initialized
INFO - 2020-08-18 07:15:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 07:15:29 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:29 --> Total execution time: 0.0259
INFO - 2020-08-18 07:15:31 --> Config Class Initialized
INFO - 2020-08-18 07:15:31 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:31 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:31 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:31 --> URI Class Initialized
INFO - 2020-08-18 07:15:31 --> Router Class Initialized
INFO - 2020-08-18 07:15:31 --> Output Class Initialized
INFO - 2020-08-18 07:15:31 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:31 --> Input Class Initialized
INFO - 2020-08-18 07:15:31 --> Language Class Initialized
INFO - 2020-08-18 07:15:31 --> Loader Class Initialized
INFO - 2020-08-18 07:15:31 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:31 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:31 --> Email Class Initialized
INFO - 2020-08-18 07:15:31 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 07:15:31 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:31 --> Total execution time: 0.0189
INFO - 2020-08-18 07:15:38 --> Config Class Initialized
INFO - 2020-08-18 07:15:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:38 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:38 --> URI Class Initialized
INFO - 2020-08-18 07:15:38 --> Router Class Initialized
INFO - 2020-08-18 07:15:38 --> Output Class Initialized
INFO - 2020-08-18 07:15:38 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:38 --> Input Class Initialized
INFO - 2020-08-18 07:15:38 --> Language Class Initialized
INFO - 2020-08-18 07:15:38 --> Loader Class Initialized
INFO - 2020-08-18 07:15:38 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:38 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:38 --> Email Class Initialized
INFO - 2020-08-18 07:15:38 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:38 --> Model Class Initialized
INFO - 2020-08-18 07:15:38 --> Model Class Initialized
INFO - 2020-08-18 07:15:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 07:15:38 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:38 --> Total execution time: 0.0239
INFO - 2020-08-18 07:15:46 --> Config Class Initialized
INFO - 2020-08-18 07:15:46 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:46 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:46 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:46 --> URI Class Initialized
INFO - 2020-08-18 07:15:46 --> Router Class Initialized
INFO - 2020-08-18 07:15:46 --> Output Class Initialized
INFO - 2020-08-18 07:15:46 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:46 --> Input Class Initialized
INFO - 2020-08-18 07:15:46 --> Language Class Initialized
INFO - 2020-08-18 07:15:46 --> Loader Class Initialized
INFO - 2020-08-18 07:15:46 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:46 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:46 --> Email Class Initialized
INFO - 2020-08-18 07:15:46 --> Controller Class Initialized
DEBUG - 2020-08-18 07:15:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:15:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 07:15:46 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:46 --> Total execution time: 0.0211
INFO - 2020-08-18 07:15:53 --> Config Class Initialized
INFO - 2020-08-18 07:15:53 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:15:53 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:15:53 --> Utf8 Class Initialized
INFO - 2020-08-18 07:15:53 --> URI Class Initialized
DEBUG - 2020-08-18 07:15:53 --> No URI present. Default controller set.
INFO - 2020-08-18 07:15:53 --> Router Class Initialized
INFO - 2020-08-18 07:15:53 --> Output Class Initialized
INFO - 2020-08-18 07:15:53 --> Security Class Initialized
DEBUG - 2020-08-18 07:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:15:53 --> Input Class Initialized
INFO - 2020-08-18 07:15:53 --> Language Class Initialized
INFO - 2020-08-18 07:15:53 --> Loader Class Initialized
INFO - 2020-08-18 07:15:53 --> Helper loaded: url_helper
INFO - 2020-08-18 07:15:53 --> Database Driver Class Initialized
INFO - 2020-08-18 07:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:15:53 --> Email Class Initialized
INFO - 2020-08-18 07:15:53 --> Controller Class Initialized
INFO - 2020-08-18 07:15:53 --> Model Class Initialized
INFO - 2020-08-18 07:15:53 --> Model Class Initialized
DEBUG - 2020-08-18 07:15:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:15:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:15:53 --> Final output sent to browser
DEBUG - 2020-08-18 07:15:53 --> Total execution time: 0.0224
INFO - 2020-08-18 07:18:11 --> Config Class Initialized
INFO - 2020-08-18 07:18:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:11 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:11 --> URI Class Initialized
DEBUG - 2020-08-18 07:18:11 --> No URI present. Default controller set.
INFO - 2020-08-18 07:18:11 --> Router Class Initialized
INFO - 2020-08-18 07:18:11 --> Output Class Initialized
INFO - 2020-08-18 07:18:11 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:11 --> Input Class Initialized
INFO - 2020-08-18 07:18:11 --> Language Class Initialized
INFO - 2020-08-18 07:18:11 --> Loader Class Initialized
INFO - 2020-08-18 07:18:11 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:11 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:11 --> Email Class Initialized
INFO - 2020-08-18 07:18:11 --> Controller Class Initialized
INFO - 2020-08-18 07:18:11 --> Model Class Initialized
INFO - 2020-08-18 07:18:11 --> Model Class Initialized
DEBUG - 2020-08-18 07:18:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:18:11 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:11 --> Total execution time: 0.0226
INFO - 2020-08-18 07:18:22 --> Config Class Initialized
INFO - 2020-08-18 07:18:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:22 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:22 --> URI Class Initialized
INFO - 2020-08-18 07:18:22 --> Router Class Initialized
INFO - 2020-08-18 07:18:22 --> Output Class Initialized
INFO - 2020-08-18 07:18:22 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:22 --> Input Class Initialized
INFO - 2020-08-18 07:18:22 --> Language Class Initialized
INFO - 2020-08-18 07:18:22 --> Loader Class Initialized
INFO - 2020-08-18 07:18:22 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:22 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:22 --> Email Class Initialized
INFO - 2020-08-18 07:18:22 --> Controller Class Initialized
INFO - 2020-08-18 07:18:22 --> Model Class Initialized
INFO - 2020-08-18 07:18:22 --> Model Class Initialized
DEBUG - 2020-08-18 07:18:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:22 --> Config Class Initialized
INFO - 2020-08-18 07:18:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:22 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:22 --> URI Class Initialized
INFO - 2020-08-18 07:18:22 --> Router Class Initialized
INFO - 2020-08-18 07:18:22 --> Output Class Initialized
INFO - 2020-08-18 07:18:22 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:22 --> Input Class Initialized
INFO - 2020-08-18 07:18:22 --> Language Class Initialized
INFO - 2020-08-18 07:18:22 --> Loader Class Initialized
INFO - 2020-08-18 07:18:22 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:22 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:22 --> Email Class Initialized
INFO - 2020-08-18 07:18:22 --> Controller Class Initialized
INFO - 2020-08-18 07:18:22 --> Model Class Initialized
INFO - 2020-08-18 07:18:22 --> Model Class Initialized
DEBUG - 2020-08-18 07:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:22 --> Model Class Initialized
INFO - 2020-08-18 07:18:22 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:22 --> Total execution time: 0.0291
INFO - 2020-08-18 07:18:22 --> Config Class Initialized
INFO - 2020-08-18 07:18:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:22 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:22 --> URI Class Initialized
INFO - 2020-08-18 07:18:22 --> Router Class Initialized
INFO - 2020-08-18 07:18:22 --> Output Class Initialized
INFO - 2020-08-18 07:18:22 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:22 --> Input Class Initialized
INFO - 2020-08-18 07:18:22 --> Language Class Initialized
INFO - 2020-08-18 07:18:22 --> Loader Class Initialized
INFO - 2020-08-18 07:18:22 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:22 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:22 --> Email Class Initialized
INFO - 2020-08-18 07:18:22 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:18:22 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:22 --> Total execution time: 0.0230
INFO - 2020-08-18 07:18:27 --> Config Class Initialized
INFO - 2020-08-18 07:18:27 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:27 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:27 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:27 --> URI Class Initialized
INFO - 2020-08-18 07:18:27 --> Router Class Initialized
INFO - 2020-08-18 07:18:27 --> Output Class Initialized
INFO - 2020-08-18 07:18:27 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:27 --> Input Class Initialized
INFO - 2020-08-18 07:18:27 --> Language Class Initialized
INFO - 2020-08-18 07:18:27 --> Loader Class Initialized
INFO - 2020-08-18 07:18:27 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:27 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:27 --> Email Class Initialized
INFO - 2020-08-18 07:18:27 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:27 --> Model Class Initialized
INFO - 2020-08-18 07:18:27 --> Model Class Initialized
INFO - 2020-08-18 07:18:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:18:27 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:27 --> Total execution time: 0.0236
INFO - 2020-08-18 07:18:30 --> Config Class Initialized
INFO - 2020-08-18 07:18:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:30 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:30 --> URI Class Initialized
INFO - 2020-08-18 07:18:30 --> Router Class Initialized
INFO - 2020-08-18 07:18:30 --> Output Class Initialized
INFO - 2020-08-18 07:18:30 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:30 --> Input Class Initialized
INFO - 2020-08-18 07:18:30 --> Language Class Initialized
INFO - 2020-08-18 07:18:30 --> Loader Class Initialized
INFO - 2020-08-18 07:18:30 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:30 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:30 --> Email Class Initialized
INFO - 2020-08-18 07:18:30 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:18:30 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:30 --> Total execution time: 0.0238
INFO - 2020-08-18 07:18:33 --> Config Class Initialized
INFO - 2020-08-18 07:18:33 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:33 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:33 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:33 --> URI Class Initialized
INFO - 2020-08-18 07:18:33 --> Router Class Initialized
INFO - 2020-08-18 07:18:33 --> Output Class Initialized
INFO - 2020-08-18 07:18:33 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:33 --> Input Class Initialized
INFO - 2020-08-18 07:18:33 --> Language Class Initialized
INFO - 2020-08-18 07:18:33 --> Loader Class Initialized
INFO - 2020-08-18 07:18:33 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:34 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:34 --> Email Class Initialized
INFO - 2020-08-18 07:18:34 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:34 --> Model Class Initialized
INFO - 2020-08-18 07:18:34 --> Model Class Initialized
INFO - 2020-08-18 07:18:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:18:34 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:34 --> Total execution time: 0.0231
INFO - 2020-08-18 07:18:36 --> Config Class Initialized
INFO - 2020-08-18 07:18:36 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:36 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:36 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:36 --> URI Class Initialized
INFO - 2020-08-18 07:18:36 --> Router Class Initialized
INFO - 2020-08-18 07:18:36 --> Output Class Initialized
INFO - 2020-08-18 07:18:36 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:36 --> Input Class Initialized
INFO - 2020-08-18 07:18:36 --> Language Class Initialized
INFO - 2020-08-18 07:18:36 --> Loader Class Initialized
INFO - 2020-08-18 07:18:36 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:36 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:36 --> Email Class Initialized
INFO - 2020-08-18 07:18:36 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:36 --> Model Class Initialized
INFO - 2020-08-18 07:18:36 --> Model Class Initialized
INFO - 2020-08-18 07:18:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 07:18:36 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:36 --> Total execution time: 0.0258
INFO - 2020-08-18 07:18:38 --> Config Class Initialized
INFO - 2020-08-18 07:18:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:38 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:38 --> URI Class Initialized
INFO - 2020-08-18 07:18:38 --> Router Class Initialized
INFO - 2020-08-18 07:18:38 --> Output Class Initialized
INFO - 2020-08-18 07:18:38 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:38 --> Input Class Initialized
INFO - 2020-08-18 07:18:38 --> Language Class Initialized
INFO - 2020-08-18 07:18:38 --> Loader Class Initialized
INFO - 2020-08-18 07:18:38 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:38 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:38 --> Email Class Initialized
INFO - 2020-08-18 07:18:38 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:18:38 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:38 --> Total execution time: 0.0328
INFO - 2020-08-18 07:18:43 --> Config Class Initialized
INFO - 2020-08-18 07:18:43 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:43 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:43 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:43 --> URI Class Initialized
INFO - 2020-08-18 07:18:43 --> Router Class Initialized
INFO - 2020-08-18 07:18:43 --> Output Class Initialized
INFO - 2020-08-18 07:18:43 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:43 --> Input Class Initialized
INFO - 2020-08-18 07:18:43 --> Language Class Initialized
INFO - 2020-08-18 07:18:43 --> Loader Class Initialized
INFO - 2020-08-18 07:18:43 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:43 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:43 --> Email Class Initialized
INFO - 2020-08-18 07:18:43 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:43 --> Model Class Initialized
INFO - 2020-08-18 07:18:43 --> Model Class Initialized
INFO - 2020-08-18 07:18:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:18:43 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:43 --> Total execution time: 0.0242
INFO - 2020-08-18 07:18:46 --> Config Class Initialized
INFO - 2020-08-18 07:18:46 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:46 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:46 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:46 --> URI Class Initialized
INFO - 2020-08-18 07:18:46 --> Router Class Initialized
INFO - 2020-08-18 07:18:46 --> Output Class Initialized
INFO - 2020-08-18 07:18:46 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:46 --> Input Class Initialized
INFO - 2020-08-18 07:18:46 --> Language Class Initialized
INFO - 2020-08-18 07:18:46 --> Loader Class Initialized
INFO - 2020-08-18 07:18:46 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:46 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:46 --> Email Class Initialized
INFO - 2020-08-18 07:18:46 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:18:46 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:46 --> Total execution time: 0.0212
INFO - 2020-08-18 07:18:51 --> Config Class Initialized
INFO - 2020-08-18 07:18:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:51 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:51 --> URI Class Initialized
INFO - 2020-08-18 07:18:51 --> Router Class Initialized
INFO - 2020-08-18 07:18:51 --> Output Class Initialized
INFO - 2020-08-18 07:18:51 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:51 --> Input Class Initialized
INFO - 2020-08-18 07:18:51 --> Language Class Initialized
INFO - 2020-08-18 07:18:51 --> Loader Class Initialized
INFO - 2020-08-18 07:18:51 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:51 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:51 --> Email Class Initialized
INFO - 2020-08-18 07:18:51 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:51 --> Model Class Initialized
INFO - 2020-08-18 07:18:51 --> Model Class Initialized
INFO - 2020-08-18 07:18:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:18:51 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:51 --> Total execution time: 0.0274
INFO - 2020-08-18 07:18:54 --> Config Class Initialized
INFO - 2020-08-18 07:18:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:54 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:54 --> URI Class Initialized
INFO - 2020-08-18 07:18:54 --> Router Class Initialized
INFO - 2020-08-18 07:18:54 --> Output Class Initialized
INFO - 2020-08-18 07:18:54 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:54 --> Input Class Initialized
INFO - 2020-08-18 07:18:54 --> Language Class Initialized
INFO - 2020-08-18 07:18:54 --> Loader Class Initialized
INFO - 2020-08-18 07:18:54 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:54 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:54 --> Email Class Initialized
INFO - 2020-08-18 07:18:54 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:54 --> Model Class Initialized
INFO - 2020-08-18 07:18:54 --> Model Class Initialized
INFO - 2020-08-18 07:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-18 07:18:54 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:54 --> Total execution time: 0.0232
INFO - 2020-08-18 07:18:59 --> Config Class Initialized
INFO - 2020-08-18 07:18:59 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:18:59 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:18:59 --> Utf8 Class Initialized
INFO - 2020-08-18 07:18:59 --> URI Class Initialized
INFO - 2020-08-18 07:18:59 --> Router Class Initialized
INFO - 2020-08-18 07:18:59 --> Output Class Initialized
INFO - 2020-08-18 07:18:59 --> Security Class Initialized
DEBUG - 2020-08-18 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:18:59 --> Input Class Initialized
INFO - 2020-08-18 07:18:59 --> Language Class Initialized
INFO - 2020-08-18 07:18:59 --> Loader Class Initialized
INFO - 2020-08-18 07:18:59 --> Helper loaded: url_helper
INFO - 2020-08-18 07:18:59 --> Database Driver Class Initialized
INFO - 2020-08-18 07:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:18:59 --> Email Class Initialized
INFO - 2020-08-18 07:18:59 --> Controller Class Initialized
DEBUG - 2020-08-18 07:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:18:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:18:59 --> Model Class Initialized
INFO - 2020-08-18 07:18:59 --> Model Class Initialized
INFO - 2020-08-18 07:18:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:18:59 --> Final output sent to browser
DEBUG - 2020-08-18 07:18:59 --> Total execution time: 0.0232
INFO - 2020-08-18 07:19:01 --> Config Class Initialized
INFO - 2020-08-18 07:19:01 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:19:01 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:19:01 --> Utf8 Class Initialized
INFO - 2020-08-18 07:19:01 --> URI Class Initialized
INFO - 2020-08-18 07:19:01 --> Router Class Initialized
INFO - 2020-08-18 07:19:01 --> Output Class Initialized
INFO - 2020-08-18 07:19:01 --> Security Class Initialized
DEBUG - 2020-08-18 07:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:19:01 --> Input Class Initialized
INFO - 2020-08-18 07:19:01 --> Language Class Initialized
INFO - 2020-08-18 07:19:01 --> Loader Class Initialized
INFO - 2020-08-18 07:19:01 --> Helper loaded: url_helper
INFO - 2020-08-18 07:19:01 --> Database Driver Class Initialized
INFO - 2020-08-18 07:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:19:01 --> Email Class Initialized
INFO - 2020-08-18 07:19:01 --> Controller Class Initialized
DEBUG - 2020-08-18 07:19:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:19:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:19:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:19:01 --> Final output sent to browser
DEBUG - 2020-08-18 07:19:01 --> Total execution time: 0.0225
INFO - 2020-08-18 07:21:35 --> Config Class Initialized
INFO - 2020-08-18 07:21:35 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:35 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:35 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:35 --> URI Class Initialized
INFO - 2020-08-18 07:21:35 --> Router Class Initialized
INFO - 2020-08-18 07:21:35 --> Output Class Initialized
INFO - 2020-08-18 07:21:35 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:35 --> Input Class Initialized
INFO - 2020-08-18 07:21:35 --> Language Class Initialized
INFO - 2020-08-18 07:21:35 --> Loader Class Initialized
INFO - 2020-08-18 07:21:35 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:35 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:35 --> Email Class Initialized
INFO - 2020-08-18 07:21:35 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:35 --> Model Class Initialized
INFO - 2020-08-18 07:21:35 --> Model Class Initialized
INFO - 2020-08-18 07:21:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:21:35 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:35 --> Total execution time: 0.0551
INFO - 2020-08-18 07:21:37 --> Config Class Initialized
INFO - 2020-08-18 07:21:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:37 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:37 --> URI Class Initialized
INFO - 2020-08-18 07:21:38 --> Router Class Initialized
INFO - 2020-08-18 07:21:38 --> Output Class Initialized
INFO - 2020-08-18 07:21:38 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:38 --> Input Class Initialized
INFO - 2020-08-18 07:21:38 --> Language Class Initialized
INFO - 2020-08-18 07:21:38 --> Loader Class Initialized
INFO - 2020-08-18 07:21:38 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:38 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:38 --> Email Class Initialized
INFO - 2020-08-18 07:21:38 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:38 --> Model Class Initialized
INFO - 2020-08-18 07:21:38 --> Model Class Initialized
INFO - 2020-08-18 07:21:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 07:21:38 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:38 --> Total execution time: 0.0455
INFO - 2020-08-18 07:21:43 --> Config Class Initialized
INFO - 2020-08-18 07:21:43 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:43 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:43 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:43 --> URI Class Initialized
INFO - 2020-08-18 07:21:43 --> Router Class Initialized
INFO - 2020-08-18 07:21:43 --> Output Class Initialized
INFO - 2020-08-18 07:21:43 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:43 --> Input Class Initialized
INFO - 2020-08-18 07:21:43 --> Language Class Initialized
INFO - 2020-08-18 07:21:43 --> Loader Class Initialized
INFO - 2020-08-18 07:21:43 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:43 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:43 --> Email Class Initialized
INFO - 2020-08-18 07:21:43 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:43 --> Model Class Initialized
INFO - 2020-08-18 07:21:43 --> Model Class Initialized
INFO - 2020-08-18 07:21:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:21:43 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:43 --> Total execution time: 0.0325
INFO - 2020-08-18 07:21:46 --> Config Class Initialized
INFO - 2020-08-18 07:21:46 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:46 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:46 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:46 --> URI Class Initialized
INFO - 2020-08-18 07:21:46 --> Router Class Initialized
INFO - 2020-08-18 07:21:46 --> Output Class Initialized
INFO - 2020-08-18 07:21:46 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:46 --> Input Class Initialized
INFO - 2020-08-18 07:21:46 --> Language Class Initialized
INFO - 2020-08-18 07:21:46 --> Loader Class Initialized
INFO - 2020-08-18 07:21:46 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:46 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:46 --> Email Class Initialized
INFO - 2020-08-18 07:21:46 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:21:46 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:46 --> Total execution time: 0.0262
INFO - 2020-08-18 07:21:50 --> Config Class Initialized
INFO - 2020-08-18 07:21:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:50 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:50 --> URI Class Initialized
INFO - 2020-08-18 07:21:50 --> Router Class Initialized
INFO - 2020-08-18 07:21:50 --> Output Class Initialized
INFO - 2020-08-18 07:21:50 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:50 --> Input Class Initialized
INFO - 2020-08-18 07:21:50 --> Language Class Initialized
INFO - 2020-08-18 07:21:50 --> Loader Class Initialized
INFO - 2020-08-18 07:21:50 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:50 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:50 --> Email Class Initialized
INFO - 2020-08-18 07:21:50 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:50 --> Model Class Initialized
INFO - 2020-08-18 07:21:50 --> Model Class Initialized
INFO - 2020-08-18 07:21:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:21:50 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:50 --> Total execution time: 0.0247
INFO - 2020-08-18 07:21:52 --> Config Class Initialized
INFO - 2020-08-18 07:21:52 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:52 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:52 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:52 --> URI Class Initialized
INFO - 2020-08-18 07:21:52 --> Router Class Initialized
INFO - 2020-08-18 07:21:52 --> Output Class Initialized
INFO - 2020-08-18 07:21:52 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:52 --> Input Class Initialized
INFO - 2020-08-18 07:21:52 --> Language Class Initialized
INFO - 2020-08-18 07:21:53 --> Loader Class Initialized
INFO - 2020-08-18 07:21:53 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:53 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:53 --> Email Class Initialized
INFO - 2020-08-18 07:21:53 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:53 --> Model Class Initialized
INFO - 2020-08-18 07:21:53 --> Model Class Initialized
INFO - 2020-08-18 07:21:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 07:21:53 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:53 --> Total execution time: 0.0286
INFO - 2020-08-18 07:21:55 --> Config Class Initialized
INFO - 2020-08-18 07:21:55 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:21:55 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:21:55 --> Utf8 Class Initialized
INFO - 2020-08-18 07:21:55 --> URI Class Initialized
INFO - 2020-08-18 07:21:55 --> Router Class Initialized
INFO - 2020-08-18 07:21:55 --> Output Class Initialized
INFO - 2020-08-18 07:21:55 --> Security Class Initialized
DEBUG - 2020-08-18 07:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:21:55 --> Input Class Initialized
INFO - 2020-08-18 07:21:55 --> Language Class Initialized
INFO - 2020-08-18 07:21:55 --> Loader Class Initialized
INFO - 2020-08-18 07:21:55 --> Helper loaded: url_helper
INFO - 2020-08-18 07:21:55 --> Database Driver Class Initialized
INFO - 2020-08-18 07:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:21:55 --> Email Class Initialized
INFO - 2020-08-18 07:21:55 --> Controller Class Initialized
DEBUG - 2020-08-18 07:21:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:21:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:21:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:21:55 --> Final output sent to browser
DEBUG - 2020-08-18 07:21:55 --> Total execution time: 0.0251
INFO - 2020-08-18 07:22:04 --> Config Class Initialized
INFO - 2020-08-18 07:22:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:22:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:22:04 --> Utf8 Class Initialized
INFO - 2020-08-18 07:22:04 --> URI Class Initialized
INFO - 2020-08-18 07:22:04 --> Router Class Initialized
INFO - 2020-08-18 07:22:04 --> Output Class Initialized
INFO - 2020-08-18 07:22:04 --> Security Class Initialized
DEBUG - 2020-08-18 07:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:22:04 --> Input Class Initialized
INFO - 2020-08-18 07:22:04 --> Language Class Initialized
INFO - 2020-08-18 07:22:04 --> Loader Class Initialized
INFO - 2020-08-18 07:22:04 --> Helper loaded: url_helper
INFO - 2020-08-18 07:22:04 --> Database Driver Class Initialized
INFO - 2020-08-18 07:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:22:04 --> Email Class Initialized
INFO - 2020-08-18 07:22:04 --> Controller Class Initialized
DEBUG - 2020-08-18 07:22:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:22:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:22:04 --> Model Class Initialized
INFO - 2020-08-18 07:22:04 --> Model Class Initialized
INFO - 2020-08-18 07:22:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 07:22:04 --> Final output sent to browser
DEBUG - 2020-08-18 07:22:04 --> Total execution time: 0.0258
INFO - 2020-08-18 07:22:06 --> Config Class Initialized
INFO - 2020-08-18 07:22:06 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:22:06 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:22:06 --> Utf8 Class Initialized
INFO - 2020-08-18 07:22:06 --> URI Class Initialized
INFO - 2020-08-18 07:22:06 --> Router Class Initialized
INFO - 2020-08-18 07:22:06 --> Output Class Initialized
INFO - 2020-08-18 07:22:06 --> Security Class Initialized
DEBUG - 2020-08-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:22:06 --> Input Class Initialized
INFO - 2020-08-18 07:22:06 --> Language Class Initialized
INFO - 2020-08-18 07:22:06 --> Loader Class Initialized
INFO - 2020-08-18 07:22:06 --> Helper loaded: url_helper
INFO - 2020-08-18 07:22:06 --> Database Driver Class Initialized
INFO - 2020-08-18 07:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:22:06 --> Email Class Initialized
INFO - 2020-08-18 07:22:06 --> Controller Class Initialized
DEBUG - 2020-08-18 07:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:22:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:22:06 --> Model Class Initialized
INFO - 2020-08-18 07:22:06 --> Model Class Initialized
INFO - 2020-08-18 07:22:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 07:22:06 --> Final output sent to browser
DEBUG - 2020-08-18 07:22:06 --> Total execution time: 0.0795
INFO - 2020-08-18 07:22:13 --> Config Class Initialized
INFO - 2020-08-18 07:22:13 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:22:13 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:22:13 --> Utf8 Class Initialized
INFO - 2020-08-18 07:22:13 --> URI Class Initialized
INFO - 2020-08-18 07:22:13 --> Router Class Initialized
INFO - 2020-08-18 07:22:13 --> Output Class Initialized
INFO - 2020-08-18 07:22:13 --> Security Class Initialized
DEBUG - 2020-08-18 07:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:22:13 --> Input Class Initialized
INFO - 2020-08-18 07:22:13 --> Language Class Initialized
INFO - 2020-08-18 07:22:13 --> Loader Class Initialized
INFO - 2020-08-18 07:22:13 --> Helper loaded: url_helper
INFO - 2020-08-18 07:22:13 --> Database Driver Class Initialized
INFO - 2020-08-18 07:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:22:13 --> Email Class Initialized
INFO - 2020-08-18 07:22:13 --> Controller Class Initialized
DEBUG - 2020-08-18 07:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:22:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:22:13 --> Model Class Initialized
INFO - 2020-08-18 07:22:13 --> Model Class Initialized
INFO - 2020-08-18 07:22:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:22:13 --> Final output sent to browser
DEBUG - 2020-08-18 07:22:13 --> Total execution time: 0.0400
INFO - 2020-08-18 07:22:16 --> Config Class Initialized
INFO - 2020-08-18 07:22:16 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:22:16 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:22:16 --> Utf8 Class Initialized
INFO - 2020-08-18 07:22:16 --> URI Class Initialized
INFO - 2020-08-18 07:22:16 --> Router Class Initialized
INFO - 2020-08-18 07:22:16 --> Output Class Initialized
INFO - 2020-08-18 07:22:16 --> Security Class Initialized
DEBUG - 2020-08-18 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:22:16 --> Input Class Initialized
INFO - 2020-08-18 07:22:16 --> Language Class Initialized
INFO - 2020-08-18 07:22:16 --> Loader Class Initialized
INFO - 2020-08-18 07:22:16 --> Helper loaded: url_helper
INFO - 2020-08-18 07:22:16 --> Database Driver Class Initialized
INFO - 2020-08-18 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:22:16 --> Email Class Initialized
INFO - 2020-08-18 07:22:16 --> Controller Class Initialized
DEBUG - 2020-08-18 07:22:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:22:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:22:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:22:16 --> Final output sent to browser
DEBUG - 2020-08-18 07:22:16 --> Total execution time: 0.0213
INFO - 2020-08-18 07:22:20 --> Config Class Initialized
INFO - 2020-08-18 07:22:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:22:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:22:20 --> Utf8 Class Initialized
INFO - 2020-08-18 07:22:20 --> URI Class Initialized
INFO - 2020-08-18 07:22:20 --> Router Class Initialized
INFO - 2020-08-18 07:22:20 --> Output Class Initialized
INFO - 2020-08-18 07:22:20 --> Security Class Initialized
DEBUG - 2020-08-18 07:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:22:20 --> Input Class Initialized
INFO - 2020-08-18 07:22:20 --> Language Class Initialized
INFO - 2020-08-18 07:22:20 --> Loader Class Initialized
INFO - 2020-08-18 07:22:20 --> Helper loaded: url_helper
INFO - 2020-08-18 07:22:20 --> Database Driver Class Initialized
INFO - 2020-08-18 07:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:22:20 --> Email Class Initialized
INFO - 2020-08-18 07:22:20 --> Controller Class Initialized
DEBUG - 2020-08-18 07:22:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:22:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:22:20 --> Model Class Initialized
INFO - 2020-08-18 07:22:20 --> Model Class Initialized
INFO - 2020-08-18 07:22:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 07:22:20 --> Final output sent to browser
DEBUG - 2020-08-18 07:22:20 --> Total execution time: 0.0249
INFO - 2020-08-18 07:22:23 --> Config Class Initialized
INFO - 2020-08-18 07:22:23 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:22:23 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:22:23 --> Utf8 Class Initialized
INFO - 2020-08-18 07:22:23 --> URI Class Initialized
INFO - 2020-08-18 07:22:23 --> Router Class Initialized
INFO - 2020-08-18 07:22:23 --> Output Class Initialized
INFO - 2020-08-18 07:22:23 --> Security Class Initialized
DEBUG - 2020-08-18 07:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:22:23 --> Input Class Initialized
INFO - 2020-08-18 07:22:23 --> Language Class Initialized
INFO - 2020-08-18 07:22:23 --> Loader Class Initialized
INFO - 2020-08-18 07:22:23 --> Helper loaded: url_helper
INFO - 2020-08-18 07:22:23 --> Database Driver Class Initialized
INFO - 2020-08-18 07:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:22:23 --> Email Class Initialized
INFO - 2020-08-18 07:22:23 --> Controller Class Initialized
DEBUG - 2020-08-18 07:22:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 07:22:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:22:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 07:22:23 --> Final output sent to browser
DEBUG - 2020-08-18 07:22:23 --> Total execution time: 0.1907
INFO - 2020-08-18 07:23:01 --> Config Class Initialized
INFO - 2020-08-18 07:23:01 --> Hooks Class Initialized
DEBUG - 2020-08-18 07:23:01 --> UTF-8 Support Enabled
INFO - 2020-08-18 07:23:01 --> Utf8 Class Initialized
INFO - 2020-08-18 07:23:01 --> URI Class Initialized
DEBUG - 2020-08-18 07:23:01 --> No URI present. Default controller set.
INFO - 2020-08-18 07:23:01 --> Router Class Initialized
INFO - 2020-08-18 07:23:01 --> Output Class Initialized
INFO - 2020-08-18 07:23:01 --> Security Class Initialized
DEBUG - 2020-08-18 07:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 07:23:01 --> Input Class Initialized
INFO - 2020-08-18 07:23:01 --> Language Class Initialized
INFO - 2020-08-18 07:23:01 --> Loader Class Initialized
INFO - 2020-08-18 07:23:01 --> Helper loaded: url_helper
INFO - 2020-08-18 07:23:01 --> Database Driver Class Initialized
INFO - 2020-08-18 07:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 07:23:01 --> Email Class Initialized
INFO - 2020-08-18 07:23:01 --> Controller Class Initialized
INFO - 2020-08-18 07:23:01 --> Model Class Initialized
INFO - 2020-08-18 07:23:01 --> Model Class Initialized
DEBUG - 2020-08-18 07:23:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 07:23:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 07:23:01 --> Final output sent to browser
DEBUG - 2020-08-18 07:23:01 --> Total execution time: 0.0244
INFO - 2020-08-18 14:19:08 --> Config Class Initialized
INFO - 2020-08-18 14:19:08 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:19:08 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:19:08 --> Utf8 Class Initialized
INFO - 2020-08-18 14:19:08 --> URI Class Initialized
DEBUG - 2020-08-18 14:19:08 --> No URI present. Default controller set.
INFO - 2020-08-18 14:19:08 --> Router Class Initialized
INFO - 2020-08-18 14:19:08 --> Output Class Initialized
INFO - 2020-08-18 14:19:08 --> Security Class Initialized
DEBUG - 2020-08-18 14:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:19:08 --> Input Class Initialized
INFO - 2020-08-18 14:19:08 --> Language Class Initialized
INFO - 2020-08-18 14:19:08 --> Loader Class Initialized
INFO - 2020-08-18 14:19:08 --> Helper loaded: url_helper
INFO - 2020-08-18 14:19:08 --> Database Driver Class Initialized
INFO - 2020-08-18 14:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:19:08 --> Email Class Initialized
INFO - 2020-08-18 14:19:08 --> Controller Class Initialized
INFO - 2020-08-18 14:19:08 --> Model Class Initialized
INFO - 2020-08-18 14:19:08 --> Model Class Initialized
DEBUG - 2020-08-18 14:19:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:19:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 14:19:08 --> Final output sent to browser
DEBUG - 2020-08-18 14:19:08 --> Total execution time: 0.0212
INFO - 2020-08-18 14:19:54 --> Config Class Initialized
INFO - 2020-08-18 14:19:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:19:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:19:54 --> Utf8 Class Initialized
INFO - 2020-08-18 14:19:54 --> URI Class Initialized
INFO - 2020-08-18 14:19:54 --> Router Class Initialized
INFO - 2020-08-18 14:19:54 --> Output Class Initialized
INFO - 2020-08-18 14:19:54 --> Security Class Initialized
INFO - 2020-08-18 14:19:54 --> Config Class Initialized
INFO - 2020-08-18 14:19:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:19:54 --> Input Class Initialized
INFO - 2020-08-18 14:19:54 --> Language Class Initialized
DEBUG - 2020-08-18 14:19:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:19:54 --> Utf8 Class Initialized
INFO - 2020-08-18 14:19:54 --> URI Class Initialized
INFO - 2020-08-18 14:19:54 --> Router Class Initialized
INFO - 2020-08-18 14:19:54 --> Loader Class Initialized
INFO - 2020-08-18 14:19:54 --> Helper loaded: url_helper
INFO - 2020-08-18 14:19:54 --> Output Class Initialized
INFO - 2020-08-18 14:19:54 --> Security Class Initialized
DEBUG - 2020-08-18 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:19:54 --> Input Class Initialized
INFO - 2020-08-18 14:19:54 --> Language Class Initialized
INFO - 2020-08-18 14:19:54 --> Database Driver Class Initialized
INFO - 2020-08-18 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:19:54 --> Email Class Initialized
INFO - 2020-08-18 14:19:54 --> Controller Class Initialized
INFO - 2020-08-18 14:19:54 --> Model Class Initialized
INFO - 2020-08-18 14:19:54 --> Model Class Initialized
DEBUG - 2020-08-18 14:19:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:19:54 --> Loader Class Initialized
INFO - 2020-08-18 14:19:54 --> Helper loaded: url_helper
INFO - 2020-08-18 14:19:54 --> Database Driver Class Initialized
INFO - 2020-08-18 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:19:54 --> Email Class Initialized
INFO - 2020-08-18 14:19:54 --> Controller Class Initialized
INFO - 2020-08-18 14:19:54 --> Model Class Initialized
INFO - 2020-08-18 14:19:54 --> Model Class Initialized
DEBUG - 2020-08-18 14:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:19:54 --> Model Class Initialized
INFO - 2020-08-18 14:19:54 --> Final output sent to browser
DEBUG - 2020-08-18 14:19:54 --> Total execution time: 0.0472
INFO - 2020-08-18 14:19:54 --> Config Class Initialized
INFO - 2020-08-18 14:19:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:19:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:19:54 --> Utf8 Class Initialized
INFO - 2020-08-18 14:19:54 --> URI Class Initialized
INFO - 2020-08-18 14:19:54 --> Router Class Initialized
INFO - 2020-08-18 14:19:54 --> Output Class Initialized
INFO - 2020-08-18 14:19:54 --> Security Class Initialized
DEBUG - 2020-08-18 14:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:19:54 --> Input Class Initialized
INFO - 2020-08-18 14:19:54 --> Language Class Initialized
INFO - 2020-08-18 14:19:54 --> Loader Class Initialized
INFO - 2020-08-18 14:19:54 --> Helper loaded: url_helper
INFO - 2020-08-18 14:19:54 --> Database Driver Class Initialized
INFO - 2020-08-18 14:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:19:54 --> Email Class Initialized
INFO - 2020-08-18 14:19:54 --> Controller Class Initialized
DEBUG - 2020-08-18 14:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:19:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:19:54 --> Final output sent to browser
DEBUG - 2020-08-18 14:19:54 --> Total execution time: 0.0212
INFO - 2020-08-18 14:20:26 --> Config Class Initialized
INFO - 2020-08-18 14:20:26 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:26 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:26 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:26 --> URI Class Initialized
INFO - 2020-08-18 14:20:26 --> Router Class Initialized
INFO - 2020-08-18 14:20:26 --> Output Class Initialized
INFO - 2020-08-18 14:20:26 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:26 --> Input Class Initialized
INFO - 2020-08-18 14:20:26 --> Language Class Initialized
INFO - 2020-08-18 14:20:26 --> Loader Class Initialized
INFO - 2020-08-18 14:20:26 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:26 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:26 --> Email Class Initialized
INFO - 2020-08-18 14:20:26 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:26 --> Model Class Initialized
INFO - 2020-08-18 14:20:26 --> Model Class Initialized
INFO - 2020-08-18 14:20:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 14:20:26 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:26 --> Total execution time: 0.0439
INFO - 2020-08-18 14:20:30 --> Config Class Initialized
INFO - 2020-08-18 14:20:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:30 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:30 --> URI Class Initialized
INFO - 2020-08-18 14:20:30 --> Router Class Initialized
INFO - 2020-08-18 14:20:30 --> Output Class Initialized
INFO - 2020-08-18 14:20:30 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:30 --> Input Class Initialized
INFO - 2020-08-18 14:20:30 --> Language Class Initialized
INFO - 2020-08-18 14:20:30 --> Loader Class Initialized
INFO - 2020-08-18 14:20:30 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:30 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:30 --> Email Class Initialized
INFO - 2020-08-18 14:20:30 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:20:30 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:30 --> Total execution time: 0.1190
INFO - 2020-08-18 14:20:34 --> Config Class Initialized
INFO - 2020-08-18 14:20:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:34 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:34 --> URI Class Initialized
INFO - 2020-08-18 14:20:34 --> Router Class Initialized
INFO - 2020-08-18 14:20:34 --> Output Class Initialized
INFO - 2020-08-18 14:20:34 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:34 --> Input Class Initialized
INFO - 2020-08-18 14:20:34 --> Language Class Initialized
INFO - 2020-08-18 14:20:34 --> Loader Class Initialized
INFO - 2020-08-18 14:20:34 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:34 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:34 --> Email Class Initialized
INFO - 2020-08-18 14:20:34 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:34 --> Model Class Initialized
INFO - 2020-08-18 14:20:34 --> Model Class Initialized
INFO - 2020-08-18 14:20:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 14:20:34 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:34 --> Total execution time: 0.0252
INFO - 2020-08-18 14:20:36 --> Config Class Initialized
INFO - 2020-08-18 14:20:36 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:36 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:36 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:36 --> URI Class Initialized
INFO - 2020-08-18 14:20:36 --> Router Class Initialized
INFO - 2020-08-18 14:20:36 --> Output Class Initialized
INFO - 2020-08-18 14:20:36 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:36 --> Input Class Initialized
INFO - 2020-08-18 14:20:36 --> Language Class Initialized
INFO - 2020-08-18 14:20:36 --> Loader Class Initialized
INFO - 2020-08-18 14:20:36 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:36 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:36 --> Email Class Initialized
INFO - 2020-08-18 14:20:36 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:36 --> Model Class Initialized
INFO - 2020-08-18 14:20:36 --> Model Class Initialized
INFO - 2020-08-18 14:20:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 14:20:36 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:36 --> Total execution time: 0.0277
INFO - 2020-08-18 14:20:39 --> Config Class Initialized
INFO - 2020-08-18 14:20:39 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:39 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:39 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:39 --> URI Class Initialized
INFO - 2020-08-18 14:20:39 --> Router Class Initialized
INFO - 2020-08-18 14:20:39 --> Output Class Initialized
INFO - 2020-08-18 14:20:39 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:39 --> Input Class Initialized
INFO - 2020-08-18 14:20:39 --> Language Class Initialized
INFO - 2020-08-18 14:20:39 --> Loader Class Initialized
INFO - 2020-08-18 14:20:39 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:39 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:39 --> Email Class Initialized
INFO - 2020-08-18 14:20:39 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:39 --> Model Class Initialized
INFO - 2020-08-18 14:20:39 --> Model Class Initialized
INFO - 2020-08-18 14:20:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 14:20:39 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:39 --> Total execution time: 0.0392
INFO - 2020-08-18 14:20:42 --> Config Class Initialized
INFO - 2020-08-18 14:20:42 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:42 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:42 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:42 --> URI Class Initialized
INFO - 2020-08-18 14:20:42 --> Router Class Initialized
INFO - 2020-08-18 14:20:42 --> Output Class Initialized
INFO - 2020-08-18 14:20:42 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:42 --> Input Class Initialized
INFO - 2020-08-18 14:20:42 --> Language Class Initialized
INFO - 2020-08-18 14:20:42 --> Loader Class Initialized
INFO - 2020-08-18 14:20:42 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:42 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:42 --> Email Class Initialized
INFO - 2020-08-18 14:20:42 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:20:42 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:42 --> Total execution time: 0.2144
INFO - 2020-08-18 14:20:47 --> Config Class Initialized
INFO - 2020-08-18 14:20:47 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:47 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:47 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:47 --> URI Class Initialized
INFO - 2020-08-18 14:20:47 --> Router Class Initialized
INFO - 2020-08-18 14:20:47 --> Output Class Initialized
INFO - 2020-08-18 14:20:47 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:47 --> Input Class Initialized
INFO - 2020-08-18 14:20:47 --> Language Class Initialized
INFO - 2020-08-18 14:20:47 --> Loader Class Initialized
INFO - 2020-08-18 14:20:47 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:47 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:47 --> Email Class Initialized
INFO - 2020-08-18 14:20:47 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:47 --> Model Class Initialized
INFO - 2020-08-18 14:20:47 --> Model Class Initialized
INFO - 2020-08-18 14:20:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 14:20:47 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:47 --> Total execution time: 0.0239
INFO - 2020-08-18 14:20:51 --> Config Class Initialized
INFO - 2020-08-18 14:20:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:51 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:51 --> URI Class Initialized
INFO - 2020-08-18 14:20:51 --> Router Class Initialized
INFO - 2020-08-18 14:20:51 --> Output Class Initialized
INFO - 2020-08-18 14:20:51 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:51 --> Input Class Initialized
INFO - 2020-08-18 14:20:51 --> Language Class Initialized
INFO - 2020-08-18 14:20:51 --> Loader Class Initialized
INFO - 2020-08-18 14:20:51 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:51 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:51 --> Email Class Initialized
INFO - 2020-08-18 14:20:51 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:51 --> Model Class Initialized
INFO - 2020-08-18 14:20:51 --> Model Class Initialized
INFO - 2020-08-18 14:20:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 14:20:51 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:51 --> Total execution time: 0.0203
INFO - 2020-08-18 14:20:55 --> Config Class Initialized
INFO - 2020-08-18 14:20:55 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:20:55 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:20:55 --> Utf8 Class Initialized
INFO - 2020-08-18 14:20:55 --> URI Class Initialized
INFO - 2020-08-18 14:20:55 --> Router Class Initialized
INFO - 2020-08-18 14:20:55 --> Output Class Initialized
INFO - 2020-08-18 14:20:55 --> Security Class Initialized
DEBUG - 2020-08-18 14:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:20:55 --> Input Class Initialized
INFO - 2020-08-18 14:20:55 --> Language Class Initialized
INFO - 2020-08-18 14:20:55 --> Loader Class Initialized
INFO - 2020-08-18 14:20:55 --> Helper loaded: url_helper
INFO - 2020-08-18 14:20:55 --> Database Driver Class Initialized
INFO - 2020-08-18 14:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:20:55 --> Email Class Initialized
INFO - 2020-08-18 14:20:55 --> Controller Class Initialized
DEBUG - 2020-08-18 14:20:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:20:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:20:55 --> Model Class Initialized
INFO - 2020-08-18 14:20:55 --> Model Class Initialized
INFO - 2020-08-18 14:20:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 14:20:55 --> Final output sent to browser
DEBUG - 2020-08-18 14:20:55 --> Total execution time: 0.0283
INFO - 2020-08-18 14:21:14 --> Config Class Initialized
INFO - 2020-08-18 14:21:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:14 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:14 --> URI Class Initialized
INFO - 2020-08-18 14:21:14 --> Router Class Initialized
INFO - 2020-08-18 14:21:14 --> Output Class Initialized
INFO - 2020-08-18 14:21:14 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:14 --> Input Class Initialized
INFO - 2020-08-18 14:21:14 --> Language Class Initialized
INFO - 2020-08-18 14:21:14 --> Loader Class Initialized
INFO - 2020-08-18 14:21:14 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:14 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:14 --> Email Class Initialized
INFO - 2020-08-18 14:21:14 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:14 --> Model Class Initialized
INFO - 2020-08-18 14:21:14 --> Model Class Initialized
INFO - 2020-08-18 14:21:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 14:21:14 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:14 --> Total execution time: 0.0273
INFO - 2020-08-18 14:21:17 --> Config Class Initialized
INFO - 2020-08-18 14:21:17 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:17 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:17 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:17 --> URI Class Initialized
INFO - 2020-08-18 14:21:17 --> Router Class Initialized
INFO - 2020-08-18 14:21:17 --> Output Class Initialized
INFO - 2020-08-18 14:21:17 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:17 --> Input Class Initialized
INFO - 2020-08-18 14:21:17 --> Language Class Initialized
INFO - 2020-08-18 14:21:17 --> Loader Class Initialized
INFO - 2020-08-18 14:21:17 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:17 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:17 --> Email Class Initialized
INFO - 2020-08-18 14:21:17 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:21:17 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:17 --> Total execution time: 0.0211
INFO - 2020-08-18 14:21:30 --> Config Class Initialized
INFO - 2020-08-18 14:21:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:30 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:30 --> URI Class Initialized
INFO - 2020-08-18 14:21:30 --> Router Class Initialized
INFO - 2020-08-18 14:21:30 --> Output Class Initialized
INFO - 2020-08-18 14:21:30 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:30 --> Input Class Initialized
INFO - 2020-08-18 14:21:30 --> Language Class Initialized
INFO - 2020-08-18 14:21:30 --> Loader Class Initialized
INFO - 2020-08-18 14:21:30 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:30 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:30 --> Email Class Initialized
INFO - 2020-08-18 14:21:30 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:30 --> Model Class Initialized
INFO - 2020-08-18 14:21:30 --> Model Class Initialized
INFO - 2020-08-18 14:21:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 14:21:30 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:30 --> Total execution time: 0.0279
INFO - 2020-08-18 14:21:34 --> Config Class Initialized
INFO - 2020-08-18 14:21:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:34 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:34 --> URI Class Initialized
INFO - 2020-08-18 14:21:34 --> Router Class Initialized
INFO - 2020-08-18 14:21:34 --> Output Class Initialized
INFO - 2020-08-18 14:21:34 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:34 --> Input Class Initialized
INFO - 2020-08-18 14:21:34 --> Language Class Initialized
INFO - 2020-08-18 14:21:34 --> Loader Class Initialized
INFO - 2020-08-18 14:21:34 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:34 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:34 --> Email Class Initialized
INFO - 2020-08-18 14:21:34 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:21:34 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:34 --> Total execution time: 0.0239
INFO - 2020-08-18 14:21:37 --> Config Class Initialized
INFO - 2020-08-18 14:21:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:37 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:37 --> URI Class Initialized
INFO - 2020-08-18 14:21:37 --> Router Class Initialized
INFO - 2020-08-18 14:21:37 --> Output Class Initialized
INFO - 2020-08-18 14:21:37 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:37 --> Input Class Initialized
INFO - 2020-08-18 14:21:37 --> Language Class Initialized
INFO - 2020-08-18 14:21:37 --> Loader Class Initialized
INFO - 2020-08-18 14:21:37 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:37 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:37 --> Email Class Initialized
INFO - 2020-08-18 14:21:37 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:37 --> Model Class Initialized
INFO - 2020-08-18 14:21:37 --> Model Class Initialized
INFO - 2020-08-18 14:21:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 14:21:37 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:37 --> Total execution time: 0.0296
INFO - 2020-08-18 14:21:39 --> Config Class Initialized
INFO - 2020-08-18 14:21:39 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:39 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:39 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:39 --> URI Class Initialized
INFO - 2020-08-18 14:21:39 --> Router Class Initialized
INFO - 2020-08-18 14:21:39 --> Output Class Initialized
INFO - 2020-08-18 14:21:39 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:39 --> Input Class Initialized
INFO - 2020-08-18 14:21:39 --> Language Class Initialized
INFO - 2020-08-18 14:21:39 --> Loader Class Initialized
INFO - 2020-08-18 14:21:39 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:39 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:39 --> Email Class Initialized
INFO - 2020-08-18 14:21:39 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:39 --> Model Class Initialized
INFO - 2020-08-18 14:21:39 --> Model Class Initialized
INFO - 2020-08-18 14:21:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-18 14:21:39 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:39 --> Total execution time: 0.0214
INFO - 2020-08-18 14:21:41 --> Config Class Initialized
INFO - 2020-08-18 14:21:41 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:41 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:41 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:41 --> URI Class Initialized
INFO - 2020-08-18 14:21:41 --> Router Class Initialized
INFO - 2020-08-18 14:21:41 --> Output Class Initialized
INFO - 2020-08-18 14:21:41 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:41 --> Input Class Initialized
INFO - 2020-08-18 14:21:41 --> Language Class Initialized
INFO - 2020-08-18 14:21:41 --> Loader Class Initialized
INFO - 2020-08-18 14:21:41 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:41 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:41 --> Email Class Initialized
INFO - 2020-08-18 14:21:41 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:21:41 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:41 --> Total execution time: 0.0240
INFO - 2020-08-18 14:21:44 --> Config Class Initialized
INFO - 2020-08-18 14:21:44 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:44 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:44 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:44 --> URI Class Initialized
INFO - 2020-08-18 14:21:44 --> Router Class Initialized
INFO - 2020-08-18 14:21:44 --> Output Class Initialized
INFO - 2020-08-18 14:21:44 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:44 --> Input Class Initialized
INFO - 2020-08-18 14:21:44 --> Language Class Initialized
INFO - 2020-08-18 14:21:44 --> Loader Class Initialized
INFO - 2020-08-18 14:21:44 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:44 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:44 --> Email Class Initialized
INFO - 2020-08-18 14:21:44 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:44 --> Model Class Initialized
INFO - 2020-08-18 14:21:44 --> Model Class Initialized
INFO - 2020-08-18 14:21:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 14:21:44 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:44 --> Total execution time: 0.0223
INFO - 2020-08-18 14:21:47 --> Config Class Initialized
INFO - 2020-08-18 14:21:47 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:47 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:47 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:47 --> URI Class Initialized
INFO - 2020-08-18 14:21:47 --> Router Class Initialized
INFO - 2020-08-18 14:21:47 --> Output Class Initialized
INFO - 2020-08-18 14:21:47 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:47 --> Input Class Initialized
INFO - 2020-08-18 14:21:47 --> Language Class Initialized
INFO - 2020-08-18 14:21:47 --> Loader Class Initialized
INFO - 2020-08-18 14:21:47 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:47 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:47 --> Email Class Initialized
INFO - 2020-08-18 14:21:47 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:47 --> Model Class Initialized
INFO - 2020-08-18 14:21:47 --> Model Class Initialized
INFO - 2020-08-18 14:21:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 14:21:47 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:47 --> Total execution time: 0.0269
INFO - 2020-08-18 14:21:51 --> Config Class Initialized
INFO - 2020-08-18 14:21:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:21:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:21:51 --> Utf8 Class Initialized
INFO - 2020-08-18 14:21:51 --> URI Class Initialized
INFO - 2020-08-18 14:21:51 --> Router Class Initialized
INFO - 2020-08-18 14:21:51 --> Output Class Initialized
INFO - 2020-08-18 14:21:51 --> Security Class Initialized
DEBUG - 2020-08-18 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:21:51 --> Input Class Initialized
INFO - 2020-08-18 14:21:51 --> Language Class Initialized
INFO - 2020-08-18 14:21:51 --> Loader Class Initialized
INFO - 2020-08-18 14:21:51 --> Helper loaded: url_helper
INFO - 2020-08-18 14:21:51 --> Database Driver Class Initialized
INFO - 2020-08-18 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:21:51 --> Email Class Initialized
INFO - 2020-08-18 14:21:51 --> Controller Class Initialized
DEBUG - 2020-08-18 14:21:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:21:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:21:51 --> Model Class Initialized
INFO - 2020-08-18 14:21:51 --> Model Class Initialized
INFO - 2020-08-18 14:21:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 14:21:51 --> Final output sent to browser
DEBUG - 2020-08-18 14:21:51 --> Total execution time: 0.0219
INFO - 2020-08-18 14:32:29 --> Config Class Initialized
INFO - 2020-08-18 14:32:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:32:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:32:29 --> Utf8 Class Initialized
INFO - 2020-08-18 14:32:29 --> URI Class Initialized
INFO - 2020-08-18 14:32:29 --> Router Class Initialized
INFO - 2020-08-18 14:32:29 --> Output Class Initialized
INFO - 2020-08-18 14:32:29 --> Security Class Initialized
DEBUG - 2020-08-18 14:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:32:29 --> Input Class Initialized
INFO - 2020-08-18 14:32:29 --> Language Class Initialized
INFO - 2020-08-18 14:32:29 --> Loader Class Initialized
INFO - 2020-08-18 14:32:29 --> Helper loaded: url_helper
INFO - 2020-08-18 14:32:29 --> Database Driver Class Initialized
INFO - 2020-08-18 14:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:32:29 --> Email Class Initialized
INFO - 2020-08-18 14:32:29 --> Controller Class Initialized
DEBUG - 2020-08-18 14:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:32:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:32:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:32:29 --> Final output sent to browser
DEBUG - 2020-08-18 14:32:29 --> Total execution time: 0.0214
INFO - 2020-08-18 14:56:36 --> Config Class Initialized
INFO - 2020-08-18 14:56:36 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:56:36 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:56:36 --> Utf8 Class Initialized
INFO - 2020-08-18 14:56:36 --> URI Class Initialized
INFO - 2020-08-18 14:56:36 --> Router Class Initialized
INFO - 2020-08-18 14:56:36 --> Output Class Initialized
INFO - 2020-08-18 14:56:36 --> Security Class Initialized
DEBUG - 2020-08-18 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:56:36 --> Input Class Initialized
INFO - 2020-08-18 14:56:36 --> Language Class Initialized
INFO - 2020-08-18 14:56:36 --> Loader Class Initialized
INFO - 2020-08-18 14:56:36 --> Helper loaded: url_helper
INFO - 2020-08-18 14:56:36 --> Database Driver Class Initialized
INFO - 2020-08-18 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:56:36 --> Email Class Initialized
INFO - 2020-08-18 14:56:36 --> Controller Class Initialized
DEBUG - 2020-08-18 14:56:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:56:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:56:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:56:36 --> Final output sent to browser
DEBUG - 2020-08-18 14:56:36 --> Total execution time: 0.0359
INFO - 2020-08-18 14:57:54 --> Config Class Initialized
INFO - 2020-08-18 14:57:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:57:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:57:54 --> Utf8 Class Initialized
INFO - 2020-08-18 14:57:54 --> URI Class Initialized
INFO - 2020-08-18 14:57:54 --> Router Class Initialized
INFO - 2020-08-18 14:57:54 --> Output Class Initialized
INFO - 2020-08-18 14:57:54 --> Security Class Initialized
DEBUG - 2020-08-18 14:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:57:54 --> Input Class Initialized
INFO - 2020-08-18 14:57:54 --> Language Class Initialized
INFO - 2020-08-18 14:57:54 --> Loader Class Initialized
INFO - 2020-08-18 14:57:54 --> Helper loaded: url_helper
INFO - 2020-08-18 14:57:54 --> Database Driver Class Initialized
INFO - 2020-08-18 14:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:57:54 --> Email Class Initialized
INFO - 2020-08-18 14:57:54 --> Controller Class Initialized
DEBUG - 2020-08-18 14:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:57:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:57:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:57:54 --> Final output sent to browser
DEBUG - 2020-08-18 14:57:54 --> Total execution time: 0.0193
INFO - 2020-08-18 14:58:28 --> Config Class Initialized
INFO - 2020-08-18 14:58:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 14:58:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 14:58:28 --> Utf8 Class Initialized
INFO - 2020-08-18 14:58:28 --> URI Class Initialized
INFO - 2020-08-18 14:58:28 --> Router Class Initialized
INFO - 2020-08-18 14:58:28 --> Output Class Initialized
INFO - 2020-08-18 14:58:28 --> Security Class Initialized
DEBUG - 2020-08-18 14:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 14:58:28 --> Input Class Initialized
INFO - 2020-08-18 14:58:28 --> Language Class Initialized
INFO - 2020-08-18 14:58:28 --> Loader Class Initialized
INFO - 2020-08-18 14:58:28 --> Helper loaded: url_helper
INFO - 2020-08-18 14:58:28 --> Database Driver Class Initialized
INFO - 2020-08-18 14:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 14:58:28 --> Email Class Initialized
INFO - 2020-08-18 14:58:28 --> Controller Class Initialized
DEBUG - 2020-08-18 14:58:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 14:58:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 14:58:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 14:58:28 --> Final output sent to browser
DEBUG - 2020-08-18 14:58:28 --> Total execution time: 0.0229
INFO - 2020-08-18 15:03:19 --> Config Class Initialized
INFO - 2020-08-18 15:03:19 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:03:19 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:03:19 --> Utf8 Class Initialized
INFO - 2020-08-18 15:03:19 --> URI Class Initialized
INFO - 2020-08-18 15:03:19 --> Router Class Initialized
INFO - 2020-08-18 15:03:19 --> Output Class Initialized
INFO - 2020-08-18 15:03:19 --> Security Class Initialized
DEBUG - 2020-08-18 15:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:03:19 --> Input Class Initialized
INFO - 2020-08-18 15:03:19 --> Language Class Initialized
INFO - 2020-08-18 15:03:19 --> Loader Class Initialized
INFO - 2020-08-18 15:03:19 --> Helper loaded: url_helper
INFO - 2020-08-18 15:03:19 --> Database Driver Class Initialized
INFO - 2020-08-18 15:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:03:19 --> Email Class Initialized
INFO - 2020-08-18 15:03:19 --> Controller Class Initialized
DEBUG - 2020-08-18 15:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:03:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:03:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:03:19 --> Final output sent to browser
DEBUG - 2020-08-18 15:03:19 --> Total execution time: 0.0220
INFO - 2020-08-18 15:04:33 --> Config Class Initialized
INFO - 2020-08-18 15:04:33 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:04:33 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:04:33 --> Utf8 Class Initialized
INFO - 2020-08-18 15:04:33 --> URI Class Initialized
INFO - 2020-08-18 15:04:33 --> Router Class Initialized
INFO - 2020-08-18 15:04:33 --> Output Class Initialized
INFO - 2020-08-18 15:04:33 --> Security Class Initialized
DEBUG - 2020-08-18 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:04:33 --> Input Class Initialized
INFO - 2020-08-18 15:04:33 --> Language Class Initialized
INFO - 2020-08-18 15:04:33 --> Loader Class Initialized
INFO - 2020-08-18 15:04:33 --> Helper loaded: url_helper
INFO - 2020-08-18 15:04:33 --> Database Driver Class Initialized
INFO - 2020-08-18 15:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:04:33 --> Email Class Initialized
INFO - 2020-08-18 15:04:33 --> Controller Class Initialized
DEBUG - 2020-08-18 15:04:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:04:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:04:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:04:33 --> Final output sent to browser
DEBUG - 2020-08-18 15:04:33 --> Total execution time: 0.1074
INFO - 2020-08-18 15:05:35 --> Config Class Initialized
INFO - 2020-08-18 15:05:35 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:05:35 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:05:35 --> Utf8 Class Initialized
INFO - 2020-08-18 15:05:35 --> URI Class Initialized
INFO - 2020-08-18 15:05:35 --> Router Class Initialized
INFO - 2020-08-18 15:05:35 --> Output Class Initialized
INFO - 2020-08-18 15:05:35 --> Security Class Initialized
DEBUG - 2020-08-18 15:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:05:35 --> Input Class Initialized
INFO - 2020-08-18 15:05:35 --> Language Class Initialized
INFO - 2020-08-18 15:05:35 --> Loader Class Initialized
INFO - 2020-08-18 15:05:35 --> Helper loaded: url_helper
INFO - 2020-08-18 15:05:35 --> Database Driver Class Initialized
INFO - 2020-08-18 15:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:05:35 --> Email Class Initialized
INFO - 2020-08-18 15:05:35 --> Controller Class Initialized
DEBUG - 2020-08-18 15:05:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:05:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:05:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:05:35 --> Final output sent to browser
DEBUG - 2020-08-18 15:05:35 --> Total execution time: 0.0259
INFO - 2020-08-18 15:06:08 --> Config Class Initialized
INFO - 2020-08-18 15:06:08 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:06:08 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:06:08 --> Utf8 Class Initialized
INFO - 2020-08-18 15:06:08 --> URI Class Initialized
INFO - 2020-08-18 15:06:08 --> Router Class Initialized
INFO - 2020-08-18 15:06:08 --> Output Class Initialized
INFO - 2020-08-18 15:06:08 --> Security Class Initialized
DEBUG - 2020-08-18 15:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:06:08 --> Input Class Initialized
INFO - 2020-08-18 15:06:08 --> Language Class Initialized
INFO - 2020-08-18 15:06:08 --> Loader Class Initialized
INFO - 2020-08-18 15:06:08 --> Helper loaded: url_helper
INFO - 2020-08-18 15:06:08 --> Database Driver Class Initialized
INFO - 2020-08-18 15:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:06:08 --> Email Class Initialized
INFO - 2020-08-18 15:06:08 --> Controller Class Initialized
DEBUG - 2020-08-18 15:06:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:06:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:06:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:06:08 --> Final output sent to browser
DEBUG - 2020-08-18 15:06:08 --> Total execution time: 0.0250
INFO - 2020-08-18 15:10:54 --> Config Class Initialized
INFO - 2020-08-18 15:10:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:10:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:10:54 --> Utf8 Class Initialized
INFO - 2020-08-18 15:10:54 --> URI Class Initialized
INFO - 2020-08-18 15:10:54 --> Router Class Initialized
INFO - 2020-08-18 15:10:54 --> Output Class Initialized
INFO - 2020-08-18 15:10:54 --> Security Class Initialized
DEBUG - 2020-08-18 15:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:10:54 --> Input Class Initialized
INFO - 2020-08-18 15:10:54 --> Language Class Initialized
INFO - 2020-08-18 15:10:54 --> Loader Class Initialized
INFO - 2020-08-18 15:10:54 --> Helper loaded: url_helper
INFO - 2020-08-18 15:10:54 --> Database Driver Class Initialized
INFO - 2020-08-18 15:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:10:54 --> Email Class Initialized
INFO - 2020-08-18 15:10:54 --> Controller Class Initialized
DEBUG - 2020-08-18 15:10:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:10:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:10:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:10:54 --> Final output sent to browser
DEBUG - 2020-08-18 15:10:54 --> Total execution time: 0.0239
INFO - 2020-08-18 15:11:47 --> Config Class Initialized
INFO - 2020-08-18 15:11:47 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:11:47 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:11:47 --> Utf8 Class Initialized
INFO - 2020-08-18 15:11:47 --> URI Class Initialized
INFO - 2020-08-18 15:11:47 --> Router Class Initialized
INFO - 2020-08-18 15:11:47 --> Output Class Initialized
INFO - 2020-08-18 15:11:47 --> Security Class Initialized
DEBUG - 2020-08-18 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:11:47 --> Input Class Initialized
INFO - 2020-08-18 15:11:47 --> Language Class Initialized
INFO - 2020-08-18 15:11:47 --> Loader Class Initialized
INFO - 2020-08-18 15:11:47 --> Helper loaded: url_helper
INFO - 2020-08-18 15:11:47 --> Database Driver Class Initialized
INFO - 2020-08-18 15:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:11:47 --> Email Class Initialized
INFO - 2020-08-18 15:11:47 --> Controller Class Initialized
DEBUG - 2020-08-18 15:11:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:11:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:11:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:11:47 --> Final output sent to browser
DEBUG - 2020-08-18 15:11:47 --> Total execution time: 0.0209
INFO - 2020-08-18 15:43:05 --> Config Class Initialized
INFO - 2020-08-18 15:43:05 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:43:05 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:43:05 --> Utf8 Class Initialized
INFO - 2020-08-18 15:43:05 --> URI Class Initialized
INFO - 2020-08-18 15:43:05 --> Router Class Initialized
INFO - 2020-08-18 15:43:05 --> Output Class Initialized
INFO - 2020-08-18 15:43:05 --> Security Class Initialized
DEBUG - 2020-08-18 15:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:43:05 --> Input Class Initialized
INFO - 2020-08-18 15:43:05 --> Language Class Initialized
INFO - 2020-08-18 15:43:05 --> Loader Class Initialized
INFO - 2020-08-18 15:43:05 --> Helper loaded: url_helper
INFO - 2020-08-18 15:43:05 --> Database Driver Class Initialized
INFO - 2020-08-18 15:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:43:05 --> Email Class Initialized
INFO - 2020-08-18 15:43:05 --> Controller Class Initialized
DEBUG - 2020-08-18 15:43:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:43:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:43:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:43:05 --> Final output sent to browser
DEBUG - 2020-08-18 15:43:05 --> Total execution time: 0.0207
INFO - 2020-08-18 15:45:29 --> Config Class Initialized
INFO - 2020-08-18 15:45:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:45:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:45:29 --> Utf8 Class Initialized
INFO - 2020-08-18 15:45:29 --> URI Class Initialized
INFO - 2020-08-18 15:45:29 --> Router Class Initialized
INFO - 2020-08-18 15:45:29 --> Output Class Initialized
INFO - 2020-08-18 15:45:29 --> Security Class Initialized
DEBUG - 2020-08-18 15:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:45:29 --> Input Class Initialized
INFO - 2020-08-18 15:45:29 --> Language Class Initialized
INFO - 2020-08-18 15:45:29 --> Loader Class Initialized
INFO - 2020-08-18 15:45:29 --> Helper loaded: url_helper
INFO - 2020-08-18 15:45:29 --> Database Driver Class Initialized
INFO - 2020-08-18 15:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:45:29 --> Email Class Initialized
INFO - 2020-08-18 15:45:29 --> Controller Class Initialized
DEBUG - 2020-08-18 15:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:45:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:45:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:45:29 --> Final output sent to browser
DEBUG - 2020-08-18 15:45:29 --> Total execution time: 0.0220
INFO - 2020-08-18 15:46:20 --> Config Class Initialized
INFO - 2020-08-18 15:46:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:46:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:46:20 --> Utf8 Class Initialized
INFO - 2020-08-18 15:46:20 --> URI Class Initialized
INFO - 2020-08-18 15:46:20 --> Router Class Initialized
INFO - 2020-08-18 15:46:20 --> Output Class Initialized
INFO - 2020-08-18 15:46:20 --> Security Class Initialized
DEBUG - 2020-08-18 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:46:20 --> Input Class Initialized
INFO - 2020-08-18 15:46:20 --> Language Class Initialized
INFO - 2020-08-18 15:46:20 --> Loader Class Initialized
INFO - 2020-08-18 15:46:20 --> Helper loaded: url_helper
INFO - 2020-08-18 15:46:20 --> Database Driver Class Initialized
INFO - 2020-08-18 15:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:46:20 --> Email Class Initialized
INFO - 2020-08-18 15:46:20 --> Controller Class Initialized
DEBUG - 2020-08-18 15:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:46:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:46:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:46:20 --> Final output sent to browser
DEBUG - 2020-08-18 15:46:20 --> Total execution time: 0.0241
INFO - 2020-08-18 15:49:04 --> Config Class Initialized
INFO - 2020-08-18 15:49:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:49:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:49:04 --> Utf8 Class Initialized
INFO - 2020-08-18 15:49:04 --> URI Class Initialized
INFO - 2020-08-18 15:49:04 --> Router Class Initialized
INFO - 2020-08-18 15:49:04 --> Output Class Initialized
INFO - 2020-08-18 15:49:04 --> Security Class Initialized
DEBUG - 2020-08-18 15:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:49:04 --> Input Class Initialized
INFO - 2020-08-18 15:49:04 --> Language Class Initialized
INFO - 2020-08-18 15:49:04 --> Loader Class Initialized
INFO - 2020-08-18 15:49:04 --> Helper loaded: url_helper
INFO - 2020-08-18 15:49:04 --> Database Driver Class Initialized
INFO - 2020-08-18 15:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:49:04 --> Email Class Initialized
INFO - 2020-08-18 15:49:04 --> Controller Class Initialized
DEBUG - 2020-08-18 15:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:49:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:49:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:49:04 --> Final output sent to browser
DEBUG - 2020-08-18 15:49:04 --> Total execution time: 0.0224
INFO - 2020-08-18 15:49:54 --> Config Class Initialized
INFO - 2020-08-18 15:49:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:49:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:49:54 --> Utf8 Class Initialized
INFO - 2020-08-18 15:49:54 --> URI Class Initialized
INFO - 2020-08-18 15:49:54 --> Router Class Initialized
INFO - 2020-08-18 15:49:54 --> Output Class Initialized
INFO - 2020-08-18 15:49:54 --> Security Class Initialized
DEBUG - 2020-08-18 15:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:49:55 --> Input Class Initialized
INFO - 2020-08-18 15:49:55 --> Language Class Initialized
INFO - 2020-08-18 15:49:55 --> Loader Class Initialized
INFO - 2020-08-18 15:49:55 --> Helper loaded: url_helper
INFO - 2020-08-18 15:49:55 --> Database Driver Class Initialized
INFO - 2020-08-18 15:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:49:55 --> Email Class Initialized
INFO - 2020-08-18 15:49:55 --> Controller Class Initialized
DEBUG - 2020-08-18 15:49:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:49:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:49:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:49:55 --> Final output sent to browser
DEBUG - 2020-08-18 15:49:55 --> Total execution time: 0.0220
INFO - 2020-08-18 15:50:11 --> Config Class Initialized
INFO - 2020-08-18 15:50:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:50:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:50:11 --> Utf8 Class Initialized
INFO - 2020-08-18 15:50:11 --> URI Class Initialized
INFO - 2020-08-18 15:50:11 --> Router Class Initialized
INFO - 2020-08-18 15:50:11 --> Output Class Initialized
INFO - 2020-08-18 15:50:11 --> Security Class Initialized
DEBUG - 2020-08-18 15:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:50:11 --> Input Class Initialized
INFO - 2020-08-18 15:50:11 --> Language Class Initialized
INFO - 2020-08-18 15:50:11 --> Loader Class Initialized
INFO - 2020-08-18 15:50:11 --> Helper loaded: url_helper
INFO - 2020-08-18 15:50:11 --> Database Driver Class Initialized
INFO - 2020-08-18 15:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:50:11 --> Email Class Initialized
INFO - 2020-08-18 15:50:11 --> Controller Class Initialized
DEBUG - 2020-08-18 15:50:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:50:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:50:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:50:11 --> Final output sent to browser
DEBUG - 2020-08-18 15:50:11 --> Total execution time: 0.0225
INFO - 2020-08-18 15:52:07 --> Config Class Initialized
INFO - 2020-08-18 15:52:07 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:52:07 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:52:07 --> Utf8 Class Initialized
INFO - 2020-08-18 15:52:07 --> URI Class Initialized
INFO - 2020-08-18 15:52:07 --> Router Class Initialized
INFO - 2020-08-18 15:52:07 --> Output Class Initialized
INFO - 2020-08-18 15:52:07 --> Security Class Initialized
DEBUG - 2020-08-18 15:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:52:07 --> Input Class Initialized
INFO - 2020-08-18 15:52:07 --> Language Class Initialized
INFO - 2020-08-18 15:52:07 --> Loader Class Initialized
INFO - 2020-08-18 15:52:07 --> Helper loaded: url_helper
INFO - 2020-08-18 15:52:07 --> Database Driver Class Initialized
INFO - 2020-08-18 15:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:52:07 --> Email Class Initialized
INFO - 2020-08-18 15:52:07 --> Controller Class Initialized
DEBUG - 2020-08-18 15:52:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:52:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:52:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:52:07 --> Final output sent to browser
DEBUG - 2020-08-18 15:52:07 --> Total execution time: 0.0263
INFO - 2020-08-18 15:52:49 --> Config Class Initialized
INFO - 2020-08-18 15:52:49 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:52:49 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:52:49 --> Utf8 Class Initialized
INFO - 2020-08-18 15:52:49 --> URI Class Initialized
INFO - 2020-08-18 15:52:49 --> Router Class Initialized
INFO - 2020-08-18 15:52:49 --> Output Class Initialized
INFO - 2020-08-18 15:52:49 --> Security Class Initialized
DEBUG - 2020-08-18 15:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:52:49 --> Input Class Initialized
INFO - 2020-08-18 15:52:49 --> Language Class Initialized
INFO - 2020-08-18 15:52:49 --> Loader Class Initialized
INFO - 2020-08-18 15:52:49 --> Helper loaded: url_helper
INFO - 2020-08-18 15:52:49 --> Database Driver Class Initialized
INFO - 2020-08-18 15:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:52:49 --> Email Class Initialized
INFO - 2020-08-18 15:52:49 --> Controller Class Initialized
DEBUG - 2020-08-18 15:52:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:52:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:52:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:52:49 --> Final output sent to browser
DEBUG - 2020-08-18 15:52:49 --> Total execution time: 0.0222
INFO - 2020-08-18 15:53:28 --> Config Class Initialized
INFO - 2020-08-18 15:53:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:53:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:53:28 --> Utf8 Class Initialized
INFO - 2020-08-18 15:53:28 --> URI Class Initialized
INFO - 2020-08-18 15:53:28 --> Router Class Initialized
INFO - 2020-08-18 15:53:28 --> Output Class Initialized
INFO - 2020-08-18 15:53:28 --> Security Class Initialized
DEBUG - 2020-08-18 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:53:28 --> Input Class Initialized
INFO - 2020-08-18 15:53:28 --> Language Class Initialized
INFO - 2020-08-18 15:53:28 --> Loader Class Initialized
INFO - 2020-08-18 15:53:28 --> Helper loaded: url_helper
INFO - 2020-08-18 15:53:28 --> Database Driver Class Initialized
INFO - 2020-08-18 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:53:28 --> Email Class Initialized
INFO - 2020-08-18 15:53:28 --> Controller Class Initialized
DEBUG - 2020-08-18 15:53:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:53:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:53:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:53:28 --> Final output sent to browser
DEBUG - 2020-08-18 15:53:28 --> Total execution time: 0.0296
INFO - 2020-08-18 15:54:29 --> Config Class Initialized
INFO - 2020-08-18 15:54:29 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:54:29 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:54:29 --> Utf8 Class Initialized
INFO - 2020-08-18 15:54:29 --> URI Class Initialized
INFO - 2020-08-18 15:54:29 --> Router Class Initialized
INFO - 2020-08-18 15:54:29 --> Output Class Initialized
INFO - 2020-08-18 15:54:29 --> Security Class Initialized
DEBUG - 2020-08-18 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:54:29 --> Input Class Initialized
INFO - 2020-08-18 15:54:29 --> Language Class Initialized
INFO - 2020-08-18 15:54:29 --> Loader Class Initialized
INFO - 2020-08-18 15:54:29 --> Helper loaded: url_helper
INFO - 2020-08-18 15:54:29 --> Database Driver Class Initialized
INFO - 2020-08-18 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:54:29 --> Email Class Initialized
INFO - 2020-08-18 15:54:29 --> Controller Class Initialized
DEBUG - 2020-08-18 15:54:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:54:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:54:29 --> Final output sent to browser
DEBUG - 2020-08-18 15:54:29 --> Total execution time: 0.0336
INFO - 2020-08-18 15:55:32 --> Config Class Initialized
INFO - 2020-08-18 15:55:32 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:55:32 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:55:32 --> Utf8 Class Initialized
INFO - 2020-08-18 15:55:32 --> URI Class Initialized
INFO - 2020-08-18 15:55:32 --> Router Class Initialized
INFO - 2020-08-18 15:55:32 --> Output Class Initialized
INFO - 2020-08-18 15:55:32 --> Security Class Initialized
DEBUG - 2020-08-18 15:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:55:32 --> Input Class Initialized
INFO - 2020-08-18 15:55:32 --> Language Class Initialized
INFO - 2020-08-18 15:55:32 --> Loader Class Initialized
INFO - 2020-08-18 15:55:32 --> Helper loaded: url_helper
INFO - 2020-08-18 15:55:32 --> Database Driver Class Initialized
INFO - 2020-08-18 15:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:55:32 --> Email Class Initialized
INFO - 2020-08-18 15:55:32 --> Controller Class Initialized
DEBUG - 2020-08-18 15:55:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:55:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:55:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:55:32 --> Final output sent to browser
DEBUG - 2020-08-18 15:55:32 --> Total execution time: 0.0241
INFO - 2020-08-18 15:57:38 --> Config Class Initialized
INFO - 2020-08-18 15:57:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 15:57:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 15:57:38 --> Utf8 Class Initialized
INFO - 2020-08-18 15:57:38 --> URI Class Initialized
INFO - 2020-08-18 15:57:38 --> Router Class Initialized
INFO - 2020-08-18 15:57:38 --> Output Class Initialized
INFO - 2020-08-18 15:57:38 --> Security Class Initialized
DEBUG - 2020-08-18 15:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 15:57:38 --> Input Class Initialized
INFO - 2020-08-18 15:57:38 --> Language Class Initialized
INFO - 2020-08-18 15:57:38 --> Loader Class Initialized
INFO - 2020-08-18 15:57:38 --> Helper loaded: url_helper
INFO - 2020-08-18 15:57:38 --> Database Driver Class Initialized
INFO - 2020-08-18 15:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 15:57:38 --> Email Class Initialized
INFO - 2020-08-18 15:57:38 --> Controller Class Initialized
DEBUG - 2020-08-18 15:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 15:57:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 15:57:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 15:57:38 --> Final output sent to browser
DEBUG - 2020-08-18 15:57:38 --> Total execution time: 0.0192
INFO - 2020-08-18 16:00:20 --> Config Class Initialized
INFO - 2020-08-18 16:00:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:00:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:00:20 --> Utf8 Class Initialized
INFO - 2020-08-18 16:00:20 --> URI Class Initialized
INFO - 2020-08-18 16:00:20 --> Router Class Initialized
INFO - 2020-08-18 16:00:20 --> Output Class Initialized
INFO - 2020-08-18 16:00:20 --> Security Class Initialized
DEBUG - 2020-08-18 16:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:00:20 --> Input Class Initialized
INFO - 2020-08-18 16:00:20 --> Language Class Initialized
INFO - 2020-08-18 16:00:21 --> Loader Class Initialized
INFO - 2020-08-18 16:00:21 --> Helper loaded: url_helper
INFO - 2020-08-18 16:00:21 --> Database Driver Class Initialized
INFO - 2020-08-18 16:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:00:21 --> Email Class Initialized
INFO - 2020-08-18 16:00:21 --> Controller Class Initialized
DEBUG - 2020-08-18 16:00:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:00:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:00:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:00:21 --> Final output sent to browser
DEBUG - 2020-08-18 16:00:21 --> Total execution time: 0.0258
INFO - 2020-08-18 16:05:31 --> Config Class Initialized
INFO - 2020-08-18 16:05:31 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:05:31 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:05:31 --> Utf8 Class Initialized
INFO - 2020-08-18 16:05:31 --> URI Class Initialized
INFO - 2020-08-18 16:05:31 --> Router Class Initialized
INFO - 2020-08-18 16:05:31 --> Output Class Initialized
INFO - 2020-08-18 16:05:31 --> Security Class Initialized
DEBUG - 2020-08-18 16:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:05:31 --> Input Class Initialized
INFO - 2020-08-18 16:05:31 --> Language Class Initialized
INFO - 2020-08-18 16:05:31 --> Loader Class Initialized
INFO - 2020-08-18 16:05:31 --> Helper loaded: url_helper
INFO - 2020-08-18 16:05:31 --> Database Driver Class Initialized
INFO - 2020-08-18 16:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:05:31 --> Email Class Initialized
INFO - 2020-08-18 16:05:31 --> Controller Class Initialized
DEBUG - 2020-08-18 16:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:05:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:05:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:05:31 --> Final output sent to browser
DEBUG - 2020-08-18 16:05:31 --> Total execution time: 0.0210
INFO - 2020-08-18 16:05:54 --> Config Class Initialized
INFO - 2020-08-18 16:05:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:05:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:05:54 --> Utf8 Class Initialized
INFO - 2020-08-18 16:05:54 --> URI Class Initialized
INFO - 2020-08-18 16:05:54 --> Router Class Initialized
INFO - 2020-08-18 16:05:54 --> Output Class Initialized
INFO - 2020-08-18 16:05:54 --> Security Class Initialized
DEBUG - 2020-08-18 16:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:05:54 --> Input Class Initialized
INFO - 2020-08-18 16:05:54 --> Language Class Initialized
INFO - 2020-08-18 16:05:54 --> Loader Class Initialized
INFO - 2020-08-18 16:05:54 --> Helper loaded: url_helper
INFO - 2020-08-18 16:05:54 --> Database Driver Class Initialized
INFO - 2020-08-18 16:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:05:54 --> Email Class Initialized
INFO - 2020-08-18 16:05:54 --> Controller Class Initialized
DEBUG - 2020-08-18 16:05:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:05:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:05:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:05:54 --> Final output sent to browser
DEBUG - 2020-08-18 16:05:54 --> Total execution time: 0.0230
INFO - 2020-08-18 16:06:21 --> Config Class Initialized
INFO - 2020-08-18 16:06:21 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:06:21 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:06:21 --> Utf8 Class Initialized
INFO - 2020-08-18 16:06:21 --> URI Class Initialized
INFO - 2020-08-18 16:06:21 --> Router Class Initialized
INFO - 2020-08-18 16:06:21 --> Output Class Initialized
INFO - 2020-08-18 16:06:21 --> Security Class Initialized
DEBUG - 2020-08-18 16:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:06:21 --> Input Class Initialized
INFO - 2020-08-18 16:06:21 --> Language Class Initialized
INFO - 2020-08-18 16:06:21 --> Loader Class Initialized
INFO - 2020-08-18 16:06:21 --> Helper loaded: url_helper
INFO - 2020-08-18 16:06:21 --> Database Driver Class Initialized
INFO - 2020-08-18 16:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:06:21 --> Email Class Initialized
INFO - 2020-08-18 16:06:21 --> Controller Class Initialized
DEBUG - 2020-08-18 16:06:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:06:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:06:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:06:21 --> Final output sent to browser
DEBUG - 2020-08-18 16:06:21 --> Total execution time: 0.2962
INFO - 2020-08-18 16:06:58 --> Config Class Initialized
INFO - 2020-08-18 16:06:58 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:06:58 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:06:58 --> Utf8 Class Initialized
INFO - 2020-08-18 16:06:58 --> URI Class Initialized
INFO - 2020-08-18 16:06:58 --> Router Class Initialized
INFO - 2020-08-18 16:06:58 --> Output Class Initialized
INFO - 2020-08-18 16:06:58 --> Security Class Initialized
DEBUG - 2020-08-18 16:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:06:58 --> Input Class Initialized
INFO - 2020-08-18 16:06:58 --> Language Class Initialized
INFO - 2020-08-18 16:06:58 --> Loader Class Initialized
INFO - 2020-08-18 16:06:58 --> Helper loaded: url_helper
INFO - 2020-08-18 16:06:58 --> Database Driver Class Initialized
INFO - 2020-08-18 16:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:06:58 --> Email Class Initialized
INFO - 2020-08-18 16:06:58 --> Controller Class Initialized
DEBUG - 2020-08-18 16:06:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:06:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:06:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:06:58 --> Final output sent to browser
DEBUG - 2020-08-18 16:06:58 --> Total execution time: 0.0229
INFO - 2020-08-18 16:07:54 --> Config Class Initialized
INFO - 2020-08-18 16:07:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:07:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:07:54 --> Utf8 Class Initialized
INFO - 2020-08-18 16:07:54 --> URI Class Initialized
INFO - 2020-08-18 16:07:54 --> Router Class Initialized
INFO - 2020-08-18 16:07:54 --> Output Class Initialized
INFO - 2020-08-18 16:07:54 --> Security Class Initialized
DEBUG - 2020-08-18 16:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:07:54 --> Input Class Initialized
INFO - 2020-08-18 16:07:54 --> Language Class Initialized
INFO - 2020-08-18 16:07:54 --> Loader Class Initialized
INFO - 2020-08-18 16:07:54 --> Helper loaded: url_helper
INFO - 2020-08-18 16:07:54 --> Database Driver Class Initialized
INFO - 2020-08-18 16:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:07:54 --> Email Class Initialized
INFO - 2020-08-18 16:07:54 --> Controller Class Initialized
DEBUG - 2020-08-18 16:07:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:07:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:07:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:07:54 --> Final output sent to browser
DEBUG - 2020-08-18 16:07:54 --> Total execution time: 0.0206
INFO - 2020-08-18 16:09:02 --> Config Class Initialized
INFO - 2020-08-18 16:09:02 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:09:02 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:09:02 --> Utf8 Class Initialized
INFO - 2020-08-18 16:09:02 --> URI Class Initialized
INFO - 2020-08-18 16:09:02 --> Router Class Initialized
INFO - 2020-08-18 16:09:02 --> Output Class Initialized
INFO - 2020-08-18 16:09:02 --> Security Class Initialized
DEBUG - 2020-08-18 16:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:09:02 --> Input Class Initialized
INFO - 2020-08-18 16:09:02 --> Language Class Initialized
INFO - 2020-08-18 16:09:02 --> Loader Class Initialized
INFO - 2020-08-18 16:09:02 --> Helper loaded: url_helper
INFO - 2020-08-18 16:09:02 --> Database Driver Class Initialized
INFO - 2020-08-18 16:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:09:02 --> Email Class Initialized
INFO - 2020-08-18 16:09:02 --> Controller Class Initialized
DEBUG - 2020-08-18 16:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:09:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:09:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:09:02 --> Final output sent to browser
DEBUG - 2020-08-18 16:09:02 --> Total execution time: 0.0219
INFO - 2020-08-18 16:10:05 --> Config Class Initialized
INFO - 2020-08-18 16:10:05 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:10:05 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:10:05 --> Utf8 Class Initialized
INFO - 2020-08-18 16:10:05 --> URI Class Initialized
INFO - 2020-08-18 16:10:05 --> Router Class Initialized
INFO - 2020-08-18 16:10:05 --> Output Class Initialized
INFO - 2020-08-18 16:10:05 --> Security Class Initialized
DEBUG - 2020-08-18 16:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:10:05 --> Input Class Initialized
INFO - 2020-08-18 16:10:05 --> Language Class Initialized
INFO - 2020-08-18 16:10:05 --> Loader Class Initialized
INFO - 2020-08-18 16:10:05 --> Helper loaded: url_helper
INFO - 2020-08-18 16:10:05 --> Database Driver Class Initialized
INFO - 2020-08-18 16:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:10:05 --> Email Class Initialized
INFO - 2020-08-18 16:10:05 --> Controller Class Initialized
DEBUG - 2020-08-18 16:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:10:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:10:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:10:05 --> Final output sent to browser
DEBUG - 2020-08-18 16:10:05 --> Total execution time: 0.0216
INFO - 2020-08-18 16:12:19 --> Config Class Initialized
INFO - 2020-08-18 16:12:19 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:12:19 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:12:19 --> Utf8 Class Initialized
INFO - 2020-08-18 16:12:19 --> URI Class Initialized
INFO - 2020-08-18 16:12:19 --> Router Class Initialized
INFO - 2020-08-18 16:12:19 --> Output Class Initialized
INFO - 2020-08-18 16:12:19 --> Security Class Initialized
DEBUG - 2020-08-18 16:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:12:19 --> Input Class Initialized
INFO - 2020-08-18 16:12:19 --> Language Class Initialized
INFO - 2020-08-18 16:12:19 --> Loader Class Initialized
INFO - 2020-08-18 16:12:19 --> Helper loaded: url_helper
INFO - 2020-08-18 16:12:19 --> Database Driver Class Initialized
INFO - 2020-08-18 16:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:12:19 --> Email Class Initialized
INFO - 2020-08-18 16:12:19 --> Controller Class Initialized
DEBUG - 2020-08-18 16:12:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:12:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:12:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:12:19 --> Final output sent to browser
DEBUG - 2020-08-18 16:12:19 --> Total execution time: 0.0210
INFO - 2020-08-18 16:13:08 --> Config Class Initialized
INFO - 2020-08-18 16:13:08 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:13:08 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:13:08 --> Utf8 Class Initialized
INFO - 2020-08-18 16:13:08 --> URI Class Initialized
INFO - 2020-08-18 16:13:08 --> Router Class Initialized
INFO - 2020-08-18 16:13:08 --> Output Class Initialized
INFO - 2020-08-18 16:13:08 --> Security Class Initialized
DEBUG - 2020-08-18 16:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:13:08 --> Input Class Initialized
INFO - 2020-08-18 16:13:08 --> Language Class Initialized
INFO - 2020-08-18 16:13:08 --> Loader Class Initialized
INFO - 2020-08-18 16:13:08 --> Helper loaded: url_helper
INFO - 2020-08-18 16:13:08 --> Database Driver Class Initialized
INFO - 2020-08-18 16:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:13:08 --> Email Class Initialized
INFO - 2020-08-18 16:13:08 --> Controller Class Initialized
DEBUG - 2020-08-18 16:13:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:13:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:13:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:13:08 --> Final output sent to browser
DEBUG - 2020-08-18 16:13:08 --> Total execution time: 0.0286
INFO - 2020-08-18 16:14:30 --> Config Class Initialized
INFO - 2020-08-18 16:14:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:14:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:14:30 --> Utf8 Class Initialized
INFO - 2020-08-18 16:14:30 --> URI Class Initialized
INFO - 2020-08-18 16:14:30 --> Router Class Initialized
INFO - 2020-08-18 16:14:30 --> Output Class Initialized
INFO - 2020-08-18 16:14:30 --> Security Class Initialized
DEBUG - 2020-08-18 16:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:14:30 --> Input Class Initialized
INFO - 2020-08-18 16:14:30 --> Language Class Initialized
INFO - 2020-08-18 16:14:30 --> Loader Class Initialized
INFO - 2020-08-18 16:14:30 --> Helper loaded: url_helper
INFO - 2020-08-18 16:14:30 --> Database Driver Class Initialized
INFO - 2020-08-18 16:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:14:30 --> Email Class Initialized
INFO - 2020-08-18 16:14:30 --> Controller Class Initialized
DEBUG - 2020-08-18 16:14:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:14:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:14:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:14:30 --> Final output sent to browser
DEBUG - 2020-08-18 16:14:30 --> Total execution time: 0.0256
INFO - 2020-08-18 16:18:06 --> Config Class Initialized
INFO - 2020-08-18 16:18:06 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:18:06 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:18:06 --> Utf8 Class Initialized
INFO - 2020-08-18 16:18:06 --> URI Class Initialized
INFO - 2020-08-18 16:18:06 --> Router Class Initialized
INFO - 2020-08-18 16:18:06 --> Output Class Initialized
INFO - 2020-08-18 16:18:06 --> Security Class Initialized
DEBUG - 2020-08-18 16:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:18:06 --> Input Class Initialized
INFO - 2020-08-18 16:18:06 --> Language Class Initialized
INFO - 2020-08-18 16:18:06 --> Loader Class Initialized
INFO - 2020-08-18 16:18:06 --> Helper loaded: url_helper
INFO - 2020-08-18 16:18:06 --> Database Driver Class Initialized
INFO - 2020-08-18 16:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:18:06 --> Email Class Initialized
INFO - 2020-08-18 16:18:06 --> Controller Class Initialized
DEBUG - 2020-08-18 16:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:18:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:18:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:18:06 --> Final output sent to browser
DEBUG - 2020-08-18 16:18:06 --> Total execution time: 0.0204
INFO - 2020-08-18 16:19:10 --> Config Class Initialized
INFO - 2020-08-18 16:19:10 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:19:10 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:10 --> Utf8 Class Initialized
INFO - 2020-08-18 16:19:10 --> URI Class Initialized
DEBUG - 2020-08-18 16:19:10 --> No URI present. Default controller set.
INFO - 2020-08-18 16:19:10 --> Router Class Initialized
INFO - 2020-08-18 16:19:10 --> Output Class Initialized
INFO - 2020-08-18 16:19:10 --> Security Class Initialized
DEBUG - 2020-08-18 16:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:10 --> Input Class Initialized
INFO - 2020-08-18 16:19:10 --> Language Class Initialized
INFO - 2020-08-18 16:19:10 --> Loader Class Initialized
INFO - 2020-08-18 16:19:10 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:10 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:10 --> Email Class Initialized
INFO - 2020-08-18 16:19:10 --> Controller Class Initialized
INFO - 2020-08-18 16:19:10 --> Model Class Initialized
INFO - 2020-08-18 16:19:10 --> Model Class Initialized
DEBUG - 2020-08-18 16:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 16:19:10 --> Final output sent to browser
DEBUG - 2020-08-18 16:19:10 --> Total execution time: 0.0222
INFO - 2020-08-18 16:19:10 --> Config Class Initialized
INFO - 2020-08-18 16:19:10 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:19:10 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:10 --> Utf8 Class Initialized
INFO - 2020-08-18 16:19:10 --> URI Class Initialized
DEBUG - 2020-08-18 16:19:10 --> No URI present. Default controller set.
INFO - 2020-08-18 16:19:10 --> Router Class Initialized
INFO - 2020-08-18 16:19:10 --> Output Class Initialized
INFO - 2020-08-18 16:19:10 --> Security Class Initialized
DEBUG - 2020-08-18 16:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:10 --> Input Class Initialized
INFO - 2020-08-18 16:19:10 --> Language Class Initialized
INFO - 2020-08-18 16:19:10 --> Loader Class Initialized
INFO - 2020-08-18 16:19:10 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:10 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:10 --> Email Class Initialized
INFO - 2020-08-18 16:19:10 --> Controller Class Initialized
INFO - 2020-08-18 16:19:10 --> Model Class Initialized
INFO - 2020-08-18 16:19:10 --> Model Class Initialized
DEBUG - 2020-08-18 16:19:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 16:19:10 --> Final output sent to browser
DEBUG - 2020-08-18 16:19:10 --> Total execution time: 0.0227
INFO - 2020-08-18 16:19:19 --> Config Class Initialized
INFO - 2020-08-18 16:19:19 --> Config Class Initialized
INFO - 2020-08-18 16:19:19 --> Hooks Class Initialized
INFO - 2020-08-18 16:19:19 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:19:19 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:19 --> Utf8 Class Initialized
DEBUG - 2020-08-18 16:19:19 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:19 --> Utf8 Class Initialized
INFO - 2020-08-18 16:19:19 --> URI Class Initialized
INFO - 2020-08-18 16:19:19 --> URI Class Initialized
INFO - 2020-08-18 16:19:19 --> Router Class Initialized
INFO - 2020-08-18 16:19:19 --> Router Class Initialized
INFO - 2020-08-18 16:19:19 --> Output Class Initialized
INFO - 2020-08-18 16:19:19 --> Output Class Initialized
INFO - 2020-08-18 16:19:19 --> Security Class Initialized
INFO - 2020-08-18 16:19:19 --> Security Class Initialized
DEBUG - 2020-08-18 16:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:19 --> Input Class Initialized
DEBUG - 2020-08-18 16:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:19 --> Input Class Initialized
INFO - 2020-08-18 16:19:19 --> Language Class Initialized
INFO - 2020-08-18 16:19:19 --> Language Class Initialized
INFO - 2020-08-18 16:19:19 --> Loader Class Initialized
INFO - 2020-08-18 16:19:19 --> Loader Class Initialized
INFO - 2020-08-18 16:19:19 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:19 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:19 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:19 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:19 --> Email Class Initialized
INFO - 2020-08-18 16:19:19 --> Controller Class Initialized
INFO - 2020-08-18 16:19:19 --> Model Class Initialized
INFO - 2020-08-18 16:19:19 --> Model Class Initialized
DEBUG - 2020-08-18 16:19:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:19 --> Email Class Initialized
INFO - 2020-08-18 16:19:19 --> Controller Class Initialized
INFO - 2020-08-18 16:19:19 --> Model Class Initialized
INFO - 2020-08-18 16:19:19 --> Model Class Initialized
DEBUG - 2020-08-18 16:19:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:19:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:19 --> Model Class Initialized
INFO - 2020-08-18 16:19:19 --> Final output sent to browser
DEBUG - 2020-08-18 16:19:19 --> Total execution time: 0.0352
INFO - 2020-08-18 16:19:20 --> Config Class Initialized
INFO - 2020-08-18 16:19:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:19:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:20 --> Utf8 Class Initialized
INFO - 2020-08-18 16:19:20 --> URI Class Initialized
INFO - 2020-08-18 16:19:20 --> Router Class Initialized
INFO - 2020-08-18 16:19:20 --> Output Class Initialized
INFO - 2020-08-18 16:19:20 --> Security Class Initialized
DEBUG - 2020-08-18 16:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:20 --> Input Class Initialized
INFO - 2020-08-18 16:19:20 --> Language Class Initialized
INFO - 2020-08-18 16:19:20 --> Loader Class Initialized
INFO - 2020-08-18 16:19:20 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:20 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:20 --> Email Class Initialized
INFO - 2020-08-18 16:19:20 --> Controller Class Initialized
DEBUG - 2020-08-18 16:19:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:19:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:19:20 --> Final output sent to browser
DEBUG - 2020-08-18 16:19:20 --> Total execution time: 0.0249
INFO - 2020-08-18 16:19:45 --> Config Class Initialized
INFO - 2020-08-18 16:19:45 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:19:45 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:45 --> Utf8 Class Initialized
INFO - 2020-08-18 16:19:45 --> URI Class Initialized
INFO - 2020-08-18 16:19:45 --> Router Class Initialized
INFO - 2020-08-18 16:19:45 --> Output Class Initialized
INFO - 2020-08-18 16:19:45 --> Security Class Initialized
DEBUG - 2020-08-18 16:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:45 --> Input Class Initialized
INFO - 2020-08-18 16:19:45 --> Language Class Initialized
INFO - 2020-08-18 16:19:45 --> Loader Class Initialized
INFO - 2020-08-18 16:19:45 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:45 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:45 --> Email Class Initialized
INFO - 2020-08-18 16:19:45 --> Controller Class Initialized
DEBUG - 2020-08-18 16:19:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:19:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:45 --> Model Class Initialized
INFO - 2020-08-18 16:19:45 --> Model Class Initialized
INFO - 2020-08-18 16:19:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 16:19:45 --> Final output sent to browser
DEBUG - 2020-08-18 16:19:45 --> Total execution time: 0.0233
INFO - 2020-08-18 16:19:52 --> Config Class Initialized
INFO - 2020-08-18 16:19:52 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:19:52 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:19:52 --> Utf8 Class Initialized
INFO - 2020-08-18 16:19:52 --> URI Class Initialized
INFO - 2020-08-18 16:19:52 --> Router Class Initialized
INFO - 2020-08-18 16:19:52 --> Output Class Initialized
INFO - 2020-08-18 16:19:52 --> Security Class Initialized
DEBUG - 2020-08-18 16:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:19:52 --> Input Class Initialized
INFO - 2020-08-18 16:19:52 --> Language Class Initialized
INFO - 2020-08-18 16:19:52 --> Loader Class Initialized
INFO - 2020-08-18 16:19:52 --> Helper loaded: url_helper
INFO - 2020-08-18 16:19:52 --> Database Driver Class Initialized
INFO - 2020-08-18 16:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:19:52 --> Email Class Initialized
INFO - 2020-08-18 16:19:52 --> Controller Class Initialized
DEBUG - 2020-08-18 16:19:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:19:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:19:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:19:52 --> Final output sent to browser
DEBUG - 2020-08-18 16:19:52 --> Total execution time: 0.0201
INFO - 2020-08-18 16:20:24 --> Config Class Initialized
INFO - 2020-08-18 16:20:24 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:20:24 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:20:24 --> Utf8 Class Initialized
INFO - 2020-08-18 16:20:24 --> URI Class Initialized
DEBUG - 2020-08-18 16:20:24 --> No URI present. Default controller set.
INFO - 2020-08-18 16:20:24 --> Router Class Initialized
INFO - 2020-08-18 16:20:24 --> Output Class Initialized
INFO - 2020-08-18 16:20:24 --> Security Class Initialized
DEBUG - 2020-08-18 16:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:20:24 --> Input Class Initialized
INFO - 2020-08-18 16:20:24 --> Language Class Initialized
INFO - 2020-08-18 16:20:24 --> Loader Class Initialized
INFO - 2020-08-18 16:20:24 --> Helper loaded: url_helper
INFO - 2020-08-18 16:20:24 --> Database Driver Class Initialized
INFO - 2020-08-18 16:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:20:24 --> Email Class Initialized
INFO - 2020-08-18 16:20:24 --> Controller Class Initialized
INFO - 2020-08-18 16:20:24 --> Model Class Initialized
INFO - 2020-08-18 16:20:24 --> Model Class Initialized
DEBUG - 2020-08-18 16:20:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:20:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 16:20:24 --> Final output sent to browser
DEBUG - 2020-08-18 16:20:24 --> Total execution time: 0.0210
INFO - 2020-08-18 16:23:53 --> Config Class Initialized
INFO - 2020-08-18 16:23:53 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:23:53 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:23:53 --> Utf8 Class Initialized
INFO - 2020-08-18 16:23:53 --> URI Class Initialized
INFO - 2020-08-18 16:23:53 --> Router Class Initialized
INFO - 2020-08-18 16:23:53 --> Output Class Initialized
INFO - 2020-08-18 16:23:53 --> Security Class Initialized
DEBUG - 2020-08-18 16:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:23:53 --> Input Class Initialized
INFO - 2020-08-18 16:23:53 --> Language Class Initialized
INFO - 2020-08-18 16:23:53 --> Loader Class Initialized
INFO - 2020-08-18 16:23:53 --> Helper loaded: url_helper
INFO - 2020-08-18 16:23:53 --> Database Driver Class Initialized
INFO - 2020-08-18 16:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:23:53 --> Email Class Initialized
INFO - 2020-08-18 16:23:53 --> Controller Class Initialized
DEBUG - 2020-08-18 16:23:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:23:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:23:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:23:53 --> Final output sent to browser
DEBUG - 2020-08-18 16:23:53 --> Total execution time: 0.0248
INFO - 2020-08-18 16:27:11 --> Config Class Initialized
INFO - 2020-08-18 16:27:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:27:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:27:11 --> Utf8 Class Initialized
INFO - 2020-08-18 16:27:11 --> URI Class Initialized
INFO - 2020-08-18 16:27:11 --> Router Class Initialized
INFO - 2020-08-18 16:27:11 --> Output Class Initialized
INFO - 2020-08-18 16:27:11 --> Security Class Initialized
DEBUG - 2020-08-18 16:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:27:11 --> Input Class Initialized
INFO - 2020-08-18 16:27:11 --> Language Class Initialized
INFO - 2020-08-18 16:27:11 --> Loader Class Initialized
INFO - 2020-08-18 16:27:11 --> Helper loaded: url_helper
INFO - 2020-08-18 16:27:11 --> Database Driver Class Initialized
INFO - 2020-08-18 16:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:27:11 --> Email Class Initialized
INFO - 2020-08-18 16:27:11 --> Controller Class Initialized
DEBUG - 2020-08-18 16:27:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:27:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:27:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:27:11 --> Final output sent to browser
DEBUG - 2020-08-18 16:27:11 --> Total execution time: 0.0204
INFO - 2020-08-18 16:32:30 --> Config Class Initialized
INFO - 2020-08-18 16:32:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:32:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:32:30 --> Utf8 Class Initialized
INFO - 2020-08-18 16:32:30 --> URI Class Initialized
INFO - 2020-08-18 16:32:30 --> Router Class Initialized
INFO - 2020-08-18 16:32:30 --> Output Class Initialized
INFO - 2020-08-18 16:32:30 --> Security Class Initialized
DEBUG - 2020-08-18 16:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:32:30 --> Input Class Initialized
INFO - 2020-08-18 16:32:30 --> Language Class Initialized
INFO - 2020-08-18 16:32:30 --> Loader Class Initialized
INFO - 2020-08-18 16:32:30 --> Helper loaded: url_helper
INFO - 2020-08-18 16:32:30 --> Database Driver Class Initialized
INFO - 2020-08-18 16:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:32:30 --> Email Class Initialized
INFO - 2020-08-18 16:32:30 --> Controller Class Initialized
DEBUG - 2020-08-18 16:32:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:32:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:32:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:32:30 --> Final output sent to browser
DEBUG - 2020-08-18 16:32:30 --> Total execution time: 0.0194
INFO - 2020-08-18 16:33:33 --> Config Class Initialized
INFO - 2020-08-18 16:33:33 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:33:33 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:33:33 --> Utf8 Class Initialized
INFO - 2020-08-18 16:33:33 --> URI Class Initialized
INFO - 2020-08-18 16:33:33 --> Router Class Initialized
INFO - 2020-08-18 16:33:33 --> Output Class Initialized
INFO - 2020-08-18 16:33:33 --> Security Class Initialized
DEBUG - 2020-08-18 16:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:33:33 --> Input Class Initialized
INFO - 2020-08-18 16:33:33 --> Language Class Initialized
INFO - 2020-08-18 16:33:33 --> Loader Class Initialized
INFO - 2020-08-18 16:33:33 --> Helper loaded: url_helper
INFO - 2020-08-18 16:33:33 --> Database Driver Class Initialized
INFO - 2020-08-18 16:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:33:33 --> Email Class Initialized
INFO - 2020-08-18 16:33:33 --> Controller Class Initialized
DEBUG - 2020-08-18 16:33:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:33:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:33:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:33:33 --> Final output sent to browser
DEBUG - 2020-08-18 16:33:33 --> Total execution time: 0.0215
INFO - 2020-08-18 16:37:10 --> Config Class Initialized
INFO - 2020-08-18 16:37:10 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:37:10 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:37:10 --> Utf8 Class Initialized
INFO - 2020-08-18 16:37:10 --> URI Class Initialized
INFO - 2020-08-18 16:37:10 --> Router Class Initialized
INFO - 2020-08-18 16:37:10 --> Output Class Initialized
INFO - 2020-08-18 16:37:10 --> Security Class Initialized
DEBUG - 2020-08-18 16:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:37:10 --> Input Class Initialized
INFO - 2020-08-18 16:37:10 --> Language Class Initialized
INFO - 2020-08-18 16:37:10 --> Loader Class Initialized
INFO - 2020-08-18 16:37:10 --> Helper loaded: url_helper
INFO - 2020-08-18 16:37:10 --> Database Driver Class Initialized
INFO - 2020-08-18 16:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:37:10 --> Email Class Initialized
INFO - 2020-08-18 16:37:10 --> Controller Class Initialized
DEBUG - 2020-08-18 16:37:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:37:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:37:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:37:10 --> Final output sent to browser
DEBUG - 2020-08-18 16:37:10 --> Total execution time: 0.0240
INFO - 2020-08-18 16:38:31 --> Config Class Initialized
INFO - 2020-08-18 16:38:31 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:38:31 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:38:31 --> Utf8 Class Initialized
INFO - 2020-08-18 16:38:31 --> URI Class Initialized
INFO - 2020-08-18 16:38:31 --> Router Class Initialized
INFO - 2020-08-18 16:38:31 --> Output Class Initialized
INFO - 2020-08-18 16:38:31 --> Security Class Initialized
DEBUG - 2020-08-18 16:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:38:31 --> Input Class Initialized
INFO - 2020-08-18 16:38:31 --> Language Class Initialized
INFO - 2020-08-18 16:38:31 --> Loader Class Initialized
INFO - 2020-08-18 16:38:31 --> Helper loaded: url_helper
INFO - 2020-08-18 16:38:31 --> Database Driver Class Initialized
INFO - 2020-08-18 16:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:38:31 --> Email Class Initialized
INFO - 2020-08-18 16:38:31 --> Controller Class Initialized
DEBUG - 2020-08-18 16:38:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:38:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:38:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:38:31 --> Final output sent to browser
DEBUG - 2020-08-18 16:38:31 --> Total execution time: 0.0243
INFO - 2020-08-18 16:48:50 --> Config Class Initialized
INFO - 2020-08-18 16:48:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:48:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:48:50 --> Utf8 Class Initialized
INFO - 2020-08-18 16:48:50 --> URI Class Initialized
INFO - 2020-08-18 16:48:50 --> Router Class Initialized
INFO - 2020-08-18 16:48:50 --> Output Class Initialized
INFO - 2020-08-18 16:48:50 --> Security Class Initialized
DEBUG - 2020-08-18 16:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:48:50 --> Input Class Initialized
INFO - 2020-08-18 16:48:50 --> Language Class Initialized
INFO - 2020-08-18 16:48:50 --> Loader Class Initialized
INFO - 2020-08-18 16:48:50 --> Helper loaded: url_helper
INFO - 2020-08-18 16:48:50 --> Database Driver Class Initialized
INFO - 2020-08-18 16:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:48:50 --> Email Class Initialized
INFO - 2020-08-18 16:48:50 --> Controller Class Initialized
DEBUG - 2020-08-18 16:48:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:48:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:48:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:48:50 --> Final output sent to browser
DEBUG - 2020-08-18 16:48:50 --> Total execution time: 0.0271
INFO - 2020-08-18 16:48:59 --> Config Class Initialized
INFO - 2020-08-18 16:48:59 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:48:59 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:48:59 --> Utf8 Class Initialized
INFO - 2020-08-18 16:48:59 --> URI Class Initialized
INFO - 2020-08-18 16:48:59 --> Router Class Initialized
INFO - 2020-08-18 16:48:59 --> Output Class Initialized
INFO - 2020-08-18 16:48:59 --> Security Class Initialized
DEBUG - 2020-08-18 16:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:48:59 --> Input Class Initialized
INFO - 2020-08-18 16:48:59 --> Language Class Initialized
INFO - 2020-08-18 16:48:59 --> Loader Class Initialized
INFO - 2020-08-18 16:48:59 --> Helper loaded: url_helper
INFO - 2020-08-18 16:49:00 --> Database Driver Class Initialized
INFO - 2020-08-18 16:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:49:00 --> Email Class Initialized
INFO - 2020-08-18 16:49:00 --> Controller Class Initialized
DEBUG - 2020-08-18 16:49:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:49:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:49:00 --> Model Class Initialized
INFO - 2020-08-18 16:49:00 --> Model Class Initialized
INFO - 2020-08-18 16:49:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 16:49:00 --> Final output sent to browser
DEBUG - 2020-08-18 16:49:00 --> Total execution time: 0.0263
INFO - 2020-08-18 16:49:05 --> Config Class Initialized
INFO - 2020-08-18 16:49:05 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:49:05 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:49:05 --> Utf8 Class Initialized
INFO - 2020-08-18 16:49:05 --> URI Class Initialized
INFO - 2020-08-18 16:49:05 --> Router Class Initialized
INFO - 2020-08-18 16:49:05 --> Output Class Initialized
INFO - 2020-08-18 16:49:05 --> Security Class Initialized
DEBUG - 2020-08-18 16:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:49:05 --> Input Class Initialized
INFO - 2020-08-18 16:49:05 --> Language Class Initialized
INFO - 2020-08-18 16:49:05 --> Loader Class Initialized
INFO - 2020-08-18 16:49:05 --> Helper loaded: url_helper
INFO - 2020-08-18 16:49:05 --> Database Driver Class Initialized
INFO - 2020-08-18 16:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:49:05 --> Email Class Initialized
INFO - 2020-08-18 16:49:05 --> Controller Class Initialized
DEBUG - 2020-08-18 16:49:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:49:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:49:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:49:05 --> Final output sent to browser
DEBUG - 2020-08-18 16:49:05 --> Total execution time: 0.0233
INFO - 2020-08-18 16:49:52 --> Config Class Initialized
INFO - 2020-08-18 16:49:52 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:49:52 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:49:52 --> Utf8 Class Initialized
INFO - 2020-08-18 16:49:52 --> URI Class Initialized
INFO - 2020-08-18 16:49:52 --> Router Class Initialized
INFO - 2020-08-18 16:49:52 --> Output Class Initialized
INFO - 2020-08-18 16:49:52 --> Security Class Initialized
DEBUG - 2020-08-18 16:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:49:52 --> Input Class Initialized
INFO - 2020-08-18 16:49:52 --> Language Class Initialized
INFO - 2020-08-18 16:49:52 --> Loader Class Initialized
INFO - 2020-08-18 16:49:52 --> Helper loaded: url_helper
INFO - 2020-08-18 16:49:52 --> Database Driver Class Initialized
INFO - 2020-08-18 16:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:49:52 --> Email Class Initialized
INFO - 2020-08-18 16:49:52 --> Controller Class Initialized
DEBUG - 2020-08-18 16:49:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:49:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:49:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:49:52 --> Final output sent to browser
DEBUG - 2020-08-18 16:49:52 --> Total execution time: 0.0232
INFO - 2020-08-18 16:51:00 --> Config Class Initialized
INFO - 2020-08-18 16:51:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:00 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:00 --> URI Class Initialized
INFO - 2020-08-18 16:51:00 --> Router Class Initialized
INFO - 2020-08-18 16:51:00 --> Output Class Initialized
INFO - 2020-08-18 16:51:00 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:00 --> Input Class Initialized
INFO - 2020-08-18 16:51:00 --> Language Class Initialized
INFO - 2020-08-18 16:51:00 --> Loader Class Initialized
INFO - 2020-08-18 16:51:00 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:00 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:00 --> Email Class Initialized
INFO - 2020-08-18 16:51:00 --> Controller Class Initialized
DEBUG - 2020-08-18 16:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:51:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:00 --> Model Class Initialized
INFO - 2020-08-18 16:51:00 --> Model Class Initialized
INFO - 2020-08-18 16:51:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 16:51:00 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:00 --> Total execution time: 0.0319
INFO - 2020-08-18 16:51:20 --> Config Class Initialized
INFO - 2020-08-18 16:51:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:20 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:20 --> URI Class Initialized
INFO - 2020-08-18 16:51:20 --> Router Class Initialized
INFO - 2020-08-18 16:51:20 --> Output Class Initialized
INFO - 2020-08-18 16:51:20 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:20 --> Input Class Initialized
INFO - 2020-08-18 16:51:20 --> Language Class Initialized
INFO - 2020-08-18 16:51:20 --> Loader Class Initialized
INFO - 2020-08-18 16:51:20 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:20 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:20 --> Email Class Initialized
INFO - 2020-08-18 16:51:20 --> Controller Class Initialized
DEBUG - 2020-08-18 16:51:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:51:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:20 --> Model Class Initialized
INFO - 2020-08-18 16:51:20 --> Model Class Initialized
INFO - 2020-08-18 16:51:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 16:51:20 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:20 --> Total execution time: 0.0288
INFO - 2020-08-18 16:51:25 --> Config Class Initialized
INFO - 2020-08-18 16:51:25 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:25 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:25 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:25 --> URI Class Initialized
INFO - 2020-08-18 16:51:25 --> Router Class Initialized
INFO - 2020-08-18 16:51:25 --> Output Class Initialized
INFO - 2020-08-18 16:51:25 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:25 --> Input Class Initialized
INFO - 2020-08-18 16:51:25 --> Language Class Initialized
INFO - 2020-08-18 16:51:25 --> Loader Class Initialized
INFO - 2020-08-18 16:51:25 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:25 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:25 --> Email Class Initialized
INFO - 2020-08-18 16:51:25 --> Controller Class Initialized
DEBUG - 2020-08-18 16:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:51:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 16:51:25 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:25 --> Total execution time: 0.0213
INFO - 2020-08-18 16:51:30 --> Config Class Initialized
INFO - 2020-08-18 16:51:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:30 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:30 --> URI Class Initialized
DEBUG - 2020-08-18 16:51:30 --> No URI present. Default controller set.
INFO - 2020-08-18 16:51:30 --> Router Class Initialized
INFO - 2020-08-18 16:51:30 --> Output Class Initialized
INFO - 2020-08-18 16:51:30 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:30 --> Input Class Initialized
INFO - 2020-08-18 16:51:30 --> Language Class Initialized
INFO - 2020-08-18 16:51:30 --> Loader Class Initialized
INFO - 2020-08-18 16:51:30 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:30 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:30 --> Email Class Initialized
INFO - 2020-08-18 16:51:30 --> Controller Class Initialized
INFO - 2020-08-18 16:51:30 --> Model Class Initialized
INFO - 2020-08-18 16:51:30 --> Model Class Initialized
DEBUG - 2020-08-18 16:51:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 16:51:30 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:30 --> Total execution time: 0.0231
INFO - 2020-08-18 16:51:34 --> Config Class Initialized
INFO - 2020-08-18 16:51:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:34 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:34 --> URI Class Initialized
INFO - 2020-08-18 16:51:34 --> Router Class Initialized
INFO - 2020-08-18 16:51:34 --> Output Class Initialized
INFO - 2020-08-18 16:51:34 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:34 --> Input Class Initialized
INFO - 2020-08-18 16:51:34 --> Language Class Initialized
INFO - 2020-08-18 16:51:34 --> Loader Class Initialized
INFO - 2020-08-18 16:51:34 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:34 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:34 --> Email Class Initialized
INFO - 2020-08-18 16:51:34 --> Controller Class Initialized
INFO - 2020-08-18 16:51:34 --> Model Class Initialized
INFO - 2020-08-18 16:51:34 --> Model Class Initialized
DEBUG - 2020-08-18 16:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:51:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:34 --> Model Class Initialized
INFO - 2020-08-18 16:51:34 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:34 --> Total execution time: 0.0261
INFO - 2020-08-18 16:51:34 --> Config Class Initialized
INFO - 2020-08-18 16:51:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:34 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:34 --> URI Class Initialized
INFO - 2020-08-18 16:51:34 --> Router Class Initialized
INFO - 2020-08-18 16:51:34 --> Output Class Initialized
INFO - 2020-08-18 16:51:34 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:34 --> Input Class Initialized
INFO - 2020-08-18 16:51:34 --> Language Class Initialized
INFO - 2020-08-18 16:51:34 --> Loader Class Initialized
INFO - 2020-08-18 16:51:34 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:34 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:34 --> Email Class Initialized
INFO - 2020-08-18 16:51:34 --> Controller Class Initialized
INFO - 2020-08-18 16:51:34 --> Model Class Initialized
INFO - 2020-08-18 16:51:34 --> Model Class Initialized
DEBUG - 2020-08-18 16:51:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:34 --> Config Class Initialized
INFO - 2020-08-18 16:51:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:34 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:34 --> URI Class Initialized
INFO - 2020-08-18 16:51:34 --> Router Class Initialized
INFO - 2020-08-18 16:51:34 --> Output Class Initialized
INFO - 2020-08-18 16:51:34 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:34 --> Input Class Initialized
INFO - 2020-08-18 16:51:34 --> Language Class Initialized
INFO - 2020-08-18 16:51:34 --> Loader Class Initialized
INFO - 2020-08-18 16:51:34 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:34 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:34 --> Email Class Initialized
INFO - 2020-08-18 16:51:34 --> Controller Class Initialized
DEBUG - 2020-08-18 16:51:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:51:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 16:51:34 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:34 --> Total execution time: 0.0215
INFO - 2020-08-18 16:51:38 --> Config Class Initialized
INFO - 2020-08-18 16:51:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:51:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:51:38 --> Utf8 Class Initialized
INFO - 2020-08-18 16:51:38 --> URI Class Initialized
INFO - 2020-08-18 16:51:38 --> Router Class Initialized
INFO - 2020-08-18 16:51:38 --> Output Class Initialized
INFO - 2020-08-18 16:51:38 --> Security Class Initialized
DEBUG - 2020-08-18 16:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:51:38 --> Input Class Initialized
INFO - 2020-08-18 16:51:38 --> Language Class Initialized
INFO - 2020-08-18 16:51:38 --> Loader Class Initialized
INFO - 2020-08-18 16:51:38 --> Helper loaded: url_helper
INFO - 2020-08-18 16:51:38 --> Database Driver Class Initialized
INFO - 2020-08-18 16:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:51:38 --> Email Class Initialized
INFO - 2020-08-18 16:51:38 --> Controller Class Initialized
DEBUG - 2020-08-18 16:51:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:51:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:51:38 --> Model Class Initialized
INFO - 2020-08-18 16:51:38 --> Model Class Initialized
INFO - 2020-08-18 16:51:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 16:51:38 --> Final output sent to browser
DEBUG - 2020-08-18 16:51:38 --> Total execution time: 0.0257
INFO - 2020-08-18 16:55:23 --> Config Class Initialized
INFO - 2020-08-18 16:55:23 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:55:23 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:55:23 --> Utf8 Class Initialized
INFO - 2020-08-18 16:55:23 --> URI Class Initialized
INFO - 2020-08-18 16:55:23 --> Router Class Initialized
INFO - 2020-08-18 16:55:23 --> Output Class Initialized
INFO - 2020-08-18 16:55:23 --> Security Class Initialized
DEBUG - 2020-08-18 16:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:55:23 --> Input Class Initialized
INFO - 2020-08-18 16:55:23 --> Language Class Initialized
INFO - 2020-08-18 16:55:23 --> Loader Class Initialized
INFO - 2020-08-18 16:55:23 --> Helper loaded: url_helper
INFO - 2020-08-18 16:55:23 --> Database Driver Class Initialized
INFO - 2020-08-18 16:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:55:23 --> Email Class Initialized
INFO - 2020-08-18 16:55:23 --> Controller Class Initialized
DEBUG - 2020-08-18 16:55:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:55:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:55:23 --> Model Class Initialized
INFO - 2020-08-18 16:55:23 --> Model Class Initialized
INFO - 2020-08-18 16:55:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 16:55:23 --> Final output sent to browser
DEBUG - 2020-08-18 16:55:23 --> Total execution time: 0.0248
INFO - 2020-08-18 16:55:28 --> Config Class Initialized
INFO - 2020-08-18 16:55:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:55:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:55:28 --> Utf8 Class Initialized
INFO - 2020-08-18 16:55:28 --> URI Class Initialized
DEBUG - 2020-08-18 16:55:28 --> No URI present. Default controller set.
INFO - 2020-08-18 16:55:28 --> Router Class Initialized
INFO - 2020-08-18 16:55:28 --> Output Class Initialized
INFO - 2020-08-18 16:55:28 --> Security Class Initialized
DEBUG - 2020-08-18 16:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:55:28 --> Input Class Initialized
INFO - 2020-08-18 16:55:28 --> Language Class Initialized
INFO - 2020-08-18 16:55:28 --> Loader Class Initialized
INFO - 2020-08-18 16:55:28 --> Helper loaded: url_helper
INFO - 2020-08-18 16:55:28 --> Database Driver Class Initialized
INFO - 2020-08-18 16:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:55:28 --> Email Class Initialized
INFO - 2020-08-18 16:55:28 --> Controller Class Initialized
INFO - 2020-08-18 16:55:28 --> Model Class Initialized
INFO - 2020-08-18 16:55:28 --> Model Class Initialized
DEBUG - 2020-08-18 16:55:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:55:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 16:55:28 --> Final output sent to browser
DEBUG - 2020-08-18 16:55:28 --> Total execution time: 0.0237
INFO - 2020-08-18 16:55:48 --> Config Class Initialized
INFO - 2020-08-18 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:55:48 --> Utf8 Class Initialized
INFO - 2020-08-18 16:55:48 --> URI Class Initialized
INFO - 2020-08-18 16:55:48 --> Router Class Initialized
INFO - 2020-08-18 16:55:48 --> Output Class Initialized
INFO - 2020-08-18 16:55:48 --> Security Class Initialized
DEBUG - 2020-08-18 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:55:48 --> Input Class Initialized
INFO - 2020-08-18 16:55:48 --> Language Class Initialized
INFO - 2020-08-18 16:55:48 --> Loader Class Initialized
INFO - 2020-08-18 16:55:48 --> Helper loaded: url_helper
INFO - 2020-08-18 16:55:48 --> Database Driver Class Initialized
INFO - 2020-08-18 16:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:55:48 --> Email Class Initialized
INFO - 2020-08-18 16:55:48 --> Controller Class Initialized
INFO - 2020-08-18 16:55:48 --> Model Class Initialized
INFO - 2020-08-18 16:55:48 --> Model Class Initialized
DEBUG - 2020-08-18 16:55:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:55:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:55:48 --> Model Class Initialized
INFO - 2020-08-18 16:55:48 --> Final output sent to browser
DEBUG - 2020-08-18 16:55:48 --> Total execution time: 0.0281
INFO - 2020-08-18 16:55:48 --> Config Class Initialized
INFO - 2020-08-18 16:55:48 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:55:48 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:55:48 --> Utf8 Class Initialized
INFO - 2020-08-18 16:55:48 --> URI Class Initialized
INFO - 2020-08-18 16:55:48 --> Router Class Initialized
INFO - 2020-08-18 16:55:48 --> Output Class Initialized
INFO - 2020-08-18 16:55:48 --> Security Class Initialized
DEBUG - 2020-08-18 16:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:55:48 --> Input Class Initialized
INFO - 2020-08-18 16:55:48 --> Language Class Initialized
INFO - 2020-08-18 16:55:48 --> Loader Class Initialized
INFO - 2020-08-18 16:55:48 --> Helper loaded: url_helper
INFO - 2020-08-18 16:55:48 --> Database Driver Class Initialized
INFO - 2020-08-18 16:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:55:48 --> Email Class Initialized
INFO - 2020-08-18 16:55:48 --> Controller Class Initialized
INFO - 2020-08-18 16:55:48 --> Model Class Initialized
INFO - 2020-08-18 16:55:48 --> Model Class Initialized
DEBUG - 2020-08-18 16:55:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:55:49 --> Config Class Initialized
INFO - 2020-08-18 16:55:49 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:55:49 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:55:49 --> Utf8 Class Initialized
INFO - 2020-08-18 16:55:49 --> URI Class Initialized
INFO - 2020-08-18 16:55:49 --> Router Class Initialized
INFO - 2020-08-18 16:55:49 --> Output Class Initialized
INFO - 2020-08-18 16:55:49 --> Security Class Initialized
DEBUG - 2020-08-18 16:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:55:49 --> Input Class Initialized
INFO - 2020-08-18 16:55:49 --> Language Class Initialized
INFO - 2020-08-18 16:55:49 --> Loader Class Initialized
INFO - 2020-08-18 16:55:49 --> Helper loaded: url_helper
INFO - 2020-08-18 16:55:49 --> Database Driver Class Initialized
INFO - 2020-08-18 16:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:55:49 --> Email Class Initialized
INFO - 2020-08-18 16:55:49 --> Controller Class Initialized
DEBUG - 2020-08-18 16:55:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:55:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:55:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 16:55:49 --> Final output sent to browser
DEBUG - 2020-08-18 16:55:49 --> Total execution time: 0.0221
INFO - 2020-08-18 16:55:58 --> Config Class Initialized
INFO - 2020-08-18 16:55:58 --> Hooks Class Initialized
DEBUG - 2020-08-18 16:55:58 --> UTF-8 Support Enabled
INFO - 2020-08-18 16:55:58 --> Utf8 Class Initialized
INFO - 2020-08-18 16:55:58 --> URI Class Initialized
INFO - 2020-08-18 16:55:58 --> Router Class Initialized
INFO - 2020-08-18 16:55:58 --> Output Class Initialized
INFO - 2020-08-18 16:55:58 --> Security Class Initialized
DEBUG - 2020-08-18 16:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 16:55:58 --> Input Class Initialized
INFO - 2020-08-18 16:55:58 --> Language Class Initialized
INFO - 2020-08-18 16:55:58 --> Loader Class Initialized
INFO - 2020-08-18 16:55:58 --> Helper loaded: url_helper
INFO - 2020-08-18 16:55:58 --> Database Driver Class Initialized
INFO - 2020-08-18 16:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 16:55:58 --> Email Class Initialized
INFO - 2020-08-18 16:55:58 --> Controller Class Initialized
DEBUG - 2020-08-18 16:55:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 16:55:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 16:55:58 --> Model Class Initialized
INFO - 2020-08-18 16:55:58 --> Model Class Initialized
INFO - 2020-08-18 16:55:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 16:55:58 --> Final output sent to browser
DEBUG - 2020-08-18 16:55:58 --> Total execution time: 0.0276
INFO - 2020-08-18 17:02:57 --> Config Class Initialized
INFO - 2020-08-18 17:02:57 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:02:57 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:02:57 --> Utf8 Class Initialized
INFO - 2020-08-18 17:02:57 --> URI Class Initialized
DEBUG - 2020-08-18 17:02:57 --> No URI present. Default controller set.
INFO - 2020-08-18 17:02:57 --> Router Class Initialized
INFO - 2020-08-18 17:02:57 --> Output Class Initialized
INFO - 2020-08-18 17:02:57 --> Security Class Initialized
DEBUG - 2020-08-18 17:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:02:57 --> Input Class Initialized
INFO - 2020-08-18 17:02:57 --> Language Class Initialized
INFO - 2020-08-18 17:02:57 --> Loader Class Initialized
INFO - 2020-08-18 17:02:57 --> Helper loaded: url_helper
INFO - 2020-08-18 17:02:57 --> Database Driver Class Initialized
INFO - 2020-08-18 17:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:02:57 --> Email Class Initialized
INFO - 2020-08-18 17:02:57 --> Controller Class Initialized
INFO - 2020-08-18 17:02:57 --> Model Class Initialized
INFO - 2020-08-18 17:02:57 --> Model Class Initialized
DEBUG - 2020-08-18 17:02:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:02:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:02:57 --> Final output sent to browser
DEBUG - 2020-08-18 17:02:57 --> Total execution time: 0.0227
INFO - 2020-08-18 17:03:00 --> Config Class Initialized
INFO - 2020-08-18 17:03:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:00 --> URI Class Initialized
INFO - 2020-08-18 17:03:00 --> Router Class Initialized
INFO - 2020-08-18 17:03:00 --> Output Class Initialized
INFO - 2020-08-18 17:03:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:00 --> Input Class Initialized
INFO - 2020-08-18 17:03:00 --> Language Class Initialized
INFO - 2020-08-18 17:03:00 --> Loader Class Initialized
INFO - 2020-08-18 17:03:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:00 --> Email Class Initialized
INFO - 2020-08-18 17:03:00 --> Controller Class Initialized
INFO - 2020-08-18 17:03:00 --> Model Class Initialized
INFO - 2020-08-18 17:03:00 --> Model Class Initialized
DEBUG - 2020-08-18 17:03:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:03:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:00 --> Model Class Initialized
INFO - 2020-08-18 17:03:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:00 --> Total execution time: 0.0285
INFO - 2020-08-18 17:03:00 --> Config Class Initialized
INFO - 2020-08-18 17:03:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:00 --> URI Class Initialized
INFO - 2020-08-18 17:03:00 --> Router Class Initialized
INFO - 2020-08-18 17:03:00 --> Output Class Initialized
INFO - 2020-08-18 17:03:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:00 --> Input Class Initialized
INFO - 2020-08-18 17:03:00 --> Language Class Initialized
INFO - 2020-08-18 17:03:00 --> Loader Class Initialized
INFO - 2020-08-18 17:03:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:00 --> Email Class Initialized
INFO - 2020-08-18 17:03:00 --> Controller Class Initialized
INFO - 2020-08-18 17:03:00 --> Model Class Initialized
INFO - 2020-08-18 17:03:00 --> Model Class Initialized
DEBUG - 2020-08-18 17:03:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:01 --> Config Class Initialized
INFO - 2020-08-18 17:03:01 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:01 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:01 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:01 --> URI Class Initialized
INFO - 2020-08-18 17:03:01 --> Router Class Initialized
INFO - 2020-08-18 17:03:01 --> Output Class Initialized
INFO - 2020-08-18 17:03:01 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:01 --> Input Class Initialized
INFO - 2020-08-18 17:03:01 --> Language Class Initialized
INFO - 2020-08-18 17:03:01 --> Loader Class Initialized
INFO - 2020-08-18 17:03:01 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:01 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:01 --> Email Class Initialized
INFO - 2020-08-18 17:03:01 --> Controller Class Initialized
DEBUG - 2020-08-18 17:03:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:03:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 17:03:01 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:01 --> Total execution time: 0.0240
INFO - 2020-08-18 17:03:04 --> Config Class Initialized
INFO - 2020-08-18 17:03:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:04 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:04 --> URI Class Initialized
INFO - 2020-08-18 17:03:04 --> Router Class Initialized
INFO - 2020-08-18 17:03:04 --> Output Class Initialized
INFO - 2020-08-18 17:03:04 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:04 --> Input Class Initialized
INFO - 2020-08-18 17:03:04 --> Language Class Initialized
INFO - 2020-08-18 17:03:04 --> Loader Class Initialized
INFO - 2020-08-18 17:03:04 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:04 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:04 --> Email Class Initialized
INFO - 2020-08-18 17:03:04 --> Controller Class Initialized
DEBUG - 2020-08-18 17:03:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:03:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:04 --> Model Class Initialized
INFO - 2020-08-18 17:03:04 --> Model Class Initialized
INFO - 2020-08-18 17:03:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:03:04 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:04 --> Total execution time: 0.0237
INFO - 2020-08-18 17:03:07 --> Config Class Initialized
INFO - 2020-08-18 17:03:07 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:07 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:07 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:07 --> URI Class Initialized
DEBUG - 2020-08-18 17:03:07 --> No URI present. Default controller set.
INFO - 2020-08-18 17:03:07 --> Router Class Initialized
INFO - 2020-08-18 17:03:07 --> Output Class Initialized
INFO - 2020-08-18 17:03:07 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:07 --> Input Class Initialized
INFO - 2020-08-18 17:03:07 --> Language Class Initialized
INFO - 2020-08-18 17:03:07 --> Loader Class Initialized
INFO - 2020-08-18 17:03:07 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:07 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:07 --> Email Class Initialized
INFO - 2020-08-18 17:03:07 --> Controller Class Initialized
INFO - 2020-08-18 17:03:07 --> Model Class Initialized
INFO - 2020-08-18 17:03:07 --> Model Class Initialized
DEBUG - 2020-08-18 17:03:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:03:07 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:07 --> Total execution time: 0.0200
INFO - 2020-08-18 17:03:26 --> Config Class Initialized
INFO - 2020-08-18 17:03:26 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:26 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:26 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:26 --> URI Class Initialized
INFO - 2020-08-18 17:03:26 --> Router Class Initialized
INFO - 2020-08-18 17:03:26 --> Output Class Initialized
INFO - 2020-08-18 17:03:26 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:26 --> Input Class Initialized
INFO - 2020-08-18 17:03:26 --> Language Class Initialized
INFO - 2020-08-18 17:03:26 --> Loader Class Initialized
INFO - 2020-08-18 17:03:26 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:26 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:26 --> Email Class Initialized
INFO - 2020-08-18 17:03:26 --> Controller Class Initialized
INFO - 2020-08-18 17:03:26 --> Model Class Initialized
INFO - 2020-08-18 17:03:26 --> Model Class Initialized
DEBUG - 2020-08-18 17:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:03:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:26 --> Model Class Initialized
INFO - 2020-08-18 17:03:26 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:26 --> Total execution time: 0.0273
INFO - 2020-08-18 17:03:26 --> Config Class Initialized
INFO - 2020-08-18 17:03:26 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:26 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:26 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:26 --> URI Class Initialized
INFO - 2020-08-18 17:03:26 --> Router Class Initialized
INFO - 2020-08-18 17:03:26 --> Output Class Initialized
INFO - 2020-08-18 17:03:26 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:26 --> Input Class Initialized
INFO - 2020-08-18 17:03:26 --> Language Class Initialized
INFO - 2020-08-18 17:03:26 --> Loader Class Initialized
INFO - 2020-08-18 17:03:26 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:26 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:26 --> Email Class Initialized
INFO - 2020-08-18 17:03:26 --> Controller Class Initialized
INFO - 2020-08-18 17:03:26 --> Model Class Initialized
INFO - 2020-08-18 17:03:26 --> Model Class Initialized
DEBUG - 2020-08-18 17:03:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:26 --> Config Class Initialized
INFO - 2020-08-18 17:03:26 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:26 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:26 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:26 --> URI Class Initialized
INFO - 2020-08-18 17:03:26 --> Router Class Initialized
INFO - 2020-08-18 17:03:26 --> Output Class Initialized
INFO - 2020-08-18 17:03:26 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:26 --> Input Class Initialized
INFO - 2020-08-18 17:03:26 --> Language Class Initialized
INFO - 2020-08-18 17:03:26 --> Loader Class Initialized
INFO - 2020-08-18 17:03:26 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:26 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:26 --> Email Class Initialized
INFO - 2020-08-18 17:03:26 --> Controller Class Initialized
DEBUG - 2020-08-18 17:03:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:03:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:03:26 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:26 --> Total execution time: 0.0218
INFO - 2020-08-18 17:03:56 --> Config Class Initialized
INFO - 2020-08-18 17:03:56 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:03:56 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:03:56 --> Utf8 Class Initialized
INFO - 2020-08-18 17:03:56 --> URI Class Initialized
INFO - 2020-08-18 17:03:56 --> Router Class Initialized
INFO - 2020-08-18 17:03:56 --> Output Class Initialized
INFO - 2020-08-18 17:03:56 --> Security Class Initialized
DEBUG - 2020-08-18 17:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:03:56 --> Input Class Initialized
INFO - 2020-08-18 17:03:56 --> Language Class Initialized
INFO - 2020-08-18 17:03:56 --> Loader Class Initialized
INFO - 2020-08-18 17:03:56 --> Helper loaded: url_helper
INFO - 2020-08-18 17:03:56 --> Database Driver Class Initialized
INFO - 2020-08-18 17:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:03:56 --> Email Class Initialized
INFO - 2020-08-18 17:03:56 --> Controller Class Initialized
DEBUG - 2020-08-18 17:03:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:03:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:03:56 --> Model Class Initialized
INFO - 2020-08-18 17:03:56 --> Model Class Initialized
INFO - 2020-08-18 17:03:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:03:56 --> Final output sent to browser
DEBUG - 2020-08-18 17:03:56 --> Total execution time: 0.0247
INFO - 2020-08-18 17:04:32 --> Config Class Initialized
INFO - 2020-08-18 17:04:32 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:04:32 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:04:32 --> Utf8 Class Initialized
INFO - 2020-08-18 17:04:32 --> URI Class Initialized
DEBUG - 2020-08-18 17:04:32 --> No URI present. Default controller set.
INFO - 2020-08-18 17:04:32 --> Router Class Initialized
INFO - 2020-08-18 17:04:32 --> Output Class Initialized
INFO - 2020-08-18 17:04:32 --> Security Class Initialized
DEBUG - 2020-08-18 17:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:04:32 --> Input Class Initialized
INFO - 2020-08-18 17:04:32 --> Language Class Initialized
INFO - 2020-08-18 17:04:32 --> Loader Class Initialized
INFO - 2020-08-18 17:04:32 --> Helper loaded: url_helper
INFO - 2020-08-18 17:04:32 --> Database Driver Class Initialized
INFO - 2020-08-18 17:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:04:32 --> Email Class Initialized
INFO - 2020-08-18 17:04:32 --> Controller Class Initialized
INFO - 2020-08-18 17:04:32 --> Model Class Initialized
INFO - 2020-08-18 17:04:32 --> Model Class Initialized
DEBUG - 2020-08-18 17:04:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:04:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:04:32 --> Final output sent to browser
DEBUG - 2020-08-18 17:04:32 --> Total execution time: 0.0220
INFO - 2020-08-18 17:04:49 --> Config Class Initialized
INFO - 2020-08-18 17:04:49 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:04:49 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:04:49 --> Utf8 Class Initialized
INFO - 2020-08-18 17:04:49 --> URI Class Initialized
INFO - 2020-08-18 17:04:49 --> Router Class Initialized
INFO - 2020-08-18 17:04:49 --> Output Class Initialized
INFO - 2020-08-18 17:04:49 --> Security Class Initialized
DEBUG - 2020-08-18 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:04:49 --> Input Class Initialized
INFO - 2020-08-18 17:04:49 --> Language Class Initialized
INFO - 2020-08-18 17:04:49 --> Loader Class Initialized
INFO - 2020-08-18 17:04:49 --> Helper loaded: url_helper
INFO - 2020-08-18 17:04:49 --> Database Driver Class Initialized
INFO - 2020-08-18 17:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:04:49 --> Email Class Initialized
INFO - 2020-08-18 17:04:49 --> Controller Class Initialized
INFO - 2020-08-18 17:04:49 --> Model Class Initialized
INFO - 2020-08-18 17:04:49 --> Model Class Initialized
DEBUG - 2020-08-18 17:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:04:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:04:49 --> Model Class Initialized
INFO - 2020-08-18 17:04:49 --> Final output sent to browser
DEBUG - 2020-08-18 17:04:49 --> Total execution time: 0.0251
INFO - 2020-08-18 17:04:49 --> Config Class Initialized
INFO - 2020-08-18 17:04:49 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:04:49 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:04:49 --> Utf8 Class Initialized
INFO - 2020-08-18 17:04:49 --> URI Class Initialized
INFO - 2020-08-18 17:04:49 --> Router Class Initialized
INFO - 2020-08-18 17:04:49 --> Output Class Initialized
INFO - 2020-08-18 17:04:49 --> Security Class Initialized
DEBUG - 2020-08-18 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:04:49 --> Input Class Initialized
INFO - 2020-08-18 17:04:49 --> Language Class Initialized
INFO - 2020-08-18 17:04:49 --> Loader Class Initialized
INFO - 2020-08-18 17:04:49 --> Helper loaded: url_helper
INFO - 2020-08-18 17:04:49 --> Database Driver Class Initialized
INFO - 2020-08-18 17:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:04:49 --> Email Class Initialized
INFO - 2020-08-18 17:04:49 --> Controller Class Initialized
INFO - 2020-08-18 17:04:49 --> Model Class Initialized
INFO - 2020-08-18 17:04:49 --> Model Class Initialized
DEBUG - 2020-08-18 17:04:49 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:04:50 --> Config Class Initialized
INFO - 2020-08-18 17:04:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:04:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:04:50 --> Utf8 Class Initialized
INFO - 2020-08-18 17:04:50 --> URI Class Initialized
INFO - 2020-08-18 17:04:50 --> Router Class Initialized
INFO - 2020-08-18 17:04:50 --> Output Class Initialized
INFO - 2020-08-18 17:04:50 --> Security Class Initialized
DEBUG - 2020-08-18 17:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:04:50 --> Input Class Initialized
INFO - 2020-08-18 17:04:50 --> Language Class Initialized
INFO - 2020-08-18 17:04:50 --> Loader Class Initialized
INFO - 2020-08-18 17:04:50 --> Helper loaded: url_helper
INFO - 2020-08-18 17:04:50 --> Database Driver Class Initialized
INFO - 2020-08-18 17:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:04:50 --> Email Class Initialized
INFO - 2020-08-18 17:04:50 --> Controller Class Initialized
DEBUG - 2020-08-18 17:04:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:04:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:04:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:04:50 --> Final output sent to browser
DEBUG - 2020-08-18 17:04:50 --> Total execution time: 0.0207
INFO - 2020-08-18 17:04:56 --> Config Class Initialized
INFO - 2020-08-18 17:04:56 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:04:56 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:04:56 --> Utf8 Class Initialized
INFO - 2020-08-18 17:04:56 --> URI Class Initialized
INFO - 2020-08-18 17:04:56 --> Router Class Initialized
INFO - 2020-08-18 17:04:56 --> Output Class Initialized
INFO - 2020-08-18 17:04:56 --> Security Class Initialized
DEBUG - 2020-08-18 17:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:04:56 --> Input Class Initialized
INFO - 2020-08-18 17:04:56 --> Language Class Initialized
INFO - 2020-08-18 17:04:56 --> Loader Class Initialized
INFO - 2020-08-18 17:04:56 --> Helper loaded: url_helper
INFO - 2020-08-18 17:04:56 --> Database Driver Class Initialized
INFO - 2020-08-18 17:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:04:56 --> Email Class Initialized
INFO - 2020-08-18 17:04:56 --> Controller Class Initialized
DEBUG - 2020-08-18 17:04:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:04:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:04:56 --> Model Class Initialized
INFO - 2020-08-18 17:04:56 --> Model Class Initialized
INFO - 2020-08-18 17:04:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:04:56 --> Final output sent to browser
DEBUG - 2020-08-18 17:04:56 --> Total execution time: 0.0248
INFO - 2020-08-18 17:05:04 --> Config Class Initialized
INFO - 2020-08-18 17:05:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:04 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:04 --> URI Class Initialized
INFO - 2020-08-18 17:05:04 --> Router Class Initialized
INFO - 2020-08-18 17:05:04 --> Output Class Initialized
INFO - 2020-08-18 17:05:04 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:04 --> Input Class Initialized
INFO - 2020-08-18 17:05:04 --> Language Class Initialized
INFO - 2020-08-18 17:05:04 --> Loader Class Initialized
INFO - 2020-08-18 17:05:04 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:04 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:04 --> Email Class Initialized
INFO - 2020-08-18 17:05:04 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:05:04 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:04 --> Total execution time: 0.0222
INFO - 2020-08-18 17:05:09 --> Config Class Initialized
INFO - 2020-08-18 17:05:09 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:09 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:09 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:09 --> URI Class Initialized
INFO - 2020-08-18 17:05:09 --> Router Class Initialized
INFO - 2020-08-18 17:05:09 --> Output Class Initialized
INFO - 2020-08-18 17:05:09 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:09 --> Input Class Initialized
INFO - 2020-08-18 17:05:09 --> Language Class Initialized
INFO - 2020-08-18 17:05:09 --> Loader Class Initialized
INFO - 2020-08-18 17:05:09 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:09 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:09 --> Email Class Initialized
INFO - 2020-08-18 17:05:09 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:09 --> Model Class Initialized
INFO - 2020-08-18 17:05:09 --> Model Class Initialized
INFO - 2020-08-18 17:05:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:05:09 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:09 --> Total execution time: 0.0261
INFO - 2020-08-18 17:05:11 --> Config Class Initialized
INFO - 2020-08-18 17:05:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:11 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:11 --> URI Class Initialized
INFO - 2020-08-18 17:05:11 --> Router Class Initialized
INFO - 2020-08-18 17:05:11 --> Output Class Initialized
INFO - 2020-08-18 17:05:11 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:11 --> Input Class Initialized
INFO - 2020-08-18 17:05:11 --> Language Class Initialized
INFO - 2020-08-18 17:05:11 --> Loader Class Initialized
INFO - 2020-08-18 17:05:11 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:11 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:11 --> Email Class Initialized
INFO - 2020-08-18 17:05:11 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:11 --> Model Class Initialized
INFO - 2020-08-18 17:05:11 --> Model Class Initialized
INFO - 2020-08-18 17:05:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:05:11 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:11 --> Total execution time: 0.0302
INFO - 2020-08-18 17:05:16 --> Config Class Initialized
INFO - 2020-08-18 17:05:16 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:16 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:16 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:16 --> URI Class Initialized
INFO - 2020-08-18 17:05:16 --> Router Class Initialized
INFO - 2020-08-18 17:05:16 --> Output Class Initialized
INFO - 2020-08-18 17:05:16 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:16 --> Input Class Initialized
INFO - 2020-08-18 17:05:16 --> Language Class Initialized
INFO - 2020-08-18 17:05:16 --> Loader Class Initialized
INFO - 2020-08-18 17:05:16 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:16 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:16 --> Email Class Initialized
INFO - 2020-08-18 17:05:16 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:16 --> Model Class Initialized
INFO - 2020-08-18 17:05:16 --> Model Class Initialized
INFO - 2020-08-18 17:05:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:05:16 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:16 --> Total execution time: 0.0239
INFO - 2020-08-18 17:05:26 --> Config Class Initialized
INFO - 2020-08-18 17:05:26 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:26 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:26 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:26 --> URI Class Initialized
INFO - 2020-08-18 17:05:26 --> Router Class Initialized
INFO - 2020-08-18 17:05:26 --> Output Class Initialized
INFO - 2020-08-18 17:05:26 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:26 --> Input Class Initialized
INFO - 2020-08-18 17:05:26 --> Language Class Initialized
INFO - 2020-08-18 17:05:26 --> Loader Class Initialized
INFO - 2020-08-18 17:05:26 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:26 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:26 --> Email Class Initialized
INFO - 2020-08-18 17:05:26 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:05:26 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:26 --> Total execution time: 0.0239
INFO - 2020-08-18 17:05:31 --> Config Class Initialized
INFO - 2020-08-18 17:05:31 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:31 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:31 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:31 --> URI Class Initialized
INFO - 2020-08-18 17:05:31 --> Router Class Initialized
INFO - 2020-08-18 17:05:31 --> Output Class Initialized
INFO - 2020-08-18 17:05:31 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:31 --> Input Class Initialized
INFO - 2020-08-18 17:05:31 --> Language Class Initialized
INFO - 2020-08-18 17:05:31 --> Loader Class Initialized
INFO - 2020-08-18 17:05:31 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:31 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:31 --> Email Class Initialized
INFO - 2020-08-18 17:05:31 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:31 --> Model Class Initialized
INFO - 2020-08-18 17:05:31 --> Model Class Initialized
INFO - 2020-08-18 17:05:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:05:31 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:31 --> Total execution time: 0.0255
INFO - 2020-08-18 17:05:33 --> Config Class Initialized
INFO - 2020-08-18 17:05:33 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:05:33 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:05:33 --> Utf8 Class Initialized
INFO - 2020-08-18 17:05:33 --> URI Class Initialized
INFO - 2020-08-18 17:05:33 --> Router Class Initialized
INFO - 2020-08-18 17:05:33 --> Output Class Initialized
INFO - 2020-08-18 17:05:33 --> Security Class Initialized
DEBUG - 2020-08-18 17:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:05:33 --> Input Class Initialized
INFO - 2020-08-18 17:05:33 --> Language Class Initialized
INFO - 2020-08-18 17:05:33 --> Loader Class Initialized
INFO - 2020-08-18 17:05:33 --> Helper loaded: url_helper
INFO - 2020-08-18 17:05:33 --> Database Driver Class Initialized
INFO - 2020-08-18 17:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:05:33 --> Email Class Initialized
INFO - 2020-08-18 17:05:33 --> Controller Class Initialized
DEBUG - 2020-08-18 17:05:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:05:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:05:33 --> Model Class Initialized
INFO - 2020-08-18 17:05:33 --> Model Class Initialized
INFO - 2020-08-18 17:05:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 17:05:33 --> Final output sent to browser
DEBUG - 2020-08-18 17:05:33 --> Total execution time: 0.0249
INFO - 2020-08-18 17:07:40 --> Config Class Initialized
INFO - 2020-08-18 17:07:40 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:07:40 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:07:40 --> Utf8 Class Initialized
INFO - 2020-08-18 17:07:40 --> URI Class Initialized
INFO - 2020-08-18 17:07:40 --> Router Class Initialized
INFO - 2020-08-18 17:07:40 --> Output Class Initialized
INFO - 2020-08-18 17:07:40 --> Security Class Initialized
DEBUG - 2020-08-18 17:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:07:40 --> Input Class Initialized
INFO - 2020-08-18 17:07:40 --> Language Class Initialized
INFO - 2020-08-18 17:07:40 --> Loader Class Initialized
INFO - 2020-08-18 17:07:40 --> Helper loaded: url_helper
INFO - 2020-08-18 17:07:40 --> Database Driver Class Initialized
INFO - 2020-08-18 17:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:07:40 --> Email Class Initialized
INFO - 2020-08-18 17:07:40 --> Controller Class Initialized
DEBUG - 2020-08-18 17:07:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:07:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:07:40 --> Model Class Initialized
INFO - 2020-08-18 17:07:40 --> Model Class Initialized
INFO - 2020-08-18 17:07:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 17:07:40 --> Final output sent to browser
DEBUG - 2020-08-18 17:07:40 --> Total execution time: 0.0319
INFO - 2020-08-18 17:07:50 --> Config Class Initialized
INFO - 2020-08-18 17:07:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:07:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:07:50 --> Utf8 Class Initialized
INFO - 2020-08-18 17:07:50 --> URI Class Initialized
INFO - 2020-08-18 17:07:50 --> Router Class Initialized
INFO - 2020-08-18 17:07:50 --> Output Class Initialized
INFO - 2020-08-18 17:07:50 --> Security Class Initialized
DEBUG - 2020-08-18 17:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:07:50 --> Input Class Initialized
INFO - 2020-08-18 17:07:50 --> Language Class Initialized
INFO - 2020-08-18 17:07:50 --> Loader Class Initialized
INFO - 2020-08-18 17:07:50 --> Helper loaded: url_helper
INFO - 2020-08-18 17:07:50 --> Database Driver Class Initialized
INFO - 2020-08-18 17:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:07:50 --> Email Class Initialized
INFO - 2020-08-18 17:07:50 --> Controller Class Initialized
DEBUG - 2020-08-18 17:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:07:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:07:50 --> Model Class Initialized
INFO - 2020-08-18 17:07:50 --> Model Class Initialized
INFO - 2020-08-18 17:07:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:07:50 --> Final output sent to browser
DEBUG - 2020-08-18 17:07:50 --> Total execution time: 0.0265
INFO - 2020-08-18 17:08:15 --> Config Class Initialized
INFO - 2020-08-18 17:08:15 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:08:15 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:08:15 --> Utf8 Class Initialized
INFO - 2020-08-18 17:08:15 --> URI Class Initialized
INFO - 2020-08-18 17:08:15 --> Router Class Initialized
INFO - 2020-08-18 17:08:15 --> Output Class Initialized
INFO - 2020-08-18 17:08:15 --> Security Class Initialized
DEBUG - 2020-08-18 17:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:08:15 --> Input Class Initialized
INFO - 2020-08-18 17:08:15 --> Language Class Initialized
INFO - 2020-08-18 17:08:15 --> Loader Class Initialized
INFO - 2020-08-18 17:08:15 --> Helper loaded: url_helper
INFO - 2020-08-18 17:08:15 --> Database Driver Class Initialized
INFO - 2020-08-18 17:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:08:15 --> Email Class Initialized
INFO - 2020-08-18 17:08:15 --> Controller Class Initialized
DEBUG - 2020-08-18 17:08:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:08:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:08:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:08:15 --> Final output sent to browser
DEBUG - 2020-08-18 17:08:15 --> Total execution time: 0.0214
INFO - 2020-08-18 17:08:53 --> Config Class Initialized
INFO - 2020-08-18 17:08:53 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:08:53 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:08:53 --> Utf8 Class Initialized
INFO - 2020-08-18 17:08:53 --> URI Class Initialized
INFO - 2020-08-18 17:08:53 --> Router Class Initialized
INFO - 2020-08-18 17:08:53 --> Output Class Initialized
INFO - 2020-08-18 17:08:53 --> Security Class Initialized
DEBUG - 2020-08-18 17:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:08:53 --> Input Class Initialized
INFO - 2020-08-18 17:08:53 --> Language Class Initialized
INFO - 2020-08-18 17:08:53 --> Loader Class Initialized
INFO - 2020-08-18 17:08:53 --> Helper loaded: url_helper
INFO - 2020-08-18 17:08:53 --> Database Driver Class Initialized
INFO - 2020-08-18 17:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:08:53 --> Email Class Initialized
INFO - 2020-08-18 17:08:53 --> Controller Class Initialized
DEBUG - 2020-08-18 17:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:08:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:08:53 --> Model Class Initialized
INFO - 2020-08-18 17:08:53 --> Model Class Initialized
INFO - 2020-08-18 17:08:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:08:53 --> Final output sent to browser
DEBUG - 2020-08-18 17:08:53 --> Total execution time: 0.0242
INFO - 2020-08-18 17:09:00 --> Config Class Initialized
INFO - 2020-08-18 17:09:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:09:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:09:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:09:00 --> URI Class Initialized
INFO - 2020-08-18 17:09:00 --> Router Class Initialized
INFO - 2020-08-18 17:09:00 --> Output Class Initialized
INFO - 2020-08-18 17:09:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:09:00 --> Input Class Initialized
INFO - 2020-08-18 17:09:00 --> Language Class Initialized
INFO - 2020-08-18 17:09:00 --> Loader Class Initialized
INFO - 2020-08-18 17:09:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:09:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:09:00 --> Email Class Initialized
INFO - 2020-08-18 17:09:00 --> Controller Class Initialized
DEBUG - 2020-08-18 17:09:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:09:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:09:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:09:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:09:00 --> Total execution time: 0.0293
INFO - 2020-08-18 17:09:07 --> Config Class Initialized
INFO - 2020-08-18 17:09:07 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:09:07 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:09:07 --> Utf8 Class Initialized
INFO - 2020-08-18 17:09:07 --> URI Class Initialized
DEBUG - 2020-08-18 17:09:07 --> No URI present. Default controller set.
INFO - 2020-08-18 17:09:07 --> Router Class Initialized
INFO - 2020-08-18 17:09:07 --> Output Class Initialized
INFO - 2020-08-18 17:09:07 --> Security Class Initialized
DEBUG - 2020-08-18 17:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:09:07 --> Input Class Initialized
INFO - 2020-08-18 17:09:07 --> Language Class Initialized
INFO - 2020-08-18 17:09:07 --> Loader Class Initialized
INFO - 2020-08-18 17:09:07 --> Helper loaded: url_helper
INFO - 2020-08-18 17:09:07 --> Database Driver Class Initialized
INFO - 2020-08-18 17:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:09:07 --> Email Class Initialized
INFO - 2020-08-18 17:09:07 --> Controller Class Initialized
INFO - 2020-08-18 17:09:07 --> Model Class Initialized
INFO - 2020-08-18 17:09:07 --> Model Class Initialized
DEBUG - 2020-08-18 17:09:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:09:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:09:07 --> Final output sent to browser
DEBUG - 2020-08-18 17:09:07 --> Total execution time: 0.0203
INFO - 2020-08-18 17:09:14 --> Config Class Initialized
INFO - 2020-08-18 17:09:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:09:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:09:14 --> Utf8 Class Initialized
INFO - 2020-08-18 17:09:14 --> URI Class Initialized
INFO - 2020-08-18 17:09:14 --> Router Class Initialized
INFO - 2020-08-18 17:09:14 --> Output Class Initialized
INFO - 2020-08-18 17:09:14 --> Security Class Initialized
DEBUG - 2020-08-18 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:09:14 --> Input Class Initialized
INFO - 2020-08-18 17:09:14 --> Language Class Initialized
INFO - 2020-08-18 17:09:14 --> Loader Class Initialized
INFO - 2020-08-18 17:09:14 --> Helper loaded: url_helper
INFO - 2020-08-18 17:09:14 --> Database Driver Class Initialized
INFO - 2020-08-18 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:09:14 --> Email Class Initialized
INFO - 2020-08-18 17:09:14 --> Controller Class Initialized
INFO - 2020-08-18 17:09:14 --> Model Class Initialized
INFO - 2020-08-18 17:09:14 --> Model Class Initialized
DEBUG - 2020-08-18 17:09:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:09:14 --> Config Class Initialized
INFO - 2020-08-18 17:09:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:09:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:09:14 --> Utf8 Class Initialized
INFO - 2020-08-18 17:09:14 --> URI Class Initialized
INFO - 2020-08-18 17:09:14 --> Router Class Initialized
INFO - 2020-08-18 17:09:14 --> Output Class Initialized
INFO - 2020-08-18 17:09:14 --> Security Class Initialized
DEBUG - 2020-08-18 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:09:14 --> Input Class Initialized
INFO - 2020-08-18 17:09:14 --> Language Class Initialized
INFO - 2020-08-18 17:09:14 --> Loader Class Initialized
INFO - 2020-08-18 17:09:14 --> Helper loaded: url_helper
INFO - 2020-08-18 17:09:14 --> Database Driver Class Initialized
INFO - 2020-08-18 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:09:14 --> Email Class Initialized
INFO - 2020-08-18 17:09:14 --> Controller Class Initialized
INFO - 2020-08-18 17:09:14 --> Model Class Initialized
INFO - 2020-08-18 17:09:14 --> Model Class Initialized
DEBUG - 2020-08-18 17:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:09:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:09:14 --> Model Class Initialized
INFO - 2020-08-18 17:09:14 --> Final output sent to browser
DEBUG - 2020-08-18 17:09:14 --> Total execution time: 0.0260
INFO - 2020-08-18 17:09:14 --> Config Class Initialized
INFO - 2020-08-18 17:09:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:09:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:09:14 --> Utf8 Class Initialized
INFO - 2020-08-18 17:09:14 --> URI Class Initialized
INFO - 2020-08-18 17:09:14 --> Router Class Initialized
INFO - 2020-08-18 17:09:14 --> Output Class Initialized
INFO - 2020-08-18 17:09:14 --> Security Class Initialized
DEBUG - 2020-08-18 17:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:09:14 --> Input Class Initialized
INFO - 2020-08-18 17:09:14 --> Language Class Initialized
INFO - 2020-08-18 17:09:14 --> Loader Class Initialized
INFO - 2020-08-18 17:09:14 --> Helper loaded: url_helper
INFO - 2020-08-18 17:09:14 --> Database Driver Class Initialized
INFO - 2020-08-18 17:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:09:14 --> Email Class Initialized
INFO - 2020-08-18 17:09:14 --> Controller Class Initialized
DEBUG - 2020-08-18 17:09:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:09:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:09:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 17:09:14 --> Final output sent to browser
DEBUG - 2020-08-18 17:09:14 --> Total execution time: 0.0218
INFO - 2020-08-18 17:28:37 --> Config Class Initialized
INFO - 2020-08-18 17:28:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:28:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:28:37 --> Utf8 Class Initialized
INFO - 2020-08-18 17:28:37 --> URI Class Initialized
INFO - 2020-08-18 17:28:37 --> Router Class Initialized
INFO - 2020-08-18 17:28:37 --> Output Class Initialized
INFO - 2020-08-18 17:28:37 --> Security Class Initialized
DEBUG - 2020-08-18 17:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:28:37 --> Input Class Initialized
INFO - 2020-08-18 17:28:37 --> Language Class Initialized
INFO - 2020-08-18 17:28:37 --> Loader Class Initialized
INFO - 2020-08-18 17:28:37 --> Helper loaded: url_helper
INFO - 2020-08-18 17:28:37 --> Database Driver Class Initialized
INFO - 2020-08-18 17:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:28:37 --> Email Class Initialized
INFO - 2020-08-18 17:28:37 --> Controller Class Initialized
DEBUG - 2020-08-18 17:28:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:28:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:28:37 --> Model Class Initialized
INFO - 2020-08-18 17:28:37 --> Model Class Initialized
INFO - 2020-08-18 17:28:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:28:37 --> Final output sent to browser
DEBUG - 2020-08-18 17:28:37 --> Total execution time: 0.0270
INFO - 2020-08-18 17:28:38 --> Config Class Initialized
INFO - 2020-08-18 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:28:38 --> Utf8 Class Initialized
INFO - 2020-08-18 17:28:38 --> URI Class Initialized
INFO - 2020-08-18 17:28:38 --> Router Class Initialized
INFO - 2020-08-18 17:28:38 --> Output Class Initialized
INFO - 2020-08-18 17:28:38 --> Security Class Initialized
DEBUG - 2020-08-18 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:28:38 --> Input Class Initialized
INFO - 2020-08-18 17:28:38 --> Language Class Initialized
ERROR - 2020-08-18 17:28:38 --> 404 Page Not Found: Dealer/img
INFO - 2020-08-18 17:29:42 --> Config Class Initialized
INFO - 2020-08-18 17:29:42 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:29:42 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:29:42 --> Utf8 Class Initialized
INFO - 2020-08-18 17:29:42 --> URI Class Initialized
INFO - 2020-08-18 17:29:42 --> Router Class Initialized
INFO - 2020-08-18 17:29:42 --> Output Class Initialized
INFO - 2020-08-18 17:29:42 --> Security Class Initialized
DEBUG - 2020-08-18 17:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:29:42 --> Input Class Initialized
INFO - 2020-08-18 17:29:42 --> Language Class Initialized
INFO - 2020-08-18 17:29:42 --> Loader Class Initialized
INFO - 2020-08-18 17:29:42 --> Helper loaded: url_helper
INFO - 2020-08-18 17:29:42 --> Database Driver Class Initialized
INFO - 2020-08-18 17:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:29:42 --> Email Class Initialized
INFO - 2020-08-18 17:29:42 --> Controller Class Initialized
DEBUG - 2020-08-18 17:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:29:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:29:42 --> Model Class Initialized
INFO - 2020-08-18 17:29:42 --> Model Class Initialized
INFO - 2020-08-18 17:29:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:29:42 --> Final output sent to browser
DEBUG - 2020-08-18 17:29:42 --> Total execution time: 0.0285
INFO - 2020-08-18 17:30:54 --> Config Class Initialized
INFO - 2020-08-18 17:30:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:30:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:30:54 --> Utf8 Class Initialized
INFO - 2020-08-18 17:30:54 --> URI Class Initialized
INFO - 2020-08-18 17:30:54 --> Router Class Initialized
INFO - 2020-08-18 17:30:54 --> Output Class Initialized
INFO - 2020-08-18 17:30:54 --> Security Class Initialized
DEBUG - 2020-08-18 17:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:30:54 --> Input Class Initialized
INFO - 2020-08-18 17:30:54 --> Language Class Initialized
INFO - 2020-08-18 17:30:54 --> Loader Class Initialized
INFO - 2020-08-18 17:30:54 --> Helper loaded: url_helper
INFO - 2020-08-18 17:30:54 --> Database Driver Class Initialized
INFO - 2020-08-18 17:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:30:54 --> Email Class Initialized
INFO - 2020-08-18 17:30:54 --> Controller Class Initialized
DEBUG - 2020-08-18 17:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:30:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:30:54 --> Model Class Initialized
INFO - 2020-08-18 17:30:54 --> Model Class Initialized
INFO - 2020-08-18 17:30:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:30:54 --> Final output sent to browser
DEBUG - 2020-08-18 17:30:54 --> Total execution time: 0.0240
INFO - 2020-08-18 17:32:05 --> Config Class Initialized
INFO - 2020-08-18 17:32:05 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:32:05 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:32:05 --> Utf8 Class Initialized
INFO - 2020-08-18 17:32:05 --> URI Class Initialized
INFO - 2020-08-18 17:32:05 --> Router Class Initialized
INFO - 2020-08-18 17:32:05 --> Output Class Initialized
INFO - 2020-08-18 17:32:05 --> Security Class Initialized
DEBUG - 2020-08-18 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:32:05 --> Input Class Initialized
INFO - 2020-08-18 17:32:05 --> Language Class Initialized
INFO - 2020-08-18 17:32:05 --> Loader Class Initialized
INFO - 2020-08-18 17:32:05 --> Helper loaded: url_helper
INFO - 2020-08-18 17:32:05 --> Database Driver Class Initialized
INFO - 2020-08-18 17:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:32:06 --> Email Class Initialized
INFO - 2020-08-18 17:32:06 --> Controller Class Initialized
DEBUG - 2020-08-18 17:32:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:32:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:32:06 --> Model Class Initialized
INFO - 2020-08-18 17:32:06 --> Model Class Initialized
INFO - 2020-08-18 17:32:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:32:06 --> Final output sent to browser
DEBUG - 2020-08-18 17:32:06 --> Total execution time: 0.0284
INFO - 2020-08-18 17:32:55 --> Config Class Initialized
INFO - 2020-08-18 17:32:55 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:32:55 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:32:55 --> Utf8 Class Initialized
INFO - 2020-08-18 17:32:55 --> URI Class Initialized
INFO - 2020-08-18 17:32:55 --> Router Class Initialized
INFO - 2020-08-18 17:32:55 --> Output Class Initialized
INFO - 2020-08-18 17:32:55 --> Security Class Initialized
DEBUG - 2020-08-18 17:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:32:55 --> Input Class Initialized
INFO - 2020-08-18 17:32:55 --> Language Class Initialized
INFO - 2020-08-18 17:32:55 --> Loader Class Initialized
INFO - 2020-08-18 17:32:55 --> Helper loaded: url_helper
INFO - 2020-08-18 17:32:55 --> Database Driver Class Initialized
INFO - 2020-08-18 17:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:32:55 --> Email Class Initialized
INFO - 2020-08-18 17:32:55 --> Controller Class Initialized
DEBUG - 2020-08-18 17:32:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:32:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:32:55 --> Model Class Initialized
INFO - 2020-08-18 17:32:55 --> Model Class Initialized
INFO - 2020-08-18 17:32:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:32:55 --> Final output sent to browser
DEBUG - 2020-08-18 17:32:55 --> Total execution time: 0.0248
INFO - 2020-08-18 17:33:34 --> Config Class Initialized
INFO - 2020-08-18 17:33:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:33:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:33:34 --> Utf8 Class Initialized
INFO - 2020-08-18 17:33:34 --> URI Class Initialized
INFO - 2020-08-18 17:33:34 --> Router Class Initialized
INFO - 2020-08-18 17:33:34 --> Output Class Initialized
INFO - 2020-08-18 17:33:34 --> Security Class Initialized
DEBUG - 2020-08-18 17:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:33:34 --> Input Class Initialized
INFO - 2020-08-18 17:33:34 --> Language Class Initialized
INFO - 2020-08-18 17:33:34 --> Loader Class Initialized
INFO - 2020-08-18 17:33:34 --> Helper loaded: url_helper
INFO - 2020-08-18 17:33:34 --> Database Driver Class Initialized
INFO - 2020-08-18 17:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:33:34 --> Email Class Initialized
INFO - 2020-08-18 17:33:34 --> Controller Class Initialized
DEBUG - 2020-08-18 17:33:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:33:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:33:34 --> Model Class Initialized
INFO - 2020-08-18 17:33:34 --> Model Class Initialized
INFO - 2020-08-18 17:33:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:33:34 --> Final output sent to browser
DEBUG - 2020-08-18 17:33:34 --> Total execution time: 0.0235
INFO - 2020-08-18 17:34:05 --> Config Class Initialized
INFO - 2020-08-18 17:34:05 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:34:05 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:34:05 --> Utf8 Class Initialized
INFO - 2020-08-18 17:34:05 --> URI Class Initialized
INFO - 2020-08-18 17:34:05 --> Router Class Initialized
INFO - 2020-08-18 17:34:05 --> Output Class Initialized
INFO - 2020-08-18 17:34:05 --> Security Class Initialized
DEBUG - 2020-08-18 17:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:34:05 --> Input Class Initialized
INFO - 2020-08-18 17:34:05 --> Language Class Initialized
INFO - 2020-08-18 17:34:05 --> Loader Class Initialized
INFO - 2020-08-18 17:34:05 --> Helper loaded: url_helper
INFO - 2020-08-18 17:34:05 --> Database Driver Class Initialized
INFO - 2020-08-18 17:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:34:05 --> Email Class Initialized
INFO - 2020-08-18 17:34:05 --> Controller Class Initialized
DEBUG - 2020-08-18 17:34:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:34:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:34:05 --> Model Class Initialized
INFO - 2020-08-18 17:34:05 --> Model Class Initialized
INFO - 2020-08-18 17:34:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:34:05 --> Final output sent to browser
DEBUG - 2020-08-18 17:34:05 --> Total execution time: 0.0250
INFO - 2020-08-18 17:34:22 --> Config Class Initialized
INFO - 2020-08-18 17:34:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:34:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:34:22 --> Utf8 Class Initialized
INFO - 2020-08-18 17:34:22 --> URI Class Initialized
INFO - 2020-08-18 17:34:22 --> Router Class Initialized
INFO - 2020-08-18 17:34:22 --> Output Class Initialized
INFO - 2020-08-18 17:34:22 --> Security Class Initialized
DEBUG - 2020-08-18 17:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:34:22 --> Input Class Initialized
INFO - 2020-08-18 17:34:22 --> Language Class Initialized
INFO - 2020-08-18 17:34:22 --> Loader Class Initialized
INFO - 2020-08-18 17:34:22 --> Helper loaded: url_helper
INFO - 2020-08-18 17:34:22 --> Database Driver Class Initialized
INFO - 2020-08-18 17:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:34:22 --> Email Class Initialized
INFO - 2020-08-18 17:34:22 --> Controller Class Initialized
DEBUG - 2020-08-18 17:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:34:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:34:22 --> Model Class Initialized
INFO - 2020-08-18 17:34:22 --> Model Class Initialized
INFO - 2020-08-18 17:34:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:34:22 --> Final output sent to browser
DEBUG - 2020-08-18 17:34:22 --> Total execution time: 0.0266
INFO - 2020-08-18 17:34:50 --> Config Class Initialized
INFO - 2020-08-18 17:34:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:34:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:34:50 --> Utf8 Class Initialized
INFO - 2020-08-18 17:34:50 --> URI Class Initialized
INFO - 2020-08-18 17:34:50 --> Router Class Initialized
INFO - 2020-08-18 17:34:50 --> Output Class Initialized
INFO - 2020-08-18 17:34:50 --> Security Class Initialized
DEBUG - 2020-08-18 17:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:34:50 --> Input Class Initialized
INFO - 2020-08-18 17:34:50 --> Language Class Initialized
INFO - 2020-08-18 17:34:50 --> Loader Class Initialized
INFO - 2020-08-18 17:34:50 --> Helper loaded: url_helper
INFO - 2020-08-18 17:34:50 --> Database Driver Class Initialized
INFO - 2020-08-18 17:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:34:50 --> Email Class Initialized
INFO - 2020-08-18 17:34:50 --> Controller Class Initialized
DEBUG - 2020-08-18 17:34:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:34:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:34:50 --> Model Class Initialized
INFO - 2020-08-18 17:34:50 --> Model Class Initialized
INFO - 2020-08-18 17:34:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:34:50 --> Final output sent to browser
DEBUG - 2020-08-18 17:34:50 --> Total execution time: 0.0273
INFO - 2020-08-18 17:35:08 --> Config Class Initialized
INFO - 2020-08-18 17:35:08 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:35:08 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:35:08 --> Utf8 Class Initialized
INFO - 2020-08-18 17:35:08 --> URI Class Initialized
INFO - 2020-08-18 17:35:08 --> Router Class Initialized
INFO - 2020-08-18 17:35:08 --> Output Class Initialized
INFO - 2020-08-18 17:35:08 --> Security Class Initialized
DEBUG - 2020-08-18 17:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:35:08 --> Input Class Initialized
INFO - 2020-08-18 17:35:08 --> Language Class Initialized
INFO - 2020-08-18 17:35:08 --> Loader Class Initialized
INFO - 2020-08-18 17:35:08 --> Helper loaded: url_helper
INFO - 2020-08-18 17:35:08 --> Database Driver Class Initialized
INFO - 2020-08-18 17:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:35:08 --> Email Class Initialized
INFO - 2020-08-18 17:35:08 --> Controller Class Initialized
DEBUG - 2020-08-18 17:35:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:35:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:35:08 --> Model Class Initialized
INFO - 2020-08-18 17:35:08 --> Model Class Initialized
INFO - 2020-08-18 17:35:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:35:08 --> Final output sent to browser
DEBUG - 2020-08-18 17:35:08 --> Total execution time: 0.0324
INFO - 2020-08-18 17:37:00 --> Config Class Initialized
INFO - 2020-08-18 17:37:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:37:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:37:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:37:00 --> URI Class Initialized
INFO - 2020-08-18 17:37:00 --> Router Class Initialized
INFO - 2020-08-18 17:37:00 --> Output Class Initialized
INFO - 2020-08-18 17:37:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:37:00 --> Input Class Initialized
INFO - 2020-08-18 17:37:00 --> Language Class Initialized
INFO - 2020-08-18 17:37:00 --> Loader Class Initialized
INFO - 2020-08-18 17:37:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:37:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:37:00 --> Email Class Initialized
INFO - 2020-08-18 17:37:00 --> Controller Class Initialized
DEBUG - 2020-08-18 17:37:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:37:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:37:00 --> Model Class Initialized
INFO - 2020-08-18 17:37:00 --> Model Class Initialized
INFO - 2020-08-18 17:37:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:37:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:37:00 --> Total execution time: 0.0288
INFO - 2020-08-18 17:39:14 --> Config Class Initialized
INFO - 2020-08-18 17:39:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:39:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:39:14 --> Utf8 Class Initialized
INFO - 2020-08-18 17:39:14 --> URI Class Initialized
INFO - 2020-08-18 17:39:14 --> Router Class Initialized
INFO - 2020-08-18 17:39:14 --> Output Class Initialized
INFO - 2020-08-18 17:39:14 --> Security Class Initialized
DEBUG - 2020-08-18 17:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:39:14 --> Input Class Initialized
INFO - 2020-08-18 17:39:14 --> Language Class Initialized
INFO - 2020-08-18 17:39:14 --> Loader Class Initialized
INFO - 2020-08-18 17:39:14 --> Helper loaded: url_helper
INFO - 2020-08-18 17:39:14 --> Database Driver Class Initialized
INFO - 2020-08-18 17:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:39:14 --> Email Class Initialized
INFO - 2020-08-18 17:39:14 --> Controller Class Initialized
DEBUG - 2020-08-18 17:39:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:39:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:39:14 --> Model Class Initialized
INFO - 2020-08-18 17:39:14 --> Model Class Initialized
INFO - 2020-08-18 17:39:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:39:14 --> Final output sent to browser
DEBUG - 2020-08-18 17:39:14 --> Total execution time: 0.0297
INFO - 2020-08-18 17:39:50 --> Config Class Initialized
INFO - 2020-08-18 17:39:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:39:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:39:50 --> Utf8 Class Initialized
INFO - 2020-08-18 17:39:50 --> URI Class Initialized
INFO - 2020-08-18 17:39:50 --> Router Class Initialized
INFO - 2020-08-18 17:39:50 --> Output Class Initialized
INFO - 2020-08-18 17:39:50 --> Security Class Initialized
DEBUG - 2020-08-18 17:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:39:50 --> Input Class Initialized
INFO - 2020-08-18 17:39:50 --> Language Class Initialized
INFO - 2020-08-18 17:39:50 --> Loader Class Initialized
INFO - 2020-08-18 17:39:50 --> Helper loaded: url_helper
INFO - 2020-08-18 17:39:50 --> Database Driver Class Initialized
INFO - 2020-08-18 17:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:39:50 --> Email Class Initialized
INFO - 2020-08-18 17:39:50 --> Controller Class Initialized
DEBUG - 2020-08-18 17:39:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:39:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:39:50 --> Model Class Initialized
INFO - 2020-08-18 17:39:50 --> Model Class Initialized
INFO - 2020-08-18 17:39:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:39:50 --> Final output sent to browser
DEBUG - 2020-08-18 17:39:50 --> Total execution time: 0.0256
INFO - 2020-08-18 17:40:14 --> Config Class Initialized
INFO - 2020-08-18 17:40:14 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:40:14 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:40:14 --> Utf8 Class Initialized
INFO - 2020-08-18 17:40:14 --> URI Class Initialized
INFO - 2020-08-18 17:40:14 --> Router Class Initialized
INFO - 2020-08-18 17:40:14 --> Output Class Initialized
INFO - 2020-08-18 17:40:14 --> Security Class Initialized
DEBUG - 2020-08-18 17:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:40:14 --> Input Class Initialized
INFO - 2020-08-18 17:40:14 --> Language Class Initialized
INFO - 2020-08-18 17:40:14 --> Loader Class Initialized
INFO - 2020-08-18 17:40:14 --> Helper loaded: url_helper
INFO - 2020-08-18 17:40:14 --> Database Driver Class Initialized
INFO - 2020-08-18 17:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:40:14 --> Email Class Initialized
INFO - 2020-08-18 17:40:14 --> Controller Class Initialized
DEBUG - 2020-08-18 17:40:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:40:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:40:14 --> Model Class Initialized
INFO - 2020-08-18 17:40:14 --> Model Class Initialized
INFO - 2020-08-18 17:40:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:40:14 --> Final output sent to browser
DEBUG - 2020-08-18 17:40:14 --> Total execution time: 0.0248
INFO - 2020-08-18 17:40:20 --> Config Class Initialized
INFO - 2020-08-18 17:40:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:40:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:40:20 --> Utf8 Class Initialized
INFO - 2020-08-18 17:40:20 --> URI Class Initialized
INFO - 2020-08-18 17:40:20 --> Router Class Initialized
INFO - 2020-08-18 17:40:20 --> Output Class Initialized
INFO - 2020-08-18 17:40:20 --> Security Class Initialized
DEBUG - 2020-08-18 17:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:40:20 --> Input Class Initialized
INFO - 2020-08-18 17:40:20 --> Language Class Initialized
INFO - 2020-08-18 17:40:20 --> Loader Class Initialized
INFO - 2020-08-18 17:40:20 --> Helper loaded: url_helper
INFO - 2020-08-18 17:40:20 --> Database Driver Class Initialized
INFO - 2020-08-18 17:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:40:20 --> Email Class Initialized
INFO - 2020-08-18 17:40:20 --> Controller Class Initialized
DEBUG - 2020-08-18 17:40:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:40:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:40:20 --> Model Class Initialized
INFO - 2020-08-18 17:40:20 --> Model Class Initialized
INFO - 2020-08-18 17:40:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 17:40:20 --> Final output sent to browser
DEBUG - 2020-08-18 17:40:20 --> Total execution time: 0.0246
INFO - 2020-08-18 17:40:24 --> Config Class Initialized
INFO - 2020-08-18 17:40:24 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:40:24 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:40:24 --> Utf8 Class Initialized
INFO - 2020-08-18 17:40:24 --> URI Class Initialized
INFO - 2020-08-18 17:40:24 --> Router Class Initialized
INFO - 2020-08-18 17:40:24 --> Output Class Initialized
INFO - 2020-08-18 17:40:24 --> Security Class Initialized
DEBUG - 2020-08-18 17:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:40:24 --> Input Class Initialized
INFO - 2020-08-18 17:40:24 --> Language Class Initialized
INFO - 2020-08-18 17:40:24 --> Loader Class Initialized
INFO - 2020-08-18 17:40:24 --> Helper loaded: url_helper
INFO - 2020-08-18 17:40:24 --> Database Driver Class Initialized
INFO - 2020-08-18 17:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:40:24 --> Email Class Initialized
INFO - 2020-08-18 17:40:24 --> Controller Class Initialized
DEBUG - 2020-08-18 17:40:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:40:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:40:24 --> Model Class Initialized
INFO - 2020-08-18 17:40:24 --> Model Class Initialized
INFO - 2020-08-18 17:40:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:40:24 --> Final output sent to browser
DEBUG - 2020-08-18 17:40:24 --> Total execution time: 0.0271
INFO - 2020-08-18 17:45:09 --> Config Class Initialized
INFO - 2020-08-18 17:45:09 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:45:09 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:45:09 --> Utf8 Class Initialized
INFO - 2020-08-18 17:45:09 --> URI Class Initialized
INFO - 2020-08-18 17:45:09 --> Router Class Initialized
INFO - 2020-08-18 17:45:09 --> Output Class Initialized
INFO - 2020-08-18 17:45:09 --> Security Class Initialized
DEBUG - 2020-08-18 17:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:45:09 --> Input Class Initialized
INFO - 2020-08-18 17:45:09 --> Language Class Initialized
INFO - 2020-08-18 17:45:09 --> Loader Class Initialized
INFO - 2020-08-18 17:45:09 --> Helper loaded: url_helper
INFO - 2020-08-18 17:45:09 --> Database Driver Class Initialized
INFO - 2020-08-18 17:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:45:09 --> Email Class Initialized
INFO - 2020-08-18 17:45:09 --> Controller Class Initialized
DEBUG - 2020-08-18 17:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:45:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:45:09 --> Model Class Initialized
INFO - 2020-08-18 17:45:09 --> Model Class Initialized
INFO - 2020-08-18 17:45:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 17:45:09 --> Final output sent to browser
DEBUG - 2020-08-18 17:45:09 --> Total execution time: 0.0253
INFO - 2020-08-18 17:45:11 --> Config Class Initialized
INFO - 2020-08-18 17:45:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:45:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:45:11 --> Utf8 Class Initialized
INFO - 2020-08-18 17:45:11 --> URI Class Initialized
INFO - 2020-08-18 17:45:11 --> Router Class Initialized
INFO - 2020-08-18 17:45:11 --> Output Class Initialized
INFO - 2020-08-18 17:45:11 --> Security Class Initialized
DEBUG - 2020-08-18 17:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:45:11 --> Input Class Initialized
INFO - 2020-08-18 17:45:11 --> Language Class Initialized
INFO - 2020-08-18 17:45:11 --> Loader Class Initialized
INFO - 2020-08-18 17:45:11 --> Helper loaded: url_helper
INFO - 2020-08-18 17:45:11 --> Database Driver Class Initialized
INFO - 2020-08-18 17:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:45:11 --> Email Class Initialized
INFO - 2020-08-18 17:45:11 --> Controller Class Initialized
DEBUG - 2020-08-18 17:45:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:45:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:45:11 --> Model Class Initialized
INFO - 2020-08-18 17:45:11 --> Model Class Initialized
INFO - 2020-08-18 17:45:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:45:11 --> Final output sent to browser
DEBUG - 2020-08-18 17:45:11 --> Total execution time: 0.0248
INFO - 2020-08-18 17:45:22 --> Config Class Initialized
INFO - 2020-08-18 17:45:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:45:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:45:22 --> Utf8 Class Initialized
INFO - 2020-08-18 17:45:22 --> URI Class Initialized
INFO - 2020-08-18 17:45:22 --> Router Class Initialized
INFO - 2020-08-18 17:45:22 --> Output Class Initialized
INFO - 2020-08-18 17:45:22 --> Security Class Initialized
DEBUG - 2020-08-18 17:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:45:22 --> Input Class Initialized
INFO - 2020-08-18 17:45:22 --> Language Class Initialized
INFO - 2020-08-18 17:45:22 --> Loader Class Initialized
INFO - 2020-08-18 17:45:22 --> Helper loaded: url_helper
INFO - 2020-08-18 17:45:22 --> Database Driver Class Initialized
INFO - 2020-08-18 17:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:45:22 --> Email Class Initialized
INFO - 2020-08-18 17:45:22 --> Controller Class Initialized
DEBUG - 2020-08-18 17:45:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:45:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:45:22 --> Model Class Initialized
INFO - 2020-08-18 17:45:22 --> Model Class Initialized
INFO - 2020-08-18 17:45:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:45:22 --> Final output sent to browser
DEBUG - 2020-08-18 17:45:22 --> Total execution time: 0.0277
INFO - 2020-08-18 17:45:24 --> Config Class Initialized
INFO - 2020-08-18 17:45:24 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:45:24 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:45:24 --> Utf8 Class Initialized
INFO - 2020-08-18 17:45:24 --> URI Class Initialized
INFO - 2020-08-18 17:45:24 --> Router Class Initialized
INFO - 2020-08-18 17:45:24 --> Output Class Initialized
INFO - 2020-08-18 17:45:24 --> Security Class Initialized
DEBUG - 2020-08-18 17:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:45:24 --> Input Class Initialized
INFO - 2020-08-18 17:45:24 --> Language Class Initialized
INFO - 2020-08-18 17:45:24 --> Loader Class Initialized
INFO - 2020-08-18 17:45:24 --> Helper loaded: url_helper
INFO - 2020-08-18 17:45:24 --> Database Driver Class Initialized
INFO - 2020-08-18 17:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:45:25 --> Email Class Initialized
INFO - 2020-08-18 17:45:25 --> Controller Class Initialized
DEBUG - 2020-08-18 17:45:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:45:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:45:25 --> Model Class Initialized
INFO - 2020-08-18 17:45:25 --> Model Class Initialized
INFO - 2020-08-18 17:45:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 17:45:25 --> Final output sent to browser
DEBUG - 2020-08-18 17:45:25 --> Total execution time: 0.0315
INFO - 2020-08-18 17:45:28 --> Config Class Initialized
INFO - 2020-08-18 17:45:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:45:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:45:28 --> Utf8 Class Initialized
INFO - 2020-08-18 17:45:28 --> URI Class Initialized
INFO - 2020-08-18 17:45:28 --> Router Class Initialized
INFO - 2020-08-18 17:45:28 --> Output Class Initialized
INFO - 2020-08-18 17:45:28 --> Security Class Initialized
DEBUG - 2020-08-18 17:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:45:28 --> Input Class Initialized
INFO - 2020-08-18 17:45:28 --> Language Class Initialized
INFO - 2020-08-18 17:45:28 --> Loader Class Initialized
INFO - 2020-08-18 17:45:28 --> Helper loaded: url_helper
INFO - 2020-08-18 17:45:28 --> Database Driver Class Initialized
INFO - 2020-08-18 17:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:45:28 --> Email Class Initialized
INFO - 2020-08-18 17:45:28 --> Controller Class Initialized
DEBUG - 2020-08-18 17:45:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:45:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:45:28 --> Model Class Initialized
INFO - 2020-08-18 17:45:28 --> Model Class Initialized
INFO - 2020-08-18 17:45:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:45:28 --> Final output sent to browser
DEBUG - 2020-08-18 17:45:28 --> Total execution time: 0.0248
INFO - 2020-08-18 17:46:09 --> Config Class Initialized
INFO - 2020-08-18 17:46:09 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:46:09 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:46:09 --> Utf8 Class Initialized
INFO - 2020-08-18 17:46:09 --> URI Class Initialized
INFO - 2020-08-18 17:46:09 --> Router Class Initialized
INFO - 2020-08-18 17:46:09 --> Output Class Initialized
INFO - 2020-08-18 17:46:09 --> Security Class Initialized
DEBUG - 2020-08-18 17:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:46:09 --> Input Class Initialized
INFO - 2020-08-18 17:46:09 --> Language Class Initialized
INFO - 2020-08-18 17:46:09 --> Loader Class Initialized
INFO - 2020-08-18 17:46:09 --> Helper loaded: url_helper
INFO - 2020-08-18 17:46:09 --> Database Driver Class Initialized
INFO - 2020-08-18 17:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:46:09 --> Email Class Initialized
INFO - 2020-08-18 17:46:09 --> Controller Class Initialized
DEBUG - 2020-08-18 17:46:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:46:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:46:09 --> Model Class Initialized
INFO - 2020-08-18 17:46:09 --> Model Class Initialized
INFO - 2020-08-18 17:46:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 17:46:09 --> Final output sent to browser
DEBUG - 2020-08-18 17:46:09 --> Total execution time: 0.0283
INFO - 2020-08-18 17:46:12 --> Config Class Initialized
INFO - 2020-08-18 17:46:12 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:46:12 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:46:12 --> Utf8 Class Initialized
INFO - 2020-08-18 17:46:12 --> URI Class Initialized
INFO - 2020-08-18 17:46:12 --> Router Class Initialized
INFO - 2020-08-18 17:46:12 --> Output Class Initialized
INFO - 2020-08-18 17:46:12 --> Security Class Initialized
DEBUG - 2020-08-18 17:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:46:12 --> Input Class Initialized
INFO - 2020-08-18 17:46:12 --> Language Class Initialized
INFO - 2020-08-18 17:46:12 --> Loader Class Initialized
INFO - 2020-08-18 17:46:12 --> Helper loaded: url_helper
INFO - 2020-08-18 17:46:12 --> Database Driver Class Initialized
INFO - 2020-08-18 17:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:46:12 --> Email Class Initialized
INFO - 2020-08-18 17:46:12 --> Controller Class Initialized
DEBUG - 2020-08-18 17:46:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:46:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:46:12 --> Model Class Initialized
INFO - 2020-08-18 17:46:12 --> Model Class Initialized
INFO - 2020-08-18 17:46:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:46:12 --> Final output sent to browser
DEBUG - 2020-08-18 17:46:12 --> Total execution time: 0.0249
INFO - 2020-08-18 17:46:32 --> Config Class Initialized
INFO - 2020-08-18 17:46:32 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:46:32 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:46:32 --> Utf8 Class Initialized
INFO - 2020-08-18 17:46:32 --> URI Class Initialized
INFO - 2020-08-18 17:46:32 --> Router Class Initialized
INFO - 2020-08-18 17:46:32 --> Output Class Initialized
INFO - 2020-08-18 17:46:32 --> Security Class Initialized
DEBUG - 2020-08-18 17:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:46:32 --> Input Class Initialized
INFO - 2020-08-18 17:46:32 --> Language Class Initialized
INFO - 2020-08-18 17:46:32 --> Loader Class Initialized
INFO - 2020-08-18 17:46:32 --> Helper loaded: url_helper
INFO - 2020-08-18 17:46:32 --> Database Driver Class Initialized
INFO - 2020-08-18 17:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:46:32 --> Email Class Initialized
INFO - 2020-08-18 17:46:32 --> Controller Class Initialized
DEBUG - 2020-08-18 17:46:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:46:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:46:32 --> Model Class Initialized
INFO - 2020-08-18 17:46:32 --> Model Class Initialized
INFO - 2020-08-18 17:46:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:46:32 --> Final output sent to browser
DEBUG - 2020-08-18 17:46:32 --> Total execution time: 0.0230
INFO - 2020-08-18 17:46:37 --> Config Class Initialized
INFO - 2020-08-18 17:46:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:46:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:46:37 --> Utf8 Class Initialized
INFO - 2020-08-18 17:46:37 --> URI Class Initialized
INFO - 2020-08-18 17:46:37 --> Router Class Initialized
INFO - 2020-08-18 17:46:37 --> Output Class Initialized
INFO - 2020-08-18 17:46:37 --> Security Class Initialized
DEBUG - 2020-08-18 17:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:46:37 --> Input Class Initialized
INFO - 2020-08-18 17:46:37 --> Language Class Initialized
INFO - 2020-08-18 17:46:37 --> Loader Class Initialized
INFO - 2020-08-18 17:46:37 --> Helper loaded: url_helper
INFO - 2020-08-18 17:46:37 --> Database Driver Class Initialized
INFO - 2020-08-18 17:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:46:37 --> Email Class Initialized
INFO - 2020-08-18 17:46:37 --> Controller Class Initialized
DEBUG - 2020-08-18 17:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:46:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:46:37 --> Model Class Initialized
INFO - 2020-08-18 17:46:37 --> Model Class Initialized
INFO - 2020-08-18 17:46:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 17:46:37 --> Final output sent to browser
DEBUG - 2020-08-18 17:46:37 --> Total execution time: 0.0275
INFO - 2020-08-18 17:46:40 --> Config Class Initialized
INFO - 2020-08-18 17:46:40 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:46:40 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:46:40 --> Utf8 Class Initialized
INFO - 2020-08-18 17:46:40 --> URI Class Initialized
INFO - 2020-08-18 17:46:40 --> Router Class Initialized
INFO - 2020-08-18 17:46:40 --> Output Class Initialized
INFO - 2020-08-18 17:46:40 --> Security Class Initialized
DEBUG - 2020-08-18 17:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:46:40 --> Input Class Initialized
INFO - 2020-08-18 17:46:40 --> Language Class Initialized
INFO - 2020-08-18 17:46:40 --> Loader Class Initialized
INFO - 2020-08-18 17:46:40 --> Helper loaded: url_helper
INFO - 2020-08-18 17:46:40 --> Database Driver Class Initialized
INFO - 2020-08-18 17:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:46:40 --> Email Class Initialized
INFO - 2020-08-18 17:46:40 --> Controller Class Initialized
DEBUG - 2020-08-18 17:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:46:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:46:40 --> Model Class Initialized
INFO - 2020-08-18 17:46:40 --> Model Class Initialized
INFO - 2020-08-18 17:46:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:46:40 --> Final output sent to browser
DEBUG - 2020-08-18 17:46:40 --> Total execution time: 0.0259
INFO - 2020-08-18 17:46:44 --> Config Class Initialized
INFO - 2020-08-18 17:46:44 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:46:44 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:46:44 --> Utf8 Class Initialized
INFO - 2020-08-18 17:46:44 --> URI Class Initialized
INFO - 2020-08-18 17:46:44 --> Router Class Initialized
INFO - 2020-08-18 17:46:44 --> Output Class Initialized
INFO - 2020-08-18 17:46:44 --> Security Class Initialized
DEBUG - 2020-08-18 17:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:46:44 --> Input Class Initialized
INFO - 2020-08-18 17:46:44 --> Language Class Initialized
INFO - 2020-08-18 17:46:44 --> Loader Class Initialized
INFO - 2020-08-18 17:46:44 --> Helper loaded: url_helper
INFO - 2020-08-18 17:46:44 --> Database Driver Class Initialized
INFO - 2020-08-18 17:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:46:44 --> Email Class Initialized
INFO - 2020-08-18 17:46:44 --> Controller Class Initialized
DEBUG - 2020-08-18 17:46:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:46:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:46:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 17:46:44 --> Final output sent to browser
DEBUG - 2020-08-18 17:46:44 --> Total execution time: 0.0212
INFO - 2020-08-18 17:47:13 --> Config Class Initialized
INFO - 2020-08-18 17:47:13 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:47:13 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:47:13 --> Utf8 Class Initialized
INFO - 2020-08-18 17:47:13 --> URI Class Initialized
DEBUG - 2020-08-18 17:47:13 --> No URI present. Default controller set.
INFO - 2020-08-18 17:47:13 --> Router Class Initialized
INFO - 2020-08-18 17:47:13 --> Output Class Initialized
INFO - 2020-08-18 17:47:13 --> Security Class Initialized
DEBUG - 2020-08-18 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:47:13 --> Input Class Initialized
INFO - 2020-08-18 17:47:13 --> Language Class Initialized
INFO - 2020-08-18 17:47:13 --> Loader Class Initialized
INFO - 2020-08-18 17:47:13 --> Helper loaded: url_helper
INFO - 2020-08-18 17:47:13 --> Database Driver Class Initialized
INFO - 2020-08-18 17:47:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:47:13 --> Email Class Initialized
INFO - 2020-08-18 17:47:13 --> Controller Class Initialized
INFO - 2020-08-18 17:47:13 --> Model Class Initialized
INFO - 2020-08-18 17:47:13 --> Model Class Initialized
DEBUG - 2020-08-18 17:47:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:47:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:47:13 --> Final output sent to browser
DEBUG - 2020-08-18 17:47:13 --> Total execution time: 0.0239
INFO - 2020-08-18 17:47:34 --> Config Class Initialized
INFO - 2020-08-18 17:47:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:47:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:47:34 --> Utf8 Class Initialized
INFO - 2020-08-18 17:47:34 --> URI Class Initialized
INFO - 2020-08-18 17:47:34 --> Router Class Initialized
INFO - 2020-08-18 17:47:34 --> Output Class Initialized
INFO - 2020-08-18 17:47:34 --> Security Class Initialized
DEBUG - 2020-08-18 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:47:34 --> Input Class Initialized
INFO - 2020-08-18 17:47:34 --> Language Class Initialized
INFO - 2020-08-18 17:47:34 --> Loader Class Initialized
INFO - 2020-08-18 17:47:34 --> Helper loaded: url_helper
INFO - 2020-08-18 17:47:34 --> Database Driver Class Initialized
INFO - 2020-08-18 17:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:47:34 --> Email Class Initialized
INFO - 2020-08-18 17:47:34 --> Controller Class Initialized
INFO - 2020-08-18 17:47:34 --> Model Class Initialized
INFO - 2020-08-18 17:47:34 --> Model Class Initialized
DEBUG - 2020-08-18 17:47:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:47:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:47:34 --> Model Class Initialized
INFO - 2020-08-18 17:47:34 --> Final output sent to browser
DEBUG - 2020-08-18 17:47:34 --> Total execution time: 0.0283
INFO - 2020-08-18 17:47:34 --> Config Class Initialized
INFO - 2020-08-18 17:47:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:47:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:47:34 --> Utf8 Class Initialized
INFO - 2020-08-18 17:47:34 --> URI Class Initialized
INFO - 2020-08-18 17:47:34 --> Router Class Initialized
INFO - 2020-08-18 17:47:34 --> Output Class Initialized
INFO - 2020-08-18 17:47:34 --> Security Class Initialized
DEBUG - 2020-08-18 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:47:34 --> Input Class Initialized
INFO - 2020-08-18 17:47:34 --> Language Class Initialized
INFO - 2020-08-18 17:47:34 --> Loader Class Initialized
INFO - 2020-08-18 17:47:34 --> Helper loaded: url_helper
INFO - 2020-08-18 17:47:34 --> Database Driver Class Initialized
INFO - 2020-08-18 17:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:47:34 --> Email Class Initialized
INFO - 2020-08-18 17:47:34 --> Controller Class Initialized
INFO - 2020-08-18 17:47:34 --> Model Class Initialized
INFO - 2020-08-18 17:47:34 --> Model Class Initialized
DEBUG - 2020-08-18 17:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:47:34 --> Config Class Initialized
INFO - 2020-08-18 17:47:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:47:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:47:34 --> Utf8 Class Initialized
INFO - 2020-08-18 17:47:34 --> URI Class Initialized
INFO - 2020-08-18 17:47:34 --> Router Class Initialized
INFO - 2020-08-18 17:47:34 --> Output Class Initialized
INFO - 2020-08-18 17:47:34 --> Security Class Initialized
DEBUG - 2020-08-18 17:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:47:34 --> Input Class Initialized
INFO - 2020-08-18 17:47:34 --> Language Class Initialized
INFO - 2020-08-18 17:47:34 --> Loader Class Initialized
INFO - 2020-08-18 17:47:34 --> Helper loaded: url_helper
INFO - 2020-08-18 17:47:34 --> Database Driver Class Initialized
INFO - 2020-08-18 17:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:47:35 --> Email Class Initialized
INFO - 2020-08-18 17:47:35 --> Controller Class Initialized
DEBUG - 2020-08-18 17:47:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:47:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:47:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:47:35 --> Final output sent to browser
DEBUG - 2020-08-18 17:47:35 --> Total execution time: 0.4062
INFO - 2020-08-18 17:48:22 --> Config Class Initialized
INFO - 2020-08-18 17:48:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:48:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:48:22 --> Utf8 Class Initialized
INFO - 2020-08-18 17:48:22 --> URI Class Initialized
INFO - 2020-08-18 17:48:22 --> Router Class Initialized
INFO - 2020-08-18 17:48:22 --> Output Class Initialized
INFO - 2020-08-18 17:48:22 --> Security Class Initialized
DEBUG - 2020-08-18 17:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:48:22 --> Input Class Initialized
INFO - 2020-08-18 17:48:22 --> Language Class Initialized
INFO - 2020-08-18 17:48:22 --> Loader Class Initialized
INFO - 2020-08-18 17:48:22 --> Helper loaded: url_helper
INFO - 2020-08-18 17:48:22 --> Database Driver Class Initialized
INFO - 2020-08-18 17:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:48:22 --> Email Class Initialized
INFO - 2020-08-18 17:48:22 --> Controller Class Initialized
DEBUG - 2020-08-18 17:48:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:48:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:48:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:48:22 --> Final output sent to browser
DEBUG - 2020-08-18 17:48:22 --> Total execution time: 0.0226
INFO - 2020-08-18 17:48:28 --> Config Class Initialized
INFO - 2020-08-18 17:48:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:48:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:48:28 --> Utf8 Class Initialized
INFO - 2020-08-18 17:48:28 --> URI Class Initialized
INFO - 2020-08-18 17:48:28 --> Router Class Initialized
INFO - 2020-08-18 17:48:28 --> Output Class Initialized
INFO - 2020-08-18 17:48:28 --> Security Class Initialized
DEBUG - 2020-08-18 17:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:48:28 --> Input Class Initialized
INFO - 2020-08-18 17:48:28 --> Language Class Initialized
INFO - 2020-08-18 17:48:28 --> Loader Class Initialized
INFO - 2020-08-18 17:48:28 --> Helper loaded: url_helper
INFO - 2020-08-18 17:48:28 --> Database Driver Class Initialized
INFO - 2020-08-18 17:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:48:28 --> Email Class Initialized
INFO - 2020-08-18 17:48:28 --> Controller Class Initialized
DEBUG - 2020-08-18 17:48:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:48:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:48:28 --> Model Class Initialized
INFO - 2020-08-18 17:48:28 --> Model Class Initialized
INFO - 2020-08-18 17:48:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:48:28 --> Final output sent to browser
DEBUG - 2020-08-18 17:48:28 --> Total execution time: 0.0272
INFO - 2020-08-18 17:48:35 --> Config Class Initialized
INFO - 2020-08-18 17:48:35 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:48:35 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:48:35 --> Utf8 Class Initialized
INFO - 2020-08-18 17:48:35 --> URI Class Initialized
INFO - 2020-08-18 17:48:35 --> Router Class Initialized
INFO - 2020-08-18 17:48:35 --> Output Class Initialized
INFO - 2020-08-18 17:48:35 --> Security Class Initialized
DEBUG - 2020-08-18 17:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:48:35 --> Input Class Initialized
INFO - 2020-08-18 17:48:35 --> Language Class Initialized
INFO - 2020-08-18 17:48:35 --> Loader Class Initialized
INFO - 2020-08-18 17:48:35 --> Helper loaded: url_helper
INFO - 2020-08-18 17:48:35 --> Database Driver Class Initialized
INFO - 2020-08-18 17:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:48:35 --> Email Class Initialized
INFO - 2020-08-18 17:48:35 --> Controller Class Initialized
DEBUG - 2020-08-18 17:48:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:48:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:48:35 --> Model Class Initialized
INFO - 2020-08-18 17:48:35 --> Model Class Initialized
INFO - 2020-08-18 17:48:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-18 17:48:35 --> Final output sent to browser
DEBUG - 2020-08-18 17:48:35 --> Total execution time: 0.0350
INFO - 2020-08-18 17:48:43 --> Config Class Initialized
INFO - 2020-08-18 17:48:43 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:48:43 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:48:43 --> Utf8 Class Initialized
INFO - 2020-08-18 17:48:43 --> URI Class Initialized
INFO - 2020-08-18 17:48:43 --> Router Class Initialized
INFO - 2020-08-18 17:48:43 --> Output Class Initialized
INFO - 2020-08-18 17:48:43 --> Security Class Initialized
DEBUG - 2020-08-18 17:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:48:43 --> Input Class Initialized
INFO - 2020-08-18 17:48:43 --> Language Class Initialized
INFO - 2020-08-18 17:48:43 --> Loader Class Initialized
INFO - 2020-08-18 17:48:43 --> Helper loaded: url_helper
INFO - 2020-08-18 17:48:43 --> Database Driver Class Initialized
INFO - 2020-08-18 17:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:48:43 --> Email Class Initialized
INFO - 2020-08-18 17:48:43 --> Controller Class Initialized
DEBUG - 2020-08-18 17:48:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:48:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:48:43 --> Model Class Initialized
INFO - 2020-08-18 17:48:43 --> Model Class Initialized
INFO - 2020-08-18 17:48:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:48:43 --> Final output sent to browser
DEBUG - 2020-08-18 17:48:43 --> Total execution time: 0.0285
INFO - 2020-08-18 17:49:15 --> Config Class Initialized
INFO - 2020-08-18 17:49:15 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:15 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:15 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:15 --> URI Class Initialized
INFO - 2020-08-18 17:49:15 --> Router Class Initialized
INFO - 2020-08-18 17:49:15 --> Output Class Initialized
INFO - 2020-08-18 17:49:15 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:15 --> Input Class Initialized
INFO - 2020-08-18 17:49:15 --> Language Class Initialized
INFO - 2020-08-18 17:49:15 --> Loader Class Initialized
INFO - 2020-08-18 17:49:15 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:15 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:15 --> Email Class Initialized
INFO - 2020-08-18 17:49:15 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:15 --> Model Class Initialized
INFO - 2020-08-18 17:49:15 --> Model Class Initialized
INFO - 2020-08-18 17:49:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-08-18 17:49:15 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:15 --> Total execution time: 0.0223
INFO - 2020-08-18 17:49:17 --> Config Class Initialized
INFO - 2020-08-18 17:49:17 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:17 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:17 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:17 --> URI Class Initialized
INFO - 2020-08-18 17:49:17 --> Router Class Initialized
INFO - 2020-08-18 17:49:17 --> Output Class Initialized
INFO - 2020-08-18 17:49:17 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:17 --> Input Class Initialized
INFO - 2020-08-18 17:49:17 --> Language Class Initialized
INFO - 2020-08-18 17:49:17 --> Loader Class Initialized
INFO - 2020-08-18 17:49:17 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:17 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:17 --> Email Class Initialized
INFO - 2020-08-18 17:49:17 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:17 --> Model Class Initialized
INFO - 2020-08-18 17:49:17 --> Model Class Initialized
INFO - 2020-08-18 17:49:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:49:17 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:17 --> Total execution time: 0.0259
INFO - 2020-08-18 17:49:26 --> Config Class Initialized
INFO - 2020-08-18 17:49:26 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:26 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:26 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:26 --> URI Class Initialized
INFO - 2020-08-18 17:49:26 --> Router Class Initialized
INFO - 2020-08-18 17:49:26 --> Output Class Initialized
INFO - 2020-08-18 17:49:26 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:26 --> Input Class Initialized
INFO - 2020-08-18 17:49:26 --> Language Class Initialized
INFO - 2020-08-18 17:49:26 --> Loader Class Initialized
INFO - 2020-08-18 17:49:26 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:26 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:26 --> Email Class Initialized
INFO - 2020-08-18 17:49:26 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:49:26 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:26 --> Total execution time: 0.1276
INFO - 2020-08-18 17:49:30 --> Config Class Initialized
INFO - 2020-08-18 17:49:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:30 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:30 --> URI Class Initialized
INFO - 2020-08-18 17:49:30 --> Router Class Initialized
INFO - 2020-08-18 17:49:30 --> Output Class Initialized
INFO - 2020-08-18 17:49:30 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:30 --> Input Class Initialized
INFO - 2020-08-18 17:49:30 --> Language Class Initialized
INFO - 2020-08-18 17:49:30 --> Loader Class Initialized
INFO - 2020-08-18 17:49:30 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:30 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:30 --> Email Class Initialized
INFO - 2020-08-18 17:49:30 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:30 --> Model Class Initialized
INFO - 2020-08-18 17:49:30 --> Model Class Initialized
INFO - 2020-08-18 17:49:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-08-18 17:49:30 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:30 --> Total execution time: 0.0290
INFO - 2020-08-18 17:49:39 --> Config Class Initialized
INFO - 2020-08-18 17:49:39 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:39 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:39 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:39 --> URI Class Initialized
INFO - 2020-08-18 17:49:39 --> Router Class Initialized
INFO - 2020-08-18 17:49:39 --> Output Class Initialized
INFO - 2020-08-18 17:49:39 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:39 --> Input Class Initialized
INFO - 2020-08-18 17:49:39 --> Language Class Initialized
INFO - 2020-08-18 17:49:39 --> Loader Class Initialized
INFO - 2020-08-18 17:49:39 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:39 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:39 --> Email Class Initialized
INFO - 2020-08-18 17:49:39 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:39 --> Model Class Initialized
INFO - 2020-08-18 17:49:39 --> Model Class Initialized
INFO - 2020-08-18 17:49:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:49:39 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:39 --> Total execution time: 0.0224
INFO - 2020-08-18 17:49:41 --> Config Class Initialized
INFO - 2020-08-18 17:49:41 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:41 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:41 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:41 --> URI Class Initialized
INFO - 2020-08-18 17:49:41 --> Router Class Initialized
INFO - 2020-08-18 17:49:41 --> Output Class Initialized
INFO - 2020-08-18 17:49:41 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:41 --> Input Class Initialized
INFO - 2020-08-18 17:49:41 --> Language Class Initialized
INFO - 2020-08-18 17:49:41 --> Loader Class Initialized
INFO - 2020-08-18 17:49:41 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:41 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:41 --> Email Class Initialized
INFO - 2020-08-18 17:49:41 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:41 --> Model Class Initialized
INFO - 2020-08-18 17:49:41 --> Model Class Initialized
INFO - 2020-08-18 17:49:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 17:49:41 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:41 --> Total execution time: 0.0266
INFO - 2020-08-18 17:49:44 --> Config Class Initialized
INFO - 2020-08-18 17:49:44 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:44 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:44 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:44 --> URI Class Initialized
INFO - 2020-08-18 17:49:44 --> Router Class Initialized
INFO - 2020-08-18 17:49:44 --> Output Class Initialized
INFO - 2020-08-18 17:49:44 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:44 --> Input Class Initialized
INFO - 2020-08-18 17:49:44 --> Language Class Initialized
INFO - 2020-08-18 17:49:44 --> Loader Class Initialized
INFO - 2020-08-18 17:49:44 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:44 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:44 --> Email Class Initialized
INFO - 2020-08-18 17:49:44 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:44 --> Model Class Initialized
INFO - 2020-08-18 17:49:44 --> Model Class Initialized
INFO - 2020-08-18 17:49:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:49:44 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:44 --> Total execution time: 0.0302
INFO - 2020-08-18 17:49:47 --> Config Class Initialized
INFO - 2020-08-18 17:49:47 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:47 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:47 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:47 --> URI Class Initialized
INFO - 2020-08-18 17:49:47 --> Router Class Initialized
INFO - 2020-08-18 17:49:47 --> Output Class Initialized
INFO - 2020-08-18 17:49:47 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:47 --> Input Class Initialized
INFO - 2020-08-18 17:49:47 --> Language Class Initialized
INFO - 2020-08-18 17:49:47 --> Loader Class Initialized
INFO - 2020-08-18 17:49:47 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:47 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:47 --> Email Class Initialized
INFO - 2020-08-18 17:49:47 --> Controller Class Initialized
DEBUG - 2020-08-18 17:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:49:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-08-18 17:49:47 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:47 --> Total execution time: 0.0235
INFO - 2020-08-18 17:49:54 --> Config Class Initialized
INFO - 2020-08-18 17:49:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:49:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:49:54 --> Utf8 Class Initialized
INFO - 2020-08-18 17:49:54 --> URI Class Initialized
DEBUG - 2020-08-18 17:49:54 --> No URI present. Default controller set.
INFO - 2020-08-18 17:49:54 --> Router Class Initialized
INFO - 2020-08-18 17:49:54 --> Output Class Initialized
INFO - 2020-08-18 17:49:54 --> Security Class Initialized
DEBUG - 2020-08-18 17:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:49:54 --> Input Class Initialized
INFO - 2020-08-18 17:49:54 --> Language Class Initialized
INFO - 2020-08-18 17:49:54 --> Loader Class Initialized
INFO - 2020-08-18 17:49:54 --> Helper loaded: url_helper
INFO - 2020-08-18 17:49:54 --> Database Driver Class Initialized
INFO - 2020-08-18 17:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:49:54 --> Email Class Initialized
INFO - 2020-08-18 17:49:54 --> Controller Class Initialized
INFO - 2020-08-18 17:49:54 --> Model Class Initialized
INFO - 2020-08-18 17:49:54 --> Model Class Initialized
DEBUG - 2020-08-18 17:49:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:49:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:49:54 --> Final output sent to browser
DEBUG - 2020-08-18 17:49:54 --> Total execution time: 0.0299
INFO - 2020-08-18 17:50:00 --> Config Class Initialized
INFO - 2020-08-18 17:50:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:50:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:50:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:50:00 --> URI Class Initialized
INFO - 2020-08-18 17:50:00 --> Router Class Initialized
INFO - 2020-08-18 17:50:00 --> Output Class Initialized
INFO - 2020-08-18 17:50:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:50:00 --> Input Class Initialized
INFO - 2020-08-18 17:50:00 --> Language Class Initialized
INFO - 2020-08-18 17:50:00 --> Loader Class Initialized
INFO - 2020-08-18 17:50:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:50:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:50:00 --> Email Class Initialized
INFO - 2020-08-18 17:50:00 --> Controller Class Initialized
INFO - 2020-08-18 17:50:00 --> Model Class Initialized
INFO - 2020-08-18 17:50:00 --> Model Class Initialized
DEBUG - 2020-08-18 17:50:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:50:00 --> Config Class Initialized
INFO - 2020-08-18 17:50:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:50:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:50:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:50:00 --> URI Class Initialized
INFO - 2020-08-18 17:50:00 --> Router Class Initialized
INFO - 2020-08-18 17:50:00 --> Output Class Initialized
INFO - 2020-08-18 17:50:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:50:00 --> Input Class Initialized
INFO - 2020-08-18 17:50:00 --> Language Class Initialized
INFO - 2020-08-18 17:50:00 --> Loader Class Initialized
INFO - 2020-08-18 17:50:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:50:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:50:00 --> Email Class Initialized
INFO - 2020-08-18 17:50:00 --> Controller Class Initialized
INFO - 2020-08-18 17:50:00 --> Model Class Initialized
INFO - 2020-08-18 17:50:00 --> Model Class Initialized
DEBUG - 2020-08-18 17:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:50:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:50:00 --> Model Class Initialized
INFO - 2020-08-18 17:50:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:50:00 --> Total execution time: 0.0262
INFO - 2020-08-18 17:50:00 --> Config Class Initialized
INFO - 2020-08-18 17:50:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:50:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:50:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:50:00 --> URI Class Initialized
INFO - 2020-08-18 17:50:00 --> Router Class Initialized
INFO - 2020-08-18 17:50:00 --> Output Class Initialized
INFO - 2020-08-18 17:50:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:50:00 --> Input Class Initialized
INFO - 2020-08-18 17:50:00 --> Language Class Initialized
INFO - 2020-08-18 17:50:00 --> Loader Class Initialized
INFO - 2020-08-18 17:50:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:50:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:50:00 --> Email Class Initialized
INFO - 2020-08-18 17:50:00 --> Controller Class Initialized
DEBUG - 2020-08-18 17:50:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:50:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:50:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 17:50:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:50:00 --> Total execution time: 0.0212
INFO - 2020-08-18 17:50:06 --> Config Class Initialized
INFO - 2020-08-18 17:50:06 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:50:06 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:50:06 --> Utf8 Class Initialized
INFO - 2020-08-18 17:50:06 --> URI Class Initialized
INFO - 2020-08-18 17:50:06 --> Router Class Initialized
INFO - 2020-08-18 17:50:06 --> Output Class Initialized
INFO - 2020-08-18 17:50:06 --> Security Class Initialized
DEBUG - 2020-08-18 17:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:50:06 --> Input Class Initialized
INFO - 2020-08-18 17:50:06 --> Language Class Initialized
INFO - 2020-08-18 17:50:06 --> Loader Class Initialized
INFO - 2020-08-18 17:50:06 --> Helper loaded: url_helper
INFO - 2020-08-18 17:50:06 --> Database Driver Class Initialized
INFO - 2020-08-18 17:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:50:06 --> Email Class Initialized
INFO - 2020-08-18 17:50:06 --> Controller Class Initialized
DEBUG - 2020-08-18 17:50:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:50:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:50:06 --> Model Class Initialized
INFO - 2020-08-18 17:50:06 --> Model Class Initialized
INFO - 2020-08-18 17:50:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:50:06 --> Final output sent to browser
DEBUG - 2020-08-18 17:50:06 --> Total execution time: 0.0276
INFO - 2020-08-18 17:50:12 --> Config Class Initialized
INFO - 2020-08-18 17:50:12 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:50:12 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:50:12 --> Utf8 Class Initialized
INFO - 2020-08-18 17:50:12 --> URI Class Initialized
INFO - 2020-08-18 17:50:12 --> Router Class Initialized
INFO - 2020-08-18 17:50:12 --> Output Class Initialized
INFO - 2020-08-18 17:50:12 --> Security Class Initialized
DEBUG - 2020-08-18 17:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:50:12 --> Input Class Initialized
INFO - 2020-08-18 17:50:12 --> Language Class Initialized
INFO - 2020-08-18 17:50:12 --> Loader Class Initialized
INFO - 2020-08-18 17:50:12 --> Helper loaded: url_helper
INFO - 2020-08-18 17:50:12 --> Database Driver Class Initialized
INFO - 2020-08-18 17:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:50:12 --> Email Class Initialized
INFO - 2020-08-18 17:50:12 --> Controller Class Initialized
DEBUG - 2020-08-18 17:50:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:50:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:50:12 --> Model Class Initialized
INFO - 2020-08-18 17:50:12 --> Model Class Initialized
INFO - 2020-08-18 17:50:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 17:50:13 --> Final output sent to browser
DEBUG - 2020-08-18 17:50:13 --> Total execution time: 0.3438
INFO - 2020-08-18 17:50:17 --> Config Class Initialized
INFO - 2020-08-18 17:50:17 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:50:17 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:50:17 --> Utf8 Class Initialized
INFO - 2020-08-18 17:50:17 --> URI Class Initialized
INFO - 2020-08-18 17:50:17 --> Router Class Initialized
INFO - 2020-08-18 17:50:17 --> Output Class Initialized
INFO - 2020-08-18 17:50:17 --> Security Class Initialized
DEBUG - 2020-08-18 17:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:50:17 --> Input Class Initialized
INFO - 2020-08-18 17:50:17 --> Language Class Initialized
INFO - 2020-08-18 17:50:17 --> Loader Class Initialized
INFO - 2020-08-18 17:50:17 --> Helper loaded: url_helper
INFO - 2020-08-18 17:50:17 --> Database Driver Class Initialized
INFO - 2020-08-18 17:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:50:17 --> Email Class Initialized
INFO - 2020-08-18 17:50:17 --> Controller Class Initialized
DEBUG - 2020-08-18 17:50:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:50:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:50:17 --> Model Class Initialized
INFO - 2020-08-18 17:50:17 --> Model Class Initialized
INFO - 2020-08-18 17:50:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:50:17 --> Final output sent to browser
DEBUG - 2020-08-18 17:50:17 --> Total execution time: 0.0303
INFO - 2020-08-18 17:53:24 --> Config Class Initialized
INFO - 2020-08-18 17:53:24 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:53:24 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:53:24 --> Utf8 Class Initialized
INFO - 2020-08-18 17:53:24 --> URI Class Initialized
INFO - 2020-08-18 17:53:24 --> Router Class Initialized
INFO - 2020-08-18 17:53:24 --> Output Class Initialized
INFO - 2020-08-18 17:53:24 --> Security Class Initialized
DEBUG - 2020-08-18 17:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:53:24 --> Input Class Initialized
INFO - 2020-08-18 17:53:24 --> Language Class Initialized
INFO - 2020-08-18 17:53:24 --> Loader Class Initialized
INFO - 2020-08-18 17:53:24 --> Helper loaded: url_helper
INFO - 2020-08-18 17:53:24 --> Database Driver Class Initialized
INFO - 2020-08-18 17:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:53:24 --> Email Class Initialized
INFO - 2020-08-18 17:53:24 --> Controller Class Initialized
DEBUG - 2020-08-18 17:53:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:53:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:53:24 --> Model Class Initialized
INFO - 2020-08-18 17:53:24 --> Model Class Initialized
INFO - 2020-08-18 17:53:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 17:53:24 --> Final output sent to browser
DEBUG - 2020-08-18 17:53:24 --> Total execution time: 0.0276
INFO - 2020-08-18 17:53:27 --> Config Class Initialized
INFO - 2020-08-18 17:53:27 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:53:27 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:53:27 --> Utf8 Class Initialized
INFO - 2020-08-18 17:53:27 --> URI Class Initialized
INFO - 2020-08-18 17:53:27 --> Router Class Initialized
INFO - 2020-08-18 17:53:27 --> Output Class Initialized
INFO - 2020-08-18 17:53:27 --> Security Class Initialized
DEBUG - 2020-08-18 17:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:53:27 --> Input Class Initialized
INFO - 2020-08-18 17:53:27 --> Language Class Initialized
INFO - 2020-08-18 17:53:27 --> Loader Class Initialized
INFO - 2020-08-18 17:53:27 --> Helper loaded: url_helper
INFO - 2020-08-18 17:53:27 --> Database Driver Class Initialized
INFO - 2020-08-18 17:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:53:27 --> Email Class Initialized
INFO - 2020-08-18 17:53:27 --> Controller Class Initialized
DEBUG - 2020-08-18 17:53:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:53:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:53:27 --> Model Class Initialized
INFO - 2020-08-18 17:53:27 --> Model Class Initialized
INFO - 2020-08-18 17:53:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:53:27 --> Final output sent to browser
DEBUG - 2020-08-18 17:53:27 --> Total execution time: 0.0271
INFO - 2020-08-18 17:54:28 --> Config Class Initialized
INFO - 2020-08-18 17:54:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:54:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:54:28 --> Utf8 Class Initialized
INFO - 2020-08-18 17:54:28 --> URI Class Initialized
INFO - 2020-08-18 17:54:28 --> Router Class Initialized
INFO - 2020-08-18 17:54:28 --> Output Class Initialized
INFO - 2020-08-18 17:54:28 --> Security Class Initialized
DEBUG - 2020-08-18 17:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:54:28 --> Input Class Initialized
INFO - 2020-08-18 17:54:28 --> Language Class Initialized
INFO - 2020-08-18 17:54:28 --> Loader Class Initialized
INFO - 2020-08-18 17:54:28 --> Helper loaded: url_helper
INFO - 2020-08-18 17:54:28 --> Database Driver Class Initialized
INFO - 2020-08-18 17:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:54:28 --> Email Class Initialized
INFO - 2020-08-18 17:54:28 --> Controller Class Initialized
DEBUG - 2020-08-18 17:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:54:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:54:28 --> Model Class Initialized
INFO - 2020-08-18 17:54:28 --> Model Class Initialized
INFO - 2020-08-18 17:54:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:54:28 --> Final output sent to browser
DEBUG - 2020-08-18 17:54:28 --> Total execution time: 0.0283
INFO - 2020-08-18 17:55:12 --> Config Class Initialized
INFO - 2020-08-18 17:55:12 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:55:12 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:55:12 --> Utf8 Class Initialized
INFO - 2020-08-18 17:55:12 --> URI Class Initialized
INFO - 2020-08-18 17:55:12 --> Router Class Initialized
INFO - 2020-08-18 17:55:12 --> Output Class Initialized
INFO - 2020-08-18 17:55:12 --> Security Class Initialized
DEBUG - 2020-08-18 17:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:55:12 --> Input Class Initialized
INFO - 2020-08-18 17:55:12 --> Language Class Initialized
INFO - 2020-08-18 17:55:12 --> Loader Class Initialized
INFO - 2020-08-18 17:55:12 --> Helper loaded: url_helper
INFO - 2020-08-18 17:55:12 --> Database Driver Class Initialized
INFO - 2020-08-18 17:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:55:12 --> Email Class Initialized
INFO - 2020-08-18 17:55:12 --> Controller Class Initialized
DEBUG - 2020-08-18 17:55:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:55:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:55:12 --> Model Class Initialized
INFO - 2020-08-18 17:55:12 --> Model Class Initialized
INFO - 2020-08-18 17:55:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:55:12 --> Final output sent to browser
DEBUG - 2020-08-18 17:55:12 --> Total execution time: 0.0268
INFO - 2020-08-18 17:55:34 --> Config Class Initialized
INFO - 2020-08-18 17:55:34 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:55:34 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:55:34 --> Utf8 Class Initialized
INFO - 2020-08-18 17:55:34 --> URI Class Initialized
INFO - 2020-08-18 17:55:34 --> Router Class Initialized
INFO - 2020-08-18 17:55:34 --> Output Class Initialized
INFO - 2020-08-18 17:55:34 --> Security Class Initialized
DEBUG - 2020-08-18 17:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:55:34 --> Input Class Initialized
INFO - 2020-08-18 17:55:34 --> Language Class Initialized
INFO - 2020-08-18 17:55:34 --> Loader Class Initialized
INFO - 2020-08-18 17:55:34 --> Helper loaded: url_helper
INFO - 2020-08-18 17:55:34 --> Database Driver Class Initialized
INFO - 2020-08-18 17:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:55:34 --> Email Class Initialized
INFO - 2020-08-18 17:55:34 --> Controller Class Initialized
DEBUG - 2020-08-18 17:55:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:55:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:55:34 --> Model Class Initialized
INFO - 2020-08-18 17:55:34 --> Model Class Initialized
INFO - 2020-08-18 17:55:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:55:34 --> Final output sent to browser
DEBUG - 2020-08-18 17:55:34 --> Total execution time: 0.0247
INFO - 2020-08-18 17:56:12 --> Config Class Initialized
INFO - 2020-08-18 17:56:12 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:56:12 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:56:12 --> Utf8 Class Initialized
INFO - 2020-08-18 17:56:12 --> URI Class Initialized
INFO - 2020-08-18 17:56:12 --> Router Class Initialized
INFO - 2020-08-18 17:56:12 --> Output Class Initialized
INFO - 2020-08-18 17:56:12 --> Security Class Initialized
DEBUG - 2020-08-18 17:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:56:12 --> Input Class Initialized
INFO - 2020-08-18 17:56:12 --> Language Class Initialized
INFO - 2020-08-18 17:56:12 --> Loader Class Initialized
INFO - 2020-08-18 17:56:12 --> Helper loaded: url_helper
INFO - 2020-08-18 17:56:12 --> Database Driver Class Initialized
INFO - 2020-08-18 17:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:56:12 --> Email Class Initialized
INFO - 2020-08-18 17:56:12 --> Controller Class Initialized
DEBUG - 2020-08-18 17:56:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:56:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:56:12 --> Model Class Initialized
INFO - 2020-08-18 17:56:12 --> Model Class Initialized
INFO - 2020-08-18 17:56:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:56:12 --> Final output sent to browser
DEBUG - 2020-08-18 17:56:12 --> Total execution time: 0.0261
INFO - 2020-08-18 17:56:53 --> Config Class Initialized
INFO - 2020-08-18 17:56:53 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:56:53 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:56:53 --> Utf8 Class Initialized
INFO - 2020-08-18 17:56:53 --> URI Class Initialized
INFO - 2020-08-18 17:56:53 --> Router Class Initialized
INFO - 2020-08-18 17:56:53 --> Output Class Initialized
INFO - 2020-08-18 17:56:53 --> Security Class Initialized
DEBUG - 2020-08-18 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:56:53 --> Input Class Initialized
INFO - 2020-08-18 17:56:53 --> Language Class Initialized
INFO - 2020-08-18 17:56:53 --> Loader Class Initialized
INFO - 2020-08-18 17:56:53 --> Helper loaded: url_helper
INFO - 2020-08-18 17:56:53 --> Database Driver Class Initialized
INFO - 2020-08-18 17:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:56:53 --> Email Class Initialized
INFO - 2020-08-18 17:56:53 --> Controller Class Initialized
DEBUG - 2020-08-18 17:56:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:56:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:56:53 --> Model Class Initialized
INFO - 2020-08-18 17:56:53 --> Model Class Initialized
INFO - 2020-08-18 17:56:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:56:53 --> Final output sent to browser
DEBUG - 2020-08-18 17:56:53 --> Total execution time: 0.0230
INFO - 2020-08-18 17:57:19 --> Config Class Initialized
INFO - 2020-08-18 17:57:19 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:57:19 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:57:19 --> Utf8 Class Initialized
INFO - 2020-08-18 17:57:19 --> URI Class Initialized
INFO - 2020-08-18 17:57:19 --> Router Class Initialized
INFO - 2020-08-18 17:57:19 --> Output Class Initialized
INFO - 2020-08-18 17:57:19 --> Security Class Initialized
DEBUG - 2020-08-18 17:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:57:19 --> Input Class Initialized
INFO - 2020-08-18 17:57:19 --> Language Class Initialized
INFO - 2020-08-18 17:57:19 --> Loader Class Initialized
INFO - 2020-08-18 17:57:19 --> Helper loaded: url_helper
INFO - 2020-08-18 17:57:19 --> Database Driver Class Initialized
INFO - 2020-08-18 17:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:57:19 --> Email Class Initialized
INFO - 2020-08-18 17:57:19 --> Controller Class Initialized
DEBUG - 2020-08-18 17:57:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:57:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:57:19 --> Model Class Initialized
INFO - 2020-08-18 17:57:19 --> Model Class Initialized
INFO - 2020-08-18 17:57:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:57:19 --> Final output sent to browser
DEBUG - 2020-08-18 17:57:19 --> Total execution time: 0.0255
INFO - 2020-08-18 17:57:57 --> Config Class Initialized
INFO - 2020-08-18 17:57:57 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:57:57 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:57:57 --> Utf8 Class Initialized
INFO - 2020-08-18 17:57:57 --> URI Class Initialized
DEBUG - 2020-08-18 17:57:57 --> No URI present. Default controller set.
INFO - 2020-08-18 17:57:57 --> Router Class Initialized
INFO - 2020-08-18 17:57:57 --> Output Class Initialized
INFO - 2020-08-18 17:57:57 --> Security Class Initialized
DEBUG - 2020-08-18 17:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:57:57 --> Input Class Initialized
INFO - 2020-08-18 17:57:57 --> Language Class Initialized
INFO - 2020-08-18 17:57:57 --> Loader Class Initialized
INFO - 2020-08-18 17:57:57 --> Helper loaded: url_helper
INFO - 2020-08-18 17:57:57 --> Database Driver Class Initialized
INFO - 2020-08-18 17:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:57:57 --> Email Class Initialized
INFO - 2020-08-18 17:57:57 --> Controller Class Initialized
INFO - 2020-08-18 17:57:57 --> Model Class Initialized
INFO - 2020-08-18 17:57:57 --> Model Class Initialized
DEBUG - 2020-08-18 17:57:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:57:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 17:57:57 --> Final output sent to browser
DEBUG - 2020-08-18 17:57:57 --> Total execution time: 0.0227
INFO - 2020-08-18 17:58:00 --> Config Class Initialized
INFO - 2020-08-18 17:58:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:58:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:58:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:58:00 --> URI Class Initialized
INFO - 2020-08-18 17:58:00 --> Router Class Initialized
INFO - 2020-08-18 17:58:00 --> Output Class Initialized
INFO - 2020-08-18 17:58:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:58:00 --> Input Class Initialized
INFO - 2020-08-18 17:58:00 --> Language Class Initialized
INFO - 2020-08-18 17:58:00 --> Loader Class Initialized
INFO - 2020-08-18 17:58:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:58:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:58:00 --> Email Class Initialized
INFO - 2020-08-18 17:58:00 --> Controller Class Initialized
INFO - 2020-08-18 17:58:00 --> Model Class Initialized
INFO - 2020-08-18 17:58:00 --> Model Class Initialized
DEBUG - 2020-08-18 17:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:58:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:58:00 --> Model Class Initialized
INFO - 2020-08-18 17:58:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:58:00 --> Total execution time: 0.0246
INFO - 2020-08-18 17:58:00 --> Config Class Initialized
INFO - 2020-08-18 17:58:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:58:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:58:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:58:00 --> URI Class Initialized
INFO - 2020-08-18 17:58:00 --> Router Class Initialized
INFO - 2020-08-18 17:58:00 --> Output Class Initialized
INFO - 2020-08-18 17:58:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:58:00 --> Input Class Initialized
INFO - 2020-08-18 17:58:00 --> Language Class Initialized
INFO - 2020-08-18 17:58:00 --> Loader Class Initialized
INFO - 2020-08-18 17:58:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:58:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:58:00 --> Email Class Initialized
INFO - 2020-08-18 17:58:00 --> Controller Class Initialized
INFO - 2020-08-18 17:58:00 --> Model Class Initialized
INFO - 2020-08-18 17:58:00 --> Model Class Initialized
DEBUG - 2020-08-18 17:58:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:58:00 --> Config Class Initialized
INFO - 2020-08-18 17:58:00 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:58:00 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:58:00 --> Utf8 Class Initialized
INFO - 2020-08-18 17:58:00 --> URI Class Initialized
INFO - 2020-08-18 17:58:00 --> Router Class Initialized
INFO - 2020-08-18 17:58:00 --> Output Class Initialized
INFO - 2020-08-18 17:58:00 --> Security Class Initialized
DEBUG - 2020-08-18 17:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:58:00 --> Input Class Initialized
INFO - 2020-08-18 17:58:00 --> Language Class Initialized
INFO - 2020-08-18 17:58:00 --> Loader Class Initialized
INFO - 2020-08-18 17:58:00 --> Helper loaded: url_helper
INFO - 2020-08-18 17:58:00 --> Database Driver Class Initialized
INFO - 2020-08-18 17:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:58:00 --> Email Class Initialized
INFO - 2020-08-18 17:58:00 --> Controller Class Initialized
DEBUG - 2020-08-18 17:58:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:58:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:58:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 17:58:00 --> Final output sent to browser
DEBUG - 2020-08-18 17:58:00 --> Total execution time: 0.0220
INFO - 2020-08-18 17:58:04 --> Config Class Initialized
INFO - 2020-08-18 17:58:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:58:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:58:04 --> Utf8 Class Initialized
INFO - 2020-08-18 17:58:04 --> URI Class Initialized
INFO - 2020-08-18 17:58:04 --> Router Class Initialized
INFO - 2020-08-18 17:58:04 --> Output Class Initialized
INFO - 2020-08-18 17:58:04 --> Security Class Initialized
DEBUG - 2020-08-18 17:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:58:04 --> Input Class Initialized
INFO - 2020-08-18 17:58:04 --> Language Class Initialized
INFO - 2020-08-18 17:58:04 --> Loader Class Initialized
INFO - 2020-08-18 17:58:04 --> Helper loaded: url_helper
INFO - 2020-08-18 17:58:04 --> Database Driver Class Initialized
INFO - 2020-08-18 17:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:58:04 --> Email Class Initialized
INFO - 2020-08-18 17:58:04 --> Controller Class Initialized
DEBUG - 2020-08-18 17:58:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:58:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:58:04 --> Model Class Initialized
INFO - 2020-08-18 17:58:04 --> Model Class Initialized
INFO - 2020-08-18 17:58:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:58:04 --> Final output sent to browser
DEBUG - 2020-08-18 17:58:04 --> Total execution time: 0.0227
INFO - 2020-08-18 17:58:27 --> Config Class Initialized
INFO - 2020-08-18 17:58:27 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:58:27 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:58:27 --> Utf8 Class Initialized
INFO - 2020-08-18 17:58:27 --> URI Class Initialized
INFO - 2020-08-18 17:58:27 --> Router Class Initialized
INFO - 2020-08-18 17:58:27 --> Output Class Initialized
INFO - 2020-08-18 17:58:27 --> Security Class Initialized
DEBUG - 2020-08-18 17:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:58:27 --> Input Class Initialized
INFO - 2020-08-18 17:58:27 --> Language Class Initialized
INFO - 2020-08-18 17:58:27 --> Loader Class Initialized
INFO - 2020-08-18 17:58:27 --> Helper loaded: url_helper
INFO - 2020-08-18 17:58:27 --> Database Driver Class Initialized
INFO - 2020-08-18 17:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:58:27 --> Email Class Initialized
INFO - 2020-08-18 17:58:27 --> Controller Class Initialized
DEBUG - 2020-08-18 17:58:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:58:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:58:27 --> Model Class Initialized
INFO - 2020-08-18 17:58:27 --> Model Class Initialized
INFO - 2020-08-18 17:58:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 17:58:27 --> Final output sent to browser
DEBUG - 2020-08-18 17:58:27 --> Total execution time: 0.0265
INFO - 2020-08-18 17:59:10 --> Config Class Initialized
INFO - 2020-08-18 17:59:10 --> Hooks Class Initialized
DEBUG - 2020-08-18 17:59:10 --> UTF-8 Support Enabled
INFO - 2020-08-18 17:59:10 --> Utf8 Class Initialized
INFO - 2020-08-18 17:59:10 --> URI Class Initialized
INFO - 2020-08-18 17:59:10 --> Router Class Initialized
INFO - 2020-08-18 17:59:10 --> Output Class Initialized
INFO - 2020-08-18 17:59:10 --> Security Class Initialized
DEBUG - 2020-08-18 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 17:59:10 --> Input Class Initialized
INFO - 2020-08-18 17:59:10 --> Language Class Initialized
INFO - 2020-08-18 17:59:10 --> Loader Class Initialized
INFO - 2020-08-18 17:59:10 --> Helper loaded: url_helper
INFO - 2020-08-18 17:59:10 --> Database Driver Class Initialized
INFO - 2020-08-18 17:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 17:59:10 --> Email Class Initialized
INFO - 2020-08-18 17:59:10 --> Controller Class Initialized
DEBUG - 2020-08-18 17:59:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 17:59:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 17:59:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 17:59:10 --> Final output sent to browser
DEBUG - 2020-08-18 17:59:10 --> Total execution time: 0.0334
INFO - 2020-08-18 18:28:25 --> Config Class Initialized
INFO - 2020-08-18 18:28:25 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:28:25 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:28:25 --> Utf8 Class Initialized
INFO - 2020-08-18 18:28:25 --> URI Class Initialized
INFO - 2020-08-18 18:28:25 --> Router Class Initialized
INFO - 2020-08-18 18:28:25 --> Output Class Initialized
INFO - 2020-08-18 18:28:25 --> Security Class Initialized
DEBUG - 2020-08-18 18:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:28:25 --> Input Class Initialized
INFO - 2020-08-18 18:28:25 --> Language Class Initialized
INFO - 2020-08-18 18:28:25 --> Loader Class Initialized
INFO - 2020-08-18 18:28:25 --> Helper loaded: url_helper
INFO - 2020-08-18 18:28:25 --> Database Driver Class Initialized
INFO - 2020-08-18 18:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:28:25 --> Email Class Initialized
INFO - 2020-08-18 18:28:25 --> Controller Class Initialized
DEBUG - 2020-08-18 18:28:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:28:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:28:25 --> Model Class Initialized
INFO - 2020-08-18 18:28:25 --> Model Class Initialized
INFO - 2020-08-18 18:28:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:28:25 --> Final output sent to browser
DEBUG - 2020-08-18 18:28:25 --> Total execution time: 0.0243
INFO - 2020-08-18 18:28:32 --> Config Class Initialized
INFO - 2020-08-18 18:28:32 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:28:32 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:28:32 --> Utf8 Class Initialized
INFO - 2020-08-18 18:28:32 --> URI Class Initialized
INFO - 2020-08-18 18:28:32 --> Router Class Initialized
INFO - 2020-08-18 18:28:32 --> Output Class Initialized
INFO - 2020-08-18 18:28:32 --> Security Class Initialized
DEBUG - 2020-08-18 18:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:28:32 --> Input Class Initialized
INFO - 2020-08-18 18:28:32 --> Language Class Initialized
INFO - 2020-08-18 18:28:32 --> Loader Class Initialized
INFO - 2020-08-18 18:28:32 --> Helper loaded: url_helper
INFO - 2020-08-18 18:28:32 --> Database Driver Class Initialized
INFO - 2020-08-18 18:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:28:32 --> Email Class Initialized
INFO - 2020-08-18 18:28:32 --> Controller Class Initialized
DEBUG - 2020-08-18 18:28:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:28:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:28:32 --> Model Class Initialized
INFO - 2020-08-18 18:28:32 --> Model Class Initialized
INFO - 2020-08-18 18:28:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-18 18:28:32 --> Final output sent to browser
DEBUG - 2020-08-18 18:28:32 --> Total execution time: 0.0230
INFO - 2020-08-18 18:28:37 --> Config Class Initialized
INFO - 2020-08-18 18:28:37 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:28:37 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:28:37 --> Utf8 Class Initialized
INFO - 2020-08-18 18:28:37 --> URI Class Initialized
INFO - 2020-08-18 18:28:37 --> Router Class Initialized
INFO - 2020-08-18 18:28:37 --> Output Class Initialized
INFO - 2020-08-18 18:28:37 --> Security Class Initialized
DEBUG - 2020-08-18 18:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:28:37 --> Input Class Initialized
INFO - 2020-08-18 18:28:37 --> Language Class Initialized
INFO - 2020-08-18 18:28:37 --> Loader Class Initialized
INFO - 2020-08-18 18:28:37 --> Helper loaded: url_helper
INFO - 2020-08-18 18:28:37 --> Database Driver Class Initialized
INFO - 2020-08-18 18:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:28:37 --> Email Class Initialized
INFO - 2020-08-18 18:28:37 --> Controller Class Initialized
DEBUG - 2020-08-18 18:28:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:28:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:28:37 --> Model Class Initialized
INFO - 2020-08-18 18:28:37 --> Model Class Initialized
INFO - 2020-08-18 18:28:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:28:37 --> Final output sent to browser
DEBUG - 2020-08-18 18:28:37 --> Total execution time: 0.0222
INFO - 2020-08-18 18:28:41 --> Config Class Initialized
INFO - 2020-08-18 18:28:41 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:28:41 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:28:41 --> Utf8 Class Initialized
INFO - 2020-08-18 18:28:41 --> URI Class Initialized
INFO - 2020-08-18 18:28:41 --> Router Class Initialized
INFO - 2020-08-18 18:28:41 --> Output Class Initialized
INFO - 2020-08-18 18:28:41 --> Security Class Initialized
DEBUG - 2020-08-18 18:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:28:41 --> Input Class Initialized
INFO - 2020-08-18 18:28:41 --> Language Class Initialized
INFO - 2020-08-18 18:28:41 --> Loader Class Initialized
INFO - 2020-08-18 18:28:41 --> Helper loaded: url_helper
INFO - 2020-08-18 18:28:41 --> Database Driver Class Initialized
INFO - 2020-08-18 18:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:28:41 --> Email Class Initialized
INFO - 2020-08-18 18:28:41 --> Controller Class Initialized
DEBUG - 2020-08-18 18:28:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:28:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:28:41 --> Model Class Initialized
INFO - 2020-08-18 18:28:41 --> Model Class Initialized
INFO - 2020-08-18 18:28:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:28:41 --> Final output sent to browser
DEBUG - 2020-08-18 18:28:41 --> Total execution time: 0.0275
INFO - 2020-08-18 18:28:51 --> Config Class Initialized
INFO - 2020-08-18 18:28:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:28:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:28:51 --> Utf8 Class Initialized
INFO - 2020-08-18 18:28:51 --> URI Class Initialized
INFO - 2020-08-18 18:28:51 --> Router Class Initialized
INFO - 2020-08-18 18:28:51 --> Output Class Initialized
INFO - 2020-08-18 18:28:51 --> Security Class Initialized
DEBUG - 2020-08-18 18:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:28:51 --> Input Class Initialized
INFO - 2020-08-18 18:28:51 --> Language Class Initialized
INFO - 2020-08-18 18:28:51 --> Loader Class Initialized
INFO - 2020-08-18 18:28:51 --> Helper loaded: url_helper
INFO - 2020-08-18 18:28:51 --> Database Driver Class Initialized
INFO - 2020-08-18 18:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:28:51 --> Email Class Initialized
INFO - 2020-08-18 18:28:51 --> Controller Class Initialized
DEBUG - 2020-08-18 18:28:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:28:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:28:51 --> Model Class Initialized
INFO - 2020-08-18 18:28:51 --> Model Class Initialized
INFO - 2020-08-18 18:28:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:28:51 --> Final output sent to browser
DEBUG - 2020-08-18 18:28:51 --> Total execution time: 0.0289
INFO - 2020-08-18 18:32:03 --> Config Class Initialized
INFO - 2020-08-18 18:32:03 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:03 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:03 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:03 --> URI Class Initialized
INFO - 2020-08-18 18:32:03 --> Router Class Initialized
INFO - 2020-08-18 18:32:03 --> Output Class Initialized
INFO - 2020-08-18 18:32:03 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:03 --> Input Class Initialized
INFO - 2020-08-18 18:32:03 --> Language Class Initialized
INFO - 2020-08-18 18:32:03 --> Loader Class Initialized
INFO - 2020-08-18 18:32:03 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:03 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:03 --> Email Class Initialized
INFO - 2020-08-18 18:32:03 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:03 --> Model Class Initialized
INFO - 2020-08-18 18:32:03 --> Model Class Initialized
INFO - 2020-08-18 18:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:32:03 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:03 --> Total execution time: 0.0230
INFO - 2020-08-18 18:32:11 --> Config Class Initialized
INFO - 2020-08-18 18:32:11 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:11 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:11 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:11 --> URI Class Initialized
INFO - 2020-08-18 18:32:11 --> Router Class Initialized
INFO - 2020-08-18 18:32:11 --> Output Class Initialized
INFO - 2020-08-18 18:32:11 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:11 --> Input Class Initialized
INFO - 2020-08-18 18:32:11 --> Language Class Initialized
INFO - 2020-08-18 18:32:11 --> Loader Class Initialized
INFO - 2020-08-18 18:32:11 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:11 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:11 --> Email Class Initialized
INFO - 2020-08-18 18:32:11 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:11 --> Model Class Initialized
INFO - 2020-08-18 18:32:11 --> Model Class Initialized
INFO - 2020-08-18 18:32:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:32:11 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:11 --> Total execution time: 0.0254
INFO - 2020-08-18 18:32:20 --> Config Class Initialized
INFO - 2020-08-18 18:32:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:20 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:20 --> URI Class Initialized
INFO - 2020-08-18 18:32:20 --> Router Class Initialized
INFO - 2020-08-18 18:32:20 --> Output Class Initialized
INFO - 2020-08-18 18:32:20 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:20 --> Input Class Initialized
INFO - 2020-08-18 18:32:20 --> Language Class Initialized
INFO - 2020-08-18 18:32:20 --> Loader Class Initialized
INFO - 2020-08-18 18:32:20 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:20 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:20 --> Email Class Initialized
INFO - 2020-08-18 18:32:20 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:20 --> Model Class Initialized
INFO - 2020-08-18 18:32:20 --> Model Class Initialized
INFO - 2020-08-18 18:32:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-18 18:32:20 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:20 --> Total execution time: 0.0273
INFO - 2020-08-18 18:32:25 --> Config Class Initialized
INFO - 2020-08-18 18:32:25 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:25 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:25 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:25 --> URI Class Initialized
INFO - 2020-08-18 18:32:25 --> Router Class Initialized
INFO - 2020-08-18 18:32:25 --> Output Class Initialized
INFO - 2020-08-18 18:32:25 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:25 --> Input Class Initialized
INFO - 2020-08-18 18:32:25 --> Language Class Initialized
INFO - 2020-08-18 18:32:25 --> Loader Class Initialized
INFO - 2020-08-18 18:32:25 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:25 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:25 --> Email Class Initialized
INFO - 2020-08-18 18:32:25 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:25 --> Model Class Initialized
INFO - 2020-08-18 18:32:25 --> Model Class Initialized
INFO - 2020-08-18 18:32:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:32:25 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:25 --> Total execution time: 0.0241
INFO - 2020-08-18 18:32:30 --> Config Class Initialized
INFO - 2020-08-18 18:32:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:30 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:30 --> URI Class Initialized
INFO - 2020-08-18 18:32:30 --> Router Class Initialized
INFO - 2020-08-18 18:32:30 --> Output Class Initialized
INFO - 2020-08-18 18:32:30 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:30 --> Input Class Initialized
INFO - 2020-08-18 18:32:30 --> Language Class Initialized
INFO - 2020-08-18 18:32:30 --> Loader Class Initialized
INFO - 2020-08-18 18:32:30 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:30 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:30 --> Email Class Initialized
INFO - 2020-08-18 18:32:30 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 18:32:30 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:30 --> Total execution time: 0.0236
INFO - 2020-08-18 18:32:50 --> Config Class Initialized
INFO - 2020-08-18 18:32:50 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:50 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:50 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:50 --> URI Class Initialized
INFO - 2020-08-18 18:32:50 --> Router Class Initialized
INFO - 2020-08-18 18:32:50 --> Output Class Initialized
INFO - 2020-08-18 18:32:50 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:50 --> Input Class Initialized
INFO - 2020-08-18 18:32:50 --> Language Class Initialized
INFO - 2020-08-18 18:32:50 --> Loader Class Initialized
INFO - 2020-08-18 18:32:50 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:50 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:50 --> Email Class Initialized
INFO - 2020-08-18 18:32:50 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:50 --> Model Class Initialized
INFO - 2020-08-18 18:32:50 --> Model Class Initialized
INFO - 2020-08-18 18:32:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 18:32:50 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:50 --> Total execution time: 0.0212
INFO - 2020-08-18 18:32:52 --> Config Class Initialized
INFO - 2020-08-18 18:32:52 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:52 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:52 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:52 --> URI Class Initialized
INFO - 2020-08-18 18:32:52 --> Router Class Initialized
INFO - 2020-08-18 18:32:52 --> Output Class Initialized
INFO - 2020-08-18 18:32:52 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:52 --> Input Class Initialized
INFO - 2020-08-18 18:32:52 --> Language Class Initialized
INFO - 2020-08-18 18:32:52 --> Loader Class Initialized
INFO - 2020-08-18 18:32:52 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:52 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:52 --> Email Class Initialized
INFO - 2020-08-18 18:32:52 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 18:32:52 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:52 --> Total execution time: 0.0193
INFO - 2020-08-18 18:32:58 --> Config Class Initialized
INFO - 2020-08-18 18:32:58 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:32:58 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:32:58 --> Utf8 Class Initialized
INFO - 2020-08-18 18:32:58 --> URI Class Initialized
INFO - 2020-08-18 18:32:58 --> Router Class Initialized
INFO - 2020-08-18 18:32:58 --> Output Class Initialized
INFO - 2020-08-18 18:32:58 --> Security Class Initialized
DEBUG - 2020-08-18 18:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:32:58 --> Input Class Initialized
INFO - 2020-08-18 18:32:58 --> Language Class Initialized
INFO - 2020-08-18 18:32:58 --> Loader Class Initialized
INFO - 2020-08-18 18:32:58 --> Helper loaded: url_helper
INFO - 2020-08-18 18:32:58 --> Database Driver Class Initialized
INFO - 2020-08-18 18:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:32:58 --> Email Class Initialized
INFO - 2020-08-18 18:32:58 --> Controller Class Initialized
DEBUG - 2020-08-18 18:32:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:32:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:32:58 --> Model Class Initialized
INFO - 2020-08-18 18:32:58 --> Model Class Initialized
INFO - 2020-08-18 18:32:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:32:58 --> Final output sent to browser
DEBUG - 2020-08-18 18:32:58 --> Total execution time: 0.0226
INFO - 2020-08-18 18:33:01 --> Config Class Initialized
INFO - 2020-08-18 18:33:01 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:33:01 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:33:01 --> Utf8 Class Initialized
INFO - 2020-08-18 18:33:01 --> URI Class Initialized
INFO - 2020-08-18 18:33:01 --> Router Class Initialized
INFO - 2020-08-18 18:33:01 --> Output Class Initialized
INFO - 2020-08-18 18:33:01 --> Security Class Initialized
DEBUG - 2020-08-18 18:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:33:01 --> Input Class Initialized
INFO - 2020-08-18 18:33:01 --> Language Class Initialized
INFO - 2020-08-18 18:33:01 --> Loader Class Initialized
INFO - 2020-08-18 18:33:01 --> Helper loaded: url_helper
INFO - 2020-08-18 18:33:01 --> Database Driver Class Initialized
INFO - 2020-08-18 18:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:33:01 --> Email Class Initialized
INFO - 2020-08-18 18:33:01 --> Controller Class Initialized
DEBUG - 2020-08-18 18:33:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:33:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:33:01 --> Model Class Initialized
INFO - 2020-08-18 18:33:01 --> Model Class Initialized
INFO - 2020-08-18 18:33:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:33:01 --> Final output sent to browser
DEBUG - 2020-08-18 18:33:01 --> Total execution time: 0.0258
INFO - 2020-08-18 18:33:04 --> Config Class Initialized
INFO - 2020-08-18 18:33:04 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:33:04 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:33:04 --> Utf8 Class Initialized
INFO - 2020-08-18 18:33:04 --> URI Class Initialized
INFO - 2020-08-18 18:33:04 --> Router Class Initialized
INFO - 2020-08-18 18:33:04 --> Output Class Initialized
INFO - 2020-08-18 18:33:04 --> Security Class Initialized
DEBUG - 2020-08-18 18:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:33:04 --> Input Class Initialized
INFO - 2020-08-18 18:33:04 --> Language Class Initialized
INFO - 2020-08-18 18:33:04 --> Loader Class Initialized
INFO - 2020-08-18 18:33:04 --> Helper loaded: url_helper
INFO - 2020-08-18 18:33:04 --> Database Driver Class Initialized
INFO - 2020-08-18 18:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:33:04 --> Email Class Initialized
INFO - 2020-08-18 18:33:04 --> Controller Class Initialized
DEBUG - 2020-08-18 18:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:33:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:33:04 --> Model Class Initialized
INFO - 2020-08-18 18:33:04 --> Model Class Initialized
INFO - 2020-08-18 18:33:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:33:04 --> Final output sent to browser
DEBUG - 2020-08-18 18:33:04 --> Total execution time: 0.0273
INFO - 2020-08-18 18:34:30 --> Config Class Initialized
INFO - 2020-08-18 18:34:30 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:34:30 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:34:30 --> Utf8 Class Initialized
INFO - 2020-08-18 18:34:30 --> URI Class Initialized
INFO - 2020-08-18 18:34:30 --> Router Class Initialized
INFO - 2020-08-18 18:34:30 --> Output Class Initialized
INFO - 2020-08-18 18:34:30 --> Security Class Initialized
DEBUG - 2020-08-18 18:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:34:30 --> Input Class Initialized
INFO - 2020-08-18 18:34:30 --> Language Class Initialized
INFO - 2020-08-18 18:34:30 --> Loader Class Initialized
INFO - 2020-08-18 18:34:30 --> Helper loaded: url_helper
INFO - 2020-08-18 18:34:30 --> Database Driver Class Initialized
INFO - 2020-08-18 18:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:34:30 --> Email Class Initialized
INFO - 2020-08-18 18:34:30 --> Controller Class Initialized
DEBUG - 2020-08-18 18:34:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:34:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:34:30 --> Model Class Initialized
INFO - 2020-08-18 18:34:30 --> Model Class Initialized
INFO - 2020-08-18 18:34:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:34:30 --> Final output sent to browser
DEBUG - 2020-08-18 18:34:30 --> Total execution time: 0.0227
INFO - 2020-08-18 18:34:33 --> Config Class Initialized
INFO - 2020-08-18 18:34:33 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:34:33 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:34:33 --> Utf8 Class Initialized
INFO - 2020-08-18 18:34:33 --> URI Class Initialized
INFO - 2020-08-18 18:34:33 --> Router Class Initialized
INFO - 2020-08-18 18:34:33 --> Output Class Initialized
INFO - 2020-08-18 18:34:33 --> Security Class Initialized
DEBUG - 2020-08-18 18:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:34:33 --> Input Class Initialized
INFO - 2020-08-18 18:34:33 --> Language Class Initialized
INFO - 2020-08-18 18:34:33 --> Loader Class Initialized
INFO - 2020-08-18 18:34:33 --> Helper loaded: url_helper
INFO - 2020-08-18 18:34:33 --> Database Driver Class Initialized
INFO - 2020-08-18 18:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:34:33 --> Email Class Initialized
INFO - 2020-08-18 18:34:33 --> Controller Class Initialized
DEBUG - 2020-08-18 18:34:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:34:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:34:33 --> Model Class Initialized
INFO - 2020-08-18 18:34:33 --> Model Class Initialized
INFO - 2020-08-18 18:34:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:34:33 --> Final output sent to browser
DEBUG - 2020-08-18 18:34:33 --> Total execution time: 0.0261
INFO - 2020-08-18 18:35:08 --> Config Class Initialized
INFO - 2020-08-18 18:35:08 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:08 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:08 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:08 --> URI Class Initialized
DEBUG - 2020-08-18 18:35:08 --> No URI present. Default controller set.
INFO - 2020-08-18 18:35:08 --> Router Class Initialized
INFO - 2020-08-18 18:35:08 --> Output Class Initialized
INFO - 2020-08-18 18:35:08 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:08 --> Input Class Initialized
INFO - 2020-08-18 18:35:08 --> Language Class Initialized
INFO - 2020-08-18 18:35:08 --> Loader Class Initialized
INFO - 2020-08-18 18:35:08 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:08 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:09 --> Email Class Initialized
INFO - 2020-08-18 18:35:09 --> Controller Class Initialized
INFO - 2020-08-18 18:35:09 --> Model Class Initialized
INFO - 2020-08-18 18:35:09 --> Model Class Initialized
DEBUG - 2020-08-18 18:35:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 18:35:09 --> Final output sent to browser
DEBUG - 2020-08-18 18:35:09 --> Total execution time: 0.0211
INFO - 2020-08-18 18:35:24 --> Config Class Initialized
INFO - 2020-08-18 18:35:24 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:24 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:24 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:24 --> URI Class Initialized
INFO - 2020-08-18 18:35:24 --> Router Class Initialized
INFO - 2020-08-18 18:35:24 --> Output Class Initialized
INFO - 2020-08-18 18:35:24 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:24 --> Input Class Initialized
INFO - 2020-08-18 18:35:24 --> Language Class Initialized
INFO - 2020-08-18 18:35:24 --> Loader Class Initialized
INFO - 2020-08-18 18:35:24 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:24 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:24 --> Email Class Initialized
INFO - 2020-08-18 18:35:24 --> Controller Class Initialized
INFO - 2020-08-18 18:35:24 --> Model Class Initialized
INFO - 2020-08-18 18:35:24 --> Model Class Initialized
DEBUG - 2020-08-18 18:35:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:35:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-08-18 18:35:24 --> Final output sent to browser
DEBUG - 2020-08-18 18:35:24 --> Total execution time: 0.0406
INFO - 2020-08-18 18:35:28 --> Config Class Initialized
INFO - 2020-08-18 18:35:28 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:28 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:28 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:28 --> URI Class Initialized
DEBUG - 2020-08-18 18:35:28 --> No URI present. Default controller set.
INFO - 2020-08-18 18:35:28 --> Router Class Initialized
INFO - 2020-08-18 18:35:28 --> Output Class Initialized
INFO - 2020-08-18 18:35:28 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:28 --> Input Class Initialized
INFO - 2020-08-18 18:35:28 --> Language Class Initialized
INFO - 2020-08-18 18:35:28 --> Loader Class Initialized
INFO - 2020-08-18 18:35:28 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:28 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:28 --> Email Class Initialized
INFO - 2020-08-18 18:35:28 --> Controller Class Initialized
INFO - 2020-08-18 18:35:28 --> Model Class Initialized
INFO - 2020-08-18 18:35:28 --> Model Class Initialized
DEBUG - 2020-08-18 18:35:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 18:35:28 --> Final output sent to browser
DEBUG - 2020-08-18 18:35:28 --> Total execution time: 0.0237
INFO - 2020-08-18 18:35:51 --> Config Class Initialized
INFO - 2020-08-18 18:35:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:51 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:51 --> URI Class Initialized
INFO - 2020-08-18 18:35:51 --> Router Class Initialized
INFO - 2020-08-18 18:35:51 --> Output Class Initialized
INFO - 2020-08-18 18:35:51 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:51 --> Input Class Initialized
INFO - 2020-08-18 18:35:51 --> Language Class Initialized
INFO - 2020-08-18 18:35:51 --> Loader Class Initialized
INFO - 2020-08-18 18:35:51 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:51 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:51 --> Email Class Initialized
INFO - 2020-08-18 18:35:51 --> Controller Class Initialized
INFO - 2020-08-18 18:35:51 --> Model Class Initialized
INFO - 2020-08-18 18:35:51 --> Model Class Initialized
DEBUG - 2020-08-18 18:35:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:51 --> Config Class Initialized
INFO - 2020-08-18 18:35:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:51 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:51 --> URI Class Initialized
INFO - 2020-08-18 18:35:51 --> Router Class Initialized
INFO - 2020-08-18 18:35:51 --> Output Class Initialized
INFO - 2020-08-18 18:35:51 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:51 --> Input Class Initialized
INFO - 2020-08-18 18:35:51 --> Language Class Initialized
INFO - 2020-08-18 18:35:51 --> Loader Class Initialized
INFO - 2020-08-18 18:35:51 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:51 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:51 --> Email Class Initialized
INFO - 2020-08-18 18:35:51 --> Controller Class Initialized
INFO - 2020-08-18 18:35:51 --> Model Class Initialized
INFO - 2020-08-18 18:35:51 --> Model Class Initialized
DEBUG - 2020-08-18 18:35:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:35:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:51 --> Model Class Initialized
INFO - 2020-08-18 18:35:51 --> Final output sent to browser
DEBUG - 2020-08-18 18:35:51 --> Total execution time: 0.0268
INFO - 2020-08-18 18:35:52 --> Config Class Initialized
INFO - 2020-08-18 18:35:52 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:52 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:52 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:52 --> URI Class Initialized
INFO - 2020-08-18 18:35:52 --> Router Class Initialized
INFO - 2020-08-18 18:35:52 --> Output Class Initialized
INFO - 2020-08-18 18:35:52 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:52 --> Input Class Initialized
INFO - 2020-08-18 18:35:52 --> Language Class Initialized
INFO - 2020-08-18 18:35:52 --> Loader Class Initialized
INFO - 2020-08-18 18:35:52 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:52 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:52 --> Email Class Initialized
INFO - 2020-08-18 18:35:52 --> Controller Class Initialized
DEBUG - 2020-08-18 18:35:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:35:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 18:35:52 --> Final output sent to browser
DEBUG - 2020-08-18 18:35:52 --> Total execution time: 0.0196
INFO - 2020-08-18 18:35:55 --> Config Class Initialized
INFO - 2020-08-18 18:35:55 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:35:55 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:35:55 --> Utf8 Class Initialized
INFO - 2020-08-18 18:35:55 --> URI Class Initialized
INFO - 2020-08-18 18:35:55 --> Router Class Initialized
INFO - 2020-08-18 18:35:55 --> Output Class Initialized
INFO - 2020-08-18 18:35:55 --> Security Class Initialized
DEBUG - 2020-08-18 18:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:35:55 --> Input Class Initialized
INFO - 2020-08-18 18:35:55 --> Language Class Initialized
INFO - 2020-08-18 18:35:55 --> Loader Class Initialized
INFO - 2020-08-18 18:35:55 --> Helper loaded: url_helper
INFO - 2020-08-18 18:35:55 --> Database Driver Class Initialized
INFO - 2020-08-18 18:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:35:55 --> Email Class Initialized
INFO - 2020-08-18 18:35:55 --> Controller Class Initialized
DEBUG - 2020-08-18 18:35:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:35:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:35:55 --> Model Class Initialized
INFO - 2020-08-18 18:35:55 --> Model Class Initialized
INFO - 2020-08-18 18:35:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:35:55 --> Final output sent to browser
DEBUG - 2020-08-18 18:35:55 --> Total execution time: 0.0293
INFO - 2020-08-18 18:36:02 --> Config Class Initialized
INFO - 2020-08-18 18:36:02 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:02 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:02 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:02 --> URI Class Initialized
INFO - 2020-08-18 18:36:02 --> Router Class Initialized
INFO - 2020-08-18 18:36:02 --> Output Class Initialized
INFO - 2020-08-18 18:36:02 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:02 --> Input Class Initialized
INFO - 2020-08-18 18:36:02 --> Language Class Initialized
INFO - 2020-08-18 18:36:02 --> Loader Class Initialized
INFO - 2020-08-18 18:36:02 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:02 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:02 --> Email Class Initialized
INFO - 2020-08-18 18:36:02 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:02 --> Model Class Initialized
INFO - 2020-08-18 18:36:02 --> Model Class Initialized
INFO - 2020-08-18 18:36:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-08-18 18:36:02 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:02 --> Total execution time: 0.0339
INFO - 2020-08-18 18:36:19 --> Config Class Initialized
INFO - 2020-08-18 18:36:19 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:19 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:19 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:19 --> URI Class Initialized
INFO - 2020-08-18 18:36:19 --> Router Class Initialized
INFO - 2020-08-18 18:36:19 --> Output Class Initialized
INFO - 2020-08-18 18:36:19 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:19 --> Input Class Initialized
INFO - 2020-08-18 18:36:19 --> Language Class Initialized
INFO - 2020-08-18 18:36:19 --> Loader Class Initialized
INFO - 2020-08-18 18:36:19 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:19 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:19 --> Email Class Initialized
INFO - 2020-08-18 18:36:19 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:19 --> Model Class Initialized
INFO - 2020-08-18 18:36:19 --> Model Class Initialized
INFO - 2020-08-18 18:36:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:36:19 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:19 --> Total execution time: 0.0272
INFO - 2020-08-18 18:36:22 --> Config Class Initialized
INFO - 2020-08-18 18:36:22 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:22 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:22 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:22 --> URI Class Initialized
INFO - 2020-08-18 18:36:22 --> Router Class Initialized
INFO - 2020-08-18 18:36:22 --> Output Class Initialized
INFO - 2020-08-18 18:36:22 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:22 --> Input Class Initialized
INFO - 2020-08-18 18:36:22 --> Language Class Initialized
INFO - 2020-08-18 18:36:22 --> Loader Class Initialized
INFO - 2020-08-18 18:36:22 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:22 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:22 --> Email Class Initialized
INFO - 2020-08-18 18:36:22 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:22 --> Model Class Initialized
INFO - 2020-08-18 18:36:22 --> Model Class Initialized
INFO - 2020-08-18 18:36:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:36:22 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:22 --> Total execution time: 0.0223
INFO - 2020-08-18 18:36:32 --> Config Class Initialized
INFO - 2020-08-18 18:36:32 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:32 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:32 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:32 --> URI Class Initialized
INFO - 2020-08-18 18:36:32 --> Router Class Initialized
INFO - 2020-08-18 18:36:32 --> Output Class Initialized
INFO - 2020-08-18 18:36:32 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:32 --> Input Class Initialized
INFO - 2020-08-18 18:36:32 --> Language Class Initialized
INFO - 2020-08-18 18:36:32 --> Loader Class Initialized
INFO - 2020-08-18 18:36:32 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:32 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:32 --> Email Class Initialized
INFO - 2020-08-18 18:36:32 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:32 --> Model Class Initialized
INFO - 2020-08-18 18:36:32 --> Model Class Initialized
INFO - 2020-08-18 18:36:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:36:32 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:32 --> Total execution time: 0.0273
INFO - 2020-08-18 18:36:35 --> Config Class Initialized
INFO - 2020-08-18 18:36:35 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:35 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:35 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:35 --> URI Class Initialized
INFO - 2020-08-18 18:36:35 --> Router Class Initialized
INFO - 2020-08-18 18:36:35 --> Output Class Initialized
INFO - 2020-08-18 18:36:35 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:35 --> Input Class Initialized
INFO - 2020-08-18 18:36:35 --> Language Class Initialized
INFO - 2020-08-18 18:36:35 --> Loader Class Initialized
INFO - 2020-08-18 18:36:35 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:35 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:35 --> Email Class Initialized
INFO - 2020-08-18 18:36:35 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:35 --> Model Class Initialized
INFO - 2020-08-18 18:36:35 --> Model Class Initialized
INFO - 2020-08-18 18:36:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:36:35 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:35 --> Total execution time: 0.0270
INFO - 2020-08-18 18:36:51 --> Config Class Initialized
INFO - 2020-08-18 18:36:51 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:51 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:51 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:51 --> URI Class Initialized
INFO - 2020-08-18 18:36:51 --> Router Class Initialized
INFO - 2020-08-18 18:36:51 --> Output Class Initialized
INFO - 2020-08-18 18:36:51 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:51 --> Input Class Initialized
INFO - 2020-08-18 18:36:51 --> Language Class Initialized
INFO - 2020-08-18 18:36:51 --> Loader Class Initialized
INFO - 2020-08-18 18:36:51 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:51 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:51 --> Email Class Initialized
INFO - 2020-08-18 18:36:51 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:51 --> Model Class Initialized
INFO - 2020-08-18 18:36:51 --> Model Class Initialized
INFO - 2020-08-18 18:36:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:36:51 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:51 --> Total execution time: 0.0273
INFO - 2020-08-18 18:36:54 --> Config Class Initialized
INFO - 2020-08-18 18:36:54 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:54 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:54 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:54 --> URI Class Initialized
INFO - 2020-08-18 18:36:54 --> Router Class Initialized
INFO - 2020-08-18 18:36:54 --> Output Class Initialized
INFO - 2020-08-18 18:36:54 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:54 --> Input Class Initialized
INFO - 2020-08-18 18:36:54 --> Language Class Initialized
INFO - 2020-08-18 18:36:54 --> Loader Class Initialized
INFO - 2020-08-18 18:36:54 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:54 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:54 --> Email Class Initialized
INFO - 2020-08-18 18:36:54 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:54 --> Model Class Initialized
INFO - 2020-08-18 18:36:54 --> Model Class Initialized
INFO - 2020-08-18 18:36:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-18 18:36:54 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:54 --> Total execution time: 0.0240
INFO - 2020-08-18 18:36:59 --> Config Class Initialized
INFO - 2020-08-18 18:36:59 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:36:59 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:36:59 --> Utf8 Class Initialized
INFO - 2020-08-18 18:36:59 --> URI Class Initialized
INFO - 2020-08-18 18:36:59 --> Router Class Initialized
INFO - 2020-08-18 18:36:59 --> Output Class Initialized
INFO - 2020-08-18 18:36:59 --> Security Class Initialized
DEBUG - 2020-08-18 18:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:36:59 --> Input Class Initialized
INFO - 2020-08-18 18:36:59 --> Language Class Initialized
INFO - 2020-08-18 18:36:59 --> Loader Class Initialized
INFO - 2020-08-18 18:36:59 --> Helper loaded: url_helper
INFO - 2020-08-18 18:36:59 --> Database Driver Class Initialized
INFO - 2020-08-18 18:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:36:59 --> Email Class Initialized
INFO - 2020-08-18 18:36:59 --> Controller Class Initialized
DEBUG - 2020-08-18 18:36:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:36:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:36:59 --> Model Class Initialized
INFO - 2020-08-18 18:36:59 --> Model Class Initialized
INFO - 2020-08-18 18:36:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-18 18:36:59 --> Final output sent to browser
DEBUG - 2020-08-18 18:36:59 --> Total execution time: 0.0372
INFO - 2020-08-18 18:37:20 --> Config Class Initialized
INFO - 2020-08-18 18:37:20 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:37:20 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:37:20 --> Utf8 Class Initialized
INFO - 2020-08-18 18:37:20 --> URI Class Initialized
INFO - 2020-08-18 18:37:20 --> Router Class Initialized
INFO - 2020-08-18 18:37:20 --> Output Class Initialized
INFO - 2020-08-18 18:37:20 --> Security Class Initialized
DEBUG - 2020-08-18 18:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:37:20 --> Input Class Initialized
INFO - 2020-08-18 18:37:20 --> Language Class Initialized
INFO - 2020-08-18 18:37:20 --> Loader Class Initialized
INFO - 2020-08-18 18:37:20 --> Helper loaded: url_helper
INFO - 2020-08-18 18:37:20 --> Database Driver Class Initialized
INFO - 2020-08-18 18:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:37:20 --> Email Class Initialized
INFO - 2020-08-18 18:37:20 --> Controller Class Initialized
DEBUG - 2020-08-18 18:37:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:37:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:37:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-18 18:37:20 --> Final output sent to browser
DEBUG - 2020-08-18 18:37:20 --> Total execution time: 0.0218
INFO - 2020-08-18 18:37:58 --> Config Class Initialized
INFO - 2020-08-18 18:37:58 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:37:58 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:37:58 --> Utf8 Class Initialized
INFO - 2020-08-18 18:37:58 --> URI Class Initialized
INFO - 2020-08-18 18:37:58 --> Router Class Initialized
INFO - 2020-08-18 18:37:58 --> Output Class Initialized
INFO - 2020-08-18 18:37:58 --> Security Class Initialized
DEBUG - 2020-08-18 18:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:37:58 --> Input Class Initialized
INFO - 2020-08-18 18:37:58 --> Language Class Initialized
INFO - 2020-08-18 18:37:58 --> Loader Class Initialized
INFO - 2020-08-18 18:37:58 --> Helper loaded: url_helper
INFO - 2020-08-18 18:37:58 --> Database Driver Class Initialized
INFO - 2020-08-18 18:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:37:58 --> Email Class Initialized
INFO - 2020-08-18 18:37:58 --> Controller Class Initialized
DEBUG - 2020-08-18 18:37:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:37:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:37:58 --> Model Class Initialized
INFO - 2020-08-18 18:37:58 --> Model Class Initialized
INFO - 2020-08-18 18:37:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 18:37:58 --> Final output sent to browser
DEBUG - 2020-08-18 18:37:58 --> Total execution time: 0.0249
INFO - 2020-08-18 18:38:02 --> Config Class Initialized
INFO - 2020-08-18 18:38:02 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:38:02 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:38:02 --> Utf8 Class Initialized
INFO - 2020-08-18 18:38:02 --> URI Class Initialized
INFO - 2020-08-18 18:38:02 --> Router Class Initialized
INFO - 2020-08-18 18:38:02 --> Output Class Initialized
INFO - 2020-08-18 18:38:02 --> Security Class Initialized
DEBUG - 2020-08-18 18:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:38:02 --> Input Class Initialized
INFO - 2020-08-18 18:38:02 --> Language Class Initialized
INFO - 2020-08-18 18:38:02 --> Loader Class Initialized
INFO - 2020-08-18 18:38:02 --> Helper loaded: url_helper
INFO - 2020-08-18 18:38:02 --> Database Driver Class Initialized
INFO - 2020-08-18 18:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:38:02 --> Email Class Initialized
INFO - 2020-08-18 18:38:02 --> Controller Class Initialized
DEBUG - 2020-08-18 18:38:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:38:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:38:02 --> Model Class Initialized
INFO - 2020-08-18 18:38:02 --> Model Class Initialized
INFO - 2020-08-18 18:38:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-08-18 18:38:02 --> Final output sent to browser
DEBUG - 2020-08-18 18:38:02 --> Total execution time: 0.0256
INFO - 2020-08-18 18:38:06 --> Config Class Initialized
INFO - 2020-08-18 18:38:06 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:38:06 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:38:06 --> Utf8 Class Initialized
INFO - 2020-08-18 18:38:06 --> URI Class Initialized
INFO - 2020-08-18 18:38:06 --> Router Class Initialized
INFO - 2020-08-18 18:38:06 --> Output Class Initialized
INFO - 2020-08-18 18:38:06 --> Security Class Initialized
DEBUG - 2020-08-18 18:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:38:06 --> Input Class Initialized
INFO - 2020-08-18 18:38:06 --> Language Class Initialized
INFO - 2020-08-18 18:38:06 --> Loader Class Initialized
INFO - 2020-08-18 18:38:06 --> Helper loaded: url_helper
INFO - 2020-08-18 18:38:06 --> Database Driver Class Initialized
INFO - 2020-08-18 18:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:38:06 --> Email Class Initialized
INFO - 2020-08-18 18:38:06 --> Controller Class Initialized
DEBUG - 2020-08-18 18:38:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-18 18:38:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:38:06 --> Model Class Initialized
INFO - 2020-08-18 18:38:06 --> Model Class Initialized
INFO - 2020-08-18 18:38:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-08-18 18:38:06 --> Final output sent to browser
DEBUG - 2020-08-18 18:38:06 --> Total execution time: 0.0266
INFO - 2020-08-18 18:38:15 --> Config Class Initialized
INFO - 2020-08-18 18:38:15 --> Hooks Class Initialized
DEBUG - 2020-08-18 18:38:15 --> UTF-8 Support Enabled
INFO - 2020-08-18 18:38:15 --> Utf8 Class Initialized
INFO - 2020-08-18 18:38:15 --> URI Class Initialized
DEBUG - 2020-08-18 18:38:15 --> No URI present. Default controller set.
INFO - 2020-08-18 18:38:15 --> Router Class Initialized
INFO - 2020-08-18 18:38:15 --> Output Class Initialized
INFO - 2020-08-18 18:38:15 --> Security Class Initialized
DEBUG - 2020-08-18 18:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-18 18:38:15 --> Input Class Initialized
INFO - 2020-08-18 18:38:15 --> Language Class Initialized
INFO - 2020-08-18 18:38:15 --> Loader Class Initialized
INFO - 2020-08-18 18:38:15 --> Helper loaded: url_helper
INFO - 2020-08-18 18:38:15 --> Database Driver Class Initialized
INFO - 2020-08-18 18:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-18 18:38:15 --> Email Class Initialized
INFO - 2020-08-18 18:38:15 --> Controller Class Initialized
INFO - 2020-08-18 18:38:15 --> Model Class Initialized
INFO - 2020-08-18 18:38:15 --> Model Class Initialized
DEBUG - 2020-08-18 18:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-18 18:38:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-18 18:38:15 --> Final output sent to browser
DEBUG - 2020-08-18 18:38:15 --> Total execution time: 0.0211
