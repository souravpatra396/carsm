<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-09 04:28:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:28:30 --> Config Class Initialized
INFO - 2020-11-09 04:28:30 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:28:30 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:28:30 --> Utf8 Class Initialized
INFO - 2020-11-09 04:28:30 --> URI Class Initialized
DEBUG - 2020-11-09 04:28:30 --> No URI present. Default controller set.
INFO - 2020-11-09 04:28:30 --> Router Class Initialized
INFO - 2020-11-09 04:28:30 --> Output Class Initialized
INFO - 2020-11-09 04:28:30 --> Security Class Initialized
DEBUG - 2020-11-09 04:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:28:30 --> Input Class Initialized
INFO - 2020-11-09 04:28:30 --> Language Class Initialized
INFO - 2020-11-09 04:28:30 --> Loader Class Initialized
INFO - 2020-11-09 04:28:30 --> Helper loaded: url_helper
INFO - 2020-11-09 04:28:30 --> Database Driver Class Initialized
INFO - 2020-11-09 04:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:28:30 --> Email Class Initialized
INFO - 2020-11-09 04:28:30 --> Controller Class Initialized
INFO - 2020-11-09 04:28:30 --> Model Class Initialized
INFO - 2020-11-09 04:28:30 --> Model Class Initialized
DEBUG - 2020-11-09 04:28:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:28:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-09 04:28:30 --> Final output sent to browser
DEBUG - 2020-11-09 04:28:30 --> Total execution time: 0.1430
ERROR - 2020-11-09 04:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:32:14 --> Config Class Initialized
INFO - 2020-11-09 04:32:14 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:32:14 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:32:14 --> Utf8 Class Initialized
INFO - 2020-11-09 04:32:14 --> URI Class Initialized
INFO - 2020-11-09 04:32:14 --> Router Class Initialized
ERROR - 2020-11-09 04:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:32:14 --> Output Class Initialized
INFO - 2020-11-09 04:32:14 --> Config Class Initialized
INFO - 2020-11-09 04:32:14 --> Hooks Class Initialized
INFO - 2020-11-09 04:32:14 --> Security Class Initialized
DEBUG - 2020-11-09 04:32:14 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:32:14 --> Utf8 Class Initialized
DEBUG - 2020-11-09 04:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:32:14 --> Input Class Initialized
INFO - 2020-11-09 04:32:14 --> Language Class Initialized
INFO - 2020-11-09 04:32:14 --> URI Class Initialized
INFO - 2020-11-09 04:32:14 --> Router Class Initialized
INFO - 2020-11-09 04:32:14 --> Loader Class Initialized
INFO - 2020-11-09 04:32:14 --> Output Class Initialized
INFO - 2020-11-09 04:32:14 --> Helper loaded: url_helper
INFO - 2020-11-09 04:32:14 --> Security Class Initialized
DEBUG - 2020-11-09 04:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:32:14 --> Input Class Initialized
INFO - 2020-11-09 04:32:14 --> Language Class Initialized
INFO - 2020-11-09 04:32:14 --> Database Driver Class Initialized
INFO - 2020-11-09 04:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:32:14 --> Email Class Initialized
INFO - 2020-11-09 04:32:14 --> Controller Class Initialized
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
DEBUG - 2020-11-09 04:32:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:32:14 --> Loader Class Initialized
INFO - 2020-11-09 04:32:14 --> Helper loaded: url_helper
INFO - 2020-11-09 04:32:14 --> Database Driver Class Initialized
INFO - 2020-11-09 04:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:32:14 --> Email Class Initialized
INFO - 2020-11-09 04:32:14 --> Controller Class Initialized
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
DEBUG - 2020-11-09 04:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 04:32:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
INFO - 2020-11-09 04:32:14 --> Final output sent to browser
DEBUG - 2020-11-09 04:32:14 --> Total execution time: 0.0596
ERROR - 2020-11-09 04:32:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:32:14 --> Config Class Initialized
INFO - 2020-11-09 04:32:14 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:32:14 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:32:14 --> Utf8 Class Initialized
INFO - 2020-11-09 04:32:14 --> URI Class Initialized
INFO - 2020-11-09 04:32:14 --> Router Class Initialized
INFO - 2020-11-09 04:32:14 --> Output Class Initialized
INFO - 2020-11-09 04:32:14 --> Security Class Initialized
DEBUG - 2020-11-09 04:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:32:14 --> Input Class Initialized
INFO - 2020-11-09 04:32:14 --> Language Class Initialized
INFO - 2020-11-09 04:32:14 --> Loader Class Initialized
INFO - 2020-11-09 04:32:14 --> Helper loaded: url_helper
INFO - 2020-11-09 04:32:14 --> Database Driver Class Initialized
INFO - 2020-11-09 04:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:32:14 --> Email Class Initialized
INFO - 2020-11-09 04:32:14 --> Controller Class Initialized
DEBUG - 2020-11-09 04:32:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 04:32:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
INFO - 2020-11-09 04:32:14 --> Model Class Initialized
INFO - 2020-11-09 04:32:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-09 04:32:15 --> Final output sent to browser
DEBUG - 2020-11-09 04:32:15 --> Total execution time: 0.0846
ERROR - 2020-11-09 04:32:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:32:21 --> Config Class Initialized
INFO - 2020-11-09 04:32:21 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:32:21 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:32:21 --> Utf8 Class Initialized
INFO - 2020-11-09 04:32:21 --> URI Class Initialized
INFO - 2020-11-09 04:32:21 --> Router Class Initialized
INFO - 2020-11-09 04:32:21 --> Output Class Initialized
INFO - 2020-11-09 04:32:21 --> Security Class Initialized
DEBUG - 2020-11-09 04:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:32:21 --> Input Class Initialized
INFO - 2020-11-09 04:32:21 --> Language Class Initialized
INFO - 2020-11-09 04:32:21 --> Loader Class Initialized
INFO - 2020-11-09 04:32:21 --> Helper loaded: url_helper
INFO - 2020-11-09 04:32:21 --> Database Driver Class Initialized
INFO - 2020-11-09 04:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:32:21 --> Email Class Initialized
INFO - 2020-11-09 04:32:21 --> Controller Class Initialized
DEBUG - 2020-11-09 04:32:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 04:32:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:32:21 --> Model Class Initialized
INFO - 2020-11-09 04:32:21 --> Model Class Initialized
INFO - 2020-11-09 04:32:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-09 04:32:21 --> Final output sent to browser
DEBUG - 2020-11-09 04:32:21 --> Total execution time: 0.0378
ERROR - 2020-11-09 04:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:32:36 --> Config Class Initialized
INFO - 2020-11-09 04:32:36 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:32:36 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:32:36 --> Utf8 Class Initialized
INFO - 2020-11-09 04:32:36 --> URI Class Initialized
INFO - 2020-11-09 04:32:36 --> Router Class Initialized
INFO - 2020-11-09 04:32:36 --> Output Class Initialized
INFO - 2020-11-09 04:32:36 --> Security Class Initialized
DEBUG - 2020-11-09 04:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:32:36 --> Input Class Initialized
INFO - 2020-11-09 04:32:36 --> Language Class Initialized
INFO - 2020-11-09 04:32:36 --> Loader Class Initialized
INFO - 2020-11-09 04:32:36 --> Helper loaded: url_helper
INFO - 2020-11-09 04:32:36 --> Database Driver Class Initialized
INFO - 2020-11-09 04:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:32:36 --> Email Class Initialized
INFO - 2020-11-09 04:32:36 --> Controller Class Initialized
DEBUG - 2020-11-09 04:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 04:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:32:36 --> Model Class Initialized
INFO - 2020-11-09 04:32:36 --> Model Class Initialized
ERROR - 2020-11-09 04:32:36 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-09 04:32:36 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-09 04:32:37 --> Final output sent to browser
DEBUG - 2020-11-09 04:32:37 --> Total execution time: 1.2392
ERROR - 2020-11-09 04:40:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:40:58 --> Config Class Initialized
INFO - 2020-11-09 04:40:58 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:40:58 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:40:58 --> Utf8 Class Initialized
INFO - 2020-11-09 04:40:58 --> URI Class Initialized
INFO - 2020-11-09 04:40:58 --> Router Class Initialized
INFO - 2020-11-09 04:40:58 --> Output Class Initialized
INFO - 2020-11-09 04:40:58 --> Security Class Initialized
DEBUG - 2020-11-09 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:40:58 --> Input Class Initialized
INFO - 2020-11-09 04:40:58 --> Language Class Initialized
INFO - 2020-11-09 04:40:58 --> Loader Class Initialized
INFO - 2020-11-09 04:40:58 --> Helper loaded: url_helper
INFO - 2020-11-09 04:40:58 --> Database Driver Class Initialized
INFO - 2020-11-09 04:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:40:58 --> Email Class Initialized
INFO - 2020-11-09 04:40:58 --> Controller Class Initialized
DEBUG - 2020-11-09 04:40:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 04:40:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:40:58 --> Model Class Initialized
INFO - 2020-11-09 04:40:58 --> Model Class Initialized
ERROR - 2020-11-09 04:40:58 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-09 04:40:58 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-09 04:41:11 --> Final output sent to browser
DEBUG - 2020-11-09 04:41:11 --> Total execution time: 13.6710
ERROR - 2020-11-09 04:43:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 04:43:38 --> Config Class Initialized
INFO - 2020-11-09 04:43:38 --> Hooks Class Initialized
DEBUG - 2020-11-09 04:43:38 --> UTF-8 Support Enabled
INFO - 2020-11-09 04:43:38 --> Utf8 Class Initialized
INFO - 2020-11-09 04:43:38 --> URI Class Initialized
INFO - 2020-11-09 04:43:38 --> Router Class Initialized
INFO - 2020-11-09 04:43:38 --> Output Class Initialized
INFO - 2020-11-09 04:43:38 --> Security Class Initialized
DEBUG - 2020-11-09 04:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 04:43:38 --> Input Class Initialized
INFO - 2020-11-09 04:43:38 --> Language Class Initialized
INFO - 2020-11-09 04:43:38 --> Loader Class Initialized
INFO - 2020-11-09 04:43:38 --> Helper loaded: url_helper
INFO - 2020-11-09 04:43:38 --> Database Driver Class Initialized
INFO - 2020-11-09 04:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 04:43:38 --> Email Class Initialized
INFO - 2020-11-09 04:43:38 --> Controller Class Initialized
DEBUG - 2020-11-09 04:43:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 04:43:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 04:43:38 --> Model Class Initialized
INFO - 2020-11-09 04:43:38 --> Model Class Initialized
ERROR - 2020-11-09 04:43:38 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-09 04:43:38 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-09 04:43:40 --> Final output sent to browser
DEBUG - 2020-11-09 04:43:40 --> Total execution time: 1.5805
ERROR - 2020-11-09 07:26:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:26:59 --> Config Class Initialized
INFO - 2020-11-09 07:26:59 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:26:59 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:26:59 --> Utf8 Class Initialized
INFO - 2020-11-09 07:26:59 --> URI Class Initialized
DEBUG - 2020-11-09 07:26:59 --> No URI present. Default controller set.
INFO - 2020-11-09 07:26:59 --> Router Class Initialized
INFO - 2020-11-09 07:26:59 --> Output Class Initialized
INFO - 2020-11-09 07:26:59 --> Security Class Initialized
DEBUG - 2020-11-09 07:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:26:59 --> Input Class Initialized
INFO - 2020-11-09 07:26:59 --> Language Class Initialized
INFO - 2020-11-09 07:26:59 --> Loader Class Initialized
INFO - 2020-11-09 07:26:59 --> Helper loaded: url_helper
INFO - 2020-11-09 07:26:59 --> Database Driver Class Initialized
INFO - 2020-11-09 07:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:26:59 --> Email Class Initialized
INFO - 2020-11-09 07:26:59 --> Controller Class Initialized
INFO - 2020-11-09 07:26:59 --> Model Class Initialized
INFO - 2020-11-09 07:26:59 --> Model Class Initialized
DEBUG - 2020-11-09 07:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:26:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-09 07:26:59 --> Final output sent to browser
DEBUG - 2020-11-09 07:26:59 --> Total execution time: 0.1070
ERROR - 2020-11-09 07:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:27:23 --> Config Class Initialized
INFO - 2020-11-09 07:27:23 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:27:23 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:27:23 --> Utf8 Class Initialized
INFO - 2020-11-09 07:27:23 --> URI Class Initialized
INFO - 2020-11-09 07:27:23 --> Router Class Initialized
INFO - 2020-11-09 07:27:23 --> Output Class Initialized
INFO - 2020-11-09 07:27:23 --> Security Class Initialized
DEBUG - 2020-11-09 07:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:27:23 --> Input Class Initialized
INFO - 2020-11-09 07:27:23 --> Language Class Initialized
INFO - 2020-11-09 07:27:23 --> Loader Class Initialized
INFO - 2020-11-09 07:27:23 --> Helper loaded: url_helper
INFO - 2020-11-09 07:27:23 --> Database Driver Class Initialized
INFO - 2020-11-09 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:27:24 --> Email Class Initialized
INFO - 2020-11-09 07:27:24 --> Controller Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:27:24 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-09 07:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:27:24 --> Config Class Initialized
INFO - 2020-11-09 07:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:27:24 --> Utf8 Class Initialized
INFO - 2020-11-09 07:27:24 --> URI Class Initialized
INFO - 2020-11-09 07:27:24 --> Router Class Initialized
INFO - 2020-11-09 07:27:24 --> Output Class Initialized
INFO - 2020-11-09 07:27:24 --> Security Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:27:24 --> Input Class Initialized
INFO - 2020-11-09 07:27:24 --> Language Class Initialized
INFO - 2020-11-09 07:27:24 --> Loader Class Initialized
INFO - 2020-11-09 07:27:24 --> Helper loaded: url_helper
INFO - 2020-11-09 07:27:24 --> Database Driver Class Initialized
INFO - 2020-11-09 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:27:24 --> Email Class Initialized
INFO - 2020-11-09 07:27:24 --> Controller Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-09 07:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:27:24 --> Config Class Initialized
INFO - 2020-11-09 07:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:27:24 --> Utf8 Class Initialized
INFO - 2020-11-09 07:27:24 --> URI Class Initialized
DEBUG - 2020-11-09 07:27:24 --> No URI present. Default controller set.
INFO - 2020-11-09 07:27:24 --> Router Class Initialized
INFO - 2020-11-09 07:27:24 --> Output Class Initialized
INFO - 2020-11-09 07:27:24 --> Security Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:27:24 --> Input Class Initialized
INFO - 2020-11-09 07:27:24 --> Language Class Initialized
INFO - 2020-11-09 07:27:24 --> Loader Class Initialized
INFO - 2020-11-09 07:27:24 --> Helper loaded: url_helper
INFO - 2020-11-09 07:27:24 --> Database Driver Class Initialized
INFO - 2020-11-09 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:27:24 --> Email Class Initialized
INFO - 2020-11-09 07:27:24 --> Controller Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:27:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-09 07:27:24 --> Final output sent to browser
DEBUG - 2020-11-09 07:27:24 --> Total execution time: 0.0202
ERROR - 2020-11-09 07:27:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:27:24 --> Config Class Initialized
INFO - 2020-11-09 07:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:27:24 --> Utf8 Class Initialized
INFO - 2020-11-09 07:27:24 --> URI Class Initialized
INFO - 2020-11-09 07:27:24 --> Router Class Initialized
INFO - 2020-11-09 07:27:24 --> Output Class Initialized
INFO - 2020-11-09 07:27:24 --> Security Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:27:24 --> Input Class Initialized
INFO - 2020-11-09 07:27:24 --> Language Class Initialized
INFO - 2020-11-09 07:27:24 --> Loader Class Initialized
INFO - 2020-11-09 07:27:24 --> Helper loaded: url_helper
INFO - 2020-11-09 07:27:24 --> Database Driver Class Initialized
INFO - 2020-11-09 07:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:27:24 --> Email Class Initialized
INFO - 2020-11-09 07:27:24 --> Controller Class Initialized
DEBUG - 2020-11-09 07:27:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:27:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
INFO - 2020-11-09 07:27:24 --> Model Class Initialized
INFO - 2020-11-09 07:27:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-09 07:27:24 --> Final output sent to browser
DEBUG - 2020-11-09 07:27:24 --> Total execution time: 0.0703
ERROR - 2020-11-09 07:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:32:12 --> Config Class Initialized
INFO - 2020-11-09 07:32:12 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:32:12 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:32:12 --> Utf8 Class Initialized
INFO - 2020-11-09 07:32:12 --> URI Class Initialized
INFO - 2020-11-09 07:32:12 --> Router Class Initialized
INFO - 2020-11-09 07:32:12 --> Output Class Initialized
INFO - 2020-11-09 07:32:12 --> Security Class Initialized
DEBUG - 2020-11-09 07:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:32:12 --> Input Class Initialized
INFO - 2020-11-09 07:32:12 --> Language Class Initialized
INFO - 2020-11-09 07:32:12 --> Loader Class Initialized
INFO - 2020-11-09 07:32:12 --> Helper loaded: url_helper
INFO - 2020-11-09 07:32:12 --> Database Driver Class Initialized
INFO - 2020-11-09 07:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:32:12 --> Email Class Initialized
INFO - 2020-11-09 07:32:12 --> Controller Class Initialized
DEBUG - 2020-11-09 07:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:32:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:32:12 --> Model Class Initialized
INFO - 2020-11-09 07:32:12 --> Model Class Initialized
INFO - 2020-11-09 07:32:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-09 07:32:12 --> Final output sent to browser
DEBUG - 2020-11-09 07:32:12 --> Total execution time: 0.0738
ERROR - 2020-11-09 07:32:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:32:26 --> Config Class Initialized
INFO - 2020-11-09 07:32:26 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:32:26 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:32:26 --> Utf8 Class Initialized
INFO - 2020-11-09 07:32:26 --> URI Class Initialized
INFO - 2020-11-09 07:32:26 --> Router Class Initialized
INFO - 2020-11-09 07:32:26 --> Output Class Initialized
INFO - 2020-11-09 07:32:26 --> Security Class Initialized
DEBUG - 2020-11-09 07:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:32:26 --> Input Class Initialized
INFO - 2020-11-09 07:32:26 --> Language Class Initialized
INFO - 2020-11-09 07:32:26 --> Loader Class Initialized
INFO - 2020-11-09 07:32:26 --> Helper loaded: url_helper
INFO - 2020-11-09 07:32:26 --> Database Driver Class Initialized
INFO - 2020-11-09 07:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:32:26 --> Email Class Initialized
INFO - 2020-11-09 07:32:26 --> Controller Class Initialized
DEBUG - 2020-11-09 07:32:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:32:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:32:26 --> Model Class Initialized
INFO - 2020-11-09 07:32:26 --> Model Class Initialized
ERROR - 2020-11-09 07:32:26 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-09 07:32:26 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-09 07:32:28 --> Final output sent to browser
DEBUG - 2020-11-09 07:32:28 --> Total execution time: 1.7784
ERROR - 2020-11-09 07:35:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:35:08 --> Config Class Initialized
INFO - 2020-11-09 07:35:08 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:35:08 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:35:08 --> Utf8 Class Initialized
INFO - 2020-11-09 07:35:08 --> URI Class Initialized
INFO - 2020-11-09 07:35:08 --> Router Class Initialized
INFO - 2020-11-09 07:35:08 --> Output Class Initialized
INFO - 2020-11-09 07:35:08 --> Security Class Initialized
DEBUG - 2020-11-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:35:08 --> Input Class Initialized
INFO - 2020-11-09 07:35:08 --> Language Class Initialized
INFO - 2020-11-09 07:35:08 --> Loader Class Initialized
INFO - 2020-11-09 07:35:08 --> Helper loaded: url_helper
INFO - 2020-11-09 07:35:08 --> Database Driver Class Initialized
INFO - 2020-11-09 07:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:35:08 --> Email Class Initialized
INFO - 2020-11-09 07:35:08 --> Controller Class Initialized
DEBUG - 2020-11-09 07:35:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:35:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:35:08 --> Model Class Initialized
INFO - 2020-11-09 07:35:08 --> Model Class Initialized
ERROR - 2020-11-09 07:35:08 --> Severity: Runtime Notice --> Non-static method Purlem::get_contact() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-09 07:35:08 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 17
INFO - 2020-11-09 07:35:09 --> Final output sent to browser
DEBUG - 2020-11-09 07:35:09 --> Total execution time: 0.9623
ERROR - 2020-11-09 07:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:41:14 --> Config Class Initialized
INFO - 2020-11-09 07:41:14 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:41:14 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:41:14 --> Utf8 Class Initialized
INFO - 2020-11-09 07:41:14 --> URI Class Initialized
INFO - 2020-11-09 07:41:14 --> Router Class Initialized
INFO - 2020-11-09 07:41:14 --> Output Class Initialized
INFO - 2020-11-09 07:41:14 --> Security Class Initialized
DEBUG - 2020-11-09 07:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:41:14 --> Input Class Initialized
INFO - 2020-11-09 07:41:14 --> Language Class Initialized
INFO - 2020-11-09 07:41:14 --> Loader Class Initialized
INFO - 2020-11-09 07:41:14 --> Helper loaded: url_helper
INFO - 2020-11-09 07:41:14 --> Database Driver Class Initialized
INFO - 2020-11-09 07:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:41:14 --> Email Class Initialized
INFO - 2020-11-09 07:41:14 --> Controller Class Initialized
DEBUG - 2020-11-09 07:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:41:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:41:14 --> Model Class Initialized
INFO - 2020-11-09 07:41:14 --> Model Class Initialized
ERROR - 2020-11-09 07:41:14 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-09 07:41:14 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 403 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-09 07:41:14 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-09 07:41:15 --> Final output sent to browser
DEBUG - 2020-11-09 07:41:15 --> Total execution time: 0.9389
ERROR - 2020-11-09 07:41:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-09 07:41:44 --> Config Class Initialized
INFO - 2020-11-09 07:41:44 --> Hooks Class Initialized
DEBUG - 2020-11-09 07:41:44 --> UTF-8 Support Enabled
INFO - 2020-11-09 07:41:44 --> Utf8 Class Initialized
INFO - 2020-11-09 07:41:44 --> URI Class Initialized
INFO - 2020-11-09 07:41:44 --> Router Class Initialized
INFO - 2020-11-09 07:41:44 --> Output Class Initialized
INFO - 2020-11-09 07:41:44 --> Security Class Initialized
DEBUG - 2020-11-09 07:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 07:41:44 --> Input Class Initialized
INFO - 2020-11-09 07:41:44 --> Language Class Initialized
INFO - 2020-11-09 07:41:44 --> Loader Class Initialized
INFO - 2020-11-09 07:41:44 --> Helper loaded: url_helper
INFO - 2020-11-09 07:41:44 --> Database Driver Class Initialized
INFO - 2020-11-09 07:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 07:41:44 --> Email Class Initialized
INFO - 2020-11-09 07:41:44 --> Controller Class Initialized
DEBUG - 2020-11-09 07:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-09 07:41:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-09 07:41:44 --> Model Class Initialized
INFO - 2020-11-09 07:41:44 --> Model Class Initialized
ERROR - 2020-11-09 07:41:44 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-09 07:41:44 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 403 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-09 07:41:44 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-09 07:41:45 --> Final output sent to browser
DEBUG - 2020-11-09 07:41:45 --> Total execution time: 1.0150
