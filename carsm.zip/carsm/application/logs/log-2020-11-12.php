<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-12 07:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:13:12 --> Config Class Initialized
INFO - 2020-11-12 07:13:12 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:13:12 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:13:12 --> Utf8 Class Initialized
INFO - 2020-11-12 07:13:12 --> URI Class Initialized
DEBUG - 2020-11-12 07:13:12 --> No URI present. Default controller set.
INFO - 2020-11-12 07:13:12 --> Router Class Initialized
INFO - 2020-11-12 07:13:12 --> Output Class Initialized
INFO - 2020-11-12 07:13:12 --> Security Class Initialized
DEBUG - 2020-11-12 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:13:12 --> Input Class Initialized
INFO - 2020-11-12 07:13:12 --> Language Class Initialized
INFO - 2020-11-12 07:13:12 --> Loader Class Initialized
INFO - 2020-11-12 07:13:12 --> Helper loaded: url_helper
INFO - 2020-11-12 07:13:12 --> Database Driver Class Initialized
INFO - 2020-11-12 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:13:12 --> Email Class Initialized
INFO - 2020-11-12 07:13:12 --> Controller Class Initialized
INFO - 2020-11-12 07:13:12 --> Model Class Initialized
INFO - 2020-11-12 07:13:12 --> Model Class Initialized
DEBUG - 2020-11-12 07:13:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:13:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-12 07:13:12 --> Final output sent to browser
DEBUG - 2020-11-12 07:13:12 --> Total execution time: 0.1798
ERROR - 2020-11-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-11-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:06 --> Config Class Initialized
INFO - 2020-11-12 07:26:06 --> Config Class Initialized
INFO - 2020-11-12 07:26:06 --> Hooks Class Initialized
INFO - 2020-11-12 07:26:06 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2020-11-12 07:26:06 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:06 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:06 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:06 --> URI Class Initialized
INFO - 2020-11-12 07:26:06 --> URI Class Initialized
INFO - 2020-11-12 07:26:06 --> Router Class Initialized
INFO - 2020-11-12 07:26:06 --> Router Class Initialized
INFO - 2020-11-12 07:26:06 --> Output Class Initialized
INFO - 2020-11-12 07:26:06 --> Output Class Initialized
INFO - 2020-11-12 07:26:06 --> Security Class Initialized
INFO - 2020-11-12 07:26:06 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-11-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:06 --> Input Class Initialized
INFO - 2020-11-12 07:26:06 --> Input Class Initialized
INFO - 2020-11-12 07:26:06 --> Language Class Initialized
INFO - 2020-11-12 07:26:06 --> Language Class Initialized
INFO - 2020-11-12 07:26:06 --> Loader Class Initialized
INFO - 2020-11-12 07:26:06 --> Loader Class Initialized
INFO - 2020-11-12 07:26:06 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:06 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:06 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:06 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:06 --> Email Class Initialized
INFO - 2020-11-12 07:26:06 --> Controller Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:06 --> Email Class Initialized
INFO - 2020-11-12 07:26:06 --> Controller Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:26:06 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:06 --> Config Class Initialized
INFO - 2020-11-12 07:26:06 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:06 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:06 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:06 --> URI Class Initialized
DEBUG - 2020-11-12 07:26:06 --> No URI present. Default controller set.
INFO - 2020-11-12 07:26:06 --> Router Class Initialized
INFO - 2020-11-12 07:26:06 --> Output Class Initialized
INFO - 2020-11-12 07:26:06 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:06 --> Input Class Initialized
INFO - 2020-11-12 07:26:06 --> Language Class Initialized
INFO - 2020-11-12 07:26:06 --> Loader Class Initialized
INFO - 2020-11-12 07:26:06 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:06 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:06 --> Email Class Initialized
INFO - 2020-11-12 07:26:06 --> Controller Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:26:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-12 07:26:06 --> Final output sent to browser
DEBUG - 2020-11-12 07:26:06 --> Total execution time: 0.0264
ERROR - 2020-11-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:06 --> Config Class Initialized
INFO - 2020-11-12 07:26:06 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:06 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:06 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:06 --> URI Class Initialized
INFO - 2020-11-12 07:26:06 --> Router Class Initialized
INFO - 2020-11-12 07:26:06 --> Output Class Initialized
INFO - 2020-11-12 07:26:06 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:06 --> Input Class Initialized
INFO - 2020-11-12 07:26:06 --> Language Class Initialized
INFO - 2020-11-12 07:26:06 --> Loader Class Initialized
INFO - 2020-11-12 07:26:06 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:06 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:06 --> Email Class Initialized
INFO - 2020-11-12 07:26:06 --> Controller Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:26:06 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:06 --> Config Class Initialized
INFO - 2020-11-12 07:26:06 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:06 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:06 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:06 --> URI Class Initialized
DEBUG - 2020-11-12 07:26:06 --> No URI present. Default controller set.
INFO - 2020-11-12 07:26:06 --> Router Class Initialized
INFO - 2020-11-12 07:26:06 --> Output Class Initialized
INFO - 2020-11-12 07:26:06 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:06 --> Input Class Initialized
INFO - 2020-11-12 07:26:06 --> Language Class Initialized
INFO - 2020-11-12 07:26:06 --> Loader Class Initialized
INFO - 2020-11-12 07:26:06 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:06 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:06 --> Email Class Initialized
INFO - 2020-11-12 07:26:06 --> Controller Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
INFO - 2020-11-12 07:26:06 --> Model Class Initialized
DEBUG - 2020-11-12 07:26:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:26:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-12 07:26:06 --> Final output sent to browser
DEBUG - 2020-11-12 07:26:06 --> Total execution time: 0.0186
ERROR - 2020-11-12 07:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:26 --> Config Class Initialized
INFO - 2020-11-12 07:26:26 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:26 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:26 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:26 --> URI Class Initialized
INFO - 2020-11-12 07:26:26 --> Router Class Initialized
INFO - 2020-11-12 07:26:26 --> Output Class Initialized
INFO - 2020-11-12 07:26:26 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:26 --> Input Class Initialized
INFO - 2020-11-12 07:26:26 --> Language Class Initialized
INFO - 2020-11-12 07:26:26 --> Loader Class Initialized
INFO - 2020-11-12 07:26:26 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:26 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:26 --> Email Class Initialized
INFO - 2020-11-12 07:26:26 --> Controller Class Initialized
INFO - 2020-11-12 07:26:26 --> Model Class Initialized
INFO - 2020-11-12 07:26:26 --> Model Class Initialized
DEBUG - 2020-11-12 07:26:26 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-12 07:26:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:26 --> Config Class Initialized
INFO - 2020-11-12 07:26:26 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:26 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:26 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:26 --> URI Class Initialized
INFO - 2020-11-12 07:26:26 --> Router Class Initialized
INFO - 2020-11-12 07:26:26 --> Output Class Initialized
INFO - 2020-11-12 07:26:26 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:26 --> Input Class Initialized
INFO - 2020-11-12 07:26:26 --> Language Class Initialized
INFO - 2020-11-12 07:26:26 --> Loader Class Initialized
INFO - 2020-11-12 07:26:26 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:26 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:26 --> Email Class Initialized
INFO - 2020-11-12 07:26:26 --> Controller Class Initialized
INFO - 2020-11-12 07:26:26 --> Model Class Initialized
INFO - 2020-11-12 07:26:26 --> Model Class Initialized
DEBUG - 2020-11-12 07:26:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:26:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:26:26 --> Model Class Initialized
INFO - 2020-11-12 07:26:26 --> Final output sent to browser
DEBUG - 2020-11-12 07:26:26 --> Total execution time: 0.0241
ERROR - 2020-11-12 07:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:26:27 --> Config Class Initialized
INFO - 2020-11-12 07:26:27 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:26:27 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:26:27 --> Utf8 Class Initialized
INFO - 2020-11-12 07:26:27 --> URI Class Initialized
INFO - 2020-11-12 07:26:27 --> Router Class Initialized
INFO - 2020-11-12 07:26:27 --> Output Class Initialized
INFO - 2020-11-12 07:26:27 --> Security Class Initialized
DEBUG - 2020-11-12 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:26:27 --> Input Class Initialized
INFO - 2020-11-12 07:26:27 --> Language Class Initialized
INFO - 2020-11-12 07:26:27 --> Loader Class Initialized
INFO - 2020-11-12 07:26:27 --> Helper loaded: url_helper
INFO - 2020-11-12 07:26:27 --> Database Driver Class Initialized
INFO - 2020-11-12 07:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:26:27 --> Email Class Initialized
INFO - 2020-11-12 07:26:27 --> Controller Class Initialized
DEBUG - 2020-11-12 07:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:26:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:26:27 --> Model Class Initialized
INFO - 2020-11-12 07:26:27 --> Model Class Initialized
INFO - 2020-11-12 07:26:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-12 07:26:27 --> Final output sent to browser
DEBUG - 2020-11-12 07:26:27 --> Total execution time: 0.0835
ERROR - 2020-11-12 07:28:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:28:50 --> Config Class Initialized
INFO - 2020-11-12 07:28:50 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:28:50 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:28:50 --> Utf8 Class Initialized
INFO - 2020-11-12 07:28:50 --> URI Class Initialized
INFO - 2020-11-12 07:28:50 --> Router Class Initialized
INFO - 2020-11-12 07:28:50 --> Output Class Initialized
INFO - 2020-11-12 07:28:50 --> Security Class Initialized
DEBUG - 2020-11-12 07:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:28:50 --> Input Class Initialized
INFO - 2020-11-12 07:28:50 --> Language Class Initialized
INFO - 2020-11-12 07:28:50 --> Loader Class Initialized
INFO - 2020-11-12 07:28:50 --> Helper loaded: url_helper
INFO - 2020-11-12 07:28:50 --> Database Driver Class Initialized
INFO - 2020-11-12 07:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:28:50 --> Email Class Initialized
INFO - 2020-11-12 07:28:50 --> Controller Class Initialized
DEBUG - 2020-11-12 07:28:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:28:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:28:50 --> Model Class Initialized
INFO - 2020-11-12 07:28:50 --> Model Class Initialized
INFO - 2020-11-12 07:28:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-12 07:28:50 --> Final output sent to browser
DEBUG - 2020-11-12 07:28:50 --> Total execution time: 0.1414
ERROR - 2020-11-12 07:28:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:28:53 --> Config Class Initialized
INFO - 2020-11-12 07:28:53 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:28:53 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:28:53 --> Utf8 Class Initialized
INFO - 2020-11-12 07:28:53 --> URI Class Initialized
INFO - 2020-11-12 07:28:53 --> Router Class Initialized
INFO - 2020-11-12 07:28:53 --> Output Class Initialized
INFO - 2020-11-12 07:28:53 --> Security Class Initialized
DEBUG - 2020-11-12 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:28:53 --> Input Class Initialized
INFO - 2020-11-12 07:28:53 --> Language Class Initialized
INFO - 2020-11-12 07:28:53 --> Loader Class Initialized
INFO - 2020-11-12 07:28:53 --> Helper loaded: url_helper
INFO - 2020-11-12 07:28:53 --> Database Driver Class Initialized
INFO - 2020-11-12 07:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:28:53 --> Email Class Initialized
INFO - 2020-11-12 07:28:53 --> Controller Class Initialized
DEBUG - 2020-11-12 07:28:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:28:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:28:53 --> Model Class Initialized
INFO - 2020-11-12 07:28:53 --> Model Class Initialized
INFO - 2020-11-12 07:28:53 --> Model Class Initialized
INFO - 2020-11-12 07:28:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-12 07:28:53 --> Final output sent to browser
DEBUG - 2020-11-12 07:28:53 --> Total execution time: 0.0291
ERROR - 2020-11-12 07:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:40:45 --> Config Class Initialized
INFO - 2020-11-12 07:40:45 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:40:45 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:40:45 --> Utf8 Class Initialized
INFO - 2020-11-12 07:40:45 --> URI Class Initialized
INFO - 2020-11-12 07:40:45 --> Router Class Initialized
INFO - 2020-11-12 07:40:45 --> Output Class Initialized
INFO - 2020-11-12 07:40:45 --> Security Class Initialized
DEBUG - 2020-11-12 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:40:45 --> Input Class Initialized
INFO - 2020-11-12 07:40:45 --> Language Class Initialized
INFO - 2020-11-12 07:40:45 --> Loader Class Initialized
INFO - 2020-11-12 07:40:45 --> Helper loaded: url_helper
INFO - 2020-11-12 07:40:45 --> Database Driver Class Initialized
INFO - 2020-11-12 07:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:40:45 --> Email Class Initialized
INFO - 2020-11-12 07:40:45 --> Controller Class Initialized
DEBUG - 2020-11-12 07:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:40:45 --> Model Class Initialized
INFO - 2020-11-12 07:40:45 --> Model Class Initialized
INFO - 2020-11-12 07:40:45 --> Model Class Initialized
INFO - 2020-11-12 07:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-12 07:40:45 --> Final output sent to browser
DEBUG - 2020-11-12 07:40:45 --> Total execution time: 0.0393
ERROR - 2020-11-12 07:40:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:40:50 --> Config Class Initialized
INFO - 2020-11-12 07:40:50 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:40:50 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:40:50 --> Utf8 Class Initialized
INFO - 2020-11-12 07:40:50 --> URI Class Initialized
INFO - 2020-11-12 07:40:50 --> Router Class Initialized
INFO - 2020-11-12 07:40:50 --> Output Class Initialized
INFO - 2020-11-12 07:40:50 --> Security Class Initialized
DEBUG - 2020-11-12 07:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:40:50 --> Input Class Initialized
INFO - 2020-11-12 07:40:50 --> Language Class Initialized
INFO - 2020-11-12 07:40:50 --> Loader Class Initialized
INFO - 2020-11-12 07:40:50 --> Helper loaded: url_helper
INFO - 2020-11-12 07:40:50 --> Database Driver Class Initialized
INFO - 2020-11-12 07:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:40:50 --> Email Class Initialized
INFO - 2020-11-12 07:40:50 --> Controller Class Initialized
DEBUG - 2020-11-12 07:40:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:40:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:40:50 --> Model Class Initialized
INFO - 2020-11-12 07:40:50 --> Model Class Initialized
ERROR - 2020-11-12 07:40:50 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:40:50 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
ERROR - 2020-11-12 07:40:52 --> Severity: Warning --> Illegal string offset 'firstName' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
INFO - 2020-11-12 07:40:52 --> Final output sent to browser
DEBUG - 2020-11-12 07:40:52 --> Total execution time: 1.5145
ERROR - 2020-11-12 07:41:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:41:17 --> Config Class Initialized
INFO - 2020-11-12 07:41:17 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:41:17 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:41:17 --> Utf8 Class Initialized
INFO - 2020-11-12 07:41:17 --> URI Class Initialized
INFO - 2020-11-12 07:41:17 --> Router Class Initialized
INFO - 2020-11-12 07:41:17 --> Output Class Initialized
INFO - 2020-11-12 07:41:17 --> Security Class Initialized
DEBUG - 2020-11-12 07:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:41:17 --> Input Class Initialized
INFO - 2020-11-12 07:41:17 --> Language Class Initialized
INFO - 2020-11-12 07:41:17 --> Loader Class Initialized
INFO - 2020-11-12 07:41:17 --> Helper loaded: url_helper
INFO - 2020-11-12 07:41:17 --> Database Driver Class Initialized
INFO - 2020-11-12 07:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:41:17 --> Email Class Initialized
INFO - 2020-11-12 07:41:17 --> Controller Class Initialized
DEBUG - 2020-11-12 07:41:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:41:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:41:17 --> Model Class Initialized
INFO - 2020-11-12 07:41:17 --> Model Class Initialized
ERROR - 2020-11-12 07:41:17 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:41:17 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
ERROR - 2020-11-12 07:41:18 --> Severity: Warning --> Illegal string offset 'firstName' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
INFO - 2020-11-12 07:41:18 --> Final output sent to browser
DEBUG - 2020-11-12 07:41:18 --> Total execution time: 0.9422
ERROR - 2020-11-12 07:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:41:56 --> Config Class Initialized
INFO - 2020-11-12 07:41:56 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:41:56 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:41:56 --> Utf8 Class Initialized
INFO - 2020-11-12 07:41:56 --> URI Class Initialized
INFO - 2020-11-12 07:41:56 --> Router Class Initialized
INFO - 2020-11-12 07:41:56 --> Output Class Initialized
INFO - 2020-11-12 07:41:56 --> Security Class Initialized
DEBUG - 2020-11-12 07:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:41:56 --> Input Class Initialized
INFO - 2020-11-12 07:41:56 --> Language Class Initialized
INFO - 2020-11-12 07:41:56 --> Loader Class Initialized
INFO - 2020-11-12 07:41:56 --> Helper loaded: url_helper
INFO - 2020-11-12 07:41:56 --> Database Driver Class Initialized
INFO - 2020-11-12 07:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:41:56 --> Email Class Initialized
INFO - 2020-11-12 07:41:56 --> Controller Class Initialized
DEBUG - 2020-11-12 07:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:41:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:41:56 --> Model Class Initialized
INFO - 2020-11-12 07:41:56 --> Model Class Initialized
ERROR - 2020-11-12 07:41:56 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:41:56 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
ERROR - 2020-11-12 07:41:57 --> Severity: Warning --> Illegal string offset 'firstName' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
INFO - 2020-11-12 07:41:57 --> Final output sent to browser
DEBUG - 2020-11-12 07:41:57 --> Total execution time: 1.0166
ERROR - 2020-11-12 07:42:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:42:02 --> Config Class Initialized
INFO - 2020-11-12 07:42:02 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:42:02 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:42:02 --> Utf8 Class Initialized
INFO - 2020-11-12 07:42:02 --> URI Class Initialized
INFO - 2020-11-12 07:42:02 --> Router Class Initialized
INFO - 2020-11-12 07:42:02 --> Output Class Initialized
INFO - 2020-11-12 07:42:02 --> Security Class Initialized
DEBUG - 2020-11-12 07:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:42:02 --> Input Class Initialized
INFO - 2020-11-12 07:42:02 --> Language Class Initialized
INFO - 2020-11-12 07:42:02 --> Loader Class Initialized
INFO - 2020-11-12 07:42:02 --> Helper loaded: url_helper
INFO - 2020-11-12 07:42:02 --> Database Driver Class Initialized
INFO - 2020-11-12 07:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:42:02 --> Email Class Initialized
INFO - 2020-11-12 07:42:02 --> Controller Class Initialized
DEBUG - 2020-11-12 07:42:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:42:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:42:02 --> Model Class Initialized
INFO - 2020-11-12 07:42:02 --> Model Class Initialized
ERROR - 2020-11-12 07:42:02 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:42:02 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
ERROR - 2020-11-12 07:42:03 --> Severity: Warning --> Illegal string offset 'firstName' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
INFO - 2020-11-12 07:42:03 --> Final output sent to browser
DEBUG - 2020-11-12 07:42:03 --> Total execution time: 0.9536
ERROR - 2020-11-12 07:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:42:21 --> Config Class Initialized
INFO - 2020-11-12 07:42:21 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:42:21 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:42:21 --> Utf8 Class Initialized
INFO - 2020-11-12 07:42:21 --> URI Class Initialized
INFO - 2020-11-12 07:42:21 --> Router Class Initialized
INFO - 2020-11-12 07:42:21 --> Output Class Initialized
INFO - 2020-11-12 07:42:21 --> Security Class Initialized
DEBUG - 2020-11-12 07:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:42:21 --> Input Class Initialized
INFO - 2020-11-12 07:42:21 --> Language Class Initialized
INFO - 2020-11-12 07:42:21 --> Loader Class Initialized
INFO - 2020-11-12 07:42:21 --> Helper loaded: url_helper
INFO - 2020-11-12 07:42:21 --> Database Driver Class Initialized
INFO - 2020-11-12 07:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:42:21 --> Email Class Initialized
INFO - 2020-11-12 07:42:21 --> Controller Class Initialized
DEBUG - 2020-11-12 07:42:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:42:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:42:21 --> Model Class Initialized
INFO - 2020-11-12 07:42:21 --> Model Class Initialized
ERROR - 2020-11-12 07:42:21 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:42:21 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:42:22 --> Final output sent to browser
DEBUG - 2020-11-12 07:42:22 --> Total execution time: 1.0167
ERROR - 2020-11-12 07:43:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:43:44 --> Config Class Initialized
INFO - 2020-11-12 07:43:44 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:43:44 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:43:44 --> Utf8 Class Initialized
INFO - 2020-11-12 07:43:44 --> URI Class Initialized
INFO - 2020-11-12 07:43:44 --> Router Class Initialized
INFO - 2020-11-12 07:43:44 --> Output Class Initialized
INFO - 2020-11-12 07:43:44 --> Security Class Initialized
DEBUG - 2020-11-12 07:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:43:44 --> Input Class Initialized
INFO - 2020-11-12 07:43:44 --> Language Class Initialized
INFO - 2020-11-12 07:43:44 --> Loader Class Initialized
INFO - 2020-11-12 07:43:44 --> Helper loaded: url_helper
INFO - 2020-11-12 07:43:44 --> Database Driver Class Initialized
INFO - 2020-11-12 07:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:43:44 --> Email Class Initialized
INFO - 2020-11-12 07:43:44 --> Controller Class Initialized
DEBUG - 2020-11-12 07:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:43:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:43:44 --> Model Class Initialized
INFO - 2020-11-12 07:43:44 --> Model Class Initialized
ERROR - 2020-11-12 07:43:44 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:43:44 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:43:45 --> Final output sent to browser
DEBUG - 2020-11-12 07:43:45 --> Total execution time: 0.9562
ERROR - 2020-11-12 07:44:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:44:18 --> Config Class Initialized
INFO - 2020-11-12 07:44:18 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:44:18 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:44:18 --> Utf8 Class Initialized
INFO - 2020-11-12 07:44:18 --> URI Class Initialized
INFO - 2020-11-12 07:44:18 --> Router Class Initialized
INFO - 2020-11-12 07:44:18 --> Output Class Initialized
INFO - 2020-11-12 07:44:18 --> Security Class Initialized
DEBUG - 2020-11-12 07:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:44:18 --> Input Class Initialized
INFO - 2020-11-12 07:44:18 --> Language Class Initialized
INFO - 2020-11-12 07:44:18 --> Loader Class Initialized
INFO - 2020-11-12 07:44:18 --> Helper loaded: url_helper
INFO - 2020-11-12 07:44:18 --> Database Driver Class Initialized
INFO - 2020-11-12 07:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:44:18 --> Email Class Initialized
INFO - 2020-11-12 07:44:18 --> Controller Class Initialized
DEBUG - 2020-11-12 07:44:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:44:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:44:18 --> Model Class Initialized
INFO - 2020-11-12 07:44:18 --> Model Class Initialized
ERROR - 2020-11-12 07:44:18 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:44:19 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:44:19 --> Final output sent to browser
DEBUG - 2020-11-12 07:44:19 --> Total execution time: 0.9921
ERROR - 2020-11-12 07:44:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:44:47 --> Config Class Initialized
INFO - 2020-11-12 07:44:47 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:44:47 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:44:47 --> Utf8 Class Initialized
INFO - 2020-11-12 07:44:47 --> URI Class Initialized
INFO - 2020-11-12 07:44:47 --> Router Class Initialized
INFO - 2020-11-12 07:44:47 --> Output Class Initialized
INFO - 2020-11-12 07:44:47 --> Security Class Initialized
DEBUG - 2020-11-12 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:44:47 --> Input Class Initialized
INFO - 2020-11-12 07:44:47 --> Language Class Initialized
INFO - 2020-11-12 07:44:47 --> Loader Class Initialized
INFO - 2020-11-12 07:44:47 --> Helper loaded: url_helper
INFO - 2020-11-12 07:44:47 --> Database Driver Class Initialized
INFO - 2020-11-12 07:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:44:47 --> Email Class Initialized
INFO - 2020-11-12 07:44:47 --> Controller Class Initialized
DEBUG - 2020-11-12 07:44:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:44:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:44:47 --> Model Class Initialized
INFO - 2020-11-12 07:44:47 --> Model Class Initialized
ERROR - 2020-11-12 07:44:47 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:44:47 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:44:48 --> Final output sent to browser
DEBUG - 2020-11-12 07:44:48 --> Total execution time: 0.9894
ERROR - 2020-11-12 07:44:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:44:51 --> Config Class Initialized
INFO - 2020-11-12 07:44:51 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:44:51 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:44:51 --> Utf8 Class Initialized
INFO - 2020-11-12 07:44:51 --> URI Class Initialized
INFO - 2020-11-12 07:44:51 --> Router Class Initialized
INFO - 2020-11-12 07:44:51 --> Output Class Initialized
INFO - 2020-11-12 07:44:51 --> Security Class Initialized
DEBUG - 2020-11-12 07:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:44:51 --> Input Class Initialized
INFO - 2020-11-12 07:44:51 --> Language Class Initialized
INFO - 2020-11-12 07:44:51 --> Loader Class Initialized
INFO - 2020-11-12 07:44:51 --> Helper loaded: url_helper
INFO - 2020-11-12 07:44:51 --> Database Driver Class Initialized
INFO - 2020-11-12 07:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:44:51 --> Email Class Initialized
INFO - 2020-11-12 07:44:51 --> Controller Class Initialized
DEBUG - 2020-11-12 07:44:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:44:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:44:51 --> Model Class Initialized
INFO - 2020-11-12 07:44:51 --> Model Class Initialized
ERROR - 2020-11-12 07:44:51 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:44:51 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:44:52 --> Final output sent to browser
DEBUG - 2020-11-12 07:44:52 --> Total execution time: 0.9995
ERROR - 2020-11-12 07:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:45:29 --> Config Class Initialized
INFO - 2020-11-12 07:45:29 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:45:29 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:45:29 --> Utf8 Class Initialized
INFO - 2020-11-12 07:45:29 --> URI Class Initialized
INFO - 2020-11-12 07:45:29 --> Router Class Initialized
INFO - 2020-11-12 07:45:29 --> Output Class Initialized
INFO - 2020-11-12 07:45:29 --> Security Class Initialized
DEBUG - 2020-11-12 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:45:29 --> Input Class Initialized
INFO - 2020-11-12 07:45:29 --> Language Class Initialized
INFO - 2020-11-12 07:45:29 --> Loader Class Initialized
INFO - 2020-11-12 07:45:29 --> Helper loaded: url_helper
INFO - 2020-11-12 07:45:29 --> Database Driver Class Initialized
INFO - 2020-11-12 07:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:45:29 --> Email Class Initialized
INFO - 2020-11-12 07:45:29 --> Controller Class Initialized
DEBUG - 2020-11-12 07:45:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:45:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:45:29 --> Model Class Initialized
INFO - 2020-11-12 07:45:29 --> Model Class Initialized
ERROR - 2020-11-12 07:45:29 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:45:29 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:45:30 --> Final output sent to browser
DEBUG - 2020-11-12 07:45:30 --> Total execution time: 0.9884
ERROR - 2020-11-12 07:46:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:46:16 --> Config Class Initialized
INFO - 2020-11-12 07:46:16 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:46:16 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:46:16 --> Utf8 Class Initialized
INFO - 2020-11-12 07:46:16 --> URI Class Initialized
INFO - 2020-11-12 07:46:16 --> Router Class Initialized
INFO - 2020-11-12 07:46:16 --> Output Class Initialized
INFO - 2020-11-12 07:46:16 --> Security Class Initialized
DEBUG - 2020-11-12 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:46:16 --> Input Class Initialized
INFO - 2020-11-12 07:46:16 --> Language Class Initialized
INFO - 2020-11-12 07:46:16 --> Loader Class Initialized
INFO - 2020-11-12 07:46:16 --> Helper loaded: url_helper
INFO - 2020-11-12 07:46:16 --> Database Driver Class Initialized
INFO - 2020-11-12 07:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:46:16 --> Email Class Initialized
INFO - 2020-11-12 07:46:16 --> Controller Class Initialized
DEBUG - 2020-11-12 07:46:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:46:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:46:16 --> Model Class Initialized
INFO - 2020-11-12 07:46:16 --> Model Class Initialized
ERROR - 2020-11-12 07:46:16 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:46:16 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:46:17 --> Final output sent to browser
DEBUG - 2020-11-12 07:46:17 --> Total execution time: 0.9487
ERROR - 2020-11-12 07:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:46:19 --> Config Class Initialized
INFO - 2020-11-12 07:46:19 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:46:19 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:46:19 --> Utf8 Class Initialized
INFO - 2020-11-12 07:46:19 --> URI Class Initialized
INFO - 2020-11-12 07:46:19 --> Router Class Initialized
INFO - 2020-11-12 07:46:19 --> Output Class Initialized
INFO - 2020-11-12 07:46:19 --> Security Class Initialized
DEBUG - 2020-11-12 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:46:19 --> Input Class Initialized
INFO - 2020-11-12 07:46:19 --> Language Class Initialized
INFO - 2020-11-12 07:46:19 --> Loader Class Initialized
INFO - 2020-11-12 07:46:19 --> Helper loaded: url_helper
INFO - 2020-11-12 07:46:19 --> Database Driver Class Initialized
INFO - 2020-11-12 07:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:46:19 --> Email Class Initialized
INFO - 2020-11-12 07:46:19 --> Controller Class Initialized
DEBUG - 2020-11-12 07:46:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:46:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:46:19 --> Model Class Initialized
INFO - 2020-11-12 07:46:19 --> Model Class Initialized
ERROR - 2020-11-12 07:46:19 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:46:19 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:46:20 --> Final output sent to browser
DEBUG - 2020-11-12 07:46:20 --> Total execution time: 1.0229
ERROR - 2020-11-12 07:46:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:46:22 --> Config Class Initialized
INFO - 2020-11-12 07:46:22 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:46:22 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:46:22 --> Utf8 Class Initialized
INFO - 2020-11-12 07:46:22 --> URI Class Initialized
INFO - 2020-11-12 07:46:22 --> Router Class Initialized
INFO - 2020-11-12 07:46:22 --> Output Class Initialized
INFO - 2020-11-12 07:46:22 --> Security Class Initialized
DEBUG - 2020-11-12 07:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:46:22 --> Input Class Initialized
INFO - 2020-11-12 07:46:22 --> Language Class Initialized
INFO - 2020-11-12 07:46:22 --> Loader Class Initialized
INFO - 2020-11-12 07:46:22 --> Helper loaded: url_helper
INFO - 2020-11-12 07:46:22 --> Database Driver Class Initialized
INFO - 2020-11-12 07:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:46:22 --> Email Class Initialized
INFO - 2020-11-12 07:46:22 --> Controller Class Initialized
DEBUG - 2020-11-12 07:46:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:46:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:46:22 --> Model Class Initialized
INFO - 2020-11-12 07:46:22 --> Model Class Initialized
ERROR - 2020-11-12 07:46:22 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:46:22 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:46:23 --> Final output sent to browser
DEBUG - 2020-11-12 07:46:23 --> Total execution time: 1.0004
ERROR - 2020-11-12 07:46:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:46:36 --> Config Class Initialized
INFO - 2020-11-12 07:46:36 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:46:36 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:46:36 --> Utf8 Class Initialized
INFO - 2020-11-12 07:46:36 --> URI Class Initialized
INFO - 2020-11-12 07:46:36 --> Router Class Initialized
INFO - 2020-11-12 07:46:36 --> Output Class Initialized
INFO - 2020-11-12 07:46:36 --> Security Class Initialized
DEBUG - 2020-11-12 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:46:36 --> Input Class Initialized
INFO - 2020-11-12 07:46:36 --> Language Class Initialized
INFO - 2020-11-12 07:46:36 --> Loader Class Initialized
INFO - 2020-11-12 07:46:36 --> Helper loaded: url_helper
INFO - 2020-11-12 07:46:36 --> Database Driver Class Initialized
INFO - 2020-11-12 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:46:36 --> Email Class Initialized
INFO - 2020-11-12 07:46:36 --> Controller Class Initialized
DEBUG - 2020-11-12 07:46:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:46:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:46:36 --> Model Class Initialized
INFO - 2020-11-12 07:46:36 --> Model Class Initialized
INFO - 2020-11-12 07:46:36 --> Model Class Initialized
INFO - 2020-11-12 07:46:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-12 07:46:36 --> Final output sent to browser
DEBUG - 2020-11-12 07:46:36 --> Total execution time: 0.0584
ERROR - 2020-11-12 07:46:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:46:37 --> Config Class Initialized
INFO - 2020-11-12 07:46:37 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:46:37 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:46:37 --> Utf8 Class Initialized
INFO - 2020-11-12 07:46:37 --> URI Class Initialized
INFO - 2020-11-12 07:46:37 --> Router Class Initialized
INFO - 2020-11-12 07:46:37 --> Output Class Initialized
INFO - 2020-11-12 07:46:37 --> Security Class Initialized
DEBUG - 2020-11-12 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:46:37 --> Input Class Initialized
INFO - 2020-11-12 07:46:37 --> Language Class Initialized
INFO - 2020-11-12 07:46:37 --> Loader Class Initialized
INFO - 2020-11-12 07:46:37 --> Helper loaded: url_helper
INFO - 2020-11-12 07:46:37 --> Database Driver Class Initialized
INFO - 2020-11-12 07:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:46:37 --> Email Class Initialized
INFO - 2020-11-12 07:46:37 --> Controller Class Initialized
DEBUG - 2020-11-12 07:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:46:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:46:37 --> Model Class Initialized
INFO - 2020-11-12 07:46:37 --> Model Class Initialized
INFO - 2020-11-12 07:46:37 --> Model Class Initialized
INFO - 2020-11-12 07:46:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-12 07:46:37 --> Final output sent to browser
DEBUG - 2020-11-12 07:46:37 --> Total execution time: 0.1389
ERROR - 2020-11-12 07:46:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:46:47 --> Config Class Initialized
INFO - 2020-11-12 07:46:47 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:46:47 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:46:47 --> Utf8 Class Initialized
INFO - 2020-11-12 07:46:47 --> URI Class Initialized
INFO - 2020-11-12 07:46:47 --> Router Class Initialized
INFO - 2020-11-12 07:46:47 --> Output Class Initialized
INFO - 2020-11-12 07:46:47 --> Security Class Initialized
DEBUG - 2020-11-12 07:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:46:47 --> Input Class Initialized
INFO - 2020-11-12 07:46:47 --> Language Class Initialized
INFO - 2020-11-12 07:46:47 --> Loader Class Initialized
INFO - 2020-11-12 07:46:47 --> Helper loaded: url_helper
INFO - 2020-11-12 07:46:47 --> Database Driver Class Initialized
INFO - 2020-11-12 07:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:46:47 --> Email Class Initialized
INFO - 2020-11-12 07:46:47 --> Controller Class Initialized
DEBUG - 2020-11-12 07:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:46:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:46:47 --> Model Class Initialized
INFO - 2020-11-12 07:46:47 --> Model Class Initialized
ERROR - 2020-11-12 07:46:47 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:46:47 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:46:48 --> Final output sent to browser
DEBUG - 2020-11-12 07:46:48 --> Total execution time: 1.0093
ERROR - 2020-11-12 07:48:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:48:45 --> Config Class Initialized
INFO - 2020-11-12 07:48:45 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:48:45 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:48:45 --> Utf8 Class Initialized
INFO - 2020-11-12 07:48:45 --> URI Class Initialized
INFO - 2020-11-12 07:48:45 --> Router Class Initialized
INFO - 2020-11-12 07:48:45 --> Output Class Initialized
INFO - 2020-11-12 07:48:45 --> Security Class Initialized
DEBUG - 2020-11-12 07:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:48:45 --> Input Class Initialized
INFO - 2020-11-12 07:48:45 --> Language Class Initialized
INFO - 2020-11-12 07:48:45 --> Loader Class Initialized
INFO - 2020-11-12 07:48:45 --> Helper loaded: url_helper
INFO - 2020-11-12 07:48:45 --> Database Driver Class Initialized
INFO - 2020-11-12 07:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:48:45 --> Email Class Initialized
INFO - 2020-11-12 07:48:45 --> Controller Class Initialized
DEBUG - 2020-11-12 07:48:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:48:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:48:45 --> Model Class Initialized
INFO - 2020-11-12 07:48:45 --> Model Class Initialized
ERROR - 2020-11-12 07:48:45 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 402
ERROR - 2020-11-12 07:48:45 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:48:47 --> Final output sent to browser
DEBUG - 2020-11-12 07:48:47 --> Total execution time: 1.6395
ERROR - 2020-11-12 07:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:49:40 --> Config Class Initialized
INFO - 2020-11-12 07:49:40 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:49:40 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:49:40 --> Utf8 Class Initialized
INFO - 2020-11-12 07:49:40 --> URI Class Initialized
INFO - 2020-11-12 07:49:40 --> Router Class Initialized
INFO - 2020-11-12 07:49:40 --> Output Class Initialized
INFO - 2020-11-12 07:49:40 --> Security Class Initialized
DEBUG - 2020-11-12 07:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:49:40 --> Input Class Initialized
INFO - 2020-11-12 07:49:40 --> Language Class Initialized
INFO - 2020-11-12 07:49:40 --> Loader Class Initialized
INFO - 2020-11-12 07:49:40 --> Helper loaded: url_helper
INFO - 2020-11-12 07:49:40 --> Database Driver Class Initialized
INFO - 2020-11-12 07:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:49:40 --> Email Class Initialized
INFO - 2020-11-12 07:49:40 --> Controller Class Initialized
DEBUG - 2020-11-12 07:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:49:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:49:40 --> Model Class Initialized
INFO - 2020-11-12 07:49:40 --> Model Class Initialized
ERROR - 2020-11-12 07:49:40 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 07:49:40 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-12 07:49:41 --> Final output sent to browser
DEBUG - 2020-11-12 07:49:41 --> Total execution time: 1.9787
ERROR - 2020-11-12 07:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:51:43 --> Config Class Initialized
INFO - 2020-11-12 07:51:43 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:51:43 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:51:43 --> Utf8 Class Initialized
INFO - 2020-11-12 07:51:43 --> URI Class Initialized
INFO - 2020-11-12 07:51:43 --> Router Class Initialized
INFO - 2020-11-12 07:51:43 --> Output Class Initialized
INFO - 2020-11-12 07:51:43 --> Security Class Initialized
DEBUG - 2020-11-12 07:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:51:43 --> Input Class Initialized
INFO - 2020-11-12 07:51:43 --> Language Class Initialized
INFO - 2020-11-12 07:51:43 --> Loader Class Initialized
INFO - 2020-11-12 07:51:43 --> Helper loaded: url_helper
INFO - 2020-11-12 07:51:43 --> Database Driver Class Initialized
INFO - 2020-11-12 07:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:51:43 --> Email Class Initialized
INFO - 2020-11-12 07:51:43 --> Controller Class Initialized
DEBUG - 2020-11-12 07:51:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:51:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:51:43 --> Model Class Initialized
INFO - 2020-11-12 07:51:43 --> Model Class Initialized
ERROR - 2020-11-12 07:51:43 --> Severity: Runtime Notice --> Non-static method Purlem::get_contact() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 07:51:43 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 17
INFO - 2020-11-12 07:51:45 --> Final output sent to browser
DEBUG - 2020-11-12 07:51:45 --> Total execution time: 1.7193
ERROR - 2020-11-12 07:54:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:54:26 --> Config Class Initialized
INFO - 2020-11-12 07:54:26 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:54:26 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:54:26 --> Utf8 Class Initialized
INFO - 2020-11-12 07:54:26 --> URI Class Initialized
INFO - 2020-11-12 07:54:26 --> Router Class Initialized
INFO - 2020-11-12 07:54:26 --> Output Class Initialized
INFO - 2020-11-12 07:54:26 --> Security Class Initialized
DEBUG - 2020-11-12 07:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:54:26 --> Input Class Initialized
INFO - 2020-11-12 07:54:26 --> Language Class Initialized
INFO - 2020-11-12 07:54:26 --> Loader Class Initialized
INFO - 2020-11-12 07:54:26 --> Helper loaded: url_helper
INFO - 2020-11-12 07:54:26 --> Database Driver Class Initialized
INFO - 2020-11-12 07:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:54:26 --> Email Class Initialized
INFO - 2020-11-12 07:54:26 --> Controller Class Initialized
DEBUG - 2020-11-12 07:54:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:54:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:54:26 --> Model Class Initialized
INFO - 2020-11-12 07:54:26 --> Model Class Initialized
ERROR - 2020-11-12 07:54:26 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 406
ERROR - 2020-11-12 07:54:26 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 406 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-12 07:54:26 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-12 07:54:27 --> Final output sent to browser
DEBUG - 2020-11-12 07:54:27 --> Total execution time: 0.9396
ERROR - 2020-11-12 07:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:55:04 --> Config Class Initialized
INFO - 2020-11-12 07:55:04 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:55:04 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:55:04 --> Utf8 Class Initialized
INFO - 2020-11-12 07:55:04 --> URI Class Initialized
INFO - 2020-11-12 07:55:04 --> Router Class Initialized
INFO - 2020-11-12 07:55:04 --> Output Class Initialized
INFO - 2020-11-12 07:55:04 --> Security Class Initialized
DEBUG - 2020-11-12 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:55:04 --> Input Class Initialized
INFO - 2020-11-12 07:55:04 --> Language Class Initialized
INFO - 2020-11-12 07:55:04 --> Loader Class Initialized
INFO - 2020-11-12 07:55:04 --> Helper loaded: url_helper
INFO - 2020-11-12 07:55:04 --> Database Driver Class Initialized
INFO - 2020-11-12 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:55:04 --> Email Class Initialized
INFO - 2020-11-12 07:55:04 --> Controller Class Initialized
DEBUG - 2020-11-12 07:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:55:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:55:04 --> Model Class Initialized
INFO - 2020-11-12 07:55:04 --> Model Class Initialized
ERROR - 2020-11-12 07:55:04 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 406
ERROR - 2020-11-12 07:55:04 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 406 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-12 07:55:04 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-12 07:55:05 --> Final output sent to browser
DEBUG - 2020-11-12 07:55:05 --> Total execution time: 0.9218
ERROR - 2020-11-12 07:55:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:55:17 --> Config Class Initialized
INFO - 2020-11-12 07:55:17 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:55:17 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:55:17 --> Utf8 Class Initialized
INFO - 2020-11-12 07:55:17 --> URI Class Initialized
INFO - 2020-11-12 07:55:17 --> Router Class Initialized
INFO - 2020-11-12 07:55:17 --> Output Class Initialized
INFO - 2020-11-12 07:55:17 --> Security Class Initialized
DEBUG - 2020-11-12 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:55:17 --> Input Class Initialized
INFO - 2020-11-12 07:55:17 --> Language Class Initialized
INFO - 2020-11-12 07:55:17 --> Loader Class Initialized
INFO - 2020-11-12 07:55:17 --> Helper loaded: url_helper
INFO - 2020-11-12 07:55:17 --> Database Driver Class Initialized
INFO - 2020-11-12 07:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:55:17 --> Email Class Initialized
INFO - 2020-11-12 07:55:17 --> Controller Class Initialized
DEBUG - 2020-11-12 07:55:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:55:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:55:17 --> Model Class Initialized
INFO - 2020-11-12 07:55:17 --> Model Class Initialized
ERROR - 2020-11-12 07:55:17 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 406
ERROR - 2020-11-12 07:55:17 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 406 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-12 07:55:17 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-12 07:55:18 --> Final output sent to browser
DEBUG - 2020-11-12 07:55:18 --> Total execution time: 1.0037
ERROR - 2020-11-12 07:55:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:55:20 --> Config Class Initialized
INFO - 2020-11-12 07:55:20 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:55:20 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:55:20 --> Utf8 Class Initialized
INFO - 2020-11-12 07:55:20 --> URI Class Initialized
INFO - 2020-11-12 07:55:20 --> Router Class Initialized
INFO - 2020-11-12 07:55:20 --> Output Class Initialized
INFO - 2020-11-12 07:55:20 --> Security Class Initialized
DEBUG - 2020-11-12 07:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:55:20 --> Input Class Initialized
INFO - 2020-11-12 07:55:20 --> Language Class Initialized
INFO - 2020-11-12 07:55:20 --> Loader Class Initialized
INFO - 2020-11-12 07:55:20 --> Helper loaded: url_helper
INFO - 2020-11-12 07:55:20 --> Database Driver Class Initialized
INFO - 2020-11-12 07:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:55:20 --> Email Class Initialized
INFO - 2020-11-12 07:55:20 --> Controller Class Initialized
DEBUG - 2020-11-12 07:55:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:55:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:55:20 --> Model Class Initialized
INFO - 2020-11-12 07:55:20 --> Model Class Initialized
ERROR - 2020-11-12 07:55:20 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_by() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 406
ERROR - 2020-11-12 07:55:20 --> Severity: Warning --> Missing argument 2 for Purlem::get_many_by(), called in /home/purpu1ex/public_html/carsm/application/controllers/Campain.php on line 406 and defined /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 30
ERROR - 2020-11-12 07:55:20 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 31
INFO - 2020-11-12 07:55:21 --> Final output sent to browser
DEBUG - 2020-11-12 07:55:21 --> Total execution time: 0.9402
ERROR - 2020-11-12 07:58:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:58:25 --> Config Class Initialized
INFO - 2020-11-12 07:58:25 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:58:25 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:58:25 --> Utf8 Class Initialized
INFO - 2020-11-12 07:58:25 --> URI Class Initialized
INFO - 2020-11-12 07:58:25 --> Router Class Initialized
INFO - 2020-11-12 07:58:25 --> Output Class Initialized
INFO - 2020-11-12 07:58:25 --> Security Class Initialized
DEBUG - 2020-11-12 07:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:58:25 --> Input Class Initialized
INFO - 2020-11-12 07:58:25 --> Language Class Initialized
INFO - 2020-11-12 07:58:25 --> Loader Class Initialized
INFO - 2020-11-12 07:58:25 --> Helper loaded: url_helper
INFO - 2020-11-12 07:58:25 --> Database Driver Class Initialized
INFO - 2020-11-12 07:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:58:25 --> Email Class Initialized
INFO - 2020-11-12 07:58:25 --> Controller Class Initialized
DEBUG - 2020-11-12 07:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:58:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:58:25 --> Model Class Initialized
INFO - 2020-11-12 07:58:25 --> Model Class Initialized
ERROR - 2020-11-12 07:58:25 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 07:58:25 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-12 07:58:26 --> Final output sent to browser
DEBUG - 2020-11-12 07:58:26 --> Total execution time: 1.4109
ERROR - 2020-11-12 07:59:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:59:20 --> Config Class Initialized
INFO - 2020-11-12 07:59:20 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:59:20 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:59:20 --> Utf8 Class Initialized
INFO - 2020-11-12 07:59:20 --> URI Class Initialized
INFO - 2020-11-12 07:59:20 --> Router Class Initialized
INFO - 2020-11-12 07:59:20 --> Output Class Initialized
INFO - 2020-11-12 07:59:20 --> Security Class Initialized
DEBUG - 2020-11-12 07:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:59:20 --> Input Class Initialized
INFO - 2020-11-12 07:59:20 --> Language Class Initialized
INFO - 2020-11-12 07:59:20 --> Loader Class Initialized
INFO - 2020-11-12 07:59:20 --> Helper loaded: url_helper
INFO - 2020-11-12 07:59:21 --> Database Driver Class Initialized
INFO - 2020-11-12 07:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:59:21 --> Email Class Initialized
INFO - 2020-11-12 07:59:21 --> Controller Class Initialized
DEBUG - 2020-11-12 07:59:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:59:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:59:21 --> Model Class Initialized
INFO - 2020-11-12 07:59:21 --> Model Class Initialized
ERROR - 2020-11-12 07:59:21 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 07:59:21 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-12 07:59:21 --> Final output sent to browser
DEBUG - 2020-11-12 07:59:21 --> Total execution time: 0.9468
ERROR - 2020-11-12 07:59:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 07:59:37 --> Config Class Initialized
INFO - 2020-11-12 07:59:37 --> Hooks Class Initialized
DEBUG - 2020-11-12 07:59:37 --> UTF-8 Support Enabled
INFO - 2020-11-12 07:59:37 --> Utf8 Class Initialized
INFO - 2020-11-12 07:59:37 --> URI Class Initialized
INFO - 2020-11-12 07:59:37 --> Router Class Initialized
INFO - 2020-11-12 07:59:37 --> Output Class Initialized
INFO - 2020-11-12 07:59:37 --> Security Class Initialized
DEBUG - 2020-11-12 07:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 07:59:37 --> Input Class Initialized
INFO - 2020-11-12 07:59:37 --> Language Class Initialized
INFO - 2020-11-12 07:59:37 --> Loader Class Initialized
INFO - 2020-11-12 07:59:37 --> Helper loaded: url_helper
INFO - 2020-11-12 07:59:37 --> Database Driver Class Initialized
INFO - 2020-11-12 07:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 07:59:37 --> Email Class Initialized
INFO - 2020-11-12 07:59:37 --> Controller Class Initialized
DEBUG - 2020-11-12 07:59:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 07:59:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 07:59:37 --> Model Class Initialized
INFO - 2020-11-12 07:59:37 --> Model Class Initialized
ERROR - 2020-11-12 07:59:37 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 07:59:37 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-12 07:59:40 --> Final output sent to browser
DEBUG - 2020-11-12 07:59:40 --> Total execution time: 3.8741
ERROR - 2020-11-12 08:00:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 08:00:17 --> Config Class Initialized
INFO - 2020-11-12 08:00:17 --> Hooks Class Initialized
DEBUG - 2020-11-12 08:00:17 --> UTF-8 Support Enabled
INFO - 2020-11-12 08:00:17 --> Utf8 Class Initialized
INFO - 2020-11-12 08:00:17 --> URI Class Initialized
INFO - 2020-11-12 08:00:17 --> Router Class Initialized
INFO - 2020-11-12 08:00:17 --> Output Class Initialized
INFO - 2020-11-12 08:00:17 --> Security Class Initialized
DEBUG - 2020-11-12 08:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 08:00:17 --> Input Class Initialized
INFO - 2020-11-12 08:00:17 --> Language Class Initialized
INFO - 2020-11-12 08:00:17 --> Loader Class Initialized
INFO - 2020-11-12 08:00:17 --> Helper loaded: url_helper
INFO - 2020-11-12 08:00:17 --> Database Driver Class Initialized
INFO - 2020-11-12 08:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 08:00:17 --> Email Class Initialized
INFO - 2020-11-12 08:00:17 --> Controller Class Initialized
DEBUG - 2020-11-12 08:00:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 08:00:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 08:00:17 --> Model Class Initialized
INFO - 2020-11-12 08:00:17 --> Model Class Initialized
ERROR - 2020-11-12 08:00:17 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 08:00:17 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-12 08:00:18 --> Final output sent to browser
DEBUG - 2020-11-12 08:00:18 --> Total execution time: 0.9532
ERROR - 2020-11-12 08:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 08:00:40 --> Config Class Initialized
INFO - 2020-11-12 08:00:40 --> Hooks Class Initialized
DEBUG - 2020-11-12 08:00:40 --> UTF-8 Support Enabled
INFO - 2020-11-12 08:00:40 --> Utf8 Class Initialized
INFO - 2020-11-12 08:00:40 --> URI Class Initialized
INFO - 2020-11-12 08:00:40 --> Router Class Initialized
INFO - 2020-11-12 08:00:40 --> Output Class Initialized
INFO - 2020-11-12 08:00:40 --> Security Class Initialized
DEBUG - 2020-11-12 08:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 08:00:40 --> Input Class Initialized
INFO - 2020-11-12 08:00:40 --> Language Class Initialized
INFO - 2020-11-12 08:00:40 --> Loader Class Initialized
INFO - 2020-11-12 08:00:40 --> Helper loaded: url_helper
INFO - 2020-11-12 08:00:40 --> Database Driver Class Initialized
INFO - 2020-11-12 08:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 08:00:40 --> Email Class Initialized
INFO - 2020-11-12 08:00:40 --> Controller Class Initialized
DEBUG - 2020-11-12 08:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 08:00:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 08:00:40 --> Model Class Initialized
INFO - 2020-11-12 08:00:40 --> Model Class Initialized
ERROR - 2020-11-12 08:00:40 --> Severity: Runtime Notice --> Non-static method Purlem::get_many_where_exists() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 08:00:40 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 27
INFO - 2020-11-12 08:00:41 --> Final output sent to browser
DEBUG - 2020-11-12 08:00:41 --> Total execution time: 0.9486
ERROR - 2020-11-12 08:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 08:24:56 --> Config Class Initialized
INFO - 2020-11-12 08:24:56 --> Hooks Class Initialized
DEBUG - 2020-11-12 08:24:56 --> UTF-8 Support Enabled
INFO - 2020-11-12 08:24:56 --> Utf8 Class Initialized
INFO - 2020-11-12 08:24:56 --> URI Class Initialized
INFO - 2020-11-12 08:24:56 --> Router Class Initialized
INFO - 2020-11-12 08:24:56 --> Output Class Initialized
INFO - 2020-11-12 08:24:56 --> Security Class Initialized
DEBUG - 2020-11-12 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 08:24:56 --> Input Class Initialized
INFO - 2020-11-12 08:24:56 --> Language Class Initialized
INFO - 2020-11-12 08:24:56 --> Loader Class Initialized
INFO - 2020-11-12 08:24:56 --> Helper loaded: url_helper
INFO - 2020-11-12 08:24:56 --> Database Driver Class Initialized
INFO - 2020-11-12 08:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 08:24:56 --> Email Class Initialized
INFO - 2020-11-12 08:24:56 --> Controller Class Initialized
DEBUG - 2020-11-12 08:24:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 08:24:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 08:24:56 --> Model Class Initialized
INFO - 2020-11-12 08:24:56 --> Model Class Initialized
ERROR - 2020-11-12 08:24:56 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-12 08:24:56 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-12 08:24:57 --> Final output sent to browser
DEBUG - 2020-11-12 08:24:57 --> Total execution time: 1.2051
ERROR - 2020-11-12 15:43:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:43:13 --> Config Class Initialized
INFO - 2020-11-12 15:43:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:43:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:43:13 --> Utf8 Class Initialized
INFO - 2020-11-12 15:43:13 --> URI Class Initialized
DEBUG - 2020-11-12 15:43:13 --> No URI present. Default controller set.
INFO - 2020-11-12 15:43:13 --> Router Class Initialized
INFO - 2020-11-12 15:43:13 --> Output Class Initialized
INFO - 2020-11-12 15:43:13 --> Security Class Initialized
DEBUG - 2020-11-12 15:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:43:13 --> Input Class Initialized
INFO - 2020-11-12 15:43:13 --> Language Class Initialized
INFO - 2020-11-12 15:43:13 --> Loader Class Initialized
INFO - 2020-11-12 15:43:13 --> Helper loaded: url_helper
INFO - 2020-11-12 15:43:13 --> Database Driver Class Initialized
INFO - 2020-11-12 15:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:43:13 --> Email Class Initialized
INFO - 2020-11-12 15:43:13 --> Controller Class Initialized
INFO - 2020-11-12 15:43:13 --> Model Class Initialized
INFO - 2020-11-12 15:43:13 --> Model Class Initialized
DEBUG - 2020-11-12 15:43:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:43:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-12 15:43:13 --> Final output sent to browser
DEBUG - 2020-11-12 15:43:13 --> Total execution time: 0.0587
ERROR - 2020-11-12 15:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:46:19 --> Config Class Initialized
INFO - 2020-11-12 15:46:19 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:46:19 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:46:19 --> Utf8 Class Initialized
INFO - 2020-11-12 15:46:19 --> URI Class Initialized
INFO - 2020-11-12 15:46:19 --> Router Class Initialized
INFO - 2020-11-12 15:46:19 --> Output Class Initialized
INFO - 2020-11-12 15:46:19 --> Security Class Initialized
DEBUG - 2020-11-12 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:46:19 --> Input Class Initialized
INFO - 2020-11-12 15:46:19 --> Language Class Initialized
INFO - 2020-11-12 15:46:19 --> Loader Class Initialized
INFO - 2020-11-12 15:46:19 --> Helper loaded: url_helper
INFO - 2020-11-12 15:46:19 --> Database Driver Class Initialized
INFO - 2020-11-12 15:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:46:19 --> Email Class Initialized
INFO - 2020-11-12 15:46:19 --> Controller Class Initialized
INFO - 2020-11-12 15:46:19 --> Model Class Initialized
INFO - 2020-11-12 15:46:19 --> Model Class Initialized
DEBUG - 2020-11-12 15:46:19 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-12 15:46:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:46:19 --> Config Class Initialized
INFO - 2020-11-12 15:46:19 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:46:19 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:46:19 --> Utf8 Class Initialized
INFO - 2020-11-12 15:46:19 --> URI Class Initialized
INFO - 2020-11-12 15:46:19 --> Router Class Initialized
INFO - 2020-11-12 15:46:19 --> Output Class Initialized
INFO - 2020-11-12 15:46:19 --> Security Class Initialized
DEBUG - 2020-11-12 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:46:19 --> Input Class Initialized
INFO - 2020-11-12 15:46:19 --> Language Class Initialized
INFO - 2020-11-12 15:46:19 --> Loader Class Initialized
INFO - 2020-11-12 15:46:19 --> Helper loaded: url_helper
INFO - 2020-11-12 15:46:19 --> Database Driver Class Initialized
INFO - 2020-11-12 15:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:46:19 --> Email Class Initialized
INFO - 2020-11-12 15:46:19 --> Controller Class Initialized
INFO - 2020-11-12 15:46:19 --> Model Class Initialized
INFO - 2020-11-12 15:46:19 --> Model Class Initialized
DEBUG - 2020-11-12 15:46:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:46:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:46:19 --> Model Class Initialized
INFO - 2020-11-12 15:46:19 --> Final output sent to browser
DEBUG - 2020-11-12 15:46:19 --> Total execution time: 0.0325
ERROR - 2020-11-12 15:46:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:46:20 --> Config Class Initialized
INFO - 2020-11-12 15:46:20 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:46:20 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:46:20 --> Utf8 Class Initialized
INFO - 2020-11-12 15:46:20 --> URI Class Initialized
INFO - 2020-11-12 15:46:20 --> Router Class Initialized
INFO - 2020-11-12 15:46:20 --> Output Class Initialized
INFO - 2020-11-12 15:46:20 --> Security Class Initialized
DEBUG - 2020-11-12 15:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:46:20 --> Input Class Initialized
INFO - 2020-11-12 15:46:20 --> Language Class Initialized
INFO - 2020-11-12 15:46:20 --> Loader Class Initialized
INFO - 2020-11-12 15:46:20 --> Helper loaded: url_helper
INFO - 2020-11-12 15:46:20 --> Database Driver Class Initialized
INFO - 2020-11-12 15:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:46:20 --> Email Class Initialized
INFO - 2020-11-12 15:46:20 --> Controller Class Initialized
DEBUG - 2020-11-12 15:46:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:46:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:46:20 --> Model Class Initialized
INFO - 2020-11-12 15:46:20 --> Model Class Initialized
INFO - 2020-11-12 15:46:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-12 15:46:20 --> Final output sent to browser
DEBUG - 2020-11-12 15:46:20 --> Total execution time: 0.0555
ERROR - 2020-11-12 15:47:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:47:23 --> Config Class Initialized
INFO - 2020-11-12 15:47:23 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:47:23 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:47:23 --> Utf8 Class Initialized
INFO - 2020-11-12 15:47:23 --> URI Class Initialized
INFO - 2020-11-12 15:47:23 --> Router Class Initialized
INFO - 2020-11-12 15:47:23 --> Output Class Initialized
INFO - 2020-11-12 15:47:23 --> Security Class Initialized
DEBUG - 2020-11-12 15:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:47:23 --> Input Class Initialized
INFO - 2020-11-12 15:47:23 --> Language Class Initialized
INFO - 2020-11-12 15:47:23 --> Loader Class Initialized
INFO - 2020-11-12 15:47:23 --> Helper loaded: url_helper
INFO - 2020-11-12 15:47:23 --> Database Driver Class Initialized
INFO - 2020-11-12 15:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:47:23 --> Email Class Initialized
INFO - 2020-11-12 15:47:23 --> Controller Class Initialized
DEBUG - 2020-11-12 15:47:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:47:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:47:23 --> Model Class Initialized
INFO - 2020-11-12 15:47:23 --> Model Class Initialized
INFO - 2020-11-12 15:47:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-12 15:47:23 --> Final output sent to browser
DEBUG - 2020-11-12 15:47:23 --> Total execution time: 0.0398
ERROR - 2020-11-12 15:47:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:47:41 --> Config Class Initialized
INFO - 2020-11-12 15:47:41 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:47:41 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:47:41 --> Utf8 Class Initialized
INFO - 2020-11-12 15:47:41 --> URI Class Initialized
INFO - 2020-11-12 15:47:41 --> Router Class Initialized
INFO - 2020-11-12 15:47:41 --> Output Class Initialized
INFO - 2020-11-12 15:47:41 --> Security Class Initialized
DEBUG - 2020-11-12 15:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:47:41 --> Input Class Initialized
INFO - 2020-11-12 15:47:41 --> Language Class Initialized
INFO - 2020-11-12 15:47:41 --> Loader Class Initialized
INFO - 2020-11-12 15:47:41 --> Helper loaded: url_helper
INFO - 2020-11-12 15:47:41 --> Database Driver Class Initialized
INFO - 2020-11-12 15:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:47:41 --> Email Class Initialized
INFO - 2020-11-12 15:47:41 --> Controller Class Initialized
DEBUG - 2020-11-12 15:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:47:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:47:41 --> Model Class Initialized
INFO - 2020-11-12 15:47:41 --> Model Class Initialized
ERROR - 2020-11-12 15:47:41 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 15:47:41 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 15:47:42 --> Final output sent to browser
DEBUG - 2020-11-12 15:47:42 --> Total execution time: 1.2634
ERROR - 2020-11-12 15:52:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:52:44 --> Config Class Initialized
INFO - 2020-11-12 15:52:44 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:52:44 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:52:44 --> Utf8 Class Initialized
INFO - 2020-11-12 15:52:44 --> URI Class Initialized
INFO - 2020-11-12 15:52:44 --> Router Class Initialized
INFO - 2020-11-12 15:52:44 --> Output Class Initialized
INFO - 2020-11-12 15:52:44 --> Security Class Initialized
DEBUG - 2020-11-12 15:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:52:44 --> Input Class Initialized
INFO - 2020-11-12 15:52:44 --> Language Class Initialized
INFO - 2020-11-12 15:52:44 --> Loader Class Initialized
INFO - 2020-11-12 15:52:44 --> Helper loaded: url_helper
INFO - 2020-11-12 15:52:44 --> Database Driver Class Initialized
INFO - 2020-11-12 15:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:52:44 --> Email Class Initialized
INFO - 2020-11-12 15:52:44 --> Controller Class Initialized
DEBUG - 2020-11-12 15:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:52:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:52:44 --> Model Class Initialized
INFO - 2020-11-12 15:52:44 --> Model Class Initialized
ERROR - 2020-11-12 15:52:44 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 15:52:44 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 15:52:45 --> Final output sent to browser
DEBUG - 2020-11-12 15:52:45 --> Total execution time: 0.9805
ERROR - 2020-11-12 15:52:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:52:57 --> Config Class Initialized
INFO - 2020-11-12 15:52:57 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:52:57 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:52:57 --> Utf8 Class Initialized
INFO - 2020-11-12 15:52:57 --> URI Class Initialized
INFO - 2020-11-12 15:52:57 --> Router Class Initialized
INFO - 2020-11-12 15:52:57 --> Output Class Initialized
INFO - 2020-11-12 15:52:57 --> Security Class Initialized
DEBUG - 2020-11-12 15:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:52:57 --> Input Class Initialized
INFO - 2020-11-12 15:52:57 --> Language Class Initialized
INFO - 2020-11-12 15:52:57 --> Loader Class Initialized
INFO - 2020-11-12 15:52:57 --> Helper loaded: url_helper
INFO - 2020-11-12 15:52:57 --> Database Driver Class Initialized
INFO - 2020-11-12 15:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:52:57 --> Email Class Initialized
INFO - 2020-11-12 15:52:57 --> Controller Class Initialized
DEBUG - 2020-11-12 15:52:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:52:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:52:57 --> Model Class Initialized
INFO - 2020-11-12 15:52:57 --> Model Class Initialized
INFO - 2020-11-12 15:52:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-12 15:52:57 --> Final output sent to browser
DEBUG - 2020-11-12 15:52:57 --> Total execution time: 0.0699
ERROR - 2020-11-12 15:54:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:54:18 --> Config Class Initialized
INFO - 2020-11-12 15:54:18 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:54:18 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:54:18 --> Utf8 Class Initialized
INFO - 2020-11-12 15:54:18 --> URI Class Initialized
INFO - 2020-11-12 15:54:18 --> Router Class Initialized
INFO - 2020-11-12 15:54:18 --> Output Class Initialized
INFO - 2020-11-12 15:54:18 --> Security Class Initialized
DEBUG - 2020-11-12 15:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:54:18 --> Input Class Initialized
INFO - 2020-11-12 15:54:18 --> Language Class Initialized
INFO - 2020-11-12 15:54:18 --> Loader Class Initialized
INFO - 2020-11-12 15:54:18 --> Helper loaded: url_helper
INFO - 2020-11-12 15:54:18 --> Database Driver Class Initialized
INFO - 2020-11-12 15:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:54:18 --> Email Class Initialized
INFO - 2020-11-12 15:54:18 --> Controller Class Initialized
DEBUG - 2020-11-12 15:54:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:54:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:54:18 --> Model Class Initialized
INFO - 2020-11-12 15:54:18 --> Model Class Initialized
ERROR - 2020-11-12 15:54:18 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 15:54:18 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 15:54:19 --> Final output sent to browser
DEBUG - 2020-11-12 15:54:19 --> Total execution time: 0.9611
ERROR - 2020-11-12 15:54:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:54:25 --> Config Class Initialized
INFO - 2020-11-12 15:54:25 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:54:25 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:54:25 --> Utf8 Class Initialized
INFO - 2020-11-12 15:54:25 --> URI Class Initialized
INFO - 2020-11-12 15:54:25 --> Router Class Initialized
INFO - 2020-11-12 15:54:25 --> Output Class Initialized
INFO - 2020-11-12 15:54:25 --> Security Class Initialized
DEBUG - 2020-11-12 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:54:25 --> Input Class Initialized
INFO - 2020-11-12 15:54:25 --> Language Class Initialized
INFO - 2020-11-12 15:54:25 --> Loader Class Initialized
INFO - 2020-11-12 15:54:25 --> Helper loaded: url_helper
INFO - 2020-11-12 15:54:25 --> Database Driver Class Initialized
INFO - 2020-11-12 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:54:25 --> Email Class Initialized
INFO - 2020-11-12 15:54:25 --> Controller Class Initialized
DEBUG - 2020-11-12 15:54:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:54:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:54:25 --> Model Class Initialized
INFO - 2020-11-12 15:54:25 --> Model Class Initialized
ERROR - 2020-11-12 15:54:25 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 15:54:25 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 15:54:26 --> Final output sent to browser
DEBUG - 2020-11-12 15:54:26 --> Total execution time: 1.0031
ERROR - 2020-11-12 15:54:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:54:34 --> Config Class Initialized
INFO - 2020-11-12 15:54:34 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:54:34 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:54:34 --> Utf8 Class Initialized
INFO - 2020-11-12 15:54:34 --> URI Class Initialized
INFO - 2020-11-12 15:54:34 --> Router Class Initialized
INFO - 2020-11-12 15:54:34 --> Output Class Initialized
INFO - 2020-11-12 15:54:34 --> Security Class Initialized
DEBUG - 2020-11-12 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:54:34 --> Input Class Initialized
INFO - 2020-11-12 15:54:34 --> Language Class Initialized
INFO - 2020-11-12 15:54:34 --> Loader Class Initialized
INFO - 2020-11-12 15:54:34 --> Helper loaded: url_helper
INFO - 2020-11-12 15:54:34 --> Database Driver Class Initialized
INFO - 2020-11-12 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:54:34 --> Email Class Initialized
INFO - 2020-11-12 15:54:34 --> Controller Class Initialized
DEBUG - 2020-11-12 15:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:54:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:54:34 --> Model Class Initialized
INFO - 2020-11-12 15:54:34 --> Model Class Initialized
ERROR - 2020-11-12 15:54:34 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 15:54:34 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 15:54:35 --> Final output sent to browser
DEBUG - 2020-11-12 15:54:35 --> Total execution time: 0.9388
ERROR - 2020-11-12 15:56:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 15:56:08 --> Config Class Initialized
INFO - 2020-11-12 15:56:08 --> Hooks Class Initialized
DEBUG - 2020-11-12 15:56:08 --> UTF-8 Support Enabled
INFO - 2020-11-12 15:56:08 --> Utf8 Class Initialized
INFO - 2020-11-12 15:56:08 --> URI Class Initialized
INFO - 2020-11-12 15:56:08 --> Router Class Initialized
INFO - 2020-11-12 15:56:08 --> Output Class Initialized
INFO - 2020-11-12 15:56:08 --> Security Class Initialized
DEBUG - 2020-11-12 15:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 15:56:08 --> Input Class Initialized
INFO - 2020-11-12 15:56:08 --> Language Class Initialized
INFO - 2020-11-12 15:56:08 --> Loader Class Initialized
INFO - 2020-11-12 15:56:08 --> Helper loaded: url_helper
INFO - 2020-11-12 15:56:08 --> Database Driver Class Initialized
INFO - 2020-11-12 15:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 15:56:08 --> Email Class Initialized
INFO - 2020-11-12 15:56:08 --> Controller Class Initialized
DEBUG - 2020-11-12 15:56:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 15:56:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 15:56:08 --> Model Class Initialized
INFO - 2020-11-12 15:56:08 --> Model Class Initialized
ERROR - 2020-11-12 15:56:08 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 15:56:08 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 15:56:09 --> Final output sent to browser
DEBUG - 2020-11-12 15:56:09 --> Total execution time: 0.9639
ERROR - 2020-11-12 16:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:00:55 --> Config Class Initialized
INFO - 2020-11-12 16:00:55 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:00:55 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:00:55 --> Utf8 Class Initialized
INFO - 2020-11-12 16:00:55 --> URI Class Initialized
INFO - 2020-11-12 16:00:55 --> Router Class Initialized
INFO - 2020-11-12 16:00:55 --> Output Class Initialized
INFO - 2020-11-12 16:00:55 --> Security Class Initialized
DEBUG - 2020-11-12 16:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:00:55 --> Input Class Initialized
INFO - 2020-11-12 16:00:55 --> Language Class Initialized
INFO - 2020-11-12 16:00:55 --> Loader Class Initialized
INFO - 2020-11-12 16:00:55 --> Helper loaded: url_helper
INFO - 2020-11-12 16:00:55 --> Database Driver Class Initialized
INFO - 2020-11-12 16:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:00:55 --> Email Class Initialized
INFO - 2020-11-12 16:00:55 --> Controller Class Initialized
DEBUG - 2020-11-12 16:00:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:00:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:00:55 --> Model Class Initialized
INFO - 2020-11-12 16:00:55 --> Model Class Initialized
ERROR - 2020-11-12 16:00:55 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:00:55 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:00:56 --> Final output sent to browser
DEBUG - 2020-11-12 16:00:56 --> Total execution time: 1.0068
ERROR - 2020-11-12 16:02:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:02:20 --> Config Class Initialized
INFO - 2020-11-12 16:02:20 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:02:20 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:02:20 --> Utf8 Class Initialized
INFO - 2020-11-12 16:02:20 --> URI Class Initialized
INFO - 2020-11-12 16:02:20 --> Router Class Initialized
INFO - 2020-11-12 16:02:20 --> Output Class Initialized
INFO - 2020-11-12 16:02:20 --> Security Class Initialized
DEBUG - 2020-11-12 16:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:02:20 --> Input Class Initialized
INFO - 2020-11-12 16:02:20 --> Language Class Initialized
INFO - 2020-11-12 16:02:20 --> Loader Class Initialized
INFO - 2020-11-12 16:02:20 --> Helper loaded: url_helper
INFO - 2020-11-12 16:02:20 --> Database Driver Class Initialized
INFO - 2020-11-12 16:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:02:20 --> Email Class Initialized
INFO - 2020-11-12 16:02:20 --> Controller Class Initialized
DEBUG - 2020-11-12 16:02:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:02:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:02:20 --> Model Class Initialized
INFO - 2020-11-12 16:02:20 --> Model Class Initialized
ERROR - 2020-11-12 16:02:20 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:02:20 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:02:21 --> Final output sent to browser
DEBUG - 2020-11-12 16:02:21 --> Total execution time: 1.0378
ERROR - 2020-11-12 16:19:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:19:36 --> Config Class Initialized
INFO - 2020-11-12 16:19:36 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:19:36 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:19:36 --> Utf8 Class Initialized
INFO - 2020-11-12 16:19:36 --> URI Class Initialized
INFO - 2020-11-12 16:19:36 --> Router Class Initialized
INFO - 2020-11-12 16:19:36 --> Output Class Initialized
INFO - 2020-11-12 16:19:36 --> Security Class Initialized
DEBUG - 2020-11-12 16:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:19:36 --> Input Class Initialized
INFO - 2020-11-12 16:19:36 --> Language Class Initialized
INFO - 2020-11-12 16:19:36 --> Loader Class Initialized
INFO - 2020-11-12 16:19:36 --> Helper loaded: url_helper
INFO - 2020-11-12 16:19:36 --> Database Driver Class Initialized
INFO - 2020-11-12 16:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:19:36 --> Email Class Initialized
INFO - 2020-11-12 16:19:36 --> Controller Class Initialized
DEBUG - 2020-11-12 16:19:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:19:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:19:36 --> Model Class Initialized
INFO - 2020-11-12 16:19:36 --> Model Class Initialized
ERROR - 2020-11-12 16:19:36 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:19:36 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:19:38 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.campaign_data_id; expected 1, got 0 - Invalid query: CALL campaign_data_id()
INFO - 2020-11-12 16:19:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-11-12 16:19:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-12 16:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:20:54 --> Config Class Initialized
INFO - 2020-11-12 16:20:54 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:20:54 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:20:54 --> Utf8 Class Initialized
INFO - 2020-11-12 16:20:54 --> URI Class Initialized
INFO - 2020-11-12 16:20:54 --> Router Class Initialized
INFO - 2020-11-12 16:20:54 --> Output Class Initialized
INFO - 2020-11-12 16:20:54 --> Security Class Initialized
DEBUG - 2020-11-12 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:20:54 --> Input Class Initialized
INFO - 2020-11-12 16:20:54 --> Language Class Initialized
INFO - 2020-11-12 16:20:54 --> Loader Class Initialized
INFO - 2020-11-12 16:20:54 --> Helper loaded: url_helper
INFO - 2020-11-12 16:20:54 --> Database Driver Class Initialized
INFO - 2020-11-12 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:20:54 --> Email Class Initialized
INFO - 2020-11-12 16:20:54 --> Controller Class Initialized
DEBUG - 2020-11-12 16:20:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:20:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:20:54 --> Model Class Initialized
INFO - 2020-11-12 16:20:54 --> Model Class Initialized
ERROR - 2020-11-12 16:20:54 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:20:54 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:20:55 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.campaign_data_id; expected 1, got 0 - Invalid query: CALL campaign_data_id()
INFO - 2020-11-12 16:20:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-11-12 16:20:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-11-12 16:22:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:22:13 --> Config Class Initialized
INFO - 2020-11-12 16:22:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:22:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:22:13 --> Utf8 Class Initialized
INFO - 2020-11-12 16:22:13 --> URI Class Initialized
INFO - 2020-11-12 16:22:13 --> Router Class Initialized
INFO - 2020-11-12 16:22:13 --> Output Class Initialized
INFO - 2020-11-12 16:22:13 --> Security Class Initialized
DEBUG - 2020-11-12 16:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:22:13 --> Input Class Initialized
INFO - 2020-11-12 16:22:13 --> Language Class Initialized
INFO - 2020-11-12 16:22:13 --> Loader Class Initialized
INFO - 2020-11-12 16:22:13 --> Helper loaded: url_helper
INFO - 2020-11-12 16:22:13 --> Database Driver Class Initialized
INFO - 2020-11-12 16:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:22:13 --> Email Class Initialized
INFO - 2020-11-12 16:22:13 --> Controller Class Initialized
DEBUG - 2020-11-12 16:22:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:22:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:22:13 --> Model Class Initialized
INFO - 2020-11-12 16:22:13 --> Model Class Initialized
ERROR - 2020-11-12 16:22:13 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:22:13 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:22:14 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:22:14 --> Final output sent to browser
DEBUG - 2020-11-12 16:22:14 --> Total execution time: 1.0409
ERROR - 2020-11-12 16:22:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:22:43 --> Config Class Initialized
INFO - 2020-11-12 16:22:43 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:22:43 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:22:43 --> Utf8 Class Initialized
INFO - 2020-11-12 16:22:43 --> URI Class Initialized
INFO - 2020-11-12 16:22:43 --> Router Class Initialized
INFO - 2020-11-12 16:22:43 --> Output Class Initialized
INFO - 2020-11-12 16:22:43 --> Security Class Initialized
DEBUG - 2020-11-12 16:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:22:43 --> Input Class Initialized
INFO - 2020-11-12 16:22:43 --> Language Class Initialized
INFO - 2020-11-12 16:22:43 --> Loader Class Initialized
INFO - 2020-11-12 16:22:43 --> Helper loaded: url_helper
INFO - 2020-11-12 16:22:43 --> Database Driver Class Initialized
INFO - 2020-11-12 16:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:22:43 --> Email Class Initialized
INFO - 2020-11-12 16:22:43 --> Controller Class Initialized
DEBUG - 2020-11-12 16:22:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:22:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:22:43 --> Model Class Initialized
INFO - 2020-11-12 16:22:43 --> Model Class Initialized
ERROR - 2020-11-12 16:22:43 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:22:43 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:22:44 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:22:44 --> Final output sent to browser
DEBUG - 2020-11-12 16:22:44 --> Total execution time: 0.9515
ERROR - 2020-11-12 16:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:23:29 --> Config Class Initialized
INFO - 2020-11-12 16:23:29 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:23:29 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:23:29 --> Utf8 Class Initialized
INFO - 2020-11-12 16:23:29 --> URI Class Initialized
INFO - 2020-11-12 16:23:29 --> Router Class Initialized
INFO - 2020-11-12 16:23:29 --> Output Class Initialized
INFO - 2020-11-12 16:23:29 --> Security Class Initialized
DEBUG - 2020-11-12 16:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:23:29 --> Input Class Initialized
INFO - 2020-11-12 16:23:29 --> Language Class Initialized
INFO - 2020-11-12 16:23:29 --> Loader Class Initialized
INFO - 2020-11-12 16:23:29 --> Helper loaded: url_helper
INFO - 2020-11-12 16:23:29 --> Database Driver Class Initialized
INFO - 2020-11-12 16:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:23:29 --> Email Class Initialized
INFO - 2020-11-12 16:23:29 --> Controller Class Initialized
DEBUG - 2020-11-12 16:23:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:23:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:23:29 --> Model Class Initialized
INFO - 2020-11-12 16:23:29 --> Model Class Initialized
ERROR - 2020-11-12 16:23:29 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:23:29 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:23:30 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:23:30 --> Final output sent to browser
DEBUG - 2020-11-12 16:23:30 --> Total execution time: 1.0281
ERROR - 2020-11-12 16:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:32:03 --> Config Class Initialized
INFO - 2020-11-12 16:32:03 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:32:03 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:32:03 --> Utf8 Class Initialized
INFO - 2020-11-12 16:32:03 --> URI Class Initialized
INFO - 2020-11-12 16:32:03 --> Router Class Initialized
INFO - 2020-11-12 16:32:03 --> Output Class Initialized
INFO - 2020-11-12 16:32:03 --> Security Class Initialized
DEBUG - 2020-11-12 16:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:32:03 --> Input Class Initialized
INFO - 2020-11-12 16:32:03 --> Language Class Initialized
INFO - 2020-11-12 16:32:03 --> Loader Class Initialized
INFO - 2020-11-12 16:32:03 --> Helper loaded: url_helper
INFO - 2020-11-12 16:32:03 --> Database Driver Class Initialized
INFO - 2020-11-12 16:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:32:03 --> Email Class Initialized
INFO - 2020-11-12 16:32:03 --> Controller Class Initialized
DEBUG - 2020-11-12 16:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:32:03 --> Model Class Initialized
INFO - 2020-11-12 16:32:03 --> Model Class Initialized
ERROR - 2020-11-12 16:32:03 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:32:03 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:32:04 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:32:04 --> Final output sent to browser
DEBUG - 2020-11-12 16:32:04 --> Total execution time: 0.9323
ERROR - 2020-11-12 16:33:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:33:40 --> Config Class Initialized
INFO - 2020-11-12 16:33:40 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:33:40 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:33:40 --> Utf8 Class Initialized
INFO - 2020-11-12 16:33:40 --> URI Class Initialized
INFO - 2020-11-12 16:33:40 --> Router Class Initialized
INFO - 2020-11-12 16:33:40 --> Output Class Initialized
INFO - 2020-11-12 16:33:40 --> Security Class Initialized
DEBUG - 2020-11-12 16:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:33:40 --> Input Class Initialized
INFO - 2020-11-12 16:33:40 --> Language Class Initialized
INFO - 2020-11-12 16:33:40 --> Loader Class Initialized
INFO - 2020-11-12 16:33:40 --> Helper loaded: url_helper
INFO - 2020-11-12 16:33:40 --> Database Driver Class Initialized
INFO - 2020-11-12 16:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:33:40 --> Email Class Initialized
INFO - 2020-11-12 16:33:40 --> Controller Class Initialized
DEBUG - 2020-11-12 16:33:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:33:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:33:40 --> Model Class Initialized
INFO - 2020-11-12 16:33:40 --> Model Class Initialized
ERROR - 2020-11-12 16:33:40 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:33:40 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:33:41 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:33:41 --> Final output sent to browser
DEBUG - 2020-11-12 16:33:41 --> Total execution time: 0.9478
ERROR - 2020-11-12 16:33:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:33:44 --> Config Class Initialized
INFO - 2020-11-12 16:33:44 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:33:44 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:33:44 --> Utf8 Class Initialized
INFO - 2020-11-12 16:33:44 --> URI Class Initialized
INFO - 2020-11-12 16:33:44 --> Router Class Initialized
INFO - 2020-11-12 16:33:44 --> Output Class Initialized
INFO - 2020-11-12 16:33:44 --> Security Class Initialized
DEBUG - 2020-11-12 16:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:33:44 --> Input Class Initialized
INFO - 2020-11-12 16:33:44 --> Language Class Initialized
INFO - 2020-11-12 16:33:44 --> Loader Class Initialized
INFO - 2020-11-12 16:33:44 --> Helper loaded: url_helper
INFO - 2020-11-12 16:33:44 --> Database Driver Class Initialized
INFO - 2020-11-12 16:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:33:44 --> Email Class Initialized
INFO - 2020-11-12 16:33:44 --> Controller Class Initialized
DEBUG - 2020-11-12 16:33:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:33:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:33:44 --> Model Class Initialized
INFO - 2020-11-12 16:33:44 --> Model Class Initialized
ERROR - 2020-11-12 16:33:44 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:33:44 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:33:45 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:33:45 --> Final output sent to browser
DEBUG - 2020-11-12 16:33:45 --> Total execution time: 0.9842
ERROR - 2020-11-12 16:34:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:34:19 --> Config Class Initialized
INFO - 2020-11-12 16:34:19 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:34:19 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:34:19 --> Utf8 Class Initialized
INFO - 2020-11-12 16:34:19 --> URI Class Initialized
INFO - 2020-11-12 16:34:19 --> Router Class Initialized
INFO - 2020-11-12 16:34:19 --> Output Class Initialized
INFO - 2020-11-12 16:34:19 --> Security Class Initialized
DEBUG - 2020-11-12 16:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:34:19 --> Input Class Initialized
INFO - 2020-11-12 16:34:19 --> Language Class Initialized
INFO - 2020-11-12 16:34:19 --> Loader Class Initialized
INFO - 2020-11-12 16:34:19 --> Helper loaded: url_helper
INFO - 2020-11-12 16:34:19 --> Database Driver Class Initialized
INFO - 2020-11-12 16:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:34:19 --> Email Class Initialized
INFO - 2020-11-12 16:34:19 --> Controller Class Initialized
DEBUG - 2020-11-12 16:34:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:34:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:34:19 --> Model Class Initialized
INFO - 2020-11-12 16:34:19 --> Model Class Initialized
ERROR - 2020-11-12 16:34:19 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:34:19 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:34:20 --> Final output sent to browser
DEBUG - 2020-11-12 16:34:20 --> Total execution time: 0.9402
ERROR - 2020-11-12 16:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:37:04 --> Config Class Initialized
INFO - 2020-11-12 16:37:04 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:37:04 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:37:04 --> Utf8 Class Initialized
INFO - 2020-11-12 16:37:04 --> URI Class Initialized
INFO - 2020-11-12 16:37:04 --> Router Class Initialized
INFO - 2020-11-12 16:37:04 --> Output Class Initialized
INFO - 2020-11-12 16:37:04 --> Security Class Initialized
DEBUG - 2020-11-12 16:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:37:04 --> Input Class Initialized
INFO - 2020-11-12 16:37:04 --> Language Class Initialized
INFO - 2020-11-12 16:37:04 --> Loader Class Initialized
INFO - 2020-11-12 16:37:04 --> Helper loaded: url_helper
INFO - 2020-11-12 16:37:04 --> Database Driver Class Initialized
INFO - 2020-11-12 16:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:37:04 --> Email Class Initialized
INFO - 2020-11-12 16:37:04 --> Controller Class Initialized
DEBUG - 2020-11-12 16:37:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:37:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:37:04 --> Model Class Initialized
INFO - 2020-11-12 16:37:04 --> Model Class Initialized
ERROR - 2020-11-12 16:37:04 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:37:04 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:37:05 --> Final output sent to browser
DEBUG - 2020-11-12 16:37:05 --> Total execution time: 0.9565
ERROR - 2020-11-12 16:38:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:38:15 --> Config Class Initialized
INFO - 2020-11-12 16:38:15 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:38:15 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:38:15 --> Utf8 Class Initialized
INFO - 2020-11-12 16:38:15 --> URI Class Initialized
INFO - 2020-11-12 16:38:15 --> Router Class Initialized
INFO - 2020-11-12 16:38:15 --> Output Class Initialized
INFO - 2020-11-12 16:38:15 --> Security Class Initialized
DEBUG - 2020-11-12 16:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:38:15 --> Input Class Initialized
INFO - 2020-11-12 16:38:15 --> Language Class Initialized
INFO - 2020-11-12 16:38:15 --> Loader Class Initialized
INFO - 2020-11-12 16:38:15 --> Helper loaded: url_helper
INFO - 2020-11-12 16:38:15 --> Database Driver Class Initialized
INFO - 2020-11-12 16:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:38:15 --> Email Class Initialized
INFO - 2020-11-12 16:38:15 --> Controller Class Initialized
DEBUG - 2020-11-12 16:38:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:38:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:38:15 --> Model Class Initialized
INFO - 2020-11-12 16:38:15 --> Model Class Initialized
ERROR - 2020-11-12 16:38:15 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:38:15 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:38:16 --> Final output sent to browser
DEBUG - 2020-11-12 16:38:16 --> Total execution time: 0.9811
ERROR - 2020-11-12 16:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:38:22 --> Config Class Initialized
INFO - 2020-11-12 16:38:22 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:38:22 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:38:22 --> Utf8 Class Initialized
INFO - 2020-11-12 16:38:22 --> URI Class Initialized
INFO - 2020-11-12 16:38:22 --> Router Class Initialized
INFO - 2020-11-12 16:38:22 --> Output Class Initialized
INFO - 2020-11-12 16:38:22 --> Security Class Initialized
DEBUG - 2020-11-12 16:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:38:22 --> Input Class Initialized
INFO - 2020-11-12 16:38:22 --> Language Class Initialized
INFO - 2020-11-12 16:38:22 --> Loader Class Initialized
INFO - 2020-11-12 16:38:22 --> Helper loaded: url_helper
INFO - 2020-11-12 16:38:22 --> Database Driver Class Initialized
INFO - 2020-11-12 16:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:38:22 --> Email Class Initialized
INFO - 2020-11-12 16:38:22 --> Controller Class Initialized
DEBUG - 2020-11-12 16:38:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:38:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:38:22 --> Model Class Initialized
INFO - 2020-11-12 16:38:22 --> Model Class Initialized
ERROR - 2020-11-12 16:38:22 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:38:22 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:38:23 --> Final output sent to browser
DEBUG - 2020-11-12 16:38:23 --> Total execution time: 0.9870
ERROR - 2020-11-12 16:38:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:38:48 --> Config Class Initialized
INFO - 2020-11-12 16:38:48 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:38:48 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:38:48 --> Utf8 Class Initialized
INFO - 2020-11-12 16:38:48 --> URI Class Initialized
INFO - 2020-11-12 16:38:48 --> Router Class Initialized
INFO - 2020-11-12 16:38:48 --> Output Class Initialized
INFO - 2020-11-12 16:38:48 --> Security Class Initialized
DEBUG - 2020-11-12 16:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:38:48 --> Input Class Initialized
INFO - 2020-11-12 16:38:48 --> Language Class Initialized
INFO - 2020-11-12 16:38:48 --> Loader Class Initialized
INFO - 2020-11-12 16:38:48 --> Helper loaded: url_helper
INFO - 2020-11-12 16:38:48 --> Database Driver Class Initialized
INFO - 2020-11-12 16:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:38:48 --> Email Class Initialized
INFO - 2020-11-12 16:38:48 --> Controller Class Initialized
DEBUG - 2020-11-12 16:38:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:38:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:38:48 --> Model Class Initialized
INFO - 2020-11-12 16:38:48 --> Model Class Initialized
ERROR - 2020-11-12 16:38:48 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:38:48 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:38:49 --> Final output sent to browser
DEBUG - 2020-11-12 16:38:49 --> Total execution time: 0.9514
ERROR - 2020-11-12 16:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:40:16 --> Config Class Initialized
INFO - 2020-11-12 16:40:16 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:40:16 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:40:16 --> Utf8 Class Initialized
INFO - 2020-11-12 16:40:16 --> URI Class Initialized
INFO - 2020-11-12 16:40:16 --> Router Class Initialized
INFO - 2020-11-12 16:40:16 --> Output Class Initialized
INFO - 2020-11-12 16:40:16 --> Security Class Initialized
DEBUG - 2020-11-12 16:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:40:16 --> Input Class Initialized
INFO - 2020-11-12 16:40:16 --> Language Class Initialized
INFO - 2020-11-12 16:40:16 --> Loader Class Initialized
INFO - 2020-11-12 16:40:16 --> Helper loaded: url_helper
INFO - 2020-11-12 16:40:16 --> Database Driver Class Initialized
INFO - 2020-11-12 16:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:40:16 --> Email Class Initialized
INFO - 2020-11-12 16:40:16 --> Controller Class Initialized
DEBUG - 2020-11-12 16:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:40:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:40:16 --> Model Class Initialized
INFO - 2020-11-12 16:40:16 --> Model Class Initialized
ERROR - 2020-11-12 16:40:16 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:40:16 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:40:17 --> Final output sent to browser
DEBUG - 2020-11-12 16:40:17 --> Total execution time: 0.9640
ERROR - 2020-11-12 16:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:40:43 --> Config Class Initialized
INFO - 2020-11-12 16:40:43 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:40:43 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:40:43 --> Utf8 Class Initialized
INFO - 2020-11-12 16:40:43 --> URI Class Initialized
INFO - 2020-11-12 16:40:43 --> Router Class Initialized
INFO - 2020-11-12 16:40:43 --> Output Class Initialized
INFO - 2020-11-12 16:40:43 --> Security Class Initialized
DEBUG - 2020-11-12 16:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:40:43 --> Input Class Initialized
INFO - 2020-11-12 16:40:43 --> Language Class Initialized
INFO - 2020-11-12 16:40:43 --> Loader Class Initialized
INFO - 2020-11-12 16:40:43 --> Helper loaded: url_helper
INFO - 2020-11-12 16:40:43 --> Database Driver Class Initialized
INFO - 2020-11-12 16:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:40:43 --> Email Class Initialized
INFO - 2020-11-12 16:40:43 --> Controller Class Initialized
DEBUG - 2020-11-12 16:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:40:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:40:43 --> Model Class Initialized
INFO - 2020-11-12 16:40:43 --> Model Class Initialized
ERROR - 2020-11-12 16:40:43 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:40:43 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:40:44 --> Final output sent to browser
DEBUG - 2020-11-12 16:40:44 --> Total execution time: 0.9428
ERROR - 2020-11-12 16:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:41:14 --> Config Class Initialized
INFO - 2020-11-12 16:41:14 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:41:14 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:41:14 --> Utf8 Class Initialized
INFO - 2020-11-12 16:41:14 --> URI Class Initialized
INFO - 2020-11-12 16:41:14 --> Router Class Initialized
INFO - 2020-11-12 16:41:14 --> Output Class Initialized
INFO - 2020-11-12 16:41:14 --> Security Class Initialized
DEBUG - 2020-11-12 16:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:41:14 --> Input Class Initialized
INFO - 2020-11-12 16:41:14 --> Language Class Initialized
INFO - 2020-11-12 16:41:14 --> Loader Class Initialized
INFO - 2020-11-12 16:41:14 --> Helper loaded: url_helper
INFO - 2020-11-12 16:41:14 --> Database Driver Class Initialized
INFO - 2020-11-12 16:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:41:14 --> Email Class Initialized
INFO - 2020-11-12 16:41:14 --> Controller Class Initialized
DEBUG - 2020-11-12 16:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:41:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:41:14 --> Model Class Initialized
INFO - 2020-11-12 16:41:14 --> Model Class Initialized
ERROR - 2020-11-12 16:41:14 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:41:14 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:41:15 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:41:15 --> Final output sent to browser
DEBUG - 2020-11-12 16:41:15 --> Total execution time: 0.9533
ERROR - 2020-11-12 16:41:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:41:41 --> Config Class Initialized
INFO - 2020-11-12 16:41:41 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:41:41 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:41:41 --> Utf8 Class Initialized
INFO - 2020-11-12 16:41:41 --> URI Class Initialized
INFO - 2020-11-12 16:41:41 --> Router Class Initialized
INFO - 2020-11-12 16:41:41 --> Output Class Initialized
INFO - 2020-11-12 16:41:41 --> Security Class Initialized
DEBUG - 2020-11-12 16:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:41:41 --> Input Class Initialized
INFO - 2020-11-12 16:41:41 --> Language Class Initialized
INFO - 2020-11-12 16:41:41 --> Loader Class Initialized
INFO - 2020-11-12 16:41:41 --> Helper loaded: url_helper
INFO - 2020-11-12 16:41:41 --> Database Driver Class Initialized
INFO - 2020-11-12 16:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:41:41 --> Email Class Initialized
INFO - 2020-11-12 16:41:41 --> Controller Class Initialized
DEBUG - 2020-11-12 16:41:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:41:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:41:41 --> Model Class Initialized
INFO - 2020-11-12 16:41:41 --> Model Class Initialized
ERROR - 2020-11-12 16:41:41 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:41:41 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:41:42 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:41:42 --> Final output sent to browser
DEBUG - 2020-11-12 16:41:42 --> Total execution time: 1.0064
ERROR - 2020-11-12 16:43:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:43:30 --> Config Class Initialized
INFO - 2020-11-12 16:43:30 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:43:30 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:43:30 --> Utf8 Class Initialized
INFO - 2020-11-12 16:43:30 --> URI Class Initialized
INFO - 2020-11-12 16:43:30 --> Router Class Initialized
INFO - 2020-11-12 16:43:30 --> Output Class Initialized
INFO - 2020-11-12 16:43:30 --> Security Class Initialized
DEBUG - 2020-11-12 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:43:30 --> Input Class Initialized
INFO - 2020-11-12 16:43:30 --> Language Class Initialized
INFO - 2020-11-12 16:43:30 --> Loader Class Initialized
INFO - 2020-11-12 16:43:30 --> Helper loaded: url_helper
INFO - 2020-11-12 16:43:30 --> Database Driver Class Initialized
INFO - 2020-11-12 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:43:30 --> Email Class Initialized
INFO - 2020-11-12 16:43:30 --> Controller Class Initialized
DEBUG - 2020-11-12 16:43:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:43:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:43:30 --> Model Class Initialized
INFO - 2020-11-12 16:43:30 --> Model Class Initialized
ERROR - 2020-11-12 16:43:30 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:43:30 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:43:31 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:43:31 --> Final output sent to browser
DEBUG - 2020-11-12 16:43:31 --> Total execution time: 0.9885
ERROR - 2020-11-12 16:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:46:40 --> Config Class Initialized
INFO - 2020-11-12 16:46:40 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:46:40 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:46:40 --> Utf8 Class Initialized
INFO - 2020-11-12 16:46:40 --> URI Class Initialized
INFO - 2020-11-12 16:46:40 --> Router Class Initialized
INFO - 2020-11-12 16:46:40 --> Output Class Initialized
INFO - 2020-11-12 16:46:40 --> Security Class Initialized
DEBUG - 2020-11-12 16:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:46:40 --> Input Class Initialized
INFO - 2020-11-12 16:46:40 --> Language Class Initialized
INFO - 2020-11-12 16:46:40 --> Loader Class Initialized
INFO - 2020-11-12 16:46:40 --> Helper loaded: url_helper
INFO - 2020-11-12 16:46:40 --> Database Driver Class Initialized
INFO - 2020-11-12 16:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:46:40 --> Email Class Initialized
INFO - 2020-11-12 16:46:40 --> Controller Class Initialized
DEBUG - 2020-11-12 16:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:46:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:46:40 --> Model Class Initialized
INFO - 2020-11-12 16:46:40 --> Model Class Initialized
ERROR - 2020-11-12 16:46:40 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:46:40 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:46:42 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:46:42 --> Final output sent to browser
DEBUG - 2020-11-12 16:46:42 --> Total execution time: 1.0368
ERROR - 2020-11-12 16:47:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:47:38 --> Config Class Initialized
INFO - 2020-11-12 16:47:38 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:47:38 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:47:38 --> Utf8 Class Initialized
INFO - 2020-11-12 16:47:38 --> URI Class Initialized
INFO - 2020-11-12 16:47:38 --> Router Class Initialized
INFO - 2020-11-12 16:47:38 --> Output Class Initialized
INFO - 2020-11-12 16:47:38 --> Security Class Initialized
DEBUG - 2020-11-12 16:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:47:38 --> Input Class Initialized
INFO - 2020-11-12 16:47:38 --> Language Class Initialized
INFO - 2020-11-12 16:47:38 --> Loader Class Initialized
INFO - 2020-11-12 16:47:38 --> Helper loaded: url_helper
INFO - 2020-11-12 16:47:38 --> Database Driver Class Initialized
INFO - 2020-11-12 16:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:47:38 --> Email Class Initialized
INFO - 2020-11-12 16:47:38 --> Controller Class Initialized
DEBUG - 2020-11-12 16:47:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:47:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:47:38 --> Model Class Initialized
INFO - 2020-11-12 16:47:38 --> Model Class Initialized
ERROR - 2020-11-12 16:47:38 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:47:38 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:39 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:47:39 --> Final output sent to browser
DEBUG - 2020-11-12 16:47:39 --> Total execution time: 1.0028
ERROR - 2020-11-12 16:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:47:50 --> Config Class Initialized
INFO - 2020-11-12 16:47:50 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:47:50 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:47:50 --> Utf8 Class Initialized
INFO - 2020-11-12 16:47:50 --> URI Class Initialized
INFO - 2020-11-12 16:47:50 --> Router Class Initialized
INFO - 2020-11-12 16:47:50 --> Output Class Initialized
INFO - 2020-11-12 16:47:50 --> Security Class Initialized
DEBUG - 2020-11-12 16:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:47:50 --> Input Class Initialized
INFO - 2020-11-12 16:47:50 --> Language Class Initialized
INFO - 2020-11-12 16:47:51 --> Loader Class Initialized
INFO - 2020-11-12 16:47:51 --> Helper loaded: url_helper
INFO - 2020-11-12 16:47:51 --> Database Driver Class Initialized
INFO - 2020-11-12 16:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:47:51 --> Email Class Initialized
INFO - 2020-11-12 16:47:51 --> Controller Class Initialized
DEBUG - 2020-11-12 16:47:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:47:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:47:51 --> Model Class Initialized
INFO - 2020-11-12 16:47:51 --> Model Class Initialized
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
ERROR - 2020-11-12 16:47:51 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-11-12 16:47:51 --> Final output sent to browser
DEBUG - 2020-11-12 16:47:51 --> Total execution time: 0.9999
ERROR - 2020-11-12 16:48:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-12 16:48:33 --> Config Class Initialized
INFO - 2020-11-12 16:48:33 --> Hooks Class Initialized
DEBUG - 2020-11-12 16:48:33 --> UTF-8 Support Enabled
INFO - 2020-11-12 16:48:33 --> Utf8 Class Initialized
INFO - 2020-11-12 16:48:33 --> URI Class Initialized
INFO - 2020-11-12 16:48:33 --> Router Class Initialized
INFO - 2020-11-12 16:48:33 --> Output Class Initialized
INFO - 2020-11-12 16:48:33 --> Security Class Initialized
DEBUG - 2020-11-12 16:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 16:48:33 --> Input Class Initialized
INFO - 2020-11-12 16:48:33 --> Language Class Initialized
INFO - 2020-11-12 16:48:33 --> Loader Class Initialized
INFO - 2020-11-12 16:48:33 --> Helper loaded: url_helper
INFO - 2020-11-12 16:48:33 --> Database Driver Class Initialized
INFO - 2020-11-12 16:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 16:48:33 --> Email Class Initialized
INFO - 2020-11-12 16:48:33 --> Controller Class Initialized
DEBUG - 2020-11-12 16:48:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-12 16:48:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-12 16:48:33 --> Model Class Initialized
INFO - 2020-11-12 16:48:33 --> Model Class Initialized
ERROR - 2020-11-12 16:48:33 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-12 16:48:33 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-12 16:48:34 --> Final output sent to browser
DEBUG - 2020-11-12 16:48:34 --> Total execution time: 0.9455
