<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-10 07:07:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 07:07:33 --> Config Class Initialized
INFO - 2020-09-10 07:07:33 --> Hooks Class Initialized
DEBUG - 2020-09-10 07:07:33 --> UTF-8 Support Enabled
INFO - 2020-09-10 07:07:33 --> Utf8 Class Initialized
INFO - 2020-09-10 07:07:33 --> URI Class Initialized
DEBUG - 2020-09-10 07:07:33 --> No URI present. Default controller set.
INFO - 2020-09-10 07:07:33 --> Router Class Initialized
INFO - 2020-09-10 07:07:33 --> Output Class Initialized
INFO - 2020-09-10 07:07:33 --> Security Class Initialized
DEBUG - 2020-09-10 07:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 07:07:33 --> Input Class Initialized
INFO - 2020-09-10 07:07:33 --> Language Class Initialized
INFO - 2020-09-10 07:07:33 --> Loader Class Initialized
INFO - 2020-09-10 07:07:33 --> Helper loaded: url_helper
INFO - 2020-09-10 07:07:33 --> Database Driver Class Initialized
INFO - 2020-09-10 07:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 07:07:33 --> Email Class Initialized
INFO - 2020-09-10 07:07:33 --> Controller Class Initialized
INFO - 2020-09-10 07:07:33 --> Model Class Initialized
INFO - 2020-09-10 07:07:33 --> Model Class Initialized
DEBUG - 2020-09-10 07:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 07:07:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 07:07:33 --> Final output sent to browser
DEBUG - 2020-09-10 07:07:33 --> Total execution time: 0.1605
ERROR - 2020-09-10 07:07:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 07:07:33 --> Config Class Initialized
INFO - 2020-09-10 07:07:33 --> Hooks Class Initialized
DEBUG - 2020-09-10 07:07:33 --> UTF-8 Support Enabled
INFO - 2020-09-10 07:07:33 --> Utf8 Class Initialized
INFO - 2020-09-10 07:07:33 --> URI Class Initialized
DEBUG - 2020-09-10 07:07:33 --> No URI present. Default controller set.
INFO - 2020-09-10 07:07:33 --> Router Class Initialized
INFO - 2020-09-10 07:07:33 --> Output Class Initialized
INFO - 2020-09-10 07:07:33 --> Security Class Initialized
DEBUG - 2020-09-10 07:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 07:07:33 --> Input Class Initialized
INFO - 2020-09-10 07:07:33 --> Language Class Initialized
INFO - 2020-09-10 07:07:33 --> Loader Class Initialized
INFO - 2020-09-10 07:07:33 --> Helper loaded: url_helper
INFO - 2020-09-10 07:07:33 --> Database Driver Class Initialized
INFO - 2020-09-10 07:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 07:07:33 --> Email Class Initialized
INFO - 2020-09-10 07:07:33 --> Controller Class Initialized
INFO - 2020-09-10 07:07:33 --> Model Class Initialized
INFO - 2020-09-10 07:07:33 --> Model Class Initialized
DEBUG - 2020-09-10 07:07:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 07:07:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 07:07:33 --> Final output sent to browser
DEBUG - 2020-09-10 07:07:33 --> Total execution time: 0.0194
ERROR - 2020-09-10 09:47:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 09:47:44 --> Config Class Initialized
INFO - 2020-09-10 09:47:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 09:47:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:47:44 --> Utf8 Class Initialized
INFO - 2020-09-10 09:47:44 --> URI Class Initialized
DEBUG - 2020-09-10 09:47:44 --> No URI present. Default controller set.
INFO - 2020-09-10 09:47:44 --> Router Class Initialized
INFO - 2020-09-10 09:47:44 --> Output Class Initialized
INFO - 2020-09-10 09:47:44 --> Security Class Initialized
DEBUG - 2020-09-10 09:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:47:44 --> Input Class Initialized
INFO - 2020-09-10 09:47:44 --> Language Class Initialized
INFO - 2020-09-10 09:47:44 --> Loader Class Initialized
INFO - 2020-09-10 09:47:44 --> Helper loaded: url_helper
INFO - 2020-09-10 09:47:44 --> Database Driver Class Initialized
INFO - 2020-09-10 09:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:47:44 --> Email Class Initialized
INFO - 2020-09-10 09:47:44 --> Controller Class Initialized
INFO - 2020-09-10 09:47:44 --> Model Class Initialized
INFO - 2020-09-10 09:47:44 --> Model Class Initialized
DEBUG - 2020-09-10 09:47:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 09:47:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 09:47:44 --> Final output sent to browser
DEBUG - 2020-09-10 09:47:44 --> Total execution time: 0.1235
ERROR - 2020-09-10 09:52:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-10 09:52:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 09:52:37 --> Config Class Initialized
INFO - 2020-09-10 09:52:37 --> Hooks Class Initialized
INFO - 2020-09-10 09:52:37 --> Config Class Initialized
INFO - 2020-09-10 09:52:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 09:52:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:52:37 --> Utf8 Class Initialized
DEBUG - 2020-09-10 09:52:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:52:37 --> Utf8 Class Initialized
INFO - 2020-09-10 09:52:37 --> URI Class Initialized
INFO - 2020-09-10 09:52:37 --> URI Class Initialized
INFO - 2020-09-10 09:52:37 --> Router Class Initialized
INFO - 2020-09-10 09:52:37 --> Router Class Initialized
INFO - 2020-09-10 09:52:37 --> Output Class Initialized
INFO - 2020-09-10 09:52:37 --> Output Class Initialized
INFO - 2020-09-10 09:52:37 --> Security Class Initialized
INFO - 2020-09-10 09:52:37 --> Security Class Initialized
DEBUG - 2020-09-10 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:52:37 --> Input Class Initialized
INFO - 2020-09-10 09:52:37 --> Language Class Initialized
DEBUG - 2020-09-10 09:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:52:37 --> Input Class Initialized
INFO - 2020-09-10 09:52:37 --> Language Class Initialized
INFO - 2020-09-10 09:52:37 --> Loader Class Initialized
INFO - 2020-09-10 09:52:37 --> Loader Class Initialized
INFO - 2020-09-10 09:52:37 --> Helper loaded: url_helper
INFO - 2020-09-10 09:52:37 --> Helper loaded: url_helper
INFO - 2020-09-10 09:52:37 --> Database Driver Class Initialized
INFO - 2020-09-10 09:52:37 --> Database Driver Class Initialized
INFO - 2020-09-10 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:52:37 --> Email Class Initialized
INFO - 2020-09-10 09:52:37 --> Controller Class Initialized
INFO - 2020-09-10 09:52:37 --> Model Class Initialized
INFO - 2020-09-10 09:52:37 --> Model Class Initialized
DEBUG - 2020-09-10 09:52:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 09:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:52:37 --> Email Class Initialized
INFO - 2020-09-10 09:52:37 --> Controller Class Initialized
INFO - 2020-09-10 09:52:37 --> Model Class Initialized
INFO - 2020-09-10 09:52:37 --> Model Class Initialized
DEBUG - 2020-09-10 09:52:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 09:52:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 09:52:37 --> Model Class Initialized
INFO - 2020-09-10 09:52:37 --> Final output sent to browser
DEBUG - 2020-09-10 09:52:37 --> Total execution time: 0.1501
ERROR - 2020-09-10 09:52:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 09:52:38 --> Config Class Initialized
INFO - 2020-09-10 09:52:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 09:52:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:52:38 --> Utf8 Class Initialized
INFO - 2020-09-10 09:52:38 --> URI Class Initialized
INFO - 2020-09-10 09:52:38 --> Router Class Initialized
INFO - 2020-09-10 09:52:38 --> Output Class Initialized
INFO - 2020-09-10 09:52:38 --> Security Class Initialized
DEBUG - 2020-09-10 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:52:38 --> Input Class Initialized
INFO - 2020-09-10 09:52:38 --> Language Class Initialized
INFO - 2020-09-10 09:52:38 --> Loader Class Initialized
INFO - 2020-09-10 09:52:38 --> Helper loaded: url_helper
INFO - 2020-09-10 09:52:38 --> Database Driver Class Initialized
INFO - 2020-09-10 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:52:38 --> Email Class Initialized
INFO - 2020-09-10 09:52:38 --> Controller Class Initialized
DEBUG - 2020-09-10 09:52:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 09:52:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 09:52:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 09:52:38 --> Final output sent to browser
DEBUG - 2020-09-10 09:52:38 --> Total execution time: 0.0359
ERROR - 2020-09-10 09:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 09:53:11 --> Config Class Initialized
INFO - 2020-09-10 09:53:11 --> Hooks Class Initialized
DEBUG - 2020-09-10 09:53:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:53:11 --> Utf8 Class Initialized
INFO - 2020-09-10 09:53:11 --> URI Class Initialized
INFO - 2020-09-10 09:53:11 --> Router Class Initialized
INFO - 2020-09-10 09:53:11 --> Output Class Initialized
INFO - 2020-09-10 09:53:11 --> Security Class Initialized
DEBUG - 2020-09-10 09:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:53:11 --> Input Class Initialized
INFO - 2020-09-10 09:53:11 --> Language Class Initialized
INFO - 2020-09-10 09:53:11 --> Loader Class Initialized
INFO - 2020-09-10 09:53:11 --> Helper loaded: url_helper
INFO - 2020-09-10 09:53:11 --> Database Driver Class Initialized
INFO - 2020-09-10 09:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:53:11 --> Email Class Initialized
INFO - 2020-09-10 09:53:11 --> Controller Class Initialized
INFO - 2020-09-10 09:53:11 --> Model Class Initialized
INFO - 2020-09-10 09:53:11 --> Model Class Initialized
INFO - 2020-09-10 09:53:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 09:53:11 --> Final output sent to browser
DEBUG - 2020-09-10 09:53:11 --> Total execution time: 0.2036
ERROR - 2020-09-10 09:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 09:53:12 --> Config Class Initialized
INFO - 2020-09-10 09:53:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 09:53:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 09:53:12 --> Utf8 Class Initialized
INFO - 2020-09-10 09:53:12 --> URI Class Initialized
INFO - 2020-09-10 09:53:12 --> Router Class Initialized
INFO - 2020-09-10 09:53:12 --> Output Class Initialized
INFO - 2020-09-10 09:53:12 --> Security Class Initialized
DEBUG - 2020-09-10 09:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 09:53:12 --> Input Class Initialized
INFO - 2020-09-10 09:53:12 --> Language Class Initialized
INFO - 2020-09-10 09:53:12 --> Loader Class Initialized
INFO - 2020-09-10 09:53:12 --> Helper loaded: url_helper
INFO - 2020-09-10 09:53:12 --> Database Driver Class Initialized
INFO - 2020-09-10 09:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 09:53:12 --> Email Class Initialized
INFO - 2020-09-10 09:53:12 --> Controller Class Initialized
INFO - 2020-09-10 09:53:12 --> Model Class Initialized
INFO - 2020-09-10 09:53:12 --> Model Class Initialized
INFO - 2020-09-10 09:53:12 --> Final output sent to browser
DEBUG - 2020-09-10 09:53:12 --> Total execution time: 0.0461
ERROR - 2020-09-10 10:03:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:03:13 --> Config Class Initialized
INFO - 2020-09-10 10:03:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:03:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:03:13 --> Utf8 Class Initialized
INFO - 2020-09-10 10:03:13 --> URI Class Initialized
INFO - 2020-09-10 10:03:13 --> Router Class Initialized
INFO - 2020-09-10 10:03:13 --> Output Class Initialized
INFO - 2020-09-10 10:03:13 --> Security Class Initialized
DEBUG - 2020-09-10 10:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:03:13 --> Input Class Initialized
INFO - 2020-09-10 10:03:13 --> Language Class Initialized
INFO - 2020-09-10 10:03:13 --> Loader Class Initialized
INFO - 2020-09-10 10:03:13 --> Helper loaded: url_helper
INFO - 2020-09-10 10:03:13 --> Database Driver Class Initialized
INFO - 2020-09-10 10:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:03:13 --> Email Class Initialized
INFO - 2020-09-10 10:03:13 --> Controller Class Initialized
INFO - 2020-09-10 10:03:13 --> Model Class Initialized
INFO - 2020-09-10 10:03:13 --> Model Class Initialized
INFO - 2020-09-10 10:03:13 --> Final output sent to browser
DEBUG - 2020-09-10 10:03:13 --> Total execution time: 0.3024
ERROR - 2020-09-10 10:03:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:03:14 --> Config Class Initialized
INFO - 2020-09-10 10:03:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:03:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:03:14 --> Utf8 Class Initialized
INFO - 2020-09-10 10:03:14 --> URI Class Initialized
INFO - 2020-09-10 10:03:14 --> Router Class Initialized
INFO - 2020-09-10 10:03:14 --> Output Class Initialized
INFO - 2020-09-10 10:03:14 --> Security Class Initialized
DEBUG - 2020-09-10 10:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:03:14 --> Input Class Initialized
INFO - 2020-09-10 10:03:14 --> Language Class Initialized
INFO - 2020-09-10 10:03:14 --> Loader Class Initialized
INFO - 2020-09-10 10:03:14 --> Helper loaded: url_helper
INFO - 2020-09-10 10:03:14 --> Database Driver Class Initialized
INFO - 2020-09-10 10:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:03:14 --> Email Class Initialized
INFO - 2020-09-10 10:03:14 --> Controller Class Initialized
INFO - 2020-09-10 10:03:14 --> Model Class Initialized
INFO - 2020-09-10 10:03:14 --> Model Class Initialized
INFO - 2020-09-10 10:03:14 --> Final output sent to browser
DEBUG - 2020-09-10 10:03:14 --> Total execution time: 0.0613
ERROR - 2020-09-10 10:03:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:03:25 --> Config Class Initialized
INFO - 2020-09-10 10:03:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:03:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:03:25 --> Utf8 Class Initialized
INFO - 2020-09-10 10:03:25 --> URI Class Initialized
INFO - 2020-09-10 10:03:25 --> Router Class Initialized
INFO - 2020-09-10 10:03:25 --> Output Class Initialized
INFO - 2020-09-10 10:03:25 --> Security Class Initialized
DEBUG - 2020-09-10 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:03:25 --> Input Class Initialized
INFO - 2020-09-10 10:03:25 --> Language Class Initialized
INFO - 2020-09-10 10:03:25 --> Loader Class Initialized
INFO - 2020-09-10 10:03:25 --> Helper loaded: url_helper
INFO - 2020-09-10 10:03:25 --> Database Driver Class Initialized
INFO - 2020-09-10 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:03:25 --> Email Class Initialized
INFO - 2020-09-10 10:03:25 --> Controller Class Initialized
INFO - 2020-09-10 10:03:25 --> Model Class Initialized
INFO - 2020-09-10 10:03:25 --> Model Class Initialized
INFO - 2020-09-10 10:03:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 10:03:25 --> Final output sent to browser
DEBUG - 2020-09-10 10:03:25 --> Total execution time: 0.0958
ERROR - 2020-09-10 10:03:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:03:26 --> Config Class Initialized
INFO - 2020-09-10 10:03:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:03:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:03:26 --> Utf8 Class Initialized
INFO - 2020-09-10 10:03:26 --> URI Class Initialized
INFO - 2020-09-10 10:03:26 --> Router Class Initialized
INFO - 2020-09-10 10:03:26 --> Output Class Initialized
INFO - 2020-09-10 10:03:26 --> Security Class Initialized
DEBUG - 2020-09-10 10:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:03:26 --> Input Class Initialized
INFO - 2020-09-10 10:03:26 --> Language Class Initialized
INFO - 2020-09-10 10:03:26 --> Loader Class Initialized
INFO - 2020-09-10 10:03:26 --> Helper loaded: url_helper
INFO - 2020-09-10 10:03:26 --> Database Driver Class Initialized
INFO - 2020-09-10 10:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:03:26 --> Email Class Initialized
INFO - 2020-09-10 10:03:26 --> Controller Class Initialized
INFO - 2020-09-10 10:03:26 --> Model Class Initialized
INFO - 2020-09-10 10:03:26 --> Model Class Initialized
INFO - 2020-09-10 10:03:26 --> Final output sent to browser
DEBUG - 2020-09-10 10:03:26 --> Total execution time: 0.0406
ERROR - 2020-09-10 10:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:04:12 --> Config Class Initialized
INFO - 2020-09-10 10:04:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:04:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:04:12 --> Utf8 Class Initialized
INFO - 2020-09-10 10:04:12 --> URI Class Initialized
INFO - 2020-09-10 10:04:12 --> Router Class Initialized
INFO - 2020-09-10 10:04:12 --> Output Class Initialized
INFO - 2020-09-10 10:04:12 --> Security Class Initialized
DEBUG - 2020-09-10 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:04:12 --> Input Class Initialized
INFO - 2020-09-10 10:04:12 --> Language Class Initialized
INFO - 2020-09-10 10:04:12 --> Loader Class Initialized
INFO - 2020-09-10 10:04:12 --> Helper loaded: url_helper
INFO - 2020-09-10 10:04:12 --> Database Driver Class Initialized
INFO - 2020-09-10 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:04:12 --> Email Class Initialized
INFO - 2020-09-10 10:04:12 --> Controller Class Initialized
INFO - 2020-09-10 10:04:12 --> Model Class Initialized
INFO - 2020-09-10 10:04:12 --> Model Class Initialized
INFO - 2020-09-10 10:04:12 --> Final output sent to browser
DEBUG - 2020-09-10 10:04:12 --> Total execution time: 0.1541
ERROR - 2020-09-10 10:04:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:04:12 --> Config Class Initialized
INFO - 2020-09-10 10:04:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:04:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:04:12 --> Utf8 Class Initialized
INFO - 2020-09-10 10:04:12 --> URI Class Initialized
INFO - 2020-09-10 10:04:12 --> Router Class Initialized
INFO - 2020-09-10 10:04:12 --> Output Class Initialized
INFO - 2020-09-10 10:04:12 --> Security Class Initialized
DEBUG - 2020-09-10 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:04:12 --> Input Class Initialized
INFO - 2020-09-10 10:04:12 --> Language Class Initialized
INFO - 2020-09-10 10:04:12 --> Loader Class Initialized
INFO - 2020-09-10 10:04:12 --> Helper loaded: url_helper
INFO - 2020-09-10 10:04:12 --> Database Driver Class Initialized
INFO - 2020-09-10 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:04:12 --> Email Class Initialized
INFO - 2020-09-10 10:04:12 --> Controller Class Initialized
INFO - 2020-09-10 10:04:12 --> Model Class Initialized
INFO - 2020-09-10 10:04:12 --> Model Class Initialized
INFO - 2020-09-10 10:04:12 --> Final output sent to browser
DEBUG - 2020-09-10 10:04:12 --> Total execution time: 0.0404
ERROR - 2020-09-10 10:05:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:05:13 --> Config Class Initialized
INFO - 2020-09-10 10:05:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:05:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:05:13 --> Utf8 Class Initialized
INFO - 2020-09-10 10:05:13 --> URI Class Initialized
INFO - 2020-09-10 10:05:13 --> Router Class Initialized
INFO - 2020-09-10 10:05:13 --> Output Class Initialized
INFO - 2020-09-10 10:05:13 --> Security Class Initialized
DEBUG - 2020-09-10 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:05:13 --> Input Class Initialized
INFO - 2020-09-10 10:05:13 --> Language Class Initialized
INFO - 2020-09-10 10:05:13 --> Loader Class Initialized
INFO - 2020-09-10 10:05:13 --> Helper loaded: url_helper
INFO - 2020-09-10 10:05:13 --> Database Driver Class Initialized
INFO - 2020-09-10 10:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:05:13 --> Email Class Initialized
INFO - 2020-09-10 10:05:13 --> Controller Class Initialized
INFO - 2020-09-10 10:05:13 --> Model Class Initialized
INFO - 2020-09-10 10:05:13 --> Model Class Initialized
INFO - 2020-09-10 10:05:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 10:05:13 --> Final output sent to browser
DEBUG - 2020-09-10 10:05:13 --> Total execution time: 0.0533
ERROR - 2020-09-10 10:05:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:05:14 --> Config Class Initialized
INFO - 2020-09-10 10:05:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:05:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:05:14 --> Utf8 Class Initialized
INFO - 2020-09-10 10:05:14 --> URI Class Initialized
INFO - 2020-09-10 10:05:14 --> Router Class Initialized
INFO - 2020-09-10 10:05:14 --> Output Class Initialized
INFO - 2020-09-10 10:05:14 --> Security Class Initialized
DEBUG - 2020-09-10 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:05:14 --> Input Class Initialized
INFO - 2020-09-10 10:05:14 --> Language Class Initialized
INFO - 2020-09-10 10:05:14 --> Loader Class Initialized
INFO - 2020-09-10 10:05:14 --> Helper loaded: url_helper
INFO - 2020-09-10 10:05:14 --> Database Driver Class Initialized
INFO - 2020-09-10 10:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:05:14 --> Email Class Initialized
INFO - 2020-09-10 10:05:14 --> Controller Class Initialized
INFO - 2020-09-10 10:05:14 --> Model Class Initialized
INFO - 2020-09-10 10:05:14 --> Model Class Initialized
INFO - 2020-09-10 10:05:14 --> Final output sent to browser
DEBUG - 2020-09-10 10:05:14 --> Total execution time: 0.0363
ERROR - 2020-09-10 10:06:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:06:26 --> Config Class Initialized
INFO - 2020-09-10 10:06:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:06:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:06:26 --> Utf8 Class Initialized
INFO - 2020-09-10 10:06:26 --> URI Class Initialized
INFO - 2020-09-10 10:06:26 --> Router Class Initialized
INFO - 2020-09-10 10:06:26 --> Output Class Initialized
INFO - 2020-09-10 10:06:26 --> Security Class Initialized
DEBUG - 2020-09-10 10:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:06:26 --> Input Class Initialized
INFO - 2020-09-10 10:06:26 --> Language Class Initialized
INFO - 2020-09-10 10:06:26 --> Loader Class Initialized
INFO - 2020-09-10 10:06:26 --> Helper loaded: url_helper
INFO - 2020-09-10 10:06:26 --> Database Driver Class Initialized
INFO - 2020-09-10 10:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:06:26 --> Email Class Initialized
INFO - 2020-09-10 10:06:26 --> Controller Class Initialized
DEBUG - 2020-09-10 10:06:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 10:06:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 10:06:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 10:06:26 --> Final output sent to browser
DEBUG - 2020-09-10 10:06:26 --> Total execution time: 0.1941
ERROR - 2020-09-10 10:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:06:35 --> Config Class Initialized
INFO - 2020-09-10 10:06:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:06:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:06:35 --> Utf8 Class Initialized
INFO - 2020-09-10 10:06:35 --> URI Class Initialized
INFO - 2020-09-10 10:06:35 --> Router Class Initialized
INFO - 2020-09-10 10:06:35 --> Output Class Initialized
INFO - 2020-09-10 10:06:35 --> Security Class Initialized
DEBUG - 2020-09-10 10:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:06:35 --> Input Class Initialized
INFO - 2020-09-10 10:06:35 --> Language Class Initialized
INFO - 2020-09-10 10:06:35 --> Loader Class Initialized
INFO - 2020-09-10 10:06:35 --> Helper loaded: url_helper
INFO - 2020-09-10 10:06:35 --> Database Driver Class Initialized
INFO - 2020-09-10 10:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:06:35 --> Email Class Initialized
INFO - 2020-09-10 10:06:35 --> Controller Class Initialized
DEBUG - 2020-09-10 10:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 10:06:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 10:06:35 --> Model Class Initialized
INFO - 2020-09-10 10:06:35 --> Model Class Initialized
INFO - 2020-09-10 10:06:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 10:06:35 --> Final output sent to browser
DEBUG - 2020-09-10 10:06:35 --> Total execution time: 0.0451
ERROR - 2020-09-10 10:06:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:06:46 --> Config Class Initialized
INFO - 2020-09-10 10:06:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:06:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:06:46 --> Utf8 Class Initialized
INFO - 2020-09-10 10:06:46 --> URI Class Initialized
INFO - 2020-09-10 10:06:46 --> Router Class Initialized
INFO - 2020-09-10 10:06:46 --> Output Class Initialized
INFO - 2020-09-10 10:06:46 --> Security Class Initialized
DEBUG - 2020-09-10 10:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:06:46 --> Input Class Initialized
INFO - 2020-09-10 10:06:46 --> Language Class Initialized
INFO - 2020-09-10 10:06:46 --> Loader Class Initialized
INFO - 2020-09-10 10:06:46 --> Helper loaded: url_helper
INFO - 2020-09-10 10:06:46 --> Database Driver Class Initialized
INFO - 2020-09-10 10:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:06:46 --> Email Class Initialized
INFO - 2020-09-10 10:06:46 --> Controller Class Initialized
DEBUG - 2020-09-10 10:06:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 10:06:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 10:06:46 --> Model Class Initialized
INFO - 2020-09-10 10:06:46 --> Model Class Initialized
INFO - 2020-09-10 10:06:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 10:06:46 --> Final output sent to browser
DEBUG - 2020-09-10 10:06:46 --> Total execution time: 0.0332
ERROR - 2020-09-10 10:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:07:51 --> Config Class Initialized
INFO - 2020-09-10 10:07:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:07:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:07:51 --> Utf8 Class Initialized
INFO - 2020-09-10 10:07:51 --> URI Class Initialized
INFO - 2020-09-10 10:07:51 --> Router Class Initialized
INFO - 2020-09-10 10:07:51 --> Output Class Initialized
INFO - 2020-09-10 10:07:51 --> Security Class Initialized
DEBUG - 2020-09-10 10:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:07:51 --> Input Class Initialized
INFO - 2020-09-10 10:07:51 --> Language Class Initialized
INFO - 2020-09-10 10:07:51 --> Loader Class Initialized
INFO - 2020-09-10 10:07:51 --> Helper loaded: url_helper
INFO - 2020-09-10 10:07:51 --> Database Driver Class Initialized
INFO - 2020-09-10 10:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:07:52 --> Email Class Initialized
INFO - 2020-09-10 10:07:52 --> Controller Class Initialized
DEBUG - 2020-09-10 10:07:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 10:07:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 10:07:52 --> Model Class Initialized
INFO - 2020-09-10 10:07:52 --> Model Class Initialized
INFO - 2020-09-10 10:07:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 10:07:52 --> Final output sent to browser
DEBUG - 2020-09-10 10:07:52 --> Total execution time: 0.0246
ERROR - 2020-09-10 10:10:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:10:16 --> Config Class Initialized
INFO - 2020-09-10 10:10:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:10:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:10:16 --> Utf8 Class Initialized
INFO - 2020-09-10 10:10:16 --> URI Class Initialized
INFO - 2020-09-10 10:10:16 --> Router Class Initialized
INFO - 2020-09-10 10:10:16 --> Output Class Initialized
INFO - 2020-09-10 10:10:16 --> Security Class Initialized
DEBUG - 2020-09-10 10:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:10:16 --> Input Class Initialized
INFO - 2020-09-10 10:10:16 --> Language Class Initialized
INFO - 2020-09-10 10:10:16 --> Loader Class Initialized
INFO - 2020-09-10 10:10:16 --> Helper loaded: url_helper
INFO - 2020-09-10 10:10:16 --> Database Driver Class Initialized
INFO - 2020-09-10 10:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:10:16 --> Email Class Initialized
INFO - 2020-09-10 10:10:16 --> Controller Class Initialized
DEBUG - 2020-09-10 10:10:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 10:10:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 10:10:16 --> Model Class Initialized
INFO - 2020-09-10 10:10:16 --> Model Class Initialized
INFO - 2020-09-10 10:10:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 10:10:16 --> Final output sent to browser
DEBUG - 2020-09-10 10:10:16 --> Total execution time: 0.0207
ERROR - 2020-09-10 10:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 10:11:04 --> Config Class Initialized
INFO - 2020-09-10 10:11:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 10:11:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 10:11:04 --> Utf8 Class Initialized
INFO - 2020-09-10 10:11:04 --> URI Class Initialized
INFO - 2020-09-10 10:11:04 --> Router Class Initialized
INFO - 2020-09-10 10:11:04 --> Output Class Initialized
INFO - 2020-09-10 10:11:04 --> Security Class Initialized
DEBUG - 2020-09-10 10:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 10:11:04 --> Input Class Initialized
INFO - 2020-09-10 10:11:04 --> Language Class Initialized
INFO - 2020-09-10 10:11:04 --> Loader Class Initialized
INFO - 2020-09-10 10:11:04 --> Helper loaded: url_helper
INFO - 2020-09-10 10:11:04 --> Database Driver Class Initialized
INFO - 2020-09-10 10:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 10:11:04 --> Email Class Initialized
INFO - 2020-09-10 10:11:04 --> Controller Class Initialized
DEBUG - 2020-09-10 10:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 10:11:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 10:11:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 10:11:04 --> Final output sent to browser
DEBUG - 2020-09-10 10:11:04 --> Total execution time: 0.0164
ERROR - 2020-09-10 14:53:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:53:34 --> Config Class Initialized
INFO - 2020-09-10 14:53:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:53:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:53:34 --> Utf8 Class Initialized
INFO - 2020-09-10 14:53:34 --> URI Class Initialized
DEBUG - 2020-09-10 14:53:34 --> No URI present. Default controller set.
INFO - 2020-09-10 14:53:34 --> Router Class Initialized
INFO - 2020-09-10 14:53:34 --> Output Class Initialized
INFO - 2020-09-10 14:53:34 --> Security Class Initialized
DEBUG - 2020-09-10 14:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:53:34 --> Input Class Initialized
INFO - 2020-09-10 14:53:34 --> Language Class Initialized
INFO - 2020-09-10 14:53:34 --> Loader Class Initialized
INFO - 2020-09-10 14:53:34 --> Helper loaded: url_helper
INFO - 2020-09-10 14:53:34 --> Database Driver Class Initialized
INFO - 2020-09-10 14:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:53:34 --> Email Class Initialized
INFO - 2020-09-10 14:53:34 --> Controller Class Initialized
INFO - 2020-09-10 14:53:34 --> Model Class Initialized
INFO - 2020-09-10 14:53:34 --> Model Class Initialized
DEBUG - 2020-09-10 14:53:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:53:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 14:53:34 --> Final output sent to browser
DEBUG - 2020-09-10 14:53:34 --> Total execution time: 0.0506
ERROR - 2020-09-10 14:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:53:41 --> Config Class Initialized
INFO - 2020-09-10 14:53:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:53:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:53:41 --> Utf8 Class Initialized
INFO - 2020-09-10 14:53:41 --> URI Class Initialized
INFO - 2020-09-10 14:53:41 --> Router Class Initialized
INFO - 2020-09-10 14:53:41 --> Output Class Initialized
INFO - 2020-09-10 14:53:41 --> Security Class Initialized
DEBUG - 2020-09-10 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:53:41 --> Input Class Initialized
INFO - 2020-09-10 14:53:41 --> Language Class Initialized
ERROR - 2020-09-10 14:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:53:41 --> Config Class Initialized
INFO - 2020-09-10 14:53:41 --> Loader Class Initialized
INFO - 2020-09-10 14:53:41 --> Hooks Class Initialized
INFO - 2020-09-10 14:53:41 --> Helper loaded: url_helper
DEBUG - 2020-09-10 14:53:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:53:41 --> Utf8 Class Initialized
INFO - 2020-09-10 14:53:41 --> URI Class Initialized
INFO - 2020-09-10 14:53:41 --> Router Class Initialized
INFO - 2020-09-10 14:53:41 --> Output Class Initialized
INFO - 2020-09-10 14:53:41 --> Security Class Initialized
INFO - 2020-09-10 14:53:41 --> Database Driver Class Initialized
DEBUG - 2020-09-10 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:53:41 --> Input Class Initialized
INFO - 2020-09-10 14:53:41 --> Language Class Initialized
INFO - 2020-09-10 14:53:41 --> Loader Class Initialized
INFO - 2020-09-10 14:53:41 --> Helper loaded: url_helper
INFO - 2020-09-10 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:53:41 --> Email Class Initialized
INFO - 2020-09-10 14:53:41 --> Controller Class Initialized
INFO - 2020-09-10 14:53:41 --> Model Class Initialized
INFO - 2020-09-10 14:53:41 --> Model Class Initialized
DEBUG - 2020-09-10 14:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 14:53:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:53:41 --> Database Driver Class Initialized
INFO - 2020-09-10 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:53:41 --> Email Class Initialized
INFO - 2020-09-10 14:53:41 --> Controller Class Initialized
INFO - 2020-09-10 14:53:41 --> Model Class Initialized
INFO - 2020-09-10 14:53:41 --> Model Class Initialized
DEBUG - 2020-09-10 14:53:41 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-10 14:53:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-10 14:53:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:53:42 --> Config Class Initialized
INFO - 2020-09-10 14:53:42 --> Hooks Class Initialized
INFO - 2020-09-10 14:53:42 --> Config Class Initialized
INFO - 2020-09-10 14:53:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:53:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:53:42 --> Utf8 Class Initialized
DEBUG - 2020-09-10 14:53:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:53:42 --> Utf8 Class Initialized
INFO - 2020-09-10 14:53:42 --> URI Class Initialized
INFO - 2020-09-10 14:53:42 --> URI Class Initialized
DEBUG - 2020-09-10 14:53:42 --> No URI present. Default controller set.
INFO - 2020-09-10 14:53:42 --> Router Class Initialized
INFO - 2020-09-10 14:53:42 --> Router Class Initialized
INFO - 2020-09-10 14:53:42 --> Output Class Initialized
INFO - 2020-09-10 14:53:42 --> Output Class Initialized
INFO - 2020-09-10 14:53:42 --> Security Class Initialized
INFO - 2020-09-10 14:53:42 --> Security Class Initialized
DEBUG - 2020-09-10 14:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:53:42 --> Input Class Initialized
DEBUG - 2020-09-10 14:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:53:42 --> Input Class Initialized
INFO - 2020-09-10 14:53:42 --> Language Class Initialized
INFO - 2020-09-10 14:53:42 --> Language Class Initialized
INFO - 2020-09-10 14:53:42 --> Loader Class Initialized
INFO - 2020-09-10 14:53:42 --> Loader Class Initialized
INFO - 2020-09-10 14:53:42 --> Helper loaded: url_helper
INFO - 2020-09-10 14:53:42 --> Helper loaded: url_helper
INFO - 2020-09-10 14:53:42 --> Database Driver Class Initialized
INFO - 2020-09-10 14:53:42 --> Database Driver Class Initialized
INFO - 2020-09-10 14:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:53:42 --> Email Class Initialized
INFO - 2020-09-10 14:53:42 --> Controller Class Initialized
INFO - 2020-09-10 14:53:42 --> Model Class Initialized
INFO - 2020-09-10 14:53:42 --> Model Class Initialized
DEBUG - 2020-09-10 14:53:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:53:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 14:53:42 --> Final output sent to browser
DEBUG - 2020-09-10 14:53:42 --> Total execution time: 0.0198
INFO - 2020-09-10 14:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:53:42 --> Email Class Initialized
INFO - 2020-09-10 14:53:42 --> Controller Class Initialized
DEBUG - 2020-09-10 14:53:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 14:53:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:53:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 14:53:42 --> Final output sent to browser
DEBUG - 2020-09-10 14:53:42 --> Total execution time: 0.0229
ERROR - 2020-09-10 14:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:55:11 --> Config Class Initialized
INFO - 2020-09-10 14:55:11 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:55:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:55:11 --> Utf8 Class Initialized
INFO - 2020-09-10 14:55:11 --> URI Class Initialized
INFO - 2020-09-10 14:55:11 --> Router Class Initialized
INFO - 2020-09-10 14:55:11 --> Output Class Initialized
INFO - 2020-09-10 14:55:11 --> Security Class Initialized
DEBUG - 2020-09-10 14:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:55:11 --> Input Class Initialized
INFO - 2020-09-10 14:55:11 --> Language Class Initialized
INFO - 2020-09-10 14:55:11 --> Loader Class Initialized
INFO - 2020-09-10 14:55:11 --> Helper loaded: url_helper
INFO - 2020-09-10 14:55:11 --> Database Driver Class Initialized
INFO - 2020-09-10 14:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:55:11 --> Email Class Initialized
INFO - 2020-09-10 14:55:11 --> Controller Class Initialized
DEBUG - 2020-09-10 14:55:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 14:55:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:55:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 14:55:11 --> Final output sent to browser
DEBUG - 2020-09-10 14:55:11 --> Total execution time: 0.0223
ERROR - 2020-09-10 14:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:55:57 --> Config Class Initialized
INFO - 2020-09-10 14:55:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:55:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:55:57 --> Utf8 Class Initialized
INFO - 2020-09-10 14:55:57 --> URI Class Initialized
INFO - 2020-09-10 14:55:57 --> Router Class Initialized
INFO - 2020-09-10 14:55:57 --> Output Class Initialized
INFO - 2020-09-10 14:55:57 --> Security Class Initialized
DEBUG - 2020-09-10 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:55:57 --> Input Class Initialized
INFO - 2020-09-10 14:55:57 --> Language Class Initialized
INFO - 2020-09-10 14:55:57 --> Loader Class Initialized
INFO - 2020-09-10 14:55:57 --> Helper loaded: url_helper
INFO - 2020-09-10 14:55:57 --> Database Driver Class Initialized
INFO - 2020-09-10 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:55:57 --> Email Class Initialized
INFO - 2020-09-10 14:55:57 --> Controller Class Initialized
DEBUG - 2020-09-10 14:55:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 14:55:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:55:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 14:55:57 --> Final output sent to browser
DEBUG - 2020-09-10 14:55:57 --> Total execution time: 0.0203
ERROR - 2020-09-10 14:56:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:56:13 --> Config Class Initialized
INFO - 2020-09-10 14:56:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:56:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:56:13 --> Utf8 Class Initialized
INFO - 2020-09-10 14:56:13 --> URI Class Initialized
INFO - 2020-09-10 14:56:13 --> Router Class Initialized
INFO - 2020-09-10 14:56:13 --> Output Class Initialized
INFO - 2020-09-10 14:56:13 --> Security Class Initialized
DEBUG - 2020-09-10 14:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:56:13 --> Input Class Initialized
INFO - 2020-09-10 14:56:13 --> Language Class Initialized
INFO - 2020-09-10 14:56:13 --> Loader Class Initialized
INFO - 2020-09-10 14:56:13 --> Helper loaded: url_helper
INFO - 2020-09-10 14:56:13 --> Database Driver Class Initialized
INFO - 2020-09-10 14:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:56:13 --> Email Class Initialized
INFO - 2020-09-10 14:56:13 --> Controller Class Initialized
DEBUG - 2020-09-10 14:56:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 14:56:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 14:56:13 --> Model Class Initialized
INFO - 2020-09-10 14:56:13 --> Model Class Initialized
INFO - 2020-09-10 14:56:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 14:56:13 --> Final output sent to browser
DEBUG - 2020-09-10 14:56:13 --> Total execution time: 0.0418
ERROR - 2020-09-10 14:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:59:58 --> Config Class Initialized
INFO - 2020-09-10 14:59:58 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:59:58 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:59:58 --> Utf8 Class Initialized
INFO - 2020-09-10 14:59:58 --> URI Class Initialized
INFO - 2020-09-10 14:59:58 --> Router Class Initialized
INFO - 2020-09-10 14:59:58 --> Output Class Initialized
INFO - 2020-09-10 14:59:58 --> Security Class Initialized
DEBUG - 2020-09-10 14:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:59:58 --> Input Class Initialized
INFO - 2020-09-10 14:59:58 --> Language Class Initialized
INFO - 2020-09-10 14:59:58 --> Loader Class Initialized
INFO - 2020-09-10 14:59:58 --> Helper loaded: url_helper
INFO - 2020-09-10 14:59:58 --> Database Driver Class Initialized
INFO - 2020-09-10 14:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:59:58 --> Email Class Initialized
INFO - 2020-09-10 14:59:58 --> Controller Class Initialized
INFO - 2020-09-10 14:59:58 --> Model Class Initialized
INFO - 2020-09-10 14:59:58 --> Model Class Initialized
INFO - 2020-09-10 14:59:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 14:59:58 --> Final output sent to browser
DEBUG - 2020-09-10 14:59:58 --> Total execution time: 0.0796
ERROR - 2020-09-10 14:59:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 14:59:58 --> Config Class Initialized
INFO - 2020-09-10 14:59:58 --> Hooks Class Initialized
DEBUG - 2020-09-10 14:59:58 --> UTF-8 Support Enabled
INFO - 2020-09-10 14:59:58 --> Utf8 Class Initialized
INFO - 2020-09-10 14:59:58 --> URI Class Initialized
INFO - 2020-09-10 14:59:58 --> Router Class Initialized
INFO - 2020-09-10 14:59:58 --> Output Class Initialized
INFO - 2020-09-10 14:59:58 --> Security Class Initialized
DEBUG - 2020-09-10 14:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 14:59:58 --> Input Class Initialized
INFO - 2020-09-10 14:59:58 --> Language Class Initialized
INFO - 2020-09-10 14:59:58 --> Loader Class Initialized
INFO - 2020-09-10 14:59:58 --> Helper loaded: url_helper
INFO - 2020-09-10 14:59:58 --> Database Driver Class Initialized
INFO - 2020-09-10 14:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 14:59:58 --> Email Class Initialized
INFO - 2020-09-10 14:59:58 --> Controller Class Initialized
INFO - 2020-09-10 14:59:58 --> Model Class Initialized
INFO - 2020-09-10 14:59:58 --> Model Class Initialized
INFO - 2020-09-10 14:59:58 --> Final output sent to browser
DEBUG - 2020-09-10 14:59:58 --> Total execution time: 0.0557
ERROR - 2020-09-10 15:00:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:00:13 --> Config Class Initialized
INFO - 2020-09-10 15:00:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:00:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:00:13 --> Utf8 Class Initialized
INFO - 2020-09-10 15:00:13 --> URI Class Initialized
INFO - 2020-09-10 15:00:13 --> Router Class Initialized
INFO - 2020-09-10 15:00:13 --> Output Class Initialized
INFO - 2020-09-10 15:00:13 --> Security Class Initialized
DEBUG - 2020-09-10 15:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:00:13 --> Input Class Initialized
INFO - 2020-09-10 15:00:13 --> Language Class Initialized
INFO - 2020-09-10 15:00:13 --> Loader Class Initialized
INFO - 2020-09-10 15:00:13 --> Helper loaded: url_helper
INFO - 2020-09-10 15:00:13 --> Database Driver Class Initialized
INFO - 2020-09-10 15:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:00:13 --> Email Class Initialized
INFO - 2020-09-10 15:00:13 --> Controller Class Initialized
INFO - 2020-09-10 15:00:13 --> Model Class Initialized
INFO - 2020-09-10 15:00:13 --> Model Class Initialized
INFO - 2020-09-10 15:00:13 --> Final output sent to browser
DEBUG - 2020-09-10 15:00:13 --> Total execution time: 0.2135
ERROR - 2020-09-10 15:00:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:00:13 --> Config Class Initialized
INFO - 2020-09-10 15:00:13 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:00:13 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:00:13 --> Utf8 Class Initialized
INFO - 2020-09-10 15:00:13 --> URI Class Initialized
INFO - 2020-09-10 15:00:13 --> Router Class Initialized
INFO - 2020-09-10 15:00:13 --> Output Class Initialized
INFO - 2020-09-10 15:00:13 --> Security Class Initialized
DEBUG - 2020-09-10 15:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:00:13 --> Input Class Initialized
INFO - 2020-09-10 15:00:13 --> Language Class Initialized
INFO - 2020-09-10 15:00:13 --> Loader Class Initialized
INFO - 2020-09-10 15:00:13 --> Helper loaded: url_helper
INFO - 2020-09-10 15:00:13 --> Database Driver Class Initialized
INFO - 2020-09-10 15:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:00:13 --> Email Class Initialized
INFO - 2020-09-10 15:00:13 --> Controller Class Initialized
INFO - 2020-09-10 15:00:13 --> Model Class Initialized
INFO - 2020-09-10 15:00:13 --> Model Class Initialized
INFO - 2020-09-10 15:00:13 --> Final output sent to browser
DEBUG - 2020-09-10 15:00:13 --> Total execution time: 0.0353
ERROR - 2020-09-10 15:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:00:20 --> Config Class Initialized
INFO - 2020-09-10 15:00:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:00:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:00:20 --> Utf8 Class Initialized
INFO - 2020-09-10 15:00:20 --> URI Class Initialized
INFO - 2020-09-10 15:00:20 --> Router Class Initialized
INFO - 2020-09-10 15:00:20 --> Output Class Initialized
INFO - 2020-09-10 15:00:20 --> Security Class Initialized
DEBUG - 2020-09-10 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:00:20 --> Input Class Initialized
INFO - 2020-09-10 15:00:20 --> Language Class Initialized
INFO - 2020-09-10 15:00:20 --> Loader Class Initialized
INFO - 2020-09-10 15:00:20 --> Helper loaded: url_helper
INFO - 2020-09-10 15:00:20 --> Database Driver Class Initialized
INFO - 2020-09-10 15:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:00:20 --> Email Class Initialized
INFO - 2020-09-10 15:00:20 --> Controller Class Initialized
INFO - 2020-09-10 15:00:20 --> Model Class Initialized
INFO - 2020-09-10 15:00:20 --> Model Class Initialized
INFO - 2020-09-10 15:00:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:00:20 --> Final output sent to browser
DEBUG - 2020-09-10 15:00:20 --> Total execution time: 0.0524
ERROR - 2020-09-10 15:00:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:00:20 --> Config Class Initialized
INFO - 2020-09-10 15:00:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:00:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:00:20 --> Utf8 Class Initialized
INFO - 2020-09-10 15:00:20 --> URI Class Initialized
INFO - 2020-09-10 15:00:20 --> Router Class Initialized
INFO - 2020-09-10 15:00:20 --> Output Class Initialized
INFO - 2020-09-10 15:00:20 --> Security Class Initialized
DEBUG - 2020-09-10 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:00:20 --> Input Class Initialized
INFO - 2020-09-10 15:00:20 --> Language Class Initialized
INFO - 2020-09-10 15:00:20 --> Loader Class Initialized
INFO - 2020-09-10 15:00:20 --> Helper loaded: url_helper
INFO - 2020-09-10 15:00:20 --> Database Driver Class Initialized
INFO - 2020-09-10 15:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:00:20 --> Email Class Initialized
INFO - 2020-09-10 15:00:20 --> Controller Class Initialized
INFO - 2020-09-10 15:00:20 --> Model Class Initialized
INFO - 2020-09-10 15:00:20 --> Model Class Initialized
INFO - 2020-09-10 15:00:20 --> Final output sent to browser
DEBUG - 2020-09-10 15:00:20 --> Total execution time: 0.0391
ERROR - 2020-09-10 15:02:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:02:46 --> Config Class Initialized
INFO - 2020-09-10 15:02:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:02:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:02:46 --> Utf8 Class Initialized
INFO - 2020-09-10 15:02:46 --> URI Class Initialized
INFO - 2020-09-10 15:02:46 --> Router Class Initialized
INFO - 2020-09-10 15:02:46 --> Output Class Initialized
INFO - 2020-09-10 15:02:46 --> Security Class Initialized
DEBUG - 2020-09-10 15:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:02:46 --> Input Class Initialized
INFO - 2020-09-10 15:02:46 --> Language Class Initialized
INFO - 2020-09-10 15:02:46 --> Loader Class Initialized
INFO - 2020-09-10 15:02:46 --> Helper loaded: url_helper
INFO - 2020-09-10 15:02:46 --> Database Driver Class Initialized
INFO - 2020-09-10 15:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:02:46 --> Email Class Initialized
INFO - 2020-09-10 15:02:46 --> Controller Class Initialized
INFO - 2020-09-10 15:02:46 --> Model Class Initialized
INFO - 2020-09-10 15:02:46 --> Model Class Initialized
INFO - 2020-09-10 15:02:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:02:46 --> Final output sent to browser
DEBUG - 2020-09-10 15:02:46 --> Total execution time: 0.0419
ERROR - 2020-09-10 15:02:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:02:47 --> Config Class Initialized
INFO - 2020-09-10 15:02:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:02:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:02:47 --> Utf8 Class Initialized
INFO - 2020-09-10 15:02:47 --> URI Class Initialized
INFO - 2020-09-10 15:02:47 --> Router Class Initialized
INFO - 2020-09-10 15:02:47 --> Output Class Initialized
INFO - 2020-09-10 15:02:47 --> Security Class Initialized
DEBUG - 2020-09-10 15:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:02:47 --> Input Class Initialized
INFO - 2020-09-10 15:02:47 --> Language Class Initialized
INFO - 2020-09-10 15:02:47 --> Loader Class Initialized
INFO - 2020-09-10 15:02:47 --> Helper loaded: url_helper
INFO - 2020-09-10 15:02:47 --> Database Driver Class Initialized
INFO - 2020-09-10 15:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:02:47 --> Email Class Initialized
INFO - 2020-09-10 15:02:47 --> Controller Class Initialized
INFO - 2020-09-10 15:02:47 --> Model Class Initialized
INFO - 2020-09-10 15:02:47 --> Model Class Initialized
INFO - 2020-09-10 15:02:47 --> Final output sent to browser
DEBUG - 2020-09-10 15:02:47 --> Total execution time: 0.0433
ERROR - 2020-09-10 15:04:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:04:40 --> Config Class Initialized
INFO - 2020-09-10 15:04:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:04:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:04:40 --> Utf8 Class Initialized
INFO - 2020-09-10 15:04:40 --> URI Class Initialized
INFO - 2020-09-10 15:04:40 --> Router Class Initialized
INFO - 2020-09-10 15:04:40 --> Output Class Initialized
INFO - 2020-09-10 15:04:40 --> Security Class Initialized
DEBUG - 2020-09-10 15:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:04:40 --> Input Class Initialized
INFO - 2020-09-10 15:04:40 --> Language Class Initialized
INFO - 2020-09-10 15:04:40 --> Loader Class Initialized
INFO - 2020-09-10 15:04:40 --> Helper loaded: url_helper
INFO - 2020-09-10 15:04:40 --> Database Driver Class Initialized
INFO - 2020-09-10 15:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:04:40 --> Email Class Initialized
INFO - 2020-09-10 15:04:40 --> Controller Class Initialized
INFO - 2020-09-10 15:04:40 --> Model Class Initialized
INFO - 2020-09-10 15:04:40 --> Model Class Initialized
INFO - 2020-09-10 15:04:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:04:40 --> Final output sent to browser
DEBUG - 2020-09-10 15:04:40 --> Total execution time: 0.1019
ERROR - 2020-09-10 15:04:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:04:41 --> Config Class Initialized
INFO - 2020-09-10 15:04:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:04:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:04:41 --> Utf8 Class Initialized
INFO - 2020-09-10 15:04:41 --> URI Class Initialized
INFO - 2020-09-10 15:04:41 --> Router Class Initialized
INFO - 2020-09-10 15:04:41 --> Output Class Initialized
INFO - 2020-09-10 15:04:41 --> Security Class Initialized
DEBUG - 2020-09-10 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:04:41 --> Input Class Initialized
INFO - 2020-09-10 15:04:41 --> Language Class Initialized
INFO - 2020-09-10 15:04:41 --> Loader Class Initialized
INFO - 2020-09-10 15:04:41 --> Helper loaded: url_helper
INFO - 2020-09-10 15:04:41 --> Database Driver Class Initialized
INFO - 2020-09-10 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:04:41 --> Email Class Initialized
INFO - 2020-09-10 15:04:41 --> Controller Class Initialized
INFO - 2020-09-10 15:04:41 --> Model Class Initialized
INFO - 2020-09-10 15:04:41 --> Model Class Initialized
INFO - 2020-09-10 15:04:41 --> Final output sent to browser
DEBUG - 2020-09-10 15:04:41 --> Total execution time: 0.0392
ERROR - 2020-09-10 15:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:12:55 --> Config Class Initialized
INFO - 2020-09-10 15:12:55 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:12:55 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:12:55 --> Utf8 Class Initialized
INFO - 2020-09-10 15:12:55 --> URI Class Initialized
INFO - 2020-09-10 15:12:55 --> Router Class Initialized
INFO - 2020-09-10 15:12:55 --> Output Class Initialized
INFO - 2020-09-10 15:12:55 --> Security Class Initialized
DEBUG - 2020-09-10 15:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:12:55 --> Input Class Initialized
INFO - 2020-09-10 15:12:55 --> Language Class Initialized
INFO - 2020-09-10 15:12:55 --> Loader Class Initialized
INFO - 2020-09-10 15:12:55 --> Helper loaded: url_helper
INFO - 2020-09-10 15:12:55 --> Database Driver Class Initialized
INFO - 2020-09-10 15:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:12:55 --> Email Class Initialized
INFO - 2020-09-10 15:12:55 --> Controller Class Initialized
INFO - 2020-09-10 15:12:55 --> Model Class Initialized
INFO - 2020-09-10 15:12:55 --> Model Class Initialized
INFO - 2020-09-10 15:12:55 --> Final output sent to browser
DEBUG - 2020-09-10 15:12:55 --> Total execution time: 0.1449
ERROR - 2020-09-10 15:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:12:56 --> Config Class Initialized
INFO - 2020-09-10 15:12:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:12:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:12:56 --> Utf8 Class Initialized
INFO - 2020-09-10 15:12:56 --> URI Class Initialized
INFO - 2020-09-10 15:12:56 --> Router Class Initialized
INFO - 2020-09-10 15:12:56 --> Output Class Initialized
INFO - 2020-09-10 15:12:56 --> Security Class Initialized
DEBUG - 2020-09-10 15:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:12:56 --> Input Class Initialized
INFO - 2020-09-10 15:12:56 --> Language Class Initialized
INFO - 2020-09-10 15:12:56 --> Loader Class Initialized
INFO - 2020-09-10 15:12:56 --> Helper loaded: url_helper
INFO - 2020-09-10 15:12:56 --> Database Driver Class Initialized
INFO - 2020-09-10 15:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:12:56 --> Email Class Initialized
INFO - 2020-09-10 15:12:56 --> Controller Class Initialized
INFO - 2020-09-10 15:12:56 --> Model Class Initialized
INFO - 2020-09-10 15:12:56 --> Model Class Initialized
INFO - 2020-09-10 15:12:56 --> Final output sent to browser
DEBUG - 2020-09-10 15:12:56 --> Total execution time: 0.0405
ERROR - 2020-09-10 15:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:13:01 --> Config Class Initialized
INFO - 2020-09-10 15:13:01 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:13:01 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:13:01 --> Utf8 Class Initialized
INFO - 2020-09-10 15:13:01 --> URI Class Initialized
INFO - 2020-09-10 15:13:01 --> Router Class Initialized
INFO - 2020-09-10 15:13:01 --> Output Class Initialized
INFO - 2020-09-10 15:13:01 --> Security Class Initialized
DEBUG - 2020-09-10 15:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:13:01 --> Input Class Initialized
INFO - 2020-09-10 15:13:01 --> Language Class Initialized
INFO - 2020-09-10 15:13:01 --> Loader Class Initialized
INFO - 2020-09-10 15:13:01 --> Helper loaded: url_helper
INFO - 2020-09-10 15:13:01 --> Database Driver Class Initialized
INFO - 2020-09-10 15:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:13:01 --> Email Class Initialized
INFO - 2020-09-10 15:13:01 --> Controller Class Initialized
INFO - 2020-09-10 15:13:01 --> Model Class Initialized
INFO - 2020-09-10 15:13:01 --> Model Class Initialized
INFO - 2020-09-10 15:13:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:13:01 --> Final output sent to browser
DEBUG - 2020-09-10 15:13:01 --> Total execution time: 0.1343
ERROR - 2020-09-10 15:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:13:01 --> Config Class Initialized
INFO - 2020-09-10 15:13:01 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:13:01 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:13:01 --> Utf8 Class Initialized
INFO - 2020-09-10 15:13:01 --> URI Class Initialized
INFO - 2020-09-10 15:13:01 --> Router Class Initialized
INFO - 2020-09-10 15:13:01 --> Output Class Initialized
INFO - 2020-09-10 15:13:01 --> Security Class Initialized
DEBUG - 2020-09-10 15:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:13:01 --> Input Class Initialized
INFO - 2020-09-10 15:13:01 --> Language Class Initialized
INFO - 2020-09-10 15:13:01 --> Loader Class Initialized
INFO - 2020-09-10 15:13:01 --> Helper loaded: url_helper
INFO - 2020-09-10 15:13:02 --> Database Driver Class Initialized
INFO - 2020-09-10 15:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:13:02 --> Email Class Initialized
INFO - 2020-09-10 15:13:02 --> Controller Class Initialized
INFO - 2020-09-10 15:13:02 --> Model Class Initialized
INFO - 2020-09-10 15:13:02 --> Model Class Initialized
INFO - 2020-09-10 15:13:02 --> Final output sent to browser
DEBUG - 2020-09-10 15:13:02 --> Total execution time: 0.0452
ERROR - 2020-09-10 15:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:14:28 --> Config Class Initialized
INFO - 2020-09-10 15:14:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:14:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:14:28 --> Utf8 Class Initialized
INFO - 2020-09-10 15:14:28 --> URI Class Initialized
INFO - 2020-09-10 15:14:28 --> Router Class Initialized
INFO - 2020-09-10 15:14:28 --> Output Class Initialized
INFO - 2020-09-10 15:14:28 --> Security Class Initialized
DEBUG - 2020-09-10 15:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:14:28 --> Input Class Initialized
INFO - 2020-09-10 15:14:28 --> Language Class Initialized
INFO - 2020-09-10 15:14:28 --> Loader Class Initialized
INFO - 2020-09-10 15:14:28 --> Helper loaded: url_helper
INFO - 2020-09-10 15:14:28 --> Database Driver Class Initialized
INFO - 2020-09-10 15:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:14:28 --> Email Class Initialized
INFO - 2020-09-10 15:14:28 --> Controller Class Initialized
INFO - 2020-09-10 15:14:28 --> Model Class Initialized
INFO - 2020-09-10 15:14:28 --> Model Class Initialized
INFO - 2020-09-10 15:14:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:14:28 --> Final output sent to browser
DEBUG - 2020-09-10 15:14:28 --> Total execution time: 0.0413
ERROR - 2020-09-10 15:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:14:28 --> Config Class Initialized
INFO - 2020-09-10 15:14:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:14:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:14:28 --> Utf8 Class Initialized
INFO - 2020-09-10 15:14:28 --> URI Class Initialized
INFO - 2020-09-10 15:14:28 --> Router Class Initialized
INFO - 2020-09-10 15:14:28 --> Output Class Initialized
INFO - 2020-09-10 15:14:28 --> Security Class Initialized
DEBUG - 2020-09-10 15:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:14:28 --> Input Class Initialized
INFO - 2020-09-10 15:14:28 --> Language Class Initialized
INFO - 2020-09-10 15:14:28 --> Loader Class Initialized
INFO - 2020-09-10 15:14:28 --> Helper loaded: url_helper
INFO - 2020-09-10 15:14:28 --> Database Driver Class Initialized
INFO - 2020-09-10 15:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:14:28 --> Email Class Initialized
INFO - 2020-09-10 15:14:28 --> Controller Class Initialized
INFO - 2020-09-10 15:14:28 --> Model Class Initialized
INFO - 2020-09-10 15:14:28 --> Model Class Initialized
INFO - 2020-09-10 15:14:28 --> Final output sent to browser
DEBUG - 2020-09-10 15:14:28 --> Total execution time: 0.0476
ERROR - 2020-09-10 15:14:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:14:36 --> Config Class Initialized
INFO - 2020-09-10 15:14:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:14:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:14:36 --> Utf8 Class Initialized
INFO - 2020-09-10 15:14:36 --> URI Class Initialized
INFO - 2020-09-10 15:14:36 --> Router Class Initialized
INFO - 2020-09-10 15:14:36 --> Output Class Initialized
INFO - 2020-09-10 15:14:36 --> Security Class Initialized
DEBUG - 2020-09-10 15:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:14:36 --> Input Class Initialized
INFO - 2020-09-10 15:14:36 --> Language Class Initialized
INFO - 2020-09-10 15:14:36 --> Loader Class Initialized
INFO - 2020-09-10 15:14:36 --> Helper loaded: url_helper
INFO - 2020-09-10 15:14:36 --> Database Driver Class Initialized
INFO - 2020-09-10 15:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:14:36 --> Email Class Initialized
INFO - 2020-09-10 15:14:36 --> Controller Class Initialized
INFO - 2020-09-10 15:14:36 --> Model Class Initialized
INFO - 2020-09-10 15:14:36 --> Model Class Initialized
INFO - 2020-09-10 15:14:36 --> Final output sent to browser
DEBUG - 2020-09-10 15:14:36 --> Total execution time: 0.1488
ERROR - 2020-09-10 15:14:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:14:36 --> Config Class Initialized
INFO - 2020-09-10 15:14:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:14:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:14:36 --> Utf8 Class Initialized
INFO - 2020-09-10 15:14:36 --> URI Class Initialized
INFO - 2020-09-10 15:14:36 --> Router Class Initialized
INFO - 2020-09-10 15:14:36 --> Output Class Initialized
INFO - 2020-09-10 15:14:36 --> Security Class Initialized
DEBUG - 2020-09-10 15:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:14:36 --> Input Class Initialized
INFO - 2020-09-10 15:14:36 --> Language Class Initialized
INFO - 2020-09-10 15:14:36 --> Loader Class Initialized
INFO - 2020-09-10 15:14:36 --> Helper loaded: url_helper
INFO - 2020-09-10 15:14:36 --> Database Driver Class Initialized
INFO - 2020-09-10 15:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:14:36 --> Email Class Initialized
INFO - 2020-09-10 15:14:36 --> Controller Class Initialized
INFO - 2020-09-10 15:14:36 --> Model Class Initialized
INFO - 2020-09-10 15:14:36 --> Model Class Initialized
INFO - 2020-09-10 15:14:36 --> Final output sent to browser
DEBUG - 2020-09-10 15:14:36 --> Total execution time: 0.0454
ERROR - 2020-09-10 15:15:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:15:06 --> Config Class Initialized
INFO - 2020-09-10 15:15:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:15:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:15:06 --> Utf8 Class Initialized
INFO - 2020-09-10 15:15:06 --> URI Class Initialized
INFO - 2020-09-10 15:15:06 --> Router Class Initialized
INFO - 2020-09-10 15:15:06 --> Output Class Initialized
INFO - 2020-09-10 15:15:06 --> Security Class Initialized
DEBUG - 2020-09-10 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:15:06 --> Input Class Initialized
INFO - 2020-09-10 15:15:06 --> Language Class Initialized
INFO - 2020-09-10 15:15:06 --> Loader Class Initialized
INFO - 2020-09-10 15:15:06 --> Helper loaded: url_helper
INFO - 2020-09-10 15:15:06 --> Database Driver Class Initialized
INFO - 2020-09-10 15:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:15:06 --> Email Class Initialized
INFO - 2020-09-10 15:15:06 --> Controller Class Initialized
INFO - 2020-09-10 15:15:06 --> Model Class Initialized
INFO - 2020-09-10 15:15:06 --> Model Class Initialized
INFO - 2020-09-10 15:15:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:15:06 --> Final output sent to browser
DEBUG - 2020-09-10 15:15:06 --> Total execution time: 0.1093
ERROR - 2020-09-10 15:15:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:15:06 --> Config Class Initialized
INFO - 2020-09-10 15:15:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:15:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:15:06 --> Utf8 Class Initialized
INFO - 2020-09-10 15:15:06 --> URI Class Initialized
INFO - 2020-09-10 15:15:06 --> Router Class Initialized
INFO - 2020-09-10 15:15:06 --> Output Class Initialized
INFO - 2020-09-10 15:15:06 --> Security Class Initialized
DEBUG - 2020-09-10 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:15:06 --> Input Class Initialized
INFO - 2020-09-10 15:15:06 --> Language Class Initialized
INFO - 2020-09-10 15:15:06 --> Loader Class Initialized
INFO - 2020-09-10 15:15:06 --> Helper loaded: url_helper
INFO - 2020-09-10 15:15:06 --> Database Driver Class Initialized
INFO - 2020-09-10 15:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:15:06 --> Email Class Initialized
INFO - 2020-09-10 15:15:06 --> Controller Class Initialized
INFO - 2020-09-10 15:15:06 --> Model Class Initialized
INFO - 2020-09-10 15:15:06 --> Model Class Initialized
INFO - 2020-09-10 15:15:06 --> Final output sent to browser
DEBUG - 2020-09-10 15:15:06 --> Total execution time: 0.0446
ERROR - 2020-09-10 15:16:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:16:19 --> Config Class Initialized
INFO - 2020-09-10 15:16:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:16:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:16:19 --> Utf8 Class Initialized
INFO - 2020-09-10 15:16:19 --> URI Class Initialized
INFO - 2020-09-10 15:16:19 --> Router Class Initialized
INFO - 2020-09-10 15:16:19 --> Output Class Initialized
INFO - 2020-09-10 15:16:19 --> Security Class Initialized
DEBUG - 2020-09-10 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:16:19 --> Input Class Initialized
INFO - 2020-09-10 15:16:19 --> Language Class Initialized
INFO - 2020-09-10 15:16:19 --> Loader Class Initialized
INFO - 2020-09-10 15:16:19 --> Helper loaded: url_helper
INFO - 2020-09-10 15:16:19 --> Database Driver Class Initialized
INFO - 2020-09-10 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:16:19 --> Email Class Initialized
INFO - 2020-09-10 15:16:19 --> Controller Class Initialized
INFO - 2020-09-10 15:16:19 --> Model Class Initialized
INFO - 2020-09-10 15:16:19 --> Model Class Initialized
INFO - 2020-09-10 15:16:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:16:19 --> Final output sent to browser
DEBUG - 2020-09-10 15:16:19 --> Total execution time: 0.0351
ERROR - 2020-09-10 15:16:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:16:19 --> Config Class Initialized
INFO - 2020-09-10 15:16:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:16:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:16:19 --> Utf8 Class Initialized
INFO - 2020-09-10 15:16:19 --> URI Class Initialized
INFO - 2020-09-10 15:16:19 --> Router Class Initialized
INFO - 2020-09-10 15:16:19 --> Output Class Initialized
INFO - 2020-09-10 15:16:19 --> Security Class Initialized
DEBUG - 2020-09-10 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:16:19 --> Input Class Initialized
INFO - 2020-09-10 15:16:19 --> Language Class Initialized
INFO - 2020-09-10 15:16:19 --> Loader Class Initialized
INFO - 2020-09-10 15:16:19 --> Helper loaded: url_helper
INFO - 2020-09-10 15:16:19 --> Database Driver Class Initialized
INFO - 2020-09-10 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:16:19 --> Email Class Initialized
INFO - 2020-09-10 15:16:19 --> Controller Class Initialized
INFO - 2020-09-10 15:16:19 --> Model Class Initialized
INFO - 2020-09-10 15:16:19 --> Model Class Initialized
INFO - 2020-09-10 15:16:19 --> Final output sent to browser
DEBUG - 2020-09-10 15:16:19 --> Total execution time: 0.0551
ERROR - 2020-09-10 15:16:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:16:23 --> Config Class Initialized
INFO - 2020-09-10 15:16:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:16:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:16:23 --> Utf8 Class Initialized
INFO - 2020-09-10 15:16:23 --> URI Class Initialized
INFO - 2020-09-10 15:16:23 --> Router Class Initialized
INFO - 2020-09-10 15:16:23 --> Output Class Initialized
INFO - 2020-09-10 15:16:23 --> Security Class Initialized
DEBUG - 2020-09-10 15:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:16:23 --> Input Class Initialized
INFO - 2020-09-10 15:16:23 --> Language Class Initialized
INFO - 2020-09-10 15:16:23 --> Loader Class Initialized
INFO - 2020-09-10 15:16:23 --> Helper loaded: url_helper
INFO - 2020-09-10 15:16:23 --> Database Driver Class Initialized
INFO - 2020-09-10 15:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:16:23 --> Email Class Initialized
INFO - 2020-09-10 15:16:23 --> Controller Class Initialized
INFO - 2020-09-10 15:16:23 --> Model Class Initialized
INFO - 2020-09-10 15:16:23 --> Model Class Initialized
INFO - 2020-09-10 15:16:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:16:23 --> Final output sent to browser
DEBUG - 2020-09-10 15:16:23 --> Total execution time: 0.0896
ERROR - 2020-09-10 15:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:16:24 --> Config Class Initialized
INFO - 2020-09-10 15:16:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:16:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:16:24 --> Utf8 Class Initialized
INFO - 2020-09-10 15:16:24 --> URI Class Initialized
INFO - 2020-09-10 15:16:24 --> Router Class Initialized
INFO - 2020-09-10 15:16:24 --> Output Class Initialized
INFO - 2020-09-10 15:16:24 --> Security Class Initialized
DEBUG - 2020-09-10 15:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:16:24 --> Input Class Initialized
INFO - 2020-09-10 15:16:24 --> Language Class Initialized
INFO - 2020-09-10 15:16:24 --> Loader Class Initialized
INFO - 2020-09-10 15:16:24 --> Helper loaded: url_helper
INFO - 2020-09-10 15:16:24 --> Database Driver Class Initialized
INFO - 2020-09-10 15:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:16:24 --> Email Class Initialized
INFO - 2020-09-10 15:16:24 --> Controller Class Initialized
INFO - 2020-09-10 15:16:24 --> Model Class Initialized
INFO - 2020-09-10 15:16:24 --> Model Class Initialized
INFO - 2020-09-10 15:16:24 --> Final output sent to browser
DEBUG - 2020-09-10 15:16:24 --> Total execution time: 0.0462
ERROR - 2020-09-10 15:20:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:20:36 --> Config Class Initialized
INFO - 2020-09-10 15:20:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:20:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:20:36 --> Utf8 Class Initialized
INFO - 2020-09-10 15:20:36 --> URI Class Initialized
INFO - 2020-09-10 15:20:36 --> Router Class Initialized
INFO - 2020-09-10 15:20:36 --> Output Class Initialized
INFO - 2020-09-10 15:20:36 --> Security Class Initialized
DEBUG - 2020-09-10 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:20:36 --> Input Class Initialized
INFO - 2020-09-10 15:20:36 --> Language Class Initialized
INFO - 2020-09-10 15:20:36 --> Loader Class Initialized
INFO - 2020-09-10 15:20:36 --> Helper loaded: url_helper
INFO - 2020-09-10 15:20:36 --> Database Driver Class Initialized
INFO - 2020-09-10 15:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:20:36 --> Email Class Initialized
INFO - 2020-09-10 15:20:36 --> Controller Class Initialized
DEBUG - 2020-09-10 15:20:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:20:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:20:36 --> Model Class Initialized
INFO - 2020-09-10 15:20:36 --> Model Class Initialized
INFO - 2020-09-10 15:20:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:20:36 --> Final output sent to browser
DEBUG - 2020-09-10 15:20:36 --> Total execution time: 0.0196
ERROR - 2020-09-10 15:23:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:23:37 --> Config Class Initialized
INFO - 2020-09-10 15:23:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:23:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:23:37 --> Utf8 Class Initialized
INFO - 2020-09-10 15:23:37 --> URI Class Initialized
INFO - 2020-09-10 15:23:37 --> Router Class Initialized
INFO - 2020-09-10 15:23:37 --> Output Class Initialized
INFO - 2020-09-10 15:23:37 --> Security Class Initialized
DEBUG - 2020-09-10 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:23:37 --> Input Class Initialized
INFO - 2020-09-10 15:23:37 --> Language Class Initialized
INFO - 2020-09-10 15:23:37 --> Loader Class Initialized
INFO - 2020-09-10 15:23:37 --> Helper loaded: url_helper
INFO - 2020-09-10 15:23:37 --> Database Driver Class Initialized
INFO - 2020-09-10 15:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:23:37 --> Email Class Initialized
INFO - 2020-09-10 15:23:37 --> Controller Class Initialized
DEBUG - 2020-09-10 15:23:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:23:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:23:37 --> Model Class Initialized
INFO - 2020-09-10 15:23:37 --> Model Class Initialized
INFO - 2020-09-10 15:23:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:23:37 --> Final output sent to browser
DEBUG - 2020-09-10 15:23:37 --> Total execution time: 0.0209
ERROR - 2020-09-10 15:26:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:35 --> Config Class Initialized
INFO - 2020-09-10 15:26:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:35 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:35 --> URI Class Initialized
INFO - 2020-09-10 15:26:35 --> Router Class Initialized
INFO - 2020-09-10 15:26:35 --> Output Class Initialized
INFO - 2020-09-10 15:26:35 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:35 --> Input Class Initialized
INFO - 2020-09-10 15:26:35 --> Language Class Initialized
INFO - 2020-09-10 15:26:35 --> Loader Class Initialized
INFO - 2020-09-10 15:26:35 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:35 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:35 --> Email Class Initialized
INFO - 2020-09-10 15:26:35 --> Controller Class Initialized
INFO - 2020-09-10 15:26:35 --> Model Class Initialized
INFO - 2020-09-10 15:26:35 --> Model Class Initialized
INFO - 2020-09-10 15:26:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:26:35 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:35 --> Total execution time: 0.0367
ERROR - 2020-09-10 15:26:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:36 --> Config Class Initialized
INFO - 2020-09-10 15:26:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:36 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:36 --> URI Class Initialized
INFO - 2020-09-10 15:26:36 --> Router Class Initialized
INFO - 2020-09-10 15:26:36 --> Output Class Initialized
INFO - 2020-09-10 15:26:36 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:36 --> Input Class Initialized
INFO - 2020-09-10 15:26:36 --> Language Class Initialized
INFO - 2020-09-10 15:26:36 --> Loader Class Initialized
INFO - 2020-09-10 15:26:36 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:36 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:36 --> Email Class Initialized
INFO - 2020-09-10 15:26:36 --> Controller Class Initialized
INFO - 2020-09-10 15:26:36 --> Model Class Initialized
INFO - 2020-09-10 15:26:36 --> Model Class Initialized
INFO - 2020-09-10 15:26:36 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:36 --> Total execution time: 0.0416
ERROR - 2020-09-10 15:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:41 --> Config Class Initialized
INFO - 2020-09-10 15:26:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:41 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:41 --> URI Class Initialized
INFO - 2020-09-10 15:26:41 --> Router Class Initialized
INFO - 2020-09-10 15:26:41 --> Output Class Initialized
INFO - 2020-09-10 15:26:41 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:41 --> Input Class Initialized
INFO - 2020-09-10 15:26:41 --> Language Class Initialized
INFO - 2020-09-10 15:26:41 --> Loader Class Initialized
INFO - 2020-09-10 15:26:41 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:41 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:41 --> Email Class Initialized
INFO - 2020-09-10 15:26:41 --> Controller Class Initialized
INFO - 2020-09-10 15:26:41 --> Model Class Initialized
INFO - 2020-09-10 15:26:41 --> Model Class Initialized
INFO - 2020-09-10 15:26:42 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:42 --> Total execution time: 0.1319
ERROR - 2020-09-10 15:26:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:45 --> Config Class Initialized
INFO - 2020-09-10 15:26:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:45 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:45 --> URI Class Initialized
INFO - 2020-09-10 15:26:45 --> Router Class Initialized
INFO - 2020-09-10 15:26:45 --> Output Class Initialized
INFO - 2020-09-10 15:26:45 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:45 --> Input Class Initialized
INFO - 2020-09-10 15:26:45 --> Language Class Initialized
INFO - 2020-09-10 15:26:45 --> Loader Class Initialized
INFO - 2020-09-10 15:26:45 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:45 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:45 --> Email Class Initialized
INFO - 2020-09-10 15:26:45 --> Controller Class Initialized
INFO - 2020-09-10 15:26:45 --> Model Class Initialized
INFO - 2020-09-10 15:26:45 --> Model Class Initialized
INFO - 2020-09-10 15:26:45 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:45 --> Total execution time: 0.1149
ERROR - 2020-09-10 15:26:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:46 --> Config Class Initialized
INFO - 2020-09-10 15:26:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:46 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:46 --> URI Class Initialized
INFO - 2020-09-10 15:26:46 --> Router Class Initialized
INFO - 2020-09-10 15:26:46 --> Output Class Initialized
INFO - 2020-09-10 15:26:46 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:46 --> Input Class Initialized
INFO - 2020-09-10 15:26:46 --> Language Class Initialized
INFO - 2020-09-10 15:26:46 --> Loader Class Initialized
INFO - 2020-09-10 15:26:46 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:46 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:46 --> Email Class Initialized
INFO - 2020-09-10 15:26:46 --> Controller Class Initialized
INFO - 2020-09-10 15:26:46 --> Model Class Initialized
INFO - 2020-09-10 15:26:46 --> Model Class Initialized
INFO - 2020-09-10 15:26:46 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:46 --> Total execution time: 0.0428
ERROR - 2020-09-10 15:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:50 --> Config Class Initialized
INFO - 2020-09-10 15:26:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:50 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:50 --> URI Class Initialized
INFO - 2020-09-10 15:26:50 --> Router Class Initialized
INFO - 2020-09-10 15:26:50 --> Output Class Initialized
INFO - 2020-09-10 15:26:50 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:50 --> Input Class Initialized
INFO - 2020-09-10 15:26:50 --> Language Class Initialized
INFO - 2020-09-10 15:26:50 --> Loader Class Initialized
INFO - 2020-09-10 15:26:50 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:50 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:50 --> Email Class Initialized
INFO - 2020-09-10 15:26:50 --> Controller Class Initialized
INFO - 2020-09-10 15:26:50 --> Model Class Initialized
INFO - 2020-09-10 15:26:50 --> Model Class Initialized
INFO - 2020-09-10 15:26:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 15:26:50 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:50 --> Total execution time: 0.0371
ERROR - 2020-09-10 15:26:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:50 --> Config Class Initialized
INFO - 2020-09-10 15:26:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:50 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:50 --> URI Class Initialized
INFO - 2020-09-10 15:26:50 --> Router Class Initialized
INFO - 2020-09-10 15:26:50 --> Output Class Initialized
INFO - 2020-09-10 15:26:50 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:50 --> Input Class Initialized
INFO - 2020-09-10 15:26:50 --> Language Class Initialized
INFO - 2020-09-10 15:26:50 --> Loader Class Initialized
INFO - 2020-09-10 15:26:50 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:50 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:50 --> Email Class Initialized
INFO - 2020-09-10 15:26:50 --> Controller Class Initialized
INFO - 2020-09-10 15:26:50 --> Model Class Initialized
INFO - 2020-09-10 15:26:50 --> Model Class Initialized
INFO - 2020-09-10 15:26:50 --> Final output sent to browser
DEBUG - 2020-09-10 15:26:50 --> Total execution time: 0.0346
ERROR - 2020-09-10 15:26:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:26:55 --> Config Class Initialized
INFO - 2020-09-10 15:26:55 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:26:55 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:26:55 --> Utf8 Class Initialized
INFO - 2020-09-10 15:26:55 --> URI Class Initialized
INFO - 2020-09-10 15:26:55 --> Router Class Initialized
INFO - 2020-09-10 15:26:55 --> Output Class Initialized
INFO - 2020-09-10 15:26:55 --> Security Class Initialized
DEBUG - 2020-09-10 15:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:26:55 --> Input Class Initialized
INFO - 2020-09-10 15:26:55 --> Language Class Initialized
INFO - 2020-09-10 15:26:55 --> Loader Class Initialized
INFO - 2020-09-10 15:26:55 --> Helper loaded: url_helper
INFO - 2020-09-10 15:26:55 --> Database Driver Class Initialized
INFO - 2020-09-10 15:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:26:55 --> Email Class Initialized
INFO - 2020-09-10 15:26:55 --> Controller Class Initialized
DEBUG - 2020-09-10 15:26:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:26:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:26:55 --> Model Class Initialized
INFO - 2020-09-10 15:26:55 --> Model Class Initialized
ERROR - 2020-09-10 15:26:55 --> Severity: Parsing Error --> syntax error, unexpected 'first_name' (T_STRING), expecting ',' or ';' /home/purpu1ex/public_html/carsm/application/views/client_master_list.php 191
ERROR - 2020-09-10 15:27:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:27:26 --> Config Class Initialized
INFO - 2020-09-10 15:27:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:27:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:27:26 --> Utf8 Class Initialized
INFO - 2020-09-10 15:27:26 --> URI Class Initialized
INFO - 2020-09-10 15:27:26 --> Router Class Initialized
INFO - 2020-09-10 15:27:26 --> Output Class Initialized
INFO - 2020-09-10 15:27:26 --> Security Class Initialized
DEBUG - 2020-09-10 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:27:26 --> Input Class Initialized
INFO - 2020-09-10 15:27:26 --> Language Class Initialized
INFO - 2020-09-10 15:27:26 --> Loader Class Initialized
INFO - 2020-09-10 15:27:26 --> Helper loaded: url_helper
INFO - 2020-09-10 15:27:26 --> Database Driver Class Initialized
INFO - 2020-09-10 15:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:27:26 --> Email Class Initialized
INFO - 2020-09-10 15:27:26 --> Controller Class Initialized
DEBUG - 2020-09-10 15:27:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:27:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:27:26 --> Model Class Initialized
INFO - 2020-09-10 15:27:26 --> Model Class Initialized
INFO - 2020-09-10 15:27:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:27:26 --> Final output sent to browser
DEBUG - 2020-09-10 15:27:26 --> Total execution time: 0.0227
ERROR - 2020-09-10 15:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:29:00 --> Config Class Initialized
INFO - 2020-09-10 15:29:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:29:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:29:00 --> Utf8 Class Initialized
INFO - 2020-09-10 15:29:00 --> URI Class Initialized
INFO - 2020-09-10 15:29:00 --> Router Class Initialized
INFO - 2020-09-10 15:29:00 --> Output Class Initialized
INFO - 2020-09-10 15:29:00 --> Security Class Initialized
DEBUG - 2020-09-10 15:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:29:00 --> Input Class Initialized
INFO - 2020-09-10 15:29:00 --> Language Class Initialized
INFO - 2020-09-10 15:29:00 --> Loader Class Initialized
INFO - 2020-09-10 15:29:00 --> Helper loaded: url_helper
INFO - 2020-09-10 15:29:00 --> Database Driver Class Initialized
INFO - 2020-09-10 15:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:29:00 --> Email Class Initialized
INFO - 2020-09-10 15:29:00 --> Controller Class Initialized
DEBUG - 2020-09-10 15:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:29:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:29:00 --> Model Class Initialized
INFO - 2020-09-10 15:29:00 --> Model Class Initialized
INFO - 2020-09-10 15:29:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:29:00 --> Final output sent to browser
DEBUG - 2020-09-10 15:29:00 --> Total execution time: 0.0232
ERROR - 2020-09-10 15:30:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:30:35 --> Config Class Initialized
INFO - 2020-09-10 15:30:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:30:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:30:35 --> Utf8 Class Initialized
INFO - 2020-09-10 15:30:35 --> URI Class Initialized
INFO - 2020-09-10 15:30:35 --> Router Class Initialized
INFO - 2020-09-10 15:30:35 --> Output Class Initialized
INFO - 2020-09-10 15:30:35 --> Security Class Initialized
DEBUG - 2020-09-10 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:30:35 --> Input Class Initialized
INFO - 2020-09-10 15:30:35 --> Language Class Initialized
INFO - 2020-09-10 15:30:35 --> Loader Class Initialized
INFO - 2020-09-10 15:30:35 --> Helper loaded: url_helper
INFO - 2020-09-10 15:30:35 --> Database Driver Class Initialized
INFO - 2020-09-10 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:30:35 --> Email Class Initialized
INFO - 2020-09-10 15:30:35 --> Controller Class Initialized
DEBUG - 2020-09-10 15:30:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:30:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:30:35 --> Model Class Initialized
INFO - 2020-09-10 15:30:35 --> Model Class Initialized
INFO - 2020-09-10 15:30:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:30:35 --> Final output sent to browser
DEBUG - 2020-09-10 15:30:35 --> Total execution time: 0.0233
ERROR - 2020-09-10 15:31:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:31:15 --> Config Class Initialized
INFO - 2020-09-10 15:31:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:31:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:31:15 --> Utf8 Class Initialized
INFO - 2020-09-10 15:31:15 --> URI Class Initialized
INFO - 2020-09-10 15:31:15 --> Router Class Initialized
INFO - 2020-09-10 15:31:15 --> Output Class Initialized
INFO - 2020-09-10 15:31:15 --> Security Class Initialized
DEBUG - 2020-09-10 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:31:15 --> Input Class Initialized
INFO - 2020-09-10 15:31:15 --> Language Class Initialized
INFO - 2020-09-10 15:31:15 --> Loader Class Initialized
INFO - 2020-09-10 15:31:15 --> Helper loaded: url_helper
INFO - 2020-09-10 15:31:15 --> Database Driver Class Initialized
INFO - 2020-09-10 15:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:31:15 --> Email Class Initialized
INFO - 2020-09-10 15:31:15 --> Controller Class Initialized
DEBUG - 2020-09-10 15:31:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:31:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:31:15 --> Model Class Initialized
INFO - 2020-09-10 15:31:15 --> Model Class Initialized
INFO - 2020-09-10 15:31:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:31:15 --> Final output sent to browser
DEBUG - 2020-09-10 15:31:15 --> Total execution time: 0.0242
ERROR - 2020-09-10 15:35:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:35:53 --> Config Class Initialized
INFO - 2020-09-10 15:35:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:35:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:35:53 --> Utf8 Class Initialized
INFO - 2020-09-10 15:35:53 --> URI Class Initialized
INFO - 2020-09-10 15:35:53 --> Router Class Initialized
INFO - 2020-09-10 15:35:53 --> Output Class Initialized
INFO - 2020-09-10 15:35:53 --> Security Class Initialized
DEBUG - 2020-09-10 15:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:35:53 --> Input Class Initialized
INFO - 2020-09-10 15:35:53 --> Language Class Initialized
INFO - 2020-09-10 15:35:53 --> Loader Class Initialized
INFO - 2020-09-10 15:35:53 --> Helper loaded: url_helper
INFO - 2020-09-10 15:35:53 --> Database Driver Class Initialized
INFO - 2020-09-10 15:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:35:53 --> Email Class Initialized
INFO - 2020-09-10 15:35:53 --> Controller Class Initialized
DEBUG - 2020-09-10 15:35:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:35:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:35:53 --> Model Class Initialized
INFO - 2020-09-10 15:35:53 --> Model Class Initialized
INFO - 2020-09-10 15:35:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:35:53 --> Final output sent to browser
DEBUG - 2020-09-10 15:35:53 --> Total execution time: 0.0229
ERROR - 2020-09-10 15:36:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:36:19 --> Config Class Initialized
INFO - 2020-09-10 15:36:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:36:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:36:19 --> Utf8 Class Initialized
INFO - 2020-09-10 15:36:19 --> URI Class Initialized
INFO - 2020-09-10 15:36:19 --> Router Class Initialized
INFO - 2020-09-10 15:36:19 --> Output Class Initialized
INFO - 2020-09-10 15:36:19 --> Security Class Initialized
DEBUG - 2020-09-10 15:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:36:19 --> Input Class Initialized
INFO - 2020-09-10 15:36:19 --> Language Class Initialized
INFO - 2020-09-10 15:36:19 --> Loader Class Initialized
INFO - 2020-09-10 15:36:19 --> Helper loaded: url_helper
INFO - 2020-09-10 15:36:19 --> Database Driver Class Initialized
INFO - 2020-09-10 15:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:36:19 --> Email Class Initialized
INFO - 2020-09-10 15:36:19 --> Controller Class Initialized
DEBUG - 2020-09-10 15:36:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:36:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:36:19 --> Model Class Initialized
INFO - 2020-09-10 15:36:19 --> Model Class Initialized
ERROR - 2020-09-10 15:36:19 --> Query error: Unknown column 'undefined' in 'field list' - Invalid query: CALL client_details_edit(undefined)
INFO - 2020-09-10 15:36:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-10 15:36:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:36:34 --> Config Class Initialized
INFO - 2020-09-10 15:36:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:36:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:36:34 --> Utf8 Class Initialized
INFO - 2020-09-10 15:36:34 --> URI Class Initialized
INFO - 2020-09-10 15:36:34 --> Router Class Initialized
INFO - 2020-09-10 15:36:34 --> Output Class Initialized
INFO - 2020-09-10 15:36:34 --> Security Class Initialized
DEBUG - 2020-09-10 15:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:36:34 --> Input Class Initialized
INFO - 2020-09-10 15:36:34 --> Language Class Initialized
INFO - 2020-09-10 15:36:34 --> Loader Class Initialized
INFO - 2020-09-10 15:36:34 --> Helper loaded: url_helper
INFO - 2020-09-10 15:36:34 --> Database Driver Class Initialized
INFO - 2020-09-10 15:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:36:34 --> Email Class Initialized
INFO - 2020-09-10 15:36:34 --> Controller Class Initialized
DEBUG - 2020-09-10 15:36:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:36:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:36:34 --> Model Class Initialized
INFO - 2020-09-10 15:36:34 --> Model Class Initialized
INFO - 2020-09-10 15:36:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:36:34 --> Final output sent to browser
DEBUG - 2020-09-10 15:36:34 --> Total execution time: 0.0219
ERROR - 2020-09-10 15:36:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:36:41 --> Config Class Initialized
INFO - 2020-09-10 15:36:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:36:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:36:41 --> Utf8 Class Initialized
INFO - 2020-09-10 15:36:41 --> URI Class Initialized
INFO - 2020-09-10 15:36:41 --> Router Class Initialized
INFO - 2020-09-10 15:36:41 --> Output Class Initialized
INFO - 2020-09-10 15:36:41 --> Security Class Initialized
DEBUG - 2020-09-10 15:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:36:41 --> Input Class Initialized
INFO - 2020-09-10 15:36:41 --> Language Class Initialized
INFO - 2020-09-10 15:36:41 --> Loader Class Initialized
INFO - 2020-09-10 15:36:41 --> Helper loaded: url_helper
INFO - 2020-09-10 15:36:41 --> Database Driver Class Initialized
INFO - 2020-09-10 15:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:36:41 --> Email Class Initialized
INFO - 2020-09-10 15:36:41 --> Controller Class Initialized
DEBUG - 2020-09-10 15:36:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:36:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:36:41 --> Model Class Initialized
INFO - 2020-09-10 15:36:41 --> Model Class Initialized
ERROR - 2020-09-10 15:36:41 --> Query error: Unknown column 'undefined' in 'field list' - Invalid query: CALL client_details_edit(undefined)
INFO - 2020-09-10 15:36:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-10 15:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:36:45 --> Config Class Initialized
INFO - 2020-09-10 15:36:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:36:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:36:45 --> Utf8 Class Initialized
INFO - 2020-09-10 15:36:45 --> URI Class Initialized
INFO - 2020-09-10 15:36:45 --> Router Class Initialized
INFO - 2020-09-10 15:36:45 --> Output Class Initialized
INFO - 2020-09-10 15:36:45 --> Security Class Initialized
DEBUG - 2020-09-10 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:36:45 --> Input Class Initialized
INFO - 2020-09-10 15:36:45 --> Language Class Initialized
INFO - 2020-09-10 15:36:45 --> Loader Class Initialized
INFO - 2020-09-10 15:36:45 --> Helper loaded: url_helper
INFO - 2020-09-10 15:36:45 --> Database Driver Class Initialized
INFO - 2020-09-10 15:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:36:45 --> Email Class Initialized
INFO - 2020-09-10 15:36:45 --> Controller Class Initialized
DEBUG - 2020-09-10 15:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:36:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:36:45 --> Model Class Initialized
INFO - 2020-09-10 15:36:45 --> Model Class Initialized
INFO - 2020-09-10 15:36:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:36:45 --> Final output sent to browser
DEBUG - 2020-09-10 15:36:45 --> Total execution time: 0.0206
ERROR - 2020-09-10 15:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:40:00 --> Config Class Initialized
INFO - 2020-09-10 15:40:00 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:40:00 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:40:00 --> Utf8 Class Initialized
INFO - 2020-09-10 15:40:00 --> URI Class Initialized
INFO - 2020-09-10 15:40:00 --> Router Class Initialized
INFO - 2020-09-10 15:40:00 --> Output Class Initialized
INFO - 2020-09-10 15:40:00 --> Security Class Initialized
DEBUG - 2020-09-10 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:40:00 --> Input Class Initialized
INFO - 2020-09-10 15:40:00 --> Language Class Initialized
INFO - 2020-09-10 15:40:00 --> Loader Class Initialized
INFO - 2020-09-10 15:40:00 --> Helper loaded: url_helper
INFO - 2020-09-10 15:40:00 --> Database Driver Class Initialized
INFO - 2020-09-10 15:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:40:00 --> Email Class Initialized
INFO - 2020-09-10 15:40:00 --> Controller Class Initialized
DEBUG - 2020-09-10 15:40:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:40:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:40:00 --> Model Class Initialized
INFO - 2020-09-10 15:40:00 --> Model Class Initialized
INFO - 2020-09-10 15:40:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 15:40:00 --> Final output sent to browser
DEBUG - 2020-09-10 15:40:00 --> Total execution time: 0.0253
ERROR - 2020-09-10 15:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:40:02 --> Config Class Initialized
INFO - 2020-09-10 15:40:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:40:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:40:02 --> Utf8 Class Initialized
INFO - 2020-09-10 15:40:02 --> URI Class Initialized
INFO - 2020-09-10 15:40:02 --> Router Class Initialized
INFO - 2020-09-10 15:40:02 --> Output Class Initialized
INFO - 2020-09-10 15:40:02 --> Security Class Initialized
DEBUG - 2020-09-10 15:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:40:02 --> Input Class Initialized
INFO - 2020-09-10 15:40:02 --> Language Class Initialized
INFO - 2020-09-10 15:40:02 --> Loader Class Initialized
INFO - 2020-09-10 15:40:02 --> Helper loaded: url_helper
INFO - 2020-09-10 15:40:02 --> Database Driver Class Initialized
INFO - 2020-09-10 15:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:40:02 --> Email Class Initialized
INFO - 2020-09-10 15:40:02 --> Controller Class Initialized
DEBUG - 2020-09-10 15:40:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:40:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:40:02 --> Model Class Initialized
INFO - 2020-09-10 15:40:02 --> Model Class Initialized
ERROR - 2020-09-10 15:40:02 --> Query error: Table 'purpu1ex_carsm.client_detailsa' doesn't exist - Invalid query: CALL client_details_edit(1)
INFO - 2020-09-10 15:40:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-10 15:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:40:34 --> Config Class Initialized
INFO - 2020-09-10 15:40:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:40:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:40:34 --> Utf8 Class Initialized
INFO - 2020-09-10 15:40:34 --> URI Class Initialized
INFO - 2020-09-10 15:40:34 --> Router Class Initialized
INFO - 2020-09-10 15:40:34 --> Output Class Initialized
INFO - 2020-09-10 15:40:34 --> Security Class Initialized
DEBUG - 2020-09-10 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:40:34 --> Input Class Initialized
INFO - 2020-09-10 15:40:34 --> Language Class Initialized
INFO - 2020-09-10 15:40:34 --> Loader Class Initialized
INFO - 2020-09-10 15:40:34 --> Helper loaded: url_helper
INFO - 2020-09-10 15:40:34 --> Database Driver Class Initialized
INFO - 2020-09-10 15:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:40:34 --> Email Class Initialized
INFO - 2020-09-10 15:40:34 --> Controller Class Initialized
DEBUG - 2020-09-10 15:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:40:34 --> Model Class Initialized
INFO - 2020-09-10 15:40:34 --> Model Class Initialized
INFO - 2020-09-10 15:40:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 15:40:34 --> Final output sent to browser
DEBUG - 2020-09-10 15:40:34 --> Total execution time: 0.0282
ERROR - 2020-09-10 15:46:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:46:51 --> Config Class Initialized
INFO - 2020-09-10 15:46:51 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:46:51 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:46:51 --> Utf8 Class Initialized
INFO - 2020-09-10 15:46:51 --> URI Class Initialized
INFO - 2020-09-10 15:46:51 --> Router Class Initialized
INFO - 2020-09-10 15:46:51 --> Output Class Initialized
INFO - 2020-09-10 15:46:51 --> Security Class Initialized
DEBUG - 2020-09-10 15:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:46:51 --> Input Class Initialized
INFO - 2020-09-10 15:46:51 --> Language Class Initialized
INFO - 2020-09-10 15:46:51 --> Loader Class Initialized
INFO - 2020-09-10 15:46:51 --> Helper loaded: url_helper
INFO - 2020-09-10 15:46:51 --> Database Driver Class Initialized
INFO - 2020-09-10 15:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:46:51 --> Email Class Initialized
INFO - 2020-09-10 15:46:51 --> Controller Class Initialized
DEBUG - 2020-09-10 15:46:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:46:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:46:51 --> Model Class Initialized
INFO - 2020-09-10 15:46:51 --> Model Class Initialized
INFO - 2020-09-10 15:46:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 15:46:51 --> Final output sent to browser
DEBUG - 2020-09-10 15:46:51 --> Total execution time: 0.0327
ERROR - 2020-09-10 15:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 15:59:59 --> Config Class Initialized
INFO - 2020-09-10 15:59:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 15:59:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 15:59:59 --> Utf8 Class Initialized
INFO - 2020-09-10 15:59:59 --> URI Class Initialized
INFO - 2020-09-10 15:59:59 --> Router Class Initialized
INFO - 2020-09-10 15:59:59 --> Output Class Initialized
INFO - 2020-09-10 15:59:59 --> Security Class Initialized
DEBUG - 2020-09-10 15:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 15:59:59 --> Input Class Initialized
INFO - 2020-09-10 15:59:59 --> Language Class Initialized
INFO - 2020-09-10 15:59:59 --> Loader Class Initialized
INFO - 2020-09-10 15:59:59 --> Helper loaded: url_helper
INFO - 2020-09-10 15:59:59 --> Database Driver Class Initialized
INFO - 2020-09-10 15:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 15:59:59 --> Email Class Initialized
INFO - 2020-09-10 15:59:59 --> Controller Class Initialized
DEBUG - 2020-09-10 15:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 15:59:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 15:59:59 --> Model Class Initialized
INFO - 2020-09-10 15:59:59 --> Model Class Initialized
ERROR - 2020-09-10 15:59:59 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: CALL client_details_update('Gordon','Sloan','Alberta','Eastern Alberta','N6J 2B7',
        '','','5194711220','gordsloan@yahoo.ca','','','Kia','2015',
        'SAGE_GREEN','112497','5XYKTDA78FG555297','10/06/16','',
        '','','4.43','','',
        '','','','',
        '','','','',
        '27 Fox Mill Crt','','Sorento',1)
INFO - 2020-09-10 15:59:59 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-10 16:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:00:59 --> Config Class Initialized
INFO - 2020-09-10 16:00:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:00:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:00:59 --> Utf8 Class Initialized
INFO - 2020-09-10 16:00:59 --> URI Class Initialized
INFO - 2020-09-10 16:00:59 --> Router Class Initialized
INFO - 2020-09-10 16:00:59 --> Output Class Initialized
INFO - 2020-09-10 16:00:59 --> Security Class Initialized
DEBUG - 2020-09-10 16:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:00:59 --> Input Class Initialized
INFO - 2020-09-10 16:00:59 --> Language Class Initialized
INFO - 2020-09-10 16:00:59 --> Loader Class Initialized
INFO - 2020-09-10 16:00:59 --> Helper loaded: url_helper
INFO - 2020-09-10 16:00:59 --> Database Driver Class Initialized
INFO - 2020-09-10 16:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:00:59 --> Email Class Initialized
INFO - 2020-09-10 16:00:59 --> Controller Class Initialized
DEBUG - 2020-09-10 16:00:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:00:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:00:59 --> Model Class Initialized
INFO - 2020-09-10 16:00:59 --> Model Class Initialized
INFO - 2020-09-10 16:00:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:00:59 --> Final output sent to browser
DEBUG - 2020-09-10 16:00:59 --> Total execution time: 0.0307
ERROR - 2020-09-10 16:01:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:01:03 --> Config Class Initialized
INFO - 2020-09-10 16:01:03 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:01:03 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:01:03 --> Utf8 Class Initialized
INFO - 2020-09-10 16:01:03 --> URI Class Initialized
INFO - 2020-09-10 16:01:03 --> Router Class Initialized
INFO - 2020-09-10 16:01:03 --> Output Class Initialized
INFO - 2020-09-10 16:01:03 --> Security Class Initialized
DEBUG - 2020-09-10 16:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:01:03 --> Input Class Initialized
INFO - 2020-09-10 16:01:03 --> Language Class Initialized
INFO - 2020-09-10 16:01:03 --> Loader Class Initialized
INFO - 2020-09-10 16:01:03 --> Helper loaded: url_helper
INFO - 2020-09-10 16:01:03 --> Database Driver Class Initialized
INFO - 2020-09-10 16:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:01:03 --> Email Class Initialized
INFO - 2020-09-10 16:01:03 --> Controller Class Initialized
DEBUG - 2020-09-10 16:01:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:01:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:01:03 --> Model Class Initialized
INFO - 2020-09-10 16:01:03 --> Model Class Initialized
ERROR - 2020-09-10 16:01:03 --> Query error: Unknown column 'cl_h_ph_no' in 'field list' - Invalid query: CALL client_details_update('Gordon','Sloan','Alberta','Eastern Alberta','N6J 2B7',
        '','','5194711220','gordsloan@yahoo.ca','','','Kia','2015',
        'SAGE_GREEN','112497','5XYKTDA78FG555297','10/06/16','',
        '','','4.43','','',
        '','','','',
        '','','','',
        '27 Fox Mill Crt','','Sorento',1)
INFO - 2020-09-10 16:01:03 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-10 16:13:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:13:40 --> Config Class Initialized
INFO - 2020-09-10 16:13:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:13:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:13:40 --> Utf8 Class Initialized
INFO - 2020-09-10 16:13:40 --> URI Class Initialized
INFO - 2020-09-10 16:13:40 --> Router Class Initialized
INFO - 2020-09-10 16:13:40 --> Output Class Initialized
INFO - 2020-09-10 16:13:40 --> Security Class Initialized
DEBUG - 2020-09-10 16:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:13:40 --> Input Class Initialized
INFO - 2020-09-10 16:13:40 --> Language Class Initialized
INFO - 2020-09-10 16:13:40 --> Loader Class Initialized
INFO - 2020-09-10 16:13:40 --> Helper loaded: url_helper
INFO - 2020-09-10 16:13:40 --> Database Driver Class Initialized
INFO - 2020-09-10 16:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:13:40 --> Email Class Initialized
INFO - 2020-09-10 16:13:40 --> Controller Class Initialized
DEBUG - 2020-09-10 16:13:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:13:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:13:40 --> Model Class Initialized
INFO - 2020-09-10 16:13:40 --> Model Class Initialized
INFO - 2020-09-10 16:13:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:13:40 --> Final output sent to browser
DEBUG - 2020-09-10 16:13:40 --> Total execution time: 0.0269
ERROR - 2020-09-10 16:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:13:44 --> Config Class Initialized
INFO - 2020-09-10 16:13:44 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:13:44 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:13:44 --> Utf8 Class Initialized
INFO - 2020-09-10 16:13:44 --> URI Class Initialized
INFO - 2020-09-10 16:13:44 --> Router Class Initialized
INFO - 2020-09-10 16:13:44 --> Output Class Initialized
INFO - 2020-09-10 16:13:44 --> Security Class Initialized
DEBUG - 2020-09-10 16:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:13:44 --> Input Class Initialized
INFO - 2020-09-10 16:13:44 --> Language Class Initialized
INFO - 2020-09-10 16:13:44 --> Loader Class Initialized
INFO - 2020-09-10 16:13:44 --> Helper loaded: url_helper
INFO - 2020-09-10 16:13:44 --> Database Driver Class Initialized
INFO - 2020-09-10 16:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:13:44 --> Email Class Initialized
INFO - 2020-09-10 16:13:44 --> Controller Class Initialized
DEBUG - 2020-09-10 16:13:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:13:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:13:44 --> Model Class Initialized
INFO - 2020-09-10 16:13:44 --> Model Class Initialized
ERROR - 2020-09-10 16:13:44 --> Severity: Warning --> Missing argument 1 for Dealer_model::client_list(), called in /home/purpu1ex/public_html/carsm/application/controllers/Dealer.php on line 292 and defined /home/purpu1ex/public_html/carsm/application/models/Dealer_model.php 61
ERROR - 2020-09-10 16:13:44 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_details_master_list; expected 1, got 0 - Invalid query: CALL client_details_master_list()
INFO - 2020-09-10 16:13:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-10 16:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-10 16:14:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:14:31 --> Config Class Initialized
INFO - 2020-09-10 16:14:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:14:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:14:31 --> Utf8 Class Initialized
INFO - 2020-09-10 16:14:31 --> URI Class Initialized
INFO - 2020-09-10 16:14:31 --> Router Class Initialized
INFO - 2020-09-10 16:14:31 --> Output Class Initialized
INFO - 2020-09-10 16:14:31 --> Security Class Initialized
DEBUG - 2020-09-10 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:14:31 --> Input Class Initialized
INFO - 2020-09-10 16:14:31 --> Language Class Initialized
INFO - 2020-09-10 16:14:31 --> Loader Class Initialized
INFO - 2020-09-10 16:14:31 --> Helper loaded: url_helper
INFO - 2020-09-10 16:14:31 --> Database Driver Class Initialized
INFO - 2020-09-10 16:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:14:31 --> Email Class Initialized
INFO - 2020-09-10 16:14:31 --> Controller Class Initialized
DEBUG - 2020-09-10 16:14:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:14:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:14:31 --> Model Class Initialized
INFO - 2020-09-10 16:14:31 --> Model Class Initialized
INFO - 2020-09-10 16:14:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:14:31 --> Final output sent to browser
DEBUG - 2020-09-10 16:14:31 --> Total execution time: 0.0254
ERROR - 2020-09-10 16:14:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:14:37 --> Config Class Initialized
INFO - 2020-09-10 16:14:37 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:14:37 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:14:37 --> Utf8 Class Initialized
INFO - 2020-09-10 16:14:37 --> URI Class Initialized
INFO - 2020-09-10 16:14:37 --> Router Class Initialized
INFO - 2020-09-10 16:14:37 --> Output Class Initialized
INFO - 2020-09-10 16:14:37 --> Security Class Initialized
DEBUG - 2020-09-10 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:14:37 --> Input Class Initialized
INFO - 2020-09-10 16:14:37 --> Language Class Initialized
INFO - 2020-09-10 16:14:37 --> Loader Class Initialized
INFO - 2020-09-10 16:14:37 --> Helper loaded: url_helper
INFO - 2020-09-10 16:14:37 --> Database Driver Class Initialized
INFO - 2020-09-10 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:14:37 --> Email Class Initialized
INFO - 2020-09-10 16:14:37 --> Controller Class Initialized
DEBUG - 2020-09-10 16:14:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:14:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:14:37 --> Model Class Initialized
INFO - 2020-09-10 16:14:37 --> Model Class Initialized
INFO - 2020-09-10 16:14:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:14:37 --> Final output sent to browser
DEBUG - 2020-09-10 16:14:37 --> Total execution time: 0.0201
ERROR - 2020-09-10 16:14:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:14:42 --> Config Class Initialized
INFO - 2020-09-10 16:14:42 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:14:42 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:14:42 --> Utf8 Class Initialized
INFO - 2020-09-10 16:14:42 --> URI Class Initialized
INFO - 2020-09-10 16:14:42 --> Router Class Initialized
INFO - 2020-09-10 16:14:42 --> Output Class Initialized
INFO - 2020-09-10 16:14:42 --> Security Class Initialized
DEBUG - 2020-09-10 16:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:14:42 --> Input Class Initialized
INFO - 2020-09-10 16:14:42 --> Language Class Initialized
INFO - 2020-09-10 16:14:42 --> Loader Class Initialized
INFO - 2020-09-10 16:14:42 --> Helper loaded: url_helper
INFO - 2020-09-10 16:14:42 --> Database Driver Class Initialized
INFO - 2020-09-10 16:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:14:42 --> Email Class Initialized
INFO - 2020-09-10 16:14:42 --> Controller Class Initialized
DEBUG - 2020-09-10 16:14:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:14:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:14:42 --> Model Class Initialized
INFO - 2020-09-10 16:14:42 --> Model Class Initialized
INFO - 2020-09-10 16:14:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:14:42 --> Final output sent to browser
DEBUG - 2020-09-10 16:14:42 --> Total execution time: 0.0294
ERROR - 2020-09-10 16:14:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:14:58 --> Config Class Initialized
INFO - 2020-09-10 16:14:58 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:14:58 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:14:58 --> Utf8 Class Initialized
INFO - 2020-09-10 16:14:58 --> URI Class Initialized
INFO - 2020-09-10 16:14:58 --> Router Class Initialized
INFO - 2020-09-10 16:14:58 --> Output Class Initialized
INFO - 2020-09-10 16:14:58 --> Security Class Initialized
DEBUG - 2020-09-10 16:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:14:58 --> Input Class Initialized
INFO - 2020-09-10 16:14:58 --> Language Class Initialized
INFO - 2020-09-10 16:14:58 --> Loader Class Initialized
INFO - 2020-09-10 16:14:58 --> Helper loaded: url_helper
INFO - 2020-09-10 16:14:58 --> Database Driver Class Initialized
INFO - 2020-09-10 16:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:14:58 --> Email Class Initialized
INFO - 2020-09-10 16:14:58 --> Controller Class Initialized
DEBUG - 2020-09-10 16:14:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:14:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:14:58 --> Model Class Initialized
INFO - 2020-09-10 16:14:58 --> Model Class Initialized
INFO - 2020-09-10 16:14:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 16:14:58 --> Final output sent to browser
DEBUG - 2020-09-10 16:14:58 --> Total execution time: 0.0364
ERROR - 2020-09-10 16:20:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:20:29 --> Config Class Initialized
INFO - 2020-09-10 16:20:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:20:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:20:29 --> Utf8 Class Initialized
INFO - 2020-09-10 16:20:29 --> URI Class Initialized
INFO - 2020-09-10 16:20:29 --> Router Class Initialized
INFO - 2020-09-10 16:20:29 --> Output Class Initialized
INFO - 2020-09-10 16:20:29 --> Security Class Initialized
DEBUG - 2020-09-10 16:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:20:29 --> Input Class Initialized
INFO - 2020-09-10 16:20:29 --> Language Class Initialized
INFO - 2020-09-10 16:20:29 --> Loader Class Initialized
INFO - 2020-09-10 16:20:29 --> Helper loaded: url_helper
INFO - 2020-09-10 16:20:29 --> Database Driver Class Initialized
INFO - 2020-09-10 16:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:20:29 --> Email Class Initialized
INFO - 2020-09-10 16:20:29 --> Controller Class Initialized
DEBUG - 2020-09-10 16:20:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:20:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:20:29 --> Model Class Initialized
INFO - 2020-09-10 16:20:29 --> Model Class Initialized
INFO - 2020-09-10 16:20:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 16:20:29 --> Final output sent to browser
DEBUG - 2020-09-10 16:20:29 --> Total execution time: 0.0275
ERROR - 2020-09-10 16:22:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:22:17 --> Config Class Initialized
INFO - 2020-09-10 16:22:17 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:22:17 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:22:17 --> Utf8 Class Initialized
INFO - 2020-09-10 16:22:17 --> URI Class Initialized
INFO - 2020-09-10 16:22:17 --> Router Class Initialized
INFO - 2020-09-10 16:22:17 --> Output Class Initialized
INFO - 2020-09-10 16:22:17 --> Security Class Initialized
DEBUG - 2020-09-10 16:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:22:17 --> Input Class Initialized
INFO - 2020-09-10 16:22:17 --> Language Class Initialized
INFO - 2020-09-10 16:22:17 --> Loader Class Initialized
INFO - 2020-09-10 16:22:17 --> Helper loaded: url_helper
INFO - 2020-09-10 16:22:17 --> Database Driver Class Initialized
INFO - 2020-09-10 16:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:22:17 --> Email Class Initialized
INFO - 2020-09-10 16:22:17 --> Controller Class Initialized
DEBUG - 2020-09-10 16:22:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:22:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:22:17 --> Model Class Initialized
INFO - 2020-09-10 16:22:17 --> Model Class Initialized
INFO - 2020-09-10 16:22:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 16:22:17 --> Final output sent to browser
DEBUG - 2020-09-10 16:22:17 --> Total execution time: 0.0252
ERROR - 2020-09-10 16:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:26:11 --> Config Class Initialized
INFO - 2020-09-10 16:26:11 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:26:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:26:11 --> Utf8 Class Initialized
INFO - 2020-09-10 16:26:11 --> URI Class Initialized
INFO - 2020-09-10 16:26:11 --> Router Class Initialized
INFO - 2020-09-10 16:26:11 --> Output Class Initialized
INFO - 2020-09-10 16:26:11 --> Security Class Initialized
DEBUG - 2020-09-10 16:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:26:11 --> Input Class Initialized
INFO - 2020-09-10 16:26:11 --> Language Class Initialized
INFO - 2020-09-10 16:26:11 --> Loader Class Initialized
INFO - 2020-09-10 16:26:11 --> Helper loaded: url_helper
INFO - 2020-09-10 16:26:11 --> Database Driver Class Initialized
INFO - 2020-09-10 16:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:26:11 --> Email Class Initialized
INFO - 2020-09-10 16:26:11 --> Controller Class Initialized
DEBUG - 2020-09-10 16:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:26:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:26:11 --> Model Class Initialized
INFO - 2020-09-10 16:26:11 --> Model Class Initialized
INFO - 2020-09-10 16:26:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:26:11 --> Final output sent to browser
DEBUG - 2020-09-10 16:26:11 --> Total execution time: 0.5146
ERROR - 2020-09-10 16:26:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:26:16 --> Config Class Initialized
INFO - 2020-09-10 16:26:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:26:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:26:16 --> Utf8 Class Initialized
INFO - 2020-09-10 16:26:16 --> URI Class Initialized
INFO - 2020-09-10 16:26:16 --> Router Class Initialized
INFO - 2020-09-10 16:26:16 --> Output Class Initialized
INFO - 2020-09-10 16:26:16 --> Security Class Initialized
DEBUG - 2020-09-10 16:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:26:16 --> Input Class Initialized
INFO - 2020-09-10 16:26:16 --> Language Class Initialized
INFO - 2020-09-10 16:26:16 --> Loader Class Initialized
INFO - 2020-09-10 16:26:16 --> Helper loaded: url_helper
INFO - 2020-09-10 16:26:16 --> Database Driver Class Initialized
INFO - 2020-09-10 16:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:26:16 --> Email Class Initialized
INFO - 2020-09-10 16:26:16 --> Controller Class Initialized
DEBUG - 2020-09-10 16:26:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:26:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:26:16 --> Model Class Initialized
INFO - 2020-09-10 16:26:16 --> Model Class Initialized
INFO - 2020-09-10 16:26:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:26:16 --> Final output sent to browser
DEBUG - 2020-09-10 16:26:16 --> Total execution time: 0.0239
ERROR - 2020-09-10 16:26:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:26:28 --> Config Class Initialized
INFO - 2020-09-10 16:26:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:26:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:26:28 --> Utf8 Class Initialized
INFO - 2020-09-10 16:26:28 --> URI Class Initialized
INFO - 2020-09-10 16:26:28 --> Router Class Initialized
INFO - 2020-09-10 16:26:28 --> Output Class Initialized
INFO - 2020-09-10 16:26:28 --> Security Class Initialized
DEBUG - 2020-09-10 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:26:28 --> Input Class Initialized
INFO - 2020-09-10 16:26:28 --> Language Class Initialized
INFO - 2020-09-10 16:26:28 --> Loader Class Initialized
INFO - 2020-09-10 16:26:28 --> Helper loaded: url_helper
INFO - 2020-09-10 16:26:28 --> Database Driver Class Initialized
INFO - 2020-09-10 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:26:28 --> Email Class Initialized
INFO - 2020-09-10 16:26:28 --> Controller Class Initialized
DEBUG - 2020-09-10 16:26:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:26:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:26:28 --> Model Class Initialized
INFO - 2020-09-10 16:26:28 --> Model Class Initialized
INFO - 2020-09-10 16:26:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:26:28 --> Final output sent to browser
DEBUG - 2020-09-10 16:26:28 --> Total execution time: 0.0312
ERROR - 2020-09-10 16:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:26:34 --> Config Class Initialized
INFO - 2020-09-10 16:26:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:26:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:26:34 --> Utf8 Class Initialized
INFO - 2020-09-10 16:26:34 --> URI Class Initialized
INFO - 2020-09-10 16:26:34 --> Router Class Initialized
INFO - 2020-09-10 16:26:34 --> Output Class Initialized
INFO - 2020-09-10 16:26:34 --> Security Class Initialized
DEBUG - 2020-09-10 16:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:26:34 --> Input Class Initialized
INFO - 2020-09-10 16:26:34 --> Language Class Initialized
INFO - 2020-09-10 16:26:34 --> Loader Class Initialized
INFO - 2020-09-10 16:26:34 --> Helper loaded: url_helper
INFO - 2020-09-10 16:26:35 --> Database Driver Class Initialized
INFO - 2020-09-10 16:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:26:35 --> Email Class Initialized
INFO - 2020-09-10 16:26:35 --> Controller Class Initialized
DEBUG - 2020-09-10 16:26:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:26:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:26:35 --> Model Class Initialized
INFO - 2020-09-10 16:26:35 --> Model Class Initialized
INFO - 2020-09-10 16:26:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:26:35 --> Final output sent to browser
DEBUG - 2020-09-10 16:26:35 --> Total execution time: 0.0238
ERROR - 2020-09-10 16:26:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:26:39 --> Config Class Initialized
INFO - 2020-09-10 16:26:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:26:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:26:39 --> Utf8 Class Initialized
INFO - 2020-09-10 16:26:39 --> URI Class Initialized
INFO - 2020-09-10 16:26:39 --> Router Class Initialized
INFO - 2020-09-10 16:26:39 --> Output Class Initialized
INFO - 2020-09-10 16:26:39 --> Security Class Initialized
DEBUG - 2020-09-10 16:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:26:39 --> Input Class Initialized
INFO - 2020-09-10 16:26:39 --> Language Class Initialized
INFO - 2020-09-10 16:26:39 --> Loader Class Initialized
INFO - 2020-09-10 16:26:39 --> Helper loaded: url_helper
INFO - 2020-09-10 16:26:39 --> Database Driver Class Initialized
INFO - 2020-09-10 16:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:26:39 --> Email Class Initialized
INFO - 2020-09-10 16:26:39 --> Controller Class Initialized
DEBUG - 2020-09-10 16:26:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:26:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:26:39 --> Model Class Initialized
INFO - 2020-09-10 16:26:39 --> Model Class Initialized
INFO - 2020-09-10 16:26:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:26:39 --> Final output sent to browser
DEBUG - 2020-09-10 16:26:39 --> Total execution time: 0.0225
ERROR - 2020-09-10 16:26:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:26:41 --> Config Class Initialized
INFO - 2020-09-10 16:26:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:26:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:26:41 --> Utf8 Class Initialized
INFO - 2020-09-10 16:26:41 --> URI Class Initialized
INFO - 2020-09-10 16:26:41 --> Router Class Initialized
INFO - 2020-09-10 16:26:41 --> Output Class Initialized
INFO - 2020-09-10 16:26:41 --> Security Class Initialized
DEBUG - 2020-09-10 16:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:26:41 --> Input Class Initialized
INFO - 2020-09-10 16:26:41 --> Language Class Initialized
INFO - 2020-09-10 16:26:41 --> Loader Class Initialized
INFO - 2020-09-10 16:26:41 --> Helper loaded: url_helper
INFO - 2020-09-10 16:26:41 --> Database Driver Class Initialized
INFO - 2020-09-10 16:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:26:41 --> Email Class Initialized
INFO - 2020-09-10 16:26:41 --> Controller Class Initialized
DEBUG - 2020-09-10 16:26:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:26:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:26:41 --> Model Class Initialized
INFO - 2020-09-10 16:26:41 --> Model Class Initialized
INFO - 2020-09-10 16:26:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 16:26:41 --> Final output sent to browser
DEBUG - 2020-09-10 16:26:41 --> Total execution time: 0.0238
ERROR - 2020-09-10 16:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:30:18 --> Config Class Initialized
INFO - 2020-09-10 16:30:18 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:30:18 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:30:18 --> Utf8 Class Initialized
INFO - 2020-09-10 16:30:18 --> URI Class Initialized
INFO - 2020-09-10 16:30:18 --> Router Class Initialized
INFO - 2020-09-10 16:30:18 --> Output Class Initialized
INFO - 2020-09-10 16:30:18 --> Security Class Initialized
DEBUG - 2020-09-10 16:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:30:18 --> Input Class Initialized
INFO - 2020-09-10 16:30:18 --> Language Class Initialized
INFO - 2020-09-10 16:30:18 --> Loader Class Initialized
INFO - 2020-09-10 16:30:18 --> Helper loaded: url_helper
INFO - 2020-09-10 16:30:18 --> Database Driver Class Initialized
INFO - 2020-09-10 16:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:30:18 --> Email Class Initialized
INFO - 2020-09-10 16:30:18 --> Controller Class Initialized
DEBUG - 2020-09-10 16:30:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:30:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:30:18 --> Model Class Initialized
INFO - 2020-09-10 16:30:18 --> Model Class Initialized
INFO - 2020-09-10 16:30:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 16:30:18 --> Final output sent to browser
DEBUG - 2020-09-10 16:30:18 --> Total execution time: 0.0334
ERROR - 2020-09-10 16:30:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:30:23 --> Config Class Initialized
INFO - 2020-09-10 16:30:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:30:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:30:23 --> Utf8 Class Initialized
INFO - 2020-09-10 16:30:23 --> URI Class Initialized
INFO - 2020-09-10 16:30:23 --> Router Class Initialized
INFO - 2020-09-10 16:30:23 --> Output Class Initialized
INFO - 2020-09-10 16:30:23 --> Security Class Initialized
DEBUG - 2020-09-10 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:30:23 --> Input Class Initialized
INFO - 2020-09-10 16:30:23 --> Language Class Initialized
INFO - 2020-09-10 16:30:23 --> Loader Class Initialized
INFO - 2020-09-10 16:30:23 --> Helper loaded: url_helper
INFO - 2020-09-10 16:30:23 --> Database Driver Class Initialized
INFO - 2020-09-10 16:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:30:23 --> Email Class Initialized
INFO - 2020-09-10 16:30:23 --> Controller Class Initialized
DEBUG - 2020-09-10 16:30:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:30:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:30:23 --> Model Class Initialized
INFO - 2020-09-10 16:30:23 --> Model Class Initialized
INFO - 2020-09-10 16:30:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:30:23 --> Final output sent to browser
DEBUG - 2020-09-10 16:30:23 --> Total execution time: 0.0230
ERROR - 2020-09-10 16:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:30:26 --> Config Class Initialized
INFO - 2020-09-10 16:30:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:30:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:30:26 --> Utf8 Class Initialized
INFO - 2020-09-10 16:30:26 --> URI Class Initialized
INFO - 2020-09-10 16:30:26 --> Router Class Initialized
INFO - 2020-09-10 16:30:26 --> Output Class Initialized
INFO - 2020-09-10 16:30:26 --> Security Class Initialized
DEBUG - 2020-09-10 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:30:26 --> Input Class Initialized
INFO - 2020-09-10 16:30:26 --> Language Class Initialized
INFO - 2020-09-10 16:30:26 --> Loader Class Initialized
INFO - 2020-09-10 16:30:26 --> Helper loaded: url_helper
INFO - 2020-09-10 16:30:26 --> Database Driver Class Initialized
INFO - 2020-09-10 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:30:26 --> Email Class Initialized
INFO - 2020-09-10 16:30:26 --> Controller Class Initialized
INFO - 2020-09-10 16:30:26 --> Model Class Initialized
INFO - 2020-09-10 16:30:26 --> Model Class Initialized
INFO - 2020-09-10 16:30:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:30:26 --> Final output sent to browser
DEBUG - 2020-09-10 16:30:26 --> Total execution time: 0.0433
ERROR - 2020-09-10 16:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:30:26 --> Config Class Initialized
INFO - 2020-09-10 16:30:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:30:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:30:26 --> Utf8 Class Initialized
INFO - 2020-09-10 16:30:26 --> URI Class Initialized
INFO - 2020-09-10 16:30:26 --> Router Class Initialized
INFO - 2020-09-10 16:30:26 --> Output Class Initialized
INFO - 2020-09-10 16:30:26 --> Security Class Initialized
DEBUG - 2020-09-10 16:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:30:26 --> Input Class Initialized
INFO - 2020-09-10 16:30:26 --> Language Class Initialized
INFO - 2020-09-10 16:30:26 --> Loader Class Initialized
INFO - 2020-09-10 16:30:26 --> Helper loaded: url_helper
INFO - 2020-09-10 16:30:26 --> Database Driver Class Initialized
INFO - 2020-09-10 16:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:30:26 --> Email Class Initialized
INFO - 2020-09-10 16:30:26 --> Controller Class Initialized
INFO - 2020-09-10 16:30:26 --> Model Class Initialized
INFO - 2020-09-10 16:30:26 --> Model Class Initialized
INFO - 2020-09-10 16:30:26 --> Final output sent to browser
DEBUG - 2020-09-10 16:30:26 --> Total execution time: 0.0400
ERROR - 2020-09-10 16:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:04 --> Config Class Initialized
INFO - 2020-09-10 16:31:04 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:04 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:04 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:04 --> URI Class Initialized
INFO - 2020-09-10 16:31:04 --> Router Class Initialized
INFO - 2020-09-10 16:31:04 --> Output Class Initialized
INFO - 2020-09-10 16:31:04 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:04 --> Input Class Initialized
INFO - 2020-09-10 16:31:04 --> Language Class Initialized
INFO - 2020-09-10 16:31:04 --> Loader Class Initialized
INFO - 2020-09-10 16:31:04 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:04 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:04 --> Email Class Initialized
INFO - 2020-09-10 16:31:04 --> Controller Class Initialized
INFO - 2020-09-10 16:31:04 --> Model Class Initialized
INFO - 2020-09-10 16:31:04 --> Model Class Initialized
INFO - 2020-09-10 16:31:04 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:04 --> Total execution time: 0.1405
ERROR - 2020-09-10 16:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:05 --> Config Class Initialized
INFO - 2020-09-10 16:31:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:05 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:05 --> URI Class Initialized
INFO - 2020-09-10 16:31:05 --> Router Class Initialized
INFO - 2020-09-10 16:31:05 --> Output Class Initialized
INFO - 2020-09-10 16:31:05 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:05 --> Input Class Initialized
INFO - 2020-09-10 16:31:05 --> Language Class Initialized
INFO - 2020-09-10 16:31:05 --> Loader Class Initialized
INFO - 2020-09-10 16:31:05 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:05 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:05 --> Email Class Initialized
INFO - 2020-09-10 16:31:05 --> Controller Class Initialized
INFO - 2020-09-10 16:31:05 --> Model Class Initialized
INFO - 2020-09-10 16:31:05 --> Model Class Initialized
INFO - 2020-09-10 16:31:05 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:05 --> Total execution time: 0.0434
ERROR - 2020-09-10 16:31:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:09 --> Config Class Initialized
INFO - 2020-09-10 16:31:09 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:09 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:09 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:09 --> URI Class Initialized
INFO - 2020-09-10 16:31:09 --> Router Class Initialized
INFO - 2020-09-10 16:31:09 --> Output Class Initialized
INFO - 2020-09-10 16:31:09 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:09 --> Input Class Initialized
INFO - 2020-09-10 16:31:09 --> Language Class Initialized
INFO - 2020-09-10 16:31:09 --> Loader Class Initialized
INFO - 2020-09-10 16:31:09 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:09 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:09 --> Email Class Initialized
INFO - 2020-09-10 16:31:09 --> Controller Class Initialized
INFO - 2020-09-10 16:31:09 --> Model Class Initialized
INFO - 2020-09-10 16:31:09 --> Model Class Initialized
INFO - 2020-09-10 16:31:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:31:09 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:09 --> Total execution time: 0.0472
ERROR - 2020-09-10 16:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:10 --> Config Class Initialized
INFO - 2020-09-10 16:31:10 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:10 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:10 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:10 --> URI Class Initialized
INFO - 2020-09-10 16:31:10 --> Router Class Initialized
INFO - 2020-09-10 16:31:10 --> Output Class Initialized
INFO - 2020-09-10 16:31:10 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:10 --> Input Class Initialized
INFO - 2020-09-10 16:31:10 --> Language Class Initialized
INFO - 2020-09-10 16:31:10 --> Loader Class Initialized
INFO - 2020-09-10 16:31:10 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:10 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:10 --> Email Class Initialized
INFO - 2020-09-10 16:31:10 --> Controller Class Initialized
INFO - 2020-09-10 16:31:10 --> Model Class Initialized
INFO - 2020-09-10 16:31:10 --> Model Class Initialized
INFO - 2020-09-10 16:31:10 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:10 --> Total execution time: 0.0587
ERROR - 2020-09-10 16:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:17 --> Config Class Initialized
INFO - 2020-09-10 16:31:17 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:17 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:17 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:17 --> URI Class Initialized
INFO - 2020-09-10 16:31:17 --> Router Class Initialized
INFO - 2020-09-10 16:31:17 --> Output Class Initialized
INFO - 2020-09-10 16:31:17 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:17 --> Input Class Initialized
INFO - 2020-09-10 16:31:17 --> Language Class Initialized
INFO - 2020-09-10 16:31:17 --> Loader Class Initialized
INFO - 2020-09-10 16:31:17 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:17 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:17 --> Email Class Initialized
INFO - 2020-09-10 16:31:17 --> Controller Class Initialized
DEBUG - 2020-09-10 16:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:31:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:31:17 --> Model Class Initialized
INFO - 2020-09-10 16:31:17 --> Model Class Initialized
INFO - 2020-09-10 16:31:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:31:17 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:17 --> Total execution time: 0.0324
ERROR - 2020-09-10 16:31:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:20 --> Config Class Initialized
INFO - 2020-09-10 16:31:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:20 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:20 --> URI Class Initialized
INFO - 2020-09-10 16:31:20 --> Router Class Initialized
INFO - 2020-09-10 16:31:20 --> Output Class Initialized
INFO - 2020-09-10 16:31:20 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:20 --> Input Class Initialized
INFO - 2020-09-10 16:31:20 --> Language Class Initialized
INFO - 2020-09-10 16:31:20 --> Loader Class Initialized
INFO - 2020-09-10 16:31:20 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:20 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:20 --> Email Class Initialized
INFO - 2020-09-10 16:31:20 --> Controller Class Initialized
DEBUG - 2020-09-10 16:31:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:31:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:31:20 --> Model Class Initialized
INFO - 2020-09-10 16:31:20 --> Model Class Initialized
INFO - 2020-09-10 16:31:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:31:20 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:20 --> Total execution time: 0.0245
ERROR - 2020-09-10 16:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:27 --> Config Class Initialized
INFO - 2020-09-10 16:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:27 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:27 --> URI Class Initialized
INFO - 2020-09-10 16:31:27 --> Router Class Initialized
INFO - 2020-09-10 16:31:27 --> Output Class Initialized
INFO - 2020-09-10 16:31:27 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:27 --> Input Class Initialized
INFO - 2020-09-10 16:31:27 --> Language Class Initialized
INFO - 2020-09-10 16:31:27 --> Loader Class Initialized
INFO - 2020-09-10 16:31:27 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:27 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:27 --> Email Class Initialized
INFO - 2020-09-10 16:31:27 --> Controller Class Initialized
DEBUG - 2020-09-10 16:31:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:31:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:31:27 --> Model Class Initialized
INFO - 2020-09-10 16:31:27 --> Model Class Initialized
INFO - 2020-09-10 16:31:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:31:27 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:27 --> Total execution time: 0.0227
ERROR - 2020-09-10 16:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:31:28 --> Config Class Initialized
INFO - 2020-09-10 16:31:28 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:31:28 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:31:28 --> Utf8 Class Initialized
INFO - 2020-09-10 16:31:28 --> URI Class Initialized
INFO - 2020-09-10 16:31:28 --> Router Class Initialized
INFO - 2020-09-10 16:31:29 --> Output Class Initialized
INFO - 2020-09-10 16:31:29 --> Security Class Initialized
DEBUG - 2020-09-10 16:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:31:29 --> Input Class Initialized
INFO - 2020-09-10 16:31:29 --> Language Class Initialized
INFO - 2020-09-10 16:31:29 --> Loader Class Initialized
INFO - 2020-09-10 16:31:29 --> Helper loaded: url_helper
INFO - 2020-09-10 16:31:29 --> Database Driver Class Initialized
INFO - 2020-09-10 16:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:31:29 --> Email Class Initialized
INFO - 2020-09-10 16:31:29 --> Controller Class Initialized
DEBUG - 2020-09-10 16:31:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:31:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:31:29 --> Model Class Initialized
INFO - 2020-09-10 16:31:29 --> Model Class Initialized
INFO - 2020-09-10 16:31:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 16:31:29 --> Final output sent to browser
DEBUG - 2020-09-10 16:31:29 --> Total execution time: 0.0227
ERROR - 2020-09-10 16:41:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:41:46 --> Config Class Initialized
INFO - 2020-09-10 16:41:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:41:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:41:46 --> Utf8 Class Initialized
INFO - 2020-09-10 16:41:46 --> URI Class Initialized
INFO - 2020-09-10 16:41:46 --> Router Class Initialized
INFO - 2020-09-10 16:41:46 --> Output Class Initialized
INFO - 2020-09-10 16:41:46 --> Security Class Initialized
DEBUG - 2020-09-10 16:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:41:46 --> Input Class Initialized
INFO - 2020-09-10 16:41:46 --> Language Class Initialized
INFO - 2020-09-10 16:41:46 --> Loader Class Initialized
INFO - 2020-09-10 16:41:46 --> Helper loaded: url_helper
INFO - 2020-09-10 16:41:46 --> Database Driver Class Initialized
INFO - 2020-09-10 16:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:41:46 --> Email Class Initialized
INFO - 2020-09-10 16:41:46 --> Controller Class Initialized
DEBUG - 2020-09-10 16:41:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:41:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:41:46 --> Model Class Initialized
INFO - 2020-09-10 16:41:46 --> Model Class Initialized
INFO - 2020-09-10 16:41:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:41:46 --> Final output sent to browser
DEBUG - 2020-09-10 16:41:46 --> Total execution time: 0.0209
ERROR - 2020-09-10 16:42:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:42:21 --> Config Class Initialized
INFO - 2020-09-10 16:42:21 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:42:21 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:42:21 --> Utf8 Class Initialized
INFO - 2020-09-10 16:42:21 --> URI Class Initialized
INFO - 2020-09-10 16:42:21 --> Router Class Initialized
INFO - 2020-09-10 16:42:21 --> Output Class Initialized
INFO - 2020-09-10 16:42:21 --> Security Class Initialized
DEBUG - 2020-09-10 16:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:42:21 --> Input Class Initialized
INFO - 2020-09-10 16:42:21 --> Language Class Initialized
INFO - 2020-09-10 16:42:21 --> Loader Class Initialized
INFO - 2020-09-10 16:42:21 --> Helper loaded: url_helper
INFO - 2020-09-10 16:42:21 --> Database Driver Class Initialized
INFO - 2020-09-10 16:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:42:21 --> Email Class Initialized
INFO - 2020-09-10 16:42:21 --> Controller Class Initialized
INFO - 2020-09-10 16:42:21 --> Model Class Initialized
INFO - 2020-09-10 16:42:21 --> Model Class Initialized
INFO - 2020-09-10 16:42:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:42:21 --> Final output sent to browser
DEBUG - 2020-09-10 16:42:21 --> Total execution time: 0.0430
ERROR - 2020-09-10 16:42:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:42:22 --> Config Class Initialized
INFO - 2020-09-10 16:42:22 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:42:22 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:42:22 --> Utf8 Class Initialized
INFO - 2020-09-10 16:42:22 --> URI Class Initialized
INFO - 2020-09-10 16:42:22 --> Router Class Initialized
INFO - 2020-09-10 16:42:22 --> Output Class Initialized
INFO - 2020-09-10 16:42:22 --> Security Class Initialized
DEBUG - 2020-09-10 16:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:42:22 --> Input Class Initialized
INFO - 2020-09-10 16:42:22 --> Language Class Initialized
INFO - 2020-09-10 16:42:22 --> Loader Class Initialized
INFO - 2020-09-10 16:42:22 --> Helper loaded: url_helper
INFO - 2020-09-10 16:42:22 --> Database Driver Class Initialized
INFO - 2020-09-10 16:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:42:22 --> Email Class Initialized
INFO - 2020-09-10 16:42:22 --> Controller Class Initialized
INFO - 2020-09-10 16:42:22 --> Model Class Initialized
INFO - 2020-09-10 16:42:22 --> Model Class Initialized
INFO - 2020-09-10 16:42:22 --> Final output sent to browser
DEBUG - 2020-09-10 16:42:22 --> Total execution time: 0.0396
ERROR - 2020-09-10 16:44:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:44:34 --> Config Class Initialized
INFO - 2020-09-10 16:44:34 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:44:34 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:44:34 --> Utf8 Class Initialized
INFO - 2020-09-10 16:44:34 --> URI Class Initialized
INFO - 2020-09-10 16:44:34 --> Router Class Initialized
INFO - 2020-09-10 16:44:34 --> Output Class Initialized
INFO - 2020-09-10 16:44:34 --> Security Class Initialized
DEBUG - 2020-09-10 16:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:44:34 --> Input Class Initialized
INFO - 2020-09-10 16:44:34 --> Language Class Initialized
INFO - 2020-09-10 16:44:34 --> Loader Class Initialized
INFO - 2020-09-10 16:44:34 --> Helper loaded: url_helper
INFO - 2020-09-10 16:44:34 --> Database Driver Class Initialized
INFO - 2020-09-10 16:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:44:34 --> Email Class Initialized
INFO - 2020-09-10 16:44:34 --> Controller Class Initialized
INFO - 2020-09-10 16:44:34 --> Model Class Initialized
INFO - 2020-09-10 16:44:34 --> Model Class Initialized
INFO - 2020-09-10 16:44:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:44:34 --> Final output sent to browser
DEBUG - 2020-09-10 16:44:34 --> Total execution time: 0.0436
ERROR - 2020-09-10 16:44:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:44:35 --> Config Class Initialized
INFO - 2020-09-10 16:44:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:44:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:44:35 --> Utf8 Class Initialized
INFO - 2020-09-10 16:44:35 --> URI Class Initialized
INFO - 2020-09-10 16:44:35 --> Router Class Initialized
INFO - 2020-09-10 16:44:35 --> Output Class Initialized
INFO - 2020-09-10 16:44:35 --> Security Class Initialized
DEBUG - 2020-09-10 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:44:35 --> Input Class Initialized
INFO - 2020-09-10 16:44:35 --> Language Class Initialized
INFO - 2020-09-10 16:44:35 --> Loader Class Initialized
INFO - 2020-09-10 16:44:35 --> Helper loaded: url_helper
INFO - 2020-09-10 16:44:35 --> Database Driver Class Initialized
INFO - 2020-09-10 16:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:44:35 --> Email Class Initialized
INFO - 2020-09-10 16:44:35 --> Controller Class Initialized
INFO - 2020-09-10 16:44:35 --> Model Class Initialized
INFO - 2020-09-10 16:44:35 --> Model Class Initialized
INFO - 2020-09-10 16:44:35 --> Final output sent to browser
DEBUG - 2020-09-10 16:44:35 --> Total execution time: 0.0477
ERROR - 2020-09-10 16:48:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:48:02 --> Config Class Initialized
INFO - 2020-09-10 16:48:02 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:48:02 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:48:02 --> Utf8 Class Initialized
INFO - 2020-09-10 16:48:02 --> URI Class Initialized
INFO - 2020-09-10 16:48:02 --> Router Class Initialized
INFO - 2020-09-10 16:48:02 --> Output Class Initialized
INFO - 2020-09-10 16:48:02 --> Security Class Initialized
DEBUG - 2020-09-10 16:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:48:02 --> Input Class Initialized
INFO - 2020-09-10 16:48:02 --> Language Class Initialized
INFO - 2020-09-10 16:48:02 --> Loader Class Initialized
INFO - 2020-09-10 16:48:02 --> Helper loaded: url_helper
INFO - 2020-09-10 16:48:02 --> Database Driver Class Initialized
INFO - 2020-09-10 16:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:48:02 --> Email Class Initialized
INFO - 2020-09-10 16:48:02 --> Controller Class Initialized
INFO - 2020-09-10 16:48:02 --> Model Class Initialized
INFO - 2020-09-10 16:48:02 --> Model Class Initialized
INFO - 2020-09-10 16:48:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:48:02 --> Final output sent to browser
DEBUG - 2020-09-10 16:48:02 --> Total execution time: 0.0547
ERROR - 2020-09-10 16:48:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:48:03 --> Config Class Initialized
INFO - 2020-09-10 16:48:03 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:48:03 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:48:03 --> Utf8 Class Initialized
INFO - 2020-09-10 16:48:03 --> URI Class Initialized
INFO - 2020-09-10 16:48:03 --> Router Class Initialized
INFO - 2020-09-10 16:48:03 --> Output Class Initialized
INFO - 2020-09-10 16:48:03 --> Security Class Initialized
DEBUG - 2020-09-10 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:48:03 --> Input Class Initialized
INFO - 2020-09-10 16:48:03 --> Language Class Initialized
INFO - 2020-09-10 16:48:03 --> Loader Class Initialized
INFO - 2020-09-10 16:48:03 --> Helper loaded: url_helper
INFO - 2020-09-10 16:48:03 --> Database Driver Class Initialized
INFO - 2020-09-10 16:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:48:03 --> Email Class Initialized
INFO - 2020-09-10 16:48:03 --> Controller Class Initialized
INFO - 2020-09-10 16:48:03 --> Model Class Initialized
INFO - 2020-09-10 16:48:03 --> Model Class Initialized
INFO - 2020-09-10 16:48:03 --> Final output sent to browser
DEBUG - 2020-09-10 16:48:03 --> Total execution time: 0.0419
ERROR - 2020-09-10 16:48:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:48:05 --> Config Class Initialized
INFO - 2020-09-10 16:48:05 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:48:05 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:48:05 --> Utf8 Class Initialized
INFO - 2020-09-10 16:48:05 --> URI Class Initialized
INFO - 2020-09-10 16:48:05 --> Router Class Initialized
INFO - 2020-09-10 16:48:05 --> Output Class Initialized
INFO - 2020-09-10 16:48:05 --> Security Class Initialized
DEBUG - 2020-09-10 16:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:48:05 --> Input Class Initialized
INFO - 2020-09-10 16:48:05 --> Language Class Initialized
INFO - 2020-09-10 16:48:05 --> Loader Class Initialized
INFO - 2020-09-10 16:48:05 --> Helper loaded: url_helper
INFO - 2020-09-10 16:48:05 --> Database Driver Class Initialized
INFO - 2020-09-10 16:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:48:05 --> Email Class Initialized
INFO - 2020-09-10 16:48:05 --> Controller Class Initialized
INFO - 2020-09-10 16:48:05 --> Model Class Initialized
INFO - 2020-09-10 16:48:05 --> Model Class Initialized
INFO - 2020-09-10 16:48:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:48:06 --> Final output sent to browser
DEBUG - 2020-09-10 16:48:06 --> Total execution time: 0.1224
ERROR - 2020-09-10 16:48:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:48:06 --> Config Class Initialized
INFO - 2020-09-10 16:48:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:48:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:48:06 --> Utf8 Class Initialized
INFO - 2020-09-10 16:48:06 --> URI Class Initialized
INFO - 2020-09-10 16:48:06 --> Router Class Initialized
INFO - 2020-09-10 16:48:06 --> Output Class Initialized
INFO - 2020-09-10 16:48:06 --> Security Class Initialized
DEBUG - 2020-09-10 16:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:48:06 --> Input Class Initialized
INFO - 2020-09-10 16:48:06 --> Language Class Initialized
INFO - 2020-09-10 16:48:06 --> Loader Class Initialized
INFO - 2020-09-10 16:48:06 --> Helper loaded: url_helper
INFO - 2020-09-10 16:48:06 --> Database Driver Class Initialized
INFO - 2020-09-10 16:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:48:06 --> Email Class Initialized
INFO - 2020-09-10 16:48:06 --> Controller Class Initialized
INFO - 2020-09-10 16:48:06 --> Model Class Initialized
INFO - 2020-09-10 16:48:06 --> Model Class Initialized
INFO - 2020-09-10 16:48:06 --> Final output sent to browser
DEBUG - 2020-09-10 16:48:06 --> Total execution time: 0.0408
ERROR - 2020-09-10 16:49:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:49:24 --> Config Class Initialized
INFO - 2020-09-10 16:49:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:49:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:49:24 --> Utf8 Class Initialized
INFO - 2020-09-10 16:49:24 --> URI Class Initialized
INFO - 2020-09-10 16:49:24 --> Router Class Initialized
INFO - 2020-09-10 16:49:24 --> Output Class Initialized
INFO - 2020-09-10 16:49:24 --> Security Class Initialized
DEBUG - 2020-09-10 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:49:24 --> Input Class Initialized
INFO - 2020-09-10 16:49:24 --> Language Class Initialized
INFO - 2020-09-10 16:49:24 --> Loader Class Initialized
INFO - 2020-09-10 16:49:24 --> Helper loaded: url_helper
INFO - 2020-09-10 16:49:24 --> Database Driver Class Initialized
INFO - 2020-09-10 16:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:49:24 --> Email Class Initialized
INFO - 2020-09-10 16:49:24 --> Controller Class Initialized
INFO - 2020-09-10 16:49:24 --> Model Class Initialized
INFO - 2020-09-10 16:49:24 --> Model Class Initialized
INFO - 2020-09-10 16:49:24 --> Final output sent to browser
DEBUG - 2020-09-10 16:49:24 --> Total execution time: 0.1244
ERROR - 2020-09-10 16:49:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:49:24 --> Config Class Initialized
INFO - 2020-09-10 16:49:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:49:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:49:24 --> Utf8 Class Initialized
INFO - 2020-09-10 16:49:24 --> URI Class Initialized
INFO - 2020-09-10 16:49:24 --> Router Class Initialized
INFO - 2020-09-10 16:49:24 --> Output Class Initialized
INFO - 2020-09-10 16:49:24 --> Security Class Initialized
DEBUG - 2020-09-10 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:49:24 --> Input Class Initialized
INFO - 2020-09-10 16:49:24 --> Language Class Initialized
INFO - 2020-09-10 16:49:24 --> Loader Class Initialized
INFO - 2020-09-10 16:49:24 --> Helper loaded: url_helper
INFO - 2020-09-10 16:49:24 --> Database Driver Class Initialized
INFO - 2020-09-10 16:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:49:24 --> Email Class Initialized
INFO - 2020-09-10 16:49:24 --> Controller Class Initialized
INFO - 2020-09-10 16:49:24 --> Model Class Initialized
INFO - 2020-09-10 16:49:24 --> Model Class Initialized
INFO - 2020-09-10 16:49:24 --> Final output sent to browser
DEBUG - 2020-09-10 16:49:24 --> Total execution time: 0.0446
ERROR - 2020-09-10 16:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:49:36 --> Config Class Initialized
INFO - 2020-09-10 16:49:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:49:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:49:36 --> Utf8 Class Initialized
INFO - 2020-09-10 16:49:36 --> URI Class Initialized
INFO - 2020-09-10 16:49:36 --> Router Class Initialized
INFO - 2020-09-10 16:49:36 --> Output Class Initialized
INFO - 2020-09-10 16:49:36 --> Security Class Initialized
DEBUG - 2020-09-10 16:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:49:36 --> Input Class Initialized
INFO - 2020-09-10 16:49:36 --> Language Class Initialized
INFO - 2020-09-10 16:49:36 --> Loader Class Initialized
INFO - 2020-09-10 16:49:36 --> Helper loaded: url_helper
INFO - 2020-09-10 16:49:36 --> Database Driver Class Initialized
INFO - 2020-09-10 16:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:49:36 --> Email Class Initialized
INFO - 2020-09-10 16:49:36 --> Controller Class Initialized
INFO - 2020-09-10 16:49:36 --> Model Class Initialized
INFO - 2020-09-10 16:49:36 --> Model Class Initialized
INFO - 2020-09-10 16:49:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 16:49:36 --> Final output sent to browser
DEBUG - 2020-09-10 16:49:36 --> Total execution time: 0.1093
ERROR - 2020-09-10 16:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:49:36 --> Config Class Initialized
INFO - 2020-09-10 16:49:36 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:49:36 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:49:36 --> Utf8 Class Initialized
INFO - 2020-09-10 16:49:36 --> URI Class Initialized
INFO - 2020-09-10 16:49:36 --> Router Class Initialized
INFO - 2020-09-10 16:49:36 --> Output Class Initialized
INFO - 2020-09-10 16:49:36 --> Security Class Initialized
DEBUG - 2020-09-10 16:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:49:36 --> Input Class Initialized
INFO - 2020-09-10 16:49:36 --> Language Class Initialized
INFO - 2020-09-10 16:49:36 --> Loader Class Initialized
INFO - 2020-09-10 16:49:36 --> Helper loaded: url_helper
INFO - 2020-09-10 16:49:36 --> Database Driver Class Initialized
INFO - 2020-09-10 16:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:49:36 --> Email Class Initialized
INFO - 2020-09-10 16:49:36 --> Controller Class Initialized
INFO - 2020-09-10 16:49:36 --> Model Class Initialized
INFO - 2020-09-10 16:49:36 --> Model Class Initialized
INFO - 2020-09-10 16:49:36 --> Final output sent to browser
DEBUG - 2020-09-10 16:49:36 --> Total execution time: 0.0405
ERROR - 2020-09-10 16:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:51:11 --> Config Class Initialized
INFO - 2020-09-10 16:51:11 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:51:11 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:51:11 --> Utf8 Class Initialized
INFO - 2020-09-10 16:51:11 --> URI Class Initialized
INFO - 2020-09-10 16:51:11 --> Router Class Initialized
INFO - 2020-09-10 16:51:11 --> Output Class Initialized
INFO - 2020-09-10 16:51:11 --> Security Class Initialized
DEBUG - 2020-09-10 16:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:51:11 --> Input Class Initialized
INFO - 2020-09-10 16:51:11 --> Language Class Initialized
INFO - 2020-09-10 16:51:11 --> Loader Class Initialized
INFO - 2020-09-10 16:51:11 --> Helper loaded: url_helper
INFO - 2020-09-10 16:51:11 --> Database Driver Class Initialized
INFO - 2020-09-10 16:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:51:11 --> Email Class Initialized
INFO - 2020-09-10 16:51:11 --> Controller Class Initialized
DEBUG - 2020-09-10 16:51:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:51:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:51:11 --> Model Class Initialized
INFO - 2020-09-10 16:51:11 --> Model Class Initialized
INFO - 2020-09-10 16:51:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:51:11 --> Final output sent to browser
DEBUG - 2020-09-10 16:51:11 --> Total execution time: 0.5225
ERROR - 2020-09-10 16:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:51:14 --> Config Class Initialized
INFO - 2020-09-10 16:51:14 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:51:14 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:51:14 --> Utf8 Class Initialized
INFO - 2020-09-10 16:51:14 --> URI Class Initialized
INFO - 2020-09-10 16:51:14 --> Router Class Initialized
INFO - 2020-09-10 16:51:14 --> Output Class Initialized
INFO - 2020-09-10 16:51:14 --> Security Class Initialized
DEBUG - 2020-09-10 16:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:51:14 --> Input Class Initialized
INFO - 2020-09-10 16:51:14 --> Language Class Initialized
INFO - 2020-09-10 16:51:14 --> Loader Class Initialized
INFO - 2020-09-10 16:51:14 --> Helper loaded: url_helper
INFO - 2020-09-10 16:51:14 --> Database Driver Class Initialized
INFO - 2020-09-10 16:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:51:14 --> Email Class Initialized
INFO - 2020-09-10 16:51:14 --> Controller Class Initialized
DEBUG - 2020-09-10 16:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:51:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:51:14 --> Model Class Initialized
INFO - 2020-09-10 16:51:14 --> Model Class Initialized
INFO - 2020-09-10 16:51:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 16:51:14 --> Final output sent to browser
DEBUG - 2020-09-10 16:51:14 --> Total execution time: 0.0404
ERROR - 2020-09-10 16:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 16:52:54 --> Config Class Initialized
INFO - 2020-09-10 16:52:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 16:52:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 16:52:54 --> Utf8 Class Initialized
INFO - 2020-09-10 16:52:54 --> URI Class Initialized
INFO - 2020-09-10 16:52:54 --> Router Class Initialized
INFO - 2020-09-10 16:52:54 --> Output Class Initialized
INFO - 2020-09-10 16:52:54 --> Security Class Initialized
DEBUG - 2020-09-10 16:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 16:52:54 --> Input Class Initialized
INFO - 2020-09-10 16:52:54 --> Language Class Initialized
INFO - 2020-09-10 16:52:54 --> Loader Class Initialized
INFO - 2020-09-10 16:52:54 --> Helper loaded: url_helper
INFO - 2020-09-10 16:52:54 --> Database Driver Class Initialized
INFO - 2020-09-10 16:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 16:52:54 --> Email Class Initialized
INFO - 2020-09-10 16:52:54 --> Controller Class Initialized
DEBUG - 2020-09-10 16:52:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 16:52:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 16:52:54 --> Model Class Initialized
INFO - 2020-09-10 16:52:54 --> Model Class Initialized
INFO - 2020-09-10 16:52:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 16:52:54 --> Final output sent to browser
DEBUG - 2020-09-10 16:52:54 --> Total execution time: 0.0356
ERROR - 2020-09-10 17:01:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:01:06 --> Config Class Initialized
INFO - 2020-09-10 17:01:06 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:01:06 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:01:06 --> Utf8 Class Initialized
INFO - 2020-09-10 17:01:06 --> URI Class Initialized
INFO - 2020-09-10 17:01:06 --> Router Class Initialized
INFO - 2020-09-10 17:01:06 --> Output Class Initialized
INFO - 2020-09-10 17:01:06 --> Security Class Initialized
DEBUG - 2020-09-10 17:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:01:06 --> Input Class Initialized
INFO - 2020-09-10 17:01:06 --> Language Class Initialized
INFO - 2020-09-10 17:01:06 --> Loader Class Initialized
INFO - 2020-09-10 17:01:06 --> Helper loaded: url_helper
INFO - 2020-09-10 17:01:06 --> Database Driver Class Initialized
INFO - 2020-09-10 17:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:01:06 --> Email Class Initialized
INFO - 2020-09-10 17:01:06 --> Controller Class Initialized
DEBUG - 2020-09-10 17:01:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:01:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:01:06 --> Model Class Initialized
INFO - 2020-09-10 17:01:06 --> Model Class Initialized
INFO - 2020-09-10 17:01:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 17:01:06 --> Final output sent to browser
DEBUG - 2020-09-10 17:01:06 --> Total execution time: 0.0275
ERROR - 2020-09-10 17:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:01:21 --> Config Class Initialized
INFO - 2020-09-10 17:01:21 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:01:21 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:01:21 --> Utf8 Class Initialized
INFO - 2020-09-10 17:01:21 --> URI Class Initialized
INFO - 2020-09-10 17:01:21 --> Router Class Initialized
INFO - 2020-09-10 17:01:21 --> Output Class Initialized
INFO - 2020-09-10 17:01:21 --> Security Class Initialized
DEBUG - 2020-09-10 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:01:21 --> Input Class Initialized
INFO - 2020-09-10 17:01:21 --> Language Class Initialized
INFO - 2020-09-10 17:01:21 --> Loader Class Initialized
INFO - 2020-09-10 17:01:21 --> Helper loaded: url_helper
INFO - 2020-09-10 17:01:21 --> Database Driver Class Initialized
INFO - 2020-09-10 17:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:01:21 --> Email Class Initialized
INFO - 2020-09-10 17:01:21 --> Controller Class Initialized
DEBUG - 2020-09-10 17:01:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:01:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:01:21 --> Model Class Initialized
INFO - 2020-09-10 17:01:21 --> Model Class Initialized
INFO - 2020-09-10 17:01:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:01:21 --> Final output sent to browser
DEBUG - 2020-09-10 17:01:21 --> Total execution time: 0.0209
ERROR - 2020-09-10 17:02:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:02:35 --> Config Class Initialized
INFO - 2020-09-10 17:02:35 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:02:35 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:02:35 --> Utf8 Class Initialized
INFO - 2020-09-10 17:02:35 --> URI Class Initialized
INFO - 2020-09-10 17:02:35 --> Router Class Initialized
INFO - 2020-09-10 17:02:35 --> Output Class Initialized
INFO - 2020-09-10 17:02:35 --> Security Class Initialized
DEBUG - 2020-09-10 17:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:02:35 --> Input Class Initialized
INFO - 2020-09-10 17:02:35 --> Language Class Initialized
INFO - 2020-09-10 17:02:35 --> Loader Class Initialized
INFO - 2020-09-10 17:02:35 --> Helper loaded: url_helper
INFO - 2020-09-10 17:02:35 --> Database Driver Class Initialized
INFO - 2020-09-10 17:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:02:35 --> Email Class Initialized
INFO - 2020-09-10 17:02:35 --> Controller Class Initialized
DEBUG - 2020-09-10 17:02:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:02:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:02:35 --> Model Class Initialized
INFO - 2020-09-10 17:02:35 --> Model Class Initialized
INFO - 2020-09-10 17:02:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:02:35 --> Final output sent to browser
DEBUG - 2020-09-10 17:02:35 --> Total execution time: 0.0201
ERROR - 2020-09-10 17:02:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:02:50 --> Config Class Initialized
INFO - 2020-09-10 17:02:50 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:02:50 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:02:50 --> Utf8 Class Initialized
INFO - 2020-09-10 17:02:50 --> URI Class Initialized
DEBUG - 2020-09-10 17:02:50 --> No URI present. Default controller set.
INFO - 2020-09-10 17:02:50 --> Router Class Initialized
INFO - 2020-09-10 17:02:50 --> Output Class Initialized
INFO - 2020-09-10 17:02:50 --> Security Class Initialized
DEBUG - 2020-09-10 17:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:02:50 --> Input Class Initialized
INFO - 2020-09-10 17:02:50 --> Language Class Initialized
INFO - 2020-09-10 17:02:50 --> Loader Class Initialized
INFO - 2020-09-10 17:02:50 --> Helper loaded: url_helper
INFO - 2020-09-10 17:02:50 --> Database Driver Class Initialized
INFO - 2020-09-10 17:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:02:50 --> Email Class Initialized
INFO - 2020-09-10 17:02:50 --> Controller Class Initialized
INFO - 2020-09-10 17:02:50 --> Model Class Initialized
INFO - 2020-09-10 17:02:50 --> Model Class Initialized
DEBUG - 2020-09-10 17:02:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:02:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 17:02:50 --> Final output sent to browser
DEBUG - 2020-09-10 17:02:50 --> Total execution time: 0.0199
ERROR - 2020-09-10 17:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:02:53 --> Config Class Initialized
INFO - 2020-09-10 17:02:53 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:02:53 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:02:53 --> Utf8 Class Initialized
INFO - 2020-09-10 17:02:53 --> URI Class Initialized
INFO - 2020-09-10 17:02:53 --> Router Class Initialized
INFO - 2020-09-10 17:02:53 --> Output Class Initialized
INFO - 2020-09-10 17:02:53 --> Security Class Initialized
DEBUG - 2020-09-10 17:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:02:53 --> Input Class Initialized
INFO - 2020-09-10 17:02:53 --> Language Class Initialized
INFO - 2020-09-10 17:02:53 --> Loader Class Initialized
INFO - 2020-09-10 17:02:53 --> Helper loaded: url_helper
INFO - 2020-09-10 17:02:54 --> Database Driver Class Initialized
INFO - 2020-09-10 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:02:54 --> Email Class Initialized
INFO - 2020-09-10 17:02:54 --> Controller Class Initialized
INFO - 2020-09-10 17:02:54 --> Model Class Initialized
INFO - 2020-09-10 17:02:54 --> Model Class Initialized
DEBUG - 2020-09-10 17:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:02:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:02:54 --> Model Class Initialized
INFO - 2020-09-10 17:02:54 --> Final output sent to browser
DEBUG - 2020-09-10 17:02:54 --> Total execution time: 0.0335
ERROR - 2020-09-10 17:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:02:54 --> Config Class Initialized
INFO - 2020-09-10 17:02:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:02:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:02:54 --> Utf8 Class Initialized
INFO - 2020-09-10 17:02:54 --> URI Class Initialized
INFO - 2020-09-10 17:02:54 --> Router Class Initialized
INFO - 2020-09-10 17:02:54 --> Output Class Initialized
INFO - 2020-09-10 17:02:54 --> Security Class Initialized
DEBUG - 2020-09-10 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:02:54 --> Input Class Initialized
INFO - 2020-09-10 17:02:54 --> Language Class Initialized
INFO - 2020-09-10 17:02:54 --> Loader Class Initialized
INFO - 2020-09-10 17:02:54 --> Helper loaded: url_helper
INFO - 2020-09-10 17:02:54 --> Database Driver Class Initialized
INFO - 2020-09-10 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:02:54 --> Email Class Initialized
INFO - 2020-09-10 17:02:54 --> Controller Class Initialized
INFO - 2020-09-10 17:02:54 --> Model Class Initialized
INFO - 2020-09-10 17:02:54 --> Model Class Initialized
DEBUG - 2020-09-10 17:02:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-10 17:02:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:02:54 --> Config Class Initialized
INFO - 2020-09-10 17:02:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:02:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:02:54 --> Utf8 Class Initialized
INFO - 2020-09-10 17:02:54 --> URI Class Initialized
INFO - 2020-09-10 17:02:54 --> Router Class Initialized
INFO - 2020-09-10 17:02:54 --> Output Class Initialized
INFO - 2020-09-10 17:02:54 --> Security Class Initialized
DEBUG - 2020-09-10 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:02:54 --> Input Class Initialized
INFO - 2020-09-10 17:02:54 --> Language Class Initialized
INFO - 2020-09-10 17:02:54 --> Loader Class Initialized
INFO - 2020-09-10 17:02:54 --> Helper loaded: url_helper
INFO - 2020-09-10 17:02:54 --> Database Driver Class Initialized
INFO - 2020-09-10 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:02:54 --> Email Class Initialized
INFO - 2020-09-10 17:02:54 --> Controller Class Initialized
DEBUG - 2020-09-10 17:02:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:02:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:02:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 17:02:54 --> Final output sent to browser
DEBUG - 2020-09-10 17:02:54 --> Total execution time: 0.0231
ERROR - 2020-09-10 17:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:02:59 --> Config Class Initialized
INFO - 2020-09-10 17:02:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:02:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:02:59 --> Utf8 Class Initialized
INFO - 2020-09-10 17:02:59 --> URI Class Initialized
INFO - 2020-09-10 17:02:59 --> Router Class Initialized
INFO - 2020-09-10 17:02:59 --> Output Class Initialized
INFO - 2020-09-10 17:02:59 --> Security Class Initialized
DEBUG - 2020-09-10 17:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:02:59 --> Input Class Initialized
INFO - 2020-09-10 17:02:59 --> Language Class Initialized
INFO - 2020-09-10 17:02:59 --> Loader Class Initialized
INFO - 2020-09-10 17:02:59 --> Helper loaded: url_helper
INFO - 2020-09-10 17:02:59 --> Database Driver Class Initialized
INFO - 2020-09-10 17:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:02:59 --> Email Class Initialized
INFO - 2020-09-10 17:02:59 --> Controller Class Initialized
DEBUG - 2020-09-10 17:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:02:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:02:59 --> Model Class Initialized
INFO - 2020-09-10 17:02:59 --> Model Class Initialized
INFO - 2020-09-10 17:02:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:02:59 --> Final output sent to browser
DEBUG - 2020-09-10 17:02:59 --> Total execution time: 0.0208
ERROR - 2020-09-10 17:03:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:15 --> Config Class Initialized
INFO - 2020-09-10 17:03:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:15 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:15 --> URI Class Initialized
INFO - 2020-09-10 17:03:15 --> Router Class Initialized
INFO - 2020-09-10 17:03:15 --> Output Class Initialized
INFO - 2020-09-10 17:03:15 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:15 --> Input Class Initialized
INFO - 2020-09-10 17:03:15 --> Language Class Initialized
INFO - 2020-09-10 17:03:15 --> Loader Class Initialized
INFO - 2020-09-10 17:03:15 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:15 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:15 --> Email Class Initialized
INFO - 2020-09-10 17:03:15 --> Controller Class Initialized
INFO - 2020-09-10 17:03:15 --> Model Class Initialized
INFO - 2020-09-10 17:03:15 --> Model Class Initialized
INFO - 2020-09-10 17:03:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:03:15 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:15 --> Total execution time: 0.0515
ERROR - 2020-09-10 17:03:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:16 --> Config Class Initialized
INFO - 2020-09-10 17:03:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:16 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:16 --> URI Class Initialized
INFO - 2020-09-10 17:03:16 --> Router Class Initialized
INFO - 2020-09-10 17:03:16 --> Output Class Initialized
INFO - 2020-09-10 17:03:16 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:16 --> Input Class Initialized
INFO - 2020-09-10 17:03:16 --> Language Class Initialized
INFO - 2020-09-10 17:03:16 --> Loader Class Initialized
INFO - 2020-09-10 17:03:16 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:16 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:16 --> Email Class Initialized
INFO - 2020-09-10 17:03:16 --> Controller Class Initialized
INFO - 2020-09-10 17:03:16 --> Model Class Initialized
INFO - 2020-09-10 17:03:16 --> Model Class Initialized
INFO - 2020-09-10 17:03:16 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:16 --> Total execution time: 0.0448
ERROR - 2020-09-10 17:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:29 --> Config Class Initialized
INFO - 2020-09-10 17:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:29 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:29 --> URI Class Initialized
INFO - 2020-09-10 17:03:29 --> Router Class Initialized
INFO - 2020-09-10 17:03:29 --> Output Class Initialized
INFO - 2020-09-10 17:03:29 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:29 --> Input Class Initialized
INFO - 2020-09-10 17:03:29 --> Language Class Initialized
INFO - 2020-09-10 17:03:29 --> Loader Class Initialized
INFO - 2020-09-10 17:03:29 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:29 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:29 --> Email Class Initialized
INFO - 2020-09-10 17:03:29 --> Controller Class Initialized
INFO - 2020-09-10 17:03:29 --> Model Class Initialized
INFO - 2020-09-10 17:03:29 --> Model Class Initialized
INFO - 2020-09-10 17:03:29 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:29 --> Total execution time: 0.1862
ERROR - 2020-09-10 17:03:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:29 --> Config Class Initialized
INFO - 2020-09-10 17:03:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:29 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:29 --> URI Class Initialized
INFO - 2020-09-10 17:03:29 --> Router Class Initialized
INFO - 2020-09-10 17:03:29 --> Output Class Initialized
INFO - 2020-09-10 17:03:29 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:29 --> Input Class Initialized
INFO - 2020-09-10 17:03:29 --> Language Class Initialized
INFO - 2020-09-10 17:03:29 --> Loader Class Initialized
INFO - 2020-09-10 17:03:29 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:29 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:29 --> Email Class Initialized
INFO - 2020-09-10 17:03:29 --> Controller Class Initialized
INFO - 2020-09-10 17:03:29 --> Model Class Initialized
INFO - 2020-09-10 17:03:29 --> Model Class Initialized
INFO - 2020-09-10 17:03:29 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:29 --> Total execution time: 0.0353
ERROR - 2020-09-10 17:03:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:38 --> Config Class Initialized
INFO - 2020-09-10 17:03:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:38 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:38 --> URI Class Initialized
INFO - 2020-09-10 17:03:38 --> Router Class Initialized
INFO - 2020-09-10 17:03:38 --> Output Class Initialized
INFO - 2020-09-10 17:03:38 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:38 --> Input Class Initialized
INFO - 2020-09-10 17:03:38 --> Language Class Initialized
INFO - 2020-09-10 17:03:38 --> Loader Class Initialized
INFO - 2020-09-10 17:03:38 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:38 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:38 --> Email Class Initialized
INFO - 2020-09-10 17:03:38 --> Controller Class Initialized
INFO - 2020-09-10 17:03:38 --> Model Class Initialized
INFO - 2020-09-10 17:03:38 --> Model Class Initialized
INFO - 2020-09-10 17:03:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:03:38 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:38 --> Total execution time: 0.0873
ERROR - 2020-09-10 17:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:39 --> Config Class Initialized
INFO - 2020-09-10 17:03:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:39 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:39 --> URI Class Initialized
INFO - 2020-09-10 17:03:39 --> Router Class Initialized
INFO - 2020-09-10 17:03:39 --> Output Class Initialized
INFO - 2020-09-10 17:03:39 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:39 --> Input Class Initialized
INFO - 2020-09-10 17:03:39 --> Language Class Initialized
INFO - 2020-09-10 17:03:39 --> Loader Class Initialized
INFO - 2020-09-10 17:03:39 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:39 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:39 --> Email Class Initialized
INFO - 2020-09-10 17:03:39 --> Controller Class Initialized
INFO - 2020-09-10 17:03:39 --> Model Class Initialized
INFO - 2020-09-10 17:03:39 --> Model Class Initialized
INFO - 2020-09-10 17:03:39 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:39 --> Total execution time: 0.0412
ERROR - 2020-09-10 17:03:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:46 --> Config Class Initialized
INFO - 2020-09-10 17:03:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:46 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:46 --> URI Class Initialized
INFO - 2020-09-10 17:03:46 --> Router Class Initialized
INFO - 2020-09-10 17:03:46 --> Output Class Initialized
INFO - 2020-09-10 17:03:46 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:46 --> Input Class Initialized
INFO - 2020-09-10 17:03:46 --> Language Class Initialized
INFO - 2020-09-10 17:03:46 --> Loader Class Initialized
INFO - 2020-09-10 17:03:46 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:46 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:46 --> Email Class Initialized
INFO - 2020-09-10 17:03:46 --> Controller Class Initialized
INFO - 2020-09-10 17:03:46 --> Model Class Initialized
INFO - 2020-09-10 17:03:46 --> Model Class Initialized
INFO - 2020-09-10 17:03:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:03:46 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:46 --> Total execution time: 0.1136
ERROR - 2020-09-10 17:03:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:03:47 --> Config Class Initialized
INFO - 2020-09-10 17:03:47 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:03:47 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:03:47 --> Utf8 Class Initialized
INFO - 2020-09-10 17:03:47 --> URI Class Initialized
INFO - 2020-09-10 17:03:47 --> Router Class Initialized
INFO - 2020-09-10 17:03:47 --> Output Class Initialized
INFO - 2020-09-10 17:03:47 --> Security Class Initialized
DEBUG - 2020-09-10 17:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:03:47 --> Input Class Initialized
INFO - 2020-09-10 17:03:47 --> Language Class Initialized
INFO - 2020-09-10 17:03:47 --> Loader Class Initialized
INFO - 2020-09-10 17:03:47 --> Helper loaded: url_helper
INFO - 2020-09-10 17:03:47 --> Database Driver Class Initialized
INFO - 2020-09-10 17:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:03:47 --> Email Class Initialized
INFO - 2020-09-10 17:03:47 --> Controller Class Initialized
INFO - 2020-09-10 17:03:47 --> Model Class Initialized
INFO - 2020-09-10 17:03:47 --> Model Class Initialized
INFO - 2020-09-10 17:03:47 --> Final output sent to browser
DEBUG - 2020-09-10 17:03:47 --> Total execution time: 0.0423
ERROR - 2020-09-10 17:05:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:05:24 --> Config Class Initialized
INFO - 2020-09-10 17:05:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:05:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:05:24 --> Utf8 Class Initialized
INFO - 2020-09-10 17:05:24 --> URI Class Initialized
INFO - 2020-09-10 17:05:24 --> Router Class Initialized
INFO - 2020-09-10 17:05:24 --> Output Class Initialized
INFO - 2020-09-10 17:05:24 --> Security Class Initialized
DEBUG - 2020-09-10 17:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:05:24 --> Input Class Initialized
INFO - 2020-09-10 17:05:24 --> Language Class Initialized
INFO - 2020-09-10 17:05:24 --> Loader Class Initialized
INFO - 2020-09-10 17:05:24 --> Helper loaded: url_helper
INFO - 2020-09-10 17:05:24 --> Database Driver Class Initialized
INFO - 2020-09-10 17:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:05:24 --> Email Class Initialized
INFO - 2020-09-10 17:05:24 --> Controller Class Initialized
INFO - 2020-09-10 17:05:24 --> Model Class Initialized
INFO - 2020-09-10 17:05:24 --> Model Class Initialized
INFO - 2020-09-10 17:05:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:05:24 --> Final output sent to browser
DEBUG - 2020-09-10 17:05:24 --> Total execution time: 0.0412
ERROR - 2020-09-10 17:05:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:05:25 --> Config Class Initialized
INFO - 2020-09-10 17:05:25 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:05:25 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:05:25 --> Utf8 Class Initialized
INFO - 2020-09-10 17:05:25 --> URI Class Initialized
INFO - 2020-09-10 17:05:25 --> Router Class Initialized
INFO - 2020-09-10 17:05:25 --> Output Class Initialized
INFO - 2020-09-10 17:05:25 --> Security Class Initialized
DEBUG - 2020-09-10 17:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:05:25 --> Input Class Initialized
INFO - 2020-09-10 17:05:25 --> Language Class Initialized
INFO - 2020-09-10 17:05:25 --> Loader Class Initialized
INFO - 2020-09-10 17:05:25 --> Helper loaded: url_helper
INFO - 2020-09-10 17:05:25 --> Database Driver Class Initialized
INFO - 2020-09-10 17:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:05:25 --> Email Class Initialized
INFO - 2020-09-10 17:05:25 --> Controller Class Initialized
INFO - 2020-09-10 17:05:25 --> Model Class Initialized
INFO - 2020-09-10 17:05:25 --> Model Class Initialized
INFO - 2020-09-10 17:05:25 --> Final output sent to browser
DEBUG - 2020-09-10 17:05:25 --> Total execution time: 0.0437
ERROR - 2020-09-10 17:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:09:16 --> Config Class Initialized
INFO - 2020-09-10 17:09:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:09:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:09:16 --> Utf8 Class Initialized
INFO - 2020-09-10 17:09:16 --> URI Class Initialized
INFO - 2020-09-10 17:09:16 --> Router Class Initialized
INFO - 2020-09-10 17:09:16 --> Output Class Initialized
INFO - 2020-09-10 17:09:16 --> Security Class Initialized
DEBUG - 2020-09-10 17:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:09:16 --> Input Class Initialized
INFO - 2020-09-10 17:09:16 --> Language Class Initialized
INFO - 2020-09-10 17:09:16 --> Loader Class Initialized
INFO - 2020-09-10 17:09:16 --> Helper loaded: url_helper
INFO - 2020-09-10 17:09:16 --> Database Driver Class Initialized
INFO - 2020-09-10 17:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:09:16 --> Email Class Initialized
INFO - 2020-09-10 17:09:16 --> Controller Class Initialized
INFO - 2020-09-10 17:09:16 --> Model Class Initialized
INFO - 2020-09-10 17:09:16 --> Model Class Initialized
INFO - 2020-09-10 17:09:16 --> Final output sent to browser
DEBUG - 2020-09-10 17:09:16 --> Total execution time: 0.1386
ERROR - 2020-09-10 17:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:09:16 --> Config Class Initialized
INFO - 2020-09-10 17:09:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:09:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:09:16 --> Utf8 Class Initialized
INFO - 2020-09-10 17:09:16 --> URI Class Initialized
INFO - 2020-09-10 17:09:16 --> Router Class Initialized
INFO - 2020-09-10 17:09:16 --> Output Class Initialized
INFO - 2020-09-10 17:09:16 --> Security Class Initialized
DEBUG - 2020-09-10 17:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:09:16 --> Input Class Initialized
INFO - 2020-09-10 17:09:16 --> Language Class Initialized
INFO - 2020-09-10 17:09:16 --> Loader Class Initialized
INFO - 2020-09-10 17:09:16 --> Helper loaded: url_helper
INFO - 2020-09-10 17:09:16 --> Database Driver Class Initialized
INFO - 2020-09-10 17:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:09:16 --> Email Class Initialized
INFO - 2020-09-10 17:09:16 --> Controller Class Initialized
INFO - 2020-09-10 17:09:16 --> Model Class Initialized
INFO - 2020-09-10 17:09:16 --> Model Class Initialized
INFO - 2020-09-10 17:09:16 --> Final output sent to browser
DEBUG - 2020-09-10 17:09:16 --> Total execution time: 0.0337
ERROR - 2020-09-10 17:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:10:26 --> Config Class Initialized
INFO - 2020-09-10 17:10:26 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:10:26 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:10:26 --> Utf8 Class Initialized
INFO - 2020-09-10 17:10:26 --> URI Class Initialized
INFO - 2020-09-10 17:10:26 --> Router Class Initialized
INFO - 2020-09-10 17:10:26 --> Output Class Initialized
INFO - 2020-09-10 17:10:26 --> Security Class Initialized
DEBUG - 2020-09-10 17:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:10:26 --> Input Class Initialized
INFO - 2020-09-10 17:10:26 --> Language Class Initialized
INFO - 2020-09-10 17:10:26 --> Loader Class Initialized
INFO - 2020-09-10 17:10:26 --> Helper loaded: url_helper
INFO - 2020-09-10 17:10:26 --> Database Driver Class Initialized
INFO - 2020-09-10 17:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:10:26 --> Email Class Initialized
INFO - 2020-09-10 17:10:26 --> Controller Class Initialized
INFO - 2020-09-10 17:10:26 --> Model Class Initialized
INFO - 2020-09-10 17:10:26 --> Model Class Initialized
INFO - 2020-09-10 17:10:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:10:27 --> Final output sent to browser
DEBUG - 2020-09-10 17:10:27 --> Total execution time: 0.0463
ERROR - 2020-09-10 17:10:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:10:27 --> Config Class Initialized
INFO - 2020-09-10 17:10:27 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:10:27 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:10:27 --> Utf8 Class Initialized
INFO - 2020-09-10 17:10:27 --> URI Class Initialized
INFO - 2020-09-10 17:10:27 --> Router Class Initialized
INFO - 2020-09-10 17:10:27 --> Output Class Initialized
INFO - 2020-09-10 17:10:27 --> Security Class Initialized
DEBUG - 2020-09-10 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:10:27 --> Input Class Initialized
INFO - 2020-09-10 17:10:27 --> Language Class Initialized
INFO - 2020-09-10 17:10:27 --> Loader Class Initialized
INFO - 2020-09-10 17:10:27 --> Helper loaded: url_helper
INFO - 2020-09-10 17:10:27 --> Database Driver Class Initialized
INFO - 2020-09-10 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:10:27 --> Email Class Initialized
INFO - 2020-09-10 17:10:27 --> Controller Class Initialized
INFO - 2020-09-10 17:10:27 --> Model Class Initialized
INFO - 2020-09-10 17:10:27 --> Model Class Initialized
INFO - 2020-09-10 17:10:27 --> Final output sent to browser
DEBUG - 2020-09-10 17:10:27 --> Total execution time: 0.0437
ERROR - 2020-09-10 17:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:11:40 --> Config Class Initialized
INFO - 2020-09-10 17:11:40 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:11:40 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:11:40 --> Utf8 Class Initialized
INFO - 2020-09-10 17:11:40 --> URI Class Initialized
INFO - 2020-09-10 17:11:40 --> Router Class Initialized
INFO - 2020-09-10 17:11:40 --> Output Class Initialized
INFO - 2020-09-10 17:11:40 --> Security Class Initialized
DEBUG - 2020-09-10 17:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:11:40 --> Input Class Initialized
INFO - 2020-09-10 17:11:40 --> Language Class Initialized
INFO - 2020-09-10 17:11:40 --> Loader Class Initialized
INFO - 2020-09-10 17:11:40 --> Helper loaded: url_helper
INFO - 2020-09-10 17:11:40 --> Database Driver Class Initialized
INFO - 2020-09-10 17:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:11:40 --> Email Class Initialized
INFO - 2020-09-10 17:11:40 --> Controller Class Initialized
INFO - 2020-09-10 17:11:40 --> Model Class Initialized
INFO - 2020-09-10 17:11:40 --> Model Class Initialized
INFO - 2020-09-10 17:11:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:11:40 --> Final output sent to browser
DEBUG - 2020-09-10 17:11:40 --> Total execution time: 0.0351
ERROR - 2020-09-10 17:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:11:41 --> Config Class Initialized
INFO - 2020-09-10 17:11:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:11:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:11:41 --> Utf8 Class Initialized
INFO - 2020-09-10 17:11:41 --> URI Class Initialized
INFO - 2020-09-10 17:11:41 --> Router Class Initialized
INFO - 2020-09-10 17:11:41 --> Output Class Initialized
INFO - 2020-09-10 17:11:41 --> Security Class Initialized
DEBUG - 2020-09-10 17:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:11:41 --> Input Class Initialized
INFO - 2020-09-10 17:11:41 --> Language Class Initialized
INFO - 2020-09-10 17:11:41 --> Loader Class Initialized
INFO - 2020-09-10 17:11:41 --> Helper loaded: url_helper
INFO - 2020-09-10 17:11:41 --> Database Driver Class Initialized
INFO - 2020-09-10 17:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:11:41 --> Email Class Initialized
INFO - 2020-09-10 17:11:41 --> Controller Class Initialized
INFO - 2020-09-10 17:11:41 --> Model Class Initialized
INFO - 2020-09-10 17:11:41 --> Model Class Initialized
INFO - 2020-09-10 17:11:41 --> Final output sent to browser
DEBUG - 2020-09-10 17:11:41 --> Total execution time: 0.0379
ERROR - 2020-09-10 17:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:11:45 --> Config Class Initialized
INFO - 2020-09-10 17:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:11:45 --> Utf8 Class Initialized
INFO - 2020-09-10 17:11:45 --> URI Class Initialized
INFO - 2020-09-10 17:11:45 --> Router Class Initialized
INFO - 2020-09-10 17:11:45 --> Output Class Initialized
INFO - 2020-09-10 17:11:45 --> Security Class Initialized
DEBUG - 2020-09-10 17:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:11:45 --> Input Class Initialized
INFO - 2020-09-10 17:11:45 --> Language Class Initialized
INFO - 2020-09-10 17:11:45 --> Loader Class Initialized
INFO - 2020-09-10 17:11:45 --> Helper loaded: url_helper
INFO - 2020-09-10 17:11:45 --> Database Driver Class Initialized
INFO - 2020-09-10 17:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:11:45 --> Email Class Initialized
INFO - 2020-09-10 17:11:45 --> Controller Class Initialized
INFO - 2020-09-10 17:11:45 --> Model Class Initialized
INFO - 2020-09-10 17:11:45 --> Model Class Initialized
INFO - 2020-09-10 17:11:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:11:45 --> Final output sent to browser
DEBUG - 2020-09-10 17:11:45 --> Total execution time: 0.0356
ERROR - 2020-09-10 17:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:11:45 --> Config Class Initialized
INFO - 2020-09-10 17:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:11:45 --> Utf8 Class Initialized
INFO - 2020-09-10 17:11:45 --> URI Class Initialized
INFO - 2020-09-10 17:11:45 --> Router Class Initialized
INFO - 2020-09-10 17:11:45 --> Output Class Initialized
INFO - 2020-09-10 17:11:45 --> Security Class Initialized
DEBUG - 2020-09-10 17:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:11:45 --> Input Class Initialized
INFO - 2020-09-10 17:11:45 --> Language Class Initialized
INFO - 2020-09-10 17:11:45 --> Loader Class Initialized
INFO - 2020-09-10 17:11:45 --> Helper loaded: url_helper
INFO - 2020-09-10 17:11:45 --> Database Driver Class Initialized
INFO - 2020-09-10 17:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:11:45 --> Email Class Initialized
INFO - 2020-09-10 17:11:45 --> Controller Class Initialized
INFO - 2020-09-10 17:11:45 --> Model Class Initialized
INFO - 2020-09-10 17:11:45 --> Model Class Initialized
INFO - 2020-09-10 17:11:45 --> Final output sent to browser
DEBUG - 2020-09-10 17:11:45 --> Total execution time: 0.0388
ERROR - 2020-09-10 17:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:12:41 --> Config Class Initialized
INFO - 2020-09-10 17:12:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:12:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:12:41 --> Utf8 Class Initialized
INFO - 2020-09-10 17:12:41 --> URI Class Initialized
INFO - 2020-09-10 17:12:41 --> Router Class Initialized
INFO - 2020-09-10 17:12:41 --> Output Class Initialized
INFO - 2020-09-10 17:12:41 --> Security Class Initialized
DEBUG - 2020-09-10 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:12:41 --> Input Class Initialized
INFO - 2020-09-10 17:12:41 --> Language Class Initialized
INFO - 2020-09-10 17:12:41 --> Loader Class Initialized
INFO - 2020-09-10 17:12:41 --> Helper loaded: url_helper
INFO - 2020-09-10 17:12:41 --> Database Driver Class Initialized
INFO - 2020-09-10 17:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:12:41 --> Email Class Initialized
INFO - 2020-09-10 17:12:41 --> Controller Class Initialized
INFO - 2020-09-10 17:12:41 --> Model Class Initialized
INFO - 2020-09-10 17:12:41 --> Model Class Initialized
INFO - 2020-09-10 17:12:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:12:41 --> Final output sent to browser
DEBUG - 2020-09-10 17:12:41 --> Total execution time: 0.0376
ERROR - 2020-09-10 17:12:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:12:41 --> Config Class Initialized
INFO - 2020-09-10 17:12:41 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:12:41 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:12:41 --> Utf8 Class Initialized
INFO - 2020-09-10 17:12:41 --> URI Class Initialized
INFO - 2020-09-10 17:12:41 --> Router Class Initialized
INFO - 2020-09-10 17:12:41 --> Output Class Initialized
INFO - 2020-09-10 17:12:41 --> Security Class Initialized
DEBUG - 2020-09-10 17:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:12:41 --> Input Class Initialized
INFO - 2020-09-10 17:12:41 --> Language Class Initialized
INFO - 2020-09-10 17:12:41 --> Loader Class Initialized
INFO - 2020-09-10 17:12:41 --> Helper loaded: url_helper
INFO - 2020-09-10 17:12:41 --> Database Driver Class Initialized
INFO - 2020-09-10 17:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:12:41 --> Email Class Initialized
INFO - 2020-09-10 17:12:41 --> Controller Class Initialized
INFO - 2020-09-10 17:12:41 --> Model Class Initialized
INFO - 2020-09-10 17:12:41 --> Model Class Initialized
INFO - 2020-09-10 17:12:41 --> Final output sent to browser
DEBUG - 2020-09-10 17:12:41 --> Total execution time: 0.0395
ERROR - 2020-09-10 17:17:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:17:56 --> Config Class Initialized
INFO - 2020-09-10 17:17:56 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:17:56 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:17:56 --> Utf8 Class Initialized
INFO - 2020-09-10 17:17:56 --> URI Class Initialized
INFO - 2020-09-10 17:17:56 --> Router Class Initialized
INFO - 2020-09-10 17:17:56 --> Output Class Initialized
INFO - 2020-09-10 17:17:56 --> Security Class Initialized
DEBUG - 2020-09-10 17:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:17:56 --> Input Class Initialized
INFO - 2020-09-10 17:17:56 --> Language Class Initialized
INFO - 2020-09-10 17:17:56 --> Loader Class Initialized
INFO - 2020-09-10 17:17:56 --> Helper loaded: url_helper
INFO - 2020-09-10 17:17:56 --> Database Driver Class Initialized
INFO - 2020-09-10 17:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:17:56 --> Email Class Initialized
INFO - 2020-09-10 17:17:56 --> Controller Class Initialized
INFO - 2020-09-10 17:17:56 --> Model Class Initialized
INFO - 2020-09-10 17:17:56 --> Model Class Initialized
INFO - 2020-09-10 17:17:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:17:56 --> Final output sent to browser
DEBUG - 2020-09-10 17:17:56 --> Total execution time: 0.0833
ERROR - 2020-09-10 17:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:17:57 --> Config Class Initialized
INFO - 2020-09-10 17:17:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:17:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:17:57 --> Utf8 Class Initialized
INFO - 2020-09-10 17:17:57 --> URI Class Initialized
INFO - 2020-09-10 17:17:57 --> Router Class Initialized
INFO - 2020-09-10 17:17:57 --> Output Class Initialized
INFO - 2020-09-10 17:17:57 --> Security Class Initialized
DEBUG - 2020-09-10 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:17:57 --> Input Class Initialized
INFO - 2020-09-10 17:17:57 --> Language Class Initialized
INFO - 2020-09-10 17:17:57 --> Loader Class Initialized
INFO - 2020-09-10 17:17:57 --> Helper loaded: url_helper
INFO - 2020-09-10 17:17:57 --> Database Driver Class Initialized
INFO - 2020-09-10 17:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:17:57 --> Email Class Initialized
INFO - 2020-09-10 17:17:57 --> Controller Class Initialized
INFO - 2020-09-10 17:17:57 --> Model Class Initialized
INFO - 2020-09-10 17:17:57 --> Model Class Initialized
INFO - 2020-09-10 17:17:57 --> Final output sent to browser
DEBUG - 2020-09-10 17:17:57 --> Total execution time: 0.0340
ERROR - 2020-09-10 17:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:20:39 --> Config Class Initialized
INFO - 2020-09-10 17:20:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:20:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:20:39 --> Utf8 Class Initialized
INFO - 2020-09-10 17:20:39 --> URI Class Initialized
INFO - 2020-09-10 17:20:39 --> Router Class Initialized
INFO - 2020-09-10 17:20:39 --> Output Class Initialized
INFO - 2020-09-10 17:20:39 --> Security Class Initialized
DEBUG - 2020-09-10 17:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:20:39 --> Input Class Initialized
INFO - 2020-09-10 17:20:39 --> Language Class Initialized
INFO - 2020-09-10 17:20:39 --> Loader Class Initialized
INFO - 2020-09-10 17:20:39 --> Helper loaded: url_helper
INFO - 2020-09-10 17:20:39 --> Database Driver Class Initialized
INFO - 2020-09-10 17:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:20:39 --> Email Class Initialized
INFO - 2020-09-10 17:20:39 --> Controller Class Initialized
INFO - 2020-09-10 17:20:39 --> Model Class Initialized
INFO - 2020-09-10 17:20:39 --> Model Class Initialized
INFO - 2020-09-10 17:20:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:20:39 --> Final output sent to browser
DEBUG - 2020-09-10 17:20:39 --> Total execution time: 0.0369
ERROR - 2020-09-10 17:20:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:20:39 --> Config Class Initialized
INFO - 2020-09-10 17:20:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:20:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:20:39 --> Utf8 Class Initialized
INFO - 2020-09-10 17:20:39 --> URI Class Initialized
INFO - 2020-09-10 17:20:39 --> Router Class Initialized
INFO - 2020-09-10 17:20:39 --> Output Class Initialized
INFO - 2020-09-10 17:20:39 --> Security Class Initialized
DEBUG - 2020-09-10 17:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:20:39 --> Input Class Initialized
INFO - 2020-09-10 17:20:39 --> Language Class Initialized
INFO - 2020-09-10 17:20:39 --> Loader Class Initialized
INFO - 2020-09-10 17:20:39 --> Helper loaded: url_helper
INFO - 2020-09-10 17:20:39 --> Database Driver Class Initialized
INFO - 2020-09-10 17:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:20:39 --> Email Class Initialized
INFO - 2020-09-10 17:20:39 --> Controller Class Initialized
INFO - 2020-09-10 17:20:39 --> Model Class Initialized
INFO - 2020-09-10 17:20:39 --> Model Class Initialized
INFO - 2020-09-10 17:20:39 --> Final output sent to browser
DEBUG - 2020-09-10 17:20:39 --> Total execution time: 0.0390
ERROR - 2020-09-10 17:20:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:20:46 --> Config Class Initialized
INFO - 2020-09-10 17:20:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:20:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:20:46 --> Utf8 Class Initialized
INFO - 2020-09-10 17:20:46 --> URI Class Initialized
INFO - 2020-09-10 17:20:46 --> Router Class Initialized
INFO - 2020-09-10 17:20:46 --> Output Class Initialized
INFO - 2020-09-10 17:20:46 --> Security Class Initialized
DEBUG - 2020-09-10 17:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:20:46 --> Input Class Initialized
INFO - 2020-09-10 17:20:46 --> Language Class Initialized
INFO - 2020-09-10 17:20:46 --> Loader Class Initialized
INFO - 2020-09-10 17:20:46 --> Helper loaded: url_helper
INFO - 2020-09-10 17:20:46 --> Database Driver Class Initialized
INFO - 2020-09-10 17:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:20:46 --> Email Class Initialized
INFO - 2020-09-10 17:20:46 --> Controller Class Initialized
INFO - 2020-09-10 17:20:46 --> Model Class Initialized
INFO - 2020-09-10 17:20:46 --> Model Class Initialized
INFO - 2020-09-10 17:20:46 --> Final output sent to browser
DEBUG - 2020-09-10 17:20:46 --> Total execution time: 0.1488
ERROR - 2020-09-10 17:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:21:15 --> Config Class Initialized
INFO - 2020-09-10 17:21:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:21:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:21:15 --> Utf8 Class Initialized
INFO - 2020-09-10 17:21:15 --> URI Class Initialized
INFO - 2020-09-10 17:21:15 --> Router Class Initialized
INFO - 2020-09-10 17:21:15 --> Output Class Initialized
INFO - 2020-09-10 17:21:15 --> Security Class Initialized
DEBUG - 2020-09-10 17:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:21:15 --> Input Class Initialized
INFO - 2020-09-10 17:21:15 --> Language Class Initialized
INFO - 2020-09-10 17:21:15 --> Loader Class Initialized
INFO - 2020-09-10 17:21:15 --> Helper loaded: url_helper
INFO - 2020-09-10 17:21:15 --> Database Driver Class Initialized
INFO - 2020-09-10 17:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:21:15 --> Email Class Initialized
INFO - 2020-09-10 17:21:15 --> Controller Class Initialized
INFO - 2020-09-10 17:21:15 --> Model Class Initialized
INFO - 2020-09-10 17:21:15 --> Model Class Initialized
INFO - 2020-09-10 17:21:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:21:15 --> Final output sent to browser
DEBUG - 2020-09-10 17:21:15 --> Total execution time: 0.0382
ERROR - 2020-09-10 17:21:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:21:16 --> Config Class Initialized
INFO - 2020-09-10 17:21:16 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:21:16 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:21:16 --> Utf8 Class Initialized
INFO - 2020-09-10 17:21:16 --> URI Class Initialized
INFO - 2020-09-10 17:21:16 --> Router Class Initialized
INFO - 2020-09-10 17:21:16 --> Output Class Initialized
INFO - 2020-09-10 17:21:16 --> Security Class Initialized
DEBUG - 2020-09-10 17:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:21:16 --> Input Class Initialized
INFO - 2020-09-10 17:21:16 --> Language Class Initialized
INFO - 2020-09-10 17:21:16 --> Loader Class Initialized
INFO - 2020-09-10 17:21:16 --> Helper loaded: url_helper
INFO - 2020-09-10 17:21:16 --> Database Driver Class Initialized
INFO - 2020-09-10 17:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:21:16 --> Email Class Initialized
INFO - 2020-09-10 17:21:16 --> Controller Class Initialized
INFO - 2020-09-10 17:21:16 --> Model Class Initialized
INFO - 2020-09-10 17:21:16 --> Model Class Initialized
INFO - 2020-09-10 17:21:16 --> Final output sent to browser
DEBUG - 2020-09-10 17:21:16 --> Total execution time: 0.0382
ERROR - 2020-09-10 17:21:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:21:19 --> Config Class Initialized
INFO - 2020-09-10 17:21:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:21:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:21:19 --> Utf8 Class Initialized
INFO - 2020-09-10 17:21:19 --> URI Class Initialized
INFO - 2020-09-10 17:21:19 --> Router Class Initialized
INFO - 2020-09-10 17:21:19 --> Output Class Initialized
INFO - 2020-09-10 17:21:19 --> Security Class Initialized
DEBUG - 2020-09-10 17:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:21:19 --> Input Class Initialized
INFO - 2020-09-10 17:21:19 --> Language Class Initialized
INFO - 2020-09-10 17:21:19 --> Loader Class Initialized
INFO - 2020-09-10 17:21:19 --> Helper loaded: url_helper
INFO - 2020-09-10 17:21:19 --> Database Driver Class Initialized
INFO - 2020-09-10 17:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:21:19 --> Email Class Initialized
INFO - 2020-09-10 17:21:19 --> Controller Class Initialized
INFO - 2020-09-10 17:21:19 --> Model Class Initialized
INFO - 2020-09-10 17:21:19 --> Model Class Initialized
INFO - 2020-09-10 17:21:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:21:19 --> Final output sent to browser
DEBUG - 2020-09-10 17:21:19 --> Total execution time: 0.0373
ERROR - 2020-09-10 17:21:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:21:20 --> Config Class Initialized
INFO - 2020-09-10 17:21:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:21:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:21:20 --> Utf8 Class Initialized
INFO - 2020-09-10 17:21:20 --> URI Class Initialized
INFO - 2020-09-10 17:21:20 --> Router Class Initialized
INFO - 2020-09-10 17:21:20 --> Output Class Initialized
INFO - 2020-09-10 17:21:20 --> Security Class Initialized
DEBUG - 2020-09-10 17:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:21:20 --> Input Class Initialized
INFO - 2020-09-10 17:21:20 --> Language Class Initialized
INFO - 2020-09-10 17:21:20 --> Loader Class Initialized
INFO - 2020-09-10 17:21:20 --> Helper loaded: url_helper
INFO - 2020-09-10 17:21:20 --> Database Driver Class Initialized
INFO - 2020-09-10 17:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:21:20 --> Email Class Initialized
INFO - 2020-09-10 17:21:20 --> Controller Class Initialized
INFO - 2020-09-10 17:21:20 --> Model Class Initialized
INFO - 2020-09-10 17:21:20 --> Model Class Initialized
INFO - 2020-09-10 17:21:20 --> Final output sent to browser
DEBUG - 2020-09-10 17:21:20 --> Total execution time: 0.0358
ERROR - 2020-09-10 17:22:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:22:08 --> Config Class Initialized
INFO - 2020-09-10 17:22:08 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:22:08 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:22:08 --> Utf8 Class Initialized
INFO - 2020-09-10 17:22:08 --> URI Class Initialized
INFO - 2020-09-10 17:22:08 --> Router Class Initialized
INFO - 2020-09-10 17:22:08 --> Output Class Initialized
INFO - 2020-09-10 17:22:08 --> Security Class Initialized
DEBUG - 2020-09-10 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:22:08 --> Input Class Initialized
INFO - 2020-09-10 17:22:08 --> Language Class Initialized
INFO - 2020-09-10 17:22:08 --> Loader Class Initialized
INFO - 2020-09-10 17:22:08 --> Helper loaded: url_helper
INFO - 2020-09-10 17:22:08 --> Database Driver Class Initialized
INFO - 2020-09-10 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:22:08 --> Email Class Initialized
INFO - 2020-09-10 17:22:08 --> Controller Class Initialized
INFO - 2020-09-10 17:22:08 --> Model Class Initialized
INFO - 2020-09-10 17:22:08 --> Model Class Initialized
INFO - 2020-09-10 17:22:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-10 17:22:08 --> Final output sent to browser
DEBUG - 2020-09-10 17:22:08 --> Total execution time: 0.1520
ERROR - 2020-09-10 17:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:20 --> Config Class Initialized
INFO - 2020-09-10 17:23:20 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:20 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:20 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:20 --> URI Class Initialized
INFO - 2020-09-10 17:23:20 --> Router Class Initialized
INFO - 2020-09-10 17:23:20 --> Output Class Initialized
INFO - 2020-09-10 17:23:20 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:20 --> Input Class Initialized
INFO - 2020-09-10 17:23:20 --> Language Class Initialized
INFO - 2020-09-10 17:23:20 --> Loader Class Initialized
INFO - 2020-09-10 17:23:20 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:20 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:20 --> Email Class Initialized
INFO - 2020-09-10 17:23:20 --> Controller Class Initialized
INFO - 2020-09-10 17:23:20 --> Model Class Initialized
INFO - 2020-09-10 17:23:20 --> Model Class Initialized
INFO - 2020-09-10 17:23:20 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:20 --> Total execution time: 0.1197
ERROR - 2020-09-10 17:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:23 --> Config Class Initialized
INFO - 2020-09-10 17:23:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:23 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:23 --> URI Class Initialized
INFO - 2020-09-10 17:23:23 --> Router Class Initialized
INFO - 2020-09-10 17:23:23 --> Output Class Initialized
INFO - 2020-09-10 17:23:23 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:23 --> Input Class Initialized
INFO - 2020-09-10 17:23:23 --> Language Class Initialized
INFO - 2020-09-10 17:23:23 --> Loader Class Initialized
INFO - 2020-09-10 17:23:23 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:23 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:23 --> Email Class Initialized
INFO - 2020-09-10 17:23:23 --> Controller Class Initialized
INFO - 2020-09-10 17:23:23 --> Model Class Initialized
INFO - 2020-09-10 17:23:23 --> Model Class Initialized
INFO - 2020-09-10 17:23:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:23:23 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:23 --> Total execution time: 0.0327
ERROR - 2020-09-10 17:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:23 --> Config Class Initialized
INFO - 2020-09-10 17:23:23 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:23 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:23 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:23 --> URI Class Initialized
INFO - 2020-09-10 17:23:23 --> Router Class Initialized
INFO - 2020-09-10 17:23:23 --> Output Class Initialized
INFO - 2020-09-10 17:23:23 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:23 --> Input Class Initialized
INFO - 2020-09-10 17:23:23 --> Language Class Initialized
INFO - 2020-09-10 17:23:23 --> Loader Class Initialized
INFO - 2020-09-10 17:23:23 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:23 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:23 --> Email Class Initialized
INFO - 2020-09-10 17:23:23 --> Controller Class Initialized
INFO - 2020-09-10 17:23:23 --> Model Class Initialized
INFO - 2020-09-10 17:23:23 --> Model Class Initialized
INFO - 2020-09-10 17:23:23 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:23 --> Total execution time: 0.0335
ERROR - 2020-09-10 17:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:31 --> Config Class Initialized
INFO - 2020-09-10 17:23:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:31 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:31 --> URI Class Initialized
INFO - 2020-09-10 17:23:31 --> Router Class Initialized
INFO - 2020-09-10 17:23:31 --> Output Class Initialized
INFO - 2020-09-10 17:23:31 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:31 --> Input Class Initialized
INFO - 2020-09-10 17:23:31 --> Language Class Initialized
INFO - 2020-09-10 17:23:31 --> Loader Class Initialized
INFO - 2020-09-10 17:23:31 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:31 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:31 --> Email Class Initialized
INFO - 2020-09-10 17:23:31 --> Controller Class Initialized
INFO - 2020-09-10 17:23:31 --> Model Class Initialized
INFO - 2020-09-10 17:23:31 --> Model Class Initialized
INFO - 2020-09-10 17:23:31 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:31 --> Total execution time: 0.1167
ERROR - 2020-09-10 17:23:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:31 --> Config Class Initialized
INFO - 2020-09-10 17:23:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:31 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:31 --> URI Class Initialized
INFO - 2020-09-10 17:23:31 --> Router Class Initialized
INFO - 2020-09-10 17:23:31 --> Output Class Initialized
INFO - 2020-09-10 17:23:31 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:31 --> Input Class Initialized
INFO - 2020-09-10 17:23:31 --> Language Class Initialized
INFO - 2020-09-10 17:23:31 --> Loader Class Initialized
INFO - 2020-09-10 17:23:31 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:31 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:31 --> Email Class Initialized
INFO - 2020-09-10 17:23:31 --> Controller Class Initialized
INFO - 2020-09-10 17:23:31 --> Model Class Initialized
INFO - 2020-09-10 17:23:31 --> Model Class Initialized
INFO - 2020-09-10 17:23:31 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:31 --> Total execution time: 0.0416
ERROR - 2020-09-10 17:23:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:38 --> Config Class Initialized
INFO - 2020-09-10 17:23:38 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:38 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:38 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:38 --> URI Class Initialized
INFO - 2020-09-10 17:23:38 --> Router Class Initialized
INFO - 2020-09-10 17:23:38 --> Output Class Initialized
INFO - 2020-09-10 17:23:38 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:38 --> Input Class Initialized
INFO - 2020-09-10 17:23:38 --> Language Class Initialized
INFO - 2020-09-10 17:23:38 --> Loader Class Initialized
INFO - 2020-09-10 17:23:38 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:38 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:38 --> Email Class Initialized
INFO - 2020-09-10 17:23:38 --> Controller Class Initialized
INFO - 2020-09-10 17:23:38 --> Model Class Initialized
INFO - 2020-09-10 17:23:38 --> Model Class Initialized
INFO - 2020-09-10 17:23:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:23:38 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:38 --> Total execution time: 0.1048
ERROR - 2020-09-10 17:23:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:23:39 --> Config Class Initialized
INFO - 2020-09-10 17:23:39 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:23:39 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:23:39 --> Utf8 Class Initialized
INFO - 2020-09-10 17:23:39 --> URI Class Initialized
INFO - 2020-09-10 17:23:39 --> Router Class Initialized
INFO - 2020-09-10 17:23:39 --> Output Class Initialized
INFO - 2020-09-10 17:23:39 --> Security Class Initialized
DEBUG - 2020-09-10 17:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:23:39 --> Input Class Initialized
INFO - 2020-09-10 17:23:39 --> Language Class Initialized
INFO - 2020-09-10 17:23:39 --> Loader Class Initialized
INFO - 2020-09-10 17:23:39 --> Helper loaded: url_helper
INFO - 2020-09-10 17:23:39 --> Database Driver Class Initialized
INFO - 2020-09-10 17:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:23:39 --> Email Class Initialized
INFO - 2020-09-10 17:23:39 --> Controller Class Initialized
INFO - 2020-09-10 17:23:39 --> Model Class Initialized
INFO - 2020-09-10 17:23:39 --> Model Class Initialized
INFO - 2020-09-10 17:23:39 --> Final output sent to browser
DEBUG - 2020-09-10 17:23:39 --> Total execution time: 0.0343
ERROR - 2020-09-10 17:24:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:24:12 --> Config Class Initialized
INFO - 2020-09-10 17:24:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:24:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:24:12 --> Utf8 Class Initialized
INFO - 2020-09-10 17:24:12 --> URI Class Initialized
INFO - 2020-09-10 17:24:12 --> Router Class Initialized
INFO - 2020-09-10 17:24:12 --> Output Class Initialized
INFO - 2020-09-10 17:24:12 --> Security Class Initialized
DEBUG - 2020-09-10 17:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:24:12 --> Input Class Initialized
INFO - 2020-09-10 17:24:12 --> Language Class Initialized
INFO - 2020-09-10 17:24:12 --> Loader Class Initialized
INFO - 2020-09-10 17:24:12 --> Helper loaded: url_helper
INFO - 2020-09-10 17:24:12 --> Database Driver Class Initialized
INFO - 2020-09-10 17:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:24:12 --> Email Class Initialized
INFO - 2020-09-10 17:24:12 --> Controller Class Initialized
DEBUG - 2020-09-10 17:24:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:24:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:24:12 --> Model Class Initialized
INFO - 2020-09-10 17:24:12 --> Model Class Initialized
INFO - 2020-09-10 17:24:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:24:12 --> Final output sent to browser
DEBUG - 2020-09-10 17:24:12 --> Total execution time: 0.0245
ERROR - 2020-09-10 17:27:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:27:09 --> Config Class Initialized
INFO - 2020-09-10 17:27:09 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:27:09 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:27:09 --> Utf8 Class Initialized
INFO - 2020-09-10 17:27:09 --> URI Class Initialized
INFO - 2020-09-10 17:27:09 --> Router Class Initialized
INFO - 2020-09-10 17:27:09 --> Output Class Initialized
INFO - 2020-09-10 17:27:09 --> Security Class Initialized
DEBUG - 2020-09-10 17:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:27:09 --> Input Class Initialized
INFO - 2020-09-10 17:27:09 --> Language Class Initialized
INFO - 2020-09-10 17:27:09 --> Loader Class Initialized
INFO - 2020-09-10 17:27:09 --> Helper loaded: url_helper
INFO - 2020-09-10 17:27:09 --> Database Driver Class Initialized
INFO - 2020-09-10 17:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:27:09 --> Email Class Initialized
INFO - 2020-09-10 17:27:09 --> Controller Class Initialized
DEBUG - 2020-09-10 17:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:27:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:27:09 --> Model Class Initialized
INFO - 2020-09-10 17:27:09 --> Model Class Initialized
INFO - 2020-09-10 17:27:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:27:09 --> Final output sent to browser
DEBUG - 2020-09-10 17:27:09 --> Total execution time: 0.0218
ERROR - 2020-09-10 17:28:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:28:31 --> Config Class Initialized
INFO - 2020-09-10 17:28:31 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:28:31 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:28:31 --> Utf8 Class Initialized
INFO - 2020-09-10 17:28:31 --> URI Class Initialized
INFO - 2020-09-10 17:28:31 --> Router Class Initialized
INFO - 2020-09-10 17:28:31 --> Output Class Initialized
INFO - 2020-09-10 17:28:31 --> Security Class Initialized
DEBUG - 2020-09-10 17:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:28:31 --> Input Class Initialized
INFO - 2020-09-10 17:28:31 --> Language Class Initialized
INFO - 2020-09-10 17:28:31 --> Loader Class Initialized
INFO - 2020-09-10 17:28:31 --> Helper loaded: url_helper
INFO - 2020-09-10 17:28:31 --> Database Driver Class Initialized
INFO - 2020-09-10 17:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:28:31 --> Email Class Initialized
INFO - 2020-09-10 17:28:31 --> Controller Class Initialized
INFO - 2020-09-10 17:28:31 --> Model Class Initialized
INFO - 2020-09-10 17:28:31 --> Model Class Initialized
INFO - 2020-09-10 17:28:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:28:31 --> Final output sent to browser
DEBUG - 2020-09-10 17:28:31 --> Total execution time: 0.0400
ERROR - 2020-09-10 17:28:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:28:45 --> Config Class Initialized
INFO - 2020-09-10 17:28:45 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:28:45 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:28:45 --> Utf8 Class Initialized
INFO - 2020-09-10 17:28:45 --> URI Class Initialized
INFO - 2020-09-10 17:28:45 --> Router Class Initialized
INFO - 2020-09-10 17:28:45 --> Output Class Initialized
INFO - 2020-09-10 17:28:45 --> Security Class Initialized
DEBUG - 2020-09-10 17:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:28:45 --> Input Class Initialized
INFO - 2020-09-10 17:28:45 --> Language Class Initialized
INFO - 2020-09-10 17:28:45 --> Loader Class Initialized
INFO - 2020-09-10 17:28:45 --> Helper loaded: url_helper
INFO - 2020-09-10 17:28:45 --> Database Driver Class Initialized
INFO - 2020-09-10 17:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:28:45 --> Email Class Initialized
INFO - 2020-09-10 17:28:45 --> Controller Class Initialized
INFO - 2020-09-10 17:28:45 --> Model Class Initialized
INFO - 2020-09-10 17:28:45 --> Model Class Initialized
INFO - 2020-09-10 17:28:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:28:45 --> Final output sent to browser
DEBUG - 2020-09-10 17:28:45 --> Total execution time: 0.0374
ERROR - 2020-09-10 17:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:28:46 --> Config Class Initialized
INFO - 2020-09-10 17:28:46 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:28:46 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:28:46 --> Utf8 Class Initialized
INFO - 2020-09-10 17:28:46 --> URI Class Initialized
INFO - 2020-09-10 17:28:46 --> Router Class Initialized
INFO - 2020-09-10 17:28:46 --> Output Class Initialized
INFO - 2020-09-10 17:28:46 --> Security Class Initialized
DEBUG - 2020-09-10 17:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:28:46 --> Input Class Initialized
INFO - 2020-09-10 17:28:46 --> Language Class Initialized
INFO - 2020-09-10 17:28:46 --> Loader Class Initialized
INFO - 2020-09-10 17:28:46 --> Helper loaded: url_helper
INFO - 2020-09-10 17:28:46 --> Database Driver Class Initialized
INFO - 2020-09-10 17:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:28:46 --> Email Class Initialized
INFO - 2020-09-10 17:28:46 --> Controller Class Initialized
INFO - 2020-09-10 17:28:46 --> Model Class Initialized
INFO - 2020-09-10 17:28:46 --> Model Class Initialized
INFO - 2020-09-10 17:28:46 --> Final output sent to browser
DEBUG - 2020-09-10 17:28:46 --> Total execution time: 0.0351
ERROR - 2020-09-10 17:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:28:54 --> Config Class Initialized
INFO - 2020-09-10 17:28:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:28:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:28:54 --> Utf8 Class Initialized
INFO - 2020-09-10 17:28:54 --> URI Class Initialized
INFO - 2020-09-10 17:28:54 --> Router Class Initialized
INFO - 2020-09-10 17:28:54 --> Output Class Initialized
INFO - 2020-09-10 17:28:54 --> Security Class Initialized
DEBUG - 2020-09-10 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:28:54 --> Input Class Initialized
INFO - 2020-09-10 17:28:54 --> Language Class Initialized
INFO - 2020-09-10 17:28:54 --> Loader Class Initialized
INFO - 2020-09-10 17:28:54 --> Helper loaded: url_helper
INFO - 2020-09-10 17:28:54 --> Database Driver Class Initialized
INFO - 2020-09-10 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:28:54 --> Email Class Initialized
INFO - 2020-09-10 17:28:54 --> Controller Class Initialized
INFO - 2020-09-10 17:28:54 --> Model Class Initialized
INFO - 2020-09-10 17:28:54 --> Model Class Initialized
INFO - 2020-09-10 17:28:54 --> Final output sent to browser
DEBUG - 2020-09-10 17:28:54 --> Total execution time: 0.1181
ERROR - 2020-09-10 17:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:28:54 --> Config Class Initialized
INFO - 2020-09-10 17:28:54 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:28:54 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:28:54 --> Utf8 Class Initialized
INFO - 2020-09-10 17:28:54 --> URI Class Initialized
INFO - 2020-09-10 17:28:54 --> Router Class Initialized
INFO - 2020-09-10 17:28:54 --> Output Class Initialized
INFO - 2020-09-10 17:28:54 --> Security Class Initialized
DEBUG - 2020-09-10 17:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:28:54 --> Input Class Initialized
INFO - 2020-09-10 17:28:54 --> Language Class Initialized
INFO - 2020-09-10 17:28:54 --> Loader Class Initialized
INFO - 2020-09-10 17:28:54 --> Helper loaded: url_helper
INFO - 2020-09-10 17:28:54 --> Database Driver Class Initialized
INFO - 2020-09-10 17:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:28:54 --> Email Class Initialized
INFO - 2020-09-10 17:28:54 --> Controller Class Initialized
INFO - 2020-09-10 17:28:54 --> Model Class Initialized
INFO - 2020-09-10 17:28:54 --> Model Class Initialized
INFO - 2020-09-10 17:28:54 --> Final output sent to browser
DEBUG - 2020-09-10 17:28:54 --> Total execution time: 0.0416
ERROR - 2020-09-10 17:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:32:15 --> Config Class Initialized
INFO - 2020-09-10 17:32:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:32:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:32:15 --> Utf8 Class Initialized
INFO - 2020-09-10 17:32:15 --> URI Class Initialized
INFO - 2020-09-10 17:32:15 --> Router Class Initialized
INFO - 2020-09-10 17:32:15 --> Output Class Initialized
INFO - 2020-09-10 17:32:15 --> Security Class Initialized
DEBUG - 2020-09-10 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:32:15 --> Input Class Initialized
INFO - 2020-09-10 17:32:15 --> Language Class Initialized
INFO - 2020-09-10 17:32:15 --> Loader Class Initialized
INFO - 2020-09-10 17:32:15 --> Helper loaded: url_helper
INFO - 2020-09-10 17:32:15 --> Database Driver Class Initialized
INFO - 2020-09-10 17:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:32:15 --> Email Class Initialized
INFO - 2020-09-10 17:32:15 --> Controller Class Initialized
INFO - 2020-09-10 17:32:15 --> Model Class Initialized
INFO - 2020-09-10 17:32:15 --> Model Class Initialized
INFO - 2020-09-10 17:32:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:32:15 --> Final output sent to browser
DEBUG - 2020-09-10 17:32:15 --> Total execution time: 0.1009
ERROR - 2020-09-10 17:32:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:32:15 --> Config Class Initialized
INFO - 2020-09-10 17:32:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:32:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:32:15 --> Utf8 Class Initialized
INFO - 2020-09-10 17:32:15 --> URI Class Initialized
INFO - 2020-09-10 17:32:15 --> Router Class Initialized
INFO - 2020-09-10 17:32:15 --> Output Class Initialized
INFO - 2020-09-10 17:32:15 --> Security Class Initialized
DEBUG - 2020-09-10 17:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:32:15 --> Input Class Initialized
INFO - 2020-09-10 17:32:15 --> Language Class Initialized
INFO - 2020-09-10 17:32:15 --> Loader Class Initialized
INFO - 2020-09-10 17:32:15 --> Helper loaded: url_helper
INFO - 2020-09-10 17:32:15 --> Database Driver Class Initialized
INFO - 2020-09-10 17:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:32:15 --> Email Class Initialized
INFO - 2020-09-10 17:32:15 --> Controller Class Initialized
INFO - 2020-09-10 17:32:15 --> Model Class Initialized
INFO - 2020-09-10 17:32:15 --> Model Class Initialized
INFO - 2020-09-10 17:32:15 --> Final output sent to browser
DEBUG - 2020-09-10 17:32:15 --> Total execution time: 0.0385
ERROR - 2020-09-10 17:43:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:43:15 --> Config Class Initialized
INFO - 2020-09-10 17:43:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:43:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:43:15 --> Utf8 Class Initialized
INFO - 2020-09-10 17:43:15 --> URI Class Initialized
INFO - 2020-09-10 17:43:15 --> Router Class Initialized
INFO - 2020-09-10 17:43:15 --> Output Class Initialized
INFO - 2020-09-10 17:43:15 --> Security Class Initialized
DEBUG - 2020-09-10 17:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:43:15 --> Input Class Initialized
INFO - 2020-09-10 17:43:15 --> Language Class Initialized
INFO - 2020-09-10 17:43:15 --> Loader Class Initialized
INFO - 2020-09-10 17:43:15 --> Helper loaded: url_helper
INFO - 2020-09-10 17:43:15 --> Database Driver Class Initialized
INFO - 2020-09-10 17:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:43:15 --> Email Class Initialized
INFO - 2020-09-10 17:43:15 --> Controller Class Initialized
DEBUG - 2020-09-10 17:43:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:43:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:43:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 17:43:15 --> Final output sent to browser
DEBUG - 2020-09-10 17:43:15 --> Total execution time: 0.0298
ERROR - 2020-09-10 17:49:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:49:57 --> Config Class Initialized
INFO - 2020-09-10 17:49:57 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:49:57 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:49:57 --> Utf8 Class Initialized
INFO - 2020-09-10 17:49:57 --> URI Class Initialized
INFO - 2020-09-10 17:49:57 --> Router Class Initialized
INFO - 2020-09-10 17:49:57 --> Output Class Initialized
INFO - 2020-09-10 17:49:57 --> Security Class Initialized
DEBUG - 2020-09-10 17:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:49:57 --> Input Class Initialized
INFO - 2020-09-10 17:49:57 --> Language Class Initialized
INFO - 2020-09-10 17:49:57 --> Loader Class Initialized
INFO - 2020-09-10 17:49:57 --> Helper loaded: url_helper
INFO - 2020-09-10 17:49:57 --> Database Driver Class Initialized
INFO - 2020-09-10 17:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:49:57 --> Email Class Initialized
INFO - 2020-09-10 17:49:57 --> Controller Class Initialized
DEBUG - 2020-09-10 17:49:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:49:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:49:57 --> Model Class Initialized
INFO - 2020-09-10 17:49:57 --> Model Class Initialized
INFO - 2020-09-10 17:49:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-10 17:49:57 --> Final output sent to browser
DEBUG - 2020-09-10 17:49:57 --> Total execution time: 0.0428
ERROR - 2020-09-10 17:50:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:12 --> Config Class Initialized
INFO - 2020-09-10 17:50:12 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:12 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:12 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:12 --> URI Class Initialized
INFO - 2020-09-10 17:50:12 --> Router Class Initialized
INFO - 2020-09-10 17:50:13 --> Output Class Initialized
INFO - 2020-09-10 17:50:13 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:13 --> Input Class Initialized
INFO - 2020-09-10 17:50:13 --> Language Class Initialized
INFO - 2020-09-10 17:50:13 --> Loader Class Initialized
INFO - 2020-09-10 17:50:13 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:13 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:13 --> Email Class Initialized
INFO - 2020-09-10 17:50:13 --> Controller Class Initialized
DEBUG - 2020-09-10 17:50:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:50:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:50:13 --> Model Class Initialized
INFO - 2020-09-10 17:50:13 --> Model Class Initialized
INFO - 2020-09-10 17:50:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:50:13 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:13 --> Total execution time: 0.0230
ERROR - 2020-09-10 17:50:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:15 --> Config Class Initialized
INFO - 2020-09-10 17:50:15 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:15 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:15 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:15 --> URI Class Initialized
INFO - 2020-09-10 17:50:15 --> Router Class Initialized
INFO - 2020-09-10 17:50:15 --> Output Class Initialized
INFO - 2020-09-10 17:50:15 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:15 --> Input Class Initialized
INFO - 2020-09-10 17:50:15 --> Language Class Initialized
INFO - 2020-09-10 17:50:15 --> Loader Class Initialized
INFO - 2020-09-10 17:50:15 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:15 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:16 --> Email Class Initialized
INFO - 2020-09-10 17:50:16 --> Controller Class Initialized
DEBUG - 2020-09-10 17:50:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:50:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:50:16 --> Model Class Initialized
INFO - 2020-09-10 17:50:16 --> Model Class Initialized
INFO - 2020-09-10 17:50:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-09-10 17:50:16 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:16 --> Total execution time: 0.0228
ERROR - 2020-09-10 17:50:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:19 --> Config Class Initialized
INFO - 2020-09-10 17:50:19 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:19 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:19 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:19 --> URI Class Initialized
INFO - 2020-09-10 17:50:19 --> Router Class Initialized
INFO - 2020-09-10 17:50:19 --> Output Class Initialized
INFO - 2020-09-10 17:50:19 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:19 --> Input Class Initialized
INFO - 2020-09-10 17:50:19 --> Language Class Initialized
INFO - 2020-09-10 17:50:19 --> Loader Class Initialized
INFO - 2020-09-10 17:50:19 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:19 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:19 --> Email Class Initialized
INFO - 2020-09-10 17:50:19 --> Controller Class Initialized
DEBUG - 2020-09-10 17:50:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:50:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:50:19 --> Model Class Initialized
INFO - 2020-09-10 17:50:19 --> Model Class Initialized
INFO - 2020-09-10 17:50:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:50:19 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:19 --> Total execution time: 0.0223
ERROR - 2020-09-10 17:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:21 --> Config Class Initialized
INFO - 2020-09-10 17:50:21 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:21 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:21 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:21 --> URI Class Initialized
INFO - 2020-09-10 17:50:21 --> Router Class Initialized
INFO - 2020-09-10 17:50:21 --> Output Class Initialized
INFO - 2020-09-10 17:50:21 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:21 --> Input Class Initialized
INFO - 2020-09-10 17:50:21 --> Language Class Initialized
INFO - 2020-09-10 17:50:21 --> Loader Class Initialized
INFO - 2020-09-10 17:50:21 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:21 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:21 --> Email Class Initialized
INFO - 2020-09-10 17:50:21 --> Controller Class Initialized
DEBUG - 2020-09-10 17:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:50:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:50:21 --> Model Class Initialized
INFO - 2020-09-10 17:50:21 --> Model Class Initialized
INFO - 2020-09-10 17:50:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-10 17:50:21 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:21 --> Total execution time: 0.0367
ERROR - 2020-09-10 17:50:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:24 --> Config Class Initialized
INFO - 2020-09-10 17:50:24 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:24 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:24 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:24 --> URI Class Initialized
INFO - 2020-09-10 17:50:24 --> Router Class Initialized
INFO - 2020-09-10 17:50:24 --> Output Class Initialized
INFO - 2020-09-10 17:50:24 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:24 --> Input Class Initialized
INFO - 2020-09-10 17:50:24 --> Language Class Initialized
INFO - 2020-09-10 17:50:24 --> Loader Class Initialized
INFO - 2020-09-10 17:50:24 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:24 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:24 --> Email Class Initialized
INFO - 2020-09-10 17:50:24 --> Controller Class Initialized
DEBUG - 2020-09-10 17:50:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-10 17:50:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:50:24 --> Model Class Initialized
INFO - 2020-09-10 17:50:24 --> Model Class Initialized
INFO - 2020-09-10 17:50:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-10 17:50:24 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:24 --> Total execution time: 0.0305
ERROR - 2020-09-10 17:50:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:58 --> Config Class Initialized
INFO - 2020-09-10 17:50:58 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:58 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:58 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:58 --> URI Class Initialized
INFO - 2020-09-10 17:50:58 --> Router Class Initialized
INFO - 2020-09-10 17:50:58 --> Output Class Initialized
INFO - 2020-09-10 17:50:58 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:58 --> Input Class Initialized
INFO - 2020-09-10 17:50:58 --> Language Class Initialized
INFO - 2020-09-10 17:50:58 --> Loader Class Initialized
INFO - 2020-09-10 17:50:58 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:58 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:58 --> Email Class Initialized
INFO - 2020-09-10 17:50:58 --> Controller Class Initialized
INFO - 2020-09-10 17:50:58 --> Model Class Initialized
INFO - 2020-09-10 17:50:58 --> Model Class Initialized
INFO - 2020-09-10 17:50:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-10 17:50:58 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:58 --> Total execution time: 0.0325
ERROR - 2020-09-10 17:50:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:50:59 --> Config Class Initialized
INFO - 2020-09-10 17:50:59 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:50:59 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:50:59 --> Utf8 Class Initialized
INFO - 2020-09-10 17:50:59 --> URI Class Initialized
INFO - 2020-09-10 17:50:59 --> Router Class Initialized
INFO - 2020-09-10 17:50:59 --> Output Class Initialized
INFO - 2020-09-10 17:50:59 --> Security Class Initialized
DEBUG - 2020-09-10 17:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:50:59 --> Input Class Initialized
INFO - 2020-09-10 17:50:59 --> Language Class Initialized
INFO - 2020-09-10 17:50:59 --> Loader Class Initialized
INFO - 2020-09-10 17:50:59 --> Helper loaded: url_helper
INFO - 2020-09-10 17:50:59 --> Database Driver Class Initialized
INFO - 2020-09-10 17:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:50:59 --> Email Class Initialized
INFO - 2020-09-10 17:50:59 --> Controller Class Initialized
INFO - 2020-09-10 17:50:59 --> Model Class Initialized
INFO - 2020-09-10 17:50:59 --> Model Class Initialized
INFO - 2020-09-10 17:50:59 --> Final output sent to browser
DEBUG - 2020-09-10 17:50:59 --> Total execution time: 0.0365
ERROR - 2020-09-10 17:53:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-10 17:53:29 --> Config Class Initialized
INFO - 2020-09-10 17:53:29 --> Hooks Class Initialized
DEBUG - 2020-09-10 17:53:29 --> UTF-8 Support Enabled
INFO - 2020-09-10 17:53:29 --> Utf8 Class Initialized
INFO - 2020-09-10 17:53:29 --> URI Class Initialized
DEBUG - 2020-09-10 17:53:29 --> No URI present. Default controller set.
INFO - 2020-09-10 17:53:29 --> Router Class Initialized
INFO - 2020-09-10 17:53:29 --> Output Class Initialized
INFO - 2020-09-10 17:53:29 --> Security Class Initialized
DEBUG - 2020-09-10 17:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-10 17:53:29 --> Input Class Initialized
INFO - 2020-09-10 17:53:29 --> Language Class Initialized
INFO - 2020-09-10 17:53:29 --> Loader Class Initialized
INFO - 2020-09-10 17:53:29 --> Helper loaded: url_helper
INFO - 2020-09-10 17:53:29 --> Database Driver Class Initialized
INFO - 2020-09-10 17:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-10 17:53:29 --> Email Class Initialized
INFO - 2020-09-10 17:53:29 --> Controller Class Initialized
INFO - 2020-09-10 17:53:29 --> Model Class Initialized
INFO - 2020-09-10 17:53:29 --> Model Class Initialized
DEBUG - 2020-09-10 17:53:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-10 17:53:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-10 17:53:29 --> Final output sent to browser
DEBUG - 2020-09-10 17:53:29 --> Total execution time: 0.0195
