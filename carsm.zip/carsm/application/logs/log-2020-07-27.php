<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-07-27 16:56:26 --> Config Class Initialized
INFO - 2020-07-27 16:56:26 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:56:26 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:56:26 --> Utf8 Class Initialized
INFO - 2020-07-27 16:56:26 --> URI Class Initialized
DEBUG - 2020-07-27 16:56:26 --> No URI present. Default controller set.
INFO - 2020-07-27 16:56:26 --> Router Class Initialized
INFO - 2020-07-27 16:56:26 --> Output Class Initialized
INFO - 2020-07-27 16:56:26 --> Security Class Initialized
DEBUG - 2020-07-27 16:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:56:26 --> Input Class Initialized
INFO - 2020-07-27 16:56:26 --> Language Class Initialized
INFO - 2020-07-27 16:56:26 --> Loader Class Initialized
INFO - 2020-07-27 16:56:26 --> Helper loaded: url_helper
INFO - 2020-07-27 16:56:26 --> Helper loaded: file_helper
INFO - 2020-07-27 16:56:26 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:56:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:56:26 --> Unable to connect to the database
INFO - 2020-07-27 16:56:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 16:57:19 --> Config Class Initialized
INFO - 2020-07-27 16:57:19 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:57:19 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:57:19 --> Utf8 Class Initialized
INFO - 2020-07-27 16:57:19 --> URI Class Initialized
DEBUG - 2020-07-27 16:57:19 --> No URI present. Default controller set.
INFO - 2020-07-27 16:57:19 --> Router Class Initialized
INFO - 2020-07-27 16:57:19 --> Output Class Initialized
INFO - 2020-07-27 16:57:19 --> Security Class Initialized
DEBUG - 2020-07-27 16:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:57:19 --> Input Class Initialized
INFO - 2020-07-27 16:57:19 --> Language Class Initialized
INFO - 2020-07-27 16:57:19 --> Loader Class Initialized
INFO - 2020-07-27 16:57:19 --> Helper loaded: url_helper
INFO - 2020-07-27 16:57:19 --> Helper loaded: file_helper
INFO - 2020-07-27 16:57:19 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:57:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:57:19 --> Unable to connect to the database
INFO - 2020-07-27 16:57:19 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:57:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 16:57:24 --> Config Class Initialized
INFO - 2020-07-27 16:57:24 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:57:24 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:57:24 --> Utf8 Class Initialized
INFO - 2020-07-27 16:57:24 --> URI Class Initialized
DEBUG - 2020-07-27 16:57:24 --> No URI present. Default controller set.
INFO - 2020-07-27 16:57:24 --> Router Class Initialized
INFO - 2020-07-27 16:57:24 --> Output Class Initialized
INFO - 2020-07-27 16:57:24 --> Security Class Initialized
DEBUG - 2020-07-27 16:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:57:24 --> Input Class Initialized
INFO - 2020-07-27 16:57:24 --> Language Class Initialized
INFO - 2020-07-27 16:57:24 --> Loader Class Initialized
INFO - 2020-07-27 16:57:24 --> Helper loaded: url_helper
INFO - 2020-07-27 16:57:24 --> Helper loaded: file_helper
INFO - 2020-07-27 16:57:24 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:57:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:57:24 --> Unable to connect to the database
INFO - 2020-07-27 16:57:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:57:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 16:57:27 --> Config Class Initialized
INFO - 2020-07-27 16:57:27 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:57:27 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:57:27 --> Utf8 Class Initialized
INFO - 2020-07-27 16:57:27 --> URI Class Initialized
DEBUG - 2020-07-27 16:57:27 --> No URI present. Default controller set.
INFO - 2020-07-27 16:57:27 --> Router Class Initialized
INFO - 2020-07-27 16:57:27 --> Output Class Initialized
INFO - 2020-07-27 16:57:27 --> Security Class Initialized
DEBUG - 2020-07-27 16:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:57:27 --> Input Class Initialized
INFO - 2020-07-27 16:57:27 --> Language Class Initialized
INFO - 2020-07-27 16:57:27 --> Loader Class Initialized
INFO - 2020-07-27 16:57:27 --> Helper loaded: url_helper
INFO - 2020-07-27 16:57:27 --> Helper loaded: file_helper
INFO - 2020-07-27 16:57:27 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:57:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:57:27 --> Unable to connect to the database
INFO - 2020-07-27 16:57:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:57:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 16:57:28 --> Config Class Initialized
INFO - 2020-07-27 16:57:28 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:57:28 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:57:28 --> Utf8 Class Initialized
INFO - 2020-07-27 16:57:28 --> URI Class Initialized
DEBUG - 2020-07-27 16:57:28 --> No URI present. Default controller set.
INFO - 2020-07-27 16:57:28 --> Router Class Initialized
INFO - 2020-07-27 16:57:28 --> Output Class Initialized
INFO - 2020-07-27 16:57:28 --> Security Class Initialized
DEBUG - 2020-07-27 16:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:57:28 --> Input Class Initialized
INFO - 2020-07-27 16:57:28 --> Language Class Initialized
INFO - 2020-07-27 16:57:28 --> Loader Class Initialized
INFO - 2020-07-27 16:57:28 --> Helper loaded: url_helper
INFO - 2020-07-27 16:57:28 --> Helper loaded: file_helper
INFO - 2020-07-27 16:57:28 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:57:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:57:28 --> Unable to connect to the database
INFO - 2020-07-27 16:57:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:57:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 16:57:29 --> Config Class Initialized
INFO - 2020-07-27 16:57:29 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:57:29 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:57:29 --> Utf8 Class Initialized
INFO - 2020-07-27 16:57:29 --> URI Class Initialized
DEBUG - 2020-07-27 16:57:29 --> No URI present. Default controller set.
INFO - 2020-07-27 16:57:29 --> Router Class Initialized
INFO - 2020-07-27 16:57:29 --> Output Class Initialized
INFO - 2020-07-27 16:57:29 --> Security Class Initialized
DEBUG - 2020-07-27 16:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:57:29 --> Input Class Initialized
INFO - 2020-07-27 16:57:29 --> Language Class Initialized
INFO - 2020-07-27 16:57:29 --> Loader Class Initialized
INFO - 2020-07-27 16:57:29 --> Helper loaded: url_helper
INFO - 2020-07-27 16:57:29 --> Helper loaded: file_helper
INFO - 2020-07-27 16:57:29 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:57:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:57:29 --> Unable to connect to the database
INFO - 2020-07-27 16:57:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:57:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 16:58:04 --> Config Class Initialized
INFO - 2020-07-27 16:58:04 --> Hooks Class Initialized
DEBUG - 2020-07-27 16:58:04 --> UTF-8 Support Enabled
INFO - 2020-07-27 16:58:04 --> Utf8 Class Initialized
INFO - 2020-07-27 16:58:04 --> URI Class Initialized
DEBUG - 2020-07-27 16:58:04 --> No URI present. Default controller set.
INFO - 2020-07-27 16:58:04 --> Router Class Initialized
INFO - 2020-07-27 16:58:04 --> Output Class Initialized
INFO - 2020-07-27 16:58:04 --> Security Class Initialized
DEBUG - 2020-07-27 16:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 16:58:04 --> Input Class Initialized
INFO - 2020-07-27 16:58:04 --> Language Class Initialized
INFO - 2020-07-27 16:58:04 --> Loader Class Initialized
INFO - 2020-07-27 16:58:04 --> Helper loaded: url_helper
INFO - 2020-07-27 16:58:04 --> Helper loaded: file_helper
INFO - 2020-07-27 16:58:04 --> Database Driver Class Initialized
ERROR - 2020-07-27 16:58:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 16:58:04 --> Unable to connect to the database
INFO - 2020-07-27 16:58:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 16:58:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:09:29 --> Config Class Initialized
INFO - 2020-07-27 17:09:29 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:09:29 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:09:29 --> Utf8 Class Initialized
INFO - 2020-07-27 17:09:29 --> URI Class Initialized
DEBUG - 2020-07-27 17:09:29 --> No URI present. Default controller set.
INFO - 2020-07-27 17:09:29 --> Router Class Initialized
INFO - 2020-07-27 17:09:29 --> Output Class Initialized
INFO - 2020-07-27 17:09:29 --> Security Class Initialized
DEBUG - 2020-07-27 17:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:09:29 --> Input Class Initialized
INFO - 2020-07-27 17:09:29 --> Language Class Initialized
INFO - 2020-07-27 17:09:29 --> Loader Class Initialized
INFO - 2020-07-27 17:09:29 --> Helper loaded: url_helper
INFO - 2020-07-27 17:09:29 --> Helper loaded: file_helper
INFO - 2020-07-27 17:09:29 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:09:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:09:29 --> Unable to connect to the database
INFO - 2020-07-27 17:09:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:09:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:09:31 --> Config Class Initialized
INFO - 2020-07-27 17:09:31 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:09:31 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:09:31 --> Utf8 Class Initialized
INFO - 2020-07-27 17:09:31 --> URI Class Initialized
DEBUG - 2020-07-27 17:09:31 --> No URI present. Default controller set.
INFO - 2020-07-27 17:09:31 --> Router Class Initialized
INFO - 2020-07-27 17:09:31 --> Output Class Initialized
INFO - 2020-07-27 17:09:31 --> Security Class Initialized
DEBUG - 2020-07-27 17:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:09:31 --> Input Class Initialized
INFO - 2020-07-27 17:09:31 --> Language Class Initialized
INFO - 2020-07-27 17:09:31 --> Loader Class Initialized
INFO - 2020-07-27 17:09:31 --> Helper loaded: url_helper
INFO - 2020-07-27 17:09:31 --> Helper loaded: file_helper
INFO - 2020-07-27 17:09:31 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:09:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:09:31 --> Unable to connect to the database
INFO - 2020-07-27 17:09:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:09:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:14:50 --> Config Class Initialized
INFO - 2020-07-27 17:14:50 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:14:50 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:14:50 --> Utf8 Class Initialized
INFO - 2020-07-27 17:14:50 --> URI Class Initialized
DEBUG - 2020-07-27 17:14:50 --> No URI present. Default controller set.
INFO - 2020-07-27 17:14:50 --> Router Class Initialized
INFO - 2020-07-27 17:14:50 --> Output Class Initialized
INFO - 2020-07-27 17:14:50 --> Security Class Initialized
DEBUG - 2020-07-27 17:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:14:50 --> Input Class Initialized
INFO - 2020-07-27 17:14:50 --> Language Class Initialized
INFO - 2020-07-27 17:14:50 --> Loader Class Initialized
INFO - 2020-07-27 17:14:50 --> Helper loaded: url_helper
INFO - 2020-07-27 17:14:50 --> Helper loaded: file_helper
INFO - 2020-07-27 17:14:50 --> Controller Class Initialized
INFO - 2020-07-27 17:14:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 17:14:50 --> Final output sent to browser
DEBUG - 2020-07-27 17:14:50 --> Total execution time: 0.0123
INFO - 2020-07-27 17:14:53 --> Config Class Initialized
INFO - 2020-07-27 17:14:53 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:14:53 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:14:53 --> Utf8 Class Initialized
INFO - 2020-07-27 17:14:53 --> URI Class Initialized
INFO - 2020-07-27 17:14:53 --> Router Class Initialized
INFO - 2020-07-27 17:14:53 --> Output Class Initialized
INFO - 2020-07-27 17:14:53 --> Security Class Initialized
DEBUG - 2020-07-27 17:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:14:53 --> Input Class Initialized
INFO - 2020-07-27 17:14:53 --> Language Class Initialized
INFO - 2020-07-27 17:14:53 --> Loader Class Initialized
INFO - 2020-07-27 17:14:53 --> Helper loaded: url_helper
INFO - 2020-07-27 17:14:53 --> Helper loaded: file_helper
INFO - 2020-07-27 17:14:53 --> Controller Class Initialized
INFO - 2020-07-27 17:14:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 17:14:53 --> Final output sent to browser
DEBUG - 2020-07-27 17:14:53 --> Total execution time: 0.0109
INFO - 2020-07-27 17:15:39 --> Config Class Initialized
INFO - 2020-07-27 17:15:39 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:15:39 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:15:39 --> Utf8 Class Initialized
INFO - 2020-07-27 17:15:39 --> URI Class Initialized
INFO - 2020-07-27 17:15:39 --> Router Class Initialized
INFO - 2020-07-27 17:15:39 --> Output Class Initialized
INFO - 2020-07-27 17:15:39 --> Security Class Initialized
DEBUG - 2020-07-27 17:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:15:39 --> Input Class Initialized
INFO - 2020-07-27 17:15:39 --> Language Class Initialized
INFO - 2020-07-27 17:15:39 --> Loader Class Initialized
INFO - 2020-07-27 17:15:39 --> Helper loaded: url_helper
INFO - 2020-07-27 17:15:39 --> Helper loaded: file_helper
INFO - 2020-07-27 17:15:39 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:15:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:15:39 --> Unable to connect to the database
INFO - 2020-07-27 17:15:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:15:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:16:25 --> Config Class Initialized
INFO - 2020-07-27 17:16:25 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:16:25 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:16:25 --> Utf8 Class Initialized
INFO - 2020-07-27 17:16:25 --> URI Class Initialized
INFO - 2020-07-27 17:16:25 --> Router Class Initialized
INFO - 2020-07-27 17:16:25 --> Output Class Initialized
INFO - 2020-07-27 17:16:25 --> Security Class Initialized
DEBUG - 2020-07-27 17:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:16:25 --> Input Class Initialized
INFO - 2020-07-27 17:16:25 --> Language Class Initialized
INFO - 2020-07-27 17:16:25 --> Loader Class Initialized
INFO - 2020-07-27 17:16:25 --> Helper loaded: url_helper
INFO - 2020-07-27 17:16:25 --> Helper loaded: file_helper
INFO - 2020-07-27 17:16:25 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:16:25 --> Severity: Warning --> mysqli::real_connect(): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:16:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): php_network_getaddresses: getaddrinfo failed: Name or service not known /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:16:25 --> Unable to connect to the database
INFO - 2020-07-27 17:16:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:16:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:16:58 --> Config Class Initialized
INFO - 2020-07-27 17:16:58 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:16:58 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:16:58 --> Utf8 Class Initialized
INFO - 2020-07-27 17:16:58 --> URI Class Initialized
INFO - 2020-07-27 17:16:58 --> Router Class Initialized
INFO - 2020-07-27 17:16:58 --> Output Class Initialized
INFO - 2020-07-27 17:16:58 --> Security Class Initialized
DEBUG - 2020-07-27 17:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:16:58 --> Input Class Initialized
INFO - 2020-07-27 17:16:58 --> Language Class Initialized
INFO - 2020-07-27 17:16:58 --> Loader Class Initialized
INFO - 2020-07-27 17:16:58 --> Helper loaded: url_helper
INFO - 2020-07-27 17:16:58 --> Helper loaded: file_helper
INFO - 2020-07-27 17:16:58 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:16:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:16:58 --> Unable to connect to the database
INFO - 2020-07-27 17:16:58 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:16:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:18:27 --> Config Class Initialized
INFO - 2020-07-27 17:18:27 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:18:27 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:18:27 --> Utf8 Class Initialized
INFO - 2020-07-27 17:18:27 --> URI Class Initialized
DEBUG - 2020-07-27 17:18:27 --> No URI present. Default controller set.
INFO - 2020-07-27 17:18:27 --> Router Class Initialized
INFO - 2020-07-27 17:18:27 --> Output Class Initialized
INFO - 2020-07-27 17:18:27 --> Security Class Initialized
DEBUG - 2020-07-27 17:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:18:27 --> Input Class Initialized
INFO - 2020-07-27 17:18:27 --> Language Class Initialized
INFO - 2020-07-27 17:18:27 --> Loader Class Initialized
INFO - 2020-07-27 17:18:27 --> Helper loaded: url_helper
INFO - 2020-07-27 17:18:27 --> Helper loaded: file_helper
INFO - 2020-07-27 17:18:27 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:18:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:18:27 --> Unable to connect to the database
INFO - 2020-07-27 17:18:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:18:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:19:26 --> Config Class Initialized
INFO - 2020-07-27 17:19:26 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:19:26 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:19:26 --> Utf8 Class Initialized
INFO - 2020-07-27 17:19:26 --> URI Class Initialized
INFO - 2020-07-27 17:19:26 --> Router Class Initialized
INFO - 2020-07-27 17:19:26 --> Output Class Initialized
INFO - 2020-07-27 17:19:26 --> Security Class Initialized
DEBUG - 2020-07-27 17:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:19:26 --> Input Class Initialized
INFO - 2020-07-27 17:19:26 --> Language Class Initialized
INFO - 2020-07-27 17:19:26 --> Loader Class Initialized
INFO - 2020-07-27 17:19:26 --> Helper loaded: url_helper
INFO - 2020-07-27 17:19:26 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:19:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:19:26 --> Unable to connect to the database
INFO - 2020-07-27 17:19:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:19:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:22:56 --> Config Class Initialized
INFO - 2020-07-27 17:22:56 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:22:56 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:22:56 --> Utf8 Class Initialized
INFO - 2020-07-27 17:22:56 --> URI Class Initialized
INFO - 2020-07-27 17:22:56 --> Router Class Initialized
INFO - 2020-07-27 17:22:56 --> Output Class Initialized
INFO - 2020-07-27 17:22:56 --> Security Class Initialized
DEBUG - 2020-07-27 17:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:22:56 --> Input Class Initialized
INFO - 2020-07-27 17:22:56 --> Language Class Initialized
INFO - 2020-07-27 17:22:56 --> Loader Class Initialized
INFO - 2020-07-27 17:22:56 --> Helper loaded: url_helper
INFO - 2020-07-27 17:22:56 --> Helper loaded: file_helper
INFO - 2020-07-27 17:22:56 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:22:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:22:56 --> Unable to connect to the database
INFO - 2020-07-27 17:22:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:22:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:28:02 --> Config Class Initialized
INFO - 2020-07-27 17:28:02 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:28:02 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:28:02 --> Utf8 Class Initialized
INFO - 2020-07-27 17:28:02 --> URI Class Initialized
INFO - 2020-07-27 17:28:02 --> Router Class Initialized
INFO - 2020-07-27 17:28:02 --> Output Class Initialized
INFO - 2020-07-27 17:28:02 --> Security Class Initialized
DEBUG - 2020-07-27 17:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:28:02 --> Input Class Initialized
INFO - 2020-07-27 17:28:02 --> Language Class Initialized
INFO - 2020-07-27 17:28:02 --> Loader Class Initialized
INFO - 2020-07-27 17:28:02 --> Helper loaded: url_helper
INFO - 2020-07-27 17:28:02 --> Helper loaded: file_helper
INFO - 2020-07-27 17:28:02 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:28:02 --> Severity: Warning --> mysql_connect(): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2020-07-27 17:28:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2020-07-27 17:28:02 --> Unable to select database: purpu1ex_carsm
INFO - 2020-07-27 17:28:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:28:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:28:42 --> Config Class Initialized
INFO - 2020-07-27 17:28:42 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:28:42 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:28:42 --> Utf8 Class Initialized
INFO - 2020-07-27 17:28:42 --> URI Class Initialized
INFO - 2020-07-27 17:28:42 --> Router Class Initialized
INFO - 2020-07-27 17:28:42 --> Output Class Initialized
INFO - 2020-07-27 17:28:42 --> Security Class Initialized
DEBUG - 2020-07-27 17:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:28:42 --> Input Class Initialized
INFO - 2020-07-27 17:28:42 --> Language Class Initialized
INFO - 2020-07-27 17:28:42 --> Loader Class Initialized
INFO - 2020-07-27 17:28:42 --> Helper loaded: url_helper
INFO - 2020-07-27 17:28:42 --> Helper loaded: file_helper
INFO - 2020-07-27 17:28:42 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:28:42 --> Severity: Warning --> mysql_connect(): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2020-07-27 17:28:42 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2020-07-27 17:28:42 --> Unable to select database: purpu1ex_carsm
INFO - 2020-07-27 17:28:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:28:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:29:48 --> Config Class Initialized
INFO - 2020-07-27 17:29:48 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:29:48 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:29:48 --> Utf8 Class Initialized
INFO - 2020-07-27 17:29:48 --> URI Class Initialized
INFO - 2020-07-27 17:29:48 --> Router Class Initialized
INFO - 2020-07-27 17:29:48 --> Output Class Initialized
INFO - 2020-07-27 17:29:48 --> Security Class Initialized
DEBUG - 2020-07-27 17:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:29:48 --> Input Class Initialized
INFO - 2020-07-27 17:29:48 --> Language Class Initialized
INFO - 2020-07-27 17:29:48 --> Loader Class Initialized
INFO - 2020-07-27 17:29:48 --> Helper loaded: url_helper
INFO - 2020-07-27 17:29:48 --> Helper loaded: file_helper
INFO - 2020-07-27 17:29:48 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:29:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-07-27 17:29:48 --> Unable to connect to the database
INFO - 2020-07-27 17:29:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:29:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:30:41 --> Config Class Initialized
INFO - 2020-07-27 17:30:41 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:30:41 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:30:41 --> Utf8 Class Initialized
INFO - 2020-07-27 17:30:41 --> URI Class Initialized
INFO - 2020-07-27 17:30:41 --> Router Class Initialized
INFO - 2020-07-27 17:30:41 --> Output Class Initialized
INFO - 2020-07-27 17:30:41 --> Security Class Initialized
DEBUG - 2020-07-27 17:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:30:41 --> Input Class Initialized
INFO - 2020-07-27 17:30:41 --> Language Class Initialized
INFO - 2020-07-27 17:30:41 --> Loader Class Initialized
INFO - 2020-07-27 17:30:41 --> Helper loaded: url_helper
INFO - 2020-07-27 17:30:41 --> Helper loaded: file_helper
INFO - 2020-07-27 17:30:41 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:30:41 --> Severity: Warning --> mysql_connect(): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2020-07-27 17:30:41 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2020-07-27 17:30:41 --> Unable to select database: purpu1ex_carsm
INFO - 2020-07-27 17:30:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:30:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:30:44 --> Config Class Initialized
INFO - 2020-07-27 17:30:44 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:30:44 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:30:44 --> Utf8 Class Initialized
INFO - 2020-07-27 17:30:44 --> URI Class Initialized
INFO - 2020-07-27 17:30:44 --> Router Class Initialized
INFO - 2020-07-27 17:30:44 --> Output Class Initialized
INFO - 2020-07-27 17:30:44 --> Security Class Initialized
DEBUG - 2020-07-27 17:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:30:44 --> Input Class Initialized
INFO - 2020-07-27 17:30:44 --> Language Class Initialized
INFO - 2020-07-27 17:30:44 --> Loader Class Initialized
INFO - 2020-07-27 17:30:44 --> Helper loaded: url_helper
INFO - 2020-07-27 17:30:44 --> Helper loaded: file_helper
INFO - 2020-07-27 17:30:44 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:30:44 --> Severity: Warning --> mysql_connect(): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2020-07-27 17:30:44 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2020-07-27 17:30:44 --> Unable to select database: purpu1ex_carsm
INFO - 2020-07-27 17:30:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:30:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:30:48 --> Config Class Initialized
INFO - 2020-07-27 17:30:48 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:30:48 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:30:48 --> Utf8 Class Initialized
INFO - 2020-07-27 17:30:48 --> URI Class Initialized
INFO - 2020-07-27 17:30:48 --> Router Class Initialized
INFO - 2020-07-27 17:30:48 --> Output Class Initialized
INFO - 2020-07-27 17:30:48 --> Security Class Initialized
DEBUG - 2020-07-27 17:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:30:48 --> Input Class Initialized
INFO - 2020-07-27 17:30:48 --> Language Class Initialized
INFO - 2020-07-27 17:30:48 --> Loader Class Initialized
INFO - 2020-07-27 17:30:48 --> Helper loaded: url_helper
INFO - 2020-07-27 17:30:48 --> Helper loaded: file_helper
INFO - 2020-07-27 17:30:48 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:30:48 --> Severity: Warning --> mysql_connect(): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2020-07-27 17:30:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2020-07-27 17:30:48 --> Unable to select database: purpu1ex_carsm
INFO - 2020-07-27 17:30:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:30:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:31:02 --> Config Class Initialized
INFO - 2020-07-27 17:31:02 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:31:02 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:31:02 --> Utf8 Class Initialized
INFO - 2020-07-27 17:31:02 --> URI Class Initialized
DEBUG - 2020-07-27 17:31:02 --> No URI present. Default controller set.
INFO - 2020-07-27 17:31:02 --> Router Class Initialized
INFO - 2020-07-27 17:31:02 --> Output Class Initialized
INFO - 2020-07-27 17:31:02 --> Security Class Initialized
DEBUG - 2020-07-27 17:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:31:02 --> Input Class Initialized
INFO - 2020-07-27 17:31:02 --> Language Class Initialized
INFO - 2020-07-27 17:31:02 --> Loader Class Initialized
INFO - 2020-07-27 17:31:02 --> Helper loaded: url_helper
INFO - 2020-07-27 17:31:02 --> Helper loaded: file_helper
INFO - 2020-07-27 17:31:02 --> Database Driver Class Initialized
ERROR - 2020-07-27 17:31:02 --> Severity: Warning --> mysql_connect(): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2020-07-27 17:31:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /home/purpu1ex/public_html/carsm/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2020-07-27 17:31:02 --> Unable to select database: purpu1ex_carsm
INFO - 2020-07-27 17:31:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-07-27 17:31:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
INFO - 2020-07-27 17:31:24 --> Config Class Initialized
INFO - 2020-07-27 17:31:24 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:31:24 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:31:24 --> Utf8 Class Initialized
INFO - 2020-07-27 17:31:24 --> URI Class Initialized
DEBUG - 2020-07-27 17:31:24 --> No URI present. Default controller set.
INFO - 2020-07-27 17:31:24 --> Router Class Initialized
INFO - 2020-07-27 17:31:24 --> Output Class Initialized
INFO - 2020-07-27 17:31:24 --> Security Class Initialized
DEBUG - 2020-07-27 17:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:31:24 --> Input Class Initialized
INFO - 2020-07-27 17:31:24 --> Language Class Initialized
INFO - 2020-07-27 17:31:24 --> Loader Class Initialized
INFO - 2020-07-27 17:31:24 --> Helper loaded: url_helper
INFO - 2020-07-27 17:31:24 --> Helper loaded: file_helper
INFO - 2020-07-27 17:31:24 --> Controller Class Initialized
INFO - 2020-07-27 17:31:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 17:31:24 --> Final output sent to browser
DEBUG - 2020-07-27 17:31:24 --> Total execution time: 0.0113
INFO - 2020-07-27 17:31:26 --> Config Class Initialized
INFO - 2020-07-27 17:31:26 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:31:26 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:31:26 --> Utf8 Class Initialized
INFO - 2020-07-27 17:31:26 --> URI Class Initialized
INFO - 2020-07-27 17:31:26 --> Router Class Initialized
INFO - 2020-07-27 17:31:26 --> Output Class Initialized
INFO - 2020-07-27 17:31:26 --> Security Class Initialized
DEBUG - 2020-07-27 17:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:31:26 --> Input Class Initialized
INFO - 2020-07-27 17:31:26 --> Language Class Initialized
INFO - 2020-07-27 17:31:26 --> Loader Class Initialized
INFO - 2020-07-27 17:31:26 --> Helper loaded: url_helper
INFO - 2020-07-27 17:31:26 --> Helper loaded: file_helper
INFO - 2020-07-27 17:31:26 --> Controller Class Initialized
INFO - 2020-07-27 17:31:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 17:31:26 --> Final output sent to browser
DEBUG - 2020-07-27 17:31:26 --> Total execution time: 0.0109
INFO - 2020-07-27 17:51:04 --> Config Class Initialized
INFO - 2020-07-27 17:51:04 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:51:04 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:51:04 --> Utf8 Class Initialized
INFO - 2020-07-27 17:51:04 --> URI Class Initialized
INFO - 2020-07-27 17:51:04 --> Router Class Initialized
INFO - 2020-07-27 17:51:04 --> Output Class Initialized
INFO - 2020-07-27 17:51:04 --> Security Class Initialized
DEBUG - 2020-07-27 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:51:04 --> Input Class Initialized
INFO - 2020-07-27 17:51:04 --> Language Class Initialized
INFO - 2020-07-27 17:51:04 --> Loader Class Initialized
INFO - 2020-07-27 17:51:04 --> Helper loaded: url_helper
INFO - 2020-07-27 17:51:04 --> Helper loaded: file_helper
INFO - 2020-07-27 17:51:04 --> Controller Class Initialized
INFO - 2020-07-27 17:51:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 17:51:04 --> Final output sent to browser
DEBUG - 2020-07-27 17:51:04 --> Total execution time: 0.0135
INFO - 2020-07-27 17:51:49 --> Config Class Initialized
INFO - 2020-07-27 17:51:49 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:51:49 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:51:49 --> Utf8 Class Initialized
INFO - 2020-07-27 17:51:49 --> URI Class Initialized
INFO - 2020-07-27 17:51:49 --> Router Class Initialized
INFO - 2020-07-27 17:51:49 --> Output Class Initialized
INFO - 2020-07-27 17:51:49 --> Security Class Initialized
DEBUG - 2020-07-27 17:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:51:49 --> Input Class Initialized
INFO - 2020-07-27 17:51:49 --> Language Class Initialized
INFO - 2020-07-27 17:51:49 --> Loader Class Initialized
INFO - 2020-07-27 17:51:49 --> Helper loaded: url_helper
INFO - 2020-07-27 17:51:49 --> Helper loaded: file_helper
INFO - 2020-07-27 17:51:49 --> Database Driver Class Initialized
INFO - 2020-07-27 17:51:49 --> Controller Class Initialized
INFO - 2020-07-27 17:51:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 17:51:49 --> Final output sent to browser
DEBUG - 2020-07-27 17:51:49 --> Total execution time: 0.0166
INFO - 2020-07-27 17:51:54 --> Config Class Initialized
INFO - 2020-07-27 17:51:54 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:51:54 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:51:54 --> Utf8 Class Initialized
INFO - 2020-07-27 17:51:54 --> URI Class Initialized
DEBUG - 2020-07-27 17:51:54 --> No URI present. Default controller set.
INFO - 2020-07-27 17:51:54 --> Router Class Initialized
INFO - 2020-07-27 17:51:54 --> Output Class Initialized
INFO - 2020-07-27 17:51:54 --> Security Class Initialized
DEBUG - 2020-07-27 17:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:51:54 --> Input Class Initialized
INFO - 2020-07-27 17:51:54 --> Language Class Initialized
INFO - 2020-07-27 17:51:54 --> Loader Class Initialized
INFO - 2020-07-27 17:51:54 --> Helper loaded: url_helper
INFO - 2020-07-27 17:51:54 --> Helper loaded: file_helper
INFO - 2020-07-27 17:51:54 --> Database Driver Class Initialized
INFO - 2020-07-27 17:51:54 --> Controller Class Initialized
INFO - 2020-07-27 17:51:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 17:51:54 --> Final output sent to browser
DEBUG - 2020-07-27 17:51:54 --> Total execution time: 0.0176
INFO - 2020-07-27 17:51:56 --> Config Class Initialized
INFO - 2020-07-27 17:51:56 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:51:56 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:51:56 --> Utf8 Class Initialized
INFO - 2020-07-27 17:51:56 --> URI Class Initialized
INFO - 2020-07-27 17:51:56 --> Router Class Initialized
INFO - 2020-07-27 17:51:56 --> Output Class Initialized
INFO - 2020-07-27 17:51:56 --> Security Class Initialized
DEBUG - 2020-07-27 17:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:51:56 --> Input Class Initialized
INFO - 2020-07-27 17:51:56 --> Language Class Initialized
INFO - 2020-07-27 17:51:56 --> Loader Class Initialized
INFO - 2020-07-27 17:51:56 --> Helper loaded: url_helper
INFO - 2020-07-27 17:51:56 --> Helper loaded: file_helper
INFO - 2020-07-27 17:51:56 --> Database Driver Class Initialized
INFO - 2020-07-27 17:51:56 --> Controller Class Initialized
INFO - 2020-07-27 17:51:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 17:51:56 --> Final output sent to browser
DEBUG - 2020-07-27 17:51:56 --> Total execution time: 0.0169
INFO - 2020-07-27 17:53:43 --> Config Class Initialized
INFO - 2020-07-27 17:53:43 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:53:43 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:53:43 --> Utf8 Class Initialized
INFO - 2020-07-27 17:53:43 --> URI Class Initialized
DEBUG - 2020-07-27 17:53:43 --> No URI present. Default controller set.
INFO - 2020-07-27 17:53:43 --> Router Class Initialized
INFO - 2020-07-27 17:53:43 --> Output Class Initialized
INFO - 2020-07-27 17:53:43 --> Security Class Initialized
DEBUG - 2020-07-27 17:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:53:43 --> Input Class Initialized
INFO - 2020-07-27 17:53:43 --> Language Class Initialized
INFO - 2020-07-27 17:53:43 --> Loader Class Initialized
INFO - 2020-07-27 17:53:43 --> Helper loaded: url_helper
INFO - 2020-07-27 17:53:43 --> Helper loaded: file_helper
INFO - 2020-07-27 17:53:43 --> Database Driver Class Initialized
INFO - 2020-07-27 17:53:43 --> Controller Class Initialized
INFO - 2020-07-27 17:53:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 17:53:43 --> Final output sent to browser
DEBUG - 2020-07-27 17:53:43 --> Total execution time: 0.0166
INFO - 2020-07-27 17:53:45 --> Config Class Initialized
INFO - 2020-07-27 17:53:45 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:53:45 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:53:45 --> Utf8 Class Initialized
INFO - 2020-07-27 17:53:45 --> URI Class Initialized
DEBUG - 2020-07-27 17:53:45 --> No URI present. Default controller set.
INFO - 2020-07-27 17:53:45 --> Router Class Initialized
INFO - 2020-07-27 17:53:45 --> Output Class Initialized
INFO - 2020-07-27 17:53:45 --> Security Class Initialized
DEBUG - 2020-07-27 17:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:53:45 --> Input Class Initialized
INFO - 2020-07-27 17:53:45 --> Language Class Initialized
INFO - 2020-07-27 17:53:45 --> Loader Class Initialized
INFO - 2020-07-27 17:53:45 --> Helper loaded: url_helper
INFO - 2020-07-27 17:53:45 --> Helper loaded: file_helper
INFO - 2020-07-27 17:53:45 --> Database Driver Class Initialized
INFO - 2020-07-27 17:53:45 --> Controller Class Initialized
INFO - 2020-07-27 17:53:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 17:53:45 --> Final output sent to browser
DEBUG - 2020-07-27 17:53:45 --> Total execution time: 0.0160
INFO - 2020-07-27 17:53:46 --> Config Class Initialized
INFO - 2020-07-27 17:53:46 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:53:46 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:53:46 --> Utf8 Class Initialized
INFO - 2020-07-27 17:53:46 --> URI Class Initialized
INFO - 2020-07-27 17:53:46 --> Router Class Initialized
INFO - 2020-07-27 17:53:46 --> Output Class Initialized
INFO - 2020-07-27 17:53:46 --> Security Class Initialized
DEBUG - 2020-07-27 17:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:53:46 --> Input Class Initialized
INFO - 2020-07-27 17:53:46 --> Language Class Initialized
INFO - 2020-07-27 17:53:46 --> Loader Class Initialized
INFO - 2020-07-27 17:53:46 --> Helper loaded: url_helper
INFO - 2020-07-27 17:53:46 --> Helper loaded: file_helper
INFO - 2020-07-27 17:53:46 --> Database Driver Class Initialized
INFO - 2020-07-27 17:53:47 --> Controller Class Initialized
INFO - 2020-07-27 17:53:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 17:53:47 --> Final output sent to browser
DEBUG - 2020-07-27 17:53:47 --> Total execution time: 0.3839
INFO - 2020-07-27 17:53:50 --> Config Class Initialized
INFO - 2020-07-27 17:53:50 --> Hooks Class Initialized
DEBUG - 2020-07-27 17:53:50 --> UTF-8 Support Enabled
INFO - 2020-07-27 17:53:50 --> Utf8 Class Initialized
INFO - 2020-07-27 17:53:50 --> URI Class Initialized
INFO - 2020-07-27 17:53:50 --> Router Class Initialized
INFO - 2020-07-27 17:53:50 --> Output Class Initialized
INFO - 2020-07-27 17:53:50 --> Security Class Initialized
DEBUG - 2020-07-27 17:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 17:53:50 --> Input Class Initialized
INFO - 2020-07-27 17:53:50 --> Language Class Initialized
INFO - 2020-07-27 17:53:50 --> Loader Class Initialized
INFO - 2020-07-27 17:53:50 --> Helper loaded: url_helper
INFO - 2020-07-27 17:53:50 --> Helper loaded: file_helper
INFO - 2020-07-27 17:53:50 --> Database Driver Class Initialized
INFO - 2020-07-27 17:53:50 --> Controller Class Initialized
INFO - 2020-07-27 17:53:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-27 17:53:50 --> Final output sent to browser
DEBUG - 2020-07-27 17:53:50 --> Total execution time: 0.0161
INFO - 2020-07-27 18:05:25 --> Config Class Initialized
INFO - 2020-07-27 18:05:25 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:05:25 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:05:25 --> Utf8 Class Initialized
INFO - 2020-07-27 18:05:25 --> URI Class Initialized
DEBUG - 2020-07-27 18:05:25 --> No URI present. Default controller set.
INFO - 2020-07-27 18:05:25 --> Router Class Initialized
INFO - 2020-07-27 18:05:25 --> Output Class Initialized
INFO - 2020-07-27 18:05:25 --> Security Class Initialized
DEBUG - 2020-07-27 18:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:05:25 --> Input Class Initialized
INFO - 2020-07-27 18:05:25 --> Language Class Initialized
INFO - 2020-07-27 18:05:25 --> Loader Class Initialized
INFO - 2020-07-27 18:05:25 --> Helper loaded: url_helper
INFO - 2020-07-27 18:05:25 --> Helper loaded: file_helper
INFO - 2020-07-27 18:05:25 --> Database Driver Class Initialized
INFO - 2020-07-27 18:05:25 --> Controller Class Initialized
INFO - 2020-07-27 18:05:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 18:05:25 --> Final output sent to browser
DEBUG - 2020-07-27 18:05:25 --> Total execution time: 0.0175
INFO - 2020-07-27 18:05:32 --> Config Class Initialized
INFO - 2020-07-27 18:05:32 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:05:32 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:05:32 --> Utf8 Class Initialized
INFO - 2020-07-27 18:05:32 --> URI Class Initialized
INFO - 2020-07-27 18:05:32 --> Router Class Initialized
INFO - 2020-07-27 18:05:32 --> Output Class Initialized
INFO - 2020-07-27 18:05:32 --> Security Class Initialized
DEBUG - 2020-07-27 18:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:05:32 --> Input Class Initialized
INFO - 2020-07-27 18:05:32 --> Language Class Initialized
INFO - 2020-07-27 18:05:32 --> Loader Class Initialized
INFO - 2020-07-27 18:05:32 --> Helper loaded: url_helper
INFO - 2020-07-27 18:05:32 --> Helper loaded: file_helper
INFO - 2020-07-27 18:05:32 --> Database Driver Class Initialized
INFO - 2020-07-27 18:05:32 --> Controller Class Initialized
ERROR - 2020-07-27 18:05:32 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 35
ERROR - 2020-07-27 18:05:32 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 36
INFO - 2020-07-27 18:05:32 --> Model Class Initialized
INFO - 2020-07-27 18:05:32 --> Model Class Initialized
ERROR - 2020-07-27 18:05:32 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 50
ERROR - 2020-07-27 18:05:32 --> Severity: Notice --> Undefined property: Welcome::$session /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 104
ERROR - 2020-07-27 18:05:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-27 18:05:32 --> Severity: Error --> Call to a member function set_flashdata() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 104
INFO - 2020-07-27 18:06:24 --> Config Class Initialized
INFO - 2020-07-27 18:06:24 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:06:24 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:06:24 --> Utf8 Class Initialized
INFO - 2020-07-27 18:06:24 --> URI Class Initialized
INFO - 2020-07-27 18:06:24 --> Router Class Initialized
INFO - 2020-07-27 18:06:24 --> Output Class Initialized
INFO - 2020-07-27 18:06:24 --> Security Class Initialized
DEBUG - 2020-07-27 18:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:06:24 --> Input Class Initialized
INFO - 2020-07-27 18:06:24 --> Language Class Initialized
INFO - 2020-07-27 18:06:24 --> Loader Class Initialized
INFO - 2020-07-27 18:06:24 --> Helper loaded: url_helper
INFO - 2020-07-27 18:06:24 --> Helper loaded: file_helper
INFO - 2020-07-27 18:06:24 --> Database Driver Class Initialized
INFO - 2020-07-27 18:06:24 --> Controller Class Initialized
ERROR - 2020-07-27 18:06:24 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 35
ERROR - 2020-07-27 18:06:24 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 36
INFO - 2020-07-27 18:06:24 --> Model Class Initialized
INFO - 2020-07-27 18:06:24 --> Model Class Initialized
ERROR - 2020-07-27 18:06:24 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 50
ERROR - 2020-07-27 18:06:24 --> Severity: Notice --> Undefined property: Welcome::$session /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 104
ERROR - 2020-07-27 18:06:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-07-27 18:06:24 --> Severity: Error --> Call to a member function set_flashdata() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 104
INFO - 2020-07-27 18:08:04 --> Config Class Initialized
INFO - 2020-07-27 18:08:04 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:08:04 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:08:04 --> Utf8 Class Initialized
INFO - 2020-07-27 18:08:04 --> URI Class Initialized
INFO - 2020-07-27 18:08:04 --> Router Class Initialized
INFO - 2020-07-27 18:08:04 --> Output Class Initialized
INFO - 2020-07-27 18:08:04 --> Security Class Initialized
DEBUG - 2020-07-27 18:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:08:04 --> Input Class Initialized
INFO - 2020-07-27 18:08:04 --> Language Class Initialized
INFO - 2020-07-27 18:08:04 --> Loader Class Initialized
INFO - 2020-07-27 18:08:04 --> Helper loaded: url_helper
INFO - 2020-07-27 18:08:04 --> Helper loaded: file_helper
INFO - 2020-07-27 18:08:04 --> Database Driver Class Initialized
INFO - 2020-07-27 18:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:08:04 --> Controller Class Initialized
ERROR - 2020-07-27 18:08:04 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 32
ERROR - 2020-07-27 18:08:04 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 35
ERROR - 2020-07-27 18:08:04 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 36
INFO - 2020-07-27 18:08:04 --> Model Class Initialized
INFO - 2020-07-27 18:08:04 --> Model Class Initialized
ERROR - 2020-07-27 18:08:04 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 50
ERROR - 2020-07-27 18:08:04 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 105
ERROR - 2020-07-27 18:08:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-27 18:09:07 --> Config Class Initialized
INFO - 2020-07-27 18:09:07 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:09:07 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:09:07 --> Utf8 Class Initialized
INFO - 2020-07-27 18:09:07 --> URI Class Initialized
INFO - 2020-07-27 18:09:07 --> Router Class Initialized
INFO - 2020-07-27 18:09:07 --> Output Class Initialized
INFO - 2020-07-27 18:09:07 --> Security Class Initialized
DEBUG - 2020-07-27 18:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:09:07 --> Input Class Initialized
INFO - 2020-07-27 18:09:07 --> Language Class Initialized
INFO - 2020-07-27 18:09:07 --> Loader Class Initialized
INFO - 2020-07-27 18:09:07 --> Helper loaded: url_helper
INFO - 2020-07-27 18:09:07 --> Helper loaded: file_helper
INFO - 2020-07-27 18:09:07 --> Database Driver Class Initialized
INFO - 2020-07-27 18:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:09:07 --> Controller Class Initialized
INFO - 2020-07-27 18:09:07 --> Model Class Initialized
INFO - 2020-07-27 18:09:07 --> Model Class Initialized
DEBUG - 2020-07-27 18:09:07 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-27 18:09:07 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 24
ERROR - 2020-07-27 18:09:07 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-27 18:09:07 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 28
ERROR - 2020-07-27 18:09:07 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 42
ERROR - 2020-07-27 18:09:07 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 97
ERROR - 2020-07-27 18:09:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-27 18:13:27 --> Config Class Initialized
INFO - 2020-07-27 18:13:27 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:13:27 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:13:27 --> Utf8 Class Initialized
INFO - 2020-07-27 18:13:27 --> URI Class Initialized
INFO - 2020-07-27 18:13:27 --> Router Class Initialized
INFO - 2020-07-27 18:13:27 --> Output Class Initialized
INFO - 2020-07-27 18:13:27 --> Security Class Initialized
DEBUG - 2020-07-27 18:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:13:27 --> Input Class Initialized
INFO - 2020-07-27 18:13:27 --> Language Class Initialized
INFO - 2020-07-27 18:13:27 --> Loader Class Initialized
INFO - 2020-07-27 18:13:27 --> Helper loaded: url_helper
INFO - 2020-07-27 18:13:27 --> Helper loaded: file_helper
INFO - 2020-07-27 18:13:27 --> Database Driver Class Initialized
INFO - 2020-07-27 18:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:13:27 --> Controller Class Initialized
INFO - 2020-07-27 18:13:27 --> Model Class Initialized
INFO - 2020-07-27 18:13:27 --> Model Class Initialized
DEBUG - 2020-07-27 18:13:27 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-27 18:13:27 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-27 18:13:27 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 28
ERROR - 2020-07-27 18:13:27 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 42
ERROR - 2020-07-27 18:13:27 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 97
ERROR - 2020-07-27 18:13:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-27 18:15:24 --> Config Class Initialized
INFO - 2020-07-27 18:15:24 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:15:24 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:15:24 --> Utf8 Class Initialized
INFO - 2020-07-27 18:15:24 --> URI Class Initialized
INFO - 2020-07-27 18:15:24 --> Router Class Initialized
INFO - 2020-07-27 18:15:24 --> Output Class Initialized
INFO - 2020-07-27 18:15:24 --> Security Class Initialized
DEBUG - 2020-07-27 18:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:15:24 --> Input Class Initialized
INFO - 2020-07-27 18:15:24 --> Language Class Initialized
INFO - 2020-07-27 18:15:24 --> Loader Class Initialized
INFO - 2020-07-27 18:15:24 --> Helper loaded: url_helper
INFO - 2020-07-27 18:15:24 --> Helper loaded: file_helper
INFO - 2020-07-27 18:15:24 --> Database Driver Class Initialized
INFO - 2020-07-27 18:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:15:24 --> Controller Class Initialized
INFO - 2020-07-27 18:15:24 --> Model Class Initialized
INFO - 2020-07-27 18:15:24 --> Model Class Initialized
DEBUG - 2020-07-27 18:15:24 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-07-27 18:15:24 --> Severity: Notice --> A session had already been started - ignoring session_start() /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 24
ERROR - 2020-07-27 18:15:24 --> Severity: Notice --> Undefined index: email /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 27
ERROR - 2020-07-27 18:15:24 --> Severity: Notice --> Undefined index: password /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 28
ERROR - 2020-07-27 18:15:24 --> Severity: Notice --> Undefined index: validity /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 42
ERROR - 2020-07-27 18:15:24 --> Severity: Notice --> Undefined variable: base_url /home/purpu1ex/public_html/carsm/application/controllers/Welcome.php 97
ERROR - 2020-07-27 18:15:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/helpers/url_helper.php 564
INFO - 2020-07-27 18:15:59 --> Config Class Initialized
INFO - 2020-07-27 18:15:59 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:15:59 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:15:59 --> Utf8 Class Initialized
INFO - 2020-07-27 18:15:59 --> URI Class Initialized
INFO - 2020-07-27 18:15:59 --> Router Class Initialized
INFO - 2020-07-27 18:15:59 --> Output Class Initialized
INFO - 2020-07-27 18:15:59 --> Security Class Initialized
DEBUG - 2020-07-27 18:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:15:59 --> Input Class Initialized
INFO - 2020-07-27 18:15:59 --> Language Class Initialized
ERROR - 2020-07-27 18:15:59 --> 404 Page Not Found: Welcome/user_auth
INFO - 2020-07-27 18:16:04 --> Config Class Initialized
INFO - 2020-07-27 18:16:04 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:04 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:04 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:04 --> URI Class Initialized
INFO - 2020-07-27 18:16:04 --> Router Class Initialized
INFO - 2020-07-27 18:16:04 --> Output Class Initialized
INFO - 2020-07-27 18:16:04 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:04 --> Input Class Initialized
INFO - 2020-07-27 18:16:04 --> Language Class Initialized
ERROR - 2020-07-27 18:16:04 --> 404 Page Not Found: Welcome/user_auth
INFO - 2020-07-27 18:16:36 --> Config Class Initialized
INFO - 2020-07-27 18:16:36 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:36 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:36 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:36 --> URI Class Initialized
INFO - 2020-07-27 18:16:36 --> Router Class Initialized
INFO - 2020-07-27 18:16:36 --> Output Class Initialized
INFO - 2020-07-27 18:16:36 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:36 --> Input Class Initialized
INFO - 2020-07-27 18:16:36 --> Language Class Initialized
ERROR - 2020-07-27 18:16:36 --> 404 Page Not Found: Welcome/user_auth
INFO - 2020-07-27 18:16:40 --> Config Class Initialized
INFO - 2020-07-27 18:16:40 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:40 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:40 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:40 --> URI Class Initialized
DEBUG - 2020-07-27 18:16:40 --> No URI present. Default controller set.
INFO - 2020-07-27 18:16:40 --> Router Class Initialized
INFO - 2020-07-27 18:16:40 --> Output Class Initialized
INFO - 2020-07-27 18:16:40 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:40 --> Input Class Initialized
INFO - 2020-07-27 18:16:40 --> Language Class Initialized
INFO - 2020-07-27 18:16:40 --> Loader Class Initialized
INFO - 2020-07-27 18:16:40 --> Helper loaded: url_helper
INFO - 2020-07-27 18:16:40 --> Helper loaded: file_helper
INFO - 2020-07-27 18:16:40 --> Database Driver Class Initialized
INFO - 2020-07-27 18:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:16:40 --> Controller Class Initialized
INFO - 2020-07-27 18:16:40 --> Model Class Initialized
INFO - 2020-07-27 18:16:40 --> Model Class Initialized
DEBUG - 2020-07-27 18:16:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-27 18:16:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 18:16:40 --> Final output sent to browser
DEBUG - 2020-07-27 18:16:40 --> Total execution time: 0.0191
INFO - 2020-07-27 18:16:42 --> Config Class Initialized
INFO - 2020-07-27 18:16:42 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:42 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:42 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:42 --> URI Class Initialized
INFO - 2020-07-27 18:16:42 --> Router Class Initialized
INFO - 2020-07-27 18:16:42 --> Output Class Initialized
INFO - 2020-07-27 18:16:42 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:42 --> Input Class Initialized
INFO - 2020-07-27 18:16:42 --> Language Class Initialized
INFO - 2020-07-27 18:16:42 --> Loader Class Initialized
INFO - 2020-07-27 18:16:42 --> Helper loaded: url_helper
INFO - 2020-07-27 18:16:42 --> Helper loaded: file_helper
INFO - 2020-07-27 18:16:42 --> Database Driver Class Initialized
INFO - 2020-07-27 18:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:16:42 --> Controller Class Initialized
INFO - 2020-07-27 18:16:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 18:16:42 --> Final output sent to browser
DEBUG - 2020-07-27 18:16:42 --> Total execution time: 0.0185
INFO - 2020-07-27 18:16:45 --> Config Class Initialized
INFO - 2020-07-27 18:16:45 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:45 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:45 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:45 --> URI Class Initialized
INFO - 2020-07-27 18:16:45 --> Router Class Initialized
INFO - 2020-07-27 18:16:45 --> Output Class Initialized
INFO - 2020-07-27 18:16:45 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:45 --> Input Class Initialized
INFO - 2020-07-27 18:16:45 --> Language Class Initialized
INFO - 2020-07-27 18:16:45 --> Loader Class Initialized
INFO - 2020-07-27 18:16:45 --> Helper loaded: url_helper
INFO - 2020-07-27 18:16:45 --> Helper loaded: file_helper
INFO - 2020-07-27 18:16:45 --> Database Driver Class Initialized
INFO - 2020-07-27 18:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:16:45 --> Controller Class Initialized
INFO - 2020-07-27 18:16:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-27 18:16:45 --> Final output sent to browser
DEBUG - 2020-07-27 18:16:45 --> Total execution time: 0.0198
INFO - 2020-07-27 18:16:50 --> Config Class Initialized
INFO - 2020-07-27 18:16:50 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:50 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:50 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:50 --> URI Class Initialized
INFO - 2020-07-27 18:16:50 --> Router Class Initialized
INFO - 2020-07-27 18:16:50 --> Output Class Initialized
INFO - 2020-07-27 18:16:50 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:50 --> Input Class Initialized
INFO - 2020-07-27 18:16:50 --> Language Class Initialized
INFO - 2020-07-27 18:16:50 --> Loader Class Initialized
INFO - 2020-07-27 18:16:50 --> Helper loaded: url_helper
INFO - 2020-07-27 18:16:50 --> Helper loaded: file_helper
INFO - 2020-07-27 18:16:50 --> Database Driver Class Initialized
INFO - 2020-07-27 18:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:16:50 --> Controller Class Initialized
INFO - 2020-07-27 18:16:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-27 18:16:50 --> Final output sent to browser
DEBUG - 2020-07-27 18:16:50 --> Total execution time: 0.0164
INFO - 2020-07-27 18:16:52 --> Config Class Initialized
INFO - 2020-07-27 18:16:52 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:52 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:52 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:52 --> URI Class Initialized
INFO - 2020-07-27 18:16:52 --> Router Class Initialized
INFO - 2020-07-27 18:16:52 --> Output Class Initialized
INFO - 2020-07-27 18:16:52 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:52 --> Input Class Initialized
INFO - 2020-07-27 18:16:52 --> Language Class Initialized
ERROR - 2020-07-27 18:16:52 --> 404 Page Not Found: Admin/dealer_master_list.html
INFO - 2020-07-27 18:16:55 --> Config Class Initialized
INFO - 2020-07-27 18:16:55 --> Hooks Class Initialized
DEBUG - 2020-07-27 18:16:55 --> UTF-8 Support Enabled
INFO - 2020-07-27 18:16:55 --> Utf8 Class Initialized
INFO - 2020-07-27 18:16:55 --> URI Class Initialized
INFO - 2020-07-27 18:16:55 --> Router Class Initialized
INFO - 2020-07-27 18:16:55 --> Output Class Initialized
INFO - 2020-07-27 18:16:55 --> Security Class Initialized
DEBUG - 2020-07-27 18:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 18:16:55 --> Input Class Initialized
INFO - 2020-07-27 18:16:55 --> Language Class Initialized
INFO - 2020-07-27 18:16:55 --> Loader Class Initialized
INFO - 2020-07-27 18:16:55 --> Helper loaded: url_helper
INFO - 2020-07-27 18:16:55 --> Helper loaded: file_helper
INFO - 2020-07-27 18:16:55 --> Database Driver Class Initialized
INFO - 2020-07-27 18:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 18:16:55 --> Controller Class Initialized
INFO - 2020-07-27 18:16:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-07-27 18:16:55 --> Final output sent to browser
DEBUG - 2020-07-27 18:16:55 --> Total execution time: 0.0181
INFO - 2020-07-27 19:17:14 --> Config Class Initialized
INFO - 2020-07-27 19:17:14 --> Hooks Class Initialized
DEBUG - 2020-07-27 19:17:14 --> UTF-8 Support Enabled
INFO - 2020-07-27 19:17:14 --> Utf8 Class Initialized
INFO - 2020-07-27 19:17:14 --> URI Class Initialized
DEBUG - 2020-07-27 19:17:14 --> No URI present. Default controller set.
INFO - 2020-07-27 19:17:14 --> Router Class Initialized
INFO - 2020-07-27 19:17:14 --> Output Class Initialized
INFO - 2020-07-27 19:17:14 --> Security Class Initialized
DEBUG - 2020-07-27 19:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 19:17:14 --> Input Class Initialized
INFO - 2020-07-27 19:17:14 --> Language Class Initialized
INFO - 2020-07-27 19:17:14 --> Loader Class Initialized
INFO - 2020-07-27 19:17:14 --> Helper loaded: url_helper
INFO - 2020-07-27 19:17:14 --> Helper loaded: file_helper
INFO - 2020-07-27 19:17:14 --> Database Driver Class Initialized
INFO - 2020-07-27 19:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 19:17:14 --> Controller Class Initialized
INFO - 2020-07-27 19:17:14 --> Model Class Initialized
INFO - 2020-07-27 19:17:14 --> Model Class Initialized
DEBUG - 2020-07-27 19:17:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-07-27 19:17:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-07-27 19:17:14 --> Final output sent to browser
DEBUG - 2020-07-27 19:17:14 --> Total execution time: 0.0222
INFO - 2020-07-27 19:18:57 --> Config Class Initialized
INFO - 2020-07-27 19:18:57 --> Hooks Class Initialized
DEBUG - 2020-07-27 19:18:57 --> UTF-8 Support Enabled
INFO - 2020-07-27 19:18:57 --> Utf8 Class Initialized
INFO - 2020-07-27 19:18:57 --> URI Class Initialized
INFO - 2020-07-27 19:18:57 --> Router Class Initialized
INFO - 2020-07-27 19:18:57 --> Output Class Initialized
INFO - 2020-07-27 19:18:57 --> Security Class Initialized
DEBUG - 2020-07-27 19:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 19:18:57 --> Input Class Initialized
INFO - 2020-07-27 19:18:57 --> Language Class Initialized
INFO - 2020-07-27 19:18:57 --> Loader Class Initialized
INFO - 2020-07-27 19:18:57 --> Helper loaded: url_helper
INFO - 2020-07-27 19:18:57 --> Helper loaded: file_helper
INFO - 2020-07-27 19:18:57 --> Database Driver Class Initialized
INFO - 2020-07-27 19:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 19:18:57 --> Controller Class Initialized
INFO - 2020-07-27 19:18:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 19:18:57 --> Final output sent to browser
DEBUG - 2020-07-27 19:18:57 --> Total execution time: 0.0205
INFO - 2020-07-27 19:19:09 --> Config Class Initialized
INFO - 2020-07-27 19:19:09 --> Hooks Class Initialized
DEBUG - 2020-07-27 19:19:09 --> UTF-8 Support Enabled
INFO - 2020-07-27 19:19:09 --> Utf8 Class Initialized
INFO - 2020-07-27 19:19:09 --> URI Class Initialized
INFO - 2020-07-27 19:19:09 --> Router Class Initialized
INFO - 2020-07-27 19:19:09 --> Output Class Initialized
INFO - 2020-07-27 19:19:09 --> Security Class Initialized
DEBUG - 2020-07-27 19:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 19:19:09 --> Input Class Initialized
INFO - 2020-07-27 19:19:09 --> Language Class Initialized
INFO - 2020-07-27 19:19:09 --> Loader Class Initialized
INFO - 2020-07-27 19:19:09 --> Helper loaded: url_helper
INFO - 2020-07-27 19:19:09 --> Helper loaded: file_helper
INFO - 2020-07-27 19:19:09 --> Database Driver Class Initialized
INFO - 2020-07-27 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 19:19:09 --> Controller Class Initialized
INFO - 2020-07-27 19:19:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-27 19:19:09 --> Final output sent to browser
DEBUG - 2020-07-27 19:19:09 --> Total execution time: 0.0198
INFO - 2020-07-27 19:19:31 --> Config Class Initialized
INFO - 2020-07-27 19:19:31 --> Hooks Class Initialized
DEBUG - 2020-07-27 19:19:31 --> UTF-8 Support Enabled
INFO - 2020-07-27 19:19:31 --> Utf8 Class Initialized
INFO - 2020-07-27 19:19:31 --> URI Class Initialized
INFO - 2020-07-27 19:19:31 --> Router Class Initialized
INFO - 2020-07-27 19:19:31 --> Output Class Initialized
INFO - 2020-07-27 19:19:31 --> Security Class Initialized
DEBUG - 2020-07-27 19:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 19:19:31 --> Input Class Initialized
INFO - 2020-07-27 19:19:31 --> Language Class Initialized
INFO - 2020-07-27 19:19:31 --> Loader Class Initialized
INFO - 2020-07-27 19:19:31 --> Helper loaded: url_helper
INFO - 2020-07-27 19:19:31 --> Helper loaded: file_helper
INFO - 2020-07-27 19:19:31 --> Database Driver Class Initialized
INFO - 2020-07-27 19:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 19:19:31 --> Controller Class Initialized
INFO - 2020-07-27 19:19:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-27 19:19:31 --> Final output sent to browser
DEBUG - 2020-07-27 19:19:31 --> Total execution time: 0.0173
INFO - 2020-07-27 19:19:37 --> Config Class Initialized
INFO - 2020-07-27 19:19:37 --> Hooks Class Initialized
DEBUG - 2020-07-27 19:19:37 --> UTF-8 Support Enabled
INFO - 2020-07-27 19:19:37 --> Utf8 Class Initialized
INFO - 2020-07-27 19:19:37 --> URI Class Initialized
INFO - 2020-07-27 19:19:37 --> Router Class Initialized
INFO - 2020-07-27 19:19:37 --> Output Class Initialized
INFO - 2020-07-27 19:19:37 --> Security Class Initialized
DEBUG - 2020-07-27 19:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 19:19:37 --> Input Class Initialized
INFO - 2020-07-27 19:19:37 --> Language Class Initialized
INFO - 2020-07-27 19:19:37 --> Loader Class Initialized
INFO - 2020-07-27 19:19:37 --> Helper loaded: url_helper
INFO - 2020-07-27 19:19:37 --> Helper loaded: file_helper
INFO - 2020-07-27 19:19:37 --> Database Driver Class Initialized
INFO - 2020-07-27 19:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 19:19:37 --> Controller Class Initialized
INFO - 2020-07-27 19:19:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-07-27 19:19:37 --> Final output sent to browser
DEBUG - 2020-07-27 19:19:37 --> Total execution time: 0.0199
INFO - 2020-07-27 19:19:55 --> Config Class Initialized
INFO - 2020-07-27 19:19:55 --> Hooks Class Initialized
DEBUG - 2020-07-27 19:19:55 --> UTF-8 Support Enabled
INFO - 2020-07-27 19:19:55 --> Utf8 Class Initialized
INFO - 2020-07-27 19:19:55 --> URI Class Initialized
INFO - 2020-07-27 19:19:55 --> Router Class Initialized
INFO - 2020-07-27 19:19:55 --> Output Class Initialized
INFO - 2020-07-27 19:19:55 --> Security Class Initialized
DEBUG - 2020-07-27 19:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-07-27 19:19:55 --> Input Class Initialized
INFO - 2020-07-27 19:19:55 --> Language Class Initialized
INFO - 2020-07-27 19:19:55 --> Loader Class Initialized
INFO - 2020-07-27 19:19:55 --> Helper loaded: url_helper
INFO - 2020-07-27 19:19:55 --> Helper loaded: file_helper
INFO - 2020-07-27 19:19:55 --> Database Driver Class Initialized
INFO - 2020-07-27 19:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-07-27 19:19:55 --> Controller Class Initialized
INFO - 2020-07-27 19:19:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-07-27 19:19:55 --> Final output sent to browser
DEBUG - 2020-07-27 19:19:55 --> Total execution time: 0.0181
