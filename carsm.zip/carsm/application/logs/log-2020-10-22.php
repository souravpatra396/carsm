<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-22 05:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-22 05:44:33 --> Config Class Initialized
INFO - 2020-10-22 05:44:33 --> Hooks Class Initialized
DEBUG - 2020-10-22 05:44:33 --> UTF-8 Support Enabled
INFO - 2020-10-22 05:44:33 --> Utf8 Class Initialized
INFO - 2020-10-22 05:44:33 --> URI Class Initialized
DEBUG - 2020-10-22 05:44:33 --> No URI present. Default controller set.
INFO - 2020-10-22 05:44:33 --> Router Class Initialized
INFO - 2020-10-22 05:44:33 --> Output Class Initialized
INFO - 2020-10-22 05:44:33 --> Security Class Initialized
DEBUG - 2020-10-22 05:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 05:44:33 --> Input Class Initialized
INFO - 2020-10-22 05:44:33 --> Language Class Initialized
INFO - 2020-10-22 05:44:33 --> Loader Class Initialized
INFO - 2020-10-22 05:44:33 --> Helper loaded: url_helper
INFO - 2020-10-22 05:44:33 --> Database Driver Class Initialized
INFO - 2020-10-22 05:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 05:44:33 --> Email Class Initialized
INFO - 2020-10-22 05:44:33 --> Controller Class Initialized
INFO - 2020-10-22 05:44:33 --> Model Class Initialized
INFO - 2020-10-22 05:44:33 --> Model Class Initialized
DEBUG - 2020-10-22 05:44:33 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-22 05:44:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-22 05:44:33 --> Final output sent to browser
DEBUG - 2020-10-22 05:44:33 --> Total execution time: 0.1904
ERROR - 2020-10-22 06:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-22 06:51:03 --> Config Class Initialized
INFO - 2020-10-22 06:51:03 --> Hooks Class Initialized
DEBUG - 2020-10-22 06:51:03 --> UTF-8 Support Enabled
INFO - 2020-10-22 06:51:03 --> Utf8 Class Initialized
INFO - 2020-10-22 06:51:03 --> URI Class Initialized
DEBUG - 2020-10-22 06:51:03 --> No URI present. Default controller set.
INFO - 2020-10-22 06:51:03 --> Router Class Initialized
INFO - 2020-10-22 06:51:03 --> Output Class Initialized
INFO - 2020-10-22 06:51:03 --> Security Class Initialized
DEBUG - 2020-10-22 06:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 06:51:03 --> Input Class Initialized
INFO - 2020-10-22 06:51:03 --> Language Class Initialized
INFO - 2020-10-22 06:51:03 --> Loader Class Initialized
INFO - 2020-10-22 06:51:03 --> Helper loaded: url_helper
INFO - 2020-10-22 06:51:03 --> Database Driver Class Initialized
INFO - 2020-10-22 06:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 06:51:03 --> Email Class Initialized
INFO - 2020-10-22 06:51:03 --> Controller Class Initialized
INFO - 2020-10-22 06:51:03 --> Model Class Initialized
INFO - 2020-10-22 06:51:03 --> Model Class Initialized
DEBUG - 2020-10-22 06:51:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-22 06:51:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-22 06:51:03 --> Final output sent to browser
DEBUG - 2020-10-22 06:51:03 --> Total execution time: 0.1265
ERROR - 2020-10-22 08:41:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-22 08:41:46 --> Config Class Initialized
INFO - 2020-10-22 08:41:46 --> Hooks Class Initialized
DEBUG - 2020-10-22 08:41:46 --> UTF-8 Support Enabled
INFO - 2020-10-22 08:41:46 --> Utf8 Class Initialized
INFO - 2020-10-22 08:41:46 --> URI Class Initialized
DEBUG - 2020-10-22 08:41:46 --> No URI present. Default controller set.
INFO - 2020-10-22 08:41:46 --> Router Class Initialized
INFO - 2020-10-22 08:41:46 --> Output Class Initialized
INFO - 2020-10-22 08:41:46 --> Security Class Initialized
DEBUG - 2020-10-22 08:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 08:41:46 --> Input Class Initialized
INFO - 2020-10-22 08:41:46 --> Language Class Initialized
INFO - 2020-10-22 08:41:46 --> Loader Class Initialized
INFO - 2020-10-22 08:41:46 --> Helper loaded: url_helper
INFO - 2020-10-22 08:41:46 --> Database Driver Class Initialized
INFO - 2020-10-22 08:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 08:41:46 --> Email Class Initialized
INFO - 2020-10-22 08:41:46 --> Controller Class Initialized
INFO - 2020-10-22 08:41:46 --> Model Class Initialized
INFO - 2020-10-22 08:41:46 --> Model Class Initialized
DEBUG - 2020-10-22 08:41:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-22 08:41:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-22 08:41:46 --> Final output sent to browser
DEBUG - 2020-10-22 08:41:46 --> Total execution time: 0.1103
ERROR - 2020-10-22 10:59:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-22 10:59:46 --> Config Class Initialized
INFO - 2020-10-22 10:59:46 --> Hooks Class Initialized
DEBUG - 2020-10-22 10:59:46 --> UTF-8 Support Enabled
INFO - 2020-10-22 10:59:46 --> Utf8 Class Initialized
INFO - 2020-10-22 10:59:46 --> URI Class Initialized
DEBUG - 2020-10-22 10:59:46 --> No URI present. Default controller set.
INFO - 2020-10-22 10:59:46 --> Router Class Initialized
INFO - 2020-10-22 10:59:46 --> Output Class Initialized
INFO - 2020-10-22 10:59:46 --> Security Class Initialized
DEBUG - 2020-10-22 10:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 10:59:46 --> Input Class Initialized
INFO - 2020-10-22 10:59:46 --> Language Class Initialized
INFO - 2020-10-22 10:59:46 --> Loader Class Initialized
INFO - 2020-10-22 10:59:46 --> Helper loaded: url_helper
INFO - 2020-10-22 10:59:46 --> Database Driver Class Initialized
INFO - 2020-10-22 10:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 10:59:46 --> Email Class Initialized
INFO - 2020-10-22 10:59:46 --> Controller Class Initialized
INFO - 2020-10-22 10:59:46 --> Model Class Initialized
INFO - 2020-10-22 10:59:46 --> Model Class Initialized
DEBUG - 2020-10-22 10:59:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-22 10:59:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-22 10:59:46 --> Final output sent to browser
DEBUG - 2020-10-22 10:59:46 --> Total execution time: 0.0222
ERROR - 2020-10-22 13:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-22 13:33:48 --> Config Class Initialized
INFO - 2020-10-22 13:33:48 --> Hooks Class Initialized
DEBUG - 2020-10-22 13:33:48 --> UTF-8 Support Enabled
INFO - 2020-10-22 13:33:48 --> Utf8 Class Initialized
INFO - 2020-10-22 13:33:48 --> URI Class Initialized
DEBUG - 2020-10-22 13:33:48 --> No URI present. Default controller set.
INFO - 2020-10-22 13:33:48 --> Router Class Initialized
INFO - 2020-10-22 13:33:48 --> Output Class Initialized
INFO - 2020-10-22 13:33:48 --> Security Class Initialized
DEBUG - 2020-10-22 13:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-22 13:33:48 --> Input Class Initialized
INFO - 2020-10-22 13:33:48 --> Language Class Initialized
INFO - 2020-10-22 13:33:48 --> Loader Class Initialized
INFO - 2020-10-22 13:33:48 --> Helper loaded: url_helper
INFO - 2020-10-22 13:33:48 --> Database Driver Class Initialized
INFO - 2020-10-22 13:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-22 13:33:48 --> Email Class Initialized
INFO - 2020-10-22 13:33:48 --> Controller Class Initialized
INFO - 2020-10-22 13:33:48 --> Model Class Initialized
INFO - 2020-10-22 13:33:48 --> Model Class Initialized
DEBUG - 2020-10-22 13:33:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-22 13:33:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-22 13:33:48 --> Final output sent to browser
DEBUG - 2020-10-22 13:33:48 --> Total execution time: 0.0214
