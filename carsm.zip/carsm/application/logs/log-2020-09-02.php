<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-02 07:58:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 07:58:48 --> Config Class Initialized
INFO - 2020-09-02 07:58:48 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:58:48 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:58:48 --> Utf8 Class Initialized
INFO - 2020-09-02 07:58:48 --> URI Class Initialized
DEBUG - 2020-09-02 07:58:48 --> No URI present. Default controller set.
INFO - 2020-09-02 07:58:48 --> Router Class Initialized
INFO - 2020-09-02 07:58:48 --> Output Class Initialized
INFO - 2020-09-02 07:58:48 --> Security Class Initialized
DEBUG - 2020-09-02 07:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:58:48 --> Input Class Initialized
INFO - 2020-09-02 07:58:48 --> Language Class Initialized
INFO - 2020-09-02 07:58:48 --> Loader Class Initialized
INFO - 2020-09-02 07:58:48 --> Helper loaded: url_helper
INFO - 2020-09-02 07:58:48 --> Database Driver Class Initialized
INFO - 2020-09-02 07:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:58:48 --> Email Class Initialized
INFO - 2020-09-02 07:58:48 --> Controller Class Initialized
INFO - 2020-09-02 07:58:48 --> Model Class Initialized
INFO - 2020-09-02 07:58:48 --> Model Class Initialized
DEBUG - 2020-09-02 07:58:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-02 07:58:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-02 07:58:48 --> Final output sent to browser
DEBUG - 2020-09-02 07:58:48 --> Total execution time: 0.1909
ERROR - 2020-09-02 07:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 07:59:11 --> Config Class Initialized
INFO - 2020-09-02 07:59:11 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:59:11 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:59:11 --> Utf8 Class Initialized
INFO - 2020-09-02 07:59:11 --> URI Class Initialized
INFO - 2020-09-02 07:59:11 --> Router Class Initialized
INFO - 2020-09-02 07:59:11 --> Output Class Initialized
INFO - 2020-09-02 07:59:11 --> Security Class Initialized
DEBUG - 2020-09-02 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:59:11 --> Input Class Initialized
INFO - 2020-09-02 07:59:11 --> Language Class Initialized
INFO - 2020-09-02 07:59:11 --> Loader Class Initialized
INFO - 2020-09-02 07:59:11 --> Helper loaded: url_helper
INFO - 2020-09-02 07:59:11 --> Database Driver Class Initialized
INFO - 2020-09-02 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:59:11 --> Email Class Initialized
INFO - 2020-09-02 07:59:11 --> Controller Class Initialized
INFO - 2020-09-02 07:59:11 --> Model Class Initialized
INFO - 2020-09-02 07:59:11 --> Model Class Initialized
DEBUG - 2020-09-02 07:59:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-02 07:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 07:59:11 --> Config Class Initialized
INFO - 2020-09-02 07:59:11 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:59:11 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:59:11 --> Utf8 Class Initialized
INFO - 2020-09-02 07:59:11 --> URI Class Initialized
INFO - 2020-09-02 07:59:11 --> Router Class Initialized
INFO - 2020-09-02 07:59:11 --> Output Class Initialized
INFO - 2020-09-02 07:59:11 --> Security Class Initialized
DEBUG - 2020-09-02 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:59:11 --> Input Class Initialized
INFO - 2020-09-02 07:59:11 --> Language Class Initialized
INFO - 2020-09-02 07:59:11 --> Loader Class Initialized
INFO - 2020-09-02 07:59:11 --> Helper loaded: url_helper
INFO - 2020-09-02 07:59:11 --> Database Driver Class Initialized
INFO - 2020-09-02 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:59:11 --> Email Class Initialized
INFO - 2020-09-02 07:59:11 --> Controller Class Initialized
INFO - 2020-09-02 07:59:11 --> Model Class Initialized
INFO - 2020-09-02 07:59:11 --> Model Class Initialized
DEBUG - 2020-09-02 07:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 07:59:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-02 07:59:11 --> Model Class Initialized
INFO - 2020-09-02 07:59:11 --> Final output sent to browser
DEBUG - 2020-09-02 07:59:11 --> Total execution time: 0.0342
ERROR - 2020-09-02 07:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 07:59:11 --> Config Class Initialized
INFO - 2020-09-02 07:59:11 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:59:11 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:59:11 --> Utf8 Class Initialized
INFO - 2020-09-02 07:59:11 --> URI Class Initialized
INFO - 2020-09-02 07:59:11 --> Router Class Initialized
INFO - 2020-09-02 07:59:11 --> Output Class Initialized
INFO - 2020-09-02 07:59:11 --> Security Class Initialized
DEBUG - 2020-09-02 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:59:11 --> Input Class Initialized
INFO - 2020-09-02 07:59:11 --> Language Class Initialized
INFO - 2020-09-02 07:59:11 --> Loader Class Initialized
INFO - 2020-09-02 07:59:11 --> Helper loaded: url_helper
INFO - 2020-09-02 07:59:11 --> Database Driver Class Initialized
INFO - 2020-09-02 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:59:11 --> Email Class Initialized
INFO - 2020-09-02 07:59:11 --> Controller Class Initialized
DEBUG - 2020-09-02 07:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 07:59:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-02 07:59:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-02 07:59:11 --> Final output sent to browser
DEBUG - 2020-09-02 07:59:11 --> Total execution time: 0.0451
ERROR - 2020-09-02 07:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 07:59:40 --> Config Class Initialized
INFO - 2020-09-02 07:59:40 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:59:40 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:59:40 --> Utf8 Class Initialized
INFO - 2020-09-02 07:59:40 --> URI Class Initialized
INFO - 2020-09-02 07:59:40 --> Router Class Initialized
INFO - 2020-09-02 07:59:40 --> Output Class Initialized
INFO - 2020-09-02 07:59:40 --> Security Class Initialized
DEBUG - 2020-09-02 07:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:59:40 --> Input Class Initialized
INFO - 2020-09-02 07:59:40 --> Language Class Initialized
INFO - 2020-09-02 07:59:40 --> Loader Class Initialized
INFO - 2020-09-02 07:59:40 --> Helper loaded: url_helper
INFO - 2020-09-02 07:59:40 --> Database Driver Class Initialized
INFO - 2020-09-02 07:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:59:40 --> Email Class Initialized
INFO - 2020-09-02 07:59:40 --> Controller Class Initialized
DEBUG - 2020-09-02 07:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 07:59:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-02 07:59:40 --> Helper loaded: form_helper
INFO - 2020-09-02 07:59:40 --> Form Validation Class Initialized
INFO - 2020-09-02 07:59:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-02 07:59:40 --> Final output sent to browser
DEBUG - 2020-09-02 07:59:40 --> Total execution time: 0.0610
ERROR - 2020-09-02 07:59:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 07:59:54 --> Config Class Initialized
INFO - 2020-09-02 07:59:54 --> Hooks Class Initialized
DEBUG - 2020-09-02 07:59:54 --> UTF-8 Support Enabled
INFO - 2020-09-02 07:59:54 --> Utf8 Class Initialized
INFO - 2020-09-02 07:59:54 --> URI Class Initialized
INFO - 2020-09-02 07:59:54 --> Router Class Initialized
INFO - 2020-09-02 07:59:54 --> Output Class Initialized
INFO - 2020-09-02 07:59:54 --> Security Class Initialized
DEBUG - 2020-09-02 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 07:59:54 --> Input Class Initialized
INFO - 2020-09-02 07:59:54 --> Language Class Initialized
INFO - 2020-09-02 07:59:54 --> Loader Class Initialized
INFO - 2020-09-02 07:59:54 --> Helper loaded: url_helper
INFO - 2020-09-02 07:59:54 --> Database Driver Class Initialized
INFO - 2020-09-02 07:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 07:59:54 --> Email Class Initialized
INFO - 2020-09-02 07:59:54 --> Controller Class Initialized
DEBUG - 2020-09-02 07:59:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-02 07:59:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-02 07:59:54 --> Helper loaded: form_helper
INFO - 2020-09-02 07:59:54 --> Form Validation Class Initialized
INFO - 2020-09-02 07:59:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-09-02 07:59:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-02 07:59:54 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-09-02 08:01:00 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-02 09:36:01 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-02 09:37:59 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-02 09:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-02 09:38:23 --> Config Class Initialized
INFO - 2020-09-02 09:38:23 --> Hooks Class Initialized
DEBUG - 2020-09-02 09:38:23 --> UTF-8 Support Enabled
INFO - 2020-09-02 09:38:23 --> Utf8 Class Initialized
INFO - 2020-09-02 09:38:23 --> URI Class Initialized
DEBUG - 2020-09-02 09:38:23 --> No URI present. Default controller set.
INFO - 2020-09-02 09:38:23 --> Router Class Initialized
INFO - 2020-09-02 09:38:23 --> Output Class Initialized
INFO - 2020-09-02 09:38:23 --> Security Class Initialized
DEBUG - 2020-09-02 09:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-02 09:38:23 --> Input Class Initialized
INFO - 2020-09-02 09:38:23 --> Language Class Initialized
INFO - 2020-09-02 09:38:23 --> Loader Class Initialized
INFO - 2020-09-02 09:38:23 --> Helper loaded: url_helper
INFO - 2020-09-02 09:38:23 --> Database Driver Class Initialized
INFO - 2020-09-02 09:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-02 09:38:23 --> Email Class Initialized
INFO - 2020-09-02 09:38:23 --> Controller Class Initialized
INFO - 2020-09-02 09:38:23 --> Model Class Initialized
INFO - 2020-09-02 09:38:23 --> Model Class Initialized
DEBUG - 2020-09-02 09:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-02 09:38:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-02 09:38:24 --> Final output sent to browser
DEBUG - 2020-09-02 09:38:24 --> Total execution time: 0.0691
ERROR - 2020-09-02 09:39:44 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-02 09:40:02 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
