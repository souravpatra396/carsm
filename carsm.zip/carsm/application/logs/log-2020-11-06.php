<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-06 06:03:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 06:03:08 --> Config Class Initialized
INFO - 2020-11-06 06:03:08 --> Hooks Class Initialized
DEBUG - 2020-11-06 06:03:08 --> UTF-8 Support Enabled
INFO - 2020-11-06 06:03:08 --> Utf8 Class Initialized
INFO - 2020-11-06 06:03:08 --> URI Class Initialized
DEBUG - 2020-11-06 06:03:08 --> No URI present. Default controller set.
INFO - 2020-11-06 06:03:08 --> Router Class Initialized
INFO - 2020-11-06 06:03:08 --> Output Class Initialized
INFO - 2020-11-06 06:03:08 --> Security Class Initialized
DEBUG - 2020-11-06 06:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 06:03:08 --> Input Class Initialized
INFO - 2020-11-06 06:03:08 --> Language Class Initialized
INFO - 2020-11-06 06:03:08 --> Loader Class Initialized
INFO - 2020-11-06 06:03:08 --> Helper loaded: url_helper
INFO - 2020-11-06 06:03:08 --> Database Driver Class Initialized
INFO - 2020-11-06 06:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 06:03:08 --> Email Class Initialized
INFO - 2020-11-06 06:03:08 --> Controller Class Initialized
INFO - 2020-11-06 06:03:08 --> Model Class Initialized
INFO - 2020-11-06 06:03:08 --> Model Class Initialized
DEBUG - 2020-11-06 06:03:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-06 06:03:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-06 06:03:08 --> Final output sent to browser
DEBUG - 2020-11-06 06:03:08 --> Total execution time: 0.1646
ERROR - 2020-11-06 06:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-11-06 06:03:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 06:03:23 --> Config Class Initialized
INFO - 2020-11-06 06:03:23 --> Hooks Class Initialized
INFO - 2020-11-06 06:03:23 --> Config Class Initialized
INFO - 2020-11-06 06:03:23 --> Hooks Class Initialized
DEBUG - 2020-11-06 06:03:23 --> UTF-8 Support Enabled
INFO - 2020-11-06 06:03:23 --> Utf8 Class Initialized
DEBUG - 2020-11-06 06:03:23 --> UTF-8 Support Enabled
INFO - 2020-11-06 06:03:23 --> Utf8 Class Initialized
INFO - 2020-11-06 06:03:23 --> URI Class Initialized
INFO - 2020-11-06 06:03:23 --> URI Class Initialized
INFO - 2020-11-06 06:03:23 --> Router Class Initialized
INFO - 2020-11-06 06:03:23 --> Router Class Initialized
INFO - 2020-11-06 06:03:23 --> Output Class Initialized
INFO - 2020-11-06 06:03:23 --> Output Class Initialized
INFO - 2020-11-06 06:03:23 --> Security Class Initialized
INFO - 2020-11-06 06:03:23 --> Security Class Initialized
DEBUG - 2020-11-06 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 06:03:23 --> Input Class Initialized
DEBUG - 2020-11-06 06:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 06:03:23 --> Input Class Initialized
INFO - 2020-11-06 06:03:23 --> Language Class Initialized
INFO - 2020-11-06 06:03:23 --> Language Class Initialized
INFO - 2020-11-06 06:03:23 --> Loader Class Initialized
INFO - 2020-11-06 06:03:23 --> Helper loaded: url_helper
INFO - 2020-11-06 06:03:23 --> Database Driver Class Initialized
INFO - 2020-11-06 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 06:03:23 --> Email Class Initialized
INFO - 2020-11-06 06:03:23 --> Controller Class Initialized
INFO - 2020-11-06 06:03:23 --> Model Class Initialized
INFO - 2020-11-06 06:03:23 --> Model Class Initialized
DEBUG - 2020-11-06 06:03:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-06 06:03:23 --> Loader Class Initialized
INFO - 2020-11-06 06:03:23 --> Helper loaded: url_helper
INFO - 2020-11-06 06:03:23 --> Database Driver Class Initialized
INFO - 2020-11-06 06:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 06:03:23 --> Email Class Initialized
INFO - 2020-11-06 06:03:23 --> Controller Class Initialized
INFO - 2020-11-06 06:03:23 --> Model Class Initialized
INFO - 2020-11-06 06:03:23 --> Model Class Initialized
DEBUG - 2020-11-06 06:03:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 06:03:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 06:03:23 --> Model Class Initialized
INFO - 2020-11-06 06:03:23 --> Final output sent to browser
DEBUG - 2020-11-06 06:03:23 --> Total execution time: 0.0788
ERROR - 2020-11-06 06:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 06:03:24 --> Config Class Initialized
INFO - 2020-11-06 06:03:24 --> Hooks Class Initialized
DEBUG - 2020-11-06 06:03:24 --> UTF-8 Support Enabled
INFO - 2020-11-06 06:03:24 --> Utf8 Class Initialized
INFO - 2020-11-06 06:03:24 --> URI Class Initialized
INFO - 2020-11-06 06:03:24 --> Router Class Initialized
INFO - 2020-11-06 06:03:24 --> Output Class Initialized
INFO - 2020-11-06 06:03:24 --> Security Class Initialized
DEBUG - 2020-11-06 06:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 06:03:24 --> Input Class Initialized
INFO - 2020-11-06 06:03:24 --> Language Class Initialized
INFO - 2020-11-06 06:03:24 --> Loader Class Initialized
INFO - 2020-11-06 06:03:24 --> Helper loaded: url_helper
INFO - 2020-11-06 06:03:24 --> Database Driver Class Initialized
INFO - 2020-11-06 06:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 06:03:24 --> Email Class Initialized
INFO - 2020-11-06 06:03:24 --> Controller Class Initialized
DEBUG - 2020-11-06 06:03:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 06:03:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 06:03:24 --> Model Class Initialized
INFO - 2020-11-06 06:03:24 --> Model Class Initialized
INFO - 2020-11-06 06:03:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-06 06:03:24 --> Final output sent to browser
DEBUG - 2020-11-06 06:03:24 --> Total execution time: 0.0931
ERROR - 2020-11-06 08:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:23:27 --> Config Class Initialized
INFO - 2020-11-06 08:23:27 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:23:27 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:23:27 --> Utf8 Class Initialized
INFO - 2020-11-06 08:23:27 --> URI Class Initialized
DEBUG - 2020-11-06 08:23:27 --> No URI present. Default controller set.
INFO - 2020-11-06 08:23:27 --> Router Class Initialized
INFO - 2020-11-06 08:23:27 --> Output Class Initialized
INFO - 2020-11-06 08:23:27 --> Security Class Initialized
DEBUG - 2020-11-06 08:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:23:27 --> Input Class Initialized
INFO - 2020-11-06 08:23:27 --> Language Class Initialized
INFO - 2020-11-06 08:23:27 --> Loader Class Initialized
INFO - 2020-11-06 08:23:27 --> Helper loaded: url_helper
INFO - 2020-11-06 08:23:27 --> Database Driver Class Initialized
INFO - 2020-11-06 08:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:23:27 --> Email Class Initialized
INFO - 2020-11-06 08:23:27 --> Controller Class Initialized
INFO - 2020-11-06 08:23:27 --> Model Class Initialized
INFO - 2020-11-06 08:23:27 --> Model Class Initialized
DEBUG - 2020-11-06 08:23:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-06 08:23:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-06 08:23:27 --> Final output sent to browser
DEBUG - 2020-11-06 08:23:27 --> Total execution time: 0.0194
ERROR - 2020-11-06 08:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:23:52 --> Config Class Initialized
INFO - 2020-11-06 08:23:52 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:23:52 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:23:52 --> Utf8 Class Initialized
INFO - 2020-11-06 08:23:52 --> URI Class Initialized
INFO - 2020-11-06 08:23:52 --> Router Class Initialized
INFO - 2020-11-06 08:23:52 --> Output Class Initialized
INFO - 2020-11-06 08:23:52 --> Security Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:23:52 --> Input Class Initialized
INFO - 2020-11-06 08:23:52 --> Language Class Initialized
INFO - 2020-11-06 08:23:52 --> Loader Class Initialized
INFO - 2020-11-06 08:23:52 --> Helper loaded: url_helper
INFO - 2020-11-06 08:23:52 --> Database Driver Class Initialized
INFO - 2020-11-06 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:23:52 --> Email Class Initialized
INFO - 2020-11-06 08:23:52 --> Controller Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 08:23:52 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-06 08:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:23:52 --> Config Class Initialized
INFO - 2020-11-06 08:23:52 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:23:52 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:23:52 --> Utf8 Class Initialized
INFO - 2020-11-06 08:23:52 --> URI Class Initialized
INFO - 2020-11-06 08:23:52 --> Router Class Initialized
INFO - 2020-11-06 08:23:52 --> Output Class Initialized
INFO - 2020-11-06 08:23:52 --> Security Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:23:52 --> Input Class Initialized
INFO - 2020-11-06 08:23:52 --> Language Class Initialized
INFO - 2020-11-06 08:23:52 --> Loader Class Initialized
INFO - 2020-11-06 08:23:52 --> Helper loaded: url_helper
INFO - 2020-11-06 08:23:52 --> Database Driver Class Initialized
INFO - 2020-11-06 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:23:52 --> Email Class Initialized
INFO - 2020-11-06 08:23:52 --> Controller Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-06 08:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:23:52 --> Config Class Initialized
INFO - 2020-11-06 08:23:52 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:23:52 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:23:52 --> Utf8 Class Initialized
INFO - 2020-11-06 08:23:52 --> URI Class Initialized
DEBUG - 2020-11-06 08:23:52 --> No URI present. Default controller set.
INFO - 2020-11-06 08:23:52 --> Router Class Initialized
INFO - 2020-11-06 08:23:52 --> Output Class Initialized
INFO - 2020-11-06 08:23:52 --> Security Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:23:52 --> Input Class Initialized
INFO - 2020-11-06 08:23:52 --> Language Class Initialized
INFO - 2020-11-06 08:23:52 --> Loader Class Initialized
INFO - 2020-11-06 08:23:52 --> Helper loaded: url_helper
INFO - 2020-11-06 08:23:52 --> Database Driver Class Initialized
INFO - 2020-11-06 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:23:52 --> Email Class Initialized
INFO - 2020-11-06 08:23:52 --> Controller Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-06 08:23:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-06 08:23:52 --> Final output sent to browser
DEBUG - 2020-11-06 08:23:52 --> Total execution time: 0.0180
ERROR - 2020-11-06 08:23:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:23:52 --> Config Class Initialized
INFO - 2020-11-06 08:23:52 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:23:52 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:23:52 --> Utf8 Class Initialized
INFO - 2020-11-06 08:23:52 --> URI Class Initialized
INFO - 2020-11-06 08:23:52 --> Router Class Initialized
INFO - 2020-11-06 08:23:52 --> Output Class Initialized
INFO - 2020-11-06 08:23:52 --> Security Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:23:52 --> Input Class Initialized
INFO - 2020-11-06 08:23:52 --> Language Class Initialized
INFO - 2020-11-06 08:23:52 --> Loader Class Initialized
INFO - 2020-11-06 08:23:52 --> Helper loaded: url_helper
INFO - 2020-11-06 08:23:52 --> Database Driver Class Initialized
INFO - 2020-11-06 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:23:52 --> Email Class Initialized
INFO - 2020-11-06 08:23:52 --> Controller Class Initialized
DEBUG - 2020-11-06 08:23:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 08:23:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
INFO - 2020-11-06 08:23:52 --> Model Class Initialized
INFO - 2020-11-06 08:23:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-06 08:23:52 --> Final output sent to browser
DEBUG - 2020-11-06 08:23:52 --> Total execution time: 0.0447
ERROR - 2020-11-06 08:24:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:24:02 --> Config Class Initialized
INFO - 2020-11-06 08:24:02 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:24:02 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:24:02 --> Utf8 Class Initialized
INFO - 2020-11-06 08:24:02 --> URI Class Initialized
INFO - 2020-11-06 08:24:02 --> Router Class Initialized
INFO - 2020-11-06 08:24:02 --> Output Class Initialized
INFO - 2020-11-06 08:24:02 --> Security Class Initialized
DEBUG - 2020-11-06 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:24:02 --> Input Class Initialized
INFO - 2020-11-06 08:24:02 --> Language Class Initialized
INFO - 2020-11-06 08:24:02 --> Loader Class Initialized
INFO - 2020-11-06 08:24:02 --> Helper loaded: url_helper
INFO - 2020-11-06 08:24:02 --> Database Driver Class Initialized
INFO - 2020-11-06 08:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:24:02 --> Email Class Initialized
INFO - 2020-11-06 08:24:02 --> Controller Class Initialized
DEBUG - 2020-11-06 08:24:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 08:24:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 08:24:02 --> Model Class Initialized
INFO - 2020-11-06 08:24:02 --> Model Class Initialized
INFO - 2020-11-06 08:24:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-06 08:24:02 --> Final output sent to browser
DEBUG - 2020-11-06 08:24:02 --> Total execution time: 0.0587
ERROR - 2020-11-06 08:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:37:25 --> Config Class Initialized
INFO - 2020-11-06 08:37:25 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:37:25 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:37:25 --> Utf8 Class Initialized
INFO - 2020-11-06 08:37:25 --> URI Class Initialized
INFO - 2020-11-06 08:37:25 --> Router Class Initialized
INFO - 2020-11-06 08:37:25 --> Output Class Initialized
INFO - 2020-11-06 08:37:25 --> Security Class Initialized
DEBUG - 2020-11-06 08:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:37:25 --> Input Class Initialized
INFO - 2020-11-06 08:37:25 --> Language Class Initialized
INFO - 2020-11-06 08:37:25 --> Loader Class Initialized
INFO - 2020-11-06 08:37:25 --> Helper loaded: url_helper
INFO - 2020-11-06 08:37:25 --> Database Driver Class Initialized
INFO - 2020-11-06 08:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:37:25 --> Email Class Initialized
INFO - 2020-11-06 08:37:25 --> Controller Class Initialized
DEBUG - 2020-11-06 08:37:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 08:37:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 08:37:25 --> Model Class Initialized
INFO - 2020-11-06 08:37:25 --> Model Class Initialized
ERROR - 2020-11-06 08:37:25 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-06 08:37:25 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-06 08:37:27 --> Final output sent to browser
DEBUG - 2020-11-06 08:37:27 --> Total execution time: 1.5450
ERROR - 2020-11-06 08:37:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 08:37:43 --> Config Class Initialized
INFO - 2020-11-06 08:37:43 --> Hooks Class Initialized
DEBUG - 2020-11-06 08:37:43 --> UTF-8 Support Enabled
INFO - 2020-11-06 08:37:43 --> Utf8 Class Initialized
INFO - 2020-11-06 08:37:43 --> URI Class Initialized
INFO - 2020-11-06 08:37:43 --> Router Class Initialized
INFO - 2020-11-06 08:37:43 --> Output Class Initialized
INFO - 2020-11-06 08:37:43 --> Security Class Initialized
DEBUG - 2020-11-06 08:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 08:37:43 --> Input Class Initialized
INFO - 2020-11-06 08:37:43 --> Language Class Initialized
INFO - 2020-11-06 08:37:43 --> Loader Class Initialized
INFO - 2020-11-06 08:37:43 --> Helper loaded: url_helper
INFO - 2020-11-06 08:37:43 --> Database Driver Class Initialized
INFO - 2020-11-06 08:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 08:37:43 --> Email Class Initialized
INFO - 2020-11-06 08:37:43 --> Controller Class Initialized
DEBUG - 2020-11-06 08:37:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 08:37:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 08:37:43 --> Model Class Initialized
INFO - 2020-11-06 08:37:43 --> Model Class Initialized
ERROR - 2020-11-06 08:37:43 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-06 08:37:43 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-06 08:37:44 --> Final output sent to browser
DEBUG - 2020-11-06 08:37:44 --> Total execution time: 1.0133
ERROR - 2020-11-06 09:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 09:16:24 --> Config Class Initialized
INFO - 2020-11-06 09:16:24 --> Hooks Class Initialized
DEBUG - 2020-11-06 09:16:24 --> UTF-8 Support Enabled
INFO - 2020-11-06 09:16:24 --> Utf8 Class Initialized
INFO - 2020-11-06 09:16:24 --> URI Class Initialized
INFO - 2020-11-06 09:16:24 --> Router Class Initialized
INFO - 2020-11-06 09:16:24 --> Output Class Initialized
INFO - 2020-11-06 09:16:24 --> Security Class Initialized
DEBUG - 2020-11-06 09:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 09:16:24 --> Input Class Initialized
INFO - 2020-11-06 09:16:24 --> Language Class Initialized
INFO - 2020-11-06 09:16:24 --> Loader Class Initialized
INFO - 2020-11-06 09:16:24 --> Helper loaded: url_helper
INFO - 2020-11-06 09:16:24 --> Database Driver Class Initialized
INFO - 2020-11-06 09:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 09:16:24 --> Email Class Initialized
INFO - 2020-11-06 09:16:24 --> Controller Class Initialized
DEBUG - 2020-11-06 09:16:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 09:16:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 09:16:24 --> Model Class Initialized
INFO - 2020-11-06 09:16:24 --> Model Class Initialized
ERROR - 2020-11-06 09:16:24 --> Severity: Runtime Notice --> Non-static method Purlem::get_contact() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 405
ERROR - 2020-11-06 09:16:24 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 17
INFO - 2020-11-06 09:16:26 --> Final output sent to browser
DEBUG - 2020-11-06 09:16:26 --> Total execution time: 1.2389
ERROR - 2020-11-06 09:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 09:21:25 --> Config Class Initialized
INFO - 2020-11-06 09:21:25 --> Hooks Class Initialized
DEBUG - 2020-11-06 09:21:25 --> UTF-8 Support Enabled
INFO - 2020-11-06 09:21:25 --> Utf8 Class Initialized
INFO - 2020-11-06 09:21:25 --> URI Class Initialized
INFO - 2020-11-06 09:21:25 --> Router Class Initialized
INFO - 2020-11-06 09:21:25 --> Output Class Initialized
INFO - 2020-11-06 09:21:25 --> Security Class Initialized
DEBUG - 2020-11-06 09:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 09:21:25 --> Input Class Initialized
INFO - 2020-11-06 09:21:25 --> Language Class Initialized
INFO - 2020-11-06 09:21:25 --> Loader Class Initialized
INFO - 2020-11-06 09:21:25 --> Helper loaded: url_helper
INFO - 2020-11-06 09:21:25 --> Database Driver Class Initialized
INFO - 2020-11-06 09:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 09:21:25 --> Email Class Initialized
INFO - 2020-11-06 09:21:25 --> Controller Class Initialized
DEBUG - 2020-11-06 09:21:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 09:21:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 09:21:25 --> Model Class Initialized
INFO - 2020-11-06 09:21:25 --> Model Class Initialized
ERROR - 2020-11-06 09:21:25 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-06 09:21:25 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-06 09:21:26 --> Final output sent to browser
DEBUG - 2020-11-06 09:21:26 --> Total execution time: 0.9526
ERROR - 2020-11-06 10:34:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 10:34:56 --> Config Class Initialized
INFO - 2020-11-06 10:34:56 --> Hooks Class Initialized
DEBUG - 2020-11-06 10:34:56 --> UTF-8 Support Enabled
INFO - 2020-11-06 10:34:56 --> Utf8 Class Initialized
INFO - 2020-11-06 10:34:56 --> URI Class Initialized
INFO - 2020-11-06 10:34:56 --> Router Class Initialized
INFO - 2020-11-06 10:34:56 --> Output Class Initialized
INFO - 2020-11-06 10:34:56 --> Security Class Initialized
DEBUG - 2020-11-06 10:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 10:34:56 --> Input Class Initialized
INFO - 2020-11-06 10:34:56 --> Language Class Initialized
INFO - 2020-11-06 10:34:56 --> Loader Class Initialized
INFO - 2020-11-06 10:34:56 --> Helper loaded: url_helper
INFO - 2020-11-06 10:34:56 --> Database Driver Class Initialized
INFO - 2020-11-06 10:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 10:34:56 --> Email Class Initialized
INFO - 2020-11-06 10:34:56 --> Controller Class Initialized
DEBUG - 2020-11-06 10:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 10:34:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 10:34:56 --> Model Class Initialized
INFO - 2020-11-06 10:34:56 --> Model Class Initialized
ERROR - 2020-11-06 10:34:56 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 404
ERROR - 2020-11-06 10:34:56 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-06 10:34:58 --> Final output sent to browser
DEBUG - 2020-11-06 10:34:58 --> Total execution time: 1.4851
ERROR - 2020-11-06 10:43:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 10:43:52 --> Config Class Initialized
INFO - 2020-11-06 10:43:52 --> Hooks Class Initialized
DEBUG - 2020-11-06 10:43:52 --> UTF-8 Support Enabled
INFO - 2020-11-06 10:43:52 --> Utf8 Class Initialized
INFO - 2020-11-06 10:43:52 --> URI Class Initialized
INFO - 2020-11-06 10:43:52 --> Router Class Initialized
INFO - 2020-11-06 10:43:52 --> Output Class Initialized
INFO - 2020-11-06 10:43:52 --> Security Class Initialized
DEBUG - 2020-11-06 10:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 10:43:52 --> Input Class Initialized
INFO - 2020-11-06 10:43:52 --> Language Class Initialized
INFO - 2020-11-06 10:43:52 --> Loader Class Initialized
INFO - 2020-11-06 10:43:52 --> Helper loaded: url_helper
INFO - 2020-11-06 10:43:52 --> Database Driver Class Initialized
INFO - 2020-11-06 10:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 10:43:52 --> Email Class Initialized
INFO - 2020-11-06 10:43:52 --> Controller Class Initialized
DEBUG - 2020-11-06 10:43:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 10:43:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 10:43:52 --> Model Class Initialized
INFO - 2020-11-06 10:43:52 --> Model Class Initialized
ERROR - 2020-11-06 10:43:52 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_clients() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 10:43:52 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 91
INFO - 2020-11-06 10:43:53 --> Final output sent to browser
DEBUG - 2020-11-06 10:43:53 --> Total execution time: 1.0368
ERROR - 2020-11-06 10:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 10:46:40 --> Config Class Initialized
INFO - 2020-11-06 10:46:40 --> Hooks Class Initialized
DEBUG - 2020-11-06 10:46:40 --> UTF-8 Support Enabled
INFO - 2020-11-06 10:46:40 --> Utf8 Class Initialized
INFO - 2020-11-06 10:46:40 --> URI Class Initialized
INFO - 2020-11-06 10:46:40 --> Router Class Initialized
INFO - 2020-11-06 10:46:40 --> Output Class Initialized
INFO - 2020-11-06 10:46:40 --> Security Class Initialized
DEBUG - 2020-11-06 10:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 10:46:40 --> Input Class Initialized
INFO - 2020-11-06 10:46:40 --> Language Class Initialized
INFO - 2020-11-06 10:46:40 --> Loader Class Initialized
INFO - 2020-11-06 10:46:40 --> Helper loaded: url_helper
INFO - 2020-11-06 10:46:40 --> Database Driver Class Initialized
INFO - 2020-11-06 10:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 10:46:40 --> Email Class Initialized
INFO - 2020-11-06 10:46:40 --> Controller Class Initialized
DEBUG - 2020-11-06 10:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 10:46:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 10:46:40 --> Model Class Initialized
INFO - 2020-11-06 10:46:40 --> Model Class Initialized
ERROR - 2020-11-06 10:46:40 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_clients() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 10:46:40 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 91
INFO - 2020-11-06 10:46:41 --> Final output sent to browser
DEBUG - 2020-11-06 10:46:41 --> Total execution time: 0.9842
ERROR - 2020-11-06 10:46:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 10:46:58 --> Config Class Initialized
INFO - 2020-11-06 10:46:58 --> Hooks Class Initialized
DEBUG - 2020-11-06 10:46:58 --> UTF-8 Support Enabled
INFO - 2020-11-06 10:46:58 --> Utf8 Class Initialized
INFO - 2020-11-06 10:46:58 --> URI Class Initialized
INFO - 2020-11-06 10:46:58 --> Router Class Initialized
INFO - 2020-11-06 10:46:58 --> Output Class Initialized
INFO - 2020-11-06 10:46:58 --> Security Class Initialized
DEBUG - 2020-11-06 10:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 10:46:58 --> Input Class Initialized
INFO - 2020-11-06 10:46:58 --> Language Class Initialized
INFO - 2020-11-06 10:46:58 --> Loader Class Initialized
INFO - 2020-11-06 10:46:58 --> Helper loaded: url_helper
INFO - 2020-11-06 10:46:58 --> Database Driver Class Initialized
INFO - 2020-11-06 10:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 10:46:58 --> Email Class Initialized
INFO - 2020-11-06 10:46:58 --> Controller Class Initialized
DEBUG - 2020-11-06 10:46:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 10:46:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 10:46:58 --> Model Class Initialized
INFO - 2020-11-06 10:46:58 --> Model Class Initialized
ERROR - 2020-11-06 10:46:58 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_clients() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 10:46:58 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 91
INFO - 2020-11-06 10:46:59 --> Final output sent to browser
DEBUG - 2020-11-06 10:46:59 --> Total execution time: 0.9687
ERROR - 2020-11-06 10:47:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 10:47:35 --> Config Class Initialized
INFO - 2020-11-06 10:47:35 --> Hooks Class Initialized
DEBUG - 2020-11-06 10:47:35 --> UTF-8 Support Enabled
INFO - 2020-11-06 10:47:35 --> Utf8 Class Initialized
INFO - 2020-11-06 10:47:35 --> URI Class Initialized
INFO - 2020-11-06 10:47:35 --> Router Class Initialized
INFO - 2020-11-06 10:47:35 --> Output Class Initialized
INFO - 2020-11-06 10:47:35 --> Security Class Initialized
DEBUG - 2020-11-06 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 10:47:35 --> Input Class Initialized
INFO - 2020-11-06 10:47:35 --> Language Class Initialized
INFO - 2020-11-06 10:47:35 --> Loader Class Initialized
INFO - 2020-11-06 10:47:35 --> Helper loaded: url_helper
INFO - 2020-11-06 10:47:35 --> Database Driver Class Initialized
INFO - 2020-11-06 10:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 10:47:35 --> Email Class Initialized
INFO - 2020-11-06 10:47:35 --> Controller Class Initialized
DEBUG - 2020-11-06 10:47:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 10:47:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 10:47:35 --> Model Class Initialized
INFO - 2020-11-06 10:47:35 --> Model Class Initialized
ERROR - 2020-11-06 10:47:35 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_clients() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 10:47:35 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 91
INFO - 2020-11-06 10:47:36 --> Final output sent to browser
DEBUG - 2020-11-06 10:47:36 --> Total execution time: 1.1000
ERROR - 2020-11-06 11:42:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:42:40 --> Config Class Initialized
INFO - 2020-11-06 11:42:40 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:42:40 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:42:40 --> Utf8 Class Initialized
INFO - 2020-11-06 11:42:40 --> URI Class Initialized
DEBUG - 2020-11-06 11:42:40 --> No URI present. Default controller set.
INFO - 2020-11-06 11:42:40 --> Router Class Initialized
INFO - 2020-11-06 11:42:40 --> Output Class Initialized
INFO - 2020-11-06 11:42:40 --> Security Class Initialized
DEBUG - 2020-11-06 11:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:42:40 --> Input Class Initialized
INFO - 2020-11-06 11:42:40 --> Language Class Initialized
INFO - 2020-11-06 11:42:40 --> Loader Class Initialized
INFO - 2020-11-06 11:42:40 --> Helper loaded: url_helper
INFO - 2020-11-06 11:42:40 --> Database Driver Class Initialized
INFO - 2020-11-06 11:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:42:40 --> Email Class Initialized
INFO - 2020-11-06 11:42:40 --> Controller Class Initialized
INFO - 2020-11-06 11:42:40 --> Model Class Initialized
INFO - 2020-11-06 11:42:40 --> Model Class Initialized
DEBUG - 2020-11-06 11:42:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:42:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-06 11:42:40 --> Final output sent to browser
DEBUG - 2020-11-06 11:42:40 --> Total execution time: 0.0181
ERROR - 2020-11-06 11:43:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:43:38 --> Config Class Initialized
INFO - 2020-11-06 11:43:38 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:43:38 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:43:38 --> Utf8 Class Initialized
INFO - 2020-11-06 11:43:38 --> URI Class Initialized
INFO - 2020-11-06 11:43:38 --> Router Class Initialized
INFO - 2020-11-06 11:43:38 --> Output Class Initialized
INFO - 2020-11-06 11:43:38 --> Security Class Initialized
DEBUG - 2020-11-06 11:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:43:38 --> Input Class Initialized
INFO - 2020-11-06 11:43:38 --> Language Class Initialized
INFO - 2020-11-06 11:43:38 --> Loader Class Initialized
INFO - 2020-11-06 11:43:38 --> Helper loaded: url_helper
INFO - 2020-11-06 11:43:38 --> Database Driver Class Initialized
INFO - 2020-11-06 11:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:43:38 --> Email Class Initialized
INFO - 2020-11-06 11:43:38 --> Controller Class Initialized
INFO - 2020-11-06 11:43:38 --> Model Class Initialized
INFO - 2020-11-06 11:43:38 --> Model Class Initialized
DEBUG - 2020-11-06 11:43:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-06 11:43:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:43:39 --> Config Class Initialized
INFO - 2020-11-06 11:43:39 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:43:39 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:43:39 --> Utf8 Class Initialized
INFO - 2020-11-06 11:43:39 --> URI Class Initialized
INFO - 2020-11-06 11:43:39 --> Router Class Initialized
INFO - 2020-11-06 11:43:39 --> Output Class Initialized
INFO - 2020-11-06 11:43:39 --> Security Class Initialized
DEBUG - 2020-11-06 11:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:43:39 --> Input Class Initialized
INFO - 2020-11-06 11:43:39 --> Language Class Initialized
INFO - 2020-11-06 11:43:39 --> Loader Class Initialized
INFO - 2020-11-06 11:43:39 --> Helper loaded: url_helper
INFO - 2020-11-06 11:43:39 --> Database Driver Class Initialized
INFO - 2020-11-06 11:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:43:39 --> Email Class Initialized
INFO - 2020-11-06 11:43:39 --> Controller Class Initialized
INFO - 2020-11-06 11:43:39 --> Model Class Initialized
INFO - 2020-11-06 11:43:39 --> Model Class Initialized
DEBUG - 2020-11-06 11:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:43:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:43:39 --> Model Class Initialized
INFO - 2020-11-06 11:43:39 --> Final output sent to browser
DEBUG - 2020-11-06 11:43:39 --> Total execution time: 0.0226
ERROR - 2020-11-06 11:43:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:43:39 --> Config Class Initialized
INFO - 2020-11-06 11:43:39 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:43:39 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:43:39 --> Utf8 Class Initialized
INFO - 2020-11-06 11:43:39 --> URI Class Initialized
INFO - 2020-11-06 11:43:39 --> Router Class Initialized
INFO - 2020-11-06 11:43:39 --> Output Class Initialized
INFO - 2020-11-06 11:43:39 --> Security Class Initialized
DEBUG - 2020-11-06 11:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:43:39 --> Input Class Initialized
INFO - 2020-11-06 11:43:39 --> Language Class Initialized
INFO - 2020-11-06 11:43:39 --> Loader Class Initialized
INFO - 2020-11-06 11:43:39 --> Helper loaded: url_helper
INFO - 2020-11-06 11:43:39 --> Database Driver Class Initialized
INFO - 2020-11-06 11:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:43:39 --> Email Class Initialized
INFO - 2020-11-06 11:43:39 --> Controller Class Initialized
DEBUG - 2020-11-06 11:43:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:43:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:43:39 --> Model Class Initialized
INFO - 2020-11-06 11:43:39 --> Model Class Initialized
INFO - 2020-11-06 11:43:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-06 11:43:39 --> Final output sent to browser
DEBUG - 2020-11-06 11:43:39 --> Total execution time: 0.0336
ERROR - 2020-11-06 11:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:43:47 --> Config Class Initialized
INFO - 2020-11-06 11:43:47 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:43:47 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:43:47 --> Utf8 Class Initialized
INFO - 2020-11-06 11:43:47 --> URI Class Initialized
INFO - 2020-11-06 11:43:47 --> Router Class Initialized
INFO - 2020-11-06 11:43:47 --> Output Class Initialized
INFO - 2020-11-06 11:43:47 --> Security Class Initialized
DEBUG - 2020-11-06 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:43:47 --> Input Class Initialized
INFO - 2020-11-06 11:43:47 --> Language Class Initialized
INFO - 2020-11-06 11:43:47 --> Loader Class Initialized
INFO - 2020-11-06 11:43:47 --> Helper loaded: url_helper
INFO - 2020-11-06 11:43:47 --> Database Driver Class Initialized
INFO - 2020-11-06 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:43:47 --> Email Class Initialized
INFO - 2020-11-06 11:43:47 --> Controller Class Initialized
DEBUG - 2020-11-06 11:43:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:43:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:43:47 --> Model Class Initialized
INFO - 2020-11-06 11:43:47 --> Model Class Initialized
INFO - 2020-11-06 11:43:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-06 11:43:47 --> Final output sent to browser
DEBUG - 2020-11-06 11:43:47 --> Total execution time: 0.0235
ERROR - 2020-11-06 11:44:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:44:04 --> Config Class Initialized
INFO - 2020-11-06 11:44:04 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:44:04 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:44:04 --> Utf8 Class Initialized
INFO - 2020-11-06 11:44:04 --> URI Class Initialized
INFO - 2020-11-06 11:44:04 --> Router Class Initialized
INFO - 2020-11-06 11:44:04 --> Output Class Initialized
INFO - 2020-11-06 11:44:04 --> Security Class Initialized
DEBUG - 2020-11-06 11:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:44:04 --> Input Class Initialized
INFO - 2020-11-06 11:44:04 --> Language Class Initialized
INFO - 2020-11-06 11:44:04 --> Loader Class Initialized
INFO - 2020-11-06 11:44:04 --> Helper loaded: url_helper
INFO - 2020-11-06 11:44:04 --> Database Driver Class Initialized
INFO - 2020-11-06 11:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:44:04 --> Email Class Initialized
INFO - 2020-11-06 11:44:04 --> Controller Class Initialized
DEBUG - 2020-11-06 11:44:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:44:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:44:04 --> Model Class Initialized
INFO - 2020-11-06 11:44:04 --> Model Class Initialized
ERROR - 2020-11-06 11:44:04 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_clients() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 11:44:04 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 91
INFO - 2020-11-06 11:44:06 --> Final output sent to browser
DEBUG - 2020-11-06 11:44:06 --> Total execution time: 1.3647
ERROR - 2020-11-06 11:49:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:49:54 --> Config Class Initialized
INFO - 2020-11-06 11:49:54 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:49:54 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:49:54 --> Utf8 Class Initialized
INFO - 2020-11-06 11:49:54 --> URI Class Initialized
INFO - 2020-11-06 11:49:54 --> Router Class Initialized
INFO - 2020-11-06 11:49:54 --> Output Class Initialized
INFO - 2020-11-06 11:49:54 --> Security Class Initialized
DEBUG - 2020-11-06 11:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:49:54 --> Input Class Initialized
INFO - 2020-11-06 11:49:54 --> Language Class Initialized
INFO - 2020-11-06 11:49:54 --> Loader Class Initialized
INFO - 2020-11-06 11:49:54 --> Helper loaded: url_helper
INFO - 2020-11-06 11:49:54 --> Database Driver Class Initialized
INFO - 2020-11-06 11:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:49:54 --> Email Class Initialized
INFO - 2020-11-06 11:49:54 --> Controller Class Initialized
DEBUG - 2020-11-06 11:49:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:49:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:49:54 --> Model Class Initialized
INFO - 2020-11-06 11:49:54 --> Model Class Initialized
ERROR - 2020-11-06 11:49:54 --> Severity: Runtime Notice --> Non-static method Purlem::get_campaign() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 11:49:54 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 51
INFO - 2020-11-06 11:49:55 --> Final output sent to browser
DEBUG - 2020-11-06 11:49:55 --> Total execution time: 1.0449
ERROR - 2020-11-06 11:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:51:36 --> Config Class Initialized
INFO - 2020-11-06 11:51:36 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:51:36 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:51:36 --> Utf8 Class Initialized
INFO - 2020-11-06 11:51:36 --> URI Class Initialized
INFO - 2020-11-06 11:51:36 --> Router Class Initialized
INFO - 2020-11-06 11:51:36 --> Output Class Initialized
INFO - 2020-11-06 11:51:36 --> Security Class Initialized
DEBUG - 2020-11-06 11:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:51:36 --> Input Class Initialized
INFO - 2020-11-06 11:51:36 --> Language Class Initialized
INFO - 2020-11-06 11:51:36 --> Loader Class Initialized
INFO - 2020-11-06 11:51:36 --> Helper loaded: url_helper
INFO - 2020-11-06 11:51:36 --> Database Driver Class Initialized
INFO - 2020-11-06 11:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:51:36 --> Email Class Initialized
INFO - 2020-11-06 11:51:36 --> Controller Class Initialized
DEBUG - 2020-11-06 11:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:51:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:51:36 --> Model Class Initialized
INFO - 2020-11-06 11:51:36 --> Model Class Initialized
ERROR - 2020-11-06 11:51:36 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaign_contacts() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 11:51:36 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 59
INFO - 2020-11-06 11:51:38 --> Final output sent to browser
DEBUG - 2020-11-06 11:51:38 --> Total execution time: 2.0351
ERROR - 2020-11-06 11:58:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:58:25 --> Config Class Initialized
INFO - 2020-11-06 11:58:25 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:58:25 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:58:25 --> Utf8 Class Initialized
INFO - 2020-11-06 11:58:25 --> URI Class Initialized
INFO - 2020-11-06 11:58:25 --> Router Class Initialized
INFO - 2020-11-06 11:58:25 --> Output Class Initialized
INFO - 2020-11-06 11:58:25 --> Security Class Initialized
DEBUG - 2020-11-06 11:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:58:25 --> Input Class Initialized
INFO - 2020-11-06 11:58:25 --> Language Class Initialized
INFO - 2020-11-06 11:58:25 --> Loader Class Initialized
INFO - 2020-11-06 11:58:25 --> Helper loaded: url_helper
INFO - 2020-11-06 11:58:25 --> Database Driver Class Initialized
INFO - 2020-11-06 11:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:58:25 --> Email Class Initialized
INFO - 2020-11-06 11:58:25 --> Controller Class Initialized
DEBUG - 2020-11-06 11:58:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:58:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:58:25 --> Model Class Initialized
INFO - 2020-11-06 11:58:25 --> Model Class Initialized
ERROR - 2020-11-06 11:58:25 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 11:58:25 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-06 11:58:27 --> Final output sent to browser
DEBUG - 2020-11-06 11:58:27 --> Total execution time: 2.0734
ERROR - 2020-11-06 11:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 11:59:33 --> Config Class Initialized
INFO - 2020-11-06 11:59:33 --> Hooks Class Initialized
DEBUG - 2020-11-06 11:59:33 --> UTF-8 Support Enabled
INFO - 2020-11-06 11:59:33 --> Utf8 Class Initialized
INFO - 2020-11-06 11:59:33 --> URI Class Initialized
INFO - 2020-11-06 11:59:33 --> Router Class Initialized
INFO - 2020-11-06 11:59:33 --> Output Class Initialized
INFO - 2020-11-06 11:59:33 --> Security Class Initialized
DEBUG - 2020-11-06 11:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 11:59:33 --> Input Class Initialized
INFO - 2020-11-06 11:59:33 --> Language Class Initialized
INFO - 2020-11-06 11:59:33 --> Loader Class Initialized
INFO - 2020-11-06 11:59:33 --> Helper loaded: url_helper
INFO - 2020-11-06 11:59:33 --> Database Driver Class Initialized
INFO - 2020-11-06 11:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 11:59:33 --> Email Class Initialized
INFO - 2020-11-06 11:59:33 --> Controller Class Initialized
DEBUG - 2020-11-06 11:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 11:59:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 11:59:33 --> Model Class Initialized
INFO - 2020-11-06 11:59:33 --> Model Class Initialized
ERROR - 2020-11-06 11:59:33 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 11:59:33 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-06 11:59:34 --> Final output sent to browser
DEBUG - 2020-11-06 11:59:34 --> Total execution time: 0.9983
ERROR - 2020-11-06 12:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-06 12:17:24 --> Config Class Initialized
INFO - 2020-11-06 12:17:24 --> Hooks Class Initialized
DEBUG - 2020-11-06 12:17:24 --> UTF-8 Support Enabled
INFO - 2020-11-06 12:17:24 --> Utf8 Class Initialized
INFO - 2020-11-06 12:17:24 --> URI Class Initialized
INFO - 2020-11-06 12:17:24 --> Router Class Initialized
INFO - 2020-11-06 12:17:24 --> Output Class Initialized
INFO - 2020-11-06 12:17:24 --> Security Class Initialized
DEBUG - 2020-11-06 12:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-06 12:17:24 --> Input Class Initialized
INFO - 2020-11-06 12:17:24 --> Language Class Initialized
INFO - 2020-11-06 12:17:24 --> Loader Class Initialized
INFO - 2020-11-06 12:17:24 --> Helper loaded: url_helper
INFO - 2020-11-06 12:17:24 --> Database Driver Class Initialized
INFO - 2020-11-06 12:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-06 12:17:24 --> Email Class Initialized
INFO - 2020-11-06 12:17:24 --> Controller Class Initialized
DEBUG - 2020-11-06 12:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-06 12:17:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-06 12:17:24 --> Model Class Initialized
INFO - 2020-11-06 12:17:24 --> Model Class Initialized
ERROR - 2020-11-06 12:17:24 --> Severity: Runtime Notice --> Non-static method Purlem::get_contact() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 403
ERROR - 2020-11-06 12:17:24 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 17
INFO - 2020-11-06 12:17:25 --> Final output sent to browser
DEBUG - 2020-11-06 12:17:25 --> Total execution time: 1.2456
