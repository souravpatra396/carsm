<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-05 07:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:37:06 --> Config Class Initialized
INFO - 2020-10-05 07:37:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:37:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:37:06 --> Utf8 Class Initialized
INFO - 2020-10-05 07:37:06 --> URI Class Initialized
DEBUG - 2020-10-05 07:37:06 --> No URI present. Default controller set.
INFO - 2020-10-05 07:37:06 --> Router Class Initialized
INFO - 2020-10-05 07:37:06 --> Output Class Initialized
INFO - 2020-10-05 07:37:06 --> Security Class Initialized
DEBUG - 2020-10-05 07:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:37:06 --> Input Class Initialized
INFO - 2020-10-05 07:37:06 --> Language Class Initialized
INFO - 2020-10-05 07:37:07 --> Loader Class Initialized
INFO - 2020-10-05 07:37:07 --> Helper loaded: url_helper
INFO - 2020-10-05 07:37:07 --> Database Driver Class Initialized
INFO - 2020-10-05 07:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:37:07 --> Email Class Initialized
INFO - 2020-10-05 07:37:07 --> Controller Class Initialized
INFO - 2020-10-05 07:37:07 --> Model Class Initialized
INFO - 2020-10-05 07:37:07 --> Model Class Initialized
DEBUG - 2020-10-05 07:37:07 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:37:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 07:37:07 --> Final output sent to browser
DEBUG - 2020-10-05 07:37:07 --> Total execution time: 0.1243
ERROR - 2020-10-05 07:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:37:26 --> Config Class Initialized
INFO - 2020-10-05 07:37:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:37:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:37:26 --> Utf8 Class Initialized
INFO - 2020-10-05 07:37:26 --> URI Class Initialized
INFO - 2020-10-05 07:37:26 --> Router Class Initialized
INFO - 2020-10-05 07:37:26 --> Output Class Initialized
INFO - 2020-10-05 07:37:26 --> Security Class Initialized
DEBUG - 2020-10-05 07:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:37:26 --> Input Class Initialized
INFO - 2020-10-05 07:37:26 --> Language Class Initialized
INFO - 2020-10-05 07:37:26 --> Loader Class Initialized
INFO - 2020-10-05 07:37:26 --> Helper loaded: url_helper
ERROR - 2020-10-05 07:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:37:26 --> Config Class Initialized
INFO - 2020-10-05 07:37:26 --> Hooks Class Initialized
INFO - 2020-10-05 07:37:26 --> Database Driver Class Initialized
DEBUG - 2020-10-05 07:37:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:37:26 --> Utf8 Class Initialized
INFO - 2020-10-05 07:37:26 --> URI Class Initialized
INFO - 2020-10-05 07:37:26 --> Router Class Initialized
INFO - 2020-10-05 07:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:37:26 --> Output Class Initialized
INFO - 2020-10-05 07:37:26 --> Security Class Initialized
DEBUG - 2020-10-05 07:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:37:26 --> Input Class Initialized
INFO - 2020-10-05 07:37:26 --> Language Class Initialized
INFO - 2020-10-05 07:37:26 --> Email Class Initialized
INFO - 2020-10-05 07:37:26 --> Controller Class Initialized
INFO - 2020-10-05 07:37:26 --> Model Class Initialized
INFO - 2020-10-05 07:37:26 --> Model Class Initialized
DEBUG - 2020-10-05 07:37:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:37:26 --> Loader Class Initialized
INFO - 2020-10-05 07:37:26 --> Helper loaded: url_helper
INFO - 2020-10-05 07:37:26 --> Database Driver Class Initialized
INFO - 2020-10-05 07:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:37:26 --> Email Class Initialized
INFO - 2020-10-05 07:37:26 --> Controller Class Initialized
INFO - 2020-10-05 07:37:26 --> Model Class Initialized
INFO - 2020-10-05 07:37:26 --> Model Class Initialized
DEBUG - 2020-10-05 07:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:37:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:37:26 --> Model Class Initialized
INFO - 2020-10-05 07:37:26 --> Final output sent to browser
DEBUG - 2020-10-05 07:37:26 --> Total execution time: 0.0434
ERROR - 2020-10-05 07:37:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:37:26 --> Config Class Initialized
INFO - 2020-10-05 07:37:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:37:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:37:26 --> Utf8 Class Initialized
INFO - 2020-10-05 07:37:26 --> URI Class Initialized
INFO - 2020-10-05 07:37:26 --> Router Class Initialized
INFO - 2020-10-05 07:37:26 --> Output Class Initialized
INFO - 2020-10-05 07:37:26 --> Security Class Initialized
DEBUG - 2020-10-05 07:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:37:26 --> Input Class Initialized
INFO - 2020-10-05 07:37:26 --> Language Class Initialized
INFO - 2020-10-05 07:37:26 --> Loader Class Initialized
INFO - 2020-10-05 07:37:26 --> Helper loaded: url_helper
INFO - 2020-10-05 07:37:26 --> Database Driver Class Initialized
INFO - 2020-10-05 07:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:37:26 --> Email Class Initialized
INFO - 2020-10-05 07:37:26 --> Controller Class Initialized
DEBUG - 2020-10-05 07:37:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:37:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:37:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 07:37:26 --> Final output sent to browser
DEBUG - 2020-10-05 07:37:26 --> Total execution time: 0.0441
ERROR - 2020-10-05 07:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:37:32 --> Config Class Initialized
INFO - 2020-10-05 07:37:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:37:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:37:32 --> Utf8 Class Initialized
INFO - 2020-10-05 07:37:32 --> URI Class Initialized
INFO - 2020-10-05 07:37:32 --> Router Class Initialized
INFO - 2020-10-05 07:37:32 --> Output Class Initialized
INFO - 2020-10-05 07:37:32 --> Security Class Initialized
DEBUG - 2020-10-05 07:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:37:32 --> Input Class Initialized
INFO - 2020-10-05 07:37:32 --> Language Class Initialized
INFO - 2020-10-05 07:37:32 --> Loader Class Initialized
INFO - 2020-10-05 07:37:32 --> Helper loaded: url_helper
INFO - 2020-10-05 07:37:32 --> Database Driver Class Initialized
INFO - 2020-10-05 07:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:37:32 --> Email Class Initialized
INFO - 2020-10-05 07:37:32 --> Controller Class Initialized
DEBUG - 2020-10-05 07:37:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:37:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:37:32 --> Model Class Initialized
INFO - 2020-10-05 07:37:32 --> Model Class Initialized
INFO - 2020-10-05 07:37:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:37:32 --> Final output sent to browser
DEBUG - 2020-10-05 07:37:32 --> Total execution time: 0.0439
ERROR - 2020-10-05 07:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:37:53 --> Config Class Initialized
INFO - 2020-10-05 07:37:53 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:37:53 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:37:53 --> Utf8 Class Initialized
INFO - 2020-10-05 07:37:53 --> URI Class Initialized
INFO - 2020-10-05 07:37:53 --> Router Class Initialized
INFO - 2020-10-05 07:37:53 --> Output Class Initialized
INFO - 2020-10-05 07:37:53 --> Security Class Initialized
DEBUG - 2020-10-05 07:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:37:53 --> Input Class Initialized
INFO - 2020-10-05 07:37:53 --> Language Class Initialized
INFO - 2020-10-05 07:37:53 --> Loader Class Initialized
INFO - 2020-10-05 07:37:53 --> Helper loaded: url_helper
INFO - 2020-10-05 07:37:53 --> Database Driver Class Initialized
INFO - 2020-10-05 07:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:37:53 --> Email Class Initialized
INFO - 2020-10-05 07:37:53 --> Controller Class Initialized
DEBUG - 2020-10-05 07:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:37:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:37:53 --> Model Class Initialized
INFO - 2020-10-05 07:37:53 --> Model Class Initialized
INFO - 2020-10-05 07:37:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 07:37:53 --> Final output sent to browser
DEBUG - 2020-10-05 07:37:53 --> Total execution time: 0.0325
ERROR - 2020-10-05 07:39:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:39:38 --> Config Class Initialized
INFO - 2020-10-05 07:39:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:39:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:39:38 --> Utf8 Class Initialized
INFO - 2020-10-05 07:39:38 --> URI Class Initialized
INFO - 2020-10-05 07:39:38 --> Router Class Initialized
INFO - 2020-10-05 07:39:38 --> Output Class Initialized
INFO - 2020-10-05 07:39:38 --> Security Class Initialized
DEBUG - 2020-10-05 07:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:39:38 --> Input Class Initialized
INFO - 2020-10-05 07:39:38 --> Language Class Initialized
INFO - 2020-10-05 07:39:38 --> Loader Class Initialized
INFO - 2020-10-05 07:39:38 --> Helper loaded: url_helper
INFO - 2020-10-05 07:39:38 --> Database Driver Class Initialized
INFO - 2020-10-05 07:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:39:38 --> Email Class Initialized
INFO - 2020-10-05 07:39:38 --> Controller Class Initialized
DEBUG - 2020-10-05 07:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:39:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:39:38 --> Model Class Initialized
INFO - 2020-10-05 07:39:38 --> Model Class Initialized
INFO - 2020-10-05 07:39:38 --> Model Class Initialized
ERROR - 2020-10-05 07:39:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('sukharanjan.mahata@gmail.com','Sukharanjan Mahata','8658658584','College More','9bd9986e',4,)
INFO - 2020-10-05 07:39:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 07:39:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:39:42 --> Config Class Initialized
INFO - 2020-10-05 07:39:42 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:39:42 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:39:42 --> Utf8 Class Initialized
INFO - 2020-10-05 07:39:42 --> URI Class Initialized
INFO - 2020-10-05 07:39:42 --> Router Class Initialized
INFO - 2020-10-05 07:39:42 --> Output Class Initialized
INFO - 2020-10-05 07:39:42 --> Security Class Initialized
DEBUG - 2020-10-05 07:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:39:42 --> Input Class Initialized
INFO - 2020-10-05 07:39:42 --> Language Class Initialized
INFO - 2020-10-05 07:39:42 --> Loader Class Initialized
INFO - 2020-10-05 07:39:42 --> Helper loaded: url_helper
INFO - 2020-10-05 07:39:42 --> Database Driver Class Initialized
INFO - 2020-10-05 07:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:39:42 --> Email Class Initialized
INFO - 2020-10-05 07:39:42 --> Controller Class Initialized
DEBUG - 2020-10-05 07:39:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:39:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:39:42 --> Model Class Initialized
INFO - 2020-10-05 07:39:42 --> Model Class Initialized
INFO - 2020-10-05 07:39:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 07:39:42 --> Final output sent to browser
DEBUG - 2020-10-05 07:39:42 --> Total execution time: 0.0189
ERROR - 2020-10-05 07:39:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:39:55 --> Config Class Initialized
INFO - 2020-10-05 07:39:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:39:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:39:55 --> Utf8 Class Initialized
INFO - 2020-10-05 07:39:55 --> URI Class Initialized
INFO - 2020-10-05 07:39:55 --> Router Class Initialized
INFO - 2020-10-05 07:39:55 --> Output Class Initialized
INFO - 2020-10-05 07:39:55 --> Security Class Initialized
DEBUG - 2020-10-05 07:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:39:55 --> Input Class Initialized
INFO - 2020-10-05 07:39:55 --> Language Class Initialized
INFO - 2020-10-05 07:39:55 --> Loader Class Initialized
INFO - 2020-10-05 07:39:55 --> Helper loaded: url_helper
INFO - 2020-10-05 07:39:55 --> Database Driver Class Initialized
INFO - 2020-10-05 07:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:39:55 --> Email Class Initialized
INFO - 2020-10-05 07:39:55 --> Controller Class Initialized
DEBUG - 2020-10-05 07:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:39:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:39:55 --> Model Class Initialized
INFO - 2020-10-05 07:39:55 --> Model Class Initialized
INFO - 2020-10-05 07:39:55 --> Model Class Initialized
ERROR - 2020-10-05 07:39:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('sukharanjan.mahata@gmail.com','Sukharanjan Mahata','8658658584','College More','381f7ef9',5,)
INFO - 2020-10-05 07:39:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 07:40:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:01 --> Config Class Initialized
INFO - 2020-10-05 07:40:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:01 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:01 --> URI Class Initialized
INFO - 2020-10-05 07:40:01 --> Router Class Initialized
INFO - 2020-10-05 07:40:01 --> Output Class Initialized
INFO - 2020-10-05 07:40:01 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:01 --> Input Class Initialized
INFO - 2020-10-05 07:40:01 --> Language Class Initialized
INFO - 2020-10-05 07:40:01 --> Loader Class Initialized
INFO - 2020-10-05 07:40:01 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:01 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:01 --> Email Class Initialized
INFO - 2020-10-05 07:40:01 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:01 --> Model Class Initialized
INFO - 2020-10-05 07:40:01 --> Model Class Initialized
INFO - 2020-10-05 07:40:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 07:40:01 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:01 --> Total execution time: 0.0409
ERROR - 2020-10-05 07:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:29 --> Config Class Initialized
INFO - 2020-10-05 07:40:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:29 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:29 --> URI Class Initialized
INFO - 2020-10-05 07:40:29 --> Router Class Initialized
INFO - 2020-10-05 07:40:29 --> Output Class Initialized
INFO - 2020-10-05 07:40:29 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:29 --> Input Class Initialized
INFO - 2020-10-05 07:40:29 --> Language Class Initialized
INFO - 2020-10-05 07:40:29 --> Loader Class Initialized
INFO - 2020-10-05 07:40:29 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:29 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:29 --> Email Class Initialized
INFO - 2020-10-05 07:40:29 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:29 --> Model Class Initialized
INFO - 2020-10-05 07:40:29 --> Model Class Initialized
INFO - 2020-10-05 07:40:29 --> Model Class Initialized
ERROR - 2020-10-05 07:40:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('sukharanjan.mahata@gmail.com','Sukharanjan Mahata','8658658584','College More','08485825',6,)
INFO - 2020-10-05 07:40:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 07:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:34 --> Config Class Initialized
INFO - 2020-10-05 07:40:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:34 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:34 --> URI Class Initialized
INFO - 2020-10-05 07:40:34 --> Router Class Initialized
INFO - 2020-10-05 07:40:34 --> Output Class Initialized
INFO - 2020-10-05 07:40:34 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:34 --> Input Class Initialized
INFO - 2020-10-05 07:40:34 --> Language Class Initialized
INFO - 2020-10-05 07:40:34 --> Loader Class Initialized
INFO - 2020-10-05 07:40:34 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:34 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:34 --> Email Class Initialized
INFO - 2020-10-05 07:40:34 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:34 --> Model Class Initialized
INFO - 2020-10-05 07:40:34 --> Model Class Initialized
INFO - 2020-10-05 07:40:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 07:40:34 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:34 --> Total execution time: 0.0190
ERROR - 2020-10-05 07:40:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:38 --> Config Class Initialized
INFO - 2020-10-05 07:40:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:38 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:38 --> URI Class Initialized
INFO - 2020-10-05 07:40:38 --> Router Class Initialized
INFO - 2020-10-05 07:40:38 --> Output Class Initialized
INFO - 2020-10-05 07:40:38 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:38 --> Input Class Initialized
INFO - 2020-10-05 07:40:38 --> Language Class Initialized
INFO - 2020-10-05 07:40:38 --> Loader Class Initialized
INFO - 2020-10-05 07:40:38 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:38 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:38 --> Email Class Initialized
INFO - 2020-10-05 07:40:38 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:38 --> Model Class Initialized
INFO - 2020-10-05 07:40:38 --> Model Class Initialized
INFO - 2020-10-05 07:40:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:40:38 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:38 --> Total execution time: 0.0278
ERROR - 2020-10-05 07:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:41 --> Config Class Initialized
INFO - 2020-10-05 07:40:41 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:41 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:41 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:41 --> URI Class Initialized
INFO - 2020-10-05 07:40:41 --> Router Class Initialized
INFO - 2020-10-05 07:40:41 --> Output Class Initialized
INFO - 2020-10-05 07:40:41 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:41 --> Input Class Initialized
INFO - 2020-10-05 07:40:41 --> Language Class Initialized
INFO - 2020-10-05 07:40:41 --> Loader Class Initialized
INFO - 2020-10-05 07:40:41 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:41 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:41 --> Email Class Initialized
INFO - 2020-10-05 07:40:41 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:41 --> Model Class Initialized
INFO - 2020-10-05 07:40:41 --> Model Class Initialized
INFO - 2020-10-05 07:40:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 07:40:41 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:41 --> Total execution time: 0.0372
ERROR - 2020-10-05 07:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:43 --> Config Class Initialized
INFO - 2020-10-05 07:40:43 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:43 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:43 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:43 --> URI Class Initialized
INFO - 2020-10-05 07:40:43 --> Router Class Initialized
INFO - 2020-10-05 07:40:43 --> Output Class Initialized
INFO - 2020-10-05 07:40:43 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:43 --> Input Class Initialized
INFO - 2020-10-05 07:40:43 --> Language Class Initialized
INFO - 2020-10-05 07:40:43 --> Loader Class Initialized
INFO - 2020-10-05 07:40:43 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:43 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:43 --> Email Class Initialized
INFO - 2020-10-05 07:40:43 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:43 --> Model Class Initialized
INFO - 2020-10-05 07:40:43 --> Model Class Initialized
INFO - 2020-10-05 07:40:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:40:43 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:43 --> Total execution time: 0.0205
ERROR - 2020-10-05 07:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:45 --> Config Class Initialized
INFO - 2020-10-05 07:40:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:45 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:45 --> URI Class Initialized
INFO - 2020-10-05 07:40:45 --> Router Class Initialized
INFO - 2020-10-05 07:40:45 --> Output Class Initialized
INFO - 2020-10-05 07:40:45 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:45 --> Input Class Initialized
INFO - 2020-10-05 07:40:45 --> Language Class Initialized
INFO - 2020-10-05 07:40:45 --> Loader Class Initialized
INFO - 2020-10-05 07:40:45 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:45 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:45 --> Email Class Initialized
INFO - 2020-10-05 07:40:45 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:45 --> Model Class Initialized
INFO - 2020-10-05 07:40:45 --> Model Class Initialized
INFO - 2020-10-05 07:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 07:40:45 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:45 --> Total execution time: 0.0276
ERROR - 2020-10-05 07:40:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:40:47 --> Config Class Initialized
INFO - 2020-10-05 07:40:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:40:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:40:47 --> Utf8 Class Initialized
INFO - 2020-10-05 07:40:47 --> URI Class Initialized
INFO - 2020-10-05 07:40:47 --> Router Class Initialized
INFO - 2020-10-05 07:40:47 --> Output Class Initialized
INFO - 2020-10-05 07:40:47 --> Security Class Initialized
DEBUG - 2020-10-05 07:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:40:47 --> Input Class Initialized
INFO - 2020-10-05 07:40:47 --> Language Class Initialized
INFO - 2020-10-05 07:40:47 --> Loader Class Initialized
INFO - 2020-10-05 07:40:47 --> Helper loaded: url_helper
INFO - 2020-10-05 07:40:47 --> Database Driver Class Initialized
INFO - 2020-10-05 07:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:40:47 --> Email Class Initialized
INFO - 2020-10-05 07:40:47 --> Controller Class Initialized
DEBUG - 2020-10-05 07:40:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:40:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:40:47 --> Model Class Initialized
INFO - 2020-10-05 07:40:47 --> Model Class Initialized
INFO - 2020-10-05 07:40:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:40:47 --> Final output sent to browser
DEBUG - 2020-10-05 07:40:47 --> Total execution time: 0.0226
ERROR - 2020-10-05 07:41:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:15 --> Config Class Initialized
INFO - 2020-10-05 07:41:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:15 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:15 --> URI Class Initialized
INFO - 2020-10-05 07:41:15 --> Router Class Initialized
INFO - 2020-10-05 07:41:15 --> Output Class Initialized
INFO - 2020-10-05 07:41:15 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:16 --> Input Class Initialized
INFO - 2020-10-05 07:41:16 --> Language Class Initialized
INFO - 2020-10-05 07:41:16 --> Loader Class Initialized
INFO - 2020-10-05 07:41:16 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:16 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:16 --> Email Class Initialized
INFO - 2020-10-05 07:41:16 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:16 --> Model Class Initialized
INFO - 2020-10-05 07:41:16 --> Model Class Initialized
INFO - 2020-10-05 07:41:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 07:41:16 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:16 --> Total execution time: 0.0198
ERROR - 2020-10-05 07:41:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:20 --> Config Class Initialized
INFO - 2020-10-05 07:41:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:20 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:20 --> URI Class Initialized
INFO - 2020-10-05 07:41:20 --> Router Class Initialized
INFO - 2020-10-05 07:41:20 --> Output Class Initialized
INFO - 2020-10-05 07:41:20 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:20 --> Input Class Initialized
INFO - 2020-10-05 07:41:20 --> Language Class Initialized
INFO - 2020-10-05 07:41:20 --> Loader Class Initialized
INFO - 2020-10-05 07:41:20 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:20 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:20 --> Email Class Initialized
INFO - 2020-10-05 07:41:20 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:20 --> Model Class Initialized
INFO - 2020-10-05 07:41:20 --> Model Class Initialized
INFO - 2020-10-05 07:41:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:41:20 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:20 --> Total execution time: 0.0201
ERROR - 2020-10-05 07:41:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:22 --> Config Class Initialized
INFO - 2020-10-05 07:41:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:22 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:22 --> URI Class Initialized
INFO - 2020-10-05 07:41:22 --> Router Class Initialized
INFO - 2020-10-05 07:41:22 --> Output Class Initialized
INFO - 2020-10-05 07:41:22 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:22 --> Input Class Initialized
INFO - 2020-10-05 07:41:22 --> Language Class Initialized
INFO - 2020-10-05 07:41:22 --> Loader Class Initialized
INFO - 2020-10-05 07:41:22 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:22 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:22 --> Email Class Initialized
INFO - 2020-10-05 07:41:22 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:22 --> Model Class Initialized
INFO - 2020-10-05 07:41:22 --> Model Class Initialized
INFO - 2020-10-05 07:41:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 07:41:22 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:22 --> Total execution time: 0.0183
ERROR - 2020-10-05 07:41:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:28 --> Config Class Initialized
INFO - 2020-10-05 07:41:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:28 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:28 --> URI Class Initialized
INFO - 2020-10-05 07:41:28 --> Router Class Initialized
INFO - 2020-10-05 07:41:28 --> Output Class Initialized
INFO - 2020-10-05 07:41:28 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:28 --> Input Class Initialized
INFO - 2020-10-05 07:41:28 --> Language Class Initialized
INFO - 2020-10-05 07:41:28 --> Loader Class Initialized
INFO - 2020-10-05 07:41:28 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:28 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:28 --> Email Class Initialized
INFO - 2020-10-05 07:41:28 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:28 --> Model Class Initialized
INFO - 2020-10-05 07:41:28 --> Model Class Initialized
INFO - 2020-10-05 07:41:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:41:28 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:28 --> Total execution time: 0.0250
ERROR - 2020-10-05 07:41:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:32 --> Config Class Initialized
INFO - 2020-10-05 07:41:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:32 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:32 --> URI Class Initialized
INFO - 2020-10-05 07:41:32 --> Router Class Initialized
INFO - 2020-10-05 07:41:32 --> Output Class Initialized
INFO - 2020-10-05 07:41:32 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:32 --> Input Class Initialized
INFO - 2020-10-05 07:41:32 --> Language Class Initialized
INFO - 2020-10-05 07:41:32 --> Loader Class Initialized
INFO - 2020-10-05 07:41:32 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:32 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:32 --> Email Class Initialized
INFO - 2020-10-05 07:41:32 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:32 --> Model Class Initialized
INFO - 2020-10-05 07:41:32 --> Model Class Initialized
INFO - 2020-10-05 07:41:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 07:41:32 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:32 --> Total execution time: 0.0237
ERROR - 2020-10-05 07:41:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:35 --> Config Class Initialized
INFO - 2020-10-05 07:41:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:35 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:35 --> URI Class Initialized
INFO - 2020-10-05 07:41:35 --> Router Class Initialized
INFO - 2020-10-05 07:41:35 --> Output Class Initialized
INFO - 2020-10-05 07:41:35 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:35 --> Input Class Initialized
INFO - 2020-10-05 07:41:35 --> Language Class Initialized
INFO - 2020-10-05 07:41:35 --> Loader Class Initialized
INFO - 2020-10-05 07:41:35 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:35 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:35 --> Email Class Initialized
INFO - 2020-10-05 07:41:35 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:35 --> Model Class Initialized
INFO - 2020-10-05 07:41:35 --> Model Class Initialized
INFO - 2020-10-05 07:41:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:41:35 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:35 --> Total execution time: 0.0218
ERROR - 2020-10-05 07:41:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:37 --> Config Class Initialized
INFO - 2020-10-05 07:41:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:37 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:37 --> URI Class Initialized
INFO - 2020-10-05 07:41:37 --> Router Class Initialized
INFO - 2020-10-05 07:41:37 --> Output Class Initialized
INFO - 2020-10-05 07:41:37 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:37 --> Input Class Initialized
INFO - 2020-10-05 07:41:37 --> Language Class Initialized
INFO - 2020-10-05 07:41:37 --> Loader Class Initialized
INFO - 2020-10-05 07:41:37 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:37 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:37 --> Email Class Initialized
INFO - 2020-10-05 07:41:37 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:37 --> Model Class Initialized
INFO - 2020-10-05 07:41:37 --> Model Class Initialized
INFO - 2020-10-05 07:41:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 07:41:37 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:37 --> Total execution time: 0.0189
ERROR - 2020-10-05 07:41:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:54 --> Config Class Initialized
INFO - 2020-10-05 07:41:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:54 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:54 --> URI Class Initialized
INFO - 2020-10-05 07:41:54 --> Router Class Initialized
INFO - 2020-10-05 07:41:54 --> Output Class Initialized
INFO - 2020-10-05 07:41:54 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:54 --> Input Class Initialized
INFO - 2020-10-05 07:41:54 --> Language Class Initialized
INFO - 2020-10-05 07:41:54 --> Loader Class Initialized
INFO - 2020-10-05 07:41:54 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:54 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:54 --> Email Class Initialized
INFO - 2020-10-05 07:41:54 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:54 --> Model Class Initialized
INFO - 2020-10-05 07:41:54 --> Model Class Initialized
INFO - 2020-10-05 07:41:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:41:54 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:54 --> Total execution time: 0.1569
ERROR - 2020-10-05 07:41:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:41:56 --> Config Class Initialized
INFO - 2020-10-05 07:41:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:41:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:41:56 --> Utf8 Class Initialized
INFO - 2020-10-05 07:41:56 --> URI Class Initialized
INFO - 2020-10-05 07:41:56 --> Router Class Initialized
INFO - 2020-10-05 07:41:56 --> Output Class Initialized
INFO - 2020-10-05 07:41:56 --> Security Class Initialized
DEBUG - 2020-10-05 07:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:41:56 --> Input Class Initialized
INFO - 2020-10-05 07:41:56 --> Language Class Initialized
INFO - 2020-10-05 07:41:56 --> Loader Class Initialized
INFO - 2020-10-05 07:41:56 --> Helper loaded: url_helper
INFO - 2020-10-05 07:41:56 --> Database Driver Class Initialized
INFO - 2020-10-05 07:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:41:56 --> Email Class Initialized
INFO - 2020-10-05 07:41:56 --> Controller Class Initialized
DEBUG - 2020-10-05 07:41:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:41:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:41:56 --> Model Class Initialized
INFO - 2020-10-05 07:41:56 --> Model Class Initialized
INFO - 2020-10-05 07:41:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 07:41:56 --> Final output sent to browser
DEBUG - 2020-10-05 07:41:56 --> Total execution time: 0.0313
ERROR - 2020-10-05 07:42:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:42:03 --> Config Class Initialized
INFO - 2020-10-05 07:42:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:42:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:42:03 --> Utf8 Class Initialized
INFO - 2020-10-05 07:42:03 --> URI Class Initialized
INFO - 2020-10-05 07:42:03 --> Router Class Initialized
INFO - 2020-10-05 07:42:03 --> Output Class Initialized
INFO - 2020-10-05 07:42:03 --> Security Class Initialized
DEBUG - 2020-10-05 07:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:42:03 --> Input Class Initialized
INFO - 2020-10-05 07:42:03 --> Language Class Initialized
INFO - 2020-10-05 07:42:03 --> Loader Class Initialized
INFO - 2020-10-05 07:42:03 --> Helper loaded: url_helper
INFO - 2020-10-05 07:42:03 --> Database Driver Class Initialized
INFO - 2020-10-05 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:42:03 --> Email Class Initialized
INFO - 2020-10-05 07:42:03 --> Controller Class Initialized
DEBUG - 2020-10-05 07:42:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:42:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:42:03 --> Model Class Initialized
INFO - 2020-10-05 07:42:03 --> Model Class Initialized
INFO - 2020-10-05 07:42:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:42:03 --> Final output sent to browser
DEBUG - 2020-10-05 07:42:03 --> Total execution time: 0.0185
ERROR - 2020-10-05 07:42:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:42:14 --> Config Class Initialized
INFO - 2020-10-05 07:42:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:42:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:42:14 --> Utf8 Class Initialized
INFO - 2020-10-05 07:42:14 --> URI Class Initialized
INFO - 2020-10-05 07:42:14 --> Router Class Initialized
INFO - 2020-10-05 07:42:14 --> Output Class Initialized
INFO - 2020-10-05 07:42:14 --> Security Class Initialized
DEBUG - 2020-10-05 07:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:42:14 --> Input Class Initialized
INFO - 2020-10-05 07:42:14 --> Language Class Initialized
INFO - 2020-10-05 07:42:14 --> Loader Class Initialized
INFO - 2020-10-05 07:42:14 --> Helper loaded: url_helper
INFO - 2020-10-05 07:42:14 --> Database Driver Class Initialized
INFO - 2020-10-05 07:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:42:14 --> Email Class Initialized
INFO - 2020-10-05 07:42:14 --> Controller Class Initialized
DEBUG - 2020-10-05 07:42:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:42:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:42:14 --> Model Class Initialized
INFO - 2020-10-05 07:42:14 --> Model Class Initialized
INFO - 2020-10-05 07:42:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 07:42:14 --> Final output sent to browser
DEBUG - 2020-10-05 07:42:14 --> Total execution time: 0.0220
ERROR - 2020-10-05 07:42:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:42:16 --> Config Class Initialized
INFO - 2020-10-05 07:42:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:42:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:42:16 --> Utf8 Class Initialized
INFO - 2020-10-05 07:42:16 --> URI Class Initialized
INFO - 2020-10-05 07:42:16 --> Router Class Initialized
INFO - 2020-10-05 07:42:16 --> Output Class Initialized
INFO - 2020-10-05 07:42:16 --> Security Class Initialized
DEBUG - 2020-10-05 07:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:42:16 --> Input Class Initialized
INFO - 2020-10-05 07:42:16 --> Language Class Initialized
INFO - 2020-10-05 07:42:16 --> Loader Class Initialized
INFO - 2020-10-05 07:42:16 --> Helper loaded: url_helper
INFO - 2020-10-05 07:42:16 --> Database Driver Class Initialized
INFO - 2020-10-05 07:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:42:16 --> Email Class Initialized
INFO - 2020-10-05 07:42:16 --> Controller Class Initialized
DEBUG - 2020-10-05 07:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:42:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:42:16 --> Model Class Initialized
INFO - 2020-10-05 07:42:16 --> Model Class Initialized
INFO - 2020-10-05 07:42:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:42:16 --> Final output sent to browser
DEBUG - 2020-10-05 07:42:16 --> Total execution time: 0.0199
ERROR - 2020-10-05 07:42:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:42:19 --> Config Class Initialized
INFO - 2020-10-05 07:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:42:19 --> Utf8 Class Initialized
INFO - 2020-10-05 07:42:19 --> URI Class Initialized
INFO - 2020-10-05 07:42:19 --> Router Class Initialized
INFO - 2020-10-05 07:42:19 --> Output Class Initialized
INFO - 2020-10-05 07:42:19 --> Security Class Initialized
DEBUG - 2020-10-05 07:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:42:19 --> Input Class Initialized
INFO - 2020-10-05 07:42:19 --> Language Class Initialized
INFO - 2020-10-05 07:42:19 --> Loader Class Initialized
INFO - 2020-10-05 07:42:19 --> Helper loaded: url_helper
INFO - 2020-10-05 07:42:19 --> Database Driver Class Initialized
INFO - 2020-10-05 07:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:42:19 --> Email Class Initialized
INFO - 2020-10-05 07:42:19 --> Controller Class Initialized
DEBUG - 2020-10-05 07:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 07:42:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:42:19 --> Model Class Initialized
INFO - 2020-10-05 07:42:19 --> Model Class Initialized
INFO - 2020-10-05 07:42:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 07:42:19 --> Final output sent to browser
DEBUG - 2020-10-05 07:42:19 --> Total execution time: 0.0189
ERROR - 2020-10-05 07:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 07:42:24 --> Config Class Initialized
INFO - 2020-10-05 07:42:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 07:42:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 07:42:24 --> Utf8 Class Initialized
INFO - 2020-10-05 07:42:24 --> URI Class Initialized
DEBUG - 2020-10-05 07:42:24 --> No URI present. Default controller set.
INFO - 2020-10-05 07:42:24 --> Router Class Initialized
INFO - 2020-10-05 07:42:24 --> Output Class Initialized
INFO - 2020-10-05 07:42:24 --> Security Class Initialized
DEBUG - 2020-10-05 07:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 07:42:24 --> Input Class Initialized
INFO - 2020-10-05 07:42:24 --> Language Class Initialized
INFO - 2020-10-05 07:42:24 --> Loader Class Initialized
INFO - 2020-10-05 07:42:24 --> Helper loaded: url_helper
INFO - 2020-10-05 07:42:24 --> Database Driver Class Initialized
INFO - 2020-10-05 07:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 07:42:24 --> Email Class Initialized
INFO - 2020-10-05 07:42:24 --> Controller Class Initialized
INFO - 2020-10-05 07:42:24 --> Model Class Initialized
INFO - 2020-10-05 07:42:24 --> Model Class Initialized
DEBUG - 2020-10-05 07:42:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 07:42:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 07:42:24 --> Final output sent to browser
DEBUG - 2020-10-05 07:42:24 --> Total execution time: 0.0397
ERROR - 2020-10-05 10:46:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:46:15 --> Config Class Initialized
INFO - 2020-10-05 10:46:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:46:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:46:15 --> Utf8 Class Initialized
INFO - 2020-10-05 10:46:15 --> URI Class Initialized
DEBUG - 2020-10-05 10:46:15 --> No URI present. Default controller set.
INFO - 2020-10-05 10:46:15 --> Router Class Initialized
INFO - 2020-10-05 10:46:15 --> Output Class Initialized
INFO - 2020-10-05 10:46:15 --> Security Class Initialized
DEBUG - 2020-10-05 10:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:46:15 --> Input Class Initialized
INFO - 2020-10-05 10:46:15 --> Language Class Initialized
INFO - 2020-10-05 10:46:15 --> Loader Class Initialized
INFO - 2020-10-05 10:46:15 --> Helper loaded: url_helper
INFO - 2020-10-05 10:46:15 --> Database Driver Class Initialized
INFO - 2020-10-05 10:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:46:15 --> Email Class Initialized
INFO - 2020-10-05 10:46:15 --> Controller Class Initialized
INFO - 2020-10-05 10:46:15 --> Model Class Initialized
INFO - 2020-10-05 10:46:15 --> Model Class Initialized
DEBUG - 2020-10-05 10:46:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:46:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 10:46:15 --> Final output sent to browser
DEBUG - 2020-10-05 10:46:15 --> Total execution time: 0.1119
ERROR - 2020-10-05 10:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:46:33 --> Config Class Initialized
INFO - 2020-10-05 10:46:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:46:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:46:33 --> Utf8 Class Initialized
INFO - 2020-10-05 10:46:33 --> URI Class Initialized
INFO - 2020-10-05 10:46:33 --> Router Class Initialized
INFO - 2020-10-05 10:46:33 --> Output Class Initialized
INFO - 2020-10-05 10:46:33 --> Security Class Initialized
DEBUG - 2020-10-05 10:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:46:33 --> Input Class Initialized
INFO - 2020-10-05 10:46:33 --> Language Class Initialized
INFO - 2020-10-05 10:46:33 --> Loader Class Initialized
INFO - 2020-10-05 10:46:33 --> Helper loaded: url_helper
INFO - 2020-10-05 10:46:33 --> Database Driver Class Initialized
INFO - 2020-10-05 10:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:46:33 --> Email Class Initialized
INFO - 2020-10-05 10:46:33 --> Controller Class Initialized
INFO - 2020-10-05 10:46:33 --> Model Class Initialized
INFO - 2020-10-05 10:46:33 --> Model Class Initialized
DEBUG - 2020-10-05 10:46:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 10:46:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:46:33 --> Config Class Initialized
INFO - 2020-10-05 10:46:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:46:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:46:33 --> Utf8 Class Initialized
INFO - 2020-10-05 10:46:33 --> URI Class Initialized
INFO - 2020-10-05 10:46:33 --> Router Class Initialized
INFO - 2020-10-05 10:46:33 --> Output Class Initialized
INFO - 2020-10-05 10:46:33 --> Security Class Initialized
DEBUG - 2020-10-05 10:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:46:33 --> Input Class Initialized
INFO - 2020-10-05 10:46:33 --> Language Class Initialized
INFO - 2020-10-05 10:46:33 --> Loader Class Initialized
INFO - 2020-10-05 10:46:33 --> Helper loaded: url_helper
INFO - 2020-10-05 10:46:33 --> Database Driver Class Initialized
INFO - 2020-10-05 10:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:46:33 --> Email Class Initialized
INFO - 2020-10-05 10:46:33 --> Controller Class Initialized
INFO - 2020-10-05 10:46:33 --> Model Class Initialized
INFO - 2020-10-05 10:46:33 --> Model Class Initialized
DEBUG - 2020-10-05 10:46:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:46:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:46:33 --> Model Class Initialized
INFO - 2020-10-05 10:46:33 --> Final output sent to browser
DEBUG - 2020-10-05 10:46:33 --> Total execution time: 0.0459
ERROR - 2020-10-05 10:46:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:46:34 --> Config Class Initialized
INFO - 2020-10-05 10:46:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:46:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:46:34 --> Utf8 Class Initialized
INFO - 2020-10-05 10:46:34 --> URI Class Initialized
INFO - 2020-10-05 10:46:34 --> Router Class Initialized
INFO - 2020-10-05 10:46:34 --> Output Class Initialized
INFO - 2020-10-05 10:46:34 --> Security Class Initialized
DEBUG - 2020-10-05 10:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:46:34 --> Input Class Initialized
INFO - 2020-10-05 10:46:34 --> Language Class Initialized
INFO - 2020-10-05 10:46:34 --> Loader Class Initialized
INFO - 2020-10-05 10:46:34 --> Helper loaded: url_helper
INFO - 2020-10-05 10:46:34 --> Database Driver Class Initialized
INFO - 2020-10-05 10:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:46:34 --> Email Class Initialized
INFO - 2020-10-05 10:46:34 --> Controller Class Initialized
DEBUG - 2020-10-05 10:46:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:46:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:46:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 10:46:34 --> Final output sent to browser
DEBUG - 2020-10-05 10:46:34 --> Total execution time: 0.0446
ERROR - 2020-10-05 10:46:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:46:47 --> Config Class Initialized
INFO - 2020-10-05 10:46:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:46:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:46:47 --> Utf8 Class Initialized
INFO - 2020-10-05 10:46:47 --> URI Class Initialized
INFO - 2020-10-05 10:46:47 --> Router Class Initialized
INFO - 2020-10-05 10:46:47 --> Output Class Initialized
INFO - 2020-10-05 10:46:47 --> Security Class Initialized
DEBUG - 2020-10-05 10:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:46:47 --> Input Class Initialized
INFO - 2020-10-05 10:46:47 --> Language Class Initialized
INFO - 2020-10-05 10:46:47 --> Loader Class Initialized
INFO - 2020-10-05 10:46:47 --> Helper loaded: url_helper
INFO - 2020-10-05 10:46:47 --> Database Driver Class Initialized
INFO - 2020-10-05 10:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:46:47 --> Email Class Initialized
INFO - 2020-10-05 10:46:47 --> Controller Class Initialized
DEBUG - 2020-10-05 10:46:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:46:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:46:47 --> Model Class Initialized
INFO - 2020-10-05 10:46:47 --> Model Class Initialized
INFO - 2020-10-05 10:46:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 10:46:47 --> Final output sent to browser
DEBUG - 2020-10-05 10:46:47 --> Total execution time: 0.0610
ERROR - 2020-10-05 10:47:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:47:17 --> Config Class Initialized
INFO - 2020-10-05 10:47:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:47:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:47:17 --> Utf8 Class Initialized
INFO - 2020-10-05 10:47:17 --> URI Class Initialized
INFO - 2020-10-05 10:47:17 --> Router Class Initialized
INFO - 2020-10-05 10:47:17 --> Output Class Initialized
INFO - 2020-10-05 10:47:17 --> Security Class Initialized
DEBUG - 2020-10-05 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:47:17 --> Input Class Initialized
INFO - 2020-10-05 10:47:17 --> Language Class Initialized
INFO - 2020-10-05 10:47:17 --> Loader Class Initialized
INFO - 2020-10-05 10:47:17 --> Helper loaded: url_helper
INFO - 2020-10-05 10:47:17 --> Database Driver Class Initialized
INFO - 2020-10-05 10:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:47:17 --> Email Class Initialized
INFO - 2020-10-05 10:47:17 --> Controller Class Initialized
DEBUG - 2020-10-05 10:47:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:47:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:47:17 --> Model Class Initialized
INFO - 2020-10-05 10:47:17 --> Model Class Initialized
INFO - 2020-10-05 10:47:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 10:47:17 --> Final output sent to browser
DEBUG - 2020-10-05 10:47:17 --> Total execution time: 0.0497
ERROR - 2020-10-05 10:47:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:47:19 --> Config Class Initialized
INFO - 2020-10-05 10:47:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:47:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:47:19 --> Utf8 Class Initialized
INFO - 2020-10-05 10:47:19 --> URI Class Initialized
INFO - 2020-10-05 10:47:19 --> Router Class Initialized
INFO - 2020-10-05 10:47:19 --> Output Class Initialized
INFO - 2020-10-05 10:47:19 --> Security Class Initialized
DEBUG - 2020-10-05 10:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:47:19 --> Input Class Initialized
INFO - 2020-10-05 10:47:19 --> Language Class Initialized
INFO - 2020-10-05 10:47:19 --> Loader Class Initialized
INFO - 2020-10-05 10:47:19 --> Helper loaded: url_helper
INFO - 2020-10-05 10:47:19 --> Database Driver Class Initialized
INFO - 2020-10-05 10:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:47:19 --> Email Class Initialized
INFO - 2020-10-05 10:47:19 --> Controller Class Initialized
DEBUG - 2020-10-05 10:47:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:47:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:47:19 --> Model Class Initialized
INFO - 2020-10-05 10:47:19 --> Model Class Initialized
INFO - 2020-10-05 10:47:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 10:47:19 --> Final output sent to browser
DEBUG - 2020-10-05 10:47:19 --> Total execution time: 0.0303
ERROR - 2020-10-05 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:48:41 --> Config Class Initialized
INFO - 2020-10-05 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-05 10:48:41 --> URI Class Initialized
INFO - 2020-10-05 10:48:41 --> Router Class Initialized
INFO - 2020-10-05 10:48:41 --> Output Class Initialized
INFO - 2020-10-05 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-05 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:48:41 --> Input Class Initialized
INFO - 2020-10-05 10:48:41 --> Language Class Initialized
INFO - 2020-10-05 10:48:41 --> Loader Class Initialized
INFO - 2020-10-05 10:48:41 --> Helper loaded: url_helper
INFO - 2020-10-05 10:48:41 --> Database Driver Class Initialized
INFO - 2020-10-05 10:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:48:41 --> Email Class Initialized
INFO - 2020-10-05 10:48:41 --> Controller Class Initialized
DEBUG - 2020-10-05 10:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:48:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:48:41 --> Model Class Initialized
INFO - 2020-10-05 10:48:41 --> Model Class Initialized
INFO - 2020-10-05 10:48:41 --> Model Class Initialized
ERROR - 2020-10-05 10:48:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('souravpatra24031996@gmail.com','sooo','1233423412','oodsf','17662921',7,)
INFO - 2020-10-05 10:48:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 10:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:12 --> Config Class Initialized
INFO - 2020-10-05 10:54:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:12 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:12 --> URI Class Initialized
INFO - 2020-10-05 10:54:12 --> Router Class Initialized
INFO - 2020-10-05 10:54:12 --> Output Class Initialized
INFO - 2020-10-05 10:54:12 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:12 --> Input Class Initialized
INFO - 2020-10-05 10:54:12 --> Language Class Initialized
INFO - 2020-10-05 10:54:12 --> Loader Class Initialized
INFO - 2020-10-05 10:54:12 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:12 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:12 --> Email Class Initialized
INFO - 2020-10-05 10:54:12 --> Controller Class Initialized
DEBUG - 2020-10-05 10:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:54:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:12 --> Model Class Initialized
INFO - 2020-10-05 10:54:12 --> Model Class Initialized
INFO - 2020-10-05 10:54:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 10:54:12 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:12 --> Total execution time: 0.0210
ERROR - 2020-10-05 10:54:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:17 --> Config Class Initialized
INFO - 2020-10-05 10:54:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:17 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:17 --> URI Class Initialized
DEBUG - 2020-10-05 10:54:17 --> No URI present. Default controller set.
INFO - 2020-10-05 10:54:17 --> Router Class Initialized
INFO - 2020-10-05 10:54:17 --> Output Class Initialized
INFO - 2020-10-05 10:54:17 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:17 --> Input Class Initialized
INFO - 2020-10-05 10:54:17 --> Language Class Initialized
INFO - 2020-10-05 10:54:17 --> Loader Class Initialized
INFO - 2020-10-05 10:54:17 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:17 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:17 --> Email Class Initialized
INFO - 2020-10-05 10:54:17 --> Controller Class Initialized
INFO - 2020-10-05 10:54:17 --> Model Class Initialized
INFO - 2020-10-05 10:54:17 --> Model Class Initialized
DEBUG - 2020-10-05 10:54:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 10:54:17 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:17 --> Total execution time: 0.0217
ERROR - 2020-10-05 10:54:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:21 --> Config Class Initialized
INFO - 2020-10-05 10:54:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:21 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:21 --> URI Class Initialized
INFO - 2020-10-05 10:54:21 --> Router Class Initialized
INFO - 2020-10-05 10:54:21 --> Output Class Initialized
INFO - 2020-10-05 10:54:21 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:21 --> Input Class Initialized
INFO - 2020-10-05 10:54:21 --> Language Class Initialized
INFO - 2020-10-05 10:54:21 --> Loader Class Initialized
INFO - 2020-10-05 10:54:21 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:21 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:21 --> Email Class Initialized
INFO - 2020-10-05 10:54:21 --> Controller Class Initialized
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
DEBUG - 2020-10-05 10:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:54:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
INFO - 2020-10-05 10:54:21 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:21 --> Total execution time: 0.0227
ERROR - 2020-10-05 10:54:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:21 --> Config Class Initialized
INFO - 2020-10-05 10:54:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:21 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:21 --> URI Class Initialized
INFO - 2020-10-05 10:54:21 --> Router Class Initialized
INFO - 2020-10-05 10:54:21 --> Output Class Initialized
INFO - 2020-10-05 10:54:21 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:21 --> Input Class Initialized
INFO - 2020-10-05 10:54:21 --> Language Class Initialized
INFO - 2020-10-05 10:54:21 --> Loader Class Initialized
INFO - 2020-10-05 10:54:21 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:21 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:21 --> Email Class Initialized
INFO - 2020-10-05 10:54:21 --> Controller Class Initialized
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
DEBUG - 2020-10-05 10:54:21 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 10:54:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:21 --> Config Class Initialized
INFO - 2020-10-05 10:54:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:21 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:21 --> URI Class Initialized
INFO - 2020-10-05 10:54:21 --> Router Class Initialized
INFO - 2020-10-05 10:54:21 --> Output Class Initialized
INFO - 2020-10-05 10:54:21 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:21 --> Input Class Initialized
INFO - 2020-10-05 10:54:21 --> Language Class Initialized
INFO - 2020-10-05 10:54:21 --> Loader Class Initialized
INFO - 2020-10-05 10:54:21 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:21 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:21 --> Email Class Initialized
INFO - 2020-10-05 10:54:21 --> Controller Class Initialized
DEBUG - 2020-10-05 10:54:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:54:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
INFO - 2020-10-05 10:54:21 --> Model Class Initialized
INFO - 2020-10-05 10:54:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-05 10:54:22 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:22 --> Total execution time: 0.0483
ERROR - 2020-10-05 10:54:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:28 --> Config Class Initialized
INFO - 2020-10-05 10:54:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:28 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:28 --> URI Class Initialized
INFO - 2020-10-05 10:54:28 --> Router Class Initialized
INFO - 2020-10-05 10:54:28 --> Output Class Initialized
INFO - 2020-10-05 10:54:28 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:28 --> Input Class Initialized
INFO - 2020-10-05 10:54:28 --> Language Class Initialized
INFO - 2020-10-05 10:54:28 --> Loader Class Initialized
INFO - 2020-10-05 10:54:28 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:28 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:28 --> Email Class Initialized
INFO - 2020-10-05 10:54:28 --> Controller Class Initialized
DEBUG - 2020-10-05 10:54:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:54:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:28 --> Model Class Initialized
INFO - 2020-10-05 10:54:28 --> Model Class Initialized
INFO - 2020-10-05 10:54:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-05 10:54:28 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:28 --> Total execution time: 0.0595
ERROR - 2020-10-05 10:54:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:32 --> Config Class Initialized
INFO - 2020-10-05 10:54:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:32 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:32 --> URI Class Initialized
INFO - 2020-10-05 10:54:32 --> Router Class Initialized
INFO - 2020-10-05 10:54:32 --> Output Class Initialized
INFO - 2020-10-05 10:54:32 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:32 --> Input Class Initialized
INFO - 2020-10-05 10:54:32 --> Language Class Initialized
INFO - 2020-10-05 10:54:32 --> Loader Class Initialized
INFO - 2020-10-05 10:54:32 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:32 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:32 --> Email Class Initialized
INFO - 2020-10-05 10:54:32 --> Controller Class Initialized
DEBUG - 2020-10-05 10:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:54:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:32 --> Model Class Initialized
INFO - 2020-10-05 10:54:32 --> Model Class Initialized
INFO - 2020-10-05 10:54:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-05 10:54:32 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:32 --> Total execution time: 0.0282
ERROR - 2020-10-05 10:54:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 10:54:52 --> Config Class Initialized
INFO - 2020-10-05 10:54:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 10:54:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 10:54:52 --> Utf8 Class Initialized
INFO - 2020-10-05 10:54:52 --> URI Class Initialized
INFO - 2020-10-05 10:54:52 --> Router Class Initialized
INFO - 2020-10-05 10:54:52 --> Output Class Initialized
INFO - 2020-10-05 10:54:52 --> Security Class Initialized
DEBUG - 2020-10-05 10:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 10:54:52 --> Input Class Initialized
INFO - 2020-10-05 10:54:52 --> Language Class Initialized
INFO - 2020-10-05 10:54:52 --> Loader Class Initialized
INFO - 2020-10-05 10:54:52 --> Helper loaded: url_helper
INFO - 2020-10-05 10:54:52 --> Database Driver Class Initialized
INFO - 2020-10-05 10:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 10:54:52 --> Email Class Initialized
INFO - 2020-10-05 10:54:52 --> Controller Class Initialized
DEBUG - 2020-10-05 10:54:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 10:54:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 10:54:52 --> Model Class Initialized
INFO - 2020-10-05 10:54:52 --> Model Class Initialized
INFO - 2020-10-05 10:54:52 --> Model Class Initialized
INFO - 2020-10-05 10:54:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-05 10:54:52 --> Final output sent to browser
DEBUG - 2020-10-05 10:54:52 --> Total execution time: 0.0698
ERROR - 2020-10-05 11:03:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:03:06 --> Config Class Initialized
INFO - 2020-10-05 11:03:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:03:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:06 --> Utf8 Class Initialized
INFO - 2020-10-05 11:03:06 --> URI Class Initialized
DEBUG - 2020-10-05 11:03:06 --> No URI present. Default controller set.
INFO - 2020-10-05 11:03:06 --> Router Class Initialized
INFO - 2020-10-05 11:03:06 --> Output Class Initialized
INFO - 2020-10-05 11:03:06 --> Security Class Initialized
DEBUG - 2020-10-05 11:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:06 --> Input Class Initialized
INFO - 2020-10-05 11:03:06 --> Language Class Initialized
INFO - 2020-10-05 11:03:06 --> Loader Class Initialized
INFO - 2020-10-05 11:03:06 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:06 --> Database Driver Class Initialized
INFO - 2020-10-05 11:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:03:06 --> Email Class Initialized
INFO - 2020-10-05 11:03:06 --> Controller Class Initialized
INFO - 2020-10-05 11:03:06 --> Model Class Initialized
INFO - 2020-10-05 11:03:06 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:06 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:03:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 11:03:06 --> Final output sent to browser
DEBUG - 2020-10-05 11:03:06 --> Total execution time: 0.1569
ERROR - 2020-10-05 11:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:03:22 --> Config Class Initialized
INFO - 2020-10-05 11:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:22 --> Utf8 Class Initialized
INFO - 2020-10-05 11:03:22 --> URI Class Initialized
INFO - 2020-10-05 11:03:22 --> Router Class Initialized
INFO - 2020-10-05 11:03:22 --> Output Class Initialized
INFO - 2020-10-05 11:03:22 --> Security Class Initialized
DEBUG - 2020-10-05 11:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:22 --> Input Class Initialized
INFO - 2020-10-05 11:03:22 --> Language Class Initialized
INFO - 2020-10-05 11:03:22 --> Loader Class Initialized
INFO - 2020-10-05 11:03:22 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:22 --> Database Driver Class Initialized
ERROR - 2020-10-05 11:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:03:22 --> Config Class Initialized
INFO - 2020-10-05 11:03:22 --> Hooks Class Initialized
INFO - 2020-10-05 11:03:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-05 11:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:22 --> Utf8 Class Initialized
INFO - 2020-10-05 11:03:22 --> URI Class Initialized
INFO - 2020-10-05 11:03:22 --> Router Class Initialized
INFO - 2020-10-05 11:03:22 --> Email Class Initialized
INFO - 2020-10-05 11:03:22 --> Controller Class Initialized
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:03:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
INFO - 2020-10-05 11:03:22 --> Output Class Initialized
INFO - 2020-10-05 11:03:22 --> Security Class Initialized
DEBUG - 2020-10-05 11:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:22 --> Input Class Initialized
INFO - 2020-10-05 11:03:22 --> Language Class Initialized
INFO - 2020-10-05 11:03:22 --> Loader Class Initialized
INFO - 2020-10-05 11:03:22 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:22 --> Database Driver Class Initialized
INFO - 2020-10-05 11:03:22 --> Final output sent to browser
DEBUG - 2020-10-05 11:03:22 --> Total execution time: 0.0628
INFO - 2020-10-05 11:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:03:22 --> Email Class Initialized
INFO - 2020-10-05 11:03:22 --> Controller Class Initialized
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:22 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 11:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:03:22 --> Config Class Initialized
INFO - 2020-10-05 11:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:22 --> Utf8 Class Initialized
INFO - 2020-10-05 11:03:22 --> URI Class Initialized
DEBUG - 2020-10-05 11:03:22 --> No URI present. Default controller set.
INFO - 2020-10-05 11:03:22 --> Router Class Initialized
INFO - 2020-10-05 11:03:22 --> Output Class Initialized
INFO - 2020-10-05 11:03:22 --> Security Class Initialized
DEBUG - 2020-10-05 11:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:22 --> Input Class Initialized
INFO - 2020-10-05 11:03:22 --> Language Class Initialized
INFO - 2020-10-05 11:03:22 --> Loader Class Initialized
INFO - 2020-10-05 11:03:22 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:22 --> Database Driver Class Initialized
INFO - 2020-10-05 11:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:03:22 --> Email Class Initialized
INFO - 2020-10-05 11:03:22 --> Controller Class Initialized
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
INFO - 2020-10-05 11:03:22 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:03:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 11:03:22 --> Final output sent to browser
DEBUG - 2020-10-05 11:03:22 --> Total execution time: 0.0188
ERROR - 2020-10-05 11:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-10-05 11:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:03:39 --> Config Class Initialized
INFO - 2020-10-05 11:03:39 --> Hooks Class Initialized
INFO - 2020-10-05 11:03:39 --> Config Class Initialized
INFO - 2020-10-05 11:03:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:03:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:39 --> Utf8 Class Initialized
DEBUG - 2020-10-05 11:03:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:39 --> Utf8 Class Initialized
INFO - 2020-10-05 11:03:39 --> URI Class Initialized
INFO - 2020-10-05 11:03:39 --> URI Class Initialized
INFO - 2020-10-05 11:03:39 --> Router Class Initialized
INFO - 2020-10-05 11:03:39 --> Router Class Initialized
INFO - 2020-10-05 11:03:39 --> Output Class Initialized
INFO - 2020-10-05 11:03:39 --> Output Class Initialized
INFO - 2020-10-05 11:03:39 --> Security Class Initialized
INFO - 2020-10-05 11:03:39 --> Security Class Initialized
DEBUG - 2020-10-05 11:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:39 --> Input Class Initialized
DEBUG - 2020-10-05 11:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:39 --> Input Class Initialized
INFO - 2020-10-05 11:03:39 --> Language Class Initialized
INFO - 2020-10-05 11:03:39 --> Language Class Initialized
INFO - 2020-10-05 11:03:39 --> Loader Class Initialized
INFO - 2020-10-05 11:03:39 --> Loader Class Initialized
INFO - 2020-10-05 11:03:39 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:39 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:39 --> Database Driver Class Initialized
INFO - 2020-10-05 11:03:39 --> Database Driver Class Initialized
INFO - 2020-10-05 11:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:03:39 --> Email Class Initialized
INFO - 2020-10-05 11:03:39 --> Controller Class Initialized
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:03:39 --> Email Class Initialized
INFO - 2020-10-05 11:03:39 --> Controller Class Initialized
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:03:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
INFO - 2020-10-05 11:03:39 --> Final output sent to browser
DEBUG - 2020-10-05 11:03:39 --> Total execution time: 0.0332
ERROR - 2020-10-05 11:03:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:03:39 --> Config Class Initialized
INFO - 2020-10-05 11:03:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:03:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:03:39 --> Utf8 Class Initialized
INFO - 2020-10-05 11:03:39 --> URI Class Initialized
DEBUG - 2020-10-05 11:03:39 --> No URI present. Default controller set.
INFO - 2020-10-05 11:03:39 --> Router Class Initialized
INFO - 2020-10-05 11:03:39 --> Output Class Initialized
INFO - 2020-10-05 11:03:39 --> Security Class Initialized
DEBUG - 2020-10-05 11:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:03:39 --> Input Class Initialized
INFO - 2020-10-05 11:03:39 --> Language Class Initialized
INFO - 2020-10-05 11:03:39 --> Loader Class Initialized
INFO - 2020-10-05 11:03:39 --> Helper loaded: url_helper
INFO - 2020-10-05 11:03:39 --> Database Driver Class Initialized
INFO - 2020-10-05 11:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:03:39 --> Email Class Initialized
INFO - 2020-10-05 11:03:39 --> Controller Class Initialized
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
INFO - 2020-10-05 11:03:39 --> Model Class Initialized
DEBUG - 2020-10-05 11:03:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:03:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 11:03:39 --> Final output sent to browser
DEBUG - 2020-10-05 11:03:39 --> Total execution time: 0.0201
ERROR - 2020-10-05 11:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:04:03 --> Config Class Initialized
INFO - 2020-10-05 11:04:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:04:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:04:03 --> Utf8 Class Initialized
INFO - 2020-10-05 11:04:03 --> URI Class Initialized
INFO - 2020-10-05 11:04:03 --> Router Class Initialized
INFO - 2020-10-05 11:04:03 --> Output Class Initialized
INFO - 2020-10-05 11:04:03 --> Security Class Initialized
DEBUG - 2020-10-05 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:04:03 --> Input Class Initialized
INFO - 2020-10-05 11:04:03 --> Language Class Initialized
INFO - 2020-10-05 11:04:03 --> Loader Class Initialized
INFO - 2020-10-05 11:04:03 --> Helper loaded: url_helper
INFO - 2020-10-05 11:04:03 --> Database Driver Class Initialized
INFO - 2020-10-05 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:04:03 --> Email Class Initialized
INFO - 2020-10-05 11:04:03 --> Controller Class Initialized
INFO - 2020-10-05 11:04:03 --> Model Class Initialized
INFO - 2020-10-05 11:04:03 --> Model Class Initialized
DEBUG - 2020-10-05 11:04:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:04:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:04:03 --> Model Class Initialized
INFO - 2020-10-05 11:04:03 --> Final output sent to browser
DEBUG - 2020-10-05 11:04:03 --> Total execution time: 0.1184
ERROR - 2020-10-05 11:04:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:04:03 --> Config Class Initialized
INFO - 2020-10-05 11:04:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:04:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:04:03 --> Utf8 Class Initialized
INFO - 2020-10-05 11:04:03 --> URI Class Initialized
INFO - 2020-10-05 11:04:03 --> Router Class Initialized
INFO - 2020-10-05 11:04:03 --> Output Class Initialized
INFO - 2020-10-05 11:04:03 --> Security Class Initialized
DEBUG - 2020-10-05 11:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:04:03 --> Input Class Initialized
INFO - 2020-10-05 11:04:03 --> Language Class Initialized
INFO - 2020-10-05 11:04:03 --> Loader Class Initialized
INFO - 2020-10-05 11:04:03 --> Helper loaded: url_helper
INFO - 2020-10-05 11:04:03 --> Database Driver Class Initialized
INFO - 2020-10-05 11:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:04:03 --> Email Class Initialized
INFO - 2020-10-05 11:04:03 --> Controller Class Initialized
INFO - 2020-10-05 11:04:03 --> Model Class Initialized
INFO - 2020-10-05 11:04:03 --> Model Class Initialized
DEBUG - 2020-10-05 11:04:03 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 11:04:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:04:04 --> Config Class Initialized
INFO - 2020-10-05 11:04:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:04:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:04:04 --> Utf8 Class Initialized
INFO - 2020-10-05 11:04:04 --> URI Class Initialized
INFO - 2020-10-05 11:04:04 --> Router Class Initialized
INFO - 2020-10-05 11:04:04 --> Output Class Initialized
INFO - 2020-10-05 11:04:04 --> Security Class Initialized
DEBUG - 2020-10-05 11:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:04:04 --> Input Class Initialized
INFO - 2020-10-05 11:04:04 --> Language Class Initialized
INFO - 2020-10-05 11:04:04 --> Loader Class Initialized
INFO - 2020-10-05 11:04:04 --> Helper loaded: url_helper
INFO - 2020-10-05 11:04:04 --> Database Driver Class Initialized
INFO - 2020-10-05 11:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:04:04 --> Email Class Initialized
INFO - 2020-10-05 11:04:04 --> Controller Class Initialized
DEBUG - 2020-10-05 11:04:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:04:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:04:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 11:04:04 --> Final output sent to browser
DEBUG - 2020-10-05 11:04:04 --> Total execution time: 0.0417
ERROR - 2020-10-05 11:04:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:04:11 --> Config Class Initialized
INFO - 2020-10-05 11:04:11 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:04:11 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:04:11 --> Utf8 Class Initialized
INFO - 2020-10-05 11:04:11 --> URI Class Initialized
INFO - 2020-10-05 11:04:11 --> Router Class Initialized
INFO - 2020-10-05 11:04:11 --> Output Class Initialized
INFO - 2020-10-05 11:04:11 --> Security Class Initialized
DEBUG - 2020-10-05 11:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:04:11 --> Input Class Initialized
INFO - 2020-10-05 11:04:11 --> Language Class Initialized
INFO - 2020-10-05 11:04:11 --> Loader Class Initialized
INFO - 2020-10-05 11:04:11 --> Helper loaded: url_helper
INFO - 2020-10-05 11:04:11 --> Database Driver Class Initialized
INFO - 2020-10-05 11:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:04:11 --> Email Class Initialized
INFO - 2020-10-05 11:04:11 --> Controller Class Initialized
DEBUG - 2020-10-05 11:04:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:04:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:04:11 --> Model Class Initialized
INFO - 2020-10-05 11:04:11 --> Model Class Initialized
INFO - 2020-10-05 11:04:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:04:11 --> Final output sent to browser
DEBUG - 2020-10-05 11:04:11 --> Total execution time: 0.0436
ERROR - 2020-10-05 11:04:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:04:13 --> Config Class Initialized
INFO - 2020-10-05 11:04:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:04:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:04:13 --> Utf8 Class Initialized
INFO - 2020-10-05 11:04:13 --> URI Class Initialized
INFO - 2020-10-05 11:04:13 --> Router Class Initialized
INFO - 2020-10-05 11:04:13 --> Output Class Initialized
INFO - 2020-10-05 11:04:13 --> Security Class Initialized
DEBUG - 2020-10-05 11:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:04:13 --> Input Class Initialized
INFO - 2020-10-05 11:04:13 --> Language Class Initialized
INFO - 2020-10-05 11:04:13 --> Loader Class Initialized
INFO - 2020-10-05 11:04:13 --> Helper loaded: url_helper
INFO - 2020-10-05 11:04:13 --> Database Driver Class Initialized
INFO - 2020-10-05 11:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:04:13 --> Email Class Initialized
INFO - 2020-10-05 11:04:13 --> Controller Class Initialized
DEBUG - 2020-10-05 11:04:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:04:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:04:13 --> Model Class Initialized
INFO - 2020-10-05 11:04:13 --> Model Class Initialized
INFO - 2020-10-05 11:04:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:04:13 --> Final output sent to browser
DEBUG - 2020-10-05 11:04:13 --> Total execution time: 0.0293
ERROR - 2020-10-05 11:04:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:04:39 --> Config Class Initialized
INFO - 2020-10-05 11:04:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:04:39 --> Utf8 Class Initialized
INFO - 2020-10-05 11:04:39 --> URI Class Initialized
INFO - 2020-10-05 11:04:39 --> Router Class Initialized
INFO - 2020-10-05 11:04:39 --> Output Class Initialized
INFO - 2020-10-05 11:04:39 --> Security Class Initialized
DEBUG - 2020-10-05 11:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:04:39 --> Input Class Initialized
INFO - 2020-10-05 11:04:39 --> Language Class Initialized
INFO - 2020-10-05 11:04:39 --> Loader Class Initialized
INFO - 2020-10-05 11:04:39 --> Helper loaded: url_helper
INFO - 2020-10-05 11:04:39 --> Database Driver Class Initialized
INFO - 2020-10-05 11:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:04:39 --> Email Class Initialized
INFO - 2020-10-05 11:04:39 --> Controller Class Initialized
DEBUG - 2020-10-05 11:04:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:04:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:04:39 --> Model Class Initialized
INFO - 2020-10-05 11:04:39 --> Model Class Initialized
INFO - 2020-10-05 11:04:39 --> Model Class Initialized
ERROR - 2020-10-05 11:04:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('afds@hgfjhgj','gfg','1233243434','hfdd','a1bd06b2',8,)
INFO - 2020-10-05 11:04:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 11:04:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:140) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-05 11:05:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:05:29 --> Config Class Initialized
INFO - 2020-10-05 11:05:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:05:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:05:29 --> Utf8 Class Initialized
INFO - 2020-10-05 11:05:29 --> URI Class Initialized
INFO - 2020-10-05 11:05:29 --> Router Class Initialized
INFO - 2020-10-05 11:05:29 --> Output Class Initialized
INFO - 2020-10-05 11:05:29 --> Security Class Initialized
DEBUG - 2020-10-05 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:05:30 --> Input Class Initialized
INFO - 2020-10-05 11:05:30 --> Language Class Initialized
INFO - 2020-10-05 11:05:30 --> Loader Class Initialized
INFO - 2020-10-05 11:05:30 --> Helper loaded: url_helper
INFO - 2020-10-05 11:05:30 --> Database Driver Class Initialized
INFO - 2020-10-05 11:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:05:30 --> Email Class Initialized
INFO - 2020-10-05 11:05:30 --> Controller Class Initialized
DEBUG - 2020-10-05 11:05:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:05:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:05:30 --> Model Class Initialized
INFO - 2020-10-05 11:05:30 --> Model Class Initialized
INFO - 2020-10-05 11:05:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:05:30 --> Final output sent to browser
DEBUG - 2020-10-05 11:05:30 --> Total execution time: 0.3078
ERROR - 2020-10-05 11:05:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:05:34 --> Config Class Initialized
INFO - 2020-10-05 11:05:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:05:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:05:34 --> Utf8 Class Initialized
INFO - 2020-10-05 11:05:34 --> URI Class Initialized
INFO - 2020-10-05 11:05:34 --> Router Class Initialized
INFO - 2020-10-05 11:05:34 --> Output Class Initialized
INFO - 2020-10-05 11:05:34 --> Security Class Initialized
DEBUG - 2020-10-05 11:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:05:34 --> Input Class Initialized
INFO - 2020-10-05 11:05:34 --> Language Class Initialized
INFO - 2020-10-05 11:05:34 --> Loader Class Initialized
INFO - 2020-10-05 11:05:34 --> Helper loaded: url_helper
INFO - 2020-10-05 11:05:34 --> Database Driver Class Initialized
INFO - 2020-10-05 11:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:05:34 --> Email Class Initialized
INFO - 2020-10-05 11:05:34 --> Controller Class Initialized
DEBUG - 2020-10-05 11:05:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:05:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:05:34 --> Model Class Initialized
INFO - 2020-10-05 11:05:34 --> Model Class Initialized
INFO - 2020-10-05 11:05:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:05:34 --> Final output sent to browser
DEBUG - 2020-10-05 11:05:34 --> Total execution time: 0.0329
ERROR - 2020-10-05 11:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:05:55 --> Config Class Initialized
INFO - 2020-10-05 11:05:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:05:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:05:55 --> Utf8 Class Initialized
INFO - 2020-10-05 11:05:55 --> URI Class Initialized
INFO - 2020-10-05 11:05:55 --> Router Class Initialized
INFO - 2020-10-05 11:05:55 --> Output Class Initialized
INFO - 2020-10-05 11:05:55 --> Security Class Initialized
DEBUG - 2020-10-05 11:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:05:55 --> Input Class Initialized
INFO - 2020-10-05 11:05:55 --> Language Class Initialized
INFO - 2020-10-05 11:05:55 --> Loader Class Initialized
INFO - 2020-10-05 11:05:55 --> Helper loaded: url_helper
INFO - 2020-10-05 11:05:55 --> Database Driver Class Initialized
INFO - 2020-10-05 11:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:05:55 --> Email Class Initialized
INFO - 2020-10-05 11:05:55 --> Controller Class Initialized
DEBUG - 2020-10-05 11:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:05:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:05:55 --> Model Class Initialized
INFO - 2020-10-05 11:05:55 --> Model Class Initialized
INFO - 2020-10-05 11:05:55 --> Model Class Initialized
ERROR - 2020-10-05 11:05:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('fdh@gchfh','jgfjg','24335','5666656','b767fa14',9,)
INFO - 2020-10-05 11:05:55 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 11:05:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:140) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-05 11:08:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:08:26 --> Config Class Initialized
INFO - 2020-10-05 11:08:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:08:27 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:08:27 --> Utf8 Class Initialized
INFO - 2020-10-05 11:08:27 --> URI Class Initialized
INFO - 2020-10-05 11:08:27 --> Router Class Initialized
INFO - 2020-10-05 11:08:27 --> Output Class Initialized
INFO - 2020-10-05 11:08:27 --> Security Class Initialized
DEBUG - 2020-10-05 11:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:08:27 --> Input Class Initialized
INFO - 2020-10-05 11:08:27 --> Language Class Initialized
INFO - 2020-10-05 11:08:27 --> Loader Class Initialized
INFO - 2020-10-05 11:08:27 --> Helper loaded: url_helper
INFO - 2020-10-05 11:08:27 --> Database Driver Class Initialized
INFO - 2020-10-05 11:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:08:27 --> Email Class Initialized
INFO - 2020-10-05 11:08:27 --> Controller Class Initialized
DEBUG - 2020-10-05 11:08:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:08:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:08:27 --> Model Class Initialized
INFO - 2020-10-05 11:08:27 --> Model Class Initialized
INFO - 2020-10-05 11:08:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:08:27 --> Final output sent to browser
DEBUG - 2020-10-05 11:08:27 --> Total execution time: 0.1699
ERROR - 2020-10-05 11:08:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:08:29 --> Config Class Initialized
INFO - 2020-10-05 11:08:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:08:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:08:29 --> Utf8 Class Initialized
INFO - 2020-10-05 11:08:29 --> URI Class Initialized
INFO - 2020-10-05 11:08:29 --> Router Class Initialized
INFO - 2020-10-05 11:08:29 --> Output Class Initialized
INFO - 2020-10-05 11:08:29 --> Security Class Initialized
DEBUG - 2020-10-05 11:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:08:29 --> Input Class Initialized
INFO - 2020-10-05 11:08:29 --> Language Class Initialized
INFO - 2020-10-05 11:08:29 --> Loader Class Initialized
INFO - 2020-10-05 11:08:29 --> Helper loaded: url_helper
INFO - 2020-10-05 11:08:29 --> Database Driver Class Initialized
INFO - 2020-10-05 11:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:08:29 --> Email Class Initialized
INFO - 2020-10-05 11:08:29 --> Controller Class Initialized
DEBUG - 2020-10-05 11:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:08:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:08:29 --> Model Class Initialized
INFO - 2020-10-05 11:08:29 --> Model Class Initialized
INFO - 2020-10-05 11:08:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:08:29 --> Final output sent to browser
DEBUG - 2020-10-05 11:08:29 --> Total execution time: 0.0222
ERROR - 2020-10-05 11:08:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:08:45 --> Config Class Initialized
INFO - 2020-10-05 11:08:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:08:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:08:45 --> Utf8 Class Initialized
INFO - 2020-10-05 11:08:45 --> URI Class Initialized
INFO - 2020-10-05 11:08:45 --> Router Class Initialized
INFO - 2020-10-05 11:08:45 --> Output Class Initialized
INFO - 2020-10-05 11:08:45 --> Security Class Initialized
DEBUG - 2020-10-05 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:08:45 --> Input Class Initialized
INFO - 2020-10-05 11:08:45 --> Language Class Initialized
INFO - 2020-10-05 11:08:45 --> Loader Class Initialized
INFO - 2020-10-05 11:08:45 --> Helper loaded: url_helper
INFO - 2020-10-05 11:08:45 --> Database Driver Class Initialized
INFO - 2020-10-05 11:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:08:45 --> Email Class Initialized
INFO - 2020-10-05 11:08:45 --> Controller Class Initialized
DEBUG - 2020-10-05 11:08:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:08:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:08:45 --> Model Class Initialized
INFO - 2020-10-05 11:08:45 --> Model Class Initialized
INFO - 2020-10-05 11:08:45 --> Model Class Initialized
ERROR - 2020-10-05 11:08:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('hgfg@gjkg','yffjhg','1563','','8d73ab99',10,)
INFO - 2020-10-05 11:08:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 11:08:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:140) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-05 11:08:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:08:53 --> Config Class Initialized
INFO - 2020-10-05 11:08:53 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:08:53 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:08:53 --> Utf8 Class Initialized
INFO - 2020-10-05 11:08:53 --> URI Class Initialized
INFO - 2020-10-05 11:08:53 --> Router Class Initialized
INFO - 2020-10-05 11:08:53 --> Output Class Initialized
INFO - 2020-10-05 11:08:53 --> Security Class Initialized
DEBUG - 2020-10-05 11:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:08:53 --> Input Class Initialized
INFO - 2020-10-05 11:08:53 --> Language Class Initialized
INFO - 2020-10-05 11:08:53 --> Loader Class Initialized
INFO - 2020-10-05 11:08:53 --> Helper loaded: url_helper
INFO - 2020-10-05 11:08:53 --> Database Driver Class Initialized
INFO - 2020-10-05 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:08:53 --> Email Class Initialized
INFO - 2020-10-05 11:08:53 --> Controller Class Initialized
DEBUG - 2020-10-05 11:08:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:08:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:08:53 --> Model Class Initialized
INFO - 2020-10-05 11:08:53 --> Model Class Initialized
INFO - 2020-10-05 11:08:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:08:53 --> Final output sent to browser
DEBUG - 2020-10-05 11:08:53 --> Total execution time: 0.0190
ERROR - 2020-10-05 11:09:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:09:02 --> Config Class Initialized
INFO - 2020-10-05 11:09:02 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:09:02 --> Utf8 Class Initialized
INFO - 2020-10-05 11:09:02 --> URI Class Initialized
INFO - 2020-10-05 11:09:02 --> Router Class Initialized
INFO - 2020-10-05 11:09:02 --> Output Class Initialized
INFO - 2020-10-05 11:09:02 --> Security Class Initialized
DEBUG - 2020-10-05 11:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:09:02 --> Input Class Initialized
INFO - 2020-10-05 11:09:02 --> Language Class Initialized
INFO - 2020-10-05 11:09:02 --> Loader Class Initialized
INFO - 2020-10-05 11:09:02 --> Helper loaded: url_helper
INFO - 2020-10-05 11:09:02 --> Database Driver Class Initialized
INFO - 2020-10-05 11:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:09:02 --> Email Class Initialized
INFO - 2020-10-05 11:09:02 --> Controller Class Initialized
DEBUG - 2020-10-05 11:09:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:09:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:09:02 --> Model Class Initialized
INFO - 2020-10-05 11:09:02 --> Model Class Initialized
INFO - 2020-10-05 11:09:02 --> Model Class Initialized
ERROR - 2020-10-05 11:09:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('hgfg@gjkg','yffjhg','1563232222','','37729346',11,)
INFO - 2020-10-05 11:09:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 11:09:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:140) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-05 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:13:09 --> Config Class Initialized
INFO - 2020-10-05 11:13:09 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:13:09 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:13:09 --> Utf8 Class Initialized
INFO - 2020-10-05 11:13:09 --> URI Class Initialized
INFO - 2020-10-05 11:13:09 --> Router Class Initialized
INFO - 2020-10-05 11:13:09 --> Output Class Initialized
INFO - 2020-10-05 11:13:09 --> Security Class Initialized
DEBUG - 2020-10-05 11:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:13:09 --> Input Class Initialized
INFO - 2020-10-05 11:13:09 --> Language Class Initialized
INFO - 2020-10-05 11:13:09 --> Loader Class Initialized
INFO - 2020-10-05 11:13:09 --> Helper loaded: url_helper
INFO - 2020-10-05 11:13:09 --> Database Driver Class Initialized
INFO - 2020-10-05 11:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:13:10 --> Email Class Initialized
INFO - 2020-10-05 11:13:10 --> Controller Class Initialized
DEBUG - 2020-10-05 11:13:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:13:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:13:10 --> Model Class Initialized
INFO - 2020-10-05 11:13:10 --> Model Class Initialized
INFO - 2020-10-05 11:13:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:13:10 --> Final output sent to browser
DEBUG - 2020-10-05 11:13:10 --> Total execution time: 0.1627
ERROR - 2020-10-05 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:13:12 --> Config Class Initialized
INFO - 2020-10-05 11:13:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:13:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:13:12 --> Utf8 Class Initialized
INFO - 2020-10-05 11:13:12 --> URI Class Initialized
INFO - 2020-10-05 11:13:12 --> Router Class Initialized
INFO - 2020-10-05 11:13:12 --> Output Class Initialized
INFO - 2020-10-05 11:13:12 --> Security Class Initialized
DEBUG - 2020-10-05 11:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:13:12 --> Input Class Initialized
INFO - 2020-10-05 11:13:12 --> Language Class Initialized
INFO - 2020-10-05 11:13:12 --> Loader Class Initialized
INFO - 2020-10-05 11:13:12 --> Helper loaded: url_helper
INFO - 2020-10-05 11:13:12 --> Database Driver Class Initialized
INFO - 2020-10-05 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:13:12 --> Email Class Initialized
INFO - 2020-10-05 11:13:12 --> Controller Class Initialized
DEBUG - 2020-10-05 11:13:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:13:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:13:12 --> Model Class Initialized
INFO - 2020-10-05 11:13:12 --> Model Class Initialized
INFO - 2020-10-05 11:13:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:13:12 --> Final output sent to browser
DEBUG - 2020-10-05 11:13:12 --> Total execution time: 0.0468
ERROR - 2020-10-05 11:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:13:31 --> Config Class Initialized
INFO - 2020-10-05 11:13:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:13:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:13:31 --> Utf8 Class Initialized
INFO - 2020-10-05 11:13:31 --> URI Class Initialized
INFO - 2020-10-05 11:13:31 --> Router Class Initialized
INFO - 2020-10-05 11:13:31 --> Output Class Initialized
INFO - 2020-10-05 11:13:31 --> Security Class Initialized
DEBUG - 2020-10-05 11:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:13:31 --> Input Class Initialized
INFO - 2020-10-05 11:13:31 --> Language Class Initialized
INFO - 2020-10-05 11:13:31 --> Loader Class Initialized
INFO - 2020-10-05 11:13:31 --> Helper loaded: url_helper
INFO - 2020-10-05 11:13:31 --> Database Driver Class Initialized
INFO - 2020-10-05 11:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:13:31 --> Email Class Initialized
INFO - 2020-10-05 11:13:31 --> Controller Class Initialized
DEBUG - 2020-10-05 11:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:13:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:13:31 --> Model Class Initialized
INFO - 2020-10-05 11:13:31 --> Model Class Initialized
INFO - 2020-10-05 11:13:31 --> Model Class Initialized
ERROR - 2020-10-05 11:13:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('hfd@dyf','gfdg','1111111111','','0fa4d2e0',12,)
INFO - 2020-10-05 11:13:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 11:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:140) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-05 11:16:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:16:08 --> Config Class Initialized
INFO - 2020-10-05 11:16:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:16:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:16:08 --> Utf8 Class Initialized
INFO - 2020-10-05 11:16:08 --> URI Class Initialized
INFO - 2020-10-05 11:16:08 --> Router Class Initialized
INFO - 2020-10-05 11:16:08 --> Output Class Initialized
INFO - 2020-10-05 11:16:08 --> Security Class Initialized
DEBUG - 2020-10-05 11:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:16:08 --> Input Class Initialized
INFO - 2020-10-05 11:16:08 --> Language Class Initialized
INFO - 2020-10-05 11:16:09 --> Loader Class Initialized
INFO - 2020-10-05 11:16:09 --> Helper loaded: url_helper
INFO - 2020-10-05 11:16:09 --> Database Driver Class Initialized
INFO - 2020-10-05 11:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:16:09 --> Email Class Initialized
INFO - 2020-10-05 11:16:09 --> Controller Class Initialized
DEBUG - 2020-10-05 11:16:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:16:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:16:09 --> Model Class Initialized
INFO - 2020-10-05 11:16:09 --> Model Class Initialized
INFO - 2020-10-05 11:16:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:16:09 --> Final output sent to browser
DEBUG - 2020-10-05 11:16:09 --> Total execution time: 0.2142
ERROR - 2020-10-05 11:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:16:14 --> Config Class Initialized
INFO - 2020-10-05 11:16:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:16:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:16:14 --> Utf8 Class Initialized
INFO - 2020-10-05 11:16:14 --> URI Class Initialized
INFO - 2020-10-05 11:16:14 --> Router Class Initialized
INFO - 2020-10-05 11:16:14 --> Output Class Initialized
INFO - 2020-10-05 11:16:14 --> Security Class Initialized
DEBUG - 2020-10-05 11:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:16:14 --> Input Class Initialized
INFO - 2020-10-05 11:16:14 --> Language Class Initialized
INFO - 2020-10-05 11:16:14 --> Loader Class Initialized
INFO - 2020-10-05 11:16:14 --> Helper loaded: url_helper
INFO - 2020-10-05 11:16:14 --> Database Driver Class Initialized
INFO - 2020-10-05 11:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:16:14 --> Email Class Initialized
INFO - 2020-10-05 11:16:14 --> Controller Class Initialized
DEBUG - 2020-10-05 11:16:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:16:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:16:14 --> Model Class Initialized
INFO - 2020-10-05 11:16:14 --> Model Class Initialized
INFO - 2020-10-05 11:16:14 --> Model Class Initialized
ERROR - 2020-10-05 11:16:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 1 - Invalid query: CALL user_registration('hfd@dyfcscs','gfdg','1111111111','','58c509b6',13,)
INFO - 2020-10-05 11:16:14 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 11:16:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/User.php:140) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-10-05 11:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:20:21 --> Config Class Initialized
INFO - 2020-10-05 11:20:21 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:20:21 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:20:21 --> Utf8 Class Initialized
INFO - 2020-10-05 11:20:21 --> URI Class Initialized
INFO - 2020-10-05 11:20:21 --> Router Class Initialized
INFO - 2020-10-05 11:20:21 --> Output Class Initialized
INFO - 2020-10-05 11:20:21 --> Security Class Initialized
DEBUG - 2020-10-05 11:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:20:21 --> Input Class Initialized
INFO - 2020-10-05 11:20:21 --> Language Class Initialized
INFO - 2020-10-05 11:20:21 --> Loader Class Initialized
INFO - 2020-10-05 11:20:21 --> Helper loaded: url_helper
INFO - 2020-10-05 11:20:21 --> Database Driver Class Initialized
INFO - 2020-10-05 11:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:20:21 --> Email Class Initialized
INFO - 2020-10-05 11:20:21 --> Controller Class Initialized
DEBUG - 2020-10-05 11:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:20:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:20:21 --> Model Class Initialized
INFO - 2020-10-05 11:20:21 --> Model Class Initialized
INFO - 2020-10-05 11:20:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:20:21 --> Final output sent to browser
DEBUG - 2020-10-05 11:20:21 --> Total execution time: 0.0296
ERROR - 2020-10-05 11:20:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:20:44 --> Config Class Initialized
INFO - 2020-10-05 11:20:44 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:20:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:20:44 --> Utf8 Class Initialized
INFO - 2020-10-05 11:20:44 --> URI Class Initialized
DEBUG - 2020-10-05 11:20:44 --> No URI present. Default controller set.
INFO - 2020-10-05 11:20:44 --> Router Class Initialized
INFO - 2020-10-05 11:20:44 --> Output Class Initialized
INFO - 2020-10-05 11:20:44 --> Security Class Initialized
DEBUG - 2020-10-05 11:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:20:44 --> Input Class Initialized
INFO - 2020-10-05 11:20:44 --> Language Class Initialized
INFO - 2020-10-05 11:20:44 --> Loader Class Initialized
INFO - 2020-10-05 11:20:44 --> Helper loaded: url_helper
INFO - 2020-10-05 11:20:44 --> Database Driver Class Initialized
INFO - 2020-10-05 11:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:20:44 --> Email Class Initialized
INFO - 2020-10-05 11:20:44 --> Controller Class Initialized
INFO - 2020-10-05 11:20:44 --> Model Class Initialized
INFO - 2020-10-05 11:20:44 --> Model Class Initialized
DEBUG - 2020-10-05 11:20:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:20:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 11:20:44 --> Final output sent to browser
DEBUG - 2020-10-05 11:20:44 --> Total execution time: 0.0400
ERROR - 2020-10-05 11:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:21:14 --> Config Class Initialized
INFO - 2020-10-05 11:21:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:21:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:21:14 --> Utf8 Class Initialized
INFO - 2020-10-05 11:21:14 --> URI Class Initialized
INFO - 2020-10-05 11:21:14 --> Router Class Initialized
INFO - 2020-10-05 11:21:14 --> Output Class Initialized
INFO - 2020-10-05 11:21:14 --> Security Class Initialized
DEBUG - 2020-10-05 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:21:14 --> Input Class Initialized
INFO - 2020-10-05 11:21:14 --> Language Class Initialized
INFO - 2020-10-05 11:21:14 --> Loader Class Initialized
INFO - 2020-10-05 11:21:14 --> Helper loaded: url_helper
INFO - 2020-10-05 11:21:14 --> Database Driver Class Initialized
INFO - 2020-10-05 11:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:21:14 --> Email Class Initialized
INFO - 2020-10-05 11:21:14 --> Controller Class Initialized
INFO - 2020-10-05 11:21:14 --> Model Class Initialized
INFO - 2020-10-05 11:21:14 --> Model Class Initialized
DEBUG - 2020-10-05 11:21:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 11:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:21:14 --> Config Class Initialized
INFO - 2020-10-05 11:21:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:21:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:21:14 --> Utf8 Class Initialized
INFO - 2020-10-05 11:21:14 --> URI Class Initialized
INFO - 2020-10-05 11:21:14 --> Router Class Initialized
INFO - 2020-10-05 11:21:14 --> Output Class Initialized
INFO - 2020-10-05 11:21:14 --> Security Class Initialized
DEBUG - 2020-10-05 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:21:14 --> Input Class Initialized
INFO - 2020-10-05 11:21:14 --> Language Class Initialized
INFO - 2020-10-05 11:21:14 --> Loader Class Initialized
INFO - 2020-10-05 11:21:14 --> Helper loaded: url_helper
INFO - 2020-10-05 11:21:14 --> Database Driver Class Initialized
INFO - 2020-10-05 11:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:21:14 --> Email Class Initialized
INFO - 2020-10-05 11:21:14 --> Controller Class Initialized
INFO - 2020-10-05 11:21:14 --> Model Class Initialized
INFO - 2020-10-05 11:21:14 --> Model Class Initialized
DEBUG - 2020-10-05 11:21:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:21:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:21:14 --> Model Class Initialized
INFO - 2020-10-05 11:21:14 --> Final output sent to browser
DEBUG - 2020-10-05 11:21:14 --> Total execution time: 0.0349
ERROR - 2020-10-05 11:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:21:15 --> Config Class Initialized
INFO - 2020-10-05 11:21:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:21:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:21:15 --> Utf8 Class Initialized
INFO - 2020-10-05 11:21:15 --> URI Class Initialized
INFO - 2020-10-05 11:21:15 --> Router Class Initialized
INFO - 2020-10-05 11:21:15 --> Output Class Initialized
INFO - 2020-10-05 11:21:15 --> Security Class Initialized
DEBUG - 2020-10-05 11:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:21:15 --> Input Class Initialized
INFO - 2020-10-05 11:21:15 --> Language Class Initialized
INFO - 2020-10-05 11:21:15 --> Loader Class Initialized
INFO - 2020-10-05 11:21:15 --> Helper loaded: url_helper
INFO - 2020-10-05 11:21:15 --> Database Driver Class Initialized
INFO - 2020-10-05 11:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:21:15 --> Email Class Initialized
INFO - 2020-10-05 11:21:15 --> Controller Class Initialized
DEBUG - 2020-10-05 11:21:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:21:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:21:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 11:21:15 --> Final output sent to browser
DEBUG - 2020-10-05 11:21:15 --> Total execution time: 0.0254
ERROR - 2020-10-05 11:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:21:24 --> Config Class Initialized
INFO - 2020-10-05 11:21:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:21:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:21:24 --> Utf8 Class Initialized
INFO - 2020-10-05 11:21:24 --> URI Class Initialized
INFO - 2020-10-05 11:21:24 --> Router Class Initialized
INFO - 2020-10-05 11:21:24 --> Output Class Initialized
INFO - 2020-10-05 11:21:24 --> Security Class Initialized
DEBUG - 2020-10-05 11:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:21:24 --> Input Class Initialized
INFO - 2020-10-05 11:21:24 --> Language Class Initialized
INFO - 2020-10-05 11:21:24 --> Loader Class Initialized
INFO - 2020-10-05 11:21:24 --> Helper loaded: url_helper
INFO - 2020-10-05 11:21:24 --> Database Driver Class Initialized
INFO - 2020-10-05 11:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:21:24 --> Email Class Initialized
INFO - 2020-10-05 11:21:24 --> Controller Class Initialized
DEBUG - 2020-10-05 11:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:21:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:21:24 --> Model Class Initialized
INFO - 2020-10-05 11:21:24 --> Model Class Initialized
INFO - 2020-10-05 11:21:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 11:21:24 --> Final output sent to browser
DEBUG - 2020-10-05 11:21:24 --> Total execution time: 0.0551
ERROR - 2020-10-05 11:21:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:21:33 --> Config Class Initialized
INFO - 2020-10-05 11:21:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:21:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:21:33 --> Utf8 Class Initialized
INFO - 2020-10-05 11:21:33 --> URI Class Initialized
INFO - 2020-10-05 11:21:33 --> Router Class Initialized
INFO - 2020-10-05 11:21:33 --> Output Class Initialized
INFO - 2020-10-05 11:21:33 --> Security Class Initialized
DEBUG - 2020-10-05 11:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:21:33 --> Input Class Initialized
INFO - 2020-10-05 11:21:33 --> Language Class Initialized
INFO - 2020-10-05 11:21:33 --> Loader Class Initialized
INFO - 2020-10-05 11:21:33 --> Helper loaded: url_helper
INFO - 2020-10-05 11:21:33 --> Database Driver Class Initialized
INFO - 2020-10-05 11:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:21:33 --> Email Class Initialized
INFO - 2020-10-05 11:21:33 --> Controller Class Initialized
DEBUG - 2020-10-05 11:21:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:21:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:21:33 --> Model Class Initialized
INFO - 2020-10-05 11:21:33 --> Model Class Initialized
INFO - 2020-10-05 11:21:33 --> Model Class Initialized
INFO - 2020-10-05 11:21:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-05 11:21:33 --> Final output sent to browser
DEBUG - 2020-10-05 11:21:33 --> Total execution time: 0.0466
ERROR - 2020-10-05 11:22:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:22:05 --> Config Class Initialized
INFO - 2020-10-05 11:22:05 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:22:05 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:22:05 --> Utf8 Class Initialized
INFO - 2020-10-05 11:22:05 --> URI Class Initialized
INFO - 2020-10-05 11:22:05 --> Router Class Initialized
INFO - 2020-10-05 11:22:05 --> Output Class Initialized
INFO - 2020-10-05 11:22:05 --> Security Class Initialized
DEBUG - 2020-10-05 11:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:22:05 --> Input Class Initialized
INFO - 2020-10-05 11:22:05 --> Language Class Initialized
INFO - 2020-10-05 11:22:05 --> Loader Class Initialized
INFO - 2020-10-05 11:22:05 --> Helper loaded: url_helper
INFO - 2020-10-05 11:22:05 --> Database Driver Class Initialized
INFO - 2020-10-05 11:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:22:05 --> Email Class Initialized
INFO - 2020-10-05 11:22:05 --> Controller Class Initialized
DEBUG - 2020-10-05 11:22:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:22:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:22:05 --> Model Class Initialized
INFO - 2020-10-05 11:22:05 --> Model Class Initialized
INFO - 2020-10-05 11:22:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:22:05 --> Final output sent to browser
DEBUG - 2020-10-05 11:22:05 --> Total execution time: 0.0302
ERROR - 2020-10-05 11:22:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:22:14 --> Config Class Initialized
INFO - 2020-10-05 11:22:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:22:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:22:14 --> Utf8 Class Initialized
INFO - 2020-10-05 11:22:14 --> URI Class Initialized
INFO - 2020-10-05 11:22:14 --> Router Class Initialized
INFO - 2020-10-05 11:22:14 --> Output Class Initialized
INFO - 2020-10-05 11:22:14 --> Security Class Initialized
DEBUG - 2020-10-05 11:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:22:14 --> Input Class Initialized
INFO - 2020-10-05 11:22:14 --> Language Class Initialized
INFO - 2020-10-05 11:22:14 --> Loader Class Initialized
INFO - 2020-10-05 11:22:14 --> Helper loaded: url_helper
INFO - 2020-10-05 11:22:14 --> Database Driver Class Initialized
INFO - 2020-10-05 11:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:22:14 --> Email Class Initialized
INFO - 2020-10-05 11:22:14 --> Controller Class Initialized
DEBUG - 2020-10-05 11:22:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:22:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:22:14 --> Model Class Initialized
INFO - 2020-10-05 11:22:14 --> Model Class Initialized
INFO - 2020-10-05 11:22:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:22:14 --> Final output sent to browser
DEBUG - 2020-10-05 11:22:14 --> Total execution time: 0.0183
ERROR - 2020-10-05 11:22:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:22:37 --> Config Class Initialized
INFO - 2020-10-05 11:22:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:22:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:22:37 --> Utf8 Class Initialized
INFO - 2020-10-05 11:22:37 --> URI Class Initialized
INFO - 2020-10-05 11:22:37 --> Router Class Initialized
INFO - 2020-10-05 11:22:37 --> Output Class Initialized
INFO - 2020-10-05 11:22:37 --> Security Class Initialized
DEBUG - 2020-10-05 11:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:22:37 --> Input Class Initialized
INFO - 2020-10-05 11:22:37 --> Language Class Initialized
INFO - 2020-10-05 11:22:37 --> Loader Class Initialized
INFO - 2020-10-05 11:22:37 --> Helper loaded: url_helper
INFO - 2020-10-05 11:22:37 --> Database Driver Class Initialized
INFO - 2020-10-05 11:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:22:37 --> Email Class Initialized
INFO - 2020-10-05 11:22:37 --> Controller Class Initialized
DEBUG - 2020-10-05 11:22:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:22:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:22:37 --> Model Class Initialized
INFO - 2020-10-05 11:22:37 --> Model Class Initialized
INFO - 2020-10-05 11:22:37 --> Model Class Initialized
INFO - 2020-10-05 11:22:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:22:37 --> Final output sent to browser
DEBUG - 2020-10-05 11:22:37 --> Total execution time: 0.0702
ERROR - 2020-10-05 11:24:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:24:14 --> Config Class Initialized
INFO - 2020-10-05 11:24:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:24:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:24:14 --> Utf8 Class Initialized
INFO - 2020-10-05 11:24:14 --> URI Class Initialized
INFO - 2020-10-05 11:24:14 --> Router Class Initialized
INFO - 2020-10-05 11:24:14 --> Output Class Initialized
INFO - 2020-10-05 11:24:14 --> Security Class Initialized
DEBUG - 2020-10-05 11:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:24:14 --> Input Class Initialized
INFO - 2020-10-05 11:24:14 --> Language Class Initialized
INFO - 2020-10-05 11:24:14 --> Loader Class Initialized
INFO - 2020-10-05 11:24:14 --> Helper loaded: url_helper
INFO - 2020-10-05 11:24:14 --> Database Driver Class Initialized
INFO - 2020-10-05 11:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:24:14 --> Email Class Initialized
INFO - 2020-10-05 11:24:14 --> Controller Class Initialized
DEBUG - 2020-10-05 11:24:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:24:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:24:14 --> Model Class Initialized
INFO - 2020-10-05 11:24:14 --> Model Class Initialized
INFO - 2020-10-05 11:24:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:24:14 --> Final output sent to browser
DEBUG - 2020-10-05 11:24:14 --> Total execution time: 0.0251
ERROR - 2020-10-05 11:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:24:22 --> Config Class Initialized
INFO - 2020-10-05 11:24:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:24:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:24:22 --> Utf8 Class Initialized
INFO - 2020-10-05 11:24:22 --> URI Class Initialized
INFO - 2020-10-05 11:24:22 --> Router Class Initialized
INFO - 2020-10-05 11:24:22 --> Output Class Initialized
INFO - 2020-10-05 11:24:22 --> Security Class Initialized
DEBUG - 2020-10-05 11:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:24:22 --> Input Class Initialized
INFO - 2020-10-05 11:24:22 --> Language Class Initialized
INFO - 2020-10-05 11:24:22 --> Loader Class Initialized
INFO - 2020-10-05 11:24:22 --> Helper loaded: url_helper
INFO - 2020-10-05 11:24:22 --> Database Driver Class Initialized
INFO - 2020-10-05 11:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:24:22 --> Email Class Initialized
INFO - 2020-10-05 11:24:22 --> Controller Class Initialized
DEBUG - 2020-10-05 11:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:24:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:24:22 --> Model Class Initialized
INFO - 2020-10-05 11:24:22 --> Model Class Initialized
INFO - 2020-10-05 11:24:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:24:22 --> Final output sent to browser
DEBUG - 2020-10-05 11:24:22 --> Total execution time: 0.0211
ERROR - 2020-10-05 11:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:38:33 --> Config Class Initialized
INFO - 2020-10-05 11:38:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:38:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:38:33 --> Utf8 Class Initialized
INFO - 2020-10-05 11:38:33 --> URI Class Initialized
INFO - 2020-10-05 11:38:33 --> Router Class Initialized
INFO - 2020-10-05 11:38:33 --> Output Class Initialized
INFO - 2020-10-05 11:38:33 --> Security Class Initialized
DEBUG - 2020-10-05 11:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:38:33 --> Input Class Initialized
INFO - 2020-10-05 11:38:33 --> Language Class Initialized
INFO - 2020-10-05 11:38:33 --> Loader Class Initialized
INFO - 2020-10-05 11:38:33 --> Helper loaded: url_helper
INFO - 2020-10-05 11:38:33 --> Database Driver Class Initialized
INFO - 2020-10-05 11:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:38:33 --> Email Class Initialized
INFO - 2020-10-05 11:38:33 --> Controller Class Initialized
DEBUG - 2020-10-05 11:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:38:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:38:33 --> Model Class Initialized
INFO - 2020-10-05 11:38:33 --> Model Class Initialized
INFO - 2020-10-05 11:38:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:38:33 --> Final output sent to browser
DEBUG - 2020-10-05 11:38:33 --> Total execution time: 0.0196
ERROR - 2020-10-05 11:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:40:30 --> Config Class Initialized
INFO - 2020-10-05 11:40:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:40:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:40:30 --> Utf8 Class Initialized
INFO - 2020-10-05 11:40:30 --> URI Class Initialized
INFO - 2020-10-05 11:40:30 --> Router Class Initialized
INFO - 2020-10-05 11:40:30 --> Output Class Initialized
INFO - 2020-10-05 11:40:30 --> Security Class Initialized
DEBUG - 2020-10-05 11:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:40:30 --> Input Class Initialized
INFO - 2020-10-05 11:40:30 --> Language Class Initialized
INFO - 2020-10-05 11:40:30 --> Loader Class Initialized
INFO - 2020-10-05 11:40:30 --> Helper loaded: url_helper
INFO - 2020-10-05 11:40:30 --> Database Driver Class Initialized
INFO - 2020-10-05 11:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:40:30 --> Email Class Initialized
INFO - 2020-10-05 11:40:30 --> Controller Class Initialized
DEBUG - 2020-10-05 11:40:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:40:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:40:30 --> Model Class Initialized
INFO - 2020-10-05 11:40:30 --> Model Class Initialized
INFO - 2020-10-05 11:40:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:40:30 --> Final output sent to browser
DEBUG - 2020-10-05 11:40:30 --> Total execution time: 0.0208
ERROR - 2020-10-05 11:40:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:40:48 --> Config Class Initialized
INFO - 2020-10-05 11:40:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:40:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:40:48 --> Utf8 Class Initialized
INFO - 2020-10-05 11:40:48 --> URI Class Initialized
INFO - 2020-10-05 11:40:48 --> Router Class Initialized
INFO - 2020-10-05 11:40:48 --> Output Class Initialized
INFO - 2020-10-05 11:40:48 --> Security Class Initialized
DEBUG - 2020-10-05 11:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:40:48 --> Input Class Initialized
INFO - 2020-10-05 11:40:48 --> Language Class Initialized
INFO - 2020-10-05 11:40:48 --> Loader Class Initialized
INFO - 2020-10-05 11:40:48 --> Helper loaded: url_helper
INFO - 2020-10-05 11:40:48 --> Database Driver Class Initialized
INFO - 2020-10-05 11:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:40:48 --> Email Class Initialized
INFO - 2020-10-05 11:40:48 --> Controller Class Initialized
DEBUG - 2020-10-05 11:40:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:40:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:40:48 --> Model Class Initialized
INFO - 2020-10-05 11:40:48 --> Model Class Initialized
INFO - 2020-10-05 11:40:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:40:48 --> Final output sent to browser
DEBUG - 2020-10-05 11:40:48 --> Total execution time: 0.0325
ERROR - 2020-10-05 11:41:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:41:26 --> Config Class Initialized
INFO - 2020-10-05 11:41:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:41:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:41:26 --> Utf8 Class Initialized
INFO - 2020-10-05 11:41:26 --> URI Class Initialized
INFO - 2020-10-05 11:41:26 --> Router Class Initialized
INFO - 2020-10-05 11:41:26 --> Output Class Initialized
INFO - 2020-10-05 11:41:26 --> Security Class Initialized
DEBUG - 2020-10-05 11:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:41:26 --> Input Class Initialized
INFO - 2020-10-05 11:41:26 --> Language Class Initialized
INFO - 2020-10-05 11:41:26 --> Loader Class Initialized
INFO - 2020-10-05 11:41:26 --> Helper loaded: url_helper
INFO - 2020-10-05 11:41:26 --> Database Driver Class Initialized
INFO - 2020-10-05 11:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:41:26 --> Email Class Initialized
INFO - 2020-10-05 11:41:26 --> Controller Class Initialized
DEBUG - 2020-10-05 11:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:41:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:41:26 --> Model Class Initialized
INFO - 2020-10-05 11:41:26 --> Model Class Initialized
INFO - 2020-10-05 11:41:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:41:26 --> Final output sent to browser
DEBUG - 2020-10-05 11:41:26 --> Total execution time: 0.0220
ERROR - 2020-10-05 11:42:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:42:16 --> Config Class Initialized
INFO - 2020-10-05 11:42:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:42:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:42:16 --> Utf8 Class Initialized
INFO - 2020-10-05 11:42:16 --> URI Class Initialized
INFO - 2020-10-05 11:42:16 --> Router Class Initialized
INFO - 2020-10-05 11:42:16 --> Output Class Initialized
INFO - 2020-10-05 11:42:16 --> Security Class Initialized
DEBUG - 2020-10-05 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:42:16 --> Input Class Initialized
INFO - 2020-10-05 11:42:16 --> Language Class Initialized
INFO - 2020-10-05 11:42:16 --> Loader Class Initialized
INFO - 2020-10-05 11:42:16 --> Helper loaded: url_helper
INFO - 2020-10-05 11:42:16 --> Database Driver Class Initialized
INFO - 2020-10-05 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:42:16 --> Email Class Initialized
INFO - 2020-10-05 11:42:16 --> Controller Class Initialized
DEBUG - 2020-10-05 11:42:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:42:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:42:16 --> Model Class Initialized
INFO - 2020-10-05 11:42:16 --> Model Class Initialized
INFO - 2020-10-05 11:42:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:42:16 --> Final output sent to browser
DEBUG - 2020-10-05 11:42:16 --> Total execution time: 0.0169
ERROR - 2020-10-05 11:43:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:43:40 --> Config Class Initialized
INFO - 2020-10-05 11:43:40 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:43:40 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:43:40 --> Utf8 Class Initialized
INFO - 2020-10-05 11:43:40 --> URI Class Initialized
INFO - 2020-10-05 11:43:40 --> Router Class Initialized
INFO - 2020-10-05 11:43:40 --> Output Class Initialized
INFO - 2020-10-05 11:43:40 --> Security Class Initialized
DEBUG - 2020-10-05 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:43:40 --> Input Class Initialized
INFO - 2020-10-05 11:43:40 --> Language Class Initialized
INFO - 2020-10-05 11:43:40 --> Loader Class Initialized
INFO - 2020-10-05 11:43:40 --> Helper loaded: url_helper
INFO - 2020-10-05 11:43:40 --> Database Driver Class Initialized
INFO - 2020-10-05 11:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:43:40 --> Email Class Initialized
INFO - 2020-10-05 11:43:40 --> Controller Class Initialized
DEBUG - 2020-10-05 11:43:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:43:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:43:40 --> Model Class Initialized
INFO - 2020-10-05 11:43:40 --> Model Class Initialized
INFO - 2020-10-05 11:43:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 11:43:40 --> Final output sent to browser
DEBUG - 2020-10-05 11:43:40 --> Total execution time: 0.0218
ERROR - 2020-10-05 11:43:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:43:44 --> Config Class Initialized
INFO - 2020-10-05 11:43:44 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:43:44 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:43:44 --> Utf8 Class Initialized
INFO - 2020-10-05 11:43:44 --> URI Class Initialized
INFO - 2020-10-05 11:43:44 --> Router Class Initialized
INFO - 2020-10-05 11:43:44 --> Output Class Initialized
INFO - 2020-10-05 11:43:44 --> Security Class Initialized
DEBUG - 2020-10-05 11:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:43:44 --> Input Class Initialized
INFO - 2020-10-05 11:43:44 --> Language Class Initialized
INFO - 2020-10-05 11:43:44 --> Loader Class Initialized
INFO - 2020-10-05 11:43:44 --> Helper loaded: url_helper
INFO - 2020-10-05 11:43:44 --> Database Driver Class Initialized
INFO - 2020-10-05 11:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:43:44 --> Email Class Initialized
INFO - 2020-10-05 11:43:44 --> Controller Class Initialized
DEBUG - 2020-10-05 11:43:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:43:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:43:44 --> Model Class Initialized
INFO - 2020-10-05 11:43:44 --> Model Class Initialized
INFO - 2020-10-05 11:43:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:43:44 --> Final output sent to browser
DEBUG - 2020-10-05 11:43:44 --> Total execution time: 0.0358
ERROR - 2020-10-05 11:43:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:43:47 --> Config Class Initialized
INFO - 2020-10-05 11:43:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:43:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:43:47 --> Utf8 Class Initialized
INFO - 2020-10-05 11:43:47 --> URI Class Initialized
INFO - 2020-10-05 11:43:47 --> Router Class Initialized
INFO - 2020-10-05 11:43:47 --> Output Class Initialized
INFO - 2020-10-05 11:43:47 --> Security Class Initialized
DEBUG - 2020-10-05 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:43:47 --> Input Class Initialized
INFO - 2020-10-05 11:43:47 --> Language Class Initialized
INFO - 2020-10-05 11:43:47 --> Loader Class Initialized
INFO - 2020-10-05 11:43:47 --> Helper loaded: url_helper
INFO - 2020-10-05 11:43:47 --> Database Driver Class Initialized
INFO - 2020-10-05 11:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:43:47 --> Email Class Initialized
INFO - 2020-10-05 11:43:47 --> Controller Class Initialized
DEBUG - 2020-10-05 11:43:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:43:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:43:47 --> Model Class Initialized
INFO - 2020-10-05 11:43:47 --> Model Class Initialized
INFO - 2020-10-05 11:43:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 11:43:47 --> Final output sent to browser
DEBUG - 2020-10-05 11:43:47 --> Total execution time: 0.0233
ERROR - 2020-10-05 11:44:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:44:00 --> Config Class Initialized
INFO - 2020-10-05 11:44:00 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:44:00 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:44:00 --> Utf8 Class Initialized
INFO - 2020-10-05 11:44:00 --> URI Class Initialized
INFO - 2020-10-05 11:44:00 --> Router Class Initialized
INFO - 2020-10-05 11:44:00 --> Output Class Initialized
INFO - 2020-10-05 11:44:00 --> Security Class Initialized
DEBUG - 2020-10-05 11:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:44:00 --> Input Class Initialized
INFO - 2020-10-05 11:44:00 --> Language Class Initialized
INFO - 2020-10-05 11:44:00 --> Loader Class Initialized
INFO - 2020-10-05 11:44:00 --> Helper loaded: url_helper
INFO - 2020-10-05 11:44:00 --> Database Driver Class Initialized
INFO - 2020-10-05 11:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:44:00 --> Email Class Initialized
INFO - 2020-10-05 11:44:00 --> Controller Class Initialized
DEBUG - 2020-10-05 11:44:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:44:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:44:00 --> Model Class Initialized
INFO - 2020-10-05 11:44:00 --> Model Class Initialized
INFO - 2020-10-05 11:44:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 11:44:00 --> Final output sent to browser
DEBUG - 2020-10-05 11:44:00 --> Total execution time: 0.0278
ERROR - 2020-10-05 11:44:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:44:08 --> Config Class Initialized
INFO - 2020-10-05 11:44:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:44:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:44:08 --> Utf8 Class Initialized
INFO - 2020-10-05 11:44:08 --> URI Class Initialized
INFO - 2020-10-05 11:44:08 --> Router Class Initialized
INFO - 2020-10-05 11:44:08 --> Output Class Initialized
INFO - 2020-10-05 11:44:08 --> Security Class Initialized
DEBUG - 2020-10-05 11:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:44:08 --> Input Class Initialized
INFO - 2020-10-05 11:44:08 --> Language Class Initialized
INFO - 2020-10-05 11:44:08 --> Loader Class Initialized
INFO - 2020-10-05 11:44:08 --> Helper loaded: url_helper
INFO - 2020-10-05 11:44:08 --> Database Driver Class Initialized
INFO - 2020-10-05 11:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:44:08 --> Email Class Initialized
INFO - 2020-10-05 11:44:08 --> Controller Class Initialized
DEBUG - 2020-10-05 11:44:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:44:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:44:08 --> Model Class Initialized
INFO - 2020-10-05 11:44:08 --> Model Class Initialized
INFO - 2020-10-05 11:44:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 11:44:08 --> Final output sent to browser
DEBUG - 2020-10-05 11:44:08 --> Total execution time: 0.0229
ERROR - 2020-10-05 11:51:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:51:06 --> Config Class Initialized
INFO - 2020-10-05 11:51:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:51:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:51:06 --> Utf8 Class Initialized
INFO - 2020-10-05 11:51:06 --> URI Class Initialized
INFO - 2020-10-05 11:51:06 --> Router Class Initialized
INFO - 2020-10-05 11:51:06 --> Output Class Initialized
INFO - 2020-10-05 11:51:06 --> Security Class Initialized
DEBUG - 2020-10-05 11:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:51:06 --> Input Class Initialized
INFO - 2020-10-05 11:51:06 --> Language Class Initialized
INFO - 2020-10-05 11:51:06 --> Loader Class Initialized
INFO - 2020-10-05 11:51:06 --> Helper loaded: url_helper
INFO - 2020-10-05 11:51:06 --> Database Driver Class Initialized
INFO - 2020-10-05 11:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:51:06 --> Email Class Initialized
INFO - 2020-10-05 11:51:06 --> Controller Class Initialized
DEBUG - 2020-10-05 11:51:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:51:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:51:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 11:51:06 --> Final output sent to browser
DEBUG - 2020-10-05 11:51:06 --> Total execution time: 0.0209
ERROR - 2020-10-05 11:51:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:51:43 --> Config Class Initialized
INFO - 2020-10-05 11:51:43 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:51:43 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:51:43 --> Utf8 Class Initialized
INFO - 2020-10-05 11:51:43 --> URI Class Initialized
DEBUG - 2020-10-05 11:51:43 --> No URI present. Default controller set.
INFO - 2020-10-05 11:51:43 --> Router Class Initialized
INFO - 2020-10-05 11:51:43 --> Output Class Initialized
INFO - 2020-10-05 11:51:43 --> Security Class Initialized
DEBUG - 2020-10-05 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:51:43 --> Input Class Initialized
INFO - 2020-10-05 11:51:43 --> Language Class Initialized
INFO - 2020-10-05 11:51:43 --> Loader Class Initialized
INFO - 2020-10-05 11:51:43 --> Helper loaded: url_helper
INFO - 2020-10-05 11:51:43 --> Database Driver Class Initialized
INFO - 2020-10-05 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:51:43 --> Email Class Initialized
INFO - 2020-10-05 11:51:43 --> Controller Class Initialized
INFO - 2020-10-05 11:51:43 --> Model Class Initialized
INFO - 2020-10-05 11:51:43 --> Model Class Initialized
DEBUG - 2020-10-05 11:51:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:51:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 11:51:43 --> Final output sent to browser
DEBUG - 2020-10-05 11:51:43 --> Total execution time: 0.0211
ERROR - 2020-10-05 11:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:51:47 --> Config Class Initialized
INFO - 2020-10-05 11:51:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:51:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:51:47 --> Utf8 Class Initialized
INFO - 2020-10-05 11:51:47 --> URI Class Initialized
INFO - 2020-10-05 11:51:47 --> Router Class Initialized
INFO - 2020-10-05 11:51:47 --> Output Class Initialized
INFO - 2020-10-05 11:51:47 --> Security Class Initialized
DEBUG - 2020-10-05 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:51:47 --> Input Class Initialized
INFO - 2020-10-05 11:51:47 --> Language Class Initialized
INFO - 2020-10-05 11:51:47 --> Loader Class Initialized
INFO - 2020-10-05 11:51:47 --> Helper loaded: url_helper
INFO - 2020-10-05 11:51:47 --> Database Driver Class Initialized
INFO - 2020-10-05 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:51:47 --> Email Class Initialized
INFO - 2020-10-05 11:51:47 --> Controller Class Initialized
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
DEBUG - 2020-10-05 11:51:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:51:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
INFO - 2020-10-05 11:51:47 --> Final output sent to browser
DEBUG - 2020-10-05 11:51:47 --> Total execution time: 0.0248
ERROR - 2020-10-05 11:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:51:47 --> Config Class Initialized
INFO - 2020-10-05 11:51:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:51:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:51:47 --> Utf8 Class Initialized
INFO - 2020-10-05 11:51:47 --> URI Class Initialized
INFO - 2020-10-05 11:51:47 --> Router Class Initialized
INFO - 2020-10-05 11:51:47 --> Output Class Initialized
INFO - 2020-10-05 11:51:47 --> Security Class Initialized
DEBUG - 2020-10-05 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:51:47 --> Input Class Initialized
INFO - 2020-10-05 11:51:47 --> Language Class Initialized
INFO - 2020-10-05 11:51:47 --> Loader Class Initialized
INFO - 2020-10-05 11:51:47 --> Helper loaded: url_helper
INFO - 2020-10-05 11:51:47 --> Database Driver Class Initialized
INFO - 2020-10-05 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:51:47 --> Email Class Initialized
INFO - 2020-10-05 11:51:47 --> Controller Class Initialized
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
DEBUG - 2020-10-05 11:51:47 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 11:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:51:47 --> Config Class Initialized
INFO - 2020-10-05 11:51:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:51:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:51:47 --> Utf8 Class Initialized
INFO - 2020-10-05 11:51:47 --> URI Class Initialized
INFO - 2020-10-05 11:51:47 --> Router Class Initialized
INFO - 2020-10-05 11:51:47 --> Output Class Initialized
INFO - 2020-10-05 11:51:47 --> Security Class Initialized
DEBUG - 2020-10-05 11:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:51:47 --> Input Class Initialized
INFO - 2020-10-05 11:51:47 --> Language Class Initialized
INFO - 2020-10-05 11:51:47 --> Loader Class Initialized
INFO - 2020-10-05 11:51:47 --> Helper loaded: url_helper
INFO - 2020-10-05 11:51:47 --> Database Driver Class Initialized
INFO - 2020-10-05 11:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:51:47 --> Email Class Initialized
INFO - 2020-10-05 11:51:47 --> Controller Class Initialized
DEBUG - 2020-10-05 11:51:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:51:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
INFO - 2020-10-05 11:51:47 --> Model Class Initialized
INFO - 2020-10-05 11:51:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-05 11:51:47 --> Final output sent to browser
DEBUG - 2020-10-05 11:51:47 --> Total execution time: 0.0444
ERROR - 2020-10-05 11:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:55:11 --> Config Class Initialized
INFO - 2020-10-05 11:55:11 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:55:11 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:55:11 --> Utf8 Class Initialized
INFO - 2020-10-05 11:55:11 --> URI Class Initialized
DEBUG - 2020-10-05 11:55:11 --> No URI present. Default controller set.
INFO - 2020-10-05 11:55:11 --> Router Class Initialized
INFO - 2020-10-05 11:55:11 --> Output Class Initialized
INFO - 2020-10-05 11:55:11 --> Security Class Initialized
DEBUG - 2020-10-05 11:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:55:11 --> Input Class Initialized
INFO - 2020-10-05 11:55:11 --> Language Class Initialized
INFO - 2020-10-05 11:55:11 --> Loader Class Initialized
INFO - 2020-10-05 11:55:11 --> Helper loaded: url_helper
INFO - 2020-10-05 11:55:11 --> Database Driver Class Initialized
INFO - 2020-10-05 11:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:55:11 --> Email Class Initialized
INFO - 2020-10-05 11:55:11 --> Controller Class Initialized
INFO - 2020-10-05 11:55:11 --> Model Class Initialized
INFO - 2020-10-05 11:55:11 --> Model Class Initialized
DEBUG - 2020-10-05 11:55:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:55:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 11:55:11 --> Final output sent to browser
DEBUG - 2020-10-05 11:55:11 --> Total execution time: 0.0201
ERROR - 2020-10-05 11:55:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:55:28 --> Config Class Initialized
INFO - 2020-10-05 11:55:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:55:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:55:28 --> Utf8 Class Initialized
INFO - 2020-10-05 11:55:28 --> URI Class Initialized
INFO - 2020-10-05 11:55:28 --> Router Class Initialized
INFO - 2020-10-05 11:55:28 --> Output Class Initialized
INFO - 2020-10-05 11:55:28 --> Security Class Initialized
DEBUG - 2020-10-05 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:55:28 --> Input Class Initialized
INFO - 2020-10-05 11:55:28 --> Language Class Initialized
INFO - 2020-10-05 11:55:28 --> Loader Class Initialized
INFO - 2020-10-05 11:55:28 --> Helper loaded: url_helper
INFO - 2020-10-05 11:55:28 --> Database Driver Class Initialized
INFO - 2020-10-05 11:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:55:28 --> Email Class Initialized
INFO - 2020-10-05 11:55:28 --> Controller Class Initialized
INFO - 2020-10-05 11:55:28 --> Model Class Initialized
INFO - 2020-10-05 11:55:28 --> Model Class Initialized
DEBUG - 2020-10-05 11:55:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:55:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:55:28 --> Model Class Initialized
INFO - 2020-10-05 11:55:28 --> Final output sent to browser
DEBUG - 2020-10-05 11:55:28 --> Total execution time: 0.0232
ERROR - 2020-10-05 11:55:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:55:29 --> Config Class Initialized
INFO - 2020-10-05 11:55:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:55:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:55:29 --> Utf8 Class Initialized
INFO - 2020-10-05 11:55:29 --> URI Class Initialized
INFO - 2020-10-05 11:55:29 --> Router Class Initialized
INFO - 2020-10-05 11:55:29 --> Output Class Initialized
INFO - 2020-10-05 11:55:29 --> Security Class Initialized
DEBUG - 2020-10-05 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:55:29 --> Input Class Initialized
INFO - 2020-10-05 11:55:29 --> Language Class Initialized
INFO - 2020-10-05 11:55:29 --> Loader Class Initialized
INFO - 2020-10-05 11:55:29 --> Helper loaded: url_helper
INFO - 2020-10-05 11:55:29 --> Database Driver Class Initialized
INFO - 2020-10-05 11:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:55:29 --> Email Class Initialized
INFO - 2020-10-05 11:55:29 --> Controller Class Initialized
INFO - 2020-10-05 11:55:29 --> Model Class Initialized
INFO - 2020-10-05 11:55:29 --> Model Class Initialized
DEBUG - 2020-10-05 11:55:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 11:55:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 11:55:29 --> Config Class Initialized
INFO - 2020-10-05 11:55:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 11:55:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 11:55:29 --> Utf8 Class Initialized
INFO - 2020-10-05 11:55:29 --> URI Class Initialized
INFO - 2020-10-05 11:55:29 --> Router Class Initialized
INFO - 2020-10-05 11:55:29 --> Output Class Initialized
INFO - 2020-10-05 11:55:29 --> Security Class Initialized
DEBUG - 2020-10-05 11:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 11:55:29 --> Input Class Initialized
INFO - 2020-10-05 11:55:29 --> Language Class Initialized
INFO - 2020-10-05 11:55:29 --> Loader Class Initialized
INFO - 2020-10-05 11:55:29 --> Helper loaded: url_helper
INFO - 2020-10-05 11:55:29 --> Database Driver Class Initialized
INFO - 2020-10-05 11:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 11:55:29 --> Email Class Initialized
INFO - 2020-10-05 11:55:29 --> Controller Class Initialized
DEBUG - 2020-10-05 11:55:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 11:55:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 11:55:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 11:55:29 --> Final output sent to browser
DEBUG - 2020-10-05 11:55:29 --> Total execution time: 0.0169
ERROR - 2020-10-05 12:00:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:00:46 --> Config Class Initialized
INFO - 2020-10-05 12:00:46 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:00:46 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:00:46 --> Utf8 Class Initialized
INFO - 2020-10-05 12:00:46 --> URI Class Initialized
INFO - 2020-10-05 12:00:46 --> Router Class Initialized
INFO - 2020-10-05 12:00:46 --> Output Class Initialized
INFO - 2020-10-05 12:00:46 --> Security Class Initialized
DEBUG - 2020-10-05 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:00:46 --> Input Class Initialized
INFO - 2020-10-05 12:00:46 --> Language Class Initialized
INFO - 2020-10-05 12:00:46 --> Loader Class Initialized
INFO - 2020-10-05 12:00:46 --> Helper loaded: url_helper
INFO - 2020-10-05 12:00:46 --> Database Driver Class Initialized
INFO - 2020-10-05 12:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:00:46 --> Email Class Initialized
INFO - 2020-10-05 12:00:46 --> Controller Class Initialized
DEBUG - 2020-10-05 12:00:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:00:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:00:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 12:00:46 --> Final output sent to browser
DEBUG - 2020-10-05 12:00:46 --> Total execution time: 0.0199
ERROR - 2020-10-05 12:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:01:17 --> Config Class Initialized
INFO - 2020-10-05 12:01:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:01:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:01:17 --> Utf8 Class Initialized
INFO - 2020-10-05 12:01:17 --> URI Class Initialized
INFO - 2020-10-05 12:01:17 --> Router Class Initialized
INFO - 2020-10-05 12:01:17 --> Output Class Initialized
INFO - 2020-10-05 12:01:17 --> Security Class Initialized
DEBUG - 2020-10-05 12:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:01:17 --> Input Class Initialized
INFO - 2020-10-05 12:01:17 --> Language Class Initialized
INFO - 2020-10-05 12:01:17 --> Loader Class Initialized
INFO - 2020-10-05 12:01:17 --> Helper loaded: url_helper
INFO - 2020-10-05 12:01:17 --> Database Driver Class Initialized
INFO - 2020-10-05 12:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:01:17 --> Email Class Initialized
INFO - 2020-10-05 12:01:17 --> Controller Class Initialized
DEBUG - 2020-10-05 12:01:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:01:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:01:17 --> Model Class Initialized
INFO - 2020-10-05 12:01:17 --> Model Class Initialized
INFO - 2020-10-05 12:01:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 12:01:17 --> Final output sent to browser
DEBUG - 2020-10-05 12:01:17 --> Total execution time: 0.0213
ERROR - 2020-10-05 12:04:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:04:01 --> Config Class Initialized
INFO - 2020-10-05 12:04:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:04:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:04:01 --> Utf8 Class Initialized
INFO - 2020-10-05 12:04:01 --> URI Class Initialized
INFO - 2020-10-05 12:04:01 --> Router Class Initialized
INFO - 2020-10-05 12:04:01 --> Output Class Initialized
INFO - 2020-10-05 12:04:01 --> Security Class Initialized
DEBUG - 2020-10-05 12:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:04:01 --> Input Class Initialized
INFO - 2020-10-05 12:04:01 --> Language Class Initialized
INFO - 2020-10-05 12:04:01 --> Loader Class Initialized
INFO - 2020-10-05 12:04:01 --> Helper loaded: url_helper
INFO - 2020-10-05 12:04:01 --> Database Driver Class Initialized
INFO - 2020-10-05 12:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:04:01 --> Email Class Initialized
INFO - 2020-10-05 12:04:01 --> Controller Class Initialized
DEBUG - 2020-10-05 12:04:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:04:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:04:01 --> Model Class Initialized
INFO - 2020-10-05 12:04:01 --> Model Class Initialized
INFO - 2020-10-05 12:04:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 12:04:01 --> Final output sent to browser
DEBUG - 2020-10-05 12:04:01 --> Total execution time: 0.0231
ERROR - 2020-10-05 12:04:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:04:17 --> Config Class Initialized
INFO - 2020-10-05 12:04:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:04:17 --> Utf8 Class Initialized
INFO - 2020-10-05 12:04:17 --> URI Class Initialized
INFO - 2020-10-05 12:04:17 --> Router Class Initialized
INFO - 2020-10-05 12:04:17 --> Output Class Initialized
INFO - 2020-10-05 12:04:17 --> Security Class Initialized
DEBUG - 2020-10-05 12:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:04:17 --> Input Class Initialized
INFO - 2020-10-05 12:04:17 --> Language Class Initialized
INFO - 2020-10-05 12:04:17 --> Loader Class Initialized
INFO - 2020-10-05 12:04:17 --> Helper loaded: url_helper
INFO - 2020-10-05 12:04:17 --> Database Driver Class Initialized
INFO - 2020-10-05 12:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:04:17 --> Email Class Initialized
INFO - 2020-10-05 12:04:17 --> Controller Class Initialized
DEBUG - 2020-10-05 12:04:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:04:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:04:17 --> Model Class Initialized
INFO - 2020-10-05 12:04:17 --> Model Class Initialized
INFO - 2020-10-05 12:04:17 --> Model Class Initialized
INFO - 2020-10-05 12:04:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-05 12:04:17 --> Final output sent to browser
DEBUG - 2020-10-05 12:04:17 --> Total execution time: 0.0281
ERROR - 2020-10-05 12:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:06:19 --> Config Class Initialized
INFO - 2020-10-05 12:06:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:06:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:06:19 --> Utf8 Class Initialized
INFO - 2020-10-05 12:06:19 --> URI Class Initialized
INFO - 2020-10-05 12:06:19 --> Router Class Initialized
INFO - 2020-10-05 12:06:19 --> Output Class Initialized
INFO - 2020-10-05 12:06:19 --> Security Class Initialized
DEBUG - 2020-10-05 12:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:06:19 --> Input Class Initialized
INFO - 2020-10-05 12:06:19 --> Language Class Initialized
INFO - 2020-10-05 12:06:19 --> Loader Class Initialized
INFO - 2020-10-05 12:06:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:06:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:06:19 --> Email Class Initialized
INFO - 2020-10-05 12:06:19 --> Controller Class Initialized
DEBUG - 2020-10-05 12:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:06:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:06:19 --> Model Class Initialized
INFO - 2020-10-05 12:06:19 --> Model Class Initialized
INFO - 2020-10-05 12:06:19 --> Model Class Initialized
INFO - 2020-10-05 12:06:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-05 12:06:19 --> Final output sent to browser
DEBUG - 2020-10-05 12:06:19 --> Total execution time: 0.0190
ERROR - 2020-10-05 12:06:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:06:35 --> Config Class Initialized
INFO - 2020-10-05 12:06:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:06:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:06:35 --> Utf8 Class Initialized
INFO - 2020-10-05 12:06:35 --> URI Class Initialized
INFO - 2020-10-05 12:06:35 --> Router Class Initialized
INFO - 2020-10-05 12:06:35 --> Output Class Initialized
INFO - 2020-10-05 12:06:35 --> Security Class Initialized
DEBUG - 2020-10-05 12:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:06:35 --> Input Class Initialized
INFO - 2020-10-05 12:06:35 --> Language Class Initialized
INFO - 2020-10-05 12:06:35 --> Loader Class Initialized
INFO - 2020-10-05 12:06:35 --> Helper loaded: url_helper
INFO - 2020-10-05 12:06:35 --> Database Driver Class Initialized
INFO - 2020-10-05 12:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:06:35 --> Email Class Initialized
INFO - 2020-10-05 12:06:35 --> Controller Class Initialized
DEBUG - 2020-10-05 12:06:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:06:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:06:35 --> Model Class Initialized
INFO - 2020-10-05 12:06:35 --> Model Class Initialized
INFO - 2020-10-05 12:06:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 12:06:35 --> Final output sent to browser
DEBUG - 2020-10-05 12:06:35 --> Total execution time: 0.0283
ERROR - 2020-10-05 12:06:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:06:37 --> Config Class Initialized
INFO - 2020-10-05 12:06:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:06:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:06:37 --> Utf8 Class Initialized
INFO - 2020-10-05 12:06:37 --> URI Class Initialized
INFO - 2020-10-05 12:06:37 --> Router Class Initialized
INFO - 2020-10-05 12:06:37 --> Output Class Initialized
INFO - 2020-10-05 12:06:37 --> Security Class Initialized
DEBUG - 2020-10-05 12:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:06:37 --> Input Class Initialized
INFO - 2020-10-05 12:06:37 --> Language Class Initialized
INFO - 2020-10-05 12:06:37 --> Loader Class Initialized
INFO - 2020-10-05 12:06:37 --> Helper loaded: url_helper
INFO - 2020-10-05 12:06:37 --> Database Driver Class Initialized
INFO - 2020-10-05 12:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:06:37 --> Email Class Initialized
INFO - 2020-10-05 12:06:37 --> Controller Class Initialized
DEBUG - 2020-10-05 12:06:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:06:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:06:37 --> Model Class Initialized
INFO - 2020-10-05 12:06:37 --> Model Class Initialized
INFO - 2020-10-05 12:06:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-05 12:06:37 --> Final output sent to browser
DEBUG - 2020-10-05 12:06:37 --> Total execution time: 0.0248
ERROR - 2020-10-05 12:07:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:07:47 --> Config Class Initialized
INFO - 2020-10-05 12:07:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:07:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:07:47 --> Utf8 Class Initialized
INFO - 2020-10-05 12:07:47 --> URI Class Initialized
INFO - 2020-10-05 12:07:47 --> Router Class Initialized
INFO - 2020-10-05 12:07:47 --> Output Class Initialized
INFO - 2020-10-05 12:07:47 --> Security Class Initialized
DEBUG - 2020-10-05 12:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:07:47 --> Input Class Initialized
INFO - 2020-10-05 12:07:47 --> Language Class Initialized
INFO - 2020-10-05 12:07:47 --> Loader Class Initialized
INFO - 2020-10-05 12:07:47 --> Helper loaded: url_helper
INFO - 2020-10-05 12:07:47 --> Database Driver Class Initialized
INFO - 2020-10-05 12:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:07:47 --> Email Class Initialized
INFO - 2020-10-05 12:07:47 --> Controller Class Initialized
DEBUG - 2020-10-05 12:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:07:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:07:47 --> Model Class Initialized
INFO - 2020-10-05 12:07:47 --> Model Class Initialized
INFO - 2020-10-05 12:07:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-05 12:07:47 --> Final output sent to browser
DEBUG - 2020-10-05 12:07:47 --> Total execution time: 0.0250
ERROR - 2020-10-05 12:08:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:08:10 --> Config Class Initialized
INFO - 2020-10-05 12:08:10 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:08:10 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:08:10 --> Utf8 Class Initialized
INFO - 2020-10-05 12:08:10 --> URI Class Initialized
INFO - 2020-10-05 12:08:10 --> Router Class Initialized
INFO - 2020-10-05 12:08:10 --> Output Class Initialized
INFO - 2020-10-05 12:08:10 --> Security Class Initialized
DEBUG - 2020-10-05 12:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:08:10 --> Input Class Initialized
INFO - 2020-10-05 12:08:10 --> Language Class Initialized
INFO - 2020-10-05 12:08:10 --> Loader Class Initialized
INFO - 2020-10-05 12:08:10 --> Helper loaded: url_helper
INFO - 2020-10-05 12:08:10 --> Database Driver Class Initialized
INFO - 2020-10-05 12:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:08:10 --> Email Class Initialized
INFO - 2020-10-05 12:08:10 --> Controller Class Initialized
DEBUG - 2020-10-05 12:08:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:08:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:08:10 --> Model Class Initialized
INFO - 2020-10-05 12:08:10 --> Model Class Initialized
INFO - 2020-10-05 12:08:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 12:08:10 --> Final output sent to browser
DEBUG - 2020-10-05 12:08:10 --> Total execution time: 0.0311
ERROR - 2020-10-05 12:08:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:08:16 --> Config Class Initialized
INFO - 2020-10-05 12:08:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:08:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:08:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:08:16 --> URI Class Initialized
INFO - 2020-10-05 12:08:16 --> Router Class Initialized
INFO - 2020-10-05 12:08:16 --> Output Class Initialized
INFO - 2020-10-05 12:08:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:08:16 --> Input Class Initialized
INFO - 2020-10-05 12:08:16 --> Language Class Initialized
INFO - 2020-10-05 12:08:16 --> Loader Class Initialized
INFO - 2020-10-05 12:08:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:08:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:08:16 --> Email Class Initialized
INFO - 2020-10-05 12:08:16 --> Controller Class Initialized
DEBUG - 2020-10-05 12:08:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:08:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:08:16 --> Model Class Initialized
INFO - 2020-10-05 12:08:16 --> Model Class Initialized
INFO - 2020-10-05 12:08:16 --> Model Class Initialized
INFO - 2020-10-05 12:08:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-10-05 12:08:16 --> Final output sent to browser
DEBUG - 2020-10-05 12:08:16 --> Total execution time: 0.0260
ERROR - 2020-10-05 12:10:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:10:19 --> Config Class Initialized
INFO - 2020-10-05 12:10:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:10:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:10:19 --> Utf8 Class Initialized
INFO - 2020-10-05 12:10:19 --> URI Class Initialized
INFO - 2020-10-05 12:10:19 --> Router Class Initialized
INFO - 2020-10-05 12:10:19 --> Output Class Initialized
INFO - 2020-10-05 12:10:19 --> Security Class Initialized
DEBUG - 2020-10-05 12:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:10:19 --> Input Class Initialized
INFO - 2020-10-05 12:10:19 --> Language Class Initialized
INFO - 2020-10-05 12:10:19 --> Loader Class Initialized
INFO - 2020-10-05 12:10:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:10:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:10:19 --> Email Class Initialized
INFO - 2020-10-05 12:10:19 --> Controller Class Initialized
DEBUG - 2020-10-05 12:10:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:10:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:10:19 --> Model Class Initialized
INFO - 2020-10-05 12:10:19 --> Model Class Initialized
INFO - 2020-10-05 12:10:19 --> Model Class Initialized
INFO - 2020-10-05 12:10:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-10-05 12:10:19 --> Final output sent to browser
DEBUG - 2020-10-05 12:10:19 --> Total execution time: 0.0251
ERROR - 2020-10-05 12:11:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:11:27 --> Config Class Initialized
INFO - 2020-10-05 12:11:27 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:11:27 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:11:27 --> Utf8 Class Initialized
INFO - 2020-10-05 12:11:27 --> URI Class Initialized
INFO - 2020-10-05 12:11:27 --> Router Class Initialized
INFO - 2020-10-05 12:11:27 --> Output Class Initialized
INFO - 2020-10-05 12:11:27 --> Security Class Initialized
DEBUG - 2020-10-05 12:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:11:27 --> Input Class Initialized
INFO - 2020-10-05 12:11:27 --> Language Class Initialized
INFO - 2020-10-05 12:11:27 --> Loader Class Initialized
INFO - 2020-10-05 12:11:27 --> Helper loaded: url_helper
INFO - 2020-10-05 12:11:27 --> Database Driver Class Initialized
INFO - 2020-10-05 12:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:11:27 --> Email Class Initialized
INFO - 2020-10-05 12:11:27 --> Controller Class Initialized
DEBUG - 2020-10-05 12:11:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:11:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:11:27 --> Model Class Initialized
INFO - 2020-10-05 12:11:27 --> Model Class Initialized
INFO - 2020-10-05 12:11:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 12:11:27 --> Final output sent to browser
DEBUG - 2020-10-05 12:11:27 --> Total execution time: 0.0289
ERROR - 2020-10-05 12:16:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:16:16 --> Config Class Initialized
INFO - 2020-10-05 12:16:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:16:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:16:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:16:16 --> URI Class Initialized
INFO - 2020-10-05 12:16:16 --> Router Class Initialized
INFO - 2020-10-05 12:16:16 --> Output Class Initialized
INFO - 2020-10-05 12:16:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:16:16 --> Input Class Initialized
INFO - 2020-10-05 12:16:16 --> Language Class Initialized
INFO - 2020-10-05 12:16:16 --> Loader Class Initialized
INFO - 2020-10-05 12:16:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:16:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:16:16 --> Email Class Initialized
INFO - 2020-10-05 12:16:16 --> Controller Class Initialized
DEBUG - 2020-10-05 12:16:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:16:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:16:16 --> Model Class Initialized
INFO - 2020-10-05 12:16:16 --> Model Class Initialized
INFO - 2020-10-05 12:16:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 12:16:16 --> Final output sent to browser
DEBUG - 2020-10-05 12:16:16 --> Total execution time: 0.0199
ERROR - 2020-10-05 12:16:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:16:52 --> Config Class Initialized
INFO - 2020-10-05 12:16:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:16:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:16:52 --> Utf8 Class Initialized
INFO - 2020-10-05 12:16:52 --> URI Class Initialized
INFO - 2020-10-05 12:16:52 --> Router Class Initialized
INFO - 2020-10-05 12:16:52 --> Output Class Initialized
INFO - 2020-10-05 12:16:52 --> Security Class Initialized
DEBUG - 2020-10-05 12:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:16:52 --> Input Class Initialized
INFO - 2020-10-05 12:16:52 --> Language Class Initialized
INFO - 2020-10-05 12:16:52 --> Loader Class Initialized
INFO - 2020-10-05 12:16:52 --> Helper loaded: url_helper
INFO - 2020-10-05 12:16:52 --> Database Driver Class Initialized
INFO - 2020-10-05 12:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:16:52 --> Email Class Initialized
INFO - 2020-10-05 12:16:52 --> Controller Class Initialized
DEBUG - 2020-10-05 12:16:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:16:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:16:52 --> Model Class Initialized
INFO - 2020-10-05 12:16:52 --> Model Class Initialized
INFO - 2020-10-05 12:16:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 12:16:52 --> Final output sent to browser
DEBUG - 2020-10-05 12:16:52 --> Total execution time: 0.0180
ERROR - 2020-10-05 12:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:18:32 --> Config Class Initialized
INFO - 2020-10-05 12:18:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:18:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:18:32 --> Utf8 Class Initialized
INFO - 2020-10-05 12:18:32 --> URI Class Initialized
INFO - 2020-10-05 12:18:32 --> Router Class Initialized
INFO - 2020-10-05 12:18:32 --> Output Class Initialized
INFO - 2020-10-05 12:18:32 --> Security Class Initialized
DEBUG - 2020-10-05 12:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:18:32 --> Input Class Initialized
INFO - 2020-10-05 12:18:32 --> Language Class Initialized
INFO - 2020-10-05 12:18:32 --> Loader Class Initialized
INFO - 2020-10-05 12:18:32 --> Helper loaded: url_helper
INFO - 2020-10-05 12:18:32 --> Database Driver Class Initialized
INFO - 2020-10-05 12:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:18:32 --> Email Class Initialized
INFO - 2020-10-05 12:18:32 --> Controller Class Initialized
DEBUG - 2020-10-05 12:18:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:18:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:18:32 --> Model Class Initialized
INFO - 2020-10-05 12:18:32 --> Model Class Initialized
INFO - 2020-10-05 12:18:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 12:18:32 --> Final output sent to browser
DEBUG - 2020-10-05 12:18:32 --> Total execution time: 0.0213
ERROR - 2020-10-05 12:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:18:37 --> Config Class Initialized
INFO - 2020-10-05 12:18:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:18:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:18:37 --> Utf8 Class Initialized
INFO - 2020-10-05 12:18:37 --> URI Class Initialized
INFO - 2020-10-05 12:18:37 --> Router Class Initialized
INFO - 2020-10-05 12:18:37 --> Output Class Initialized
INFO - 2020-10-05 12:18:37 --> Security Class Initialized
DEBUG - 2020-10-05 12:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:18:37 --> Input Class Initialized
INFO - 2020-10-05 12:18:37 --> Language Class Initialized
INFO - 2020-10-05 12:18:37 --> Loader Class Initialized
INFO - 2020-10-05 12:18:37 --> Helper loaded: url_helper
INFO - 2020-10-05 12:18:37 --> Database Driver Class Initialized
INFO - 2020-10-05 12:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:18:37 --> Email Class Initialized
INFO - 2020-10-05 12:18:37 --> Controller Class Initialized
DEBUG - 2020-10-05 12:18:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:18:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:18:37 --> Model Class Initialized
INFO - 2020-10-05 12:18:37 --> Model Class Initialized
INFO - 2020-10-05 12:18:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 12:18:37 --> Final output sent to browser
DEBUG - 2020-10-05 12:18:37 --> Total execution time: 0.0268
ERROR - 2020-10-05 12:18:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:18:40 --> Config Class Initialized
INFO - 2020-10-05 12:18:40 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:18:40 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:18:40 --> Utf8 Class Initialized
INFO - 2020-10-05 12:18:40 --> URI Class Initialized
INFO - 2020-10-05 12:18:40 --> Router Class Initialized
INFO - 2020-10-05 12:18:40 --> Output Class Initialized
INFO - 2020-10-05 12:18:40 --> Security Class Initialized
DEBUG - 2020-10-05 12:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:18:40 --> Input Class Initialized
INFO - 2020-10-05 12:18:40 --> Language Class Initialized
INFO - 2020-10-05 12:18:40 --> Loader Class Initialized
INFO - 2020-10-05 12:18:40 --> Helper loaded: url_helper
INFO - 2020-10-05 12:18:40 --> Database Driver Class Initialized
INFO - 2020-10-05 12:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:18:40 --> Email Class Initialized
INFO - 2020-10-05 12:18:40 --> Controller Class Initialized
DEBUG - 2020-10-05 12:18:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:18:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:18:40 --> Model Class Initialized
INFO - 2020-10-05 12:18:40 --> Model Class Initialized
INFO - 2020-10-05 12:18:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 12:18:40 --> Final output sent to browser
DEBUG - 2020-10-05 12:18:40 --> Total execution time: 0.0242
ERROR - 2020-10-05 12:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:18:59 --> Config Class Initialized
INFO - 2020-10-05 12:18:59 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:18:59 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:18:59 --> Utf8 Class Initialized
INFO - 2020-10-05 12:18:59 --> URI Class Initialized
INFO - 2020-10-05 12:18:59 --> Router Class Initialized
INFO - 2020-10-05 12:18:59 --> Output Class Initialized
INFO - 2020-10-05 12:18:59 --> Security Class Initialized
DEBUG - 2020-10-05 12:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:18:59 --> Input Class Initialized
INFO - 2020-10-05 12:18:59 --> Language Class Initialized
INFO - 2020-10-05 12:18:59 --> Loader Class Initialized
INFO - 2020-10-05 12:18:59 --> Helper loaded: url_helper
INFO - 2020-10-05 12:18:59 --> Database Driver Class Initialized
INFO - 2020-10-05 12:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:18:59 --> Email Class Initialized
INFO - 2020-10-05 12:18:59 --> Controller Class Initialized
DEBUG - 2020-10-05 12:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:18:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:18:59 --> Model Class Initialized
INFO - 2020-10-05 12:18:59 --> Model Class Initialized
INFO - 2020-10-05 12:18:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-05 12:18:59 --> Final output sent to browser
DEBUG - 2020-10-05 12:18:59 --> Total execution time: 0.0224
ERROR - 2020-10-05 12:19:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:19:47 --> Config Class Initialized
INFO - 2020-10-05 12:19:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:19:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:19:47 --> Utf8 Class Initialized
INFO - 2020-10-05 12:19:47 --> URI Class Initialized
INFO - 2020-10-05 12:19:47 --> Router Class Initialized
INFO - 2020-10-05 12:19:47 --> Output Class Initialized
INFO - 2020-10-05 12:19:47 --> Security Class Initialized
DEBUG - 2020-10-05 12:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:19:47 --> Input Class Initialized
INFO - 2020-10-05 12:19:47 --> Language Class Initialized
INFO - 2020-10-05 12:19:47 --> Loader Class Initialized
INFO - 2020-10-05 12:19:47 --> Helper loaded: url_helper
INFO - 2020-10-05 12:19:47 --> Database Driver Class Initialized
INFO - 2020-10-05 12:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:19:47 --> Email Class Initialized
INFO - 2020-10-05 12:19:47 --> Controller Class Initialized
DEBUG - 2020-10-05 12:19:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:19:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:19:47 --> Model Class Initialized
INFO - 2020-10-05 12:19:47 --> Model Class Initialized
INFO - 2020-10-05 12:19:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-05 12:19:47 --> Final output sent to browser
DEBUG - 2020-10-05 12:19:47 --> Total execution time: 0.0201
ERROR - 2020-10-05 12:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:19:54 --> Config Class Initialized
INFO - 2020-10-05 12:19:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:19:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:19:54 --> Utf8 Class Initialized
INFO - 2020-10-05 12:19:54 --> URI Class Initialized
INFO - 2020-10-05 12:19:54 --> Router Class Initialized
INFO - 2020-10-05 12:19:54 --> Output Class Initialized
INFO - 2020-10-05 12:19:54 --> Security Class Initialized
DEBUG - 2020-10-05 12:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:19:54 --> Input Class Initialized
INFO - 2020-10-05 12:19:54 --> Language Class Initialized
INFO - 2020-10-05 12:19:54 --> Loader Class Initialized
INFO - 2020-10-05 12:19:54 --> Helper loaded: url_helper
INFO - 2020-10-05 12:19:54 --> Database Driver Class Initialized
INFO - 2020-10-05 12:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:19:54 --> Email Class Initialized
INFO - 2020-10-05 12:19:54 --> Controller Class Initialized
DEBUG - 2020-10-05 12:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:19:54 --> Model Class Initialized
INFO - 2020-10-05 12:19:54 --> Model Class Initialized
INFO - 2020-10-05 12:19:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-05 12:19:54 --> Final output sent to browser
DEBUG - 2020-10-05 12:19:54 --> Total execution time: 0.0260
ERROR - 2020-10-05 12:19:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:19:58 --> Config Class Initialized
INFO - 2020-10-05 12:19:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:19:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:19:58 --> Utf8 Class Initialized
INFO - 2020-10-05 12:19:58 --> URI Class Initialized
INFO - 2020-10-05 12:19:58 --> Router Class Initialized
INFO - 2020-10-05 12:19:58 --> Output Class Initialized
INFO - 2020-10-05 12:19:58 --> Security Class Initialized
DEBUG - 2020-10-05 12:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:19:58 --> Input Class Initialized
INFO - 2020-10-05 12:19:58 --> Language Class Initialized
INFO - 2020-10-05 12:19:58 --> Loader Class Initialized
INFO - 2020-10-05 12:19:58 --> Helper loaded: url_helper
INFO - 2020-10-05 12:19:58 --> Database Driver Class Initialized
INFO - 2020-10-05 12:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:19:58 --> Email Class Initialized
INFO - 2020-10-05 12:19:58 --> Controller Class Initialized
INFO - 2020-10-05 12:19:58 --> Model Class Initialized
INFO - 2020-10-05 12:19:58 --> Model Class Initialized
INFO - 2020-10-05 12:19:58 --> Model Class Initialized
INFO - 2020-10-05 12:19:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-05 12:19:58 --> Final output sent to browser
DEBUG - 2020-10-05 12:19:58 --> Total execution time: 0.1811
ERROR - 2020-10-05 12:19:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:19:59 --> Config Class Initialized
INFO - 2020-10-05 12:19:59 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:19:59 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:19:59 --> Utf8 Class Initialized
INFO - 2020-10-05 12:19:59 --> URI Class Initialized
INFO - 2020-10-05 12:19:59 --> Router Class Initialized
INFO - 2020-10-05 12:19:59 --> Output Class Initialized
INFO - 2020-10-05 12:19:59 --> Security Class Initialized
DEBUG - 2020-10-05 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:19:59 --> Input Class Initialized
INFO - 2020-10-05 12:19:59 --> Language Class Initialized
INFO - 2020-10-05 12:19:59 --> Loader Class Initialized
INFO - 2020-10-05 12:19:59 --> Helper loaded: url_helper
INFO - 2020-10-05 12:19:59 --> Database Driver Class Initialized
INFO - 2020-10-05 12:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:19:59 --> Email Class Initialized
INFO - 2020-10-05 12:19:59 --> Controller Class Initialized
INFO - 2020-10-05 12:19:59 --> Model Class Initialized
INFO - 2020-10-05 12:19:59 --> Model Class Initialized
INFO - 2020-10-05 12:19:59 --> Final output sent to browser
DEBUG - 2020-10-05 12:19:59 --> Total execution time: 0.0387
ERROR - 2020-10-05 12:21:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:21:08 --> Config Class Initialized
INFO - 2020-10-05 12:21:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:08 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:08 --> URI Class Initialized
INFO - 2020-10-05 12:21:08 --> Router Class Initialized
INFO - 2020-10-05 12:21:08 --> Output Class Initialized
INFO - 2020-10-05 12:21:08 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:08 --> Input Class Initialized
INFO - 2020-10-05 12:21:08 --> Language Class Initialized
INFO - 2020-10-05 12:21:08 --> Loader Class Initialized
INFO - 2020-10-05 12:21:08 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:08 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:08 --> Email Class Initialized
INFO - 2020-10-05 12:21:08 --> Controller Class Initialized
INFO - 2020-10-05 12:21:08 --> Model Class Initialized
INFO - 2020-10-05 12:21:08 --> Model Class Initialized
INFO - 2020-10-05 12:21:08 --> Model Class Initialized
INFO - 2020-10-05 12:21:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-10-05 12:21:08 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:08 --> Total execution time: 0.0428
ERROR - 2020-10-05 12:21:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:21:14 --> Config Class Initialized
INFO - 2020-10-05 12:21:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:14 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:14 --> URI Class Initialized
INFO - 2020-10-05 12:21:14 --> Router Class Initialized
INFO - 2020-10-05 12:21:14 --> Output Class Initialized
INFO - 2020-10-05 12:21:14 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:14 --> Input Class Initialized
INFO - 2020-10-05 12:21:14 --> Language Class Initialized
INFO - 2020-10-05 12:21:14 --> Loader Class Initialized
INFO - 2020-10-05 12:21:14 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:14 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:14 --> Email Class Initialized
INFO - 2020-10-05 12:21:14 --> Controller Class Initialized
INFO - 2020-10-05 12:21:14 --> Model Class Initialized
INFO - 2020-10-05 12:21:14 --> Model Class Initialized
INFO - 2020-10-05 12:21:14 --> Model Class Initialized
INFO - 2020-10-05 12:21:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-05 12:21:14 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:14 --> Total execution time: 0.0401
ERROR - 2020-10-05 12:21:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:21:15 --> Config Class Initialized
INFO - 2020-10-05 12:21:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:15 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:15 --> URI Class Initialized
INFO - 2020-10-05 12:21:15 --> Router Class Initialized
INFO - 2020-10-05 12:21:15 --> Output Class Initialized
INFO - 2020-10-05 12:21:15 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:15 --> Input Class Initialized
INFO - 2020-10-05 12:21:15 --> Language Class Initialized
INFO - 2020-10-05 12:21:15 --> Loader Class Initialized
INFO - 2020-10-05 12:21:15 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:15 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:15 --> Email Class Initialized
INFO - 2020-10-05 12:21:15 --> Controller Class Initialized
INFO - 2020-10-05 12:21:15 --> Model Class Initialized
INFO - 2020-10-05 12:21:15 --> Model Class Initialized
INFO - 2020-10-05 12:21:15 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:15 --> Total execution time: 0.0414
ERROR - 2020-10-05 12:21:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:21:18 --> Config Class Initialized
INFO - 2020-10-05 12:21:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:18 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:18 --> URI Class Initialized
INFO - 2020-10-05 12:21:18 --> Router Class Initialized
INFO - 2020-10-05 12:21:18 --> Output Class Initialized
INFO - 2020-10-05 12:21:18 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:18 --> Input Class Initialized
INFO - 2020-10-05 12:21:18 --> Language Class Initialized
INFO - 2020-10-05 12:21:18 --> Loader Class Initialized
INFO - 2020-10-05 12:21:18 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:18 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:18 --> Email Class Initialized
INFO - 2020-10-05 12:21:18 --> Controller Class Initialized
DEBUG - 2020-10-05 12:21:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:21:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:21:18 --> Model Class Initialized
INFO - 2020-10-05 12:21:18 --> Model Class Initialized
INFO - 2020-10-05 12:21:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-05 12:21:18 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:18 --> Total execution time: 0.0214
ERROR - 2020-10-05 12:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:21:22 --> Config Class Initialized
INFO - 2020-10-05 12:21:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:22 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:22 --> URI Class Initialized
INFO - 2020-10-05 12:21:22 --> Router Class Initialized
INFO - 2020-10-05 12:21:22 --> Output Class Initialized
INFO - 2020-10-05 12:21:22 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:22 --> Input Class Initialized
INFO - 2020-10-05 12:21:22 --> Language Class Initialized
INFO - 2020-10-05 12:21:22 --> Loader Class Initialized
INFO - 2020-10-05 12:21:22 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:22 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:22 --> Email Class Initialized
INFO - 2020-10-05 12:21:22 --> Controller Class Initialized
DEBUG - 2020-10-05 12:21:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:21:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:21:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 12:21:22 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:22 --> Total execution time: 0.0196
ERROR - 2020-10-05 12:21:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:21:31 --> Config Class Initialized
INFO - 2020-10-05 12:21:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:21:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:21:31 --> Utf8 Class Initialized
INFO - 2020-10-05 12:21:31 --> URI Class Initialized
INFO - 2020-10-05 12:21:31 --> Router Class Initialized
INFO - 2020-10-05 12:21:31 --> Output Class Initialized
INFO - 2020-10-05 12:21:31 --> Security Class Initialized
DEBUG - 2020-10-05 12:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:21:31 --> Input Class Initialized
INFO - 2020-10-05 12:21:31 --> Language Class Initialized
INFO - 2020-10-05 12:21:31 --> Loader Class Initialized
INFO - 2020-10-05 12:21:31 --> Helper loaded: url_helper
INFO - 2020-10-05 12:21:31 --> Database Driver Class Initialized
INFO - 2020-10-05 12:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:21:31 --> Email Class Initialized
INFO - 2020-10-05 12:21:31 --> Controller Class Initialized
DEBUG - 2020-10-05 12:21:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:21:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:21:31 --> Model Class Initialized
INFO - 2020-10-05 12:21:31 --> Model Class Initialized
INFO - 2020-10-05 12:21:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-05 12:21:31 --> Final output sent to browser
DEBUG - 2020-10-05 12:21:31 --> Total execution time: 0.0444
ERROR - 2020-10-05 12:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:22:18 --> Config Class Initialized
INFO - 2020-10-05 12:22:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:22:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:22:18 --> Utf8 Class Initialized
INFO - 2020-10-05 12:22:18 --> URI Class Initialized
INFO - 2020-10-05 12:22:18 --> Router Class Initialized
INFO - 2020-10-05 12:22:18 --> Output Class Initialized
INFO - 2020-10-05 12:22:18 --> Security Class Initialized
DEBUG - 2020-10-05 12:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:22:18 --> Input Class Initialized
INFO - 2020-10-05 12:22:18 --> Language Class Initialized
INFO - 2020-10-05 12:22:18 --> Loader Class Initialized
INFO - 2020-10-05 12:22:18 --> Helper loaded: url_helper
INFO - 2020-10-05 12:22:18 --> Database Driver Class Initialized
INFO - 2020-10-05 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:22:18 --> Email Class Initialized
INFO - 2020-10-05 12:22:18 --> Controller Class Initialized
DEBUG - 2020-10-05 12:22:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:22:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:22:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 12:22:18 --> Final output sent to browser
DEBUG - 2020-10-05 12:22:18 --> Total execution time: 0.0199
ERROR - 2020-10-05 12:22:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:22:26 --> Config Class Initialized
INFO - 2020-10-05 12:22:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:22:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:22:26 --> Utf8 Class Initialized
INFO - 2020-10-05 12:22:26 --> URI Class Initialized
DEBUG - 2020-10-05 12:22:26 --> No URI present. Default controller set.
INFO - 2020-10-05 12:22:26 --> Router Class Initialized
INFO - 2020-10-05 12:22:26 --> Output Class Initialized
INFO - 2020-10-05 12:22:26 --> Security Class Initialized
DEBUG - 2020-10-05 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:22:27 --> Input Class Initialized
INFO - 2020-10-05 12:22:27 --> Language Class Initialized
INFO - 2020-10-05 12:22:27 --> Loader Class Initialized
INFO - 2020-10-05 12:22:27 --> Helper loaded: url_helper
INFO - 2020-10-05 12:22:27 --> Database Driver Class Initialized
INFO - 2020-10-05 12:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:22:27 --> Email Class Initialized
INFO - 2020-10-05 12:22:27 --> Controller Class Initialized
INFO - 2020-10-05 12:22:27 --> Model Class Initialized
INFO - 2020-10-05 12:22:27 --> Model Class Initialized
DEBUG - 2020-10-05 12:22:27 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:22:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 12:22:27 --> Final output sent to browser
DEBUG - 2020-10-05 12:22:27 --> Total execution time: 0.0198
ERROR - 2020-10-05 12:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:25:12 --> Config Class Initialized
INFO - 2020-10-05 12:25:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:25:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:25:12 --> Utf8 Class Initialized
INFO - 2020-10-05 12:25:12 --> URI Class Initialized
INFO - 2020-10-05 12:25:12 --> Router Class Initialized
INFO - 2020-10-05 12:25:12 --> Output Class Initialized
INFO - 2020-10-05 12:25:12 --> Security Class Initialized
DEBUG - 2020-10-05 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:25:12 --> Input Class Initialized
INFO - 2020-10-05 12:25:12 --> Language Class Initialized
INFO - 2020-10-05 12:25:12 --> Loader Class Initialized
INFO - 2020-10-05 12:25:12 --> Helper loaded: url_helper
INFO - 2020-10-05 12:25:12 --> Database Driver Class Initialized
INFO - 2020-10-05 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:25:12 --> Email Class Initialized
INFO - 2020-10-05 12:25:12 --> Controller Class Initialized
INFO - 2020-10-05 12:25:12 --> Model Class Initialized
INFO - 2020-10-05 12:25:12 --> Model Class Initialized
DEBUG - 2020-10-05 12:25:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 12:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:25:12 --> Config Class Initialized
INFO - 2020-10-05 12:25:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:25:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:25:12 --> Utf8 Class Initialized
INFO - 2020-10-05 12:25:12 --> URI Class Initialized
INFO - 2020-10-05 12:25:12 --> Router Class Initialized
INFO - 2020-10-05 12:25:12 --> Output Class Initialized
INFO - 2020-10-05 12:25:12 --> Security Class Initialized
DEBUG - 2020-10-05 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:25:12 --> Input Class Initialized
INFO - 2020-10-05 12:25:12 --> Language Class Initialized
INFO - 2020-10-05 12:25:12 --> Loader Class Initialized
INFO - 2020-10-05 12:25:12 --> Helper loaded: url_helper
INFO - 2020-10-05 12:25:12 --> Database Driver Class Initialized
INFO - 2020-10-05 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:25:12 --> Email Class Initialized
INFO - 2020-10-05 12:25:12 --> Controller Class Initialized
INFO - 2020-10-05 12:25:12 --> Model Class Initialized
INFO - 2020-10-05 12:25:12 --> Model Class Initialized
DEBUG - 2020-10-05 12:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:25:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:25:12 --> Model Class Initialized
INFO - 2020-10-05 12:25:12 --> Final output sent to browser
DEBUG - 2020-10-05 12:25:12 --> Total execution time: 0.0222
ERROR - 2020-10-05 12:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:25:12 --> Config Class Initialized
INFO - 2020-10-05 12:25:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:25:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:25:12 --> Utf8 Class Initialized
INFO - 2020-10-05 12:25:12 --> URI Class Initialized
INFO - 2020-10-05 12:25:12 --> Router Class Initialized
INFO - 2020-10-05 12:25:12 --> Output Class Initialized
INFO - 2020-10-05 12:25:12 --> Security Class Initialized
DEBUG - 2020-10-05 12:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:25:12 --> Input Class Initialized
INFO - 2020-10-05 12:25:12 --> Language Class Initialized
INFO - 2020-10-05 12:25:12 --> Loader Class Initialized
INFO - 2020-10-05 12:25:12 --> Helper loaded: url_helper
INFO - 2020-10-05 12:25:12 --> Database Driver Class Initialized
INFO - 2020-10-05 12:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:25:12 --> Email Class Initialized
INFO - 2020-10-05 12:25:12 --> Controller Class Initialized
DEBUG - 2020-10-05 12:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:25:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:25:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 12:25:12 --> Final output sent to browser
DEBUG - 2020-10-05 12:25:12 --> Total execution time: 0.0180
ERROR - 2020-10-05 12:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:25:19 --> Config Class Initialized
INFO - 2020-10-05 12:25:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:25:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:25:19 --> Utf8 Class Initialized
INFO - 2020-10-05 12:25:19 --> URI Class Initialized
INFO - 2020-10-05 12:25:19 --> Router Class Initialized
INFO - 2020-10-05 12:25:19 --> Output Class Initialized
INFO - 2020-10-05 12:25:19 --> Security Class Initialized
DEBUG - 2020-10-05 12:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:25:19 --> Input Class Initialized
INFO - 2020-10-05 12:25:19 --> Language Class Initialized
INFO - 2020-10-05 12:25:19 --> Loader Class Initialized
INFO - 2020-10-05 12:25:19 --> Helper loaded: url_helper
INFO - 2020-10-05 12:25:19 --> Database Driver Class Initialized
INFO - 2020-10-05 12:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:25:19 --> Email Class Initialized
INFO - 2020-10-05 12:25:19 --> Controller Class Initialized
DEBUG - 2020-10-05 12:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:25:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:25:19 --> Model Class Initialized
INFO - 2020-10-05 12:25:19 --> Model Class Initialized
INFO - 2020-10-05 12:25:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-05 12:25:19 --> Final output sent to browser
DEBUG - 2020-10-05 12:25:19 --> Total execution time: 0.0238
ERROR - 2020-10-05 12:25:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:25:22 --> Config Class Initialized
INFO - 2020-10-05 12:25:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:25:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:25:22 --> Utf8 Class Initialized
INFO - 2020-10-05 12:25:22 --> URI Class Initialized
INFO - 2020-10-05 12:25:22 --> Router Class Initialized
INFO - 2020-10-05 12:25:22 --> Output Class Initialized
INFO - 2020-10-05 12:25:22 --> Security Class Initialized
DEBUG - 2020-10-05 12:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:25:22 --> Input Class Initialized
INFO - 2020-10-05 12:25:22 --> Language Class Initialized
INFO - 2020-10-05 12:25:22 --> Loader Class Initialized
INFO - 2020-10-05 12:25:22 --> Helper loaded: url_helper
INFO - 2020-10-05 12:25:22 --> Database Driver Class Initialized
INFO - 2020-10-05 12:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:25:22 --> Email Class Initialized
INFO - 2020-10-05 12:25:22 --> Controller Class Initialized
DEBUG - 2020-10-05 12:25:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:25:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:25:22 --> Model Class Initialized
INFO - 2020-10-05 12:25:22 --> Model Class Initialized
INFO - 2020-10-05 12:25:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-05 12:25:22 --> Final output sent to browser
DEBUG - 2020-10-05 12:25:22 --> Total execution time: 0.0306
ERROR - 2020-10-05 12:25:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:25:30 --> Config Class Initialized
INFO - 2020-10-05 12:25:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:25:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:25:30 --> Utf8 Class Initialized
INFO - 2020-10-05 12:25:30 --> URI Class Initialized
INFO - 2020-10-05 12:25:30 --> Router Class Initialized
INFO - 2020-10-05 12:25:30 --> Output Class Initialized
INFO - 2020-10-05 12:25:30 --> Security Class Initialized
DEBUG - 2020-10-05 12:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:25:30 --> Input Class Initialized
INFO - 2020-10-05 12:25:30 --> Language Class Initialized
INFO - 2020-10-05 12:25:30 --> Loader Class Initialized
INFO - 2020-10-05 12:25:30 --> Helper loaded: url_helper
INFO - 2020-10-05 12:25:30 --> Database Driver Class Initialized
INFO - 2020-10-05 12:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:25:30 --> Email Class Initialized
INFO - 2020-10-05 12:25:30 --> Controller Class Initialized
DEBUG - 2020-10-05 12:25:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:25:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:25:30 --> Model Class Initialized
INFO - 2020-10-05 12:25:30 --> Model Class Initialized
INFO - 2020-10-05 12:25:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-05 12:25:30 --> Final output sent to browser
DEBUG - 2020-10-05 12:25:30 --> Total execution time: 0.0283
ERROR - 2020-10-05 12:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:28:40 --> Config Class Initialized
INFO - 2020-10-05 12:28:40 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:28:40 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:28:40 --> Utf8 Class Initialized
INFO - 2020-10-05 12:28:40 --> URI Class Initialized
DEBUG - 2020-10-05 12:28:40 --> No URI present. Default controller set.
INFO - 2020-10-05 12:28:40 --> Router Class Initialized
INFO - 2020-10-05 12:28:40 --> Output Class Initialized
INFO - 2020-10-05 12:28:40 --> Security Class Initialized
DEBUG - 2020-10-05 12:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:28:40 --> Input Class Initialized
INFO - 2020-10-05 12:28:40 --> Language Class Initialized
INFO - 2020-10-05 12:28:40 --> Loader Class Initialized
INFO - 2020-10-05 12:28:40 --> Helper loaded: url_helper
INFO - 2020-10-05 12:28:40 --> Database Driver Class Initialized
INFO - 2020-10-05 12:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:28:40 --> Email Class Initialized
INFO - 2020-10-05 12:28:40 --> Controller Class Initialized
INFO - 2020-10-05 12:28:40 --> Model Class Initialized
INFO - 2020-10-05 12:28:40 --> Model Class Initialized
DEBUG - 2020-10-05 12:28:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:28:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 12:28:40 --> Final output sent to browser
DEBUG - 2020-10-05 12:28:40 --> Total execution time: 0.0187
ERROR - 2020-10-05 12:28:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:28:48 --> Config Class Initialized
INFO - 2020-10-05 12:28:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:28:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:28:48 --> Utf8 Class Initialized
INFO - 2020-10-05 12:28:48 --> URI Class Initialized
INFO - 2020-10-05 12:28:48 --> Router Class Initialized
INFO - 2020-10-05 12:28:48 --> Output Class Initialized
INFO - 2020-10-05 12:28:48 --> Security Class Initialized
DEBUG - 2020-10-05 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:28:48 --> Input Class Initialized
INFO - 2020-10-05 12:28:48 --> Language Class Initialized
INFO - 2020-10-05 12:28:48 --> Loader Class Initialized
INFO - 2020-10-05 12:28:48 --> Helper loaded: url_helper
INFO - 2020-10-05 12:28:48 --> Database Driver Class Initialized
INFO - 2020-10-05 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:28:48 --> Email Class Initialized
INFO - 2020-10-05 12:28:48 --> Controller Class Initialized
INFO - 2020-10-05 12:28:48 --> Model Class Initialized
INFO - 2020-10-05 12:28:48 --> Model Class Initialized
DEBUG - 2020-10-05 12:28:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:28:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:28:48 --> Model Class Initialized
INFO - 2020-10-05 12:28:48 --> Final output sent to browser
DEBUG - 2020-10-05 12:28:48 --> Total execution time: 0.0222
ERROR - 2020-10-05 12:28:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:28:48 --> Config Class Initialized
INFO - 2020-10-05 12:28:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:28:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:28:48 --> Utf8 Class Initialized
INFO - 2020-10-05 12:28:48 --> URI Class Initialized
INFO - 2020-10-05 12:28:48 --> Router Class Initialized
INFO - 2020-10-05 12:28:48 --> Output Class Initialized
INFO - 2020-10-05 12:28:48 --> Security Class Initialized
DEBUG - 2020-10-05 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:28:48 --> Input Class Initialized
INFO - 2020-10-05 12:28:48 --> Language Class Initialized
INFO - 2020-10-05 12:28:48 --> Loader Class Initialized
INFO - 2020-10-05 12:28:48 --> Helper loaded: url_helper
INFO - 2020-10-05 12:28:48 --> Database Driver Class Initialized
INFO - 2020-10-05 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:28:48 --> Email Class Initialized
INFO - 2020-10-05 12:28:48 --> Controller Class Initialized
INFO - 2020-10-05 12:28:48 --> Model Class Initialized
INFO - 2020-10-05 12:28:48 --> Model Class Initialized
DEBUG - 2020-10-05 12:28:48 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 12:28:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:28:49 --> Config Class Initialized
INFO - 2020-10-05 12:28:49 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:28:49 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:28:49 --> Utf8 Class Initialized
INFO - 2020-10-05 12:28:49 --> URI Class Initialized
INFO - 2020-10-05 12:28:49 --> Router Class Initialized
INFO - 2020-10-05 12:28:49 --> Output Class Initialized
INFO - 2020-10-05 12:28:49 --> Security Class Initialized
DEBUG - 2020-10-05 12:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:28:49 --> Input Class Initialized
INFO - 2020-10-05 12:28:49 --> Language Class Initialized
INFO - 2020-10-05 12:28:49 --> Loader Class Initialized
INFO - 2020-10-05 12:28:49 --> Helper loaded: url_helper
INFO - 2020-10-05 12:28:49 --> Database Driver Class Initialized
INFO - 2020-10-05 12:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:28:49 --> Email Class Initialized
INFO - 2020-10-05 12:28:49 --> Controller Class Initialized
DEBUG - 2020-10-05 12:28:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:28:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:28:49 --> Model Class Initialized
INFO - 2020-10-05 12:28:49 --> Model Class Initialized
INFO - 2020-10-05 12:28:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-05 12:28:49 --> Final output sent to browser
DEBUG - 2020-10-05 12:28:49 --> Total execution time: 0.0253
ERROR - 2020-10-05 12:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:28:56 --> Config Class Initialized
INFO - 2020-10-05 12:28:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:28:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:28:56 --> Utf8 Class Initialized
INFO - 2020-10-05 12:28:56 --> URI Class Initialized
INFO - 2020-10-05 12:28:56 --> Router Class Initialized
INFO - 2020-10-05 12:28:56 --> Output Class Initialized
INFO - 2020-10-05 12:28:56 --> Security Class Initialized
DEBUG - 2020-10-05 12:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:28:56 --> Input Class Initialized
INFO - 2020-10-05 12:28:56 --> Language Class Initialized
INFO - 2020-10-05 12:28:56 --> Loader Class Initialized
INFO - 2020-10-05 12:28:56 --> Helper loaded: url_helper
INFO - 2020-10-05 12:28:56 --> Database Driver Class Initialized
INFO - 2020-10-05 12:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:28:56 --> Email Class Initialized
INFO - 2020-10-05 12:28:56 --> Controller Class Initialized
DEBUG - 2020-10-05 12:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:28:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:28:56 --> Model Class Initialized
INFO - 2020-10-05 12:28:56 --> Model Class Initialized
INFO - 2020-10-05 12:28:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-05 12:28:56 --> Final output sent to browser
DEBUG - 2020-10-05 12:28:56 --> Total execution time: 0.0220
ERROR - 2020-10-05 12:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:29:01 --> Config Class Initialized
INFO - 2020-10-05 12:29:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:29:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:29:01 --> Utf8 Class Initialized
INFO - 2020-10-05 12:29:01 --> URI Class Initialized
INFO - 2020-10-05 12:29:01 --> Router Class Initialized
INFO - 2020-10-05 12:29:01 --> Output Class Initialized
INFO - 2020-10-05 12:29:01 --> Security Class Initialized
DEBUG - 2020-10-05 12:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:29:01 --> Input Class Initialized
INFO - 2020-10-05 12:29:01 --> Language Class Initialized
INFO - 2020-10-05 12:29:01 --> Loader Class Initialized
INFO - 2020-10-05 12:29:01 --> Helper loaded: url_helper
INFO - 2020-10-05 12:29:01 --> Database Driver Class Initialized
INFO - 2020-10-05 12:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:29:01 --> Email Class Initialized
INFO - 2020-10-05 12:29:01 --> Controller Class Initialized
DEBUG - 2020-10-05 12:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:29:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:29:01 --> Model Class Initialized
INFO - 2020-10-05 12:29:01 --> Model Class Initialized
INFO - 2020-10-05 12:29:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-05 12:29:01 --> Final output sent to browser
DEBUG - 2020-10-05 12:29:01 --> Total execution time: 0.0197
ERROR - 2020-10-05 12:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:30:54 --> Config Class Initialized
INFO - 2020-10-05 12:30:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:30:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:30:54 --> Utf8 Class Initialized
INFO - 2020-10-05 12:30:54 --> URI Class Initialized
INFO - 2020-10-05 12:30:54 --> Router Class Initialized
INFO - 2020-10-05 12:30:54 --> Output Class Initialized
INFO - 2020-10-05 12:30:54 --> Security Class Initialized
DEBUG - 2020-10-05 12:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:30:54 --> Input Class Initialized
INFO - 2020-10-05 12:30:54 --> Language Class Initialized
INFO - 2020-10-05 12:30:54 --> Loader Class Initialized
INFO - 2020-10-05 12:30:54 --> Helper loaded: url_helper
INFO - 2020-10-05 12:30:54 --> Database Driver Class Initialized
INFO - 2020-10-05 12:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:30:54 --> Email Class Initialized
INFO - 2020-10-05 12:30:54 --> Controller Class Initialized
DEBUG - 2020-10-05 12:30:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:30:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:30:54 --> Model Class Initialized
INFO - 2020-10-05 12:30:54 --> Model Class Initialized
INFO - 2020-10-05 12:30:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-05 12:30:54 --> Final output sent to browser
DEBUG - 2020-10-05 12:30:54 --> Total execution time: 0.0215
ERROR - 2020-10-05 12:30:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:30:57 --> Config Class Initialized
INFO - 2020-10-05 12:30:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:30:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:30:57 --> Utf8 Class Initialized
INFO - 2020-10-05 12:30:57 --> URI Class Initialized
INFO - 2020-10-05 12:30:57 --> Router Class Initialized
INFO - 2020-10-05 12:30:57 --> Output Class Initialized
INFO - 2020-10-05 12:30:57 --> Security Class Initialized
DEBUG - 2020-10-05 12:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:30:57 --> Input Class Initialized
INFO - 2020-10-05 12:30:57 --> Language Class Initialized
INFO - 2020-10-05 12:30:57 --> Loader Class Initialized
INFO - 2020-10-05 12:30:57 --> Helper loaded: url_helper
INFO - 2020-10-05 12:30:57 --> Database Driver Class Initialized
INFO - 2020-10-05 12:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:30:57 --> Email Class Initialized
INFO - 2020-10-05 12:30:57 --> Controller Class Initialized
DEBUG - 2020-10-05 12:30:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:30:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:30:57 --> Model Class Initialized
INFO - 2020-10-05 12:30:57 --> Model Class Initialized
INFO - 2020-10-05 12:30:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-05 12:30:57 --> Final output sent to browser
DEBUG - 2020-10-05 12:30:57 --> Total execution time: 0.0205
ERROR - 2020-10-05 12:31:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:10 --> Config Class Initialized
INFO - 2020-10-05 12:31:10 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:10 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:10 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:10 --> URI Class Initialized
INFO - 2020-10-05 12:31:10 --> Router Class Initialized
INFO - 2020-10-05 12:31:10 --> Output Class Initialized
INFO - 2020-10-05 12:31:10 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:10 --> Input Class Initialized
INFO - 2020-10-05 12:31:10 --> Language Class Initialized
INFO - 2020-10-05 12:31:10 --> Loader Class Initialized
INFO - 2020-10-05 12:31:10 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:10 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:10 --> Email Class Initialized
INFO - 2020-10-05 12:31:10 --> Controller Class Initialized
DEBUG - 2020-10-05 12:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:31:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:31:10 --> Model Class Initialized
INFO - 2020-10-05 12:31:10 --> Model Class Initialized
INFO - 2020-10-05 12:31:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_edit.php
INFO - 2020-10-05 12:31:10 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:10 --> Total execution time: 0.0291
ERROR - 2020-10-05 12:31:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:13 --> Config Class Initialized
INFO - 2020-10-05 12:31:13 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:13 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:13 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:13 --> URI Class Initialized
DEBUG - 2020-10-05 12:31:13 --> No URI present. Default controller set.
INFO - 2020-10-05 12:31:13 --> Router Class Initialized
INFO - 2020-10-05 12:31:13 --> Output Class Initialized
INFO - 2020-10-05 12:31:13 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:13 --> Input Class Initialized
INFO - 2020-10-05 12:31:13 --> Language Class Initialized
INFO - 2020-10-05 12:31:13 --> Loader Class Initialized
INFO - 2020-10-05 12:31:13 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:13 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:13 --> Email Class Initialized
INFO - 2020-10-05 12:31:13 --> Controller Class Initialized
INFO - 2020-10-05 12:31:13 --> Model Class Initialized
INFO - 2020-10-05 12:31:13 --> Model Class Initialized
DEBUG - 2020-10-05 12:31:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:31:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 12:31:13 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:13 --> Total execution time: 0.0214
ERROR - 2020-10-05 12:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:16 --> Config Class Initialized
INFO - 2020-10-05 12:31:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:16 --> URI Class Initialized
INFO - 2020-10-05 12:31:16 --> Router Class Initialized
INFO - 2020-10-05 12:31:16 --> Output Class Initialized
INFO - 2020-10-05 12:31:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:16 --> Input Class Initialized
INFO - 2020-10-05 12:31:16 --> Language Class Initialized
INFO - 2020-10-05 12:31:16 --> Loader Class Initialized
INFO - 2020-10-05 12:31:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:16 --> Email Class Initialized
INFO - 2020-10-05 12:31:16 --> Controller Class Initialized
INFO - 2020-10-05 12:31:16 --> Model Class Initialized
INFO - 2020-10-05 12:31:16 --> Model Class Initialized
DEBUG - 2020-10-05 12:31:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:31:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:31:16 --> Model Class Initialized
INFO - 2020-10-05 12:31:16 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:16 --> Total execution time: 0.0211
ERROR - 2020-10-05 12:31:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:16 --> Config Class Initialized
INFO - 2020-10-05 12:31:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:16 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:16 --> URI Class Initialized
INFO - 2020-10-05 12:31:16 --> Router Class Initialized
INFO - 2020-10-05 12:31:16 --> Output Class Initialized
INFO - 2020-10-05 12:31:16 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:16 --> Input Class Initialized
INFO - 2020-10-05 12:31:16 --> Language Class Initialized
INFO - 2020-10-05 12:31:16 --> Loader Class Initialized
INFO - 2020-10-05 12:31:16 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:16 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:16 --> Email Class Initialized
INFO - 2020-10-05 12:31:16 --> Controller Class Initialized
INFO - 2020-10-05 12:31:16 --> Model Class Initialized
INFO - 2020-10-05 12:31:16 --> Model Class Initialized
DEBUG - 2020-10-05 12:31:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 12:31:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:17 --> Config Class Initialized
INFO - 2020-10-05 12:31:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:17 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:17 --> URI Class Initialized
INFO - 2020-10-05 12:31:17 --> Router Class Initialized
INFO - 2020-10-05 12:31:17 --> Output Class Initialized
INFO - 2020-10-05 12:31:17 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:17 --> Input Class Initialized
INFO - 2020-10-05 12:31:17 --> Language Class Initialized
INFO - 2020-10-05 12:31:17 --> Loader Class Initialized
INFO - 2020-10-05 12:31:17 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:17 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:17 --> Email Class Initialized
INFO - 2020-10-05 12:31:17 --> Controller Class Initialized
DEBUG - 2020-10-05 12:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:31:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:31:17 --> Model Class Initialized
INFO - 2020-10-05 12:31:17 --> Model Class Initialized
INFO - 2020-10-05 12:31:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-05 12:31:17 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:17 --> Total execution time: 0.0208
ERROR - 2020-10-05 12:31:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:22 --> Config Class Initialized
INFO - 2020-10-05 12:31:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:22 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:22 --> URI Class Initialized
INFO - 2020-10-05 12:31:22 --> Router Class Initialized
INFO - 2020-10-05 12:31:22 --> Output Class Initialized
INFO - 2020-10-05 12:31:22 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:22 --> Input Class Initialized
INFO - 2020-10-05 12:31:22 --> Language Class Initialized
INFO - 2020-10-05 12:31:22 --> Loader Class Initialized
INFO - 2020-10-05 12:31:22 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:22 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:22 --> Email Class Initialized
INFO - 2020-10-05 12:31:22 --> Controller Class Initialized
DEBUG - 2020-10-05 12:31:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:31:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:31:22 --> Model Class Initialized
INFO - 2020-10-05 12:31:22 --> Model Class Initialized
INFO - 2020-10-05 12:31:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-05 12:31:22 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:22 --> Total execution time: 0.0199
ERROR - 2020-10-05 12:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 12:31:29 --> Config Class Initialized
INFO - 2020-10-05 12:31:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 12:31:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 12:31:29 --> Utf8 Class Initialized
INFO - 2020-10-05 12:31:29 --> URI Class Initialized
INFO - 2020-10-05 12:31:29 --> Router Class Initialized
INFO - 2020-10-05 12:31:29 --> Output Class Initialized
INFO - 2020-10-05 12:31:29 --> Security Class Initialized
DEBUG - 2020-10-05 12:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 12:31:29 --> Input Class Initialized
INFO - 2020-10-05 12:31:29 --> Language Class Initialized
INFO - 2020-10-05 12:31:29 --> Loader Class Initialized
INFO - 2020-10-05 12:31:29 --> Helper loaded: url_helper
INFO - 2020-10-05 12:31:29 --> Database Driver Class Initialized
INFO - 2020-10-05 12:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 12:31:29 --> Email Class Initialized
INFO - 2020-10-05 12:31:29 --> Controller Class Initialized
DEBUG - 2020-10-05 12:31:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 12:31:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 12:31:29 --> Model Class Initialized
INFO - 2020-10-05 12:31:29 --> Model Class Initialized
INFO - 2020-10-05 12:31:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-05 12:31:29 --> Final output sent to browser
DEBUG - 2020-10-05 12:31:29 --> Total execution time: 0.0210
ERROR - 2020-10-05 15:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:25:12 --> Config Class Initialized
INFO - 2020-10-05 15:25:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:25:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:25:12 --> Utf8 Class Initialized
INFO - 2020-10-05 15:25:12 --> URI Class Initialized
DEBUG - 2020-10-05 15:25:12 --> No URI present. Default controller set.
INFO - 2020-10-05 15:25:12 --> Router Class Initialized
INFO - 2020-10-05 15:25:12 --> Output Class Initialized
INFO - 2020-10-05 15:25:12 --> Security Class Initialized
DEBUG - 2020-10-05 15:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:25:12 --> Input Class Initialized
INFO - 2020-10-05 15:25:12 --> Language Class Initialized
INFO - 2020-10-05 15:25:12 --> Loader Class Initialized
INFO - 2020-10-05 15:25:12 --> Helper loaded: url_helper
INFO - 2020-10-05 15:25:12 --> Database Driver Class Initialized
INFO - 2020-10-05 15:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:25:12 --> Email Class Initialized
INFO - 2020-10-05 15:25:12 --> Controller Class Initialized
INFO - 2020-10-05 15:25:12 --> Model Class Initialized
INFO - 2020-10-05 15:25:12 --> Model Class Initialized
DEBUG - 2020-10-05 15:25:12 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:25:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 15:25:12 --> Final output sent to browser
DEBUG - 2020-10-05 15:25:12 --> Total execution time: 0.0201
ERROR - 2020-10-05 15:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:25:38 --> Config Class Initialized
INFO - 2020-10-05 15:25:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:25:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:25:38 --> Utf8 Class Initialized
INFO - 2020-10-05 15:25:38 --> URI Class Initialized
INFO - 2020-10-05 15:25:38 --> Router Class Initialized
INFO - 2020-10-05 15:25:38 --> Output Class Initialized
INFO - 2020-10-05 15:25:38 --> Security Class Initialized
DEBUG - 2020-10-05 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:25:38 --> Input Class Initialized
INFO - 2020-10-05 15:25:38 --> Language Class Initialized
INFO - 2020-10-05 15:25:38 --> Loader Class Initialized
INFO - 2020-10-05 15:25:38 --> Helper loaded: url_helper
INFO - 2020-10-05 15:25:38 --> Database Driver Class Initialized
INFO - 2020-10-05 15:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:25:38 --> Email Class Initialized
INFO - 2020-10-05 15:25:38 --> Controller Class Initialized
INFO - 2020-10-05 15:25:38 --> Model Class Initialized
INFO - 2020-10-05 15:25:38 --> Model Class Initialized
DEBUG - 2020-10-05 15:25:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:25:38 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-05 15:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:25:38 --> Config Class Initialized
INFO - 2020-10-05 15:25:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:25:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:25:38 --> Utf8 Class Initialized
INFO - 2020-10-05 15:25:38 --> URI Class Initialized
INFO - 2020-10-05 15:25:38 --> Router Class Initialized
INFO - 2020-10-05 15:25:38 --> Output Class Initialized
INFO - 2020-10-05 15:25:38 --> Security Class Initialized
DEBUG - 2020-10-05 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:25:38 --> Input Class Initialized
INFO - 2020-10-05 15:25:38 --> Language Class Initialized
INFO - 2020-10-05 15:25:38 --> Loader Class Initialized
INFO - 2020-10-05 15:25:38 --> Helper loaded: url_helper
INFO - 2020-10-05 15:25:38 --> Database Driver Class Initialized
INFO - 2020-10-05 15:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:25:38 --> Email Class Initialized
INFO - 2020-10-05 15:25:38 --> Controller Class Initialized
INFO - 2020-10-05 15:25:38 --> Model Class Initialized
INFO - 2020-10-05 15:25:38 --> Model Class Initialized
DEBUG - 2020-10-05 15:25:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-05 15:25:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:25:38 --> Config Class Initialized
INFO - 2020-10-05 15:25:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:25:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:25:38 --> Utf8 Class Initialized
INFO - 2020-10-05 15:25:38 --> URI Class Initialized
DEBUG - 2020-10-05 15:25:38 --> No URI present. Default controller set.
INFO - 2020-10-05 15:25:38 --> Router Class Initialized
INFO - 2020-10-05 15:25:38 --> Output Class Initialized
INFO - 2020-10-05 15:25:38 --> Security Class Initialized
DEBUG - 2020-10-05 15:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:25:38 --> Input Class Initialized
INFO - 2020-10-05 15:25:38 --> Language Class Initialized
INFO - 2020-10-05 15:25:38 --> Loader Class Initialized
INFO - 2020-10-05 15:25:38 --> Helper loaded: url_helper
INFO - 2020-10-05 15:25:38 --> Database Driver Class Initialized
INFO - 2020-10-05 15:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:25:38 --> Email Class Initialized
INFO - 2020-10-05 15:25:38 --> Controller Class Initialized
INFO - 2020-10-05 15:25:38 --> Model Class Initialized
INFO - 2020-10-05 15:25:38 --> Model Class Initialized
DEBUG - 2020-10-05 15:25:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:25:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 15:25:38 --> Final output sent to browser
DEBUG - 2020-10-05 15:25:38 --> Total execution time: 0.0202
ERROR - 2020-10-05 15:25:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:25:39 --> Config Class Initialized
INFO - 2020-10-05 15:25:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:25:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:25:39 --> Utf8 Class Initialized
INFO - 2020-10-05 15:25:39 --> URI Class Initialized
INFO - 2020-10-05 15:25:39 --> Router Class Initialized
INFO - 2020-10-05 15:25:39 --> Output Class Initialized
INFO - 2020-10-05 15:25:39 --> Security Class Initialized
DEBUG - 2020-10-05 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:25:39 --> Input Class Initialized
INFO - 2020-10-05 15:25:39 --> Language Class Initialized
INFO - 2020-10-05 15:25:39 --> Loader Class Initialized
INFO - 2020-10-05 15:25:39 --> Helper loaded: url_helper
INFO - 2020-10-05 15:25:39 --> Database Driver Class Initialized
INFO - 2020-10-05 15:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:25:39 --> Email Class Initialized
INFO - 2020-10-05 15:25:39 --> Controller Class Initialized
DEBUG - 2020-10-05 15:25:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:25:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:25:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 15:25:39 --> Final output sent to browser
DEBUG - 2020-10-05 15:25:39 --> Total execution time: 0.0169
ERROR - 2020-10-05 15:26:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:26:20 --> Config Class Initialized
INFO - 2020-10-05 15:26:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:26:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:26:20 --> Utf8 Class Initialized
INFO - 2020-10-05 15:26:20 --> URI Class Initialized
INFO - 2020-10-05 15:26:20 --> Router Class Initialized
INFO - 2020-10-05 15:26:20 --> Output Class Initialized
INFO - 2020-10-05 15:26:20 --> Security Class Initialized
DEBUG - 2020-10-05 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:26:20 --> Input Class Initialized
INFO - 2020-10-05 15:26:20 --> Language Class Initialized
INFO - 2020-10-05 15:26:20 --> Loader Class Initialized
INFO - 2020-10-05 15:26:20 --> Helper loaded: url_helper
INFO - 2020-10-05 15:26:20 --> Database Driver Class Initialized
INFO - 2020-10-05 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:26:20 --> Email Class Initialized
INFO - 2020-10-05 15:26:20 --> Controller Class Initialized
DEBUG - 2020-10-05 15:26:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:26:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:26:20 --> Model Class Initialized
INFO - 2020-10-05 15:26:20 --> Model Class Initialized
INFO - 2020-10-05 15:26:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 15:26:20 --> Final output sent to browser
DEBUG - 2020-10-05 15:26:20 --> Total execution time: 0.0304
ERROR - 2020-10-05 15:27:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:27:04 --> Config Class Initialized
INFO - 2020-10-05 15:27:04 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:27:04 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:27:04 --> Utf8 Class Initialized
INFO - 2020-10-05 15:27:04 --> URI Class Initialized
INFO - 2020-10-05 15:27:04 --> Router Class Initialized
INFO - 2020-10-05 15:27:04 --> Output Class Initialized
INFO - 2020-10-05 15:27:04 --> Security Class Initialized
DEBUG - 2020-10-05 15:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:27:04 --> Input Class Initialized
INFO - 2020-10-05 15:27:04 --> Language Class Initialized
INFO - 2020-10-05 15:27:04 --> Loader Class Initialized
INFO - 2020-10-05 15:27:04 --> Helper loaded: url_helper
INFO - 2020-10-05 15:27:04 --> Database Driver Class Initialized
INFO - 2020-10-05 15:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:27:04 --> Email Class Initialized
INFO - 2020-10-05 15:27:04 --> Controller Class Initialized
DEBUG - 2020-10-05 15:27:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:27:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:27:04 --> Model Class Initialized
INFO - 2020-10-05 15:27:04 --> Model Class Initialized
INFO - 2020-10-05 15:27:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 15:27:04 --> Final output sent to browser
DEBUG - 2020-10-05 15:27:04 --> Total execution time: 0.0248
ERROR - 2020-10-05 15:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:27:08 --> Config Class Initialized
INFO - 2020-10-05 15:27:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:27:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:27:08 --> Utf8 Class Initialized
INFO - 2020-10-05 15:27:08 --> URI Class Initialized
INFO - 2020-10-05 15:27:08 --> Router Class Initialized
INFO - 2020-10-05 15:27:08 --> Output Class Initialized
INFO - 2020-10-05 15:27:08 --> Security Class Initialized
DEBUG - 2020-10-05 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:27:08 --> Input Class Initialized
INFO - 2020-10-05 15:27:08 --> Language Class Initialized
INFO - 2020-10-05 15:27:08 --> Loader Class Initialized
INFO - 2020-10-05 15:27:08 --> Helper loaded: url_helper
INFO - 2020-10-05 15:27:08 --> Database Driver Class Initialized
INFO - 2020-10-05 15:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:27:08 --> Email Class Initialized
INFO - 2020-10-05 15:27:08 --> Controller Class Initialized
DEBUG - 2020-10-05 15:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:27:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:27:08 --> Model Class Initialized
INFO - 2020-10-05 15:27:08 --> Model Class Initialized
INFO - 2020-10-05 15:27:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 15:27:08 --> Final output sent to browser
DEBUG - 2020-10-05 15:27:08 --> Total execution time: 0.0167
ERROR - 2020-10-05 15:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:27:12 --> Config Class Initialized
INFO - 2020-10-05 15:27:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:27:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:27:12 --> Utf8 Class Initialized
INFO - 2020-10-05 15:27:12 --> URI Class Initialized
INFO - 2020-10-05 15:27:12 --> Router Class Initialized
INFO - 2020-10-05 15:27:12 --> Output Class Initialized
INFO - 2020-10-05 15:27:12 --> Security Class Initialized
DEBUG - 2020-10-05 15:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:27:12 --> Input Class Initialized
INFO - 2020-10-05 15:27:12 --> Language Class Initialized
INFO - 2020-10-05 15:27:12 --> Loader Class Initialized
INFO - 2020-10-05 15:27:12 --> Helper loaded: url_helper
INFO - 2020-10-05 15:27:12 --> Database Driver Class Initialized
INFO - 2020-10-05 15:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:27:12 --> Email Class Initialized
INFO - 2020-10-05 15:27:12 --> Controller Class Initialized
DEBUG - 2020-10-05 15:27:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:27:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:27:12 --> Model Class Initialized
INFO - 2020-10-05 15:27:12 --> Model Class Initialized
INFO - 2020-10-05 15:27:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 15:27:12 --> Final output sent to browser
DEBUG - 2020-10-05 15:27:12 --> Total execution time: 0.0224
ERROR - 2020-10-05 15:27:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 15:27:15 --> Config Class Initialized
INFO - 2020-10-05 15:27:15 --> Hooks Class Initialized
DEBUG - 2020-10-05 15:27:15 --> UTF-8 Support Enabled
INFO - 2020-10-05 15:27:15 --> Utf8 Class Initialized
INFO - 2020-10-05 15:27:15 --> URI Class Initialized
INFO - 2020-10-05 15:27:15 --> Router Class Initialized
INFO - 2020-10-05 15:27:15 --> Output Class Initialized
INFO - 2020-10-05 15:27:15 --> Security Class Initialized
DEBUG - 2020-10-05 15:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 15:27:15 --> Input Class Initialized
INFO - 2020-10-05 15:27:15 --> Language Class Initialized
INFO - 2020-10-05 15:27:15 --> Loader Class Initialized
INFO - 2020-10-05 15:27:15 --> Helper loaded: url_helper
INFO - 2020-10-05 15:27:15 --> Database Driver Class Initialized
INFO - 2020-10-05 15:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 15:27:15 --> Email Class Initialized
INFO - 2020-10-05 15:27:15 --> Controller Class Initialized
DEBUG - 2020-10-05 15:27:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 15:27:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 15:27:15 --> Model Class Initialized
INFO - 2020-10-05 15:27:15 --> Model Class Initialized
INFO - 2020-10-05 15:27:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 15:27:15 --> Final output sent to browser
DEBUG - 2020-10-05 15:27:15 --> Total execution time: 0.0328
ERROR - 2020-10-05 16:17:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:17:03 --> Config Class Initialized
INFO - 2020-10-05 16:17:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:17:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:17:03 --> Utf8 Class Initialized
INFO - 2020-10-05 16:17:03 --> URI Class Initialized
INFO - 2020-10-05 16:17:03 --> Router Class Initialized
INFO - 2020-10-05 16:17:03 --> Output Class Initialized
INFO - 2020-10-05 16:17:03 --> Security Class Initialized
DEBUG - 2020-10-05 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:17:03 --> Input Class Initialized
INFO - 2020-10-05 16:17:03 --> Language Class Initialized
INFO - 2020-10-05 16:17:03 --> Loader Class Initialized
INFO - 2020-10-05 16:17:03 --> Helper loaded: url_helper
INFO - 2020-10-05 16:17:03 --> Database Driver Class Initialized
INFO - 2020-10-05 16:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:17:03 --> Email Class Initialized
INFO - 2020-10-05 16:17:03 --> Controller Class Initialized
DEBUG - 2020-10-05 16:17:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:17:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:17:03 --> Model Class Initialized
ERROR - 2020-10-05 16:17:03 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /home/purpu1ex/public_html/carsm/application/models/Admin_model.php 185
ERROR - 2020-10-05 16:18:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:18:06 --> Config Class Initialized
INFO - 2020-10-05 16:18:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:06 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:06 --> URI Class Initialized
INFO - 2020-10-05 16:18:06 --> Router Class Initialized
INFO - 2020-10-05 16:18:06 --> Output Class Initialized
INFO - 2020-10-05 16:18:06 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:06 --> Input Class Initialized
INFO - 2020-10-05 16:18:06 --> Language Class Initialized
INFO - 2020-10-05 16:18:06 --> Loader Class Initialized
INFO - 2020-10-05 16:18:06 --> Helper loaded: url_helper
INFO - 2020-10-05 16:18:06 --> Database Driver Class Initialized
INFO - 2020-10-05 16:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:18:06 --> Email Class Initialized
INFO - 2020-10-05 16:18:06 --> Controller Class Initialized
DEBUG - 2020-10-05 16:18:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:18:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:18:06 --> Model Class Initialized
INFO - 2020-10-05 16:18:06 --> Model Class Initialized
INFO - 2020-10-05 16:18:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 16:18:06 --> Final output sent to browser
DEBUG - 2020-10-05 16:18:06 --> Total execution time: 0.0229
ERROR - 2020-10-05 16:18:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:18:10 --> Config Class Initialized
INFO - 2020-10-05 16:18:10 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:10 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:10 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:10 --> URI Class Initialized
INFO - 2020-10-05 16:18:10 --> Router Class Initialized
INFO - 2020-10-05 16:18:10 --> Output Class Initialized
INFO - 2020-10-05 16:18:10 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:10 --> Input Class Initialized
INFO - 2020-10-05 16:18:10 --> Language Class Initialized
INFO - 2020-10-05 16:18:10 --> Loader Class Initialized
INFO - 2020-10-05 16:18:10 --> Helper loaded: url_helper
INFO - 2020-10-05 16:18:10 --> Database Driver Class Initialized
INFO - 2020-10-05 16:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:18:10 --> Email Class Initialized
INFO - 2020-10-05 16:18:10 --> Controller Class Initialized
DEBUG - 2020-10-05 16:18:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:18:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:18:10 --> Model Class Initialized
INFO - 2020-10-05 16:18:10 --> Model Class Initialized
INFO - 2020-10-05 16:18:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:18:10 --> Final output sent to browser
DEBUG - 2020-10-05 16:18:10 --> Total execution time: 0.0192
ERROR - 2020-10-05 16:18:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:18:12 --> Config Class Initialized
INFO - 2020-10-05 16:18:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:12 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:12 --> URI Class Initialized
INFO - 2020-10-05 16:18:12 --> Router Class Initialized
INFO - 2020-10-05 16:18:12 --> Output Class Initialized
INFO - 2020-10-05 16:18:12 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:12 --> Input Class Initialized
INFO - 2020-10-05 16:18:12 --> Language Class Initialized
INFO - 2020-10-05 16:18:12 --> Loader Class Initialized
INFO - 2020-10-05 16:18:12 --> Helper loaded: url_helper
INFO - 2020-10-05 16:18:12 --> Database Driver Class Initialized
INFO - 2020-10-05 16:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:18:12 --> Email Class Initialized
INFO - 2020-10-05 16:18:12 --> Controller Class Initialized
DEBUG - 2020-10-05 16:18:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:18:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:18:12 --> Model Class Initialized
INFO - 2020-10-05 16:18:12 --> Model Class Initialized
INFO - 2020-10-05 16:18:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 16:18:12 --> Final output sent to browser
DEBUG - 2020-10-05 16:18:12 --> Total execution time: 0.0222
ERROR - 2020-10-05 16:18:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:18:12 --> Config Class Initialized
INFO - 2020-10-05 16:18:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:18:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:18:12 --> Utf8 Class Initialized
INFO - 2020-10-05 16:18:12 --> URI Class Initialized
INFO - 2020-10-05 16:18:12 --> Router Class Initialized
INFO - 2020-10-05 16:18:12 --> Output Class Initialized
INFO - 2020-10-05 16:18:12 --> Security Class Initialized
DEBUG - 2020-10-05 16:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:18:12 --> Input Class Initialized
INFO - 2020-10-05 16:18:12 --> Language Class Initialized
ERROR - 2020-10-05 16:18:12 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 16:19:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:19:28 --> Config Class Initialized
INFO - 2020-10-05 16:19:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:19:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:19:28 --> Utf8 Class Initialized
INFO - 2020-10-05 16:19:28 --> URI Class Initialized
INFO - 2020-10-05 16:19:28 --> Router Class Initialized
INFO - 2020-10-05 16:19:28 --> Output Class Initialized
INFO - 2020-10-05 16:19:28 --> Security Class Initialized
DEBUG - 2020-10-05 16:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:19:28 --> Input Class Initialized
INFO - 2020-10-05 16:19:28 --> Language Class Initialized
INFO - 2020-10-05 16:19:28 --> Loader Class Initialized
INFO - 2020-10-05 16:19:28 --> Helper loaded: url_helper
INFO - 2020-10-05 16:19:28 --> Database Driver Class Initialized
INFO - 2020-10-05 16:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:19:28 --> Email Class Initialized
INFO - 2020-10-05 16:19:28 --> Controller Class Initialized
DEBUG - 2020-10-05 16:19:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:19:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:19:28 --> Model Class Initialized
INFO - 2020-10-05 16:19:28 --> Model Class Initialized
INFO - 2020-10-05 16:19:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 16:19:28 --> Final output sent to browser
DEBUG - 2020-10-05 16:19:28 --> Total execution time: 0.0199
ERROR - 2020-10-05 16:19:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:19:29 --> Config Class Initialized
INFO - 2020-10-05 16:19:29 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:19:29 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:19:29 --> Utf8 Class Initialized
INFO - 2020-10-05 16:19:29 --> URI Class Initialized
INFO - 2020-10-05 16:19:29 --> Router Class Initialized
INFO - 2020-10-05 16:19:29 --> Output Class Initialized
INFO - 2020-10-05 16:19:29 --> Security Class Initialized
DEBUG - 2020-10-05 16:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:19:29 --> Input Class Initialized
INFO - 2020-10-05 16:19:29 --> Language Class Initialized
ERROR - 2020-10-05 16:19:29 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 16:19:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:19:34 --> Config Class Initialized
INFO - 2020-10-05 16:19:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:19:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:19:34 --> Utf8 Class Initialized
INFO - 2020-10-05 16:19:34 --> URI Class Initialized
INFO - 2020-10-05 16:19:34 --> Router Class Initialized
INFO - 2020-10-05 16:19:34 --> Output Class Initialized
INFO - 2020-10-05 16:19:34 --> Security Class Initialized
DEBUG - 2020-10-05 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:19:34 --> Input Class Initialized
INFO - 2020-10-05 16:19:34 --> Language Class Initialized
INFO - 2020-10-05 16:19:34 --> Loader Class Initialized
INFO - 2020-10-05 16:19:34 --> Helper loaded: url_helper
INFO - 2020-10-05 16:19:34 --> Database Driver Class Initialized
INFO - 2020-10-05 16:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:19:34 --> Email Class Initialized
INFO - 2020-10-05 16:19:34 --> Controller Class Initialized
DEBUG - 2020-10-05 16:19:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:19:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:19:34 --> Model Class Initialized
INFO - 2020-10-05 16:19:34 --> Model Class Initialized
INFO - 2020-10-05 16:19:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:19:34 --> Final output sent to browser
DEBUG - 2020-10-05 16:19:34 --> Total execution time: 0.0203
ERROR - 2020-10-05 16:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:19:37 --> Config Class Initialized
INFO - 2020-10-05 16:19:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:19:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:19:37 --> Utf8 Class Initialized
INFO - 2020-10-05 16:19:37 --> URI Class Initialized
INFO - 2020-10-05 16:19:37 --> Router Class Initialized
INFO - 2020-10-05 16:19:37 --> Output Class Initialized
INFO - 2020-10-05 16:19:37 --> Security Class Initialized
DEBUG - 2020-10-05 16:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:19:37 --> Input Class Initialized
INFO - 2020-10-05 16:19:37 --> Language Class Initialized
INFO - 2020-10-05 16:19:37 --> Loader Class Initialized
INFO - 2020-10-05 16:19:37 --> Helper loaded: url_helper
INFO - 2020-10-05 16:19:37 --> Database Driver Class Initialized
INFO - 2020-10-05 16:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:19:37 --> Email Class Initialized
INFO - 2020-10-05 16:19:37 --> Controller Class Initialized
DEBUG - 2020-10-05 16:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:19:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:19:37 --> Model Class Initialized
INFO - 2020-10-05 16:19:37 --> Model Class Initialized
INFO - 2020-10-05 16:19:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 16:19:37 --> Final output sent to browser
DEBUG - 2020-10-05 16:19:37 --> Total execution time: 0.0176
ERROR - 2020-10-05 16:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:19:37 --> Config Class Initialized
INFO - 2020-10-05 16:19:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:19:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:19:37 --> Utf8 Class Initialized
INFO - 2020-10-05 16:19:37 --> URI Class Initialized
INFO - 2020-10-05 16:19:37 --> Router Class Initialized
INFO - 2020-10-05 16:19:37 --> Output Class Initialized
INFO - 2020-10-05 16:19:37 --> Security Class Initialized
DEBUG - 2020-10-05 16:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:19:37 --> Input Class Initialized
INFO - 2020-10-05 16:19:37 --> Language Class Initialized
ERROR - 2020-10-05 16:19:37 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 16:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:24:20 --> Config Class Initialized
INFO - 2020-10-05 16:24:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:24:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:24:20 --> Utf8 Class Initialized
INFO - 2020-10-05 16:24:20 --> URI Class Initialized
INFO - 2020-10-05 16:24:20 --> Router Class Initialized
INFO - 2020-10-05 16:24:20 --> Output Class Initialized
INFO - 2020-10-05 16:24:20 --> Security Class Initialized
DEBUG - 2020-10-05 16:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:24:20 --> Input Class Initialized
INFO - 2020-10-05 16:24:20 --> Language Class Initialized
INFO - 2020-10-05 16:24:20 --> Loader Class Initialized
INFO - 2020-10-05 16:24:20 --> Helper loaded: url_helper
INFO - 2020-10-05 16:24:20 --> Database Driver Class Initialized
INFO - 2020-10-05 16:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:24:20 --> Email Class Initialized
INFO - 2020-10-05 16:24:20 --> Controller Class Initialized
DEBUG - 2020-10-05 16:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:24:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:24:20 --> Model Class Initialized
INFO - 2020-10-05 16:24:20 --> Model Class Initialized
INFO - 2020-10-05 16:24:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:24:20 --> Final output sent to browser
DEBUG - 2020-10-05 16:24:20 --> Total execution time: 0.0218
ERROR - 2020-10-05 16:24:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:24:22 --> Config Class Initialized
INFO - 2020-10-05 16:24:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:24:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:24:22 --> Utf8 Class Initialized
INFO - 2020-10-05 16:24:22 --> URI Class Initialized
INFO - 2020-10-05 16:24:22 --> Router Class Initialized
INFO - 2020-10-05 16:24:22 --> Output Class Initialized
INFO - 2020-10-05 16:24:22 --> Security Class Initialized
DEBUG - 2020-10-05 16:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:24:22 --> Input Class Initialized
INFO - 2020-10-05 16:24:22 --> Language Class Initialized
INFO - 2020-10-05 16:24:22 --> Loader Class Initialized
INFO - 2020-10-05 16:24:22 --> Helper loaded: url_helper
INFO - 2020-10-05 16:24:22 --> Database Driver Class Initialized
INFO - 2020-10-05 16:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:24:22 --> Email Class Initialized
INFO - 2020-10-05 16:24:22 --> Controller Class Initialized
DEBUG - 2020-10-05 16:24:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:24:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:24:22 --> Model Class Initialized
INFO - 2020-10-05 16:24:22 --> Model Class Initialized
INFO - 2020-10-05 16:24:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 16:24:23 --> Final output sent to browser
DEBUG - 2020-10-05 16:24:23 --> Total execution time: 0.0213
ERROR - 2020-10-05 16:24:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:24:23 --> Config Class Initialized
INFO - 2020-10-05 16:24:23 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:24:23 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:24:23 --> Utf8 Class Initialized
INFO - 2020-10-05 16:24:23 --> URI Class Initialized
INFO - 2020-10-05 16:24:23 --> Router Class Initialized
INFO - 2020-10-05 16:24:23 --> Output Class Initialized
INFO - 2020-10-05 16:24:23 --> Security Class Initialized
DEBUG - 2020-10-05 16:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:24:23 --> Input Class Initialized
INFO - 2020-10-05 16:24:23 --> Language Class Initialized
ERROR - 2020-10-05 16:24:23 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 16:24:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:24:26 --> Config Class Initialized
INFO - 2020-10-05 16:24:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:24:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:24:26 --> Utf8 Class Initialized
INFO - 2020-10-05 16:24:26 --> URI Class Initialized
INFO - 2020-10-05 16:24:26 --> Router Class Initialized
INFO - 2020-10-05 16:24:26 --> Output Class Initialized
INFO - 2020-10-05 16:24:26 --> Security Class Initialized
DEBUG - 2020-10-05 16:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:24:26 --> Input Class Initialized
INFO - 2020-10-05 16:24:26 --> Language Class Initialized
INFO - 2020-10-05 16:24:26 --> Loader Class Initialized
INFO - 2020-10-05 16:24:26 --> Helper loaded: url_helper
INFO - 2020-10-05 16:24:26 --> Database Driver Class Initialized
INFO - 2020-10-05 16:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:24:26 --> Email Class Initialized
INFO - 2020-10-05 16:24:26 --> Controller Class Initialized
DEBUG - 2020-10-05 16:24:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:24:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:24:26 --> Model Class Initialized
INFO - 2020-10-05 16:24:26 --> Model Class Initialized
INFO - 2020-10-05 16:24:26 --> Final output sent to browser
DEBUG - 2020-10-05 16:24:26 --> Total execution time: 0.0270
ERROR - 2020-10-05 16:24:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:24:56 --> Config Class Initialized
INFO - 2020-10-05 16:24:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:24:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:24:56 --> Utf8 Class Initialized
INFO - 2020-10-05 16:24:56 --> URI Class Initialized
INFO - 2020-10-05 16:24:56 --> Router Class Initialized
INFO - 2020-10-05 16:24:56 --> Output Class Initialized
INFO - 2020-10-05 16:24:56 --> Security Class Initialized
DEBUG - 2020-10-05 16:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:24:56 --> Input Class Initialized
INFO - 2020-10-05 16:24:56 --> Language Class Initialized
INFO - 2020-10-05 16:24:56 --> Loader Class Initialized
INFO - 2020-10-05 16:24:56 --> Helper loaded: url_helper
INFO - 2020-10-05 16:24:56 --> Database Driver Class Initialized
INFO - 2020-10-05 16:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:24:57 --> Email Class Initialized
INFO - 2020-10-05 16:24:57 --> Controller Class Initialized
DEBUG - 2020-10-05 16:24:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:24:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:24:57 --> Model Class Initialized
INFO - 2020-10-05 16:24:57 --> Model Class Initialized
INFO - 2020-10-05 16:24:57 --> Final output sent to browser
DEBUG - 2020-10-05 16:24:57 --> Total execution time: 0.0227
ERROR - 2020-10-05 16:25:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:25:01 --> Config Class Initialized
INFO - 2020-10-05 16:25:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:25:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:25:01 --> Utf8 Class Initialized
INFO - 2020-10-05 16:25:01 --> URI Class Initialized
INFO - 2020-10-05 16:25:01 --> Router Class Initialized
INFO - 2020-10-05 16:25:01 --> Output Class Initialized
INFO - 2020-10-05 16:25:01 --> Security Class Initialized
DEBUG - 2020-10-05 16:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:25:01 --> Input Class Initialized
INFO - 2020-10-05 16:25:01 --> Language Class Initialized
INFO - 2020-10-05 16:25:01 --> Loader Class Initialized
INFO - 2020-10-05 16:25:01 --> Helper loaded: url_helper
INFO - 2020-10-05 16:25:01 --> Database Driver Class Initialized
INFO - 2020-10-05 16:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:25:01 --> Email Class Initialized
INFO - 2020-10-05 16:25:01 --> Controller Class Initialized
DEBUG - 2020-10-05 16:25:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:25:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:25:01 --> Model Class Initialized
INFO - 2020-10-05 16:25:01 --> Model Class Initialized
INFO - 2020-10-05 16:25:01 --> Final output sent to browser
DEBUG - 2020-10-05 16:25:01 --> Total execution time: 0.0217
ERROR - 2020-10-05 16:25:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:25:05 --> Config Class Initialized
INFO - 2020-10-05 16:25:05 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:25:05 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:25:05 --> Utf8 Class Initialized
INFO - 2020-10-05 16:25:05 --> URI Class Initialized
INFO - 2020-10-05 16:25:05 --> Router Class Initialized
INFO - 2020-10-05 16:25:05 --> Output Class Initialized
INFO - 2020-10-05 16:25:05 --> Security Class Initialized
DEBUG - 2020-10-05 16:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:25:05 --> Input Class Initialized
INFO - 2020-10-05 16:25:05 --> Language Class Initialized
INFO - 2020-10-05 16:25:05 --> Loader Class Initialized
INFO - 2020-10-05 16:25:05 --> Helper loaded: url_helper
INFO - 2020-10-05 16:25:05 --> Database Driver Class Initialized
INFO - 2020-10-05 16:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:25:05 --> Email Class Initialized
INFO - 2020-10-05 16:25:05 --> Controller Class Initialized
DEBUG - 2020-10-05 16:25:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:25:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:25:05 --> Model Class Initialized
INFO - 2020-10-05 16:25:05 --> Model Class Initialized
INFO - 2020-10-05 16:25:05 --> Final output sent to browser
DEBUG - 2020-10-05 16:25:05 --> Total execution time: 0.0231
ERROR - 2020-10-05 16:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:25:08 --> Config Class Initialized
INFO - 2020-10-05 16:25:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:25:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:25:08 --> Utf8 Class Initialized
INFO - 2020-10-05 16:25:08 --> URI Class Initialized
INFO - 2020-10-05 16:25:08 --> Router Class Initialized
INFO - 2020-10-05 16:25:08 --> Output Class Initialized
INFO - 2020-10-05 16:25:08 --> Security Class Initialized
DEBUG - 2020-10-05 16:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:25:08 --> Input Class Initialized
INFO - 2020-10-05 16:25:08 --> Language Class Initialized
INFO - 2020-10-05 16:25:08 --> Loader Class Initialized
INFO - 2020-10-05 16:25:08 --> Helper loaded: url_helper
INFO - 2020-10-05 16:25:08 --> Database Driver Class Initialized
INFO - 2020-10-05 16:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:25:08 --> Email Class Initialized
INFO - 2020-10-05 16:25:08 --> Controller Class Initialized
DEBUG - 2020-10-05 16:25:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:25:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:25:08 --> Model Class Initialized
INFO - 2020-10-05 16:25:08 --> Model Class Initialized
INFO - 2020-10-05 16:25:08 --> Final output sent to browser
DEBUG - 2020-10-05 16:25:08 --> Total execution time: 0.0307
ERROR - 2020-10-05 16:25:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:25:10 --> Config Class Initialized
INFO - 2020-10-05 16:25:10 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:25:10 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:25:10 --> Utf8 Class Initialized
INFO - 2020-10-05 16:25:10 --> URI Class Initialized
INFO - 2020-10-05 16:25:10 --> Router Class Initialized
INFO - 2020-10-05 16:25:10 --> Output Class Initialized
INFO - 2020-10-05 16:25:10 --> Security Class Initialized
DEBUG - 2020-10-05 16:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:25:10 --> Input Class Initialized
INFO - 2020-10-05 16:25:10 --> Language Class Initialized
INFO - 2020-10-05 16:25:10 --> Loader Class Initialized
INFO - 2020-10-05 16:25:10 --> Helper loaded: url_helper
INFO - 2020-10-05 16:25:10 --> Database Driver Class Initialized
INFO - 2020-10-05 16:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:25:10 --> Email Class Initialized
INFO - 2020-10-05 16:25:10 --> Controller Class Initialized
DEBUG - 2020-10-05 16:25:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:25:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:25:10 --> Model Class Initialized
INFO - 2020-10-05 16:25:10 --> Model Class Initialized
INFO - 2020-10-05 16:25:10 --> Final output sent to browser
DEBUG - 2020-10-05 16:25:10 --> Total execution time: 0.0266
ERROR - 2020-10-05 16:25:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:25:12 --> Config Class Initialized
INFO - 2020-10-05 16:25:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:25:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:25:12 --> Utf8 Class Initialized
INFO - 2020-10-05 16:25:12 --> URI Class Initialized
INFO - 2020-10-05 16:25:12 --> Router Class Initialized
INFO - 2020-10-05 16:25:12 --> Output Class Initialized
INFO - 2020-10-05 16:25:12 --> Security Class Initialized
DEBUG - 2020-10-05 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:25:12 --> Input Class Initialized
INFO - 2020-10-05 16:25:12 --> Language Class Initialized
INFO - 2020-10-05 16:25:12 --> Loader Class Initialized
INFO - 2020-10-05 16:25:12 --> Helper loaded: url_helper
INFO - 2020-10-05 16:25:12 --> Database Driver Class Initialized
INFO - 2020-10-05 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:25:12 --> Email Class Initialized
INFO - 2020-10-05 16:25:12 --> Controller Class Initialized
DEBUG - 2020-10-05 16:25:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:25:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:25:12 --> Model Class Initialized
INFO - 2020-10-05 16:25:12 --> Model Class Initialized
INFO - 2020-10-05 16:25:12 --> Final output sent to browser
DEBUG - 2020-10-05 16:25:12 --> Total execution time: 0.0253
ERROR - 2020-10-05 16:31:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:31:39 --> Config Class Initialized
INFO - 2020-10-05 16:31:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:31:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:31:39 --> Utf8 Class Initialized
INFO - 2020-10-05 16:31:39 --> URI Class Initialized
INFO - 2020-10-05 16:31:39 --> Router Class Initialized
INFO - 2020-10-05 16:31:39 --> Output Class Initialized
INFO - 2020-10-05 16:31:39 --> Security Class Initialized
DEBUG - 2020-10-05 16:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:31:39 --> Input Class Initialized
INFO - 2020-10-05 16:31:39 --> Language Class Initialized
INFO - 2020-10-05 16:31:39 --> Loader Class Initialized
INFO - 2020-10-05 16:31:39 --> Helper loaded: url_helper
INFO - 2020-10-05 16:31:39 --> Database Driver Class Initialized
INFO - 2020-10-05 16:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:31:39 --> Email Class Initialized
INFO - 2020-10-05 16:31:39 --> Controller Class Initialized
DEBUG - 2020-10-05 16:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:31:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:31:39 --> Model Class Initialized
INFO - 2020-10-05 16:31:39 --> Model Class Initialized
INFO - 2020-10-05 16:31:39 --> Final output sent to browser
DEBUG - 2020-10-05 16:31:39 --> Total execution time: 0.0256
ERROR - 2020-10-05 16:31:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:31:48 --> Config Class Initialized
INFO - 2020-10-05 16:31:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:31:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:31:48 --> Utf8 Class Initialized
INFO - 2020-10-05 16:31:48 --> URI Class Initialized
INFO - 2020-10-05 16:31:48 --> Router Class Initialized
INFO - 2020-10-05 16:31:48 --> Output Class Initialized
INFO - 2020-10-05 16:31:48 --> Security Class Initialized
DEBUG - 2020-10-05 16:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:31:48 --> Input Class Initialized
INFO - 2020-10-05 16:31:48 --> Language Class Initialized
INFO - 2020-10-05 16:31:48 --> Loader Class Initialized
INFO - 2020-10-05 16:31:48 --> Helper loaded: url_helper
INFO - 2020-10-05 16:31:48 --> Database Driver Class Initialized
INFO - 2020-10-05 16:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:31:48 --> Email Class Initialized
INFO - 2020-10-05 16:31:48 --> Controller Class Initialized
DEBUG - 2020-10-05 16:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:31:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:31:48 --> Model Class Initialized
INFO - 2020-10-05 16:31:48 --> Model Class Initialized
INFO - 2020-10-05 16:31:48 --> Final output sent to browser
DEBUG - 2020-10-05 16:31:48 --> Total execution time: 0.0216
ERROR - 2020-10-05 16:31:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:31:51 --> Config Class Initialized
INFO - 2020-10-05 16:31:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:31:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:31:51 --> Utf8 Class Initialized
INFO - 2020-10-05 16:31:51 --> URI Class Initialized
INFO - 2020-10-05 16:31:51 --> Router Class Initialized
INFO - 2020-10-05 16:31:51 --> Output Class Initialized
INFO - 2020-10-05 16:31:51 --> Security Class Initialized
DEBUG - 2020-10-05 16:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:31:51 --> Input Class Initialized
INFO - 2020-10-05 16:31:51 --> Language Class Initialized
INFO - 2020-10-05 16:31:51 --> Loader Class Initialized
INFO - 2020-10-05 16:31:51 --> Helper loaded: url_helper
INFO - 2020-10-05 16:31:51 --> Database Driver Class Initialized
INFO - 2020-10-05 16:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:31:51 --> Email Class Initialized
INFO - 2020-10-05 16:31:51 --> Controller Class Initialized
DEBUG - 2020-10-05 16:31:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:31:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:31:51 --> Model Class Initialized
INFO - 2020-10-05 16:31:51 --> Model Class Initialized
INFO - 2020-10-05 16:31:51 --> Final output sent to browser
DEBUG - 2020-10-05 16:31:51 --> Total execution time: 0.0225
ERROR - 2020-10-05 16:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:31:56 --> Config Class Initialized
INFO - 2020-10-05 16:31:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:31:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:31:56 --> Utf8 Class Initialized
INFO - 2020-10-05 16:31:56 --> URI Class Initialized
INFO - 2020-10-05 16:31:56 --> Router Class Initialized
INFO - 2020-10-05 16:31:56 --> Output Class Initialized
INFO - 2020-10-05 16:31:56 --> Security Class Initialized
DEBUG - 2020-10-05 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:31:56 --> Input Class Initialized
INFO - 2020-10-05 16:31:56 --> Language Class Initialized
INFO - 2020-10-05 16:31:56 --> Loader Class Initialized
INFO - 2020-10-05 16:31:56 --> Helper loaded: url_helper
INFO - 2020-10-05 16:31:56 --> Database Driver Class Initialized
INFO - 2020-10-05 16:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:31:56 --> Email Class Initialized
INFO - 2020-10-05 16:31:56 --> Controller Class Initialized
DEBUG - 2020-10-05 16:31:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:31:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:31:56 --> Model Class Initialized
INFO - 2020-10-05 16:31:56 --> Model Class Initialized
INFO - 2020-10-05 16:31:56 --> Final output sent to browser
DEBUG - 2020-10-05 16:31:56 --> Total execution time: 0.0188
ERROR - 2020-10-05 16:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:32:03 --> Config Class Initialized
INFO - 2020-10-05 16:32:03 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:32:03 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:32:03 --> Utf8 Class Initialized
INFO - 2020-10-05 16:32:03 --> URI Class Initialized
INFO - 2020-10-05 16:32:03 --> Router Class Initialized
INFO - 2020-10-05 16:32:03 --> Output Class Initialized
INFO - 2020-10-05 16:32:03 --> Security Class Initialized
DEBUG - 2020-10-05 16:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:32:03 --> Input Class Initialized
INFO - 2020-10-05 16:32:03 --> Language Class Initialized
INFO - 2020-10-05 16:32:03 --> Loader Class Initialized
INFO - 2020-10-05 16:32:03 --> Helper loaded: url_helper
INFO - 2020-10-05 16:32:03 --> Database Driver Class Initialized
INFO - 2020-10-05 16:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:32:03 --> Email Class Initialized
INFO - 2020-10-05 16:32:03 --> Controller Class Initialized
DEBUG - 2020-10-05 16:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:32:03 --> Model Class Initialized
INFO - 2020-10-05 16:32:03 --> Model Class Initialized
INFO - 2020-10-05 16:32:03 --> Final output sent to browser
DEBUG - 2020-10-05 16:32:03 --> Total execution time: 0.0211
ERROR - 2020-10-05 16:37:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:37:37 --> Config Class Initialized
INFO - 2020-10-05 16:37:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:37:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:37:37 --> Utf8 Class Initialized
INFO - 2020-10-05 16:37:37 --> URI Class Initialized
INFO - 2020-10-05 16:37:37 --> Router Class Initialized
INFO - 2020-10-05 16:37:37 --> Output Class Initialized
INFO - 2020-10-05 16:37:37 --> Security Class Initialized
DEBUG - 2020-10-05 16:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:37:37 --> Input Class Initialized
INFO - 2020-10-05 16:37:37 --> Language Class Initialized
INFO - 2020-10-05 16:37:37 --> Loader Class Initialized
INFO - 2020-10-05 16:37:37 --> Helper loaded: url_helper
INFO - 2020-10-05 16:37:37 --> Database Driver Class Initialized
INFO - 2020-10-05 16:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:37:37 --> Email Class Initialized
INFO - 2020-10-05 16:37:37 --> Controller Class Initialized
DEBUG - 2020-10-05 16:37:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:37:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:37:37 --> Model Class Initialized
INFO - 2020-10-05 16:37:37 --> Model Class Initialized
INFO - 2020-10-05 16:37:37 --> Final output sent to browser
DEBUG - 2020-10-05 16:37:37 --> Total execution time: 0.0244
ERROR - 2020-10-05 16:40:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:40:25 --> Config Class Initialized
INFO - 2020-10-05 16:40:25 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:40:25 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:40:25 --> Utf8 Class Initialized
INFO - 2020-10-05 16:40:25 --> URI Class Initialized
INFO - 2020-10-05 16:40:25 --> Router Class Initialized
INFO - 2020-10-05 16:40:25 --> Output Class Initialized
INFO - 2020-10-05 16:40:25 --> Security Class Initialized
DEBUG - 2020-10-05 16:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:40:25 --> Input Class Initialized
INFO - 2020-10-05 16:40:25 --> Language Class Initialized
INFO - 2020-10-05 16:40:25 --> Loader Class Initialized
INFO - 2020-10-05 16:40:25 --> Helper loaded: url_helper
INFO - 2020-10-05 16:40:25 --> Database Driver Class Initialized
INFO - 2020-10-05 16:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:40:25 --> Email Class Initialized
INFO - 2020-10-05 16:40:25 --> Controller Class Initialized
DEBUG - 2020-10-05 16:40:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:40:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:40:25 --> Model Class Initialized
INFO - 2020-10-05 16:40:25 --> Model Class Initialized
INFO - 2020-10-05 16:40:25 --> Final output sent to browser
DEBUG - 2020-10-05 16:40:25 --> Total execution time: 0.0202
ERROR - 2020-10-05 16:40:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:40:28 --> Config Class Initialized
INFO - 2020-10-05 16:40:28 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:40:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:40:28 --> Utf8 Class Initialized
INFO - 2020-10-05 16:40:28 --> URI Class Initialized
INFO - 2020-10-05 16:40:28 --> Router Class Initialized
INFO - 2020-10-05 16:40:28 --> Output Class Initialized
INFO - 2020-10-05 16:40:28 --> Security Class Initialized
DEBUG - 2020-10-05 16:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:40:28 --> Input Class Initialized
INFO - 2020-10-05 16:40:28 --> Language Class Initialized
INFO - 2020-10-05 16:40:28 --> Loader Class Initialized
INFO - 2020-10-05 16:40:28 --> Helper loaded: url_helper
INFO - 2020-10-05 16:40:28 --> Database Driver Class Initialized
INFO - 2020-10-05 16:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:40:28 --> Email Class Initialized
INFO - 2020-10-05 16:40:28 --> Controller Class Initialized
DEBUG - 2020-10-05 16:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:40:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:40:28 --> Model Class Initialized
INFO - 2020-10-05 16:40:28 --> Model Class Initialized
INFO - 2020-10-05 16:40:28 --> Final output sent to browser
DEBUG - 2020-10-05 16:40:28 --> Total execution time: 0.0187
ERROR - 2020-10-05 16:40:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:40:57 --> Config Class Initialized
INFO - 2020-10-05 16:40:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:40:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:40:57 --> Utf8 Class Initialized
INFO - 2020-10-05 16:40:57 --> URI Class Initialized
INFO - 2020-10-05 16:40:57 --> Router Class Initialized
INFO - 2020-10-05 16:40:57 --> Output Class Initialized
INFO - 2020-10-05 16:40:57 --> Security Class Initialized
DEBUG - 2020-10-05 16:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:40:57 --> Input Class Initialized
INFO - 2020-10-05 16:40:57 --> Language Class Initialized
INFO - 2020-10-05 16:40:57 --> Loader Class Initialized
INFO - 2020-10-05 16:40:57 --> Helper loaded: url_helper
INFO - 2020-10-05 16:40:57 --> Database Driver Class Initialized
INFO - 2020-10-05 16:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:40:57 --> Email Class Initialized
INFO - 2020-10-05 16:40:57 --> Controller Class Initialized
DEBUG - 2020-10-05 16:40:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:40:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:40:57 --> Model Class Initialized
INFO - 2020-10-05 16:40:57 --> Model Class Initialized
INFO - 2020-10-05 16:40:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:40:57 --> Final output sent to browser
DEBUG - 2020-10-05 16:40:57 --> Total execution time: 0.0196
ERROR - 2020-10-05 16:41:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:41:00 --> Config Class Initialized
INFO - 2020-10-05 16:41:00 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:41:00 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:41:00 --> Utf8 Class Initialized
INFO - 2020-10-05 16:41:00 --> URI Class Initialized
INFO - 2020-10-05 16:41:00 --> Router Class Initialized
INFO - 2020-10-05 16:41:00 --> Output Class Initialized
INFO - 2020-10-05 16:41:00 --> Security Class Initialized
DEBUG - 2020-10-05 16:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:41:00 --> Input Class Initialized
INFO - 2020-10-05 16:41:00 --> Language Class Initialized
INFO - 2020-10-05 16:41:00 --> Loader Class Initialized
INFO - 2020-10-05 16:41:00 --> Helper loaded: url_helper
INFO - 2020-10-05 16:41:00 --> Database Driver Class Initialized
INFO - 2020-10-05 16:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:41:00 --> Email Class Initialized
INFO - 2020-10-05 16:41:00 --> Controller Class Initialized
DEBUG - 2020-10-05 16:41:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:41:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:41:00 --> Model Class Initialized
INFO - 2020-10-05 16:41:00 --> Model Class Initialized
INFO - 2020-10-05 16:41:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 16:41:00 --> Final output sent to browser
DEBUG - 2020-10-05 16:41:00 --> Total execution time: 0.0185
ERROR - 2020-10-05 16:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:25 --> Config Class Initialized
INFO - 2020-10-05 16:51:25 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:25 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:25 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:25 --> URI Class Initialized
INFO - 2020-10-05 16:51:25 --> Router Class Initialized
INFO - 2020-10-05 16:51:25 --> Output Class Initialized
INFO - 2020-10-05 16:51:25 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:25 --> Input Class Initialized
INFO - 2020-10-05 16:51:25 --> Language Class Initialized
INFO - 2020-10-05 16:51:25 --> Loader Class Initialized
INFO - 2020-10-05 16:51:25 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:25 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:25 --> Email Class Initialized
INFO - 2020-10-05 16:51:25 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:25 --> Model Class Initialized
INFO - 2020-10-05 16:51:25 --> Model Class Initialized
INFO - 2020-10-05 16:51:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 16:51:25 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:25 --> Total execution time: 0.0227
ERROR - 2020-10-05 16:51:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:26 --> Config Class Initialized
INFO - 2020-10-05 16:51:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:26 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:26 --> URI Class Initialized
INFO - 2020-10-05 16:51:26 --> Router Class Initialized
INFO - 2020-10-05 16:51:26 --> Output Class Initialized
INFO - 2020-10-05 16:51:26 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:26 --> Input Class Initialized
INFO - 2020-10-05 16:51:26 --> Language Class Initialized
INFO - 2020-10-05 16:51:26 --> Loader Class Initialized
INFO - 2020-10-05 16:51:26 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:26 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:26 --> Email Class Initialized
INFO - 2020-10-05 16:51:26 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:26 --> Model Class Initialized
INFO - 2020-10-05 16:51:26 --> Model Class Initialized
INFO - 2020-10-05 16:51:26 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:26 --> Total execution time: 0.0226
ERROR - 2020-10-05 16:51:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:30 --> Config Class Initialized
INFO - 2020-10-05 16:51:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:30 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:30 --> URI Class Initialized
INFO - 2020-10-05 16:51:30 --> Router Class Initialized
INFO - 2020-10-05 16:51:30 --> Output Class Initialized
INFO - 2020-10-05 16:51:30 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:30 --> Input Class Initialized
INFO - 2020-10-05 16:51:30 --> Language Class Initialized
INFO - 2020-10-05 16:51:30 --> Loader Class Initialized
INFO - 2020-10-05 16:51:30 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:30 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:30 --> Email Class Initialized
INFO - 2020-10-05 16:51:30 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:30 --> Model Class Initialized
INFO - 2020-10-05 16:51:30 --> Model Class Initialized
INFO - 2020-10-05 16:51:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:51:30 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:30 --> Total execution time: 0.0204
ERROR - 2020-10-05 16:51:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:35 --> Config Class Initialized
INFO - 2020-10-05 16:51:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:35 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:35 --> URI Class Initialized
INFO - 2020-10-05 16:51:35 --> Router Class Initialized
INFO - 2020-10-05 16:51:35 --> Output Class Initialized
INFO - 2020-10-05 16:51:35 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:35 --> Input Class Initialized
INFO - 2020-10-05 16:51:35 --> Language Class Initialized
INFO - 2020-10-05 16:51:35 --> Loader Class Initialized
INFO - 2020-10-05 16:51:35 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:35 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:35 --> Email Class Initialized
INFO - 2020-10-05 16:51:35 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:35 --> Model Class Initialized
INFO - 2020-10-05 16:51:35 --> Model Class Initialized
INFO - 2020-10-05 16:51:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 16:51:35 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:35 --> Total execution time: 0.0264
ERROR - 2020-10-05 16:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:36 --> Config Class Initialized
INFO - 2020-10-05 16:51:36 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:36 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:36 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:36 --> URI Class Initialized
INFO - 2020-10-05 16:51:36 --> Router Class Initialized
INFO - 2020-10-05 16:51:36 --> Output Class Initialized
INFO - 2020-10-05 16:51:36 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:36 --> Input Class Initialized
INFO - 2020-10-05 16:51:36 --> Language Class Initialized
INFO - 2020-10-05 16:51:36 --> Loader Class Initialized
INFO - 2020-10-05 16:51:36 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:36 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:36 --> Email Class Initialized
INFO - 2020-10-05 16:51:36 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:36 --> Model Class Initialized
INFO - 2020-10-05 16:51:36 --> Model Class Initialized
INFO - 2020-10-05 16:51:36 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:36 --> Total execution time: 0.0280
ERROR - 2020-10-05 16:51:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:42 --> Config Class Initialized
INFO - 2020-10-05 16:51:42 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:42 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:42 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:42 --> URI Class Initialized
INFO - 2020-10-05 16:51:42 --> Router Class Initialized
INFO - 2020-10-05 16:51:42 --> Output Class Initialized
INFO - 2020-10-05 16:51:42 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:42 --> Input Class Initialized
INFO - 2020-10-05 16:51:42 --> Language Class Initialized
INFO - 2020-10-05 16:51:42 --> Loader Class Initialized
INFO - 2020-10-05 16:51:42 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:42 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:42 --> Email Class Initialized
INFO - 2020-10-05 16:51:42 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:42 --> Model Class Initialized
INFO - 2020-10-05 16:51:42 --> Model Class Initialized
INFO - 2020-10-05 16:51:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:51:42 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:42 --> Total execution time: 0.0188
ERROR - 2020-10-05 16:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:48 --> Config Class Initialized
INFO - 2020-10-05 16:51:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:48 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:48 --> URI Class Initialized
INFO - 2020-10-05 16:51:48 --> Router Class Initialized
INFO - 2020-10-05 16:51:48 --> Output Class Initialized
INFO - 2020-10-05 16:51:48 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:48 --> Input Class Initialized
INFO - 2020-10-05 16:51:48 --> Language Class Initialized
INFO - 2020-10-05 16:51:48 --> Loader Class Initialized
INFO - 2020-10-05 16:51:48 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:48 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:48 --> Email Class Initialized
INFO - 2020-10-05 16:51:48 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:48 --> Model Class Initialized
INFO - 2020-10-05 16:51:48 --> Model Class Initialized
INFO - 2020-10-05 16:51:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 16:51:48 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:48 --> Total execution time: 0.0247
ERROR - 2020-10-05 16:51:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:48 --> Config Class Initialized
INFO - 2020-10-05 16:51:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:48 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:48 --> URI Class Initialized
INFO - 2020-10-05 16:51:48 --> Router Class Initialized
INFO - 2020-10-05 16:51:48 --> Output Class Initialized
INFO - 2020-10-05 16:51:48 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:48 --> Input Class Initialized
INFO - 2020-10-05 16:51:48 --> Language Class Initialized
INFO - 2020-10-05 16:51:48 --> Loader Class Initialized
INFO - 2020-10-05 16:51:48 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:48 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:48 --> Email Class Initialized
INFO - 2020-10-05 16:51:48 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:48 --> Model Class Initialized
INFO - 2020-10-05 16:51:48 --> Model Class Initialized
INFO - 2020-10-05 16:51:48 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:48 --> Total execution time: 0.0262
ERROR - 2020-10-05 16:51:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:52 --> Config Class Initialized
INFO - 2020-10-05 16:51:52 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:52 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:52 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:52 --> URI Class Initialized
INFO - 2020-10-05 16:51:52 --> Router Class Initialized
INFO - 2020-10-05 16:51:52 --> Output Class Initialized
INFO - 2020-10-05 16:51:52 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:52 --> Input Class Initialized
INFO - 2020-10-05 16:51:52 --> Language Class Initialized
INFO - 2020-10-05 16:51:52 --> Loader Class Initialized
INFO - 2020-10-05 16:51:52 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:52 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:52 --> Email Class Initialized
INFO - 2020-10-05 16:51:52 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:52 --> Model Class Initialized
INFO - 2020-10-05 16:51:52 --> Model Class Initialized
INFO - 2020-10-05 16:51:52 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:52 --> Total execution time: 0.0228
ERROR - 2020-10-05 16:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:51:56 --> Config Class Initialized
INFO - 2020-10-05 16:51:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:51:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:51:56 --> Utf8 Class Initialized
INFO - 2020-10-05 16:51:56 --> URI Class Initialized
INFO - 2020-10-05 16:51:56 --> Router Class Initialized
INFO - 2020-10-05 16:51:56 --> Output Class Initialized
INFO - 2020-10-05 16:51:56 --> Security Class Initialized
DEBUG - 2020-10-05 16:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:51:56 --> Input Class Initialized
INFO - 2020-10-05 16:51:56 --> Language Class Initialized
INFO - 2020-10-05 16:51:56 --> Loader Class Initialized
INFO - 2020-10-05 16:51:56 --> Helper loaded: url_helper
INFO - 2020-10-05 16:51:56 --> Database Driver Class Initialized
INFO - 2020-10-05 16:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:51:57 --> Email Class Initialized
INFO - 2020-10-05 16:51:57 --> Controller Class Initialized
DEBUG - 2020-10-05 16:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:51:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:51:57 --> Model Class Initialized
INFO - 2020-10-05 16:51:57 --> Model Class Initialized
INFO - 2020-10-05 16:51:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 16:51:57 --> Final output sent to browser
DEBUG - 2020-10-05 16:51:57 --> Total execution time: 0.0257
ERROR - 2020-10-05 16:52:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:52:07 --> Config Class Initialized
INFO - 2020-10-05 16:52:07 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:52:07 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:52:07 --> Utf8 Class Initialized
INFO - 2020-10-05 16:52:07 --> URI Class Initialized
INFO - 2020-10-05 16:52:07 --> Router Class Initialized
INFO - 2020-10-05 16:52:07 --> Output Class Initialized
INFO - 2020-10-05 16:52:07 --> Security Class Initialized
DEBUG - 2020-10-05 16:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:52:07 --> Input Class Initialized
INFO - 2020-10-05 16:52:07 --> Language Class Initialized
INFO - 2020-10-05 16:52:07 --> Loader Class Initialized
INFO - 2020-10-05 16:52:07 --> Helper loaded: url_helper
INFO - 2020-10-05 16:52:07 --> Database Driver Class Initialized
INFO - 2020-10-05 16:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:52:07 --> Email Class Initialized
INFO - 2020-10-05 16:52:07 --> Controller Class Initialized
DEBUG - 2020-10-05 16:52:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:52:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:52:07 --> Model Class Initialized
INFO - 2020-10-05 16:52:07 --> Model Class Initialized
INFO - 2020-10-05 16:52:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 16:52:07 --> Final output sent to browser
DEBUG - 2020-10-05 16:52:07 --> Total execution time: 0.0199
ERROR - 2020-10-05 16:52:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 16:52:08 --> Config Class Initialized
INFO - 2020-10-05 16:52:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 16:52:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 16:52:08 --> Utf8 Class Initialized
INFO - 2020-10-05 16:52:08 --> URI Class Initialized
INFO - 2020-10-05 16:52:08 --> Router Class Initialized
INFO - 2020-10-05 16:52:08 --> Output Class Initialized
INFO - 2020-10-05 16:52:08 --> Security Class Initialized
DEBUG - 2020-10-05 16:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 16:52:08 --> Input Class Initialized
INFO - 2020-10-05 16:52:08 --> Language Class Initialized
INFO - 2020-10-05 16:52:08 --> Loader Class Initialized
INFO - 2020-10-05 16:52:08 --> Helper loaded: url_helper
INFO - 2020-10-05 16:52:08 --> Database Driver Class Initialized
INFO - 2020-10-05 16:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 16:52:08 --> Email Class Initialized
INFO - 2020-10-05 16:52:08 --> Controller Class Initialized
DEBUG - 2020-10-05 16:52:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 16:52:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 16:52:08 --> Model Class Initialized
INFO - 2020-10-05 16:52:08 --> Model Class Initialized
INFO - 2020-10-05 16:52:08 --> Final output sent to browser
DEBUG - 2020-10-05 16:52:08 --> Total execution time: 0.0219
ERROR - 2020-10-05 17:11:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:12 --> Config Class Initialized
INFO - 2020-10-05 17:11:12 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:12 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:12 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:12 --> URI Class Initialized
INFO - 2020-10-05 17:11:12 --> Router Class Initialized
INFO - 2020-10-05 17:11:12 --> Output Class Initialized
INFO - 2020-10-05 17:11:12 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:12 --> Input Class Initialized
INFO - 2020-10-05 17:11:12 --> Language Class Initialized
INFO - 2020-10-05 17:11:12 --> Loader Class Initialized
INFO - 2020-10-05 17:11:12 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:12 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:12 --> Email Class Initialized
INFO - 2020-10-05 17:11:12 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:12 --> Model Class Initialized
INFO - 2020-10-05 17:11:12 --> Model Class Initialized
INFO - 2020-10-05 17:11:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:11:12 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:12 --> Total execution time: 0.0240
ERROR - 2020-10-05 17:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:32 --> Config Class Initialized
INFO - 2020-10-05 17:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:32 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:32 --> URI Class Initialized
INFO - 2020-10-05 17:11:32 --> Router Class Initialized
INFO - 2020-10-05 17:11:32 --> Output Class Initialized
INFO - 2020-10-05 17:11:32 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:32 --> Input Class Initialized
INFO - 2020-10-05 17:11:32 --> Language Class Initialized
INFO - 2020-10-05 17:11:32 --> Loader Class Initialized
INFO - 2020-10-05 17:11:32 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:32 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:32 --> Email Class Initialized
INFO - 2020-10-05 17:11:32 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:32 --> Model Class Initialized
INFO - 2020-10-05 17:11:32 --> Model Class Initialized
INFO - 2020-10-05 17:11:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:11:32 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:32 --> Total execution time: 0.0222
ERROR - 2020-10-05 17:11:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:33 --> Config Class Initialized
INFO - 2020-10-05 17:11:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:33 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:33 --> URI Class Initialized
INFO - 2020-10-05 17:11:33 --> Router Class Initialized
INFO - 2020-10-05 17:11:33 --> Output Class Initialized
INFO - 2020-10-05 17:11:33 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:33 --> Input Class Initialized
INFO - 2020-10-05 17:11:33 --> Language Class Initialized
INFO - 2020-10-05 17:11:33 --> Loader Class Initialized
INFO - 2020-10-05 17:11:33 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:33 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:33 --> Email Class Initialized
INFO - 2020-10-05 17:11:33 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:33 --> Model Class Initialized
INFO - 2020-10-05 17:11:33 --> Model Class Initialized
INFO - 2020-10-05 17:11:33 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:33 --> Total execution time: 0.0249
ERROR - 2020-10-05 17:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:37 --> Config Class Initialized
INFO - 2020-10-05 17:11:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:37 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:37 --> URI Class Initialized
INFO - 2020-10-05 17:11:37 --> Router Class Initialized
INFO - 2020-10-05 17:11:37 --> Output Class Initialized
INFO - 2020-10-05 17:11:37 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:37 --> Input Class Initialized
INFO - 2020-10-05 17:11:37 --> Language Class Initialized
INFO - 2020-10-05 17:11:37 --> Loader Class Initialized
INFO - 2020-10-05 17:11:37 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:37 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:37 --> Email Class Initialized
INFO - 2020-10-05 17:11:37 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:37 --> Model Class Initialized
INFO - 2020-10-05 17:11:37 --> Model Class Initialized
INFO - 2020-10-05 17:11:37 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:37 --> Total execution time: 0.0203
ERROR - 2020-10-05 17:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:38 --> Config Class Initialized
INFO - 2020-10-05 17:11:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:38 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:38 --> URI Class Initialized
INFO - 2020-10-05 17:11:38 --> Router Class Initialized
INFO - 2020-10-05 17:11:38 --> Output Class Initialized
INFO - 2020-10-05 17:11:38 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:38 --> Input Class Initialized
INFO - 2020-10-05 17:11:38 --> Language Class Initialized
INFO - 2020-10-05 17:11:38 --> Loader Class Initialized
INFO - 2020-10-05 17:11:38 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:38 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:38 --> Email Class Initialized
INFO - 2020-10-05 17:11:38 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:38 --> Model Class Initialized
INFO - 2020-10-05 17:11:38 --> Model Class Initialized
INFO - 2020-10-05 17:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:11:38 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:38 --> Total execution time: 0.0270
ERROR - 2020-10-05 17:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:55 --> Config Class Initialized
INFO - 2020-10-05 17:11:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:55 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:55 --> URI Class Initialized
INFO - 2020-10-05 17:11:55 --> Router Class Initialized
INFO - 2020-10-05 17:11:55 --> Output Class Initialized
INFO - 2020-10-05 17:11:55 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:55 --> Input Class Initialized
INFO - 2020-10-05 17:11:55 --> Language Class Initialized
INFO - 2020-10-05 17:11:55 --> Loader Class Initialized
INFO - 2020-10-05 17:11:55 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:55 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:55 --> Email Class Initialized
INFO - 2020-10-05 17:11:55 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:55 --> Model Class Initialized
INFO - 2020-10-05 17:11:55 --> Model Class Initialized
INFO - 2020-10-05 17:11:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:11:55 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:55 --> Total execution time: 0.0221
ERROR - 2020-10-05 17:11:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:11:55 --> Config Class Initialized
INFO - 2020-10-05 17:11:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:11:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:11:55 --> Utf8 Class Initialized
INFO - 2020-10-05 17:11:55 --> URI Class Initialized
INFO - 2020-10-05 17:11:55 --> Router Class Initialized
INFO - 2020-10-05 17:11:55 --> Output Class Initialized
INFO - 2020-10-05 17:11:55 --> Security Class Initialized
DEBUG - 2020-10-05 17:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:11:55 --> Input Class Initialized
INFO - 2020-10-05 17:11:55 --> Language Class Initialized
INFO - 2020-10-05 17:11:55 --> Loader Class Initialized
INFO - 2020-10-05 17:11:55 --> Helper loaded: url_helper
INFO - 2020-10-05 17:11:55 --> Database Driver Class Initialized
INFO - 2020-10-05 17:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:11:55 --> Email Class Initialized
INFO - 2020-10-05 17:11:55 --> Controller Class Initialized
DEBUG - 2020-10-05 17:11:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:11:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:11:55 --> Model Class Initialized
INFO - 2020-10-05 17:11:55 --> Model Class Initialized
INFO - 2020-10-05 17:11:55 --> Final output sent to browser
DEBUG - 2020-10-05 17:11:55 --> Total execution time: 0.0274
ERROR - 2020-10-05 17:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:14:20 --> Config Class Initialized
INFO - 2020-10-05 17:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:14:20 --> Utf8 Class Initialized
INFO - 2020-10-05 17:14:20 --> URI Class Initialized
INFO - 2020-10-05 17:14:20 --> Router Class Initialized
INFO - 2020-10-05 17:14:20 --> Output Class Initialized
INFO - 2020-10-05 17:14:20 --> Security Class Initialized
DEBUG - 2020-10-05 17:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:14:20 --> Input Class Initialized
INFO - 2020-10-05 17:14:20 --> Language Class Initialized
INFO - 2020-10-05 17:14:20 --> Loader Class Initialized
INFO - 2020-10-05 17:14:20 --> Helper loaded: url_helper
INFO - 2020-10-05 17:14:20 --> Database Driver Class Initialized
INFO - 2020-10-05 17:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:14:20 --> Email Class Initialized
INFO - 2020-10-05 17:14:20 --> Controller Class Initialized
DEBUG - 2020-10-05 17:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:14:20 --> Model Class Initialized
INFO - 2020-10-05 17:14:20 --> Model Class Initialized
INFO - 2020-10-05 17:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:14:20 --> Final output sent to browser
DEBUG - 2020-10-05 17:14:20 --> Total execution time: 0.0361
ERROR - 2020-10-05 17:14:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:14:22 --> Config Class Initialized
INFO - 2020-10-05 17:14:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:14:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:14:22 --> Utf8 Class Initialized
INFO - 2020-10-05 17:14:22 --> URI Class Initialized
INFO - 2020-10-05 17:14:22 --> Router Class Initialized
INFO - 2020-10-05 17:14:22 --> Output Class Initialized
INFO - 2020-10-05 17:14:22 --> Security Class Initialized
DEBUG - 2020-10-05 17:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:14:22 --> Input Class Initialized
INFO - 2020-10-05 17:14:22 --> Language Class Initialized
INFO - 2020-10-05 17:14:22 --> Loader Class Initialized
INFO - 2020-10-05 17:14:22 --> Helper loaded: url_helper
INFO - 2020-10-05 17:14:22 --> Database Driver Class Initialized
INFO - 2020-10-05 17:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:14:22 --> Email Class Initialized
INFO - 2020-10-05 17:14:22 --> Controller Class Initialized
DEBUG - 2020-10-05 17:14:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:14:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:14:22 --> Model Class Initialized
INFO - 2020-10-05 17:14:22 --> Model Class Initialized
INFO - 2020-10-05 17:14:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:14:22 --> Final output sent to browser
DEBUG - 2020-10-05 17:14:22 --> Total execution time: 0.0207
ERROR - 2020-10-05 17:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:14:23 --> Config Class Initialized
INFO - 2020-10-05 17:14:23 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:14:23 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:14:23 --> Utf8 Class Initialized
INFO - 2020-10-05 17:14:23 --> URI Class Initialized
INFO - 2020-10-05 17:14:23 --> Router Class Initialized
INFO - 2020-10-05 17:14:23 --> Output Class Initialized
INFO - 2020-10-05 17:14:23 --> Security Class Initialized
DEBUG - 2020-10-05 17:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:14:23 --> Input Class Initialized
INFO - 2020-10-05 17:14:23 --> Language Class Initialized
ERROR - 2020-10-05 17:14:23 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:14:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:14:26 --> Config Class Initialized
INFO - 2020-10-05 17:14:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:14:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:14:26 --> Utf8 Class Initialized
INFO - 2020-10-05 17:14:26 --> URI Class Initialized
INFO - 2020-10-05 17:14:26 --> Router Class Initialized
INFO - 2020-10-05 17:14:26 --> Output Class Initialized
INFO - 2020-10-05 17:14:26 --> Security Class Initialized
DEBUG - 2020-10-05 17:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:14:26 --> Input Class Initialized
INFO - 2020-10-05 17:14:26 --> Language Class Initialized
INFO - 2020-10-05 17:14:26 --> Loader Class Initialized
INFO - 2020-10-05 17:14:26 --> Helper loaded: url_helper
INFO - 2020-10-05 17:14:26 --> Database Driver Class Initialized
INFO - 2020-10-05 17:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:14:26 --> Email Class Initialized
INFO - 2020-10-05 17:14:26 --> Controller Class Initialized
DEBUG - 2020-10-05 17:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:14:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:14:26 --> Model Class Initialized
INFO - 2020-10-05 17:14:26 --> Model Class Initialized
INFO - 2020-10-05 17:14:26 --> Final output sent to browser
DEBUG - 2020-10-05 17:14:26 --> Total execution time: 0.0246
ERROR - 2020-10-05 17:14:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:14:57 --> Config Class Initialized
INFO - 2020-10-05 17:14:57 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:14:57 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:14:57 --> Utf8 Class Initialized
INFO - 2020-10-05 17:14:57 --> URI Class Initialized
INFO - 2020-10-05 17:14:57 --> Router Class Initialized
INFO - 2020-10-05 17:14:57 --> Output Class Initialized
INFO - 2020-10-05 17:14:57 --> Security Class Initialized
DEBUG - 2020-10-05 17:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:14:57 --> Input Class Initialized
INFO - 2020-10-05 17:14:57 --> Language Class Initialized
INFO - 2020-10-05 17:14:57 --> Loader Class Initialized
INFO - 2020-10-05 17:14:57 --> Helper loaded: url_helper
INFO - 2020-10-05 17:14:57 --> Database Driver Class Initialized
INFO - 2020-10-05 17:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:14:57 --> Email Class Initialized
INFO - 2020-10-05 17:14:57 --> Controller Class Initialized
DEBUG - 2020-10-05 17:14:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:14:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:14:57 --> Model Class Initialized
INFO - 2020-10-05 17:14:57 --> Model Class Initialized
INFO - 2020-10-05 17:14:57 --> Final output sent to browser
DEBUG - 2020-10-05 17:14:57 --> Total execution time: 0.0289
ERROR - 2020-10-05 17:15:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:15:00 --> Config Class Initialized
INFO - 2020-10-05 17:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:15:00 --> Utf8 Class Initialized
INFO - 2020-10-05 17:15:00 --> URI Class Initialized
INFO - 2020-10-05 17:15:00 --> Router Class Initialized
INFO - 2020-10-05 17:15:00 --> Output Class Initialized
INFO - 2020-10-05 17:15:00 --> Security Class Initialized
DEBUG - 2020-10-05 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:15:00 --> Input Class Initialized
INFO - 2020-10-05 17:15:00 --> Language Class Initialized
INFO - 2020-10-05 17:15:00 --> Loader Class Initialized
INFO - 2020-10-05 17:15:00 --> Helper loaded: url_helper
INFO - 2020-10-05 17:15:00 --> Database Driver Class Initialized
INFO - 2020-10-05 17:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:15:00 --> Email Class Initialized
INFO - 2020-10-05 17:15:00 --> Controller Class Initialized
DEBUG - 2020-10-05 17:15:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:15:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:15:00 --> Model Class Initialized
INFO - 2020-10-05 17:15:00 --> Model Class Initialized
INFO - 2020-10-05 17:15:00 --> Model Class Initialized
INFO - 2020-10-05 17:15:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:15:00 --> Final output sent to browser
DEBUG - 2020-10-05 17:15:00 --> Total execution time: 0.0890
ERROR - 2020-10-05 17:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:15:08 --> Config Class Initialized
INFO - 2020-10-05 17:15:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:15:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:15:08 --> Utf8 Class Initialized
INFO - 2020-10-05 17:15:08 --> URI Class Initialized
INFO - 2020-10-05 17:15:08 --> Router Class Initialized
INFO - 2020-10-05 17:15:08 --> Output Class Initialized
INFO - 2020-10-05 17:15:08 --> Security Class Initialized
DEBUG - 2020-10-05 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:15:08 --> Input Class Initialized
INFO - 2020-10-05 17:15:08 --> Language Class Initialized
INFO - 2020-10-05 17:15:08 --> Loader Class Initialized
INFO - 2020-10-05 17:15:08 --> Helper loaded: url_helper
INFO - 2020-10-05 17:15:08 --> Database Driver Class Initialized
INFO - 2020-10-05 17:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:15:08 --> Email Class Initialized
INFO - 2020-10-05 17:15:08 --> Controller Class Initialized
DEBUG - 2020-10-05 17:15:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:15:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:15:08 --> Model Class Initialized
INFO - 2020-10-05 17:15:08 --> Model Class Initialized
INFO - 2020-10-05 17:15:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:15:08 --> Final output sent to browser
DEBUG - 2020-10-05 17:15:08 --> Total execution time: 0.0235
ERROR - 2020-10-05 17:15:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:15:08 --> Config Class Initialized
INFO - 2020-10-05 17:15:08 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:15:08 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:15:08 --> Utf8 Class Initialized
INFO - 2020-10-05 17:15:08 --> URI Class Initialized
INFO - 2020-10-05 17:15:08 --> Router Class Initialized
INFO - 2020-10-05 17:15:08 --> Output Class Initialized
INFO - 2020-10-05 17:15:08 --> Security Class Initialized
DEBUG - 2020-10-05 17:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:15:08 --> Input Class Initialized
INFO - 2020-10-05 17:15:08 --> Language Class Initialized
INFO - 2020-10-05 17:15:08 --> Loader Class Initialized
INFO - 2020-10-05 17:15:08 --> Helper loaded: url_helper
INFO - 2020-10-05 17:15:08 --> Database Driver Class Initialized
INFO - 2020-10-05 17:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:15:08 --> Email Class Initialized
INFO - 2020-10-05 17:15:08 --> Controller Class Initialized
DEBUG - 2020-10-05 17:15:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:15:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:15:08 --> Model Class Initialized
INFO - 2020-10-05 17:15:08 --> Model Class Initialized
INFO - 2020-10-05 17:15:08 --> Final output sent to browser
DEBUG - 2020-10-05 17:15:08 --> Total execution time: 0.0212
ERROR - 2020-10-05 17:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:15:16 --> Config Class Initialized
INFO - 2020-10-05 17:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:15:16 --> Utf8 Class Initialized
INFO - 2020-10-05 17:15:16 --> URI Class Initialized
INFO - 2020-10-05 17:15:16 --> Router Class Initialized
INFO - 2020-10-05 17:15:16 --> Output Class Initialized
INFO - 2020-10-05 17:15:16 --> Security Class Initialized
DEBUG - 2020-10-05 17:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:15:16 --> Input Class Initialized
INFO - 2020-10-05 17:15:16 --> Language Class Initialized
INFO - 2020-10-05 17:15:16 --> Loader Class Initialized
INFO - 2020-10-05 17:15:16 --> Helper loaded: url_helper
INFO - 2020-10-05 17:15:16 --> Database Driver Class Initialized
INFO - 2020-10-05 17:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:15:16 --> Email Class Initialized
INFO - 2020-10-05 17:15:16 --> Controller Class Initialized
DEBUG - 2020-10-05 17:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:15:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:15:16 --> Model Class Initialized
INFO - 2020-10-05 17:15:16 --> Model Class Initialized
INFO - 2020-10-05 17:15:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:15:16 --> Final output sent to browser
DEBUG - 2020-10-05 17:15:16 --> Total execution time: 0.0236
ERROR - 2020-10-05 17:15:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:15:38 --> Config Class Initialized
INFO - 2020-10-05 17:15:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:15:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:15:38 --> Utf8 Class Initialized
INFO - 2020-10-05 17:15:38 --> URI Class Initialized
INFO - 2020-10-05 17:15:38 --> Router Class Initialized
INFO - 2020-10-05 17:15:38 --> Output Class Initialized
INFO - 2020-10-05 17:15:38 --> Security Class Initialized
DEBUG - 2020-10-05 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:15:38 --> Input Class Initialized
INFO - 2020-10-05 17:15:38 --> Language Class Initialized
INFO - 2020-10-05 17:15:38 --> Loader Class Initialized
INFO - 2020-10-05 17:15:38 --> Helper loaded: url_helper
INFO - 2020-10-05 17:15:38 --> Database Driver Class Initialized
INFO - 2020-10-05 17:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:15:38 --> Email Class Initialized
INFO - 2020-10-05 17:15:38 --> Controller Class Initialized
DEBUG - 2020-10-05 17:15:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:15:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:15:38 --> Model Class Initialized
INFO - 2020-10-05 17:15:38 --> Model Class Initialized
INFO - 2020-10-05 17:15:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 17:15:38 --> Final output sent to browser
DEBUG - 2020-10-05 17:15:38 --> Total execution time: 0.0326
ERROR - 2020-10-05 17:16:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:16:22 --> Config Class Initialized
INFO - 2020-10-05 17:16:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:16:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:16:22 --> Utf8 Class Initialized
INFO - 2020-10-05 17:16:22 --> URI Class Initialized
INFO - 2020-10-05 17:16:22 --> Router Class Initialized
INFO - 2020-10-05 17:16:22 --> Output Class Initialized
INFO - 2020-10-05 17:16:22 --> Security Class Initialized
DEBUG - 2020-10-05 17:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:16:22 --> Input Class Initialized
INFO - 2020-10-05 17:16:22 --> Language Class Initialized
INFO - 2020-10-05 17:16:22 --> Loader Class Initialized
INFO - 2020-10-05 17:16:22 --> Helper loaded: url_helper
INFO - 2020-10-05 17:16:22 --> Database Driver Class Initialized
INFO - 2020-10-05 17:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:16:22 --> Email Class Initialized
INFO - 2020-10-05 17:16:22 --> Controller Class Initialized
DEBUG - 2020-10-05 17:16:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:16:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:16:22 --> Model Class Initialized
INFO - 2020-10-05 17:16:22 --> Model Class Initialized
INFO - 2020-10-05 17:16:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 17:16:22 --> Final output sent to browser
DEBUG - 2020-10-05 17:16:22 --> Total execution time: 0.0225
ERROR - 2020-10-05 17:17:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:17:14 --> Config Class Initialized
INFO - 2020-10-05 17:17:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:17:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:17:14 --> Utf8 Class Initialized
INFO - 2020-10-05 17:17:14 --> URI Class Initialized
INFO - 2020-10-05 17:17:14 --> Router Class Initialized
INFO - 2020-10-05 17:17:14 --> Output Class Initialized
INFO - 2020-10-05 17:17:14 --> Security Class Initialized
DEBUG - 2020-10-05 17:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:17:14 --> Input Class Initialized
INFO - 2020-10-05 17:17:14 --> Language Class Initialized
INFO - 2020-10-05 17:17:14 --> Loader Class Initialized
INFO - 2020-10-05 17:17:14 --> Helper loaded: url_helper
INFO - 2020-10-05 17:17:14 --> Database Driver Class Initialized
INFO - 2020-10-05 17:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:17:14 --> Email Class Initialized
INFO - 2020-10-05 17:17:14 --> Controller Class Initialized
DEBUG - 2020-10-05 17:17:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:17:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:17:14 --> Model Class Initialized
INFO - 2020-10-05 17:17:14 --> Model Class Initialized
INFO - 2020-10-05 17:17:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 17:17:14 --> Final output sent to browser
DEBUG - 2020-10-05 17:17:14 --> Total execution time: 0.1245
ERROR - 2020-10-05 17:17:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:17:20 --> Config Class Initialized
INFO - 2020-10-05 17:17:20 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:17:20 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:17:20 --> Utf8 Class Initialized
INFO - 2020-10-05 17:17:20 --> URI Class Initialized
INFO - 2020-10-05 17:17:20 --> Router Class Initialized
INFO - 2020-10-05 17:17:20 --> Output Class Initialized
INFO - 2020-10-05 17:17:20 --> Security Class Initialized
DEBUG - 2020-10-05 17:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:17:20 --> Input Class Initialized
INFO - 2020-10-05 17:17:20 --> Language Class Initialized
INFO - 2020-10-05 17:17:20 --> Loader Class Initialized
INFO - 2020-10-05 17:17:20 --> Helper loaded: url_helper
INFO - 2020-10-05 17:17:20 --> Database Driver Class Initialized
INFO - 2020-10-05 17:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:17:20 --> Email Class Initialized
INFO - 2020-10-05 17:17:20 --> Controller Class Initialized
DEBUG - 2020-10-05 17:17:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:17:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:17:20 --> Model Class Initialized
INFO - 2020-10-05 17:17:20 --> Model Class Initialized
INFO - 2020-10-05 17:17:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:17:20 --> Final output sent to browser
DEBUG - 2020-10-05 17:17:20 --> Total execution time: 0.0221
ERROR - 2020-10-05 17:17:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:17:24 --> Config Class Initialized
INFO - 2020-10-05 17:17:24 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:17:24 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:17:24 --> Utf8 Class Initialized
INFO - 2020-10-05 17:17:24 --> URI Class Initialized
INFO - 2020-10-05 17:17:24 --> Router Class Initialized
INFO - 2020-10-05 17:17:24 --> Output Class Initialized
INFO - 2020-10-05 17:17:24 --> Security Class Initialized
DEBUG - 2020-10-05 17:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:17:24 --> Input Class Initialized
INFO - 2020-10-05 17:17:24 --> Language Class Initialized
INFO - 2020-10-05 17:17:24 --> Loader Class Initialized
INFO - 2020-10-05 17:17:24 --> Helper loaded: url_helper
INFO - 2020-10-05 17:17:24 --> Database Driver Class Initialized
INFO - 2020-10-05 17:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:17:24 --> Email Class Initialized
INFO - 2020-10-05 17:17:24 --> Controller Class Initialized
DEBUG - 2020-10-05 17:17:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:17:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:17:24 --> Model Class Initialized
INFO - 2020-10-05 17:17:24 --> Model Class Initialized
INFO - 2020-10-05 17:17:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:17:24 --> Final output sent to browser
DEBUG - 2020-10-05 17:17:24 --> Total execution time: 0.0241
ERROR - 2020-10-05 17:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:17:25 --> Config Class Initialized
INFO - 2020-10-05 17:17:25 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:17:25 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:17:25 --> Utf8 Class Initialized
INFO - 2020-10-05 17:17:25 --> URI Class Initialized
INFO - 2020-10-05 17:17:25 --> Router Class Initialized
INFO - 2020-10-05 17:17:25 --> Output Class Initialized
INFO - 2020-10-05 17:17:25 --> Security Class Initialized
DEBUG - 2020-10-05 17:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:17:25 --> Input Class Initialized
INFO - 2020-10-05 17:17:25 --> Language Class Initialized
INFO - 2020-10-05 17:17:25 --> Loader Class Initialized
INFO - 2020-10-05 17:17:25 --> Helper loaded: url_helper
INFO - 2020-10-05 17:17:25 --> Database Driver Class Initialized
INFO - 2020-10-05 17:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:17:25 --> Email Class Initialized
INFO - 2020-10-05 17:17:25 --> Controller Class Initialized
DEBUG - 2020-10-05 17:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:17:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:17:25 --> Model Class Initialized
INFO - 2020-10-05 17:17:25 --> Model Class Initialized
INFO - 2020-10-05 17:17:25 --> Final output sent to browser
DEBUG - 2020-10-05 17:17:25 --> Total execution time: 0.0227
ERROR - 2020-10-05 17:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:17:32 --> Config Class Initialized
INFO - 2020-10-05 17:17:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:17:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:17:32 --> Utf8 Class Initialized
INFO - 2020-10-05 17:17:32 --> URI Class Initialized
INFO - 2020-10-05 17:17:32 --> Router Class Initialized
INFO - 2020-10-05 17:17:32 --> Output Class Initialized
INFO - 2020-10-05 17:17:32 --> Security Class Initialized
DEBUG - 2020-10-05 17:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:17:32 --> Input Class Initialized
INFO - 2020-10-05 17:17:32 --> Language Class Initialized
INFO - 2020-10-05 17:17:32 --> Loader Class Initialized
INFO - 2020-10-05 17:17:32 --> Helper loaded: url_helper
INFO - 2020-10-05 17:17:32 --> Database Driver Class Initialized
INFO - 2020-10-05 17:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:17:32 --> Email Class Initialized
INFO - 2020-10-05 17:17:32 --> Controller Class Initialized
DEBUG - 2020-10-05 17:17:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:17:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:17:32 --> Model Class Initialized
INFO - 2020-10-05 17:17:32 --> Model Class Initialized
INFO - 2020-10-05 17:17:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:17:32 --> Final output sent to browser
DEBUG - 2020-10-05 17:17:32 --> Total execution time: 0.0186
ERROR - 2020-10-05 17:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:16 --> Config Class Initialized
INFO - 2020-10-05 17:18:16 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:16 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:16 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:16 --> URI Class Initialized
INFO - 2020-10-05 17:18:16 --> Router Class Initialized
INFO - 2020-10-05 17:18:16 --> Output Class Initialized
INFO - 2020-10-05 17:18:16 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:16 --> Input Class Initialized
INFO - 2020-10-05 17:18:16 --> Language Class Initialized
INFO - 2020-10-05 17:18:16 --> Loader Class Initialized
INFO - 2020-10-05 17:18:16 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:16 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:16 --> Email Class Initialized
INFO - 2020-10-05 17:18:16 --> Controller Class Initialized
DEBUG - 2020-10-05 17:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:18:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:18:16 --> Model Class Initialized
INFO - 2020-10-05 17:18:16 --> Model Class Initialized
INFO - 2020-10-05 17:18:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:18:16 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:16 --> Total execution time: 0.0220
ERROR - 2020-10-05 17:18:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:17 --> Config Class Initialized
INFO - 2020-10-05 17:18:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:17 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:17 --> URI Class Initialized
INFO - 2020-10-05 17:18:17 --> Router Class Initialized
INFO - 2020-10-05 17:18:17 --> Output Class Initialized
INFO - 2020-10-05 17:18:17 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:17 --> Input Class Initialized
INFO - 2020-10-05 17:18:17 --> Language Class Initialized
ERROR - 2020-10-05 17:18:17 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:18:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:34 --> Config Class Initialized
INFO - 2020-10-05 17:18:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:34 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:34 --> URI Class Initialized
INFO - 2020-10-05 17:18:34 --> Router Class Initialized
INFO - 2020-10-05 17:18:34 --> Output Class Initialized
INFO - 2020-10-05 17:18:34 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:34 --> Input Class Initialized
INFO - 2020-10-05 17:18:34 --> Language Class Initialized
INFO - 2020-10-05 17:18:34 --> Loader Class Initialized
INFO - 2020-10-05 17:18:34 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:34 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:34 --> Email Class Initialized
INFO - 2020-10-05 17:18:34 --> Controller Class Initialized
DEBUG - 2020-10-05 17:18:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:18:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:18:34 --> Model Class Initialized
INFO - 2020-10-05 17:18:34 --> Model Class Initialized
INFO - 2020-10-05 17:18:34 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:34 --> Total execution time: 0.0204
ERROR - 2020-10-05 17:18:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:38 --> Config Class Initialized
INFO - 2020-10-05 17:18:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:38 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:38 --> URI Class Initialized
INFO - 2020-10-05 17:18:38 --> Router Class Initialized
INFO - 2020-10-05 17:18:38 --> Output Class Initialized
INFO - 2020-10-05 17:18:38 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:38 --> Input Class Initialized
INFO - 2020-10-05 17:18:38 --> Language Class Initialized
INFO - 2020-10-05 17:18:38 --> Loader Class Initialized
INFO - 2020-10-05 17:18:38 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:38 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:38 --> Email Class Initialized
INFO - 2020-10-05 17:18:38 --> Controller Class Initialized
DEBUG - 2020-10-05 17:18:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:18:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:18:38 --> Model Class Initialized
INFO - 2020-10-05 17:18:38 --> Model Class Initialized
INFO - 2020-10-05 17:18:38 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:38 --> Total execution time: 0.0256
ERROR - 2020-10-05 17:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:54 --> Config Class Initialized
INFO - 2020-10-05 17:18:54 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:54 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:54 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:54 --> URI Class Initialized
INFO - 2020-10-05 17:18:54 --> Router Class Initialized
INFO - 2020-10-05 17:18:54 --> Output Class Initialized
INFO - 2020-10-05 17:18:54 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:54 --> Input Class Initialized
INFO - 2020-10-05 17:18:54 --> Language Class Initialized
INFO - 2020-10-05 17:18:54 --> Loader Class Initialized
INFO - 2020-10-05 17:18:54 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:54 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:54 --> Email Class Initialized
INFO - 2020-10-05 17:18:54 --> Controller Class Initialized
DEBUG - 2020-10-05 17:18:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:18:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:18:54 --> Model Class Initialized
INFO - 2020-10-05 17:18:54 --> Model Class Initialized
INFO - 2020-10-05 17:18:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:18:54 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:54 --> Total execution time: 0.0215
ERROR - 2020-10-05 17:18:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:58 --> Config Class Initialized
INFO - 2020-10-05 17:18:58 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:58 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:58 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:58 --> URI Class Initialized
INFO - 2020-10-05 17:18:58 --> Router Class Initialized
INFO - 2020-10-05 17:18:58 --> Output Class Initialized
INFO - 2020-10-05 17:18:58 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:58 --> Input Class Initialized
INFO - 2020-10-05 17:18:58 --> Language Class Initialized
INFO - 2020-10-05 17:18:58 --> Loader Class Initialized
INFO - 2020-10-05 17:18:58 --> Helper loaded: url_helper
INFO - 2020-10-05 17:18:58 --> Database Driver Class Initialized
INFO - 2020-10-05 17:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:18:58 --> Email Class Initialized
INFO - 2020-10-05 17:18:58 --> Controller Class Initialized
DEBUG - 2020-10-05 17:18:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:18:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:18:58 --> Model Class Initialized
INFO - 2020-10-05 17:18:58 --> Model Class Initialized
INFO - 2020-10-05 17:18:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:18:58 --> Final output sent to browser
DEBUG - 2020-10-05 17:18:58 --> Total execution time: 0.0241
ERROR - 2020-10-05 17:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:18:59 --> Config Class Initialized
INFO - 2020-10-05 17:18:59 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:18:59 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:18:59 --> Utf8 Class Initialized
INFO - 2020-10-05 17:18:59 --> URI Class Initialized
INFO - 2020-10-05 17:18:59 --> Router Class Initialized
INFO - 2020-10-05 17:18:59 --> Output Class Initialized
INFO - 2020-10-05 17:18:59 --> Security Class Initialized
DEBUG - 2020-10-05 17:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:18:59 --> Input Class Initialized
INFO - 2020-10-05 17:18:59 --> Language Class Initialized
ERROR - 2020-10-05 17:18:59 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:22:06 --> Config Class Initialized
INFO - 2020-10-05 17:22:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:22:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:22:06 --> Utf8 Class Initialized
INFO - 2020-10-05 17:22:06 --> URI Class Initialized
INFO - 2020-10-05 17:22:06 --> Router Class Initialized
INFO - 2020-10-05 17:22:06 --> Output Class Initialized
INFO - 2020-10-05 17:22:06 --> Security Class Initialized
DEBUG - 2020-10-05 17:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:22:06 --> Input Class Initialized
INFO - 2020-10-05 17:22:06 --> Language Class Initialized
INFO - 2020-10-05 17:22:06 --> Loader Class Initialized
INFO - 2020-10-05 17:22:06 --> Helper loaded: url_helper
INFO - 2020-10-05 17:22:06 --> Database Driver Class Initialized
INFO - 2020-10-05 17:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:22:06 --> Email Class Initialized
INFO - 2020-10-05 17:22:06 --> Controller Class Initialized
DEBUG - 2020-10-05 17:22:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:22:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:22:06 --> Model Class Initialized
INFO - 2020-10-05 17:22:06 --> Model Class Initialized
INFO - 2020-10-05 17:22:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:22:06 --> Final output sent to browser
DEBUG - 2020-10-05 17:22:06 --> Total execution time: 0.0191
ERROR - 2020-10-05 17:22:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:22:06 --> Config Class Initialized
INFO - 2020-10-05 17:22:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:22:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:22:06 --> Utf8 Class Initialized
INFO - 2020-10-05 17:22:06 --> URI Class Initialized
INFO - 2020-10-05 17:22:06 --> Router Class Initialized
INFO - 2020-10-05 17:22:06 --> Output Class Initialized
INFO - 2020-10-05 17:22:06 --> Security Class Initialized
DEBUG - 2020-10-05 17:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:22:06 --> Input Class Initialized
INFO - 2020-10-05 17:22:06 --> Language Class Initialized
ERROR - 2020-10-05 17:22:06 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:22:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:22:18 --> Config Class Initialized
INFO - 2020-10-05 17:22:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:22:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:22:18 --> Utf8 Class Initialized
INFO - 2020-10-05 17:22:18 --> URI Class Initialized
INFO - 2020-10-05 17:22:18 --> Router Class Initialized
INFO - 2020-10-05 17:22:18 --> Output Class Initialized
INFO - 2020-10-05 17:22:18 --> Security Class Initialized
DEBUG - 2020-10-05 17:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:22:18 --> Input Class Initialized
INFO - 2020-10-05 17:22:18 --> Language Class Initialized
INFO - 2020-10-05 17:22:18 --> Loader Class Initialized
INFO - 2020-10-05 17:22:18 --> Helper loaded: url_helper
INFO - 2020-10-05 17:22:18 --> Database Driver Class Initialized
INFO - 2020-10-05 17:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:22:18 --> Email Class Initialized
INFO - 2020-10-05 17:22:18 --> Controller Class Initialized
DEBUG - 2020-10-05 17:22:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:22:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:22:18 --> Model Class Initialized
INFO - 2020-10-05 17:22:18 --> Model Class Initialized
INFO - 2020-10-05 17:22:18 --> Final output sent to browser
DEBUG - 2020-10-05 17:22:18 --> Total execution time: 0.0270
ERROR - 2020-10-05 17:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:24:37 --> Config Class Initialized
INFO - 2020-10-05 17:24:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:24:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:24:37 --> Utf8 Class Initialized
INFO - 2020-10-05 17:24:37 --> URI Class Initialized
INFO - 2020-10-05 17:24:37 --> Router Class Initialized
INFO - 2020-10-05 17:24:37 --> Output Class Initialized
INFO - 2020-10-05 17:24:37 --> Security Class Initialized
DEBUG - 2020-10-05 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:24:37 --> Input Class Initialized
INFO - 2020-10-05 17:24:37 --> Language Class Initialized
INFO - 2020-10-05 17:24:37 --> Loader Class Initialized
INFO - 2020-10-05 17:24:37 --> Helper loaded: url_helper
INFO - 2020-10-05 17:24:37 --> Database Driver Class Initialized
INFO - 2020-10-05 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:24:37 --> Email Class Initialized
INFO - 2020-10-05 17:24:37 --> Controller Class Initialized
DEBUG - 2020-10-05 17:24:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:24:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:24:37 --> Model Class Initialized
INFO - 2020-10-05 17:24:37 --> Model Class Initialized
INFO - 2020-10-05 17:24:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:24:37 --> Final output sent to browser
DEBUG - 2020-10-05 17:24:37 --> Total execution time: 0.0258
ERROR - 2020-10-05 17:24:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:24:37 --> Config Class Initialized
INFO - 2020-10-05 17:24:37 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:24:37 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:24:37 --> Utf8 Class Initialized
INFO - 2020-10-05 17:24:37 --> URI Class Initialized
INFO - 2020-10-05 17:24:37 --> Router Class Initialized
INFO - 2020-10-05 17:24:37 --> Output Class Initialized
INFO - 2020-10-05 17:24:37 --> Security Class Initialized
DEBUG - 2020-10-05 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:24:37 --> Input Class Initialized
INFO - 2020-10-05 17:24:37 --> Language Class Initialized
ERROR - 2020-10-05 17:24:37 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:24:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:24:45 --> Config Class Initialized
INFO - 2020-10-05 17:24:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:24:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:24:45 --> Utf8 Class Initialized
INFO - 2020-10-05 17:24:45 --> URI Class Initialized
INFO - 2020-10-05 17:24:45 --> Router Class Initialized
INFO - 2020-10-05 17:24:45 --> Output Class Initialized
INFO - 2020-10-05 17:24:45 --> Security Class Initialized
DEBUG - 2020-10-05 17:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:24:45 --> Input Class Initialized
INFO - 2020-10-05 17:24:45 --> Language Class Initialized
INFO - 2020-10-05 17:24:45 --> Loader Class Initialized
INFO - 2020-10-05 17:24:45 --> Helper loaded: url_helper
INFO - 2020-10-05 17:24:45 --> Database Driver Class Initialized
INFO - 2020-10-05 17:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:24:45 --> Email Class Initialized
INFO - 2020-10-05 17:24:45 --> Controller Class Initialized
DEBUG - 2020-10-05 17:24:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:24:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:24:45 --> Model Class Initialized
INFO - 2020-10-05 17:24:45 --> Model Class Initialized
ERROR - 2020-10-05 17:24:45 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.bye_zone_list_by_province; expected 1, got 0 - Invalid query: CALL bye_zone_list_by_province()
INFO - 2020-10-05 17:24:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-10-05 17:33:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:26 --> Config Class Initialized
INFO - 2020-10-05 17:33:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:26 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:26 --> URI Class Initialized
INFO - 2020-10-05 17:33:26 --> Router Class Initialized
INFO - 2020-10-05 17:33:26 --> Output Class Initialized
INFO - 2020-10-05 17:33:26 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:26 --> Input Class Initialized
INFO - 2020-10-05 17:33:26 --> Language Class Initialized
INFO - 2020-10-05 17:33:26 --> Loader Class Initialized
INFO - 2020-10-05 17:33:26 --> Helper loaded: url_helper
INFO - 2020-10-05 17:33:26 --> Database Driver Class Initialized
INFO - 2020-10-05 17:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:33:26 --> Email Class Initialized
INFO - 2020-10-05 17:33:26 --> Controller Class Initialized
DEBUG - 2020-10-05 17:33:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:33:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:33:26 --> Model Class Initialized
INFO - 2020-10-05 17:33:26 --> Model Class Initialized
INFO - 2020-10-05 17:33:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:33:26 --> Final output sent to browser
DEBUG - 2020-10-05 17:33:26 --> Total execution time: 0.0202
ERROR - 2020-10-05 17:33:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:27 --> Config Class Initialized
INFO - 2020-10-05 17:33:27 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:27 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:27 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:27 --> URI Class Initialized
INFO - 2020-10-05 17:33:27 --> Router Class Initialized
INFO - 2020-10-05 17:33:27 --> Output Class Initialized
INFO - 2020-10-05 17:33:27 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:27 --> Input Class Initialized
INFO - 2020-10-05 17:33:27 --> Language Class Initialized
ERROR - 2020-10-05 17:33:27 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:33:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:42 --> Config Class Initialized
INFO - 2020-10-05 17:33:42 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:42 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:42 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:42 --> URI Class Initialized
INFO - 2020-10-05 17:33:42 --> Router Class Initialized
INFO - 2020-10-05 17:33:42 --> Output Class Initialized
INFO - 2020-10-05 17:33:42 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:42 --> Input Class Initialized
INFO - 2020-10-05 17:33:42 --> Language Class Initialized
INFO - 2020-10-05 17:33:42 --> Loader Class Initialized
INFO - 2020-10-05 17:33:42 --> Helper loaded: url_helper
INFO - 2020-10-05 17:33:42 --> Database Driver Class Initialized
INFO - 2020-10-05 17:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:33:42 --> Email Class Initialized
INFO - 2020-10-05 17:33:42 --> Controller Class Initialized
DEBUG - 2020-10-05 17:33:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:33:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:33:42 --> Model Class Initialized
INFO - 2020-10-05 17:33:42 --> Model Class Initialized
INFO - 2020-10-05 17:33:42 --> Final output sent to browser
DEBUG - 2020-10-05 17:33:42 --> Total execution time: 0.0230
ERROR - 2020-10-05 17:33:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:47 --> Config Class Initialized
INFO - 2020-10-05 17:33:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:47 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:47 --> URI Class Initialized
INFO - 2020-10-05 17:33:47 --> Router Class Initialized
INFO - 2020-10-05 17:33:47 --> Output Class Initialized
INFO - 2020-10-05 17:33:47 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:47 --> Input Class Initialized
INFO - 2020-10-05 17:33:47 --> Language Class Initialized
INFO - 2020-10-05 17:33:47 --> Loader Class Initialized
INFO - 2020-10-05 17:33:47 --> Helper loaded: url_helper
INFO - 2020-10-05 17:33:47 --> Database Driver Class Initialized
INFO - 2020-10-05 17:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:33:47 --> Email Class Initialized
INFO - 2020-10-05 17:33:47 --> Controller Class Initialized
DEBUG - 2020-10-05 17:33:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:33:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:33:47 --> Model Class Initialized
INFO - 2020-10-05 17:33:47 --> Model Class Initialized
INFO - 2020-10-05 17:33:47 --> Final output sent to browser
DEBUG - 2020-10-05 17:33:47 --> Total execution time: 0.0232
ERROR - 2020-10-05 17:33:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:48 --> Config Class Initialized
INFO - 2020-10-05 17:33:48 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:48 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:48 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:48 --> URI Class Initialized
INFO - 2020-10-05 17:33:48 --> Router Class Initialized
INFO - 2020-10-05 17:33:48 --> Output Class Initialized
INFO - 2020-10-05 17:33:48 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:48 --> Input Class Initialized
INFO - 2020-10-05 17:33:48 --> Language Class Initialized
INFO - 2020-10-05 17:33:48 --> Loader Class Initialized
INFO - 2020-10-05 17:33:48 --> Helper loaded: url_helper
INFO - 2020-10-05 17:33:48 --> Database Driver Class Initialized
INFO - 2020-10-05 17:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:33:48 --> Email Class Initialized
INFO - 2020-10-05 17:33:48 --> Controller Class Initialized
DEBUG - 2020-10-05 17:33:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:33:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:33:48 --> Model Class Initialized
INFO - 2020-10-05 17:33:48 --> Model Class Initialized
INFO - 2020-10-05 17:33:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:33:48 --> Final output sent to browser
DEBUG - 2020-10-05 17:33:48 --> Total execution time: 0.0346
ERROR - 2020-10-05 17:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:50 --> Config Class Initialized
INFO - 2020-10-05 17:33:50 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:50 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:50 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:50 --> URI Class Initialized
INFO - 2020-10-05 17:33:50 --> Router Class Initialized
INFO - 2020-10-05 17:33:50 --> Output Class Initialized
INFO - 2020-10-05 17:33:50 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:50 --> Input Class Initialized
INFO - 2020-10-05 17:33:50 --> Language Class Initialized
INFO - 2020-10-05 17:33:50 --> Loader Class Initialized
INFO - 2020-10-05 17:33:50 --> Helper loaded: url_helper
INFO - 2020-10-05 17:33:50 --> Database Driver Class Initialized
INFO - 2020-10-05 17:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:33:50 --> Email Class Initialized
INFO - 2020-10-05 17:33:50 --> Controller Class Initialized
DEBUG - 2020-10-05 17:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:33:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:33:50 --> Model Class Initialized
INFO - 2020-10-05 17:33:50 --> Model Class Initialized
INFO - 2020-10-05 17:33:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:33:50 --> Final output sent to browser
DEBUG - 2020-10-05 17:33:50 --> Total execution time: 0.0239
ERROR - 2020-10-05 17:33:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:33:51 --> Config Class Initialized
INFO - 2020-10-05 17:33:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:33:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:33:51 --> Utf8 Class Initialized
INFO - 2020-10-05 17:33:51 --> URI Class Initialized
INFO - 2020-10-05 17:33:51 --> Router Class Initialized
INFO - 2020-10-05 17:33:51 --> Output Class Initialized
INFO - 2020-10-05 17:33:51 --> Security Class Initialized
DEBUG - 2020-10-05 17:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:33:51 --> Input Class Initialized
INFO - 2020-10-05 17:33:51 --> Language Class Initialized
ERROR - 2020-10-05 17:33:51 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:37:32 --> Config Class Initialized
INFO - 2020-10-05 17:37:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:37:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:37:32 --> Utf8 Class Initialized
INFO - 2020-10-05 17:37:32 --> URI Class Initialized
INFO - 2020-10-05 17:37:32 --> Router Class Initialized
INFO - 2020-10-05 17:37:32 --> Output Class Initialized
INFO - 2020-10-05 17:37:32 --> Security Class Initialized
DEBUG - 2020-10-05 17:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:37:32 --> Input Class Initialized
INFO - 2020-10-05 17:37:32 --> Language Class Initialized
INFO - 2020-10-05 17:37:32 --> Loader Class Initialized
INFO - 2020-10-05 17:37:32 --> Helper loaded: url_helper
INFO - 2020-10-05 17:37:32 --> Database Driver Class Initialized
INFO - 2020-10-05 17:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:37:32 --> Email Class Initialized
INFO - 2020-10-05 17:37:32 --> Controller Class Initialized
DEBUG - 2020-10-05 17:37:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:37:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:37:32 --> Model Class Initialized
INFO - 2020-10-05 17:37:32 --> Model Class Initialized
INFO - 2020-10-05 17:37:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:37:32 --> Final output sent to browser
DEBUG - 2020-10-05 17:37:32 --> Total execution time: 0.0198
ERROR - 2020-10-05 17:37:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:37:32 --> Config Class Initialized
INFO - 2020-10-05 17:37:32 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:37:32 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:37:32 --> Utf8 Class Initialized
INFO - 2020-10-05 17:37:32 --> URI Class Initialized
INFO - 2020-10-05 17:37:32 --> Router Class Initialized
INFO - 2020-10-05 17:37:32 --> Output Class Initialized
INFO - 2020-10-05 17:37:32 --> Security Class Initialized
DEBUG - 2020-10-05 17:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:37:32 --> Input Class Initialized
INFO - 2020-10-05 17:37:32 --> Language Class Initialized
ERROR - 2020-10-05 17:37:32 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:14 --> Config Class Initialized
INFO - 2020-10-05 17:39:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:14 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:14 --> URI Class Initialized
INFO - 2020-10-05 17:39:14 --> Router Class Initialized
INFO - 2020-10-05 17:39:14 --> Output Class Initialized
INFO - 2020-10-05 17:39:14 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:14 --> Input Class Initialized
INFO - 2020-10-05 17:39:14 --> Language Class Initialized
INFO - 2020-10-05 17:39:14 --> Loader Class Initialized
INFO - 2020-10-05 17:39:14 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:14 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:14 --> Email Class Initialized
INFO - 2020-10-05 17:39:14 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:14 --> Model Class Initialized
INFO - 2020-10-05 17:39:14 --> Model Class Initialized
INFO - 2020-10-05 17:39:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:39:14 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:14 --> Total execution time: 0.0251
ERROR - 2020-10-05 17:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:17 --> Config Class Initialized
INFO - 2020-10-05 17:39:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:17 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:17 --> URI Class Initialized
INFO - 2020-10-05 17:39:17 --> Router Class Initialized
INFO - 2020-10-05 17:39:17 --> Output Class Initialized
INFO - 2020-10-05 17:39:17 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:17 --> Input Class Initialized
INFO - 2020-10-05 17:39:17 --> Language Class Initialized
INFO - 2020-10-05 17:39:17 --> Loader Class Initialized
INFO - 2020-10-05 17:39:17 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:17 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:17 --> Email Class Initialized
INFO - 2020-10-05 17:39:17 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:17 --> Model Class Initialized
INFO - 2020-10-05 17:39:17 --> Model Class Initialized
INFO - 2020-10-05 17:39:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:39:17 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:17 --> Total execution time: 0.0221
ERROR - 2020-10-05 17:39:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:17 --> Config Class Initialized
INFO - 2020-10-05 17:39:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:17 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:17 --> URI Class Initialized
INFO - 2020-10-05 17:39:17 --> Router Class Initialized
INFO - 2020-10-05 17:39:17 --> Output Class Initialized
INFO - 2020-10-05 17:39:17 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:17 --> Input Class Initialized
INFO - 2020-10-05 17:39:17 --> Language Class Initialized
INFO - 2020-10-05 17:39:17 --> Loader Class Initialized
INFO - 2020-10-05 17:39:17 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:17 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:17 --> Email Class Initialized
INFO - 2020-10-05 17:39:17 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:17 --> Model Class Initialized
INFO - 2020-10-05 17:39:17 --> Model Class Initialized
INFO - 2020-10-05 17:39:17 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:17 --> Total execution time: 0.0283
ERROR - 2020-10-05 17:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:22 --> Config Class Initialized
INFO - 2020-10-05 17:39:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:22 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:22 --> URI Class Initialized
INFO - 2020-10-05 17:39:22 --> Router Class Initialized
INFO - 2020-10-05 17:39:22 --> Output Class Initialized
INFO - 2020-10-05 17:39:22 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:22 --> Input Class Initialized
INFO - 2020-10-05 17:39:22 --> Language Class Initialized
INFO - 2020-10-05 17:39:22 --> Loader Class Initialized
INFO - 2020-10-05 17:39:22 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:22 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:22 --> Email Class Initialized
INFO - 2020-10-05 17:39:22 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:22 --> Model Class Initialized
INFO - 2020-10-05 17:39:22 --> Model Class Initialized
INFO - 2020-10-05 17:39:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:39:22 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:22 --> Total execution time: 0.0228
ERROR - 2020-10-05 17:39:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:23 --> Config Class Initialized
INFO - 2020-10-05 17:39:23 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:23 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:23 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:23 --> URI Class Initialized
INFO - 2020-10-05 17:39:23 --> Router Class Initialized
INFO - 2020-10-05 17:39:23 --> Output Class Initialized
INFO - 2020-10-05 17:39:23 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:23 --> Input Class Initialized
INFO - 2020-10-05 17:39:23 --> Language Class Initialized
INFO - 2020-10-05 17:39:23 --> Loader Class Initialized
INFO - 2020-10-05 17:39:23 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:23 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:23 --> Email Class Initialized
INFO - 2020-10-05 17:39:23 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:23 --> Model Class Initialized
INFO - 2020-10-05 17:39:23 --> Model Class Initialized
INFO - 2020-10-05 17:39:23 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:23 --> Total execution time: 0.0241
ERROR - 2020-10-05 17:39:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:31 --> Config Class Initialized
INFO - 2020-10-05 17:39:31 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:31 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:31 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:31 --> URI Class Initialized
INFO - 2020-10-05 17:39:31 --> Router Class Initialized
INFO - 2020-10-05 17:39:31 --> Output Class Initialized
INFO - 2020-10-05 17:39:31 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:31 --> Input Class Initialized
INFO - 2020-10-05 17:39:31 --> Language Class Initialized
INFO - 2020-10-05 17:39:31 --> Loader Class Initialized
INFO - 2020-10-05 17:39:31 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:31 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:31 --> Email Class Initialized
INFO - 2020-10-05 17:39:31 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:31 --> Model Class Initialized
INFO - 2020-10-05 17:39:31 --> Model Class Initialized
INFO - 2020-10-05 17:39:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:39:31 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:31 --> Total execution time: 0.0209
ERROR - 2020-10-05 17:39:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:33 --> Config Class Initialized
INFO - 2020-10-05 17:39:33 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:33 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:33 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:33 --> URI Class Initialized
INFO - 2020-10-05 17:39:33 --> Router Class Initialized
INFO - 2020-10-05 17:39:33 --> Output Class Initialized
INFO - 2020-10-05 17:39:33 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:33 --> Input Class Initialized
INFO - 2020-10-05 17:39:33 --> Language Class Initialized
INFO - 2020-10-05 17:39:33 --> Loader Class Initialized
INFO - 2020-10-05 17:39:33 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:33 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:33 --> Email Class Initialized
INFO - 2020-10-05 17:39:33 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:33 --> Model Class Initialized
INFO - 2020-10-05 17:39:33 --> Model Class Initialized
INFO - 2020-10-05 17:39:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:39:33 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:33 --> Total execution time: 0.0227
ERROR - 2020-10-05 17:39:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:34 --> Config Class Initialized
INFO - 2020-10-05 17:39:34 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:34 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:34 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:34 --> URI Class Initialized
INFO - 2020-10-05 17:39:34 --> Router Class Initialized
INFO - 2020-10-05 17:39:34 --> Output Class Initialized
INFO - 2020-10-05 17:39:34 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:34 --> Input Class Initialized
INFO - 2020-10-05 17:39:34 --> Language Class Initialized
INFO - 2020-10-05 17:39:34 --> Loader Class Initialized
INFO - 2020-10-05 17:39:34 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:34 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:34 --> Email Class Initialized
INFO - 2020-10-05 17:39:34 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:34 --> Model Class Initialized
INFO - 2020-10-05 17:39:34 --> Model Class Initialized
INFO - 2020-10-05 17:39:34 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:34 --> Total execution time: 0.0241
ERROR - 2020-10-05 17:39:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:38 --> Config Class Initialized
INFO - 2020-10-05 17:39:38 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:38 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:38 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:38 --> URI Class Initialized
INFO - 2020-10-05 17:39:38 --> Router Class Initialized
INFO - 2020-10-05 17:39:38 --> Output Class Initialized
INFO - 2020-10-05 17:39:38 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:38 --> Input Class Initialized
INFO - 2020-10-05 17:39:38 --> Language Class Initialized
INFO - 2020-10-05 17:39:38 --> Loader Class Initialized
INFO - 2020-10-05 17:39:38 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:38 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:38 --> Email Class Initialized
INFO - 2020-10-05 17:39:38 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:38 --> Model Class Initialized
INFO - 2020-10-05 17:39:38 --> Model Class Initialized
INFO - 2020-10-05 17:39:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:39:38 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:38 --> Total execution time: 0.0206
ERROR - 2020-10-05 17:39:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:39 --> Config Class Initialized
INFO - 2020-10-05 17:39:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:39 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:39 --> URI Class Initialized
INFO - 2020-10-05 17:39:39 --> Router Class Initialized
INFO - 2020-10-05 17:39:39 --> Output Class Initialized
INFO - 2020-10-05 17:39:39 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:39 --> Input Class Initialized
INFO - 2020-10-05 17:39:39 --> Language Class Initialized
INFO - 2020-10-05 17:39:39 --> Loader Class Initialized
INFO - 2020-10-05 17:39:39 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:39 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:39 --> Email Class Initialized
INFO - 2020-10-05 17:39:39 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:39 --> Model Class Initialized
INFO - 2020-10-05 17:39:39 --> Model Class Initialized
INFO - 2020-10-05 17:39:39 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:39 --> Total execution time: 0.0397
ERROR - 2020-10-05 17:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:43 --> Config Class Initialized
INFO - 2020-10-05 17:39:43 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:43 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:43 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:43 --> URI Class Initialized
INFO - 2020-10-05 17:39:43 --> Router Class Initialized
INFO - 2020-10-05 17:39:43 --> Output Class Initialized
INFO - 2020-10-05 17:39:43 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:43 --> Input Class Initialized
INFO - 2020-10-05 17:39:43 --> Language Class Initialized
INFO - 2020-10-05 17:39:43 --> Loader Class Initialized
INFO - 2020-10-05 17:39:43 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:43 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:43 --> Email Class Initialized
INFO - 2020-10-05 17:39:43 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:43 --> Model Class Initialized
INFO - 2020-10-05 17:39:43 --> Model Class Initialized
INFO - 2020-10-05 17:39:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:39:43 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:43 --> Total execution time: 0.0196
ERROR - 2020-10-05 17:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:43 --> Config Class Initialized
INFO - 2020-10-05 17:39:43 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:43 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:43 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:43 --> URI Class Initialized
INFO - 2020-10-05 17:39:43 --> Router Class Initialized
INFO - 2020-10-05 17:39:43 --> Output Class Initialized
INFO - 2020-10-05 17:39:43 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:43 --> Input Class Initialized
INFO - 2020-10-05 17:39:43 --> Language Class Initialized
INFO - 2020-10-05 17:39:43 --> Loader Class Initialized
INFO - 2020-10-05 17:39:43 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:43 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:43 --> Email Class Initialized
INFO - 2020-10-05 17:39:43 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:43 --> Model Class Initialized
INFO - 2020-10-05 17:39:43 --> Model Class Initialized
INFO - 2020-10-05 17:39:43 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:43 --> Total execution time: 0.0290
ERROR - 2020-10-05 17:39:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:47 --> Config Class Initialized
INFO - 2020-10-05 17:39:47 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:47 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:47 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:47 --> URI Class Initialized
INFO - 2020-10-05 17:39:47 --> Router Class Initialized
INFO - 2020-10-05 17:39:47 --> Output Class Initialized
INFO - 2020-10-05 17:39:47 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:47 --> Input Class Initialized
INFO - 2020-10-05 17:39:47 --> Language Class Initialized
INFO - 2020-10-05 17:39:47 --> Loader Class Initialized
INFO - 2020-10-05 17:39:47 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:47 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:47 --> Email Class Initialized
INFO - 2020-10-05 17:39:47 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:47 --> Model Class Initialized
INFO - 2020-10-05 17:39:47 --> Model Class Initialized
INFO - 2020-10-05 17:39:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:39:47 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:47 --> Total execution time: 0.0251
ERROR - 2020-10-05 17:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:50 --> Config Class Initialized
INFO - 2020-10-05 17:39:50 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:50 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:50 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:50 --> URI Class Initialized
INFO - 2020-10-05 17:39:50 --> Router Class Initialized
INFO - 2020-10-05 17:39:50 --> Output Class Initialized
INFO - 2020-10-05 17:39:50 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:50 --> Input Class Initialized
INFO - 2020-10-05 17:39:50 --> Language Class Initialized
INFO - 2020-10-05 17:39:50 --> Loader Class Initialized
INFO - 2020-10-05 17:39:50 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:50 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:50 --> Email Class Initialized
INFO - 2020-10-05 17:39:50 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:50 --> Model Class Initialized
INFO - 2020-10-05 17:39:50 --> Model Class Initialized
INFO - 2020-10-05 17:39:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:39:50 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:50 --> Total execution time: 0.0229
ERROR - 2020-10-05 17:39:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:39:51 --> Config Class Initialized
INFO - 2020-10-05 17:39:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:39:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:39:51 --> Utf8 Class Initialized
INFO - 2020-10-05 17:39:51 --> URI Class Initialized
INFO - 2020-10-05 17:39:51 --> Router Class Initialized
INFO - 2020-10-05 17:39:51 --> Output Class Initialized
INFO - 2020-10-05 17:39:51 --> Security Class Initialized
DEBUG - 2020-10-05 17:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:39:51 --> Input Class Initialized
INFO - 2020-10-05 17:39:51 --> Language Class Initialized
INFO - 2020-10-05 17:39:51 --> Loader Class Initialized
INFO - 2020-10-05 17:39:51 --> Helper loaded: url_helper
INFO - 2020-10-05 17:39:51 --> Database Driver Class Initialized
INFO - 2020-10-05 17:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:39:51 --> Email Class Initialized
INFO - 2020-10-05 17:39:51 --> Controller Class Initialized
DEBUG - 2020-10-05 17:39:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:39:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:39:51 --> Model Class Initialized
INFO - 2020-10-05 17:39:51 --> Model Class Initialized
INFO - 2020-10-05 17:39:51 --> Final output sent to browser
DEBUG - 2020-10-05 17:39:51 --> Total execution time: 0.0223
ERROR - 2020-10-05 17:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:02 --> Config Class Initialized
INFO - 2020-10-05 17:40:02 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:02 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:02 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:02 --> URI Class Initialized
INFO - 2020-10-05 17:40:02 --> Router Class Initialized
INFO - 2020-10-05 17:40:02 --> Output Class Initialized
INFO - 2020-10-05 17:40:02 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:02 --> Input Class Initialized
INFO - 2020-10-05 17:40:02 --> Language Class Initialized
INFO - 2020-10-05 17:40:02 --> Loader Class Initialized
INFO - 2020-10-05 17:40:02 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:02 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:02 --> Email Class Initialized
INFO - 2020-10-05 17:40:02 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:02 --> Model Class Initialized
INFO - 2020-10-05 17:40:02 --> Model Class Initialized
INFO - 2020-10-05 17:40:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:40:02 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:02 --> Total execution time: 0.0193
ERROR - 2020-10-05 17:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:05 --> Config Class Initialized
INFO - 2020-10-05 17:40:05 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:05 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:05 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:05 --> URI Class Initialized
INFO - 2020-10-05 17:40:05 --> Router Class Initialized
INFO - 2020-10-05 17:40:05 --> Output Class Initialized
INFO - 2020-10-05 17:40:05 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:05 --> Input Class Initialized
INFO - 2020-10-05 17:40:05 --> Language Class Initialized
INFO - 2020-10-05 17:40:05 --> Loader Class Initialized
INFO - 2020-10-05 17:40:05 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:05 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:05 --> Email Class Initialized
INFO - 2020-10-05 17:40:05 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:05 --> Model Class Initialized
INFO - 2020-10-05 17:40:05 --> Model Class Initialized
INFO - 2020-10-05 17:40:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:40:05 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:05 --> Total execution time: 0.0246
ERROR - 2020-10-05 17:40:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:06 --> Config Class Initialized
INFO - 2020-10-05 17:40:06 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:06 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:06 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:06 --> URI Class Initialized
INFO - 2020-10-05 17:40:06 --> Router Class Initialized
INFO - 2020-10-05 17:40:06 --> Output Class Initialized
INFO - 2020-10-05 17:40:06 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:06 --> Input Class Initialized
INFO - 2020-10-05 17:40:06 --> Language Class Initialized
INFO - 2020-10-05 17:40:06 --> Loader Class Initialized
INFO - 2020-10-05 17:40:06 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:06 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:06 --> Email Class Initialized
INFO - 2020-10-05 17:40:06 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:06 --> Model Class Initialized
INFO - 2020-10-05 17:40:06 --> Model Class Initialized
INFO - 2020-10-05 17:40:06 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:06 --> Total execution time: 0.0242
ERROR - 2020-10-05 17:40:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:11 --> Config Class Initialized
INFO - 2020-10-05 17:40:11 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:11 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:11 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:11 --> URI Class Initialized
INFO - 2020-10-05 17:40:11 --> Router Class Initialized
INFO - 2020-10-05 17:40:11 --> Output Class Initialized
INFO - 2020-10-05 17:40:11 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:11 --> Input Class Initialized
INFO - 2020-10-05 17:40:11 --> Language Class Initialized
INFO - 2020-10-05 17:40:11 --> Loader Class Initialized
INFO - 2020-10-05 17:40:11 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:11 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:11 --> Email Class Initialized
INFO - 2020-10-05 17:40:11 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:11 --> Model Class Initialized
INFO - 2020-10-05 17:40:11 --> Model Class Initialized
INFO - 2020-10-05 17:40:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:40:11 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:11 --> Total execution time: 0.0238
ERROR - 2020-10-05 17:40:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:14 --> Config Class Initialized
INFO - 2020-10-05 17:40:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:14 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:14 --> URI Class Initialized
INFO - 2020-10-05 17:40:14 --> Router Class Initialized
INFO - 2020-10-05 17:40:14 --> Output Class Initialized
INFO - 2020-10-05 17:40:14 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:14 --> Input Class Initialized
INFO - 2020-10-05 17:40:14 --> Language Class Initialized
INFO - 2020-10-05 17:40:14 --> Loader Class Initialized
INFO - 2020-10-05 17:40:14 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:14 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:14 --> Email Class Initialized
INFO - 2020-10-05 17:40:14 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:14 --> Model Class Initialized
INFO - 2020-10-05 17:40:14 --> Model Class Initialized
INFO - 2020-10-05 17:40:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:40:14 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:14 --> Total execution time: 0.0210
ERROR - 2020-10-05 17:40:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:17 --> Config Class Initialized
INFO - 2020-10-05 17:40:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:17 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:17 --> URI Class Initialized
INFO - 2020-10-05 17:40:17 --> Router Class Initialized
INFO - 2020-10-05 17:40:17 --> Output Class Initialized
INFO - 2020-10-05 17:40:17 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:17 --> Input Class Initialized
INFO - 2020-10-05 17:40:17 --> Language Class Initialized
INFO - 2020-10-05 17:40:17 --> Loader Class Initialized
INFO - 2020-10-05 17:40:17 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:17 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:17 --> Email Class Initialized
INFO - 2020-10-05 17:40:17 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:17 --> Model Class Initialized
INFO - 2020-10-05 17:40:17 --> Model Class Initialized
INFO - 2020-10-05 17:40:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:40:17 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:17 --> Total execution time: 0.0197
ERROR - 2020-10-05 17:40:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:18 --> Config Class Initialized
INFO - 2020-10-05 17:40:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:18 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:18 --> URI Class Initialized
INFO - 2020-10-05 17:40:18 --> Router Class Initialized
INFO - 2020-10-05 17:40:18 --> Output Class Initialized
INFO - 2020-10-05 17:40:18 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:18 --> Input Class Initialized
INFO - 2020-10-05 17:40:18 --> Language Class Initialized
INFO - 2020-10-05 17:40:18 --> Loader Class Initialized
INFO - 2020-10-05 17:40:18 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:18 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:18 --> Email Class Initialized
INFO - 2020-10-05 17:40:18 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:18 --> Model Class Initialized
INFO - 2020-10-05 17:40:18 --> Model Class Initialized
INFO - 2020-10-05 17:40:18 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:18 --> Total execution time: 0.0272
ERROR - 2020-10-05 17:40:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:27 --> Config Class Initialized
INFO - 2020-10-05 17:40:27 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:28 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:28 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:28 --> URI Class Initialized
INFO - 2020-10-05 17:40:28 --> Router Class Initialized
INFO - 2020-10-05 17:40:28 --> Output Class Initialized
INFO - 2020-10-05 17:40:28 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:28 --> Input Class Initialized
INFO - 2020-10-05 17:40:28 --> Language Class Initialized
INFO - 2020-10-05 17:40:28 --> Loader Class Initialized
INFO - 2020-10-05 17:40:28 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:28 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:28 --> Email Class Initialized
INFO - 2020-10-05 17:40:28 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:28 --> Model Class Initialized
INFO - 2020-10-05 17:40:28 --> Model Class Initialized
INFO - 2020-10-05 17:40:28 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:28 --> Total execution time: 0.0230
ERROR - 2020-10-05 17:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:30 --> Config Class Initialized
INFO - 2020-10-05 17:40:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:30 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:30 --> URI Class Initialized
INFO - 2020-10-05 17:40:30 --> Router Class Initialized
INFO - 2020-10-05 17:40:30 --> Output Class Initialized
INFO - 2020-10-05 17:40:30 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:30 --> Input Class Initialized
INFO - 2020-10-05 17:40:30 --> Language Class Initialized
INFO - 2020-10-05 17:40:30 --> Loader Class Initialized
INFO - 2020-10-05 17:40:30 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:30 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:30 --> Email Class Initialized
INFO - 2020-10-05 17:40:30 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:30 --> Model Class Initialized
INFO - 2020-10-05 17:40:30 --> Model Class Initialized
INFO - 2020-10-05 17:40:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:40:30 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:30 --> Total execution time: 0.0218
ERROR - 2020-10-05 17:40:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:35 --> Config Class Initialized
INFO - 2020-10-05 17:40:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:35 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:35 --> URI Class Initialized
INFO - 2020-10-05 17:40:35 --> Router Class Initialized
INFO - 2020-10-05 17:40:35 --> Output Class Initialized
INFO - 2020-10-05 17:40:35 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:35 --> Input Class Initialized
INFO - 2020-10-05 17:40:35 --> Language Class Initialized
INFO - 2020-10-05 17:40:35 --> Loader Class Initialized
INFO - 2020-10-05 17:40:35 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:35 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:35 --> Email Class Initialized
INFO - 2020-10-05 17:40:35 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:35 --> Model Class Initialized
INFO - 2020-10-05 17:40:35 --> Model Class Initialized
INFO - 2020-10-05 17:40:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:40:35 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:35 --> Total execution time: 0.0222
ERROR - 2020-10-05 17:40:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:36 --> Config Class Initialized
INFO - 2020-10-05 17:40:36 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:36 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:36 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:36 --> URI Class Initialized
INFO - 2020-10-05 17:40:36 --> Router Class Initialized
INFO - 2020-10-05 17:40:36 --> Output Class Initialized
INFO - 2020-10-05 17:40:36 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:36 --> Input Class Initialized
INFO - 2020-10-05 17:40:36 --> Language Class Initialized
INFO - 2020-10-05 17:40:36 --> Loader Class Initialized
INFO - 2020-10-05 17:40:36 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:36 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:36 --> Email Class Initialized
INFO - 2020-10-05 17:40:36 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:36 --> Model Class Initialized
INFO - 2020-10-05 17:40:36 --> Model Class Initialized
INFO - 2020-10-05 17:40:36 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:36 --> Total execution time: 0.0349
ERROR - 2020-10-05 17:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:39 --> Config Class Initialized
INFO - 2020-10-05 17:40:39 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:39 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:39 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:39 --> URI Class Initialized
INFO - 2020-10-05 17:40:39 --> Router Class Initialized
INFO - 2020-10-05 17:40:39 --> Output Class Initialized
INFO - 2020-10-05 17:40:39 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:39 --> Input Class Initialized
INFO - 2020-10-05 17:40:39 --> Language Class Initialized
INFO - 2020-10-05 17:40:39 --> Loader Class Initialized
INFO - 2020-10-05 17:40:39 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:39 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:39 --> Email Class Initialized
INFO - 2020-10-05 17:40:39 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:39 --> Model Class Initialized
INFO - 2020-10-05 17:40:39 --> Model Class Initialized
INFO - 2020-10-05 17:40:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:40:39 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:39 --> Total execution time: 0.0221
ERROR - 2020-10-05 17:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:45 --> Config Class Initialized
INFO - 2020-10-05 17:40:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:45 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:45 --> URI Class Initialized
INFO - 2020-10-05 17:40:45 --> Router Class Initialized
INFO - 2020-10-05 17:40:45 --> Output Class Initialized
INFO - 2020-10-05 17:40:45 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:45 --> Input Class Initialized
INFO - 2020-10-05 17:40:45 --> Language Class Initialized
INFO - 2020-10-05 17:40:45 --> Loader Class Initialized
INFO - 2020-10-05 17:40:45 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:45 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:45 --> Email Class Initialized
INFO - 2020-10-05 17:40:45 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:45 --> Model Class Initialized
INFO - 2020-10-05 17:40:45 --> Model Class Initialized
INFO - 2020-10-05 17:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:40:45 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:45 --> Total execution time: 0.0202
ERROR - 2020-10-05 17:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:45 --> Config Class Initialized
INFO - 2020-10-05 17:40:45 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:45 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:45 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:45 --> URI Class Initialized
INFO - 2020-10-05 17:40:45 --> Router Class Initialized
INFO - 2020-10-05 17:40:45 --> Output Class Initialized
INFO - 2020-10-05 17:40:45 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:45 --> Input Class Initialized
INFO - 2020-10-05 17:40:45 --> Language Class Initialized
INFO - 2020-10-05 17:40:45 --> Loader Class Initialized
INFO - 2020-10-05 17:40:45 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:45 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:45 --> Email Class Initialized
INFO - 2020-10-05 17:40:45 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:45 --> Model Class Initialized
INFO - 2020-10-05 17:40:45 --> Model Class Initialized
INFO - 2020-10-05 17:40:45 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:45 --> Total execution time: 0.0232
ERROR - 2020-10-05 17:40:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:51 --> Config Class Initialized
INFO - 2020-10-05 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:51 --> URI Class Initialized
INFO - 2020-10-05 17:40:51 --> Router Class Initialized
INFO - 2020-10-05 17:40:51 --> Output Class Initialized
INFO - 2020-10-05 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:51 --> Input Class Initialized
INFO - 2020-10-05 17:40:51 --> Language Class Initialized
INFO - 2020-10-05 17:40:51 --> Loader Class Initialized
INFO - 2020-10-05 17:40:51 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:51 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:51 --> Email Class Initialized
INFO - 2020-10-05 17:40:51 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:51 --> Model Class Initialized
INFO - 2020-10-05 17:40:51 --> Model Class Initialized
INFO - 2020-10-05 17:40:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:40:51 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:51 --> Total execution time: 0.0213
ERROR - 2020-10-05 17:40:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:55 --> Config Class Initialized
INFO - 2020-10-05 17:40:55 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:55 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:55 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:55 --> URI Class Initialized
INFO - 2020-10-05 17:40:55 --> Router Class Initialized
INFO - 2020-10-05 17:40:55 --> Output Class Initialized
INFO - 2020-10-05 17:40:55 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:55 --> Input Class Initialized
INFO - 2020-10-05 17:40:55 --> Language Class Initialized
INFO - 2020-10-05 17:40:55 --> Loader Class Initialized
INFO - 2020-10-05 17:40:55 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:55 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:55 --> Email Class Initialized
INFO - 2020-10-05 17:40:55 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:55 --> Model Class Initialized
INFO - 2020-10-05 17:40:55 --> Model Class Initialized
INFO - 2020-10-05 17:40:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-05 17:40:55 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:55 --> Total execution time: 0.0244
ERROR - 2020-10-05 17:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:40:56 --> Config Class Initialized
INFO - 2020-10-05 17:40:56 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:40:56 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:40:56 --> Utf8 Class Initialized
INFO - 2020-10-05 17:40:56 --> URI Class Initialized
INFO - 2020-10-05 17:40:56 --> Router Class Initialized
INFO - 2020-10-05 17:40:56 --> Output Class Initialized
INFO - 2020-10-05 17:40:56 --> Security Class Initialized
DEBUG - 2020-10-05 17:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:40:56 --> Input Class Initialized
INFO - 2020-10-05 17:40:56 --> Language Class Initialized
INFO - 2020-10-05 17:40:56 --> Loader Class Initialized
INFO - 2020-10-05 17:40:56 --> Helper loaded: url_helper
INFO - 2020-10-05 17:40:56 --> Database Driver Class Initialized
INFO - 2020-10-05 17:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:40:56 --> Email Class Initialized
INFO - 2020-10-05 17:40:56 --> Controller Class Initialized
DEBUG - 2020-10-05 17:40:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:40:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:40:56 --> Model Class Initialized
INFO - 2020-10-05 17:40:56 --> Model Class Initialized
INFO - 2020-10-05 17:40:56 --> Final output sent to browser
DEBUG - 2020-10-05 17:40:56 --> Total execution time: 0.0198
ERROR - 2020-10-05 17:41:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:41:01 --> Config Class Initialized
INFO - 2020-10-05 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-05 17:41:01 --> URI Class Initialized
INFO - 2020-10-05 17:41:01 --> Router Class Initialized
INFO - 2020-10-05 17:41:01 --> Output Class Initialized
INFO - 2020-10-05 17:41:01 --> Security Class Initialized
DEBUG - 2020-10-05 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:41:01 --> Input Class Initialized
INFO - 2020-10-05 17:41:01 --> Language Class Initialized
INFO - 2020-10-05 17:41:01 --> Loader Class Initialized
INFO - 2020-10-05 17:41:01 --> Helper loaded: url_helper
INFO - 2020-10-05 17:41:01 --> Database Driver Class Initialized
INFO - 2020-10-05 17:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:41:01 --> Email Class Initialized
INFO - 2020-10-05 17:41:01 --> Controller Class Initialized
DEBUG - 2020-10-05 17:41:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:41:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:41:01 --> Model Class Initialized
INFO - 2020-10-05 17:41:01 --> Model Class Initialized
INFO - 2020-10-05 17:41:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:41:01 --> Final output sent to browser
DEBUG - 2020-10-05 17:41:01 --> Total execution time: 0.0307
ERROR - 2020-10-05 17:41:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:41:14 --> Config Class Initialized
INFO - 2020-10-05 17:41:14 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:41:14 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:41:14 --> Utf8 Class Initialized
INFO - 2020-10-05 17:41:14 --> URI Class Initialized
INFO - 2020-10-05 17:41:14 --> Router Class Initialized
INFO - 2020-10-05 17:41:14 --> Output Class Initialized
INFO - 2020-10-05 17:41:14 --> Security Class Initialized
DEBUG - 2020-10-05 17:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:41:14 --> Input Class Initialized
INFO - 2020-10-05 17:41:14 --> Language Class Initialized
INFO - 2020-10-05 17:41:14 --> Loader Class Initialized
INFO - 2020-10-05 17:41:14 --> Helper loaded: url_helper
INFO - 2020-10-05 17:41:14 --> Database Driver Class Initialized
INFO - 2020-10-05 17:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:41:14 --> Email Class Initialized
INFO - 2020-10-05 17:41:14 --> Controller Class Initialized
DEBUG - 2020-10-05 17:41:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:41:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:41:14 --> Model Class Initialized
INFO - 2020-10-05 17:41:14 --> Model Class Initialized
INFO - 2020-10-05 17:41:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-05 17:41:14 --> Final output sent to browser
DEBUG - 2020-10-05 17:41:14 --> Total execution time: 0.0219
ERROR - 2020-10-05 17:41:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:41:18 --> Config Class Initialized
INFO - 2020-10-05 17:41:18 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:41:18 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:41:18 --> Utf8 Class Initialized
INFO - 2020-10-05 17:41:18 --> URI Class Initialized
INFO - 2020-10-05 17:41:18 --> Router Class Initialized
INFO - 2020-10-05 17:41:18 --> Output Class Initialized
INFO - 2020-10-05 17:41:18 --> Security Class Initialized
DEBUG - 2020-10-05 17:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:41:18 --> Input Class Initialized
INFO - 2020-10-05 17:41:18 --> Language Class Initialized
INFO - 2020-10-05 17:41:18 --> Loader Class Initialized
INFO - 2020-10-05 17:41:18 --> Helper loaded: url_helper
INFO - 2020-10-05 17:41:18 --> Database Driver Class Initialized
INFO - 2020-10-05 17:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:41:18 --> Email Class Initialized
INFO - 2020-10-05 17:41:18 --> Controller Class Initialized
DEBUG - 2020-10-05 17:41:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:41:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:41:18 --> Model Class Initialized
INFO - 2020-10-05 17:41:18 --> Model Class Initialized
INFO - 2020-10-05 17:41:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:41:18 --> Final output sent to browser
DEBUG - 2020-10-05 17:41:18 --> Total execution time: 0.0215
ERROR - 2020-10-05 17:41:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:41:26 --> Config Class Initialized
INFO - 2020-10-05 17:41:26 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:41:26 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:41:26 --> Utf8 Class Initialized
INFO - 2020-10-05 17:41:26 --> URI Class Initialized
INFO - 2020-10-05 17:41:26 --> Router Class Initialized
INFO - 2020-10-05 17:41:26 --> Output Class Initialized
INFO - 2020-10-05 17:41:26 --> Security Class Initialized
DEBUG - 2020-10-05 17:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:41:26 --> Input Class Initialized
INFO - 2020-10-05 17:41:26 --> Language Class Initialized
INFO - 2020-10-05 17:41:26 --> Loader Class Initialized
INFO - 2020-10-05 17:41:26 --> Helper loaded: url_helper
INFO - 2020-10-05 17:41:26 --> Database Driver Class Initialized
INFO - 2020-10-05 17:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:41:26 --> Email Class Initialized
INFO - 2020-10-05 17:41:26 --> Controller Class Initialized
DEBUG - 2020-10-05 17:41:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:41:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:41:26 --> Model Class Initialized
INFO - 2020-10-05 17:41:26 --> Model Class Initialized
INFO - 2020-10-05 17:41:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:41:26 --> Final output sent to browser
DEBUG - 2020-10-05 17:41:26 --> Total execution time: 0.0206
ERROR - 2020-10-05 17:42:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:42:02 --> Config Class Initialized
INFO - 2020-10-05 17:42:02 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:42:02 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:42:02 --> Utf8 Class Initialized
INFO - 2020-10-05 17:42:02 --> URI Class Initialized
INFO - 2020-10-05 17:42:02 --> Router Class Initialized
INFO - 2020-10-05 17:42:02 --> Output Class Initialized
INFO - 2020-10-05 17:42:02 --> Security Class Initialized
DEBUG - 2020-10-05 17:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:42:02 --> Input Class Initialized
INFO - 2020-10-05 17:42:02 --> Language Class Initialized
INFO - 2020-10-05 17:42:02 --> Loader Class Initialized
INFO - 2020-10-05 17:42:02 --> Helper loaded: url_helper
INFO - 2020-10-05 17:42:02 --> Database Driver Class Initialized
INFO - 2020-10-05 17:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:42:02 --> Email Class Initialized
INFO - 2020-10-05 17:42:02 --> Controller Class Initialized
DEBUG - 2020-10-05 17:42:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:42:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:42:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-05 17:42:02 --> Final output sent to browser
DEBUG - 2020-10-05 17:42:02 --> Total execution time: 0.0206
ERROR - 2020-10-05 17:42:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:42:17 --> Config Class Initialized
INFO - 2020-10-05 17:42:17 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:42:17 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:42:17 --> Utf8 Class Initialized
INFO - 2020-10-05 17:42:17 --> URI Class Initialized
INFO - 2020-10-05 17:42:17 --> Router Class Initialized
INFO - 2020-10-05 17:42:17 --> Output Class Initialized
INFO - 2020-10-05 17:42:17 --> Security Class Initialized
DEBUG - 2020-10-05 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:42:17 --> Input Class Initialized
INFO - 2020-10-05 17:42:17 --> Language Class Initialized
INFO - 2020-10-05 17:42:17 --> Loader Class Initialized
INFO - 2020-10-05 17:42:17 --> Helper loaded: url_helper
INFO - 2020-10-05 17:42:17 --> Database Driver Class Initialized
INFO - 2020-10-05 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:42:17 --> Email Class Initialized
INFO - 2020-10-05 17:42:17 --> Controller Class Initialized
DEBUG - 2020-10-05 17:42:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:42:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:42:17 --> Model Class Initialized
INFO - 2020-10-05 17:42:17 --> Model Class Initialized
INFO - 2020-10-05 17:42:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:42:17 --> Final output sent to browser
DEBUG - 2020-10-05 17:42:17 --> Total execution time: 0.0213
ERROR - 2020-10-05 17:42:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:42:22 --> Config Class Initialized
INFO - 2020-10-05 17:42:22 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:42:22 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:42:22 --> Utf8 Class Initialized
INFO - 2020-10-05 17:42:22 --> URI Class Initialized
INFO - 2020-10-05 17:42:22 --> Router Class Initialized
INFO - 2020-10-05 17:42:22 --> Output Class Initialized
INFO - 2020-10-05 17:42:22 --> Security Class Initialized
DEBUG - 2020-10-05 17:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:42:22 --> Input Class Initialized
INFO - 2020-10-05 17:42:22 --> Language Class Initialized
INFO - 2020-10-05 17:42:22 --> Loader Class Initialized
INFO - 2020-10-05 17:42:22 --> Helper loaded: url_helper
INFO - 2020-10-05 17:42:22 --> Database Driver Class Initialized
INFO - 2020-10-05 17:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:42:22 --> Email Class Initialized
INFO - 2020-10-05 17:42:22 --> Controller Class Initialized
DEBUG - 2020-10-05 17:42:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:42:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:42:22 --> Model Class Initialized
INFO - 2020-10-05 17:42:22 --> Model Class Initialized
INFO - 2020-10-05 17:42:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-05 17:42:22 --> Final output sent to browser
DEBUG - 2020-10-05 17:42:22 --> Total execution time: 0.0246
ERROR - 2020-10-05 17:42:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:42:35 --> Config Class Initialized
INFO - 2020-10-05 17:42:35 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:42:35 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:42:35 --> Utf8 Class Initialized
INFO - 2020-10-05 17:42:35 --> URI Class Initialized
INFO - 2020-10-05 17:42:35 --> Router Class Initialized
INFO - 2020-10-05 17:42:35 --> Output Class Initialized
INFO - 2020-10-05 17:42:35 --> Security Class Initialized
DEBUG - 2020-10-05 17:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:42:35 --> Input Class Initialized
INFO - 2020-10-05 17:42:35 --> Language Class Initialized
INFO - 2020-10-05 17:42:35 --> Loader Class Initialized
INFO - 2020-10-05 17:42:35 --> Helper loaded: url_helper
INFO - 2020-10-05 17:42:35 --> Database Driver Class Initialized
INFO - 2020-10-05 17:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:42:35 --> Email Class Initialized
INFO - 2020-10-05 17:42:35 --> Controller Class Initialized
DEBUG - 2020-10-05 17:42:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:42:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:42:35 --> Model Class Initialized
INFO - 2020-10-05 17:42:35 --> Model Class Initialized
INFO - 2020-10-05 17:42:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:42:35 --> Final output sent to browser
DEBUG - 2020-10-05 17:42:35 --> Total execution time: 0.0230
ERROR - 2020-10-05 17:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:45:19 --> Config Class Initialized
INFO - 2020-10-05 17:45:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:45:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:45:19 --> Utf8 Class Initialized
INFO - 2020-10-05 17:45:19 --> URI Class Initialized
INFO - 2020-10-05 17:45:19 --> Router Class Initialized
INFO - 2020-10-05 17:45:19 --> Output Class Initialized
INFO - 2020-10-05 17:45:19 --> Security Class Initialized
DEBUG - 2020-10-05 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:45:19 --> Input Class Initialized
INFO - 2020-10-05 17:45:19 --> Language Class Initialized
INFO - 2020-10-05 17:45:19 --> Loader Class Initialized
INFO - 2020-10-05 17:45:19 --> Helper loaded: url_helper
INFO - 2020-10-05 17:45:19 --> Database Driver Class Initialized
INFO - 2020-10-05 17:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:45:19 --> Email Class Initialized
INFO - 2020-10-05 17:45:19 --> Controller Class Initialized
DEBUG - 2020-10-05 17:45:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:45:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:45:19 --> Model Class Initialized
INFO - 2020-10-05 17:45:19 --> Model Class Initialized
INFO - 2020-10-05 17:45:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-10-05 17:45:19 --> Final output sent to browser
DEBUG - 2020-10-05 17:45:19 --> Total execution time: 0.0247
ERROR - 2020-10-05 17:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:45:19 --> Config Class Initialized
INFO - 2020-10-05 17:45:19 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:45:19 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:45:19 --> Utf8 Class Initialized
INFO - 2020-10-05 17:45:19 --> URI Class Initialized
INFO - 2020-10-05 17:45:19 --> Router Class Initialized
INFO - 2020-10-05 17:45:19 --> Output Class Initialized
INFO - 2020-10-05 17:45:19 --> Security Class Initialized
DEBUG - 2020-10-05 17:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:45:19 --> Input Class Initialized
INFO - 2020-10-05 17:45:19 --> Language Class Initialized
ERROR - 2020-10-05 17:45:19 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-10-05 17:45:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:45:30 --> Config Class Initialized
INFO - 2020-10-05 17:45:30 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:45:30 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:45:30 --> Utf8 Class Initialized
INFO - 2020-10-05 17:45:30 --> URI Class Initialized
INFO - 2020-10-05 17:45:30 --> Router Class Initialized
INFO - 2020-10-05 17:45:30 --> Output Class Initialized
INFO - 2020-10-05 17:45:30 --> Security Class Initialized
DEBUG - 2020-10-05 17:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:45:30 --> Input Class Initialized
INFO - 2020-10-05 17:45:30 --> Language Class Initialized
INFO - 2020-10-05 17:45:30 --> Loader Class Initialized
INFO - 2020-10-05 17:45:30 --> Helper loaded: url_helper
INFO - 2020-10-05 17:45:30 --> Database Driver Class Initialized
INFO - 2020-10-05 17:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:45:30 --> Email Class Initialized
INFO - 2020-10-05 17:45:30 --> Controller Class Initialized
DEBUG - 2020-10-05 17:45:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-05 17:45:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:45:30 --> Model Class Initialized
INFO - 2020-10-05 17:45:30 --> Model Class Initialized
INFO - 2020-10-05 17:45:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-05 17:45:30 --> Final output sent to browser
DEBUG - 2020-10-05 17:45:30 --> Total execution time: 0.0204
ERROR - 2020-10-05 17:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-05 17:45:41 --> Config Class Initialized
INFO - 2020-10-05 17:45:41 --> Hooks Class Initialized
DEBUG - 2020-10-05 17:45:41 --> UTF-8 Support Enabled
INFO - 2020-10-05 17:45:41 --> Utf8 Class Initialized
INFO - 2020-10-05 17:45:41 --> URI Class Initialized
DEBUG - 2020-10-05 17:45:41 --> No URI present. Default controller set.
INFO - 2020-10-05 17:45:41 --> Router Class Initialized
INFO - 2020-10-05 17:45:41 --> Output Class Initialized
INFO - 2020-10-05 17:45:41 --> Security Class Initialized
DEBUG - 2020-10-05 17:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-05 17:45:41 --> Input Class Initialized
INFO - 2020-10-05 17:45:41 --> Language Class Initialized
INFO - 2020-10-05 17:45:41 --> Loader Class Initialized
INFO - 2020-10-05 17:45:41 --> Helper loaded: url_helper
INFO - 2020-10-05 17:45:41 --> Database Driver Class Initialized
INFO - 2020-10-05 17:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-05 17:45:41 --> Email Class Initialized
INFO - 2020-10-05 17:45:41 --> Controller Class Initialized
INFO - 2020-10-05 17:45:41 --> Model Class Initialized
INFO - 2020-10-05 17:45:41 --> Model Class Initialized
DEBUG - 2020-10-05 17:45:41 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-05 17:45:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-05 17:45:41 --> Final output sent to browser
DEBUG - 2020-10-05 17:45:41 --> Total execution time: 0.0173
