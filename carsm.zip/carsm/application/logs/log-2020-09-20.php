<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-20 14:30:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:30:10 --> Config Class Initialized
INFO - 2020-09-20 14:30:10 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:30:10 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:30:10 --> Utf8 Class Initialized
INFO - 2020-09-20 14:30:10 --> URI Class Initialized
DEBUG - 2020-09-20 14:30:10 --> No URI present. Default controller set.
INFO - 2020-09-20 14:30:10 --> Router Class Initialized
INFO - 2020-09-20 14:30:10 --> Output Class Initialized
INFO - 2020-09-20 14:30:10 --> Security Class Initialized
DEBUG - 2020-09-20 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:30:10 --> Input Class Initialized
INFO - 2020-09-20 14:30:10 --> Language Class Initialized
INFO - 2020-09-20 14:30:10 --> Loader Class Initialized
INFO - 2020-09-20 14:30:10 --> Helper loaded: url_helper
INFO - 2020-09-20 14:30:10 --> Database Driver Class Initialized
INFO - 2020-09-20 14:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:30:10 --> Email Class Initialized
INFO - 2020-09-20 14:30:10 --> Controller Class Initialized
INFO - 2020-09-20 14:30:10 --> Model Class Initialized
INFO - 2020-09-20 14:30:10 --> Model Class Initialized
DEBUG - 2020-09-20 14:30:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:30:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-20 14:30:10 --> Final output sent to browser
DEBUG - 2020-09-20 14:30:10 --> Total execution time: 0.1239
ERROR - 2020-09-20 14:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:30:27 --> Config Class Initialized
INFO - 2020-09-20 14:30:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:30:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:30:27 --> Utf8 Class Initialized
INFO - 2020-09-20 14:30:27 --> URI Class Initialized
INFO - 2020-09-20 14:30:27 --> Router Class Initialized
INFO - 2020-09-20 14:30:27 --> Output Class Initialized
INFO - 2020-09-20 14:30:27 --> Security Class Initialized
DEBUG - 2020-09-20 14:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:30:27 --> Input Class Initialized
INFO - 2020-09-20 14:30:27 --> Language Class Initialized
INFO - 2020-09-20 14:30:28 --> Loader Class Initialized
INFO - 2020-09-20 14:30:28 --> Helper loaded: url_helper
INFO - 2020-09-20 14:30:28 --> Database Driver Class Initialized
INFO - 2020-09-20 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:30:28 --> Email Class Initialized
INFO - 2020-09-20 14:30:28 --> Controller Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:30:28 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-20 14:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:30:28 --> Config Class Initialized
INFO - 2020-09-20 14:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:30:28 --> Utf8 Class Initialized
INFO - 2020-09-20 14:30:28 --> URI Class Initialized
INFO - 2020-09-20 14:30:28 --> Router Class Initialized
INFO - 2020-09-20 14:30:28 --> Output Class Initialized
INFO - 2020-09-20 14:30:28 --> Security Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:30:28 --> Input Class Initialized
INFO - 2020-09-20 14:30:28 --> Language Class Initialized
INFO - 2020-09-20 14:30:28 --> Loader Class Initialized
INFO - 2020-09-20 14:30:28 --> Helper loaded: url_helper
INFO - 2020-09-20 14:30:28 --> Database Driver Class Initialized
INFO - 2020-09-20 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:30:28 --> Email Class Initialized
INFO - 2020-09-20 14:30:28 --> Controller Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-20 14:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:30:28 --> Config Class Initialized
INFO - 2020-09-20 14:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:30:28 --> Utf8 Class Initialized
INFO - 2020-09-20 14:30:28 --> URI Class Initialized
DEBUG - 2020-09-20 14:30:28 --> No URI present. Default controller set.
INFO - 2020-09-20 14:30:28 --> Router Class Initialized
INFO - 2020-09-20 14:30:28 --> Output Class Initialized
INFO - 2020-09-20 14:30:28 --> Security Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:30:28 --> Input Class Initialized
INFO - 2020-09-20 14:30:28 --> Language Class Initialized
INFO - 2020-09-20 14:30:28 --> Loader Class Initialized
INFO - 2020-09-20 14:30:28 --> Helper loaded: url_helper
INFO - 2020-09-20 14:30:28 --> Database Driver Class Initialized
INFO - 2020-09-20 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:30:28 --> Email Class Initialized
INFO - 2020-09-20 14:30:28 --> Controller Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:30:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-20 14:30:28 --> Final output sent to browser
DEBUG - 2020-09-20 14:30:28 --> Total execution time: 0.0206
ERROR - 2020-09-20 14:30:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:30:28 --> Config Class Initialized
INFO - 2020-09-20 14:30:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:30:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:30:28 --> Utf8 Class Initialized
INFO - 2020-09-20 14:30:28 --> URI Class Initialized
INFO - 2020-09-20 14:30:28 --> Router Class Initialized
INFO - 2020-09-20 14:30:28 --> Output Class Initialized
INFO - 2020-09-20 14:30:28 --> Security Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:30:28 --> Input Class Initialized
INFO - 2020-09-20 14:30:28 --> Language Class Initialized
INFO - 2020-09-20 14:30:28 --> Loader Class Initialized
INFO - 2020-09-20 14:30:28 --> Helper loaded: url_helper
INFO - 2020-09-20 14:30:28 --> Database Driver Class Initialized
INFO - 2020-09-20 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:30:28 --> Email Class Initialized
INFO - 2020-09-20 14:30:28 --> Controller Class Initialized
DEBUG - 2020-09-20 14:30:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:30:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
INFO - 2020-09-20 14:30:28 --> Model Class Initialized
INFO - 2020-09-20 14:30:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:30:28 --> Final output sent to browser
DEBUG - 2020-09-20 14:30:28 --> Total execution time: 0.0514
ERROR - 2020-09-20 14:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:30:38 --> Config Class Initialized
INFO - 2020-09-20 14:30:38 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:30:38 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:30:38 --> Utf8 Class Initialized
INFO - 2020-09-20 14:30:38 --> URI Class Initialized
INFO - 2020-09-20 14:30:38 --> Router Class Initialized
INFO - 2020-09-20 14:30:38 --> Output Class Initialized
INFO - 2020-09-20 14:30:38 --> Security Class Initialized
DEBUG - 2020-09-20 14:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:30:38 --> Input Class Initialized
INFO - 2020-09-20 14:30:38 --> Language Class Initialized
INFO - 2020-09-20 14:30:38 --> Loader Class Initialized
INFO - 2020-09-20 14:30:38 --> Helper loaded: url_helper
INFO - 2020-09-20 14:30:38 --> Database Driver Class Initialized
INFO - 2020-09-20 14:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:30:38 --> Email Class Initialized
INFO - 2020-09-20 14:30:38 --> Controller Class Initialized
DEBUG - 2020-09-20 14:30:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:30:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:30:38 --> Model Class Initialized
INFO - 2020-09-20 14:30:38 --> Model Class Initialized
INFO - 2020-09-20 14:30:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:30:38 --> Final output sent to browser
DEBUG - 2020-09-20 14:30:38 --> Total execution time: 0.0408
ERROR - 2020-09-20 14:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:31:47 --> Config Class Initialized
INFO - 2020-09-20 14:31:47 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:31:47 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:31:47 --> Utf8 Class Initialized
INFO - 2020-09-20 14:31:47 --> URI Class Initialized
INFO - 2020-09-20 14:31:47 --> Router Class Initialized
INFO - 2020-09-20 14:31:47 --> Output Class Initialized
INFO - 2020-09-20 14:31:47 --> Security Class Initialized
DEBUG - 2020-09-20 14:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:31:47 --> Input Class Initialized
INFO - 2020-09-20 14:31:47 --> Language Class Initialized
INFO - 2020-09-20 14:31:47 --> Loader Class Initialized
INFO - 2020-09-20 14:31:47 --> Helper loaded: url_helper
INFO - 2020-09-20 14:31:47 --> Database Driver Class Initialized
INFO - 2020-09-20 14:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:31:47 --> Email Class Initialized
INFO - 2020-09-20 14:31:47 --> Controller Class Initialized
DEBUG - 2020-09-20 14:31:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:31:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:31:47 --> Model Class Initialized
INFO - 2020-09-20 14:31:47 --> Model Class Initialized
INFO - 2020-09-20 14:31:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:31:47 --> Final output sent to browser
DEBUG - 2020-09-20 14:31:47 --> Total execution time: 0.0214
ERROR - 2020-09-20 14:35:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:35:45 --> Config Class Initialized
INFO - 2020-09-20 14:35:45 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:35:45 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:35:45 --> Utf8 Class Initialized
INFO - 2020-09-20 14:35:45 --> URI Class Initialized
INFO - 2020-09-20 14:35:45 --> Router Class Initialized
INFO - 2020-09-20 14:35:45 --> Output Class Initialized
INFO - 2020-09-20 14:35:45 --> Security Class Initialized
DEBUG - 2020-09-20 14:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:35:45 --> Input Class Initialized
INFO - 2020-09-20 14:35:45 --> Language Class Initialized
INFO - 2020-09-20 14:35:45 --> Loader Class Initialized
INFO - 2020-09-20 14:35:45 --> Helper loaded: url_helper
INFO - 2020-09-20 14:35:45 --> Database Driver Class Initialized
INFO - 2020-09-20 14:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:35:45 --> Email Class Initialized
INFO - 2020-09-20 14:35:45 --> Controller Class Initialized
DEBUG - 2020-09-20 14:35:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:35:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:35:45 --> Model Class Initialized
INFO - 2020-09-20 14:35:45 --> Model Class Initialized
INFO - 2020-09-20 14:35:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:35:45 --> Final output sent to browser
DEBUG - 2020-09-20 14:35:45 --> Total execution time: 0.0246
ERROR - 2020-09-20 14:36:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:36:45 --> Config Class Initialized
INFO - 2020-09-20 14:36:45 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:36:45 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:36:45 --> Utf8 Class Initialized
INFO - 2020-09-20 14:36:45 --> URI Class Initialized
INFO - 2020-09-20 14:36:45 --> Router Class Initialized
INFO - 2020-09-20 14:36:45 --> Output Class Initialized
INFO - 2020-09-20 14:36:45 --> Security Class Initialized
DEBUG - 2020-09-20 14:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:36:45 --> Input Class Initialized
INFO - 2020-09-20 14:36:45 --> Language Class Initialized
INFO - 2020-09-20 14:36:45 --> Loader Class Initialized
INFO - 2020-09-20 14:36:45 --> Helper loaded: url_helper
INFO - 2020-09-20 14:36:45 --> Database Driver Class Initialized
INFO - 2020-09-20 14:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:36:45 --> Email Class Initialized
INFO - 2020-09-20 14:36:45 --> Controller Class Initialized
DEBUG - 2020-09-20 14:36:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:36:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:36:45 --> Model Class Initialized
INFO - 2020-09-20 14:36:45 --> Model Class Initialized
INFO - 2020-09-20 14:36:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:36:45 --> Final output sent to browser
DEBUG - 2020-09-20 14:36:45 --> Total execution time: 0.0262
ERROR - 2020-09-20 14:36:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:36:52 --> Config Class Initialized
INFO - 2020-09-20 14:36:52 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:36:52 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:36:52 --> Utf8 Class Initialized
INFO - 2020-09-20 14:36:52 --> URI Class Initialized
INFO - 2020-09-20 14:36:52 --> Router Class Initialized
INFO - 2020-09-20 14:36:52 --> Output Class Initialized
INFO - 2020-09-20 14:36:52 --> Security Class Initialized
DEBUG - 2020-09-20 14:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:36:52 --> Input Class Initialized
INFO - 2020-09-20 14:36:52 --> Language Class Initialized
INFO - 2020-09-20 14:36:52 --> Loader Class Initialized
INFO - 2020-09-20 14:36:52 --> Helper loaded: url_helper
INFO - 2020-09-20 14:36:52 --> Database Driver Class Initialized
INFO - 2020-09-20 14:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:36:52 --> Email Class Initialized
INFO - 2020-09-20 14:36:52 --> Controller Class Initialized
DEBUG - 2020-09-20 14:36:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:36:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:36:52 --> Model Class Initialized
INFO - 2020-09-20 14:36:52 --> Model Class Initialized
INFO - 2020-09-20 14:36:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:36:52 --> Final output sent to browser
DEBUG - 2020-09-20 14:36:52 --> Total execution time: 0.0196
ERROR - 2020-09-20 14:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:40:10 --> Config Class Initialized
INFO - 2020-09-20 14:40:10 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:40:10 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:40:10 --> Utf8 Class Initialized
INFO - 2020-09-20 14:40:10 --> URI Class Initialized
INFO - 2020-09-20 14:40:10 --> Router Class Initialized
INFO - 2020-09-20 14:40:10 --> Output Class Initialized
INFO - 2020-09-20 14:40:10 --> Security Class Initialized
DEBUG - 2020-09-20 14:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:40:10 --> Input Class Initialized
INFO - 2020-09-20 14:40:10 --> Language Class Initialized
INFO - 2020-09-20 14:40:10 --> Loader Class Initialized
INFO - 2020-09-20 14:40:10 --> Helper loaded: url_helper
INFO - 2020-09-20 14:40:10 --> Database Driver Class Initialized
INFO - 2020-09-20 14:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:40:10 --> Email Class Initialized
INFO - 2020-09-20 14:40:10 --> Controller Class Initialized
DEBUG - 2020-09-20 14:40:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:40:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:40:10 --> Model Class Initialized
INFO - 2020-09-20 14:40:10 --> Model Class Initialized
INFO - 2020-09-20 14:40:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:40:10 --> Final output sent to browser
DEBUG - 2020-09-20 14:40:10 --> Total execution time: 0.0253
ERROR - 2020-09-20 14:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:40:56 --> Config Class Initialized
INFO - 2020-09-20 14:40:56 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:40:56 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:40:56 --> Utf8 Class Initialized
INFO - 2020-09-20 14:40:56 --> URI Class Initialized
INFO - 2020-09-20 14:40:56 --> Router Class Initialized
INFO - 2020-09-20 14:40:56 --> Output Class Initialized
INFO - 2020-09-20 14:40:56 --> Security Class Initialized
DEBUG - 2020-09-20 14:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:40:56 --> Input Class Initialized
INFO - 2020-09-20 14:40:56 --> Language Class Initialized
INFO - 2020-09-20 14:40:56 --> Loader Class Initialized
INFO - 2020-09-20 14:40:56 --> Helper loaded: url_helper
INFO - 2020-09-20 14:40:56 --> Database Driver Class Initialized
INFO - 2020-09-20 14:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:40:56 --> Email Class Initialized
INFO - 2020-09-20 14:40:56 --> Controller Class Initialized
DEBUG - 2020-09-20 14:40:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:40:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:40:56 --> Model Class Initialized
INFO - 2020-09-20 14:40:56 --> Model Class Initialized
INFO - 2020-09-20 14:40:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:40:56 --> Final output sent to browser
DEBUG - 2020-09-20 14:40:56 --> Total execution time: 0.0311
ERROR - 2020-09-20 14:40:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:40:59 --> Config Class Initialized
INFO - 2020-09-20 14:40:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:40:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:40:59 --> Utf8 Class Initialized
INFO - 2020-09-20 14:40:59 --> URI Class Initialized
INFO - 2020-09-20 14:40:59 --> Router Class Initialized
INFO - 2020-09-20 14:40:59 --> Output Class Initialized
INFO - 2020-09-20 14:40:59 --> Security Class Initialized
DEBUG - 2020-09-20 14:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:40:59 --> Input Class Initialized
INFO - 2020-09-20 14:40:59 --> Language Class Initialized
INFO - 2020-09-20 14:40:59 --> Loader Class Initialized
INFO - 2020-09-20 14:40:59 --> Helper loaded: url_helper
INFO - 2020-09-20 14:40:59 --> Database Driver Class Initialized
INFO - 2020-09-20 14:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:40:59 --> Email Class Initialized
INFO - 2020-09-20 14:40:59 --> Controller Class Initialized
DEBUG - 2020-09-20 14:40:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:40:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:40:59 --> Model Class Initialized
INFO - 2020-09-20 14:40:59 --> Model Class Initialized
INFO - 2020-09-20 14:40:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:40:59 --> Final output sent to browser
DEBUG - 2020-09-20 14:40:59 --> Total execution time: 0.0267
ERROR - 2020-09-20 14:42:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:42:23 --> Config Class Initialized
INFO - 2020-09-20 14:42:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:42:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:42:23 --> Utf8 Class Initialized
INFO - 2020-09-20 14:42:23 --> URI Class Initialized
INFO - 2020-09-20 14:42:23 --> Router Class Initialized
INFO - 2020-09-20 14:42:23 --> Output Class Initialized
INFO - 2020-09-20 14:42:23 --> Security Class Initialized
DEBUG - 2020-09-20 14:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:42:23 --> Input Class Initialized
INFO - 2020-09-20 14:42:23 --> Language Class Initialized
INFO - 2020-09-20 14:42:23 --> Loader Class Initialized
INFO - 2020-09-20 14:42:23 --> Helper loaded: url_helper
INFO - 2020-09-20 14:42:23 --> Database Driver Class Initialized
INFO - 2020-09-20 14:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:42:23 --> Email Class Initialized
INFO - 2020-09-20 14:42:23 --> Controller Class Initialized
DEBUG - 2020-09-20 14:42:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:42:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:42:23 --> Model Class Initialized
INFO - 2020-09-20 14:42:23 --> Model Class Initialized
INFO - 2020-09-20 14:42:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:42:23 --> Final output sent to browser
DEBUG - 2020-09-20 14:42:23 --> Total execution time: 0.0225
ERROR - 2020-09-20 14:43:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:43:34 --> Config Class Initialized
INFO - 2020-09-20 14:43:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:43:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:43:34 --> Utf8 Class Initialized
INFO - 2020-09-20 14:43:34 --> URI Class Initialized
INFO - 2020-09-20 14:43:34 --> Router Class Initialized
INFO - 2020-09-20 14:43:34 --> Output Class Initialized
INFO - 2020-09-20 14:43:34 --> Security Class Initialized
DEBUG - 2020-09-20 14:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:43:34 --> Input Class Initialized
INFO - 2020-09-20 14:43:34 --> Language Class Initialized
INFO - 2020-09-20 14:43:34 --> Loader Class Initialized
INFO - 2020-09-20 14:43:34 --> Helper loaded: url_helper
INFO - 2020-09-20 14:43:34 --> Database Driver Class Initialized
INFO - 2020-09-20 14:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:43:34 --> Email Class Initialized
INFO - 2020-09-20 14:43:34 --> Controller Class Initialized
DEBUG - 2020-09-20 14:43:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:43:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:43:34 --> Model Class Initialized
INFO - 2020-09-20 14:43:34 --> Model Class Initialized
INFO - 2020-09-20 14:43:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:43:34 --> Final output sent to browser
DEBUG - 2020-09-20 14:43:34 --> Total execution time: 0.0243
ERROR - 2020-09-20 14:44:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:44:22 --> Config Class Initialized
INFO - 2020-09-20 14:44:22 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:44:22 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:44:22 --> Utf8 Class Initialized
INFO - 2020-09-20 14:44:22 --> URI Class Initialized
INFO - 2020-09-20 14:44:22 --> Router Class Initialized
INFO - 2020-09-20 14:44:22 --> Output Class Initialized
INFO - 2020-09-20 14:44:22 --> Security Class Initialized
DEBUG - 2020-09-20 14:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:44:22 --> Input Class Initialized
INFO - 2020-09-20 14:44:22 --> Language Class Initialized
INFO - 2020-09-20 14:44:22 --> Loader Class Initialized
INFO - 2020-09-20 14:44:22 --> Helper loaded: url_helper
INFO - 2020-09-20 14:44:22 --> Database Driver Class Initialized
INFO - 2020-09-20 14:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:44:22 --> Email Class Initialized
INFO - 2020-09-20 14:44:22 --> Controller Class Initialized
DEBUG - 2020-09-20 14:44:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:44:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:44:22 --> Model Class Initialized
INFO - 2020-09-20 14:44:22 --> Model Class Initialized
INFO - 2020-09-20 14:44:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:44:22 --> Final output sent to browser
DEBUG - 2020-09-20 14:44:22 --> Total execution time: 0.0246
ERROR - 2020-09-20 14:44:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:44:28 --> Config Class Initialized
INFO - 2020-09-20 14:44:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:44:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:44:28 --> Utf8 Class Initialized
INFO - 2020-09-20 14:44:28 --> URI Class Initialized
INFO - 2020-09-20 14:44:28 --> Router Class Initialized
INFO - 2020-09-20 14:44:28 --> Output Class Initialized
INFO - 2020-09-20 14:44:28 --> Security Class Initialized
DEBUG - 2020-09-20 14:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:44:28 --> Input Class Initialized
INFO - 2020-09-20 14:44:28 --> Language Class Initialized
INFO - 2020-09-20 14:44:28 --> Loader Class Initialized
INFO - 2020-09-20 14:44:28 --> Helper loaded: url_helper
INFO - 2020-09-20 14:44:28 --> Database Driver Class Initialized
INFO - 2020-09-20 14:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:44:28 --> Email Class Initialized
INFO - 2020-09-20 14:44:28 --> Controller Class Initialized
DEBUG - 2020-09-20 14:44:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:44:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:44:28 --> Model Class Initialized
INFO - 2020-09-20 14:44:28 --> Model Class Initialized
INFO - 2020-09-20 14:44:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:44:28 --> Final output sent to browser
DEBUG - 2020-09-20 14:44:28 --> Total execution time: 0.0284
ERROR - 2020-09-20 14:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:44:32 --> Config Class Initialized
INFO - 2020-09-20 14:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:44:32 --> Utf8 Class Initialized
INFO - 2020-09-20 14:44:32 --> URI Class Initialized
INFO - 2020-09-20 14:44:32 --> Router Class Initialized
INFO - 2020-09-20 14:44:32 --> Output Class Initialized
INFO - 2020-09-20 14:44:32 --> Security Class Initialized
DEBUG - 2020-09-20 14:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:44:32 --> Input Class Initialized
INFO - 2020-09-20 14:44:32 --> Language Class Initialized
INFO - 2020-09-20 14:44:32 --> Loader Class Initialized
INFO - 2020-09-20 14:44:32 --> Helper loaded: url_helper
INFO - 2020-09-20 14:44:32 --> Database Driver Class Initialized
INFO - 2020-09-20 14:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:44:32 --> Email Class Initialized
INFO - 2020-09-20 14:44:32 --> Controller Class Initialized
DEBUG - 2020-09-20 14:44:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:44:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:44:32 --> Model Class Initialized
INFO - 2020-09-20 14:44:32 --> Model Class Initialized
INFO - 2020-09-20 14:44:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:44:32 --> Final output sent to browser
DEBUG - 2020-09-20 14:44:32 --> Total execution time: 0.0264
ERROR - 2020-09-20 14:45:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:45:26 --> Config Class Initialized
INFO - 2020-09-20 14:45:26 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:45:26 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:45:26 --> Utf8 Class Initialized
INFO - 2020-09-20 14:45:26 --> URI Class Initialized
INFO - 2020-09-20 14:45:26 --> Router Class Initialized
INFO - 2020-09-20 14:45:26 --> Output Class Initialized
INFO - 2020-09-20 14:45:26 --> Security Class Initialized
DEBUG - 2020-09-20 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:45:26 --> Input Class Initialized
INFO - 2020-09-20 14:45:26 --> Language Class Initialized
INFO - 2020-09-20 14:45:27 --> Loader Class Initialized
INFO - 2020-09-20 14:45:27 --> Helper loaded: url_helper
INFO - 2020-09-20 14:45:27 --> Database Driver Class Initialized
INFO - 2020-09-20 14:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:45:27 --> Email Class Initialized
INFO - 2020-09-20 14:45:27 --> Controller Class Initialized
DEBUG - 2020-09-20 14:45:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:45:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:45:27 --> Model Class Initialized
INFO - 2020-09-20 14:45:27 --> Model Class Initialized
INFO - 2020-09-20 14:45:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:45:27 --> Final output sent to browser
DEBUG - 2020-09-20 14:45:27 --> Total execution time: 0.0262
ERROR - 2020-09-20 14:45:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:45:41 --> Config Class Initialized
INFO - 2020-09-20 14:45:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:45:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:45:41 --> Utf8 Class Initialized
INFO - 2020-09-20 14:45:41 --> URI Class Initialized
INFO - 2020-09-20 14:45:41 --> Router Class Initialized
INFO - 2020-09-20 14:45:41 --> Output Class Initialized
INFO - 2020-09-20 14:45:41 --> Security Class Initialized
DEBUG - 2020-09-20 14:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:45:41 --> Input Class Initialized
INFO - 2020-09-20 14:45:41 --> Language Class Initialized
INFO - 2020-09-20 14:45:41 --> Loader Class Initialized
INFO - 2020-09-20 14:45:41 --> Helper loaded: url_helper
INFO - 2020-09-20 14:45:41 --> Database Driver Class Initialized
INFO - 2020-09-20 14:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:45:41 --> Email Class Initialized
INFO - 2020-09-20 14:45:41 --> Controller Class Initialized
DEBUG - 2020-09-20 14:45:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:45:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:45:41 --> Model Class Initialized
INFO - 2020-09-20 14:45:41 --> Model Class Initialized
INFO - 2020-09-20 14:45:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:45:41 --> Final output sent to browser
DEBUG - 2020-09-20 14:45:41 --> Total execution time: 0.0203
ERROR - 2020-09-20 14:46:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:46:37 --> Config Class Initialized
INFO - 2020-09-20 14:46:37 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:46:37 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:46:37 --> Utf8 Class Initialized
INFO - 2020-09-20 14:46:37 --> URI Class Initialized
INFO - 2020-09-20 14:46:37 --> Router Class Initialized
INFO - 2020-09-20 14:46:37 --> Output Class Initialized
INFO - 2020-09-20 14:46:37 --> Security Class Initialized
DEBUG - 2020-09-20 14:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:46:37 --> Input Class Initialized
INFO - 2020-09-20 14:46:37 --> Language Class Initialized
INFO - 2020-09-20 14:46:37 --> Loader Class Initialized
INFO - 2020-09-20 14:46:37 --> Helper loaded: url_helper
INFO - 2020-09-20 14:46:37 --> Database Driver Class Initialized
INFO - 2020-09-20 14:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:46:37 --> Email Class Initialized
INFO - 2020-09-20 14:46:37 --> Controller Class Initialized
DEBUG - 2020-09-20 14:46:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:46:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:46:37 --> Model Class Initialized
INFO - 2020-09-20 14:46:37 --> Model Class Initialized
INFO - 2020-09-20 14:46:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:46:37 --> Final output sent to browser
DEBUG - 2020-09-20 14:46:37 --> Total execution time: 0.0237
ERROR - 2020-09-20 14:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:03 --> Config Class Initialized
INFO - 2020-09-20 14:49:03 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:03 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:03 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:03 --> URI Class Initialized
INFO - 2020-09-20 14:49:03 --> Router Class Initialized
INFO - 2020-09-20 14:49:03 --> Output Class Initialized
INFO - 2020-09-20 14:49:03 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:03 --> Input Class Initialized
INFO - 2020-09-20 14:49:03 --> Language Class Initialized
INFO - 2020-09-20 14:49:03 --> Loader Class Initialized
INFO - 2020-09-20 14:49:03 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:03 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:03 --> Email Class Initialized
INFO - 2020-09-20 14:49:03 --> Controller Class Initialized
DEBUG - 2020-09-20 14:49:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:49:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:03 --> Model Class Initialized
INFO - 2020-09-20 14:49:03 --> Model Class Initialized
INFO - 2020-09-20 14:49:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:49:03 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:03 --> Total execution time: 0.0231
ERROR - 2020-09-20 14:49:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:10 --> Config Class Initialized
INFO - 2020-09-20 14:49:10 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:10 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:10 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:10 --> URI Class Initialized
DEBUG - 2020-09-20 14:49:10 --> No URI present. Default controller set.
INFO - 2020-09-20 14:49:10 --> Router Class Initialized
INFO - 2020-09-20 14:49:10 --> Output Class Initialized
INFO - 2020-09-20 14:49:10 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:10 --> Input Class Initialized
INFO - 2020-09-20 14:49:10 --> Language Class Initialized
INFO - 2020-09-20 14:49:10 --> Loader Class Initialized
INFO - 2020-09-20 14:49:10 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:10 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:10 --> Email Class Initialized
INFO - 2020-09-20 14:49:10 --> Controller Class Initialized
INFO - 2020-09-20 14:49:10 --> Model Class Initialized
INFO - 2020-09-20 14:49:10 --> Model Class Initialized
DEBUG - 2020-09-20 14:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-20 14:49:10 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:10 --> Total execution time: 0.0221
ERROR - 2020-09-20 14:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:20 --> Config Class Initialized
INFO - 2020-09-20 14:49:20 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:20 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:20 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:20 --> URI Class Initialized
INFO - 2020-09-20 14:49:20 --> Router Class Initialized
INFO - 2020-09-20 14:49:20 --> Output Class Initialized
INFO - 2020-09-20 14:49:20 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:20 --> Input Class Initialized
INFO - 2020-09-20 14:49:20 --> Language Class Initialized
INFO - 2020-09-20 14:49:20 --> Loader Class Initialized
INFO - 2020-09-20 14:49:20 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:20 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:20 --> Email Class Initialized
INFO - 2020-09-20 14:49:20 --> Controller Class Initialized
INFO - 2020-09-20 14:49:20 --> Model Class Initialized
INFO - 2020-09-20 14:49:20 --> Model Class Initialized
DEBUG - 2020-09-20 14:49:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:49:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:20 --> Model Class Initialized
INFO - 2020-09-20 14:49:20 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:20 --> Total execution time: 0.0238
ERROR - 2020-09-20 14:49:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:20 --> Config Class Initialized
INFO - 2020-09-20 14:49:20 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:20 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:20 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:20 --> URI Class Initialized
INFO - 2020-09-20 14:49:20 --> Router Class Initialized
INFO - 2020-09-20 14:49:20 --> Output Class Initialized
INFO - 2020-09-20 14:49:20 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:20 --> Input Class Initialized
INFO - 2020-09-20 14:49:20 --> Language Class Initialized
INFO - 2020-09-20 14:49:20 --> Loader Class Initialized
INFO - 2020-09-20 14:49:20 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:20 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:20 --> Email Class Initialized
INFO - 2020-09-20 14:49:20 --> Controller Class Initialized
INFO - 2020-09-20 14:49:20 --> Model Class Initialized
INFO - 2020-09-20 14:49:20 --> Model Class Initialized
DEBUG - 2020-09-20 14:49:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-20 14:49:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:21 --> Config Class Initialized
INFO - 2020-09-20 14:49:21 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:21 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:21 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:21 --> URI Class Initialized
DEBUG - 2020-09-20 14:49:21 --> No URI present. Default controller set.
INFO - 2020-09-20 14:49:21 --> Router Class Initialized
INFO - 2020-09-20 14:49:21 --> Output Class Initialized
INFO - 2020-09-20 14:49:21 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:21 --> Input Class Initialized
INFO - 2020-09-20 14:49:21 --> Language Class Initialized
INFO - 2020-09-20 14:49:21 --> Loader Class Initialized
INFO - 2020-09-20 14:49:21 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:21 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:21 --> Email Class Initialized
INFO - 2020-09-20 14:49:21 --> Controller Class Initialized
INFO - 2020-09-20 14:49:21 --> Model Class Initialized
INFO - 2020-09-20 14:49:21 --> Model Class Initialized
DEBUG - 2020-09-20 14:49:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-20 14:49:21 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:21 --> Total execution time: 0.0206
ERROR - 2020-09-20 14:49:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:33 --> Config Class Initialized
INFO - 2020-09-20 14:49:33 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:33 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:33 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:33 --> URI Class Initialized
INFO - 2020-09-20 14:49:33 --> Router Class Initialized
INFO - 2020-09-20 14:49:33 --> Output Class Initialized
INFO - 2020-09-20 14:49:33 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:33 --> Input Class Initialized
INFO - 2020-09-20 14:49:33 --> Language Class Initialized
INFO - 2020-09-20 14:49:33 --> Loader Class Initialized
INFO - 2020-09-20 14:49:33 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:33 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:33 --> Email Class Initialized
INFO - 2020-09-20 14:49:33 --> Controller Class Initialized
INFO - 2020-09-20 14:49:33 --> Model Class Initialized
INFO - 2020-09-20 14:49:33 --> Model Class Initialized
DEBUG - 2020-09-20 14:49:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:49:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:33 --> Model Class Initialized
INFO - 2020-09-20 14:49:33 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:33 --> Total execution time: 0.0239
ERROR - 2020-09-20 14:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:34 --> Config Class Initialized
INFO - 2020-09-20 14:49:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:34 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:34 --> URI Class Initialized
INFO - 2020-09-20 14:49:34 --> Router Class Initialized
INFO - 2020-09-20 14:49:34 --> Output Class Initialized
INFO - 2020-09-20 14:49:34 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:34 --> Input Class Initialized
INFO - 2020-09-20 14:49:34 --> Language Class Initialized
INFO - 2020-09-20 14:49:34 --> Loader Class Initialized
INFO - 2020-09-20 14:49:34 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:34 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:34 --> Email Class Initialized
INFO - 2020-09-20 14:49:34 --> Controller Class Initialized
INFO - 2020-09-20 14:49:34 --> Model Class Initialized
INFO - 2020-09-20 14:49:34 --> Model Class Initialized
DEBUG - 2020-09-20 14:49:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-20 14:49:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:34 --> Config Class Initialized
INFO - 2020-09-20 14:49:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:34 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:34 --> URI Class Initialized
INFO - 2020-09-20 14:49:34 --> Router Class Initialized
INFO - 2020-09-20 14:49:34 --> Output Class Initialized
INFO - 2020-09-20 14:49:34 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:34 --> Input Class Initialized
INFO - 2020-09-20 14:49:34 --> Language Class Initialized
INFO - 2020-09-20 14:49:34 --> Loader Class Initialized
INFO - 2020-09-20 14:49:34 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:34 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:34 --> Email Class Initialized
INFO - 2020-09-20 14:49:34 --> Controller Class Initialized
DEBUG - 2020-09-20 14:49:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:49:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:34 --> Model Class Initialized
INFO - 2020-09-20 14:49:34 --> Model Class Initialized
INFO - 2020-09-20 14:49:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 14:49:34 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:34 --> Total execution time: 0.0255
ERROR - 2020-09-20 14:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:49:41 --> Config Class Initialized
INFO - 2020-09-20 14:49:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:49:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:49:41 --> Utf8 Class Initialized
INFO - 2020-09-20 14:49:41 --> URI Class Initialized
INFO - 2020-09-20 14:49:41 --> Router Class Initialized
INFO - 2020-09-20 14:49:41 --> Output Class Initialized
INFO - 2020-09-20 14:49:41 --> Security Class Initialized
DEBUG - 2020-09-20 14:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:49:41 --> Input Class Initialized
INFO - 2020-09-20 14:49:41 --> Language Class Initialized
INFO - 2020-09-20 14:49:41 --> Loader Class Initialized
INFO - 2020-09-20 14:49:41 --> Helper loaded: url_helper
INFO - 2020-09-20 14:49:41 --> Database Driver Class Initialized
INFO - 2020-09-20 14:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:49:41 --> Email Class Initialized
INFO - 2020-09-20 14:49:41 --> Controller Class Initialized
DEBUG - 2020-09-20 14:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:49:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:49:41 --> Model Class Initialized
INFO - 2020-09-20 14:49:41 --> Model Class Initialized
INFO - 2020-09-20 14:49:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:49:41 --> Final output sent to browser
DEBUG - 2020-09-20 14:49:41 --> Total execution time: 0.0180
ERROR - 2020-09-20 14:51:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:51:40 --> Config Class Initialized
INFO - 2020-09-20 14:51:40 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:51:40 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:51:40 --> Utf8 Class Initialized
INFO - 2020-09-20 14:51:40 --> URI Class Initialized
INFO - 2020-09-20 14:51:40 --> Router Class Initialized
INFO - 2020-09-20 14:51:40 --> Output Class Initialized
INFO - 2020-09-20 14:51:40 --> Security Class Initialized
DEBUG - 2020-09-20 14:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:51:40 --> Input Class Initialized
INFO - 2020-09-20 14:51:40 --> Language Class Initialized
INFO - 2020-09-20 14:51:40 --> Loader Class Initialized
INFO - 2020-09-20 14:51:40 --> Helper loaded: url_helper
INFO - 2020-09-20 14:51:40 --> Database Driver Class Initialized
INFO - 2020-09-20 14:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:51:40 --> Email Class Initialized
INFO - 2020-09-20 14:51:40 --> Controller Class Initialized
DEBUG - 2020-09-20 14:51:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:51:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:51:40 --> Model Class Initialized
INFO - 2020-09-20 14:51:40 --> Model Class Initialized
INFO - 2020-09-20 14:51:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:51:40 --> Final output sent to browser
DEBUG - 2020-09-20 14:51:40 --> Total execution time: 0.0217
ERROR - 2020-09-20 14:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:51:41 --> Config Class Initialized
INFO - 2020-09-20 14:51:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:51:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:51:41 --> Utf8 Class Initialized
INFO - 2020-09-20 14:51:41 --> URI Class Initialized
INFO - 2020-09-20 14:51:41 --> Router Class Initialized
INFO - 2020-09-20 14:51:41 --> Output Class Initialized
INFO - 2020-09-20 14:51:41 --> Security Class Initialized
DEBUG - 2020-09-20 14:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:51:41 --> Input Class Initialized
INFO - 2020-09-20 14:51:41 --> Language Class Initialized
INFO - 2020-09-20 14:51:41 --> Loader Class Initialized
INFO - 2020-09-20 14:51:41 --> Helper loaded: url_helper
INFO - 2020-09-20 14:51:41 --> Database Driver Class Initialized
INFO - 2020-09-20 14:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:51:41 --> Email Class Initialized
INFO - 2020-09-20 14:51:41 --> Controller Class Initialized
DEBUG - 2020-09-20 14:51:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:51:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:51:41 --> Model Class Initialized
INFO - 2020-09-20 14:51:41 --> Model Class Initialized
ERROR - 2020-09-20 14:51:41 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_details_list; expected 1, got 0 - Invalid query: CALL client_status_details_list()
INFO - 2020-09-20 14:51:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 14:52:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:52:30 --> Config Class Initialized
INFO - 2020-09-20 14:52:30 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:52:30 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:52:30 --> Utf8 Class Initialized
INFO - 2020-09-20 14:52:30 --> URI Class Initialized
INFO - 2020-09-20 14:52:30 --> Router Class Initialized
INFO - 2020-09-20 14:52:30 --> Output Class Initialized
INFO - 2020-09-20 14:52:30 --> Security Class Initialized
DEBUG - 2020-09-20 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:52:30 --> Input Class Initialized
INFO - 2020-09-20 14:52:30 --> Language Class Initialized
INFO - 2020-09-20 14:52:30 --> Loader Class Initialized
INFO - 2020-09-20 14:52:30 --> Helper loaded: url_helper
INFO - 2020-09-20 14:52:30 --> Database Driver Class Initialized
INFO - 2020-09-20 14:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:52:30 --> Email Class Initialized
INFO - 2020-09-20 14:52:30 --> Controller Class Initialized
DEBUG - 2020-09-20 14:52:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:52:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:52:30 --> Model Class Initialized
INFO - 2020-09-20 14:52:30 --> Model Class Initialized
ERROR - 2020-09-20 14:52:30 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.sale_rep_assign_view_for_client; expected 1, got 0 - Invalid query: CALL sale_rep_assign_view_for_client()
INFO - 2020-09-20 14:52:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 14:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:53:39 --> Config Class Initialized
INFO - 2020-09-20 14:53:39 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:53:39 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:53:39 --> Utf8 Class Initialized
INFO - 2020-09-20 14:53:39 --> URI Class Initialized
INFO - 2020-09-20 14:53:39 --> Router Class Initialized
INFO - 2020-09-20 14:53:39 --> Output Class Initialized
INFO - 2020-09-20 14:53:39 --> Security Class Initialized
DEBUG - 2020-09-20 14:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:53:39 --> Input Class Initialized
INFO - 2020-09-20 14:53:39 --> Language Class Initialized
INFO - 2020-09-20 14:53:39 --> Loader Class Initialized
INFO - 2020-09-20 14:53:39 --> Helper loaded: url_helper
INFO - 2020-09-20 14:53:39 --> Database Driver Class Initialized
INFO - 2020-09-20 14:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:53:39 --> Email Class Initialized
INFO - 2020-09-20 14:53:39 --> Controller Class Initialized
DEBUG - 2020-09-20 14:53:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:53:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:53:39 --> Model Class Initialized
INFO - 2020-09-20 14:53:39 --> Model Class Initialized
INFO - 2020-09-20 14:53:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 14:53:39 --> Final output sent to browser
DEBUG - 2020-09-20 14:53:39 --> Total execution time: 0.0198
ERROR - 2020-09-20 14:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:53:41 --> Config Class Initialized
INFO - 2020-09-20 14:53:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:53:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:53:41 --> Utf8 Class Initialized
INFO - 2020-09-20 14:53:41 --> URI Class Initialized
INFO - 2020-09-20 14:53:41 --> Router Class Initialized
INFO - 2020-09-20 14:53:41 --> Output Class Initialized
INFO - 2020-09-20 14:53:41 --> Security Class Initialized
DEBUG - 2020-09-20 14:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:53:41 --> Input Class Initialized
INFO - 2020-09-20 14:53:41 --> Language Class Initialized
INFO - 2020-09-20 14:53:41 --> Loader Class Initialized
INFO - 2020-09-20 14:53:41 --> Helper loaded: url_helper
INFO - 2020-09-20 14:53:41 --> Database Driver Class Initialized
INFO - 2020-09-20 14:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:53:41 --> Email Class Initialized
INFO - 2020-09-20 14:53:41 --> Controller Class Initialized
DEBUG - 2020-09-20 14:53:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:53:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:53:41 --> Model Class Initialized
INFO - 2020-09-20 14:53:41 --> Model Class Initialized
INFO - 2020-09-20 14:53:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 14:53:41 --> Final output sent to browser
DEBUG - 2020-09-20 14:53:41 --> Total execution time: 0.0369
ERROR - 2020-09-20 14:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:53:52 --> Config Class Initialized
INFO - 2020-09-20 14:53:52 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:53:52 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:53:52 --> Utf8 Class Initialized
INFO - 2020-09-20 14:53:52 --> URI Class Initialized
INFO - 2020-09-20 14:53:52 --> Router Class Initialized
INFO - 2020-09-20 14:53:52 --> Output Class Initialized
INFO - 2020-09-20 14:53:52 --> Security Class Initialized
DEBUG - 2020-09-20 14:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:53:52 --> Input Class Initialized
INFO - 2020-09-20 14:53:52 --> Language Class Initialized
INFO - 2020-09-20 14:53:52 --> Loader Class Initialized
INFO - 2020-09-20 14:53:52 --> Helper loaded: url_helper
INFO - 2020-09-20 14:53:52 --> Database Driver Class Initialized
INFO - 2020-09-20 14:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:53:52 --> Email Class Initialized
INFO - 2020-09-20 14:53:52 --> Controller Class Initialized
DEBUG - 2020-09-20 14:53:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:53:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:53:52 --> Model Class Initialized
INFO - 2020-09-20 14:53:52 --> Model Class Initialized
INFO - 2020-09-20 14:53:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 14:53:52 --> Final output sent to browser
DEBUG - 2020-09-20 14:53:52 --> Total execution time: 0.0269
ERROR - 2020-09-20 14:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 14:55:36 --> Config Class Initialized
INFO - 2020-09-20 14:55:36 --> Hooks Class Initialized
DEBUG - 2020-09-20 14:55:36 --> UTF-8 Support Enabled
INFO - 2020-09-20 14:55:36 --> Utf8 Class Initialized
INFO - 2020-09-20 14:55:36 --> URI Class Initialized
INFO - 2020-09-20 14:55:36 --> Router Class Initialized
INFO - 2020-09-20 14:55:36 --> Output Class Initialized
INFO - 2020-09-20 14:55:36 --> Security Class Initialized
DEBUG - 2020-09-20 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 14:55:36 --> Input Class Initialized
INFO - 2020-09-20 14:55:36 --> Language Class Initialized
INFO - 2020-09-20 14:55:36 --> Loader Class Initialized
INFO - 2020-09-20 14:55:36 --> Helper loaded: url_helper
INFO - 2020-09-20 14:55:36 --> Database Driver Class Initialized
INFO - 2020-09-20 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 14:55:36 --> Email Class Initialized
INFO - 2020-09-20 14:55:36 --> Controller Class Initialized
DEBUG - 2020-09-20 14:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 14:55:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 14:55:36 --> Model Class Initialized
INFO - 2020-09-20 14:55:36 --> Model Class Initialized
INFO - 2020-09-20 14:55:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 14:55:36 --> Final output sent to browser
DEBUG - 2020-09-20 14:55:36 --> Total execution time: 0.0240
ERROR - 2020-09-20 15:03:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:03:49 --> Config Class Initialized
INFO - 2020-09-20 15:03:49 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:03:49 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:03:49 --> Utf8 Class Initialized
INFO - 2020-09-20 15:03:49 --> URI Class Initialized
INFO - 2020-09-20 15:03:49 --> Router Class Initialized
INFO - 2020-09-20 15:03:49 --> Output Class Initialized
INFO - 2020-09-20 15:03:49 --> Security Class Initialized
DEBUG - 2020-09-20 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:03:49 --> Input Class Initialized
INFO - 2020-09-20 15:03:49 --> Language Class Initialized
INFO - 2020-09-20 15:03:49 --> Loader Class Initialized
INFO - 2020-09-20 15:03:49 --> Helper loaded: url_helper
INFO - 2020-09-20 15:03:49 --> Database Driver Class Initialized
INFO - 2020-09-20 15:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:03:49 --> Email Class Initialized
INFO - 2020-09-20 15:03:49 --> Controller Class Initialized
DEBUG - 2020-09-20 15:03:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:03:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:03:49 --> Model Class Initialized
INFO - 2020-09-20 15:03:49 --> Model Class Initialized
INFO - 2020-09-20 15:03:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:03:49 --> Final output sent to browser
DEBUG - 2020-09-20 15:03:49 --> Total execution time: 0.0304
ERROR - 2020-09-20 15:04:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:04:05 --> Config Class Initialized
INFO - 2020-09-20 15:04:05 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:04:05 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:04:05 --> Utf8 Class Initialized
INFO - 2020-09-20 15:04:05 --> URI Class Initialized
INFO - 2020-09-20 15:04:05 --> Router Class Initialized
INFO - 2020-09-20 15:04:05 --> Output Class Initialized
INFO - 2020-09-20 15:04:05 --> Security Class Initialized
DEBUG - 2020-09-20 15:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:04:05 --> Input Class Initialized
INFO - 2020-09-20 15:04:05 --> Language Class Initialized
INFO - 2020-09-20 15:04:05 --> Loader Class Initialized
INFO - 2020-09-20 15:04:05 --> Helper loaded: url_helper
INFO - 2020-09-20 15:04:05 --> Database Driver Class Initialized
INFO - 2020-09-20 15:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:04:05 --> Email Class Initialized
INFO - 2020-09-20 15:04:05 --> Controller Class Initialized
DEBUG - 2020-09-20 15:04:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:04:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:04:05 --> Model Class Initialized
INFO - 2020-09-20 15:04:05 --> Model Class Initialized
INFO - 2020-09-20 15:04:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 15:04:05 --> Final output sent to browser
DEBUG - 2020-09-20 15:04:05 --> Total execution time: 0.0228
ERROR - 2020-09-20 15:04:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:04:07 --> Config Class Initialized
INFO - 2020-09-20 15:04:07 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:04:07 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:04:07 --> Utf8 Class Initialized
INFO - 2020-09-20 15:04:07 --> URI Class Initialized
INFO - 2020-09-20 15:04:07 --> Router Class Initialized
INFO - 2020-09-20 15:04:07 --> Output Class Initialized
INFO - 2020-09-20 15:04:07 --> Security Class Initialized
DEBUG - 2020-09-20 15:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:04:07 --> Input Class Initialized
INFO - 2020-09-20 15:04:07 --> Language Class Initialized
INFO - 2020-09-20 15:04:07 --> Loader Class Initialized
INFO - 2020-09-20 15:04:07 --> Helper loaded: url_helper
INFO - 2020-09-20 15:04:07 --> Database Driver Class Initialized
INFO - 2020-09-20 15:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:04:07 --> Email Class Initialized
INFO - 2020-09-20 15:04:07 --> Controller Class Initialized
DEBUG - 2020-09-20 15:04:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:04:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:04:07 --> Model Class Initialized
INFO - 2020-09-20 15:04:07 --> Model Class Initialized
INFO - 2020-09-20 15:04:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:04:07 --> Final output sent to browser
DEBUG - 2020-09-20 15:04:07 --> Total execution time: 0.0266
ERROR - 2020-09-20 15:08:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:08:54 --> Config Class Initialized
INFO - 2020-09-20 15:08:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:08:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:08:54 --> Utf8 Class Initialized
INFO - 2020-09-20 15:08:54 --> URI Class Initialized
INFO - 2020-09-20 15:08:54 --> Router Class Initialized
INFO - 2020-09-20 15:08:54 --> Output Class Initialized
INFO - 2020-09-20 15:08:54 --> Security Class Initialized
DEBUG - 2020-09-20 15:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:08:54 --> Input Class Initialized
INFO - 2020-09-20 15:08:54 --> Language Class Initialized
INFO - 2020-09-20 15:08:54 --> Loader Class Initialized
INFO - 2020-09-20 15:08:54 --> Helper loaded: url_helper
INFO - 2020-09-20 15:08:54 --> Database Driver Class Initialized
INFO - 2020-09-20 15:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:08:54 --> Email Class Initialized
INFO - 2020-09-20 15:08:54 --> Controller Class Initialized
DEBUG - 2020-09-20 15:08:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:08:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:08:54 --> Model Class Initialized
INFO - 2020-09-20 15:08:54 --> Model Class Initialized
INFO - 2020-09-20 15:08:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:08:54 --> Final output sent to browser
DEBUG - 2020-09-20 15:08:54 --> Total execution time: 0.0284
ERROR - 2020-09-20 15:09:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:09:26 --> Config Class Initialized
INFO - 2020-09-20 15:09:26 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:09:26 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:09:26 --> Utf8 Class Initialized
INFO - 2020-09-20 15:09:26 --> URI Class Initialized
INFO - 2020-09-20 15:09:26 --> Router Class Initialized
INFO - 2020-09-20 15:09:26 --> Output Class Initialized
INFO - 2020-09-20 15:09:26 --> Security Class Initialized
DEBUG - 2020-09-20 15:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:09:26 --> Input Class Initialized
INFO - 2020-09-20 15:09:26 --> Language Class Initialized
INFO - 2020-09-20 15:09:26 --> Loader Class Initialized
INFO - 2020-09-20 15:09:26 --> Helper loaded: url_helper
INFO - 2020-09-20 15:09:26 --> Database Driver Class Initialized
INFO - 2020-09-20 15:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:09:26 --> Email Class Initialized
INFO - 2020-09-20 15:09:26 --> Controller Class Initialized
DEBUG - 2020-09-20 15:09:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:09:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:09:26 --> Model Class Initialized
INFO - 2020-09-20 15:09:26 --> Model Class Initialized
INFO - 2020-09-20 15:09:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:09:26 --> Final output sent to browser
DEBUG - 2020-09-20 15:09:26 --> Total execution time: 0.0261
ERROR - 2020-09-20 15:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:11:16 --> Config Class Initialized
INFO - 2020-09-20 15:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:11:16 --> Utf8 Class Initialized
INFO - 2020-09-20 15:11:16 --> URI Class Initialized
INFO - 2020-09-20 15:11:16 --> Router Class Initialized
INFO - 2020-09-20 15:11:16 --> Output Class Initialized
INFO - 2020-09-20 15:11:16 --> Security Class Initialized
DEBUG - 2020-09-20 15:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:11:16 --> Input Class Initialized
INFO - 2020-09-20 15:11:16 --> Language Class Initialized
INFO - 2020-09-20 15:11:16 --> Loader Class Initialized
INFO - 2020-09-20 15:11:16 --> Helper loaded: url_helper
INFO - 2020-09-20 15:11:16 --> Database Driver Class Initialized
INFO - 2020-09-20 15:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:11:16 --> Email Class Initialized
INFO - 2020-09-20 15:11:16 --> Controller Class Initialized
DEBUG - 2020-09-20 15:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:11:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:11:16 --> Model Class Initialized
INFO - 2020-09-20 15:11:16 --> Model Class Initialized
INFO - 2020-09-20 15:11:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:11:16 --> Final output sent to browser
DEBUG - 2020-09-20 15:11:16 --> Total execution time: 0.0244
ERROR - 2020-09-20 15:25:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:25:46 --> Config Class Initialized
INFO - 2020-09-20 15:25:46 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:25:46 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:25:46 --> Utf8 Class Initialized
INFO - 2020-09-20 15:25:46 --> URI Class Initialized
INFO - 2020-09-20 15:25:46 --> Router Class Initialized
INFO - 2020-09-20 15:25:46 --> Output Class Initialized
INFO - 2020-09-20 15:25:46 --> Security Class Initialized
DEBUG - 2020-09-20 15:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:25:46 --> Input Class Initialized
INFO - 2020-09-20 15:25:46 --> Language Class Initialized
INFO - 2020-09-20 15:25:46 --> Loader Class Initialized
INFO - 2020-09-20 15:25:46 --> Helper loaded: url_helper
INFO - 2020-09-20 15:25:46 --> Database Driver Class Initialized
INFO - 2020-09-20 15:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:25:46 --> Email Class Initialized
INFO - 2020-09-20 15:25:46 --> Controller Class Initialized
DEBUG - 2020-09-20 15:25:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:25:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:25:46 --> Model Class Initialized
INFO - 2020-09-20 15:25:46 --> Model Class Initialized
INFO - 2020-09-20 15:25:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 15:25:46 --> Final output sent to browser
DEBUG - 2020-09-20 15:25:46 --> Total execution time: 0.0308
ERROR - 2020-09-20 15:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:25:52 --> Config Class Initialized
INFO - 2020-09-20 15:25:52 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:25:52 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:25:52 --> Utf8 Class Initialized
INFO - 2020-09-20 15:25:52 --> URI Class Initialized
INFO - 2020-09-20 15:25:52 --> Router Class Initialized
INFO - 2020-09-20 15:25:52 --> Output Class Initialized
INFO - 2020-09-20 15:25:52 --> Security Class Initialized
DEBUG - 2020-09-20 15:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:25:52 --> Input Class Initialized
INFO - 2020-09-20 15:25:52 --> Language Class Initialized
INFO - 2020-09-20 15:25:52 --> Loader Class Initialized
INFO - 2020-09-20 15:25:52 --> Helper loaded: url_helper
INFO - 2020-09-20 15:25:52 --> Database Driver Class Initialized
INFO - 2020-09-20 15:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:25:52 --> Email Class Initialized
INFO - 2020-09-20 15:25:52 --> Controller Class Initialized
DEBUG - 2020-09-20 15:25:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:25:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:25:52 --> Model Class Initialized
INFO - 2020-09-20 15:25:52 --> Model Class Initialized
INFO - 2020-09-20 15:25:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 15:25:52 --> Final output sent to browser
DEBUG - 2020-09-20 15:25:52 --> Total execution time: 0.0234
ERROR - 2020-09-20 15:25:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:25:55 --> Config Class Initialized
INFO - 2020-09-20 15:25:55 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:25:55 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:25:55 --> Utf8 Class Initialized
INFO - 2020-09-20 15:25:55 --> URI Class Initialized
INFO - 2020-09-20 15:25:55 --> Router Class Initialized
INFO - 2020-09-20 15:25:55 --> Output Class Initialized
INFO - 2020-09-20 15:25:55 --> Security Class Initialized
DEBUG - 2020-09-20 15:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:25:55 --> Input Class Initialized
INFO - 2020-09-20 15:25:55 --> Language Class Initialized
INFO - 2020-09-20 15:25:55 --> Loader Class Initialized
INFO - 2020-09-20 15:25:55 --> Helper loaded: url_helper
INFO - 2020-09-20 15:25:55 --> Database Driver Class Initialized
INFO - 2020-09-20 15:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:25:55 --> Email Class Initialized
INFO - 2020-09-20 15:25:55 --> Controller Class Initialized
DEBUG - 2020-09-20 15:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:25:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:25:55 --> Model Class Initialized
INFO - 2020-09-20 15:25:55 --> Model Class Initialized
INFO - 2020-09-20 15:25:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:25:55 --> Final output sent to browser
DEBUG - 2020-09-20 15:25:55 --> Total execution time: 0.0249
ERROR - 2020-09-20 15:26:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:26:15 --> Config Class Initialized
INFO - 2020-09-20 15:26:15 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:26:15 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:26:15 --> Utf8 Class Initialized
INFO - 2020-09-20 15:26:15 --> URI Class Initialized
INFO - 2020-09-20 15:26:15 --> Router Class Initialized
INFO - 2020-09-20 15:26:15 --> Output Class Initialized
INFO - 2020-09-20 15:26:15 --> Security Class Initialized
DEBUG - 2020-09-20 15:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:26:15 --> Input Class Initialized
INFO - 2020-09-20 15:26:15 --> Language Class Initialized
INFO - 2020-09-20 15:26:15 --> Loader Class Initialized
INFO - 2020-09-20 15:26:15 --> Helper loaded: url_helper
INFO - 2020-09-20 15:26:15 --> Database Driver Class Initialized
INFO - 2020-09-20 15:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:26:15 --> Email Class Initialized
INFO - 2020-09-20 15:26:15 --> Controller Class Initialized
DEBUG - 2020-09-20 15:26:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:26:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:26:15 --> Model Class Initialized
INFO - 2020-09-20 15:26:15 --> Model Class Initialized
INFO - 2020-09-20 15:26:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 15:26:15 --> Final output sent to browser
DEBUG - 2020-09-20 15:26:15 --> Total execution time: 0.0213
ERROR - 2020-09-20 15:26:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 15:26:24 --> Config Class Initialized
INFO - 2020-09-20 15:26:24 --> Hooks Class Initialized
DEBUG - 2020-09-20 15:26:24 --> UTF-8 Support Enabled
INFO - 2020-09-20 15:26:24 --> Utf8 Class Initialized
INFO - 2020-09-20 15:26:24 --> URI Class Initialized
INFO - 2020-09-20 15:26:24 --> Router Class Initialized
INFO - 2020-09-20 15:26:24 --> Output Class Initialized
INFO - 2020-09-20 15:26:24 --> Security Class Initialized
DEBUG - 2020-09-20 15:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 15:26:24 --> Input Class Initialized
INFO - 2020-09-20 15:26:24 --> Language Class Initialized
INFO - 2020-09-20 15:26:24 --> Loader Class Initialized
INFO - 2020-09-20 15:26:24 --> Helper loaded: url_helper
INFO - 2020-09-20 15:26:24 --> Database Driver Class Initialized
INFO - 2020-09-20 15:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 15:26:24 --> Email Class Initialized
INFO - 2020-09-20 15:26:24 --> Controller Class Initialized
DEBUG - 2020-09-20 15:26:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 15:26:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 15:26:24 --> Model Class Initialized
INFO - 2020-09-20 15:26:24 --> Model Class Initialized
INFO - 2020-09-20 15:26:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 15:26:24 --> Final output sent to browser
DEBUG - 2020-09-20 15:26:24 --> Total execution time: 0.0307
ERROR - 2020-09-20 16:05:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:05:09 --> Config Class Initialized
INFO - 2020-09-20 16:05:09 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:05:09 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:05:09 --> Utf8 Class Initialized
INFO - 2020-09-20 16:05:09 --> URI Class Initialized
INFO - 2020-09-20 16:05:09 --> Router Class Initialized
INFO - 2020-09-20 16:05:09 --> Output Class Initialized
INFO - 2020-09-20 16:05:09 --> Security Class Initialized
DEBUG - 2020-09-20 16:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:05:09 --> Input Class Initialized
INFO - 2020-09-20 16:05:09 --> Language Class Initialized
INFO - 2020-09-20 16:05:09 --> Loader Class Initialized
INFO - 2020-09-20 16:05:09 --> Helper loaded: url_helper
INFO - 2020-09-20 16:05:09 --> Database Driver Class Initialized
INFO - 2020-09-20 16:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:05:09 --> Email Class Initialized
INFO - 2020-09-20 16:05:09 --> Controller Class Initialized
DEBUG - 2020-09-20 16:05:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:05:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:05:09 --> Model Class Initialized
INFO - 2020-09-20 16:05:09 --> Model Class Initialized
INFO - 2020-09-20 16:05:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 16:05:09 --> Final output sent to browser
DEBUG - 2020-09-20 16:05:09 --> Total execution time: 0.0253
ERROR - 2020-09-20 16:06:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:06:57 --> Config Class Initialized
INFO - 2020-09-20 16:06:57 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:06:57 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:06:57 --> Utf8 Class Initialized
INFO - 2020-09-20 16:06:57 --> URI Class Initialized
INFO - 2020-09-20 16:06:57 --> Router Class Initialized
INFO - 2020-09-20 16:06:57 --> Output Class Initialized
INFO - 2020-09-20 16:06:57 --> Security Class Initialized
DEBUG - 2020-09-20 16:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:06:57 --> Input Class Initialized
INFO - 2020-09-20 16:06:57 --> Language Class Initialized
INFO - 2020-09-20 16:06:57 --> Loader Class Initialized
INFO - 2020-09-20 16:06:57 --> Helper loaded: url_helper
INFO - 2020-09-20 16:06:57 --> Database Driver Class Initialized
INFO - 2020-09-20 16:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:06:57 --> Email Class Initialized
INFO - 2020-09-20 16:06:57 --> Controller Class Initialized
DEBUG - 2020-09-20 16:06:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:06:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:06:57 --> Model Class Initialized
INFO - 2020-09-20 16:06:57 --> Model Class Initialized
INFO - 2020-09-20 16:06:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 16:06:57 --> Final output sent to browser
DEBUG - 2020-09-20 16:06:57 --> Total execution time: 0.0267
ERROR - 2020-09-20 16:07:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:07:12 --> Config Class Initialized
INFO - 2020-09-20 16:07:12 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:07:12 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:07:12 --> Utf8 Class Initialized
INFO - 2020-09-20 16:07:12 --> URI Class Initialized
INFO - 2020-09-20 16:07:12 --> Router Class Initialized
INFO - 2020-09-20 16:07:12 --> Output Class Initialized
INFO - 2020-09-20 16:07:12 --> Security Class Initialized
DEBUG - 2020-09-20 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:07:12 --> Input Class Initialized
INFO - 2020-09-20 16:07:12 --> Language Class Initialized
INFO - 2020-09-20 16:07:12 --> Loader Class Initialized
INFO - 2020-09-20 16:07:12 --> Helper loaded: url_helper
INFO - 2020-09-20 16:07:12 --> Database Driver Class Initialized
INFO - 2020-09-20 16:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:07:12 --> Email Class Initialized
INFO - 2020-09-20 16:07:12 --> Controller Class Initialized
DEBUG - 2020-09-20 16:07:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:07:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:07:12 --> Model Class Initialized
INFO - 2020-09-20 16:07:12 --> Model Class Initialized
INFO - 2020-09-20 16:07:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 16:07:12 --> Final output sent to browser
DEBUG - 2020-09-20 16:07:12 --> Total execution time: 0.0220
ERROR - 2020-09-20 16:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:35:57 --> Config Class Initialized
INFO - 2020-09-20 16:35:57 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:35:57 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:35:57 --> Utf8 Class Initialized
INFO - 2020-09-20 16:35:57 --> URI Class Initialized
INFO - 2020-09-20 16:35:57 --> Router Class Initialized
INFO - 2020-09-20 16:35:57 --> Output Class Initialized
INFO - 2020-09-20 16:35:57 --> Security Class Initialized
DEBUG - 2020-09-20 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:35:57 --> Input Class Initialized
INFO - 2020-09-20 16:35:57 --> Language Class Initialized
INFO - 2020-09-20 16:35:57 --> Loader Class Initialized
INFO - 2020-09-20 16:35:57 --> Helper loaded: url_helper
INFO - 2020-09-20 16:35:57 --> Database Driver Class Initialized
INFO - 2020-09-20 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:35:57 --> Email Class Initialized
INFO - 2020-09-20 16:35:57 --> Controller Class Initialized
DEBUG - 2020-09-20 16:35:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:35:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:35:57 --> Model Class Initialized
INFO - 2020-09-20 16:35:57 --> Model Class Initialized
INFO - 2020-09-20 16:35:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 16:35:57 --> Final output sent to browser
DEBUG - 2020-09-20 16:35:57 --> Total execution time: 0.1514
ERROR - 2020-09-20 16:47:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:47:58 --> Config Class Initialized
INFO - 2020-09-20 16:47:58 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:47:58 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:47:58 --> Utf8 Class Initialized
INFO - 2020-09-20 16:47:58 --> URI Class Initialized
INFO - 2020-09-20 16:47:58 --> Router Class Initialized
INFO - 2020-09-20 16:47:58 --> Output Class Initialized
INFO - 2020-09-20 16:47:58 --> Security Class Initialized
DEBUG - 2020-09-20 16:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:47:58 --> Input Class Initialized
INFO - 2020-09-20 16:47:58 --> Language Class Initialized
INFO - 2020-09-20 16:47:58 --> Loader Class Initialized
INFO - 2020-09-20 16:47:58 --> Helper loaded: url_helper
INFO - 2020-09-20 16:47:58 --> Database Driver Class Initialized
INFO - 2020-09-20 16:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:47:58 --> Email Class Initialized
INFO - 2020-09-20 16:47:58 --> Controller Class Initialized
DEBUG - 2020-09-20 16:47:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:47:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:47:58 --> Model Class Initialized
INFO - 2020-09-20 16:47:58 --> Model Class Initialized
INFO - 2020-09-20 16:47:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 16:47:58 --> Final output sent to browser
DEBUG - 2020-09-20 16:47:58 --> Total execution time: 0.0266
ERROR - 2020-09-20 16:48:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:48:07 --> Config Class Initialized
INFO - 2020-09-20 16:48:07 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:48:07 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:48:07 --> Utf8 Class Initialized
INFO - 2020-09-20 16:48:07 --> URI Class Initialized
INFO - 2020-09-20 16:48:07 --> Router Class Initialized
INFO - 2020-09-20 16:48:07 --> Output Class Initialized
INFO - 2020-09-20 16:48:07 --> Security Class Initialized
DEBUG - 2020-09-20 16:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:48:07 --> Input Class Initialized
INFO - 2020-09-20 16:48:07 --> Language Class Initialized
INFO - 2020-09-20 16:48:07 --> Loader Class Initialized
INFO - 2020-09-20 16:48:07 --> Helper loaded: url_helper
INFO - 2020-09-20 16:48:07 --> Database Driver Class Initialized
INFO - 2020-09-20 16:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:48:07 --> Email Class Initialized
INFO - 2020-09-20 16:48:07 --> Controller Class Initialized
DEBUG - 2020-09-20 16:48:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:48:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:48:07 --> Model Class Initialized
INFO - 2020-09-20 16:48:07 --> Model Class Initialized
INFO - 2020-09-20 16:48:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 16:48:07 --> Final output sent to browser
DEBUG - 2020-09-20 16:48:07 --> Total execution time: 0.0284
ERROR - 2020-09-20 16:49:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:49:03 --> Config Class Initialized
INFO - 2020-09-20 16:49:03 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:49:03 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:49:03 --> Utf8 Class Initialized
INFO - 2020-09-20 16:49:03 --> URI Class Initialized
INFO - 2020-09-20 16:49:03 --> Router Class Initialized
INFO - 2020-09-20 16:49:03 --> Output Class Initialized
INFO - 2020-09-20 16:49:04 --> Security Class Initialized
DEBUG - 2020-09-20 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:49:04 --> Input Class Initialized
INFO - 2020-09-20 16:49:04 --> Language Class Initialized
INFO - 2020-09-20 16:49:04 --> Loader Class Initialized
INFO - 2020-09-20 16:49:04 --> Helper loaded: url_helper
INFO - 2020-09-20 16:49:04 --> Database Driver Class Initialized
INFO - 2020-09-20 16:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:49:04 --> Email Class Initialized
INFO - 2020-09-20 16:49:04 --> Controller Class Initialized
DEBUG - 2020-09-20 16:49:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:49:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:49:04 --> Model Class Initialized
INFO - 2020-09-20 16:49:04 --> Model Class Initialized
INFO - 2020-09-20 16:49:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 16:49:04 --> Final output sent to browser
DEBUG - 2020-09-20 16:49:04 --> Total execution time: 0.0244
ERROR - 2020-09-20 16:49:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:49:08 --> Config Class Initialized
INFO - 2020-09-20 16:49:08 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:49:08 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:49:08 --> Utf8 Class Initialized
INFO - 2020-09-20 16:49:08 --> URI Class Initialized
INFO - 2020-09-20 16:49:08 --> Router Class Initialized
INFO - 2020-09-20 16:49:08 --> Output Class Initialized
INFO - 2020-09-20 16:49:08 --> Security Class Initialized
DEBUG - 2020-09-20 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:49:08 --> Input Class Initialized
INFO - 2020-09-20 16:49:08 --> Language Class Initialized
INFO - 2020-09-20 16:49:08 --> Loader Class Initialized
INFO - 2020-09-20 16:49:08 --> Helper loaded: url_helper
INFO - 2020-09-20 16:49:08 --> Database Driver Class Initialized
INFO - 2020-09-20 16:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:49:08 --> Email Class Initialized
INFO - 2020-09-20 16:49:08 --> Controller Class Initialized
DEBUG - 2020-09-20 16:49:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:49:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:49:08 --> Model Class Initialized
INFO - 2020-09-20 16:49:08 --> Model Class Initialized
INFO - 2020-09-20 16:49:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 16:49:08 --> Final output sent to browser
DEBUG - 2020-09-20 16:49:08 --> Total execution time: 0.0217
ERROR - 2020-09-20 16:49:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:49:17 --> Config Class Initialized
INFO - 2020-09-20 16:49:17 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:49:17 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:49:17 --> Utf8 Class Initialized
INFO - 2020-09-20 16:49:17 --> URI Class Initialized
INFO - 2020-09-20 16:49:17 --> Router Class Initialized
INFO - 2020-09-20 16:49:17 --> Output Class Initialized
INFO - 2020-09-20 16:49:17 --> Security Class Initialized
DEBUG - 2020-09-20 16:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:49:17 --> Input Class Initialized
INFO - 2020-09-20 16:49:17 --> Language Class Initialized
INFO - 2020-09-20 16:49:17 --> Loader Class Initialized
INFO - 2020-09-20 16:49:17 --> Helper loaded: url_helper
INFO - 2020-09-20 16:49:17 --> Database Driver Class Initialized
INFO - 2020-09-20 16:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:49:17 --> Email Class Initialized
INFO - 2020-09-20 16:49:17 --> Controller Class Initialized
DEBUG - 2020-09-20 16:49:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:49:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:49:17 --> Model Class Initialized
INFO - 2020-09-20 16:49:17 --> Model Class Initialized
INFO - 2020-09-20 16:49:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 16:49:17 --> Final output sent to browser
DEBUG - 2020-09-20 16:49:17 --> Total execution time: 0.0291
ERROR - 2020-09-20 16:49:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:49:21 --> Config Class Initialized
INFO - 2020-09-20 16:49:21 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:49:21 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:49:21 --> Utf8 Class Initialized
INFO - 2020-09-20 16:49:21 --> URI Class Initialized
INFO - 2020-09-20 16:49:21 --> Router Class Initialized
INFO - 2020-09-20 16:49:21 --> Output Class Initialized
INFO - 2020-09-20 16:49:21 --> Security Class Initialized
DEBUG - 2020-09-20 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:49:21 --> Input Class Initialized
INFO - 2020-09-20 16:49:21 --> Language Class Initialized
INFO - 2020-09-20 16:49:21 --> Loader Class Initialized
INFO - 2020-09-20 16:49:21 --> Helper loaded: url_helper
INFO - 2020-09-20 16:49:21 --> Database Driver Class Initialized
INFO - 2020-09-20 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:49:21 --> Email Class Initialized
INFO - 2020-09-20 16:49:21 --> Controller Class Initialized
DEBUG - 2020-09-20 16:49:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:49:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:49:21 --> Model Class Initialized
INFO - 2020-09-20 16:49:21 --> Model Class Initialized
INFO - 2020-09-20 16:49:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 16:49:21 --> Final output sent to browser
DEBUG - 2020-09-20 16:49:21 --> Total execution time: 0.0358
ERROR - 2020-09-20 16:59:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:59:18 --> Config Class Initialized
INFO - 2020-09-20 16:59:18 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:59:18 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:59:18 --> Utf8 Class Initialized
INFO - 2020-09-20 16:59:18 --> URI Class Initialized
INFO - 2020-09-20 16:59:18 --> Router Class Initialized
INFO - 2020-09-20 16:59:18 --> Output Class Initialized
INFO - 2020-09-20 16:59:18 --> Security Class Initialized
DEBUG - 2020-09-20 16:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:59:18 --> Input Class Initialized
INFO - 2020-09-20 16:59:18 --> Language Class Initialized
INFO - 2020-09-20 16:59:18 --> Loader Class Initialized
INFO - 2020-09-20 16:59:18 --> Helper loaded: url_helper
INFO - 2020-09-20 16:59:18 --> Database Driver Class Initialized
INFO - 2020-09-20 16:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:59:18 --> Email Class Initialized
INFO - 2020-09-20 16:59:18 --> Controller Class Initialized
DEBUG - 2020-09-20 16:59:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:59:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:59:18 --> Model Class Initialized
INFO - 2020-09-20 16:59:18 --> Model Class Initialized
INFO - 2020-09-20 16:59:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 16:59:18 --> Final output sent to browser
DEBUG - 2020-09-20 16:59:18 --> Total execution time: 0.0280
ERROR - 2020-09-20 16:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 16:59:59 --> Config Class Initialized
INFO - 2020-09-20 16:59:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 16:59:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 16:59:59 --> Utf8 Class Initialized
INFO - 2020-09-20 16:59:59 --> URI Class Initialized
INFO - 2020-09-20 16:59:59 --> Router Class Initialized
INFO - 2020-09-20 16:59:59 --> Output Class Initialized
INFO - 2020-09-20 16:59:59 --> Security Class Initialized
DEBUG - 2020-09-20 16:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 16:59:59 --> Input Class Initialized
INFO - 2020-09-20 16:59:59 --> Language Class Initialized
INFO - 2020-09-20 16:59:59 --> Loader Class Initialized
INFO - 2020-09-20 16:59:59 --> Helper loaded: url_helper
INFO - 2020-09-20 16:59:59 --> Database Driver Class Initialized
INFO - 2020-09-20 16:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 16:59:59 --> Email Class Initialized
INFO - 2020-09-20 16:59:59 --> Controller Class Initialized
DEBUG - 2020-09-20 16:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 16:59:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 16:59:59 --> Model Class Initialized
INFO - 2020-09-20 16:59:59 --> Model Class Initialized
INFO - 2020-09-20 16:59:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 16:59:59 --> Final output sent to browser
DEBUG - 2020-09-20 16:59:59 --> Total execution time: 0.0216
ERROR - 2020-09-20 17:00:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:00:01 --> Config Class Initialized
INFO - 2020-09-20 17:00:01 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:00:01 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:00:01 --> Utf8 Class Initialized
INFO - 2020-09-20 17:00:01 --> URI Class Initialized
INFO - 2020-09-20 17:00:01 --> Router Class Initialized
INFO - 2020-09-20 17:00:01 --> Output Class Initialized
INFO - 2020-09-20 17:00:01 --> Security Class Initialized
DEBUG - 2020-09-20 17:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:00:01 --> Input Class Initialized
INFO - 2020-09-20 17:00:01 --> Language Class Initialized
INFO - 2020-09-20 17:00:01 --> Loader Class Initialized
INFO - 2020-09-20 17:00:01 --> Helper loaded: url_helper
INFO - 2020-09-20 17:00:01 --> Database Driver Class Initialized
INFO - 2020-09-20 17:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:00:01 --> Email Class Initialized
INFO - 2020-09-20 17:00:01 --> Controller Class Initialized
DEBUG - 2020-09-20 17:00:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:00:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:00:01 --> Model Class Initialized
INFO - 2020-09-20 17:00:01 --> Model Class Initialized
INFO - 2020-09-20 17:00:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:00:01 --> Final output sent to browser
DEBUG - 2020-09-20 17:00:01 --> Total execution time: 0.0249
ERROR - 2020-09-20 17:00:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:00:06 --> Config Class Initialized
INFO - 2020-09-20 17:00:06 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:00:06 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:00:06 --> Utf8 Class Initialized
INFO - 2020-09-20 17:00:06 --> URI Class Initialized
INFO - 2020-09-20 17:00:06 --> Router Class Initialized
INFO - 2020-09-20 17:00:06 --> Output Class Initialized
INFO - 2020-09-20 17:00:06 --> Security Class Initialized
DEBUG - 2020-09-20 17:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:00:06 --> Input Class Initialized
INFO - 2020-09-20 17:00:06 --> Language Class Initialized
INFO - 2020-09-20 17:00:06 --> Loader Class Initialized
INFO - 2020-09-20 17:00:06 --> Helper loaded: url_helper
INFO - 2020-09-20 17:00:06 --> Database Driver Class Initialized
INFO - 2020-09-20 17:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:00:06 --> Email Class Initialized
INFO - 2020-09-20 17:00:06 --> Controller Class Initialized
DEBUG - 2020-09-20 17:00:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:00:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:00:06 --> Model Class Initialized
INFO - 2020-09-20 17:00:06 --> Model Class Initialized
INFO - 2020-09-20 17:00:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:00:06 --> Final output sent to browser
DEBUG - 2020-09-20 17:00:06 --> Total execution time: 0.0229
ERROR - 2020-09-20 17:00:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:00:33 --> Config Class Initialized
INFO - 2020-09-20 17:00:33 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:00:33 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:00:33 --> Utf8 Class Initialized
INFO - 2020-09-20 17:00:33 --> URI Class Initialized
INFO - 2020-09-20 17:00:33 --> Router Class Initialized
INFO - 2020-09-20 17:00:33 --> Output Class Initialized
INFO - 2020-09-20 17:00:33 --> Security Class Initialized
DEBUG - 2020-09-20 17:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:00:33 --> Input Class Initialized
INFO - 2020-09-20 17:00:33 --> Language Class Initialized
INFO - 2020-09-20 17:00:33 --> Loader Class Initialized
INFO - 2020-09-20 17:00:33 --> Helper loaded: url_helper
INFO - 2020-09-20 17:00:33 --> Database Driver Class Initialized
INFO - 2020-09-20 17:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:00:33 --> Email Class Initialized
INFO - 2020-09-20 17:00:33 --> Controller Class Initialized
DEBUG - 2020-09-20 17:00:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:00:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:00:33 --> Model Class Initialized
INFO - 2020-09-20 17:00:33 --> Model Class Initialized
INFO - 2020-09-20 17:00:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:00:33 --> Final output sent to browser
DEBUG - 2020-09-20 17:00:33 --> Total execution time: 0.0216
ERROR - 2020-09-20 17:00:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:00:40 --> Config Class Initialized
INFO - 2020-09-20 17:00:40 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:00:40 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:00:40 --> Utf8 Class Initialized
INFO - 2020-09-20 17:00:40 --> URI Class Initialized
INFO - 2020-09-20 17:00:40 --> Router Class Initialized
INFO - 2020-09-20 17:00:40 --> Output Class Initialized
INFO - 2020-09-20 17:00:40 --> Security Class Initialized
DEBUG - 2020-09-20 17:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:00:40 --> Input Class Initialized
INFO - 2020-09-20 17:00:40 --> Language Class Initialized
INFO - 2020-09-20 17:00:40 --> Loader Class Initialized
INFO - 2020-09-20 17:00:40 --> Helper loaded: url_helper
INFO - 2020-09-20 17:00:40 --> Database Driver Class Initialized
INFO - 2020-09-20 17:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:00:40 --> Email Class Initialized
INFO - 2020-09-20 17:00:40 --> Controller Class Initialized
DEBUG - 2020-09-20 17:00:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:00:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:00:40 --> Model Class Initialized
INFO - 2020-09-20 17:00:40 --> Model Class Initialized
INFO - 2020-09-20 17:00:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:00:40 --> Final output sent to browser
DEBUG - 2020-09-20 17:00:40 --> Total execution time: 0.0269
ERROR - 2020-09-20 17:01:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:01:12 --> Config Class Initialized
INFO - 2020-09-20 17:01:12 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:01:12 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:01:12 --> Utf8 Class Initialized
INFO - 2020-09-20 17:01:12 --> URI Class Initialized
INFO - 2020-09-20 17:01:12 --> Router Class Initialized
INFO - 2020-09-20 17:01:12 --> Output Class Initialized
INFO - 2020-09-20 17:01:12 --> Security Class Initialized
DEBUG - 2020-09-20 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:01:12 --> Input Class Initialized
INFO - 2020-09-20 17:01:12 --> Language Class Initialized
INFO - 2020-09-20 17:01:12 --> Loader Class Initialized
INFO - 2020-09-20 17:01:12 --> Helper loaded: url_helper
INFO - 2020-09-20 17:01:12 --> Database Driver Class Initialized
INFO - 2020-09-20 17:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:01:12 --> Email Class Initialized
INFO - 2020-09-20 17:01:12 --> Controller Class Initialized
DEBUG - 2020-09-20 17:01:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:01:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:01:12 --> Model Class Initialized
INFO - 2020-09-20 17:01:12 --> Model Class Initialized
INFO - 2020-09-20 17:01:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 17:01:12 --> Final output sent to browser
DEBUG - 2020-09-20 17:01:12 --> Total execution time: 0.0274
ERROR - 2020-09-20 17:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:01:15 --> Config Class Initialized
INFO - 2020-09-20 17:01:15 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:01:15 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:01:15 --> Utf8 Class Initialized
INFO - 2020-09-20 17:01:15 --> URI Class Initialized
INFO - 2020-09-20 17:01:15 --> Router Class Initialized
INFO - 2020-09-20 17:01:15 --> Output Class Initialized
INFO - 2020-09-20 17:01:15 --> Security Class Initialized
DEBUG - 2020-09-20 17:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:01:15 --> Input Class Initialized
INFO - 2020-09-20 17:01:15 --> Language Class Initialized
INFO - 2020-09-20 17:01:15 --> Loader Class Initialized
INFO - 2020-09-20 17:01:15 --> Helper loaded: url_helper
INFO - 2020-09-20 17:01:15 --> Database Driver Class Initialized
INFO - 2020-09-20 17:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:01:15 --> Email Class Initialized
INFO - 2020-09-20 17:01:15 --> Controller Class Initialized
DEBUG - 2020-09-20 17:01:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:01:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:01:15 --> Model Class Initialized
INFO - 2020-09-20 17:01:15 --> Model Class Initialized
INFO - 2020-09-20 17:01:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:01:15 --> Final output sent to browser
DEBUG - 2020-09-20 17:01:15 --> Total execution time: 0.0227
ERROR - 2020-09-20 17:01:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:01:26 --> Config Class Initialized
INFO - 2020-09-20 17:01:26 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:01:26 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:01:26 --> Utf8 Class Initialized
INFO - 2020-09-20 17:01:26 --> URI Class Initialized
INFO - 2020-09-20 17:01:26 --> Router Class Initialized
INFO - 2020-09-20 17:01:26 --> Output Class Initialized
INFO - 2020-09-20 17:01:26 --> Security Class Initialized
DEBUG - 2020-09-20 17:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:01:26 --> Input Class Initialized
INFO - 2020-09-20 17:01:26 --> Language Class Initialized
INFO - 2020-09-20 17:01:26 --> Loader Class Initialized
INFO - 2020-09-20 17:01:26 --> Helper loaded: url_helper
INFO - 2020-09-20 17:01:26 --> Database Driver Class Initialized
INFO - 2020-09-20 17:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:01:26 --> Email Class Initialized
INFO - 2020-09-20 17:01:26 --> Controller Class Initialized
DEBUG - 2020-09-20 17:01:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:01:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:01:26 --> Model Class Initialized
INFO - 2020-09-20 17:01:26 --> Model Class Initialized
INFO - 2020-09-20 17:01:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:01:26 --> Final output sent to browser
DEBUG - 2020-09-20 17:01:26 --> Total execution time: 0.0250
ERROR - 2020-09-20 17:01:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:01:34 --> Config Class Initialized
INFO - 2020-09-20 17:01:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:01:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:01:34 --> Utf8 Class Initialized
INFO - 2020-09-20 17:01:34 --> URI Class Initialized
INFO - 2020-09-20 17:01:34 --> Router Class Initialized
INFO - 2020-09-20 17:01:34 --> Output Class Initialized
INFO - 2020-09-20 17:01:34 --> Security Class Initialized
DEBUG - 2020-09-20 17:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:01:34 --> Input Class Initialized
INFO - 2020-09-20 17:01:34 --> Language Class Initialized
INFO - 2020-09-20 17:01:34 --> Loader Class Initialized
INFO - 2020-09-20 17:01:34 --> Helper loaded: url_helper
INFO - 2020-09-20 17:01:34 --> Database Driver Class Initialized
INFO - 2020-09-20 17:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:01:34 --> Email Class Initialized
INFO - 2020-09-20 17:01:34 --> Controller Class Initialized
DEBUG - 2020-09-20 17:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:01:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:01:34 --> Model Class Initialized
INFO - 2020-09-20 17:01:34 --> Model Class Initialized
INFO - 2020-09-20 17:01:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:01:34 --> Final output sent to browser
DEBUG - 2020-09-20 17:01:34 --> Total execution time: 0.0234
ERROR - 2020-09-20 17:02:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:02:43 --> Config Class Initialized
INFO - 2020-09-20 17:02:43 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:02:43 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:02:43 --> Utf8 Class Initialized
INFO - 2020-09-20 17:02:43 --> URI Class Initialized
INFO - 2020-09-20 17:02:43 --> Router Class Initialized
INFO - 2020-09-20 17:02:43 --> Output Class Initialized
INFO - 2020-09-20 17:02:43 --> Security Class Initialized
DEBUG - 2020-09-20 17:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:02:43 --> Input Class Initialized
INFO - 2020-09-20 17:02:43 --> Language Class Initialized
INFO - 2020-09-20 17:02:43 --> Loader Class Initialized
INFO - 2020-09-20 17:02:43 --> Helper loaded: url_helper
INFO - 2020-09-20 17:02:43 --> Database Driver Class Initialized
INFO - 2020-09-20 17:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:02:43 --> Email Class Initialized
INFO - 2020-09-20 17:02:43 --> Controller Class Initialized
DEBUG - 2020-09-20 17:02:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:02:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:02:43 --> Model Class Initialized
INFO - 2020-09-20 17:02:43 --> Model Class Initialized
INFO - 2020-09-20 17:02:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:02:43 --> Final output sent to browser
DEBUG - 2020-09-20 17:02:43 --> Total execution time: 0.0263
ERROR - 2020-09-20 17:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:02:49 --> Config Class Initialized
INFO - 2020-09-20 17:02:49 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:02:49 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:02:49 --> Utf8 Class Initialized
INFO - 2020-09-20 17:02:49 --> URI Class Initialized
INFO - 2020-09-20 17:02:49 --> Router Class Initialized
INFO - 2020-09-20 17:02:49 --> Output Class Initialized
INFO - 2020-09-20 17:02:49 --> Security Class Initialized
DEBUG - 2020-09-20 17:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:02:49 --> Input Class Initialized
INFO - 2020-09-20 17:02:49 --> Language Class Initialized
INFO - 2020-09-20 17:02:49 --> Loader Class Initialized
INFO - 2020-09-20 17:02:49 --> Helper loaded: url_helper
INFO - 2020-09-20 17:02:49 --> Database Driver Class Initialized
INFO - 2020-09-20 17:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:02:49 --> Email Class Initialized
INFO - 2020-09-20 17:02:49 --> Controller Class Initialized
DEBUG - 2020-09-20 17:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:02:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:02:49 --> Model Class Initialized
INFO - 2020-09-20 17:02:49 --> Model Class Initialized
INFO - 2020-09-20 17:02:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:02:49 --> Final output sent to browser
DEBUG - 2020-09-20 17:02:49 --> Total execution time: 0.0252
ERROR - 2020-09-20 17:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:02:59 --> Config Class Initialized
INFO - 2020-09-20 17:02:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:02:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:02:59 --> Utf8 Class Initialized
INFO - 2020-09-20 17:02:59 --> URI Class Initialized
INFO - 2020-09-20 17:02:59 --> Router Class Initialized
INFO - 2020-09-20 17:02:59 --> Output Class Initialized
INFO - 2020-09-20 17:02:59 --> Security Class Initialized
DEBUG - 2020-09-20 17:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:02:59 --> Input Class Initialized
INFO - 2020-09-20 17:02:59 --> Language Class Initialized
INFO - 2020-09-20 17:02:59 --> Loader Class Initialized
INFO - 2020-09-20 17:02:59 --> Helper loaded: url_helper
INFO - 2020-09-20 17:02:59 --> Database Driver Class Initialized
INFO - 2020-09-20 17:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:02:59 --> Email Class Initialized
INFO - 2020-09-20 17:02:59 --> Controller Class Initialized
DEBUG - 2020-09-20 17:02:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:02:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:02:59 --> Model Class Initialized
INFO - 2020-09-20 17:02:59 --> Model Class Initialized
INFO - 2020-09-20 17:02:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:02:59 --> Final output sent to browser
DEBUG - 2020-09-20 17:02:59 --> Total execution time: 0.0213
ERROR - 2020-09-20 17:03:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:03:28 --> Config Class Initialized
INFO - 2020-09-20 17:03:28 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:03:28 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:03:28 --> Utf8 Class Initialized
INFO - 2020-09-20 17:03:28 --> URI Class Initialized
INFO - 2020-09-20 17:03:28 --> Router Class Initialized
INFO - 2020-09-20 17:03:28 --> Output Class Initialized
INFO - 2020-09-20 17:03:28 --> Security Class Initialized
DEBUG - 2020-09-20 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:03:28 --> Input Class Initialized
INFO - 2020-09-20 17:03:28 --> Language Class Initialized
INFO - 2020-09-20 17:03:28 --> Loader Class Initialized
INFO - 2020-09-20 17:03:28 --> Helper loaded: url_helper
INFO - 2020-09-20 17:03:28 --> Database Driver Class Initialized
INFO - 2020-09-20 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:03:28 --> Email Class Initialized
INFO - 2020-09-20 17:03:28 --> Controller Class Initialized
DEBUG - 2020-09-20 17:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:03:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:03:28 --> Model Class Initialized
INFO - 2020-09-20 17:03:28 --> Model Class Initialized
INFO - 2020-09-20 17:03:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:03:28 --> Final output sent to browser
DEBUG - 2020-09-20 17:03:28 --> Total execution time: 0.0262
ERROR - 2020-09-20 17:03:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:03:32 --> Config Class Initialized
INFO - 2020-09-20 17:03:32 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:03:32 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:03:32 --> Utf8 Class Initialized
INFO - 2020-09-20 17:03:32 --> URI Class Initialized
INFO - 2020-09-20 17:03:32 --> Router Class Initialized
INFO - 2020-09-20 17:03:32 --> Output Class Initialized
INFO - 2020-09-20 17:03:32 --> Security Class Initialized
DEBUG - 2020-09-20 17:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:03:32 --> Input Class Initialized
INFO - 2020-09-20 17:03:32 --> Language Class Initialized
INFO - 2020-09-20 17:03:32 --> Loader Class Initialized
INFO - 2020-09-20 17:03:32 --> Helper loaded: url_helper
INFO - 2020-09-20 17:03:32 --> Database Driver Class Initialized
INFO - 2020-09-20 17:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:03:32 --> Email Class Initialized
INFO - 2020-09-20 17:03:32 --> Controller Class Initialized
DEBUG - 2020-09-20 17:03:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:03:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:03:32 --> Model Class Initialized
INFO - 2020-09-20 17:03:32 --> Model Class Initialized
INFO - 2020-09-20 17:03:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:03:32 --> Final output sent to browser
DEBUG - 2020-09-20 17:03:32 --> Total execution time: 0.0286
ERROR - 2020-09-20 17:04:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:04:49 --> Config Class Initialized
INFO - 2020-09-20 17:04:49 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:04:49 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:04:49 --> Utf8 Class Initialized
INFO - 2020-09-20 17:04:49 --> URI Class Initialized
INFO - 2020-09-20 17:04:49 --> Router Class Initialized
INFO - 2020-09-20 17:04:49 --> Output Class Initialized
INFO - 2020-09-20 17:04:49 --> Security Class Initialized
DEBUG - 2020-09-20 17:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:04:49 --> Input Class Initialized
INFO - 2020-09-20 17:04:49 --> Language Class Initialized
INFO - 2020-09-20 17:04:49 --> Loader Class Initialized
INFO - 2020-09-20 17:04:49 --> Helper loaded: url_helper
INFO - 2020-09-20 17:04:49 --> Database Driver Class Initialized
INFO - 2020-09-20 17:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:04:49 --> Email Class Initialized
INFO - 2020-09-20 17:04:49 --> Controller Class Initialized
DEBUG - 2020-09-20 17:04:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:04:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:04:49 --> Model Class Initialized
INFO - 2020-09-20 17:04:49 --> Model Class Initialized
INFO - 2020-09-20 17:04:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:04:49 --> Final output sent to browser
DEBUG - 2020-09-20 17:04:49 --> Total execution time: 0.0228
ERROR - 2020-09-20 17:12:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:12:27 --> Config Class Initialized
INFO - 2020-09-20 17:12:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:12:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:12:27 --> Utf8 Class Initialized
INFO - 2020-09-20 17:12:27 --> URI Class Initialized
INFO - 2020-09-20 17:12:27 --> Router Class Initialized
INFO - 2020-09-20 17:12:27 --> Output Class Initialized
INFO - 2020-09-20 17:12:27 --> Security Class Initialized
DEBUG - 2020-09-20 17:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:12:27 --> Input Class Initialized
INFO - 2020-09-20 17:12:27 --> Language Class Initialized
INFO - 2020-09-20 17:12:27 --> Loader Class Initialized
INFO - 2020-09-20 17:12:27 --> Helper loaded: url_helper
INFO - 2020-09-20 17:12:27 --> Database Driver Class Initialized
INFO - 2020-09-20 17:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:12:27 --> Email Class Initialized
INFO - 2020-09-20 17:12:27 --> Controller Class Initialized
DEBUG - 2020-09-20 17:12:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:12:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:12:27 --> Model Class Initialized
INFO - 2020-09-20 17:12:27 --> Model Class Initialized
INFO - 2020-09-20 17:12:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:12:27 --> Final output sent to browser
DEBUG - 2020-09-20 17:12:27 --> Total execution time: 0.0254
ERROR - 2020-09-20 17:13:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:13:21 --> Config Class Initialized
INFO - 2020-09-20 17:13:21 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:13:21 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:13:21 --> Utf8 Class Initialized
INFO - 2020-09-20 17:13:21 --> URI Class Initialized
INFO - 2020-09-20 17:13:21 --> Router Class Initialized
INFO - 2020-09-20 17:13:21 --> Output Class Initialized
INFO - 2020-09-20 17:13:21 --> Security Class Initialized
DEBUG - 2020-09-20 17:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:13:21 --> Input Class Initialized
INFO - 2020-09-20 17:13:21 --> Language Class Initialized
INFO - 2020-09-20 17:13:21 --> Loader Class Initialized
INFO - 2020-09-20 17:13:21 --> Helper loaded: url_helper
INFO - 2020-09-20 17:13:21 --> Database Driver Class Initialized
INFO - 2020-09-20 17:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:13:21 --> Email Class Initialized
INFO - 2020-09-20 17:13:21 --> Controller Class Initialized
DEBUG - 2020-09-20 17:13:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:13:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:13:21 --> Model Class Initialized
INFO - 2020-09-20 17:13:21 --> Model Class Initialized
INFO - 2020-09-20 17:13:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:13:21 --> Final output sent to browser
DEBUG - 2020-09-20 17:13:21 --> Total execution time: 0.0240
ERROR - 2020-09-20 17:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:13:23 --> Config Class Initialized
INFO - 2020-09-20 17:13:23 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:13:23 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:13:23 --> Utf8 Class Initialized
INFO - 2020-09-20 17:13:23 --> URI Class Initialized
INFO - 2020-09-20 17:13:23 --> Router Class Initialized
INFO - 2020-09-20 17:13:23 --> Output Class Initialized
INFO - 2020-09-20 17:13:23 --> Security Class Initialized
DEBUG - 2020-09-20 17:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:13:23 --> Input Class Initialized
INFO - 2020-09-20 17:13:23 --> Language Class Initialized
INFO - 2020-09-20 17:13:23 --> Loader Class Initialized
INFO - 2020-09-20 17:13:23 --> Helper loaded: url_helper
INFO - 2020-09-20 17:13:23 --> Database Driver Class Initialized
INFO - 2020-09-20 17:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:13:23 --> Email Class Initialized
INFO - 2020-09-20 17:13:23 --> Controller Class Initialized
DEBUG - 2020-09-20 17:13:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:13:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:13:23 --> Model Class Initialized
INFO - 2020-09-20 17:13:23 --> Model Class Initialized
INFO - 2020-09-20 17:13:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:13:23 --> Final output sent to browser
DEBUG - 2020-09-20 17:13:23 --> Total execution time: 0.0231
ERROR - 2020-09-20 17:13:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:13:34 --> Config Class Initialized
INFO - 2020-09-20 17:13:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:13:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:13:34 --> Utf8 Class Initialized
INFO - 2020-09-20 17:13:34 --> URI Class Initialized
INFO - 2020-09-20 17:13:34 --> Router Class Initialized
INFO - 2020-09-20 17:13:34 --> Output Class Initialized
INFO - 2020-09-20 17:13:34 --> Security Class Initialized
DEBUG - 2020-09-20 17:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:13:34 --> Input Class Initialized
INFO - 2020-09-20 17:13:34 --> Language Class Initialized
INFO - 2020-09-20 17:13:34 --> Loader Class Initialized
INFO - 2020-09-20 17:13:34 --> Helper loaded: url_helper
INFO - 2020-09-20 17:13:34 --> Database Driver Class Initialized
INFO - 2020-09-20 17:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:13:34 --> Email Class Initialized
INFO - 2020-09-20 17:13:34 --> Controller Class Initialized
DEBUG - 2020-09-20 17:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:13:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:13:34 --> Model Class Initialized
INFO - 2020-09-20 17:13:34 --> Model Class Initialized
INFO - 2020-09-20 17:13:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:13:34 --> Final output sent to browser
DEBUG - 2020-09-20 17:13:34 --> Total execution time: 0.0192
ERROR - 2020-09-20 17:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:14:29 --> Config Class Initialized
INFO - 2020-09-20 17:14:29 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:14:29 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:14:29 --> Utf8 Class Initialized
INFO - 2020-09-20 17:14:29 --> URI Class Initialized
INFO - 2020-09-20 17:14:29 --> Router Class Initialized
INFO - 2020-09-20 17:14:29 --> Output Class Initialized
INFO - 2020-09-20 17:14:29 --> Security Class Initialized
DEBUG - 2020-09-20 17:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:14:29 --> Input Class Initialized
INFO - 2020-09-20 17:14:29 --> Language Class Initialized
INFO - 2020-09-20 17:14:29 --> Loader Class Initialized
INFO - 2020-09-20 17:14:29 --> Helper loaded: url_helper
INFO - 2020-09-20 17:14:29 --> Database Driver Class Initialized
INFO - 2020-09-20 17:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:14:29 --> Email Class Initialized
INFO - 2020-09-20 17:14:29 --> Controller Class Initialized
DEBUG - 2020-09-20 17:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:14:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:14:29 --> Model Class Initialized
INFO - 2020-09-20 17:14:29 --> Model Class Initialized
INFO - 2020-09-20 17:14:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:14:29 --> Final output sent to browser
DEBUG - 2020-09-20 17:14:29 --> Total execution time: 0.0395
ERROR - 2020-09-20 17:14:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:14:34 --> Config Class Initialized
INFO - 2020-09-20 17:14:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:14:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:14:34 --> Utf8 Class Initialized
INFO - 2020-09-20 17:14:34 --> URI Class Initialized
INFO - 2020-09-20 17:14:34 --> Router Class Initialized
INFO - 2020-09-20 17:14:34 --> Output Class Initialized
INFO - 2020-09-20 17:14:34 --> Security Class Initialized
DEBUG - 2020-09-20 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:14:34 --> Input Class Initialized
INFO - 2020-09-20 17:14:34 --> Language Class Initialized
INFO - 2020-09-20 17:14:34 --> Loader Class Initialized
INFO - 2020-09-20 17:14:34 --> Helper loaded: url_helper
INFO - 2020-09-20 17:14:34 --> Database Driver Class Initialized
INFO - 2020-09-20 17:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:14:34 --> Email Class Initialized
INFO - 2020-09-20 17:14:34 --> Controller Class Initialized
DEBUG - 2020-09-20 17:14:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:14:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:14:34 --> Model Class Initialized
INFO - 2020-09-20 17:14:34 --> Model Class Initialized
INFO - 2020-09-20 17:14:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:14:34 --> Final output sent to browser
DEBUG - 2020-09-20 17:14:34 --> Total execution time: 0.0251
ERROR - 2020-09-20 17:14:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:14:41 --> Config Class Initialized
INFO - 2020-09-20 17:14:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:14:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:14:41 --> Utf8 Class Initialized
INFO - 2020-09-20 17:14:41 --> URI Class Initialized
INFO - 2020-09-20 17:14:41 --> Router Class Initialized
INFO - 2020-09-20 17:14:41 --> Output Class Initialized
INFO - 2020-09-20 17:14:41 --> Security Class Initialized
DEBUG - 2020-09-20 17:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:14:41 --> Input Class Initialized
INFO - 2020-09-20 17:14:41 --> Language Class Initialized
INFO - 2020-09-20 17:14:41 --> Loader Class Initialized
INFO - 2020-09-20 17:14:41 --> Helper loaded: url_helper
INFO - 2020-09-20 17:14:41 --> Database Driver Class Initialized
INFO - 2020-09-20 17:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:14:41 --> Email Class Initialized
INFO - 2020-09-20 17:14:41 --> Controller Class Initialized
DEBUG - 2020-09-20 17:14:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:14:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:14:41 --> Model Class Initialized
INFO - 2020-09-20 17:14:41 --> Model Class Initialized
INFO - 2020-09-20 17:14:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:14:41 --> Final output sent to browser
DEBUG - 2020-09-20 17:14:41 --> Total execution time: 0.0272
ERROR - 2020-09-20 17:15:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:15:55 --> Config Class Initialized
INFO - 2020-09-20 17:15:55 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:15:55 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:15:55 --> Utf8 Class Initialized
INFO - 2020-09-20 17:15:55 --> URI Class Initialized
INFO - 2020-09-20 17:15:55 --> Router Class Initialized
INFO - 2020-09-20 17:15:55 --> Output Class Initialized
INFO - 2020-09-20 17:15:55 --> Security Class Initialized
DEBUG - 2020-09-20 17:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:15:55 --> Input Class Initialized
INFO - 2020-09-20 17:15:55 --> Language Class Initialized
INFO - 2020-09-20 17:15:55 --> Loader Class Initialized
INFO - 2020-09-20 17:15:55 --> Helper loaded: url_helper
INFO - 2020-09-20 17:15:55 --> Database Driver Class Initialized
INFO - 2020-09-20 17:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:15:55 --> Email Class Initialized
INFO - 2020-09-20 17:15:55 --> Controller Class Initialized
DEBUG - 2020-09-20 17:15:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:15:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:15:55 --> Model Class Initialized
INFO - 2020-09-20 17:15:55 --> Model Class Initialized
INFO - 2020-09-20 17:15:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:15:55 --> Final output sent to browser
DEBUG - 2020-09-20 17:15:55 --> Total execution time: 0.0253
ERROR - 2020-09-20 17:18:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:18:09 --> Config Class Initialized
INFO - 2020-09-20 17:18:09 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:18:09 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:18:09 --> Utf8 Class Initialized
INFO - 2020-09-20 17:18:09 --> URI Class Initialized
INFO - 2020-09-20 17:18:09 --> Router Class Initialized
INFO - 2020-09-20 17:18:09 --> Output Class Initialized
INFO - 2020-09-20 17:18:09 --> Security Class Initialized
DEBUG - 2020-09-20 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:18:09 --> Input Class Initialized
INFO - 2020-09-20 17:18:09 --> Language Class Initialized
INFO - 2020-09-20 17:18:09 --> Loader Class Initialized
INFO - 2020-09-20 17:18:09 --> Helper loaded: url_helper
INFO - 2020-09-20 17:18:09 --> Database Driver Class Initialized
INFO - 2020-09-20 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:18:09 --> Email Class Initialized
INFO - 2020-09-20 17:18:09 --> Controller Class Initialized
DEBUG - 2020-09-20 17:18:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:18:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:18:09 --> Model Class Initialized
INFO - 2020-09-20 17:18:09 --> Model Class Initialized
ERROR - 2020-09-20 17:18:09 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_details_list; expected 1, got 0 - Invalid query: CALL client_status_details_list()
INFO - 2020-09-20 17:18:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 17:18:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:18:16 --> Config Class Initialized
INFO - 2020-09-20 17:18:16 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:18:16 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:18:16 --> Utf8 Class Initialized
INFO - 2020-09-20 17:18:16 --> URI Class Initialized
INFO - 2020-09-20 17:18:16 --> Router Class Initialized
INFO - 2020-09-20 17:18:16 --> Output Class Initialized
INFO - 2020-09-20 17:18:16 --> Security Class Initialized
DEBUG - 2020-09-20 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:18:16 --> Input Class Initialized
INFO - 2020-09-20 17:18:16 --> Language Class Initialized
INFO - 2020-09-20 17:18:16 --> Loader Class Initialized
INFO - 2020-09-20 17:18:16 --> Helper loaded: url_helper
INFO - 2020-09-20 17:18:16 --> Database Driver Class Initialized
INFO - 2020-09-20 17:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:18:16 --> Email Class Initialized
INFO - 2020-09-20 17:18:16 --> Controller Class Initialized
DEBUG - 2020-09-20 17:18:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:18:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:18:16 --> Model Class Initialized
INFO - 2020-09-20 17:18:16 --> Model Class Initialized
INFO - 2020-09-20 17:18:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:18:16 --> Final output sent to browser
DEBUG - 2020-09-20 17:18:16 --> Total execution time: 0.0267
ERROR - 2020-09-20 17:18:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:18:20 --> Config Class Initialized
INFO - 2020-09-20 17:18:20 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:18:20 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:18:20 --> Utf8 Class Initialized
INFO - 2020-09-20 17:18:20 --> URI Class Initialized
INFO - 2020-09-20 17:18:20 --> Router Class Initialized
INFO - 2020-09-20 17:18:20 --> Output Class Initialized
INFO - 2020-09-20 17:18:20 --> Security Class Initialized
DEBUG - 2020-09-20 17:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:18:20 --> Input Class Initialized
INFO - 2020-09-20 17:18:20 --> Language Class Initialized
INFO - 2020-09-20 17:18:20 --> Loader Class Initialized
INFO - 2020-09-20 17:18:20 --> Helper loaded: url_helper
INFO - 2020-09-20 17:18:20 --> Database Driver Class Initialized
INFO - 2020-09-20 17:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:18:20 --> Email Class Initialized
INFO - 2020-09-20 17:18:20 --> Controller Class Initialized
DEBUG - 2020-09-20 17:18:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:18:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:18:20 --> Model Class Initialized
INFO - 2020-09-20 17:18:20 --> Model Class Initialized
ERROR - 2020-09-20 17:18:20 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_details_list; expected 1, got 0 - Invalid query: CALL client_status_details_list()
INFO - 2020-09-20 17:18:20 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 17:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:21:29 --> Config Class Initialized
INFO - 2020-09-20 17:21:29 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:21:29 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:21:29 --> Utf8 Class Initialized
INFO - 2020-09-20 17:21:29 --> URI Class Initialized
INFO - 2020-09-20 17:21:29 --> Router Class Initialized
INFO - 2020-09-20 17:21:29 --> Output Class Initialized
INFO - 2020-09-20 17:21:29 --> Security Class Initialized
DEBUG - 2020-09-20 17:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:21:29 --> Input Class Initialized
INFO - 2020-09-20 17:21:29 --> Language Class Initialized
INFO - 2020-09-20 17:21:29 --> Loader Class Initialized
INFO - 2020-09-20 17:21:29 --> Helper loaded: url_helper
INFO - 2020-09-20 17:21:29 --> Database Driver Class Initialized
INFO - 2020-09-20 17:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:21:29 --> Email Class Initialized
INFO - 2020-09-20 17:21:29 --> Controller Class Initialized
DEBUG - 2020-09-20 17:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:21:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:21:29 --> Model Class Initialized
INFO - 2020-09-20 17:21:29 --> Model Class Initialized
INFO - 2020-09-20 17:21:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:21:29 --> Final output sent to browser
DEBUG - 2020-09-20 17:21:29 --> Total execution time: 0.0263
ERROR - 2020-09-20 17:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:25:27 --> Config Class Initialized
INFO - 2020-09-20 17:25:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:27 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:27 --> URI Class Initialized
INFO - 2020-09-20 17:25:27 --> Router Class Initialized
INFO - 2020-09-20 17:25:27 --> Output Class Initialized
INFO - 2020-09-20 17:25:27 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:27 --> Input Class Initialized
INFO - 2020-09-20 17:25:27 --> Language Class Initialized
INFO - 2020-09-20 17:25:27 --> Loader Class Initialized
INFO - 2020-09-20 17:25:27 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:27 --> Database Driver Class Initialized
INFO - 2020-09-20 17:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:27 --> Email Class Initialized
INFO - 2020-09-20 17:25:27 --> Controller Class Initialized
DEBUG - 2020-09-20 17:25:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:25:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:25:27 --> Model Class Initialized
INFO - 2020-09-20 17:25:27 --> Model Class Initialized
INFO - 2020-09-20 17:25:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:25:27 --> Final output sent to browser
DEBUG - 2020-09-20 17:25:27 --> Total execution time: 0.0273
ERROR - 2020-09-20 17:25:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:25:29 --> Config Class Initialized
INFO - 2020-09-20 17:25:29 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:25:29 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:25:29 --> Utf8 Class Initialized
INFO - 2020-09-20 17:25:29 --> URI Class Initialized
INFO - 2020-09-20 17:25:29 --> Router Class Initialized
INFO - 2020-09-20 17:25:29 --> Output Class Initialized
INFO - 2020-09-20 17:25:29 --> Security Class Initialized
DEBUG - 2020-09-20 17:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:25:29 --> Input Class Initialized
INFO - 2020-09-20 17:25:29 --> Language Class Initialized
INFO - 2020-09-20 17:25:29 --> Loader Class Initialized
INFO - 2020-09-20 17:25:29 --> Helper loaded: url_helper
INFO - 2020-09-20 17:25:29 --> Database Driver Class Initialized
INFO - 2020-09-20 17:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:25:29 --> Email Class Initialized
INFO - 2020-09-20 17:25:29 --> Controller Class Initialized
DEBUG - 2020-09-20 17:25:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:25:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:25:29 --> Model Class Initialized
INFO - 2020-09-20 17:25:29 --> Model Class Initialized
ERROR - 2020-09-20 17:25:29 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_edit; expected 1, got 0 - Invalid query: CALL client_status_edit()
INFO - 2020-09-20 17:25:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 17:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:26:34 --> Config Class Initialized
INFO - 2020-09-20 17:26:34 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:26:34 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:26:34 --> Utf8 Class Initialized
INFO - 2020-09-20 17:26:34 --> URI Class Initialized
INFO - 2020-09-20 17:26:34 --> Router Class Initialized
INFO - 2020-09-20 17:26:34 --> Output Class Initialized
INFO - 2020-09-20 17:26:34 --> Security Class Initialized
DEBUG - 2020-09-20 17:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:26:34 --> Input Class Initialized
INFO - 2020-09-20 17:26:34 --> Language Class Initialized
INFO - 2020-09-20 17:26:34 --> Loader Class Initialized
INFO - 2020-09-20 17:26:34 --> Helper loaded: url_helper
INFO - 2020-09-20 17:26:34 --> Database Driver Class Initialized
INFO - 2020-09-20 17:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:26:34 --> Email Class Initialized
INFO - 2020-09-20 17:26:34 --> Controller Class Initialized
DEBUG - 2020-09-20 17:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:26:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:26:34 --> Model Class Initialized
INFO - 2020-09-20 17:26:34 --> Model Class Initialized
INFO - 2020-09-20 17:26:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:26:34 --> Final output sent to browser
DEBUG - 2020-09-20 17:26:34 --> Total execution time: 0.0236
ERROR - 2020-09-20 17:26:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:26:38 --> Config Class Initialized
INFO - 2020-09-20 17:26:38 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:26:38 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:26:38 --> Utf8 Class Initialized
INFO - 2020-09-20 17:26:38 --> URI Class Initialized
INFO - 2020-09-20 17:26:38 --> Router Class Initialized
INFO - 2020-09-20 17:26:38 --> Output Class Initialized
INFO - 2020-09-20 17:26:38 --> Security Class Initialized
DEBUG - 2020-09-20 17:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:26:38 --> Input Class Initialized
INFO - 2020-09-20 17:26:38 --> Language Class Initialized
INFO - 2020-09-20 17:26:38 --> Loader Class Initialized
INFO - 2020-09-20 17:26:38 --> Helper loaded: url_helper
INFO - 2020-09-20 17:26:38 --> Database Driver Class Initialized
INFO - 2020-09-20 17:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:26:38 --> Email Class Initialized
INFO - 2020-09-20 17:26:38 --> Controller Class Initialized
DEBUG - 2020-09-20 17:26:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:26:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:26:38 --> Model Class Initialized
INFO - 2020-09-20 17:26:38 --> Model Class Initialized
ERROR - 2020-09-20 17:26:38 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_edit; expected 1, got 0 - Invalid query: CALL client_status_edit()
INFO - 2020-09-20 17:26:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 17:27:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:27:35 --> Config Class Initialized
INFO - 2020-09-20 17:27:35 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:27:35 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:27:35 --> Utf8 Class Initialized
INFO - 2020-09-20 17:27:35 --> URI Class Initialized
INFO - 2020-09-20 17:27:35 --> Router Class Initialized
INFO - 2020-09-20 17:27:35 --> Output Class Initialized
INFO - 2020-09-20 17:27:35 --> Security Class Initialized
DEBUG - 2020-09-20 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:27:35 --> Input Class Initialized
INFO - 2020-09-20 17:27:35 --> Language Class Initialized
INFO - 2020-09-20 17:27:35 --> Loader Class Initialized
INFO - 2020-09-20 17:27:35 --> Helper loaded: url_helper
INFO - 2020-09-20 17:27:35 --> Database Driver Class Initialized
INFO - 2020-09-20 17:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:27:35 --> Email Class Initialized
INFO - 2020-09-20 17:27:35 --> Controller Class Initialized
DEBUG - 2020-09-20 17:27:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:27:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:27:35 --> Model Class Initialized
INFO - 2020-09-20 17:27:35 --> Model Class Initialized
INFO - 2020-09-20 17:27:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:27:35 --> Final output sent to browser
DEBUG - 2020-09-20 17:27:35 --> Total execution time: 0.0237
ERROR - 2020-09-20 17:27:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:27:42 --> Config Class Initialized
INFO - 2020-09-20 17:27:42 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:27:42 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:27:42 --> Utf8 Class Initialized
INFO - 2020-09-20 17:27:42 --> URI Class Initialized
INFO - 2020-09-20 17:27:42 --> Router Class Initialized
INFO - 2020-09-20 17:27:42 --> Output Class Initialized
INFO - 2020-09-20 17:27:42 --> Security Class Initialized
DEBUG - 2020-09-20 17:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:27:42 --> Input Class Initialized
INFO - 2020-09-20 17:27:42 --> Language Class Initialized
INFO - 2020-09-20 17:27:42 --> Loader Class Initialized
INFO - 2020-09-20 17:27:42 --> Helper loaded: url_helper
INFO - 2020-09-20 17:27:42 --> Database Driver Class Initialized
INFO - 2020-09-20 17:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:27:42 --> Email Class Initialized
INFO - 2020-09-20 17:27:42 --> Controller Class Initialized
DEBUG - 2020-09-20 17:27:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:27:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:27:42 --> Model Class Initialized
INFO - 2020-09-20 17:27:42 --> Model Class Initialized
ERROR - 2020-09-20 17:27:42 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.client_status_edit; expected 1, got 0 - Invalid query: CALL client_status_edit()
INFO - 2020-09-20 17:27:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-20 17:31:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:31:30 --> Config Class Initialized
INFO - 2020-09-20 17:31:30 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:31:30 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:31:30 --> Utf8 Class Initialized
INFO - 2020-09-20 17:31:30 --> URI Class Initialized
INFO - 2020-09-20 17:31:30 --> Router Class Initialized
INFO - 2020-09-20 17:31:30 --> Output Class Initialized
INFO - 2020-09-20 17:31:30 --> Security Class Initialized
DEBUG - 2020-09-20 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:31:30 --> Input Class Initialized
INFO - 2020-09-20 17:31:30 --> Language Class Initialized
INFO - 2020-09-20 17:31:30 --> Loader Class Initialized
INFO - 2020-09-20 17:31:30 --> Helper loaded: url_helper
INFO - 2020-09-20 17:31:30 --> Database Driver Class Initialized
INFO - 2020-09-20 17:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:31:30 --> Email Class Initialized
INFO - 2020-09-20 17:31:30 --> Controller Class Initialized
DEBUG - 2020-09-20 17:31:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:31:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:31:30 --> Model Class Initialized
INFO - 2020-09-20 17:31:30 --> Model Class Initialized
INFO - 2020-09-20 17:31:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:31:30 --> Final output sent to browser
DEBUG - 2020-09-20 17:31:30 --> Total execution time: 0.0299
ERROR - 2020-09-20 17:32:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:32:29 --> Config Class Initialized
INFO - 2020-09-20 17:32:29 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:32:29 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:32:29 --> Utf8 Class Initialized
INFO - 2020-09-20 17:32:29 --> URI Class Initialized
INFO - 2020-09-20 17:32:29 --> Router Class Initialized
INFO - 2020-09-20 17:32:29 --> Output Class Initialized
INFO - 2020-09-20 17:32:29 --> Security Class Initialized
DEBUG - 2020-09-20 17:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:32:29 --> Input Class Initialized
INFO - 2020-09-20 17:32:29 --> Language Class Initialized
INFO - 2020-09-20 17:32:29 --> Loader Class Initialized
INFO - 2020-09-20 17:32:29 --> Helper loaded: url_helper
INFO - 2020-09-20 17:32:29 --> Database Driver Class Initialized
INFO - 2020-09-20 17:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:32:29 --> Email Class Initialized
INFO - 2020-09-20 17:32:29 --> Controller Class Initialized
DEBUG - 2020-09-20 17:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:32:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:32:29 --> Model Class Initialized
INFO - 2020-09-20 17:32:29 --> Model Class Initialized
INFO - 2020-09-20 17:32:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:32:29 --> Final output sent to browser
DEBUG - 2020-09-20 17:32:29 --> Total execution time: 0.3223
ERROR - 2020-09-20 17:32:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:32:32 --> Config Class Initialized
INFO - 2020-09-20 17:32:32 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:32:32 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:32:32 --> Utf8 Class Initialized
INFO - 2020-09-20 17:32:32 --> URI Class Initialized
INFO - 2020-09-20 17:32:32 --> Router Class Initialized
INFO - 2020-09-20 17:32:32 --> Output Class Initialized
INFO - 2020-09-20 17:32:32 --> Security Class Initialized
DEBUG - 2020-09-20 17:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:32:32 --> Input Class Initialized
INFO - 2020-09-20 17:32:32 --> Language Class Initialized
INFO - 2020-09-20 17:32:32 --> Loader Class Initialized
INFO - 2020-09-20 17:32:32 --> Helper loaded: url_helper
INFO - 2020-09-20 17:32:32 --> Database Driver Class Initialized
INFO - 2020-09-20 17:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:32:32 --> Email Class Initialized
INFO - 2020-09-20 17:32:32 --> Controller Class Initialized
DEBUG - 2020-09-20 17:32:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:32:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:32:32 --> Model Class Initialized
INFO - 2020-09-20 17:32:32 --> Model Class Initialized
INFO - 2020-09-20 17:32:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:32:32 --> Final output sent to browser
DEBUG - 2020-09-20 17:32:32 --> Total execution time: 0.0237
ERROR - 2020-09-20 17:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:39:59 --> Config Class Initialized
INFO - 2020-09-20 17:39:59 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:39:59 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:39:59 --> Utf8 Class Initialized
INFO - 2020-09-20 17:39:59 --> URI Class Initialized
INFO - 2020-09-20 17:39:59 --> Router Class Initialized
INFO - 2020-09-20 17:39:59 --> Output Class Initialized
INFO - 2020-09-20 17:39:59 --> Security Class Initialized
DEBUG - 2020-09-20 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:39:59 --> Input Class Initialized
INFO - 2020-09-20 17:39:59 --> Language Class Initialized
INFO - 2020-09-20 17:39:59 --> Loader Class Initialized
INFO - 2020-09-20 17:39:59 --> Helper loaded: url_helper
INFO - 2020-09-20 17:39:59 --> Database Driver Class Initialized
INFO - 2020-09-20 17:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:39:59 --> Email Class Initialized
INFO - 2020-09-20 17:39:59 --> Controller Class Initialized
DEBUG - 2020-09-20 17:39:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:39:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:39:59 --> Model Class Initialized
INFO - 2020-09-20 17:39:59 --> Model Class Initialized
INFO - 2020-09-20 17:39:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:39:59 --> Final output sent to browser
DEBUG - 2020-09-20 17:39:59 --> Total execution time: 0.0234
ERROR - 2020-09-20 17:40:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:40:02 --> Config Class Initialized
INFO - 2020-09-20 17:40:02 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:40:02 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:40:02 --> Utf8 Class Initialized
INFO - 2020-09-20 17:40:02 --> URI Class Initialized
INFO - 2020-09-20 17:40:02 --> Router Class Initialized
INFO - 2020-09-20 17:40:02 --> Output Class Initialized
INFO - 2020-09-20 17:40:02 --> Security Class Initialized
DEBUG - 2020-09-20 17:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:40:02 --> Input Class Initialized
INFO - 2020-09-20 17:40:02 --> Language Class Initialized
INFO - 2020-09-20 17:40:02 --> Loader Class Initialized
INFO - 2020-09-20 17:40:02 --> Helper loaded: url_helper
INFO - 2020-09-20 17:40:02 --> Database Driver Class Initialized
INFO - 2020-09-20 17:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:40:02 --> Email Class Initialized
INFO - 2020-09-20 17:40:02 --> Controller Class Initialized
DEBUG - 2020-09-20 17:40:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:40:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:40:02 --> Model Class Initialized
INFO - 2020-09-20 17:40:02 --> Model Class Initialized
INFO - 2020-09-20 17:40:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:40:02 --> Final output sent to browser
DEBUG - 2020-09-20 17:40:02 --> Total execution time: 0.0243
ERROR - 2020-09-20 17:40:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:40:32 --> Config Class Initialized
INFO - 2020-09-20 17:40:32 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:40:32 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:40:32 --> Utf8 Class Initialized
INFO - 2020-09-20 17:40:32 --> URI Class Initialized
INFO - 2020-09-20 17:40:32 --> Router Class Initialized
INFO - 2020-09-20 17:40:32 --> Output Class Initialized
INFO - 2020-09-20 17:40:32 --> Security Class Initialized
DEBUG - 2020-09-20 17:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:40:32 --> Input Class Initialized
INFO - 2020-09-20 17:40:32 --> Language Class Initialized
INFO - 2020-09-20 17:40:32 --> Loader Class Initialized
INFO - 2020-09-20 17:40:32 --> Helper loaded: url_helper
INFO - 2020-09-20 17:40:32 --> Database Driver Class Initialized
INFO - 2020-09-20 17:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:40:32 --> Email Class Initialized
INFO - 2020-09-20 17:40:32 --> Controller Class Initialized
DEBUG - 2020-09-20 17:40:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:40:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:40:32 --> Model Class Initialized
INFO - 2020-09-20 17:40:32 --> Model Class Initialized
INFO - 2020-09-20 17:40:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:40:32 --> Final output sent to browser
DEBUG - 2020-09-20 17:40:32 --> Total execution time: 0.0281
ERROR - 2020-09-20 17:41:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:41:48 --> Config Class Initialized
INFO - 2020-09-20 17:41:48 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:41:48 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:41:48 --> Utf8 Class Initialized
INFO - 2020-09-20 17:41:48 --> URI Class Initialized
INFO - 2020-09-20 17:41:48 --> Router Class Initialized
INFO - 2020-09-20 17:41:48 --> Output Class Initialized
INFO - 2020-09-20 17:41:48 --> Security Class Initialized
DEBUG - 2020-09-20 17:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:41:48 --> Input Class Initialized
INFO - 2020-09-20 17:41:48 --> Language Class Initialized
INFO - 2020-09-20 17:41:48 --> Loader Class Initialized
INFO - 2020-09-20 17:41:48 --> Helper loaded: url_helper
INFO - 2020-09-20 17:41:48 --> Database Driver Class Initialized
INFO - 2020-09-20 17:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:41:48 --> Email Class Initialized
INFO - 2020-09-20 17:41:48 --> Controller Class Initialized
DEBUG - 2020-09-20 17:41:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:41:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:41:48 --> Model Class Initialized
INFO - 2020-09-20 17:41:48 --> Model Class Initialized
INFO - 2020-09-20 17:41:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:41:48 --> Final output sent to browser
DEBUG - 2020-09-20 17:41:48 --> Total execution time: 0.0265
ERROR - 2020-09-20 17:41:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:41:52 --> Config Class Initialized
INFO - 2020-09-20 17:41:52 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:41:52 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:41:52 --> Utf8 Class Initialized
INFO - 2020-09-20 17:41:52 --> URI Class Initialized
INFO - 2020-09-20 17:41:52 --> Router Class Initialized
INFO - 2020-09-20 17:41:52 --> Output Class Initialized
INFO - 2020-09-20 17:41:52 --> Security Class Initialized
DEBUG - 2020-09-20 17:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:41:52 --> Input Class Initialized
INFO - 2020-09-20 17:41:52 --> Language Class Initialized
INFO - 2020-09-20 17:41:52 --> Loader Class Initialized
INFO - 2020-09-20 17:41:52 --> Helper loaded: url_helper
INFO - 2020-09-20 17:41:52 --> Database Driver Class Initialized
INFO - 2020-09-20 17:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:41:52 --> Email Class Initialized
INFO - 2020-09-20 17:41:52 --> Controller Class Initialized
DEBUG - 2020-09-20 17:41:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:41:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:41:52 --> Model Class Initialized
INFO - 2020-09-20 17:41:52 --> Model Class Initialized
INFO - 2020-09-20 17:41:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:41:52 --> Final output sent to browser
DEBUG - 2020-09-20 17:41:52 --> Total execution time: 0.0247
ERROR - 2020-09-20 17:48:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:12 --> Config Class Initialized
INFO - 2020-09-20 17:48:12 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:12 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:12 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:12 --> URI Class Initialized
INFO - 2020-09-20 17:48:12 --> Router Class Initialized
INFO - 2020-09-20 17:48:12 --> Output Class Initialized
INFO - 2020-09-20 17:48:12 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:12 --> Input Class Initialized
INFO - 2020-09-20 17:48:12 --> Language Class Initialized
INFO - 2020-09-20 17:48:12 --> Loader Class Initialized
INFO - 2020-09-20 17:48:12 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:12 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:12 --> Email Class Initialized
INFO - 2020-09-20 17:48:12 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:12 --> Model Class Initialized
INFO - 2020-09-20 17:48:12 --> Model Class Initialized
INFO - 2020-09-20 17:48:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:48:12 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:12 --> Total execution time: 0.0271
ERROR - 2020-09-20 17:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:17 --> Config Class Initialized
INFO - 2020-09-20 17:48:17 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:17 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:17 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:17 --> URI Class Initialized
INFO - 2020-09-20 17:48:17 --> Router Class Initialized
INFO - 2020-09-20 17:48:17 --> Output Class Initialized
INFO - 2020-09-20 17:48:17 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:17 --> Input Class Initialized
INFO - 2020-09-20 17:48:17 --> Language Class Initialized
INFO - 2020-09-20 17:48:17 --> Loader Class Initialized
INFO - 2020-09-20 17:48:17 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:17 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:17 --> Email Class Initialized
INFO - 2020-09-20 17:48:17 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:17 --> Model Class Initialized
INFO - 2020-09-20 17:48:17 --> Model Class Initialized
INFO - 2020-09-20 17:48:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:48:17 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:17 --> Total execution time: 0.0370
ERROR - 2020-09-20 17:48:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:27 --> Config Class Initialized
INFO - 2020-09-20 17:48:27 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:27 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:27 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:27 --> URI Class Initialized
INFO - 2020-09-20 17:48:27 --> Router Class Initialized
INFO - 2020-09-20 17:48:27 --> Output Class Initialized
INFO - 2020-09-20 17:48:27 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:27 --> Input Class Initialized
INFO - 2020-09-20 17:48:27 --> Language Class Initialized
INFO - 2020-09-20 17:48:27 --> Loader Class Initialized
INFO - 2020-09-20 17:48:27 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:27 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:27 --> Email Class Initialized
INFO - 2020-09-20 17:48:27 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:27 --> Model Class Initialized
INFO - 2020-09-20 17:48:27 --> Model Class Initialized
INFO - 2020-09-20 17:48:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:48:27 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:27 --> Total execution time: 0.0274
ERROR - 2020-09-20 17:48:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:39 --> Config Class Initialized
INFO - 2020-09-20 17:48:39 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:39 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:39 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:39 --> URI Class Initialized
INFO - 2020-09-20 17:48:39 --> Router Class Initialized
INFO - 2020-09-20 17:48:39 --> Output Class Initialized
INFO - 2020-09-20 17:48:39 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:39 --> Input Class Initialized
INFO - 2020-09-20 17:48:39 --> Language Class Initialized
INFO - 2020-09-20 17:48:39 --> Loader Class Initialized
INFO - 2020-09-20 17:48:39 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:39 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:39 --> Email Class Initialized
INFO - 2020-09-20 17:48:39 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:39 --> Model Class Initialized
INFO - 2020-09-20 17:48:39 --> Model Class Initialized
INFO - 2020-09-20 17:48:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:48:39 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:39 --> Total execution time: 0.0224
ERROR - 2020-09-20 17:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:42 --> Config Class Initialized
INFO - 2020-09-20 17:48:42 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:42 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:42 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:42 --> URI Class Initialized
INFO - 2020-09-20 17:48:42 --> Router Class Initialized
INFO - 2020-09-20 17:48:42 --> Output Class Initialized
INFO - 2020-09-20 17:48:42 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:42 --> Input Class Initialized
INFO - 2020-09-20 17:48:42 --> Language Class Initialized
INFO - 2020-09-20 17:48:42 --> Loader Class Initialized
INFO - 2020-09-20 17:48:42 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:42 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:42 --> Email Class Initialized
INFO - 2020-09-20 17:48:42 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:42 --> Model Class Initialized
INFO - 2020-09-20 17:48:42 --> Model Class Initialized
INFO - 2020-09-20 17:48:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:48:42 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:42 --> Total execution time: 0.0248
ERROR - 2020-09-20 17:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:55 --> Config Class Initialized
INFO - 2020-09-20 17:48:55 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:55 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:55 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:55 --> URI Class Initialized
INFO - 2020-09-20 17:48:55 --> Router Class Initialized
INFO - 2020-09-20 17:48:55 --> Output Class Initialized
INFO - 2020-09-20 17:48:55 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:55 --> Input Class Initialized
INFO - 2020-09-20 17:48:55 --> Language Class Initialized
INFO - 2020-09-20 17:48:55 --> Loader Class Initialized
INFO - 2020-09-20 17:48:55 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:55 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:55 --> Email Class Initialized
INFO - 2020-09-20 17:48:55 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:55 --> Model Class Initialized
INFO - 2020-09-20 17:48:55 --> Model Class Initialized
INFO - 2020-09-20 17:48:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:48:55 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:55 --> Total execution time: 0.0304
ERROR - 2020-09-20 17:48:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:48:57 --> Config Class Initialized
INFO - 2020-09-20 17:48:57 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:48:57 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:48:57 --> Utf8 Class Initialized
INFO - 2020-09-20 17:48:57 --> URI Class Initialized
INFO - 2020-09-20 17:48:57 --> Router Class Initialized
INFO - 2020-09-20 17:48:57 --> Output Class Initialized
INFO - 2020-09-20 17:48:57 --> Security Class Initialized
DEBUG - 2020-09-20 17:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:48:57 --> Input Class Initialized
INFO - 2020-09-20 17:48:57 --> Language Class Initialized
INFO - 2020-09-20 17:48:57 --> Loader Class Initialized
INFO - 2020-09-20 17:48:57 --> Helper loaded: url_helper
INFO - 2020-09-20 17:48:57 --> Database Driver Class Initialized
INFO - 2020-09-20 17:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:48:57 --> Email Class Initialized
INFO - 2020-09-20 17:48:57 --> Controller Class Initialized
DEBUG - 2020-09-20 17:48:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:48:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:48:57 --> Model Class Initialized
INFO - 2020-09-20 17:48:57 --> Model Class Initialized
INFO - 2020-09-20 17:48:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:48:57 --> Final output sent to browser
DEBUG - 2020-09-20 17:48:57 --> Total execution time: 0.0257
ERROR - 2020-09-20 17:49:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:12 --> Config Class Initialized
INFO - 2020-09-20 17:49:12 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:12 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:12 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:12 --> URI Class Initialized
INFO - 2020-09-20 17:49:12 --> Router Class Initialized
INFO - 2020-09-20 17:49:12 --> Output Class Initialized
INFO - 2020-09-20 17:49:12 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:12 --> Input Class Initialized
INFO - 2020-09-20 17:49:12 --> Language Class Initialized
INFO - 2020-09-20 17:49:12 --> Loader Class Initialized
INFO - 2020-09-20 17:49:12 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:12 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:12 --> Email Class Initialized
INFO - 2020-09-20 17:49:12 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:12 --> Model Class Initialized
INFO - 2020-09-20 17:49:12 --> Model Class Initialized
INFO - 2020-09-20 17:49:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:49:12 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:12 --> Total execution time: 0.0279
ERROR - 2020-09-20 17:49:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:35 --> Config Class Initialized
INFO - 2020-09-20 17:49:35 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:35 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:35 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:35 --> URI Class Initialized
INFO - 2020-09-20 17:49:35 --> Router Class Initialized
INFO - 2020-09-20 17:49:35 --> Output Class Initialized
INFO - 2020-09-20 17:49:35 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:35 --> Input Class Initialized
INFO - 2020-09-20 17:49:35 --> Language Class Initialized
INFO - 2020-09-20 17:49:35 --> Loader Class Initialized
INFO - 2020-09-20 17:49:35 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:35 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:35 --> Email Class Initialized
INFO - 2020-09-20 17:49:35 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:35 --> Model Class Initialized
INFO - 2020-09-20 17:49:35 --> Model Class Initialized
INFO - 2020-09-20 17:49:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:49:35 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:35 --> Total execution time: 0.0253
ERROR - 2020-09-20 17:49:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:37 --> Config Class Initialized
INFO - 2020-09-20 17:49:37 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:37 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:37 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:37 --> URI Class Initialized
INFO - 2020-09-20 17:49:37 --> Router Class Initialized
INFO - 2020-09-20 17:49:37 --> Output Class Initialized
INFO - 2020-09-20 17:49:37 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:37 --> Input Class Initialized
INFO - 2020-09-20 17:49:37 --> Language Class Initialized
INFO - 2020-09-20 17:49:37 --> Loader Class Initialized
INFO - 2020-09-20 17:49:37 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:37 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:37 --> Email Class Initialized
INFO - 2020-09-20 17:49:37 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:37 --> Model Class Initialized
INFO - 2020-09-20 17:49:37 --> Model Class Initialized
INFO - 2020-09-20 17:49:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:49:37 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:37 --> Total execution time: 0.0241
ERROR - 2020-09-20 17:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:41 --> Config Class Initialized
INFO - 2020-09-20 17:49:41 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:41 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:41 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:41 --> URI Class Initialized
INFO - 2020-09-20 17:49:41 --> Router Class Initialized
INFO - 2020-09-20 17:49:41 --> Output Class Initialized
INFO - 2020-09-20 17:49:41 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:41 --> Input Class Initialized
INFO - 2020-09-20 17:49:41 --> Language Class Initialized
INFO - 2020-09-20 17:49:41 --> Loader Class Initialized
INFO - 2020-09-20 17:49:41 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:41 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:41 --> Email Class Initialized
INFO - 2020-09-20 17:49:41 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:41 --> Model Class Initialized
INFO - 2020-09-20 17:49:41 --> Model Class Initialized
INFO - 2020-09-20 17:49:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:49:41 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:41 --> Total execution time: 0.0254
ERROR - 2020-09-20 17:49:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:46 --> Config Class Initialized
INFO - 2020-09-20 17:49:46 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:46 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:46 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:46 --> URI Class Initialized
INFO - 2020-09-20 17:49:46 --> Router Class Initialized
INFO - 2020-09-20 17:49:46 --> Output Class Initialized
INFO - 2020-09-20 17:49:46 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:46 --> Input Class Initialized
INFO - 2020-09-20 17:49:46 --> Language Class Initialized
INFO - 2020-09-20 17:49:46 --> Loader Class Initialized
INFO - 2020-09-20 17:49:46 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:46 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:46 --> Email Class Initialized
INFO - 2020-09-20 17:49:46 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:46 --> Model Class Initialized
INFO - 2020-09-20 17:49:46 --> Model Class Initialized
INFO - 2020-09-20 17:49:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:49:46 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:46 --> Total execution time: 0.0210
ERROR - 2020-09-20 17:49:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:48 --> Config Class Initialized
INFO - 2020-09-20 17:49:48 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:48 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:48 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:48 --> URI Class Initialized
INFO - 2020-09-20 17:49:48 --> Router Class Initialized
INFO - 2020-09-20 17:49:48 --> Output Class Initialized
INFO - 2020-09-20 17:49:48 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:48 --> Input Class Initialized
INFO - 2020-09-20 17:49:48 --> Language Class Initialized
INFO - 2020-09-20 17:49:48 --> Loader Class Initialized
INFO - 2020-09-20 17:49:48 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:48 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:48 --> Email Class Initialized
INFO - 2020-09-20 17:49:48 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:48 --> Model Class Initialized
INFO - 2020-09-20 17:49:48 --> Model Class Initialized
INFO - 2020-09-20 17:49:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:49:48 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:48 --> Total execution time: 0.0370
ERROR - 2020-09-20 17:49:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:49:53 --> Config Class Initialized
INFO - 2020-09-20 17:49:53 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:49:53 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:49:53 --> Utf8 Class Initialized
INFO - 2020-09-20 17:49:53 --> URI Class Initialized
INFO - 2020-09-20 17:49:53 --> Router Class Initialized
INFO - 2020-09-20 17:49:53 --> Output Class Initialized
INFO - 2020-09-20 17:49:53 --> Security Class Initialized
DEBUG - 2020-09-20 17:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:49:53 --> Input Class Initialized
INFO - 2020-09-20 17:49:53 --> Language Class Initialized
INFO - 2020-09-20 17:49:53 --> Loader Class Initialized
INFO - 2020-09-20 17:49:53 --> Helper loaded: url_helper
INFO - 2020-09-20 17:49:53 --> Database Driver Class Initialized
INFO - 2020-09-20 17:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:49:53 --> Email Class Initialized
INFO - 2020-09-20 17:49:53 --> Controller Class Initialized
DEBUG - 2020-09-20 17:49:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:49:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:49:53 --> Model Class Initialized
INFO - 2020-09-20 17:49:53 --> Model Class Initialized
INFO - 2020-09-20 17:49:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:49:53 --> Final output sent to browser
DEBUG - 2020-09-20 17:49:53 --> Total execution time: 0.0196
ERROR - 2020-09-20 17:50:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:50:54 --> Config Class Initialized
INFO - 2020-09-20 17:50:54 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:50:54 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:50:54 --> Utf8 Class Initialized
INFO - 2020-09-20 17:50:54 --> URI Class Initialized
INFO - 2020-09-20 17:50:54 --> Router Class Initialized
INFO - 2020-09-20 17:50:54 --> Output Class Initialized
INFO - 2020-09-20 17:50:54 --> Security Class Initialized
DEBUG - 2020-09-20 17:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:50:54 --> Input Class Initialized
INFO - 2020-09-20 17:50:54 --> Language Class Initialized
INFO - 2020-09-20 17:50:54 --> Loader Class Initialized
INFO - 2020-09-20 17:50:54 --> Helper loaded: url_helper
INFO - 2020-09-20 17:50:54 --> Database Driver Class Initialized
INFO - 2020-09-20 17:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:50:54 --> Email Class Initialized
INFO - 2020-09-20 17:50:54 --> Controller Class Initialized
DEBUG - 2020-09-20 17:50:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:50:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:50:54 --> Model Class Initialized
INFO - 2020-09-20 17:50:54 --> Model Class Initialized
INFO - 2020-09-20 17:50:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 17:50:54 --> Final output sent to browser
DEBUG - 2020-09-20 17:50:54 --> Total execution time: 0.0272
ERROR - 2020-09-20 17:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:04 --> Config Class Initialized
INFO - 2020-09-20 17:51:04 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:04 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:04 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:04 --> URI Class Initialized
INFO - 2020-09-20 17:51:04 --> Router Class Initialized
INFO - 2020-09-20 17:51:04 --> Output Class Initialized
INFO - 2020-09-20 17:51:04 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:04 --> Input Class Initialized
INFO - 2020-09-20 17:51:04 --> Language Class Initialized
INFO - 2020-09-20 17:51:04 --> Loader Class Initialized
INFO - 2020-09-20 17:51:04 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:04 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:04 --> Email Class Initialized
INFO - 2020-09-20 17:51:04 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:04 --> Model Class Initialized
INFO - 2020-09-20 17:51:04 --> Model Class Initialized
INFO - 2020-09-20 17:51:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:51:04 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:04 --> Total execution time: 0.0249
ERROR - 2020-09-20 17:51:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:08 --> Config Class Initialized
INFO - 2020-09-20 17:51:08 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:08 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:08 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:08 --> URI Class Initialized
INFO - 2020-09-20 17:51:08 --> Router Class Initialized
INFO - 2020-09-20 17:51:08 --> Output Class Initialized
INFO - 2020-09-20 17:51:08 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:08 --> Input Class Initialized
INFO - 2020-09-20 17:51:08 --> Language Class Initialized
INFO - 2020-09-20 17:51:08 --> Loader Class Initialized
INFO - 2020-09-20 17:51:08 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:08 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:08 --> Email Class Initialized
INFO - 2020-09-20 17:51:08 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:08 --> Model Class Initialized
INFO - 2020-09-20 17:51:08 --> Model Class Initialized
INFO - 2020-09-20 17:51:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_update.php
INFO - 2020-09-20 17:51:08 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:08 --> Total execution time: 0.0215
ERROR - 2020-09-20 17:51:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:11 --> Config Class Initialized
INFO - 2020-09-20 17:51:11 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:11 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:11 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:11 --> URI Class Initialized
INFO - 2020-09-20 17:51:11 --> Router Class Initialized
INFO - 2020-09-20 17:51:11 --> Output Class Initialized
INFO - 2020-09-20 17:51:11 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:11 --> Input Class Initialized
INFO - 2020-09-20 17:51:11 --> Language Class Initialized
INFO - 2020-09-20 17:51:11 --> Loader Class Initialized
INFO - 2020-09-20 17:51:11 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:11 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:11 --> Email Class Initialized
INFO - 2020-09-20 17:51:11 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:11 --> Model Class Initialized
INFO - 2020-09-20 17:51:11 --> Model Class Initialized
INFO - 2020-09-20 17:51:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 17:51:11 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:11 --> Total execution time: 0.0247
ERROR - 2020-09-20 17:51:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:15 --> Config Class Initialized
INFO - 2020-09-20 17:51:15 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:15 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:15 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:15 --> URI Class Initialized
INFO - 2020-09-20 17:51:15 --> Router Class Initialized
INFO - 2020-09-20 17:51:15 --> Output Class Initialized
INFO - 2020-09-20 17:51:15 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:15 --> Input Class Initialized
INFO - 2020-09-20 17:51:15 --> Language Class Initialized
INFO - 2020-09-20 17:51:15 --> Loader Class Initialized
INFO - 2020-09-20 17:51:15 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:15 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:15 --> Email Class Initialized
INFO - 2020-09-20 17:51:15 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:15 --> Model Class Initialized
INFO - 2020-09-20 17:51:15 --> Model Class Initialized
INFO - 2020-09-20 17:51:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:51:15 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:15 --> Total execution time: 0.0204
ERROR - 2020-09-20 17:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:18 --> Config Class Initialized
INFO - 2020-09-20 17:51:18 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:18 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:18 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:18 --> URI Class Initialized
INFO - 2020-09-20 17:51:18 --> Router Class Initialized
INFO - 2020-09-20 17:51:18 --> Output Class Initialized
INFO - 2020-09-20 17:51:18 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:18 --> Input Class Initialized
INFO - 2020-09-20 17:51:18 --> Language Class Initialized
INFO - 2020-09-20 17:51:18 --> Loader Class Initialized
INFO - 2020-09-20 17:51:18 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:18 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:18 --> Email Class Initialized
INFO - 2020-09-20 17:51:18 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:18 --> Model Class Initialized
INFO - 2020-09-20 17:51:18 --> Model Class Initialized
INFO - 2020-09-20 17:51:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-09-20 17:51:18 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:18 --> Total execution time: 0.0271
ERROR - 2020-09-20 17:51:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:20 --> Config Class Initialized
INFO - 2020-09-20 17:51:20 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:20 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:20 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:20 --> URI Class Initialized
INFO - 2020-09-20 17:51:20 --> Router Class Initialized
INFO - 2020-09-20 17:51:20 --> Output Class Initialized
INFO - 2020-09-20 17:51:20 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:20 --> Input Class Initialized
INFO - 2020-09-20 17:51:20 --> Language Class Initialized
INFO - 2020-09-20 17:51:20 --> Loader Class Initialized
INFO - 2020-09-20 17:51:20 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:20 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:20 --> Email Class Initialized
INFO - 2020-09-20 17:51:20 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:20 --> Model Class Initialized
INFO - 2020-09-20 17:51:20 --> Model Class Initialized
INFO - 2020-09-20 17:51:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-20 17:51:20 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:20 --> Total execution time: 0.1290
ERROR - 2020-09-20 17:51:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:51:39 --> Config Class Initialized
INFO - 2020-09-20 17:51:39 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:51:39 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:51:39 --> Utf8 Class Initialized
INFO - 2020-09-20 17:51:39 --> URI Class Initialized
INFO - 2020-09-20 17:51:39 --> Router Class Initialized
INFO - 2020-09-20 17:51:39 --> Output Class Initialized
INFO - 2020-09-20 17:51:39 --> Security Class Initialized
DEBUG - 2020-09-20 17:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:51:39 --> Input Class Initialized
INFO - 2020-09-20 17:51:39 --> Language Class Initialized
INFO - 2020-09-20 17:51:39 --> Loader Class Initialized
INFO - 2020-09-20 17:51:39 --> Helper loaded: url_helper
INFO - 2020-09-20 17:51:39 --> Database Driver Class Initialized
INFO - 2020-09-20 17:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:51:39 --> Email Class Initialized
INFO - 2020-09-20 17:51:39 --> Controller Class Initialized
DEBUG - 2020-09-20 17:51:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-20 17:51:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:51:39 --> Model Class Initialized
INFO - 2020-09-20 17:51:39 --> Model Class Initialized
INFO - 2020-09-20 17:51:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-09-20 17:51:39 --> Final output sent to browser
DEBUG - 2020-09-20 17:51:39 --> Total execution time: 0.0275
ERROR - 2020-09-20 17:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-20 17:52:21 --> Config Class Initialized
INFO - 2020-09-20 17:52:21 --> Hooks Class Initialized
DEBUG - 2020-09-20 17:52:21 --> UTF-8 Support Enabled
INFO - 2020-09-20 17:52:21 --> Utf8 Class Initialized
INFO - 2020-09-20 17:52:21 --> URI Class Initialized
DEBUG - 2020-09-20 17:52:21 --> No URI present. Default controller set.
INFO - 2020-09-20 17:52:21 --> Router Class Initialized
INFO - 2020-09-20 17:52:21 --> Output Class Initialized
INFO - 2020-09-20 17:52:21 --> Security Class Initialized
DEBUG - 2020-09-20 17:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-20 17:52:21 --> Input Class Initialized
INFO - 2020-09-20 17:52:21 --> Language Class Initialized
INFO - 2020-09-20 17:52:21 --> Loader Class Initialized
INFO - 2020-09-20 17:52:21 --> Helper loaded: url_helper
INFO - 2020-09-20 17:52:21 --> Database Driver Class Initialized
INFO - 2020-09-20 17:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-20 17:52:21 --> Email Class Initialized
INFO - 2020-09-20 17:52:21 --> Controller Class Initialized
INFO - 2020-09-20 17:52:21 --> Model Class Initialized
INFO - 2020-09-20 17:52:21 --> Model Class Initialized
DEBUG - 2020-09-20 17:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-20 17:52:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-20 17:52:21 --> Final output sent to browser
DEBUG - 2020-09-20 17:52:21 --> Total execution time: 0.0218
