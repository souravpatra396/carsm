<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 06:19:46 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 07:20:20 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 11:17:38 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 11:19:48 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 12:03:12 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 12:03:18 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 15:25:30 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:45:35 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:49:48 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:49:51 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:50:47 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:50:48 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:50:51 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:52:18 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 16:57:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-03 16:57:08 --> Config Class Initialized
INFO - 2020-09-03 16:57:08 --> Hooks Class Initialized
DEBUG - 2020-09-03 16:57:08 --> UTF-8 Support Enabled
INFO - 2020-09-03 16:57:08 --> Utf8 Class Initialized
INFO - 2020-09-03 16:57:08 --> URI Class Initialized
DEBUG - 2020-09-03 16:57:08 --> No URI present. Default controller set.
INFO - 2020-09-03 16:57:08 --> Router Class Initialized
INFO - 2020-09-03 16:57:08 --> Output Class Initialized
INFO - 2020-09-03 16:57:09 --> Security Class Initialized
DEBUG - 2020-09-03 16:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 16:57:09 --> Input Class Initialized
INFO - 2020-09-03 16:57:09 --> Language Class Initialized
INFO - 2020-09-03 16:57:09 --> Loader Class Initialized
INFO - 2020-09-03 16:57:09 --> Helper loaded: url_helper
INFO - 2020-09-03 16:57:09 --> Database Driver Class Initialized
INFO - 2020-09-03 16:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 16:57:09 --> Email Class Initialized
INFO - 2020-09-03 16:57:09 --> Controller Class Initialized
INFO - 2020-09-03 16:57:09 --> Model Class Initialized
INFO - 2020-09-03 16:57:09 --> Model Class Initialized
DEBUG - 2020-09-03 16:57:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-03 16:57:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-03 16:57:09 --> Final output sent to browser
DEBUG - 2020-09-03 16:57:09 --> Total execution time: 0.1376
ERROR - 2020-09-03 17:09:56 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting '&' or variable (T_VARIABLE) /home/purpu1ex/public_html/carsm/vendor/markbaker/complex/classes/src/operations/add.php 18
ERROR - 2020-09-03 17:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-03 17:23:35 --> Config Class Initialized
INFO - 2020-09-03 17:23:35 --> Hooks Class Initialized
DEBUG - 2020-09-03 17:23:35 --> UTF-8 Support Enabled
INFO - 2020-09-03 17:23:35 --> Utf8 Class Initialized
INFO - 2020-09-03 17:23:35 --> URI Class Initialized
DEBUG - 2020-09-03 17:23:35 --> No URI present. Default controller set.
INFO - 2020-09-03 17:23:35 --> Router Class Initialized
INFO - 2020-09-03 17:23:35 --> Output Class Initialized
INFO - 2020-09-03 17:23:35 --> Security Class Initialized
DEBUG - 2020-09-03 17:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-03 17:23:35 --> Input Class Initialized
INFO - 2020-09-03 17:23:35 --> Language Class Initialized
INFO - 2020-09-03 17:23:35 --> Loader Class Initialized
INFO - 2020-09-03 17:23:35 --> Helper loaded: url_helper
INFO - 2020-09-03 17:23:35 --> Database Driver Class Initialized
INFO - 2020-09-03 17:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-03 17:23:35 --> Email Class Initialized
INFO - 2020-09-03 17:23:35 --> Controller Class Initialized
INFO - 2020-09-03 17:23:35 --> Model Class Initialized
INFO - 2020-09-03 17:23:35 --> Model Class Initialized
DEBUG - 2020-09-03 17:23:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-03 17:23:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-03 17:23:35 --> Final output sent to browser
DEBUG - 2020-09-03 17:23:35 --> Total execution time: 0.0205
