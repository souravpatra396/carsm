<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-13 01:12:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-13 01:12:59 --> Config Class Initialized
INFO - 2020-12-13 01:12:59 --> Hooks Class Initialized
DEBUG - 2020-12-13 01:12:59 --> UTF-8 Support Enabled
INFO - 2020-12-13 01:12:59 --> Utf8 Class Initialized
INFO - 2020-12-13 01:12:59 --> URI Class Initialized
DEBUG - 2020-12-13 01:12:59 --> No URI present. Default controller set.
INFO - 2020-12-13 01:12:59 --> Router Class Initialized
INFO - 2020-12-13 01:12:59 --> Output Class Initialized
INFO - 2020-12-13 01:12:59 --> Security Class Initialized
DEBUG - 2020-12-13 01:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-13 01:12:59 --> Input Class Initialized
INFO - 2020-12-13 01:12:59 --> Language Class Initialized
INFO - 2020-12-13 01:12:59 --> Loader Class Initialized
INFO - 2020-12-13 01:12:59 --> Helper loaded: url_helper
INFO - 2020-12-13 01:12:59 --> Database Driver Class Initialized
INFO - 2020-12-13 01:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-13 01:12:59 --> Email Class Initialized
INFO - 2020-12-13 01:12:59 --> Controller Class Initialized
INFO - 2020-12-13 01:12:59 --> Model Class Initialized
INFO - 2020-12-13 01:12:59 --> Model Class Initialized
DEBUG - 2020-12-13 01:12:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-13 01:12:59 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-13 01:12:59 --> Final output sent to browser
DEBUG - 2020-12-13 01:12:59 --> Total execution time: 0.1364
ERROR - 2020-12-13 13:53:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-13 13:53:02 --> Config Class Initialized
INFO - 2020-12-13 13:53:02 --> Hooks Class Initialized
DEBUG - 2020-12-13 13:53:02 --> UTF-8 Support Enabled
INFO - 2020-12-13 13:53:02 --> Utf8 Class Initialized
INFO - 2020-12-13 13:53:02 --> URI Class Initialized
DEBUG - 2020-12-13 13:53:02 --> No URI present. Default controller set.
INFO - 2020-12-13 13:53:02 --> Router Class Initialized
INFO - 2020-12-13 13:53:02 --> Output Class Initialized
INFO - 2020-12-13 13:53:02 --> Security Class Initialized
DEBUG - 2020-12-13 13:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-13 13:53:02 --> Input Class Initialized
INFO - 2020-12-13 13:53:02 --> Language Class Initialized
INFO - 2020-12-13 13:53:02 --> Loader Class Initialized
INFO - 2020-12-13 13:53:02 --> Helper loaded: url_helper
INFO - 2020-12-13 13:53:02 --> Database Driver Class Initialized
INFO - 2020-12-13 13:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-13 13:53:02 --> Email Class Initialized
INFO - 2020-12-13 13:53:02 --> Controller Class Initialized
INFO - 2020-12-13 13:53:02 --> Model Class Initialized
INFO - 2020-12-13 13:53:02 --> Model Class Initialized
DEBUG - 2020-12-13 13:53:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-13 13:53:02 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-13 13:53:02 --> Final output sent to browser
DEBUG - 2020-12-13 13:53:02 --> Total execution time: 0.2002
