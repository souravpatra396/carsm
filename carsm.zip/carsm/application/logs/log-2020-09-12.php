<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-12 05:35:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:35:04 --> Config Class Initialized
INFO - 2020-09-12 05:35:04 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:35:04 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:35:04 --> Utf8 Class Initialized
INFO - 2020-09-12 05:35:04 --> URI Class Initialized
DEBUG - 2020-09-12 05:35:04 --> No URI present. Default controller set.
INFO - 2020-09-12 05:35:04 --> Router Class Initialized
INFO - 2020-09-12 05:35:04 --> Output Class Initialized
INFO - 2020-09-12 05:35:04 --> Security Class Initialized
DEBUG - 2020-09-12 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:35:04 --> Input Class Initialized
INFO - 2020-09-12 05:35:04 --> Language Class Initialized
INFO - 2020-09-12 05:35:04 --> Loader Class Initialized
INFO - 2020-09-12 05:35:04 --> Helper loaded: url_helper
INFO - 2020-09-12 05:35:04 --> Database Driver Class Initialized
INFO - 2020-09-12 05:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:35:04 --> Email Class Initialized
INFO - 2020-09-12 05:35:04 --> Controller Class Initialized
INFO - 2020-09-12 05:35:04 --> Model Class Initialized
INFO - 2020-09-12 05:35:04 --> Model Class Initialized
DEBUG - 2020-09-12 05:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:35:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 05:35:04 --> Final output sent to browser
DEBUG - 2020-09-12 05:35:04 --> Total execution time: 0.1373
ERROR - 2020-09-12 05:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-12 05:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:38:03 --> Config Class Initialized
INFO - 2020-09-12 05:38:03 --> Config Class Initialized
INFO - 2020-09-12 05:38:03 --> Hooks Class Initialized
INFO - 2020-09-12 05:38:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:38:03 --> UTF-8 Support Enabled
DEBUG - 2020-09-12 05:38:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:38:03 --> Utf8 Class Initialized
INFO - 2020-09-12 05:38:03 --> Utf8 Class Initialized
INFO - 2020-09-12 05:38:03 --> URI Class Initialized
INFO - 2020-09-12 05:38:03 --> URI Class Initialized
INFO - 2020-09-12 05:38:03 --> Router Class Initialized
INFO - 2020-09-12 05:38:03 --> Router Class Initialized
INFO - 2020-09-12 05:38:03 --> Output Class Initialized
INFO - 2020-09-12 05:38:03 --> Output Class Initialized
INFO - 2020-09-12 05:38:03 --> Security Class Initialized
INFO - 2020-09-12 05:38:03 --> Security Class Initialized
DEBUG - 2020-09-12 05:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-09-12 05:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:38:03 --> Input Class Initialized
INFO - 2020-09-12 05:38:03 --> Input Class Initialized
INFO - 2020-09-12 05:38:03 --> Language Class Initialized
INFO - 2020-09-12 05:38:03 --> Language Class Initialized
INFO - 2020-09-12 05:38:03 --> Loader Class Initialized
INFO - 2020-09-12 05:38:03 --> Loader Class Initialized
INFO - 2020-09-12 05:38:03 --> Helper loaded: url_helper
INFO - 2020-09-12 05:38:03 --> Helper loaded: url_helper
INFO - 2020-09-12 05:38:03 --> Database Driver Class Initialized
INFO - 2020-09-12 05:38:03 --> Database Driver Class Initialized
INFO - 2020-09-12 05:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:38:03 --> Email Class Initialized
INFO - 2020-09-12 05:38:03 --> Controller Class Initialized
INFO - 2020-09-12 05:38:03 --> Model Class Initialized
INFO - 2020-09-12 05:38:03 --> Model Class Initialized
DEBUG - 2020-09-12 05:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:38:03 --> Email Class Initialized
INFO - 2020-09-12 05:38:03 --> Controller Class Initialized
INFO - 2020-09-12 05:38:03 --> Model Class Initialized
INFO - 2020-09-12 05:38:03 --> Model Class Initialized
DEBUG - 2020-09-12 05:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:38:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:38:03 --> Model Class Initialized
INFO - 2020-09-12 05:38:03 --> Final output sent to browser
DEBUG - 2020-09-12 05:38:03 --> Total execution time: 0.2023
ERROR - 2020-09-12 05:38:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:38:03 --> Config Class Initialized
INFO - 2020-09-12 05:38:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:38:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:38:03 --> Utf8 Class Initialized
INFO - 2020-09-12 05:38:03 --> URI Class Initialized
INFO - 2020-09-12 05:38:03 --> Router Class Initialized
INFO - 2020-09-12 05:38:03 --> Output Class Initialized
INFO - 2020-09-12 05:38:03 --> Security Class Initialized
DEBUG - 2020-09-12 05:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:38:03 --> Input Class Initialized
INFO - 2020-09-12 05:38:03 --> Language Class Initialized
INFO - 2020-09-12 05:38:03 --> Loader Class Initialized
INFO - 2020-09-12 05:38:03 --> Helper loaded: url_helper
INFO - 2020-09-12 05:38:03 --> Database Driver Class Initialized
INFO - 2020-09-12 05:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:38:03 --> Email Class Initialized
INFO - 2020-09-12 05:38:03 --> Controller Class Initialized
DEBUG - 2020-09-12 05:38:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:38:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:38:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 05:38:03 --> Final output sent to browser
DEBUG - 2020-09-12 05:38:03 --> Total execution time: 0.0468
ERROR - 2020-09-12 05:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:38:32 --> Config Class Initialized
INFO - 2020-09-12 05:38:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:38:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:38:32 --> Utf8 Class Initialized
INFO - 2020-09-12 05:38:32 --> URI Class Initialized
INFO - 2020-09-12 05:38:32 --> Router Class Initialized
INFO - 2020-09-12 05:38:32 --> Output Class Initialized
INFO - 2020-09-12 05:38:32 --> Security Class Initialized
DEBUG - 2020-09-12 05:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:38:32 --> Input Class Initialized
INFO - 2020-09-12 05:38:32 --> Language Class Initialized
INFO - 2020-09-12 05:38:32 --> Loader Class Initialized
INFO - 2020-09-12 05:38:32 --> Helper loaded: url_helper
INFO - 2020-09-12 05:38:32 --> Database Driver Class Initialized
INFO - 2020-09-12 05:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:38:32 --> Email Class Initialized
INFO - 2020-09-12 05:38:32 --> Controller Class Initialized
DEBUG - 2020-09-12 05:38:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:38:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:38:32 --> Model Class Initialized
INFO - 2020-09-12 05:38:32 --> Model Class Initialized
INFO - 2020-09-12 05:38:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 05:38:32 --> Final output sent to browser
DEBUG - 2020-09-12 05:38:32 --> Total execution time: 0.0543
ERROR - 2020-09-12 05:49:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:49:42 --> Config Class Initialized
INFO - 2020-09-12 05:49:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:49:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:49:42 --> Utf8 Class Initialized
INFO - 2020-09-12 05:49:42 --> URI Class Initialized
INFO - 2020-09-12 05:49:42 --> Router Class Initialized
INFO - 2020-09-12 05:49:42 --> Output Class Initialized
INFO - 2020-09-12 05:49:42 --> Security Class Initialized
DEBUG - 2020-09-12 05:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:49:42 --> Input Class Initialized
INFO - 2020-09-12 05:49:42 --> Language Class Initialized
INFO - 2020-09-12 05:49:42 --> Loader Class Initialized
INFO - 2020-09-12 05:49:42 --> Helper loaded: url_helper
INFO - 2020-09-12 05:49:42 --> Database Driver Class Initialized
INFO - 2020-09-12 05:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:49:42 --> Email Class Initialized
INFO - 2020-09-12 05:49:42 --> Controller Class Initialized
DEBUG - 2020-09-12 05:49:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:49:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:49:42 --> Model Class Initialized
INFO - 2020-09-12 05:49:42 --> Model Class Initialized
INFO - 2020-09-12 05:49:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 05:49:42 --> Final output sent to browser
DEBUG - 2020-09-12 05:49:42 --> Total execution time: 0.0388
ERROR - 2020-09-12 05:49:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:49:58 --> Config Class Initialized
INFO - 2020-09-12 05:49:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:49:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:49:58 --> Utf8 Class Initialized
INFO - 2020-09-12 05:49:58 --> URI Class Initialized
INFO - 2020-09-12 05:49:58 --> Router Class Initialized
INFO - 2020-09-12 05:49:58 --> Output Class Initialized
INFO - 2020-09-12 05:49:58 --> Security Class Initialized
DEBUG - 2020-09-12 05:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:49:58 --> Input Class Initialized
INFO - 2020-09-12 05:49:58 --> Language Class Initialized
INFO - 2020-09-12 05:49:58 --> Loader Class Initialized
INFO - 2020-09-12 05:49:58 --> Helper loaded: url_helper
INFO - 2020-09-12 05:49:58 --> Database Driver Class Initialized
INFO - 2020-09-12 05:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:49:58 --> Email Class Initialized
INFO - 2020-09-12 05:49:58 --> Controller Class Initialized
DEBUG - 2020-09-12 05:49:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:49:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:49:58 --> Model Class Initialized
INFO - 2020-09-12 05:49:58 --> Model Class Initialized
INFO - 2020-09-12 05:49:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 05:49:58 --> Final output sent to browser
DEBUG - 2020-09-12 05:49:58 --> Total execution time: 0.3445
ERROR - 2020-09-12 05:51:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:51:13 --> Config Class Initialized
INFO - 2020-09-12 05:51:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:51:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:51:13 --> Utf8 Class Initialized
INFO - 2020-09-12 05:51:13 --> URI Class Initialized
INFO - 2020-09-12 05:51:13 --> Router Class Initialized
INFO - 2020-09-12 05:51:13 --> Output Class Initialized
INFO - 2020-09-12 05:51:13 --> Security Class Initialized
DEBUG - 2020-09-12 05:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:51:13 --> Input Class Initialized
INFO - 2020-09-12 05:51:13 --> Language Class Initialized
INFO - 2020-09-12 05:51:13 --> Loader Class Initialized
INFO - 2020-09-12 05:51:13 --> Helper loaded: url_helper
INFO - 2020-09-12 05:51:13 --> Database Driver Class Initialized
INFO - 2020-09-12 05:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:51:13 --> Email Class Initialized
INFO - 2020-09-12 05:51:13 --> Controller Class Initialized
DEBUG - 2020-09-12 05:51:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:51:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:51:13 --> Model Class Initialized
INFO - 2020-09-12 05:51:13 --> Model Class Initialized
INFO - 2020-09-12 05:51:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 05:51:13 --> Final output sent to browser
DEBUG - 2020-09-12 05:51:13 --> Total execution time: 0.0209
ERROR - 2020-09-12 05:52:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:52:12 --> Config Class Initialized
INFO - 2020-09-12 05:52:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:52:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:52:12 --> Utf8 Class Initialized
INFO - 2020-09-12 05:52:12 --> URI Class Initialized
INFO - 2020-09-12 05:52:12 --> Router Class Initialized
INFO - 2020-09-12 05:52:12 --> Output Class Initialized
INFO - 2020-09-12 05:52:12 --> Security Class Initialized
DEBUG - 2020-09-12 05:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:52:12 --> Input Class Initialized
INFO - 2020-09-12 05:52:12 --> Language Class Initialized
INFO - 2020-09-12 05:52:12 --> Loader Class Initialized
INFO - 2020-09-12 05:52:12 --> Helper loaded: url_helper
INFO - 2020-09-12 05:52:12 --> Database Driver Class Initialized
INFO - 2020-09-12 05:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:52:12 --> Email Class Initialized
INFO - 2020-09-12 05:52:12 --> Controller Class Initialized
DEBUG - 2020-09-12 05:52:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:52:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:52:12 --> Model Class Initialized
INFO - 2020-09-12 05:52:12 --> Model Class Initialized
INFO - 2020-09-12 05:52:12 --> Model Class Initialized
INFO - 2020-09-12 05:52:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 05:52:12 --> Final output sent to browser
DEBUG - 2020-09-12 05:52:12 --> Total execution time: 0.0276
ERROR - 2020-09-12 05:57:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:57:38 --> Config Class Initialized
INFO - 2020-09-12 05:57:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:38 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:38 --> URI Class Initialized
INFO - 2020-09-12 05:57:38 --> Router Class Initialized
INFO - 2020-09-12 05:57:38 --> Output Class Initialized
INFO - 2020-09-12 05:57:38 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:38 --> Input Class Initialized
INFO - 2020-09-12 05:57:38 --> Language Class Initialized
INFO - 2020-09-12 05:57:38 --> Loader Class Initialized
INFO - 2020-09-12 05:57:38 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:38 --> Database Driver Class Initialized
INFO - 2020-09-12 05:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:38 --> Email Class Initialized
INFO - 2020-09-12 05:57:38 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:57:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:57:38 --> Model Class Initialized
INFO - 2020-09-12 05:57:38 --> Model Class Initialized
INFO - 2020-09-12 05:57:38 --> Model Class Initialized
INFO - 2020-09-12 05:57:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 05:57:38 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:38 --> Total execution time: 0.0257
ERROR - 2020-09-12 05:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:57:40 --> Config Class Initialized
INFO - 2020-09-12 05:57:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:57:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:57:40 --> Utf8 Class Initialized
INFO - 2020-09-12 05:57:40 --> URI Class Initialized
INFO - 2020-09-12 05:57:40 --> Router Class Initialized
INFO - 2020-09-12 05:57:40 --> Output Class Initialized
INFO - 2020-09-12 05:57:40 --> Security Class Initialized
DEBUG - 2020-09-12 05:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:57:40 --> Input Class Initialized
INFO - 2020-09-12 05:57:40 --> Language Class Initialized
INFO - 2020-09-12 05:57:40 --> Loader Class Initialized
INFO - 2020-09-12 05:57:40 --> Helper loaded: url_helper
INFO - 2020-09-12 05:57:40 --> Database Driver Class Initialized
INFO - 2020-09-12 05:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:57:40 --> Email Class Initialized
INFO - 2020-09-12 05:57:40 --> Controller Class Initialized
DEBUG - 2020-09-12 05:57:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:57:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:57:40 --> Model Class Initialized
INFO - 2020-09-12 05:57:40 --> Model Class Initialized
INFO - 2020-09-12 05:57:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 05:57:40 --> Final output sent to browser
DEBUG - 2020-09-12 05:57:40 --> Total execution time: 0.0222
ERROR - 2020-09-12 05:58:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:58:12 --> Config Class Initialized
INFO - 2020-09-12 05:58:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:58:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:58:12 --> Utf8 Class Initialized
INFO - 2020-09-12 05:58:12 --> URI Class Initialized
INFO - 2020-09-12 05:58:12 --> Router Class Initialized
INFO - 2020-09-12 05:58:12 --> Output Class Initialized
INFO - 2020-09-12 05:58:12 --> Security Class Initialized
DEBUG - 2020-09-12 05:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:58:12 --> Input Class Initialized
INFO - 2020-09-12 05:58:12 --> Language Class Initialized
INFO - 2020-09-12 05:58:12 --> Loader Class Initialized
INFO - 2020-09-12 05:58:12 --> Helper loaded: url_helper
INFO - 2020-09-12 05:58:12 --> Database Driver Class Initialized
INFO - 2020-09-12 05:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:58:12 --> Email Class Initialized
INFO - 2020-09-12 05:58:12 --> Controller Class Initialized
DEBUG - 2020-09-12 05:58:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:58:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:58:12 --> Model Class Initialized
INFO - 2020-09-12 05:58:12 --> Model Class Initialized
INFO - 2020-09-12 05:58:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 05:58:12 --> Final output sent to browser
DEBUG - 2020-09-12 05:58:12 --> Total execution time: 0.0223
ERROR - 2020-09-12 05:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:58:53 --> Config Class Initialized
INFO - 2020-09-12 05:58:53 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:58:53 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:58:53 --> Utf8 Class Initialized
INFO - 2020-09-12 05:58:53 --> URI Class Initialized
INFO - 2020-09-12 05:58:53 --> Router Class Initialized
INFO - 2020-09-12 05:58:53 --> Output Class Initialized
INFO - 2020-09-12 05:58:53 --> Security Class Initialized
DEBUG - 2020-09-12 05:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:58:53 --> Input Class Initialized
INFO - 2020-09-12 05:58:53 --> Language Class Initialized
INFO - 2020-09-12 05:58:53 --> Loader Class Initialized
INFO - 2020-09-12 05:58:53 --> Helper loaded: url_helper
INFO - 2020-09-12 05:58:53 --> Database Driver Class Initialized
INFO - 2020-09-12 05:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:58:53 --> Email Class Initialized
INFO - 2020-09-12 05:58:53 --> Controller Class Initialized
DEBUG - 2020-09-12 05:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:58:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:58:53 --> Model Class Initialized
INFO - 2020-09-12 05:58:53 --> Model Class Initialized
INFO - 2020-09-12 05:58:53 --> Model Class Initialized
ERROR - 2020-09-12 05:58:53 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 05:58:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 05:59:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:59:14 --> Config Class Initialized
INFO - 2020-09-12 05:59:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:59:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:59:14 --> Utf8 Class Initialized
INFO - 2020-09-12 05:59:14 --> URI Class Initialized
INFO - 2020-09-12 05:59:14 --> Router Class Initialized
INFO - 2020-09-12 05:59:14 --> Output Class Initialized
INFO - 2020-09-12 05:59:14 --> Security Class Initialized
DEBUG - 2020-09-12 05:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:59:14 --> Input Class Initialized
INFO - 2020-09-12 05:59:14 --> Language Class Initialized
INFO - 2020-09-12 05:59:14 --> Loader Class Initialized
INFO - 2020-09-12 05:59:14 --> Helper loaded: url_helper
INFO - 2020-09-12 05:59:14 --> Database Driver Class Initialized
INFO - 2020-09-12 05:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:59:14 --> Email Class Initialized
INFO - 2020-09-12 05:59:14 --> Controller Class Initialized
DEBUG - 2020-09-12 05:59:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:59:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:59:14 --> Model Class Initialized
INFO - 2020-09-12 05:59:14 --> Model Class Initialized
INFO - 2020-09-12 05:59:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 05:59:14 --> Final output sent to browser
DEBUG - 2020-09-12 05:59:14 --> Total execution time: 0.0245
ERROR - 2020-09-12 05:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 05:59:16 --> Config Class Initialized
INFO - 2020-09-12 05:59:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 05:59:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 05:59:16 --> Utf8 Class Initialized
INFO - 2020-09-12 05:59:16 --> URI Class Initialized
INFO - 2020-09-12 05:59:16 --> Router Class Initialized
INFO - 2020-09-12 05:59:16 --> Output Class Initialized
INFO - 2020-09-12 05:59:16 --> Security Class Initialized
DEBUG - 2020-09-12 05:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 05:59:16 --> Input Class Initialized
INFO - 2020-09-12 05:59:16 --> Language Class Initialized
INFO - 2020-09-12 05:59:16 --> Loader Class Initialized
INFO - 2020-09-12 05:59:16 --> Helper loaded: url_helper
INFO - 2020-09-12 05:59:16 --> Database Driver Class Initialized
INFO - 2020-09-12 05:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 05:59:16 --> Email Class Initialized
INFO - 2020-09-12 05:59:16 --> Controller Class Initialized
DEBUG - 2020-09-12 05:59:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 05:59:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 05:59:16 --> Model Class Initialized
INFO - 2020-09-12 05:59:16 --> Model Class Initialized
INFO - 2020-09-12 05:59:16 --> Model Class Initialized
ERROR - 2020-09-12 05:59:16 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 05:59:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:00:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:00:29 --> Config Class Initialized
INFO - 2020-09-12 06:00:29 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:00:29 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:00:29 --> Utf8 Class Initialized
INFO - 2020-09-12 06:00:29 --> URI Class Initialized
INFO - 2020-09-12 06:00:29 --> Router Class Initialized
INFO - 2020-09-12 06:00:29 --> Output Class Initialized
INFO - 2020-09-12 06:00:29 --> Security Class Initialized
DEBUG - 2020-09-12 06:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:00:29 --> Input Class Initialized
INFO - 2020-09-12 06:00:29 --> Language Class Initialized
INFO - 2020-09-12 06:00:29 --> Loader Class Initialized
INFO - 2020-09-12 06:00:29 --> Helper loaded: url_helper
INFO - 2020-09-12 06:00:29 --> Database Driver Class Initialized
INFO - 2020-09-12 06:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:00:29 --> Email Class Initialized
INFO - 2020-09-12 06:00:29 --> Controller Class Initialized
DEBUG - 2020-09-12 06:00:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:00:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:00:29 --> Model Class Initialized
INFO - 2020-09-12 06:00:29 --> Model Class Initialized
INFO - 2020-09-12 06:00:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:00:29 --> Final output sent to browser
DEBUG - 2020-09-12 06:00:29 --> Total execution time: 0.0235
ERROR - 2020-09-12 06:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:00:32 --> Config Class Initialized
INFO - 2020-09-12 06:00:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:00:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:00:32 --> Utf8 Class Initialized
INFO - 2020-09-12 06:00:32 --> URI Class Initialized
INFO - 2020-09-12 06:00:32 --> Router Class Initialized
INFO - 2020-09-12 06:00:32 --> Output Class Initialized
INFO - 2020-09-12 06:00:32 --> Security Class Initialized
DEBUG - 2020-09-12 06:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:00:32 --> Input Class Initialized
INFO - 2020-09-12 06:00:32 --> Language Class Initialized
INFO - 2020-09-12 06:00:32 --> Loader Class Initialized
INFO - 2020-09-12 06:00:32 --> Helper loaded: url_helper
INFO - 2020-09-12 06:00:32 --> Database Driver Class Initialized
INFO - 2020-09-12 06:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:00:32 --> Email Class Initialized
INFO - 2020-09-12 06:00:32 --> Controller Class Initialized
DEBUG - 2020-09-12 06:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:00:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:00:32 --> Model Class Initialized
INFO - 2020-09-12 06:00:32 --> Model Class Initialized
INFO - 2020-09-12 06:00:32 --> Model Class Initialized
INFO - 2020-09-12 06:00:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 06:00:32 --> Final output sent to browser
DEBUG - 2020-09-12 06:00:32 --> Total execution time: 0.0240
ERROR - 2020-09-12 06:00:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:00:51 --> Config Class Initialized
INFO - 2020-09-12 06:00:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:00:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:00:51 --> Utf8 Class Initialized
INFO - 2020-09-12 06:00:51 --> URI Class Initialized
INFO - 2020-09-12 06:00:51 --> Router Class Initialized
INFO - 2020-09-12 06:00:51 --> Output Class Initialized
INFO - 2020-09-12 06:00:51 --> Security Class Initialized
DEBUG - 2020-09-12 06:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:00:51 --> Input Class Initialized
INFO - 2020-09-12 06:00:51 --> Language Class Initialized
INFO - 2020-09-12 06:00:51 --> Loader Class Initialized
INFO - 2020-09-12 06:00:51 --> Helper loaded: url_helper
INFO - 2020-09-12 06:00:51 --> Database Driver Class Initialized
INFO - 2020-09-12 06:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:00:51 --> Email Class Initialized
INFO - 2020-09-12 06:00:51 --> Controller Class Initialized
DEBUG - 2020-09-12 06:00:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:00:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:00:51 --> Model Class Initialized
INFO - 2020-09-12 06:00:51 --> Model Class Initialized
INFO - 2020-09-12 06:00:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:00:51 --> Final output sent to browser
DEBUG - 2020-09-12 06:00:51 --> Total execution time: 0.0222
ERROR - 2020-09-12 06:00:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:00:56 --> Config Class Initialized
INFO - 2020-09-12 06:00:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:00:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:00:56 --> Utf8 Class Initialized
INFO - 2020-09-12 06:00:56 --> URI Class Initialized
INFO - 2020-09-12 06:00:56 --> Router Class Initialized
INFO - 2020-09-12 06:00:56 --> Output Class Initialized
INFO - 2020-09-12 06:00:56 --> Security Class Initialized
DEBUG - 2020-09-12 06:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:00:56 --> Input Class Initialized
INFO - 2020-09-12 06:00:56 --> Language Class Initialized
INFO - 2020-09-12 06:00:56 --> Loader Class Initialized
INFO - 2020-09-12 06:00:56 --> Helper loaded: url_helper
INFO - 2020-09-12 06:00:56 --> Database Driver Class Initialized
INFO - 2020-09-12 06:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:00:56 --> Email Class Initialized
INFO - 2020-09-12 06:00:56 --> Controller Class Initialized
DEBUG - 2020-09-12 06:00:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:00:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:00:56 --> Model Class Initialized
INFO - 2020-09-12 06:00:56 --> Model Class Initialized
INFO - 2020-09-12 06:00:56 --> Model Class Initialized
ERROR - 2020-09-12 06:00:56 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(4)
INFO - 2020-09-12 06:00:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:02:52 --> Config Class Initialized
INFO - 2020-09-12 06:02:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:02:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:02:52 --> Utf8 Class Initialized
INFO - 2020-09-12 06:02:52 --> URI Class Initialized
INFO - 2020-09-12 06:02:52 --> Router Class Initialized
INFO - 2020-09-12 06:02:52 --> Output Class Initialized
INFO - 2020-09-12 06:02:52 --> Security Class Initialized
DEBUG - 2020-09-12 06:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:02:52 --> Input Class Initialized
INFO - 2020-09-12 06:02:52 --> Language Class Initialized
INFO - 2020-09-12 06:02:52 --> Loader Class Initialized
INFO - 2020-09-12 06:02:52 --> Helper loaded: url_helper
INFO - 2020-09-12 06:02:52 --> Database Driver Class Initialized
INFO - 2020-09-12 06:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:02:52 --> Email Class Initialized
INFO - 2020-09-12 06:02:52 --> Controller Class Initialized
DEBUG - 2020-09-12 06:02:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:02:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:02:52 --> Model Class Initialized
INFO - 2020-09-12 06:02:52 --> Model Class Initialized
INFO - 2020-09-12 06:02:52 --> Model Class Initialized
ERROR - 2020-09-12 06:02:52 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(4)
INFO - 2020-09-12 06:02:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:05:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:05:33 --> Config Class Initialized
INFO - 2020-09-12 06:05:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:05:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:05:33 --> Utf8 Class Initialized
INFO - 2020-09-12 06:05:33 --> URI Class Initialized
INFO - 2020-09-12 06:05:33 --> Router Class Initialized
INFO - 2020-09-12 06:05:33 --> Output Class Initialized
INFO - 2020-09-12 06:05:33 --> Security Class Initialized
DEBUG - 2020-09-12 06:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:05:33 --> Input Class Initialized
INFO - 2020-09-12 06:05:33 --> Language Class Initialized
INFO - 2020-09-12 06:05:33 --> Loader Class Initialized
INFO - 2020-09-12 06:05:33 --> Helper loaded: url_helper
INFO - 2020-09-12 06:05:33 --> Database Driver Class Initialized
INFO - 2020-09-12 06:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:05:33 --> Email Class Initialized
INFO - 2020-09-12 06:05:33 --> Controller Class Initialized
DEBUG - 2020-09-12 06:05:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:05:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:05:33 --> Model Class Initialized
INFO - 2020-09-12 06:05:33 --> Model Class Initialized
INFO - 2020-09-12 06:05:33 --> Model Class Initialized
INFO - 2020-09-12 06:05:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 06:05:33 --> Final output sent to browser
DEBUG - 2020-09-12 06:05:33 --> Total execution time: 0.0234
ERROR - 2020-09-12 06:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:08:09 --> Config Class Initialized
INFO - 2020-09-12 06:08:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:08:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:08:09 --> Utf8 Class Initialized
INFO - 2020-09-12 06:08:09 --> URI Class Initialized
INFO - 2020-09-12 06:08:09 --> Router Class Initialized
INFO - 2020-09-12 06:08:09 --> Output Class Initialized
INFO - 2020-09-12 06:08:09 --> Security Class Initialized
DEBUG - 2020-09-12 06:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:08:09 --> Input Class Initialized
INFO - 2020-09-12 06:08:09 --> Language Class Initialized
INFO - 2020-09-12 06:08:09 --> Loader Class Initialized
INFO - 2020-09-12 06:08:09 --> Helper loaded: url_helper
INFO - 2020-09-12 06:08:09 --> Database Driver Class Initialized
INFO - 2020-09-12 06:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:08:09 --> Email Class Initialized
INFO - 2020-09-12 06:08:09 --> Controller Class Initialized
DEBUG - 2020-09-12 06:08:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:08:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:08:09 --> Model Class Initialized
INFO - 2020-09-12 06:08:09 --> Model Class Initialized
INFO - 2020-09-12 06:08:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:08:09 --> Final output sent to browser
DEBUG - 2020-09-12 06:08:09 --> Total execution time: 0.0249
ERROR - 2020-09-12 06:08:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:08:11 --> Config Class Initialized
INFO - 2020-09-12 06:08:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:08:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:08:11 --> Utf8 Class Initialized
INFO - 2020-09-12 06:08:11 --> URI Class Initialized
INFO - 2020-09-12 06:08:11 --> Router Class Initialized
INFO - 2020-09-12 06:08:11 --> Output Class Initialized
INFO - 2020-09-12 06:08:11 --> Security Class Initialized
DEBUG - 2020-09-12 06:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:08:11 --> Input Class Initialized
INFO - 2020-09-12 06:08:11 --> Language Class Initialized
INFO - 2020-09-12 06:08:11 --> Loader Class Initialized
INFO - 2020-09-12 06:08:11 --> Helper loaded: url_helper
INFO - 2020-09-12 06:08:11 --> Database Driver Class Initialized
INFO - 2020-09-12 06:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:08:11 --> Email Class Initialized
INFO - 2020-09-12 06:08:11 --> Controller Class Initialized
DEBUG - 2020-09-12 06:08:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:08:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:08:11 --> Model Class Initialized
INFO - 2020-09-12 06:08:11 --> Model Class Initialized
INFO - 2020-09-12 06:08:11 --> Model Class Initialized
INFO - 2020-09-12 06:08:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 06:08:11 --> Final output sent to browser
DEBUG - 2020-09-12 06:08:11 --> Total execution time: 0.0200
ERROR - 2020-09-12 06:08:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:08:34 --> Config Class Initialized
INFO - 2020-09-12 06:08:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:08:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:08:34 --> Utf8 Class Initialized
INFO - 2020-09-12 06:08:34 --> URI Class Initialized
INFO - 2020-09-12 06:08:34 --> Router Class Initialized
INFO - 2020-09-12 06:08:34 --> Output Class Initialized
INFO - 2020-09-12 06:08:34 --> Security Class Initialized
DEBUG - 2020-09-12 06:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:08:34 --> Input Class Initialized
INFO - 2020-09-12 06:08:34 --> Language Class Initialized
INFO - 2020-09-12 06:08:34 --> Loader Class Initialized
INFO - 2020-09-12 06:08:34 --> Helper loaded: url_helper
INFO - 2020-09-12 06:08:34 --> Database Driver Class Initialized
INFO - 2020-09-12 06:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:08:34 --> Email Class Initialized
INFO - 2020-09-12 06:08:34 --> Controller Class Initialized
DEBUG - 2020-09-12 06:08:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:08:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:08:34 --> Model Class Initialized
INFO - 2020-09-12 06:08:34 --> Model Class Initialized
INFO - 2020-09-12 06:08:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:08:34 --> Final output sent to browser
DEBUG - 2020-09-12 06:08:34 --> Total execution time: 0.0554
ERROR - 2020-09-12 06:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:11:49 --> Config Class Initialized
INFO - 2020-09-12 06:11:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:11:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:11:49 --> Utf8 Class Initialized
INFO - 2020-09-12 06:11:49 --> URI Class Initialized
INFO - 2020-09-12 06:11:49 --> Router Class Initialized
INFO - 2020-09-12 06:11:49 --> Output Class Initialized
INFO - 2020-09-12 06:11:49 --> Security Class Initialized
DEBUG - 2020-09-12 06:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:11:49 --> Input Class Initialized
INFO - 2020-09-12 06:11:49 --> Language Class Initialized
INFO - 2020-09-12 06:11:49 --> Loader Class Initialized
INFO - 2020-09-12 06:11:49 --> Helper loaded: url_helper
INFO - 2020-09-12 06:11:49 --> Database Driver Class Initialized
INFO - 2020-09-12 06:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:11:49 --> Email Class Initialized
INFO - 2020-09-12 06:11:49 --> Controller Class Initialized
DEBUG - 2020-09-12 06:11:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:11:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:11:49 --> Model Class Initialized
INFO - 2020-09-12 06:11:49 --> Model Class Initialized
INFO - 2020-09-12 06:11:49 --> Model Class Initialized
INFO - 2020-09-12 06:11:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 06:11:49 --> Final output sent to browser
DEBUG - 2020-09-12 06:11:49 --> Total execution time: 0.0257
ERROR - 2020-09-12 06:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:12:08 --> Config Class Initialized
INFO - 2020-09-12 06:12:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:12:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:12:08 --> Utf8 Class Initialized
INFO - 2020-09-12 06:12:08 --> URI Class Initialized
INFO - 2020-09-12 06:12:08 --> Router Class Initialized
INFO - 2020-09-12 06:12:08 --> Output Class Initialized
INFO - 2020-09-12 06:12:08 --> Security Class Initialized
DEBUG - 2020-09-12 06:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:12:08 --> Input Class Initialized
INFO - 2020-09-12 06:12:08 --> Language Class Initialized
INFO - 2020-09-12 06:12:08 --> Loader Class Initialized
INFO - 2020-09-12 06:12:08 --> Helper loaded: url_helper
INFO - 2020-09-12 06:12:08 --> Database Driver Class Initialized
INFO - 2020-09-12 06:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:12:08 --> Email Class Initialized
INFO - 2020-09-12 06:12:08 --> Controller Class Initialized
DEBUG - 2020-09-12 06:12:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:12:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:12:08 --> Model Class Initialized
INFO - 2020-09-12 06:12:08 --> Model Class Initialized
INFO - 2020-09-12 06:12:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:12:08 --> Final output sent to browser
DEBUG - 2020-09-12 06:12:08 --> Total execution time: 0.0234
ERROR - 2020-09-12 06:14:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:14:06 --> Config Class Initialized
INFO - 2020-09-12 06:14:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:14:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:14:06 --> Utf8 Class Initialized
INFO - 2020-09-12 06:14:06 --> URI Class Initialized
INFO - 2020-09-12 06:14:06 --> Router Class Initialized
INFO - 2020-09-12 06:14:06 --> Output Class Initialized
INFO - 2020-09-12 06:14:06 --> Security Class Initialized
DEBUG - 2020-09-12 06:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:14:06 --> Input Class Initialized
INFO - 2020-09-12 06:14:06 --> Language Class Initialized
INFO - 2020-09-12 06:14:06 --> Loader Class Initialized
INFO - 2020-09-12 06:14:06 --> Helper loaded: url_helper
INFO - 2020-09-12 06:14:06 --> Database Driver Class Initialized
INFO - 2020-09-12 06:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:14:06 --> Email Class Initialized
INFO - 2020-09-12 06:14:06 --> Controller Class Initialized
DEBUG - 2020-09-12 06:14:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:14:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:14:06 --> Model Class Initialized
INFO - 2020-09-12 06:14:06 --> Model Class Initialized
INFO - 2020-09-12 06:14:06 --> Model Class Initialized
INFO - 2020-09-12 06:14:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 06:14:06 --> Final output sent to browser
DEBUG - 2020-09-12 06:14:06 --> Total execution time: 0.0226
ERROR - 2020-09-12 06:14:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:14:32 --> Config Class Initialized
INFO - 2020-09-12 06:14:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:14:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:14:32 --> Utf8 Class Initialized
INFO - 2020-09-12 06:14:32 --> URI Class Initialized
INFO - 2020-09-12 06:14:32 --> Router Class Initialized
INFO - 2020-09-12 06:14:32 --> Output Class Initialized
INFO - 2020-09-12 06:14:32 --> Security Class Initialized
DEBUG - 2020-09-12 06:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:14:32 --> Input Class Initialized
INFO - 2020-09-12 06:14:32 --> Language Class Initialized
INFO - 2020-09-12 06:14:32 --> Loader Class Initialized
INFO - 2020-09-12 06:14:32 --> Helper loaded: url_helper
INFO - 2020-09-12 06:14:32 --> Database Driver Class Initialized
INFO - 2020-09-12 06:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:14:32 --> Email Class Initialized
INFO - 2020-09-12 06:14:32 --> Controller Class Initialized
DEBUG - 2020-09-12 06:14:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:14:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:14:32 --> Model Class Initialized
INFO - 2020-09-12 06:14:32 --> Model Class Initialized
INFO - 2020-09-12 06:14:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:14:32 --> Final output sent to browser
DEBUG - 2020-09-12 06:14:32 --> Total execution time: 0.5198
ERROR - 2020-09-12 06:14:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:14:45 --> Config Class Initialized
INFO - 2020-09-12 06:14:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:14:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:14:45 --> Utf8 Class Initialized
INFO - 2020-09-12 06:14:45 --> URI Class Initialized
INFO - 2020-09-12 06:14:45 --> Router Class Initialized
INFO - 2020-09-12 06:14:45 --> Output Class Initialized
INFO - 2020-09-12 06:14:45 --> Security Class Initialized
DEBUG - 2020-09-12 06:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:14:45 --> Input Class Initialized
INFO - 2020-09-12 06:14:45 --> Language Class Initialized
INFO - 2020-09-12 06:14:45 --> Loader Class Initialized
INFO - 2020-09-12 06:14:45 --> Helper loaded: url_helper
INFO - 2020-09-12 06:14:45 --> Database Driver Class Initialized
INFO - 2020-09-12 06:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:14:45 --> Email Class Initialized
INFO - 2020-09-12 06:14:45 --> Controller Class Initialized
DEBUG - 2020-09-12 06:14:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:14:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:14:45 --> Model Class Initialized
INFO - 2020-09-12 06:14:45 --> Model Class Initialized
INFO - 2020-09-12 06:14:45 --> Model Class Initialized
INFO - 2020-09-12 06:14:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 06:14:45 --> Final output sent to browser
DEBUG - 2020-09-12 06:14:45 --> Total execution time: 0.0228
ERROR - 2020-09-12 06:15:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:15:15 --> Config Class Initialized
INFO - 2020-09-12 06:15:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:15:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:15:15 --> Utf8 Class Initialized
INFO - 2020-09-12 06:15:15 --> URI Class Initialized
INFO - 2020-09-12 06:15:15 --> Router Class Initialized
INFO - 2020-09-12 06:15:15 --> Output Class Initialized
INFO - 2020-09-12 06:15:15 --> Security Class Initialized
DEBUG - 2020-09-12 06:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:15:15 --> Input Class Initialized
INFO - 2020-09-12 06:15:15 --> Language Class Initialized
INFO - 2020-09-12 06:15:15 --> Loader Class Initialized
INFO - 2020-09-12 06:15:15 --> Helper loaded: url_helper
INFO - 2020-09-12 06:15:15 --> Database Driver Class Initialized
INFO - 2020-09-12 06:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:15:15 --> Email Class Initialized
INFO - 2020-09-12 06:15:15 --> Controller Class Initialized
DEBUG - 2020-09-12 06:15:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:15:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:15:15 --> Model Class Initialized
INFO - 2020-09-12 06:15:15 --> Model Class Initialized
INFO - 2020-09-12 06:15:15 --> Model Class Initialized
ERROR - 2020-09-12 06:15:15 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(7)
INFO - 2020-09-12 06:15:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:16:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:16:07 --> Config Class Initialized
INFO - 2020-09-12 06:16:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:16:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:16:07 --> Utf8 Class Initialized
INFO - 2020-09-12 06:16:07 --> URI Class Initialized
INFO - 2020-09-12 06:16:07 --> Router Class Initialized
INFO - 2020-09-12 06:16:07 --> Output Class Initialized
INFO - 2020-09-12 06:16:07 --> Security Class Initialized
DEBUG - 2020-09-12 06:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:16:07 --> Input Class Initialized
INFO - 2020-09-12 06:16:07 --> Language Class Initialized
INFO - 2020-09-12 06:16:07 --> Loader Class Initialized
INFO - 2020-09-12 06:16:07 --> Helper loaded: url_helper
INFO - 2020-09-12 06:16:07 --> Database Driver Class Initialized
INFO - 2020-09-12 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:16:07 --> Email Class Initialized
INFO - 2020-09-12 06:16:07 --> Controller Class Initialized
DEBUG - 2020-09-12 06:16:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:16:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:16:07 --> Model Class Initialized
INFO - 2020-09-12 06:16:07 --> Model Class Initialized
INFO - 2020-09-12 06:16:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:16:07 --> Final output sent to browser
DEBUG - 2020-09-12 06:16:07 --> Total execution time: 0.0238
ERROR - 2020-09-12 06:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:16:11 --> Config Class Initialized
INFO - 2020-09-12 06:16:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:16:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:16:11 --> Utf8 Class Initialized
INFO - 2020-09-12 06:16:11 --> URI Class Initialized
INFO - 2020-09-12 06:16:11 --> Router Class Initialized
INFO - 2020-09-12 06:16:11 --> Output Class Initialized
INFO - 2020-09-12 06:16:11 --> Security Class Initialized
DEBUG - 2020-09-12 06:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:16:11 --> Input Class Initialized
INFO - 2020-09-12 06:16:11 --> Language Class Initialized
INFO - 2020-09-12 06:16:11 --> Loader Class Initialized
INFO - 2020-09-12 06:16:11 --> Helper loaded: url_helper
INFO - 2020-09-12 06:16:11 --> Database Driver Class Initialized
INFO - 2020-09-12 06:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:16:11 --> Email Class Initialized
INFO - 2020-09-12 06:16:11 --> Controller Class Initialized
DEBUG - 2020-09-12 06:16:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:16:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:16:11 --> Model Class Initialized
INFO - 2020-09-12 06:16:11 --> Model Class Initialized
INFO - 2020-09-12 06:16:11 --> Model Class Initialized
INFO - 2020-09-12 06:16:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 06:16:11 --> Final output sent to browser
DEBUG - 2020-09-12 06:16:11 --> Total execution time: 0.0222
ERROR - 2020-09-12 06:16:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:16:31 --> Config Class Initialized
INFO - 2020-09-12 06:16:31 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:16:31 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:16:31 --> Utf8 Class Initialized
INFO - 2020-09-12 06:16:31 --> URI Class Initialized
INFO - 2020-09-12 06:16:31 --> Router Class Initialized
INFO - 2020-09-12 06:16:31 --> Output Class Initialized
INFO - 2020-09-12 06:16:31 --> Security Class Initialized
DEBUG - 2020-09-12 06:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:16:31 --> Input Class Initialized
INFO - 2020-09-12 06:16:31 --> Language Class Initialized
INFO - 2020-09-12 06:16:31 --> Loader Class Initialized
INFO - 2020-09-12 06:16:31 --> Helper loaded: url_helper
INFO - 2020-09-12 06:16:31 --> Database Driver Class Initialized
INFO - 2020-09-12 06:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:16:31 --> Email Class Initialized
INFO - 2020-09-12 06:16:31 --> Controller Class Initialized
DEBUG - 2020-09-12 06:16:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:16:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:16:31 --> Model Class Initialized
INFO - 2020-09-12 06:16:31 --> Model Class Initialized
INFO - 2020-09-12 06:16:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:16:31 --> Final output sent to browser
DEBUG - 2020-09-12 06:16:31 --> Total execution time: 0.0217
ERROR - 2020-09-12 06:16:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:16:53 --> Config Class Initialized
INFO - 2020-09-12 06:16:53 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:16:53 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:16:53 --> Utf8 Class Initialized
INFO - 2020-09-12 06:16:53 --> URI Class Initialized
INFO - 2020-09-12 06:16:53 --> Router Class Initialized
INFO - 2020-09-12 06:16:53 --> Output Class Initialized
INFO - 2020-09-12 06:16:53 --> Security Class Initialized
DEBUG - 2020-09-12 06:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:16:53 --> Input Class Initialized
INFO - 2020-09-12 06:16:53 --> Language Class Initialized
INFO - 2020-09-12 06:16:53 --> Loader Class Initialized
INFO - 2020-09-12 06:16:53 --> Helper loaded: url_helper
INFO - 2020-09-12 06:16:53 --> Database Driver Class Initialized
INFO - 2020-09-12 06:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:16:53 --> Email Class Initialized
INFO - 2020-09-12 06:16:53 --> Controller Class Initialized
DEBUG - 2020-09-12 06:16:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:16:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:16:53 --> Model Class Initialized
INFO - 2020-09-12 06:16:53 --> Model Class Initialized
INFO - 2020-09-12 06:16:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 06:16:53 --> Final output sent to browser
DEBUG - 2020-09-12 06:16:53 --> Total execution time: 0.0285
ERROR - 2020-09-12 06:30:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:30:58 --> Config Class Initialized
INFO - 2020-09-12 06:30:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:30:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:30:58 --> Utf8 Class Initialized
INFO - 2020-09-12 06:30:58 --> URI Class Initialized
INFO - 2020-09-12 06:30:58 --> Router Class Initialized
INFO - 2020-09-12 06:30:58 --> Output Class Initialized
INFO - 2020-09-12 06:30:58 --> Security Class Initialized
DEBUG - 2020-09-12 06:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:30:58 --> Input Class Initialized
INFO - 2020-09-12 06:30:58 --> Language Class Initialized
INFO - 2020-09-12 06:30:58 --> Loader Class Initialized
INFO - 2020-09-12 06:30:58 --> Helper loaded: url_helper
INFO - 2020-09-12 06:30:58 --> Database Driver Class Initialized
INFO - 2020-09-12 06:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:30:58 --> Email Class Initialized
INFO - 2020-09-12 06:30:58 --> Controller Class Initialized
DEBUG - 2020-09-12 06:30:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:30:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:30:58 --> Model Class Initialized
INFO - 2020-09-12 06:30:58 --> Model Class Initialized
INFO - 2020-09-12 06:30:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 06:30:58 --> Final output sent to browser
DEBUG - 2020-09-12 06:30:58 --> Total execution time: 0.0264
ERROR - 2020-09-12 06:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:31:01 --> Config Class Initialized
INFO - 2020-09-12 06:31:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:31:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:31:01 --> Utf8 Class Initialized
INFO - 2020-09-12 06:31:01 --> URI Class Initialized
INFO - 2020-09-12 06:31:01 --> Router Class Initialized
INFO - 2020-09-12 06:31:01 --> Output Class Initialized
INFO - 2020-09-12 06:31:01 --> Security Class Initialized
DEBUG - 2020-09-12 06:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:31:01 --> Input Class Initialized
INFO - 2020-09-12 06:31:01 --> Language Class Initialized
INFO - 2020-09-12 06:31:01 --> Loader Class Initialized
INFO - 2020-09-12 06:31:01 --> Helper loaded: url_helper
INFO - 2020-09-12 06:31:01 --> Database Driver Class Initialized
INFO - 2020-09-12 06:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:31:01 --> Email Class Initialized
INFO - 2020-09-12 06:31:01 --> Controller Class Initialized
DEBUG - 2020-09-12 06:31:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:31:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:31:01 --> Model Class Initialized
INFO - 2020-09-12 06:31:01 --> Model Class Initialized
INFO - 2020-09-12 06:31:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:31:01 --> Final output sent to browser
DEBUG - 2020-09-12 06:31:01 --> Total execution time: 0.0252
ERROR - 2020-09-12 06:31:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:31:05 --> Config Class Initialized
INFO - 2020-09-12 06:31:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:31:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:31:05 --> Utf8 Class Initialized
INFO - 2020-09-12 06:31:05 --> URI Class Initialized
INFO - 2020-09-12 06:31:05 --> Router Class Initialized
INFO - 2020-09-12 06:31:05 --> Output Class Initialized
INFO - 2020-09-12 06:31:05 --> Security Class Initialized
DEBUG - 2020-09-12 06:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:31:05 --> Input Class Initialized
INFO - 2020-09-12 06:31:05 --> Language Class Initialized
INFO - 2020-09-12 06:31:05 --> Loader Class Initialized
INFO - 2020-09-12 06:31:05 --> Helper loaded: url_helper
INFO - 2020-09-12 06:31:05 --> Database Driver Class Initialized
INFO - 2020-09-12 06:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:31:05 --> Email Class Initialized
INFO - 2020-09-12 06:31:05 --> Controller Class Initialized
DEBUG - 2020-09-12 06:31:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:31:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:31:05 --> Model Class Initialized
INFO - 2020-09-12 06:31:05 --> Model Class Initialized
INFO - 2020-09-12 06:31:05 --> Model Class Initialized
INFO - 2020-09-12 06:31:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 06:31:05 --> Final output sent to browser
DEBUG - 2020-09-12 06:31:05 --> Total execution time: 0.0202
ERROR - 2020-09-12 06:31:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:31:23 --> Config Class Initialized
INFO - 2020-09-12 06:31:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:31:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:31:23 --> Utf8 Class Initialized
INFO - 2020-09-12 06:31:23 --> URI Class Initialized
INFO - 2020-09-12 06:31:23 --> Router Class Initialized
INFO - 2020-09-12 06:31:23 --> Output Class Initialized
INFO - 2020-09-12 06:31:23 --> Security Class Initialized
DEBUG - 2020-09-12 06:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:31:23 --> Input Class Initialized
INFO - 2020-09-12 06:31:23 --> Language Class Initialized
INFO - 2020-09-12 06:31:23 --> Loader Class Initialized
INFO - 2020-09-12 06:31:23 --> Helper loaded: url_helper
INFO - 2020-09-12 06:31:23 --> Database Driver Class Initialized
INFO - 2020-09-12 06:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:31:23 --> Email Class Initialized
INFO - 2020-09-12 06:31:23 --> Controller Class Initialized
DEBUG - 2020-09-12 06:31:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:31:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:31:23 --> Model Class Initialized
INFO - 2020-09-12 06:31:23 --> Model Class Initialized
INFO - 2020-09-12 06:31:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:31:23 --> Final output sent to browser
DEBUG - 2020-09-12 06:31:23 --> Total execution time: 0.0245
ERROR - 2020-09-12 06:31:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:31:33 --> Config Class Initialized
INFO - 2020-09-12 06:31:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:31:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:31:33 --> Utf8 Class Initialized
INFO - 2020-09-12 06:31:33 --> URI Class Initialized
INFO - 2020-09-12 06:31:33 --> Router Class Initialized
INFO - 2020-09-12 06:31:33 --> Output Class Initialized
INFO - 2020-09-12 06:31:33 --> Security Class Initialized
DEBUG - 2020-09-12 06:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:31:33 --> Input Class Initialized
INFO - 2020-09-12 06:31:33 --> Language Class Initialized
INFO - 2020-09-12 06:31:33 --> Loader Class Initialized
INFO - 2020-09-12 06:31:33 --> Helper loaded: url_helper
INFO - 2020-09-12 06:31:33 --> Database Driver Class Initialized
INFO - 2020-09-12 06:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:31:33 --> Email Class Initialized
INFO - 2020-09-12 06:31:33 --> Controller Class Initialized
DEBUG - 2020-09-12 06:31:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:31:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:31:33 --> Model Class Initialized
INFO - 2020-09-12 06:31:33 --> Model Class Initialized
INFO - 2020-09-12 06:31:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 06:31:33 --> Final output sent to browser
DEBUG - 2020-09-12 06:31:33 --> Total execution time: 0.0203
ERROR - 2020-09-12 06:31:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:31:37 --> Config Class Initialized
INFO - 2020-09-12 06:31:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:31:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:31:37 --> Utf8 Class Initialized
INFO - 2020-09-12 06:31:37 --> URI Class Initialized
INFO - 2020-09-12 06:31:37 --> Router Class Initialized
INFO - 2020-09-12 06:31:37 --> Output Class Initialized
INFO - 2020-09-12 06:31:37 --> Security Class Initialized
DEBUG - 2020-09-12 06:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:31:37 --> Input Class Initialized
INFO - 2020-09-12 06:31:37 --> Language Class Initialized
INFO - 2020-09-12 06:31:37 --> Loader Class Initialized
INFO - 2020-09-12 06:31:37 --> Helper loaded: url_helper
INFO - 2020-09-12 06:31:37 --> Database Driver Class Initialized
INFO - 2020-09-12 06:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:31:37 --> Email Class Initialized
INFO - 2020-09-12 06:31:37 --> Controller Class Initialized
DEBUG - 2020-09-12 06:31:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:31:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:31:37 --> Model Class Initialized
INFO - 2020-09-12 06:31:37 --> Model Class Initialized
INFO - 2020-09-12 06:31:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:31:37 --> Final output sent to browser
DEBUG - 2020-09-12 06:31:37 --> Total execution time: 0.0208
ERROR - 2020-09-12 06:31:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:31:39 --> Config Class Initialized
INFO - 2020-09-12 06:31:39 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:31:39 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:31:39 --> Utf8 Class Initialized
INFO - 2020-09-12 06:31:39 --> URI Class Initialized
INFO - 2020-09-12 06:31:39 --> Router Class Initialized
INFO - 2020-09-12 06:31:39 --> Output Class Initialized
INFO - 2020-09-12 06:31:39 --> Security Class Initialized
DEBUG - 2020-09-12 06:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:31:39 --> Input Class Initialized
INFO - 2020-09-12 06:31:39 --> Language Class Initialized
INFO - 2020-09-12 06:31:39 --> Loader Class Initialized
INFO - 2020-09-12 06:31:39 --> Helper loaded: url_helper
INFO - 2020-09-12 06:31:39 --> Database Driver Class Initialized
INFO - 2020-09-12 06:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:31:39 --> Email Class Initialized
INFO - 2020-09-12 06:31:39 --> Controller Class Initialized
DEBUG - 2020-09-12 06:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:31:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:31:39 --> Model Class Initialized
INFO - 2020-09-12 06:31:39 --> Model Class Initialized
INFO - 2020-09-12 06:31:39 --> Model Class Initialized
ERROR - 2020-09-12 06:31:39 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:31:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:37:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:37:03 --> Config Class Initialized
INFO - 2020-09-12 06:37:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:37:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:37:03 --> Utf8 Class Initialized
INFO - 2020-09-12 06:37:03 --> URI Class Initialized
INFO - 2020-09-12 06:37:03 --> Router Class Initialized
INFO - 2020-09-12 06:37:03 --> Output Class Initialized
INFO - 2020-09-12 06:37:03 --> Security Class Initialized
DEBUG - 2020-09-12 06:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:37:03 --> Input Class Initialized
INFO - 2020-09-12 06:37:03 --> Language Class Initialized
INFO - 2020-09-12 06:37:03 --> Loader Class Initialized
INFO - 2020-09-12 06:37:03 --> Helper loaded: url_helper
INFO - 2020-09-12 06:37:03 --> Database Driver Class Initialized
INFO - 2020-09-12 06:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:37:03 --> Email Class Initialized
INFO - 2020-09-12 06:37:03 --> Controller Class Initialized
DEBUG - 2020-09-12 06:37:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:37:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:37:03 --> Model Class Initialized
INFO - 2020-09-12 06:37:03 --> Model Class Initialized
INFO - 2020-09-12 06:37:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:37:03 --> Final output sent to browser
DEBUG - 2020-09-12 06:37:03 --> Total execution time: 0.0238
ERROR - 2020-09-12 06:37:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:37:06 --> Config Class Initialized
INFO - 2020-09-12 06:37:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:37:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:37:06 --> Utf8 Class Initialized
INFO - 2020-09-12 06:37:06 --> URI Class Initialized
INFO - 2020-09-12 06:37:06 --> Router Class Initialized
INFO - 2020-09-12 06:37:06 --> Output Class Initialized
INFO - 2020-09-12 06:37:06 --> Security Class Initialized
DEBUG - 2020-09-12 06:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:37:06 --> Input Class Initialized
INFO - 2020-09-12 06:37:06 --> Language Class Initialized
INFO - 2020-09-12 06:37:06 --> Loader Class Initialized
INFO - 2020-09-12 06:37:06 --> Helper loaded: url_helper
INFO - 2020-09-12 06:37:06 --> Database Driver Class Initialized
INFO - 2020-09-12 06:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:37:06 --> Email Class Initialized
INFO - 2020-09-12 06:37:06 --> Controller Class Initialized
DEBUG - 2020-09-12 06:37:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:37:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:37:06 --> Model Class Initialized
INFO - 2020-09-12 06:37:06 --> Model Class Initialized
INFO - 2020-09-12 06:37:06 --> Model Class Initialized
ERROR - 2020-09-12 06:37:06 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL dealer_master_list()
INFO - 2020-09-12 06:37:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:37:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:37:22 --> Config Class Initialized
INFO - 2020-09-12 06:37:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:37:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:37:22 --> Utf8 Class Initialized
INFO - 2020-09-12 06:37:22 --> URI Class Initialized
INFO - 2020-09-12 06:37:22 --> Router Class Initialized
INFO - 2020-09-12 06:37:22 --> Output Class Initialized
INFO - 2020-09-12 06:37:22 --> Security Class Initialized
DEBUG - 2020-09-12 06:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:37:22 --> Input Class Initialized
INFO - 2020-09-12 06:37:23 --> Language Class Initialized
INFO - 2020-09-12 06:37:23 --> Loader Class Initialized
INFO - 2020-09-12 06:37:23 --> Helper loaded: url_helper
INFO - 2020-09-12 06:37:23 --> Database Driver Class Initialized
INFO - 2020-09-12 06:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:37:23 --> Email Class Initialized
INFO - 2020-09-12 06:37:23 --> Controller Class Initialized
DEBUG - 2020-09-12 06:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:37:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:37:23 --> Model Class Initialized
INFO - 2020-09-12 06:37:23 --> Model Class Initialized
INFO - 2020-09-12 06:37:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:37:23 --> Final output sent to browser
DEBUG - 2020-09-12 06:37:23 --> Total execution time: 0.0229
ERROR - 2020-09-12 06:37:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:37:52 --> Config Class Initialized
INFO - 2020-09-12 06:37:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:37:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:37:52 --> Utf8 Class Initialized
INFO - 2020-09-12 06:37:52 --> URI Class Initialized
INFO - 2020-09-12 06:37:52 --> Router Class Initialized
INFO - 2020-09-12 06:37:52 --> Output Class Initialized
INFO - 2020-09-12 06:37:52 --> Security Class Initialized
DEBUG - 2020-09-12 06:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:37:52 --> Input Class Initialized
INFO - 2020-09-12 06:37:52 --> Language Class Initialized
INFO - 2020-09-12 06:37:52 --> Loader Class Initialized
INFO - 2020-09-12 06:37:52 --> Helper loaded: url_helper
INFO - 2020-09-12 06:37:52 --> Database Driver Class Initialized
INFO - 2020-09-12 06:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:37:52 --> Email Class Initialized
INFO - 2020-09-12 06:37:52 --> Controller Class Initialized
DEBUG - 2020-09-12 06:37:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:37:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:37:52 --> Model Class Initialized
INFO - 2020-09-12 06:37:52 --> Model Class Initialized
INFO - 2020-09-12 06:37:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:37:52 --> Final output sent to browser
DEBUG - 2020-09-12 06:37:52 --> Total execution time: 0.0238
ERROR - 2020-09-12 06:37:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:37:55 --> Config Class Initialized
INFO - 2020-09-12 06:37:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:37:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:37:55 --> Utf8 Class Initialized
INFO - 2020-09-12 06:37:55 --> URI Class Initialized
INFO - 2020-09-12 06:37:55 --> Router Class Initialized
INFO - 2020-09-12 06:37:55 --> Output Class Initialized
INFO - 2020-09-12 06:37:55 --> Security Class Initialized
DEBUG - 2020-09-12 06:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:37:55 --> Input Class Initialized
INFO - 2020-09-12 06:37:55 --> Language Class Initialized
INFO - 2020-09-12 06:37:55 --> Loader Class Initialized
INFO - 2020-09-12 06:37:55 --> Helper loaded: url_helper
INFO - 2020-09-12 06:37:55 --> Database Driver Class Initialized
INFO - 2020-09-12 06:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:37:55 --> Email Class Initialized
INFO - 2020-09-12 06:37:55 --> Controller Class Initialized
DEBUG - 2020-09-12 06:37:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:37:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:37:55 --> Model Class Initialized
INFO - 2020-09-12 06:37:55 --> Model Class Initialized
INFO - 2020-09-12 06:37:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 06:37:55 --> Final output sent to browser
DEBUG - 2020-09-12 06:37:55 --> Total execution time: 0.0212
ERROR - 2020-09-12 06:37:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:37:57 --> Config Class Initialized
INFO - 2020-09-12 06:37:57 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:37:57 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:37:57 --> Utf8 Class Initialized
INFO - 2020-09-12 06:37:57 --> URI Class Initialized
INFO - 2020-09-12 06:37:57 --> Router Class Initialized
INFO - 2020-09-12 06:37:57 --> Output Class Initialized
INFO - 2020-09-12 06:37:57 --> Security Class Initialized
DEBUG - 2020-09-12 06:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:37:57 --> Input Class Initialized
INFO - 2020-09-12 06:37:57 --> Language Class Initialized
INFO - 2020-09-12 06:37:57 --> Loader Class Initialized
INFO - 2020-09-12 06:37:57 --> Helper loaded: url_helper
INFO - 2020-09-12 06:37:57 --> Database Driver Class Initialized
INFO - 2020-09-12 06:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:37:57 --> Email Class Initialized
INFO - 2020-09-12 06:37:57 --> Controller Class Initialized
DEBUG - 2020-09-12 06:37:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:37:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:37:57 --> Model Class Initialized
INFO - 2020-09-12 06:37:57 --> Model Class Initialized
INFO - 2020-09-12 06:37:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:37:57 --> Final output sent to browser
DEBUG - 2020-09-12 06:37:57 --> Total execution time: 0.0227
ERROR - 2020-09-12 06:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:38:00 --> Config Class Initialized
INFO - 2020-09-12 06:38:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:38:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:38:00 --> Utf8 Class Initialized
INFO - 2020-09-12 06:38:00 --> URI Class Initialized
INFO - 2020-09-12 06:38:00 --> Router Class Initialized
INFO - 2020-09-12 06:38:00 --> Output Class Initialized
INFO - 2020-09-12 06:38:00 --> Security Class Initialized
DEBUG - 2020-09-12 06:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:38:00 --> Input Class Initialized
INFO - 2020-09-12 06:38:00 --> Language Class Initialized
INFO - 2020-09-12 06:38:00 --> Loader Class Initialized
INFO - 2020-09-12 06:38:00 --> Helper loaded: url_helper
INFO - 2020-09-12 06:38:00 --> Database Driver Class Initialized
INFO - 2020-09-12 06:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:38:00 --> Email Class Initialized
INFO - 2020-09-12 06:38:00 --> Controller Class Initialized
DEBUG - 2020-09-12 06:38:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:38:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:38:00 --> Model Class Initialized
INFO - 2020-09-12 06:38:00 --> Model Class Initialized
INFO - 2020-09-12 06:38:00 --> Model Class Initialized
ERROR - 2020-09-12 06:38:00 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 06:38:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:38:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:38:34 --> Config Class Initialized
INFO - 2020-09-12 06:38:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:38:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:38:34 --> Utf8 Class Initialized
INFO - 2020-09-12 06:38:34 --> URI Class Initialized
INFO - 2020-09-12 06:38:34 --> Router Class Initialized
INFO - 2020-09-12 06:38:34 --> Output Class Initialized
INFO - 2020-09-12 06:38:34 --> Security Class Initialized
DEBUG - 2020-09-12 06:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:38:34 --> Input Class Initialized
INFO - 2020-09-12 06:38:34 --> Language Class Initialized
INFO - 2020-09-12 06:38:34 --> Loader Class Initialized
INFO - 2020-09-12 06:38:34 --> Helper loaded: url_helper
INFO - 2020-09-12 06:38:34 --> Database Driver Class Initialized
INFO - 2020-09-12 06:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:38:34 --> Email Class Initialized
INFO - 2020-09-12 06:38:34 --> Controller Class Initialized
DEBUG - 2020-09-12 06:38:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:38:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:38:34 --> Model Class Initialized
INFO - 2020-09-12 06:38:34 --> Model Class Initialized
INFO - 2020-09-12 06:38:34 --> Model Class Initialized
ERROR - 2020-09-12 06:38:34 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 06:38:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:38:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:38:39 --> Config Class Initialized
INFO - 2020-09-12 06:38:39 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:38:39 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:38:39 --> Utf8 Class Initialized
INFO - 2020-09-12 06:38:39 --> URI Class Initialized
INFO - 2020-09-12 06:38:39 --> Router Class Initialized
INFO - 2020-09-12 06:38:39 --> Output Class Initialized
INFO - 2020-09-12 06:38:39 --> Security Class Initialized
DEBUG - 2020-09-12 06:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:38:39 --> Input Class Initialized
INFO - 2020-09-12 06:38:39 --> Language Class Initialized
INFO - 2020-09-12 06:38:39 --> Loader Class Initialized
INFO - 2020-09-12 06:38:39 --> Helper loaded: url_helper
INFO - 2020-09-12 06:38:39 --> Database Driver Class Initialized
INFO - 2020-09-12 06:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:38:39 --> Email Class Initialized
INFO - 2020-09-12 06:38:39 --> Controller Class Initialized
DEBUG - 2020-09-12 06:38:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:38:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:38:39 --> Model Class Initialized
INFO - 2020-09-12 06:38:39 --> Model Class Initialized
INFO - 2020-09-12 06:38:39 --> Model Class Initialized
ERROR - 2020-09-12 06:38:39 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 06:38:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:39:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:39:15 --> Config Class Initialized
INFO - 2020-09-12 06:39:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:39:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:39:15 --> Utf8 Class Initialized
INFO - 2020-09-12 06:39:15 --> URI Class Initialized
INFO - 2020-09-12 06:39:15 --> Router Class Initialized
INFO - 2020-09-12 06:39:15 --> Output Class Initialized
INFO - 2020-09-12 06:39:15 --> Security Class Initialized
DEBUG - 2020-09-12 06:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:39:15 --> Input Class Initialized
INFO - 2020-09-12 06:39:15 --> Language Class Initialized
INFO - 2020-09-12 06:39:15 --> Loader Class Initialized
INFO - 2020-09-12 06:39:15 --> Helper loaded: url_helper
INFO - 2020-09-12 06:39:15 --> Database Driver Class Initialized
INFO - 2020-09-12 06:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:39:15 --> Email Class Initialized
INFO - 2020-09-12 06:39:15 --> Controller Class Initialized
DEBUG - 2020-09-12 06:39:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:39:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:39:15 --> Model Class Initialized
INFO - 2020-09-12 06:39:15 --> Model Class Initialized
INFO - 2020-09-12 06:39:15 --> Model Class Initialized
INFO - 2020-09-12 06:39:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 06:39:15 --> Final output sent to browser
DEBUG - 2020-09-12 06:39:15 --> Total execution time: 0.0244
ERROR - 2020-09-12 06:39:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:39:52 --> Config Class Initialized
INFO - 2020-09-12 06:39:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:39:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:39:52 --> Utf8 Class Initialized
INFO - 2020-09-12 06:39:52 --> URI Class Initialized
INFO - 2020-09-12 06:39:52 --> Router Class Initialized
INFO - 2020-09-12 06:39:52 --> Output Class Initialized
INFO - 2020-09-12 06:39:52 --> Security Class Initialized
DEBUG - 2020-09-12 06:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:39:52 --> Input Class Initialized
INFO - 2020-09-12 06:39:52 --> Language Class Initialized
INFO - 2020-09-12 06:39:52 --> Loader Class Initialized
INFO - 2020-09-12 06:39:52 --> Helper loaded: url_helper
INFO - 2020-09-12 06:39:52 --> Database Driver Class Initialized
INFO - 2020-09-12 06:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:39:52 --> Email Class Initialized
INFO - 2020-09-12 06:39:52 --> Controller Class Initialized
DEBUG - 2020-09-12 06:39:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:39:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:39:52 --> Model Class Initialized
INFO - 2020-09-12 06:39:52 --> Model Class Initialized
INFO - 2020-09-12 06:39:52 --> Model Class Initialized
INFO - 2020-09-12 06:39:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 06:39:52 --> Final output sent to browser
DEBUG - 2020-09-12 06:39:52 --> Total execution time: 0.0286
ERROR - 2020-09-12 06:39:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:39:54 --> Config Class Initialized
INFO - 2020-09-12 06:39:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:39:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:39:54 --> Utf8 Class Initialized
INFO - 2020-09-12 06:39:54 --> URI Class Initialized
INFO - 2020-09-12 06:39:54 --> Router Class Initialized
INFO - 2020-09-12 06:39:54 --> Output Class Initialized
INFO - 2020-09-12 06:39:54 --> Security Class Initialized
DEBUG - 2020-09-12 06:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:39:54 --> Input Class Initialized
INFO - 2020-09-12 06:39:54 --> Language Class Initialized
INFO - 2020-09-12 06:39:54 --> Loader Class Initialized
INFO - 2020-09-12 06:39:54 --> Helper loaded: url_helper
INFO - 2020-09-12 06:39:55 --> Database Driver Class Initialized
INFO - 2020-09-12 06:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:39:55 --> Email Class Initialized
INFO - 2020-09-12 06:39:55 --> Controller Class Initialized
DEBUG - 2020-09-12 06:39:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:39:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:39:55 --> Model Class Initialized
INFO - 2020-09-12 06:39:55 --> Model Class Initialized
INFO - 2020-09-12 06:39:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:39:55 --> Final output sent to browser
DEBUG - 2020-09-12 06:39:55 --> Total execution time: 0.0246
ERROR - 2020-09-12 06:39:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:39:57 --> Config Class Initialized
INFO - 2020-09-12 06:39:57 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:39:57 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:39:57 --> Utf8 Class Initialized
INFO - 2020-09-12 06:39:57 --> URI Class Initialized
INFO - 2020-09-12 06:39:57 --> Router Class Initialized
INFO - 2020-09-12 06:39:57 --> Output Class Initialized
INFO - 2020-09-12 06:39:57 --> Security Class Initialized
DEBUG - 2020-09-12 06:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:39:57 --> Input Class Initialized
INFO - 2020-09-12 06:39:57 --> Language Class Initialized
INFO - 2020-09-12 06:39:57 --> Loader Class Initialized
INFO - 2020-09-12 06:39:57 --> Helper loaded: url_helper
INFO - 2020-09-12 06:39:57 --> Database Driver Class Initialized
INFO - 2020-09-12 06:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:39:57 --> Email Class Initialized
INFO - 2020-09-12 06:39:57 --> Controller Class Initialized
DEBUG - 2020-09-12 06:39:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:39:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:39:57 --> Model Class Initialized
INFO - 2020-09-12 06:39:57 --> Model Class Initialized
INFO - 2020-09-12 06:39:57 --> Model Class Initialized
INFO - 2020-09-12 06:39:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 06:39:57 --> Final output sent to browser
DEBUG - 2020-09-12 06:39:57 --> Total execution time: 0.0247
ERROR - 2020-09-12 06:43:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:43:52 --> Config Class Initialized
INFO - 2020-09-12 06:43:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:43:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:43:52 --> Utf8 Class Initialized
INFO - 2020-09-12 06:43:52 --> URI Class Initialized
INFO - 2020-09-12 06:43:52 --> Router Class Initialized
INFO - 2020-09-12 06:43:52 --> Output Class Initialized
INFO - 2020-09-12 06:43:52 --> Security Class Initialized
DEBUG - 2020-09-12 06:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:43:52 --> Input Class Initialized
INFO - 2020-09-12 06:43:52 --> Language Class Initialized
INFO - 2020-09-12 06:43:52 --> Loader Class Initialized
INFO - 2020-09-12 06:43:52 --> Helper loaded: url_helper
INFO - 2020-09-12 06:43:52 --> Database Driver Class Initialized
INFO - 2020-09-12 06:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:43:52 --> Email Class Initialized
INFO - 2020-09-12 06:43:52 --> Controller Class Initialized
DEBUG - 2020-09-12 06:43:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:43:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:43:52 --> Model Class Initialized
INFO - 2020-09-12 06:43:52 --> Model Class Initialized
INFO - 2020-09-12 06:43:52 --> Model Class Initialized
ERROR - 2020-09-12 06:43:52 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:43:52 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:47:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:47:11 --> Config Class Initialized
INFO - 2020-09-12 06:47:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:47:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:47:11 --> Utf8 Class Initialized
INFO - 2020-09-12 06:47:11 --> URI Class Initialized
INFO - 2020-09-12 06:47:11 --> Router Class Initialized
INFO - 2020-09-12 06:47:11 --> Output Class Initialized
INFO - 2020-09-12 06:47:11 --> Security Class Initialized
DEBUG - 2020-09-12 06:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:47:11 --> Input Class Initialized
INFO - 2020-09-12 06:47:11 --> Language Class Initialized
INFO - 2020-09-12 06:47:11 --> Loader Class Initialized
INFO - 2020-09-12 06:47:11 --> Helper loaded: url_helper
INFO - 2020-09-12 06:47:11 --> Database Driver Class Initialized
INFO - 2020-09-12 06:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:47:11 --> Email Class Initialized
INFO - 2020-09-12 06:47:11 --> Controller Class Initialized
DEBUG - 2020-09-12 06:47:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:47:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:47:11 --> Model Class Initialized
INFO - 2020-09-12 06:47:11 --> Model Class Initialized
INFO - 2020-09-12 06:47:11 --> Model Class Initialized
ERROR - 2020-09-12 06:47:11 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:47:11 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:48:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:48:37 --> Config Class Initialized
INFO - 2020-09-12 06:48:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:48:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:48:37 --> Utf8 Class Initialized
INFO - 2020-09-12 06:48:37 --> URI Class Initialized
INFO - 2020-09-12 06:48:37 --> Router Class Initialized
INFO - 2020-09-12 06:48:37 --> Output Class Initialized
INFO - 2020-09-12 06:48:37 --> Security Class Initialized
DEBUG - 2020-09-12 06:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:48:37 --> Input Class Initialized
INFO - 2020-09-12 06:48:37 --> Language Class Initialized
INFO - 2020-09-12 06:48:37 --> Loader Class Initialized
INFO - 2020-09-12 06:48:37 --> Helper loaded: url_helper
INFO - 2020-09-12 06:48:37 --> Database Driver Class Initialized
INFO - 2020-09-12 06:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:48:37 --> Email Class Initialized
INFO - 2020-09-12 06:48:37 --> Controller Class Initialized
DEBUG - 2020-09-12 06:48:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:48:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:48:37 --> Model Class Initialized
INFO - 2020-09-12 06:48:37 --> Model Class Initialized
INFO - 2020-09-12 06:48:37 --> Model Class Initialized
ERROR - 2020-09-12 06:48:37 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:48:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:48:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:48:52 --> Config Class Initialized
INFO - 2020-09-12 06:48:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:48:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:48:52 --> Utf8 Class Initialized
INFO - 2020-09-12 06:48:52 --> URI Class Initialized
INFO - 2020-09-12 06:48:52 --> Router Class Initialized
INFO - 2020-09-12 06:48:52 --> Output Class Initialized
INFO - 2020-09-12 06:48:52 --> Security Class Initialized
DEBUG - 2020-09-12 06:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:48:52 --> Input Class Initialized
INFO - 2020-09-12 06:48:52 --> Language Class Initialized
INFO - 2020-09-12 06:48:52 --> Loader Class Initialized
INFO - 2020-09-12 06:48:52 --> Helper loaded: url_helper
INFO - 2020-09-12 06:48:52 --> Database Driver Class Initialized
INFO - 2020-09-12 06:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:48:52 --> Email Class Initialized
INFO - 2020-09-12 06:48:52 --> Controller Class Initialized
DEBUG - 2020-09-12 06:48:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:48:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:48:52 --> Model Class Initialized
INFO - 2020-09-12 06:48:52 --> Model Class Initialized
INFO - 2020-09-12 06:48:52 --> Model Class Initialized
ERROR - 2020-09-12 06:48:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Campain_model.php:102) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-12 06:48:52 --> Severity: Error --> Call to a member function num_rows() on a non-object /home/purpu1ex/public_html/carsm/application/models/Campain_model.php 102
ERROR - 2020-09-12 06:49:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:49:25 --> Config Class Initialized
INFO - 2020-09-12 06:49:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:49:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:49:25 --> Utf8 Class Initialized
INFO - 2020-09-12 06:49:25 --> URI Class Initialized
INFO - 2020-09-12 06:49:25 --> Router Class Initialized
INFO - 2020-09-12 06:49:25 --> Output Class Initialized
INFO - 2020-09-12 06:49:25 --> Security Class Initialized
DEBUG - 2020-09-12 06:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:49:25 --> Input Class Initialized
INFO - 2020-09-12 06:49:25 --> Language Class Initialized
INFO - 2020-09-12 06:49:25 --> Loader Class Initialized
INFO - 2020-09-12 06:49:25 --> Helper loaded: url_helper
INFO - 2020-09-12 06:49:25 --> Database Driver Class Initialized
INFO - 2020-09-12 06:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:49:25 --> Email Class Initialized
INFO - 2020-09-12 06:49:25 --> Controller Class Initialized
DEBUG - 2020-09-12 06:49:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:49:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:49:25 --> Model Class Initialized
INFO - 2020-09-12 06:49:25 --> Model Class Initialized
INFO - 2020-09-12 06:49:25 --> Model Class Initialized
ERROR - 2020-09-12 06:49:25 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:49:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:52:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:52:34 --> Config Class Initialized
INFO - 2020-09-12 06:52:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:52:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:52:34 --> Utf8 Class Initialized
INFO - 2020-09-12 06:52:34 --> URI Class Initialized
INFO - 2020-09-12 06:52:34 --> Router Class Initialized
INFO - 2020-09-12 06:52:34 --> Output Class Initialized
INFO - 2020-09-12 06:52:34 --> Security Class Initialized
DEBUG - 2020-09-12 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:52:34 --> Input Class Initialized
INFO - 2020-09-12 06:52:34 --> Language Class Initialized
INFO - 2020-09-12 06:52:34 --> Loader Class Initialized
INFO - 2020-09-12 06:52:34 --> Helper loaded: url_helper
INFO - 2020-09-12 06:52:34 --> Database Driver Class Initialized
INFO - 2020-09-12 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:52:34 --> Email Class Initialized
INFO - 2020-09-12 06:52:34 --> Controller Class Initialized
DEBUG - 2020-09-12 06:52:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:52:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:52:34 --> Model Class Initialized
INFO - 2020-09-12 06:52:34 --> Model Class Initialized
INFO - 2020-09-12 06:52:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:52:34 --> Final output sent to browser
DEBUG - 2020-09-12 06:52:34 --> Total execution time: 0.0248
ERROR - 2020-09-12 06:54:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:54:22 --> Config Class Initialized
INFO - 2020-09-12 06:54:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:54:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:54:22 --> Utf8 Class Initialized
INFO - 2020-09-12 06:54:22 --> URI Class Initialized
INFO - 2020-09-12 06:54:22 --> Router Class Initialized
INFO - 2020-09-12 06:54:22 --> Output Class Initialized
INFO - 2020-09-12 06:54:22 --> Security Class Initialized
DEBUG - 2020-09-12 06:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:54:22 --> Input Class Initialized
INFO - 2020-09-12 06:54:22 --> Language Class Initialized
INFO - 2020-09-12 06:54:22 --> Loader Class Initialized
INFO - 2020-09-12 06:54:22 --> Helper loaded: url_helper
INFO - 2020-09-12 06:54:22 --> Database Driver Class Initialized
INFO - 2020-09-12 06:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:54:22 --> Email Class Initialized
INFO - 2020-09-12 06:54:22 --> Controller Class Initialized
DEBUG - 2020-09-12 06:54:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:54:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:54:22 --> Model Class Initialized
INFO - 2020-09-12 06:54:22 --> Model Class Initialized
INFO - 2020-09-12 06:54:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:54:22 --> Final output sent to browser
DEBUG - 2020-09-12 06:54:22 --> Total execution time: 0.0239
ERROR - 2020-09-12 06:54:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:54:27 --> Config Class Initialized
INFO - 2020-09-12 06:54:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:54:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:54:27 --> Utf8 Class Initialized
INFO - 2020-09-12 06:54:27 --> URI Class Initialized
INFO - 2020-09-12 06:54:27 --> Router Class Initialized
INFO - 2020-09-12 06:54:27 --> Output Class Initialized
INFO - 2020-09-12 06:54:27 --> Security Class Initialized
DEBUG - 2020-09-12 06:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:54:27 --> Input Class Initialized
INFO - 2020-09-12 06:54:27 --> Language Class Initialized
INFO - 2020-09-12 06:54:27 --> Loader Class Initialized
INFO - 2020-09-12 06:54:27 --> Helper loaded: url_helper
INFO - 2020-09-12 06:54:27 --> Database Driver Class Initialized
INFO - 2020-09-12 06:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:54:27 --> Email Class Initialized
INFO - 2020-09-12 06:54:27 --> Controller Class Initialized
DEBUG - 2020-09-12 06:54:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:54:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:54:27 --> Model Class Initialized
INFO - 2020-09-12 06:54:27 --> Model Class Initialized
INFO - 2020-09-12 06:54:27 --> Model Class Initialized
ERROR - 2020-09-12 06:54:27 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:54:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:57:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:57:02 --> Config Class Initialized
INFO - 2020-09-12 06:57:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:57:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:57:02 --> Utf8 Class Initialized
INFO - 2020-09-12 06:57:02 --> URI Class Initialized
INFO - 2020-09-12 06:57:02 --> Router Class Initialized
INFO - 2020-09-12 06:57:02 --> Output Class Initialized
INFO - 2020-09-12 06:57:02 --> Security Class Initialized
DEBUG - 2020-09-12 06:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:57:02 --> Input Class Initialized
INFO - 2020-09-12 06:57:02 --> Language Class Initialized
INFO - 2020-09-12 06:57:02 --> Loader Class Initialized
INFO - 2020-09-12 06:57:02 --> Helper loaded: url_helper
INFO - 2020-09-12 06:57:02 --> Database Driver Class Initialized
INFO - 2020-09-12 06:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:57:02 --> Email Class Initialized
INFO - 2020-09-12 06:57:02 --> Controller Class Initialized
DEBUG - 2020-09-12 06:57:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:57:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:57:02 --> Model Class Initialized
INFO - 2020-09-12 06:57:02 --> Model Class Initialized
INFO - 2020-09-12 06:57:02 --> Model Class Initialized
INFO - 2020-09-12 06:57:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 06:57:02 --> Final output sent to browser
DEBUG - 2020-09-12 06:57:02 --> Total execution time: 0.0253
ERROR - 2020-09-12 06:57:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:57:15 --> Config Class Initialized
INFO - 2020-09-12 06:57:15 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:57:15 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:57:15 --> Utf8 Class Initialized
INFO - 2020-09-12 06:57:15 --> URI Class Initialized
INFO - 2020-09-12 06:57:15 --> Router Class Initialized
INFO - 2020-09-12 06:57:15 --> Output Class Initialized
INFO - 2020-09-12 06:57:15 --> Security Class Initialized
DEBUG - 2020-09-12 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:57:15 --> Input Class Initialized
INFO - 2020-09-12 06:57:15 --> Language Class Initialized
INFO - 2020-09-12 06:57:15 --> Loader Class Initialized
INFO - 2020-09-12 06:57:15 --> Helper loaded: url_helper
INFO - 2020-09-12 06:57:15 --> Database Driver Class Initialized
INFO - 2020-09-12 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:57:15 --> Email Class Initialized
INFO - 2020-09-12 06:57:15 --> Controller Class Initialized
DEBUG - 2020-09-12 06:57:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:57:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:57:15 --> Model Class Initialized
INFO - 2020-09-12 06:57:15 --> Model Class Initialized
INFO - 2020-09-12 06:57:15 --> Model Class Initialized
ERROR - 2020-09-12 06:57:15 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:57:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 06:57:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:57:34 --> Config Class Initialized
INFO - 2020-09-12 06:57:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:57:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:57:34 --> Utf8 Class Initialized
INFO - 2020-09-12 06:57:34 --> URI Class Initialized
INFO - 2020-09-12 06:57:34 --> Router Class Initialized
INFO - 2020-09-12 06:57:34 --> Output Class Initialized
INFO - 2020-09-12 06:57:34 --> Security Class Initialized
DEBUG - 2020-09-12 06:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:57:34 --> Input Class Initialized
INFO - 2020-09-12 06:57:34 --> Language Class Initialized
INFO - 2020-09-12 06:57:34 --> Loader Class Initialized
INFO - 2020-09-12 06:57:34 --> Helper loaded: url_helper
INFO - 2020-09-12 06:57:34 --> Database Driver Class Initialized
INFO - 2020-09-12 06:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:57:34 --> Email Class Initialized
INFO - 2020-09-12 06:57:34 --> Controller Class Initialized
DEBUG - 2020-09-12 06:57:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:57:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:57:34 --> Model Class Initialized
INFO - 2020-09-12 06:57:34 --> Model Class Initialized
INFO - 2020-09-12 06:57:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 06:57:34 --> Final output sent to browser
DEBUG - 2020-09-12 06:57:34 --> Total execution time: 0.0235
ERROR - 2020-09-12 06:57:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 06:57:37 --> Config Class Initialized
INFO - 2020-09-12 06:57:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 06:57:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 06:57:37 --> Utf8 Class Initialized
INFO - 2020-09-12 06:57:37 --> URI Class Initialized
INFO - 2020-09-12 06:57:37 --> Router Class Initialized
INFO - 2020-09-12 06:57:37 --> Output Class Initialized
INFO - 2020-09-12 06:57:37 --> Security Class Initialized
DEBUG - 2020-09-12 06:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 06:57:37 --> Input Class Initialized
INFO - 2020-09-12 06:57:37 --> Language Class Initialized
INFO - 2020-09-12 06:57:37 --> Loader Class Initialized
INFO - 2020-09-12 06:57:37 --> Helper loaded: url_helper
INFO - 2020-09-12 06:57:37 --> Database Driver Class Initialized
INFO - 2020-09-12 06:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 06:57:37 --> Email Class Initialized
INFO - 2020-09-12 06:57:37 --> Controller Class Initialized
DEBUG - 2020-09-12 06:57:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 06:57:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 06:57:37 --> Model Class Initialized
INFO - 2020-09-12 06:57:37 --> Model Class Initialized
INFO - 2020-09-12 06:57:37 --> Model Class Initialized
ERROR - 2020-09-12 06:57:37 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 06:57:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:02:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:02:00 --> Config Class Initialized
INFO - 2020-09-12 07:02:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:02:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:02:00 --> Utf8 Class Initialized
INFO - 2020-09-12 07:02:00 --> URI Class Initialized
INFO - 2020-09-12 07:02:00 --> Router Class Initialized
INFO - 2020-09-12 07:02:00 --> Output Class Initialized
INFO - 2020-09-12 07:02:00 --> Security Class Initialized
DEBUG - 2020-09-12 07:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:02:00 --> Input Class Initialized
INFO - 2020-09-12 07:02:00 --> Language Class Initialized
INFO - 2020-09-12 07:02:00 --> Loader Class Initialized
INFO - 2020-09-12 07:02:00 --> Helper loaded: url_helper
INFO - 2020-09-12 07:02:00 --> Database Driver Class Initialized
INFO - 2020-09-12 07:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:02:00 --> Email Class Initialized
INFO - 2020-09-12 07:02:00 --> Controller Class Initialized
DEBUG - 2020-09-12 07:02:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:02:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:02:00 --> Model Class Initialized
INFO - 2020-09-12 07:02:00 --> Model Class Initialized
INFO - 2020-09-12 07:02:00 --> Model Class Initialized
ERROR - 2020-09-12 07:02:00 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 07:02:00 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:02:02 --> Config Class Initialized
INFO - 2020-09-12 07:02:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:02:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:02:02 --> Utf8 Class Initialized
INFO - 2020-09-12 07:02:02 --> URI Class Initialized
INFO - 2020-09-12 07:02:02 --> Router Class Initialized
INFO - 2020-09-12 07:02:02 --> Output Class Initialized
INFO - 2020-09-12 07:02:02 --> Security Class Initialized
DEBUG - 2020-09-12 07:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:02:02 --> Input Class Initialized
INFO - 2020-09-12 07:02:02 --> Language Class Initialized
INFO - 2020-09-12 07:02:02 --> Loader Class Initialized
INFO - 2020-09-12 07:02:02 --> Helper loaded: url_helper
INFO - 2020-09-12 07:02:02 --> Database Driver Class Initialized
INFO - 2020-09-12 07:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:02:02 --> Email Class Initialized
INFO - 2020-09-12 07:02:02 --> Controller Class Initialized
DEBUG - 2020-09-12 07:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:02:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:02:02 --> Model Class Initialized
INFO - 2020-09-12 07:02:02 --> Model Class Initialized
INFO - 2020-09-12 07:02:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:02:02 --> Final output sent to browser
DEBUG - 2020-09-12 07:02:02 --> Total execution time: 0.0237
ERROR - 2020-09-12 07:02:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:02:06 --> Config Class Initialized
INFO - 2020-09-12 07:02:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:02:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:02:06 --> Utf8 Class Initialized
INFO - 2020-09-12 07:02:06 --> URI Class Initialized
INFO - 2020-09-12 07:02:06 --> Router Class Initialized
INFO - 2020-09-12 07:02:06 --> Output Class Initialized
INFO - 2020-09-12 07:02:06 --> Security Class Initialized
DEBUG - 2020-09-12 07:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:02:06 --> Input Class Initialized
INFO - 2020-09-12 07:02:06 --> Language Class Initialized
INFO - 2020-09-12 07:02:06 --> Loader Class Initialized
INFO - 2020-09-12 07:02:06 --> Helper loaded: url_helper
INFO - 2020-09-12 07:02:06 --> Database Driver Class Initialized
INFO - 2020-09-12 07:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:02:06 --> Email Class Initialized
INFO - 2020-09-12 07:02:06 --> Controller Class Initialized
DEBUG - 2020-09-12 07:02:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:02:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:02:06 --> Model Class Initialized
INFO - 2020-09-12 07:02:06 --> Model Class Initialized
INFO - 2020-09-12 07:02:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 07:02:06 --> Final output sent to browser
DEBUG - 2020-09-12 07:02:06 --> Total execution time: 0.0244
ERROR - 2020-09-12 07:02:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:02:08 --> Config Class Initialized
INFO - 2020-09-12 07:02:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:02:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:02:08 --> Utf8 Class Initialized
INFO - 2020-09-12 07:02:08 --> URI Class Initialized
INFO - 2020-09-12 07:02:08 --> Router Class Initialized
INFO - 2020-09-12 07:02:08 --> Output Class Initialized
INFO - 2020-09-12 07:02:08 --> Security Class Initialized
DEBUG - 2020-09-12 07:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:02:08 --> Input Class Initialized
INFO - 2020-09-12 07:02:08 --> Language Class Initialized
INFO - 2020-09-12 07:02:08 --> Loader Class Initialized
INFO - 2020-09-12 07:02:08 --> Helper loaded: url_helper
INFO - 2020-09-12 07:02:08 --> Database Driver Class Initialized
INFO - 2020-09-12 07:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:02:08 --> Email Class Initialized
INFO - 2020-09-12 07:02:08 --> Controller Class Initialized
DEBUG - 2020-09-12 07:02:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:02:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:02:08 --> Model Class Initialized
INFO - 2020-09-12 07:02:08 --> Model Class Initialized
INFO - 2020-09-12 07:02:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:02:08 --> Final output sent to browser
DEBUG - 2020-09-12 07:02:08 --> Total execution time: 0.0241
ERROR - 2020-09-12 07:02:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:02:10 --> Config Class Initialized
INFO - 2020-09-12 07:02:10 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:02:10 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:02:10 --> Utf8 Class Initialized
INFO - 2020-09-12 07:02:10 --> URI Class Initialized
INFO - 2020-09-12 07:02:10 --> Router Class Initialized
INFO - 2020-09-12 07:02:10 --> Output Class Initialized
INFO - 2020-09-12 07:02:10 --> Security Class Initialized
DEBUG - 2020-09-12 07:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:02:10 --> Input Class Initialized
INFO - 2020-09-12 07:02:10 --> Language Class Initialized
INFO - 2020-09-12 07:02:10 --> Loader Class Initialized
INFO - 2020-09-12 07:02:10 --> Helper loaded: url_helper
INFO - 2020-09-12 07:02:10 --> Database Driver Class Initialized
INFO - 2020-09-12 07:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:02:10 --> Email Class Initialized
INFO - 2020-09-12 07:02:10 --> Controller Class Initialized
DEBUG - 2020-09-12 07:02:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:02:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:02:10 --> Model Class Initialized
INFO - 2020-09-12 07:02:10 --> Model Class Initialized
INFO - 2020-09-12 07:02:10 --> Model Class Initialized
ERROR - 2020-09-12 07:02:10 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:02:10 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:04:16 --> Config Class Initialized
INFO - 2020-09-12 07:04:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:04:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:04:16 --> Utf8 Class Initialized
INFO - 2020-09-12 07:04:16 --> URI Class Initialized
INFO - 2020-09-12 07:04:16 --> Router Class Initialized
INFO - 2020-09-12 07:04:16 --> Output Class Initialized
INFO - 2020-09-12 07:04:16 --> Security Class Initialized
DEBUG - 2020-09-12 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:04:16 --> Input Class Initialized
INFO - 2020-09-12 07:04:16 --> Language Class Initialized
INFO - 2020-09-12 07:04:16 --> Loader Class Initialized
INFO - 2020-09-12 07:04:16 --> Helper loaded: url_helper
INFO - 2020-09-12 07:04:16 --> Database Driver Class Initialized
INFO - 2020-09-12 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:04:16 --> Email Class Initialized
INFO - 2020-09-12 07:04:16 --> Controller Class Initialized
DEBUG - 2020-09-12 07:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:04:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:04:16 --> Model Class Initialized
INFO - 2020-09-12 07:04:16 --> Model Class Initialized
INFO - 2020-09-12 07:04:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:04:16 --> Final output sent to browser
DEBUG - 2020-09-12 07:04:16 --> Total execution time: 0.0209
ERROR - 2020-09-12 07:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:04:18 --> Config Class Initialized
INFO - 2020-09-12 07:04:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:04:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:04:18 --> Utf8 Class Initialized
INFO - 2020-09-12 07:04:18 --> URI Class Initialized
INFO - 2020-09-12 07:04:18 --> Router Class Initialized
INFO - 2020-09-12 07:04:18 --> Output Class Initialized
INFO - 2020-09-12 07:04:18 --> Security Class Initialized
DEBUG - 2020-09-12 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:04:18 --> Input Class Initialized
INFO - 2020-09-12 07:04:18 --> Language Class Initialized
INFO - 2020-09-12 07:04:18 --> Loader Class Initialized
INFO - 2020-09-12 07:04:18 --> Helper loaded: url_helper
INFO - 2020-09-12 07:04:18 --> Database Driver Class Initialized
INFO - 2020-09-12 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:04:18 --> Email Class Initialized
INFO - 2020-09-12 07:04:18 --> Controller Class Initialized
DEBUG - 2020-09-12 07:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:04:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:04:18 --> Model Class Initialized
INFO - 2020-09-12 07:04:18 --> Model Class Initialized
INFO - 2020-09-12 07:04:18 --> Model Class Initialized
ERROR - 2020-09-12 07:04:18 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:04:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:05:40 --> Config Class Initialized
INFO - 2020-09-12 07:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:05:40 --> Utf8 Class Initialized
INFO - 2020-09-12 07:05:40 --> URI Class Initialized
INFO - 2020-09-12 07:05:40 --> Router Class Initialized
INFO - 2020-09-12 07:05:40 --> Output Class Initialized
INFO - 2020-09-12 07:05:40 --> Security Class Initialized
DEBUG - 2020-09-12 07:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:05:40 --> Input Class Initialized
INFO - 2020-09-12 07:05:40 --> Language Class Initialized
INFO - 2020-09-12 07:05:40 --> Loader Class Initialized
INFO - 2020-09-12 07:05:40 --> Helper loaded: url_helper
INFO - 2020-09-12 07:05:40 --> Database Driver Class Initialized
INFO - 2020-09-12 07:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:05:40 --> Email Class Initialized
INFO - 2020-09-12 07:05:40 --> Controller Class Initialized
DEBUG - 2020-09-12 07:05:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:05:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:05:40 --> Model Class Initialized
INFO - 2020-09-12 07:05:40 --> Model Class Initialized
INFO - 2020-09-12 07:05:40 --> Model Class Initialized
INFO - 2020-09-12 07:05:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:05:40 --> Final output sent to browser
DEBUG - 2020-09-12 07:05:40 --> Total execution time: 0.0243
ERROR - 2020-09-12 07:06:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:06:57 --> Config Class Initialized
INFO - 2020-09-12 07:06:57 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:06:57 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:06:57 --> Utf8 Class Initialized
INFO - 2020-09-12 07:06:57 --> URI Class Initialized
INFO - 2020-09-12 07:06:57 --> Router Class Initialized
INFO - 2020-09-12 07:06:57 --> Output Class Initialized
INFO - 2020-09-12 07:06:57 --> Security Class Initialized
DEBUG - 2020-09-12 07:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:06:57 --> Input Class Initialized
INFO - 2020-09-12 07:06:57 --> Language Class Initialized
INFO - 2020-09-12 07:06:57 --> Loader Class Initialized
INFO - 2020-09-12 07:06:57 --> Helper loaded: url_helper
INFO - 2020-09-12 07:06:57 --> Database Driver Class Initialized
INFO - 2020-09-12 07:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:06:57 --> Email Class Initialized
INFO - 2020-09-12 07:06:57 --> Controller Class Initialized
DEBUG - 2020-09-12 07:06:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:06:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:06:57 --> Model Class Initialized
INFO - 2020-09-12 07:06:57 --> Model Class Initialized
INFO - 2020-09-12 07:06:57 --> Model Class Initialized
INFO - 2020-09-12 07:06:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:06:57 --> Final output sent to browser
DEBUG - 2020-09-12 07:06:57 --> Total execution time: 0.0191
ERROR - 2020-09-12 07:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:07:16 --> Config Class Initialized
INFO - 2020-09-12 07:07:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:07:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:07:16 --> Utf8 Class Initialized
INFO - 2020-09-12 07:07:16 --> URI Class Initialized
INFO - 2020-09-12 07:07:16 --> Router Class Initialized
INFO - 2020-09-12 07:07:16 --> Output Class Initialized
INFO - 2020-09-12 07:07:16 --> Security Class Initialized
DEBUG - 2020-09-12 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:07:16 --> Input Class Initialized
INFO - 2020-09-12 07:07:16 --> Language Class Initialized
INFO - 2020-09-12 07:07:16 --> Loader Class Initialized
INFO - 2020-09-12 07:07:16 --> Helper loaded: url_helper
INFO - 2020-09-12 07:07:16 --> Database Driver Class Initialized
INFO - 2020-09-12 07:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:07:16 --> Email Class Initialized
INFO - 2020-09-12 07:07:16 --> Controller Class Initialized
DEBUG - 2020-09-12 07:07:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:07:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:07:16 --> Model Class Initialized
INFO - 2020-09-12 07:07:16 --> Model Class Initialized
INFO - 2020-09-12 07:07:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:07:16 --> Final output sent to browser
DEBUG - 2020-09-12 07:07:16 --> Total execution time: 0.0189
ERROR - 2020-09-12 07:07:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:07:18 --> Config Class Initialized
INFO - 2020-09-12 07:07:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:07:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:07:18 --> Utf8 Class Initialized
INFO - 2020-09-12 07:07:18 --> URI Class Initialized
INFO - 2020-09-12 07:07:18 --> Router Class Initialized
INFO - 2020-09-12 07:07:18 --> Output Class Initialized
INFO - 2020-09-12 07:07:18 --> Security Class Initialized
DEBUG - 2020-09-12 07:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:07:18 --> Input Class Initialized
INFO - 2020-09-12 07:07:18 --> Language Class Initialized
INFO - 2020-09-12 07:07:18 --> Loader Class Initialized
INFO - 2020-09-12 07:07:18 --> Helper loaded: url_helper
INFO - 2020-09-12 07:07:18 --> Database Driver Class Initialized
INFO - 2020-09-12 07:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:07:18 --> Email Class Initialized
INFO - 2020-09-12 07:07:18 --> Controller Class Initialized
DEBUG - 2020-09-12 07:07:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:07:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:07:18 --> Model Class Initialized
INFO - 2020-09-12 07:07:18 --> Model Class Initialized
INFO - 2020-09-12 07:07:18 --> Model Class Initialized
INFO - 2020-09-12 07:07:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:07:18 --> Final output sent to browser
DEBUG - 2020-09-12 07:07:18 --> Total execution time: 0.0227
ERROR - 2020-09-12 07:07:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:07:22 --> Config Class Initialized
INFO - 2020-09-12 07:07:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:07:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:07:22 --> Utf8 Class Initialized
INFO - 2020-09-12 07:07:22 --> URI Class Initialized
INFO - 2020-09-12 07:07:22 --> Router Class Initialized
INFO - 2020-09-12 07:07:22 --> Output Class Initialized
INFO - 2020-09-12 07:07:22 --> Security Class Initialized
DEBUG - 2020-09-12 07:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:07:22 --> Input Class Initialized
INFO - 2020-09-12 07:07:22 --> Language Class Initialized
INFO - 2020-09-12 07:07:22 --> Loader Class Initialized
INFO - 2020-09-12 07:07:22 --> Helper loaded: url_helper
INFO - 2020-09-12 07:07:22 --> Database Driver Class Initialized
INFO - 2020-09-12 07:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:07:22 --> Email Class Initialized
INFO - 2020-09-12 07:07:22 --> Controller Class Initialized
DEBUG - 2020-09-12 07:07:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:07:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:07:22 --> Model Class Initialized
INFO - 2020-09-12 07:07:22 --> Model Class Initialized
INFO - 2020-09-12 07:07:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:07:22 --> Final output sent to browser
DEBUG - 2020-09-12 07:07:22 --> Total execution time: 0.0222
ERROR - 2020-09-12 07:07:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:07:25 --> Config Class Initialized
INFO - 2020-09-12 07:07:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:07:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:07:25 --> Utf8 Class Initialized
INFO - 2020-09-12 07:07:25 --> URI Class Initialized
INFO - 2020-09-12 07:07:25 --> Router Class Initialized
INFO - 2020-09-12 07:07:25 --> Output Class Initialized
INFO - 2020-09-12 07:07:25 --> Security Class Initialized
DEBUG - 2020-09-12 07:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:07:25 --> Input Class Initialized
INFO - 2020-09-12 07:07:25 --> Language Class Initialized
INFO - 2020-09-12 07:07:25 --> Loader Class Initialized
INFO - 2020-09-12 07:07:25 --> Helper loaded: url_helper
INFO - 2020-09-12 07:07:25 --> Database Driver Class Initialized
INFO - 2020-09-12 07:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:07:25 --> Email Class Initialized
INFO - 2020-09-12 07:07:25 --> Controller Class Initialized
DEBUG - 2020-09-12 07:07:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:07:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:07:25 --> Model Class Initialized
INFO - 2020-09-12 07:07:25 --> Model Class Initialized
INFO - 2020-09-12 07:07:25 --> Model Class Initialized
INFO - 2020-09-12 07:07:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:07:25 --> Final output sent to browser
DEBUG - 2020-09-12 07:07:25 --> Total execution time: 0.0259
ERROR - 2020-09-12 07:12:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:12:21 --> Config Class Initialized
INFO - 2020-09-12 07:12:21 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:12:21 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:12:21 --> Utf8 Class Initialized
INFO - 2020-09-12 07:12:21 --> URI Class Initialized
INFO - 2020-09-12 07:12:21 --> Router Class Initialized
INFO - 2020-09-12 07:12:21 --> Output Class Initialized
INFO - 2020-09-12 07:12:21 --> Security Class Initialized
DEBUG - 2020-09-12 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:12:21 --> Input Class Initialized
INFO - 2020-09-12 07:12:21 --> Language Class Initialized
INFO - 2020-09-12 07:12:21 --> Loader Class Initialized
INFO - 2020-09-12 07:12:21 --> Helper loaded: url_helper
INFO - 2020-09-12 07:12:21 --> Database Driver Class Initialized
INFO - 2020-09-12 07:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:12:21 --> Email Class Initialized
INFO - 2020-09-12 07:12:21 --> Controller Class Initialized
DEBUG - 2020-09-12 07:12:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:12:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:12:21 --> Model Class Initialized
INFO - 2020-09-12 07:12:21 --> Model Class Initialized
INFO - 2020-09-12 07:12:21 --> Model Class Initialized
INFO - 2020-09-12 07:12:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:12:21 --> Final output sent to browser
DEBUG - 2020-09-12 07:12:21 --> Total execution time: 0.0399
ERROR - 2020-09-12 07:12:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:12:26 --> Config Class Initialized
INFO - 2020-09-12 07:12:26 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:12:26 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:12:26 --> Utf8 Class Initialized
INFO - 2020-09-12 07:12:26 --> URI Class Initialized
INFO - 2020-09-12 07:12:26 --> Router Class Initialized
INFO - 2020-09-12 07:12:26 --> Output Class Initialized
INFO - 2020-09-12 07:12:26 --> Security Class Initialized
DEBUG - 2020-09-12 07:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:12:26 --> Input Class Initialized
INFO - 2020-09-12 07:12:26 --> Language Class Initialized
INFO - 2020-09-12 07:12:26 --> Loader Class Initialized
INFO - 2020-09-12 07:12:26 --> Helper loaded: url_helper
INFO - 2020-09-12 07:12:26 --> Database Driver Class Initialized
INFO - 2020-09-12 07:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:12:26 --> Email Class Initialized
INFO - 2020-09-12 07:12:26 --> Controller Class Initialized
DEBUG - 2020-09-12 07:12:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:12:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:12:26 --> Model Class Initialized
INFO - 2020-09-12 07:12:26 --> Model Class Initialized
INFO - 2020-09-12 07:12:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:12:26 --> Final output sent to browser
DEBUG - 2020-09-12 07:12:26 --> Total execution time: 0.0341
ERROR - 2020-09-12 07:13:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:13:20 --> Config Class Initialized
INFO - 2020-09-12 07:13:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:13:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:13:20 --> Utf8 Class Initialized
INFO - 2020-09-12 07:13:20 --> URI Class Initialized
INFO - 2020-09-12 07:13:20 --> Router Class Initialized
INFO - 2020-09-12 07:13:20 --> Output Class Initialized
INFO - 2020-09-12 07:13:20 --> Security Class Initialized
DEBUG - 2020-09-12 07:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:13:20 --> Input Class Initialized
INFO - 2020-09-12 07:13:20 --> Language Class Initialized
INFO - 2020-09-12 07:13:20 --> Loader Class Initialized
INFO - 2020-09-12 07:13:20 --> Helper loaded: url_helper
INFO - 2020-09-12 07:13:20 --> Database Driver Class Initialized
INFO - 2020-09-12 07:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:13:20 --> Email Class Initialized
INFO - 2020-09-12 07:13:20 --> Controller Class Initialized
DEBUG - 2020-09-12 07:13:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:13:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:13:20 --> Model Class Initialized
INFO - 2020-09-12 07:13:20 --> Model Class Initialized
INFO - 2020-09-12 07:13:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 07:13:20 --> Final output sent to browser
DEBUG - 2020-09-12 07:13:20 --> Total execution time: 0.0314
ERROR - 2020-09-12 07:13:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:13:22 --> Config Class Initialized
INFO - 2020-09-12 07:13:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:13:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:13:22 --> Utf8 Class Initialized
INFO - 2020-09-12 07:13:22 --> URI Class Initialized
INFO - 2020-09-12 07:13:22 --> Router Class Initialized
INFO - 2020-09-12 07:13:22 --> Output Class Initialized
INFO - 2020-09-12 07:13:22 --> Security Class Initialized
DEBUG - 2020-09-12 07:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:13:22 --> Input Class Initialized
INFO - 2020-09-12 07:13:22 --> Language Class Initialized
INFO - 2020-09-12 07:13:22 --> Loader Class Initialized
INFO - 2020-09-12 07:13:22 --> Helper loaded: url_helper
INFO - 2020-09-12 07:13:22 --> Database Driver Class Initialized
INFO - 2020-09-12 07:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:13:22 --> Email Class Initialized
INFO - 2020-09-12 07:13:22 --> Controller Class Initialized
DEBUG - 2020-09-12 07:13:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:13:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:13:22 --> Model Class Initialized
INFO - 2020-09-12 07:13:22 --> Model Class Initialized
INFO - 2020-09-12 07:13:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:13:22 --> Final output sent to browser
DEBUG - 2020-09-12 07:13:22 --> Total execution time: 0.0229
ERROR - 2020-09-12 07:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:13:25 --> Config Class Initialized
INFO - 2020-09-12 07:13:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:13:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:13:25 --> Utf8 Class Initialized
INFO - 2020-09-12 07:13:25 --> URI Class Initialized
INFO - 2020-09-12 07:13:25 --> Router Class Initialized
INFO - 2020-09-12 07:13:25 --> Output Class Initialized
INFO - 2020-09-12 07:13:25 --> Security Class Initialized
DEBUG - 2020-09-12 07:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:13:25 --> Input Class Initialized
INFO - 2020-09-12 07:13:25 --> Language Class Initialized
INFO - 2020-09-12 07:13:25 --> Loader Class Initialized
INFO - 2020-09-12 07:13:25 --> Helper loaded: url_helper
INFO - 2020-09-12 07:13:25 --> Database Driver Class Initialized
INFO - 2020-09-12 07:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:13:25 --> Email Class Initialized
INFO - 2020-09-12 07:13:25 --> Controller Class Initialized
DEBUG - 2020-09-12 07:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:13:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:13:25 --> Model Class Initialized
INFO - 2020-09-12 07:13:25 --> Model Class Initialized
INFO - 2020-09-12 07:13:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 07:13:25 --> Final output sent to browser
DEBUG - 2020-09-12 07:13:25 --> Total execution time: 0.0238
ERROR - 2020-09-12 07:13:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:13:27 --> Config Class Initialized
INFO - 2020-09-12 07:13:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:13:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:13:27 --> Utf8 Class Initialized
INFO - 2020-09-12 07:13:27 --> URI Class Initialized
INFO - 2020-09-12 07:13:27 --> Router Class Initialized
INFO - 2020-09-12 07:13:27 --> Output Class Initialized
INFO - 2020-09-12 07:13:27 --> Security Class Initialized
DEBUG - 2020-09-12 07:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:13:27 --> Input Class Initialized
INFO - 2020-09-12 07:13:27 --> Language Class Initialized
INFO - 2020-09-12 07:13:27 --> Loader Class Initialized
INFO - 2020-09-12 07:13:27 --> Helper loaded: url_helper
INFO - 2020-09-12 07:13:27 --> Database Driver Class Initialized
INFO - 2020-09-12 07:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:13:27 --> Email Class Initialized
INFO - 2020-09-12 07:13:27 --> Controller Class Initialized
DEBUG - 2020-09-12 07:13:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:13:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:13:27 --> Model Class Initialized
INFO - 2020-09-12 07:13:27 --> Model Class Initialized
INFO - 2020-09-12 07:13:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:13:27 --> Final output sent to browser
DEBUG - 2020-09-12 07:13:27 --> Total execution time: 0.0248
ERROR - 2020-09-12 07:13:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:13:34 --> Config Class Initialized
INFO - 2020-09-12 07:13:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:13:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:13:34 --> Utf8 Class Initialized
INFO - 2020-09-12 07:13:34 --> URI Class Initialized
INFO - 2020-09-12 07:13:34 --> Router Class Initialized
INFO - 2020-09-12 07:13:34 --> Output Class Initialized
INFO - 2020-09-12 07:13:34 --> Security Class Initialized
DEBUG - 2020-09-12 07:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:13:34 --> Input Class Initialized
INFO - 2020-09-12 07:13:34 --> Language Class Initialized
INFO - 2020-09-12 07:13:34 --> Loader Class Initialized
INFO - 2020-09-12 07:13:34 --> Helper loaded: url_helper
INFO - 2020-09-12 07:13:34 --> Database Driver Class Initialized
INFO - 2020-09-12 07:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:13:34 --> Email Class Initialized
INFO - 2020-09-12 07:13:34 --> Controller Class Initialized
DEBUG - 2020-09-12 07:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:13:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:13:34 --> Model Class Initialized
INFO - 2020-09-12 07:13:34 --> Model Class Initialized
INFO - 2020-09-12 07:13:34 --> Model Class Initialized
INFO - 2020-09-12 07:13:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:13:34 --> Final output sent to browser
DEBUG - 2020-09-12 07:13:34 --> Total execution time: 0.0251
ERROR - 2020-09-12 07:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:14:18 --> Config Class Initialized
INFO - 2020-09-12 07:14:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:14:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:14:18 --> Utf8 Class Initialized
INFO - 2020-09-12 07:14:18 --> URI Class Initialized
INFO - 2020-09-12 07:14:18 --> Router Class Initialized
INFO - 2020-09-12 07:14:18 --> Output Class Initialized
INFO - 2020-09-12 07:14:18 --> Security Class Initialized
DEBUG - 2020-09-12 07:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:14:18 --> Input Class Initialized
INFO - 2020-09-12 07:14:18 --> Language Class Initialized
INFO - 2020-09-12 07:14:18 --> Loader Class Initialized
INFO - 2020-09-12 07:14:18 --> Helper loaded: url_helper
INFO - 2020-09-12 07:14:18 --> Database Driver Class Initialized
INFO - 2020-09-12 07:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:14:18 --> Email Class Initialized
INFO - 2020-09-12 07:14:18 --> Controller Class Initialized
DEBUG - 2020-09-12 07:14:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:14:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:14:18 --> Model Class Initialized
INFO - 2020-09-12 07:14:18 --> Model Class Initialized
INFO - 2020-09-12 07:14:18 --> Model Class Initialized
INFO - 2020-09-12 07:14:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:14:18 --> Final output sent to browser
DEBUG - 2020-09-12 07:14:18 --> Total execution time: 0.0284
ERROR - 2020-09-12 07:14:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:14:21 --> Config Class Initialized
INFO - 2020-09-12 07:14:21 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:14:21 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:14:21 --> Utf8 Class Initialized
INFO - 2020-09-12 07:14:21 --> URI Class Initialized
INFO - 2020-09-12 07:14:21 --> Router Class Initialized
INFO - 2020-09-12 07:14:21 --> Output Class Initialized
INFO - 2020-09-12 07:14:21 --> Security Class Initialized
DEBUG - 2020-09-12 07:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:14:21 --> Input Class Initialized
INFO - 2020-09-12 07:14:21 --> Language Class Initialized
INFO - 2020-09-12 07:14:21 --> Loader Class Initialized
INFO - 2020-09-12 07:14:21 --> Helper loaded: url_helper
INFO - 2020-09-12 07:14:21 --> Database Driver Class Initialized
INFO - 2020-09-12 07:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:14:21 --> Email Class Initialized
INFO - 2020-09-12 07:14:21 --> Controller Class Initialized
DEBUG - 2020-09-12 07:14:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:14:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:14:21 --> Model Class Initialized
INFO - 2020-09-12 07:14:21 --> Model Class Initialized
INFO - 2020-09-12 07:14:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:14:21 --> Final output sent to browser
DEBUG - 2020-09-12 07:14:21 --> Total execution time: 0.0235
ERROR - 2020-09-12 07:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:14:24 --> Config Class Initialized
INFO - 2020-09-12 07:14:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:14:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:14:24 --> Utf8 Class Initialized
INFO - 2020-09-12 07:14:24 --> URI Class Initialized
INFO - 2020-09-12 07:14:24 --> Router Class Initialized
INFO - 2020-09-12 07:14:24 --> Output Class Initialized
INFO - 2020-09-12 07:14:24 --> Security Class Initialized
DEBUG - 2020-09-12 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:14:24 --> Input Class Initialized
INFO - 2020-09-12 07:14:24 --> Language Class Initialized
INFO - 2020-09-12 07:14:24 --> Loader Class Initialized
INFO - 2020-09-12 07:14:24 --> Helper loaded: url_helper
INFO - 2020-09-12 07:14:24 --> Database Driver Class Initialized
INFO - 2020-09-12 07:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:14:24 --> Email Class Initialized
INFO - 2020-09-12 07:14:24 --> Controller Class Initialized
DEBUG - 2020-09-12 07:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:14:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:14:24 --> Model Class Initialized
INFO - 2020-09-12 07:14:24 --> Model Class Initialized
INFO - 2020-09-12 07:14:24 --> Model Class Initialized
ERROR - 2020-09-12 07:14:24 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:14:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:21:05 --> Config Class Initialized
INFO - 2020-09-12 07:21:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:21:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:21:05 --> Utf8 Class Initialized
INFO - 2020-09-12 07:21:05 --> URI Class Initialized
INFO - 2020-09-12 07:21:05 --> Router Class Initialized
INFO - 2020-09-12 07:21:05 --> Output Class Initialized
INFO - 2020-09-12 07:21:05 --> Security Class Initialized
DEBUG - 2020-09-12 07:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:21:05 --> Input Class Initialized
INFO - 2020-09-12 07:21:05 --> Language Class Initialized
INFO - 2020-09-12 07:21:05 --> Loader Class Initialized
INFO - 2020-09-12 07:21:05 --> Helper loaded: url_helper
INFO - 2020-09-12 07:21:05 --> Database Driver Class Initialized
INFO - 2020-09-12 07:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:21:05 --> Email Class Initialized
INFO - 2020-09-12 07:21:05 --> Controller Class Initialized
DEBUG - 2020-09-12 07:21:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:21:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:21:05 --> Model Class Initialized
INFO - 2020-09-12 07:21:05 --> Model Class Initialized
INFO - 2020-09-12 07:21:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:21:05 --> Final output sent to browser
DEBUG - 2020-09-12 07:21:05 --> Total execution time: 0.0218
ERROR - 2020-09-12 07:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:21:24 --> Config Class Initialized
INFO - 2020-09-12 07:21:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:21:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:21:24 --> Utf8 Class Initialized
INFO - 2020-09-12 07:21:24 --> URI Class Initialized
INFO - 2020-09-12 07:21:24 --> Router Class Initialized
INFO - 2020-09-12 07:21:24 --> Output Class Initialized
INFO - 2020-09-12 07:21:24 --> Security Class Initialized
DEBUG - 2020-09-12 07:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:21:24 --> Input Class Initialized
INFO - 2020-09-12 07:21:24 --> Language Class Initialized
INFO - 2020-09-12 07:21:24 --> Loader Class Initialized
INFO - 2020-09-12 07:21:24 --> Helper loaded: url_helper
INFO - 2020-09-12 07:21:24 --> Database Driver Class Initialized
INFO - 2020-09-12 07:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:21:24 --> Email Class Initialized
INFO - 2020-09-12 07:21:24 --> Controller Class Initialized
DEBUG - 2020-09-12 07:21:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:21:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:21:24 --> Model Class Initialized
INFO - 2020-09-12 07:21:24 --> Model Class Initialized
INFO - 2020-09-12 07:21:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:21:24 --> Final output sent to browser
DEBUG - 2020-09-12 07:21:24 --> Total execution time: 0.0257
ERROR - 2020-09-12 07:21:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:21:28 --> Config Class Initialized
INFO - 2020-09-12 07:21:28 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:21:28 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:21:28 --> Utf8 Class Initialized
INFO - 2020-09-12 07:21:28 --> URI Class Initialized
INFO - 2020-09-12 07:21:28 --> Router Class Initialized
INFO - 2020-09-12 07:21:28 --> Output Class Initialized
INFO - 2020-09-12 07:21:28 --> Security Class Initialized
DEBUG - 2020-09-12 07:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:21:29 --> Input Class Initialized
INFO - 2020-09-12 07:21:29 --> Language Class Initialized
INFO - 2020-09-12 07:21:29 --> Loader Class Initialized
INFO - 2020-09-12 07:21:29 --> Helper loaded: url_helper
INFO - 2020-09-12 07:21:29 --> Database Driver Class Initialized
INFO - 2020-09-12 07:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:21:29 --> Email Class Initialized
INFO - 2020-09-12 07:21:29 --> Controller Class Initialized
DEBUG - 2020-09-12 07:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:21:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:21:29 --> Model Class Initialized
INFO - 2020-09-12 07:21:29 --> Model Class Initialized
INFO - 2020-09-12 07:21:29 --> Model Class Initialized
ERROR - 2020-09-12 07:21:29 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:21:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:21:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:21:29 --> Config Class Initialized
INFO - 2020-09-12 07:21:29 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:21:29 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:21:29 --> Utf8 Class Initialized
INFO - 2020-09-12 07:21:29 --> URI Class Initialized
INFO - 2020-09-12 07:21:29 --> Router Class Initialized
INFO - 2020-09-12 07:21:29 --> Output Class Initialized
INFO - 2020-09-12 07:21:29 --> Security Class Initialized
DEBUG - 2020-09-12 07:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:21:29 --> Input Class Initialized
INFO - 2020-09-12 07:21:29 --> Language Class Initialized
INFO - 2020-09-12 07:21:29 --> Loader Class Initialized
INFO - 2020-09-12 07:21:29 --> Helper loaded: url_helper
INFO - 2020-09-12 07:21:29 --> Database Driver Class Initialized
INFO - 2020-09-12 07:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:21:29 --> Email Class Initialized
INFO - 2020-09-12 07:21:29 --> Controller Class Initialized
DEBUG - 2020-09-12 07:21:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:21:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:21:29 --> Model Class Initialized
INFO - 2020-09-12 07:21:29 --> Model Class Initialized
INFO - 2020-09-12 07:21:29 --> Model Class Initialized
ERROR - 2020-09-12 07:21:29 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:21:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:21:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:21:41 --> Config Class Initialized
INFO - 2020-09-12 07:21:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:21:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:21:41 --> Utf8 Class Initialized
INFO - 2020-09-12 07:21:41 --> URI Class Initialized
INFO - 2020-09-12 07:21:41 --> Router Class Initialized
INFO - 2020-09-12 07:21:41 --> Output Class Initialized
INFO - 2020-09-12 07:21:41 --> Security Class Initialized
DEBUG - 2020-09-12 07:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:21:41 --> Input Class Initialized
INFO - 2020-09-12 07:21:41 --> Language Class Initialized
INFO - 2020-09-12 07:21:41 --> Loader Class Initialized
INFO - 2020-09-12 07:21:41 --> Helper loaded: url_helper
INFO - 2020-09-12 07:21:41 --> Database Driver Class Initialized
INFO - 2020-09-12 07:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:21:41 --> Email Class Initialized
INFO - 2020-09-12 07:21:41 --> Controller Class Initialized
DEBUG - 2020-09-12 07:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:21:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:21:41 --> Model Class Initialized
INFO - 2020-09-12 07:21:41 --> Model Class Initialized
INFO - 2020-09-12 07:21:41 --> Model Class Initialized
INFO - 2020-09-12 07:21:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:21:41 --> Final output sent to browser
DEBUG - 2020-09-12 07:21:41 --> Total execution time: 0.0260
ERROR - 2020-09-12 07:22:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:22:35 --> Config Class Initialized
INFO - 2020-09-12 07:22:35 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:22:35 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:22:35 --> Utf8 Class Initialized
INFO - 2020-09-12 07:22:35 --> URI Class Initialized
INFO - 2020-09-12 07:22:35 --> Router Class Initialized
INFO - 2020-09-12 07:22:35 --> Output Class Initialized
INFO - 2020-09-12 07:22:35 --> Security Class Initialized
DEBUG - 2020-09-12 07:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:22:35 --> Input Class Initialized
INFO - 2020-09-12 07:22:35 --> Language Class Initialized
INFO - 2020-09-12 07:22:35 --> Loader Class Initialized
INFO - 2020-09-12 07:22:35 --> Helper loaded: url_helper
INFO - 2020-09-12 07:22:35 --> Database Driver Class Initialized
INFO - 2020-09-12 07:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:22:35 --> Email Class Initialized
INFO - 2020-09-12 07:22:35 --> Controller Class Initialized
DEBUG - 2020-09-12 07:22:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:22:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:22:35 --> Model Class Initialized
INFO - 2020-09-12 07:22:35 --> Model Class Initialized
INFO - 2020-09-12 07:22:35 --> Model Class Initialized
INFO - 2020-09-12 07:22:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:22:35 --> Final output sent to browser
DEBUG - 2020-09-12 07:22:35 --> Total execution time: 0.0262
ERROR - 2020-09-12 07:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:23:18 --> Config Class Initialized
INFO - 2020-09-12 07:23:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:23:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:23:18 --> Utf8 Class Initialized
INFO - 2020-09-12 07:23:18 --> URI Class Initialized
INFO - 2020-09-12 07:23:18 --> Router Class Initialized
INFO - 2020-09-12 07:23:18 --> Output Class Initialized
INFO - 2020-09-12 07:23:18 --> Security Class Initialized
DEBUG - 2020-09-12 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:23:18 --> Input Class Initialized
INFO - 2020-09-12 07:23:18 --> Language Class Initialized
INFO - 2020-09-12 07:23:18 --> Loader Class Initialized
INFO - 2020-09-12 07:23:18 --> Helper loaded: url_helper
INFO - 2020-09-12 07:23:18 --> Database Driver Class Initialized
INFO - 2020-09-12 07:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:23:18 --> Email Class Initialized
INFO - 2020-09-12 07:23:18 --> Controller Class Initialized
DEBUG - 2020-09-12 07:23:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:23:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:23:18 --> Model Class Initialized
INFO - 2020-09-12 07:23:18 --> Model Class Initialized
INFO - 2020-09-12 07:23:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:23:18 --> Final output sent to browser
DEBUG - 2020-09-12 07:23:18 --> Total execution time: 0.0228
ERROR - 2020-09-12 07:23:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:23:35 --> Config Class Initialized
INFO - 2020-09-12 07:23:35 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:23:35 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:23:35 --> Utf8 Class Initialized
INFO - 2020-09-12 07:23:35 --> URI Class Initialized
INFO - 2020-09-12 07:23:35 --> Router Class Initialized
INFO - 2020-09-12 07:23:35 --> Output Class Initialized
INFO - 2020-09-12 07:23:35 --> Security Class Initialized
DEBUG - 2020-09-12 07:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:23:35 --> Input Class Initialized
INFO - 2020-09-12 07:23:35 --> Language Class Initialized
INFO - 2020-09-12 07:23:35 --> Loader Class Initialized
INFO - 2020-09-12 07:23:35 --> Helper loaded: url_helper
INFO - 2020-09-12 07:23:35 --> Database Driver Class Initialized
INFO - 2020-09-12 07:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:23:35 --> Email Class Initialized
INFO - 2020-09-12 07:23:35 --> Controller Class Initialized
DEBUG - 2020-09-12 07:23:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:23:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:23:35 --> Model Class Initialized
INFO - 2020-09-12 07:23:35 --> Model Class Initialized
INFO - 2020-09-12 07:23:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 07:23:35 --> Final output sent to browser
DEBUG - 2020-09-12 07:23:35 --> Total execution time: 0.0361
ERROR - 2020-09-12 07:23:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:23:42 --> Config Class Initialized
INFO - 2020-09-12 07:23:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:23:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:23:42 --> Utf8 Class Initialized
INFO - 2020-09-12 07:23:42 --> URI Class Initialized
INFO - 2020-09-12 07:23:42 --> Router Class Initialized
INFO - 2020-09-12 07:23:42 --> Output Class Initialized
INFO - 2020-09-12 07:23:42 --> Security Class Initialized
DEBUG - 2020-09-12 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:23:42 --> Input Class Initialized
INFO - 2020-09-12 07:23:42 --> Language Class Initialized
INFO - 2020-09-12 07:23:42 --> Loader Class Initialized
INFO - 2020-09-12 07:23:42 --> Helper loaded: url_helper
INFO - 2020-09-12 07:23:42 --> Database Driver Class Initialized
INFO - 2020-09-12 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:23:42 --> Email Class Initialized
INFO - 2020-09-12 07:23:42 --> Controller Class Initialized
DEBUG - 2020-09-12 07:23:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:23:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:23:42 --> Model Class Initialized
INFO - 2020-09-12 07:23:42 --> Model Class Initialized
INFO - 2020-09-12 07:23:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:23:42 --> Final output sent to browser
DEBUG - 2020-09-12 07:23:42 --> Total execution time: 0.0219
ERROR - 2020-09-12 07:23:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:23:48 --> Config Class Initialized
INFO - 2020-09-12 07:23:48 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:23:48 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:23:48 --> Utf8 Class Initialized
INFO - 2020-09-12 07:23:48 --> URI Class Initialized
INFO - 2020-09-12 07:23:48 --> Router Class Initialized
INFO - 2020-09-12 07:23:48 --> Output Class Initialized
INFO - 2020-09-12 07:23:48 --> Security Class Initialized
DEBUG - 2020-09-12 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:23:48 --> Input Class Initialized
INFO - 2020-09-12 07:23:48 --> Language Class Initialized
INFO - 2020-09-12 07:23:48 --> Loader Class Initialized
INFO - 2020-09-12 07:23:48 --> Helper loaded: url_helper
INFO - 2020-09-12 07:23:48 --> Database Driver Class Initialized
INFO - 2020-09-12 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:23:48 --> Email Class Initialized
INFO - 2020-09-12 07:23:48 --> Controller Class Initialized
DEBUG - 2020-09-12 07:23:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:23:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:23:48 --> Model Class Initialized
INFO - 2020-09-12 07:23:48 --> Model Class Initialized
INFO - 2020-09-12 07:23:48 --> Model Class Initialized
ERROR - 2020-09-12 07:23:48 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:23:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:26:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:01 --> Config Class Initialized
INFO - 2020-09-12 07:26:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:01 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:01 --> URI Class Initialized
INFO - 2020-09-12 07:26:01 --> Router Class Initialized
INFO - 2020-09-12 07:26:01 --> Output Class Initialized
INFO - 2020-09-12 07:26:01 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:01 --> Input Class Initialized
INFO - 2020-09-12 07:26:01 --> Language Class Initialized
INFO - 2020-09-12 07:26:01 --> Loader Class Initialized
INFO - 2020-09-12 07:26:01 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:01 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:01 --> Email Class Initialized
INFO - 2020-09-12 07:26:01 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:01 --> Model Class Initialized
INFO - 2020-09-12 07:26:01 --> Model Class Initialized
INFO - 2020-09-12 07:26:01 --> Model Class Initialized
ERROR - 2020-09-12 07:26:01 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(1)
INFO - 2020-09-12 07:26:01 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:03 --> Config Class Initialized
INFO - 2020-09-12 07:26:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:03 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:03 --> URI Class Initialized
INFO - 2020-09-12 07:26:03 --> Router Class Initialized
INFO - 2020-09-12 07:26:03 --> Output Class Initialized
INFO - 2020-09-12 07:26:03 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:03 --> Input Class Initialized
INFO - 2020-09-12 07:26:03 --> Language Class Initialized
INFO - 2020-09-12 07:26:03 --> Loader Class Initialized
INFO - 2020-09-12 07:26:03 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:03 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:03 --> Email Class Initialized
INFO - 2020-09-12 07:26:03 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:03 --> Model Class Initialized
INFO - 2020-09-12 07:26:03 --> Model Class Initialized
INFO - 2020-09-12 07:26:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:26:03 --> Final output sent to browser
DEBUG - 2020-09-12 07:26:03 --> Total execution time: 0.0282
ERROR - 2020-09-12 07:26:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:06 --> Config Class Initialized
INFO - 2020-09-12 07:26:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:06 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:06 --> URI Class Initialized
INFO - 2020-09-12 07:26:06 --> Router Class Initialized
INFO - 2020-09-12 07:26:06 --> Output Class Initialized
INFO - 2020-09-12 07:26:06 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:06 --> Input Class Initialized
INFO - 2020-09-12 07:26:06 --> Language Class Initialized
INFO - 2020-09-12 07:26:06 --> Loader Class Initialized
INFO - 2020-09-12 07:26:06 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:06 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:06 --> Email Class Initialized
INFO - 2020-09-12 07:26:06 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:06 --> Model Class Initialized
INFO - 2020-09-12 07:26:06 --> Model Class Initialized
INFO - 2020-09-12 07:26:06 --> Model Class Initialized
ERROR - 2020-09-12 07:26:06 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL campain_edit(2)
INFO - 2020-09-12 07:26:06 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 07:26:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:27 --> Config Class Initialized
INFO - 2020-09-12 07:26:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:27 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:27 --> URI Class Initialized
INFO - 2020-09-12 07:26:27 --> Router Class Initialized
INFO - 2020-09-12 07:26:27 --> Output Class Initialized
INFO - 2020-09-12 07:26:27 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:27 --> Input Class Initialized
INFO - 2020-09-12 07:26:27 --> Language Class Initialized
INFO - 2020-09-12 07:26:27 --> Loader Class Initialized
INFO - 2020-09-12 07:26:27 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:27 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:27 --> Email Class Initialized
INFO - 2020-09-12 07:26:27 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:27 --> Model Class Initialized
INFO - 2020-09-12 07:26:27 --> Model Class Initialized
INFO - 2020-09-12 07:26:27 --> Model Class Initialized
INFO - 2020-09-12 07:26:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:26:27 --> Final output sent to browser
DEBUG - 2020-09-12 07:26:27 --> Total execution time: 0.0261
ERROR - 2020-09-12 07:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:34 --> Config Class Initialized
INFO - 2020-09-12 07:26:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:34 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:34 --> URI Class Initialized
INFO - 2020-09-12 07:26:34 --> Router Class Initialized
INFO - 2020-09-12 07:26:34 --> Output Class Initialized
INFO - 2020-09-12 07:26:34 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:34 --> Input Class Initialized
INFO - 2020-09-12 07:26:34 --> Language Class Initialized
INFO - 2020-09-12 07:26:34 --> Loader Class Initialized
INFO - 2020-09-12 07:26:34 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:34 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:34 --> Email Class Initialized
INFO - 2020-09-12 07:26:34 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:34 --> Model Class Initialized
INFO - 2020-09-12 07:26:34 --> Model Class Initialized
INFO - 2020-09-12 07:26:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:26:34 --> Final output sent to browser
DEBUG - 2020-09-12 07:26:34 --> Total execution time: 0.2308
ERROR - 2020-09-12 07:26:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:37 --> Config Class Initialized
INFO - 2020-09-12 07:26:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:37 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:37 --> URI Class Initialized
INFO - 2020-09-12 07:26:37 --> Router Class Initialized
INFO - 2020-09-12 07:26:37 --> Output Class Initialized
INFO - 2020-09-12 07:26:37 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:37 --> Input Class Initialized
INFO - 2020-09-12 07:26:37 --> Language Class Initialized
INFO - 2020-09-12 07:26:37 --> Loader Class Initialized
INFO - 2020-09-12 07:26:37 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:37 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:37 --> Email Class Initialized
INFO - 2020-09-12 07:26:37 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:37 --> Model Class Initialized
INFO - 2020-09-12 07:26:37 --> Model Class Initialized
INFO - 2020-09-12 07:26:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 07:26:37 --> Final output sent to browser
DEBUG - 2020-09-12 07:26:37 --> Total execution time: 0.0344
ERROR - 2020-09-12 07:26:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:40 --> Config Class Initialized
INFO - 2020-09-12 07:26:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:40 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:40 --> URI Class Initialized
INFO - 2020-09-12 07:26:40 --> Router Class Initialized
INFO - 2020-09-12 07:26:40 --> Output Class Initialized
INFO - 2020-09-12 07:26:40 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:40 --> Input Class Initialized
INFO - 2020-09-12 07:26:40 --> Language Class Initialized
INFO - 2020-09-12 07:26:40 --> Loader Class Initialized
INFO - 2020-09-12 07:26:40 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:40 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:40 --> Email Class Initialized
INFO - 2020-09-12 07:26:40 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:40 --> Model Class Initialized
INFO - 2020-09-12 07:26:40 --> Model Class Initialized
INFO - 2020-09-12 07:26:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-12 07:26:40 --> Final output sent to browser
DEBUG - 2020-09-12 07:26:40 --> Total execution time: 0.0284
ERROR - 2020-09-12 07:26:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:26:44 --> Config Class Initialized
INFO - 2020-09-12 07:26:44 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:26:44 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:26:44 --> Utf8 Class Initialized
INFO - 2020-09-12 07:26:44 --> URI Class Initialized
INFO - 2020-09-12 07:26:44 --> Router Class Initialized
INFO - 2020-09-12 07:26:44 --> Output Class Initialized
INFO - 2020-09-12 07:26:44 --> Security Class Initialized
DEBUG - 2020-09-12 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:26:44 --> Input Class Initialized
INFO - 2020-09-12 07:26:44 --> Language Class Initialized
INFO - 2020-09-12 07:26:44 --> Loader Class Initialized
INFO - 2020-09-12 07:26:44 --> Helper loaded: url_helper
INFO - 2020-09-12 07:26:44 --> Database Driver Class Initialized
INFO - 2020-09-12 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:26:44 --> Email Class Initialized
INFO - 2020-09-12 07:26:44 --> Controller Class Initialized
DEBUG - 2020-09-12 07:26:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:26:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:26:44 --> Model Class Initialized
INFO - 2020-09-12 07:26:44 --> Model Class Initialized
INFO - 2020-09-12 07:26:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 07:26:44 --> Final output sent to browser
DEBUG - 2020-09-12 07:26:44 --> Total execution time: 0.0252
ERROR - 2020-09-12 07:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:01 --> Config Class Initialized
INFO - 2020-09-12 07:27:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:01 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:01 --> URI Class Initialized
INFO - 2020-09-12 07:27:01 --> Router Class Initialized
INFO - 2020-09-12 07:27:01 --> Output Class Initialized
INFO - 2020-09-12 07:27:01 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:01 --> Input Class Initialized
INFO - 2020-09-12 07:27:01 --> Language Class Initialized
INFO - 2020-09-12 07:27:01 --> Loader Class Initialized
INFO - 2020-09-12 07:27:01 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:01 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:01 --> Email Class Initialized
INFO - 2020-09-12 07:27:01 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:01 --> Model Class Initialized
INFO - 2020-09-12 07:27:01 --> Model Class Initialized
INFO - 2020-09-12 07:27:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 07:27:01 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:01 --> Total execution time: 0.0253
ERROR - 2020-09-12 07:27:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:07 --> Config Class Initialized
INFO - 2020-09-12 07:27:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:07 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:07 --> URI Class Initialized
INFO - 2020-09-12 07:27:07 --> Router Class Initialized
INFO - 2020-09-12 07:27:07 --> Output Class Initialized
INFO - 2020-09-12 07:27:07 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:07 --> Input Class Initialized
INFO - 2020-09-12 07:27:07 --> Language Class Initialized
INFO - 2020-09-12 07:27:07 --> Loader Class Initialized
INFO - 2020-09-12 07:27:07 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:07 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:07 --> Email Class Initialized
INFO - 2020-09-12 07:27:07 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 07:27:07 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:07 --> Total execution time: 0.0204
ERROR - 2020-09-12 07:27:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:09 --> Config Class Initialized
INFO - 2020-09-12 07:27:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:09 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:09 --> URI Class Initialized
INFO - 2020-09-12 07:27:09 --> Router Class Initialized
INFO - 2020-09-12 07:27:09 --> Output Class Initialized
INFO - 2020-09-12 07:27:09 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:09 --> Input Class Initialized
INFO - 2020-09-12 07:27:09 --> Language Class Initialized
INFO - 2020-09-12 07:27:09 --> Loader Class Initialized
INFO - 2020-09-12 07:27:09 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:09 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:09 --> Email Class Initialized
INFO - 2020-09-12 07:27:09 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:09 --> Model Class Initialized
INFO - 2020-09-12 07:27:09 --> Model Class Initialized
INFO - 2020-09-12 07:27:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:27:09 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:09 --> Total execution time: 0.0283
ERROR - 2020-09-12 07:27:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:14 --> Config Class Initialized
INFO - 2020-09-12 07:27:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:14 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:14 --> URI Class Initialized
INFO - 2020-09-12 07:27:14 --> Router Class Initialized
INFO - 2020-09-12 07:27:14 --> Output Class Initialized
INFO - 2020-09-12 07:27:14 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:14 --> Input Class Initialized
INFO - 2020-09-12 07:27:14 --> Language Class Initialized
INFO - 2020-09-12 07:27:14 --> Loader Class Initialized
INFO - 2020-09-12 07:27:14 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:14 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:14 --> Email Class Initialized
INFO - 2020-09-12 07:27:14 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:14 --> Model Class Initialized
INFO - 2020-09-12 07:27:14 --> Model Class Initialized
INFO - 2020-09-12 07:27:14 --> Model Class Initialized
INFO - 2020-09-12 07:27:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:27:14 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:14 --> Total execution time: 0.0246
ERROR - 2020-09-12 07:27:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:23 --> Config Class Initialized
INFO - 2020-09-12 07:27:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:23 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:23 --> URI Class Initialized
INFO - 2020-09-12 07:27:23 --> Router Class Initialized
INFO - 2020-09-12 07:27:23 --> Output Class Initialized
INFO - 2020-09-12 07:27:23 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:23 --> Input Class Initialized
INFO - 2020-09-12 07:27:23 --> Language Class Initialized
INFO - 2020-09-12 07:27:23 --> Loader Class Initialized
INFO - 2020-09-12 07:27:23 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:23 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:23 --> Email Class Initialized
INFO - 2020-09-12 07:27:23 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:23 --> Model Class Initialized
INFO - 2020-09-12 07:27:23 --> Model Class Initialized
INFO - 2020-09-12 07:27:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:27:23 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:23 --> Total execution time: 0.0237
ERROR - 2020-09-12 07:27:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:28 --> Config Class Initialized
INFO - 2020-09-12 07:27:28 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:28 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:28 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:28 --> URI Class Initialized
INFO - 2020-09-12 07:27:28 --> Router Class Initialized
INFO - 2020-09-12 07:27:28 --> Output Class Initialized
INFO - 2020-09-12 07:27:28 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:28 --> Input Class Initialized
INFO - 2020-09-12 07:27:28 --> Language Class Initialized
INFO - 2020-09-12 07:27:28 --> Loader Class Initialized
INFO - 2020-09-12 07:27:28 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:28 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:28 --> Email Class Initialized
INFO - 2020-09-12 07:27:28 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:28 --> Model Class Initialized
INFO - 2020-09-12 07:27:28 --> Model Class Initialized
INFO - 2020-09-12 07:27:28 --> Model Class Initialized
INFO - 2020-09-12 07:27:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:27:28 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:28 --> Total execution time: 0.0272
ERROR - 2020-09-12 07:27:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:27:34 --> Config Class Initialized
INFO - 2020-09-12 07:27:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:27:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:27:34 --> Utf8 Class Initialized
INFO - 2020-09-12 07:27:34 --> URI Class Initialized
INFO - 2020-09-12 07:27:34 --> Router Class Initialized
INFO - 2020-09-12 07:27:34 --> Output Class Initialized
INFO - 2020-09-12 07:27:34 --> Security Class Initialized
DEBUG - 2020-09-12 07:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:27:34 --> Input Class Initialized
INFO - 2020-09-12 07:27:34 --> Language Class Initialized
INFO - 2020-09-12 07:27:34 --> Loader Class Initialized
INFO - 2020-09-12 07:27:34 --> Helper loaded: url_helper
INFO - 2020-09-12 07:27:34 --> Database Driver Class Initialized
INFO - 2020-09-12 07:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:27:34 --> Email Class Initialized
INFO - 2020-09-12 07:27:34 --> Controller Class Initialized
DEBUG - 2020-09-12 07:27:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:27:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:27:34 --> Model Class Initialized
INFO - 2020-09-12 07:27:34 --> Model Class Initialized
INFO - 2020-09-12 07:27:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:27:34 --> Final output sent to browser
DEBUG - 2020-09-12 07:27:34 --> Total execution time: 0.0234
ERROR - 2020-09-12 07:28:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:01 --> Config Class Initialized
INFO - 2020-09-12 07:28:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:01 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:01 --> URI Class Initialized
INFO - 2020-09-12 07:28:01 --> Router Class Initialized
INFO - 2020-09-12 07:28:01 --> Output Class Initialized
INFO - 2020-09-12 07:28:01 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:01 --> Input Class Initialized
INFO - 2020-09-12 07:28:01 --> Language Class Initialized
INFO - 2020-09-12 07:28:01 --> Loader Class Initialized
INFO - 2020-09-12 07:28:01 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:01 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:01 --> Email Class Initialized
INFO - 2020-09-12 07:28:01 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:01 --> Model Class Initialized
INFO - 2020-09-12 07:28:01 --> Model Class Initialized
INFO - 2020-09-12 07:28:01 --> Model Class Initialized
INFO - 2020-09-12 07:28:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:28:01 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:01 --> Total execution time: 0.0292
ERROR - 2020-09-12 07:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:08 --> Config Class Initialized
INFO - 2020-09-12 07:28:08 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:08 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:08 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:08 --> URI Class Initialized
INFO - 2020-09-12 07:28:08 --> Router Class Initialized
INFO - 2020-09-12 07:28:08 --> Output Class Initialized
INFO - 2020-09-12 07:28:08 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:08 --> Input Class Initialized
INFO - 2020-09-12 07:28:08 --> Language Class Initialized
INFO - 2020-09-12 07:28:08 --> Loader Class Initialized
INFO - 2020-09-12 07:28:08 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:08 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:08 --> Email Class Initialized
INFO - 2020-09-12 07:28:08 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:08 --> Model Class Initialized
INFO - 2020-09-12 07:28:08 --> Model Class Initialized
INFO - 2020-09-12 07:28:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:28:08 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:08 --> Total execution time: 0.0213
ERROR - 2020-09-12 07:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:13 --> Config Class Initialized
INFO - 2020-09-12 07:28:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:13 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:13 --> URI Class Initialized
INFO - 2020-09-12 07:28:13 --> Router Class Initialized
INFO - 2020-09-12 07:28:13 --> Output Class Initialized
INFO - 2020-09-12 07:28:13 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:13 --> Input Class Initialized
INFO - 2020-09-12 07:28:13 --> Language Class Initialized
INFO - 2020-09-12 07:28:13 --> Loader Class Initialized
INFO - 2020-09-12 07:28:13 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:13 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:13 --> Email Class Initialized
INFO - 2020-09-12 07:28:13 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:13 --> Model Class Initialized
INFO - 2020-09-12 07:28:13 --> Model Class Initialized
INFO - 2020-09-12 07:28:13 --> Model Class Initialized
INFO - 2020-09-12 07:28:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:28:13 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:13 --> Total execution time: 0.0248
ERROR - 2020-09-12 07:28:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:17 --> Config Class Initialized
INFO - 2020-09-12 07:28:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:17 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:17 --> URI Class Initialized
INFO - 2020-09-12 07:28:17 --> Router Class Initialized
INFO - 2020-09-12 07:28:17 --> Output Class Initialized
INFO - 2020-09-12 07:28:17 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:17 --> Input Class Initialized
INFO - 2020-09-12 07:28:17 --> Language Class Initialized
INFO - 2020-09-12 07:28:17 --> Loader Class Initialized
INFO - 2020-09-12 07:28:17 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:17 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:17 --> Email Class Initialized
INFO - 2020-09-12 07:28:17 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:17 --> Model Class Initialized
INFO - 2020-09-12 07:28:17 --> Model Class Initialized
INFO - 2020-09-12 07:28:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:28:17 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:17 --> Total execution time: 0.0307
ERROR - 2020-09-12 07:28:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:20 --> Config Class Initialized
INFO - 2020-09-12 07:28:20 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:20 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:20 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:20 --> URI Class Initialized
INFO - 2020-09-12 07:28:20 --> Router Class Initialized
INFO - 2020-09-12 07:28:20 --> Output Class Initialized
INFO - 2020-09-12 07:28:20 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:20 --> Input Class Initialized
INFO - 2020-09-12 07:28:20 --> Language Class Initialized
INFO - 2020-09-12 07:28:20 --> Loader Class Initialized
INFO - 2020-09-12 07:28:20 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:20 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:20 --> Email Class Initialized
INFO - 2020-09-12 07:28:20 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:20 --> Model Class Initialized
INFO - 2020-09-12 07:28:20 --> Model Class Initialized
INFO - 2020-09-12 07:28:20 --> Model Class Initialized
INFO - 2020-09-12 07:28:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 07:28:20 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:20 --> Total execution time: 0.0250
ERROR - 2020-09-12 07:28:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:23 --> Config Class Initialized
INFO - 2020-09-12 07:28:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:23 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:23 --> URI Class Initialized
INFO - 2020-09-12 07:28:23 --> Router Class Initialized
INFO - 2020-09-12 07:28:23 --> Output Class Initialized
INFO - 2020-09-12 07:28:23 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:23 --> Input Class Initialized
INFO - 2020-09-12 07:28:23 --> Language Class Initialized
INFO - 2020-09-12 07:28:23 --> Loader Class Initialized
INFO - 2020-09-12 07:28:23 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:23 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:23 --> Email Class Initialized
INFO - 2020-09-12 07:28:23 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:23 --> Model Class Initialized
INFO - 2020-09-12 07:28:23 --> Model Class Initialized
INFO - 2020-09-12 07:28:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:28:23 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:23 --> Total execution time: 0.0209
ERROR - 2020-09-12 07:28:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:28:25 --> Config Class Initialized
INFO - 2020-09-12 07:28:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:28:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:28:25 --> Utf8 Class Initialized
INFO - 2020-09-12 07:28:25 --> URI Class Initialized
INFO - 2020-09-12 07:28:25 --> Router Class Initialized
INFO - 2020-09-12 07:28:25 --> Output Class Initialized
INFO - 2020-09-12 07:28:25 --> Security Class Initialized
DEBUG - 2020-09-12 07:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:28:25 --> Input Class Initialized
INFO - 2020-09-12 07:28:25 --> Language Class Initialized
INFO - 2020-09-12 07:28:25 --> Loader Class Initialized
INFO - 2020-09-12 07:28:25 --> Helper loaded: url_helper
INFO - 2020-09-12 07:28:25 --> Database Driver Class Initialized
INFO - 2020-09-12 07:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:28:25 --> Email Class Initialized
INFO - 2020-09-12 07:28:25 --> Controller Class Initialized
DEBUG - 2020-09-12 07:28:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:28:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:28:25 --> Model Class Initialized
INFO - 2020-09-12 07:28:25 --> Model Class Initialized
INFO - 2020-09-12 07:28:25 --> Model Class Initialized
INFO - 2020-09-12 07:28:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:28:25 --> Final output sent to browser
DEBUG - 2020-09-12 07:28:25 --> Total execution time: 0.0260
ERROR - 2020-09-12 07:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:29:02 --> Config Class Initialized
INFO - 2020-09-12 07:29:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:29:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:29:02 --> Utf8 Class Initialized
INFO - 2020-09-12 07:29:02 --> URI Class Initialized
INFO - 2020-09-12 07:29:02 --> Router Class Initialized
INFO - 2020-09-12 07:29:02 --> Output Class Initialized
INFO - 2020-09-12 07:29:02 --> Security Class Initialized
DEBUG - 2020-09-12 07:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:29:02 --> Input Class Initialized
INFO - 2020-09-12 07:29:02 --> Language Class Initialized
INFO - 2020-09-12 07:29:02 --> Loader Class Initialized
INFO - 2020-09-12 07:29:02 --> Helper loaded: url_helper
INFO - 2020-09-12 07:29:02 --> Database Driver Class Initialized
INFO - 2020-09-12 07:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:29:02 --> Email Class Initialized
INFO - 2020-09-12 07:29:02 --> Controller Class Initialized
DEBUG - 2020-09-12 07:29:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:29:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:29:02 --> Model Class Initialized
INFO - 2020-09-12 07:29:02 --> Model Class Initialized
INFO - 2020-09-12 07:29:02 --> Model Class Initialized
INFO - 2020-09-12 07:29:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:29:02 --> Final output sent to browser
DEBUG - 2020-09-12 07:29:02 --> Total execution time: 0.0608
ERROR - 2020-09-12 07:29:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:29:04 --> Config Class Initialized
INFO - 2020-09-12 07:29:04 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:29:04 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:29:04 --> Utf8 Class Initialized
INFO - 2020-09-12 07:29:04 --> URI Class Initialized
INFO - 2020-09-12 07:29:04 --> Router Class Initialized
INFO - 2020-09-12 07:29:04 --> Output Class Initialized
INFO - 2020-09-12 07:29:04 --> Security Class Initialized
DEBUG - 2020-09-12 07:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:29:04 --> Input Class Initialized
INFO - 2020-09-12 07:29:04 --> Language Class Initialized
INFO - 2020-09-12 07:29:04 --> Loader Class Initialized
INFO - 2020-09-12 07:29:04 --> Helper loaded: url_helper
INFO - 2020-09-12 07:29:04 --> Database Driver Class Initialized
INFO - 2020-09-12 07:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:29:04 --> Email Class Initialized
INFO - 2020-09-12 07:29:04 --> Controller Class Initialized
DEBUG - 2020-09-12 07:29:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:29:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:29:04 --> Model Class Initialized
INFO - 2020-09-12 07:29:04 --> Model Class Initialized
INFO - 2020-09-12 07:29:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:29:04 --> Final output sent to browser
DEBUG - 2020-09-12 07:29:04 --> Total execution time: 0.0364
ERROR - 2020-09-12 07:29:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:29:39 --> Config Class Initialized
INFO - 2020-09-12 07:29:39 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:29:39 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:29:39 --> Utf8 Class Initialized
INFO - 2020-09-12 07:29:39 --> URI Class Initialized
INFO - 2020-09-12 07:29:39 --> Router Class Initialized
INFO - 2020-09-12 07:29:39 --> Output Class Initialized
INFO - 2020-09-12 07:29:39 --> Security Class Initialized
DEBUG - 2020-09-12 07:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:29:39 --> Input Class Initialized
INFO - 2020-09-12 07:29:39 --> Language Class Initialized
INFO - 2020-09-12 07:29:39 --> Loader Class Initialized
INFO - 2020-09-12 07:29:39 --> Helper loaded: url_helper
INFO - 2020-09-12 07:29:39 --> Database Driver Class Initialized
INFO - 2020-09-12 07:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:29:39 --> Email Class Initialized
INFO - 2020-09-12 07:29:39 --> Controller Class Initialized
DEBUG - 2020-09-12 07:29:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:29:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:29:39 --> Model Class Initialized
INFO - 2020-09-12 07:29:39 --> Model Class Initialized
INFO - 2020-09-12 07:29:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:29:39 --> Final output sent to browser
DEBUG - 2020-09-12 07:29:39 --> Total execution time: 0.0233
ERROR - 2020-09-12 07:29:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:29:42 --> Config Class Initialized
INFO - 2020-09-12 07:29:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:29:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:29:42 --> Utf8 Class Initialized
INFO - 2020-09-12 07:29:42 --> URI Class Initialized
INFO - 2020-09-12 07:29:42 --> Router Class Initialized
INFO - 2020-09-12 07:29:42 --> Output Class Initialized
INFO - 2020-09-12 07:29:42 --> Security Class Initialized
DEBUG - 2020-09-12 07:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:29:42 --> Input Class Initialized
INFO - 2020-09-12 07:29:42 --> Language Class Initialized
INFO - 2020-09-12 07:29:42 --> Loader Class Initialized
INFO - 2020-09-12 07:29:42 --> Helper loaded: url_helper
INFO - 2020-09-12 07:29:42 --> Database Driver Class Initialized
INFO - 2020-09-12 07:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:29:42 --> Email Class Initialized
INFO - 2020-09-12 07:29:42 --> Controller Class Initialized
DEBUG - 2020-09-12 07:29:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:29:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:29:42 --> Model Class Initialized
INFO - 2020-09-12 07:29:42 --> Model Class Initialized
INFO - 2020-09-12 07:29:42 --> Model Class Initialized
INFO - 2020-09-12 07:29:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 07:29:42 --> Final output sent to browser
DEBUG - 2020-09-12 07:29:42 --> Total execution time: 0.0229
ERROR - 2020-09-12 07:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-12 07:29:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:29:50 --> Config Class Initialized
INFO - 2020-09-12 07:29:50 --> Hooks Class Initialized
INFO - 2020-09-12 07:29:50 --> Config Class Initialized
INFO - 2020-09-12 07:29:50 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:29:50 --> Utf8 Class Initialized
INFO - 2020-09-12 07:29:50 --> URI Class Initialized
DEBUG - 2020-09-12 07:29:50 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:29:50 --> Utf8 Class Initialized
INFO - 2020-09-12 07:29:50 --> Router Class Initialized
INFO - 2020-09-12 07:29:50 --> URI Class Initialized
INFO - 2020-09-12 07:29:50 --> Output Class Initialized
INFO - 2020-09-12 07:29:50 --> Router Class Initialized
INFO - 2020-09-12 07:29:50 --> Security Class Initialized
INFO - 2020-09-12 07:29:50 --> Output Class Initialized
DEBUG - 2020-09-12 07:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:29:50 --> Input Class Initialized
INFO - 2020-09-12 07:29:50 --> Language Class Initialized
INFO - 2020-09-12 07:29:50 --> Security Class Initialized
DEBUG - 2020-09-12 07:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:29:50 --> Input Class Initialized
INFO - 2020-09-12 07:29:50 --> Language Class Initialized
INFO - 2020-09-12 07:29:50 --> Loader Class Initialized
INFO - 2020-09-12 07:29:50 --> Helper loaded: url_helper
INFO - 2020-09-12 07:29:50 --> Loader Class Initialized
INFO - 2020-09-12 07:29:50 --> Helper loaded: url_helper
INFO - 2020-09-12 07:29:50 --> Database Driver Class Initialized
INFO - 2020-09-12 07:29:50 --> Database Driver Class Initialized
INFO - 2020-09-12 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:29:50 --> Email Class Initialized
INFO - 2020-09-12 07:29:50 --> Controller Class Initialized
DEBUG - 2020-09-12 07:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:29:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:29:50 --> Model Class Initialized
INFO - 2020-09-12 07:29:50 --> Model Class Initialized
INFO - 2020-09-12 07:29:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:29:50 --> Final output sent to browser
DEBUG - 2020-09-12 07:29:50 --> Total execution time: 0.0314
INFO - 2020-09-12 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:29:50 --> Email Class Initialized
INFO - 2020-09-12 07:29:50 --> Controller Class Initialized
DEBUG - 2020-09-12 07:29:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:29:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:29:50 --> Model Class Initialized
INFO - 2020-09-12 07:29:50 --> Model Class Initialized
INFO - 2020-09-12 07:29:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 07:29:50 --> Final output sent to browser
DEBUG - 2020-09-12 07:29:50 --> Total execution time: 0.0379
ERROR - 2020-09-12 07:30:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:30:26 --> Config Class Initialized
INFO - 2020-09-12 07:30:26 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:30:26 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:30:26 --> Utf8 Class Initialized
INFO - 2020-09-12 07:30:26 --> URI Class Initialized
INFO - 2020-09-12 07:30:26 --> Router Class Initialized
INFO - 2020-09-12 07:30:26 --> Output Class Initialized
INFO - 2020-09-12 07:30:26 --> Security Class Initialized
DEBUG - 2020-09-12 07:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:30:26 --> Input Class Initialized
INFO - 2020-09-12 07:30:26 --> Language Class Initialized
INFO - 2020-09-12 07:30:26 --> Loader Class Initialized
INFO - 2020-09-12 07:30:26 --> Helper loaded: url_helper
INFO - 2020-09-12 07:30:26 --> Database Driver Class Initialized
INFO - 2020-09-12 07:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:30:26 --> Email Class Initialized
INFO - 2020-09-12 07:30:26 --> Controller Class Initialized
DEBUG - 2020-09-12 07:30:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:30:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:30:26 --> Model Class Initialized
INFO - 2020-09-12 07:30:26 --> Model Class Initialized
INFO - 2020-09-12 07:30:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 07:30:26 --> Final output sent to browser
DEBUG - 2020-09-12 07:30:26 --> Total execution time: 0.0229
ERROR - 2020-09-12 07:30:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 07:30:27 --> Config Class Initialized
INFO - 2020-09-12 07:30:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 07:30:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 07:30:27 --> Utf8 Class Initialized
INFO - 2020-09-12 07:30:27 --> URI Class Initialized
INFO - 2020-09-12 07:30:27 --> Router Class Initialized
INFO - 2020-09-12 07:30:27 --> Output Class Initialized
INFO - 2020-09-12 07:30:27 --> Security Class Initialized
DEBUG - 2020-09-12 07:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 07:30:27 --> Input Class Initialized
INFO - 2020-09-12 07:30:27 --> Language Class Initialized
INFO - 2020-09-12 07:30:27 --> Loader Class Initialized
INFO - 2020-09-12 07:30:27 --> Helper loaded: url_helper
INFO - 2020-09-12 07:30:27 --> Database Driver Class Initialized
INFO - 2020-09-12 07:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 07:30:27 --> Email Class Initialized
INFO - 2020-09-12 07:30:27 --> Controller Class Initialized
DEBUG - 2020-09-12 07:30:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 07:30:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 07:30:27 --> Model Class Initialized
INFO - 2020-09-12 07:30:27 --> Model Class Initialized
INFO - 2020-09-12 07:30:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 07:30:27 --> Final output sent to browser
DEBUG - 2020-09-12 07:30:27 --> Total execution time: 0.0278
ERROR - 2020-09-12 09:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:05:40 --> Config Class Initialized
INFO - 2020-09-12 09:05:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:05:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:05:40 --> Utf8 Class Initialized
INFO - 2020-09-12 09:05:40 --> URI Class Initialized
DEBUG - 2020-09-12 09:05:40 --> No URI present. Default controller set.
INFO - 2020-09-12 09:05:40 --> Router Class Initialized
INFO - 2020-09-12 09:05:40 --> Output Class Initialized
INFO - 2020-09-12 09:05:40 --> Security Class Initialized
DEBUG - 2020-09-12 09:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:05:40 --> Input Class Initialized
INFO - 2020-09-12 09:05:40 --> Language Class Initialized
INFO - 2020-09-12 09:05:40 --> Loader Class Initialized
INFO - 2020-09-12 09:05:40 --> Helper loaded: url_helper
INFO - 2020-09-12 09:05:40 --> Database Driver Class Initialized
INFO - 2020-09-12 09:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:05:40 --> Email Class Initialized
INFO - 2020-09-12 09:05:40 --> Controller Class Initialized
INFO - 2020-09-12 09:05:40 --> Model Class Initialized
INFO - 2020-09-12 09:05:40 --> Model Class Initialized
DEBUG - 2020-09-12 09:05:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:05:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 09:05:40 --> Final output sent to browser
DEBUG - 2020-09-12 09:05:40 --> Total execution time: 0.0387
ERROR - 2020-09-12 09:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:19 --> Config Class Initialized
INFO - 2020-09-12 09:06:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:19 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:19 --> URI Class Initialized
INFO - 2020-09-12 09:06:19 --> Router Class Initialized
INFO - 2020-09-12 09:06:19 --> Output Class Initialized
INFO - 2020-09-12 09:06:19 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:19 --> Input Class Initialized
INFO - 2020-09-12 09:06:19 --> Language Class Initialized
INFO - 2020-09-12 09:06:19 --> Loader Class Initialized
INFO - 2020-09-12 09:06:19 --> Helper loaded: url_helper
ERROR - 2020-09-12 09:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:19 --> Config Class Initialized
INFO - 2020-09-12 09:06:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:19 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:19 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:19 --> URI Class Initialized
INFO - 2020-09-12 09:06:19 --> Router Class Initialized
INFO - 2020-09-12 09:06:19 --> Output Class Initialized
INFO - 2020-09-12 09:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:19 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:19 --> Input Class Initialized
INFO - 2020-09-12 09:06:19 --> Language Class Initialized
INFO - 2020-09-12 09:06:19 --> Email Class Initialized
INFO - 2020-09-12 09:06:19 --> Controller Class Initialized
INFO - 2020-09-12 09:06:19 --> Model Class Initialized
INFO - 2020-09-12 09:06:19 --> Model Class Initialized
DEBUG - 2020-09-12 09:06:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:19 --> Loader Class Initialized
INFO - 2020-09-12 09:06:19 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:19 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:19 --> Email Class Initialized
INFO - 2020-09-12 09:06:19 --> Controller Class Initialized
INFO - 2020-09-12 09:06:19 --> Model Class Initialized
INFO - 2020-09-12 09:06:19 --> Model Class Initialized
DEBUG - 2020-09-12 09:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:19 --> Model Class Initialized
INFO - 2020-09-12 09:06:19 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:19 --> Total execution time: 0.0328
ERROR - 2020-09-12 09:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:19 --> Config Class Initialized
INFO - 2020-09-12 09:06:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:19 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:19 --> URI Class Initialized
INFO - 2020-09-12 09:06:19 --> Router Class Initialized
INFO - 2020-09-12 09:06:19 --> Output Class Initialized
INFO - 2020-09-12 09:06:19 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:19 --> Input Class Initialized
INFO - 2020-09-12 09:06:19 --> Language Class Initialized
INFO - 2020-09-12 09:06:19 --> Loader Class Initialized
INFO - 2020-09-12 09:06:19 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:19 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:19 --> Email Class Initialized
INFO - 2020-09-12 09:06:19 --> Controller Class Initialized
DEBUG - 2020-09-12 09:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:06:19 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:19 --> Total execution time: 0.0301
ERROR - 2020-09-12 09:06:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:32 --> Config Class Initialized
INFO - 2020-09-12 09:06:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:32 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:32 --> URI Class Initialized
INFO - 2020-09-12 09:06:32 --> Router Class Initialized
INFO - 2020-09-12 09:06:32 --> Output Class Initialized
INFO - 2020-09-12 09:06:32 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:32 --> Input Class Initialized
INFO - 2020-09-12 09:06:32 --> Language Class Initialized
INFO - 2020-09-12 09:06:32 --> Loader Class Initialized
INFO - 2020-09-12 09:06:32 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:32 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:32 --> Email Class Initialized
INFO - 2020-09-12 09:06:32 --> Controller Class Initialized
DEBUG - 2020-09-12 09:06:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:32 --> Model Class Initialized
INFO - 2020-09-12 09:06:32 --> Model Class Initialized
INFO - 2020-09-12 09:06:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 09:06:32 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:32 --> Total execution time: 0.0274
ERROR - 2020-09-12 09:06:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:38 --> Config Class Initialized
INFO - 2020-09-12 09:06:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:38 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:38 --> URI Class Initialized
INFO - 2020-09-12 09:06:38 --> Router Class Initialized
INFO - 2020-09-12 09:06:38 --> Output Class Initialized
INFO - 2020-09-12 09:06:38 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:38 --> Input Class Initialized
INFO - 2020-09-12 09:06:38 --> Language Class Initialized
INFO - 2020-09-12 09:06:38 --> Loader Class Initialized
INFO - 2020-09-12 09:06:38 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:38 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:38 --> Email Class Initialized
INFO - 2020-09-12 09:06:38 --> Controller Class Initialized
DEBUG - 2020-09-12 09:06:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:38 --> Model Class Initialized
INFO - 2020-09-12 09:06:38 --> Model Class Initialized
INFO - 2020-09-12 09:06:38 --> Model Class Initialized
INFO - 2020-09-12 09:06:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 09:06:38 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:38 --> Total execution time: 0.0314
ERROR - 2020-09-12 09:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:43 --> Config Class Initialized
INFO - 2020-09-12 09:06:43 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:43 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:43 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:43 --> URI Class Initialized
INFO - 2020-09-12 09:06:43 --> Router Class Initialized
INFO - 2020-09-12 09:06:43 --> Output Class Initialized
INFO - 2020-09-12 09:06:43 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:43 --> Input Class Initialized
INFO - 2020-09-12 09:06:43 --> Language Class Initialized
INFO - 2020-09-12 09:06:43 --> Loader Class Initialized
INFO - 2020-09-12 09:06:43 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:43 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:43 --> Email Class Initialized
INFO - 2020-09-12 09:06:43 --> Controller Class Initialized
DEBUG - 2020-09-12 09:06:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:43 --> Model Class Initialized
INFO - 2020-09-12 09:06:43 --> Model Class Initialized
INFO - 2020-09-12 09:06:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 09:06:43 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:43 --> Total execution time: 0.0222
ERROR - 2020-09-12 09:06:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:52 --> Config Class Initialized
INFO - 2020-09-12 09:06:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:52 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:52 --> URI Class Initialized
INFO - 2020-09-12 09:06:52 --> Router Class Initialized
INFO - 2020-09-12 09:06:52 --> Output Class Initialized
INFO - 2020-09-12 09:06:52 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:52 --> Input Class Initialized
INFO - 2020-09-12 09:06:52 --> Language Class Initialized
INFO - 2020-09-12 09:06:52 --> Loader Class Initialized
INFO - 2020-09-12 09:06:52 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:52 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:52 --> Email Class Initialized
INFO - 2020-09-12 09:06:52 --> Controller Class Initialized
DEBUG - 2020-09-12 09:06:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:52 --> Model Class Initialized
INFO - 2020-09-12 09:06:52 --> Model Class Initialized
INFO - 2020-09-12 09:06:52 --> Model Class Initialized
INFO - 2020-09-12 09:06:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 09:06:52 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:52 --> Total execution time: 0.0254
ERROR - 2020-09-12 09:06:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:06:55 --> Config Class Initialized
INFO - 2020-09-12 09:06:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:06:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:06:55 --> Utf8 Class Initialized
INFO - 2020-09-12 09:06:55 --> URI Class Initialized
INFO - 2020-09-12 09:06:55 --> Router Class Initialized
INFO - 2020-09-12 09:06:55 --> Output Class Initialized
INFO - 2020-09-12 09:06:55 --> Security Class Initialized
DEBUG - 2020-09-12 09:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:06:55 --> Input Class Initialized
INFO - 2020-09-12 09:06:55 --> Language Class Initialized
INFO - 2020-09-12 09:06:55 --> Loader Class Initialized
INFO - 2020-09-12 09:06:55 --> Helper loaded: url_helper
INFO - 2020-09-12 09:06:55 --> Database Driver Class Initialized
INFO - 2020-09-12 09:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:06:55 --> Email Class Initialized
INFO - 2020-09-12 09:06:55 --> Controller Class Initialized
DEBUG - 2020-09-12 09:06:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:06:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:06:55 --> Model Class Initialized
INFO - 2020-09-12 09:06:55 --> Model Class Initialized
INFO - 2020-09-12 09:06:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 09:06:55 --> Final output sent to browser
DEBUG - 2020-09-12 09:06:55 --> Total execution time: 0.0240
ERROR - 2020-09-12 09:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:09:53 --> Config Class Initialized
INFO - 2020-09-12 09:09:53 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:09:53 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:09:53 --> Utf8 Class Initialized
INFO - 2020-09-12 09:09:53 --> URI Class Initialized
INFO - 2020-09-12 09:09:53 --> Router Class Initialized
INFO - 2020-09-12 09:09:53 --> Output Class Initialized
INFO - 2020-09-12 09:09:53 --> Security Class Initialized
DEBUG - 2020-09-12 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:09:53 --> Input Class Initialized
INFO - 2020-09-12 09:09:53 --> Language Class Initialized
INFO - 2020-09-12 09:09:53 --> Loader Class Initialized
INFO - 2020-09-12 09:09:53 --> Helper loaded: url_helper
INFO - 2020-09-12 09:09:53 --> Database Driver Class Initialized
INFO - 2020-09-12 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:09:53 --> Email Class Initialized
INFO - 2020-09-12 09:09:53 --> Controller Class Initialized
DEBUG - 2020-09-12 09:09:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:09:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:09:53 --> Model Class Initialized
INFO - 2020-09-12 09:09:53 --> Model Class Initialized
INFO - 2020-09-12 09:09:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 09:09:53 --> Final output sent to browser
DEBUG - 2020-09-12 09:09:53 --> Total execution time: 0.0267
ERROR - 2020-09-12 09:09:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:09:56 --> Config Class Initialized
INFO - 2020-09-12 09:09:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:09:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:09:56 --> Utf8 Class Initialized
INFO - 2020-09-12 09:09:56 --> URI Class Initialized
INFO - 2020-09-12 09:09:56 --> Router Class Initialized
INFO - 2020-09-12 09:09:56 --> Output Class Initialized
INFO - 2020-09-12 09:09:56 --> Security Class Initialized
DEBUG - 2020-09-12 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:09:56 --> Input Class Initialized
INFO - 2020-09-12 09:09:56 --> Language Class Initialized
INFO - 2020-09-12 09:09:56 --> Loader Class Initialized
INFO - 2020-09-12 09:09:56 --> Helper loaded: url_helper
INFO - 2020-09-12 09:09:56 --> Database Driver Class Initialized
INFO - 2020-09-12 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:09:56 --> Email Class Initialized
INFO - 2020-09-12 09:09:56 --> Controller Class Initialized
DEBUG - 2020-09-12 09:09:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:09:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:09:56 --> Model Class Initialized
INFO - 2020-09-12 09:09:56 --> Model Class Initialized
INFO - 2020-09-12 09:09:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 09:09:56 --> Final output sent to browser
DEBUG - 2020-09-12 09:09:56 --> Total execution time: 0.0208
ERROR - 2020-09-12 09:10:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:10:05 --> Config Class Initialized
INFO - 2020-09-12 09:10:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:10:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:10:05 --> Utf8 Class Initialized
INFO - 2020-09-12 09:10:05 --> URI Class Initialized
INFO - 2020-09-12 09:10:05 --> Router Class Initialized
INFO - 2020-09-12 09:10:05 --> Output Class Initialized
INFO - 2020-09-12 09:10:05 --> Security Class Initialized
DEBUG - 2020-09-12 09:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:10:05 --> Input Class Initialized
INFO - 2020-09-12 09:10:05 --> Language Class Initialized
INFO - 2020-09-12 09:10:05 --> Loader Class Initialized
INFO - 2020-09-12 09:10:05 --> Helper loaded: url_helper
INFO - 2020-09-12 09:10:05 --> Database Driver Class Initialized
INFO - 2020-09-12 09:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:10:05 --> Email Class Initialized
INFO - 2020-09-12 09:10:05 --> Controller Class Initialized
DEBUG - 2020-09-12 09:10:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:10:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:10:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:10:05 --> Final output sent to browser
DEBUG - 2020-09-12 09:10:05 --> Total execution time: 0.0171
ERROR - 2020-09-12 09:12:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:12:46 --> Config Class Initialized
INFO - 2020-09-12 09:12:46 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:12:46 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:12:46 --> Utf8 Class Initialized
INFO - 2020-09-12 09:12:46 --> URI Class Initialized
INFO - 2020-09-12 09:12:46 --> Router Class Initialized
INFO - 2020-09-12 09:12:46 --> Output Class Initialized
INFO - 2020-09-12 09:12:46 --> Security Class Initialized
DEBUG - 2020-09-12 09:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:12:46 --> Input Class Initialized
INFO - 2020-09-12 09:12:46 --> Language Class Initialized
INFO - 2020-09-12 09:12:46 --> Loader Class Initialized
INFO - 2020-09-12 09:12:46 --> Helper loaded: url_helper
INFO - 2020-09-12 09:12:46 --> Database Driver Class Initialized
INFO - 2020-09-12 09:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:12:46 --> Email Class Initialized
INFO - 2020-09-12 09:12:46 --> Controller Class Initialized
DEBUG - 2020-09-12 09:12:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:12:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:12:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:12:46 --> Final output sent to browser
DEBUG - 2020-09-12 09:12:46 --> Total execution time: 0.0221
ERROR - 2020-09-12 09:12:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:12:56 --> Config Class Initialized
INFO - 2020-09-12 09:12:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:12:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:12:56 --> Utf8 Class Initialized
INFO - 2020-09-12 09:12:56 --> URI Class Initialized
INFO - 2020-09-12 09:12:56 --> Router Class Initialized
INFO - 2020-09-12 09:12:56 --> Output Class Initialized
INFO - 2020-09-12 09:12:56 --> Security Class Initialized
DEBUG - 2020-09-12 09:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:12:56 --> Input Class Initialized
INFO - 2020-09-12 09:12:56 --> Language Class Initialized
INFO - 2020-09-12 09:12:56 --> Loader Class Initialized
INFO - 2020-09-12 09:12:56 --> Helper loaded: url_helper
INFO - 2020-09-12 09:12:56 --> Database Driver Class Initialized
INFO - 2020-09-12 09:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:12:56 --> Email Class Initialized
INFO - 2020-09-12 09:12:56 --> Controller Class Initialized
DEBUG - 2020-09-12 09:12:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:12:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:12:56 --> Model Class Initialized
INFO - 2020-09-12 09:12:56 --> Model Class Initialized
INFO - 2020-09-12 09:12:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 09:12:56 --> Final output sent to browser
DEBUG - 2020-09-12 09:12:56 --> Total execution time: 0.0234
ERROR - 2020-09-12 09:12:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:12:59 --> Config Class Initialized
INFO - 2020-09-12 09:12:59 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:13:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:13:00 --> Utf8 Class Initialized
INFO - 2020-09-12 09:13:00 --> URI Class Initialized
INFO - 2020-09-12 09:13:00 --> Router Class Initialized
INFO - 2020-09-12 09:13:00 --> Output Class Initialized
INFO - 2020-09-12 09:13:00 --> Security Class Initialized
DEBUG - 2020-09-12 09:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:13:00 --> Input Class Initialized
INFO - 2020-09-12 09:13:00 --> Language Class Initialized
INFO - 2020-09-12 09:13:00 --> Loader Class Initialized
INFO - 2020-09-12 09:13:00 --> Helper loaded: url_helper
INFO - 2020-09-12 09:13:00 --> Database Driver Class Initialized
INFO - 2020-09-12 09:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:13:00 --> Email Class Initialized
INFO - 2020-09-12 09:13:00 --> Controller Class Initialized
DEBUG - 2020-09-12 09:13:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:13:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:13:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:13:00 --> Final output sent to browser
DEBUG - 2020-09-12 09:13:00 --> Total execution time: 0.0204
ERROR - 2020-09-12 09:13:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:13:34 --> Config Class Initialized
INFO - 2020-09-12 09:13:34 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:13:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:13:34 --> Utf8 Class Initialized
INFO - 2020-09-12 09:13:34 --> URI Class Initialized
INFO - 2020-09-12 09:13:34 --> Router Class Initialized
INFO - 2020-09-12 09:13:34 --> Output Class Initialized
INFO - 2020-09-12 09:13:34 --> Security Class Initialized
DEBUG - 2020-09-12 09:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:13:34 --> Input Class Initialized
INFO - 2020-09-12 09:13:34 --> Language Class Initialized
INFO - 2020-09-12 09:13:34 --> Loader Class Initialized
INFO - 2020-09-12 09:13:34 --> Helper loaded: url_helper
INFO - 2020-09-12 09:13:34 --> Database Driver Class Initialized
INFO - 2020-09-12 09:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:13:34 --> Email Class Initialized
INFO - 2020-09-12 09:13:34 --> Controller Class Initialized
DEBUG - 2020-09-12 09:13:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:13:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:13:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:13:34 --> Final output sent to browser
DEBUG - 2020-09-12 09:13:34 --> Total execution time: 0.0190
ERROR - 2020-09-12 09:13:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:13:43 --> Config Class Initialized
INFO - 2020-09-12 09:13:43 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:13:43 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:13:43 --> Utf8 Class Initialized
INFO - 2020-09-12 09:13:43 --> URI Class Initialized
DEBUG - 2020-09-12 09:13:43 --> No URI present. Default controller set.
INFO - 2020-09-12 09:13:43 --> Router Class Initialized
INFO - 2020-09-12 09:13:43 --> Output Class Initialized
INFO - 2020-09-12 09:13:43 --> Security Class Initialized
DEBUG - 2020-09-12 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:13:43 --> Input Class Initialized
INFO - 2020-09-12 09:13:43 --> Language Class Initialized
INFO - 2020-09-12 09:13:43 --> Loader Class Initialized
INFO - 2020-09-12 09:13:43 --> Helper loaded: url_helper
INFO - 2020-09-12 09:13:43 --> Database Driver Class Initialized
INFO - 2020-09-12 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:13:43 --> Email Class Initialized
INFO - 2020-09-12 09:13:43 --> Controller Class Initialized
INFO - 2020-09-12 09:13:43 --> Model Class Initialized
INFO - 2020-09-12 09:13:43 --> Model Class Initialized
DEBUG - 2020-09-12 09:13:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:13:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 09:13:43 --> Final output sent to browser
DEBUG - 2020-09-12 09:13:43 --> Total execution time: 0.0214
ERROR - 2020-09-12 09:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:14:01 --> Config Class Initialized
INFO - 2020-09-12 09:14:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:14:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:14:01 --> Utf8 Class Initialized
INFO - 2020-09-12 09:14:01 --> URI Class Initialized
INFO - 2020-09-12 09:14:01 --> Router Class Initialized
INFO - 2020-09-12 09:14:01 --> Output Class Initialized
INFO - 2020-09-12 09:14:01 --> Security Class Initialized
DEBUG - 2020-09-12 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:14:01 --> Input Class Initialized
INFO - 2020-09-12 09:14:01 --> Language Class Initialized
INFO - 2020-09-12 09:14:01 --> Loader Class Initialized
INFO - 2020-09-12 09:14:01 --> Helper loaded: url_helper
INFO - 2020-09-12 09:14:01 --> Database Driver Class Initialized
INFO - 2020-09-12 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:14:01 --> Email Class Initialized
INFO - 2020-09-12 09:14:01 --> Controller Class Initialized
INFO - 2020-09-12 09:14:01 --> Model Class Initialized
INFO - 2020-09-12 09:14:01 --> Model Class Initialized
DEBUG - 2020-09-12 09:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:14:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:14:01 --> Model Class Initialized
INFO - 2020-09-12 09:14:01 --> Final output sent to browser
DEBUG - 2020-09-12 09:14:01 --> Total execution time: 0.0219
ERROR - 2020-09-12 09:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:14:01 --> Config Class Initialized
INFO - 2020-09-12 09:14:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:14:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:14:01 --> Utf8 Class Initialized
INFO - 2020-09-12 09:14:01 --> URI Class Initialized
INFO - 2020-09-12 09:14:01 --> Router Class Initialized
INFO - 2020-09-12 09:14:01 --> Output Class Initialized
INFO - 2020-09-12 09:14:01 --> Security Class Initialized
DEBUG - 2020-09-12 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:14:01 --> Input Class Initialized
INFO - 2020-09-12 09:14:01 --> Language Class Initialized
INFO - 2020-09-12 09:14:01 --> Loader Class Initialized
INFO - 2020-09-12 09:14:01 --> Helper loaded: url_helper
INFO - 2020-09-12 09:14:01 --> Database Driver Class Initialized
INFO - 2020-09-12 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:14:01 --> Email Class Initialized
INFO - 2020-09-12 09:14:01 --> Controller Class Initialized
INFO - 2020-09-12 09:14:01 --> Model Class Initialized
INFO - 2020-09-12 09:14:01 --> Model Class Initialized
DEBUG - 2020-09-12 09:14:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-12 09:14:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:14:01 --> Config Class Initialized
INFO - 2020-09-12 09:14:01 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:14:01 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:14:01 --> Utf8 Class Initialized
INFO - 2020-09-12 09:14:01 --> URI Class Initialized
INFO - 2020-09-12 09:14:01 --> Router Class Initialized
INFO - 2020-09-12 09:14:01 --> Output Class Initialized
INFO - 2020-09-12 09:14:01 --> Security Class Initialized
DEBUG - 2020-09-12 09:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:14:01 --> Input Class Initialized
INFO - 2020-09-12 09:14:01 --> Language Class Initialized
INFO - 2020-09-12 09:14:01 --> Loader Class Initialized
INFO - 2020-09-12 09:14:01 --> Helper loaded: url_helper
INFO - 2020-09-12 09:14:01 --> Database Driver Class Initialized
INFO - 2020-09-12 09:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:14:01 --> Email Class Initialized
INFO - 2020-09-12 09:14:01 --> Controller Class Initialized
DEBUG - 2020-09-12 09:14:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:14:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:14:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:14:01 --> Final output sent to browser
DEBUG - 2020-09-12 09:14:01 --> Total execution time: 0.0211
ERROR - 2020-09-12 09:30:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:30:36 --> Config Class Initialized
INFO - 2020-09-12 09:30:36 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:30:36 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:30:36 --> Utf8 Class Initialized
INFO - 2020-09-12 09:30:36 --> URI Class Initialized
INFO - 2020-09-12 09:30:36 --> Router Class Initialized
INFO - 2020-09-12 09:30:36 --> Output Class Initialized
INFO - 2020-09-12 09:30:36 --> Security Class Initialized
DEBUG - 2020-09-12 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:30:36 --> Input Class Initialized
INFO - 2020-09-12 09:30:36 --> Language Class Initialized
INFO - 2020-09-12 09:30:36 --> Loader Class Initialized
INFO - 2020-09-12 09:30:36 --> Helper loaded: url_helper
INFO - 2020-09-12 09:30:36 --> Database Driver Class Initialized
INFO - 2020-09-12 09:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:30:36 --> Email Class Initialized
INFO - 2020-09-12 09:30:36 --> Controller Class Initialized
DEBUG - 2020-09-12 09:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:30:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:30:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 09:30:36 --> Final output sent to browser
DEBUG - 2020-09-12 09:30:36 --> Total execution time: 0.0204
ERROR - 2020-09-12 09:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:30:41 --> Config Class Initialized
INFO - 2020-09-12 09:30:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:30:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:30:41 --> Utf8 Class Initialized
INFO - 2020-09-12 09:30:41 --> URI Class Initialized
INFO - 2020-09-12 09:30:41 --> Router Class Initialized
INFO - 2020-09-12 09:30:41 --> Output Class Initialized
INFO - 2020-09-12 09:30:41 --> Security Class Initialized
DEBUG - 2020-09-12 09:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:30:41 --> Input Class Initialized
INFO - 2020-09-12 09:30:41 --> Language Class Initialized
INFO - 2020-09-12 09:30:41 --> Loader Class Initialized
INFO - 2020-09-12 09:30:41 --> Helper loaded: url_helper
INFO - 2020-09-12 09:30:41 --> Database Driver Class Initialized
INFO - 2020-09-12 09:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:30:41 --> Email Class Initialized
INFO - 2020-09-12 09:30:41 --> Controller Class Initialized
DEBUG - 2020-09-12 09:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:30:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:30:41 --> Model Class Initialized
INFO - 2020-09-12 09:30:41 --> Model Class Initialized
INFO - 2020-09-12 09:30:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:30:41 --> Final output sent to browser
DEBUG - 2020-09-12 09:30:41 --> Total execution time: 0.0215
ERROR - 2020-09-12 09:32:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:32:28 --> Config Class Initialized
INFO - 2020-09-12 09:32:28 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:32:28 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:32:28 --> Utf8 Class Initialized
INFO - 2020-09-12 09:32:28 --> URI Class Initialized
INFO - 2020-09-12 09:32:28 --> Router Class Initialized
INFO - 2020-09-12 09:32:28 --> Output Class Initialized
INFO - 2020-09-12 09:32:28 --> Security Class Initialized
DEBUG - 2020-09-12 09:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:32:28 --> Input Class Initialized
INFO - 2020-09-12 09:32:28 --> Language Class Initialized
INFO - 2020-09-12 09:32:28 --> Loader Class Initialized
INFO - 2020-09-12 09:32:28 --> Helper loaded: url_helper
INFO - 2020-09-12 09:32:28 --> Database Driver Class Initialized
INFO - 2020-09-12 09:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:32:28 --> Email Class Initialized
INFO - 2020-09-12 09:32:28 --> Controller Class Initialized
DEBUG - 2020-09-12 09:32:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:32:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:32:28 --> Model Class Initialized
INFO - 2020-09-12 09:32:29 --> Model Class Initialized
INFO - 2020-09-12 09:32:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:32:29 --> Final output sent to browser
DEBUG - 2020-09-12 09:32:29 --> Total execution time: 0.0249
ERROR - 2020-09-12 09:33:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:33:13 --> Config Class Initialized
INFO - 2020-09-12 09:33:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:33:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:33:13 --> Utf8 Class Initialized
INFO - 2020-09-12 09:33:13 --> URI Class Initialized
INFO - 2020-09-12 09:33:13 --> Router Class Initialized
INFO - 2020-09-12 09:33:13 --> Output Class Initialized
INFO - 2020-09-12 09:33:13 --> Security Class Initialized
DEBUG - 2020-09-12 09:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:33:13 --> Input Class Initialized
INFO - 2020-09-12 09:33:13 --> Language Class Initialized
INFO - 2020-09-12 09:33:13 --> Loader Class Initialized
INFO - 2020-09-12 09:33:13 --> Helper loaded: url_helper
INFO - 2020-09-12 09:33:13 --> Database Driver Class Initialized
INFO - 2020-09-12 09:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:33:13 --> Email Class Initialized
INFO - 2020-09-12 09:33:13 --> Controller Class Initialized
DEBUG - 2020-09-12 09:33:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:33:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:33:13 --> Model Class Initialized
INFO - 2020-09-12 09:33:13 --> Model Class Initialized
INFO - 2020-09-12 09:33:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:33:13 --> Final output sent to browser
DEBUG - 2020-09-12 09:33:13 --> Total execution time: 0.0249
ERROR - 2020-09-12 09:43:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:43:23 --> Config Class Initialized
INFO - 2020-09-12 09:43:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:43:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:43:23 --> Utf8 Class Initialized
INFO - 2020-09-12 09:43:23 --> URI Class Initialized
INFO - 2020-09-12 09:43:23 --> Router Class Initialized
INFO - 2020-09-12 09:43:23 --> Output Class Initialized
INFO - 2020-09-12 09:43:23 --> Security Class Initialized
DEBUG - 2020-09-12 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:43:23 --> Input Class Initialized
INFO - 2020-09-12 09:43:23 --> Language Class Initialized
INFO - 2020-09-12 09:43:23 --> Loader Class Initialized
INFO - 2020-09-12 09:43:23 --> Helper loaded: url_helper
INFO - 2020-09-12 09:43:23 --> Database Driver Class Initialized
INFO - 2020-09-12 09:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:43:23 --> Email Class Initialized
INFO - 2020-09-12 09:43:23 --> Controller Class Initialized
DEBUG - 2020-09-12 09:43:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:43:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:43:23 --> Model Class Initialized
INFO - 2020-09-12 09:43:23 --> Model Class Initialized
INFO - 2020-09-12 09:43:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:43:23 --> Final output sent to browser
DEBUG - 2020-09-12 09:43:23 --> Total execution time: 0.0226
ERROR - 2020-09-12 09:43:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:43:25 --> Config Class Initialized
INFO - 2020-09-12 09:43:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:43:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:43:25 --> Utf8 Class Initialized
INFO - 2020-09-12 09:43:25 --> URI Class Initialized
INFO - 2020-09-12 09:43:25 --> Router Class Initialized
INFO - 2020-09-12 09:43:25 --> Output Class Initialized
INFO - 2020-09-12 09:43:25 --> Security Class Initialized
DEBUG - 2020-09-12 09:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:43:25 --> Input Class Initialized
INFO - 2020-09-12 09:43:25 --> Language Class Initialized
INFO - 2020-09-12 09:43:25 --> Loader Class Initialized
INFO - 2020-09-12 09:43:25 --> Helper loaded: url_helper
INFO - 2020-09-12 09:43:25 --> Database Driver Class Initialized
INFO - 2020-09-12 09:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:43:25 --> Email Class Initialized
INFO - 2020-09-12 09:43:25 --> Controller Class Initialized
DEBUG - 2020-09-12 09:43:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:43:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:43:25 --> Model Class Initialized
INFO - 2020-09-12 09:43:25 --> Model Class Initialized
INFO - 2020-09-12 09:43:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 09:43:25 --> Final output sent to browser
DEBUG - 2020-09-12 09:43:25 --> Total execution time: 0.0310
ERROR - 2020-09-12 09:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:48:41 --> Config Class Initialized
INFO - 2020-09-12 09:48:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:48:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:48:41 --> Utf8 Class Initialized
INFO - 2020-09-12 09:48:41 --> URI Class Initialized
INFO - 2020-09-12 09:48:41 --> Router Class Initialized
INFO - 2020-09-12 09:48:41 --> Output Class Initialized
INFO - 2020-09-12 09:48:41 --> Security Class Initialized
DEBUG - 2020-09-12 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:48:41 --> Input Class Initialized
INFO - 2020-09-12 09:48:41 --> Language Class Initialized
INFO - 2020-09-12 09:48:41 --> Loader Class Initialized
INFO - 2020-09-12 09:48:41 --> Helper loaded: url_helper
INFO - 2020-09-12 09:48:41 --> Database Driver Class Initialized
INFO - 2020-09-12 09:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:48:41 --> Email Class Initialized
INFO - 2020-09-12 09:48:41 --> Controller Class Initialized
DEBUG - 2020-09-12 09:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:48:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:48:41 --> Model Class Initialized
ERROR - 2020-09-12 09:48:41 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) /home/purpu1ex/public_html/carsm/application/models/Dealer_model.php 218
ERROR - 2020-09-12 09:50:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:50:16 --> Config Class Initialized
INFO - 2020-09-12 09:50:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:50:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:50:16 --> Utf8 Class Initialized
INFO - 2020-09-12 09:50:16 --> URI Class Initialized
INFO - 2020-09-12 09:50:16 --> Router Class Initialized
INFO - 2020-09-12 09:50:16 --> Output Class Initialized
INFO - 2020-09-12 09:50:16 --> Security Class Initialized
DEBUG - 2020-09-12 09:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:50:16 --> Input Class Initialized
INFO - 2020-09-12 09:50:16 --> Language Class Initialized
INFO - 2020-09-12 09:50:16 --> Loader Class Initialized
INFO - 2020-09-12 09:50:16 --> Helper loaded: url_helper
INFO - 2020-09-12 09:50:16 --> Database Driver Class Initialized
INFO - 2020-09-12 09:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:50:16 --> Email Class Initialized
INFO - 2020-09-12 09:50:16 --> Controller Class Initialized
DEBUG - 2020-09-12 09:50:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:50:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:50:16 --> Model Class Initialized
INFO - 2020-09-12 09:50:16 --> Model Class Initialized
INFO - 2020-09-12 09:50:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:50:16 --> Final output sent to browser
DEBUG - 2020-09-12 09:50:16 --> Total execution time: 0.0247
ERROR - 2020-09-12 09:50:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:50:18 --> Config Class Initialized
INFO - 2020-09-12 09:50:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:50:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:50:18 --> Utf8 Class Initialized
INFO - 2020-09-12 09:50:18 --> URI Class Initialized
INFO - 2020-09-12 09:50:18 --> Router Class Initialized
INFO - 2020-09-12 09:50:18 --> Output Class Initialized
INFO - 2020-09-12 09:50:18 --> Security Class Initialized
DEBUG - 2020-09-12 09:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:50:18 --> Input Class Initialized
INFO - 2020-09-12 09:50:18 --> Language Class Initialized
INFO - 2020-09-12 09:50:18 --> Loader Class Initialized
INFO - 2020-09-12 09:50:18 --> Helper loaded: url_helper
INFO - 2020-09-12 09:50:18 --> Database Driver Class Initialized
INFO - 2020-09-12 09:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:50:18 --> Email Class Initialized
INFO - 2020-09-12 09:50:18 --> Controller Class Initialized
DEBUG - 2020-09-12 09:50:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:50:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:50:18 --> Model Class Initialized
ERROR - 2020-09-12 09:50:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/models/Dealer_model.php:62) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-12 09:50:18 --> Severity: Compile Error --> Cannot redeclare Dealer_model::client_update() /home/purpu1ex/public_html/carsm/application/models/Dealer_model.php 62
ERROR - 2020-09-12 09:51:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:51:07 --> Config Class Initialized
INFO - 2020-09-12 09:51:07 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:51:07 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:51:07 --> Utf8 Class Initialized
INFO - 2020-09-12 09:51:07 --> URI Class Initialized
INFO - 2020-09-12 09:51:07 --> Router Class Initialized
INFO - 2020-09-12 09:51:07 --> Output Class Initialized
INFO - 2020-09-12 09:51:07 --> Security Class Initialized
DEBUG - 2020-09-12 09:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:51:07 --> Input Class Initialized
INFO - 2020-09-12 09:51:07 --> Language Class Initialized
INFO - 2020-09-12 09:51:07 --> Loader Class Initialized
INFO - 2020-09-12 09:51:07 --> Helper loaded: url_helper
INFO - 2020-09-12 09:51:07 --> Database Driver Class Initialized
INFO - 2020-09-12 09:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:51:07 --> Email Class Initialized
INFO - 2020-09-12 09:51:07 --> Controller Class Initialized
DEBUG - 2020-09-12 09:51:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:51:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:51:07 --> Model Class Initialized
INFO - 2020-09-12 09:51:07 --> Model Class Initialized
INFO - 2020-09-12 09:51:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 09:51:07 --> Final output sent to browser
DEBUG - 2020-09-12 09:51:07 --> Total execution time: 0.0194
ERROR - 2020-09-12 09:52:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:52:38 --> Config Class Initialized
INFO - 2020-09-12 09:52:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:52:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:52:38 --> Utf8 Class Initialized
INFO - 2020-09-12 09:52:38 --> URI Class Initialized
INFO - 2020-09-12 09:52:38 --> Router Class Initialized
INFO - 2020-09-12 09:52:38 --> Output Class Initialized
INFO - 2020-09-12 09:52:38 --> Security Class Initialized
DEBUG - 2020-09-12 09:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:52:38 --> Input Class Initialized
INFO - 2020-09-12 09:52:38 --> Language Class Initialized
INFO - 2020-09-12 09:52:38 --> Loader Class Initialized
INFO - 2020-09-12 09:52:38 --> Helper loaded: url_helper
INFO - 2020-09-12 09:52:38 --> Database Driver Class Initialized
INFO - 2020-09-12 09:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:52:38 --> Email Class Initialized
INFO - 2020-09-12 09:52:38 --> Controller Class Initialized
DEBUG - 2020-09-12 09:52:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:52:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:52:38 --> Model Class Initialized
INFO - 2020-09-12 09:52:38 --> Model Class Initialized
ERROR - 2020-09-12 09:52:38 --> Query error: Unknown column 'p_cl_v_mode' in 'field list' - Invalid query: CALL client_details_reg('1','2','4','5','6',
        '7','8','9','10@vcvdbgf','11','12','13','14',
        '16','17','18','19','20',
        '21','22','23','24','25',
        '26','27','28','29',
        '30','31','32','33',
        '3','3','15',29)
INFO - 2020-09-12 09:52:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-12 09:56:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:56:45 --> Config Class Initialized
INFO - 2020-09-12 09:56:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:56:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:56:45 --> Utf8 Class Initialized
INFO - 2020-09-12 09:56:45 --> URI Class Initialized
INFO - 2020-09-12 09:56:45 --> Router Class Initialized
INFO - 2020-09-12 09:56:45 --> Output Class Initialized
INFO - 2020-09-12 09:56:45 --> Security Class Initialized
DEBUG - 2020-09-12 09:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:56:45 --> Input Class Initialized
INFO - 2020-09-12 09:56:45 --> Language Class Initialized
INFO - 2020-09-12 09:56:45 --> Loader Class Initialized
INFO - 2020-09-12 09:56:45 --> Helper loaded: url_helper
INFO - 2020-09-12 09:56:45 --> Database Driver Class Initialized
INFO - 2020-09-12 09:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:56:45 --> Email Class Initialized
INFO - 2020-09-12 09:56:45 --> Controller Class Initialized
DEBUG - 2020-09-12 09:56:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:56:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:56:45 --> Model Class Initialized
INFO - 2020-09-12 09:56:45 --> Model Class Initialized
INFO - 2020-09-12 09:56:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:56:45 --> Final output sent to browser
DEBUG - 2020-09-12 09:56:45 --> Total execution time: 0.0207
ERROR - 2020-09-12 09:56:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:56:48 --> Config Class Initialized
INFO - 2020-09-12 09:56:48 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:56:48 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:56:48 --> Utf8 Class Initialized
INFO - 2020-09-12 09:56:48 --> URI Class Initialized
INFO - 2020-09-12 09:56:48 --> Router Class Initialized
INFO - 2020-09-12 09:56:48 --> Output Class Initialized
INFO - 2020-09-12 09:56:48 --> Security Class Initialized
DEBUG - 2020-09-12 09:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:56:48 --> Input Class Initialized
INFO - 2020-09-12 09:56:48 --> Language Class Initialized
INFO - 2020-09-12 09:56:48 --> Loader Class Initialized
INFO - 2020-09-12 09:56:48 --> Helper loaded: url_helper
INFO - 2020-09-12 09:56:48 --> Database Driver Class Initialized
INFO - 2020-09-12 09:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:56:48 --> Email Class Initialized
INFO - 2020-09-12 09:56:48 --> Controller Class Initialized
DEBUG - 2020-09-12 09:56:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:56:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:56:48 --> Model Class Initialized
INFO - 2020-09-12 09:56:48 --> Model Class Initialized
INFO - 2020-09-12 09:56:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 09:56:48 --> Final output sent to browser
DEBUG - 2020-09-12 09:56:48 --> Total execution time: 0.0212
ERROR - 2020-09-12 09:58:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:58:06 --> Config Class Initialized
INFO - 2020-09-12 09:58:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:58:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:58:06 --> Utf8 Class Initialized
INFO - 2020-09-12 09:58:06 --> URI Class Initialized
INFO - 2020-09-12 09:58:06 --> Router Class Initialized
INFO - 2020-09-12 09:58:06 --> Output Class Initialized
INFO - 2020-09-12 09:58:06 --> Security Class Initialized
DEBUG - 2020-09-12 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:58:06 --> Input Class Initialized
INFO - 2020-09-12 09:58:06 --> Language Class Initialized
INFO - 2020-09-12 09:58:06 --> Loader Class Initialized
INFO - 2020-09-12 09:58:06 --> Helper loaded: url_helper
INFO - 2020-09-12 09:58:06 --> Database Driver Class Initialized
INFO - 2020-09-12 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:58:06 --> Email Class Initialized
INFO - 2020-09-12 09:58:06 --> Controller Class Initialized
DEBUG - 2020-09-12 09:58:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:58:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:58:06 --> Model Class Initialized
INFO - 2020-09-12 09:58:06 --> Model Class Initialized
INFO - 2020-09-12 09:58:06 --> Model Class Initialized
INFO - 2020-09-12 09:58:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:58:06 --> Final output sent to browser
DEBUG - 2020-09-12 09:58:06 --> Total execution time: 0.0322
ERROR - 2020-09-12 09:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 09:59:29 --> Config Class Initialized
INFO - 2020-09-12 09:59:29 --> Hooks Class Initialized
DEBUG - 2020-09-12 09:59:29 --> UTF-8 Support Enabled
INFO - 2020-09-12 09:59:29 --> Utf8 Class Initialized
INFO - 2020-09-12 09:59:29 --> URI Class Initialized
INFO - 2020-09-12 09:59:29 --> Router Class Initialized
INFO - 2020-09-12 09:59:29 --> Output Class Initialized
INFO - 2020-09-12 09:59:29 --> Security Class Initialized
DEBUG - 2020-09-12 09:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 09:59:29 --> Input Class Initialized
INFO - 2020-09-12 09:59:29 --> Language Class Initialized
INFO - 2020-09-12 09:59:29 --> Loader Class Initialized
INFO - 2020-09-12 09:59:29 --> Helper loaded: url_helper
INFO - 2020-09-12 09:59:29 --> Database Driver Class Initialized
INFO - 2020-09-12 09:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 09:59:29 --> Email Class Initialized
INFO - 2020-09-12 09:59:29 --> Controller Class Initialized
DEBUG - 2020-09-12 09:59:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 09:59:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 09:59:29 --> Model Class Initialized
INFO - 2020-09-12 09:59:29 --> Model Class Initialized
INFO - 2020-09-12 09:59:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 09:59:29 --> Final output sent to browser
DEBUG - 2020-09-12 09:59:29 --> Total execution time: 0.0271
ERROR - 2020-09-12 10:01:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:01:54 --> Config Class Initialized
INFO - 2020-09-12 10:01:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:01:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:01:54 --> Utf8 Class Initialized
INFO - 2020-09-12 10:01:54 --> URI Class Initialized
INFO - 2020-09-12 10:01:54 --> Router Class Initialized
INFO - 2020-09-12 10:01:54 --> Output Class Initialized
INFO - 2020-09-12 10:01:54 --> Security Class Initialized
DEBUG - 2020-09-12 10:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:01:54 --> Input Class Initialized
INFO - 2020-09-12 10:01:54 --> Language Class Initialized
INFO - 2020-09-12 10:01:54 --> Loader Class Initialized
INFO - 2020-09-12 10:01:54 --> Helper loaded: url_helper
INFO - 2020-09-12 10:01:54 --> Database Driver Class Initialized
INFO - 2020-09-12 10:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:01:54 --> Email Class Initialized
INFO - 2020-09-12 10:01:54 --> Controller Class Initialized
DEBUG - 2020-09-12 10:01:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:01:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:01:54 --> Model Class Initialized
INFO - 2020-09-12 10:01:54 --> Model Class Initialized
INFO - 2020-09-12 10:01:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:01:54 --> Final output sent to browser
DEBUG - 2020-09-12 10:01:54 --> Total execution time: 0.0245
ERROR - 2020-09-12 10:02:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:13 --> Config Class Initialized
INFO - 2020-09-12 10:02:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:13 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:13 --> URI Class Initialized
DEBUG - 2020-09-12 10:02:13 --> No URI present. Default controller set.
INFO - 2020-09-12 10:02:13 --> Router Class Initialized
INFO - 2020-09-12 10:02:13 --> Output Class Initialized
INFO - 2020-09-12 10:02:13 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:13 --> Input Class Initialized
INFO - 2020-09-12 10:02:13 --> Language Class Initialized
INFO - 2020-09-12 10:02:13 --> Loader Class Initialized
INFO - 2020-09-12 10:02:13 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:13 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:13 --> Email Class Initialized
INFO - 2020-09-12 10:02:13 --> Controller Class Initialized
INFO - 2020-09-12 10:02:13 --> Model Class Initialized
INFO - 2020-09-12 10:02:13 --> Model Class Initialized
DEBUG - 2020-09-12 10:02:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:02:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 10:02:13 --> Final output sent to browser
DEBUG - 2020-09-12 10:02:13 --> Total execution time: 0.0204
ERROR - 2020-09-12 10:02:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:16 --> Config Class Initialized
INFO - 2020-09-12 10:02:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:16 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:16 --> URI Class Initialized
INFO - 2020-09-12 10:02:16 --> Router Class Initialized
INFO - 2020-09-12 10:02:16 --> Output Class Initialized
INFO - 2020-09-12 10:02:16 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:16 --> Input Class Initialized
INFO - 2020-09-12 10:02:16 --> Language Class Initialized
INFO - 2020-09-12 10:02:16 --> Loader Class Initialized
INFO - 2020-09-12 10:02:16 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:16 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:16 --> Email Class Initialized
INFO - 2020-09-12 10:02:16 --> Controller Class Initialized
INFO - 2020-09-12 10:02:16 --> Model Class Initialized
INFO - 2020-09-12 10:02:16 --> Model Class Initialized
DEBUG - 2020-09-12 10:02:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:02:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:02:16 --> Model Class Initialized
INFO - 2020-09-12 10:02:16 --> Final output sent to browser
DEBUG - 2020-09-12 10:02:16 --> Total execution time: 0.0230
ERROR - 2020-09-12 10:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:17 --> Config Class Initialized
INFO - 2020-09-12 10:02:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:17 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:17 --> URI Class Initialized
INFO - 2020-09-12 10:02:17 --> Router Class Initialized
INFO - 2020-09-12 10:02:17 --> Output Class Initialized
INFO - 2020-09-12 10:02:17 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:17 --> Input Class Initialized
INFO - 2020-09-12 10:02:17 --> Language Class Initialized
INFO - 2020-09-12 10:02:17 --> Loader Class Initialized
INFO - 2020-09-12 10:02:17 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:17 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:17 --> Email Class Initialized
INFO - 2020-09-12 10:02:17 --> Controller Class Initialized
INFO - 2020-09-12 10:02:17 --> Model Class Initialized
INFO - 2020-09-12 10:02:17 --> Model Class Initialized
DEBUG - 2020-09-12 10:02:17 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-12 10:02:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:17 --> Config Class Initialized
INFO - 2020-09-12 10:02:17 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:17 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:17 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:17 --> URI Class Initialized
INFO - 2020-09-12 10:02:17 --> Router Class Initialized
INFO - 2020-09-12 10:02:17 --> Output Class Initialized
INFO - 2020-09-12 10:02:17 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:17 --> Input Class Initialized
INFO - 2020-09-12 10:02:17 --> Language Class Initialized
INFO - 2020-09-12 10:02:17 --> Loader Class Initialized
INFO - 2020-09-12 10:02:17 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:17 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:17 --> Email Class Initialized
INFO - 2020-09-12 10:02:17 --> Controller Class Initialized
DEBUG - 2020-09-12 10:02:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:02:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:02:17 --> Model Class Initialized
INFO - 2020-09-12 10:02:17 --> Model Class Initialized
INFO - 2020-09-12 10:02:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-12 10:02:17 --> Final output sent to browser
DEBUG - 2020-09-12 10:02:17 --> Total execution time: 0.0403
ERROR - 2020-09-12 10:02:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:22 --> Config Class Initialized
INFO - 2020-09-12 10:02:22 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:22 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:22 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:22 --> URI Class Initialized
DEBUG - 2020-09-12 10:02:22 --> No URI present. Default controller set.
INFO - 2020-09-12 10:02:22 --> Router Class Initialized
INFO - 2020-09-12 10:02:22 --> Output Class Initialized
INFO - 2020-09-12 10:02:22 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:22 --> Input Class Initialized
INFO - 2020-09-12 10:02:22 --> Language Class Initialized
INFO - 2020-09-12 10:02:22 --> Loader Class Initialized
INFO - 2020-09-12 10:02:22 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:22 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:22 --> Email Class Initialized
INFO - 2020-09-12 10:02:22 --> Controller Class Initialized
INFO - 2020-09-12 10:02:22 --> Model Class Initialized
INFO - 2020-09-12 10:02:22 --> Model Class Initialized
DEBUG - 2020-09-12 10:02:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:02:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 10:02:22 --> Final output sent to browser
DEBUG - 2020-09-12 10:02:22 --> Total execution time: 0.0204
ERROR - 2020-09-12 10:02:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:37 --> Config Class Initialized
INFO - 2020-09-12 10:02:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:37 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:37 --> URI Class Initialized
INFO - 2020-09-12 10:02:37 --> Router Class Initialized
INFO - 2020-09-12 10:02:37 --> Output Class Initialized
INFO - 2020-09-12 10:02:37 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:37 --> Input Class Initialized
INFO - 2020-09-12 10:02:37 --> Language Class Initialized
INFO - 2020-09-12 10:02:37 --> Loader Class Initialized
INFO - 2020-09-12 10:02:37 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:37 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:37 --> Email Class Initialized
INFO - 2020-09-12 10:02:37 --> Controller Class Initialized
INFO - 2020-09-12 10:02:37 --> Model Class Initialized
INFO - 2020-09-12 10:02:37 --> Model Class Initialized
DEBUG - 2020-09-12 10:02:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:02:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:02:37 --> Model Class Initialized
INFO - 2020-09-12 10:02:37 --> Final output sent to browser
DEBUG - 2020-09-12 10:02:37 --> Total execution time: 0.0213
ERROR - 2020-09-12 10:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:38 --> Config Class Initialized
INFO - 2020-09-12 10:02:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:38 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:38 --> URI Class Initialized
INFO - 2020-09-12 10:02:38 --> Router Class Initialized
INFO - 2020-09-12 10:02:38 --> Output Class Initialized
INFO - 2020-09-12 10:02:38 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:38 --> Input Class Initialized
INFO - 2020-09-12 10:02:38 --> Language Class Initialized
INFO - 2020-09-12 10:02:38 --> Loader Class Initialized
INFO - 2020-09-12 10:02:38 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:38 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:38 --> Email Class Initialized
INFO - 2020-09-12 10:02:38 --> Controller Class Initialized
INFO - 2020-09-12 10:02:38 --> Model Class Initialized
INFO - 2020-09-12 10:02:38 --> Model Class Initialized
DEBUG - 2020-09-12 10:02:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-12 10:02:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:02:38 --> Config Class Initialized
INFO - 2020-09-12 10:02:38 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:02:38 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:02:38 --> Utf8 Class Initialized
INFO - 2020-09-12 10:02:38 --> URI Class Initialized
INFO - 2020-09-12 10:02:38 --> Router Class Initialized
INFO - 2020-09-12 10:02:38 --> Output Class Initialized
INFO - 2020-09-12 10:02:38 --> Security Class Initialized
DEBUG - 2020-09-12 10:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:02:38 --> Input Class Initialized
INFO - 2020-09-12 10:02:38 --> Language Class Initialized
INFO - 2020-09-12 10:02:38 --> Loader Class Initialized
INFO - 2020-09-12 10:02:38 --> Helper loaded: url_helper
INFO - 2020-09-12 10:02:38 --> Database Driver Class Initialized
INFO - 2020-09-12 10:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:02:38 --> Email Class Initialized
INFO - 2020-09-12 10:02:38 --> Controller Class Initialized
DEBUG - 2020-09-12 10:02:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:02:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:02:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:02:38 --> Final output sent to browser
DEBUG - 2020-09-12 10:02:38 --> Total execution time: 0.0204
ERROR - 2020-09-12 10:03:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:03:19 --> Config Class Initialized
INFO - 2020-09-12 10:03:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:19 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:19 --> URI Class Initialized
INFO - 2020-09-12 10:03:19 --> Router Class Initialized
INFO - 2020-09-12 10:03:19 --> Output Class Initialized
INFO - 2020-09-12 10:03:19 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:19 --> Input Class Initialized
INFO - 2020-09-12 10:03:19 --> Language Class Initialized
INFO - 2020-09-12 10:03:19 --> Loader Class Initialized
INFO - 2020-09-12 10:03:19 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:19 --> Database Driver Class Initialized
INFO - 2020-09-12 10:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:19 --> Email Class Initialized
INFO - 2020-09-12 10:03:19 --> Controller Class Initialized
DEBUG - 2020-09-12 10:03:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:03:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:03:19 --> Model Class Initialized
INFO - 2020-09-12 10:03:19 --> Model Class Initialized
INFO - 2020-09-12 10:03:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:03:19 --> Final output sent to browser
DEBUG - 2020-09-12 10:03:19 --> Total execution time: 0.0319
ERROR - 2020-09-12 10:03:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:03:28 --> Config Class Initialized
INFO - 2020-09-12 10:03:28 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:03:28 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:03:28 --> Utf8 Class Initialized
INFO - 2020-09-12 10:03:28 --> URI Class Initialized
INFO - 2020-09-12 10:03:28 --> Router Class Initialized
INFO - 2020-09-12 10:03:28 --> Output Class Initialized
INFO - 2020-09-12 10:03:28 --> Security Class Initialized
DEBUG - 2020-09-12 10:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:03:28 --> Input Class Initialized
INFO - 2020-09-12 10:03:28 --> Language Class Initialized
INFO - 2020-09-12 10:03:28 --> Loader Class Initialized
INFO - 2020-09-12 10:03:28 --> Helper loaded: url_helper
INFO - 2020-09-12 10:03:28 --> Database Driver Class Initialized
INFO - 2020-09-12 10:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:03:28 --> Email Class Initialized
INFO - 2020-09-12 10:03:28 --> Controller Class Initialized
DEBUG - 2020-09-12 10:03:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:03:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:03:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:03:28 --> Final output sent to browser
DEBUG - 2020-09-12 10:03:28 --> Total execution time: 0.0174
ERROR - 2020-09-12 10:04:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:04:18 --> Config Class Initialized
INFO - 2020-09-12 10:04:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:04:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:04:18 --> Utf8 Class Initialized
INFO - 2020-09-12 10:04:18 --> URI Class Initialized
INFO - 2020-09-12 10:04:18 --> Router Class Initialized
INFO - 2020-09-12 10:04:18 --> Output Class Initialized
INFO - 2020-09-12 10:04:18 --> Security Class Initialized
DEBUG - 2020-09-12 10:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:04:18 --> Input Class Initialized
INFO - 2020-09-12 10:04:18 --> Language Class Initialized
INFO - 2020-09-12 10:04:18 --> Loader Class Initialized
INFO - 2020-09-12 10:04:18 --> Helper loaded: url_helper
INFO - 2020-09-12 10:04:18 --> Database Driver Class Initialized
INFO - 2020-09-12 10:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:04:18 --> Email Class Initialized
INFO - 2020-09-12 10:04:18 --> Controller Class Initialized
DEBUG - 2020-09-12 10:04:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:04:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:04:18 --> Model Class Initialized
INFO - 2020-09-12 10:04:18 --> Model Class Initialized
INFO - 2020-09-12 10:04:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:04:18 --> Final output sent to browser
DEBUG - 2020-09-12 10:04:18 --> Total execution time: 0.0228
ERROR - 2020-09-12 10:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:04:30 --> Config Class Initialized
INFO - 2020-09-12 10:04:30 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:04:30 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:04:30 --> Utf8 Class Initialized
INFO - 2020-09-12 10:04:30 --> URI Class Initialized
INFO - 2020-09-12 10:04:30 --> Router Class Initialized
INFO - 2020-09-12 10:04:30 --> Output Class Initialized
INFO - 2020-09-12 10:04:30 --> Security Class Initialized
DEBUG - 2020-09-12 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:04:30 --> Input Class Initialized
INFO - 2020-09-12 10:04:30 --> Language Class Initialized
INFO - 2020-09-12 10:04:30 --> Loader Class Initialized
INFO - 2020-09-12 10:04:30 --> Helper loaded: url_helper
INFO - 2020-09-12 10:04:30 --> Database Driver Class Initialized
INFO - 2020-09-12 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:04:30 --> Email Class Initialized
INFO - 2020-09-12 10:04:30 --> Controller Class Initialized
DEBUG - 2020-09-12 10:04:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:04:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:04:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:04:30 --> Final output sent to browser
DEBUG - 2020-09-12 10:04:30 --> Total execution time: 0.0208
ERROR - 2020-09-12 10:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:05:27 --> Config Class Initialized
INFO - 2020-09-12 10:05:27 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:05:27 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:05:27 --> Utf8 Class Initialized
INFO - 2020-09-12 10:05:27 --> URI Class Initialized
INFO - 2020-09-12 10:05:27 --> Router Class Initialized
INFO - 2020-09-12 10:05:27 --> Output Class Initialized
INFO - 2020-09-12 10:05:27 --> Security Class Initialized
DEBUG - 2020-09-12 10:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:05:27 --> Input Class Initialized
INFO - 2020-09-12 10:05:27 --> Language Class Initialized
INFO - 2020-09-12 10:05:27 --> Loader Class Initialized
INFO - 2020-09-12 10:05:27 --> Helper loaded: url_helper
INFO - 2020-09-12 10:05:27 --> Database Driver Class Initialized
INFO - 2020-09-12 10:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:05:27 --> Email Class Initialized
INFO - 2020-09-12 10:05:27 --> Controller Class Initialized
DEBUG - 2020-09-12 10:05:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:05:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:05:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:05:27 --> Final output sent to browser
DEBUG - 2020-09-12 10:05:27 --> Total execution time: 0.0181
ERROR - 2020-09-12 10:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:06:02 --> Config Class Initialized
INFO - 2020-09-12 10:06:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:06:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:06:02 --> Utf8 Class Initialized
INFO - 2020-09-12 10:06:02 --> URI Class Initialized
INFO - 2020-09-12 10:06:02 --> Router Class Initialized
INFO - 2020-09-12 10:06:02 --> Output Class Initialized
INFO - 2020-09-12 10:06:02 --> Security Class Initialized
DEBUG - 2020-09-12 10:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:06:02 --> Input Class Initialized
INFO - 2020-09-12 10:06:02 --> Language Class Initialized
INFO - 2020-09-12 10:06:02 --> Loader Class Initialized
INFO - 2020-09-12 10:06:02 --> Helper loaded: url_helper
INFO - 2020-09-12 10:06:02 --> Database Driver Class Initialized
INFO - 2020-09-12 10:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:06:02 --> Email Class Initialized
INFO - 2020-09-12 10:06:02 --> Controller Class Initialized
DEBUG - 2020-09-12 10:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:06:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:06:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:06:02 --> Final output sent to browser
DEBUG - 2020-09-12 10:06:02 --> Total execution time: 0.0253
ERROR - 2020-09-12 10:06:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:06:32 --> Config Class Initialized
INFO - 2020-09-12 10:06:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:06:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:06:32 --> Utf8 Class Initialized
INFO - 2020-09-12 10:06:32 --> URI Class Initialized
INFO - 2020-09-12 10:06:32 --> Router Class Initialized
INFO - 2020-09-12 10:06:32 --> Output Class Initialized
INFO - 2020-09-12 10:06:32 --> Security Class Initialized
DEBUG - 2020-09-12 10:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:06:32 --> Input Class Initialized
INFO - 2020-09-12 10:06:32 --> Language Class Initialized
INFO - 2020-09-12 10:06:32 --> Loader Class Initialized
INFO - 2020-09-12 10:06:32 --> Helper loaded: url_helper
INFO - 2020-09-12 10:06:32 --> Database Driver Class Initialized
INFO - 2020-09-12 10:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:06:32 --> Email Class Initialized
INFO - 2020-09-12 10:06:32 --> Controller Class Initialized
DEBUG - 2020-09-12 10:06:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:06:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:06:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:06:32 --> Final output sent to browser
DEBUG - 2020-09-12 10:06:32 --> Total execution time: 0.0216
ERROR - 2020-09-12 10:06:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:06:44 --> Config Class Initialized
INFO - 2020-09-12 10:06:44 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:06:44 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:06:44 --> Utf8 Class Initialized
INFO - 2020-09-12 10:06:44 --> URI Class Initialized
INFO - 2020-09-12 10:06:44 --> Router Class Initialized
INFO - 2020-09-12 10:06:44 --> Output Class Initialized
INFO - 2020-09-12 10:06:44 --> Security Class Initialized
DEBUG - 2020-09-12 10:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:06:44 --> Input Class Initialized
INFO - 2020-09-12 10:06:44 --> Language Class Initialized
INFO - 2020-09-12 10:06:44 --> Loader Class Initialized
INFO - 2020-09-12 10:06:44 --> Helper loaded: url_helper
INFO - 2020-09-12 10:06:44 --> Database Driver Class Initialized
INFO - 2020-09-12 10:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:06:44 --> Email Class Initialized
INFO - 2020-09-12 10:06:44 --> Controller Class Initialized
DEBUG - 2020-09-12 10:06:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:06:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:06:44 --> Model Class Initialized
INFO - 2020-09-12 10:06:44 --> Model Class Initialized
INFO - 2020-09-12 10:06:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:06:44 --> Final output sent to browser
DEBUG - 2020-09-12 10:06:44 --> Total execution time: 0.0216
ERROR - 2020-09-12 10:08:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:08:29 --> Config Class Initialized
INFO - 2020-09-12 10:08:29 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:08:29 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:08:29 --> Utf8 Class Initialized
INFO - 2020-09-12 10:08:29 --> URI Class Initialized
INFO - 2020-09-12 10:08:29 --> Router Class Initialized
INFO - 2020-09-12 10:08:29 --> Output Class Initialized
INFO - 2020-09-12 10:08:29 --> Security Class Initialized
DEBUG - 2020-09-12 10:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:08:29 --> Input Class Initialized
INFO - 2020-09-12 10:08:29 --> Language Class Initialized
INFO - 2020-09-12 10:08:29 --> Loader Class Initialized
INFO - 2020-09-12 10:08:29 --> Helper loaded: url_helper
INFO - 2020-09-12 10:08:29 --> Database Driver Class Initialized
INFO - 2020-09-12 10:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:08:29 --> Email Class Initialized
INFO - 2020-09-12 10:08:29 --> Controller Class Initialized
DEBUG - 2020-09-12 10:08:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:08:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:08:29 --> Model Class Initialized
INFO - 2020-09-12 10:08:29 --> Model Class Initialized
INFO - 2020-09-12 10:08:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:08:29 --> Final output sent to browser
DEBUG - 2020-09-12 10:08:29 --> Total execution time: 0.0207
ERROR - 2020-09-12 10:09:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:09:13 --> Config Class Initialized
INFO - 2020-09-12 10:09:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:09:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:09:13 --> Utf8 Class Initialized
INFO - 2020-09-12 10:09:13 --> URI Class Initialized
INFO - 2020-09-12 10:09:13 --> Router Class Initialized
INFO - 2020-09-12 10:09:13 --> Output Class Initialized
INFO - 2020-09-12 10:09:13 --> Security Class Initialized
DEBUG - 2020-09-12 10:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:09:13 --> Input Class Initialized
INFO - 2020-09-12 10:09:13 --> Language Class Initialized
INFO - 2020-09-12 10:09:13 --> Loader Class Initialized
INFO - 2020-09-12 10:09:13 --> Helper loaded: url_helper
INFO - 2020-09-12 10:09:13 --> Database Driver Class Initialized
INFO - 2020-09-12 10:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:09:13 --> Email Class Initialized
INFO - 2020-09-12 10:09:13 --> Controller Class Initialized
DEBUG - 2020-09-12 10:09:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:09:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:09:13 --> Model Class Initialized
INFO - 2020-09-12 10:09:13 --> Model Class Initialized
INFO - 2020-09-12 10:09:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:09:13 --> Final output sent to browser
DEBUG - 2020-09-12 10:09:13 --> Total execution time: 0.0227
ERROR - 2020-09-12 10:09:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:09:33 --> Config Class Initialized
INFO - 2020-09-12 10:09:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:09:34 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:09:34 --> Utf8 Class Initialized
INFO - 2020-09-12 10:09:34 --> URI Class Initialized
INFO - 2020-09-12 10:09:34 --> Router Class Initialized
INFO - 2020-09-12 10:09:34 --> Output Class Initialized
INFO - 2020-09-12 10:09:34 --> Security Class Initialized
DEBUG - 2020-09-12 10:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:09:34 --> Input Class Initialized
INFO - 2020-09-12 10:09:34 --> Language Class Initialized
INFO - 2020-09-12 10:09:34 --> Loader Class Initialized
INFO - 2020-09-12 10:09:34 --> Helper loaded: url_helper
INFO - 2020-09-12 10:09:34 --> Database Driver Class Initialized
INFO - 2020-09-12 10:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:09:34 --> Email Class Initialized
INFO - 2020-09-12 10:09:34 --> Controller Class Initialized
DEBUG - 2020-09-12 10:09:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:09:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:09:34 --> Model Class Initialized
INFO - 2020-09-12 10:09:34 --> Model Class Initialized
INFO - 2020-09-12 10:09:34 --> Model Class Initialized
INFO - 2020-09-12 10:09:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 10:09:34 --> Final output sent to browser
DEBUG - 2020-09-12 10:09:34 --> Total execution time: 0.0365
ERROR - 2020-09-12 10:10:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:10:30 --> Config Class Initialized
INFO - 2020-09-12 10:10:30 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:10:30 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:10:30 --> Utf8 Class Initialized
INFO - 2020-09-12 10:10:30 --> URI Class Initialized
INFO - 2020-09-12 10:10:30 --> Router Class Initialized
INFO - 2020-09-12 10:10:30 --> Output Class Initialized
INFO - 2020-09-12 10:10:30 --> Security Class Initialized
DEBUG - 2020-09-12 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:10:30 --> Input Class Initialized
INFO - 2020-09-12 10:10:30 --> Language Class Initialized
INFO - 2020-09-12 10:10:30 --> Loader Class Initialized
INFO - 2020-09-12 10:10:30 --> Helper loaded: url_helper
INFO - 2020-09-12 10:10:30 --> Database Driver Class Initialized
INFO - 2020-09-12 10:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:10:30 --> Email Class Initialized
INFO - 2020-09-12 10:10:30 --> Controller Class Initialized
DEBUG - 2020-09-12 10:10:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:10:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:10:30 --> Model Class Initialized
INFO - 2020-09-12 10:10:30 --> Model Class Initialized
INFO - 2020-09-12 10:10:30 --> Model Class Initialized
INFO - 2020-09-12 10:10:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 10:10:30 --> Final output sent to browser
DEBUG - 2020-09-12 10:10:30 --> Total execution time: 0.0214
ERROR - 2020-09-12 10:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:10:45 --> Config Class Initialized
INFO - 2020-09-12 10:10:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:10:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:10:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:10:45 --> URI Class Initialized
INFO - 2020-09-12 10:10:45 --> Router Class Initialized
INFO - 2020-09-12 10:10:45 --> Output Class Initialized
INFO - 2020-09-12 10:10:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:10:45 --> Input Class Initialized
INFO - 2020-09-12 10:10:45 --> Language Class Initialized
INFO - 2020-09-12 10:10:45 --> Loader Class Initialized
ERROR - 2020-09-12 10:10:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:10:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:10:45 --> Config Class Initialized
INFO - 2020-09-12 10:10:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:10:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:10:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:10:45 --> URI Class Initialized
INFO - 2020-09-12 10:10:45 --> Router Class Initialized
INFO - 2020-09-12 10:10:45 --> Output Class Initialized
INFO - 2020-09-12 10:10:45 --> Database Driver Class Initialized
INFO - 2020-09-12 10:10:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:10:45 --> Input Class Initialized
INFO - 2020-09-12 10:10:45 --> Language Class Initialized
INFO - 2020-09-12 10:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:10:45 --> Loader Class Initialized
INFO - 2020-09-12 10:10:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:10:45 --> Email Class Initialized
INFO - 2020-09-12 10:10:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:10:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:10:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:10:45 --> Model Class Initialized
INFO - 2020-09-12 10:10:45 --> Model Class Initialized
INFO - 2020-09-12 10:10:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:10:45 --> Final output sent to browser
DEBUG - 2020-09-12 10:10:45 --> Total execution time: 0.0366
INFO - 2020-09-12 10:10:45 --> Database Driver Class Initialized
INFO - 2020-09-12 10:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:10:45 --> Email Class Initialized
INFO - 2020-09-12 10:10:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:10:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:10:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:10:45 --> Model Class Initialized
INFO - 2020-09-12 10:10:45 --> Model Class Initialized
INFO - 2020-09-12 10:10:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:10:46 --> Final output sent to browser
DEBUG - 2020-09-12 10:10:46 --> Total execution time: 0.0361
ERROR - 2020-09-12 10:10:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:10:51 --> Config Class Initialized
INFO - 2020-09-12 10:10:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:10:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:10:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:10:51 --> URI Class Initialized
INFO - 2020-09-12 10:10:51 --> Router Class Initialized
INFO - 2020-09-12 10:10:51 --> Output Class Initialized
INFO - 2020-09-12 10:10:51 --> Security Class Initialized
DEBUG - 2020-09-12 10:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:10:51 --> Input Class Initialized
INFO - 2020-09-12 10:10:51 --> Language Class Initialized
INFO - 2020-09-12 10:10:51 --> Loader Class Initialized
INFO - 2020-09-12 10:10:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:10:51 --> Database Driver Class Initialized
INFO - 2020-09-12 10:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:10:51 --> Email Class Initialized
INFO - 2020-09-12 10:10:51 --> Controller Class Initialized
DEBUG - 2020-09-12 10:10:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:10:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:10:51 --> Model Class Initialized
INFO - 2020-09-12 10:10:51 --> Model Class Initialized
INFO - 2020-09-12 10:10:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 10:10:51 --> Final output sent to browser
DEBUG - 2020-09-12 10:10:51 --> Total execution time: 0.0413
ERROR - 2020-09-12 10:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:11:45 --> Config Class Initialized
INFO - 2020-09-12 10:11:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:11:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:11:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:11:45 --> URI Class Initialized
INFO - 2020-09-12 10:11:45 --> Router Class Initialized
INFO - 2020-09-12 10:11:45 --> Output Class Initialized
INFO - 2020-09-12 10:11:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:11:45 --> Input Class Initialized
INFO - 2020-09-12 10:11:45 --> Language Class Initialized
INFO - 2020-09-12 10:11:45 --> Loader Class Initialized
INFO - 2020-09-12 10:11:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:11:45 --> Database Driver Class Initialized
INFO - 2020-09-12 10:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:11:45 --> Email Class Initialized
INFO - 2020-09-12 10:11:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:11:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:11:45 --> Model Class Initialized
INFO - 2020-09-12 10:11:45 --> Model Class Initialized
INFO - 2020-09-12 10:11:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 10:11:45 --> Final output sent to browser
DEBUG - 2020-09-12 10:11:45 --> Total execution time: 0.0254
ERROR - 2020-09-12 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:11:52 --> Config Class Initialized
INFO - 2020-09-12 10:11:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:11:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:11:52 --> Utf8 Class Initialized
INFO - 2020-09-12 10:11:52 --> URI Class Initialized
INFO - 2020-09-12 10:11:52 --> Router Class Initialized
INFO - 2020-09-12 10:11:52 --> Output Class Initialized
INFO - 2020-09-12 10:11:52 --> Security Class Initialized
DEBUG - 2020-09-12 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:11:52 --> Input Class Initialized
INFO - 2020-09-12 10:11:52 --> Language Class Initialized
INFO - 2020-09-12 10:11:52 --> Loader Class Initialized
INFO - 2020-09-12 10:11:52 --> Helper loaded: url_helper
INFO - 2020-09-12 10:11:52 --> Database Driver Class Initialized
INFO - 2020-09-12 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:11:52 --> Email Class Initialized
INFO - 2020-09-12 10:11:52 --> Controller Class Initialized
DEBUG - 2020-09-12 10:11:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:11:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:11:52 --> Model Class Initialized
INFO - 2020-09-12 10:11:52 --> Model Class Initialized
INFO - 2020-09-12 10:11:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:11:52 --> Final output sent to browser
DEBUG - 2020-09-12 10:11:52 --> Total execution time: 0.0238
ERROR - 2020-09-12 10:11:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:11:54 --> Config Class Initialized
INFO - 2020-09-12 10:11:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:11:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:11:54 --> Utf8 Class Initialized
INFO - 2020-09-12 10:11:54 --> URI Class Initialized
INFO - 2020-09-12 10:11:54 --> Router Class Initialized
INFO - 2020-09-12 10:11:54 --> Output Class Initialized
INFO - 2020-09-12 10:11:54 --> Security Class Initialized
DEBUG - 2020-09-12 10:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:11:54 --> Input Class Initialized
INFO - 2020-09-12 10:11:54 --> Language Class Initialized
INFO - 2020-09-12 10:11:54 --> Loader Class Initialized
INFO - 2020-09-12 10:11:54 --> Helper loaded: url_helper
INFO - 2020-09-12 10:11:54 --> Database Driver Class Initialized
INFO - 2020-09-12 10:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:11:54 --> Email Class Initialized
INFO - 2020-09-12 10:11:54 --> Controller Class Initialized
DEBUG - 2020-09-12 10:11:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:11:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:11:54 --> Model Class Initialized
INFO - 2020-09-12 10:11:54 --> Model Class Initialized
INFO - 2020-09-12 10:11:54 --> Model Class Initialized
INFO - 2020-09-12 10:11:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 10:11:54 --> Final output sent to browser
DEBUG - 2020-09-12 10:11:54 --> Total execution time: 0.0230
ERROR - 2020-09-12 10:13:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:13:41 --> Config Class Initialized
INFO - 2020-09-12 10:13:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:13:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:13:41 --> Utf8 Class Initialized
INFO - 2020-09-12 10:13:41 --> URI Class Initialized
INFO - 2020-09-12 10:13:41 --> Router Class Initialized
INFO - 2020-09-12 10:13:41 --> Output Class Initialized
INFO - 2020-09-12 10:13:41 --> Security Class Initialized
DEBUG - 2020-09-12 10:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:13:41 --> Input Class Initialized
INFO - 2020-09-12 10:13:41 --> Language Class Initialized
INFO - 2020-09-12 10:13:41 --> Loader Class Initialized
INFO - 2020-09-12 10:13:41 --> Helper loaded: url_helper
INFO - 2020-09-12 10:13:41 --> Database Driver Class Initialized
INFO - 2020-09-12 10:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:13:41 --> Email Class Initialized
INFO - 2020-09-12 10:13:41 --> Controller Class Initialized
DEBUG - 2020-09-12 10:13:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:13:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:13:41 --> Model Class Initialized
INFO - 2020-09-12 10:13:41 --> Model Class Initialized
INFO - 2020-09-12 10:13:41 --> Model Class Initialized
INFO - 2020-09-12 10:13:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 10:13:41 --> Final output sent to browser
DEBUG - 2020-09-12 10:13:41 --> Total execution time: 0.0223
ERROR - 2020-09-12 10:13:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:13:46 --> Config Class Initialized
INFO - 2020-09-12 10:13:46 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:13:46 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:13:46 --> Utf8 Class Initialized
INFO - 2020-09-12 10:13:46 --> URI Class Initialized
INFO - 2020-09-12 10:13:46 --> Router Class Initialized
INFO - 2020-09-12 10:13:46 --> Output Class Initialized
INFO - 2020-09-12 10:13:46 --> Security Class Initialized
DEBUG - 2020-09-12 10:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:13:46 --> Input Class Initialized
INFO - 2020-09-12 10:13:46 --> Language Class Initialized
INFO - 2020-09-12 10:13:46 --> Loader Class Initialized
INFO - 2020-09-12 10:13:46 --> Helper loaded: url_helper
INFO - 2020-09-12 10:13:46 --> Database Driver Class Initialized
INFO - 2020-09-12 10:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:13:46 --> Email Class Initialized
INFO - 2020-09-12 10:13:46 --> Controller Class Initialized
DEBUG - 2020-09-12 10:13:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:13:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:13:46 --> Model Class Initialized
INFO - 2020-09-12 10:13:46 --> Model Class Initialized
INFO - 2020-09-12 10:13:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:13:46 --> Final output sent to browser
DEBUG - 2020-09-12 10:13:46 --> Total execution time: 0.0185
ERROR - 2020-09-12 10:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:13:53 --> Config Class Initialized
INFO - 2020-09-12 10:13:53 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:13:53 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:13:53 --> Utf8 Class Initialized
INFO - 2020-09-12 10:13:53 --> URI Class Initialized
INFO - 2020-09-12 10:13:53 --> Router Class Initialized
INFO - 2020-09-12 10:13:53 --> Output Class Initialized
INFO - 2020-09-12 10:13:53 --> Security Class Initialized
DEBUG - 2020-09-12 10:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:13:53 --> Input Class Initialized
INFO - 2020-09-12 10:13:53 --> Language Class Initialized
INFO - 2020-09-12 10:13:53 --> Loader Class Initialized
INFO - 2020-09-12 10:13:53 --> Helper loaded: url_helper
INFO - 2020-09-12 10:13:53 --> Database Driver Class Initialized
INFO - 2020-09-12 10:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:13:53 --> Email Class Initialized
INFO - 2020-09-12 10:13:53 --> Controller Class Initialized
DEBUG - 2020-09-12 10:13:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:13:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:13:53 --> Model Class Initialized
INFO - 2020-09-12 10:13:53 --> Model Class Initialized
INFO - 2020-09-12 10:13:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:13:53 --> Final output sent to browser
DEBUG - 2020-09-12 10:13:53 --> Total execution time: 0.0242
ERROR - 2020-09-12 10:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:15:49 --> Config Class Initialized
INFO - 2020-09-12 10:15:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:15:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:15:49 --> Utf8 Class Initialized
INFO - 2020-09-12 10:15:49 --> URI Class Initialized
INFO - 2020-09-12 10:15:49 --> Router Class Initialized
INFO - 2020-09-12 10:15:49 --> Output Class Initialized
INFO - 2020-09-12 10:15:49 --> Security Class Initialized
DEBUG - 2020-09-12 10:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:15:49 --> Input Class Initialized
INFO - 2020-09-12 10:15:49 --> Language Class Initialized
INFO - 2020-09-12 10:15:49 --> Loader Class Initialized
INFO - 2020-09-12 10:15:49 --> Helper loaded: url_helper
INFO - 2020-09-12 10:15:49 --> Database Driver Class Initialized
INFO - 2020-09-12 10:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:15:49 --> Email Class Initialized
INFO - 2020-09-12 10:15:49 --> Controller Class Initialized
DEBUG - 2020-09-12 10:15:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:15:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:15:49 --> Model Class Initialized
INFO - 2020-09-12 10:15:49 --> Model Class Initialized
INFO - 2020-09-12 10:15:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:15:49 --> Final output sent to browser
DEBUG - 2020-09-12 10:15:49 --> Total execution time: 0.1114
ERROR - 2020-09-12 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:15:51 --> Config Class Initialized
INFO - 2020-09-12 10:15:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:15:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:15:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:15:51 --> URI Class Initialized
INFO - 2020-09-12 10:15:51 --> Router Class Initialized
INFO - 2020-09-12 10:15:51 --> Output Class Initialized
INFO - 2020-09-12 10:15:51 --> Security Class Initialized
DEBUG - 2020-09-12 10:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:15:51 --> Input Class Initialized
INFO - 2020-09-12 10:15:51 --> Language Class Initialized
INFO - 2020-09-12 10:15:51 --> Loader Class Initialized
INFO - 2020-09-12 10:15:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:15:51 --> Database Driver Class Initialized
INFO - 2020-09-12 10:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:15:51 --> Email Class Initialized
INFO - 2020-09-12 10:15:51 --> Controller Class Initialized
DEBUG - 2020-09-12 10:15:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:15:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:15:51 --> Model Class Initialized
INFO - 2020-09-12 10:15:51 --> Model Class Initialized
INFO - 2020-09-12 10:15:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:15:51 --> Final output sent to browser
DEBUG - 2020-09-12 10:15:51 --> Total execution time: 0.0203
ERROR - 2020-09-12 10:17:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:17:05 --> Config Class Initialized
INFO - 2020-09-12 10:17:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:17:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:17:05 --> Utf8 Class Initialized
INFO - 2020-09-12 10:17:05 --> URI Class Initialized
INFO - 2020-09-12 10:17:05 --> Router Class Initialized
INFO - 2020-09-12 10:17:05 --> Output Class Initialized
INFO - 2020-09-12 10:17:05 --> Security Class Initialized
DEBUG - 2020-09-12 10:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:17:05 --> Input Class Initialized
INFO - 2020-09-12 10:17:05 --> Language Class Initialized
INFO - 2020-09-12 10:17:05 --> Loader Class Initialized
INFO - 2020-09-12 10:17:05 --> Helper loaded: url_helper
INFO - 2020-09-12 10:17:05 --> Database Driver Class Initialized
INFO - 2020-09-12 10:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:17:05 --> Email Class Initialized
INFO - 2020-09-12 10:17:05 --> Controller Class Initialized
DEBUG - 2020-09-12 10:17:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:17:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:17:05 --> Model Class Initialized
INFO - 2020-09-12 10:17:05 --> Model Class Initialized
INFO - 2020-09-12 10:17:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:17:05 --> Final output sent to browser
DEBUG - 2020-09-12 10:17:05 --> Total execution time: 0.0175
ERROR - 2020-09-12 10:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:17:11 --> Config Class Initialized
INFO - 2020-09-12 10:17:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:17:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:17:11 --> Utf8 Class Initialized
INFO - 2020-09-12 10:17:11 --> URI Class Initialized
INFO - 2020-09-12 10:17:11 --> Router Class Initialized
INFO - 2020-09-12 10:17:11 --> Output Class Initialized
INFO - 2020-09-12 10:17:11 --> Security Class Initialized
DEBUG - 2020-09-12 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:17:11 --> Input Class Initialized
INFO - 2020-09-12 10:17:11 --> Language Class Initialized
INFO - 2020-09-12 10:17:11 --> Loader Class Initialized
INFO - 2020-09-12 10:17:11 --> Helper loaded: url_helper
INFO - 2020-09-12 10:17:11 --> Database Driver Class Initialized
INFO - 2020-09-12 10:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:17:11 --> Email Class Initialized
INFO - 2020-09-12 10:17:11 --> Controller Class Initialized
DEBUG - 2020-09-12 10:17:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:17:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:17:11 --> Model Class Initialized
INFO - 2020-09-12 10:17:11 --> Model Class Initialized
INFO - 2020-09-12 10:17:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:17:11 --> Final output sent to browser
DEBUG - 2020-09-12 10:17:11 --> Total execution time: 0.0220
ERROR - 2020-09-12 10:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:17:30 --> Config Class Initialized
INFO - 2020-09-12 10:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:17:30 --> Utf8 Class Initialized
INFO - 2020-09-12 10:17:30 --> URI Class Initialized
INFO - 2020-09-12 10:17:30 --> Router Class Initialized
INFO - 2020-09-12 10:17:30 --> Output Class Initialized
INFO - 2020-09-12 10:17:30 --> Security Class Initialized
DEBUG - 2020-09-12 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:17:30 --> Input Class Initialized
INFO - 2020-09-12 10:17:30 --> Language Class Initialized
INFO - 2020-09-12 10:17:30 --> Loader Class Initialized
INFO - 2020-09-12 10:17:30 --> Helper loaded: url_helper
INFO - 2020-09-12 10:17:30 --> Database Driver Class Initialized
INFO - 2020-09-12 10:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:17:30 --> Email Class Initialized
INFO - 2020-09-12 10:17:30 --> Controller Class Initialized
DEBUG - 2020-09-12 10:17:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:17:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:17:30 --> Model Class Initialized
INFO - 2020-09-12 10:17:30 --> Model Class Initialized
INFO - 2020-09-12 10:17:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:17:30 --> Final output sent to browser
DEBUG - 2020-09-12 10:17:30 --> Total execution time: 0.0224
ERROR - 2020-09-12 10:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:17:36 --> Config Class Initialized
INFO - 2020-09-12 10:17:36 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:17:36 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:17:36 --> Utf8 Class Initialized
INFO - 2020-09-12 10:17:36 --> URI Class Initialized
INFO - 2020-09-12 10:17:36 --> Router Class Initialized
INFO - 2020-09-12 10:17:36 --> Output Class Initialized
INFO - 2020-09-12 10:17:36 --> Security Class Initialized
DEBUG - 2020-09-12 10:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:17:36 --> Input Class Initialized
INFO - 2020-09-12 10:17:36 --> Language Class Initialized
INFO - 2020-09-12 10:17:36 --> Loader Class Initialized
INFO - 2020-09-12 10:17:36 --> Helper loaded: url_helper
INFO - 2020-09-12 10:17:36 --> Database Driver Class Initialized
INFO - 2020-09-12 10:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:17:36 --> Email Class Initialized
INFO - 2020-09-12 10:17:36 --> Controller Class Initialized
DEBUG - 2020-09-12 10:17:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:17:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:17:36 --> Model Class Initialized
INFO - 2020-09-12 10:17:36 --> Model Class Initialized
INFO - 2020-09-12 10:17:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:17:36 --> Final output sent to browser
DEBUG - 2020-09-12 10:17:36 --> Total execution time: 0.0250
ERROR - 2020-09-12 10:18:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:18:59 --> Config Class Initialized
INFO - 2020-09-12 10:18:59 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:18:59 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:18:59 --> Utf8 Class Initialized
INFO - 2020-09-12 10:18:59 --> URI Class Initialized
INFO - 2020-09-12 10:18:59 --> Router Class Initialized
INFO - 2020-09-12 10:18:59 --> Output Class Initialized
INFO - 2020-09-12 10:18:59 --> Security Class Initialized
DEBUG - 2020-09-12 10:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:18:59 --> Input Class Initialized
INFO - 2020-09-12 10:18:59 --> Language Class Initialized
INFO - 2020-09-12 10:18:59 --> Loader Class Initialized
INFO - 2020-09-12 10:18:59 --> Helper loaded: url_helper
INFO - 2020-09-12 10:18:59 --> Database Driver Class Initialized
INFO - 2020-09-12 10:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:18:59 --> Email Class Initialized
INFO - 2020-09-12 10:18:59 --> Controller Class Initialized
DEBUG - 2020-09-12 10:18:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:18:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:18:59 --> Model Class Initialized
INFO - 2020-09-12 10:18:59 --> Model Class Initialized
INFO - 2020-09-12 10:18:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:18:59 --> Final output sent to browser
DEBUG - 2020-09-12 10:18:59 --> Total execution time: 0.0237
ERROR - 2020-09-12 10:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:19:03 --> Config Class Initialized
INFO - 2020-09-12 10:19:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:19:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:19:03 --> Utf8 Class Initialized
INFO - 2020-09-12 10:19:03 --> URI Class Initialized
INFO - 2020-09-12 10:19:03 --> Router Class Initialized
INFO - 2020-09-12 10:19:03 --> Output Class Initialized
INFO - 2020-09-12 10:19:03 --> Security Class Initialized
DEBUG - 2020-09-12 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:19:03 --> Input Class Initialized
INFO - 2020-09-12 10:19:03 --> Language Class Initialized
INFO - 2020-09-12 10:19:03 --> Loader Class Initialized
INFO - 2020-09-12 10:19:03 --> Helper loaded: url_helper
INFO - 2020-09-12 10:19:03 --> Database Driver Class Initialized
INFO - 2020-09-12 10:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:19:03 --> Email Class Initialized
INFO - 2020-09-12 10:19:03 --> Controller Class Initialized
DEBUG - 2020-09-12 10:19:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:19:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:19:03 --> Model Class Initialized
INFO - 2020-09-12 10:19:03 --> Model Class Initialized
INFO - 2020-09-12 10:19:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-12 10:19:03 --> Final output sent to browser
DEBUG - 2020-09-12 10:19:03 --> Total execution time: 0.0285
ERROR - 2020-09-12 10:19:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:19:32 --> Config Class Initialized
INFO - 2020-09-12 10:19:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:19:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:19:32 --> Utf8 Class Initialized
INFO - 2020-09-12 10:19:32 --> URI Class Initialized
INFO - 2020-09-12 10:19:32 --> Router Class Initialized
INFO - 2020-09-12 10:19:32 --> Output Class Initialized
INFO - 2020-09-12 10:19:32 --> Security Class Initialized
DEBUG - 2020-09-12 10:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:19:32 --> Input Class Initialized
INFO - 2020-09-12 10:19:32 --> Language Class Initialized
INFO - 2020-09-12 10:19:32 --> Loader Class Initialized
INFO - 2020-09-12 10:19:32 --> Helper loaded: url_helper
INFO - 2020-09-12 10:19:32 --> Database Driver Class Initialized
INFO - 2020-09-12 10:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:19:32 --> Email Class Initialized
INFO - 2020-09-12 10:19:32 --> Controller Class Initialized
DEBUG - 2020-09-12 10:19:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:19:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:19:32 --> Model Class Initialized
INFO - 2020-09-12 10:19:32 --> Model Class Initialized
INFO - 2020-09-12 10:19:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-12 10:19:32 --> Final output sent to browser
DEBUG - 2020-09-12 10:19:32 --> Total execution time: 0.0226
ERROR - 2020-09-12 10:19:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:19:37 --> Config Class Initialized
INFO - 2020-09-12 10:19:37 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:19:37 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:19:37 --> Utf8 Class Initialized
INFO - 2020-09-12 10:19:37 --> URI Class Initialized
INFO - 2020-09-12 10:19:37 --> Router Class Initialized
INFO - 2020-09-12 10:19:37 --> Output Class Initialized
INFO - 2020-09-12 10:19:37 --> Security Class Initialized
DEBUG - 2020-09-12 10:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:19:37 --> Input Class Initialized
INFO - 2020-09-12 10:19:37 --> Language Class Initialized
INFO - 2020-09-12 10:19:37 --> Loader Class Initialized
INFO - 2020-09-12 10:19:37 --> Helper loaded: url_helper
INFO - 2020-09-12 10:19:37 --> Database Driver Class Initialized
INFO - 2020-09-12 10:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:19:37 --> Email Class Initialized
INFO - 2020-09-12 10:19:37 --> Controller Class Initialized
DEBUG - 2020-09-12 10:19:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:19:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:19:37 --> Model Class Initialized
INFO - 2020-09-12 10:19:37 --> Model Class Initialized
INFO - 2020-09-12 10:19:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:19:37 --> Final output sent to browser
DEBUG - 2020-09-12 10:19:37 --> Total execution time: 0.0205
ERROR - 2020-09-12 10:19:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:19:41 --> Config Class Initialized
INFO - 2020-09-12 10:19:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:19:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:19:41 --> Utf8 Class Initialized
INFO - 2020-09-12 10:19:41 --> URI Class Initialized
INFO - 2020-09-12 10:19:41 --> Router Class Initialized
INFO - 2020-09-12 10:19:41 --> Output Class Initialized
INFO - 2020-09-12 10:19:41 --> Security Class Initialized
DEBUG - 2020-09-12 10:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:19:41 --> Input Class Initialized
INFO - 2020-09-12 10:19:41 --> Language Class Initialized
INFO - 2020-09-12 10:19:41 --> Loader Class Initialized
INFO - 2020-09-12 10:19:41 --> Helper loaded: url_helper
INFO - 2020-09-12 10:19:41 --> Database Driver Class Initialized
INFO - 2020-09-12 10:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:19:41 --> Email Class Initialized
INFO - 2020-09-12 10:19:41 --> Controller Class Initialized
DEBUG - 2020-09-12 10:19:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:19:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:19:41 --> Model Class Initialized
INFO - 2020-09-12 10:19:41 --> Model Class Initialized
INFO - 2020-09-12 10:19:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-12 10:19:41 --> Final output sent to browser
DEBUG - 2020-09-12 10:19:41 --> Total execution time: 0.0233
ERROR - 2020-09-12 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:20:26 --> Config Class Initialized
INFO - 2020-09-12 10:20:26 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:20:26 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:20:26 --> Utf8 Class Initialized
INFO - 2020-09-12 10:20:26 --> URI Class Initialized
INFO - 2020-09-12 10:20:26 --> Router Class Initialized
INFO - 2020-09-12 10:20:26 --> Output Class Initialized
INFO - 2020-09-12 10:20:26 --> Security Class Initialized
DEBUG - 2020-09-12 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:20:26 --> Input Class Initialized
INFO - 2020-09-12 10:20:26 --> Language Class Initialized
INFO - 2020-09-12 10:20:26 --> Loader Class Initialized
INFO - 2020-09-12 10:20:26 --> Helper loaded: url_helper
INFO - 2020-09-12 10:20:26 --> Database Driver Class Initialized
INFO - 2020-09-12 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:20:26 --> Email Class Initialized
INFO - 2020-09-12 10:20:26 --> Controller Class Initialized
DEBUG - 2020-09-12 10:20:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:20:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:20:26 --> Model Class Initialized
INFO - 2020-09-12 10:20:26 --> Model Class Initialized
INFO - 2020-09-12 10:20:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-12 10:20:26 --> Final output sent to browser
DEBUG - 2020-09-12 10:20:26 --> Total execution time: 0.0252
ERROR - 2020-09-12 10:20:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:20:28 --> Config Class Initialized
INFO - 2020-09-12 10:20:28 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:20:28 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:20:28 --> Utf8 Class Initialized
INFO - 2020-09-12 10:20:28 --> URI Class Initialized
INFO - 2020-09-12 10:20:28 --> Router Class Initialized
INFO - 2020-09-12 10:20:28 --> Output Class Initialized
INFO - 2020-09-12 10:20:28 --> Security Class Initialized
DEBUG - 2020-09-12 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:20:28 --> Input Class Initialized
INFO - 2020-09-12 10:20:28 --> Language Class Initialized
INFO - 2020-09-12 10:20:28 --> Loader Class Initialized
INFO - 2020-09-12 10:20:28 --> Helper loaded: url_helper
INFO - 2020-09-12 10:20:28 --> Database Driver Class Initialized
INFO - 2020-09-12 10:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:20:28 --> Email Class Initialized
INFO - 2020-09-12 10:20:28 --> Controller Class Initialized
DEBUG - 2020-09-12 10:20:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:20:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:20:28 --> Model Class Initialized
INFO - 2020-09-12 10:20:28 --> Model Class Initialized
INFO - 2020-09-12 10:20:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:20:28 --> Final output sent to browser
DEBUG - 2020-09-12 10:20:28 --> Total execution time: 0.0222
ERROR - 2020-09-12 10:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:20:31 --> Config Class Initialized
INFO - 2020-09-12 10:20:31 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:20:31 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:20:31 --> Utf8 Class Initialized
INFO - 2020-09-12 10:20:31 --> URI Class Initialized
INFO - 2020-09-12 10:20:31 --> Router Class Initialized
INFO - 2020-09-12 10:20:31 --> Output Class Initialized
INFO - 2020-09-12 10:20:31 --> Security Class Initialized
DEBUG - 2020-09-12 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:20:31 --> Input Class Initialized
INFO - 2020-09-12 10:20:31 --> Language Class Initialized
INFO - 2020-09-12 10:20:31 --> Loader Class Initialized
INFO - 2020-09-12 10:20:31 --> Helper loaded: url_helper
INFO - 2020-09-12 10:20:31 --> Database Driver Class Initialized
INFO - 2020-09-12 10:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:20:32 --> Email Class Initialized
INFO - 2020-09-12 10:20:32 --> Controller Class Initialized
DEBUG - 2020-09-12 10:20:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:20:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:20:32 --> Model Class Initialized
INFO - 2020-09-12 10:20:32 --> Model Class Initialized
INFO - 2020-09-12 10:20:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-12 10:20:32 --> Final output sent to browser
DEBUG - 2020-09-12 10:20:32 --> Total execution time: 0.0220
ERROR - 2020-09-12 10:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:20:45 --> Config Class Initialized
INFO - 2020-09-12 10:20:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:20:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:20:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:20:45 --> URI Class Initialized
INFO - 2020-09-12 10:20:45 --> Router Class Initialized
INFO - 2020-09-12 10:20:45 --> Output Class Initialized
INFO - 2020-09-12 10:20:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:20:45 --> Input Class Initialized
INFO - 2020-09-12 10:20:45 --> Language Class Initialized
INFO - 2020-09-12 10:20:45 --> Loader Class Initialized
INFO - 2020-09-12 10:20:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:20:45 --> Database Driver Class Initialized
INFO - 2020-09-12 10:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:20:45 --> Email Class Initialized
INFO - 2020-09-12 10:20:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:20:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:20:45 --> Model Class Initialized
INFO - 2020-09-12 10:20:45 --> Model Class Initialized
INFO - 2020-09-12 10:20:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:20:45 --> Final output sent to browser
DEBUG - 2020-09-12 10:20:45 --> Total execution time: 0.0227
ERROR - 2020-09-12 10:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:20:54 --> Config Class Initialized
INFO - 2020-09-12 10:20:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:20:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:20:54 --> Utf8 Class Initialized
INFO - 2020-09-12 10:20:54 --> URI Class Initialized
INFO - 2020-09-12 10:20:54 --> Router Class Initialized
INFO - 2020-09-12 10:20:54 --> Output Class Initialized
INFO - 2020-09-12 10:20:54 --> Security Class Initialized
DEBUG - 2020-09-12 10:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:20:54 --> Input Class Initialized
INFO - 2020-09-12 10:20:54 --> Language Class Initialized
INFO - 2020-09-12 10:20:54 --> Loader Class Initialized
INFO - 2020-09-12 10:20:54 --> Helper loaded: url_helper
INFO - 2020-09-12 10:20:54 --> Database Driver Class Initialized
INFO - 2020-09-12 10:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:20:54 --> Email Class Initialized
INFO - 2020-09-12 10:20:54 --> Controller Class Initialized
DEBUG - 2020-09-12 10:20:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:20:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:20:54 --> Model Class Initialized
INFO - 2020-09-12 10:20:54 --> Model Class Initialized
INFO - 2020-09-12 10:20:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:20:54 --> Final output sent to browser
DEBUG - 2020-09-12 10:20:54 --> Total execution time: 0.0223
ERROR - 2020-09-12 10:21:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:21:41 --> Config Class Initialized
INFO - 2020-09-12 10:21:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:21:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:21:41 --> Utf8 Class Initialized
INFO - 2020-09-12 10:21:41 --> URI Class Initialized
INFO - 2020-09-12 10:21:41 --> Router Class Initialized
INFO - 2020-09-12 10:21:41 --> Output Class Initialized
INFO - 2020-09-12 10:21:41 --> Security Class Initialized
DEBUG - 2020-09-12 10:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:21:41 --> Input Class Initialized
INFO - 2020-09-12 10:21:41 --> Language Class Initialized
INFO - 2020-09-12 10:21:41 --> Loader Class Initialized
INFO - 2020-09-12 10:21:41 --> Helper loaded: url_helper
INFO - 2020-09-12 10:21:41 --> Database Driver Class Initialized
INFO - 2020-09-12 10:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:21:41 --> Email Class Initialized
INFO - 2020-09-12 10:21:41 --> Controller Class Initialized
DEBUG - 2020-09-12 10:21:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:21:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:21:41 --> Model Class Initialized
INFO - 2020-09-12 10:21:41 --> Model Class Initialized
INFO - 2020-09-12 10:21:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:21:41 --> Final output sent to browser
DEBUG - 2020-09-12 10:21:41 --> Total execution time: 0.0231
ERROR - 2020-09-12 10:21:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:21:59 --> Config Class Initialized
INFO - 2020-09-12 10:21:59 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:21:59 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:21:59 --> Utf8 Class Initialized
INFO - 2020-09-12 10:21:59 --> URI Class Initialized
INFO - 2020-09-12 10:21:59 --> Router Class Initialized
INFO - 2020-09-12 10:21:59 --> Output Class Initialized
INFO - 2020-09-12 10:21:59 --> Security Class Initialized
DEBUG - 2020-09-12 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:21:59 --> Input Class Initialized
INFO - 2020-09-12 10:21:59 --> Language Class Initialized
INFO - 2020-09-12 10:21:59 --> Loader Class Initialized
INFO - 2020-09-12 10:21:59 --> Helper loaded: url_helper
INFO - 2020-09-12 10:21:59 --> Database Driver Class Initialized
INFO - 2020-09-12 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:21:59 --> Email Class Initialized
INFO - 2020-09-12 10:21:59 --> Controller Class Initialized
DEBUG - 2020-09-12 10:21:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:21:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:21:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 10:21:59 --> Final output sent to browser
DEBUG - 2020-09-12 10:21:59 --> Total execution time: 0.0191
ERROR - 2020-09-12 10:23:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:23:11 --> Config Class Initialized
INFO - 2020-09-12 10:23:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:23:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:23:11 --> Utf8 Class Initialized
INFO - 2020-09-12 10:23:11 --> URI Class Initialized
INFO - 2020-09-12 10:23:11 --> Router Class Initialized
INFO - 2020-09-12 10:23:11 --> Output Class Initialized
INFO - 2020-09-12 10:23:11 --> Security Class Initialized
DEBUG - 2020-09-12 10:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:23:11 --> Input Class Initialized
INFO - 2020-09-12 10:23:11 --> Language Class Initialized
INFO - 2020-09-12 10:23:11 --> Loader Class Initialized
INFO - 2020-09-12 10:23:11 --> Helper loaded: url_helper
INFO - 2020-09-12 10:23:11 --> Database Driver Class Initialized
INFO - 2020-09-12 10:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:23:11 --> Email Class Initialized
INFO - 2020-09-12 10:23:11 --> Controller Class Initialized
DEBUG - 2020-09-12 10:23:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:23:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:23:11 --> Model Class Initialized
INFO - 2020-09-12 10:23:11 --> Model Class Initialized
INFO - 2020-09-12 10:23:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:23:11 --> Final output sent to browser
DEBUG - 2020-09-12 10:23:11 --> Total execution time: 0.0219
ERROR - 2020-09-12 10:23:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:23:13 --> Config Class Initialized
INFO - 2020-09-12 10:23:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:23:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:23:13 --> Utf8 Class Initialized
INFO - 2020-09-12 10:23:13 --> URI Class Initialized
INFO - 2020-09-12 10:23:13 --> Router Class Initialized
INFO - 2020-09-12 10:23:13 --> Output Class Initialized
INFO - 2020-09-12 10:23:13 --> Security Class Initialized
DEBUG - 2020-09-12 10:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:23:13 --> Input Class Initialized
INFO - 2020-09-12 10:23:13 --> Language Class Initialized
INFO - 2020-09-12 10:23:13 --> Loader Class Initialized
INFO - 2020-09-12 10:23:13 --> Helper loaded: url_helper
INFO - 2020-09-12 10:23:13 --> Database Driver Class Initialized
INFO - 2020-09-12 10:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:23:13 --> Email Class Initialized
INFO - 2020-09-12 10:23:13 --> Controller Class Initialized
DEBUG - 2020-09-12 10:23:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:23:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:23:13 --> Model Class Initialized
INFO - 2020-09-12 10:23:13 --> Model Class Initialized
INFO - 2020-09-12 10:23:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:23:13 --> Final output sent to browser
DEBUG - 2020-09-12 10:23:13 --> Total execution time: 0.0347
ERROR - 2020-09-12 10:23:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:23:19 --> Config Class Initialized
INFO - 2020-09-12 10:23:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:23:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:23:19 --> Utf8 Class Initialized
INFO - 2020-09-12 10:23:19 --> URI Class Initialized
INFO - 2020-09-12 10:23:19 --> Router Class Initialized
INFO - 2020-09-12 10:23:19 --> Output Class Initialized
INFO - 2020-09-12 10:23:19 --> Security Class Initialized
DEBUG - 2020-09-12 10:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:23:19 --> Input Class Initialized
INFO - 2020-09-12 10:23:19 --> Language Class Initialized
INFO - 2020-09-12 10:23:19 --> Loader Class Initialized
INFO - 2020-09-12 10:23:19 --> Helper loaded: url_helper
INFO - 2020-09-12 10:23:19 --> Database Driver Class Initialized
INFO - 2020-09-12 10:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:23:19 --> Email Class Initialized
INFO - 2020-09-12 10:23:19 --> Controller Class Initialized
DEBUG - 2020-09-12 10:23:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:23:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:23:19 --> Model Class Initialized
INFO - 2020-09-12 10:23:19 --> Model Class Initialized
INFO - 2020-09-12 10:23:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:23:19 --> Final output sent to browser
DEBUG - 2020-09-12 10:23:19 --> Total execution time: 0.0269
ERROR - 2020-09-12 10:23:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:23:56 --> Config Class Initialized
INFO - 2020-09-12 10:23:56 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:23:56 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:23:56 --> Utf8 Class Initialized
INFO - 2020-09-12 10:23:56 --> URI Class Initialized
INFO - 2020-09-12 10:23:56 --> Router Class Initialized
INFO - 2020-09-12 10:23:56 --> Output Class Initialized
INFO - 2020-09-12 10:23:56 --> Security Class Initialized
DEBUG - 2020-09-12 10:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:23:56 --> Input Class Initialized
INFO - 2020-09-12 10:23:56 --> Language Class Initialized
INFO - 2020-09-12 10:23:56 --> Loader Class Initialized
INFO - 2020-09-12 10:23:56 --> Helper loaded: url_helper
INFO - 2020-09-12 10:23:56 --> Database Driver Class Initialized
INFO - 2020-09-12 10:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:23:56 --> Email Class Initialized
INFO - 2020-09-12 10:23:56 --> Controller Class Initialized
DEBUG - 2020-09-12 10:23:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:23:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:23:56 --> Model Class Initialized
INFO - 2020-09-12 10:23:56 --> Model Class Initialized
INFO - 2020-09-12 10:23:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:23:56 --> Final output sent to browser
DEBUG - 2020-09-12 10:23:56 --> Total execution time: 0.0241
ERROR - 2020-09-12 10:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:24:30 --> Config Class Initialized
INFO - 2020-09-12 10:24:30 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:24:30 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:24:30 --> Utf8 Class Initialized
INFO - 2020-09-12 10:24:30 --> URI Class Initialized
INFO - 2020-09-12 10:24:30 --> Router Class Initialized
INFO - 2020-09-12 10:24:30 --> Output Class Initialized
INFO - 2020-09-12 10:24:30 --> Security Class Initialized
DEBUG - 2020-09-12 10:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:24:30 --> Input Class Initialized
INFO - 2020-09-12 10:24:30 --> Language Class Initialized
INFO - 2020-09-12 10:24:30 --> Loader Class Initialized
INFO - 2020-09-12 10:24:30 --> Helper loaded: url_helper
INFO - 2020-09-12 10:24:30 --> Database Driver Class Initialized
INFO - 2020-09-12 10:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:24:30 --> Email Class Initialized
INFO - 2020-09-12 10:24:30 --> Controller Class Initialized
DEBUG - 2020-09-12 10:24:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:24:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:24:30 --> Model Class Initialized
INFO - 2020-09-12 10:24:30 --> Model Class Initialized
INFO - 2020-09-12 10:24:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:24:30 --> Final output sent to browser
DEBUG - 2020-09-12 10:24:30 --> Total execution time: 0.0259
ERROR - 2020-09-12 10:25:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:19 --> Config Class Initialized
INFO - 2020-09-12 10:25:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:19 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:19 --> URI Class Initialized
INFO - 2020-09-12 10:25:19 --> Router Class Initialized
INFO - 2020-09-12 10:25:19 --> Output Class Initialized
INFO - 2020-09-12 10:25:19 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:19 --> Input Class Initialized
INFO - 2020-09-12 10:25:19 --> Language Class Initialized
INFO - 2020-09-12 10:25:19 --> Loader Class Initialized
INFO - 2020-09-12 10:25:19 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:19 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:19 --> Email Class Initialized
INFO - 2020-09-12 10:25:19 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:19 --> Model Class Initialized
INFO - 2020-09-12 10:25:19 --> Model Class Initialized
INFO - 2020-09-12 10:25:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:25:19 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:19 --> Total execution time: 0.0226
ERROR - 2020-09-12 10:25:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:24 --> Config Class Initialized
INFO - 2020-09-12 10:25:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:24 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:24 --> URI Class Initialized
INFO - 2020-09-12 10:25:24 --> Router Class Initialized
INFO - 2020-09-12 10:25:24 --> Output Class Initialized
INFO - 2020-09-12 10:25:24 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:24 --> Input Class Initialized
INFO - 2020-09-12 10:25:24 --> Language Class Initialized
INFO - 2020-09-12 10:25:24 --> Loader Class Initialized
INFO - 2020-09-12 10:25:24 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:24 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:24 --> Email Class Initialized
INFO - 2020-09-12 10:25:24 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:24 --> Model Class Initialized
INFO - 2020-09-12 10:25:24 --> Model Class Initialized
INFO - 2020-09-12 10:25:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:25:24 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:24 --> Total execution time: 0.0241
ERROR - 2020-09-12 10:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:28 --> Config Class Initialized
INFO - 2020-09-12 10:25:28 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:28 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:28 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:28 --> URI Class Initialized
INFO - 2020-09-12 10:25:28 --> Router Class Initialized
INFO - 2020-09-12 10:25:28 --> Output Class Initialized
INFO - 2020-09-12 10:25:28 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:28 --> Input Class Initialized
INFO - 2020-09-12 10:25:28 --> Language Class Initialized
INFO - 2020-09-12 10:25:28 --> Loader Class Initialized
INFO - 2020-09-12 10:25:28 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:28 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:28 --> Email Class Initialized
INFO - 2020-09-12 10:25:28 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:28 --> Model Class Initialized
INFO - 2020-09-12 10:25:28 --> Model Class Initialized
INFO - 2020-09-12 10:25:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:25:28 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:28 --> Total execution time: 0.0205
ERROR - 2020-09-12 10:25:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:33 --> Config Class Initialized
INFO - 2020-09-12 10:25:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:33 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:33 --> URI Class Initialized
INFO - 2020-09-12 10:25:33 --> Router Class Initialized
INFO - 2020-09-12 10:25:33 --> Output Class Initialized
INFO - 2020-09-12 10:25:33 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:33 --> Input Class Initialized
INFO - 2020-09-12 10:25:33 --> Language Class Initialized
INFO - 2020-09-12 10:25:33 --> Loader Class Initialized
INFO - 2020-09-12 10:25:33 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:33 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:33 --> Email Class Initialized
INFO - 2020-09-12 10:25:33 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:33 --> Model Class Initialized
INFO - 2020-09-12 10:25:33 --> Model Class Initialized
INFO - 2020-09-12 10:25:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:25:33 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:33 --> Total execution time: 0.0189
ERROR - 2020-09-12 10:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:36 --> Config Class Initialized
INFO - 2020-09-12 10:25:36 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:36 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:36 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:36 --> URI Class Initialized
INFO - 2020-09-12 10:25:36 --> Router Class Initialized
INFO - 2020-09-12 10:25:36 --> Output Class Initialized
INFO - 2020-09-12 10:25:36 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:36 --> Input Class Initialized
INFO - 2020-09-12 10:25:36 --> Language Class Initialized
INFO - 2020-09-12 10:25:36 --> Loader Class Initialized
INFO - 2020-09-12 10:25:36 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:36 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:36 --> Email Class Initialized
INFO - 2020-09-12 10:25:36 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:36 --> Model Class Initialized
INFO - 2020-09-12 10:25:36 --> Model Class Initialized
INFO - 2020-09-12 10:25:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-09-12 10:25:36 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:36 --> Total execution time: 0.0207
ERROR - 2020-09-12 10:25:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:40 --> Config Class Initialized
INFO - 2020-09-12 10:25:40 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:40 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:40 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:40 --> URI Class Initialized
INFO - 2020-09-12 10:25:40 --> Router Class Initialized
INFO - 2020-09-12 10:25:40 --> Output Class Initialized
INFO - 2020-09-12 10:25:40 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:40 --> Input Class Initialized
INFO - 2020-09-12 10:25:40 --> Language Class Initialized
INFO - 2020-09-12 10:25:40 --> Loader Class Initialized
INFO - 2020-09-12 10:25:40 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:40 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:40 --> Email Class Initialized
INFO - 2020-09-12 10:25:40 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:40 --> Model Class Initialized
INFO - 2020-09-12 10:25:40 --> Model Class Initialized
INFO - 2020-09-12 10:25:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:25:40 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:40 --> Total execution time: 0.0229
ERROR - 2020-09-12 10:25:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:42 --> Config Class Initialized
INFO - 2020-09-12 10:25:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:42 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:42 --> URI Class Initialized
INFO - 2020-09-12 10:25:42 --> Router Class Initialized
INFO - 2020-09-12 10:25:42 --> Output Class Initialized
INFO - 2020-09-12 10:25:42 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:42 --> Input Class Initialized
INFO - 2020-09-12 10:25:42 --> Language Class Initialized
INFO - 2020-09-12 10:25:42 --> Loader Class Initialized
INFO - 2020-09-12 10:25:42 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:42 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:42 --> Email Class Initialized
INFO - 2020-09-12 10:25:42 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:42 --> Model Class Initialized
INFO - 2020-09-12 10:25:42 --> Model Class Initialized
INFO - 2020-09-12 10:25:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-09-12 10:25:42 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:42 --> Total execution time: 0.0215
ERROR - 2020-09-12 10:25:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:45 --> Config Class Initialized
INFO - 2020-09-12 10:25:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:45 --> URI Class Initialized
INFO - 2020-09-12 10:25:45 --> Router Class Initialized
INFO - 2020-09-12 10:25:45 --> Output Class Initialized
INFO - 2020-09-12 10:25:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:45 --> Input Class Initialized
INFO - 2020-09-12 10:25:45 --> Language Class Initialized
INFO - 2020-09-12 10:25:45 --> Loader Class Initialized
INFO - 2020-09-12 10:25:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:45 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:45 --> Email Class Initialized
INFO - 2020-09-12 10:25:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:45 --> Model Class Initialized
INFO - 2020-09-12 10:25:45 --> Model Class Initialized
INFO - 2020-09-12 10:25:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:25:45 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:45 --> Total execution time: 0.0203
ERROR - 2020-09-12 10:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:47 --> Config Class Initialized
INFO - 2020-09-12 10:25:47 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:47 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:47 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:47 --> URI Class Initialized
INFO - 2020-09-12 10:25:47 --> Router Class Initialized
INFO - 2020-09-12 10:25:47 --> Output Class Initialized
INFO - 2020-09-12 10:25:47 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:47 --> Input Class Initialized
INFO - 2020-09-12 10:25:47 --> Language Class Initialized
INFO - 2020-09-12 10:25:47 --> Loader Class Initialized
INFO - 2020-09-12 10:25:47 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:47 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:47 --> Email Class Initialized
INFO - 2020-09-12 10:25:47 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:47 --> Model Class Initialized
INFO - 2020-09-12 10:25:47 --> Model Class Initialized
INFO - 2020-09-12 10:25:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-09-12 10:25:47 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:47 --> Total execution time: 0.0224
ERROR - 2020-09-12 10:25:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:50 --> Config Class Initialized
INFO - 2020-09-12 10:25:50 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:50 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:50 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:50 --> URI Class Initialized
INFO - 2020-09-12 10:25:50 --> Router Class Initialized
INFO - 2020-09-12 10:25:50 --> Output Class Initialized
INFO - 2020-09-12 10:25:50 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:50 --> Input Class Initialized
INFO - 2020-09-12 10:25:50 --> Language Class Initialized
INFO - 2020-09-12 10:25:50 --> Loader Class Initialized
INFO - 2020-09-12 10:25:50 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:50 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:50 --> Email Class Initialized
INFO - 2020-09-12 10:25:50 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:50 --> Model Class Initialized
INFO - 2020-09-12 10:25:50 --> Model Class Initialized
INFO - 2020-09-12 10:25:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:25:50 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:50 --> Total execution time: 0.0275
ERROR - 2020-09-12 10:25:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:52 --> Config Class Initialized
INFO - 2020-09-12 10:25:52 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:52 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:52 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:52 --> URI Class Initialized
INFO - 2020-09-12 10:25:52 --> Router Class Initialized
INFO - 2020-09-12 10:25:52 --> Output Class Initialized
INFO - 2020-09-12 10:25:52 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:52 --> Input Class Initialized
INFO - 2020-09-12 10:25:52 --> Language Class Initialized
INFO - 2020-09-12 10:25:52 --> Loader Class Initialized
INFO - 2020-09-12 10:25:52 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:52 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:52 --> Email Class Initialized
INFO - 2020-09-12 10:25:52 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:52 --> Model Class Initialized
INFO - 2020-09-12 10:25:52 --> Model Class Initialized
INFO - 2020-09-12 10:25:52 --> Model Class Initialized
INFO - 2020-09-12 10:25:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-09-12 10:25:52 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:52 --> Total execution time: 0.0207
ERROR - 2020-09-12 10:25:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:55 --> Config Class Initialized
INFO - 2020-09-12 10:25:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:55 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:55 --> URI Class Initialized
INFO - 2020-09-12 10:25:55 --> Router Class Initialized
INFO - 2020-09-12 10:25:55 --> Output Class Initialized
INFO - 2020-09-12 10:25:55 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:55 --> Input Class Initialized
INFO - 2020-09-12 10:25:55 --> Language Class Initialized
INFO - 2020-09-12 10:25:55 --> Loader Class Initialized
INFO - 2020-09-12 10:25:55 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:55 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:55 --> Email Class Initialized
INFO - 2020-09-12 10:25:55 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:55 --> Model Class Initialized
INFO - 2020-09-12 10:25:55 --> Model Class Initialized
INFO - 2020-09-12 10:25:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:25:55 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:55 --> Total execution time: 0.0214
ERROR - 2020-09-12 10:25:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:25:58 --> Config Class Initialized
INFO - 2020-09-12 10:25:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:25:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:25:58 --> Utf8 Class Initialized
INFO - 2020-09-12 10:25:58 --> URI Class Initialized
INFO - 2020-09-12 10:25:58 --> Router Class Initialized
INFO - 2020-09-12 10:25:58 --> Output Class Initialized
INFO - 2020-09-12 10:25:58 --> Security Class Initialized
DEBUG - 2020-09-12 10:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:25:58 --> Input Class Initialized
INFO - 2020-09-12 10:25:58 --> Language Class Initialized
INFO - 2020-09-12 10:25:58 --> Loader Class Initialized
INFO - 2020-09-12 10:25:58 --> Helper loaded: url_helper
INFO - 2020-09-12 10:25:58 --> Database Driver Class Initialized
INFO - 2020-09-12 10:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:25:58 --> Email Class Initialized
INFO - 2020-09-12 10:25:58 --> Controller Class Initialized
DEBUG - 2020-09-12 10:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:25:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:25:58 --> Model Class Initialized
INFO - 2020-09-12 10:25:58 --> Model Class Initialized
INFO - 2020-09-12 10:25:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-09-12 10:25:58 --> Final output sent to browser
DEBUG - 2020-09-12 10:25:58 --> Total execution time: 0.0230
ERROR - 2020-09-12 10:26:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:26:00 --> Config Class Initialized
INFO - 2020-09-12 10:26:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:26:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:26:00 --> Utf8 Class Initialized
INFO - 2020-09-12 10:26:00 --> URI Class Initialized
INFO - 2020-09-12 10:26:00 --> Router Class Initialized
INFO - 2020-09-12 10:26:00 --> Output Class Initialized
INFO - 2020-09-12 10:26:00 --> Security Class Initialized
DEBUG - 2020-09-12 10:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:26:00 --> Input Class Initialized
INFO - 2020-09-12 10:26:00 --> Language Class Initialized
INFO - 2020-09-12 10:26:00 --> Loader Class Initialized
INFO - 2020-09-12 10:26:00 --> Helper loaded: url_helper
INFO - 2020-09-12 10:26:00 --> Database Driver Class Initialized
INFO - 2020-09-12 10:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:26:00 --> Email Class Initialized
INFO - 2020-09-12 10:26:00 --> Controller Class Initialized
DEBUG - 2020-09-12 10:26:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:26:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:26:00 --> Model Class Initialized
INFO - 2020-09-12 10:26:00 --> Model Class Initialized
INFO - 2020-09-12 10:26:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:26:00 --> Final output sent to browser
DEBUG - 2020-09-12 10:26:00 --> Total execution time: 0.0240
ERROR - 2020-09-12 10:26:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:26:03 --> Config Class Initialized
INFO - 2020-09-12 10:26:03 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:26:03 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:26:03 --> Utf8 Class Initialized
INFO - 2020-09-12 10:26:03 --> URI Class Initialized
INFO - 2020-09-12 10:26:03 --> Router Class Initialized
INFO - 2020-09-12 10:26:03 --> Output Class Initialized
INFO - 2020-09-12 10:26:03 --> Security Class Initialized
DEBUG - 2020-09-12 10:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:26:03 --> Input Class Initialized
INFO - 2020-09-12 10:26:03 --> Language Class Initialized
INFO - 2020-09-12 10:26:03 --> Loader Class Initialized
INFO - 2020-09-12 10:26:03 --> Helper loaded: url_helper
INFO - 2020-09-12 10:26:03 --> Database Driver Class Initialized
INFO - 2020-09-12 10:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:26:03 --> Email Class Initialized
INFO - 2020-09-12 10:26:03 --> Controller Class Initialized
DEBUG - 2020-09-12 10:26:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:26:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:26:03 --> Model Class Initialized
INFO - 2020-09-12 10:26:03 --> Model Class Initialized
INFO - 2020-09-12 10:26:03 --> Model Class Initialized
INFO - 2020-09-12 10:26:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 10:26:03 --> Final output sent to browser
DEBUG - 2020-09-12 10:26:03 --> Total execution time: 0.0236
ERROR - 2020-09-12 10:26:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:26:05 --> Config Class Initialized
INFO - 2020-09-12 10:26:05 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:26:05 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:26:05 --> Utf8 Class Initialized
INFO - 2020-09-12 10:26:05 --> URI Class Initialized
INFO - 2020-09-12 10:26:05 --> Router Class Initialized
INFO - 2020-09-12 10:26:05 --> Output Class Initialized
INFO - 2020-09-12 10:26:05 --> Security Class Initialized
DEBUG - 2020-09-12 10:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:26:05 --> Input Class Initialized
INFO - 2020-09-12 10:26:05 --> Language Class Initialized
INFO - 2020-09-12 10:26:05 --> Loader Class Initialized
INFO - 2020-09-12 10:26:05 --> Helper loaded: url_helper
INFO - 2020-09-12 10:26:05 --> Database Driver Class Initialized
INFO - 2020-09-12 10:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:26:05 --> Email Class Initialized
INFO - 2020-09-12 10:26:05 --> Controller Class Initialized
DEBUG - 2020-09-12 10:26:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:26:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:26:05 --> Model Class Initialized
INFO - 2020-09-12 10:26:05 --> Model Class Initialized
INFO - 2020-09-12 10:26:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:26:05 --> Final output sent to browser
DEBUG - 2020-09-12 10:26:05 --> Total execution time: 0.0209
ERROR - 2020-09-12 10:26:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:26:09 --> Config Class Initialized
INFO - 2020-09-12 10:26:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:26:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:26:09 --> Utf8 Class Initialized
INFO - 2020-09-12 10:26:09 --> URI Class Initialized
INFO - 2020-09-12 10:26:09 --> Router Class Initialized
INFO - 2020-09-12 10:26:09 --> Output Class Initialized
INFO - 2020-09-12 10:26:09 --> Security Class Initialized
DEBUG - 2020-09-12 10:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:26:09 --> Input Class Initialized
INFO - 2020-09-12 10:26:09 --> Language Class Initialized
INFO - 2020-09-12 10:26:09 --> Loader Class Initialized
INFO - 2020-09-12 10:26:09 --> Helper loaded: url_helper
INFO - 2020-09-12 10:26:09 --> Database Driver Class Initialized
INFO - 2020-09-12 10:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:26:09 --> Email Class Initialized
INFO - 2020-09-12 10:26:09 --> Controller Class Initialized
DEBUG - 2020-09-12 10:26:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:26:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:26:09 --> Model Class Initialized
INFO - 2020-09-12 10:26:09 --> Model Class Initialized
INFO - 2020-09-12 10:26:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:26:09 --> Final output sent to browser
DEBUG - 2020-09-12 10:26:09 --> Total execution time: 0.0228
ERROR - 2020-09-12 10:26:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:26:11 --> Config Class Initialized
INFO - 2020-09-12 10:26:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:26:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:26:11 --> Utf8 Class Initialized
INFO - 2020-09-12 10:26:11 --> URI Class Initialized
INFO - 2020-09-12 10:26:11 --> Router Class Initialized
INFO - 2020-09-12 10:26:11 --> Output Class Initialized
INFO - 2020-09-12 10:26:11 --> Security Class Initialized
DEBUG - 2020-09-12 10:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:26:11 --> Input Class Initialized
INFO - 2020-09-12 10:26:11 --> Language Class Initialized
INFO - 2020-09-12 10:26:11 --> Loader Class Initialized
INFO - 2020-09-12 10:26:11 --> Helper loaded: url_helper
INFO - 2020-09-12 10:26:11 --> Database Driver Class Initialized
INFO - 2020-09-12 10:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:26:11 --> Email Class Initialized
INFO - 2020-09-12 10:26:11 --> Controller Class Initialized
DEBUG - 2020-09-12 10:26:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:26:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:26:11 --> Model Class Initialized
INFO - 2020-09-12 10:26:11 --> Model Class Initialized
INFO - 2020-09-12 10:26:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:26:11 --> Final output sent to browser
DEBUG - 2020-09-12 10:26:11 --> Total execution time: 0.0246
ERROR - 2020-09-12 10:29:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:29:55 --> Config Class Initialized
INFO - 2020-09-12 10:29:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:29:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:29:55 --> Utf8 Class Initialized
INFO - 2020-09-12 10:29:55 --> URI Class Initialized
INFO - 2020-09-12 10:29:55 --> Router Class Initialized
INFO - 2020-09-12 10:29:55 --> Output Class Initialized
INFO - 2020-09-12 10:29:55 --> Security Class Initialized
DEBUG - 2020-09-12 10:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:29:55 --> Input Class Initialized
INFO - 2020-09-12 10:29:55 --> Language Class Initialized
INFO - 2020-09-12 10:29:55 --> Loader Class Initialized
INFO - 2020-09-12 10:29:55 --> Helper loaded: url_helper
INFO - 2020-09-12 10:29:55 --> Database Driver Class Initialized
INFO - 2020-09-12 10:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:29:55 --> Email Class Initialized
INFO - 2020-09-12 10:29:55 --> Controller Class Initialized
DEBUG - 2020-09-12 10:29:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:29:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:29:55 --> Model Class Initialized
INFO - 2020-09-12 10:29:55 --> Model Class Initialized
INFO - 2020-09-12 10:29:55 --> Model Class Initialized
INFO - 2020-09-12 10:29:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:29:55 --> Final output sent to browser
DEBUG - 2020-09-12 10:29:55 --> Total execution time: 0.0234
ERROR - 2020-09-12 10:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:32:25 --> Config Class Initialized
INFO - 2020-09-12 10:32:25 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:32:25 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:32:25 --> Utf8 Class Initialized
INFO - 2020-09-12 10:32:25 --> URI Class Initialized
INFO - 2020-09-12 10:32:25 --> Router Class Initialized
INFO - 2020-09-12 10:32:25 --> Output Class Initialized
INFO - 2020-09-12 10:32:25 --> Security Class Initialized
DEBUG - 2020-09-12 10:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:32:25 --> Input Class Initialized
INFO - 2020-09-12 10:32:25 --> Language Class Initialized
INFO - 2020-09-12 10:32:25 --> Loader Class Initialized
INFO - 2020-09-12 10:32:25 --> Helper loaded: url_helper
INFO - 2020-09-12 10:32:25 --> Database Driver Class Initialized
INFO - 2020-09-12 10:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:32:25 --> Email Class Initialized
INFO - 2020-09-12 10:32:25 --> Controller Class Initialized
DEBUG - 2020-09-12 10:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:32:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:32:25 --> Model Class Initialized
INFO - 2020-09-12 10:32:25 --> Model Class Initialized
INFO - 2020-09-12 10:32:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:32:25 --> Final output sent to browser
DEBUG - 2020-09-12 10:32:25 --> Total execution time: 0.0247
ERROR - 2020-09-12 10:33:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:33:51 --> Config Class Initialized
INFO - 2020-09-12 10:33:51 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:33:51 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:33:51 --> Utf8 Class Initialized
INFO - 2020-09-12 10:33:51 --> URI Class Initialized
INFO - 2020-09-12 10:33:51 --> Router Class Initialized
INFO - 2020-09-12 10:33:51 --> Output Class Initialized
INFO - 2020-09-12 10:33:51 --> Security Class Initialized
DEBUG - 2020-09-12 10:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:33:51 --> Input Class Initialized
INFO - 2020-09-12 10:33:51 --> Language Class Initialized
INFO - 2020-09-12 10:33:51 --> Loader Class Initialized
INFO - 2020-09-12 10:33:51 --> Helper loaded: url_helper
INFO - 2020-09-12 10:33:51 --> Database Driver Class Initialized
INFO - 2020-09-12 10:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:33:51 --> Email Class Initialized
INFO - 2020-09-12 10:33:51 --> Controller Class Initialized
DEBUG - 2020-09-12 10:33:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:33:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:33:51 --> Model Class Initialized
INFO - 2020-09-12 10:33:51 --> Model Class Initialized
INFO - 2020-09-12 10:33:51 --> Model Class Initialized
INFO - 2020-09-12 10:33:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-09-12 10:33:51 --> Final output sent to browser
DEBUG - 2020-09-12 10:33:51 --> Total execution time: 0.0309
ERROR - 2020-09-12 10:33:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:33:54 --> Config Class Initialized
INFO - 2020-09-12 10:33:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:33:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:33:54 --> Utf8 Class Initialized
INFO - 2020-09-12 10:33:54 --> URI Class Initialized
INFO - 2020-09-12 10:33:54 --> Router Class Initialized
INFO - 2020-09-12 10:33:54 --> Output Class Initialized
INFO - 2020-09-12 10:33:54 --> Security Class Initialized
DEBUG - 2020-09-12 10:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:33:54 --> Input Class Initialized
INFO - 2020-09-12 10:33:54 --> Language Class Initialized
INFO - 2020-09-12 10:33:54 --> Loader Class Initialized
INFO - 2020-09-12 10:33:54 --> Helper loaded: url_helper
INFO - 2020-09-12 10:33:54 --> Database Driver Class Initialized
INFO - 2020-09-12 10:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:33:54 --> Email Class Initialized
INFO - 2020-09-12 10:33:54 --> Controller Class Initialized
DEBUG - 2020-09-12 10:33:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:33:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:33:54 --> Model Class Initialized
INFO - 2020-09-12 10:33:54 --> Model Class Initialized
INFO - 2020-09-12 10:33:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:33:54 --> Final output sent to browser
DEBUG - 2020-09-12 10:33:54 --> Total execution time: 0.0255
ERROR - 2020-09-12 10:34:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:34:02 --> Config Class Initialized
INFO - 2020-09-12 10:34:02 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:34:02 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:34:02 --> Utf8 Class Initialized
INFO - 2020-09-12 10:34:02 --> URI Class Initialized
INFO - 2020-09-12 10:34:02 --> Router Class Initialized
INFO - 2020-09-12 10:34:02 --> Output Class Initialized
INFO - 2020-09-12 10:34:02 --> Security Class Initialized
DEBUG - 2020-09-12 10:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:34:02 --> Input Class Initialized
INFO - 2020-09-12 10:34:02 --> Language Class Initialized
INFO - 2020-09-12 10:34:02 --> Loader Class Initialized
INFO - 2020-09-12 10:34:02 --> Helper loaded: url_helper
INFO - 2020-09-12 10:34:02 --> Database Driver Class Initialized
INFO - 2020-09-12 10:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:34:02 --> Email Class Initialized
INFO - 2020-09-12 10:34:02 --> Controller Class Initialized
DEBUG - 2020-09-12 10:34:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:34:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:34:02 --> Model Class Initialized
INFO - 2020-09-12 10:34:02 --> Model Class Initialized
INFO - 2020-09-12 10:34:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:34:02 --> Final output sent to browser
DEBUG - 2020-09-12 10:34:02 --> Total execution time: 0.0219
ERROR - 2020-09-12 10:34:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:34:10 --> Config Class Initialized
INFO - 2020-09-12 10:34:10 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:34:10 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:34:10 --> Utf8 Class Initialized
INFO - 2020-09-12 10:34:10 --> URI Class Initialized
INFO - 2020-09-12 10:34:10 --> Router Class Initialized
INFO - 2020-09-12 10:34:10 --> Output Class Initialized
INFO - 2020-09-12 10:34:10 --> Security Class Initialized
DEBUG - 2020-09-12 10:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:34:10 --> Input Class Initialized
INFO - 2020-09-12 10:34:10 --> Language Class Initialized
INFO - 2020-09-12 10:34:10 --> Loader Class Initialized
INFO - 2020-09-12 10:34:10 --> Helper loaded: url_helper
INFO - 2020-09-12 10:34:10 --> Database Driver Class Initialized
INFO - 2020-09-12 10:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:34:10 --> Email Class Initialized
INFO - 2020-09-12 10:34:10 --> Controller Class Initialized
DEBUG - 2020-09-12 10:34:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:34:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:34:10 --> Model Class Initialized
INFO - 2020-09-12 10:34:10 --> Model Class Initialized
INFO - 2020-09-12 10:34:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:34:10 --> Final output sent to browser
DEBUG - 2020-09-12 10:34:10 --> Total execution time: 0.0218
ERROR - 2020-09-12 10:35:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:35:14 --> Config Class Initialized
INFO - 2020-09-12 10:35:14 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:35:14 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:35:14 --> Utf8 Class Initialized
INFO - 2020-09-12 10:35:14 --> URI Class Initialized
INFO - 2020-09-12 10:35:14 --> Router Class Initialized
INFO - 2020-09-12 10:35:14 --> Output Class Initialized
INFO - 2020-09-12 10:35:14 --> Security Class Initialized
DEBUG - 2020-09-12 10:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:35:14 --> Input Class Initialized
INFO - 2020-09-12 10:35:14 --> Language Class Initialized
INFO - 2020-09-12 10:35:14 --> Loader Class Initialized
INFO - 2020-09-12 10:35:14 --> Helper loaded: url_helper
INFO - 2020-09-12 10:35:14 --> Database Driver Class Initialized
INFO - 2020-09-12 10:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:35:14 --> Email Class Initialized
INFO - 2020-09-12 10:35:14 --> Controller Class Initialized
DEBUG - 2020-09-12 10:35:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:35:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:35:14 --> Model Class Initialized
INFO - 2020-09-12 10:35:14 --> Model Class Initialized
INFO - 2020-09-12 10:35:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:35:14 --> Final output sent to browser
DEBUG - 2020-09-12 10:35:14 --> Total execution time: 0.0206
ERROR - 2020-09-12 10:36:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:36:06 --> Config Class Initialized
INFO - 2020-09-12 10:36:06 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:36:06 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:36:06 --> Utf8 Class Initialized
INFO - 2020-09-12 10:36:06 --> URI Class Initialized
INFO - 2020-09-12 10:36:06 --> Router Class Initialized
INFO - 2020-09-12 10:36:06 --> Output Class Initialized
INFO - 2020-09-12 10:36:06 --> Security Class Initialized
DEBUG - 2020-09-12 10:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:36:06 --> Input Class Initialized
INFO - 2020-09-12 10:36:06 --> Language Class Initialized
INFO - 2020-09-12 10:36:06 --> Loader Class Initialized
INFO - 2020-09-12 10:36:06 --> Helper loaded: url_helper
INFO - 2020-09-12 10:36:06 --> Database Driver Class Initialized
INFO - 2020-09-12 10:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:36:06 --> Email Class Initialized
INFO - 2020-09-12 10:36:06 --> Controller Class Initialized
DEBUG - 2020-09-12 10:36:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:36:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:36:06 --> Model Class Initialized
INFO - 2020-09-12 10:36:06 --> Model Class Initialized
INFO - 2020-09-12 10:36:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:36:06 --> Final output sent to browser
DEBUG - 2020-09-12 10:36:06 --> Total execution time: 0.0240
ERROR - 2020-09-12 10:38:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:38:42 --> Config Class Initialized
INFO - 2020-09-12 10:38:42 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:38:42 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:38:42 --> Utf8 Class Initialized
INFO - 2020-09-12 10:38:42 --> URI Class Initialized
INFO - 2020-09-12 10:38:42 --> Router Class Initialized
INFO - 2020-09-12 10:38:42 --> Output Class Initialized
INFO - 2020-09-12 10:38:42 --> Security Class Initialized
DEBUG - 2020-09-12 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:38:42 --> Input Class Initialized
INFO - 2020-09-12 10:38:42 --> Language Class Initialized
INFO - 2020-09-12 10:38:42 --> Loader Class Initialized
INFO - 2020-09-12 10:38:42 --> Helper loaded: url_helper
INFO - 2020-09-12 10:38:42 --> Database Driver Class Initialized
INFO - 2020-09-12 10:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:38:42 --> Email Class Initialized
INFO - 2020-09-12 10:38:42 --> Controller Class Initialized
DEBUG - 2020-09-12 10:38:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:38:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:38:42 --> Model Class Initialized
INFO - 2020-09-12 10:38:42 --> Model Class Initialized
INFO - 2020-09-12 10:38:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:38:42 --> Final output sent to browser
DEBUG - 2020-09-12 10:38:42 --> Total execution time: 0.0231
ERROR - 2020-09-12 10:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:40:45 --> Config Class Initialized
INFO - 2020-09-12 10:40:45 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:40:45 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:40:45 --> Utf8 Class Initialized
INFO - 2020-09-12 10:40:45 --> URI Class Initialized
INFO - 2020-09-12 10:40:45 --> Router Class Initialized
INFO - 2020-09-12 10:40:45 --> Output Class Initialized
INFO - 2020-09-12 10:40:45 --> Security Class Initialized
DEBUG - 2020-09-12 10:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:40:45 --> Input Class Initialized
INFO - 2020-09-12 10:40:45 --> Language Class Initialized
INFO - 2020-09-12 10:40:45 --> Loader Class Initialized
INFO - 2020-09-12 10:40:45 --> Helper loaded: url_helper
INFO - 2020-09-12 10:40:45 --> Database Driver Class Initialized
INFO - 2020-09-12 10:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:40:45 --> Email Class Initialized
INFO - 2020-09-12 10:40:45 --> Controller Class Initialized
DEBUG - 2020-09-12 10:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:40:45 --> Model Class Initialized
INFO - 2020-09-12 10:40:45 --> Model Class Initialized
INFO - 2020-09-12 10:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:40:45 --> Final output sent to browser
DEBUG - 2020-09-12 10:40:45 --> Total execution time: 0.0248
ERROR - 2020-09-12 10:40:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:40:54 --> Config Class Initialized
INFO - 2020-09-12 10:40:54 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:40:54 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:40:54 --> Utf8 Class Initialized
INFO - 2020-09-12 10:40:54 --> URI Class Initialized
INFO - 2020-09-12 10:40:54 --> Router Class Initialized
INFO - 2020-09-12 10:40:54 --> Output Class Initialized
INFO - 2020-09-12 10:40:54 --> Security Class Initialized
DEBUG - 2020-09-12 10:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:40:54 --> Input Class Initialized
INFO - 2020-09-12 10:40:54 --> Language Class Initialized
INFO - 2020-09-12 10:40:54 --> Loader Class Initialized
INFO - 2020-09-12 10:40:54 --> Helper loaded: url_helper
INFO - 2020-09-12 10:40:54 --> Database Driver Class Initialized
INFO - 2020-09-12 10:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:40:54 --> Email Class Initialized
INFO - 2020-09-12 10:40:54 --> Controller Class Initialized
DEBUG - 2020-09-12 10:40:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:40:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:40:54 --> Model Class Initialized
INFO - 2020-09-12 10:40:54 --> Model Class Initialized
INFO - 2020-09-12 10:40:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:40:54 --> Final output sent to browser
DEBUG - 2020-09-12 10:40:54 --> Total execution time: 0.0223
ERROR - 2020-09-12 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:41:33 --> Config Class Initialized
INFO - 2020-09-12 10:41:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:41:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:41:33 --> Utf8 Class Initialized
INFO - 2020-09-12 10:41:33 --> URI Class Initialized
INFO - 2020-09-12 10:41:33 --> Router Class Initialized
INFO - 2020-09-12 10:41:33 --> Output Class Initialized
INFO - 2020-09-12 10:41:33 --> Security Class Initialized
DEBUG - 2020-09-12 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:41:33 --> Input Class Initialized
INFO - 2020-09-12 10:41:33 --> Language Class Initialized
INFO - 2020-09-12 10:41:33 --> Loader Class Initialized
INFO - 2020-09-12 10:41:33 --> Helper loaded: url_helper
INFO - 2020-09-12 10:41:33 --> Database Driver Class Initialized
INFO - 2020-09-12 10:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:41:33 --> Email Class Initialized
INFO - 2020-09-12 10:41:33 --> Controller Class Initialized
DEBUG - 2020-09-12 10:41:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:41:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:41:33 --> Model Class Initialized
INFO - 2020-09-12 10:41:33 --> Model Class Initialized
INFO - 2020-09-12 10:41:33 --> Model Class Initialized
INFO - 2020-09-12 10:41:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:41:33 --> Final output sent to browser
DEBUG - 2020-09-12 10:41:33 --> Total execution time: 0.0250
ERROR - 2020-09-12 10:43:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:43:19 --> Config Class Initialized
INFO - 2020-09-12 10:43:19 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:43:19 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:43:19 --> Utf8 Class Initialized
INFO - 2020-09-12 10:43:19 --> URI Class Initialized
INFO - 2020-09-12 10:43:19 --> Router Class Initialized
INFO - 2020-09-12 10:43:19 --> Output Class Initialized
INFO - 2020-09-12 10:43:19 --> Security Class Initialized
DEBUG - 2020-09-12 10:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:43:19 --> Input Class Initialized
INFO - 2020-09-12 10:43:19 --> Language Class Initialized
INFO - 2020-09-12 10:43:19 --> Loader Class Initialized
INFO - 2020-09-12 10:43:19 --> Helper loaded: url_helper
INFO - 2020-09-12 10:43:19 --> Database Driver Class Initialized
INFO - 2020-09-12 10:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:43:19 --> Email Class Initialized
INFO - 2020-09-12 10:43:19 --> Controller Class Initialized
DEBUG - 2020-09-12 10:43:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:43:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:43:19 --> Model Class Initialized
INFO - 2020-09-12 10:43:19 --> Model Class Initialized
INFO - 2020-09-12 10:43:19 --> Model Class Initialized
INFO - 2020-09-12 10:43:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:43:19 --> Final output sent to browser
DEBUG - 2020-09-12 10:43:19 --> Total execution time: 0.0228
ERROR - 2020-09-12 10:44:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:44:29 --> Config Class Initialized
INFO - 2020-09-12 10:44:29 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:44:29 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:44:29 --> Utf8 Class Initialized
INFO - 2020-09-12 10:44:29 --> URI Class Initialized
INFO - 2020-09-12 10:44:29 --> Router Class Initialized
INFO - 2020-09-12 10:44:29 --> Output Class Initialized
INFO - 2020-09-12 10:44:29 --> Security Class Initialized
DEBUG - 2020-09-12 10:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:44:29 --> Input Class Initialized
INFO - 2020-09-12 10:44:29 --> Language Class Initialized
INFO - 2020-09-12 10:44:29 --> Loader Class Initialized
INFO - 2020-09-12 10:44:29 --> Helper loaded: url_helper
INFO - 2020-09-12 10:44:29 --> Database Driver Class Initialized
INFO - 2020-09-12 10:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:44:29 --> Email Class Initialized
INFO - 2020-09-12 10:44:29 --> Controller Class Initialized
DEBUG - 2020-09-12 10:44:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:44:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:44:29 --> Model Class Initialized
INFO - 2020-09-12 10:44:29 --> Model Class Initialized
INFO - 2020-09-12 10:44:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:44:29 --> Final output sent to browser
DEBUG - 2020-09-12 10:44:29 --> Total execution time: 0.0230
ERROR - 2020-09-12 10:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:44:33 --> Config Class Initialized
INFO - 2020-09-12 10:44:33 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:44:33 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:44:33 --> Utf8 Class Initialized
INFO - 2020-09-12 10:44:33 --> URI Class Initialized
INFO - 2020-09-12 10:44:33 --> Router Class Initialized
INFO - 2020-09-12 10:44:33 --> Output Class Initialized
INFO - 2020-09-12 10:44:33 --> Security Class Initialized
DEBUG - 2020-09-12 10:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:44:33 --> Input Class Initialized
INFO - 2020-09-12 10:44:33 --> Language Class Initialized
INFO - 2020-09-12 10:44:33 --> Loader Class Initialized
INFO - 2020-09-12 10:44:33 --> Helper loaded: url_helper
INFO - 2020-09-12 10:44:33 --> Database Driver Class Initialized
INFO - 2020-09-12 10:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:44:33 --> Email Class Initialized
INFO - 2020-09-12 10:44:33 --> Controller Class Initialized
DEBUG - 2020-09-12 10:44:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:44:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:44:33 --> Model Class Initialized
INFO - 2020-09-12 10:44:33 --> Model Class Initialized
INFO - 2020-09-12 10:44:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:44:33 --> Final output sent to browser
DEBUG - 2020-09-12 10:44:33 --> Total execution time: 0.0258
ERROR - 2020-09-12 10:44:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:44:35 --> Config Class Initialized
INFO - 2020-09-12 10:44:35 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:44:35 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:44:35 --> Utf8 Class Initialized
INFO - 2020-09-12 10:44:35 --> URI Class Initialized
INFO - 2020-09-12 10:44:35 --> Router Class Initialized
INFO - 2020-09-12 10:44:35 --> Output Class Initialized
INFO - 2020-09-12 10:44:35 --> Security Class Initialized
DEBUG - 2020-09-12 10:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:44:35 --> Input Class Initialized
INFO - 2020-09-12 10:44:35 --> Language Class Initialized
INFO - 2020-09-12 10:44:35 --> Loader Class Initialized
INFO - 2020-09-12 10:44:35 --> Helper loaded: url_helper
INFO - 2020-09-12 10:44:35 --> Database Driver Class Initialized
INFO - 2020-09-12 10:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:44:35 --> Email Class Initialized
INFO - 2020-09-12 10:44:35 --> Controller Class Initialized
DEBUG - 2020-09-12 10:44:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:44:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:44:35 --> Model Class Initialized
INFO - 2020-09-12 10:44:35 --> Model Class Initialized
INFO - 2020-09-12 10:44:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:44:35 --> Final output sent to browser
DEBUG - 2020-09-12 10:44:35 --> Total execution time: 0.0215
ERROR - 2020-09-12 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:48:41 --> Config Class Initialized
INFO - 2020-09-12 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:48:41 --> Utf8 Class Initialized
INFO - 2020-09-12 10:48:41 --> URI Class Initialized
INFO - 2020-09-12 10:48:41 --> Router Class Initialized
INFO - 2020-09-12 10:48:41 --> Output Class Initialized
INFO - 2020-09-12 10:48:41 --> Security Class Initialized
DEBUG - 2020-09-12 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:48:41 --> Input Class Initialized
INFO - 2020-09-12 10:48:41 --> Language Class Initialized
INFO - 2020-09-12 10:48:41 --> Loader Class Initialized
INFO - 2020-09-12 10:48:41 --> Helper loaded: url_helper
INFO - 2020-09-12 10:48:41 --> Database Driver Class Initialized
INFO - 2020-09-12 10:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:48:41 --> Email Class Initialized
INFO - 2020-09-12 10:48:41 --> Controller Class Initialized
DEBUG - 2020-09-12 10:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:48:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:48:41 --> Model Class Initialized
INFO - 2020-09-12 10:48:41 --> Model Class Initialized
INFO - 2020-09-12 10:48:41 --> Model Class Initialized
INFO - 2020-09-12 10:48:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-12 10:48:41 --> Final output sent to browser
DEBUG - 2020-09-12 10:48:41 --> Total execution time: 0.0226
ERROR - 2020-09-12 10:48:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:48:49 --> Config Class Initialized
INFO - 2020-09-12 10:48:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:48:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:48:49 --> Utf8 Class Initialized
INFO - 2020-09-12 10:48:49 --> URI Class Initialized
INFO - 2020-09-12 10:48:49 --> Router Class Initialized
INFO - 2020-09-12 10:48:49 --> Output Class Initialized
INFO - 2020-09-12 10:48:49 --> Security Class Initialized
DEBUG - 2020-09-12 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:48:49 --> Input Class Initialized
INFO - 2020-09-12 10:48:49 --> Language Class Initialized
INFO - 2020-09-12 10:48:49 --> Loader Class Initialized
INFO - 2020-09-12 10:48:49 --> Helper loaded: url_helper
INFO - 2020-09-12 10:48:49 --> Database Driver Class Initialized
INFO - 2020-09-12 10:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:48:49 --> Email Class Initialized
INFO - 2020-09-12 10:48:49 --> Controller Class Initialized
DEBUG - 2020-09-12 10:48:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:48:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:48:49 --> Model Class Initialized
INFO - 2020-09-12 10:48:49 --> Model Class Initialized
INFO - 2020-09-12 10:48:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-12 10:48:49 --> Final output sent to browser
DEBUG - 2020-09-12 10:48:49 --> Total execution time: 0.0220
ERROR - 2020-09-12 10:48:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:48:55 --> Config Class Initialized
INFO - 2020-09-12 10:48:55 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:48:55 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:48:55 --> Utf8 Class Initialized
INFO - 2020-09-12 10:48:55 --> URI Class Initialized
INFO - 2020-09-12 10:48:55 --> Router Class Initialized
INFO - 2020-09-12 10:48:55 --> Output Class Initialized
INFO - 2020-09-12 10:48:55 --> Security Class Initialized
DEBUG - 2020-09-12 10:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:48:55 --> Input Class Initialized
INFO - 2020-09-12 10:48:55 --> Language Class Initialized
INFO - 2020-09-12 10:48:55 --> Loader Class Initialized
INFO - 2020-09-12 10:48:55 --> Helper loaded: url_helper
INFO - 2020-09-12 10:48:55 --> Database Driver Class Initialized
INFO - 2020-09-12 10:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:48:55 --> Email Class Initialized
INFO - 2020-09-12 10:48:55 --> Controller Class Initialized
DEBUG - 2020-09-12 10:48:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:48:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:48:55 --> Model Class Initialized
INFO - 2020-09-12 10:48:55 --> Model Class Initialized
INFO - 2020-09-12 10:48:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-09-12 10:48:55 --> Final output sent to browser
DEBUG - 2020-09-12 10:48:55 --> Total execution time: 0.0213
ERROR - 2020-09-12 10:48:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:48:58 --> Config Class Initialized
INFO - 2020-09-12 10:48:58 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:48:58 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:48:58 --> Utf8 Class Initialized
INFO - 2020-09-12 10:48:58 --> URI Class Initialized
INFO - 2020-09-12 10:48:58 --> Router Class Initialized
INFO - 2020-09-12 10:48:58 --> Output Class Initialized
INFO - 2020-09-12 10:48:58 --> Security Class Initialized
DEBUG - 2020-09-12 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:48:58 --> Input Class Initialized
INFO - 2020-09-12 10:48:58 --> Language Class Initialized
INFO - 2020-09-12 10:48:58 --> Loader Class Initialized
INFO - 2020-09-12 10:48:58 --> Helper loaded: url_helper
INFO - 2020-09-12 10:48:58 --> Database Driver Class Initialized
INFO - 2020-09-12 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:48:58 --> Email Class Initialized
INFO - 2020-09-12 10:48:58 --> Controller Class Initialized
DEBUG - 2020-09-12 10:48:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:48:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:48:58 --> Model Class Initialized
INFO - 2020-09-12 10:48:58 --> Model Class Initialized
INFO - 2020-09-12 10:48:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-12 10:48:58 --> Final output sent to browser
DEBUG - 2020-09-12 10:48:58 --> Total execution time: 0.0233
ERROR - 2020-09-12 10:53:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:09 --> Config Class Initialized
INFO - 2020-09-12 10:53:09 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:09 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:09 --> URI Class Initialized
DEBUG - 2020-09-12 10:53:09 --> No URI present. Default controller set.
INFO - 2020-09-12 10:53:09 --> Router Class Initialized
INFO - 2020-09-12 10:53:09 --> Output Class Initialized
INFO - 2020-09-12 10:53:09 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:09 --> Input Class Initialized
INFO - 2020-09-12 10:53:09 --> Language Class Initialized
INFO - 2020-09-12 10:53:09 --> Loader Class Initialized
INFO - 2020-09-12 10:53:09 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:09 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:09 --> Email Class Initialized
INFO - 2020-09-12 10:53:09 --> Controller Class Initialized
INFO - 2020-09-12 10:53:09 --> Model Class Initialized
INFO - 2020-09-12 10:53:09 --> Model Class Initialized
DEBUG - 2020-09-12 10:53:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:53:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 10:53:09 --> Final output sent to browser
DEBUG - 2020-09-12 10:53:09 --> Total execution time: 0.0183
ERROR - 2020-09-12 10:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:11 --> Config Class Initialized
INFO - 2020-09-12 10:53:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:11 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:11 --> URI Class Initialized
INFO - 2020-09-12 10:53:11 --> Router Class Initialized
INFO - 2020-09-12 10:53:11 --> Output Class Initialized
INFO - 2020-09-12 10:53:11 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:11 --> Input Class Initialized
INFO - 2020-09-12 10:53:11 --> Language Class Initialized
INFO - 2020-09-12 10:53:11 --> Loader Class Initialized
INFO - 2020-09-12 10:53:11 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:11 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:11 --> Email Class Initialized
INFO - 2020-09-12 10:53:11 --> Controller Class Initialized
INFO - 2020-09-12 10:53:11 --> Model Class Initialized
INFO - 2020-09-12 10:53:11 --> Model Class Initialized
DEBUG - 2020-09-12 10:53:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:53:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:53:11 --> Model Class Initialized
INFO - 2020-09-12 10:53:11 --> Final output sent to browser
DEBUG - 2020-09-12 10:53:11 --> Total execution time: 0.0242
ERROR - 2020-09-12 10:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:11 --> Config Class Initialized
INFO - 2020-09-12 10:53:11 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:11 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:11 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:11 --> URI Class Initialized
INFO - 2020-09-12 10:53:11 --> Router Class Initialized
INFO - 2020-09-12 10:53:11 --> Output Class Initialized
INFO - 2020-09-12 10:53:11 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:11 --> Input Class Initialized
INFO - 2020-09-12 10:53:11 --> Language Class Initialized
INFO - 2020-09-12 10:53:11 --> Loader Class Initialized
INFO - 2020-09-12 10:53:11 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:11 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:11 --> Email Class Initialized
INFO - 2020-09-12 10:53:11 --> Controller Class Initialized
INFO - 2020-09-12 10:53:11 --> Model Class Initialized
INFO - 2020-09-12 10:53:11 --> Model Class Initialized
DEBUG - 2020-09-12 10:53:11 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-12 10:53:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:12 --> Config Class Initialized
INFO - 2020-09-12 10:53:12 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:12 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:12 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:12 --> URI Class Initialized
INFO - 2020-09-12 10:53:12 --> Router Class Initialized
INFO - 2020-09-12 10:53:12 --> Output Class Initialized
INFO - 2020-09-12 10:53:12 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:12 --> Input Class Initialized
INFO - 2020-09-12 10:53:12 --> Language Class Initialized
INFO - 2020-09-12 10:53:12 --> Loader Class Initialized
INFO - 2020-09-12 10:53:12 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:12 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:12 --> Email Class Initialized
INFO - 2020-09-12 10:53:12 --> Controller Class Initialized
DEBUG - 2020-09-12 10:53:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:53:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:53:12 --> Model Class Initialized
INFO - 2020-09-12 10:53:12 --> Model Class Initialized
INFO - 2020-09-12 10:53:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-12 10:53:12 --> Final output sent to browser
DEBUG - 2020-09-12 10:53:12 --> Total execution time: 0.0239
ERROR - 2020-09-12 10:53:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:18 --> Config Class Initialized
INFO - 2020-09-12 10:53:18 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:18 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:18 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:18 --> URI Class Initialized
INFO - 2020-09-12 10:53:18 --> Router Class Initialized
INFO - 2020-09-12 10:53:18 --> Output Class Initialized
INFO - 2020-09-12 10:53:18 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:18 --> Input Class Initialized
INFO - 2020-09-12 10:53:18 --> Language Class Initialized
INFO - 2020-09-12 10:53:18 --> Loader Class Initialized
INFO - 2020-09-12 10:53:18 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:18 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:18 --> Email Class Initialized
INFO - 2020-09-12 10:53:18 --> Controller Class Initialized
DEBUG - 2020-09-12 10:53:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:53:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:53:18 --> Model Class Initialized
INFO - 2020-09-12 10:53:18 --> Model Class Initialized
INFO - 2020-09-12 10:53:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-12 10:53:18 --> Final output sent to browser
DEBUG - 2020-09-12 10:53:18 --> Total execution time: 0.0217
ERROR - 2020-09-12 10:53:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:23 --> Config Class Initialized
INFO - 2020-09-12 10:53:23 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:23 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:23 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:23 --> URI Class Initialized
INFO - 2020-09-12 10:53:23 --> Router Class Initialized
INFO - 2020-09-12 10:53:23 --> Output Class Initialized
INFO - 2020-09-12 10:53:23 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:23 --> Input Class Initialized
INFO - 2020-09-12 10:53:23 --> Language Class Initialized
INFO - 2020-09-12 10:53:23 --> Loader Class Initialized
INFO - 2020-09-12 10:53:23 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:23 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:23 --> Email Class Initialized
INFO - 2020-09-12 10:53:23 --> Controller Class Initialized
INFO - 2020-09-12 10:53:23 --> Model Class Initialized
INFO - 2020-09-12 10:53:23 --> Model Class Initialized
INFO - 2020-09-12 10:53:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-12 10:53:23 --> Final output sent to browser
DEBUG - 2020-09-12 10:53:23 --> Total execution time: 0.2171
ERROR - 2020-09-12 10:53:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:53:24 --> Config Class Initialized
INFO - 2020-09-12 10:53:24 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:53:24 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:53:24 --> Utf8 Class Initialized
INFO - 2020-09-12 10:53:24 --> URI Class Initialized
INFO - 2020-09-12 10:53:24 --> Router Class Initialized
INFO - 2020-09-12 10:53:24 --> Output Class Initialized
INFO - 2020-09-12 10:53:24 --> Security Class Initialized
DEBUG - 2020-09-12 10:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:53:24 --> Input Class Initialized
INFO - 2020-09-12 10:53:24 --> Language Class Initialized
INFO - 2020-09-12 10:53:24 --> Loader Class Initialized
INFO - 2020-09-12 10:53:24 --> Helper loaded: url_helper
INFO - 2020-09-12 10:53:24 --> Database Driver Class Initialized
INFO - 2020-09-12 10:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:53:24 --> Email Class Initialized
INFO - 2020-09-12 10:53:24 --> Controller Class Initialized
INFO - 2020-09-12 10:53:24 --> Model Class Initialized
INFO - 2020-09-12 10:53:24 --> Model Class Initialized
INFO - 2020-09-12 10:53:24 --> Final output sent to browser
DEBUG - 2020-09-12 10:53:24 --> Total execution time: 0.0401
ERROR - 2020-09-12 10:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 10:58:13 --> Config Class Initialized
INFO - 2020-09-12 10:58:13 --> Hooks Class Initialized
DEBUG - 2020-09-12 10:58:13 --> UTF-8 Support Enabled
INFO - 2020-09-12 10:58:13 --> Utf8 Class Initialized
INFO - 2020-09-12 10:58:13 --> URI Class Initialized
INFO - 2020-09-12 10:58:13 --> Router Class Initialized
INFO - 2020-09-12 10:58:13 --> Output Class Initialized
INFO - 2020-09-12 10:58:13 --> Security Class Initialized
DEBUG - 2020-09-12 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 10:58:13 --> Input Class Initialized
INFO - 2020-09-12 10:58:13 --> Language Class Initialized
INFO - 2020-09-12 10:58:13 --> Loader Class Initialized
INFO - 2020-09-12 10:58:13 --> Helper loaded: url_helper
INFO - 2020-09-12 10:58:13 --> Database Driver Class Initialized
INFO - 2020-09-12 10:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 10:58:13 --> Email Class Initialized
INFO - 2020-09-12 10:58:13 --> Controller Class Initialized
DEBUG - 2020-09-12 10:58:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 10:58:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 10:58:13 --> Model Class Initialized
INFO - 2020-09-12 10:58:13 --> Model Class Initialized
INFO - 2020-09-12 10:58:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-12 10:58:13 --> Final output sent to browser
DEBUG - 2020-09-12 10:58:13 --> Total execution time: 0.0277
ERROR - 2020-09-12 11:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:00:32 --> Config Class Initialized
INFO - 2020-09-12 11:00:32 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:00:32 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:00:32 --> Utf8 Class Initialized
INFO - 2020-09-12 11:00:32 --> URI Class Initialized
DEBUG - 2020-09-12 11:00:32 --> No URI present. Default controller set.
INFO - 2020-09-12 11:00:32 --> Router Class Initialized
INFO - 2020-09-12 11:00:32 --> Output Class Initialized
INFO - 2020-09-12 11:00:32 --> Security Class Initialized
DEBUG - 2020-09-12 11:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:00:32 --> Input Class Initialized
INFO - 2020-09-12 11:00:32 --> Language Class Initialized
INFO - 2020-09-12 11:00:32 --> Loader Class Initialized
INFO - 2020-09-12 11:00:32 --> Helper loaded: url_helper
INFO - 2020-09-12 11:00:32 --> Database Driver Class Initialized
INFO - 2020-09-12 11:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:00:32 --> Email Class Initialized
INFO - 2020-09-12 11:00:32 --> Controller Class Initialized
INFO - 2020-09-12 11:00:32 --> Model Class Initialized
INFO - 2020-09-12 11:00:32 --> Model Class Initialized
DEBUG - 2020-09-12 11:00:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 11:00:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 11:00:32 --> Final output sent to browser
DEBUG - 2020-09-12 11:00:32 --> Total execution time: 0.0189
ERROR - 2020-09-12 11:00:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:00:49 --> Config Class Initialized
INFO - 2020-09-12 11:00:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:00:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:00:49 --> Utf8 Class Initialized
INFO - 2020-09-12 11:00:49 --> URI Class Initialized
INFO - 2020-09-12 11:00:49 --> Router Class Initialized
INFO - 2020-09-12 11:00:49 --> Output Class Initialized
INFO - 2020-09-12 11:00:49 --> Security Class Initialized
DEBUG - 2020-09-12 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:00:49 --> Input Class Initialized
INFO - 2020-09-12 11:00:49 --> Language Class Initialized
INFO - 2020-09-12 11:00:49 --> Loader Class Initialized
INFO - 2020-09-12 11:00:49 --> Helper loaded: url_helper
INFO - 2020-09-12 11:00:49 --> Database Driver Class Initialized
INFO - 2020-09-12 11:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:00:49 --> Email Class Initialized
INFO - 2020-09-12 11:00:49 --> Controller Class Initialized
INFO - 2020-09-12 11:00:49 --> Model Class Initialized
INFO - 2020-09-12 11:00:49 --> Model Class Initialized
DEBUG - 2020-09-12 11:00:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 11:00:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 11:00:49 --> Model Class Initialized
INFO - 2020-09-12 11:00:49 --> Final output sent to browser
DEBUG - 2020-09-12 11:00:49 --> Total execution time: 0.0221
ERROR - 2020-09-12 11:00:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:00:49 --> Config Class Initialized
INFO - 2020-09-12 11:00:49 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:00:49 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:00:49 --> Utf8 Class Initialized
INFO - 2020-09-12 11:00:49 --> URI Class Initialized
INFO - 2020-09-12 11:00:49 --> Router Class Initialized
INFO - 2020-09-12 11:00:49 --> Output Class Initialized
INFO - 2020-09-12 11:00:49 --> Security Class Initialized
DEBUG - 2020-09-12 11:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:00:49 --> Input Class Initialized
INFO - 2020-09-12 11:00:49 --> Language Class Initialized
INFO - 2020-09-12 11:00:49 --> Loader Class Initialized
INFO - 2020-09-12 11:00:49 --> Helper loaded: url_helper
INFO - 2020-09-12 11:00:49 --> Database Driver Class Initialized
INFO - 2020-09-12 11:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:00:49 --> Email Class Initialized
INFO - 2020-09-12 11:00:49 --> Controller Class Initialized
INFO - 2020-09-12 11:00:49 --> Model Class Initialized
INFO - 2020-09-12 11:00:49 --> Model Class Initialized
DEBUG - 2020-09-12 11:00:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-12 11:00:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:00:50 --> Config Class Initialized
INFO - 2020-09-12 11:00:50 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:00:50 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:00:50 --> Utf8 Class Initialized
INFO - 2020-09-12 11:00:50 --> URI Class Initialized
INFO - 2020-09-12 11:00:50 --> Router Class Initialized
INFO - 2020-09-12 11:00:50 --> Output Class Initialized
INFO - 2020-09-12 11:00:50 --> Security Class Initialized
DEBUG - 2020-09-12 11:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:00:50 --> Input Class Initialized
INFO - 2020-09-12 11:00:50 --> Language Class Initialized
INFO - 2020-09-12 11:00:50 --> Loader Class Initialized
INFO - 2020-09-12 11:00:50 --> Helper loaded: url_helper
INFO - 2020-09-12 11:00:50 --> Database Driver Class Initialized
INFO - 2020-09-12 11:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:00:50 --> Email Class Initialized
INFO - 2020-09-12 11:00:50 --> Controller Class Initialized
DEBUG - 2020-09-12 11:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 11:00:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 11:00:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-12 11:00:50 --> Final output sent to browser
DEBUG - 2020-09-12 11:00:50 --> Total execution time: 0.0191
ERROR - 2020-09-12 11:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:01:00 --> Config Class Initialized
INFO - 2020-09-12 11:01:00 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:01:00 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:01:00 --> Utf8 Class Initialized
INFO - 2020-09-12 11:01:00 --> URI Class Initialized
DEBUG - 2020-09-12 11:01:00 --> No URI present. Default controller set.
INFO - 2020-09-12 11:01:00 --> Router Class Initialized
INFO - 2020-09-12 11:01:00 --> Output Class Initialized
INFO - 2020-09-12 11:01:00 --> Security Class Initialized
DEBUG - 2020-09-12 11:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:01:00 --> Input Class Initialized
INFO - 2020-09-12 11:01:00 --> Language Class Initialized
INFO - 2020-09-12 11:01:00 --> Loader Class Initialized
INFO - 2020-09-12 11:01:00 --> Helper loaded: url_helper
INFO - 2020-09-12 11:01:00 --> Database Driver Class Initialized
INFO - 2020-09-12 11:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:01:00 --> Email Class Initialized
INFO - 2020-09-12 11:01:00 --> Controller Class Initialized
INFO - 2020-09-12 11:01:00 --> Model Class Initialized
INFO - 2020-09-12 11:01:00 --> Model Class Initialized
DEBUG - 2020-09-12 11:01:00 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 11:01:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 11:01:00 --> Final output sent to browser
DEBUG - 2020-09-12 11:01:00 --> Total execution time: 0.0207
ERROR - 2020-09-12 11:01:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:01:04 --> Config Class Initialized
INFO - 2020-09-12 11:01:04 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:01:04 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:01:04 --> Utf8 Class Initialized
INFO - 2020-09-12 11:01:04 --> URI Class Initialized
INFO - 2020-09-12 11:01:04 --> Router Class Initialized
INFO - 2020-09-12 11:01:04 --> Output Class Initialized
INFO - 2020-09-12 11:01:04 --> Security Class Initialized
DEBUG - 2020-09-12 11:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:01:04 --> Input Class Initialized
INFO - 2020-09-12 11:01:04 --> Language Class Initialized
INFO - 2020-09-12 11:01:04 --> Loader Class Initialized
INFO - 2020-09-12 11:01:04 --> Helper loaded: url_helper
INFO - 2020-09-12 11:01:04 --> Database Driver Class Initialized
INFO - 2020-09-12 11:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:01:04 --> Email Class Initialized
INFO - 2020-09-12 11:01:04 --> Controller Class Initialized
INFO - 2020-09-12 11:01:04 --> Model Class Initialized
INFO - 2020-09-12 11:01:04 --> Model Class Initialized
DEBUG - 2020-09-12 11:01:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-12 11:01:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-12 11:01:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-09-12 11:01:04 --> Final output sent to browser
DEBUG - 2020-09-12 11:01:04 --> Total execution time: 0.0380
ERROR - 2020-09-12 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-12 11:01:16 --> Config Class Initialized
INFO - 2020-09-12 11:01:16 --> Hooks Class Initialized
DEBUG - 2020-09-12 11:01:16 --> UTF-8 Support Enabled
INFO - 2020-09-12 11:01:16 --> Utf8 Class Initialized
INFO - 2020-09-12 11:01:16 --> URI Class Initialized
DEBUG - 2020-09-12 11:01:16 --> No URI present. Default controller set.
INFO - 2020-09-12 11:01:16 --> Router Class Initialized
INFO - 2020-09-12 11:01:16 --> Output Class Initialized
INFO - 2020-09-12 11:01:16 --> Security Class Initialized
DEBUG - 2020-09-12 11:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-12 11:01:16 --> Input Class Initialized
INFO - 2020-09-12 11:01:16 --> Language Class Initialized
INFO - 2020-09-12 11:01:16 --> Loader Class Initialized
INFO - 2020-09-12 11:01:16 --> Helper loaded: url_helper
INFO - 2020-09-12 11:01:16 --> Database Driver Class Initialized
INFO - 2020-09-12 11:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-12 11:01:16 --> Email Class Initialized
INFO - 2020-09-12 11:01:16 --> Controller Class Initialized
INFO - 2020-09-12 11:01:16 --> Model Class Initialized
INFO - 2020-09-12 11:01:16 --> Model Class Initialized
DEBUG - 2020-09-12 11:01:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-12 11:01:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-12 11:01:16 --> Final output sent to browser
DEBUG - 2020-09-12 11:01:16 --> Total execution time: 0.0183
