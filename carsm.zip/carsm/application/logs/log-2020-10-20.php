<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-20 04:59:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-20 04:59:25 --> Config Class Initialized
INFO - 2020-10-20 04:59:25 --> Hooks Class Initialized
DEBUG - 2020-10-20 04:59:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 04:59:25 --> Utf8 Class Initialized
INFO - 2020-10-20 04:59:25 --> URI Class Initialized
DEBUG - 2020-10-20 04:59:25 --> No URI present. Default controller set.
INFO - 2020-10-20 04:59:25 --> Router Class Initialized
INFO - 2020-10-20 04:59:25 --> Output Class Initialized
INFO - 2020-10-20 04:59:25 --> Security Class Initialized
DEBUG - 2020-10-20 04:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 04:59:25 --> Input Class Initialized
INFO - 2020-10-20 04:59:25 --> Language Class Initialized
INFO - 2020-10-20 04:59:25 --> Loader Class Initialized
INFO - 2020-10-20 04:59:25 --> Helper loaded: url_helper
INFO - 2020-10-20 04:59:25 --> Database Driver Class Initialized
INFO - 2020-10-20 04:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 04:59:25 --> Email Class Initialized
INFO - 2020-10-20 04:59:25 --> Controller Class Initialized
INFO - 2020-10-20 04:59:25 --> Model Class Initialized
INFO - 2020-10-20 04:59:25 --> Model Class Initialized
DEBUG - 2020-10-20 04:59:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-20 04:59:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-20 04:59:25 --> Final output sent to browser
DEBUG - 2020-10-20 04:59:25 --> Total execution time: 0.1517
ERROR - 2020-10-20 13:01:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-20 13:01:26 --> Config Class Initialized
INFO - 2020-10-20 13:01:26 --> Hooks Class Initialized
DEBUG - 2020-10-20 13:01:26 --> UTF-8 Support Enabled
INFO - 2020-10-20 13:01:26 --> Utf8 Class Initialized
INFO - 2020-10-20 13:01:26 --> URI Class Initialized
DEBUG - 2020-10-20 13:01:26 --> No URI present. Default controller set.
INFO - 2020-10-20 13:01:26 --> Router Class Initialized
INFO - 2020-10-20 13:01:26 --> Output Class Initialized
INFO - 2020-10-20 13:01:26 --> Security Class Initialized
DEBUG - 2020-10-20 13:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 13:01:26 --> Input Class Initialized
INFO - 2020-10-20 13:01:26 --> Language Class Initialized
INFO - 2020-10-20 13:01:26 --> Loader Class Initialized
INFO - 2020-10-20 13:01:26 --> Helper loaded: url_helper
INFO - 2020-10-20 13:01:26 --> Database Driver Class Initialized
INFO - 2020-10-20 13:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 13:01:26 --> Email Class Initialized
INFO - 2020-10-20 13:01:26 --> Controller Class Initialized
INFO - 2020-10-20 13:01:26 --> Model Class Initialized
INFO - 2020-10-20 13:01:26 --> Model Class Initialized
DEBUG - 2020-10-20 13:01:26 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-20 13:01:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-20 13:01:26 --> Final output sent to browser
DEBUG - 2020-10-20 13:01:26 --> Total execution time: 0.1062
