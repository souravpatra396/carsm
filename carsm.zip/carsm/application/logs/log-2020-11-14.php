<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-11-14 07:05:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:05:31 --> Config Class Initialized
INFO - 2020-11-14 07:05:31 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:05:31 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:05:31 --> Utf8 Class Initialized
INFO - 2020-11-14 07:05:31 --> URI Class Initialized
DEBUG - 2020-11-14 07:05:31 --> No URI present. Default controller set.
INFO - 2020-11-14 07:05:31 --> Router Class Initialized
INFO - 2020-11-14 07:05:31 --> Output Class Initialized
INFO - 2020-11-14 07:05:31 --> Security Class Initialized
DEBUG - 2020-11-14 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:05:31 --> Input Class Initialized
INFO - 2020-11-14 07:05:31 --> Language Class Initialized
INFO - 2020-11-14 07:05:31 --> Loader Class Initialized
INFO - 2020-11-14 07:05:31 --> Helper loaded: url_helper
INFO - 2020-11-14 07:05:31 --> Database Driver Class Initialized
INFO - 2020-11-14 07:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:05:31 --> Email Class Initialized
INFO - 2020-11-14 07:05:31 --> Controller Class Initialized
INFO - 2020-11-14 07:05:31 --> Model Class Initialized
INFO - 2020-11-14 07:05:31 --> Model Class Initialized
DEBUG - 2020-11-14 07:05:31 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:05:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 07:05:31 --> Final output sent to browser
DEBUG - 2020-11-14 07:05:31 --> Total execution time: 0.2098
ERROR - 2020-11-14 07:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:09:20 --> Config Class Initialized
INFO - 2020-11-14 07:09:20 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:09:20 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:09:20 --> Utf8 Class Initialized
INFO - 2020-11-14 07:09:20 --> URI Class Initialized
INFO - 2020-11-14 07:09:20 --> Router Class Initialized
INFO - 2020-11-14 07:09:20 --> Output Class Initialized
INFO - 2020-11-14 07:09:20 --> Security Class Initialized
DEBUG - 2020-11-14 07:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:09:20 --> Input Class Initialized
INFO - 2020-11-14 07:09:20 --> Language Class Initialized
INFO - 2020-11-14 07:09:20 --> Loader Class Initialized
INFO - 2020-11-14 07:09:20 --> Helper loaded: url_helper
INFO - 2020-11-14 07:09:20 --> Database Driver Class Initialized
INFO - 2020-11-14 07:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:09:20 --> Email Class Initialized
INFO - 2020-11-14 07:09:20 --> Controller Class Initialized
INFO - 2020-11-14 07:09:20 --> Model Class Initialized
INFO - 2020-11-14 07:09:20 --> Model Class Initialized
DEBUG - 2020-11-14 07:09:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:09:20 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-11-14 07:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:09:20 --> Config Class Initialized
INFO - 2020-11-14 07:09:20 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:09:20 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:09:20 --> Utf8 Class Initialized
INFO - 2020-11-14 07:09:20 --> URI Class Initialized
INFO - 2020-11-14 07:09:20 --> Router Class Initialized
INFO - 2020-11-14 07:09:20 --> Output Class Initialized
INFO - 2020-11-14 07:09:20 --> Security Class Initialized
DEBUG - 2020-11-14 07:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:09:20 --> Input Class Initialized
INFO - 2020-11-14 07:09:20 --> Language Class Initialized
INFO - 2020-11-14 07:09:20 --> Loader Class Initialized
INFO - 2020-11-14 07:09:20 --> Helper loaded: url_helper
INFO - 2020-11-14 07:09:20 --> Database Driver Class Initialized
INFO - 2020-11-14 07:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:09:20 --> Email Class Initialized
INFO - 2020-11-14 07:09:20 --> Controller Class Initialized
INFO - 2020-11-14 07:09:20 --> Model Class Initialized
INFO - 2020-11-14 07:09:20 --> Model Class Initialized
DEBUG - 2020-11-14 07:09:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-14 07:09:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:09:20 --> Config Class Initialized
INFO - 2020-11-14 07:09:20 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:09:20 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:09:20 --> Utf8 Class Initialized
INFO - 2020-11-14 07:09:20 --> URI Class Initialized
DEBUG - 2020-11-14 07:09:20 --> No URI present. Default controller set.
INFO - 2020-11-14 07:09:20 --> Router Class Initialized
INFO - 2020-11-14 07:09:20 --> Output Class Initialized
INFO - 2020-11-14 07:09:20 --> Security Class Initialized
DEBUG - 2020-11-14 07:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:09:20 --> Input Class Initialized
INFO - 2020-11-14 07:09:20 --> Language Class Initialized
INFO - 2020-11-14 07:09:20 --> Loader Class Initialized
INFO - 2020-11-14 07:09:20 --> Helper loaded: url_helper
INFO - 2020-11-14 07:09:20 --> Database Driver Class Initialized
INFO - 2020-11-14 07:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:09:20 --> Email Class Initialized
INFO - 2020-11-14 07:09:20 --> Controller Class Initialized
INFO - 2020-11-14 07:09:20 --> Model Class Initialized
INFO - 2020-11-14 07:09:20 --> Model Class Initialized
DEBUG - 2020-11-14 07:09:20 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:09:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 07:09:20 --> Final output sent to browser
DEBUG - 2020-11-14 07:09:20 --> Total execution time: 0.0182
ERROR - 2020-11-14 07:09:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:09:21 --> Config Class Initialized
INFO - 2020-11-14 07:09:21 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:09:21 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:09:21 --> Utf8 Class Initialized
INFO - 2020-11-14 07:09:21 --> URI Class Initialized
INFO - 2020-11-14 07:09:21 --> Router Class Initialized
INFO - 2020-11-14 07:09:21 --> Output Class Initialized
INFO - 2020-11-14 07:09:21 --> Security Class Initialized
DEBUG - 2020-11-14 07:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:09:21 --> Input Class Initialized
INFO - 2020-11-14 07:09:21 --> Language Class Initialized
INFO - 2020-11-14 07:09:21 --> Loader Class Initialized
INFO - 2020-11-14 07:09:21 --> Helper loaded: url_helper
INFO - 2020-11-14 07:09:21 --> Database Driver Class Initialized
INFO - 2020-11-14 07:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:09:21 --> Email Class Initialized
INFO - 2020-11-14 07:09:21 --> Controller Class Initialized
DEBUG - 2020-11-14 07:09:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:09:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:09:21 --> Model Class Initialized
INFO - 2020-11-14 07:09:21 --> Model Class Initialized
INFO - 2020-11-14 07:09:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:09:21 --> Final output sent to browser
DEBUG - 2020-11-14 07:09:21 --> Total execution time: 0.0808
ERROR - 2020-11-14 07:10:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:10:13 --> Config Class Initialized
INFO - 2020-11-14 07:10:13 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:10:13 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:10:13 --> Utf8 Class Initialized
INFO - 2020-11-14 07:10:13 --> URI Class Initialized
INFO - 2020-11-14 07:10:13 --> Router Class Initialized
INFO - 2020-11-14 07:10:13 --> Output Class Initialized
INFO - 2020-11-14 07:10:13 --> Security Class Initialized
DEBUG - 2020-11-14 07:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:10:13 --> Input Class Initialized
INFO - 2020-11-14 07:10:13 --> Language Class Initialized
INFO - 2020-11-14 07:10:13 --> Loader Class Initialized
INFO - 2020-11-14 07:10:13 --> Helper loaded: url_helper
INFO - 2020-11-14 07:10:13 --> Database Driver Class Initialized
INFO - 2020-11-14 07:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:10:13 --> Email Class Initialized
INFO - 2020-11-14 07:10:13 --> Controller Class Initialized
DEBUG - 2020-11-14 07:10:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:10:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:10:13 --> Model Class Initialized
INFO - 2020-11-14 07:10:13 --> Model Class Initialized
INFO - 2020-11-14 07:10:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:10:13 --> Final output sent to browser
DEBUG - 2020-11-14 07:10:13 --> Total execution time: 0.0416
ERROR - 2020-11-14 07:10:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:10:17 --> Config Class Initialized
INFO - 2020-11-14 07:10:17 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:10:17 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:10:17 --> Utf8 Class Initialized
INFO - 2020-11-14 07:10:17 --> URI Class Initialized
INFO - 2020-11-14 07:10:17 --> Router Class Initialized
INFO - 2020-11-14 07:10:17 --> Output Class Initialized
INFO - 2020-11-14 07:10:17 --> Security Class Initialized
DEBUG - 2020-11-14 07:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:10:17 --> Input Class Initialized
INFO - 2020-11-14 07:10:17 --> Language Class Initialized
INFO - 2020-11-14 07:10:17 --> Loader Class Initialized
INFO - 2020-11-14 07:10:17 --> Helper loaded: url_helper
INFO - 2020-11-14 07:10:17 --> Database Driver Class Initialized
INFO - 2020-11-14 07:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:10:17 --> Email Class Initialized
INFO - 2020-11-14 07:10:17 --> Controller Class Initialized
DEBUG - 2020-11-14 07:10:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:10:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:10:17 --> Model Class Initialized
INFO - 2020-11-14 07:10:17 --> Model Class Initialized
INFO - 2020-11-14 07:10:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:10:17 --> Final output sent to browser
DEBUG - 2020-11-14 07:10:17 --> Total execution time: 0.0271
ERROR - 2020-11-14 07:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:10:21 --> Config Class Initialized
INFO - 2020-11-14 07:10:21 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:10:21 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:10:21 --> Utf8 Class Initialized
INFO - 2020-11-14 07:10:21 --> URI Class Initialized
INFO - 2020-11-14 07:10:21 --> Router Class Initialized
INFO - 2020-11-14 07:10:21 --> Output Class Initialized
INFO - 2020-11-14 07:10:21 --> Security Class Initialized
DEBUG - 2020-11-14 07:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:10:21 --> Input Class Initialized
INFO - 2020-11-14 07:10:21 --> Language Class Initialized
INFO - 2020-11-14 07:10:21 --> Loader Class Initialized
INFO - 2020-11-14 07:10:21 --> Helper loaded: url_helper
INFO - 2020-11-14 07:10:21 --> Database Driver Class Initialized
INFO - 2020-11-14 07:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:10:21 --> Email Class Initialized
INFO - 2020-11-14 07:10:21 --> Controller Class Initialized
DEBUG - 2020-11-14 07:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:10:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:10:21 --> Model Class Initialized
INFO - 2020-11-14 07:10:21 --> Model Class Initialized
INFO - 2020-11-14 07:10:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:10:21 --> Final output sent to browser
DEBUG - 2020-11-14 07:10:21 --> Total execution time: 0.0578
ERROR - 2020-11-14 07:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:10:22 --> Config Class Initialized
INFO - 2020-11-14 07:10:22 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:10:22 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:10:22 --> Utf8 Class Initialized
INFO - 2020-11-14 07:10:22 --> URI Class Initialized
INFO - 2020-11-14 07:10:22 --> Router Class Initialized
INFO - 2020-11-14 07:10:22 --> Output Class Initialized
INFO - 2020-11-14 07:10:22 --> Security Class Initialized
DEBUG - 2020-11-14 07:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:10:22 --> Input Class Initialized
INFO - 2020-11-14 07:10:22 --> Language Class Initialized
INFO - 2020-11-14 07:10:22 --> Loader Class Initialized
INFO - 2020-11-14 07:10:22 --> Helper loaded: url_helper
INFO - 2020-11-14 07:10:22 --> Database Driver Class Initialized
INFO - 2020-11-14 07:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:10:22 --> Email Class Initialized
INFO - 2020-11-14 07:10:22 --> Controller Class Initialized
DEBUG - 2020-11-14 07:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:10:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:10:22 --> Model Class Initialized
INFO - 2020-11-14 07:10:22 --> Model Class Initialized
INFO - 2020-11-14 07:10:22 --> Final output sent to browser
DEBUG - 2020-11-14 07:10:22 --> Total execution time: 0.0538
ERROR - 2020-11-14 07:10:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:10:25 --> Config Class Initialized
INFO - 2020-11-14 07:10:25 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:10:25 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:10:25 --> Utf8 Class Initialized
INFO - 2020-11-14 07:10:25 --> URI Class Initialized
INFO - 2020-11-14 07:10:25 --> Router Class Initialized
INFO - 2020-11-14 07:10:25 --> Output Class Initialized
INFO - 2020-11-14 07:10:25 --> Security Class Initialized
DEBUG - 2020-11-14 07:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:10:25 --> Input Class Initialized
INFO - 2020-11-14 07:10:25 --> Language Class Initialized
INFO - 2020-11-14 07:10:25 --> Loader Class Initialized
INFO - 2020-11-14 07:10:25 --> Helper loaded: url_helper
INFO - 2020-11-14 07:10:25 --> Database Driver Class Initialized
INFO - 2020-11-14 07:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:10:25 --> Email Class Initialized
INFO - 2020-11-14 07:10:25 --> Controller Class Initialized
DEBUG - 2020-11-14 07:10:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:10:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:10:25 --> Model Class Initialized
INFO - 2020-11-14 07:10:25 --> Model Class Initialized
ERROR - 2020-11-14 07:10:25 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 470
ERROR - 2020-11-14 07:10:25 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-14 07:10:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:10:28 --> Final output sent to browser
DEBUG - 2020-11-14 07:10:28 --> Total execution time: 3.3405
ERROR - 2020-11-14 07:10:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:10:31 --> Config Class Initialized
INFO - 2020-11-14 07:10:31 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:10:31 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:10:31 --> Utf8 Class Initialized
INFO - 2020-11-14 07:10:31 --> URI Class Initialized
INFO - 2020-11-14 07:10:31 --> Router Class Initialized
INFO - 2020-11-14 07:10:31 --> Output Class Initialized
INFO - 2020-11-14 07:10:31 --> Security Class Initialized
DEBUG - 2020-11-14 07:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:10:31 --> Input Class Initialized
INFO - 2020-11-14 07:10:31 --> Language Class Initialized
INFO - 2020-11-14 07:10:31 --> Loader Class Initialized
INFO - 2020-11-14 07:10:31 --> Helper loaded: url_helper
INFO - 2020-11-14 07:10:31 --> Database Driver Class Initialized
INFO - 2020-11-14 07:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:10:31 --> Email Class Initialized
INFO - 2020-11-14 07:10:31 --> Controller Class Initialized
DEBUG - 2020-11-14 07:10:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:10:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:10:31 --> Model Class Initialized
INFO - 2020-11-14 07:10:31 --> Model Class Initialized
INFO - 2020-11-14 07:10:31 --> Final output sent to browser
DEBUG - 2020-11-14 07:10:31 --> Total execution time: 0.0252
ERROR - 2020-11-14 07:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:11:38 --> Config Class Initialized
INFO - 2020-11-14 07:11:38 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:11:38 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:11:38 --> Utf8 Class Initialized
INFO - 2020-11-14 07:11:38 --> URI Class Initialized
INFO - 2020-11-14 07:11:38 --> Router Class Initialized
INFO - 2020-11-14 07:11:38 --> Output Class Initialized
INFO - 2020-11-14 07:11:38 --> Security Class Initialized
DEBUG - 2020-11-14 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:11:38 --> Input Class Initialized
INFO - 2020-11-14 07:11:38 --> Language Class Initialized
INFO - 2020-11-14 07:11:38 --> Loader Class Initialized
INFO - 2020-11-14 07:11:38 --> Helper loaded: url_helper
INFO - 2020-11-14 07:11:38 --> Database Driver Class Initialized
INFO - 2020-11-14 07:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:11:38 --> Email Class Initialized
INFO - 2020-11-14 07:11:38 --> Controller Class Initialized
DEBUG - 2020-11-14 07:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:11:38 --> Model Class Initialized
INFO - 2020-11-14 07:11:38 --> Model Class Initialized
INFO - 2020-11-14 07:11:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:11:38 --> Final output sent to browser
DEBUG - 2020-11-14 07:11:38 --> Total execution time: 0.0252
ERROR - 2020-11-14 07:11:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:11:38 --> Config Class Initialized
INFO - 2020-11-14 07:11:38 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:11:38 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:11:38 --> Utf8 Class Initialized
INFO - 2020-11-14 07:11:38 --> URI Class Initialized
INFO - 2020-11-14 07:11:38 --> Router Class Initialized
INFO - 2020-11-14 07:11:38 --> Output Class Initialized
INFO - 2020-11-14 07:11:38 --> Security Class Initialized
DEBUG - 2020-11-14 07:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:11:38 --> Input Class Initialized
INFO - 2020-11-14 07:11:38 --> Language Class Initialized
INFO - 2020-11-14 07:11:38 --> Loader Class Initialized
INFO - 2020-11-14 07:11:38 --> Helper loaded: url_helper
INFO - 2020-11-14 07:11:38 --> Database Driver Class Initialized
INFO - 2020-11-14 07:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:11:38 --> Email Class Initialized
INFO - 2020-11-14 07:11:38 --> Controller Class Initialized
DEBUG - 2020-11-14 07:11:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:11:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:11:38 --> Model Class Initialized
INFO - 2020-11-14 07:11:38 --> Model Class Initialized
INFO - 2020-11-14 07:11:38 --> Final output sent to browser
DEBUG - 2020-11-14 07:11:38 --> Total execution time: 0.0214
ERROR - 2020-11-14 07:11:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:11:42 --> Config Class Initialized
INFO - 2020-11-14 07:11:42 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:11:42 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:11:42 --> Utf8 Class Initialized
INFO - 2020-11-14 07:11:42 --> URI Class Initialized
INFO - 2020-11-14 07:11:42 --> Router Class Initialized
INFO - 2020-11-14 07:11:42 --> Output Class Initialized
INFO - 2020-11-14 07:11:42 --> Security Class Initialized
DEBUG - 2020-11-14 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:11:42 --> Input Class Initialized
INFO - 2020-11-14 07:11:42 --> Language Class Initialized
INFO - 2020-11-14 07:11:42 --> Loader Class Initialized
INFO - 2020-11-14 07:11:42 --> Helper loaded: url_helper
INFO - 2020-11-14 07:11:42 --> Database Driver Class Initialized
INFO - 2020-11-14 07:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:11:42 --> Email Class Initialized
INFO - 2020-11-14 07:11:42 --> Controller Class Initialized
DEBUG - 2020-11-14 07:11:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:11:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:11:42 --> Model Class Initialized
INFO - 2020-11-14 07:11:42 --> Model Class Initialized
ERROR - 2020-11-14 07:11:42 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 470
ERROR - 2020-11-14 07:11:42 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-14 07:11:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:11:44 --> Final output sent to browser
DEBUG - 2020-11-14 07:11:44 --> Total execution time: 2.0684
ERROR - 2020-11-14 07:11:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:11:45 --> Config Class Initialized
INFO - 2020-11-14 07:11:45 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:11:45 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:11:45 --> Utf8 Class Initialized
INFO - 2020-11-14 07:11:45 --> URI Class Initialized
INFO - 2020-11-14 07:11:45 --> Router Class Initialized
INFO - 2020-11-14 07:11:45 --> Output Class Initialized
INFO - 2020-11-14 07:11:45 --> Security Class Initialized
DEBUG - 2020-11-14 07:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:11:45 --> Input Class Initialized
INFO - 2020-11-14 07:11:45 --> Language Class Initialized
INFO - 2020-11-14 07:11:45 --> Loader Class Initialized
INFO - 2020-11-14 07:11:45 --> Helper loaded: url_helper
INFO - 2020-11-14 07:11:45 --> Database Driver Class Initialized
INFO - 2020-11-14 07:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:11:45 --> Email Class Initialized
INFO - 2020-11-14 07:11:45 --> Controller Class Initialized
DEBUG - 2020-11-14 07:11:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:11:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:11:45 --> Model Class Initialized
INFO - 2020-11-14 07:11:45 --> Model Class Initialized
INFO - 2020-11-14 07:11:45 --> Final output sent to browser
DEBUG - 2020-11-14 07:11:45 --> Total execution time: 0.0283
ERROR - 2020-11-14 07:12:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:12:55 --> Config Class Initialized
INFO - 2020-11-14 07:12:55 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:12:55 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:12:55 --> Utf8 Class Initialized
INFO - 2020-11-14 07:12:55 --> URI Class Initialized
DEBUG - 2020-11-14 07:12:55 --> No URI present. Default controller set.
INFO - 2020-11-14 07:12:55 --> Router Class Initialized
INFO - 2020-11-14 07:12:55 --> Output Class Initialized
INFO - 2020-11-14 07:12:55 --> Security Class Initialized
DEBUG - 2020-11-14 07:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:12:55 --> Input Class Initialized
INFO - 2020-11-14 07:12:55 --> Language Class Initialized
INFO - 2020-11-14 07:12:55 --> Loader Class Initialized
INFO - 2020-11-14 07:12:55 --> Helper loaded: url_helper
INFO - 2020-11-14 07:12:55 --> Database Driver Class Initialized
INFO - 2020-11-14 07:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:12:55 --> Email Class Initialized
INFO - 2020-11-14 07:12:55 --> Controller Class Initialized
INFO - 2020-11-14 07:12:55 --> Model Class Initialized
INFO - 2020-11-14 07:12:55 --> Model Class Initialized
DEBUG - 2020-11-14 07:12:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:12:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 07:12:55 --> Final output sent to browser
DEBUG - 2020-11-14 07:12:55 --> Total execution time: 0.0209
ERROR - 2020-11-14 07:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:12:58 --> Config Class Initialized
INFO - 2020-11-14 07:12:58 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:12:58 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:12:58 --> Utf8 Class Initialized
INFO - 2020-11-14 07:12:58 --> URI Class Initialized
INFO - 2020-11-14 07:12:58 --> Router Class Initialized
INFO - 2020-11-14 07:12:58 --> Output Class Initialized
INFO - 2020-11-14 07:12:58 --> Security Class Initialized
DEBUG - 2020-11-14 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:12:58 --> Input Class Initialized
INFO - 2020-11-14 07:12:58 --> Language Class Initialized
INFO - 2020-11-14 07:12:58 --> Loader Class Initialized
INFO - 2020-11-14 07:12:58 --> Helper loaded: url_helper
INFO - 2020-11-14 07:12:58 --> Database Driver Class Initialized
INFO - 2020-11-14 07:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:12:58 --> Email Class Initialized
INFO - 2020-11-14 07:12:58 --> Controller Class Initialized
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
DEBUG - 2020-11-14 07:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:12:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
INFO - 2020-11-14 07:12:58 --> Final output sent to browser
DEBUG - 2020-11-14 07:12:58 --> Total execution time: 0.0235
ERROR - 2020-11-14 07:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:12:58 --> Config Class Initialized
INFO - 2020-11-14 07:12:58 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:12:58 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:12:58 --> Utf8 Class Initialized
INFO - 2020-11-14 07:12:58 --> URI Class Initialized
INFO - 2020-11-14 07:12:58 --> Router Class Initialized
INFO - 2020-11-14 07:12:58 --> Output Class Initialized
INFO - 2020-11-14 07:12:58 --> Security Class Initialized
DEBUG - 2020-11-14 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:12:58 --> Input Class Initialized
INFO - 2020-11-14 07:12:58 --> Language Class Initialized
INFO - 2020-11-14 07:12:58 --> Loader Class Initialized
INFO - 2020-11-14 07:12:58 --> Helper loaded: url_helper
INFO - 2020-11-14 07:12:58 --> Database Driver Class Initialized
INFO - 2020-11-14 07:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:12:58 --> Email Class Initialized
INFO - 2020-11-14 07:12:58 --> Controller Class Initialized
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
DEBUG - 2020-11-14 07:12:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-14 07:12:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:12:58 --> Config Class Initialized
INFO - 2020-11-14 07:12:58 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:12:58 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:12:58 --> Utf8 Class Initialized
INFO - 2020-11-14 07:12:58 --> URI Class Initialized
INFO - 2020-11-14 07:12:58 --> Router Class Initialized
INFO - 2020-11-14 07:12:58 --> Output Class Initialized
INFO - 2020-11-14 07:12:58 --> Security Class Initialized
DEBUG - 2020-11-14 07:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:12:58 --> Input Class Initialized
INFO - 2020-11-14 07:12:58 --> Language Class Initialized
INFO - 2020-11-14 07:12:58 --> Loader Class Initialized
INFO - 2020-11-14 07:12:58 --> Helper loaded: url_helper
INFO - 2020-11-14 07:12:58 --> Database Driver Class Initialized
INFO - 2020-11-14 07:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:12:58 --> Email Class Initialized
INFO - 2020-11-14 07:12:58 --> Controller Class Initialized
DEBUG - 2020-11-14 07:12:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:12:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
INFO - 2020-11-14 07:12:58 --> Model Class Initialized
INFO - 2020-11-14 07:12:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-11-14 07:12:58 --> Final output sent to browser
DEBUG - 2020-11-14 07:12:58 --> Total execution time: 0.0670
ERROR - 2020-11-14 07:13:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:13:01 --> Config Class Initialized
INFO - 2020-11-14 07:13:01 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:13:01 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:13:01 --> Utf8 Class Initialized
INFO - 2020-11-14 07:13:01 --> URI Class Initialized
DEBUG - 2020-11-14 07:13:01 --> No URI present. Default controller set.
INFO - 2020-11-14 07:13:01 --> Router Class Initialized
INFO - 2020-11-14 07:13:01 --> Output Class Initialized
INFO - 2020-11-14 07:13:01 --> Security Class Initialized
DEBUG - 2020-11-14 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:13:01 --> Input Class Initialized
INFO - 2020-11-14 07:13:01 --> Language Class Initialized
INFO - 2020-11-14 07:13:01 --> Loader Class Initialized
INFO - 2020-11-14 07:13:01 --> Helper loaded: url_helper
INFO - 2020-11-14 07:13:01 --> Database Driver Class Initialized
INFO - 2020-11-14 07:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:13:01 --> Email Class Initialized
INFO - 2020-11-14 07:13:01 --> Controller Class Initialized
INFO - 2020-11-14 07:13:01 --> Model Class Initialized
INFO - 2020-11-14 07:13:01 --> Model Class Initialized
DEBUG - 2020-11-14 07:13:01 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:13:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 07:13:01 --> Final output sent to browser
DEBUG - 2020-11-14 07:13:01 --> Total execution time: 0.0270
ERROR - 2020-11-14 07:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:13:12 --> Config Class Initialized
INFO - 2020-11-14 07:13:12 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:13:12 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:13:12 --> Utf8 Class Initialized
INFO - 2020-11-14 07:13:12 --> URI Class Initialized
INFO - 2020-11-14 07:13:12 --> Router Class Initialized
INFO - 2020-11-14 07:13:12 --> Output Class Initialized
INFO - 2020-11-14 07:13:12 --> Security Class Initialized
DEBUG - 2020-11-14 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:13:12 --> Input Class Initialized
INFO - 2020-11-14 07:13:12 --> Language Class Initialized
INFO - 2020-11-14 07:13:12 --> Loader Class Initialized
INFO - 2020-11-14 07:13:12 --> Helper loaded: url_helper
INFO - 2020-11-14 07:13:12 --> Database Driver Class Initialized
INFO - 2020-11-14 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:13:12 --> Email Class Initialized
INFO - 2020-11-14 07:13:12 --> Controller Class Initialized
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
DEBUG - 2020-11-14 07:13:12 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-14 07:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:13:12 --> Config Class Initialized
INFO - 2020-11-14 07:13:12 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:13:12 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:13:12 --> Utf8 Class Initialized
INFO - 2020-11-14 07:13:12 --> URI Class Initialized
INFO - 2020-11-14 07:13:12 --> Router Class Initialized
INFO - 2020-11-14 07:13:12 --> Output Class Initialized
INFO - 2020-11-14 07:13:12 --> Security Class Initialized
DEBUG - 2020-11-14 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:13:12 --> Input Class Initialized
INFO - 2020-11-14 07:13:12 --> Language Class Initialized
INFO - 2020-11-14 07:13:12 --> Loader Class Initialized
INFO - 2020-11-14 07:13:12 --> Helper loaded: url_helper
INFO - 2020-11-14 07:13:12 --> Database Driver Class Initialized
INFO - 2020-11-14 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:13:12 --> Email Class Initialized
INFO - 2020-11-14 07:13:12 --> Controller Class Initialized
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
DEBUG - 2020-11-14 07:13:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:13:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
INFO - 2020-11-14 07:13:12 --> Final output sent to browser
DEBUG - 2020-11-14 07:13:12 --> Total execution time: 0.0238
ERROR - 2020-11-14 07:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:13:12 --> Config Class Initialized
INFO - 2020-11-14 07:13:12 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:13:12 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:13:12 --> Utf8 Class Initialized
INFO - 2020-11-14 07:13:12 --> URI Class Initialized
INFO - 2020-11-14 07:13:12 --> Router Class Initialized
INFO - 2020-11-14 07:13:12 --> Output Class Initialized
INFO - 2020-11-14 07:13:12 --> Security Class Initialized
DEBUG - 2020-11-14 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:13:12 --> Input Class Initialized
INFO - 2020-11-14 07:13:12 --> Language Class Initialized
INFO - 2020-11-14 07:13:12 --> Loader Class Initialized
INFO - 2020-11-14 07:13:12 --> Helper loaded: url_helper
INFO - 2020-11-14 07:13:12 --> Database Driver Class Initialized
INFO - 2020-11-14 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:13:12 --> Email Class Initialized
INFO - 2020-11-14 07:13:12 --> Controller Class Initialized
DEBUG - 2020-11-14 07:13:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:13:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
INFO - 2020-11-14 07:13:12 --> Model Class Initialized
INFO - 2020-11-14 07:13:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:13:12 --> Final output sent to browser
DEBUG - 2020-11-14 07:13:12 --> Total execution time: 0.0262
ERROR - 2020-11-14 07:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:23 --> Config Class Initialized
INFO - 2020-11-14 07:14:23 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:23 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:23 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:23 --> URI Class Initialized
INFO - 2020-11-14 07:14:23 --> Router Class Initialized
INFO - 2020-11-14 07:14:23 --> Output Class Initialized
INFO - 2020-11-14 07:14:23 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:23 --> Input Class Initialized
INFO - 2020-11-14 07:14:23 --> Language Class Initialized
INFO - 2020-11-14 07:14:23 --> Loader Class Initialized
INFO - 2020-11-14 07:14:23 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:23 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:23 --> Email Class Initialized
INFO - 2020-11-14 07:14:23 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:23 --> Model Class Initialized
INFO - 2020-11-14 07:14:23 --> Model Class Initialized
INFO - 2020-11-14 07:14:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:14:23 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:23 --> Total execution time: 0.0427
ERROR - 2020-11-14 07:14:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:24 --> Config Class Initialized
INFO - 2020-11-14 07:14:24 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:24 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:24 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:24 --> URI Class Initialized
INFO - 2020-11-14 07:14:24 --> Router Class Initialized
INFO - 2020-11-14 07:14:24 --> Output Class Initialized
INFO - 2020-11-14 07:14:24 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:24 --> Input Class Initialized
INFO - 2020-11-14 07:14:24 --> Language Class Initialized
INFO - 2020-11-14 07:14:24 --> Loader Class Initialized
INFO - 2020-11-14 07:14:24 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:24 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:24 --> Email Class Initialized
INFO - 2020-11-14 07:14:24 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:24 --> Model Class Initialized
INFO - 2020-11-14 07:14:24 --> Model Class Initialized
INFO - 2020-11-14 07:14:24 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:24 --> Total execution time: 0.0211
ERROR - 2020-11-14 07:14:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:26 --> Config Class Initialized
INFO - 2020-11-14 07:14:26 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:26 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:26 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:26 --> URI Class Initialized
INFO - 2020-11-14 07:14:26 --> Router Class Initialized
INFO - 2020-11-14 07:14:26 --> Output Class Initialized
INFO - 2020-11-14 07:14:26 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:26 --> Input Class Initialized
INFO - 2020-11-14 07:14:26 --> Language Class Initialized
INFO - 2020-11-14 07:14:26 --> Loader Class Initialized
INFO - 2020-11-14 07:14:26 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:26 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:26 --> Email Class Initialized
INFO - 2020-11-14 07:14:26 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:26 --> Model Class Initialized
INFO - 2020-11-14 07:14:26 --> Model Class Initialized
ERROR - 2020-11-14 07:14:26 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 470
ERROR - 2020-11-14 07:14:26 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
ERROR - 2020-11-14 07:14:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:28 --> Config Class Initialized
INFO - 2020-11-14 07:14:28 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:28 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:28 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:28 --> URI Class Initialized
INFO - 2020-11-14 07:14:28 --> Router Class Initialized
INFO - 2020-11-14 07:14:28 --> Output Class Initialized
INFO - 2020-11-14 07:14:28 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:28 --> Input Class Initialized
INFO - 2020-11-14 07:14:28 --> Language Class Initialized
INFO - 2020-11-14 07:14:28 --> Loader Class Initialized
INFO - 2020-11-14 07:14:28 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:28 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:14:28 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:28 --> Total execution time: 1.9517
INFO - 2020-11-14 07:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:28 --> Email Class Initialized
INFO - 2020-11-14 07:14:28 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:28 --> Model Class Initialized
INFO - 2020-11-14 07:14:28 --> Model Class Initialized
INFO - 2020-11-14 07:14:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:14:28 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:28 --> Total execution time: 0.0693
ERROR - 2020-11-14 07:14:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:29 --> Config Class Initialized
INFO - 2020-11-14 07:14:29 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:29 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:29 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:29 --> URI Class Initialized
INFO - 2020-11-14 07:14:29 --> Router Class Initialized
INFO - 2020-11-14 07:14:29 --> Output Class Initialized
INFO - 2020-11-14 07:14:29 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:29 --> Input Class Initialized
INFO - 2020-11-14 07:14:29 --> Language Class Initialized
INFO - 2020-11-14 07:14:29 --> Loader Class Initialized
INFO - 2020-11-14 07:14:29 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:29 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:29 --> Email Class Initialized
INFO - 2020-11-14 07:14:29 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:29 --> Model Class Initialized
INFO - 2020-11-14 07:14:29 --> Model Class Initialized
INFO - 2020-11-14 07:14:29 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:29 --> Total execution time: 0.0207
ERROR - 2020-11-14 07:14:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:34 --> Config Class Initialized
INFO - 2020-11-14 07:14:34 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:34 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:34 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:34 --> URI Class Initialized
INFO - 2020-11-14 07:14:34 --> Router Class Initialized
INFO - 2020-11-14 07:14:34 --> Output Class Initialized
INFO - 2020-11-14 07:14:34 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:34 --> Input Class Initialized
INFO - 2020-11-14 07:14:34 --> Language Class Initialized
INFO - 2020-11-14 07:14:34 --> Loader Class Initialized
INFO - 2020-11-14 07:14:34 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:34 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:34 --> Email Class Initialized
INFO - 2020-11-14 07:14:34 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:34 --> Model Class Initialized
INFO - 2020-11-14 07:14:34 --> Model Class Initialized
ERROR - 2020-11-14 07:14:34 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 470
ERROR - 2020-11-14 07:14:34 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-14 07:14:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:14:36 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:36 --> Total execution time: 2.1060
ERROR - 2020-11-14 07:14:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:14:36 --> Config Class Initialized
INFO - 2020-11-14 07:14:36 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:14:36 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:14:36 --> Utf8 Class Initialized
INFO - 2020-11-14 07:14:36 --> URI Class Initialized
INFO - 2020-11-14 07:14:36 --> Router Class Initialized
INFO - 2020-11-14 07:14:36 --> Output Class Initialized
INFO - 2020-11-14 07:14:36 --> Security Class Initialized
DEBUG - 2020-11-14 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:14:36 --> Input Class Initialized
INFO - 2020-11-14 07:14:36 --> Language Class Initialized
INFO - 2020-11-14 07:14:36 --> Loader Class Initialized
INFO - 2020-11-14 07:14:36 --> Helper loaded: url_helper
INFO - 2020-11-14 07:14:36 --> Database Driver Class Initialized
INFO - 2020-11-14 07:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:14:36 --> Email Class Initialized
INFO - 2020-11-14 07:14:36 --> Controller Class Initialized
DEBUG - 2020-11-14 07:14:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:14:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:14:36 --> Model Class Initialized
INFO - 2020-11-14 07:14:36 --> Model Class Initialized
INFO - 2020-11-14 07:14:36 --> Final output sent to browser
DEBUG - 2020-11-14 07:14:36 --> Total execution time: 0.0244
ERROR - 2020-11-14 07:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:15:09 --> Config Class Initialized
INFO - 2020-11-14 07:15:09 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:15:09 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:15:09 --> Utf8 Class Initialized
INFO - 2020-11-14 07:15:09 --> URI Class Initialized
INFO - 2020-11-14 07:15:09 --> Router Class Initialized
INFO - 2020-11-14 07:15:09 --> Output Class Initialized
INFO - 2020-11-14 07:15:09 --> Security Class Initialized
DEBUG - 2020-11-14 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:15:09 --> Input Class Initialized
INFO - 2020-11-14 07:15:09 --> Language Class Initialized
INFO - 2020-11-14 07:15:09 --> Loader Class Initialized
INFO - 2020-11-14 07:15:09 --> Helper loaded: url_helper
INFO - 2020-11-14 07:15:09 --> Database Driver Class Initialized
INFO - 2020-11-14 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:15:09 --> Email Class Initialized
INFO - 2020-11-14 07:15:09 --> Controller Class Initialized
DEBUG - 2020-11-14 07:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:15:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:15:09 --> Model Class Initialized
INFO - 2020-11-14 07:15:09 --> Model Class Initialized
INFO - 2020-11-14 07:15:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:15:09 --> Final output sent to browser
DEBUG - 2020-11-14 07:15:09 --> Total execution time: 0.0246
ERROR - 2020-11-14 07:15:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:15:09 --> Config Class Initialized
INFO - 2020-11-14 07:15:09 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:15:09 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:15:09 --> Utf8 Class Initialized
INFO - 2020-11-14 07:15:09 --> URI Class Initialized
INFO - 2020-11-14 07:15:09 --> Router Class Initialized
INFO - 2020-11-14 07:15:09 --> Output Class Initialized
INFO - 2020-11-14 07:15:09 --> Security Class Initialized
DEBUG - 2020-11-14 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:15:09 --> Input Class Initialized
INFO - 2020-11-14 07:15:09 --> Language Class Initialized
INFO - 2020-11-14 07:15:09 --> Loader Class Initialized
INFO - 2020-11-14 07:15:09 --> Helper loaded: url_helper
INFO - 2020-11-14 07:15:09 --> Database Driver Class Initialized
INFO - 2020-11-14 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:15:09 --> Email Class Initialized
INFO - 2020-11-14 07:15:09 --> Controller Class Initialized
DEBUG - 2020-11-14 07:15:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:15:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:15:09 --> Model Class Initialized
INFO - 2020-11-14 07:15:09 --> Model Class Initialized
INFO - 2020-11-14 07:15:09 --> Final output sent to browser
DEBUG - 2020-11-14 07:15:09 --> Total execution time: 0.0245
ERROR - 2020-11-14 07:15:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:15:13 --> Config Class Initialized
INFO - 2020-11-14 07:15:13 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:15:13 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:15:13 --> Utf8 Class Initialized
INFO - 2020-11-14 07:15:13 --> URI Class Initialized
INFO - 2020-11-14 07:15:13 --> Router Class Initialized
INFO - 2020-11-14 07:15:13 --> Output Class Initialized
INFO - 2020-11-14 07:15:13 --> Security Class Initialized
DEBUG - 2020-11-14 07:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:15:13 --> Input Class Initialized
INFO - 2020-11-14 07:15:13 --> Language Class Initialized
INFO - 2020-11-14 07:15:13 --> Loader Class Initialized
INFO - 2020-11-14 07:15:13 --> Helper loaded: url_helper
INFO - 2020-11-14 07:15:13 --> Database Driver Class Initialized
INFO - 2020-11-14 07:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:15:13 --> Email Class Initialized
INFO - 2020-11-14 07:15:13 --> Controller Class Initialized
DEBUG - 2020-11-14 07:15:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:15:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:15:13 --> Model Class Initialized
INFO - 2020-11-14 07:15:13 --> Model Class Initialized
ERROR - 2020-11-14 07:15:13 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 470
ERROR - 2020-11-14 07:15:13 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-14 07:15:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:15:15 --> Final output sent to browser
DEBUG - 2020-11-14 07:15:15 --> Total execution time: 2.5111
ERROR - 2020-11-14 07:15:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:15:16 --> Config Class Initialized
INFO - 2020-11-14 07:15:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:15:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:15:16 --> Utf8 Class Initialized
INFO - 2020-11-14 07:15:16 --> URI Class Initialized
INFO - 2020-11-14 07:15:16 --> Router Class Initialized
INFO - 2020-11-14 07:15:16 --> Output Class Initialized
INFO - 2020-11-14 07:15:16 --> Security Class Initialized
DEBUG - 2020-11-14 07:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:15:16 --> Input Class Initialized
INFO - 2020-11-14 07:15:16 --> Language Class Initialized
INFO - 2020-11-14 07:15:16 --> Loader Class Initialized
INFO - 2020-11-14 07:15:16 --> Helper loaded: url_helper
INFO - 2020-11-14 07:15:16 --> Database Driver Class Initialized
INFO - 2020-11-14 07:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:15:16 --> Email Class Initialized
INFO - 2020-11-14 07:15:16 --> Controller Class Initialized
DEBUG - 2020-11-14 07:15:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:15:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:15:16 --> Model Class Initialized
INFO - 2020-11-14 07:15:16 --> Model Class Initialized
INFO - 2020-11-14 07:15:16 --> Final output sent to browser
DEBUG - 2020-11-14 07:15:16 --> Total execution time: 0.0266
ERROR - 2020-11-14 07:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:17:02 --> Config Class Initialized
INFO - 2020-11-14 07:17:02 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:17:02 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:17:02 --> Utf8 Class Initialized
INFO - 2020-11-14 07:17:02 --> URI Class Initialized
INFO - 2020-11-14 07:17:02 --> Router Class Initialized
INFO - 2020-11-14 07:17:02 --> Output Class Initialized
INFO - 2020-11-14 07:17:02 --> Security Class Initialized
DEBUG - 2020-11-14 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:17:02 --> Input Class Initialized
INFO - 2020-11-14 07:17:02 --> Language Class Initialized
INFO - 2020-11-14 07:17:02 --> Loader Class Initialized
INFO - 2020-11-14 07:17:02 --> Helper loaded: url_helper
INFO - 2020-11-14 07:17:02 --> Database Driver Class Initialized
INFO - 2020-11-14 07:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:17:02 --> Email Class Initialized
INFO - 2020-11-14 07:17:02 --> Controller Class Initialized
DEBUG - 2020-11-14 07:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:17:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:17:02 --> Model Class Initialized
INFO - 2020-11-14 07:17:02 --> Model Class Initialized
INFO - 2020-11-14 07:17:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:17:02 --> Final output sent to browser
DEBUG - 2020-11-14 07:17:02 --> Total execution time: 0.0236
ERROR - 2020-11-14 07:17:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:17:02 --> Config Class Initialized
INFO - 2020-11-14 07:17:02 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:17:02 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:17:02 --> Utf8 Class Initialized
INFO - 2020-11-14 07:17:02 --> URI Class Initialized
INFO - 2020-11-14 07:17:02 --> Router Class Initialized
INFO - 2020-11-14 07:17:02 --> Output Class Initialized
INFO - 2020-11-14 07:17:02 --> Security Class Initialized
DEBUG - 2020-11-14 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:17:02 --> Input Class Initialized
INFO - 2020-11-14 07:17:02 --> Language Class Initialized
INFO - 2020-11-14 07:17:02 --> Loader Class Initialized
INFO - 2020-11-14 07:17:02 --> Helper loaded: url_helper
INFO - 2020-11-14 07:17:02 --> Database Driver Class Initialized
INFO - 2020-11-14 07:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:17:02 --> Email Class Initialized
INFO - 2020-11-14 07:17:02 --> Controller Class Initialized
DEBUG - 2020-11-14 07:17:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:17:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:17:02 --> Model Class Initialized
INFO - 2020-11-14 07:17:02 --> Model Class Initialized
INFO - 2020-11-14 07:17:02 --> Final output sent to browser
DEBUG - 2020-11-14 07:17:02 --> Total execution time: 0.0218
ERROR - 2020-11-14 07:17:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:17:07 --> Config Class Initialized
INFO - 2020-11-14 07:17:07 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:17:07 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:17:07 --> Utf8 Class Initialized
INFO - 2020-11-14 07:17:07 --> URI Class Initialized
INFO - 2020-11-14 07:17:07 --> Router Class Initialized
INFO - 2020-11-14 07:17:07 --> Output Class Initialized
INFO - 2020-11-14 07:17:07 --> Security Class Initialized
DEBUG - 2020-11-14 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:17:07 --> Input Class Initialized
INFO - 2020-11-14 07:17:07 --> Language Class Initialized
INFO - 2020-11-14 07:17:07 --> Loader Class Initialized
INFO - 2020-11-14 07:17:07 --> Helper loaded: url_helper
INFO - 2020-11-14 07:17:07 --> Database Driver Class Initialized
INFO - 2020-11-14 07:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:17:07 --> Email Class Initialized
INFO - 2020-11-14 07:17:07 --> Controller Class Initialized
DEBUG - 2020-11-14 07:17:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:17:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:17:07 --> Model Class Initialized
INFO - 2020-11-14 07:17:07 --> Model Class Initialized
ERROR - 2020-11-14 07:17:07 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 470
ERROR - 2020-11-14 07:17:07 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-14 07:17:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:17:09 --> Final output sent to browser
DEBUG - 2020-11-14 07:17:09 --> Total execution time: 2.3847
ERROR - 2020-11-14 07:17:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:17:10 --> Config Class Initialized
INFO - 2020-11-14 07:17:10 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:17:10 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:17:10 --> Utf8 Class Initialized
INFO - 2020-11-14 07:17:10 --> URI Class Initialized
INFO - 2020-11-14 07:17:10 --> Router Class Initialized
INFO - 2020-11-14 07:17:10 --> Output Class Initialized
INFO - 2020-11-14 07:17:10 --> Security Class Initialized
DEBUG - 2020-11-14 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:17:10 --> Input Class Initialized
INFO - 2020-11-14 07:17:10 --> Language Class Initialized
INFO - 2020-11-14 07:17:10 --> Loader Class Initialized
INFO - 2020-11-14 07:17:10 --> Helper loaded: url_helper
INFO - 2020-11-14 07:17:10 --> Database Driver Class Initialized
INFO - 2020-11-14 07:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:17:10 --> Email Class Initialized
INFO - 2020-11-14 07:17:10 --> Controller Class Initialized
DEBUG - 2020-11-14 07:17:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:17:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:17:10 --> Model Class Initialized
INFO - 2020-11-14 07:17:10 --> Model Class Initialized
INFO - 2020-11-14 07:17:10 --> Final output sent to browser
DEBUG - 2020-11-14 07:17:10 --> Total execution time: 0.0234
ERROR - 2020-11-14 07:29:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:29:16 --> Config Class Initialized
INFO - 2020-11-14 07:29:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:29:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:29:16 --> Utf8 Class Initialized
INFO - 2020-11-14 07:29:16 --> URI Class Initialized
INFO - 2020-11-14 07:29:16 --> Router Class Initialized
INFO - 2020-11-14 07:29:16 --> Output Class Initialized
INFO - 2020-11-14 07:29:16 --> Security Class Initialized
DEBUG - 2020-11-14 07:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:29:16 --> Input Class Initialized
INFO - 2020-11-14 07:29:16 --> Language Class Initialized
INFO - 2020-11-14 07:29:16 --> Loader Class Initialized
INFO - 2020-11-14 07:29:16 --> Helper loaded: url_helper
INFO - 2020-11-14 07:29:16 --> Database Driver Class Initialized
INFO - 2020-11-14 07:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:29:16 --> Email Class Initialized
INFO - 2020-11-14 07:29:16 --> Controller Class Initialized
DEBUG - 2020-11-14 07:29:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:29:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:29:16 --> Model Class Initialized
INFO - 2020-11-14 07:29:16 --> Model Class Initialized
INFO - 2020-11-14 07:29:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:29:16 --> Final output sent to browser
DEBUG - 2020-11-14 07:29:16 --> Total execution time: 0.0503
ERROR - 2020-11-14 07:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:29:17 --> Config Class Initialized
INFO - 2020-11-14 07:29:17 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:29:17 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:29:17 --> Utf8 Class Initialized
INFO - 2020-11-14 07:29:17 --> URI Class Initialized
INFO - 2020-11-14 07:29:17 --> Router Class Initialized
INFO - 2020-11-14 07:29:17 --> Output Class Initialized
INFO - 2020-11-14 07:29:17 --> Security Class Initialized
DEBUG - 2020-11-14 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:29:17 --> Input Class Initialized
INFO - 2020-11-14 07:29:17 --> Language Class Initialized
INFO - 2020-11-14 07:29:17 --> Loader Class Initialized
INFO - 2020-11-14 07:29:17 --> Helper loaded: url_helper
INFO - 2020-11-14 07:29:17 --> Database Driver Class Initialized
INFO - 2020-11-14 07:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:29:17 --> Email Class Initialized
INFO - 2020-11-14 07:29:17 --> Controller Class Initialized
DEBUG - 2020-11-14 07:29:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:29:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:29:17 --> Model Class Initialized
INFO - 2020-11-14 07:29:17 --> Model Class Initialized
INFO - 2020-11-14 07:29:17 --> Final output sent to browser
DEBUG - 2020-11-14 07:29:17 --> Total execution time: 0.0232
ERROR - 2020-11-14 07:29:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:29:20 --> Config Class Initialized
INFO - 2020-11-14 07:29:20 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:29:20 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:29:20 --> Utf8 Class Initialized
INFO - 2020-11-14 07:29:20 --> URI Class Initialized
INFO - 2020-11-14 07:29:20 --> Router Class Initialized
INFO - 2020-11-14 07:29:20 --> Output Class Initialized
INFO - 2020-11-14 07:29:20 --> Security Class Initialized
DEBUG - 2020-11-14 07:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:29:20 --> Input Class Initialized
INFO - 2020-11-14 07:29:20 --> Language Class Initialized
INFO - 2020-11-14 07:29:20 --> Loader Class Initialized
INFO - 2020-11-14 07:29:20 --> Helper loaded: url_helper
INFO - 2020-11-14 07:29:20 --> Database Driver Class Initialized
INFO - 2020-11-14 07:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:29:20 --> Email Class Initialized
INFO - 2020-11-14 07:29:20 --> Controller Class Initialized
DEBUG - 2020-11-14 07:29:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:29:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:29:20 --> Model Class Initialized
INFO - 2020-11-14 07:29:20 --> Model Class Initialized
ERROR - 2020-11-14 07:29:20 --> Severity: Runtime Notice --> Non-static method Purlem::get_results() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 471
ERROR - 2020-11-14 07:29:20 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 79
INFO - 2020-11-14 07:29:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:29:22 --> Final output sent to browser
DEBUG - 2020-11-14 07:29:22 --> Total execution time: 2.1855
ERROR - 2020-11-14 07:29:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:29:22 --> Config Class Initialized
INFO - 2020-11-14 07:29:22 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:29:23 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:29:23 --> Utf8 Class Initialized
INFO - 2020-11-14 07:29:23 --> URI Class Initialized
INFO - 2020-11-14 07:29:23 --> Router Class Initialized
INFO - 2020-11-14 07:29:23 --> Output Class Initialized
INFO - 2020-11-14 07:29:23 --> Security Class Initialized
DEBUG - 2020-11-14 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:29:23 --> Input Class Initialized
INFO - 2020-11-14 07:29:23 --> Language Class Initialized
INFO - 2020-11-14 07:29:23 --> Loader Class Initialized
INFO - 2020-11-14 07:29:23 --> Helper loaded: url_helper
INFO - 2020-11-14 07:29:23 --> Database Driver Class Initialized
INFO - 2020-11-14 07:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:29:23 --> Email Class Initialized
INFO - 2020-11-14 07:29:23 --> Controller Class Initialized
DEBUG - 2020-11-14 07:29:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:29:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:29:23 --> Model Class Initialized
INFO - 2020-11-14 07:29:23 --> Model Class Initialized
INFO - 2020-11-14 07:29:23 --> Final output sent to browser
DEBUG - 2020-11-14 07:29:23 --> Total execution time: 0.0229
ERROR - 2020-11-14 07:30:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:06 --> Config Class Initialized
INFO - 2020-11-14 07:30:06 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:06 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:06 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:06 --> URI Class Initialized
INFO - 2020-11-14 07:30:06 --> Router Class Initialized
INFO - 2020-11-14 07:30:06 --> Output Class Initialized
INFO - 2020-11-14 07:30:06 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:06 --> Input Class Initialized
INFO - 2020-11-14 07:30:06 --> Language Class Initialized
INFO - 2020-11-14 07:30:07 --> Loader Class Initialized
INFO - 2020-11-14 07:30:07 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:07 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:07 --> Email Class Initialized
INFO - 2020-11-14 07:30:07 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:07 --> Model Class Initialized
INFO - 2020-11-14 07:30:07 --> Model Class Initialized
INFO - 2020-11-14 07:30:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:30:07 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:07 --> Total execution time: 0.0226
ERROR - 2020-11-14 07:30:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:07 --> Config Class Initialized
INFO - 2020-11-14 07:30:07 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:07 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:07 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:07 --> URI Class Initialized
INFO - 2020-11-14 07:30:07 --> Router Class Initialized
INFO - 2020-11-14 07:30:07 --> Output Class Initialized
INFO - 2020-11-14 07:30:07 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:07 --> Input Class Initialized
INFO - 2020-11-14 07:30:07 --> Language Class Initialized
INFO - 2020-11-14 07:30:07 --> Loader Class Initialized
INFO - 2020-11-14 07:30:07 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:07 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:07 --> Email Class Initialized
INFO - 2020-11-14 07:30:07 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:07 --> Model Class Initialized
INFO - 2020-11-14 07:30:07 --> Model Class Initialized
INFO - 2020-11-14 07:30:07 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:07 --> Total execution time: 0.0236
ERROR - 2020-11-14 07:30:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:10 --> Config Class Initialized
INFO - 2020-11-14 07:30:10 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:10 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:10 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:10 --> URI Class Initialized
INFO - 2020-11-14 07:30:10 --> Router Class Initialized
INFO - 2020-11-14 07:30:10 --> Output Class Initialized
INFO - 2020-11-14 07:30:10 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:10 --> Input Class Initialized
INFO - 2020-11-14 07:30:10 --> Language Class Initialized
INFO - 2020-11-14 07:30:10 --> Loader Class Initialized
INFO - 2020-11-14 07:30:10 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:10 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:10 --> Email Class Initialized
INFO - 2020-11-14 07:30:10 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:10 --> Model Class Initialized
INFO - 2020-11-14 07:30:10 --> Model Class Initialized
INFO - 2020-11-14 07:30:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:30:12 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:12 --> Total execution time: 2.1933
ERROR - 2020-11-14 07:30:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:13 --> Config Class Initialized
INFO - 2020-11-14 07:30:13 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:13 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:13 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:13 --> URI Class Initialized
INFO - 2020-11-14 07:30:13 --> Router Class Initialized
INFO - 2020-11-14 07:30:13 --> Output Class Initialized
INFO - 2020-11-14 07:30:13 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:13 --> Input Class Initialized
INFO - 2020-11-14 07:30:13 --> Language Class Initialized
INFO - 2020-11-14 07:30:13 --> Loader Class Initialized
INFO - 2020-11-14 07:30:13 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:13 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:13 --> Email Class Initialized
INFO - 2020-11-14 07:30:13 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:13 --> Model Class Initialized
INFO - 2020-11-14 07:30:13 --> Model Class Initialized
INFO - 2020-11-14 07:30:13 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:13 --> Total execution time: 0.0235
ERROR - 2020-11-14 07:30:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:36 --> Config Class Initialized
INFO - 2020-11-14 07:30:36 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:36 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:36 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:36 --> URI Class Initialized
INFO - 2020-11-14 07:30:36 --> Router Class Initialized
INFO - 2020-11-14 07:30:36 --> Output Class Initialized
INFO - 2020-11-14 07:30:36 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:36 --> Input Class Initialized
INFO - 2020-11-14 07:30:36 --> Language Class Initialized
INFO - 2020-11-14 07:30:36 --> Loader Class Initialized
INFO - 2020-11-14 07:30:36 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:36 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:36 --> Email Class Initialized
INFO - 2020-11-14 07:30:36 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:36 --> Model Class Initialized
INFO - 2020-11-14 07:30:36 --> Model Class Initialized
INFO - 2020-11-14 07:30:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:30:36 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:36 --> Total execution time: 0.0246
ERROR - 2020-11-14 07:30:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:50 --> Config Class Initialized
INFO - 2020-11-14 07:30:50 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:50 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:50 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:50 --> URI Class Initialized
INFO - 2020-11-14 07:30:50 --> Router Class Initialized
INFO - 2020-11-14 07:30:50 --> Output Class Initialized
INFO - 2020-11-14 07:30:50 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:50 --> Input Class Initialized
INFO - 2020-11-14 07:30:50 --> Language Class Initialized
INFO - 2020-11-14 07:30:50 --> Loader Class Initialized
INFO - 2020-11-14 07:30:50 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:50 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:50 --> Email Class Initialized
INFO - 2020-11-14 07:30:50 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:50 --> Model Class Initialized
INFO - 2020-11-14 07:30:50 --> Model Class Initialized
ERROR - 2020-11-14 07:30:50 --> Severity: Runtime Notice --> Non-static method Purlem::get_all_campaigns() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 406
ERROR - 2020-11-14 07:30:50 --> Severity: Runtime Notice --> Non-static method Purlem::_curlRequest() should not be called statically, assuming $this from incompatible context /home/purpu1ex/public_html/carsm/application/libraries/purlapi.php 47
INFO - 2020-11-14 07:30:51 --> Model Class Initialized
INFO - 2020-11-14 07:30:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:30:51 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:51 --> Total execution time: 1.1696
ERROR - 2020-11-14 07:30:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:30:56 --> Config Class Initialized
INFO - 2020-11-14 07:30:56 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:30:56 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:30:56 --> Utf8 Class Initialized
INFO - 2020-11-14 07:30:56 --> URI Class Initialized
INFO - 2020-11-14 07:30:56 --> Router Class Initialized
INFO - 2020-11-14 07:30:56 --> Output Class Initialized
INFO - 2020-11-14 07:30:56 --> Security Class Initialized
DEBUG - 2020-11-14 07:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:30:56 --> Input Class Initialized
INFO - 2020-11-14 07:30:56 --> Language Class Initialized
INFO - 2020-11-14 07:30:56 --> Loader Class Initialized
INFO - 2020-11-14 07:30:56 --> Helper loaded: url_helper
INFO - 2020-11-14 07:30:56 --> Database Driver Class Initialized
INFO - 2020-11-14 07:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:30:56 --> Email Class Initialized
INFO - 2020-11-14 07:30:56 --> Controller Class Initialized
DEBUG - 2020-11-14 07:30:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:30:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:30:56 --> Model Class Initialized
INFO - 2020-11-14 07:30:56 --> Model Class Initialized
INFO - 2020-11-14 07:30:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:30:56 --> Final output sent to browser
DEBUG - 2020-11-14 07:30:56 --> Total execution time: 0.0285
ERROR - 2020-11-14 07:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:31:57 --> Config Class Initialized
INFO - 2020-11-14 07:31:57 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:31:57 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:31:57 --> Utf8 Class Initialized
INFO - 2020-11-14 07:31:57 --> URI Class Initialized
INFO - 2020-11-14 07:31:57 --> Router Class Initialized
INFO - 2020-11-14 07:31:57 --> Output Class Initialized
INFO - 2020-11-14 07:31:57 --> Security Class Initialized
DEBUG - 2020-11-14 07:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:31:57 --> Input Class Initialized
INFO - 2020-11-14 07:31:57 --> Language Class Initialized
INFO - 2020-11-14 07:31:57 --> Loader Class Initialized
INFO - 2020-11-14 07:31:57 --> Helper loaded: url_helper
INFO - 2020-11-14 07:31:57 --> Database Driver Class Initialized
INFO - 2020-11-14 07:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:31:57 --> Email Class Initialized
INFO - 2020-11-14 07:31:57 --> Controller Class Initialized
DEBUG - 2020-11-14 07:31:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:31:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:31:57 --> Model Class Initialized
INFO - 2020-11-14 07:31:57 --> Model Class Initialized
INFO - 2020-11-14 07:31:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:31:57 --> Final output sent to browser
DEBUG - 2020-11-14 07:31:57 --> Total execution time: 0.3138
ERROR - 2020-11-14 07:31:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:31:58 --> Config Class Initialized
INFO - 2020-11-14 07:31:58 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:31:58 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:31:58 --> Utf8 Class Initialized
INFO - 2020-11-14 07:31:58 --> URI Class Initialized
INFO - 2020-11-14 07:31:58 --> Router Class Initialized
INFO - 2020-11-14 07:31:58 --> Output Class Initialized
INFO - 2020-11-14 07:31:58 --> Security Class Initialized
DEBUG - 2020-11-14 07:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:31:58 --> Input Class Initialized
INFO - 2020-11-14 07:31:58 --> Language Class Initialized
INFO - 2020-11-14 07:31:58 --> Loader Class Initialized
INFO - 2020-11-14 07:31:58 --> Helper loaded: url_helper
INFO - 2020-11-14 07:31:58 --> Database Driver Class Initialized
INFO - 2020-11-14 07:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:31:58 --> Email Class Initialized
INFO - 2020-11-14 07:31:58 --> Controller Class Initialized
DEBUG - 2020-11-14 07:31:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:31:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:31:58 --> Model Class Initialized
INFO - 2020-11-14 07:31:58 --> Model Class Initialized
INFO - 2020-11-14 07:31:58 --> Final output sent to browser
DEBUG - 2020-11-14 07:31:58 --> Total execution time: 0.3699
ERROR - 2020-11-14 07:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:32:02 --> Config Class Initialized
INFO - 2020-11-14 07:32:02 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:32:02 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:32:02 --> Utf8 Class Initialized
INFO - 2020-11-14 07:32:02 --> URI Class Initialized
INFO - 2020-11-14 07:32:02 --> Router Class Initialized
INFO - 2020-11-14 07:32:02 --> Output Class Initialized
INFO - 2020-11-14 07:32:02 --> Security Class Initialized
DEBUG - 2020-11-14 07:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:32:02 --> Input Class Initialized
INFO - 2020-11-14 07:32:02 --> Language Class Initialized
INFO - 2020-11-14 07:32:02 --> Loader Class Initialized
INFO - 2020-11-14 07:32:02 --> Helper loaded: url_helper
INFO - 2020-11-14 07:32:02 --> Database Driver Class Initialized
INFO - 2020-11-14 07:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:32:02 --> Email Class Initialized
INFO - 2020-11-14 07:32:02 --> Controller Class Initialized
DEBUG - 2020-11-14 07:32:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:32:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:32:02 --> Model Class Initialized
INFO - 2020-11-14 07:32:02 --> Model Class Initialized
INFO - 2020-11-14 07:32:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:32:04 --> Final output sent to browser
DEBUG - 2020-11-14 07:32:04 --> Total execution time: 1.4635
ERROR - 2020-11-14 07:32:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:32:04 --> Config Class Initialized
INFO - 2020-11-14 07:32:04 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:32:04 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:32:04 --> Utf8 Class Initialized
INFO - 2020-11-14 07:32:04 --> URI Class Initialized
INFO - 2020-11-14 07:32:04 --> Router Class Initialized
INFO - 2020-11-14 07:32:04 --> Output Class Initialized
INFO - 2020-11-14 07:32:04 --> Security Class Initialized
DEBUG - 2020-11-14 07:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:32:04 --> Input Class Initialized
INFO - 2020-11-14 07:32:04 --> Language Class Initialized
INFO - 2020-11-14 07:32:04 --> Loader Class Initialized
INFO - 2020-11-14 07:32:04 --> Helper loaded: url_helper
INFO - 2020-11-14 07:32:04 --> Database Driver Class Initialized
INFO - 2020-11-14 07:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:32:04 --> Email Class Initialized
INFO - 2020-11-14 07:32:04 --> Controller Class Initialized
DEBUG - 2020-11-14 07:32:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:32:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:32:04 --> Model Class Initialized
INFO - 2020-11-14 07:32:04 --> Model Class Initialized
INFO - 2020-11-14 07:32:04 --> Final output sent to browser
DEBUG - 2020-11-14 07:32:04 --> Total execution time: 0.0278
ERROR - 2020-11-14 07:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:40:16 --> Config Class Initialized
INFO - 2020-11-14 07:40:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:40:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:40:16 --> Utf8 Class Initialized
INFO - 2020-11-14 07:40:16 --> URI Class Initialized
INFO - 2020-11-14 07:40:16 --> Router Class Initialized
INFO - 2020-11-14 07:40:16 --> Output Class Initialized
INFO - 2020-11-14 07:40:16 --> Security Class Initialized
DEBUG - 2020-11-14 07:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:40:16 --> Input Class Initialized
INFO - 2020-11-14 07:40:16 --> Language Class Initialized
INFO - 2020-11-14 07:40:16 --> Loader Class Initialized
INFO - 2020-11-14 07:40:16 --> Helper loaded: url_helper
INFO - 2020-11-14 07:40:16 --> Database Driver Class Initialized
INFO - 2020-11-14 07:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:40:16 --> Email Class Initialized
INFO - 2020-11-14 07:40:16 --> Controller Class Initialized
DEBUG - 2020-11-14 07:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:40:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:40:16 --> Model Class Initialized
INFO - 2020-11-14 07:40:16 --> Model Class Initialized
INFO - 2020-11-14 07:40:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:40:16 --> Final output sent to browser
DEBUG - 2020-11-14 07:40:16 --> Total execution time: 0.0458
ERROR - 2020-11-14 07:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:40:16 --> Config Class Initialized
INFO - 2020-11-14 07:40:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:40:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:40:16 --> Utf8 Class Initialized
INFO - 2020-11-14 07:40:16 --> URI Class Initialized
INFO - 2020-11-14 07:40:16 --> Router Class Initialized
INFO - 2020-11-14 07:40:16 --> Output Class Initialized
INFO - 2020-11-14 07:40:16 --> Security Class Initialized
DEBUG - 2020-11-14 07:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:40:16 --> Input Class Initialized
INFO - 2020-11-14 07:40:16 --> Language Class Initialized
INFO - 2020-11-14 07:40:16 --> Loader Class Initialized
INFO - 2020-11-14 07:40:16 --> Helper loaded: url_helper
INFO - 2020-11-14 07:40:16 --> Database Driver Class Initialized
INFO - 2020-11-14 07:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:40:16 --> Email Class Initialized
INFO - 2020-11-14 07:40:16 --> Controller Class Initialized
DEBUG - 2020-11-14 07:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:40:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:40:16 --> Model Class Initialized
INFO - 2020-11-14 07:40:16 --> Model Class Initialized
INFO - 2020-11-14 07:40:16 --> Final output sent to browser
DEBUG - 2020-11-14 07:40:16 --> Total execution time: 0.0228
ERROR - 2020-11-14 07:40:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:40:21 --> Config Class Initialized
INFO - 2020-11-14 07:40:21 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:40:21 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:40:21 --> Utf8 Class Initialized
INFO - 2020-11-14 07:40:21 --> URI Class Initialized
INFO - 2020-11-14 07:40:21 --> Router Class Initialized
INFO - 2020-11-14 07:40:21 --> Output Class Initialized
INFO - 2020-11-14 07:40:21 --> Security Class Initialized
DEBUG - 2020-11-14 07:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:40:21 --> Input Class Initialized
INFO - 2020-11-14 07:40:21 --> Language Class Initialized
INFO - 2020-11-14 07:40:21 --> Loader Class Initialized
INFO - 2020-11-14 07:40:21 --> Helper loaded: url_helper
INFO - 2020-11-14 07:40:21 --> Database Driver Class Initialized
INFO - 2020-11-14 07:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:40:21 --> Email Class Initialized
INFO - 2020-11-14 07:40:21 --> Controller Class Initialized
DEBUG - 2020-11-14 07:40:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:40:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:40:21 --> Model Class Initialized
INFO - 2020-11-14 07:40:21 --> Model Class Initialized
INFO - 2020-11-14 07:40:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:40:23 --> Final output sent to browser
DEBUG - 2020-11-14 07:40:23 --> Total execution time: 1.8771
ERROR - 2020-11-14 07:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:40:23 --> Config Class Initialized
INFO - 2020-11-14 07:40:23 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:40:23 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:40:23 --> Utf8 Class Initialized
INFO - 2020-11-14 07:40:23 --> URI Class Initialized
INFO - 2020-11-14 07:40:23 --> Router Class Initialized
INFO - 2020-11-14 07:40:23 --> Output Class Initialized
INFO - 2020-11-14 07:40:23 --> Security Class Initialized
DEBUG - 2020-11-14 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:40:23 --> Input Class Initialized
INFO - 2020-11-14 07:40:23 --> Language Class Initialized
INFO - 2020-11-14 07:40:23 --> Loader Class Initialized
INFO - 2020-11-14 07:40:23 --> Helper loaded: url_helper
INFO - 2020-11-14 07:40:23 --> Database Driver Class Initialized
INFO - 2020-11-14 07:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:40:23 --> Email Class Initialized
INFO - 2020-11-14 07:40:23 --> Controller Class Initialized
DEBUG - 2020-11-14 07:40:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:40:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:40:23 --> Model Class Initialized
INFO - 2020-11-14 07:40:23 --> Model Class Initialized
INFO - 2020-11-14 07:40:23 --> Final output sent to browser
DEBUG - 2020-11-14 07:40:23 --> Total execution time: 0.0240
ERROR - 2020-11-14 07:40:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:40:56 --> Config Class Initialized
INFO - 2020-11-14 07:40:56 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:40:56 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:40:56 --> Utf8 Class Initialized
INFO - 2020-11-14 07:40:56 --> URI Class Initialized
INFO - 2020-11-14 07:40:56 --> Router Class Initialized
INFO - 2020-11-14 07:40:56 --> Output Class Initialized
INFO - 2020-11-14 07:40:56 --> Security Class Initialized
DEBUG - 2020-11-14 07:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:40:56 --> Input Class Initialized
INFO - 2020-11-14 07:40:56 --> Language Class Initialized
INFO - 2020-11-14 07:40:56 --> Loader Class Initialized
INFO - 2020-11-14 07:40:56 --> Helper loaded: url_helper
INFO - 2020-11-14 07:40:56 --> Database Driver Class Initialized
INFO - 2020-11-14 07:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:40:56 --> Email Class Initialized
INFO - 2020-11-14 07:40:56 --> Controller Class Initialized
DEBUG - 2020-11-14 07:40:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:40:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:40:56 --> Model Class Initialized
INFO - 2020-11-14 07:40:56 --> Model Class Initialized
INFO - 2020-11-14 07:40:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:40:56 --> Final output sent to browser
DEBUG - 2020-11-14 07:40:56 --> Total execution time: 0.0273
ERROR - 2020-11-14 07:49:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:49:37 --> Config Class Initialized
INFO - 2020-11-14 07:49:37 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:49:37 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:49:37 --> Utf8 Class Initialized
INFO - 2020-11-14 07:49:37 --> URI Class Initialized
INFO - 2020-11-14 07:49:37 --> Router Class Initialized
INFO - 2020-11-14 07:49:37 --> Output Class Initialized
INFO - 2020-11-14 07:49:37 --> Security Class Initialized
DEBUG - 2020-11-14 07:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:49:37 --> Input Class Initialized
INFO - 2020-11-14 07:49:37 --> Language Class Initialized
INFO - 2020-11-14 07:49:37 --> Loader Class Initialized
INFO - 2020-11-14 07:49:37 --> Helper loaded: url_helper
INFO - 2020-11-14 07:49:37 --> Database Driver Class Initialized
INFO - 2020-11-14 07:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:49:37 --> Email Class Initialized
INFO - 2020-11-14 07:49:37 --> Controller Class Initialized
DEBUG - 2020-11-14 07:49:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:49:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:49:37 --> Model Class Initialized
INFO - 2020-11-14 07:49:37 --> Model Class Initialized
INFO - 2020-11-14 07:49:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:49:37 --> Final output sent to browser
DEBUG - 2020-11-14 07:49:37 --> Total execution time: 0.0472
ERROR - 2020-11-14 07:49:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:49:40 --> Config Class Initialized
INFO - 2020-11-14 07:49:40 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:49:40 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:49:40 --> Utf8 Class Initialized
INFO - 2020-11-14 07:49:40 --> URI Class Initialized
INFO - 2020-11-14 07:49:40 --> Router Class Initialized
INFO - 2020-11-14 07:49:40 --> Output Class Initialized
INFO - 2020-11-14 07:49:40 --> Security Class Initialized
DEBUG - 2020-11-14 07:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:49:40 --> Input Class Initialized
INFO - 2020-11-14 07:49:40 --> Language Class Initialized
INFO - 2020-11-14 07:49:40 --> Loader Class Initialized
INFO - 2020-11-14 07:49:40 --> Helper loaded: url_helper
INFO - 2020-11-14 07:49:40 --> Database Driver Class Initialized
INFO - 2020-11-14 07:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:49:40 --> Email Class Initialized
INFO - 2020-11-14 07:49:40 --> Controller Class Initialized
DEBUG - 2020-11-14 07:49:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:49:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:49:40 --> Model Class Initialized
INFO - 2020-11-14 07:49:40 --> Model Class Initialized
INFO - 2020-11-14 07:49:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:49:40 --> Final output sent to browser
DEBUG - 2020-11-14 07:49:40 --> Total execution time: 0.0180
ERROR - 2020-11-14 07:49:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:49:41 --> Config Class Initialized
INFO - 2020-11-14 07:49:41 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:49:41 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:49:41 --> Utf8 Class Initialized
INFO - 2020-11-14 07:49:41 --> URI Class Initialized
INFO - 2020-11-14 07:49:41 --> Router Class Initialized
INFO - 2020-11-14 07:49:41 --> Output Class Initialized
INFO - 2020-11-14 07:49:41 --> Security Class Initialized
DEBUG - 2020-11-14 07:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:49:41 --> Input Class Initialized
INFO - 2020-11-14 07:49:41 --> Language Class Initialized
INFO - 2020-11-14 07:49:41 --> Loader Class Initialized
INFO - 2020-11-14 07:49:41 --> Helper loaded: url_helper
INFO - 2020-11-14 07:49:41 --> Database Driver Class Initialized
INFO - 2020-11-14 07:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:49:41 --> Email Class Initialized
INFO - 2020-11-14 07:49:41 --> Controller Class Initialized
DEBUG - 2020-11-14 07:49:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:49:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:49:41 --> Model Class Initialized
INFO - 2020-11-14 07:49:41 --> Model Class Initialized
INFO - 2020-11-14 07:49:41 --> Final output sent to browser
DEBUG - 2020-11-14 07:49:41 --> Total execution time: 0.0207
ERROR - 2020-11-14 07:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:50:09 --> Config Class Initialized
INFO - 2020-11-14 07:50:09 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:50:09 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:50:09 --> Utf8 Class Initialized
INFO - 2020-11-14 07:50:09 --> URI Class Initialized
INFO - 2020-11-14 07:50:09 --> Router Class Initialized
INFO - 2020-11-14 07:50:09 --> Output Class Initialized
INFO - 2020-11-14 07:50:09 --> Security Class Initialized
DEBUG - 2020-11-14 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:50:09 --> Input Class Initialized
INFO - 2020-11-14 07:50:09 --> Language Class Initialized
INFO - 2020-11-14 07:50:09 --> Loader Class Initialized
INFO - 2020-11-14 07:50:09 --> Helper loaded: url_helper
INFO - 2020-11-14 07:50:09 --> Database Driver Class Initialized
INFO - 2020-11-14 07:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:50:09 --> Email Class Initialized
INFO - 2020-11-14 07:50:09 --> Controller Class Initialized
DEBUG - 2020-11-14 07:50:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:50:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:50:09 --> Model Class Initialized
INFO - 2020-11-14 07:50:09 --> Model Class Initialized
INFO - 2020-11-14 07:50:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:50:09 --> Final output sent to browser
DEBUG - 2020-11-14 07:50:09 --> Total execution time: 0.0220
ERROR - 2020-11-14 07:50:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:50:10 --> Config Class Initialized
INFO - 2020-11-14 07:50:10 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:50:10 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:50:10 --> Utf8 Class Initialized
INFO - 2020-11-14 07:50:10 --> URI Class Initialized
INFO - 2020-11-14 07:50:10 --> Router Class Initialized
INFO - 2020-11-14 07:50:10 --> Output Class Initialized
INFO - 2020-11-14 07:50:10 --> Security Class Initialized
DEBUG - 2020-11-14 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:50:10 --> Input Class Initialized
INFO - 2020-11-14 07:50:10 --> Language Class Initialized
INFO - 2020-11-14 07:50:10 --> Loader Class Initialized
INFO - 2020-11-14 07:50:10 --> Helper loaded: url_helper
INFO - 2020-11-14 07:50:10 --> Database Driver Class Initialized
INFO - 2020-11-14 07:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:50:10 --> Email Class Initialized
INFO - 2020-11-14 07:50:10 --> Controller Class Initialized
DEBUG - 2020-11-14 07:50:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:50:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:50:10 --> Model Class Initialized
INFO - 2020-11-14 07:50:10 --> Model Class Initialized
INFO - 2020-11-14 07:50:10 --> Final output sent to browser
DEBUG - 2020-11-14 07:50:10 --> Total execution time: 0.0237
ERROR - 2020-11-14 07:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:51:00 --> Config Class Initialized
INFO - 2020-11-14 07:51:00 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:51:00 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:51:00 --> Utf8 Class Initialized
INFO - 2020-11-14 07:51:00 --> URI Class Initialized
INFO - 2020-11-14 07:51:00 --> Router Class Initialized
INFO - 2020-11-14 07:51:00 --> Output Class Initialized
INFO - 2020-11-14 07:51:00 --> Security Class Initialized
DEBUG - 2020-11-14 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:51:00 --> Input Class Initialized
INFO - 2020-11-14 07:51:00 --> Language Class Initialized
INFO - 2020-11-14 07:51:00 --> Loader Class Initialized
INFO - 2020-11-14 07:51:00 --> Helper loaded: url_helper
INFO - 2020-11-14 07:51:00 --> Database Driver Class Initialized
INFO - 2020-11-14 07:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:51:00 --> Email Class Initialized
INFO - 2020-11-14 07:51:00 --> Controller Class Initialized
DEBUG - 2020-11-14 07:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:51:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:51:00 --> Model Class Initialized
INFO - 2020-11-14 07:51:00 --> Model Class Initialized
INFO - 2020-11-14 07:51:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:51:00 --> Final output sent to browser
DEBUG - 2020-11-14 07:51:00 --> Total execution time: 0.0323
ERROR - 2020-11-14 07:51:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:51:00 --> Config Class Initialized
INFO - 2020-11-14 07:51:00 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:51:00 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:51:00 --> Utf8 Class Initialized
INFO - 2020-11-14 07:51:00 --> URI Class Initialized
INFO - 2020-11-14 07:51:00 --> Router Class Initialized
INFO - 2020-11-14 07:51:00 --> Output Class Initialized
INFO - 2020-11-14 07:51:00 --> Security Class Initialized
DEBUG - 2020-11-14 07:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:51:00 --> Input Class Initialized
INFO - 2020-11-14 07:51:00 --> Language Class Initialized
INFO - 2020-11-14 07:51:00 --> Loader Class Initialized
INFO - 2020-11-14 07:51:00 --> Helper loaded: url_helper
INFO - 2020-11-14 07:51:00 --> Database Driver Class Initialized
INFO - 2020-11-14 07:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:51:00 --> Email Class Initialized
INFO - 2020-11-14 07:51:00 --> Controller Class Initialized
DEBUG - 2020-11-14 07:51:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:51:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:51:00 --> Model Class Initialized
INFO - 2020-11-14 07:51:00 --> Model Class Initialized
INFO - 2020-11-14 07:51:00 --> Final output sent to browser
DEBUG - 2020-11-14 07:51:00 --> Total execution time: 0.0220
ERROR - 2020-11-14 07:51:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:51:36 --> Config Class Initialized
INFO - 2020-11-14 07:51:36 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:51:36 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:51:36 --> Utf8 Class Initialized
INFO - 2020-11-14 07:51:36 --> URI Class Initialized
INFO - 2020-11-14 07:51:36 --> Router Class Initialized
INFO - 2020-11-14 07:51:36 --> Output Class Initialized
INFO - 2020-11-14 07:51:36 --> Security Class Initialized
DEBUG - 2020-11-14 07:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:51:36 --> Input Class Initialized
INFO - 2020-11-14 07:51:36 --> Language Class Initialized
INFO - 2020-11-14 07:51:36 --> Loader Class Initialized
INFO - 2020-11-14 07:51:36 --> Helper loaded: url_helper
INFO - 2020-11-14 07:51:36 --> Database Driver Class Initialized
INFO - 2020-11-14 07:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:51:36 --> Email Class Initialized
INFO - 2020-11-14 07:51:36 --> Controller Class Initialized
DEBUG - 2020-11-14 07:51:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:51:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:51:36 --> Model Class Initialized
INFO - 2020-11-14 07:51:36 --> Model Class Initialized
INFO - 2020-11-14 07:51:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:51:36 --> Final output sent to browser
DEBUG - 2020-11-14 07:51:36 --> Total execution time: 0.0272
ERROR - 2020-11-14 07:51:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:51:37 --> Config Class Initialized
INFO - 2020-11-14 07:51:37 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:51:37 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:51:37 --> Utf8 Class Initialized
INFO - 2020-11-14 07:51:37 --> URI Class Initialized
INFO - 2020-11-14 07:51:37 --> Router Class Initialized
INFO - 2020-11-14 07:51:37 --> Output Class Initialized
INFO - 2020-11-14 07:51:37 --> Security Class Initialized
DEBUG - 2020-11-14 07:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:51:37 --> Input Class Initialized
INFO - 2020-11-14 07:51:37 --> Language Class Initialized
INFO - 2020-11-14 07:51:37 --> Loader Class Initialized
INFO - 2020-11-14 07:51:37 --> Helper loaded: url_helper
INFO - 2020-11-14 07:51:37 --> Database Driver Class Initialized
INFO - 2020-11-14 07:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:51:37 --> Email Class Initialized
INFO - 2020-11-14 07:51:37 --> Controller Class Initialized
DEBUG - 2020-11-14 07:51:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:51:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:51:37 --> Model Class Initialized
INFO - 2020-11-14 07:51:37 --> Model Class Initialized
INFO - 2020-11-14 07:51:37 --> Final output sent to browser
DEBUG - 2020-11-14 07:51:37 --> Total execution time: 0.0204
ERROR - 2020-11-14 07:55:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:04 --> Config Class Initialized
INFO - 2020-11-14 07:55:04 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:04 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:04 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:04 --> URI Class Initialized
INFO - 2020-11-14 07:55:04 --> Router Class Initialized
INFO - 2020-11-14 07:55:04 --> Output Class Initialized
INFO - 2020-11-14 07:55:04 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:04 --> Input Class Initialized
INFO - 2020-11-14 07:55:04 --> Language Class Initialized
INFO - 2020-11-14 07:55:04 --> Loader Class Initialized
INFO - 2020-11-14 07:55:04 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:04 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:04 --> Email Class Initialized
INFO - 2020-11-14 07:55:04 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:04 --> Model Class Initialized
INFO - 2020-11-14 07:55:04 --> Model Class Initialized
INFO - 2020-11-14 07:55:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:55:04 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:04 --> Total execution time: 0.0323
ERROR - 2020-11-14 07:55:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:05 --> Config Class Initialized
INFO - 2020-11-14 07:55:05 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:05 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:05 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:05 --> URI Class Initialized
INFO - 2020-11-14 07:55:05 --> Router Class Initialized
INFO - 2020-11-14 07:55:05 --> Output Class Initialized
INFO - 2020-11-14 07:55:05 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:05 --> Input Class Initialized
INFO - 2020-11-14 07:55:05 --> Language Class Initialized
INFO - 2020-11-14 07:55:05 --> Loader Class Initialized
INFO - 2020-11-14 07:55:05 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:05 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:05 --> Email Class Initialized
INFO - 2020-11-14 07:55:05 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:05 --> Model Class Initialized
INFO - 2020-11-14 07:55:05 --> Model Class Initialized
INFO - 2020-11-14 07:55:05 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:05 --> Total execution time: 0.0216
ERROR - 2020-11-14 07:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:07 --> Config Class Initialized
INFO - 2020-11-14 07:55:07 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:07 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:07 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:07 --> URI Class Initialized
INFO - 2020-11-14 07:55:07 --> Router Class Initialized
INFO - 2020-11-14 07:55:07 --> Output Class Initialized
INFO - 2020-11-14 07:55:07 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:07 --> Input Class Initialized
INFO - 2020-11-14 07:55:07 --> Language Class Initialized
INFO - 2020-11-14 07:55:07 --> Loader Class Initialized
INFO - 2020-11-14 07:55:07 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:07 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:07 --> Email Class Initialized
INFO - 2020-11-14 07:55:07 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:07 --> Model Class Initialized
INFO - 2020-11-14 07:55:07 --> Model Class Initialized
INFO - 2020-11-14 07:55:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:55:13 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:13 --> Total execution time: 6.4388
ERROR - 2020-11-14 07:55:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:14 --> Config Class Initialized
INFO - 2020-11-14 07:55:14 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:14 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:14 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:14 --> URI Class Initialized
INFO - 2020-11-14 07:55:14 --> Router Class Initialized
INFO - 2020-11-14 07:55:14 --> Output Class Initialized
INFO - 2020-11-14 07:55:14 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:14 --> Input Class Initialized
INFO - 2020-11-14 07:55:14 --> Language Class Initialized
INFO - 2020-11-14 07:55:14 --> Loader Class Initialized
INFO - 2020-11-14 07:55:14 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:14 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:14 --> Email Class Initialized
INFO - 2020-11-14 07:55:14 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:14 --> Model Class Initialized
INFO - 2020-11-14 07:55:14 --> Model Class Initialized
INFO - 2020-11-14 07:55:14 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:14 --> Total execution time: 0.0272
ERROR - 2020-11-14 07:55:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:39 --> Config Class Initialized
INFO - 2020-11-14 07:55:39 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:39 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:39 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:39 --> URI Class Initialized
INFO - 2020-11-14 07:55:39 --> Router Class Initialized
INFO - 2020-11-14 07:55:39 --> Output Class Initialized
INFO - 2020-11-14 07:55:39 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:39 --> Input Class Initialized
INFO - 2020-11-14 07:55:39 --> Language Class Initialized
INFO - 2020-11-14 07:55:39 --> Loader Class Initialized
INFO - 2020-11-14 07:55:39 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:39 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:39 --> Email Class Initialized
INFO - 2020-11-14 07:55:39 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:39 --> Model Class Initialized
INFO - 2020-11-14 07:55:39 --> Model Class Initialized
INFO - 2020-11-14 07:55:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:55:39 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:39 --> Total execution time: 0.0396
ERROR - 2020-11-14 07:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:43 --> Config Class Initialized
INFO - 2020-11-14 07:55:43 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:43 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:43 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:43 --> URI Class Initialized
INFO - 2020-11-14 07:55:43 --> Router Class Initialized
INFO - 2020-11-14 07:55:43 --> Output Class Initialized
INFO - 2020-11-14 07:55:43 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:43 --> Input Class Initialized
INFO - 2020-11-14 07:55:43 --> Language Class Initialized
INFO - 2020-11-14 07:55:43 --> Loader Class Initialized
INFO - 2020-11-14 07:55:43 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:43 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:43 --> Email Class Initialized
INFO - 2020-11-14 07:55:43 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:43 --> Model Class Initialized
INFO - 2020-11-14 07:55:43 --> Model Class Initialized
INFO - 2020-11-14 07:55:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:55:43 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:43 --> Total execution time: 0.0255
ERROR - 2020-11-14 07:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:43 --> Config Class Initialized
INFO - 2020-11-14 07:55:43 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:43 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:43 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:43 --> URI Class Initialized
INFO - 2020-11-14 07:55:43 --> Router Class Initialized
INFO - 2020-11-14 07:55:43 --> Output Class Initialized
INFO - 2020-11-14 07:55:43 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:43 --> Input Class Initialized
INFO - 2020-11-14 07:55:43 --> Language Class Initialized
INFO - 2020-11-14 07:55:43 --> Loader Class Initialized
INFO - 2020-11-14 07:55:43 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:43 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:43 --> Email Class Initialized
INFO - 2020-11-14 07:55:43 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:43 --> Model Class Initialized
INFO - 2020-11-14 07:55:43 --> Model Class Initialized
INFO - 2020-11-14 07:55:43 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:43 --> Total execution time: 0.0260
ERROR - 2020-11-14 07:55:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:47 --> Config Class Initialized
INFO - 2020-11-14 07:55:47 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:47 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:47 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:47 --> URI Class Initialized
INFO - 2020-11-14 07:55:47 --> Router Class Initialized
INFO - 2020-11-14 07:55:47 --> Output Class Initialized
INFO - 2020-11-14 07:55:47 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:47 --> Input Class Initialized
INFO - 2020-11-14 07:55:47 --> Language Class Initialized
INFO - 2020-11-14 07:55:47 --> Loader Class Initialized
INFO - 2020-11-14 07:55:47 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:47 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:47 --> Email Class Initialized
INFO - 2020-11-14 07:55:47 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:47 --> Model Class Initialized
INFO - 2020-11-14 07:55:47 --> Model Class Initialized
INFO - 2020-11-14 07:55:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:55:47 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:47 --> Total execution time: 0.0362
ERROR - 2020-11-14 07:55:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:50 --> Config Class Initialized
INFO - 2020-11-14 07:55:50 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:50 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:50 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:50 --> URI Class Initialized
INFO - 2020-11-14 07:55:50 --> Router Class Initialized
INFO - 2020-11-14 07:55:50 --> Output Class Initialized
INFO - 2020-11-14 07:55:50 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:50 --> Input Class Initialized
INFO - 2020-11-14 07:55:50 --> Language Class Initialized
INFO - 2020-11-14 07:55:50 --> Loader Class Initialized
INFO - 2020-11-14 07:55:50 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:50 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:50 --> Email Class Initialized
INFO - 2020-11-14 07:55:50 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:50 --> Model Class Initialized
INFO - 2020-11-14 07:55:50 --> Model Class Initialized
INFO - 2020-11-14 07:55:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:55:50 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:50 --> Total execution time: 0.0227
ERROR - 2020-11-14 07:55:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:51 --> Config Class Initialized
INFO - 2020-11-14 07:55:51 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:51 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:51 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:51 --> URI Class Initialized
INFO - 2020-11-14 07:55:51 --> Router Class Initialized
INFO - 2020-11-14 07:55:51 --> Output Class Initialized
INFO - 2020-11-14 07:55:51 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:51 --> Input Class Initialized
INFO - 2020-11-14 07:55:51 --> Language Class Initialized
INFO - 2020-11-14 07:55:51 --> Loader Class Initialized
INFO - 2020-11-14 07:55:51 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:51 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:51 --> Email Class Initialized
INFO - 2020-11-14 07:55:51 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:51 --> Model Class Initialized
INFO - 2020-11-14 07:55:51 --> Model Class Initialized
INFO - 2020-11-14 07:55:51 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:51 --> Total execution time: 0.0251
ERROR - 2020-11-14 07:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:52 --> Config Class Initialized
INFO - 2020-11-14 07:55:52 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:52 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:52 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:52 --> URI Class Initialized
INFO - 2020-11-14 07:55:52 --> Router Class Initialized
INFO - 2020-11-14 07:55:52 --> Output Class Initialized
INFO - 2020-11-14 07:55:52 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:52 --> Input Class Initialized
INFO - 2020-11-14 07:55:52 --> Language Class Initialized
INFO - 2020-11-14 07:55:52 --> Loader Class Initialized
INFO - 2020-11-14 07:55:52 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:52 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:52 --> Email Class Initialized
INFO - 2020-11-14 07:55:52 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:52 --> Model Class Initialized
INFO - 2020-11-14 07:55:52 --> Model Class Initialized
INFO - 2020-11-14 07:55:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:55:52 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:52 --> Total execution time: 0.0281
ERROR - 2020-11-14 07:55:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:56 --> Config Class Initialized
INFO - 2020-11-14 07:55:56 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:56 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:56 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:56 --> URI Class Initialized
INFO - 2020-11-14 07:55:56 --> Router Class Initialized
INFO - 2020-11-14 07:55:56 --> Output Class Initialized
INFO - 2020-11-14 07:55:56 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:56 --> Input Class Initialized
INFO - 2020-11-14 07:55:56 --> Language Class Initialized
INFO - 2020-11-14 07:55:56 --> Loader Class Initialized
INFO - 2020-11-14 07:55:56 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:56 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:56 --> Email Class Initialized
INFO - 2020-11-14 07:55:56 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:56 --> Model Class Initialized
INFO - 2020-11-14 07:55:56 --> Model Class Initialized
INFO - 2020-11-14 07:55:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:55:56 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:56 --> Total execution time: 0.0374
ERROR - 2020-11-14 07:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:57 --> Config Class Initialized
INFO - 2020-11-14 07:55:57 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:57 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:57 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:57 --> URI Class Initialized
INFO - 2020-11-14 07:55:57 --> Router Class Initialized
INFO - 2020-11-14 07:55:57 --> Output Class Initialized
INFO - 2020-11-14 07:55:57 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:57 --> Input Class Initialized
INFO - 2020-11-14 07:55:57 --> Language Class Initialized
INFO - 2020-11-14 07:55:57 --> Loader Class Initialized
INFO - 2020-11-14 07:55:57 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:57 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:57 --> Email Class Initialized
INFO - 2020-11-14 07:55:57 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:57 --> Model Class Initialized
INFO - 2020-11-14 07:55:57 --> Model Class Initialized
INFO - 2020-11-14 07:55:57 --> Final output sent to browser
DEBUG - 2020-11-14 07:55:57 --> Total execution time: 0.0315
ERROR - 2020-11-14 07:55:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:55:59 --> Config Class Initialized
INFO - 2020-11-14 07:55:59 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:55:59 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:55:59 --> Utf8 Class Initialized
INFO - 2020-11-14 07:55:59 --> URI Class Initialized
INFO - 2020-11-14 07:55:59 --> Router Class Initialized
INFO - 2020-11-14 07:55:59 --> Output Class Initialized
INFO - 2020-11-14 07:55:59 --> Security Class Initialized
DEBUG - 2020-11-14 07:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:55:59 --> Input Class Initialized
INFO - 2020-11-14 07:55:59 --> Language Class Initialized
INFO - 2020-11-14 07:55:59 --> Loader Class Initialized
INFO - 2020-11-14 07:55:59 --> Helper loaded: url_helper
INFO - 2020-11-14 07:55:59 --> Database Driver Class Initialized
INFO - 2020-11-14 07:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:55:59 --> Email Class Initialized
INFO - 2020-11-14 07:55:59 --> Controller Class Initialized
DEBUG - 2020-11-14 07:55:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:55:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:55:59 --> Model Class Initialized
INFO - 2020-11-14 07:55:59 --> Model Class Initialized
INFO - 2020-11-14 07:56:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:56:02 --> Final output sent to browser
DEBUG - 2020-11-14 07:56:02 --> Total execution time: 2.3776
ERROR - 2020-11-14 07:56:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:56:02 --> Config Class Initialized
INFO - 2020-11-14 07:56:02 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:56:02 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:56:02 --> Utf8 Class Initialized
INFO - 2020-11-14 07:56:02 --> URI Class Initialized
INFO - 2020-11-14 07:56:02 --> Router Class Initialized
INFO - 2020-11-14 07:56:02 --> Output Class Initialized
INFO - 2020-11-14 07:56:02 --> Security Class Initialized
DEBUG - 2020-11-14 07:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:56:02 --> Input Class Initialized
INFO - 2020-11-14 07:56:02 --> Language Class Initialized
INFO - 2020-11-14 07:56:02 --> Loader Class Initialized
INFO - 2020-11-14 07:56:02 --> Helper loaded: url_helper
INFO - 2020-11-14 07:56:02 --> Database Driver Class Initialized
INFO - 2020-11-14 07:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:56:02 --> Email Class Initialized
INFO - 2020-11-14 07:56:02 --> Controller Class Initialized
DEBUG - 2020-11-14 07:56:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:56:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:56:02 --> Model Class Initialized
INFO - 2020-11-14 07:56:02 --> Model Class Initialized
INFO - 2020-11-14 07:56:02 --> Final output sent to browser
DEBUG - 2020-11-14 07:56:02 --> Total execution time: 0.0231
ERROR - 2020-11-14 07:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:56:30 --> Config Class Initialized
INFO - 2020-11-14 07:56:30 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:56:30 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:56:30 --> Utf8 Class Initialized
INFO - 2020-11-14 07:56:30 --> URI Class Initialized
INFO - 2020-11-14 07:56:30 --> Router Class Initialized
INFO - 2020-11-14 07:56:30 --> Output Class Initialized
INFO - 2020-11-14 07:56:30 --> Security Class Initialized
DEBUG - 2020-11-14 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:56:30 --> Input Class Initialized
INFO - 2020-11-14 07:56:30 --> Language Class Initialized
INFO - 2020-11-14 07:56:30 --> Loader Class Initialized
INFO - 2020-11-14 07:56:30 --> Helper loaded: url_helper
INFO - 2020-11-14 07:56:30 --> Database Driver Class Initialized
INFO - 2020-11-14 07:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:56:30 --> Email Class Initialized
INFO - 2020-11-14 07:56:30 --> Controller Class Initialized
DEBUG - 2020-11-14 07:56:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:56:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:56:30 --> Model Class Initialized
INFO - 2020-11-14 07:56:30 --> Model Class Initialized
INFO - 2020-11-14 07:56:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 07:56:30 --> Final output sent to browser
DEBUG - 2020-11-14 07:56:30 --> Total execution time: 0.0266
ERROR - 2020-11-14 07:58:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:58:51 --> Config Class Initialized
INFO - 2020-11-14 07:58:51 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:58:51 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:58:51 --> Utf8 Class Initialized
INFO - 2020-11-14 07:58:51 --> URI Class Initialized
INFO - 2020-11-14 07:58:51 --> Router Class Initialized
INFO - 2020-11-14 07:58:51 --> Output Class Initialized
INFO - 2020-11-14 07:58:51 --> Security Class Initialized
DEBUG - 2020-11-14 07:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:58:51 --> Input Class Initialized
INFO - 2020-11-14 07:58:51 --> Language Class Initialized
INFO - 2020-11-14 07:58:51 --> Loader Class Initialized
INFO - 2020-11-14 07:58:51 --> Helper loaded: url_helper
INFO - 2020-11-14 07:58:51 --> Database Driver Class Initialized
INFO - 2020-11-14 07:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:58:51 --> Email Class Initialized
INFO - 2020-11-14 07:58:51 --> Controller Class Initialized
DEBUG - 2020-11-14 07:58:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:58:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:58:51 --> Model Class Initialized
INFO - 2020-11-14 07:58:51 --> Model Class Initialized
INFO - 2020-11-14 07:58:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:58:51 --> Final output sent to browser
DEBUG - 2020-11-14 07:58:51 --> Total execution time: 0.0199
ERROR - 2020-11-14 07:58:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:58:52 --> Config Class Initialized
INFO - 2020-11-14 07:58:52 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:58:52 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:58:52 --> Utf8 Class Initialized
INFO - 2020-11-14 07:58:52 --> URI Class Initialized
INFO - 2020-11-14 07:58:52 --> Router Class Initialized
INFO - 2020-11-14 07:58:52 --> Output Class Initialized
INFO - 2020-11-14 07:58:52 --> Security Class Initialized
DEBUG - 2020-11-14 07:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:58:52 --> Input Class Initialized
INFO - 2020-11-14 07:58:52 --> Language Class Initialized
INFO - 2020-11-14 07:58:52 --> Loader Class Initialized
INFO - 2020-11-14 07:58:52 --> Helper loaded: url_helper
INFO - 2020-11-14 07:58:52 --> Database Driver Class Initialized
INFO - 2020-11-14 07:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:58:52 --> Email Class Initialized
INFO - 2020-11-14 07:58:52 --> Controller Class Initialized
DEBUG - 2020-11-14 07:58:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:58:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:58:52 --> Model Class Initialized
INFO - 2020-11-14 07:58:52 --> Model Class Initialized
INFO - 2020-11-14 07:58:52 --> Final output sent to browser
DEBUG - 2020-11-14 07:58:52 --> Total execution time: 0.0200
ERROR - 2020-11-14 07:58:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:58:53 --> Config Class Initialized
INFO - 2020-11-14 07:58:53 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:58:53 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:58:53 --> Utf8 Class Initialized
INFO - 2020-11-14 07:58:53 --> URI Class Initialized
INFO - 2020-11-14 07:58:53 --> Router Class Initialized
INFO - 2020-11-14 07:58:53 --> Output Class Initialized
INFO - 2020-11-14 07:58:53 --> Security Class Initialized
DEBUG - 2020-11-14 07:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:58:53 --> Input Class Initialized
INFO - 2020-11-14 07:58:53 --> Language Class Initialized
INFO - 2020-11-14 07:58:53 --> Loader Class Initialized
INFO - 2020-11-14 07:58:53 --> Helper loaded: url_helper
INFO - 2020-11-14 07:58:53 --> Database Driver Class Initialized
INFO - 2020-11-14 07:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:58:53 --> Email Class Initialized
INFO - 2020-11-14 07:58:53 --> Controller Class Initialized
DEBUG - 2020-11-14 07:58:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:58:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:58:53 --> Model Class Initialized
INFO - 2020-11-14 07:58:53 --> Model Class Initialized
INFO - 2020-11-14 07:58:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 07:58:54 --> Final output sent to browser
DEBUG - 2020-11-14 07:58:54 --> Total execution time: 1.0990
ERROR - 2020-11-14 07:58:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:58:55 --> Config Class Initialized
INFO - 2020-11-14 07:58:55 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:58:55 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:58:55 --> Utf8 Class Initialized
INFO - 2020-11-14 07:58:55 --> URI Class Initialized
INFO - 2020-11-14 07:58:55 --> Router Class Initialized
INFO - 2020-11-14 07:58:55 --> Output Class Initialized
INFO - 2020-11-14 07:58:55 --> Security Class Initialized
DEBUG - 2020-11-14 07:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:58:55 --> Input Class Initialized
INFO - 2020-11-14 07:58:55 --> Language Class Initialized
INFO - 2020-11-14 07:58:55 --> Loader Class Initialized
INFO - 2020-11-14 07:58:55 --> Helper loaded: url_helper
INFO - 2020-11-14 07:58:55 --> Database Driver Class Initialized
INFO - 2020-11-14 07:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:58:55 --> Email Class Initialized
INFO - 2020-11-14 07:58:55 --> Controller Class Initialized
DEBUG - 2020-11-14 07:58:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:58:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:58:55 --> Model Class Initialized
INFO - 2020-11-14 07:58:55 --> Model Class Initialized
INFO - 2020-11-14 07:58:55 --> Final output sent to browser
DEBUG - 2020-11-14 07:58:55 --> Total execution time: 0.0265
ERROR - 2020-11-14 07:59:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:06 --> Config Class Initialized
INFO - 2020-11-14 07:59:06 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:06 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:06 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:06 --> URI Class Initialized
INFO - 2020-11-14 07:59:06 --> Router Class Initialized
INFO - 2020-11-14 07:59:06 --> Output Class Initialized
INFO - 2020-11-14 07:59:06 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:06 --> Input Class Initialized
INFO - 2020-11-14 07:59:06 --> Language Class Initialized
INFO - 2020-11-14 07:59:06 --> Loader Class Initialized
INFO - 2020-11-14 07:59:06 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:06 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:06 --> Email Class Initialized
INFO - 2020-11-14 07:59:06 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:06 --> Model Class Initialized
INFO - 2020-11-14 07:59:06 --> Model Class Initialized
INFO - 2020-11-14 07:59:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:59:06 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:06 --> Total execution time: 0.0242
ERROR - 2020-11-14 07:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:07 --> Config Class Initialized
INFO - 2020-11-14 07:59:07 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:07 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:07 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:07 --> URI Class Initialized
INFO - 2020-11-14 07:59:07 --> Router Class Initialized
INFO - 2020-11-14 07:59:07 --> Output Class Initialized
INFO - 2020-11-14 07:59:07 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:07 --> Input Class Initialized
INFO - 2020-11-14 07:59:07 --> Language Class Initialized
INFO - 2020-11-14 07:59:07 --> Loader Class Initialized
INFO - 2020-11-14 07:59:07 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:07 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:07 --> Email Class Initialized
INFO - 2020-11-14 07:59:07 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:07 --> Model Class Initialized
INFO - 2020-11-14 07:59:07 --> Model Class Initialized
INFO - 2020-11-14 07:59:07 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:07 --> Total execution time: 0.0246
ERROR - 2020-11-14 07:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:11 --> Config Class Initialized
INFO - 2020-11-14 07:59:11 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:11 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:11 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:11 --> URI Class Initialized
INFO - 2020-11-14 07:59:11 --> Router Class Initialized
INFO - 2020-11-14 07:59:11 --> Output Class Initialized
INFO - 2020-11-14 07:59:11 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:11 --> Input Class Initialized
INFO - 2020-11-14 07:59:11 --> Language Class Initialized
INFO - 2020-11-14 07:59:11 --> Loader Class Initialized
INFO - 2020-11-14 07:59:11 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:11 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:11 --> Email Class Initialized
INFO - 2020-11-14 07:59:11 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:11 --> Model Class Initialized
INFO - 2020-11-14 07:59:11 --> Model Class Initialized
ERROR - 2020-11-14 07:59:12 --> Severity: Warning --> Illegal string offset 'ID' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 489
ERROR - 2020-11-14 07:59:12 --> Severity: Warning --> Illegal string offset 'campaignID' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 490
ERROR - 2020-11-14 07:59:12 --> Severity: Warning --> Illegal string offset 'contactID' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 491
INFO - 2020-11-14 07:59:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:59:12 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:12 --> Total execution time: 0.9638
ERROR - 2020-11-14 07:59:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:12 --> Config Class Initialized
INFO - 2020-11-14 07:59:12 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:12 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:12 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:12 --> URI Class Initialized
INFO - 2020-11-14 07:59:12 --> Router Class Initialized
INFO - 2020-11-14 07:59:12 --> Output Class Initialized
INFO - 2020-11-14 07:59:12 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:12 --> Input Class Initialized
INFO - 2020-11-14 07:59:12 --> Language Class Initialized
INFO - 2020-11-14 07:59:12 --> Loader Class Initialized
INFO - 2020-11-14 07:59:12 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:12 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:12 --> Email Class Initialized
INFO - 2020-11-14 07:59:12 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:12 --> Model Class Initialized
INFO - 2020-11-14 07:59:12 --> Model Class Initialized
INFO - 2020-11-14 07:59:12 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:12 --> Total execution time: 0.0256
ERROR - 2020-11-14 07:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:30 --> Config Class Initialized
INFO - 2020-11-14 07:59:30 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:30 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:30 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:30 --> URI Class Initialized
INFO - 2020-11-14 07:59:30 --> Router Class Initialized
INFO - 2020-11-14 07:59:30 --> Output Class Initialized
INFO - 2020-11-14 07:59:30 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:30 --> Input Class Initialized
INFO - 2020-11-14 07:59:30 --> Language Class Initialized
INFO - 2020-11-14 07:59:30 --> Loader Class Initialized
INFO - 2020-11-14 07:59:30 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:30 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:30 --> Email Class Initialized
INFO - 2020-11-14 07:59:30 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:30 --> Model Class Initialized
INFO - 2020-11-14 07:59:30 --> Model Class Initialized
INFO - 2020-11-14 07:59:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:59:30 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:30 --> Total execution time: 0.0215
ERROR - 2020-11-14 07:59:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:30 --> Config Class Initialized
INFO - 2020-11-14 07:59:30 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:30 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:30 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:30 --> URI Class Initialized
INFO - 2020-11-14 07:59:30 --> Router Class Initialized
INFO - 2020-11-14 07:59:30 --> Output Class Initialized
INFO - 2020-11-14 07:59:30 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:30 --> Input Class Initialized
INFO - 2020-11-14 07:59:30 --> Language Class Initialized
INFO - 2020-11-14 07:59:30 --> Loader Class Initialized
INFO - 2020-11-14 07:59:30 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:30 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:30 --> Email Class Initialized
INFO - 2020-11-14 07:59:30 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:30 --> Model Class Initialized
INFO - 2020-11-14 07:59:30 --> Model Class Initialized
INFO - 2020-11-14 07:59:30 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:30 --> Total execution time: 0.0238
ERROR - 2020-11-14 07:59:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:33 --> Config Class Initialized
INFO - 2020-11-14 07:59:33 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:33 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:33 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:33 --> URI Class Initialized
INFO - 2020-11-14 07:59:33 --> Router Class Initialized
INFO - 2020-11-14 07:59:33 --> Output Class Initialized
INFO - 2020-11-14 07:59:33 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:33 --> Input Class Initialized
INFO - 2020-11-14 07:59:33 --> Language Class Initialized
INFO - 2020-11-14 07:59:33 --> Loader Class Initialized
INFO - 2020-11-14 07:59:33 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:33 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:33 --> Email Class Initialized
INFO - 2020-11-14 07:59:33 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:33 --> Model Class Initialized
INFO - 2020-11-14 07:59:33 --> Model Class Initialized
INFO - 2020-11-14 07:59:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:59:35 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:35 --> Total execution time: 1.9800
ERROR - 2020-11-14 07:59:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:35 --> Config Class Initialized
INFO - 2020-11-14 07:59:35 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:35 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:35 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:35 --> URI Class Initialized
INFO - 2020-11-14 07:59:35 --> Router Class Initialized
INFO - 2020-11-14 07:59:35 --> Output Class Initialized
INFO - 2020-11-14 07:59:35 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:35 --> Input Class Initialized
INFO - 2020-11-14 07:59:35 --> Language Class Initialized
INFO - 2020-11-14 07:59:35 --> Loader Class Initialized
INFO - 2020-11-14 07:59:35 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:35 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:35 --> Email Class Initialized
INFO - 2020-11-14 07:59:35 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:35 --> Model Class Initialized
INFO - 2020-11-14 07:59:35 --> Model Class Initialized
INFO - 2020-11-14 07:59:35 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:35 --> Total execution time: 0.0261
ERROR - 2020-11-14 07:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:39 --> Config Class Initialized
INFO - 2020-11-14 07:59:39 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:39 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:39 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:39 --> URI Class Initialized
INFO - 2020-11-14 07:59:39 --> Router Class Initialized
INFO - 2020-11-14 07:59:39 --> Output Class Initialized
INFO - 2020-11-14 07:59:39 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:39 --> Input Class Initialized
INFO - 2020-11-14 07:59:39 --> Language Class Initialized
INFO - 2020-11-14 07:59:39 --> Loader Class Initialized
INFO - 2020-11-14 07:59:39 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:39 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:39 --> Email Class Initialized
INFO - 2020-11-14 07:59:39 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:39 --> Model Class Initialized
INFO - 2020-11-14 07:59:39 --> Model Class Initialized
INFO - 2020-11-14 07:59:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:59:40 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:40 --> Total execution time: 1.2419
ERROR - 2020-11-14 07:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:41 --> Config Class Initialized
INFO - 2020-11-14 07:59:41 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:41 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:41 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:41 --> URI Class Initialized
INFO - 2020-11-14 07:59:41 --> Router Class Initialized
INFO - 2020-11-14 07:59:41 --> Output Class Initialized
INFO - 2020-11-14 07:59:41 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:41 --> Input Class Initialized
INFO - 2020-11-14 07:59:41 --> Language Class Initialized
INFO - 2020-11-14 07:59:41 --> Loader Class Initialized
INFO - 2020-11-14 07:59:41 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:41 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:41 --> Email Class Initialized
INFO - 2020-11-14 07:59:41 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:41 --> Model Class Initialized
INFO - 2020-11-14 07:59:41 --> Model Class Initialized
INFO - 2020-11-14 07:59:41 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:41 --> Total execution time: 0.0221
ERROR - 2020-11-14 07:59:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:46 --> Config Class Initialized
INFO - 2020-11-14 07:59:46 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:46 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:46 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:46 --> URI Class Initialized
INFO - 2020-11-14 07:59:46 --> Router Class Initialized
INFO - 2020-11-14 07:59:46 --> Output Class Initialized
INFO - 2020-11-14 07:59:46 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:46 --> Input Class Initialized
INFO - 2020-11-14 07:59:46 --> Language Class Initialized
INFO - 2020-11-14 07:59:46 --> Loader Class Initialized
INFO - 2020-11-14 07:59:46 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:46 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:46 --> Email Class Initialized
INFO - 2020-11-14 07:59:46 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:46 --> Model Class Initialized
INFO - 2020-11-14 07:59:46 --> Model Class Initialized
ERROR - 2020-11-14 07:59:47 --> Severity: Warning --> Illegal string offset 'ID' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 489
ERROR - 2020-11-14 07:59:47 --> Severity: Warning --> Illegal string offset 'campaignID' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 490
ERROR - 2020-11-14 07:59:47 --> Severity: Warning --> Illegal string offset 'contactID' /home/purpu1ex/public_html/carsm/application/controllers/Campain.php 491
INFO - 2020-11-14 07:59:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 07:59:47 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:47 --> Total execution time: 0.9769
ERROR - 2020-11-14 07:59:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 07:59:48 --> Config Class Initialized
INFO - 2020-11-14 07:59:48 --> Hooks Class Initialized
DEBUG - 2020-11-14 07:59:48 --> UTF-8 Support Enabled
INFO - 2020-11-14 07:59:48 --> Utf8 Class Initialized
INFO - 2020-11-14 07:59:48 --> URI Class Initialized
INFO - 2020-11-14 07:59:48 --> Router Class Initialized
INFO - 2020-11-14 07:59:48 --> Output Class Initialized
INFO - 2020-11-14 07:59:48 --> Security Class Initialized
DEBUG - 2020-11-14 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 07:59:48 --> Input Class Initialized
INFO - 2020-11-14 07:59:48 --> Language Class Initialized
INFO - 2020-11-14 07:59:48 --> Loader Class Initialized
INFO - 2020-11-14 07:59:48 --> Helper loaded: url_helper
INFO - 2020-11-14 07:59:48 --> Database Driver Class Initialized
INFO - 2020-11-14 07:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 07:59:48 --> Email Class Initialized
INFO - 2020-11-14 07:59:48 --> Controller Class Initialized
DEBUG - 2020-11-14 07:59:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 07:59:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 07:59:48 --> Model Class Initialized
INFO - 2020-11-14 07:59:48 --> Model Class Initialized
INFO - 2020-11-14 07:59:48 --> Final output sent to browser
DEBUG - 2020-11-14 07:59:48 --> Total execution time: 0.0219
ERROR - 2020-11-14 08:00:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:19 --> Config Class Initialized
INFO - 2020-11-14 08:00:19 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:19 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:19 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:19 --> URI Class Initialized
DEBUG - 2020-11-14 08:00:19 --> No URI present. Default controller set.
INFO - 2020-11-14 08:00:19 --> Router Class Initialized
INFO - 2020-11-14 08:00:19 --> Output Class Initialized
INFO - 2020-11-14 08:00:19 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:19 --> Input Class Initialized
INFO - 2020-11-14 08:00:19 --> Language Class Initialized
INFO - 2020-11-14 08:00:19 --> Loader Class Initialized
INFO - 2020-11-14 08:00:19 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:19 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:19 --> Email Class Initialized
INFO - 2020-11-14 08:00:19 --> Controller Class Initialized
INFO - 2020-11-14 08:00:19 --> Model Class Initialized
INFO - 2020-11-14 08:00:19 --> Model Class Initialized
DEBUG - 2020-11-14 08:00:19 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 08:00:19 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:19 --> Total execution time: 0.0220
ERROR - 2020-11-14 08:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:31 --> Config Class Initialized
INFO - 2020-11-14 08:00:31 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:31 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:31 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:31 --> URI Class Initialized
INFO - 2020-11-14 08:00:31 --> Router Class Initialized
INFO - 2020-11-14 08:00:31 --> Output Class Initialized
INFO - 2020-11-14 08:00:31 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:31 --> Input Class Initialized
INFO - 2020-11-14 08:00:31 --> Language Class Initialized
INFO - 2020-11-14 08:00:31 --> Loader Class Initialized
INFO - 2020-11-14 08:00:31 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:31 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:31 --> Email Class Initialized
INFO - 2020-11-14 08:00:31 --> Controller Class Initialized
INFO - 2020-11-14 08:00:31 --> Model Class Initialized
INFO - 2020-11-14 08:00:31 --> Model Class Initialized
DEBUG - 2020-11-14 08:00:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:31 --> Model Class Initialized
INFO - 2020-11-14 08:00:31 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:31 --> Total execution time: 0.0219
ERROR - 2020-11-14 08:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:31 --> Config Class Initialized
INFO - 2020-11-14 08:00:31 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:31 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:31 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:31 --> URI Class Initialized
INFO - 2020-11-14 08:00:31 --> Router Class Initialized
INFO - 2020-11-14 08:00:31 --> Output Class Initialized
INFO - 2020-11-14 08:00:31 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:31 --> Input Class Initialized
INFO - 2020-11-14 08:00:31 --> Language Class Initialized
INFO - 2020-11-14 08:00:31 --> Loader Class Initialized
INFO - 2020-11-14 08:00:31 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:31 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:31 --> Email Class Initialized
INFO - 2020-11-14 08:00:31 --> Controller Class Initialized
INFO - 2020-11-14 08:00:31 --> Model Class Initialized
INFO - 2020-11-14 08:00:31 --> Model Class Initialized
DEBUG - 2020-11-14 08:00:31 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-14 08:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:32 --> Config Class Initialized
INFO - 2020-11-14 08:00:32 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:32 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:32 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:32 --> URI Class Initialized
INFO - 2020-11-14 08:00:32 --> Router Class Initialized
INFO - 2020-11-14 08:00:32 --> Output Class Initialized
INFO - 2020-11-14 08:00:32 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:32 --> Input Class Initialized
INFO - 2020-11-14 08:00:32 --> Language Class Initialized
INFO - 2020-11-14 08:00:32 --> Loader Class Initialized
INFO - 2020-11-14 08:00:32 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:32 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:32 --> Email Class Initialized
INFO - 2020-11-14 08:00:32 --> Controller Class Initialized
DEBUG - 2020-11-14 08:00:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:32 --> Model Class Initialized
INFO - 2020-11-14 08:00:32 --> Model Class Initialized
INFO - 2020-11-14 08:00:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:00:32 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:32 --> Total execution time: 0.0248
ERROR - 2020-11-14 08:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:41 --> Config Class Initialized
INFO - 2020-11-14 08:00:41 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:41 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:41 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:41 --> URI Class Initialized
INFO - 2020-11-14 08:00:41 --> Router Class Initialized
INFO - 2020-11-14 08:00:41 --> Output Class Initialized
INFO - 2020-11-14 08:00:41 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:41 --> Input Class Initialized
INFO - 2020-11-14 08:00:41 --> Language Class Initialized
INFO - 2020-11-14 08:00:41 --> Loader Class Initialized
INFO - 2020-11-14 08:00:41 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:41 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:41 --> Email Class Initialized
INFO - 2020-11-14 08:00:41 --> Controller Class Initialized
DEBUG - 2020-11-14 08:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:41 --> Model Class Initialized
INFO - 2020-11-14 08:00:41 --> Model Class Initialized
INFO - 2020-11-14 08:00:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 08:00:41 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:41 --> Total execution time: 0.0202
ERROR - 2020-11-14 08:00:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:41 --> Config Class Initialized
INFO - 2020-11-14 08:00:41 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:41 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:41 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:41 --> URI Class Initialized
INFO - 2020-11-14 08:00:41 --> Router Class Initialized
INFO - 2020-11-14 08:00:41 --> Output Class Initialized
INFO - 2020-11-14 08:00:41 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:41 --> Input Class Initialized
INFO - 2020-11-14 08:00:41 --> Language Class Initialized
INFO - 2020-11-14 08:00:41 --> Loader Class Initialized
INFO - 2020-11-14 08:00:41 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:41 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:41 --> Email Class Initialized
INFO - 2020-11-14 08:00:41 --> Controller Class Initialized
DEBUG - 2020-11-14 08:00:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:41 --> Model Class Initialized
INFO - 2020-11-14 08:00:41 --> Model Class Initialized
INFO - 2020-11-14 08:00:41 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:41 --> Total execution time: 0.0232
ERROR - 2020-11-14 08:00:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:42 --> Config Class Initialized
INFO - 2020-11-14 08:00:42 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:42 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:42 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:42 --> URI Class Initialized
INFO - 2020-11-14 08:00:42 --> Router Class Initialized
INFO - 2020-11-14 08:00:42 --> Output Class Initialized
INFO - 2020-11-14 08:00:42 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:42 --> Input Class Initialized
INFO - 2020-11-14 08:00:42 --> Language Class Initialized
INFO - 2020-11-14 08:00:42 --> Loader Class Initialized
INFO - 2020-11-14 08:00:42 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:42 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:42 --> Email Class Initialized
INFO - 2020-11-14 08:00:42 --> Controller Class Initialized
DEBUG - 2020-11-14 08:00:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:42 --> Model Class Initialized
INFO - 2020-11-14 08:00:42 --> Model Class Initialized
INFO - 2020-11-14 08:00:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 08:00:43 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:43 --> Total execution time: 1.0692
ERROR - 2020-11-14 08:00:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:44 --> Config Class Initialized
INFO - 2020-11-14 08:00:44 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:44 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:44 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:44 --> URI Class Initialized
INFO - 2020-11-14 08:00:44 --> Router Class Initialized
INFO - 2020-11-14 08:00:44 --> Output Class Initialized
INFO - 2020-11-14 08:00:44 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:44 --> Input Class Initialized
INFO - 2020-11-14 08:00:44 --> Language Class Initialized
INFO - 2020-11-14 08:00:44 --> Loader Class Initialized
INFO - 2020-11-14 08:00:44 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:44 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:44 --> Email Class Initialized
INFO - 2020-11-14 08:00:44 --> Controller Class Initialized
DEBUG - 2020-11-14 08:00:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:44 --> Model Class Initialized
INFO - 2020-11-14 08:00:44 --> Model Class Initialized
INFO - 2020-11-14 08:00:44 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:44 --> Total execution time: 0.0219
ERROR - 2020-11-14 08:00:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:00:48 --> Config Class Initialized
INFO - 2020-11-14 08:00:48 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:00:48 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:00:48 --> Utf8 Class Initialized
INFO - 2020-11-14 08:00:48 --> URI Class Initialized
INFO - 2020-11-14 08:00:48 --> Router Class Initialized
INFO - 2020-11-14 08:00:48 --> Output Class Initialized
INFO - 2020-11-14 08:00:48 --> Security Class Initialized
DEBUG - 2020-11-14 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:00:48 --> Input Class Initialized
INFO - 2020-11-14 08:00:48 --> Language Class Initialized
INFO - 2020-11-14 08:00:48 --> Loader Class Initialized
INFO - 2020-11-14 08:00:48 --> Helper loaded: url_helper
INFO - 2020-11-14 08:00:48 --> Database Driver Class Initialized
INFO - 2020-11-14 08:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:00:48 --> Email Class Initialized
INFO - 2020-11-14 08:00:48 --> Controller Class Initialized
DEBUG - 2020-11-14 08:00:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:00:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:00:48 --> Model Class Initialized
INFO - 2020-11-14 08:00:48 --> Model Class Initialized
INFO - 2020-11-14 08:00:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:00:48 --> Final output sent to browser
DEBUG - 2020-11-14 08:00:48 --> Total execution time: 0.0216
ERROR - 2020-11-14 08:01:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:01:18 --> Config Class Initialized
INFO - 2020-11-14 08:01:18 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:01:18 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:01:18 --> Utf8 Class Initialized
INFO - 2020-11-14 08:01:18 --> URI Class Initialized
DEBUG - 2020-11-14 08:01:18 --> No URI present. Default controller set.
INFO - 2020-11-14 08:01:18 --> Router Class Initialized
INFO - 2020-11-14 08:01:18 --> Output Class Initialized
INFO - 2020-11-14 08:01:18 --> Security Class Initialized
DEBUG - 2020-11-14 08:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:01:18 --> Input Class Initialized
INFO - 2020-11-14 08:01:18 --> Language Class Initialized
INFO - 2020-11-14 08:01:18 --> Loader Class Initialized
INFO - 2020-11-14 08:01:18 --> Helper loaded: url_helper
INFO - 2020-11-14 08:01:18 --> Database Driver Class Initialized
INFO - 2020-11-14 08:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:01:18 --> Email Class Initialized
INFO - 2020-11-14 08:01:18 --> Controller Class Initialized
INFO - 2020-11-14 08:01:18 --> Model Class Initialized
INFO - 2020-11-14 08:01:18 --> Model Class Initialized
DEBUG - 2020-11-14 08:01:18 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:01:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 08:01:18 --> Final output sent to browser
DEBUG - 2020-11-14 08:01:18 --> Total execution time: 0.0178
ERROR - 2020-11-14 08:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:01:34 --> Config Class Initialized
INFO - 2020-11-14 08:01:34 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:01:34 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:01:34 --> Utf8 Class Initialized
INFO - 2020-11-14 08:01:34 --> URI Class Initialized
INFO - 2020-11-14 08:01:34 --> Router Class Initialized
INFO - 2020-11-14 08:01:34 --> Output Class Initialized
INFO - 2020-11-14 08:01:34 --> Security Class Initialized
DEBUG - 2020-11-14 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:01:34 --> Input Class Initialized
INFO - 2020-11-14 08:01:34 --> Language Class Initialized
INFO - 2020-11-14 08:01:34 --> Loader Class Initialized
INFO - 2020-11-14 08:01:34 --> Helper loaded: url_helper
INFO - 2020-11-14 08:01:34 --> Database Driver Class Initialized
INFO - 2020-11-14 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:01:34 --> Email Class Initialized
INFO - 2020-11-14 08:01:34 --> Controller Class Initialized
INFO - 2020-11-14 08:01:34 --> Model Class Initialized
INFO - 2020-11-14 08:01:34 --> Model Class Initialized
DEBUG - 2020-11-14 08:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:01:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:01:34 --> Model Class Initialized
INFO - 2020-11-14 08:01:34 --> Final output sent to browser
DEBUG - 2020-11-14 08:01:34 --> Total execution time: 0.0241
ERROR - 2020-11-14 08:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:01:34 --> Config Class Initialized
INFO - 2020-11-14 08:01:34 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:01:34 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:01:34 --> Utf8 Class Initialized
INFO - 2020-11-14 08:01:34 --> URI Class Initialized
INFO - 2020-11-14 08:01:34 --> Router Class Initialized
INFO - 2020-11-14 08:01:34 --> Output Class Initialized
INFO - 2020-11-14 08:01:34 --> Security Class Initialized
DEBUG - 2020-11-14 08:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:01:34 --> Input Class Initialized
INFO - 2020-11-14 08:01:34 --> Language Class Initialized
INFO - 2020-11-14 08:01:34 --> Loader Class Initialized
INFO - 2020-11-14 08:01:34 --> Helper loaded: url_helper
INFO - 2020-11-14 08:01:34 --> Database Driver Class Initialized
INFO - 2020-11-14 08:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:01:34 --> Email Class Initialized
INFO - 2020-11-14 08:01:34 --> Controller Class Initialized
INFO - 2020-11-14 08:01:34 --> Model Class Initialized
INFO - 2020-11-14 08:01:34 --> Model Class Initialized
DEBUG - 2020-11-14 08:01:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-14 08:01:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:01:35 --> Config Class Initialized
INFO - 2020-11-14 08:01:35 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:01:35 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:01:35 --> Utf8 Class Initialized
INFO - 2020-11-14 08:01:35 --> URI Class Initialized
INFO - 2020-11-14 08:01:35 --> Router Class Initialized
INFO - 2020-11-14 08:01:35 --> Output Class Initialized
INFO - 2020-11-14 08:01:35 --> Security Class Initialized
DEBUG - 2020-11-14 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:01:35 --> Input Class Initialized
INFO - 2020-11-14 08:01:35 --> Language Class Initialized
INFO - 2020-11-14 08:01:35 --> Loader Class Initialized
INFO - 2020-11-14 08:01:35 --> Helper loaded: url_helper
INFO - 2020-11-14 08:01:35 --> Database Driver Class Initialized
INFO - 2020-11-14 08:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:01:35 --> Email Class Initialized
INFO - 2020-11-14 08:01:35 --> Controller Class Initialized
DEBUG - 2020-11-14 08:01:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:01:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:01:35 --> Model Class Initialized
INFO - 2020-11-14 08:01:35 --> Model Class Initialized
INFO - 2020-11-14 08:01:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:01:35 --> Final output sent to browser
DEBUG - 2020-11-14 08:01:35 --> Total execution time: 0.0244
ERROR - 2020-11-14 08:02:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:02:14 --> Config Class Initialized
INFO - 2020-11-14 08:02:14 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:02:14 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:02:14 --> Utf8 Class Initialized
INFO - 2020-11-14 08:02:14 --> URI Class Initialized
INFO - 2020-11-14 08:02:14 --> Router Class Initialized
INFO - 2020-11-14 08:02:14 --> Output Class Initialized
INFO - 2020-11-14 08:02:14 --> Security Class Initialized
DEBUG - 2020-11-14 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:02:14 --> Input Class Initialized
INFO - 2020-11-14 08:02:14 --> Language Class Initialized
INFO - 2020-11-14 08:02:14 --> Loader Class Initialized
INFO - 2020-11-14 08:02:14 --> Helper loaded: url_helper
INFO - 2020-11-14 08:02:14 --> Database Driver Class Initialized
INFO - 2020-11-14 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:02:14 --> Email Class Initialized
INFO - 2020-11-14 08:02:14 --> Controller Class Initialized
DEBUG - 2020-11-14 08:02:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:02:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:02:14 --> Model Class Initialized
INFO - 2020-11-14 08:02:14 --> Model Class Initialized
INFO - 2020-11-14 08:02:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-14 08:02:14 --> Final output sent to browser
DEBUG - 2020-11-14 08:02:14 --> Total execution time: 0.0422
ERROR - 2020-11-14 08:05:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:05:56 --> Config Class Initialized
INFO - 2020-11-14 08:05:56 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:05:56 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:05:56 --> Utf8 Class Initialized
INFO - 2020-11-14 08:05:56 --> URI Class Initialized
INFO - 2020-11-14 08:05:56 --> Router Class Initialized
INFO - 2020-11-14 08:05:56 --> Output Class Initialized
INFO - 2020-11-14 08:05:56 --> Security Class Initialized
DEBUG - 2020-11-14 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:05:56 --> Input Class Initialized
INFO - 2020-11-14 08:05:56 --> Language Class Initialized
INFO - 2020-11-14 08:05:56 --> Loader Class Initialized
INFO - 2020-11-14 08:05:56 --> Helper loaded: url_helper
INFO - 2020-11-14 08:05:56 --> Database Driver Class Initialized
INFO - 2020-11-14 08:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:05:56 --> Email Class Initialized
INFO - 2020-11-14 08:05:56 --> Controller Class Initialized
DEBUG - 2020-11-14 08:05:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:05:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:05:56 --> Model Class Initialized
INFO - 2020-11-14 08:05:56 --> Model Class Initialized
INFO - 2020-11-14 08:05:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-14 08:05:56 --> Final output sent to browser
DEBUG - 2020-11-14 08:05:56 --> Total execution time: 0.0348
ERROR - 2020-11-14 08:06:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:06:01 --> Config Class Initialized
INFO - 2020-11-14 08:06:01 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:06:01 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:06:01 --> Utf8 Class Initialized
INFO - 2020-11-14 08:06:01 --> URI Class Initialized
INFO - 2020-11-14 08:06:01 --> Router Class Initialized
INFO - 2020-11-14 08:06:01 --> Output Class Initialized
INFO - 2020-11-14 08:06:01 --> Security Class Initialized
DEBUG - 2020-11-14 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:06:01 --> Input Class Initialized
INFO - 2020-11-14 08:06:01 --> Language Class Initialized
INFO - 2020-11-14 08:06:01 --> Loader Class Initialized
INFO - 2020-11-14 08:06:01 --> Helper loaded: url_helper
INFO - 2020-11-14 08:06:01 --> Database Driver Class Initialized
INFO - 2020-11-14 08:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:06:01 --> Email Class Initialized
INFO - 2020-11-14 08:06:01 --> Controller Class Initialized
DEBUG - 2020-11-14 08:06:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:06:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:06:01 --> Model Class Initialized
INFO - 2020-11-14 08:06:01 --> Model Class Initialized
INFO - 2020-11-14 08:06:01 --> Model Class Initialized
INFO - 2020-11-14 08:06:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-14 08:06:01 --> Final output sent to browser
DEBUG - 2020-11-14 08:06:01 --> Total execution time: 0.0250
ERROR - 2020-11-14 08:06:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:06:58 --> Config Class Initialized
INFO - 2020-11-14 08:06:58 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:06:58 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:06:58 --> Utf8 Class Initialized
INFO - 2020-11-14 08:06:58 --> URI Class Initialized
INFO - 2020-11-14 08:06:58 --> Router Class Initialized
INFO - 2020-11-14 08:06:58 --> Output Class Initialized
INFO - 2020-11-14 08:06:58 --> Security Class Initialized
DEBUG - 2020-11-14 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:06:58 --> Input Class Initialized
INFO - 2020-11-14 08:06:58 --> Language Class Initialized
INFO - 2020-11-14 08:06:58 --> Loader Class Initialized
INFO - 2020-11-14 08:06:58 --> Helper loaded: url_helper
INFO - 2020-11-14 08:06:58 --> Database Driver Class Initialized
INFO - 2020-11-14 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:06:59 --> Email Class Initialized
INFO - 2020-11-14 08:06:59 --> Controller Class Initialized
DEBUG - 2020-11-14 08:06:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:06:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:06:59 --> Model Class Initialized
INFO - 2020-11-14 08:06:59 --> Model Class Initialized
INFO - 2020-11-14 08:06:59 --> Model Class Initialized
INFO - 2020-11-14 08:06:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-11-14 08:06:59 --> Final output sent to browser
DEBUG - 2020-11-14 08:06:59 --> Total execution time: 0.0237
ERROR - 2020-11-14 08:07:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:07:01 --> Config Class Initialized
INFO - 2020-11-14 08:07:01 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:07:01 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:07:01 --> Utf8 Class Initialized
INFO - 2020-11-14 08:07:01 --> URI Class Initialized
INFO - 2020-11-14 08:07:01 --> Router Class Initialized
INFO - 2020-11-14 08:07:01 --> Output Class Initialized
INFO - 2020-11-14 08:07:01 --> Security Class Initialized
DEBUG - 2020-11-14 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:07:01 --> Input Class Initialized
INFO - 2020-11-14 08:07:01 --> Language Class Initialized
INFO - 2020-11-14 08:07:02 --> Loader Class Initialized
INFO - 2020-11-14 08:07:02 --> Helper loaded: url_helper
INFO - 2020-11-14 08:07:02 --> Database Driver Class Initialized
INFO - 2020-11-14 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:07:02 --> Email Class Initialized
INFO - 2020-11-14 08:07:02 --> Controller Class Initialized
DEBUG - 2020-11-14 08:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:07:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:07:02 --> Model Class Initialized
INFO - 2020-11-14 08:07:02 --> Model Class Initialized
INFO - 2020-11-14 08:07:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-14 08:07:02 --> Final output sent to browser
DEBUG - 2020-11-14 08:07:02 --> Total execution time: 0.0265
ERROR - 2020-11-14 08:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:07:03 --> Config Class Initialized
INFO - 2020-11-14 08:07:03 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:07:03 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:07:03 --> Utf8 Class Initialized
INFO - 2020-11-14 08:07:03 --> URI Class Initialized
INFO - 2020-11-14 08:07:03 --> Router Class Initialized
INFO - 2020-11-14 08:07:03 --> Output Class Initialized
INFO - 2020-11-14 08:07:03 --> Security Class Initialized
DEBUG - 2020-11-14 08:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:07:03 --> Input Class Initialized
INFO - 2020-11-14 08:07:03 --> Language Class Initialized
INFO - 2020-11-14 08:07:03 --> Loader Class Initialized
INFO - 2020-11-14 08:07:03 --> Helper loaded: url_helper
INFO - 2020-11-14 08:07:03 --> Database Driver Class Initialized
INFO - 2020-11-14 08:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:07:03 --> Email Class Initialized
INFO - 2020-11-14 08:07:03 --> Controller Class Initialized
DEBUG - 2020-11-14 08:07:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:07:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:07:03 --> Model Class Initialized
INFO - 2020-11-14 08:07:03 --> Model Class Initialized
INFO - 2020-11-14 08:07:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-11-14 08:07:03 --> Final output sent to browser
DEBUG - 2020-11-14 08:07:03 --> Total execution time: 0.0225
ERROR - 2020-11-14 08:07:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:07:06 --> Config Class Initialized
INFO - 2020-11-14 08:07:06 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:07:06 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:07:06 --> Utf8 Class Initialized
INFO - 2020-11-14 08:07:06 --> URI Class Initialized
INFO - 2020-11-14 08:07:06 --> Router Class Initialized
INFO - 2020-11-14 08:07:06 --> Output Class Initialized
INFO - 2020-11-14 08:07:06 --> Security Class Initialized
DEBUG - 2020-11-14 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:07:06 --> Input Class Initialized
INFO - 2020-11-14 08:07:06 --> Language Class Initialized
INFO - 2020-11-14 08:07:06 --> Loader Class Initialized
INFO - 2020-11-14 08:07:06 --> Helper loaded: url_helper
INFO - 2020-11-14 08:07:06 --> Database Driver Class Initialized
INFO - 2020-11-14 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:07:06 --> Email Class Initialized
INFO - 2020-11-14 08:07:06 --> Controller Class Initialized
DEBUG - 2020-11-14 08:07:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:07:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:07:06 --> Model Class Initialized
INFO - 2020-11-14 08:07:06 --> Model Class Initialized
INFO - 2020-11-14 08:07:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-14 08:07:06 --> Final output sent to browser
DEBUG - 2020-11-14 08:07:06 --> Total execution time: 0.0221
ERROR - 2020-11-14 08:07:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:07:09 --> Config Class Initialized
INFO - 2020-11-14 08:07:09 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:07:09 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:07:09 --> Utf8 Class Initialized
INFO - 2020-11-14 08:07:09 --> URI Class Initialized
INFO - 2020-11-14 08:07:09 --> Router Class Initialized
INFO - 2020-11-14 08:07:09 --> Output Class Initialized
INFO - 2020-11-14 08:07:09 --> Security Class Initialized
DEBUG - 2020-11-14 08:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:07:09 --> Input Class Initialized
INFO - 2020-11-14 08:07:09 --> Language Class Initialized
INFO - 2020-11-14 08:07:09 --> Loader Class Initialized
INFO - 2020-11-14 08:07:09 --> Helper loaded: url_helper
INFO - 2020-11-14 08:07:09 --> Database Driver Class Initialized
INFO - 2020-11-14 08:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:07:09 --> Email Class Initialized
INFO - 2020-11-14 08:07:09 --> Controller Class Initialized
DEBUG - 2020-11-14 08:07:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:07:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:07:09 --> Model Class Initialized
INFO - 2020-11-14 08:07:09 --> Model Class Initialized
INFO - 2020-11-14 08:07:09 --> Model Class Initialized
INFO - 2020-11-14 08:07:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_edit.php
INFO - 2020-11-14 08:07:09 --> Final output sent to browser
DEBUG - 2020-11-14 08:07:09 --> Total execution time: 0.0283
ERROR - 2020-11-14 08:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:07:20 --> Config Class Initialized
INFO - 2020-11-14 08:07:20 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:07:20 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:07:20 --> Utf8 Class Initialized
INFO - 2020-11-14 08:07:20 --> URI Class Initialized
INFO - 2020-11-14 08:07:20 --> Router Class Initialized
INFO - 2020-11-14 08:07:20 --> Output Class Initialized
INFO - 2020-11-14 08:07:20 --> Security Class Initialized
DEBUG - 2020-11-14 08:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:07:20 --> Input Class Initialized
INFO - 2020-11-14 08:07:20 --> Language Class Initialized
INFO - 2020-11-14 08:07:20 --> Loader Class Initialized
INFO - 2020-11-14 08:07:20 --> Helper loaded: url_helper
INFO - 2020-11-14 08:07:20 --> Database Driver Class Initialized
INFO - 2020-11-14 08:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:07:20 --> Email Class Initialized
INFO - 2020-11-14 08:07:20 --> Controller Class Initialized
DEBUG - 2020-11-14 08:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:07:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:07:20 --> Model Class Initialized
INFO - 2020-11-14 08:07:20 --> Model Class Initialized
INFO - 2020-11-14 08:07:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-14 08:07:20 --> Final output sent to browser
DEBUG - 2020-11-14 08:07:20 --> Total execution time: 0.0237
ERROR - 2020-11-14 08:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:07:30 --> Config Class Initialized
INFO - 2020-11-14 08:07:30 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:07:30 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:07:30 --> Utf8 Class Initialized
INFO - 2020-11-14 08:07:30 --> URI Class Initialized
INFO - 2020-11-14 08:07:30 --> Router Class Initialized
INFO - 2020-11-14 08:07:30 --> Output Class Initialized
INFO - 2020-11-14 08:07:30 --> Security Class Initialized
DEBUG - 2020-11-14 08:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:07:30 --> Input Class Initialized
INFO - 2020-11-14 08:07:30 --> Language Class Initialized
INFO - 2020-11-14 08:07:30 --> Loader Class Initialized
INFO - 2020-11-14 08:07:30 --> Helper loaded: url_helper
INFO - 2020-11-14 08:07:30 --> Database Driver Class Initialized
INFO - 2020-11-14 08:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:07:30 --> Email Class Initialized
INFO - 2020-11-14 08:07:30 --> Controller Class Initialized
DEBUG - 2020-11-14 08:07:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:07:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:07:30 --> Model Class Initialized
INFO - 2020-11-14 08:07:30 --> Model Class Initialized
INFO - 2020-11-14 08:07:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-14 08:07:30 --> Final output sent to browser
DEBUG - 2020-11-14 08:07:30 --> Total execution time: 0.0296
ERROR - 2020-11-14 08:08:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:08:51 --> Config Class Initialized
INFO - 2020-11-14 08:08:51 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:08:51 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:08:51 --> Utf8 Class Initialized
INFO - 2020-11-14 08:08:51 --> URI Class Initialized
INFO - 2020-11-14 08:08:51 --> Router Class Initialized
INFO - 2020-11-14 08:08:51 --> Output Class Initialized
INFO - 2020-11-14 08:08:51 --> Security Class Initialized
DEBUG - 2020-11-14 08:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:08:51 --> Input Class Initialized
INFO - 2020-11-14 08:08:51 --> Language Class Initialized
INFO - 2020-11-14 08:08:51 --> Loader Class Initialized
INFO - 2020-11-14 08:08:51 --> Helper loaded: url_helper
INFO - 2020-11-14 08:08:51 --> Database Driver Class Initialized
INFO - 2020-11-14 08:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:08:51 --> Email Class Initialized
INFO - 2020-11-14 08:08:51 --> Controller Class Initialized
DEBUG - 2020-11-14 08:08:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:08:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:08:51 --> Model Class Initialized
INFO - 2020-11-14 08:08:51 --> Model Class Initialized
INFO - 2020-11-14 08:08:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-14 08:08:51 --> Final output sent to browser
DEBUG - 2020-11-14 08:08:51 --> Total execution time: 0.0227
ERROR - 2020-11-14 08:08:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:08:52 --> Config Class Initialized
INFO - 2020-11-14 08:08:52 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:08:52 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:08:52 --> Utf8 Class Initialized
INFO - 2020-11-14 08:08:52 --> URI Class Initialized
INFO - 2020-11-14 08:08:52 --> Router Class Initialized
INFO - 2020-11-14 08:08:52 --> Output Class Initialized
INFO - 2020-11-14 08:08:52 --> Security Class Initialized
DEBUG - 2020-11-14 08:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:08:52 --> Input Class Initialized
INFO - 2020-11-14 08:08:52 --> Language Class Initialized
INFO - 2020-11-14 08:08:52 --> Loader Class Initialized
INFO - 2020-11-14 08:08:52 --> Helper loaded: url_helper
INFO - 2020-11-14 08:08:52 --> Database Driver Class Initialized
INFO - 2020-11-14 08:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:08:52 --> Email Class Initialized
INFO - 2020-11-14 08:08:52 --> Controller Class Initialized
DEBUG - 2020-11-14 08:08:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:08:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:08:52 --> Model Class Initialized
INFO - 2020-11-14 08:08:52 --> Model Class Initialized
INFO - 2020-11-14 08:08:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_add.php
INFO - 2020-11-14 08:08:52 --> Final output sent to browser
DEBUG - 2020-11-14 08:08:52 --> Total execution time: 0.0294
ERROR - 2020-11-14 08:08:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:08:53 --> Config Class Initialized
INFO - 2020-11-14 08:08:53 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:08:53 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:08:53 --> Utf8 Class Initialized
INFO - 2020-11-14 08:08:53 --> URI Class Initialized
INFO - 2020-11-14 08:08:53 --> Router Class Initialized
INFO - 2020-11-14 08:08:53 --> Output Class Initialized
INFO - 2020-11-14 08:08:53 --> Security Class Initialized
DEBUG - 2020-11-14 08:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:08:53 --> Input Class Initialized
INFO - 2020-11-14 08:08:53 --> Language Class Initialized
ERROR - 2020-11-14 08:08:53 --> 404 Page Not Found: Admin/client_list_ajx
ERROR - 2020-11-14 08:08:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:08:59 --> Config Class Initialized
INFO - 2020-11-14 08:08:59 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:08:59 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:08:59 --> Utf8 Class Initialized
INFO - 2020-11-14 08:08:59 --> URI Class Initialized
INFO - 2020-11-14 08:08:59 --> Router Class Initialized
INFO - 2020-11-14 08:08:59 --> Output Class Initialized
INFO - 2020-11-14 08:08:59 --> Security Class Initialized
DEBUG - 2020-11-14 08:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:08:59 --> Input Class Initialized
INFO - 2020-11-14 08:08:59 --> Language Class Initialized
INFO - 2020-11-14 08:08:59 --> Loader Class Initialized
INFO - 2020-11-14 08:08:59 --> Helper loaded: url_helper
INFO - 2020-11-14 08:08:59 --> Database Driver Class Initialized
INFO - 2020-11-14 08:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:08:59 --> Email Class Initialized
INFO - 2020-11-14 08:08:59 --> Controller Class Initialized
DEBUG - 2020-11-14 08:08:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:08:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:08:59 --> Model Class Initialized
INFO - 2020-11-14 08:08:59 --> Model Class Initialized
INFO - 2020-11-14 08:08:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-14 08:08:59 --> Final output sent to browser
DEBUG - 2020-11-14 08:08:59 --> Total execution time: 0.0245
ERROR - 2020-11-14 08:09:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:09:03 --> Config Class Initialized
INFO - 2020-11-14 08:09:03 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:09:03 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:09:03 --> Utf8 Class Initialized
INFO - 2020-11-14 08:09:03 --> URI Class Initialized
INFO - 2020-11-14 08:09:03 --> Router Class Initialized
INFO - 2020-11-14 08:09:03 --> Output Class Initialized
INFO - 2020-11-14 08:09:03 --> Security Class Initialized
DEBUG - 2020-11-14 08:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:09:03 --> Input Class Initialized
INFO - 2020-11-14 08:09:03 --> Language Class Initialized
INFO - 2020-11-14 08:09:03 --> Loader Class Initialized
INFO - 2020-11-14 08:09:03 --> Helper loaded: url_helper
INFO - 2020-11-14 08:09:03 --> Database Driver Class Initialized
INFO - 2020-11-14 08:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:09:03 --> Email Class Initialized
INFO - 2020-11-14 08:09:03 --> Controller Class Initialized
DEBUG - 2020-11-14 08:09:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:09:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:09:03 --> Model Class Initialized
INFO - 2020-11-14 08:09:03 --> Model Class Initialized
INFO - 2020-11-14 08:09:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-11-14 08:09:03 --> Final output sent to browser
DEBUG - 2020-11-14 08:09:03 --> Total execution time: 0.0233
ERROR - 2020-11-14 08:09:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:09:06 --> Config Class Initialized
INFO - 2020-11-14 08:09:06 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:09:06 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:09:06 --> Utf8 Class Initialized
INFO - 2020-11-14 08:09:06 --> URI Class Initialized
INFO - 2020-11-14 08:09:06 --> Router Class Initialized
INFO - 2020-11-14 08:09:06 --> Output Class Initialized
INFO - 2020-11-14 08:09:06 --> Security Class Initialized
DEBUG - 2020-11-14 08:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:09:06 --> Input Class Initialized
INFO - 2020-11-14 08:09:06 --> Language Class Initialized
INFO - 2020-11-14 08:09:06 --> Loader Class Initialized
INFO - 2020-11-14 08:09:06 --> Helper loaded: url_helper
INFO - 2020-11-14 08:09:06 --> Database Driver Class Initialized
INFO - 2020-11-14 08:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:09:06 --> Email Class Initialized
INFO - 2020-11-14 08:09:06 --> Controller Class Initialized
DEBUG - 2020-11-14 08:09:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:09:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:09:06 --> Model Class Initialized
INFO - 2020-11-14 08:09:06 --> Model Class Initialized
INFO - 2020-11-14 08:09:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-14 08:09:06 --> Final output sent to browser
DEBUG - 2020-11-14 08:09:06 --> Total execution time: 0.0215
ERROR - 2020-11-14 08:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:09:08 --> Config Class Initialized
INFO - 2020-11-14 08:09:08 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:09:08 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:09:08 --> Utf8 Class Initialized
INFO - 2020-11-14 08:09:08 --> URI Class Initialized
INFO - 2020-11-14 08:09:08 --> Router Class Initialized
INFO - 2020-11-14 08:09:08 --> Output Class Initialized
INFO - 2020-11-14 08:09:08 --> Security Class Initialized
DEBUG - 2020-11-14 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:09:08 --> Input Class Initialized
INFO - 2020-11-14 08:09:08 --> Language Class Initialized
INFO - 2020-11-14 08:09:08 --> Loader Class Initialized
INFO - 2020-11-14 08:09:08 --> Helper loaded: url_helper
INFO - 2020-11-14 08:09:08 --> Database Driver Class Initialized
INFO - 2020-11-14 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:09:08 --> Email Class Initialized
INFO - 2020-11-14 08:09:08 --> Controller Class Initialized
DEBUG - 2020-11-14 08:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:09:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:09:08 --> Model Class Initialized
INFO - 2020-11-14 08:09:08 --> Model Class Initialized
INFO - 2020-11-14 08:09:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-11-14 08:09:08 --> Final output sent to browser
DEBUG - 2020-11-14 08:09:08 --> Total execution time: 0.0238
ERROR - 2020-11-14 08:09:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:09:08 --> Config Class Initialized
INFO - 2020-11-14 08:09:08 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:09:08 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:09:08 --> Utf8 Class Initialized
INFO - 2020-11-14 08:09:08 --> URI Class Initialized
INFO - 2020-11-14 08:09:08 --> Router Class Initialized
INFO - 2020-11-14 08:09:08 --> Output Class Initialized
INFO - 2020-11-14 08:09:08 --> Security Class Initialized
DEBUG - 2020-11-14 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:09:08 --> Input Class Initialized
INFO - 2020-11-14 08:09:08 --> Language Class Initialized
INFO - 2020-11-14 08:09:08 --> Loader Class Initialized
INFO - 2020-11-14 08:09:08 --> Helper loaded: url_helper
INFO - 2020-11-14 08:09:08 --> Database Driver Class Initialized
INFO - 2020-11-14 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:09:08 --> Email Class Initialized
INFO - 2020-11-14 08:09:08 --> Controller Class Initialized
DEBUG - 2020-11-14 08:09:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:09:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:09:08 --> Model Class Initialized
INFO - 2020-11-14 08:09:08 --> Model Class Initialized
INFO - 2020-11-14 08:09:08 --> Final output sent to browser
DEBUG - 2020-11-14 08:09:08 --> Total execution time: 0.0268
ERROR - 2020-11-14 08:09:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:09:10 --> Config Class Initialized
INFO - 2020-11-14 08:09:10 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:09:10 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:09:10 --> Utf8 Class Initialized
INFO - 2020-11-14 08:09:10 --> URI Class Initialized
INFO - 2020-11-14 08:09:10 --> Router Class Initialized
INFO - 2020-11-14 08:09:10 --> Output Class Initialized
INFO - 2020-11-14 08:09:10 --> Security Class Initialized
DEBUG - 2020-11-14 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:09:10 --> Input Class Initialized
INFO - 2020-11-14 08:09:10 --> Language Class Initialized
INFO - 2020-11-14 08:09:10 --> Loader Class Initialized
INFO - 2020-11-14 08:09:10 --> Helper loaded: url_helper
INFO - 2020-11-14 08:09:10 --> Database Driver Class Initialized
INFO - 2020-11-14 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:09:10 --> Email Class Initialized
INFO - 2020-11-14 08:09:10 --> Controller Class Initialized
DEBUG - 2020-11-14 08:09:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:09:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:09:10 --> Model Class Initialized
INFO - 2020-11-14 08:09:10 --> Model Class Initialized
INFO - 2020-11-14 08:09:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-11-14 08:09:10 --> Final output sent to browser
DEBUG - 2020-11-14 08:09:10 --> Total execution time: 0.0225
ERROR - 2020-11-14 08:09:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:09:16 --> Config Class Initialized
INFO - 2020-11-14 08:09:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:09:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:09:16 --> Utf8 Class Initialized
INFO - 2020-11-14 08:09:16 --> URI Class Initialized
INFO - 2020-11-14 08:09:16 --> Router Class Initialized
INFO - 2020-11-14 08:09:16 --> Output Class Initialized
INFO - 2020-11-14 08:09:16 --> Security Class Initialized
DEBUG - 2020-11-14 08:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:09:16 --> Input Class Initialized
INFO - 2020-11-14 08:09:16 --> Language Class Initialized
INFO - 2020-11-14 08:09:16 --> Loader Class Initialized
INFO - 2020-11-14 08:09:16 --> Helper loaded: url_helper
INFO - 2020-11-14 08:09:16 --> Database Driver Class Initialized
INFO - 2020-11-14 08:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:09:16 --> Email Class Initialized
INFO - 2020-11-14 08:09:16 --> Controller Class Initialized
DEBUG - 2020-11-14 08:09:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:09:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:09:16 --> Model Class Initialized
INFO - 2020-11-14 08:09:16 --> Model Class Initialized
INFO - 2020-11-14 08:09:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-14 08:09:16 --> Final output sent to browser
DEBUG - 2020-11-14 08:09:16 --> Total execution time: 0.0230
ERROR - 2020-11-14 08:11:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:11:35 --> Config Class Initialized
INFO - 2020-11-14 08:11:35 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:11:35 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:11:35 --> Utf8 Class Initialized
INFO - 2020-11-14 08:11:35 --> URI Class Initialized
INFO - 2020-11-14 08:11:35 --> Router Class Initialized
INFO - 2020-11-14 08:11:35 --> Output Class Initialized
INFO - 2020-11-14 08:11:35 --> Security Class Initialized
DEBUG - 2020-11-14 08:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:11:35 --> Input Class Initialized
INFO - 2020-11-14 08:11:35 --> Language Class Initialized
INFO - 2020-11-14 08:11:35 --> Loader Class Initialized
INFO - 2020-11-14 08:11:35 --> Helper loaded: url_helper
INFO - 2020-11-14 08:11:35 --> Database Driver Class Initialized
INFO - 2020-11-14 08:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:11:35 --> Email Class Initialized
INFO - 2020-11-14 08:11:35 --> Controller Class Initialized
DEBUG - 2020-11-14 08:11:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:11:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:11:35 --> Model Class Initialized
INFO - 2020-11-14 08:11:35 --> Model Class Initialized
INFO - 2020-11-14 08:11:35 --> Model Class Initialized
INFO - 2020-11-14 08:11:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-11-14 08:11:35 --> Final output sent to browser
DEBUG - 2020-11-14 08:11:35 --> Total execution time: 0.0258
ERROR - 2020-11-14 08:11:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:11:44 --> Config Class Initialized
INFO - 2020-11-14 08:11:44 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:11:44 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:11:44 --> Utf8 Class Initialized
INFO - 2020-11-14 08:11:44 --> URI Class Initialized
INFO - 2020-11-14 08:11:44 --> Router Class Initialized
INFO - 2020-11-14 08:11:44 --> Output Class Initialized
INFO - 2020-11-14 08:11:44 --> Security Class Initialized
DEBUG - 2020-11-14 08:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:11:44 --> Input Class Initialized
INFO - 2020-11-14 08:11:44 --> Language Class Initialized
INFO - 2020-11-14 08:11:44 --> Loader Class Initialized
INFO - 2020-11-14 08:11:44 --> Helper loaded: url_helper
INFO - 2020-11-14 08:11:44 --> Database Driver Class Initialized
INFO - 2020-11-14 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:11:44 --> Email Class Initialized
INFO - 2020-11-14 08:11:44 --> Controller Class Initialized
DEBUG - 2020-11-14 08:11:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:11:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:11:44 --> Model Class Initialized
INFO - 2020-11-14 08:11:44 --> Model Class Initialized
INFO - 2020-11-14 08:11:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-14 08:11:44 --> Final output sent to browser
DEBUG - 2020-11-14 08:11:44 --> Total execution time: 0.0247
ERROR - 2020-11-14 08:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:12:05 --> Config Class Initialized
INFO - 2020-11-14 08:12:05 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:12:05 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:12:05 --> Utf8 Class Initialized
INFO - 2020-11-14 08:12:05 --> URI Class Initialized
INFO - 2020-11-14 08:12:05 --> Router Class Initialized
INFO - 2020-11-14 08:12:05 --> Output Class Initialized
INFO - 2020-11-14 08:12:05 --> Security Class Initialized
DEBUG - 2020-11-14 08:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:12:05 --> Input Class Initialized
INFO - 2020-11-14 08:12:05 --> Language Class Initialized
INFO - 2020-11-14 08:12:05 --> Loader Class Initialized
INFO - 2020-11-14 08:12:05 --> Helper loaded: url_helper
INFO - 2020-11-14 08:12:05 --> Database Driver Class Initialized
INFO - 2020-11-14 08:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:12:05 --> Email Class Initialized
INFO - 2020-11-14 08:12:05 --> Controller Class Initialized
DEBUG - 2020-11-14 08:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:12:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:12:05 --> Model Class Initialized
INFO - 2020-11-14 08:12:05 --> Model Class Initialized
INFO - 2020-11-14 08:12:05 --> Model Class Initialized
INFO - 2020-11-14 08:12:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-11-14 08:12:05 --> Final output sent to browser
DEBUG - 2020-11-14 08:12:05 --> Total execution time: 0.0383
ERROR - 2020-11-14 08:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:12:33 --> Config Class Initialized
INFO - 2020-11-14 08:12:33 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:12:33 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:12:33 --> Utf8 Class Initialized
INFO - 2020-11-14 08:12:33 --> URI Class Initialized
INFO - 2020-11-14 08:12:33 --> Router Class Initialized
INFO - 2020-11-14 08:12:33 --> Output Class Initialized
INFO - 2020-11-14 08:12:33 --> Security Class Initialized
DEBUG - 2020-11-14 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:12:33 --> Input Class Initialized
INFO - 2020-11-14 08:12:33 --> Language Class Initialized
INFO - 2020-11-14 08:12:33 --> Loader Class Initialized
INFO - 2020-11-14 08:12:33 --> Helper loaded: url_helper
INFO - 2020-11-14 08:12:33 --> Database Driver Class Initialized
INFO - 2020-11-14 08:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:12:33 --> Email Class Initialized
INFO - 2020-11-14 08:12:33 --> Controller Class Initialized
DEBUG - 2020-11-14 08:12:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:12:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:12:33 --> Model Class Initialized
INFO - 2020-11-14 08:12:33 --> Model Class Initialized
INFO - 2020-11-14 08:12:33 --> Model Class Initialized
INFO - 2020-11-14 08:12:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-11-14 08:12:33 --> Final output sent to browser
DEBUG - 2020-11-14 08:12:33 --> Total execution time: 0.0247
ERROR - 2020-11-14 08:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:12:38 --> Config Class Initialized
INFO - 2020-11-14 08:12:38 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:12:38 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:12:38 --> Utf8 Class Initialized
INFO - 2020-11-14 08:12:38 --> URI Class Initialized
INFO - 2020-11-14 08:12:38 --> Router Class Initialized
INFO - 2020-11-14 08:12:38 --> Output Class Initialized
INFO - 2020-11-14 08:12:38 --> Security Class Initialized
DEBUG - 2020-11-14 08:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:12:38 --> Input Class Initialized
INFO - 2020-11-14 08:12:38 --> Language Class Initialized
INFO - 2020-11-14 08:12:38 --> Loader Class Initialized
INFO - 2020-11-14 08:12:38 --> Helper loaded: url_helper
INFO - 2020-11-14 08:12:38 --> Database Driver Class Initialized
INFO - 2020-11-14 08:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:12:38 --> Email Class Initialized
INFO - 2020-11-14 08:12:38 --> Controller Class Initialized
DEBUG - 2020-11-14 08:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:12:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:12:38 --> Model Class Initialized
INFO - 2020-11-14 08:12:38 --> Model Class Initialized
INFO - 2020-11-14 08:12:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-14 08:12:38 --> Final output sent to browser
DEBUG - 2020-11-14 08:12:38 --> Total execution time: 0.0240
ERROR - 2020-11-14 08:12:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:12:42 --> Config Class Initialized
INFO - 2020-11-14 08:12:42 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:12:42 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:12:42 --> Utf8 Class Initialized
INFO - 2020-11-14 08:12:42 --> URI Class Initialized
INFO - 2020-11-14 08:12:42 --> Router Class Initialized
INFO - 2020-11-14 08:12:42 --> Output Class Initialized
INFO - 2020-11-14 08:12:42 --> Security Class Initialized
DEBUG - 2020-11-14 08:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:12:42 --> Input Class Initialized
INFO - 2020-11-14 08:12:42 --> Language Class Initialized
INFO - 2020-11-14 08:12:42 --> Loader Class Initialized
INFO - 2020-11-14 08:12:42 --> Helper loaded: url_helper
INFO - 2020-11-14 08:12:42 --> Database Driver Class Initialized
INFO - 2020-11-14 08:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:12:42 --> Email Class Initialized
INFO - 2020-11-14 08:12:42 --> Controller Class Initialized
INFO - 2020-11-14 08:12:42 --> Model Class Initialized
INFO - 2020-11-14 08:12:42 --> Model Class Initialized
INFO - 2020-11-14 08:12:43 --> Model Class Initialized
INFO - 2020-11-14 08:12:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-11-14 08:12:43 --> Final output sent to browser
DEBUG - 2020-11-14 08:12:43 --> Total execution time: 0.2225
ERROR - 2020-11-14 08:12:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:12:43 --> Config Class Initialized
INFO - 2020-11-14 08:12:43 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:12:43 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:12:43 --> Utf8 Class Initialized
INFO - 2020-11-14 08:12:43 --> URI Class Initialized
INFO - 2020-11-14 08:12:43 --> Router Class Initialized
INFO - 2020-11-14 08:12:43 --> Output Class Initialized
INFO - 2020-11-14 08:12:43 --> Security Class Initialized
DEBUG - 2020-11-14 08:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:12:43 --> Input Class Initialized
INFO - 2020-11-14 08:12:43 --> Language Class Initialized
INFO - 2020-11-14 08:12:43 --> Loader Class Initialized
INFO - 2020-11-14 08:12:43 --> Helper loaded: url_helper
INFO - 2020-11-14 08:12:43 --> Database Driver Class Initialized
INFO - 2020-11-14 08:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:12:43 --> Email Class Initialized
INFO - 2020-11-14 08:12:43 --> Controller Class Initialized
INFO - 2020-11-14 08:12:43 --> Model Class Initialized
INFO - 2020-11-14 08:12:43 --> Model Class Initialized
INFO - 2020-11-14 08:12:43 --> Final output sent to browser
DEBUG - 2020-11-14 08:12:43 --> Total execution time: 0.0496
ERROR - 2020-11-14 08:13:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:13:26 --> Config Class Initialized
INFO - 2020-11-14 08:13:26 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:13:26 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:13:26 --> Utf8 Class Initialized
INFO - 2020-11-14 08:13:26 --> URI Class Initialized
INFO - 2020-11-14 08:13:26 --> Router Class Initialized
INFO - 2020-11-14 08:13:26 --> Output Class Initialized
INFO - 2020-11-14 08:13:26 --> Security Class Initialized
DEBUG - 2020-11-14 08:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:13:26 --> Input Class Initialized
INFO - 2020-11-14 08:13:26 --> Language Class Initialized
INFO - 2020-11-14 08:13:26 --> Loader Class Initialized
INFO - 2020-11-14 08:13:26 --> Helper loaded: url_helper
INFO - 2020-11-14 08:13:26 --> Database Driver Class Initialized
INFO - 2020-11-14 08:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:13:26 --> Email Class Initialized
INFO - 2020-11-14 08:13:26 --> Controller Class Initialized
INFO - 2020-11-14 08:13:26 --> Model Class Initialized
INFO - 2020-11-14 08:13:26 --> Model Class Initialized
INFO - 2020-11-14 08:13:26 --> Model Class Initialized
INFO - 2020-11-14 08:13:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-11-14 08:13:26 --> Final output sent to browser
DEBUG - 2020-11-14 08:13:26 --> Total execution time: 0.0426
ERROR - 2020-11-14 08:13:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:13:27 --> Config Class Initialized
INFO - 2020-11-14 08:13:27 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:13:27 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:13:27 --> Utf8 Class Initialized
INFO - 2020-11-14 08:13:27 --> URI Class Initialized
INFO - 2020-11-14 08:13:27 --> Router Class Initialized
INFO - 2020-11-14 08:13:27 --> Output Class Initialized
INFO - 2020-11-14 08:13:27 --> Security Class Initialized
DEBUG - 2020-11-14 08:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:13:27 --> Input Class Initialized
INFO - 2020-11-14 08:13:27 --> Language Class Initialized
INFO - 2020-11-14 08:13:27 --> Loader Class Initialized
INFO - 2020-11-14 08:13:27 --> Helper loaded: url_helper
INFO - 2020-11-14 08:13:27 --> Database Driver Class Initialized
INFO - 2020-11-14 08:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:13:27 --> Email Class Initialized
INFO - 2020-11-14 08:13:27 --> Controller Class Initialized
INFO - 2020-11-14 08:13:27 --> Model Class Initialized
INFO - 2020-11-14 08:13:27 --> Model Class Initialized
INFO - 2020-11-14 08:13:27 --> Final output sent to browser
DEBUG - 2020-11-14 08:13:27 --> Total execution time: 0.0437
ERROR - 2020-11-14 08:13:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:13:36 --> Config Class Initialized
INFO - 2020-11-14 08:13:36 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:13:36 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:13:36 --> Utf8 Class Initialized
INFO - 2020-11-14 08:13:36 --> URI Class Initialized
INFO - 2020-11-14 08:13:36 --> Router Class Initialized
INFO - 2020-11-14 08:13:36 --> Output Class Initialized
INFO - 2020-11-14 08:13:36 --> Security Class Initialized
DEBUG - 2020-11-14 08:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:13:36 --> Input Class Initialized
INFO - 2020-11-14 08:13:36 --> Language Class Initialized
INFO - 2020-11-14 08:13:36 --> Loader Class Initialized
INFO - 2020-11-14 08:13:36 --> Helper loaded: url_helper
INFO - 2020-11-14 08:13:36 --> Database Driver Class Initialized
INFO - 2020-11-14 08:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:13:36 --> Email Class Initialized
INFO - 2020-11-14 08:13:36 --> Controller Class Initialized
INFO - 2020-11-14 08:13:36 --> Model Class Initialized
INFO - 2020-11-14 08:13:36 --> Model Class Initialized
INFO - 2020-11-14 08:13:36 --> Model Class Initialized
INFO - 2020-11-14 08:13:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-11-14 08:13:36 --> Final output sent to browser
DEBUG - 2020-11-14 08:13:36 --> Total execution time: 0.0420
ERROR - 2020-11-14 08:14:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:14:16 --> Config Class Initialized
INFO - 2020-11-14 08:14:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:14:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:14:16 --> Utf8 Class Initialized
INFO - 2020-11-14 08:14:16 --> URI Class Initialized
INFO - 2020-11-14 08:14:16 --> Router Class Initialized
INFO - 2020-11-14 08:14:16 --> Output Class Initialized
INFO - 2020-11-14 08:14:16 --> Security Class Initialized
DEBUG - 2020-11-14 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:14:16 --> Input Class Initialized
INFO - 2020-11-14 08:14:16 --> Language Class Initialized
INFO - 2020-11-14 08:14:16 --> Loader Class Initialized
INFO - 2020-11-14 08:14:16 --> Helper loaded: url_helper
INFO - 2020-11-14 08:14:16 --> Database Driver Class Initialized
INFO - 2020-11-14 08:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:14:16 --> Email Class Initialized
INFO - 2020-11-14 08:14:16 --> Controller Class Initialized
INFO - 2020-11-14 08:14:16 --> Model Class Initialized
INFO - 2020-11-14 08:14:16 --> Model Class Initialized
INFO - 2020-11-14 08:14:16 --> Model Class Initialized
INFO - 2020-11-14 08:14:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-11-14 08:14:16 --> Final output sent to browser
DEBUG - 2020-11-14 08:14:16 --> Total execution time: 0.0375
ERROR - 2020-11-14 08:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:14:23 --> Config Class Initialized
INFO - 2020-11-14 08:14:23 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:14:23 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:14:23 --> Utf8 Class Initialized
INFO - 2020-11-14 08:14:23 --> URI Class Initialized
INFO - 2020-11-14 08:14:23 --> Router Class Initialized
INFO - 2020-11-14 08:14:23 --> Output Class Initialized
INFO - 2020-11-14 08:14:23 --> Security Class Initialized
DEBUG - 2020-11-14 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:14:23 --> Input Class Initialized
INFO - 2020-11-14 08:14:23 --> Language Class Initialized
INFO - 2020-11-14 08:14:23 --> Loader Class Initialized
INFO - 2020-11-14 08:14:23 --> Helper loaded: url_helper
INFO - 2020-11-14 08:14:23 --> Database Driver Class Initialized
INFO - 2020-11-14 08:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:14:23 --> Email Class Initialized
INFO - 2020-11-14 08:14:23 --> Controller Class Initialized
DEBUG - 2020-11-14 08:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:14:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:14:23 --> Model Class Initialized
INFO - 2020-11-14 08:14:23 --> Model Class Initialized
INFO - 2020-11-14 08:14:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-11-14 08:14:23 --> Final output sent to browser
DEBUG - 2020-11-14 08:14:23 --> Total execution time: 0.0248
ERROR - 2020-11-14 08:14:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:14:25 --> Config Class Initialized
INFO - 2020-11-14 08:14:25 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:14:25 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:14:25 --> Utf8 Class Initialized
INFO - 2020-11-14 08:14:25 --> URI Class Initialized
INFO - 2020-11-14 08:14:25 --> Router Class Initialized
INFO - 2020-11-14 08:14:25 --> Output Class Initialized
INFO - 2020-11-14 08:14:25 --> Security Class Initialized
DEBUG - 2020-11-14 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:14:25 --> Input Class Initialized
INFO - 2020-11-14 08:14:25 --> Language Class Initialized
INFO - 2020-11-14 08:14:25 --> Loader Class Initialized
INFO - 2020-11-14 08:14:25 --> Helper loaded: url_helper
INFO - 2020-11-14 08:14:25 --> Database Driver Class Initialized
INFO - 2020-11-14 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:14:25 --> Email Class Initialized
INFO - 2020-11-14 08:14:25 --> Controller Class Initialized
DEBUG - 2020-11-14 08:14:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:14:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:14:25 --> Model Class Initialized
INFO - 2020-11-14 08:14:25 --> Model Class Initialized
INFO - 2020-11-14 08:14:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:14:25 --> Final output sent to browser
DEBUG - 2020-11-14 08:14:25 --> Total execution time: 0.0203
ERROR - 2020-11-14 08:20:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:14 --> Config Class Initialized
INFO - 2020-11-14 08:20:14 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:14 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:14 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:14 --> URI Class Initialized
INFO - 2020-11-14 08:20:14 --> Router Class Initialized
INFO - 2020-11-14 08:20:14 --> Output Class Initialized
INFO - 2020-11-14 08:20:14 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:14 --> Input Class Initialized
INFO - 2020-11-14 08:20:14 --> Language Class Initialized
INFO - 2020-11-14 08:20:14 --> Loader Class Initialized
INFO - 2020-11-14 08:20:14 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:14 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:14 --> Email Class Initialized
INFO - 2020-11-14 08:20:14 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:14 --> Model Class Initialized
INFO - 2020-11-14 08:20:14 --> Model Class Initialized
INFO - 2020-11-14 08:20:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-11-14 08:20:14 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:14 --> Total execution time: 0.0208
ERROR - 2020-11-14 08:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:16 --> Config Class Initialized
INFO - 2020-11-14 08:20:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:16 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:16 --> URI Class Initialized
INFO - 2020-11-14 08:20:16 --> Router Class Initialized
INFO - 2020-11-14 08:20:16 --> Output Class Initialized
INFO - 2020-11-14 08:20:16 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:16 --> Input Class Initialized
INFO - 2020-11-14 08:20:16 --> Language Class Initialized
INFO - 2020-11-14 08:20:16 --> Loader Class Initialized
INFO - 2020-11-14 08:20:16 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:16 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:16 --> Email Class Initialized
INFO - 2020-11-14 08:20:16 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:16 --> Model Class Initialized
INFO - 2020-11-14 08:20:16 --> Model Class Initialized
INFO - 2020-11-14 08:20:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 08:20:16 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:16 --> Total execution time: 0.0193
ERROR - 2020-11-14 08:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:17 --> Config Class Initialized
INFO - 2020-11-14 08:20:17 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:17 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:17 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:17 --> URI Class Initialized
INFO - 2020-11-14 08:20:17 --> Router Class Initialized
INFO - 2020-11-14 08:20:17 --> Output Class Initialized
INFO - 2020-11-14 08:20:17 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:17 --> Input Class Initialized
INFO - 2020-11-14 08:20:17 --> Language Class Initialized
INFO - 2020-11-14 08:20:17 --> Loader Class Initialized
INFO - 2020-11-14 08:20:17 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:17 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:17 --> Email Class Initialized
INFO - 2020-11-14 08:20:17 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:17 --> Model Class Initialized
INFO - 2020-11-14 08:20:17 --> Model Class Initialized
INFO - 2020-11-14 08:20:17 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:17 --> Total execution time: 0.0231
ERROR - 2020-11-14 08:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:18 --> Config Class Initialized
INFO - 2020-11-14 08:20:18 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:18 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:18 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:18 --> URI Class Initialized
INFO - 2020-11-14 08:20:18 --> Router Class Initialized
INFO - 2020-11-14 08:20:18 --> Output Class Initialized
INFO - 2020-11-14 08:20:18 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:18 --> Input Class Initialized
INFO - 2020-11-14 08:20:18 --> Language Class Initialized
INFO - 2020-11-14 08:20:18 --> Loader Class Initialized
INFO - 2020-11-14 08:20:18 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:18 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:18 --> Email Class Initialized
INFO - 2020-11-14 08:20:18 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:18 --> Model Class Initialized
INFO - 2020-11-14 08:20:18 --> Model Class Initialized
INFO - 2020-11-14 08:20:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 08:20:18 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:18 --> Total execution time: 0.0241
ERROR - 2020-11-14 08:20:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:18 --> Config Class Initialized
INFO - 2020-11-14 08:20:18 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:18 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:18 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:18 --> URI Class Initialized
INFO - 2020-11-14 08:20:18 --> Router Class Initialized
INFO - 2020-11-14 08:20:18 --> Output Class Initialized
INFO - 2020-11-14 08:20:18 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:18 --> Input Class Initialized
INFO - 2020-11-14 08:20:18 --> Language Class Initialized
INFO - 2020-11-14 08:20:18 --> Loader Class Initialized
INFO - 2020-11-14 08:20:18 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:18 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:18 --> Email Class Initialized
INFO - 2020-11-14 08:20:18 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:18 --> Model Class Initialized
INFO - 2020-11-14 08:20:18 --> Model Class Initialized
INFO - 2020-11-14 08:20:18 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:18 --> Total execution time: 0.0186
ERROR - 2020-11-14 08:20:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:21 --> Config Class Initialized
INFO - 2020-11-14 08:20:21 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:21 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:21 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:21 --> URI Class Initialized
INFO - 2020-11-14 08:20:21 --> Router Class Initialized
INFO - 2020-11-14 08:20:21 --> Output Class Initialized
INFO - 2020-11-14 08:20:21 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:21 --> Input Class Initialized
INFO - 2020-11-14 08:20:21 --> Language Class Initialized
INFO - 2020-11-14 08:20:21 --> Loader Class Initialized
INFO - 2020-11-14 08:20:21 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:21 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:21 --> Email Class Initialized
INFO - 2020-11-14 08:20:21 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:21 --> Model Class Initialized
INFO - 2020-11-14 08:20:21 --> Model Class Initialized
INFO - 2020-11-14 08:20:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 08:20:24 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:24 --> Total execution time: 2.4621
ERROR - 2020-11-14 08:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:20:24 --> Config Class Initialized
INFO - 2020-11-14 08:20:24 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:20:24 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:20:24 --> Utf8 Class Initialized
INFO - 2020-11-14 08:20:24 --> URI Class Initialized
INFO - 2020-11-14 08:20:24 --> Router Class Initialized
INFO - 2020-11-14 08:20:24 --> Output Class Initialized
INFO - 2020-11-14 08:20:24 --> Security Class Initialized
DEBUG - 2020-11-14 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:20:24 --> Input Class Initialized
INFO - 2020-11-14 08:20:24 --> Language Class Initialized
INFO - 2020-11-14 08:20:24 --> Loader Class Initialized
INFO - 2020-11-14 08:20:24 --> Helper loaded: url_helper
INFO - 2020-11-14 08:20:24 --> Database Driver Class Initialized
INFO - 2020-11-14 08:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:20:24 --> Email Class Initialized
INFO - 2020-11-14 08:20:24 --> Controller Class Initialized
DEBUG - 2020-11-14 08:20:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:20:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:20:24 --> Model Class Initialized
INFO - 2020-11-14 08:20:24 --> Model Class Initialized
INFO - 2020-11-14 08:20:24 --> Final output sent to browser
DEBUG - 2020-11-14 08:20:24 --> Total execution time: 0.0217
ERROR - 2020-11-14 08:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:28:08 --> Config Class Initialized
INFO - 2020-11-14 08:28:08 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:28:08 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:28:08 --> Utf8 Class Initialized
INFO - 2020-11-14 08:28:08 --> URI Class Initialized
INFO - 2020-11-14 08:28:08 --> Router Class Initialized
INFO - 2020-11-14 08:28:08 --> Output Class Initialized
INFO - 2020-11-14 08:28:08 --> Security Class Initialized
DEBUG - 2020-11-14 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:28:08 --> Input Class Initialized
INFO - 2020-11-14 08:28:08 --> Language Class Initialized
INFO - 2020-11-14 08:28:08 --> Loader Class Initialized
INFO - 2020-11-14 08:28:08 --> Helper loaded: url_helper
INFO - 2020-11-14 08:28:08 --> Database Driver Class Initialized
INFO - 2020-11-14 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:28:08 --> Email Class Initialized
INFO - 2020-11-14 08:28:08 --> Controller Class Initialized
DEBUG - 2020-11-14 08:28:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:28:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:28:08 --> Model Class Initialized
INFO - 2020-11-14 08:28:08 --> Model Class Initialized
INFO - 2020-11-14 08:28:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:28:08 --> Final output sent to browser
DEBUG - 2020-11-14 08:28:08 --> Total execution time: 0.0392
ERROR - 2020-11-14 08:31:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:31:38 --> Config Class Initialized
INFO - 2020-11-14 08:31:38 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:31:38 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:31:38 --> Utf8 Class Initialized
INFO - 2020-11-14 08:31:38 --> URI Class Initialized
INFO - 2020-11-14 08:31:38 --> Router Class Initialized
INFO - 2020-11-14 08:31:38 --> Output Class Initialized
INFO - 2020-11-14 08:31:38 --> Security Class Initialized
DEBUG - 2020-11-14 08:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:31:38 --> Input Class Initialized
INFO - 2020-11-14 08:31:38 --> Language Class Initialized
INFO - 2020-11-14 08:31:38 --> Loader Class Initialized
INFO - 2020-11-14 08:31:38 --> Helper loaded: url_helper
INFO - 2020-11-14 08:31:39 --> Database Driver Class Initialized
INFO - 2020-11-14 08:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:31:39 --> Email Class Initialized
INFO - 2020-11-14 08:31:39 --> Controller Class Initialized
DEBUG - 2020-11-14 08:31:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:31:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:31:39 --> Model Class Initialized
INFO - 2020-11-14 08:31:39 --> Model Class Initialized
INFO - 2020-11-14 08:31:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:31:39 --> Final output sent to browser
DEBUG - 2020-11-14 08:31:39 --> Total execution time: 0.0269
ERROR - 2020-11-14 08:31:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:31:48 --> Config Class Initialized
INFO - 2020-11-14 08:31:48 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:31:48 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:31:48 --> Utf8 Class Initialized
INFO - 2020-11-14 08:31:48 --> URI Class Initialized
INFO - 2020-11-14 08:31:48 --> Router Class Initialized
INFO - 2020-11-14 08:31:48 --> Output Class Initialized
INFO - 2020-11-14 08:31:48 --> Security Class Initialized
DEBUG - 2020-11-14 08:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:31:48 --> Input Class Initialized
INFO - 2020-11-14 08:31:48 --> Language Class Initialized
INFO - 2020-11-14 08:31:48 --> Loader Class Initialized
INFO - 2020-11-14 08:31:48 --> Helper loaded: url_helper
INFO - 2020-11-14 08:31:48 --> Database Driver Class Initialized
INFO - 2020-11-14 08:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:31:48 --> Email Class Initialized
INFO - 2020-11-14 08:31:48 --> Controller Class Initialized
DEBUG - 2020-11-14 08:31:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:31:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:31:48 --> Model Class Initialized
INFO - 2020-11-14 08:31:48 --> Model Class Initialized
INFO - 2020-11-14 08:31:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 08:31:48 --> Final output sent to browser
DEBUG - 2020-11-14 08:31:48 --> Total execution time: 0.0212
ERROR - 2020-11-14 08:31:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:31:49 --> Config Class Initialized
INFO - 2020-11-14 08:31:49 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:31:49 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:31:49 --> Utf8 Class Initialized
INFO - 2020-11-14 08:31:49 --> URI Class Initialized
INFO - 2020-11-14 08:31:49 --> Router Class Initialized
INFO - 2020-11-14 08:31:49 --> Output Class Initialized
INFO - 2020-11-14 08:31:49 --> Security Class Initialized
DEBUG - 2020-11-14 08:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:31:49 --> Input Class Initialized
INFO - 2020-11-14 08:31:49 --> Language Class Initialized
INFO - 2020-11-14 08:31:49 --> Loader Class Initialized
INFO - 2020-11-14 08:31:49 --> Helper loaded: url_helper
INFO - 2020-11-14 08:31:49 --> Database Driver Class Initialized
INFO - 2020-11-14 08:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:31:49 --> Email Class Initialized
INFO - 2020-11-14 08:31:49 --> Controller Class Initialized
DEBUG - 2020-11-14 08:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:31:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:31:49 --> Model Class Initialized
INFO - 2020-11-14 08:31:49 --> Model Class Initialized
INFO - 2020-11-14 08:31:49 --> Final output sent to browser
DEBUG - 2020-11-14 08:31:49 --> Total execution time: 0.0251
ERROR - 2020-11-14 08:31:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:31:52 --> Config Class Initialized
INFO - 2020-11-14 08:31:52 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:31:52 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:31:52 --> Utf8 Class Initialized
INFO - 2020-11-14 08:31:52 --> URI Class Initialized
INFO - 2020-11-14 08:31:52 --> Router Class Initialized
INFO - 2020-11-14 08:31:52 --> Output Class Initialized
INFO - 2020-11-14 08:31:52 --> Security Class Initialized
DEBUG - 2020-11-14 08:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:31:52 --> Input Class Initialized
INFO - 2020-11-14 08:31:52 --> Language Class Initialized
INFO - 2020-11-14 08:31:52 --> Loader Class Initialized
INFO - 2020-11-14 08:31:52 --> Helper loaded: url_helper
INFO - 2020-11-14 08:31:52 --> Database Driver Class Initialized
INFO - 2020-11-14 08:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:31:52 --> Email Class Initialized
INFO - 2020-11-14 08:31:52 --> Controller Class Initialized
DEBUG - 2020-11-14 08:31:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:31:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:31:52 --> Model Class Initialized
INFO - 2020-11-14 08:31:52 --> Model Class Initialized
INFO - 2020-11-14 08:31:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 08:31:52 --> Final output sent to browser
DEBUG - 2020-11-14 08:31:52 --> Total execution time: 0.0228
ERROR - 2020-11-14 08:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:31:53 --> Config Class Initialized
INFO - 2020-11-14 08:31:53 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:31:53 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:31:53 --> Utf8 Class Initialized
INFO - 2020-11-14 08:31:53 --> URI Class Initialized
INFO - 2020-11-14 08:31:53 --> Router Class Initialized
INFO - 2020-11-14 08:31:53 --> Output Class Initialized
INFO - 2020-11-14 08:31:53 --> Security Class Initialized
DEBUG - 2020-11-14 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:31:53 --> Input Class Initialized
INFO - 2020-11-14 08:31:53 --> Language Class Initialized
INFO - 2020-11-14 08:31:53 --> Loader Class Initialized
INFO - 2020-11-14 08:31:53 --> Helper loaded: url_helper
INFO - 2020-11-14 08:31:53 --> Database Driver Class Initialized
INFO - 2020-11-14 08:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:31:53 --> Email Class Initialized
INFO - 2020-11-14 08:31:53 --> Controller Class Initialized
DEBUG - 2020-11-14 08:31:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:31:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:31:53 --> Model Class Initialized
INFO - 2020-11-14 08:31:53 --> Model Class Initialized
INFO - 2020-11-14 08:31:53 --> Final output sent to browser
DEBUG - 2020-11-14 08:31:53 --> Total execution time: 0.0227
ERROR - 2020-11-14 08:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:03 --> Config Class Initialized
INFO - 2020-11-14 08:32:03 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:03 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:03 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:03 --> URI Class Initialized
INFO - 2020-11-14 08:32:03 --> Router Class Initialized
INFO - 2020-11-14 08:32:03 --> Output Class Initialized
INFO - 2020-11-14 08:32:03 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:03 --> Input Class Initialized
INFO - 2020-11-14 08:32:03 --> Language Class Initialized
INFO - 2020-11-14 08:32:03 --> Loader Class Initialized
INFO - 2020-11-14 08:32:03 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:03 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:03 --> Email Class Initialized
INFO - 2020-11-14 08:32:03 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:03 --> Model Class Initialized
INFO - 2020-11-14 08:32:03 --> Model Class Initialized
INFO - 2020-11-14 08:32:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 08:32:03 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:03 --> Total execution time: 0.0297
ERROR - 2020-11-14 08:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:08 --> Config Class Initialized
INFO - 2020-11-14 08:32:08 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:08 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:08 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:08 --> URI Class Initialized
DEBUG - 2020-11-14 08:32:08 --> No URI present. Default controller set.
INFO - 2020-11-14 08:32:08 --> Router Class Initialized
INFO - 2020-11-14 08:32:08 --> Output Class Initialized
INFO - 2020-11-14 08:32:08 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:08 --> Input Class Initialized
INFO - 2020-11-14 08:32:08 --> Language Class Initialized
INFO - 2020-11-14 08:32:08 --> Loader Class Initialized
INFO - 2020-11-14 08:32:08 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:08 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:08 --> Email Class Initialized
INFO - 2020-11-14 08:32:08 --> Controller Class Initialized
INFO - 2020-11-14 08:32:08 --> Model Class Initialized
INFO - 2020-11-14 08:32:08 --> Model Class Initialized
DEBUG - 2020-11-14 08:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 08:32:08 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:08 --> Total execution time: 0.0194
ERROR - 2020-11-14 08:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:25 --> Config Class Initialized
INFO - 2020-11-14 08:32:25 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:25 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:25 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:25 --> URI Class Initialized
INFO - 2020-11-14 08:32:25 --> Router Class Initialized
INFO - 2020-11-14 08:32:25 --> Output Class Initialized
INFO - 2020-11-14 08:32:25 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:25 --> Input Class Initialized
INFO - 2020-11-14 08:32:25 --> Language Class Initialized
INFO - 2020-11-14 08:32:25 --> Loader Class Initialized
INFO - 2020-11-14 08:32:25 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:25 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:25 --> Email Class Initialized
INFO - 2020-11-14 08:32:25 --> Controller Class Initialized
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
DEBUG - 2020-11-14 08:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
INFO - 2020-11-14 08:32:25 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:25 --> Total execution time: 0.0200
ERROR - 2020-11-14 08:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:25 --> Config Class Initialized
INFO - 2020-11-14 08:32:25 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:25 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:25 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:25 --> URI Class Initialized
INFO - 2020-11-14 08:32:25 --> Router Class Initialized
INFO - 2020-11-14 08:32:25 --> Output Class Initialized
INFO - 2020-11-14 08:32:25 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:25 --> Input Class Initialized
INFO - 2020-11-14 08:32:25 --> Language Class Initialized
INFO - 2020-11-14 08:32:25 --> Loader Class Initialized
INFO - 2020-11-14 08:32:25 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:25 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:25 --> Email Class Initialized
INFO - 2020-11-14 08:32:25 --> Controller Class Initialized
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
DEBUG - 2020-11-14 08:32:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-11-14 08:32:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:25 --> Config Class Initialized
INFO - 2020-11-14 08:32:25 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:25 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:25 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:25 --> URI Class Initialized
INFO - 2020-11-14 08:32:25 --> Router Class Initialized
INFO - 2020-11-14 08:32:25 --> Output Class Initialized
INFO - 2020-11-14 08:32:25 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:25 --> Input Class Initialized
INFO - 2020-11-14 08:32:25 --> Language Class Initialized
INFO - 2020-11-14 08:32:25 --> Loader Class Initialized
INFO - 2020-11-14 08:32:25 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:25 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:25 --> Email Class Initialized
INFO - 2020-11-14 08:32:25 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
INFO - 2020-11-14 08:32:25 --> Model Class Initialized
INFO - 2020-11-14 08:32:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-11-14 08:32:25 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:25 --> Total execution time: 0.0225
ERROR - 2020-11-14 08:32:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:29 --> Config Class Initialized
INFO - 2020-11-14 08:32:29 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:29 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:29 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:29 --> URI Class Initialized
INFO - 2020-11-14 08:32:29 --> Router Class Initialized
INFO - 2020-11-14 08:32:29 --> Output Class Initialized
INFO - 2020-11-14 08:32:29 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:29 --> Input Class Initialized
INFO - 2020-11-14 08:32:29 --> Language Class Initialized
INFO - 2020-11-14 08:32:29 --> Loader Class Initialized
INFO - 2020-11-14 08:32:29 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:29 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:29 --> Email Class Initialized
INFO - 2020-11-14 08:32:29 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:29 --> Model Class Initialized
INFO - 2020-11-14 08:32:29 --> Model Class Initialized
INFO - 2020-11-14 08:32:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-11-14 08:32:29 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:29 --> Total execution time: 0.0217
ERROR - 2020-11-14 08:32:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:33 --> Config Class Initialized
INFO - 2020-11-14 08:32:33 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:33 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:33 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:33 --> URI Class Initialized
INFO - 2020-11-14 08:32:33 --> Router Class Initialized
INFO - 2020-11-14 08:32:33 --> Output Class Initialized
INFO - 2020-11-14 08:32:33 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:33 --> Input Class Initialized
INFO - 2020-11-14 08:32:33 --> Language Class Initialized
INFO - 2020-11-14 08:32:33 --> Loader Class Initialized
INFO - 2020-11-14 08:32:33 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:33 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:33 --> Email Class Initialized
INFO - 2020-11-14 08:32:33 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:33 --> Model Class Initialized
INFO - 2020-11-14 08:32:33 --> Model Class Initialized
INFO - 2020-11-14 08:32:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-11-14 08:32:33 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:33 --> Total execution time: 0.0215
ERROR - 2020-11-14 08:32:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:35 --> Config Class Initialized
INFO - 2020-11-14 08:32:35 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:35 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:35 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:35 --> URI Class Initialized
INFO - 2020-11-14 08:32:35 --> Router Class Initialized
INFO - 2020-11-14 08:32:35 --> Output Class Initialized
INFO - 2020-11-14 08:32:35 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:35 --> Input Class Initialized
INFO - 2020-11-14 08:32:35 --> Language Class Initialized
INFO - 2020-11-14 08:32:35 --> Loader Class Initialized
INFO - 2020-11-14 08:32:35 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:35 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:35 --> Email Class Initialized
INFO - 2020-11-14 08:32:35 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:35 --> Model Class Initialized
INFO - 2020-11-14 08:32:35 --> Model Class Initialized
INFO - 2020-11-14 08:32:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-11-14 08:32:35 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:35 --> Total execution time: 0.0226
ERROR - 2020-11-14 08:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:36 --> Config Class Initialized
INFO - 2020-11-14 08:32:36 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:36 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:36 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:36 --> URI Class Initialized
INFO - 2020-11-14 08:32:36 --> Router Class Initialized
INFO - 2020-11-14 08:32:36 --> Output Class Initialized
INFO - 2020-11-14 08:32:36 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:36 --> Input Class Initialized
INFO - 2020-11-14 08:32:36 --> Language Class Initialized
INFO - 2020-11-14 08:32:36 --> Loader Class Initialized
INFO - 2020-11-14 08:32:36 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:36 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:36 --> Email Class Initialized
INFO - 2020-11-14 08:32:36 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:36 --> Model Class Initialized
INFO - 2020-11-14 08:32:36 --> Model Class Initialized
INFO - 2020-11-14 08:32:36 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:36 --> Total execution time: 0.0218
ERROR - 2020-11-14 08:32:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:36 --> Config Class Initialized
INFO - 2020-11-14 08:32:36 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:36 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:36 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:36 --> URI Class Initialized
INFO - 2020-11-14 08:32:36 --> Router Class Initialized
INFO - 2020-11-14 08:32:36 --> Output Class Initialized
INFO - 2020-11-14 08:32:36 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:36 --> Input Class Initialized
INFO - 2020-11-14 08:32:36 --> Language Class Initialized
INFO - 2020-11-14 08:32:36 --> Loader Class Initialized
INFO - 2020-11-14 08:32:36 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:36 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:36 --> Email Class Initialized
INFO - 2020-11-14 08:32:36 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:36 --> Model Class Initialized
INFO - 2020-11-14 08:32:36 --> Model Class Initialized
INFO - 2020-11-14 08:32:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-11-14 08:32:36 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:36 --> Total execution time: 0.0221
ERROR - 2020-11-14 08:32:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:37 --> Config Class Initialized
INFO - 2020-11-14 08:32:37 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:37 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:37 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:37 --> URI Class Initialized
INFO - 2020-11-14 08:32:37 --> Router Class Initialized
INFO - 2020-11-14 08:32:37 --> Output Class Initialized
INFO - 2020-11-14 08:32:37 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:37 --> Input Class Initialized
INFO - 2020-11-14 08:32:37 --> Language Class Initialized
INFO - 2020-11-14 08:32:37 --> Loader Class Initialized
INFO - 2020-11-14 08:32:37 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:37 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:37 --> Email Class Initialized
INFO - 2020-11-14 08:32:37 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:37 --> Model Class Initialized
INFO - 2020-11-14 08:32:37 --> Model Class Initialized
INFO - 2020-11-14 08:32:37 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:37 --> Total execution time: 0.0230
ERROR - 2020-11-14 08:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:32:39 --> Config Class Initialized
INFO - 2020-11-14 08:32:39 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:32:39 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:32:39 --> Utf8 Class Initialized
INFO - 2020-11-14 08:32:39 --> URI Class Initialized
INFO - 2020-11-14 08:32:39 --> Router Class Initialized
INFO - 2020-11-14 08:32:39 --> Output Class Initialized
INFO - 2020-11-14 08:32:39 --> Security Class Initialized
DEBUG - 2020-11-14 08:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:32:39 --> Input Class Initialized
INFO - 2020-11-14 08:32:39 --> Language Class Initialized
INFO - 2020-11-14 08:32:39 --> Loader Class Initialized
INFO - 2020-11-14 08:32:39 --> Helper loaded: url_helper
INFO - 2020-11-14 08:32:39 --> Database Driver Class Initialized
INFO - 2020-11-14 08:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:32:39 --> Email Class Initialized
INFO - 2020-11-14 08:32:39 --> Controller Class Initialized
DEBUG - 2020-11-14 08:32:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 08:32:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:32:39 --> Model Class Initialized
INFO - 2020-11-14 08:32:39 --> Model Class Initialized
INFO - 2020-11-14 08:32:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-11-14 08:32:39 --> Final output sent to browser
DEBUG - 2020-11-14 08:32:39 --> Total execution time: 0.0229
ERROR - 2020-11-14 08:39:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 08:39:43 --> Config Class Initialized
INFO - 2020-11-14 08:39:43 --> Hooks Class Initialized
DEBUG - 2020-11-14 08:39:43 --> UTF-8 Support Enabled
INFO - 2020-11-14 08:39:43 --> Utf8 Class Initialized
INFO - 2020-11-14 08:39:43 --> URI Class Initialized
DEBUG - 2020-11-14 08:39:43 --> No URI present. Default controller set.
INFO - 2020-11-14 08:39:43 --> Router Class Initialized
INFO - 2020-11-14 08:39:43 --> Output Class Initialized
INFO - 2020-11-14 08:39:43 --> Security Class Initialized
DEBUG - 2020-11-14 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 08:39:43 --> Input Class Initialized
INFO - 2020-11-14 08:39:43 --> Language Class Initialized
INFO - 2020-11-14 08:39:43 --> Loader Class Initialized
INFO - 2020-11-14 08:39:43 --> Helper loaded: url_helper
INFO - 2020-11-14 08:39:43 --> Database Driver Class Initialized
INFO - 2020-11-14 08:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 08:39:43 --> Email Class Initialized
INFO - 2020-11-14 08:39:43 --> Controller Class Initialized
INFO - 2020-11-14 08:39:43 --> Model Class Initialized
INFO - 2020-11-14 08:39:43 --> Model Class Initialized
DEBUG - 2020-11-14 08:39:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 08:39:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-11-14 08:39:43 --> Final output sent to browser
DEBUG - 2020-11-14 08:39:43 --> Total execution time: 0.0183
ERROR - 2020-11-14 09:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:11:15 --> Config Class Initialized
INFO - 2020-11-14 09:11:15 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:11:15 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:11:15 --> Utf8 Class Initialized
INFO - 2020-11-14 09:11:15 --> URI Class Initialized
INFO - 2020-11-14 09:11:15 --> Router Class Initialized
INFO - 2020-11-14 09:11:15 --> Output Class Initialized
INFO - 2020-11-14 09:11:15 --> Security Class Initialized
DEBUG - 2020-11-14 09:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:11:15 --> Input Class Initialized
INFO - 2020-11-14 09:11:15 --> Language Class Initialized
INFO - 2020-11-14 09:11:15 --> Loader Class Initialized
INFO - 2020-11-14 09:11:15 --> Helper loaded: url_helper
INFO - 2020-11-14 09:11:15 --> Database Driver Class Initialized
ERROR - 2020-11-14 09:11:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:11:15 --> Config Class Initialized
INFO - 2020-11-14 09:11:15 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:11:15 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:11:15 --> Utf8 Class Initialized
INFO - 2020-11-14 09:11:15 --> URI Class Initialized
INFO - 2020-11-14 09:11:15 --> Router Class Initialized
INFO - 2020-11-14 09:11:15 --> Output Class Initialized
INFO - 2020-11-14 09:11:15 --> Security Class Initialized
DEBUG - 2020-11-14 09:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:11:15 --> Input Class Initialized
INFO - 2020-11-14 09:11:15 --> Language Class Initialized
INFO - 2020-11-14 09:11:15 --> Loader Class Initialized
INFO - 2020-11-14 09:11:15 --> Helper loaded: url_helper
INFO - 2020-11-14 09:11:15 --> Database Driver Class Initialized
INFO - 2020-11-14 09:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:11:15 --> Email Class Initialized
INFO - 2020-11-14 09:11:15 --> Controller Class Initialized
INFO - 2020-11-14 09:11:15 --> Model Class Initialized
INFO - 2020-11-14 09:11:15 --> Model Class Initialized
DEBUG - 2020-11-14 09:11:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:11:15 --> Email Class Initialized
INFO - 2020-11-14 09:11:15 --> Controller Class Initialized
INFO - 2020-11-14 09:11:15 --> Model Class Initialized
INFO - 2020-11-14 09:11:15 --> Model Class Initialized
DEBUG - 2020-11-14 09:11:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:11:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:11:15 --> Model Class Initialized
INFO - 2020-11-14 09:11:15 --> Final output sent to browser
DEBUG - 2020-11-14 09:11:15 --> Total execution time: 0.0315
ERROR - 2020-11-14 09:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:11:16 --> Config Class Initialized
INFO - 2020-11-14 09:11:16 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:11:16 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:11:16 --> Utf8 Class Initialized
INFO - 2020-11-14 09:11:16 --> URI Class Initialized
INFO - 2020-11-14 09:11:16 --> Router Class Initialized
INFO - 2020-11-14 09:11:16 --> Output Class Initialized
INFO - 2020-11-14 09:11:16 --> Security Class Initialized
DEBUG - 2020-11-14 09:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:11:16 --> Input Class Initialized
INFO - 2020-11-14 09:11:16 --> Language Class Initialized
INFO - 2020-11-14 09:11:16 --> Loader Class Initialized
INFO - 2020-11-14 09:11:16 --> Helper loaded: url_helper
INFO - 2020-11-14 09:11:16 --> Database Driver Class Initialized
INFO - 2020-11-14 09:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:11:16 --> Email Class Initialized
INFO - 2020-11-14 09:11:16 --> Controller Class Initialized
DEBUG - 2020-11-14 09:11:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:11:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:11:16 --> Model Class Initialized
INFO - 2020-11-14 09:11:16 --> Model Class Initialized
INFO - 2020-11-14 09:11:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 09:11:16 --> Final output sent to browser
DEBUG - 2020-11-14 09:11:16 --> Total execution time: 0.0282
ERROR - 2020-11-14 09:12:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:03 --> Config Class Initialized
INFO - 2020-11-14 09:12:03 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:03 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:03 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:03 --> URI Class Initialized
INFO - 2020-11-14 09:12:03 --> Router Class Initialized
INFO - 2020-11-14 09:12:03 --> Output Class Initialized
INFO - 2020-11-14 09:12:03 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:03 --> Input Class Initialized
INFO - 2020-11-14 09:12:03 --> Language Class Initialized
INFO - 2020-11-14 09:12:03 --> Loader Class Initialized
INFO - 2020-11-14 09:12:03 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:03 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:03 --> Email Class Initialized
INFO - 2020-11-14 09:12:03 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:03 --> Model Class Initialized
INFO - 2020-11-14 09:12:03 --> Model Class Initialized
INFO - 2020-11-14 09:12:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 09:12:03 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:03 --> Total execution time: 0.0191
ERROR - 2020-11-14 09:12:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:03 --> Config Class Initialized
INFO - 2020-11-14 09:12:03 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:03 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:03 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:03 --> URI Class Initialized
INFO - 2020-11-14 09:12:03 --> Router Class Initialized
INFO - 2020-11-14 09:12:03 --> Output Class Initialized
INFO - 2020-11-14 09:12:03 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:03 --> Input Class Initialized
INFO - 2020-11-14 09:12:03 --> Language Class Initialized
INFO - 2020-11-14 09:12:03 --> Loader Class Initialized
INFO - 2020-11-14 09:12:03 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:03 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:03 --> Email Class Initialized
INFO - 2020-11-14 09:12:03 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:03 --> Model Class Initialized
INFO - 2020-11-14 09:12:03 --> Model Class Initialized
INFO - 2020-11-14 09:12:03 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:03 --> Total execution time: 0.0196
ERROR - 2020-11-14 09:12:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:05 --> Config Class Initialized
INFO - 2020-11-14 09:12:05 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:05 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:05 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:05 --> URI Class Initialized
INFO - 2020-11-14 09:12:05 --> Router Class Initialized
INFO - 2020-11-14 09:12:05 --> Output Class Initialized
INFO - 2020-11-14 09:12:05 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:05 --> Input Class Initialized
INFO - 2020-11-14 09:12:05 --> Language Class Initialized
INFO - 2020-11-14 09:12:05 --> Loader Class Initialized
INFO - 2020-11-14 09:12:05 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:05 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:05 --> Email Class Initialized
INFO - 2020-11-14 09:12:05 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:05 --> Model Class Initialized
INFO - 2020-11-14 09:12:05 --> Model Class Initialized
INFO - 2020-11-14 09:12:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 09:12:06 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:06 --> Total execution time: 1.6196
ERROR - 2020-11-14 09:12:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:07 --> Config Class Initialized
INFO - 2020-11-14 09:12:07 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:07 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:07 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:07 --> URI Class Initialized
INFO - 2020-11-14 09:12:07 --> Router Class Initialized
INFO - 2020-11-14 09:12:07 --> Output Class Initialized
INFO - 2020-11-14 09:12:07 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:07 --> Input Class Initialized
INFO - 2020-11-14 09:12:07 --> Language Class Initialized
INFO - 2020-11-14 09:12:07 --> Loader Class Initialized
INFO - 2020-11-14 09:12:07 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:07 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:07 --> Email Class Initialized
INFO - 2020-11-14 09:12:07 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:07 --> Model Class Initialized
INFO - 2020-11-14 09:12:07 --> Model Class Initialized
INFO - 2020-11-14 09:12:07 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:07 --> Total execution time: 0.0252
ERROR - 2020-11-14 09:12:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:08 --> Config Class Initialized
INFO - 2020-11-14 09:12:08 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:08 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:08 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:08 --> URI Class Initialized
INFO - 2020-11-14 09:12:08 --> Router Class Initialized
INFO - 2020-11-14 09:12:08 --> Output Class Initialized
INFO - 2020-11-14 09:12:08 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:08 --> Input Class Initialized
INFO - 2020-11-14 09:12:08 --> Language Class Initialized
INFO - 2020-11-14 09:12:08 --> Loader Class Initialized
INFO - 2020-11-14 09:12:08 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:08 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:08 --> Email Class Initialized
INFO - 2020-11-14 09:12:08 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:08 --> Model Class Initialized
INFO - 2020-11-14 09:12:08 --> Model Class Initialized
INFO - 2020-11-14 09:12:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 09:12:08 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:08 --> Total execution time: 0.0200
ERROR - 2020-11-14 09:12:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:09 --> Config Class Initialized
INFO - 2020-11-14 09:12:09 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:09 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:09 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:09 --> URI Class Initialized
INFO - 2020-11-14 09:12:09 --> Router Class Initialized
INFO - 2020-11-14 09:12:09 --> Output Class Initialized
INFO - 2020-11-14 09:12:09 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:09 --> Input Class Initialized
INFO - 2020-11-14 09:12:09 --> Language Class Initialized
INFO - 2020-11-14 09:12:09 --> Loader Class Initialized
INFO - 2020-11-14 09:12:09 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:09 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:09 --> Email Class Initialized
INFO - 2020-11-14 09:12:09 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:09 --> Model Class Initialized
INFO - 2020-11-14 09:12:09 --> Model Class Initialized
INFO - 2020-11-14 09:12:09 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:09 --> Total execution time: 0.0202
ERROR - 2020-11-14 09:12:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:15 --> Config Class Initialized
INFO - 2020-11-14 09:12:15 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:15 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:15 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:15 --> URI Class Initialized
INFO - 2020-11-14 09:12:15 --> Router Class Initialized
INFO - 2020-11-14 09:12:15 --> Output Class Initialized
INFO - 2020-11-14 09:12:15 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:15 --> Input Class Initialized
INFO - 2020-11-14 09:12:15 --> Language Class Initialized
INFO - 2020-11-14 09:12:15 --> Loader Class Initialized
INFO - 2020-11-14 09:12:15 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:15 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:15 --> Email Class Initialized
INFO - 2020-11-14 09:12:15 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:15 --> Model Class Initialized
INFO - 2020-11-14 09:12:15 --> Model Class Initialized
INFO - 2020-11-14 09:12:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campaign_data_upload.php
INFO - 2020-11-14 09:12:17 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:17 --> Total execution time: 1.9786
ERROR - 2020-11-14 09:12:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:18 --> Config Class Initialized
INFO - 2020-11-14 09:12:18 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:18 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:18 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:18 --> URI Class Initialized
INFO - 2020-11-14 09:12:18 --> Router Class Initialized
INFO - 2020-11-14 09:12:18 --> Output Class Initialized
INFO - 2020-11-14 09:12:18 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:18 --> Input Class Initialized
INFO - 2020-11-14 09:12:18 --> Language Class Initialized
INFO - 2020-11-14 09:12:18 --> Loader Class Initialized
INFO - 2020-11-14 09:12:18 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:18 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:18 --> Email Class Initialized
INFO - 2020-11-14 09:12:18 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:18 --> Model Class Initialized
INFO - 2020-11-14 09:12:18 --> Model Class Initialized
INFO - 2020-11-14 09:12:18 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:18 --> Total execution time: 0.0209
ERROR - 2020-11-14 09:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:29 --> Config Class Initialized
INFO - 2020-11-14 09:12:29 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:29 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:29 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:29 --> URI Class Initialized
INFO - 2020-11-14 09:12:29 --> Router Class Initialized
INFO - 2020-11-14 09:12:29 --> Output Class Initialized
INFO - 2020-11-14 09:12:29 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:29 --> Input Class Initialized
INFO - 2020-11-14 09:12:29 --> Language Class Initialized
INFO - 2020-11-14 09:12:29 --> Loader Class Initialized
INFO - 2020-11-14 09:12:29 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:29 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:29 --> Email Class Initialized
INFO - 2020-11-14 09:12:29 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:29 --> Model Class Initialized
INFO - 2020-11-14 09:12:29 --> Model Class Initialized
INFO - 2020-11-14 09:12:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 09:12:29 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:29 --> Total execution time: 0.0264
ERROR - 2020-11-14 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:34 --> Config Class Initialized
INFO - 2020-11-14 09:12:34 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:34 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:34 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:34 --> URI Class Initialized
INFO - 2020-11-14 09:12:34 --> Router Class Initialized
INFO - 2020-11-14 09:12:34 --> Output Class Initialized
INFO - 2020-11-14 09:12:34 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:34 --> Input Class Initialized
INFO - 2020-11-14 09:12:34 --> Language Class Initialized
INFO - 2020-11-14 09:12:34 --> Loader Class Initialized
INFO - 2020-11-14 09:12:34 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:34 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:34 --> Email Class Initialized
INFO - 2020-11-14 09:12:34 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:34 --> Model Class Initialized
INFO - 2020-11-14 09:12:34 --> Model Class Initialized
INFO - 2020-11-14 09:12:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/all_camapaign_add.php
INFO - 2020-11-14 09:12:34 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:34 --> Total execution time: 0.0179
ERROR - 2020-11-14 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:34 --> Config Class Initialized
INFO - 2020-11-14 09:12:34 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:34 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:34 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:34 --> URI Class Initialized
INFO - 2020-11-14 09:12:34 --> Router Class Initialized
INFO - 2020-11-14 09:12:34 --> Output Class Initialized
INFO - 2020-11-14 09:12:34 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:34 --> Input Class Initialized
INFO - 2020-11-14 09:12:34 --> Language Class Initialized
INFO - 2020-11-14 09:12:34 --> Loader Class Initialized
INFO - 2020-11-14 09:12:34 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:34 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:34 --> Email Class Initialized
INFO - 2020-11-14 09:12:34 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:34 --> Model Class Initialized
INFO - 2020-11-14 09:12:34 --> Model Class Initialized
INFO - 2020-11-14 09:12:34 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:34 --> Total execution time: 0.0186
ERROR - 2020-11-14 09:12:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-11-14 09:12:38 --> Config Class Initialized
INFO - 2020-11-14 09:12:38 --> Hooks Class Initialized
DEBUG - 2020-11-14 09:12:38 --> UTF-8 Support Enabled
INFO - 2020-11-14 09:12:38 --> Utf8 Class Initialized
INFO - 2020-11-14 09:12:38 --> URI Class Initialized
INFO - 2020-11-14 09:12:38 --> Router Class Initialized
INFO - 2020-11-14 09:12:38 --> Output Class Initialized
INFO - 2020-11-14 09:12:38 --> Security Class Initialized
DEBUG - 2020-11-14 09:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-14 09:12:38 --> Input Class Initialized
INFO - 2020-11-14 09:12:38 --> Language Class Initialized
INFO - 2020-11-14 09:12:38 --> Loader Class Initialized
INFO - 2020-11-14 09:12:38 --> Helper loaded: url_helper
INFO - 2020-11-14 09:12:38 --> Database Driver Class Initialized
INFO - 2020-11-14 09:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-14 09:12:38 --> Email Class Initialized
INFO - 2020-11-14 09:12:38 --> Controller Class Initialized
DEBUG - 2020-11-14 09:12:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-11-14 09:12:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-11-14 09:12:38 --> Model Class Initialized
INFO - 2020-11-14 09:12:38 --> Model Class Initialized
INFO - 2020-11-14 09:12:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-11-14 09:12:38 --> Final output sent to browser
DEBUG - 2020-11-14 09:12:38 --> Total execution time: 0.0251
