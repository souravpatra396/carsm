<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-14 05:28:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:13 --> Config Class Initialized
INFO - 2020-12-14 05:28:13 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:13 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:13 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:13 --> URI Class Initialized
DEBUG - 2020-12-14 05:28:14 --> No URI present. Default controller set.
INFO - 2020-12-14 05:28:14 --> Router Class Initialized
INFO - 2020-12-14 05:28:14 --> Output Class Initialized
INFO - 2020-12-14 05:28:14 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:14 --> Input Class Initialized
INFO - 2020-12-14 05:28:14 --> Language Class Initialized
INFO - 2020-12-14 05:28:14 --> Loader Class Initialized
INFO - 2020-12-14 05:28:14 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:14 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:14 --> Email Class Initialized
INFO - 2020-12-14 05:28:14 --> Controller Class Initialized
INFO - 2020-12-14 05:28:14 --> Model Class Initialized
INFO - 2020-12-14 05:28:14 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:14 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-14 05:28:14 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:14 --> Total execution time: 0.2444
ERROR - 2020-12-14 05:28:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:15 --> Config Class Initialized
INFO - 2020-12-14 05:28:15 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:15 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:15 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:15 --> URI Class Initialized
DEBUG - 2020-12-14 05:28:15 --> No URI present. Default controller set.
INFO - 2020-12-14 05:28:15 --> Router Class Initialized
INFO - 2020-12-14 05:28:15 --> Output Class Initialized
INFO - 2020-12-14 05:28:15 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:15 --> Input Class Initialized
INFO - 2020-12-14 05:28:15 --> Language Class Initialized
INFO - 2020-12-14 05:28:15 --> Loader Class Initialized
INFO - 2020-12-14 05:28:15 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:15 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:15 --> Email Class Initialized
INFO - 2020-12-14 05:28:15 --> Controller Class Initialized
INFO - 2020-12-14 05:28:15 --> Model Class Initialized
INFO - 2020-12-14 05:28:15 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:15 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:15 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-14 05:28:15 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:15 --> Total execution time: 0.0515
ERROR - 2020-12-14 05:28:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:21 --> Config Class Initialized
INFO - 2020-12-14 05:28:21 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:21 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:21 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:21 --> URI Class Initialized
DEBUG - 2020-12-14 05:28:21 --> No URI present. Default controller set.
INFO - 2020-12-14 05:28:21 --> Router Class Initialized
INFO - 2020-12-14 05:28:21 --> Output Class Initialized
INFO - 2020-12-14 05:28:21 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:21 --> Input Class Initialized
INFO - 2020-12-14 05:28:21 --> Language Class Initialized
INFO - 2020-12-14 05:28:21 --> Loader Class Initialized
INFO - 2020-12-14 05:28:21 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:21 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:21 --> Email Class Initialized
INFO - 2020-12-14 05:28:21 --> Controller Class Initialized
INFO - 2020-12-14 05:28:21 --> Model Class Initialized
INFO - 2020-12-14 05:28:21 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:21 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-14 05:28:21 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:21 --> Total execution time: 0.0708
ERROR - 2020-12-14 05:28:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:33 --> Config Class Initialized
INFO - 2020-12-14 05:28:33 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:33 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:33 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:33 --> URI Class Initialized
INFO - 2020-12-14 05:28:33 --> Router Class Initialized
INFO - 2020-12-14 05:28:33 --> Output Class Initialized
INFO - 2020-12-14 05:28:33 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:33 --> Input Class Initialized
INFO - 2020-12-14 05:28:33 --> Language Class Initialized
INFO - 2020-12-14 05:28:33 --> Loader Class Initialized
INFO - 2020-12-14 05:28:33 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:33 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:33 --> Email Class Initialized
INFO - 2020-12-14 05:28:33 --> Controller Class Initialized
INFO - 2020-12-14 05:28:33 --> Model Class Initialized
INFO - 2020-12-14 05:28:33 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:33 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-14 05:28:33 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-14 05:28:33 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-14 05:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:34 --> Config Class Initialized
INFO - 2020-12-14 05:28:34 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:34 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:34 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:34 --> URI Class Initialized
INFO - 2020-12-14 05:28:34 --> Router Class Initialized
INFO - 2020-12-14 05:28:34 --> Output Class Initialized
INFO - 2020-12-14 05:28:34 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:34 --> Input Class Initialized
INFO - 2020-12-14 05:28:34 --> Language Class Initialized
INFO - 2020-12-14 05:28:34 --> Loader Class Initialized
INFO - 2020-12-14 05:28:34 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:34 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:34 --> Email Class Initialized
INFO - 2020-12-14 05:28:34 --> Controller Class Initialized
DEBUG - 2020-12-14 05:28:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-14 05:28:34 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-12-14 05:28:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:34 --> Config Class Initialized
INFO - 2020-12-14 05:28:34 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:34 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:34 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:34 --> URI Class Initialized
DEBUG - 2020-12-14 05:28:34 --> No URI present. Default controller set.
INFO - 2020-12-14 05:28:34 --> Router Class Initialized
INFO - 2020-12-14 05:28:34 --> Output Class Initialized
INFO - 2020-12-14 05:28:34 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:34 --> Input Class Initialized
INFO - 2020-12-14 05:28:34 --> Language Class Initialized
INFO - 2020-12-14 05:28:34 --> Loader Class Initialized
INFO - 2020-12-14 05:28:34 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:34 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:34 --> Email Class Initialized
INFO - 2020-12-14 05:28:34 --> Controller Class Initialized
INFO - 2020-12-14 05:28:34 --> Model Class Initialized
INFO - 2020-12-14 05:28:34 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:34 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-14 05:28:34 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:34 --> Total execution time: 0.0422
ERROR - 2020-12-14 05:28:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:39 --> Config Class Initialized
INFO - 2020-12-14 05:28:39 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:39 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:39 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:39 --> URI Class Initialized
DEBUG - 2020-12-14 05:28:39 --> No URI present. Default controller set.
INFO - 2020-12-14 05:28:39 --> Router Class Initialized
INFO - 2020-12-14 05:28:39 --> Output Class Initialized
INFO - 2020-12-14 05:28:39 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:39 --> Input Class Initialized
INFO - 2020-12-14 05:28:39 --> Language Class Initialized
INFO - 2020-12-14 05:28:39 --> Loader Class Initialized
INFO - 2020-12-14 05:28:39 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:39 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:39 --> Email Class Initialized
INFO - 2020-12-14 05:28:39 --> Controller Class Initialized
INFO - 2020-12-14 05:28:39 --> Model Class Initialized
INFO - 2020-12-14 05:28:39 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:39 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-14 05:28:39 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:39 --> Total execution time: 0.0423
ERROR - 2020-12-14 05:28:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:45 --> Config Class Initialized
INFO - 2020-12-14 05:28:45 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:45 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:45 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:45 --> URI Class Initialized
INFO - 2020-12-14 05:28:45 --> Router Class Initialized
INFO - 2020-12-14 05:28:45 --> Output Class Initialized
INFO - 2020-12-14 05:28:45 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:45 --> Input Class Initialized
INFO - 2020-12-14 05:28:45 --> Language Class Initialized
INFO - 2020-12-14 05:28:45 --> Loader Class Initialized
INFO - 2020-12-14 05:28:45 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:45 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:45 --> Email Class Initialized
INFO - 2020-12-14 05:28:45 --> Controller Class Initialized
INFO - 2020-12-14 05:28:45 --> Model Class Initialized
INFO - 2020-12-14 05:28:45 --> Model Class Initialized
DEBUG - 2020-12-14 05:28:45 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-12-14 05:28:45 --> Severity: Warning --> session_cache_limiter(): Cannot change cache limiter when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 28
ERROR - 2020-12-14 05:28:45 --> Severity: Warning --> session_cache_expire(): Cannot change cache expire when session is active /home/portaldev2020/public_html/application/controllers/Welcome.php 29
ERROR - 2020-12-14 05:28:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:46 --> Config Class Initialized
INFO - 2020-12-14 05:28:46 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:46 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:46 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:46 --> URI Class Initialized
INFO - 2020-12-14 05:28:46 --> Router Class Initialized
INFO - 2020-12-14 05:28:46 --> Output Class Initialized
INFO - 2020-12-14 05:28:46 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:46 --> Input Class Initialized
INFO - 2020-12-14 05:28:46 --> Language Class Initialized
INFO - 2020-12-14 05:28:46 --> Loader Class Initialized
INFO - 2020-12-14 05:28:46 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:46 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:46 --> Email Class Initialized
INFO - 2020-12-14 05:28:46 --> Controller Class Initialized
DEBUG - 2020-12-14 05:28:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-14 05:28:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:46 --> Model Class Initialized
INFO - 2020-12-14 05:28:46 --> Model Class Initialized
INFO - 2020-12-14 05:28:46 --> File loaded: /home/portaldev2020/public_html/application/views/dash.php
INFO - 2020-12-14 05:28:46 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:46 --> Total execution time: 0.1064
ERROR - 2020-12-14 05:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:28:56 --> Config Class Initialized
INFO - 2020-12-14 05:28:56 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:28:56 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:28:56 --> Utf8 Class Initialized
INFO - 2020-12-14 05:28:56 --> URI Class Initialized
INFO - 2020-12-14 05:28:56 --> Router Class Initialized
INFO - 2020-12-14 05:28:56 --> Output Class Initialized
INFO - 2020-12-14 05:28:56 --> Security Class Initialized
DEBUG - 2020-12-14 05:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:28:56 --> Input Class Initialized
INFO - 2020-12-14 05:28:56 --> Language Class Initialized
INFO - 2020-12-14 05:28:56 --> Loader Class Initialized
INFO - 2020-12-14 05:28:56 --> Helper loaded: url_helper
INFO - 2020-12-14 05:28:56 --> Database Driver Class Initialized
INFO - 2020-12-14 05:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:28:56 --> Email Class Initialized
INFO - 2020-12-14 05:28:56 --> Controller Class Initialized
DEBUG - 2020-12-14 05:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-14 05:28:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:28:56 --> Model Class Initialized
INFO - 2020-12-14 05:28:56 --> Model Class Initialized
INFO - 2020-12-14 05:28:56 --> File loaded: /home/portaldev2020/public_html/application/views/campain_master_list.php
INFO - 2020-12-14 05:28:56 --> Final output sent to browser
DEBUG - 2020-12-14 05:28:56 --> Total execution time: 0.0961
ERROR - 2020-12-14 05:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:29:01 --> Config Class Initialized
INFO - 2020-12-14 05:29:01 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:29:01 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:29:01 --> Utf8 Class Initialized
INFO - 2020-12-14 05:29:01 --> URI Class Initialized
INFO - 2020-12-14 05:29:01 --> Router Class Initialized
INFO - 2020-12-14 05:29:01 --> Output Class Initialized
INFO - 2020-12-14 05:29:01 --> Security Class Initialized
DEBUG - 2020-12-14 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:29:01 --> Input Class Initialized
INFO - 2020-12-14 05:29:01 --> Language Class Initialized
INFO - 2020-12-14 05:29:01 --> Loader Class Initialized
INFO - 2020-12-14 05:29:01 --> Helper loaded: url_helper
INFO - 2020-12-14 05:29:01 --> Database Driver Class Initialized
INFO - 2020-12-14 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:29:01 --> Email Class Initialized
INFO - 2020-12-14 05:29:01 --> Controller Class Initialized
DEBUG - 2020-12-14 05:29:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-12-14 05:29:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:29:01 --> Model Class Initialized
INFO - 2020-12-14 05:29:01 --> Model Class Initialized
INFO - 2020-12-14 05:29:01 --> File loaded: /home/portaldev2020/public_html/application/views/campain_master_list.php
INFO - 2020-12-14 05:29:01 --> Final output sent to browser
DEBUG - 2020-12-14 05:29:01 --> Total execution time: 0.0575
ERROR - 2020-12-14 05:29:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-14 05:29:04 --> Config Class Initialized
INFO - 2020-12-14 05:29:04 --> Hooks Class Initialized
DEBUG - 2020-12-14 05:29:04 --> UTF-8 Support Enabled
INFO - 2020-12-14 05:29:04 --> Utf8 Class Initialized
INFO - 2020-12-14 05:29:04 --> URI Class Initialized
DEBUG - 2020-12-14 05:29:04 --> No URI present. Default controller set.
INFO - 2020-12-14 05:29:04 --> Router Class Initialized
INFO - 2020-12-14 05:29:04 --> Output Class Initialized
INFO - 2020-12-14 05:29:04 --> Security Class Initialized
DEBUG - 2020-12-14 05:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-14 05:29:04 --> Input Class Initialized
INFO - 2020-12-14 05:29:04 --> Language Class Initialized
INFO - 2020-12-14 05:29:04 --> Loader Class Initialized
INFO - 2020-12-14 05:29:04 --> Helper loaded: url_helper
INFO - 2020-12-14 05:29:04 --> Database Driver Class Initialized
INFO - 2020-12-14 05:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-14 05:29:04 --> Email Class Initialized
INFO - 2020-12-14 05:29:04 --> Controller Class Initialized
INFO - 2020-12-14 05:29:04 --> Model Class Initialized
INFO - 2020-12-14 05:29:04 --> Model Class Initialized
DEBUG - 2020-12-14 05:29:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-14 05:29:04 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-14 05:29:04 --> Final output sent to browser
DEBUG - 2020-12-14 05:29:04 --> Total execution time: 0.0511
