<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-15 06:09:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:09:53 --> Config Class Initialized
INFO - 2020-09-15 06:09:53 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:09:53 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:09:53 --> Utf8 Class Initialized
INFO - 2020-09-15 06:09:53 --> URI Class Initialized
DEBUG - 2020-09-15 06:09:53 --> No URI present. Default controller set.
INFO - 2020-09-15 06:09:53 --> Router Class Initialized
INFO - 2020-09-15 06:09:53 --> Output Class Initialized
INFO - 2020-09-15 06:09:53 --> Security Class Initialized
DEBUG - 2020-09-15 06:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:09:53 --> Input Class Initialized
INFO - 2020-09-15 06:09:53 --> Language Class Initialized
INFO - 2020-09-15 06:09:53 --> Loader Class Initialized
INFO - 2020-09-15 06:09:53 --> Helper loaded: url_helper
INFO - 2020-09-15 06:09:53 --> Database Driver Class Initialized
INFO - 2020-09-15 06:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:09:53 --> Email Class Initialized
INFO - 2020-09-15 06:09:53 --> Controller Class Initialized
INFO - 2020-09-15 06:09:53 --> Model Class Initialized
INFO - 2020-09-15 06:09:53 --> Model Class Initialized
DEBUG - 2020-09-15 06:09:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:09:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:09:53 --> Final output sent to browser
DEBUG - 2020-09-15 06:09:53 --> Total execution time: 0.0735
ERROR - 2020-09-15 06:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:09:58 --> Config Class Initialized
INFO - 2020-09-15 06:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:09:58 --> Utf8 Class Initialized
INFO - 2020-09-15 06:09:58 --> URI Class Initialized
INFO - 2020-09-15 06:09:58 --> Router Class Initialized
INFO - 2020-09-15 06:09:58 --> Output Class Initialized
INFO - 2020-09-15 06:09:58 --> Security Class Initialized
DEBUG - 2020-09-15 06:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:09:58 --> Input Class Initialized
INFO - 2020-09-15 06:09:58 --> Language Class Initialized
INFO - 2020-09-15 06:09:58 --> Loader Class Initialized
INFO - 2020-09-15 06:09:58 --> Helper loaded: url_helper
INFO - 2020-09-15 06:09:58 --> Database Driver Class Initialized
INFO - 2020-09-15 06:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:09:58 --> Email Class Initialized
INFO - 2020-09-15 06:09:58 --> Controller Class Initialized
INFO - 2020-09-15 06:09:58 --> Model Class Initialized
INFO - 2020-09-15 06:09:58 --> Model Class Initialized
DEBUG - 2020-09-15 06:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:09:58 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:09:58 --> Config Class Initialized
INFO - 2020-09-15 06:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:09:58 --> Utf8 Class Initialized
INFO - 2020-09-15 06:09:58 --> URI Class Initialized
INFO - 2020-09-15 06:09:58 --> Router Class Initialized
INFO - 2020-09-15 06:09:58 --> Output Class Initialized
INFO - 2020-09-15 06:09:58 --> Security Class Initialized
DEBUG - 2020-09-15 06:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:09:58 --> Input Class Initialized
INFO - 2020-09-15 06:09:58 --> Language Class Initialized
INFO - 2020-09-15 06:09:58 --> Loader Class Initialized
INFO - 2020-09-15 06:09:58 --> Helper loaded: url_helper
INFO - 2020-09-15 06:09:58 --> Database Driver Class Initialized
INFO - 2020-09-15 06:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:09:58 --> Email Class Initialized
INFO - 2020-09-15 06:09:58 --> Controller Class Initialized
INFO - 2020-09-15 06:09:58 --> Model Class Initialized
INFO - 2020-09-15 06:09:58 --> Model Class Initialized
DEBUG - 2020-09-15 06:09:58 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:09:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:09:58 --> Config Class Initialized
INFO - 2020-09-15 06:09:58 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:09:58 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:09:58 --> Utf8 Class Initialized
INFO - 2020-09-15 06:09:58 --> URI Class Initialized
INFO - 2020-09-15 06:09:58 --> Router Class Initialized
INFO - 2020-09-15 06:09:58 --> Output Class Initialized
INFO - 2020-09-15 06:09:58 --> Security Class Initialized
DEBUG - 2020-09-15 06:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:09:58 --> Input Class Initialized
INFO - 2020-09-15 06:09:58 --> Language Class Initialized
INFO - 2020-09-15 06:09:58 --> Loader Class Initialized
INFO - 2020-09-15 06:09:58 --> Helper loaded: url_helper
INFO - 2020-09-15 06:09:58 --> Database Driver Class Initialized
INFO - 2020-09-15 06:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:09:58 --> Email Class Initialized
INFO - 2020-09-15 06:09:58 --> Controller Class Initialized
DEBUG - 2020-09-15 06:09:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:09:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:09:58 --> Model Class Initialized
INFO - 2020-09-15 06:09:58 --> Model Class Initialized
INFO - 2020-09-15 06:09:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 06:09:58 --> Final output sent to browser
DEBUG - 2020-09-15 06:09:58 --> Total execution time: 0.0381
ERROR - 2020-09-15 06:09:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:09:59 --> Config Class Initialized
INFO - 2020-09-15 06:09:59 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:09:59 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:09:59 --> Utf8 Class Initialized
INFO - 2020-09-15 06:09:59 --> URI Class Initialized
DEBUG - 2020-09-15 06:09:59 --> No URI present. Default controller set.
INFO - 2020-09-15 06:09:59 --> Router Class Initialized
INFO - 2020-09-15 06:09:59 --> Output Class Initialized
INFO - 2020-09-15 06:09:59 --> Security Class Initialized
DEBUG - 2020-09-15 06:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:09:59 --> Input Class Initialized
INFO - 2020-09-15 06:09:59 --> Language Class Initialized
INFO - 2020-09-15 06:09:59 --> Loader Class Initialized
INFO - 2020-09-15 06:09:59 --> Helper loaded: url_helper
INFO - 2020-09-15 06:09:59 --> Database Driver Class Initialized
INFO - 2020-09-15 06:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:09:59 --> Email Class Initialized
INFO - 2020-09-15 06:09:59 --> Controller Class Initialized
INFO - 2020-09-15 06:09:59 --> Model Class Initialized
INFO - 2020-09-15 06:09:59 --> Model Class Initialized
DEBUG - 2020-09-15 06:09:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:09:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:09:59 --> Final output sent to browser
DEBUG - 2020-09-15 06:09:59 --> Total execution time: 0.0456
ERROR - 2020-09-15 06:10:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:10:26 --> Config Class Initialized
INFO - 2020-09-15 06:10:26 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:10:26 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:10:26 --> Utf8 Class Initialized
INFO - 2020-09-15 06:10:26 --> URI Class Initialized
INFO - 2020-09-15 06:10:26 --> Router Class Initialized
INFO - 2020-09-15 06:10:26 --> Output Class Initialized
INFO - 2020-09-15 06:10:26 --> Security Class Initialized
DEBUG - 2020-09-15 06:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:10:26 --> Input Class Initialized
INFO - 2020-09-15 06:10:26 --> Language Class Initialized
INFO - 2020-09-15 06:10:26 --> Loader Class Initialized
INFO - 2020-09-15 06:10:26 --> Helper loaded: url_helper
INFO - 2020-09-15 06:10:26 --> Database Driver Class Initialized
INFO - 2020-09-15 06:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:10:26 --> Email Class Initialized
INFO - 2020-09-15 06:10:26 --> Controller Class Initialized
DEBUG - 2020-09-15 06:10:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:10:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:10:26 --> Model Class Initialized
INFO - 2020-09-15 06:10:26 --> Model Class Initialized
INFO - 2020-09-15 06:10:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 06:10:26 --> Final output sent to browser
DEBUG - 2020-09-15 06:10:26 --> Total execution time: 0.0379
ERROR - 2020-09-15 06:10:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:10:30 --> Config Class Initialized
INFO - 2020-09-15 06:10:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:10:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:10:30 --> Utf8 Class Initialized
INFO - 2020-09-15 06:10:30 --> URI Class Initialized
INFO - 2020-09-15 06:10:30 --> Router Class Initialized
INFO - 2020-09-15 06:10:30 --> Output Class Initialized
INFO - 2020-09-15 06:10:30 --> Security Class Initialized
DEBUG - 2020-09-15 06:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:10:30 --> Input Class Initialized
INFO - 2020-09-15 06:10:30 --> Language Class Initialized
INFO - 2020-09-15 06:10:30 --> Loader Class Initialized
INFO - 2020-09-15 06:10:30 --> Helper loaded: url_helper
INFO - 2020-09-15 06:10:30 --> Database Driver Class Initialized
INFO - 2020-09-15 06:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:10:30 --> Email Class Initialized
INFO - 2020-09-15 06:10:30 --> Controller Class Initialized
DEBUG - 2020-09-15 06:10:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:10:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:10:30 --> Model Class Initialized
INFO - 2020-09-15 06:10:30 --> Model Class Initialized
INFO - 2020-09-15 06:10:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 06:10:30 --> Final output sent to browser
DEBUG - 2020-09-15 06:10:30 --> Total execution time: 0.0216
ERROR - 2020-09-15 06:11:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:04 --> Config Class Initialized
INFO - 2020-09-15 06:11:04 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:04 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:04 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:04 --> URI Class Initialized
INFO - 2020-09-15 06:11:04 --> Router Class Initialized
INFO - 2020-09-15 06:11:04 --> Output Class Initialized
INFO - 2020-09-15 06:11:04 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:04 --> Input Class Initialized
INFO - 2020-09-15 06:11:04 --> Language Class Initialized
INFO - 2020-09-15 06:11:04 --> Loader Class Initialized
INFO - 2020-09-15 06:11:04 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:04 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:04 --> Email Class Initialized
INFO - 2020-09-15 06:11:04 --> Controller Class Initialized
DEBUG - 2020-09-15 06:11:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:04 --> Model Class Initialized
INFO - 2020-09-15 06:11:04 --> Model Class Initialized
INFO - 2020-09-15 06:11:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 06:11:04 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:04 --> Total execution time: 0.0224
ERROR - 2020-09-15 06:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:09 --> Config Class Initialized
INFO - 2020-09-15 06:11:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:09 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:09 --> URI Class Initialized
INFO - 2020-09-15 06:11:09 --> Router Class Initialized
INFO - 2020-09-15 06:11:09 --> Output Class Initialized
INFO - 2020-09-15 06:11:09 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:09 --> Input Class Initialized
INFO - 2020-09-15 06:11:09 --> Language Class Initialized
INFO - 2020-09-15 06:11:09 --> Loader Class Initialized
INFO - 2020-09-15 06:11:09 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:09 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:09 --> Email Class Initialized
INFO - 2020-09-15 06:11:09 --> Controller Class Initialized
DEBUG - 2020-09-15 06:11:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:09 --> Model Class Initialized
INFO - 2020-09-15 06:11:09 --> Model Class Initialized
INFO - 2020-09-15 06:11:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 06:11:09 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:09 --> Total execution time: 0.0224
ERROR - 2020-09-15 06:11:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:16 --> Config Class Initialized
INFO - 2020-09-15 06:11:16 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:16 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:16 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:16 --> URI Class Initialized
DEBUG - 2020-09-15 06:11:16 --> No URI present. Default controller set.
INFO - 2020-09-15 06:11:16 --> Router Class Initialized
INFO - 2020-09-15 06:11:16 --> Output Class Initialized
INFO - 2020-09-15 06:11:16 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:16 --> Input Class Initialized
INFO - 2020-09-15 06:11:16 --> Language Class Initialized
INFO - 2020-09-15 06:11:16 --> Loader Class Initialized
INFO - 2020-09-15 06:11:16 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:16 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:16 --> Email Class Initialized
INFO - 2020-09-15 06:11:16 --> Controller Class Initialized
INFO - 2020-09-15 06:11:16 --> Model Class Initialized
INFO - 2020-09-15 06:11:16 --> Model Class Initialized
DEBUG - 2020-09-15 06:11:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:11:16 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:16 --> Total execution time: 0.0203
ERROR - 2020-09-15 06:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:22 --> Config Class Initialized
INFO - 2020-09-15 06:11:22 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:22 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:22 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:22 --> URI Class Initialized
INFO - 2020-09-15 06:11:22 --> Router Class Initialized
INFO - 2020-09-15 06:11:22 --> Output Class Initialized
INFO - 2020-09-15 06:11:22 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:22 --> Input Class Initialized
INFO - 2020-09-15 06:11:22 --> Language Class Initialized
INFO - 2020-09-15 06:11:22 --> Loader Class Initialized
INFO - 2020-09-15 06:11:22 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:22 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:22 --> Email Class Initialized
INFO - 2020-09-15 06:11:22 --> Controller Class Initialized
INFO - 2020-09-15 06:11:22 --> Model Class Initialized
INFO - 2020-09-15 06:11:22 --> Model Class Initialized
DEBUG - 2020-09-15 06:11:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:22 --> Model Class Initialized
INFO - 2020-09-15 06:11:22 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:22 --> Total execution time: 0.0219
ERROR - 2020-09-15 06:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:23 --> Config Class Initialized
INFO - 2020-09-15 06:11:23 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:23 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:23 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:23 --> URI Class Initialized
INFO - 2020-09-15 06:11:23 --> Router Class Initialized
INFO - 2020-09-15 06:11:23 --> Output Class Initialized
INFO - 2020-09-15 06:11:23 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:23 --> Input Class Initialized
INFO - 2020-09-15 06:11:23 --> Language Class Initialized
INFO - 2020-09-15 06:11:23 --> Loader Class Initialized
INFO - 2020-09-15 06:11:23 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:23 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:23 --> Email Class Initialized
INFO - 2020-09-15 06:11:23 --> Controller Class Initialized
INFO - 2020-09-15 06:11:23 --> Model Class Initialized
INFO - 2020-09-15 06:11:23 --> Model Class Initialized
DEBUG - 2020-09-15 06:11:23 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:11:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:23 --> Config Class Initialized
INFO - 2020-09-15 06:11:23 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:23 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:23 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:23 --> URI Class Initialized
DEBUG - 2020-09-15 06:11:23 --> No URI present. Default controller set.
INFO - 2020-09-15 06:11:23 --> Router Class Initialized
INFO - 2020-09-15 06:11:23 --> Output Class Initialized
INFO - 2020-09-15 06:11:23 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:23 --> Input Class Initialized
INFO - 2020-09-15 06:11:23 --> Language Class Initialized
INFO - 2020-09-15 06:11:23 --> Loader Class Initialized
INFO - 2020-09-15 06:11:23 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:23 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:23 --> Email Class Initialized
INFO - 2020-09-15 06:11:23 --> Controller Class Initialized
INFO - 2020-09-15 06:11:23 --> Model Class Initialized
INFO - 2020-09-15 06:11:23 --> Model Class Initialized
DEBUG - 2020-09-15 06:11:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:11:23 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:23 --> Total execution time: 0.0238
ERROR - 2020-09-15 06:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:29 --> Config Class Initialized
INFO - 2020-09-15 06:11:29 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:29 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:29 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:29 --> URI Class Initialized
INFO - 2020-09-15 06:11:29 --> Router Class Initialized
INFO - 2020-09-15 06:11:29 --> Output Class Initialized
INFO - 2020-09-15 06:11:29 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:29 --> Input Class Initialized
INFO - 2020-09-15 06:11:29 --> Language Class Initialized
INFO - 2020-09-15 06:11:29 --> Loader Class Initialized
INFO - 2020-09-15 06:11:29 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:29 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:29 --> Email Class Initialized
INFO - 2020-09-15 06:11:29 --> Controller Class Initialized
INFO - 2020-09-15 06:11:29 --> Model Class Initialized
INFO - 2020-09-15 06:11:29 --> Model Class Initialized
DEBUG - 2020-09-15 06:11:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:29 --> Model Class Initialized
INFO - 2020-09-15 06:11:29 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:29 --> Total execution time: 0.0213
ERROR - 2020-09-15 06:11:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:29 --> Config Class Initialized
INFO - 2020-09-15 06:11:29 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:29 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:29 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:29 --> URI Class Initialized
INFO - 2020-09-15 06:11:29 --> Router Class Initialized
INFO - 2020-09-15 06:11:29 --> Output Class Initialized
INFO - 2020-09-15 06:11:29 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:29 --> Input Class Initialized
INFO - 2020-09-15 06:11:29 --> Language Class Initialized
INFO - 2020-09-15 06:11:29 --> Loader Class Initialized
INFO - 2020-09-15 06:11:29 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:29 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:29 --> Email Class Initialized
INFO - 2020-09-15 06:11:29 --> Controller Class Initialized
INFO - 2020-09-15 06:11:29 --> Model Class Initialized
INFO - 2020-09-15 06:11:29 --> Model Class Initialized
DEBUG - 2020-09-15 06:11:29 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:11:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:30 --> Config Class Initialized
INFO - 2020-09-15 06:11:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:30 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:30 --> URI Class Initialized
INFO - 2020-09-15 06:11:30 --> Router Class Initialized
INFO - 2020-09-15 06:11:30 --> Output Class Initialized
INFO - 2020-09-15 06:11:30 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:30 --> Input Class Initialized
INFO - 2020-09-15 06:11:30 --> Language Class Initialized
INFO - 2020-09-15 06:11:30 --> Loader Class Initialized
INFO - 2020-09-15 06:11:30 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:30 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:30 --> Email Class Initialized
INFO - 2020-09-15 06:11:30 --> Controller Class Initialized
DEBUG - 2020-09-15 06:11:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:30 --> Model Class Initialized
INFO - 2020-09-15 06:11:30 --> Model Class Initialized
INFO - 2020-09-15 06:11:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 06:11:30 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:30 --> Total execution time: 0.0200
ERROR - 2020-09-15 06:11:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:37 --> Config Class Initialized
INFO - 2020-09-15 06:11:37 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:37 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:37 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:37 --> URI Class Initialized
INFO - 2020-09-15 06:11:37 --> Router Class Initialized
INFO - 2020-09-15 06:11:37 --> Output Class Initialized
INFO - 2020-09-15 06:11:37 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:37 --> Input Class Initialized
INFO - 2020-09-15 06:11:37 --> Language Class Initialized
INFO - 2020-09-15 06:11:37 --> Loader Class Initialized
INFO - 2020-09-15 06:11:37 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:37 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:37 --> Email Class Initialized
INFO - 2020-09-15 06:11:37 --> Controller Class Initialized
DEBUG - 2020-09-15 06:11:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:37 --> Model Class Initialized
INFO - 2020-09-15 06:11:37 --> Model Class Initialized
INFO - 2020-09-15 06:11:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 06:11:37 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:37 --> Total execution time: 0.0257
ERROR - 2020-09-15 06:11:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:11:40 --> Config Class Initialized
INFO - 2020-09-15 06:11:40 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:11:40 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:11:40 --> Utf8 Class Initialized
INFO - 2020-09-15 06:11:40 --> URI Class Initialized
INFO - 2020-09-15 06:11:40 --> Router Class Initialized
INFO - 2020-09-15 06:11:40 --> Output Class Initialized
INFO - 2020-09-15 06:11:40 --> Security Class Initialized
DEBUG - 2020-09-15 06:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:11:40 --> Input Class Initialized
INFO - 2020-09-15 06:11:40 --> Language Class Initialized
INFO - 2020-09-15 06:11:40 --> Loader Class Initialized
INFO - 2020-09-15 06:11:40 --> Helper loaded: url_helper
INFO - 2020-09-15 06:11:40 --> Database Driver Class Initialized
INFO - 2020-09-15 06:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:11:40 --> Email Class Initialized
INFO - 2020-09-15 06:11:40 --> Controller Class Initialized
DEBUG - 2020-09-15 06:11:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:11:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:11:40 --> Model Class Initialized
INFO - 2020-09-15 06:11:40 --> Model Class Initialized
INFO - 2020-09-15 06:11:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 06:11:40 --> Final output sent to browser
DEBUG - 2020-09-15 06:11:40 --> Total execution time: 0.0199
ERROR - 2020-09-15 06:12:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:12:14 --> Config Class Initialized
INFO - 2020-09-15 06:12:14 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:12:14 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:12:14 --> Utf8 Class Initialized
INFO - 2020-09-15 06:12:14 --> URI Class Initialized
INFO - 2020-09-15 06:12:14 --> Router Class Initialized
INFO - 2020-09-15 06:12:14 --> Output Class Initialized
INFO - 2020-09-15 06:12:14 --> Security Class Initialized
DEBUG - 2020-09-15 06:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:12:14 --> Input Class Initialized
INFO - 2020-09-15 06:12:14 --> Language Class Initialized
INFO - 2020-09-15 06:12:14 --> Loader Class Initialized
INFO - 2020-09-15 06:12:14 --> Helper loaded: url_helper
INFO - 2020-09-15 06:12:14 --> Database Driver Class Initialized
INFO - 2020-09-15 06:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:12:14 --> Email Class Initialized
INFO - 2020-09-15 06:12:14 --> Controller Class Initialized
DEBUG - 2020-09-15 06:12:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:12:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:12:14 --> Model Class Initialized
INFO - 2020-09-15 06:12:14 --> Model Class Initialized
INFO - 2020-09-15 06:12:14 --> Model Class Initialized
INFO - 2020-09-15 06:12:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 06:12:14 --> Final output sent to browser
DEBUG - 2020-09-15 06:12:14 --> Total execution time: 0.0761
ERROR - 2020-09-15 06:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:09 --> Config Class Initialized
INFO - 2020-09-15 06:13:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:09 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:09 --> URI Class Initialized
INFO - 2020-09-15 06:13:09 --> Router Class Initialized
INFO - 2020-09-15 06:13:09 --> Output Class Initialized
INFO - 2020-09-15 06:13:09 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:09 --> Input Class Initialized
INFO - 2020-09-15 06:13:09 --> Language Class Initialized
INFO - 2020-09-15 06:13:09 --> Loader Class Initialized
INFO - 2020-09-15 06:13:09 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:09 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:09 --> Email Class Initialized
INFO - 2020-09-15 06:13:09 --> Controller Class Initialized
INFO - 2020-09-15 06:13:09 --> Model Class Initialized
INFO - 2020-09-15 06:13:09 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:13:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:13:09 --> Model Class Initialized
INFO - 2020-09-15 06:13:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/pwd_reset1.php
INFO - 2020-09-15 06:13:09 --> Final output sent to browser
DEBUG - 2020-09-15 06:13:09 --> Total execution time: 0.0427
ERROR - 2020-09-15 06:13:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:31 --> Config Class Initialized
INFO - 2020-09-15 06:13:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:31 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:31 --> URI Class Initialized
INFO - 2020-09-15 06:13:31 --> Router Class Initialized
INFO - 2020-09-15 06:13:31 --> Output Class Initialized
INFO - 2020-09-15 06:13:31 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:31 --> Input Class Initialized
INFO - 2020-09-15 06:13:31 --> Language Class Initialized
INFO - 2020-09-15 06:13:31 --> Loader Class Initialized
INFO - 2020-09-15 06:13:31 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:31 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:31 --> Email Class Initialized
INFO - 2020-09-15 06:13:31 --> Controller Class Initialized
INFO - 2020-09-15 06:13:31 --> Model Class Initialized
INFO - 2020-09-15 06:13:31 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:13:31 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:32 --> Config Class Initialized
INFO - 2020-09-15 06:13:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:32 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:32 --> URI Class Initialized
INFO - 2020-09-15 06:13:32 --> Router Class Initialized
INFO - 2020-09-15 06:13:32 --> Output Class Initialized
INFO - 2020-09-15 06:13:32 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:32 --> Input Class Initialized
INFO - 2020-09-15 06:13:32 --> Language Class Initialized
INFO - 2020-09-15 06:13:32 --> Loader Class Initialized
INFO - 2020-09-15 06:13:32 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:32 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:32 --> Email Class Initialized
INFO - 2020-09-15 06:13:32 --> Controller Class Initialized
INFO - 2020-09-15 06:13:32 --> Model Class Initialized
INFO - 2020-09-15 06:13:32 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:13:32 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:32 --> Config Class Initialized
INFO - 2020-09-15 06:13:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:32 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:32 --> URI Class Initialized
DEBUG - 2020-09-15 06:13:32 --> No URI present. Default controller set.
INFO - 2020-09-15 06:13:32 --> Router Class Initialized
INFO - 2020-09-15 06:13:32 --> Output Class Initialized
INFO - 2020-09-15 06:13:32 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:32 --> Input Class Initialized
INFO - 2020-09-15 06:13:32 --> Language Class Initialized
INFO - 2020-09-15 06:13:32 --> Loader Class Initialized
INFO - 2020-09-15 06:13:32 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:32 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:32 --> Email Class Initialized
INFO - 2020-09-15 06:13:32 --> Controller Class Initialized
INFO - 2020-09-15 06:13:32 --> Model Class Initialized
INFO - 2020-09-15 06:13:32 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:13:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:13:32 --> Final output sent to browser
DEBUG - 2020-09-15 06:13:32 --> Total execution time: 0.0258
ERROR - 2020-09-15 06:13:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:32 --> Config Class Initialized
INFO - 2020-09-15 06:13:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:32 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:32 --> URI Class Initialized
DEBUG - 2020-09-15 06:13:32 --> No URI present. Default controller set.
INFO - 2020-09-15 06:13:32 --> Router Class Initialized
INFO - 2020-09-15 06:13:32 --> Output Class Initialized
INFO - 2020-09-15 06:13:32 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:32 --> Input Class Initialized
INFO - 2020-09-15 06:13:32 --> Language Class Initialized
INFO - 2020-09-15 06:13:32 --> Loader Class Initialized
INFO - 2020-09-15 06:13:32 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:32 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:32 --> Email Class Initialized
INFO - 2020-09-15 06:13:32 --> Controller Class Initialized
INFO - 2020-09-15 06:13:32 --> Model Class Initialized
INFO - 2020-09-15 06:13:32 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:13:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:13:32 --> Final output sent to browser
DEBUG - 2020-09-15 06:13:32 --> Total execution time: 0.0187
ERROR - 2020-09-15 06:13:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:53 --> Config Class Initialized
INFO - 2020-09-15 06:13:53 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:53 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:53 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:53 --> URI Class Initialized
INFO - 2020-09-15 06:13:53 --> Router Class Initialized
INFO - 2020-09-15 06:13:53 --> Output Class Initialized
INFO - 2020-09-15 06:13:53 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:53 --> Input Class Initialized
INFO - 2020-09-15 06:13:53 --> Language Class Initialized
INFO - 2020-09-15 06:13:53 --> Loader Class Initialized
INFO - 2020-09-15 06:13:53 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:53 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:53 --> Email Class Initialized
INFO - 2020-09-15 06:13:53 --> Controller Class Initialized
INFO - 2020-09-15 06:13:53 --> Model Class Initialized
INFO - 2020-09-15 06:13:53 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:13:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:13:53 --> Model Class Initialized
ERROR - 2020-09-15 06:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:13:54 --> Config Class Initialized
INFO - 2020-09-15 06:13:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:13:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:13:54 --> Utf8 Class Initialized
INFO - 2020-09-15 06:13:54 --> URI Class Initialized
DEBUG - 2020-09-15 06:13:54 --> No URI present. Default controller set.
INFO - 2020-09-15 06:13:54 --> Router Class Initialized
INFO - 2020-09-15 06:13:54 --> Output Class Initialized
INFO - 2020-09-15 06:13:54 --> Security Class Initialized
DEBUG - 2020-09-15 06:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:13:54 --> Input Class Initialized
INFO - 2020-09-15 06:13:54 --> Language Class Initialized
INFO - 2020-09-15 06:13:54 --> Loader Class Initialized
INFO - 2020-09-15 06:13:54 --> Helper loaded: url_helper
INFO - 2020-09-15 06:13:54 --> Database Driver Class Initialized
INFO - 2020-09-15 06:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:13:54 --> Email Class Initialized
INFO - 2020-09-15 06:13:54 --> Controller Class Initialized
INFO - 2020-09-15 06:13:54 --> Model Class Initialized
INFO - 2020-09-15 06:13:54 --> Model Class Initialized
DEBUG - 2020-09-15 06:13:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:13:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:13:54 --> Final output sent to browser
DEBUG - 2020-09-15 06:13:54 --> Total execution time: 0.0290
ERROR - 2020-09-15 06:30:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:30:41 --> Config Class Initialized
INFO - 2020-09-15 06:30:41 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:30:41 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:30:41 --> Utf8 Class Initialized
INFO - 2020-09-15 06:30:41 --> URI Class Initialized
INFO - 2020-09-15 06:30:41 --> Router Class Initialized
INFO - 2020-09-15 06:30:41 --> Output Class Initialized
INFO - 2020-09-15 06:30:41 --> Security Class Initialized
DEBUG - 2020-09-15 06:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:30:41 --> Input Class Initialized
INFO - 2020-09-15 06:30:41 --> Language Class Initialized
INFO - 2020-09-15 06:30:41 --> Loader Class Initialized
INFO - 2020-09-15 06:30:41 --> Helper loaded: url_helper
INFO - 2020-09-15 06:30:41 --> Database Driver Class Initialized
INFO - 2020-09-15 06:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:30:41 --> Email Class Initialized
INFO - 2020-09-15 06:30:41 --> Controller Class Initialized
DEBUG - 2020-09-15 06:30:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:30:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:30:41 --> Model Class Initialized
INFO - 2020-09-15 06:30:41 --> Model Class Initialized
INFO - 2020-09-15 06:30:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 06:30:41 --> Final output sent to browser
DEBUG - 2020-09-15 06:30:41 --> Total execution time: 0.0195
ERROR - 2020-09-15 06:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:30:53 --> Config Class Initialized
INFO - 2020-09-15 06:30:53 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:30:53 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:30:53 --> Utf8 Class Initialized
INFO - 2020-09-15 06:30:53 --> URI Class Initialized
INFO - 2020-09-15 06:30:53 --> Router Class Initialized
INFO - 2020-09-15 06:30:53 --> Output Class Initialized
INFO - 2020-09-15 06:30:53 --> Security Class Initialized
DEBUG - 2020-09-15 06:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:30:53 --> Input Class Initialized
INFO - 2020-09-15 06:30:53 --> Language Class Initialized
INFO - 2020-09-15 06:30:53 --> Loader Class Initialized
INFO - 2020-09-15 06:30:53 --> Helper loaded: url_helper
INFO - 2020-09-15 06:30:53 --> Database Driver Class Initialized
INFO - 2020-09-15 06:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:30:53 --> Email Class Initialized
INFO - 2020-09-15 06:30:53 --> Controller Class Initialized
DEBUG - 2020-09-15 06:30:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:30:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:30:53 --> Model Class Initialized
INFO - 2020-09-15 06:30:53 --> Model Class Initialized
INFO - 2020-09-15 06:30:53 --> Model Class Initialized
INFO - 2020-09-15 06:30:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 06:30:53 --> Final output sent to browser
DEBUG - 2020-09-15 06:30:53 --> Total execution time: 0.0872
ERROR - 2020-09-15 06:34:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:34:43 --> Config Class Initialized
INFO - 2020-09-15 06:34:43 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:34:43 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:34:43 --> Utf8 Class Initialized
INFO - 2020-09-15 06:34:43 --> URI Class Initialized
DEBUG - 2020-09-15 06:34:43 --> No URI present. Default controller set.
INFO - 2020-09-15 06:34:43 --> Router Class Initialized
INFO - 2020-09-15 06:34:43 --> Output Class Initialized
INFO - 2020-09-15 06:34:43 --> Security Class Initialized
DEBUG - 2020-09-15 06:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:34:43 --> Input Class Initialized
INFO - 2020-09-15 06:34:43 --> Language Class Initialized
INFO - 2020-09-15 06:34:43 --> Loader Class Initialized
INFO - 2020-09-15 06:34:43 --> Helper loaded: url_helper
INFO - 2020-09-15 06:34:43 --> Database Driver Class Initialized
INFO - 2020-09-15 06:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:34:43 --> Email Class Initialized
INFO - 2020-09-15 06:34:43 --> Controller Class Initialized
INFO - 2020-09-15 06:34:43 --> Model Class Initialized
INFO - 2020-09-15 06:34:43 --> Model Class Initialized
DEBUG - 2020-09-15 06:34:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:34:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:34:43 --> Final output sent to browser
DEBUG - 2020-09-15 06:34:43 --> Total execution time: 0.0221
ERROR - 2020-09-15 06:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:36:42 --> Config Class Initialized
INFO - 2020-09-15 06:36:42 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:36:42 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:36:42 --> Utf8 Class Initialized
INFO - 2020-09-15 06:36:42 --> URI Class Initialized
INFO - 2020-09-15 06:36:42 --> Router Class Initialized
INFO - 2020-09-15 06:36:42 --> Output Class Initialized
INFO - 2020-09-15 06:36:42 --> Security Class Initialized
DEBUG - 2020-09-15 06:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:36:42 --> Input Class Initialized
INFO - 2020-09-15 06:36:42 --> Language Class Initialized
INFO - 2020-09-15 06:36:42 --> Loader Class Initialized
INFO - 2020-09-15 06:36:42 --> Helper loaded: url_helper
ERROR - 2020-09-15 06:36:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:36:42 --> Config Class Initialized
INFO - 2020-09-15 06:36:42 --> Hooks Class Initialized
INFO - 2020-09-15 06:36:42 --> Database Driver Class Initialized
DEBUG - 2020-09-15 06:36:42 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:36:42 --> Utf8 Class Initialized
INFO - 2020-09-15 06:36:42 --> URI Class Initialized
INFO - 2020-09-15 06:36:42 --> Router Class Initialized
INFO - 2020-09-15 06:36:42 --> Output Class Initialized
INFO - 2020-09-15 06:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:36:42 --> Security Class Initialized
DEBUG - 2020-09-15 06:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:36:42 --> Input Class Initialized
INFO - 2020-09-15 06:36:42 --> Language Class Initialized
INFO - 2020-09-15 06:36:42 --> Email Class Initialized
INFO - 2020-09-15 06:36:42 --> Controller Class Initialized
INFO - 2020-09-15 06:36:42 --> Model Class Initialized
INFO - 2020-09-15 06:36:42 --> Loader Class Initialized
INFO - 2020-09-15 06:36:42 --> Model Class Initialized
DEBUG - 2020-09-15 06:36:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:36:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:36:42 --> Model Class Initialized
INFO - 2020-09-15 06:36:42 --> Helper loaded: url_helper
INFO - 2020-09-15 06:36:42 --> Final output sent to browser
DEBUG - 2020-09-15 06:36:42 --> Total execution time: 0.0270
INFO - 2020-09-15 06:36:42 --> Database Driver Class Initialized
INFO - 2020-09-15 06:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:36:42 --> Email Class Initialized
INFO - 2020-09-15 06:36:42 --> Controller Class Initialized
INFO - 2020-09-15 06:36:42 --> Model Class Initialized
INFO - 2020-09-15 06:36:42 --> Model Class Initialized
DEBUG - 2020-09-15 06:36:42 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:36:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:36:43 --> Config Class Initialized
INFO - 2020-09-15 06:36:43 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:36:43 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:36:43 --> Utf8 Class Initialized
INFO - 2020-09-15 06:36:43 --> URI Class Initialized
INFO - 2020-09-15 06:36:43 --> Router Class Initialized
INFO - 2020-09-15 06:36:43 --> Output Class Initialized
INFO - 2020-09-15 06:36:43 --> Security Class Initialized
DEBUG - 2020-09-15 06:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:36:43 --> Input Class Initialized
INFO - 2020-09-15 06:36:43 --> Language Class Initialized
INFO - 2020-09-15 06:36:43 --> Loader Class Initialized
INFO - 2020-09-15 06:36:43 --> Helper loaded: url_helper
INFO - 2020-09-15 06:36:43 --> Database Driver Class Initialized
INFO - 2020-09-15 06:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:36:43 --> Email Class Initialized
INFO - 2020-09-15 06:36:43 --> Controller Class Initialized
DEBUG - 2020-09-15 06:36:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:36:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:36:43 --> Model Class Initialized
INFO - 2020-09-15 06:36:43 --> Model Class Initialized
INFO - 2020-09-15 06:36:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-15 06:36:43 --> Final output sent to browser
DEBUG - 2020-09-15 06:36:43 --> Total execution time: 0.0202
ERROR - 2020-09-15 06:37:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:37:01 --> Config Class Initialized
INFO - 2020-09-15 06:37:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:37:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:37:01 --> Utf8 Class Initialized
INFO - 2020-09-15 06:37:01 --> URI Class Initialized
INFO - 2020-09-15 06:37:01 --> Router Class Initialized
INFO - 2020-09-15 06:37:01 --> Output Class Initialized
INFO - 2020-09-15 06:37:01 --> Security Class Initialized
DEBUG - 2020-09-15 06:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:37:01 --> Input Class Initialized
INFO - 2020-09-15 06:37:01 --> Language Class Initialized
INFO - 2020-09-15 06:37:01 --> Loader Class Initialized
INFO - 2020-09-15 06:37:01 --> Helper loaded: url_helper
INFO - 2020-09-15 06:37:01 --> Database Driver Class Initialized
INFO - 2020-09-15 06:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:37:01 --> Email Class Initialized
INFO - 2020-09-15 06:37:01 --> Controller Class Initialized
DEBUG - 2020-09-15 06:37:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:37:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:37:01 --> Model Class Initialized
INFO - 2020-09-15 06:37:01 --> Model Class Initialized
INFO - 2020-09-15 06:37:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-15 06:37:01 --> Final output sent to browser
DEBUG - 2020-09-15 06:37:01 --> Total execution time: 0.0315
ERROR - 2020-09-15 06:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:38:55 --> Config Class Initialized
INFO - 2020-09-15 06:38:55 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:38:55 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:38:55 --> Utf8 Class Initialized
INFO - 2020-09-15 06:38:55 --> URI Class Initialized
INFO - 2020-09-15 06:38:55 --> Router Class Initialized
INFO - 2020-09-15 06:38:55 --> Output Class Initialized
INFO - 2020-09-15 06:38:55 --> Security Class Initialized
DEBUG - 2020-09-15 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:38:55 --> Input Class Initialized
INFO - 2020-09-15 06:38:55 --> Language Class Initialized
INFO - 2020-09-15 06:38:55 --> Loader Class Initialized
INFO - 2020-09-15 06:38:55 --> Helper loaded: url_helper
INFO - 2020-09-15 06:38:55 --> Database Driver Class Initialized
INFO - 2020-09-15 06:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:38:55 --> Email Class Initialized
INFO - 2020-09-15 06:38:55 --> Controller Class Initialized
DEBUG - 2020-09-15 06:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:38:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:38:55 --> Model Class Initialized
INFO - 2020-09-15 06:38:55 --> Model Class Initialized
INFO - 2020-09-15 06:38:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-09-15 06:38:55 --> Final output sent to browser
DEBUG - 2020-09-15 06:38:55 --> Total execution time: 0.0204
ERROR - 2020-09-15 06:39:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:39:14 --> Config Class Initialized
INFO - 2020-09-15 06:39:14 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:39:14 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:39:14 --> Utf8 Class Initialized
INFO - 2020-09-15 06:39:14 --> URI Class Initialized
DEBUG - 2020-09-15 06:39:14 --> No URI present. Default controller set.
INFO - 2020-09-15 06:39:14 --> Router Class Initialized
INFO - 2020-09-15 06:39:14 --> Output Class Initialized
INFO - 2020-09-15 06:39:14 --> Security Class Initialized
DEBUG - 2020-09-15 06:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:39:14 --> Input Class Initialized
INFO - 2020-09-15 06:39:14 --> Language Class Initialized
INFO - 2020-09-15 06:39:14 --> Loader Class Initialized
INFO - 2020-09-15 06:39:14 --> Helper loaded: url_helper
INFO - 2020-09-15 06:39:14 --> Database Driver Class Initialized
INFO - 2020-09-15 06:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:39:14 --> Email Class Initialized
INFO - 2020-09-15 06:39:14 --> Controller Class Initialized
INFO - 2020-09-15 06:39:14 --> Model Class Initialized
INFO - 2020-09-15 06:39:14 --> Model Class Initialized
DEBUG - 2020-09-15 06:39:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:39:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 06:39:14 --> Final output sent to browser
DEBUG - 2020-09-15 06:39:14 --> Total execution time: 0.0203
ERROR - 2020-09-15 06:39:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:39:48 --> Config Class Initialized
INFO - 2020-09-15 06:39:48 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:39:48 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:39:48 --> Utf8 Class Initialized
INFO - 2020-09-15 06:39:48 --> URI Class Initialized
INFO - 2020-09-15 06:39:48 --> Router Class Initialized
INFO - 2020-09-15 06:39:48 --> Output Class Initialized
INFO - 2020-09-15 06:39:48 --> Security Class Initialized
DEBUG - 2020-09-15 06:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:39:48 --> Input Class Initialized
INFO - 2020-09-15 06:39:48 --> Language Class Initialized
INFO - 2020-09-15 06:39:48 --> Loader Class Initialized
INFO - 2020-09-15 06:39:48 --> Helper loaded: url_helper
INFO - 2020-09-15 06:39:48 --> Database Driver Class Initialized
INFO - 2020-09-15 06:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:39:48 --> Email Class Initialized
INFO - 2020-09-15 06:39:48 --> Controller Class Initialized
INFO - 2020-09-15 06:39:48 --> Model Class Initialized
INFO - 2020-09-15 06:39:48 --> Model Class Initialized
DEBUG - 2020-09-15 06:39:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:39:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:39:48 --> Model Class Initialized
INFO - 2020-09-15 06:39:48 --> Final output sent to browser
DEBUG - 2020-09-15 06:39:48 --> Total execution time: 0.0246
ERROR - 2020-09-15 06:39:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:39:49 --> Config Class Initialized
INFO - 2020-09-15 06:39:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:39:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:39:49 --> Utf8 Class Initialized
INFO - 2020-09-15 06:39:49 --> URI Class Initialized
INFO - 2020-09-15 06:39:49 --> Router Class Initialized
INFO - 2020-09-15 06:39:49 --> Output Class Initialized
INFO - 2020-09-15 06:39:49 --> Security Class Initialized
DEBUG - 2020-09-15 06:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:39:49 --> Input Class Initialized
INFO - 2020-09-15 06:39:49 --> Language Class Initialized
INFO - 2020-09-15 06:39:49 --> Loader Class Initialized
INFO - 2020-09-15 06:39:49 --> Helper loaded: url_helper
INFO - 2020-09-15 06:39:49 --> Database Driver Class Initialized
INFO - 2020-09-15 06:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:39:49 --> Email Class Initialized
INFO - 2020-09-15 06:39:49 --> Controller Class Initialized
INFO - 2020-09-15 06:39:49 --> Model Class Initialized
INFO - 2020-09-15 06:39:49 --> Model Class Initialized
DEBUG - 2020-09-15 06:39:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 06:39:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:39:50 --> Config Class Initialized
INFO - 2020-09-15 06:39:50 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:39:50 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:39:50 --> Utf8 Class Initialized
INFO - 2020-09-15 06:39:50 --> URI Class Initialized
INFO - 2020-09-15 06:39:50 --> Router Class Initialized
INFO - 2020-09-15 06:39:50 --> Output Class Initialized
INFO - 2020-09-15 06:39:50 --> Security Class Initialized
DEBUG - 2020-09-15 06:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:39:50 --> Input Class Initialized
INFO - 2020-09-15 06:39:50 --> Language Class Initialized
INFO - 2020-09-15 06:39:50 --> Loader Class Initialized
INFO - 2020-09-15 06:39:50 --> Helper loaded: url_helper
INFO - 2020-09-15 06:39:50 --> Database Driver Class Initialized
INFO - 2020-09-15 06:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:39:50 --> Email Class Initialized
INFO - 2020-09-15 06:39:50 --> Controller Class Initialized
DEBUG - 2020-09-15 06:39:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:39:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:39:50 --> Model Class Initialized
INFO - 2020-09-15 06:39:50 --> Model Class Initialized
INFO - 2020-09-15 06:39:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 06:39:50 --> Final output sent to browser
DEBUG - 2020-09-15 06:39:50 --> Total execution time: 0.0219
ERROR - 2020-09-15 06:44:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 06:44:10 --> Config Class Initialized
INFO - 2020-09-15 06:44:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 06:44:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 06:44:10 --> Utf8 Class Initialized
INFO - 2020-09-15 06:44:10 --> URI Class Initialized
INFO - 2020-09-15 06:44:10 --> Router Class Initialized
INFO - 2020-09-15 06:44:10 --> Output Class Initialized
INFO - 2020-09-15 06:44:10 --> Security Class Initialized
DEBUG - 2020-09-15 06:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 06:44:10 --> Input Class Initialized
INFO - 2020-09-15 06:44:10 --> Language Class Initialized
INFO - 2020-09-15 06:44:10 --> Loader Class Initialized
INFO - 2020-09-15 06:44:10 --> Helper loaded: url_helper
INFO - 2020-09-15 06:44:10 --> Database Driver Class Initialized
INFO - 2020-09-15 06:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 06:44:10 --> Email Class Initialized
INFO - 2020-09-15 06:44:10 --> Controller Class Initialized
DEBUG - 2020-09-15 06:44:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 06:44:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 06:44:10 --> Model Class Initialized
INFO - 2020-09-15 06:44:10 --> Model Class Initialized
INFO - 2020-09-15 06:44:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 06:44:10 --> Final output sent to browser
DEBUG - 2020-09-15 06:44:10 --> Total execution time: 0.0233
ERROR - 2020-09-15 07:03:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:03:17 --> Config Class Initialized
INFO - 2020-09-15 07:03:17 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:03:17 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:03:17 --> Utf8 Class Initialized
INFO - 2020-09-15 07:03:17 --> URI Class Initialized
INFO - 2020-09-15 07:03:17 --> Router Class Initialized
INFO - 2020-09-15 07:03:17 --> Output Class Initialized
INFO - 2020-09-15 07:03:17 --> Security Class Initialized
DEBUG - 2020-09-15 07:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:03:17 --> Input Class Initialized
INFO - 2020-09-15 07:03:17 --> Language Class Initialized
INFO - 2020-09-15 07:03:17 --> Loader Class Initialized
INFO - 2020-09-15 07:03:17 --> Helper loaded: url_helper
INFO - 2020-09-15 07:03:17 --> Database Driver Class Initialized
INFO - 2020-09-15 07:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:03:17 --> Email Class Initialized
INFO - 2020-09-15 07:03:17 --> Controller Class Initialized
DEBUG - 2020-09-15 07:03:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:03:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:03:17 --> Model Class Initialized
INFO - 2020-09-15 07:03:17 --> Model Class Initialized
ERROR - 2020-09-15 07:03:17 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL total_records_in_system(29)
INFO - 2020-09-15 07:03:17 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 07:03:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:03:57 --> Config Class Initialized
INFO - 2020-09-15 07:03:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:03:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:03:57 --> Utf8 Class Initialized
INFO - 2020-09-15 07:03:57 --> URI Class Initialized
INFO - 2020-09-15 07:03:57 --> Router Class Initialized
INFO - 2020-09-15 07:03:57 --> Output Class Initialized
INFO - 2020-09-15 07:03:57 --> Security Class Initialized
DEBUG - 2020-09-15 07:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:03:57 --> Input Class Initialized
INFO - 2020-09-15 07:03:57 --> Language Class Initialized
INFO - 2020-09-15 07:03:57 --> Loader Class Initialized
INFO - 2020-09-15 07:03:57 --> Helper loaded: url_helper
INFO - 2020-09-15 07:03:57 --> Database Driver Class Initialized
INFO - 2020-09-15 07:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:03:57 --> Email Class Initialized
INFO - 2020-09-15 07:03:57 --> Controller Class Initialized
DEBUG - 2020-09-15 07:03:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:03:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:03:57 --> Model Class Initialized
INFO - 2020-09-15 07:03:57 --> Model Class Initialized
ERROR - 2020-09-15 07:03:57 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL total_records_in_system(29)
INFO - 2020-09-15 07:03:57 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 07:04:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:04:16 --> Config Class Initialized
INFO - 2020-09-15 07:04:16 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:04:16 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:04:16 --> Utf8 Class Initialized
INFO - 2020-09-15 07:04:16 --> URI Class Initialized
INFO - 2020-09-15 07:04:16 --> Router Class Initialized
INFO - 2020-09-15 07:04:16 --> Output Class Initialized
INFO - 2020-09-15 07:04:16 --> Security Class Initialized
DEBUG - 2020-09-15 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:04:16 --> Input Class Initialized
INFO - 2020-09-15 07:04:16 --> Language Class Initialized
INFO - 2020-09-15 07:04:16 --> Loader Class Initialized
INFO - 2020-09-15 07:04:16 --> Helper loaded: url_helper
INFO - 2020-09-15 07:04:16 --> Database Driver Class Initialized
INFO - 2020-09-15 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:04:16 --> Email Class Initialized
INFO - 2020-09-15 07:04:16 --> Controller Class Initialized
DEBUG - 2020-09-15 07:04:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:04:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:04:16 --> Model Class Initialized
INFO - 2020-09-15 07:04:16 --> Model Class Initialized
INFO - 2020-09-15 07:04:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:04:17 --> Final output sent to browser
DEBUG - 2020-09-15 07:04:17 --> Total execution time: 0.0258
ERROR - 2020-09-15 07:05:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:05:51 --> Config Class Initialized
INFO - 2020-09-15 07:05:51 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:05:51 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:05:51 --> Utf8 Class Initialized
INFO - 2020-09-15 07:05:51 --> URI Class Initialized
INFO - 2020-09-15 07:05:51 --> Router Class Initialized
INFO - 2020-09-15 07:05:51 --> Output Class Initialized
INFO - 2020-09-15 07:05:51 --> Security Class Initialized
DEBUG - 2020-09-15 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:05:51 --> Input Class Initialized
INFO - 2020-09-15 07:05:51 --> Language Class Initialized
INFO - 2020-09-15 07:05:51 --> Loader Class Initialized
INFO - 2020-09-15 07:05:51 --> Helper loaded: url_helper
INFO - 2020-09-15 07:05:51 --> Database Driver Class Initialized
INFO - 2020-09-15 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:05:51 --> Email Class Initialized
INFO - 2020-09-15 07:05:51 --> Controller Class Initialized
DEBUG - 2020-09-15 07:05:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:05:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:05:51 --> Model Class Initialized
INFO - 2020-09-15 07:05:51 --> Model Class Initialized
INFO - 2020-09-15 07:05:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:05:51 --> Final output sent to browser
DEBUG - 2020-09-15 07:05:51 --> Total execution time: 0.0267
ERROR - 2020-09-15 07:05:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:05:55 --> Config Class Initialized
INFO - 2020-09-15 07:05:55 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:05:55 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:05:55 --> Utf8 Class Initialized
INFO - 2020-09-15 07:05:55 --> URI Class Initialized
INFO - 2020-09-15 07:05:55 --> Router Class Initialized
INFO - 2020-09-15 07:05:55 --> Output Class Initialized
INFO - 2020-09-15 07:05:55 --> Security Class Initialized
DEBUG - 2020-09-15 07:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:05:55 --> Input Class Initialized
INFO - 2020-09-15 07:05:55 --> Language Class Initialized
INFO - 2020-09-15 07:05:55 --> Loader Class Initialized
INFO - 2020-09-15 07:05:55 --> Helper loaded: url_helper
INFO - 2020-09-15 07:05:55 --> Database Driver Class Initialized
INFO - 2020-09-15 07:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:05:55 --> Email Class Initialized
INFO - 2020-09-15 07:05:55 --> Controller Class Initialized
DEBUG - 2020-09-15 07:05:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:05:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:05:55 --> Model Class Initialized
INFO - 2020-09-15 07:05:55 --> Model Class Initialized
INFO - 2020-09-15 07:05:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 07:05:55 --> Final output sent to browser
DEBUG - 2020-09-15 07:05:55 --> Total execution time: 0.2958
ERROR - 2020-09-15 07:06:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:06:00 --> Config Class Initialized
INFO - 2020-09-15 07:06:00 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:06:00 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:06:00 --> Utf8 Class Initialized
INFO - 2020-09-15 07:06:00 --> URI Class Initialized
INFO - 2020-09-15 07:06:00 --> Router Class Initialized
INFO - 2020-09-15 07:06:00 --> Output Class Initialized
INFO - 2020-09-15 07:06:00 --> Security Class Initialized
DEBUG - 2020-09-15 07:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:06:00 --> Input Class Initialized
INFO - 2020-09-15 07:06:00 --> Language Class Initialized
INFO - 2020-09-15 07:06:00 --> Loader Class Initialized
INFO - 2020-09-15 07:06:00 --> Helper loaded: url_helper
INFO - 2020-09-15 07:06:00 --> Database Driver Class Initialized
INFO - 2020-09-15 07:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:06:00 --> Email Class Initialized
INFO - 2020-09-15 07:06:00 --> Controller Class Initialized
DEBUG - 2020-09-15 07:06:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:06:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:06:00 --> Model Class Initialized
INFO - 2020-09-15 07:06:00 --> Model Class Initialized
INFO - 2020-09-15 07:06:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 07:06:00 --> Final output sent to browser
DEBUG - 2020-09-15 07:06:00 --> Total execution time: 0.0259
ERROR - 2020-09-15 07:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:06:02 --> Config Class Initialized
INFO - 2020-09-15 07:06:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:06:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:06:02 --> Utf8 Class Initialized
INFO - 2020-09-15 07:06:02 --> URI Class Initialized
INFO - 2020-09-15 07:06:02 --> Router Class Initialized
INFO - 2020-09-15 07:06:02 --> Output Class Initialized
INFO - 2020-09-15 07:06:02 --> Security Class Initialized
DEBUG - 2020-09-15 07:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:06:02 --> Input Class Initialized
INFO - 2020-09-15 07:06:02 --> Language Class Initialized
INFO - 2020-09-15 07:06:02 --> Loader Class Initialized
INFO - 2020-09-15 07:06:02 --> Helper loaded: url_helper
INFO - 2020-09-15 07:06:02 --> Database Driver Class Initialized
INFO - 2020-09-15 07:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:06:02 --> Email Class Initialized
INFO - 2020-09-15 07:06:02 --> Controller Class Initialized
DEBUG - 2020-09-15 07:06:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:06:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:06:02 --> Model Class Initialized
INFO - 2020-09-15 07:06:02 --> Model Class Initialized
INFO - 2020-09-15 07:06:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:06:02 --> Final output sent to browser
DEBUG - 2020-09-15 07:06:02 --> Total execution time: 0.0224
ERROR - 2020-09-15 07:06:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:06:10 --> Config Class Initialized
INFO - 2020-09-15 07:06:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:06:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:06:10 --> Utf8 Class Initialized
INFO - 2020-09-15 07:06:10 --> URI Class Initialized
INFO - 2020-09-15 07:06:10 --> Router Class Initialized
INFO - 2020-09-15 07:06:10 --> Output Class Initialized
INFO - 2020-09-15 07:06:10 --> Security Class Initialized
DEBUG - 2020-09-15 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:06:10 --> Input Class Initialized
INFO - 2020-09-15 07:06:10 --> Language Class Initialized
ERROR - 2020-09-15 07:06:10 --> 404 Page Not Found: Dealer/dash.html
ERROR - 2020-09-15 07:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:06:13 --> Config Class Initialized
INFO - 2020-09-15 07:06:13 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:06:13 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:06:13 --> Utf8 Class Initialized
INFO - 2020-09-15 07:06:13 --> URI Class Initialized
INFO - 2020-09-15 07:06:13 --> Router Class Initialized
INFO - 2020-09-15 07:06:13 --> Output Class Initialized
INFO - 2020-09-15 07:06:13 --> Security Class Initialized
DEBUG - 2020-09-15 07:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:06:13 --> Input Class Initialized
INFO - 2020-09-15 07:06:13 --> Language Class Initialized
INFO - 2020-09-15 07:06:13 --> Loader Class Initialized
INFO - 2020-09-15 07:06:13 --> Helper loaded: url_helper
INFO - 2020-09-15 07:06:13 --> Database Driver Class Initialized
INFO - 2020-09-15 07:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:06:13 --> Email Class Initialized
INFO - 2020-09-15 07:06:13 --> Controller Class Initialized
DEBUG - 2020-09-15 07:06:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:06:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:06:13 --> Model Class Initialized
INFO - 2020-09-15 07:06:13 --> Model Class Initialized
INFO - 2020-09-15 07:06:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:06:13 --> Final output sent to browser
DEBUG - 2020-09-15 07:06:13 --> Total execution time: 0.0209
ERROR - 2020-09-15 07:06:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:06:17 --> Config Class Initialized
INFO - 2020-09-15 07:06:17 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:06:17 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:06:17 --> Utf8 Class Initialized
INFO - 2020-09-15 07:06:17 --> URI Class Initialized
INFO - 2020-09-15 07:06:17 --> Router Class Initialized
INFO - 2020-09-15 07:06:17 --> Output Class Initialized
INFO - 2020-09-15 07:06:17 --> Security Class Initialized
DEBUG - 2020-09-15 07:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:06:17 --> Input Class Initialized
INFO - 2020-09-15 07:06:17 --> Language Class Initialized
INFO - 2020-09-15 07:06:17 --> Loader Class Initialized
INFO - 2020-09-15 07:06:17 --> Helper loaded: url_helper
INFO - 2020-09-15 07:06:17 --> Database Driver Class Initialized
INFO - 2020-09-15 07:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:06:17 --> Email Class Initialized
INFO - 2020-09-15 07:06:17 --> Controller Class Initialized
DEBUG - 2020-09-15 07:06:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:06:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:06:17 --> Model Class Initialized
INFO - 2020-09-15 07:06:17 --> Model Class Initialized
INFO - 2020-09-15 07:06:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 07:06:17 --> Final output sent to browser
DEBUG - 2020-09-15 07:06:17 --> Total execution time: 0.0246
ERROR - 2020-09-15 07:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:06:19 --> Config Class Initialized
INFO - 2020-09-15 07:06:19 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:06:19 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:06:19 --> Utf8 Class Initialized
INFO - 2020-09-15 07:06:19 --> URI Class Initialized
INFO - 2020-09-15 07:06:19 --> Router Class Initialized
INFO - 2020-09-15 07:06:19 --> Output Class Initialized
INFO - 2020-09-15 07:06:19 --> Security Class Initialized
DEBUG - 2020-09-15 07:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:06:19 --> Input Class Initialized
INFO - 2020-09-15 07:06:19 --> Language Class Initialized
INFO - 2020-09-15 07:06:19 --> Loader Class Initialized
INFO - 2020-09-15 07:06:19 --> Helper loaded: url_helper
INFO - 2020-09-15 07:06:19 --> Database Driver Class Initialized
INFO - 2020-09-15 07:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:06:19 --> Email Class Initialized
INFO - 2020-09-15 07:06:19 --> Controller Class Initialized
DEBUG - 2020-09-15 07:06:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:06:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:06:19 --> Model Class Initialized
INFO - 2020-09-15 07:06:19 --> Model Class Initialized
INFO - 2020-09-15 07:06:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:06:19 --> Final output sent to browser
DEBUG - 2020-09-15 07:06:19 --> Total execution time: 0.0265
ERROR - 2020-09-15 07:07:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:02 --> Config Class Initialized
INFO - 2020-09-15 07:07:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:02 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:02 --> URI Class Initialized
INFO - 2020-09-15 07:07:02 --> Router Class Initialized
INFO - 2020-09-15 07:07:02 --> Output Class Initialized
INFO - 2020-09-15 07:07:02 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:02 --> Input Class Initialized
INFO - 2020-09-15 07:07:02 --> Language Class Initialized
INFO - 2020-09-15 07:07:02 --> Loader Class Initialized
INFO - 2020-09-15 07:07:02 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:02 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:02 --> Email Class Initialized
INFO - 2020-09-15 07:07:02 --> Controller Class Initialized
DEBUG - 2020-09-15 07:07:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:07:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:02 --> Model Class Initialized
INFO - 2020-09-15 07:07:02 --> Model Class Initialized
INFO - 2020-09-15 07:07:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:07:02 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:02 --> Total execution time: 0.0221
ERROR - 2020-09-15 07:07:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:16 --> Config Class Initialized
INFO - 2020-09-15 07:07:16 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:16 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:16 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:16 --> URI Class Initialized
DEBUG - 2020-09-15 07:07:16 --> No URI present. Default controller set.
INFO - 2020-09-15 07:07:16 --> Router Class Initialized
INFO - 2020-09-15 07:07:16 --> Output Class Initialized
INFO - 2020-09-15 07:07:16 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:16 --> Input Class Initialized
INFO - 2020-09-15 07:07:16 --> Language Class Initialized
INFO - 2020-09-15 07:07:16 --> Loader Class Initialized
INFO - 2020-09-15 07:07:16 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:16 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:16 --> Email Class Initialized
INFO - 2020-09-15 07:07:16 --> Controller Class Initialized
INFO - 2020-09-15 07:07:16 --> Model Class Initialized
INFO - 2020-09-15 07:07:16 --> Model Class Initialized
DEBUG - 2020-09-15 07:07:16 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 07:07:16 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:16 --> Total execution time: 0.0232
ERROR - 2020-09-15 07:07:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:20 --> Config Class Initialized
INFO - 2020-09-15 07:07:20 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:20 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:20 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:20 --> URI Class Initialized
INFO - 2020-09-15 07:07:20 --> Router Class Initialized
INFO - 2020-09-15 07:07:20 --> Output Class Initialized
INFO - 2020-09-15 07:07:20 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:20 --> Input Class Initialized
INFO - 2020-09-15 07:07:20 --> Language Class Initialized
INFO - 2020-09-15 07:07:20 --> Loader Class Initialized
INFO - 2020-09-15 07:07:20 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:20 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:20 --> Email Class Initialized
INFO - 2020-09-15 07:07:20 --> Controller Class Initialized
INFO - 2020-09-15 07:07:20 --> Model Class Initialized
INFO - 2020-09-15 07:07:20 --> Model Class Initialized
DEBUG - 2020-09-15 07:07:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:07:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/forget_password.php
INFO - 2020-09-15 07:07:20 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:20 --> Total execution time: 0.0200
ERROR - 2020-09-15 07:07:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:24 --> Config Class Initialized
INFO - 2020-09-15 07:07:24 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:24 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:24 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:24 --> URI Class Initialized
DEBUG - 2020-09-15 07:07:24 --> No URI present. Default controller set.
INFO - 2020-09-15 07:07:24 --> Router Class Initialized
INFO - 2020-09-15 07:07:24 --> Output Class Initialized
INFO - 2020-09-15 07:07:24 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:24 --> Input Class Initialized
INFO - 2020-09-15 07:07:24 --> Language Class Initialized
INFO - 2020-09-15 07:07:24 --> Loader Class Initialized
INFO - 2020-09-15 07:07:24 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:24 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:24 --> Email Class Initialized
INFO - 2020-09-15 07:07:24 --> Controller Class Initialized
INFO - 2020-09-15 07:07:24 --> Model Class Initialized
INFO - 2020-09-15 07:07:24 --> Model Class Initialized
DEBUG - 2020-09-15 07:07:24 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 07:07:24 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:24 --> Total execution time: 0.0214
ERROR - 2020-09-15 07:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:30 --> Config Class Initialized
INFO - 2020-09-15 07:07:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:30 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:30 --> URI Class Initialized
INFO - 2020-09-15 07:07:30 --> Router Class Initialized
INFO - 2020-09-15 07:07:30 --> Output Class Initialized
INFO - 2020-09-15 07:07:30 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:30 --> Input Class Initialized
INFO - 2020-09-15 07:07:30 --> Language Class Initialized
INFO - 2020-09-15 07:07:30 --> Loader Class Initialized
INFO - 2020-09-15 07:07:30 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:30 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:30 --> Email Class Initialized
INFO - 2020-09-15 07:07:30 --> Controller Class Initialized
INFO - 2020-09-15 07:07:30 --> Model Class Initialized
INFO - 2020-09-15 07:07:30 --> Model Class Initialized
DEBUG - 2020-09-15 07:07:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:07:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:30 --> Model Class Initialized
INFO - 2020-09-15 07:07:30 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:30 --> Total execution time: 0.0214
ERROR - 2020-09-15 07:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:30 --> Config Class Initialized
INFO - 2020-09-15 07:07:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:30 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:30 --> URI Class Initialized
INFO - 2020-09-15 07:07:30 --> Router Class Initialized
INFO - 2020-09-15 07:07:30 --> Output Class Initialized
INFO - 2020-09-15 07:07:30 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:30 --> Input Class Initialized
INFO - 2020-09-15 07:07:30 --> Language Class Initialized
INFO - 2020-09-15 07:07:30 --> Loader Class Initialized
INFO - 2020-09-15 07:07:30 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:30 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:30 --> Email Class Initialized
INFO - 2020-09-15 07:07:30 --> Controller Class Initialized
INFO - 2020-09-15 07:07:30 --> Model Class Initialized
INFO - 2020-09-15 07:07:30 --> Model Class Initialized
DEBUG - 2020-09-15 07:07:30 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 07:07:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:30 --> Config Class Initialized
INFO - 2020-09-15 07:07:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:30 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:30 --> URI Class Initialized
INFO - 2020-09-15 07:07:30 --> Router Class Initialized
INFO - 2020-09-15 07:07:30 --> Output Class Initialized
INFO - 2020-09-15 07:07:30 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:30 --> Input Class Initialized
INFO - 2020-09-15 07:07:30 --> Language Class Initialized
INFO - 2020-09-15 07:07:30 --> Loader Class Initialized
INFO - 2020-09-15 07:07:30 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:31 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:31 --> Email Class Initialized
INFO - 2020-09-15 07:07:31 --> Controller Class Initialized
DEBUG - 2020-09-15 07:07:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:07:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:31 --> Model Class Initialized
INFO - 2020-09-15 07:07:31 --> Model Class Initialized
INFO - 2020-09-15 07:07:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 07:07:31 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:31 --> Total execution time: 0.0246
ERROR - 2020-09-15 07:07:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:07:44 --> Config Class Initialized
INFO - 2020-09-15 07:07:44 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:07:44 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:07:44 --> Utf8 Class Initialized
INFO - 2020-09-15 07:07:44 --> URI Class Initialized
INFO - 2020-09-15 07:07:44 --> Router Class Initialized
INFO - 2020-09-15 07:07:44 --> Output Class Initialized
INFO - 2020-09-15 07:07:44 --> Security Class Initialized
DEBUG - 2020-09-15 07:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:07:44 --> Input Class Initialized
INFO - 2020-09-15 07:07:44 --> Language Class Initialized
INFO - 2020-09-15 07:07:44 --> Loader Class Initialized
INFO - 2020-09-15 07:07:44 --> Helper loaded: url_helper
INFO - 2020-09-15 07:07:44 --> Database Driver Class Initialized
INFO - 2020-09-15 07:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:07:44 --> Email Class Initialized
INFO - 2020-09-15 07:07:44 --> Controller Class Initialized
DEBUG - 2020-09-15 07:07:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:07:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:07:44 --> Model Class Initialized
INFO - 2020-09-15 07:07:44 --> Model Class Initialized
INFO - 2020-09-15 07:07:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 07:07:44 --> Final output sent to browser
DEBUG - 2020-09-15 07:07:44 --> Total execution time: 0.0220
ERROR - 2020-09-15 07:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:09:45 --> Config Class Initialized
INFO - 2020-09-15 07:09:45 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:09:45 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:09:45 --> Utf8 Class Initialized
INFO - 2020-09-15 07:09:45 --> URI Class Initialized
INFO - 2020-09-15 07:09:45 --> Router Class Initialized
INFO - 2020-09-15 07:09:45 --> Output Class Initialized
INFO - 2020-09-15 07:09:45 --> Security Class Initialized
DEBUG - 2020-09-15 07:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:09:45 --> Input Class Initialized
INFO - 2020-09-15 07:09:45 --> Language Class Initialized
INFO - 2020-09-15 07:09:45 --> Loader Class Initialized
INFO - 2020-09-15 07:09:45 --> Helper loaded: url_helper
INFO - 2020-09-15 07:09:45 --> Database Driver Class Initialized
INFO - 2020-09-15 07:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:09:45 --> Email Class Initialized
INFO - 2020-09-15 07:09:45 --> Controller Class Initialized
DEBUG - 2020-09-15 07:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:09:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:09:45 --> Model Class Initialized
INFO - 2020-09-15 07:09:45 --> Model Class Initialized
INFO - 2020-09-15 07:09:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 07:09:45 --> Final output sent to browser
DEBUG - 2020-09-15 07:09:45 --> Total execution time: 0.0236
ERROR - 2020-09-15 07:10:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:10:02 --> Config Class Initialized
INFO - 2020-09-15 07:10:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:10:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:10:02 --> Utf8 Class Initialized
INFO - 2020-09-15 07:10:02 --> URI Class Initialized
INFO - 2020-09-15 07:10:02 --> Router Class Initialized
INFO - 2020-09-15 07:10:02 --> Output Class Initialized
INFO - 2020-09-15 07:10:02 --> Security Class Initialized
DEBUG - 2020-09-15 07:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:10:02 --> Input Class Initialized
INFO - 2020-09-15 07:10:02 --> Language Class Initialized
INFO - 2020-09-15 07:10:02 --> Loader Class Initialized
INFO - 2020-09-15 07:10:02 --> Helper loaded: url_helper
INFO - 2020-09-15 07:10:02 --> Database Driver Class Initialized
INFO - 2020-09-15 07:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:10:02 --> Email Class Initialized
INFO - 2020-09-15 07:10:02 --> Controller Class Initialized
DEBUG - 2020-09-15 07:10:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:10:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:10:02 --> Model Class Initialized
INFO - 2020-09-15 07:10:02 --> Model Class Initialized
INFO - 2020-09-15 07:10:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 07:10:02 --> Final output sent to browser
DEBUG - 2020-09-15 07:10:02 --> Total execution time: 0.0251
ERROR - 2020-09-15 07:10:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:10:09 --> Config Class Initialized
INFO - 2020-09-15 07:10:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:10:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:10:09 --> Utf8 Class Initialized
INFO - 2020-09-15 07:10:09 --> URI Class Initialized
INFO - 2020-09-15 07:10:09 --> Router Class Initialized
INFO - 2020-09-15 07:10:09 --> Output Class Initialized
INFO - 2020-09-15 07:10:09 --> Security Class Initialized
DEBUG - 2020-09-15 07:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:10:09 --> Input Class Initialized
INFO - 2020-09-15 07:10:09 --> Language Class Initialized
INFO - 2020-09-15 07:10:09 --> Loader Class Initialized
INFO - 2020-09-15 07:10:09 --> Helper loaded: url_helper
INFO - 2020-09-15 07:10:09 --> Database Driver Class Initialized
INFO - 2020-09-15 07:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:10:09 --> Email Class Initialized
INFO - 2020-09-15 07:10:09 --> Controller Class Initialized
DEBUG - 2020-09-15 07:10:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:10:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:10:09 --> Model Class Initialized
INFO - 2020-09-15 07:10:09 --> Model Class Initialized
INFO - 2020-09-15 07:10:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-15 07:10:09 --> Final output sent to browser
DEBUG - 2020-09-15 07:10:09 --> Total execution time: 0.0248
ERROR - 2020-09-15 07:12:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:28 --> Config Class Initialized
INFO - 2020-09-15 07:12:28 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:28 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:28 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:28 --> URI Class Initialized
DEBUG - 2020-09-15 07:12:28 --> No URI present. Default controller set.
INFO - 2020-09-15 07:12:28 --> Router Class Initialized
INFO - 2020-09-15 07:12:28 --> Output Class Initialized
INFO - 2020-09-15 07:12:28 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:28 --> Input Class Initialized
INFO - 2020-09-15 07:12:28 --> Language Class Initialized
INFO - 2020-09-15 07:12:28 --> Loader Class Initialized
INFO - 2020-09-15 07:12:28 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:28 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:28 --> Email Class Initialized
INFO - 2020-09-15 07:12:28 --> Controller Class Initialized
INFO - 2020-09-15 07:12:28 --> Model Class Initialized
INFO - 2020-09-15 07:12:28 --> Model Class Initialized
DEBUG - 2020-09-15 07:12:28 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:12:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 07:12:28 --> Final output sent to browser
DEBUG - 2020-09-15 07:12:28 --> Total execution time: 0.0167
ERROR - 2020-09-15 07:12:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:39 --> Config Class Initialized
INFO - 2020-09-15 07:12:39 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:39 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:39 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:39 --> URI Class Initialized
INFO - 2020-09-15 07:12:39 --> Router Class Initialized
INFO - 2020-09-15 07:12:39 --> Output Class Initialized
INFO - 2020-09-15 07:12:39 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:39 --> Input Class Initialized
INFO - 2020-09-15 07:12:39 --> Language Class Initialized
INFO - 2020-09-15 07:12:39 --> Loader Class Initialized
INFO - 2020-09-15 07:12:39 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:39 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:39 --> Email Class Initialized
INFO - 2020-09-15 07:12:39 --> Controller Class Initialized
INFO - 2020-09-15 07:12:39 --> Model Class Initialized
INFO - 2020-09-15 07:12:39 --> Model Class Initialized
DEBUG - 2020-09-15 07:12:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:12:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:12:39 --> Model Class Initialized
INFO - 2020-09-15 07:12:39 --> Final output sent to browser
DEBUG - 2020-09-15 07:12:39 --> Total execution time: 0.0239
ERROR - 2020-09-15 07:12:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:39 --> Config Class Initialized
INFO - 2020-09-15 07:12:39 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:39 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:39 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:39 --> URI Class Initialized
INFO - 2020-09-15 07:12:39 --> Router Class Initialized
INFO - 2020-09-15 07:12:39 --> Output Class Initialized
INFO - 2020-09-15 07:12:39 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:39 --> Input Class Initialized
INFO - 2020-09-15 07:12:39 --> Language Class Initialized
INFO - 2020-09-15 07:12:39 --> Loader Class Initialized
INFO - 2020-09-15 07:12:39 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:39 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:39 --> Email Class Initialized
INFO - 2020-09-15 07:12:39 --> Controller Class Initialized
INFO - 2020-09-15 07:12:39 --> Model Class Initialized
INFO - 2020-09-15 07:12:39 --> Model Class Initialized
DEBUG - 2020-09-15 07:12:39 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 07:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:40 --> Config Class Initialized
INFO - 2020-09-15 07:12:40 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:40 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:40 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:40 --> URI Class Initialized
DEBUG - 2020-09-15 07:12:40 --> No URI present. Default controller set.
INFO - 2020-09-15 07:12:40 --> Router Class Initialized
INFO - 2020-09-15 07:12:40 --> Output Class Initialized
INFO - 2020-09-15 07:12:40 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:40 --> Input Class Initialized
INFO - 2020-09-15 07:12:40 --> Language Class Initialized
INFO - 2020-09-15 07:12:40 --> Loader Class Initialized
INFO - 2020-09-15 07:12:40 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:40 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:40 --> Email Class Initialized
INFO - 2020-09-15 07:12:40 --> Controller Class Initialized
INFO - 2020-09-15 07:12:40 --> Model Class Initialized
INFO - 2020-09-15 07:12:40 --> Model Class Initialized
DEBUG - 2020-09-15 07:12:40 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:12:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 07:12:40 --> Final output sent to browser
DEBUG - 2020-09-15 07:12:40 --> Total execution time: 0.0179
ERROR - 2020-09-15 07:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:54 --> Config Class Initialized
INFO - 2020-09-15 07:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:54 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:54 --> URI Class Initialized
INFO - 2020-09-15 07:12:54 --> Router Class Initialized
INFO - 2020-09-15 07:12:54 --> Output Class Initialized
INFO - 2020-09-15 07:12:54 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:54 --> Input Class Initialized
INFO - 2020-09-15 07:12:54 --> Language Class Initialized
INFO - 2020-09-15 07:12:54 --> Loader Class Initialized
INFO - 2020-09-15 07:12:54 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:54 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:54 --> Email Class Initialized
INFO - 2020-09-15 07:12:54 --> Controller Class Initialized
INFO - 2020-09-15 07:12:54 --> Model Class Initialized
INFO - 2020-09-15 07:12:54 --> Model Class Initialized
DEBUG - 2020-09-15 07:12:54 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 07:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:54 --> Config Class Initialized
INFO - 2020-09-15 07:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:54 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:54 --> URI Class Initialized
INFO - 2020-09-15 07:12:54 --> Router Class Initialized
INFO - 2020-09-15 07:12:54 --> Output Class Initialized
INFO - 2020-09-15 07:12:54 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:54 --> Input Class Initialized
INFO - 2020-09-15 07:12:54 --> Language Class Initialized
INFO - 2020-09-15 07:12:54 --> Loader Class Initialized
INFO - 2020-09-15 07:12:54 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:54 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:54 --> Email Class Initialized
INFO - 2020-09-15 07:12:54 --> Controller Class Initialized
INFO - 2020-09-15 07:12:54 --> Model Class Initialized
INFO - 2020-09-15 07:12:54 --> Model Class Initialized
DEBUG - 2020-09-15 07:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:12:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:12:54 --> Model Class Initialized
INFO - 2020-09-15 07:12:54 --> Final output sent to browser
DEBUG - 2020-09-15 07:12:54 --> Total execution time: 0.0238
ERROR - 2020-09-15 07:12:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:12:54 --> Config Class Initialized
INFO - 2020-09-15 07:12:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:12:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:12:54 --> Utf8 Class Initialized
INFO - 2020-09-15 07:12:54 --> URI Class Initialized
INFO - 2020-09-15 07:12:54 --> Router Class Initialized
INFO - 2020-09-15 07:12:54 --> Output Class Initialized
INFO - 2020-09-15 07:12:54 --> Security Class Initialized
DEBUG - 2020-09-15 07:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:12:54 --> Input Class Initialized
INFO - 2020-09-15 07:12:54 --> Language Class Initialized
INFO - 2020-09-15 07:12:54 --> Loader Class Initialized
INFO - 2020-09-15 07:12:54 --> Helper loaded: url_helper
INFO - 2020-09-15 07:12:54 --> Database Driver Class Initialized
INFO - 2020-09-15 07:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:12:54 --> Email Class Initialized
INFO - 2020-09-15 07:12:54 --> Controller Class Initialized
DEBUG - 2020-09-15 07:12:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:12:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:12:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-15 07:12:54 --> Final output sent to browser
DEBUG - 2020-09-15 07:12:54 --> Total execution time: 0.0214
ERROR - 2020-09-15 07:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:13:12 --> Config Class Initialized
INFO - 2020-09-15 07:13:12 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:13:12 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:13:12 --> Utf8 Class Initialized
INFO - 2020-09-15 07:13:12 --> URI Class Initialized
INFO - 2020-09-15 07:13:12 --> Router Class Initialized
INFO - 2020-09-15 07:13:12 --> Output Class Initialized
INFO - 2020-09-15 07:13:12 --> Security Class Initialized
DEBUG - 2020-09-15 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:13:12 --> Input Class Initialized
INFO - 2020-09-15 07:13:12 --> Language Class Initialized
INFO - 2020-09-15 07:13:12 --> Loader Class Initialized
INFO - 2020-09-15 07:13:12 --> Helper loaded: url_helper
INFO - 2020-09-15 07:13:12 --> Database Driver Class Initialized
INFO - 2020-09-15 07:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:13:12 --> Email Class Initialized
INFO - 2020-09-15 07:13:12 --> Controller Class Initialized
DEBUG - 2020-09-15 07:13:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:13:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:13:12 --> Model Class Initialized
INFO - 2020-09-15 07:13:12 --> Model Class Initialized
INFO - 2020-09-15 07:13:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-15 07:13:12 --> Final output sent to browser
DEBUG - 2020-09-15 07:13:12 --> Total execution time: 0.0237
ERROR - 2020-09-15 07:14:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:14:26 --> Config Class Initialized
INFO - 2020-09-15 07:14:26 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:14:26 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:14:26 --> Utf8 Class Initialized
INFO - 2020-09-15 07:14:26 --> URI Class Initialized
INFO - 2020-09-15 07:14:26 --> Router Class Initialized
INFO - 2020-09-15 07:14:26 --> Output Class Initialized
INFO - 2020-09-15 07:14:26 --> Security Class Initialized
DEBUG - 2020-09-15 07:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:14:26 --> Input Class Initialized
INFO - 2020-09-15 07:14:26 --> Language Class Initialized
INFO - 2020-09-15 07:14:26 --> Loader Class Initialized
INFO - 2020-09-15 07:14:26 --> Helper loaded: url_helper
INFO - 2020-09-15 07:14:26 --> Database Driver Class Initialized
INFO - 2020-09-15 07:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:14:26 --> Email Class Initialized
INFO - 2020-09-15 07:14:26 --> Controller Class Initialized
INFO - 2020-09-15 07:14:26 --> Model Class Initialized
INFO - 2020-09-15 07:14:26 --> Model Class Initialized
INFO - 2020-09-15 07:14:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 07:14:27 --> Final output sent to browser
DEBUG - 2020-09-15 07:14:27 --> Total execution time: 0.3462
ERROR - 2020-09-15 07:14:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:14:27 --> Config Class Initialized
INFO - 2020-09-15 07:14:27 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:14:27 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:14:27 --> Utf8 Class Initialized
INFO - 2020-09-15 07:14:27 --> URI Class Initialized
INFO - 2020-09-15 07:14:27 --> Router Class Initialized
INFO - 2020-09-15 07:14:27 --> Output Class Initialized
INFO - 2020-09-15 07:14:27 --> Security Class Initialized
DEBUG - 2020-09-15 07:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:14:28 --> Input Class Initialized
INFO - 2020-09-15 07:14:28 --> Language Class Initialized
INFO - 2020-09-15 07:14:28 --> Loader Class Initialized
INFO - 2020-09-15 07:14:28 --> Helper loaded: url_helper
INFO - 2020-09-15 07:14:28 --> Database Driver Class Initialized
INFO - 2020-09-15 07:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:14:28 --> Email Class Initialized
INFO - 2020-09-15 07:14:28 --> Controller Class Initialized
INFO - 2020-09-15 07:14:28 --> Model Class Initialized
INFO - 2020-09-15 07:14:28 --> Model Class Initialized
INFO - 2020-09-15 07:14:28 --> Final output sent to browser
DEBUG - 2020-09-15 07:14:28 --> Total execution time: 0.2195
ERROR - 2020-09-15 07:16:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:16:13 --> Config Class Initialized
INFO - 2020-09-15 07:16:13 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:16:13 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:16:13 --> Utf8 Class Initialized
INFO - 2020-09-15 07:16:13 --> URI Class Initialized
INFO - 2020-09-15 07:16:13 --> Router Class Initialized
INFO - 2020-09-15 07:16:13 --> Output Class Initialized
INFO - 2020-09-15 07:16:13 --> Security Class Initialized
DEBUG - 2020-09-15 07:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:16:13 --> Input Class Initialized
INFO - 2020-09-15 07:16:13 --> Language Class Initialized
INFO - 2020-09-15 07:16:13 --> Loader Class Initialized
INFO - 2020-09-15 07:16:13 --> Helper loaded: url_helper
INFO - 2020-09-15 07:16:13 --> Database Driver Class Initialized
INFO - 2020-09-15 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:16:13 --> Email Class Initialized
INFO - 2020-09-15 07:16:13 --> Controller Class Initialized
DEBUG - 2020-09-15 07:16:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 07:16:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:16:13 --> Model Class Initialized
INFO - 2020-09-15 07:16:13 --> Model Class Initialized
INFO - 2020-09-15 07:16:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-15 07:16:13 --> Final output sent to browser
DEBUG - 2020-09-15 07:16:13 --> Total execution time: 0.0234
ERROR - 2020-09-15 07:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 07:17:51 --> Config Class Initialized
INFO - 2020-09-15 07:17:51 --> Hooks Class Initialized
DEBUG - 2020-09-15 07:17:51 --> UTF-8 Support Enabled
INFO - 2020-09-15 07:17:51 --> Utf8 Class Initialized
INFO - 2020-09-15 07:17:51 --> URI Class Initialized
DEBUG - 2020-09-15 07:17:51 --> No URI present. Default controller set.
INFO - 2020-09-15 07:17:51 --> Router Class Initialized
INFO - 2020-09-15 07:17:51 --> Output Class Initialized
INFO - 2020-09-15 07:17:51 --> Security Class Initialized
DEBUG - 2020-09-15 07:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 07:17:51 --> Input Class Initialized
INFO - 2020-09-15 07:17:51 --> Language Class Initialized
INFO - 2020-09-15 07:17:51 --> Loader Class Initialized
INFO - 2020-09-15 07:17:51 --> Helper loaded: url_helper
INFO - 2020-09-15 07:17:51 --> Database Driver Class Initialized
INFO - 2020-09-15 07:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 07:17:51 --> Email Class Initialized
INFO - 2020-09-15 07:17:51 --> Controller Class Initialized
INFO - 2020-09-15 07:17:51 --> Model Class Initialized
INFO - 2020-09-15 07:17:51 --> Model Class Initialized
DEBUG - 2020-09-15 07:17:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 07:17:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 07:17:51 --> Final output sent to browser
DEBUG - 2020-09-15 07:17:51 --> Total execution time: 0.0212
ERROR - 2020-09-15 14:52:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:52:21 --> Config Class Initialized
INFO - 2020-09-15 14:52:21 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:52:21 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:52:21 --> Utf8 Class Initialized
INFO - 2020-09-15 14:52:21 --> URI Class Initialized
DEBUG - 2020-09-15 14:52:21 --> No URI present. Default controller set.
INFO - 2020-09-15 14:52:21 --> Router Class Initialized
INFO - 2020-09-15 14:52:21 --> Output Class Initialized
INFO - 2020-09-15 14:52:21 --> Security Class Initialized
DEBUG - 2020-09-15 14:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:52:21 --> Input Class Initialized
INFO - 2020-09-15 14:52:21 --> Language Class Initialized
INFO - 2020-09-15 14:52:21 --> Loader Class Initialized
INFO - 2020-09-15 14:52:21 --> Helper loaded: url_helper
INFO - 2020-09-15 14:52:21 --> Database Driver Class Initialized
INFO - 2020-09-15 14:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:52:21 --> Email Class Initialized
INFO - 2020-09-15 14:52:21 --> Controller Class Initialized
INFO - 2020-09-15 14:52:21 --> Model Class Initialized
INFO - 2020-09-15 14:52:21 --> Model Class Initialized
DEBUG - 2020-09-15 14:52:21 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:52:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 14:52:21 --> Final output sent to browser
DEBUG - 2020-09-15 14:52:21 --> Total execution time: 0.1264
ERROR - 2020-09-15 14:55:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:55:35 --> Config Class Initialized
INFO - 2020-09-15 14:55:35 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:55:35 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:55:35 --> Utf8 Class Initialized
INFO - 2020-09-15 14:55:35 --> URI Class Initialized
INFO - 2020-09-15 14:55:35 --> Router Class Initialized
INFO - 2020-09-15 14:55:35 --> Output Class Initialized
INFO - 2020-09-15 14:55:35 --> Security Class Initialized
DEBUG - 2020-09-15 14:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:55:35 --> Input Class Initialized
INFO - 2020-09-15 14:55:35 --> Language Class Initialized
INFO - 2020-09-15 14:55:35 --> Loader Class Initialized
INFO - 2020-09-15 14:55:35 --> Helper loaded: url_helper
INFO - 2020-09-15 14:55:35 --> Database Driver Class Initialized
INFO - 2020-09-15 14:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:55:35 --> Email Class Initialized
INFO - 2020-09-15 14:55:35 --> Controller Class Initialized
INFO - 2020-09-15 14:55:35 --> Model Class Initialized
INFO - 2020-09-15 14:55:35 --> Model Class Initialized
DEBUG - 2020-09-15 14:55:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 14:55:35 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-09-15 14:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:55:36 --> Config Class Initialized
INFO - 2020-09-15 14:55:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:55:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:55:36 --> Utf8 Class Initialized
INFO - 2020-09-15 14:55:36 --> URI Class Initialized
INFO - 2020-09-15 14:55:36 --> Router Class Initialized
INFO - 2020-09-15 14:55:36 --> Output Class Initialized
INFO - 2020-09-15 14:55:36 --> Security Class Initialized
DEBUG - 2020-09-15 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:55:36 --> Input Class Initialized
INFO - 2020-09-15 14:55:36 --> Language Class Initialized
INFO - 2020-09-15 14:55:36 --> Loader Class Initialized
INFO - 2020-09-15 14:55:36 --> Helper loaded: url_helper
INFO - 2020-09-15 14:55:36 --> Database Driver Class Initialized
INFO - 2020-09-15 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:55:36 --> Email Class Initialized
INFO - 2020-09-15 14:55:36 --> Controller Class Initialized
INFO - 2020-09-15 14:55:36 --> Model Class Initialized
INFO - 2020-09-15 14:55:36 --> Model Class Initialized
DEBUG - 2020-09-15 14:55:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 14:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:55:36 --> Config Class Initialized
INFO - 2020-09-15 14:55:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:55:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:55:36 --> Utf8 Class Initialized
INFO - 2020-09-15 14:55:36 --> URI Class Initialized
DEBUG - 2020-09-15 14:55:36 --> No URI present. Default controller set.
INFO - 2020-09-15 14:55:36 --> Router Class Initialized
INFO - 2020-09-15 14:55:36 --> Output Class Initialized
INFO - 2020-09-15 14:55:36 --> Security Class Initialized
DEBUG - 2020-09-15 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:55:36 --> Input Class Initialized
INFO - 2020-09-15 14:55:36 --> Language Class Initialized
INFO - 2020-09-15 14:55:36 --> Loader Class Initialized
INFO - 2020-09-15 14:55:36 --> Helper loaded: url_helper
INFO - 2020-09-15 14:55:36 --> Database Driver Class Initialized
INFO - 2020-09-15 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:55:36 --> Email Class Initialized
INFO - 2020-09-15 14:55:36 --> Controller Class Initialized
INFO - 2020-09-15 14:55:36 --> Model Class Initialized
INFO - 2020-09-15 14:55:36 --> Model Class Initialized
DEBUG - 2020-09-15 14:55:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:55:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 14:55:36 --> Final output sent to browser
DEBUG - 2020-09-15 14:55:36 --> Total execution time: 0.0192
ERROR - 2020-09-15 14:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:55:36 --> Config Class Initialized
INFO - 2020-09-15 14:55:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:55:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:55:36 --> Utf8 Class Initialized
INFO - 2020-09-15 14:55:36 --> URI Class Initialized
INFO - 2020-09-15 14:55:36 --> Router Class Initialized
INFO - 2020-09-15 14:55:36 --> Output Class Initialized
INFO - 2020-09-15 14:55:36 --> Security Class Initialized
DEBUG - 2020-09-15 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:55:36 --> Input Class Initialized
INFO - 2020-09-15 14:55:36 --> Language Class Initialized
INFO - 2020-09-15 14:55:36 --> Loader Class Initialized
INFO - 2020-09-15 14:55:36 --> Helper loaded: url_helper
INFO - 2020-09-15 14:55:36 --> Database Driver Class Initialized
INFO - 2020-09-15 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:55:36 --> Email Class Initialized
INFO - 2020-09-15 14:55:36 --> Controller Class Initialized
DEBUG - 2020-09-15 14:55:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 14:55:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:55:36 --> Model Class Initialized
INFO - 2020-09-15 14:55:36 --> Model Class Initialized
INFO - 2020-09-15 14:55:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 14:55:36 --> Final output sent to browser
DEBUG - 2020-09-15 14:55:36 --> Total execution time: 0.0794
ERROR - 2020-09-15 14:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:56:04 --> Config Class Initialized
INFO - 2020-09-15 14:56:04 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:56:04 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:56:04 --> Utf8 Class Initialized
INFO - 2020-09-15 14:56:04 --> URI Class Initialized
DEBUG - 2020-09-15 14:56:04 --> No URI present. Default controller set.
INFO - 2020-09-15 14:56:04 --> Router Class Initialized
INFO - 2020-09-15 14:56:04 --> Output Class Initialized
INFO - 2020-09-15 14:56:04 --> Security Class Initialized
DEBUG - 2020-09-15 14:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:56:04 --> Input Class Initialized
INFO - 2020-09-15 14:56:04 --> Language Class Initialized
INFO - 2020-09-15 14:56:04 --> Loader Class Initialized
INFO - 2020-09-15 14:56:04 --> Helper loaded: url_helper
INFO - 2020-09-15 14:56:04 --> Database Driver Class Initialized
INFO - 2020-09-15 14:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:56:04 --> Email Class Initialized
INFO - 2020-09-15 14:56:04 --> Controller Class Initialized
INFO - 2020-09-15 14:56:04 --> Model Class Initialized
INFO - 2020-09-15 14:56:04 --> Model Class Initialized
DEBUG - 2020-09-15 14:56:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:56:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 14:56:04 --> Final output sent to browser
DEBUG - 2020-09-15 14:56:04 --> Total execution time: 0.0248
ERROR - 2020-09-15 14:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:57:32 --> Config Class Initialized
INFO - 2020-09-15 14:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:57:32 --> Utf8 Class Initialized
INFO - 2020-09-15 14:57:32 --> URI Class Initialized
INFO - 2020-09-15 14:57:32 --> Router Class Initialized
INFO - 2020-09-15 14:57:32 --> Output Class Initialized
INFO - 2020-09-15 14:57:32 --> Security Class Initialized
DEBUG - 2020-09-15 14:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:57:32 --> Input Class Initialized
INFO - 2020-09-15 14:57:32 --> Language Class Initialized
INFO - 2020-09-15 14:57:32 --> Loader Class Initialized
INFO - 2020-09-15 14:57:32 --> Helper loaded: url_helper
INFO - 2020-09-15 14:57:32 --> Database Driver Class Initialized
INFO - 2020-09-15 14:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:57:32 --> Email Class Initialized
INFO - 2020-09-15 14:57:32 --> Controller Class Initialized
INFO - 2020-09-15 14:57:32 --> Model Class Initialized
INFO - 2020-09-15 14:57:32 --> Model Class Initialized
DEBUG - 2020-09-15 14:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 14:57:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:57:32 --> Model Class Initialized
INFO - 2020-09-15 14:57:32 --> Final output sent to browser
DEBUG - 2020-09-15 14:57:32 --> Total execution time: 0.0258
ERROR - 2020-09-15 14:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:57:32 --> Config Class Initialized
INFO - 2020-09-15 14:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:57:32 --> Utf8 Class Initialized
INFO - 2020-09-15 14:57:32 --> URI Class Initialized
INFO - 2020-09-15 14:57:32 --> Router Class Initialized
INFO - 2020-09-15 14:57:32 --> Output Class Initialized
INFO - 2020-09-15 14:57:32 --> Security Class Initialized
DEBUG - 2020-09-15 14:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:57:32 --> Input Class Initialized
INFO - 2020-09-15 14:57:32 --> Language Class Initialized
INFO - 2020-09-15 14:57:32 --> Loader Class Initialized
INFO - 2020-09-15 14:57:32 --> Helper loaded: url_helper
INFO - 2020-09-15 14:57:32 --> Database Driver Class Initialized
INFO - 2020-09-15 14:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:57:32 --> Email Class Initialized
INFO - 2020-09-15 14:57:32 --> Controller Class Initialized
INFO - 2020-09-15 14:57:32 --> Model Class Initialized
INFO - 2020-09-15 14:57:32 --> Model Class Initialized
DEBUG - 2020-09-15 14:57:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 14:57:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:57:32 --> Config Class Initialized
INFO - 2020-09-15 14:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:57:32 --> Utf8 Class Initialized
INFO - 2020-09-15 14:57:32 --> URI Class Initialized
INFO - 2020-09-15 14:57:32 --> Router Class Initialized
INFO - 2020-09-15 14:57:32 --> Output Class Initialized
INFO - 2020-09-15 14:57:32 --> Security Class Initialized
DEBUG - 2020-09-15 14:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:57:32 --> Input Class Initialized
INFO - 2020-09-15 14:57:32 --> Language Class Initialized
INFO - 2020-09-15 14:57:32 --> Loader Class Initialized
INFO - 2020-09-15 14:57:32 --> Helper loaded: url_helper
INFO - 2020-09-15 14:57:32 --> Database Driver Class Initialized
INFO - 2020-09-15 14:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:57:32 --> Email Class Initialized
INFO - 2020-09-15 14:57:32 --> Controller Class Initialized
DEBUG - 2020-09-15 14:57:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 14:57:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:57:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-15 14:57:32 --> Final output sent to browser
DEBUG - 2020-09-15 14:57:32 --> Total execution time: 0.0488
ERROR - 2020-09-15 14:57:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:57:38 --> Config Class Initialized
INFO - 2020-09-15 14:57:38 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:57:38 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:57:38 --> Utf8 Class Initialized
INFO - 2020-09-15 14:57:38 --> URI Class Initialized
INFO - 2020-09-15 14:57:38 --> Router Class Initialized
INFO - 2020-09-15 14:57:38 --> Output Class Initialized
INFO - 2020-09-15 14:57:38 --> Security Class Initialized
DEBUG - 2020-09-15 14:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:57:38 --> Input Class Initialized
INFO - 2020-09-15 14:57:38 --> Language Class Initialized
INFO - 2020-09-15 14:57:38 --> Loader Class Initialized
INFO - 2020-09-15 14:57:38 --> Helper loaded: url_helper
INFO - 2020-09-15 14:57:38 --> Database Driver Class Initialized
INFO - 2020-09-15 14:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:57:38 --> Email Class Initialized
INFO - 2020-09-15 14:57:38 --> Controller Class Initialized
INFO - 2020-09-15 14:57:38 --> Model Class Initialized
INFO - 2020-09-15 14:57:38 --> Model Class Initialized
INFO - 2020-09-15 14:57:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 14:57:38 --> Final output sent to browser
DEBUG - 2020-09-15 14:57:38 --> Total execution time: 0.1623
ERROR - 2020-09-15 14:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:57:41 --> Config Class Initialized
INFO - 2020-09-15 14:57:41 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:57:41 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:57:41 --> Utf8 Class Initialized
INFO - 2020-09-15 14:57:41 --> URI Class Initialized
INFO - 2020-09-15 14:57:41 --> Router Class Initialized
INFO - 2020-09-15 14:57:41 --> Output Class Initialized
INFO - 2020-09-15 14:57:41 --> Security Class Initialized
DEBUG - 2020-09-15 14:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:57:41 --> Input Class Initialized
INFO - 2020-09-15 14:57:41 --> Language Class Initialized
INFO - 2020-09-15 14:57:41 --> Loader Class Initialized
INFO - 2020-09-15 14:57:41 --> Helper loaded: url_helper
INFO - 2020-09-15 14:57:41 --> Database Driver Class Initialized
INFO - 2020-09-15 14:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:57:41 --> Email Class Initialized
INFO - 2020-09-15 14:57:41 --> Controller Class Initialized
INFO - 2020-09-15 14:57:41 --> Model Class Initialized
INFO - 2020-09-15 14:57:41 --> Model Class Initialized
INFO - 2020-09-15 14:57:41 --> Final output sent to browser
DEBUG - 2020-09-15 14:57:41 --> Total execution time: 0.0479
ERROR - 2020-09-15 14:59:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:59:08 --> Config Class Initialized
INFO - 2020-09-15 14:59:08 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:59:08 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:59:08 --> Utf8 Class Initialized
INFO - 2020-09-15 14:59:08 --> URI Class Initialized
INFO - 2020-09-15 14:59:08 --> Router Class Initialized
INFO - 2020-09-15 14:59:08 --> Output Class Initialized
INFO - 2020-09-15 14:59:08 --> Security Class Initialized
DEBUG - 2020-09-15 14:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:59:08 --> Input Class Initialized
INFO - 2020-09-15 14:59:08 --> Language Class Initialized
INFO - 2020-09-15 14:59:08 --> Loader Class Initialized
INFO - 2020-09-15 14:59:08 --> Helper loaded: url_helper
INFO - 2020-09-15 14:59:08 --> Database Driver Class Initialized
INFO - 2020-09-15 14:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:59:08 --> Email Class Initialized
INFO - 2020-09-15 14:59:08 --> Controller Class Initialized
DEBUG - 2020-09-15 14:59:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 14:59:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:59:08 --> Model Class Initialized
INFO - 2020-09-15 14:59:08 --> Model Class Initialized
INFO - 2020-09-15 14:59:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-09-15 14:59:08 --> Final output sent to browser
DEBUG - 2020-09-15 14:59:08 --> Total execution time: 0.0471
ERROR - 2020-09-15 14:59:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 14:59:11 --> Config Class Initialized
INFO - 2020-09-15 14:59:11 --> Hooks Class Initialized
DEBUG - 2020-09-15 14:59:11 --> UTF-8 Support Enabled
INFO - 2020-09-15 14:59:11 --> Utf8 Class Initialized
INFO - 2020-09-15 14:59:11 --> URI Class Initialized
INFO - 2020-09-15 14:59:11 --> Router Class Initialized
INFO - 2020-09-15 14:59:11 --> Output Class Initialized
INFO - 2020-09-15 14:59:11 --> Security Class Initialized
DEBUG - 2020-09-15 14:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 14:59:11 --> Input Class Initialized
INFO - 2020-09-15 14:59:11 --> Language Class Initialized
INFO - 2020-09-15 14:59:11 --> Loader Class Initialized
INFO - 2020-09-15 14:59:11 --> Helper loaded: url_helper
INFO - 2020-09-15 14:59:11 --> Database Driver Class Initialized
INFO - 2020-09-15 14:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 14:59:11 --> Email Class Initialized
INFO - 2020-09-15 14:59:11 --> Controller Class Initialized
DEBUG - 2020-09-15 14:59:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 14:59:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 14:59:11 --> Model Class Initialized
INFO - 2020-09-15 14:59:11 --> Model Class Initialized
INFO - 2020-09-15 14:59:11 --> Model Class Initialized
INFO - 2020-09-15 14:59:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-15 14:59:11 --> Final output sent to browser
DEBUG - 2020-09-15 14:59:11 --> Total execution time: 0.0409
ERROR - 2020-09-15 15:03:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:03:22 --> Config Class Initialized
INFO - 2020-09-15 15:03:22 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:03:22 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:03:22 --> Utf8 Class Initialized
INFO - 2020-09-15 15:03:22 --> URI Class Initialized
INFO - 2020-09-15 15:03:22 --> Router Class Initialized
INFO - 2020-09-15 15:03:22 --> Output Class Initialized
INFO - 2020-09-15 15:03:22 --> Security Class Initialized
DEBUG - 2020-09-15 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:03:22 --> Input Class Initialized
INFO - 2020-09-15 15:03:22 --> Language Class Initialized
INFO - 2020-09-15 15:03:22 --> Loader Class Initialized
INFO - 2020-09-15 15:03:22 --> Helper loaded: url_helper
INFO - 2020-09-15 15:03:22 --> Database Driver Class Initialized
INFO - 2020-09-15 15:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:03:22 --> Email Class Initialized
INFO - 2020-09-15 15:03:22 --> Controller Class Initialized
DEBUG - 2020-09-15 15:03:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:03:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:03:22 --> Model Class Initialized
INFO - 2020-09-15 15:03:22 --> Model Class Initialized
INFO - 2020-09-15 15:03:22 --> Model Class Initialized
INFO - 2020-09-15 15:03:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_add.php
INFO - 2020-09-15 15:03:22 --> Final output sent to browser
DEBUG - 2020-09-15 15:03:22 --> Total execution time: 0.0254
ERROR - 2020-09-15 15:03:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:03:24 --> Config Class Initialized
INFO - 2020-09-15 15:03:24 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:03:24 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:03:24 --> Utf8 Class Initialized
INFO - 2020-09-15 15:03:24 --> URI Class Initialized
INFO - 2020-09-15 15:03:24 --> Router Class Initialized
INFO - 2020-09-15 15:03:24 --> Output Class Initialized
INFO - 2020-09-15 15:03:24 --> Security Class Initialized
DEBUG - 2020-09-15 15:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:03:24 --> Input Class Initialized
INFO - 2020-09-15 15:03:24 --> Language Class Initialized
INFO - 2020-09-15 15:03:24 --> Loader Class Initialized
INFO - 2020-09-15 15:03:24 --> Helper loaded: url_helper
INFO - 2020-09-15 15:03:24 --> Database Driver Class Initialized
INFO - 2020-09-15 15:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:03:24 --> Email Class Initialized
INFO - 2020-09-15 15:03:24 --> Controller Class Initialized
INFO - 2020-09-15 15:03:24 --> Model Class Initialized
INFO - 2020-09-15 15:03:24 --> Model Class Initialized
INFO - 2020-09-15 15:03:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:03:24 --> Final output sent to browser
DEBUG - 2020-09-15 15:03:24 --> Total execution time: 0.0415
ERROR - 2020-09-15 15:03:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:03:35 --> Config Class Initialized
INFO - 2020-09-15 15:03:35 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:03:35 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:03:35 --> Utf8 Class Initialized
INFO - 2020-09-15 15:03:35 --> URI Class Initialized
INFO - 2020-09-15 15:03:35 --> Router Class Initialized
INFO - 2020-09-15 15:03:35 --> Output Class Initialized
INFO - 2020-09-15 15:03:35 --> Security Class Initialized
DEBUG - 2020-09-15 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:03:35 --> Input Class Initialized
INFO - 2020-09-15 15:03:35 --> Language Class Initialized
INFO - 2020-09-15 15:03:35 --> Loader Class Initialized
INFO - 2020-09-15 15:03:35 --> Helper loaded: url_helper
INFO - 2020-09-15 15:03:35 --> Database Driver Class Initialized
INFO - 2020-09-15 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:03:35 --> Email Class Initialized
INFO - 2020-09-15 15:03:35 --> Controller Class Initialized
INFO - 2020-09-15 15:03:35 --> Model Class Initialized
INFO - 2020-09-15 15:03:35 --> Model Class Initialized
INFO - 2020-09-15 15:03:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:03:35 --> Final output sent to browser
DEBUG - 2020-09-15 15:03:35 --> Total execution time: 0.0408
ERROR - 2020-09-15 15:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:03:36 --> Config Class Initialized
INFO - 2020-09-15 15:03:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:03:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:03:36 --> Utf8 Class Initialized
INFO - 2020-09-15 15:03:36 --> URI Class Initialized
INFO - 2020-09-15 15:03:36 --> Router Class Initialized
INFO - 2020-09-15 15:03:36 --> Output Class Initialized
INFO - 2020-09-15 15:03:36 --> Security Class Initialized
DEBUG - 2020-09-15 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:03:36 --> Input Class Initialized
INFO - 2020-09-15 15:03:36 --> Language Class Initialized
INFO - 2020-09-15 15:03:36 --> Loader Class Initialized
INFO - 2020-09-15 15:03:36 --> Helper loaded: url_helper
INFO - 2020-09-15 15:03:36 --> Database Driver Class Initialized
INFO - 2020-09-15 15:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:03:36 --> Email Class Initialized
INFO - 2020-09-15 15:03:36 --> Controller Class Initialized
INFO - 2020-09-15 15:03:36 --> Model Class Initialized
INFO - 2020-09-15 15:03:36 --> Model Class Initialized
INFO - 2020-09-15 15:03:36 --> Final output sent to browser
DEBUG - 2020-09-15 15:03:36 --> Total execution time: 0.0423
ERROR - 2020-09-15 15:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:03:59 --> Config Class Initialized
INFO - 2020-09-15 15:03:59 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:03:59 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:03:59 --> Utf8 Class Initialized
INFO - 2020-09-15 15:03:59 --> URI Class Initialized
INFO - 2020-09-15 15:03:59 --> Router Class Initialized
INFO - 2020-09-15 15:03:59 --> Output Class Initialized
INFO - 2020-09-15 15:03:59 --> Security Class Initialized
DEBUG - 2020-09-15 15:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:03:59 --> Input Class Initialized
INFO - 2020-09-15 15:03:59 --> Language Class Initialized
INFO - 2020-09-15 15:03:59 --> Loader Class Initialized
INFO - 2020-09-15 15:03:59 --> Helper loaded: url_helper
INFO - 2020-09-15 15:03:59 --> Database Driver Class Initialized
INFO - 2020-09-15 15:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:03:59 --> Email Class Initialized
INFO - 2020-09-15 15:03:59 --> Controller Class Initialized
INFO - 2020-09-15 15:03:59 --> Model Class Initialized
INFO - 2020-09-15 15:03:59 --> Model Class Initialized
INFO - 2020-09-15 15:03:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:03:59 --> Final output sent to browser
DEBUG - 2020-09-15 15:03:59 --> Total execution time: 0.0392
ERROR - 2020-09-15 15:03:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:03:59 --> Config Class Initialized
INFO - 2020-09-15 15:03:59 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:03:59 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:03:59 --> Utf8 Class Initialized
INFO - 2020-09-15 15:03:59 --> URI Class Initialized
INFO - 2020-09-15 15:03:59 --> Router Class Initialized
INFO - 2020-09-15 15:03:59 --> Output Class Initialized
INFO - 2020-09-15 15:03:59 --> Security Class Initialized
DEBUG - 2020-09-15 15:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:03:59 --> Input Class Initialized
INFO - 2020-09-15 15:03:59 --> Language Class Initialized
INFO - 2020-09-15 15:03:59 --> Loader Class Initialized
INFO - 2020-09-15 15:03:59 --> Helper loaded: url_helper
INFO - 2020-09-15 15:03:59 --> Database Driver Class Initialized
INFO - 2020-09-15 15:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:03:59 --> Email Class Initialized
INFO - 2020-09-15 15:03:59 --> Controller Class Initialized
INFO - 2020-09-15 15:03:59 --> Model Class Initialized
INFO - 2020-09-15 15:03:59 --> Model Class Initialized
INFO - 2020-09-15 15:03:59 --> Final output sent to browser
DEBUG - 2020-09-15 15:03:59 --> Total execution time: 0.0340
ERROR - 2020-09-15 15:04:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:04:08 --> Config Class Initialized
INFO - 2020-09-15 15:04:08 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:04:08 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:04:08 --> Utf8 Class Initialized
INFO - 2020-09-15 15:04:08 --> URI Class Initialized
INFO - 2020-09-15 15:04:08 --> Router Class Initialized
INFO - 2020-09-15 15:04:08 --> Output Class Initialized
INFO - 2020-09-15 15:04:08 --> Security Class Initialized
DEBUG - 2020-09-15 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:04:08 --> Input Class Initialized
INFO - 2020-09-15 15:04:08 --> Language Class Initialized
INFO - 2020-09-15 15:04:08 --> Loader Class Initialized
INFO - 2020-09-15 15:04:08 --> Helper loaded: url_helper
INFO - 2020-09-15 15:04:08 --> Database Driver Class Initialized
INFO - 2020-09-15 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:04:08 --> Email Class Initialized
INFO - 2020-09-15 15:04:08 --> Controller Class Initialized
INFO - 2020-09-15 15:04:08 --> Model Class Initialized
INFO - 2020-09-15 15:04:08 --> Model Class Initialized
INFO - 2020-09-15 15:04:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:04:08 --> Final output sent to browser
DEBUG - 2020-09-15 15:04:08 --> Total execution time: 0.0396
ERROR - 2020-09-15 15:04:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:04:24 --> Config Class Initialized
INFO - 2020-09-15 15:04:24 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:04:24 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:04:24 --> Utf8 Class Initialized
INFO - 2020-09-15 15:04:24 --> URI Class Initialized
INFO - 2020-09-15 15:04:24 --> Router Class Initialized
INFO - 2020-09-15 15:04:24 --> Output Class Initialized
INFO - 2020-09-15 15:04:24 --> Security Class Initialized
DEBUG - 2020-09-15 15:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:04:24 --> Input Class Initialized
INFO - 2020-09-15 15:04:24 --> Language Class Initialized
INFO - 2020-09-15 15:04:24 --> Loader Class Initialized
INFO - 2020-09-15 15:04:24 --> Helper loaded: url_helper
INFO - 2020-09-15 15:04:24 --> Database Driver Class Initialized
INFO - 2020-09-15 15:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:04:24 --> Email Class Initialized
INFO - 2020-09-15 15:04:24 --> Controller Class Initialized
INFO - 2020-09-15 15:04:24 --> Model Class Initialized
INFO - 2020-09-15 15:04:24 --> Model Class Initialized
INFO - 2020-09-15 15:04:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:04:24 --> Final output sent to browser
DEBUG - 2020-09-15 15:04:24 --> Total execution time: 0.0324
ERROR - 2020-09-15 15:04:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:04:25 --> Config Class Initialized
INFO - 2020-09-15 15:04:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:04:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:04:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:04:25 --> URI Class Initialized
INFO - 2020-09-15 15:04:25 --> Router Class Initialized
INFO - 2020-09-15 15:04:25 --> Output Class Initialized
INFO - 2020-09-15 15:04:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:04:25 --> Input Class Initialized
INFO - 2020-09-15 15:04:25 --> Language Class Initialized
INFO - 2020-09-15 15:04:25 --> Loader Class Initialized
INFO - 2020-09-15 15:04:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:04:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:04:25 --> Email Class Initialized
INFO - 2020-09-15 15:04:25 --> Controller Class Initialized
INFO - 2020-09-15 15:04:25 --> Model Class Initialized
INFO - 2020-09-15 15:04:25 --> Model Class Initialized
INFO - 2020-09-15 15:04:25 --> Final output sent to browser
DEBUG - 2020-09-15 15:04:25 --> Total execution time: 0.0382
ERROR - 2020-09-15 15:04:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:04:41 --> Config Class Initialized
INFO - 2020-09-15 15:04:41 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:04:41 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:04:41 --> Utf8 Class Initialized
INFO - 2020-09-15 15:04:41 --> URI Class Initialized
INFO - 2020-09-15 15:04:41 --> Router Class Initialized
INFO - 2020-09-15 15:04:41 --> Output Class Initialized
INFO - 2020-09-15 15:04:41 --> Security Class Initialized
DEBUG - 2020-09-15 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:04:41 --> Input Class Initialized
INFO - 2020-09-15 15:04:41 --> Language Class Initialized
INFO - 2020-09-15 15:04:41 --> Loader Class Initialized
INFO - 2020-09-15 15:04:41 --> Helper loaded: url_helper
INFO - 2020-09-15 15:04:41 --> Database Driver Class Initialized
INFO - 2020-09-15 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:04:41 --> Email Class Initialized
INFO - 2020-09-15 15:04:41 --> Controller Class Initialized
INFO - 2020-09-15 15:04:41 --> Model Class Initialized
INFO - 2020-09-15 15:04:41 --> Model Class Initialized
INFO - 2020-09-15 15:04:41 --> Final output sent to browser
DEBUG - 2020-09-15 15:04:41 --> Total execution time: 0.2371
ERROR - 2020-09-15 15:04:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:04:43 --> Config Class Initialized
INFO - 2020-09-15 15:04:43 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:04:43 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:04:43 --> Utf8 Class Initialized
INFO - 2020-09-15 15:04:43 --> URI Class Initialized
INFO - 2020-09-15 15:04:43 --> Router Class Initialized
INFO - 2020-09-15 15:04:43 --> Output Class Initialized
INFO - 2020-09-15 15:04:43 --> Security Class Initialized
DEBUG - 2020-09-15 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:04:43 --> Input Class Initialized
INFO - 2020-09-15 15:04:43 --> Language Class Initialized
INFO - 2020-09-15 15:04:43 --> Loader Class Initialized
INFO - 2020-09-15 15:04:43 --> Helper loaded: url_helper
INFO - 2020-09-15 15:04:43 --> Database Driver Class Initialized
INFO - 2020-09-15 15:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:04:43 --> Email Class Initialized
INFO - 2020-09-15 15:04:43 --> Controller Class Initialized
INFO - 2020-09-15 15:04:43 --> Model Class Initialized
INFO - 2020-09-15 15:04:43 --> Model Class Initialized
INFO - 2020-09-15 15:04:43 --> Final output sent to browser
DEBUG - 2020-09-15 15:04:43 --> Total execution time: 0.0451
ERROR - 2020-09-15 15:05:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:05:58 --> Config Class Initialized
INFO - 2020-09-15 15:05:58 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:05:58 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:05:58 --> Utf8 Class Initialized
INFO - 2020-09-15 15:05:58 --> URI Class Initialized
INFO - 2020-09-15 15:05:58 --> Router Class Initialized
INFO - 2020-09-15 15:05:58 --> Output Class Initialized
INFO - 2020-09-15 15:05:58 --> Security Class Initialized
DEBUG - 2020-09-15 15:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:05:58 --> Input Class Initialized
INFO - 2020-09-15 15:05:58 --> Language Class Initialized
INFO - 2020-09-15 15:05:58 --> Loader Class Initialized
INFO - 2020-09-15 15:05:58 --> Helper loaded: url_helper
INFO - 2020-09-15 15:05:58 --> Database Driver Class Initialized
INFO - 2020-09-15 15:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:05:58 --> Email Class Initialized
INFO - 2020-09-15 15:05:58 --> Controller Class Initialized
DEBUG - 2020-09-15 15:05:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:05:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:05:58 --> Model Class Initialized
INFO - 2020-09-15 15:05:58 --> Model Class Initialized
INFO - 2020-09-15 15:05:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-09-15 15:05:58 --> Final output sent to browser
DEBUG - 2020-09-15 15:05:58 --> Total execution time: 0.0647
ERROR - 2020-09-15 15:06:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:06:01 --> Config Class Initialized
INFO - 2020-09-15 15:06:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:06:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:06:01 --> Utf8 Class Initialized
INFO - 2020-09-15 15:06:01 --> URI Class Initialized
INFO - 2020-09-15 15:06:01 --> Router Class Initialized
INFO - 2020-09-15 15:06:01 --> Output Class Initialized
INFO - 2020-09-15 15:06:01 --> Security Class Initialized
DEBUG - 2020-09-15 15:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:06:01 --> Input Class Initialized
INFO - 2020-09-15 15:06:01 --> Language Class Initialized
INFO - 2020-09-15 15:06:01 --> Loader Class Initialized
INFO - 2020-09-15 15:06:01 --> Helper loaded: url_helper
INFO - 2020-09-15 15:06:01 --> Database Driver Class Initialized
INFO - 2020-09-15 15:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:06:01 --> Email Class Initialized
INFO - 2020-09-15 15:06:01 --> Controller Class Initialized
INFO - 2020-09-15 15:06:01 --> Model Class Initialized
INFO - 2020-09-15 15:06:01 --> Model Class Initialized
INFO - 2020-09-15 15:06:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:06:01 --> Final output sent to browser
DEBUG - 2020-09-15 15:06:01 --> Total execution time: 0.0387
ERROR - 2020-09-15 15:06:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:06:01 --> Config Class Initialized
INFO - 2020-09-15 15:06:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:06:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:06:01 --> Utf8 Class Initialized
INFO - 2020-09-15 15:06:01 --> URI Class Initialized
INFO - 2020-09-15 15:06:01 --> Router Class Initialized
INFO - 2020-09-15 15:06:01 --> Output Class Initialized
INFO - 2020-09-15 15:06:01 --> Security Class Initialized
DEBUG - 2020-09-15 15:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:06:01 --> Input Class Initialized
INFO - 2020-09-15 15:06:01 --> Language Class Initialized
INFO - 2020-09-15 15:06:01 --> Loader Class Initialized
INFO - 2020-09-15 15:06:01 --> Helper loaded: url_helper
INFO - 2020-09-15 15:06:01 --> Database Driver Class Initialized
INFO - 2020-09-15 15:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:06:01 --> Email Class Initialized
INFO - 2020-09-15 15:06:01 --> Controller Class Initialized
INFO - 2020-09-15 15:06:01 --> Model Class Initialized
INFO - 2020-09-15 15:06:01 --> Model Class Initialized
INFO - 2020-09-15 15:06:01 --> Final output sent to browser
DEBUG - 2020-09-15 15:06:01 --> Total execution time: 0.0483
ERROR - 2020-09-15 15:07:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:07:03 --> Config Class Initialized
INFO - 2020-09-15 15:07:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:07:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:07:03 --> Utf8 Class Initialized
INFO - 2020-09-15 15:07:03 --> URI Class Initialized
INFO - 2020-09-15 15:07:03 --> Router Class Initialized
INFO - 2020-09-15 15:07:03 --> Output Class Initialized
INFO - 2020-09-15 15:07:03 --> Security Class Initialized
DEBUG - 2020-09-15 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:07:03 --> Input Class Initialized
INFO - 2020-09-15 15:07:03 --> Language Class Initialized
INFO - 2020-09-15 15:07:03 --> Loader Class Initialized
INFO - 2020-09-15 15:07:03 --> Helper loaded: url_helper
INFO - 2020-09-15 15:07:03 --> Database Driver Class Initialized
INFO - 2020-09-15 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:07:03 --> Email Class Initialized
INFO - 2020-09-15 15:07:03 --> Controller Class Initialized
INFO - 2020-09-15 15:07:03 --> Model Class Initialized
INFO - 2020-09-15 15:07:03 --> Model Class Initialized
INFO - 2020-09-15 15:07:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:07:03 --> Final output sent to browser
DEBUG - 2020-09-15 15:07:03 --> Total execution time: 0.0422
ERROR - 2020-09-15 15:07:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:07:04 --> Config Class Initialized
INFO - 2020-09-15 15:07:04 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:07:04 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:07:04 --> Utf8 Class Initialized
INFO - 2020-09-15 15:07:04 --> URI Class Initialized
INFO - 2020-09-15 15:07:04 --> Router Class Initialized
INFO - 2020-09-15 15:07:04 --> Output Class Initialized
INFO - 2020-09-15 15:07:04 --> Security Class Initialized
DEBUG - 2020-09-15 15:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:07:04 --> Input Class Initialized
INFO - 2020-09-15 15:07:04 --> Language Class Initialized
INFO - 2020-09-15 15:07:04 --> Loader Class Initialized
INFO - 2020-09-15 15:07:04 --> Helper loaded: url_helper
INFO - 2020-09-15 15:07:04 --> Database Driver Class Initialized
INFO - 2020-09-15 15:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:07:04 --> Email Class Initialized
INFO - 2020-09-15 15:07:04 --> Controller Class Initialized
INFO - 2020-09-15 15:07:04 --> Model Class Initialized
INFO - 2020-09-15 15:07:04 --> Model Class Initialized
INFO - 2020-09-15 15:07:04 --> Final output sent to browser
DEBUG - 2020-09-15 15:07:04 --> Total execution time: 0.0457
ERROR - 2020-09-15 15:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:09:48 --> Config Class Initialized
INFO - 2020-09-15 15:09:48 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:09:48 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:09:48 --> Utf8 Class Initialized
INFO - 2020-09-15 15:09:48 --> URI Class Initialized
INFO - 2020-09-15 15:09:48 --> Router Class Initialized
INFO - 2020-09-15 15:09:48 --> Output Class Initialized
INFO - 2020-09-15 15:09:48 --> Security Class Initialized
DEBUG - 2020-09-15 15:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:09:48 --> Input Class Initialized
INFO - 2020-09-15 15:09:48 --> Language Class Initialized
INFO - 2020-09-15 15:09:48 --> Loader Class Initialized
INFO - 2020-09-15 15:09:48 --> Helper loaded: url_helper
INFO - 2020-09-15 15:09:48 --> Database Driver Class Initialized
INFO - 2020-09-15 15:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:09:48 --> Email Class Initialized
INFO - 2020-09-15 15:09:48 --> Controller Class Initialized
INFO - 2020-09-15 15:09:48 --> Model Class Initialized
INFO - 2020-09-15 15:09:48 --> Model Class Initialized
INFO - 2020-09-15 15:09:48 --> Model Class Initialized
INFO - 2020-09-15 15:09:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:09:49 --> Final output sent to browser
DEBUG - 2020-09-15 15:09:49 --> Total execution time: 0.0394
ERROR - 2020-09-15 15:09:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:09:49 --> Config Class Initialized
INFO - 2020-09-15 15:09:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:09:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:09:49 --> Utf8 Class Initialized
INFO - 2020-09-15 15:09:49 --> URI Class Initialized
INFO - 2020-09-15 15:09:49 --> Router Class Initialized
INFO - 2020-09-15 15:09:49 --> Output Class Initialized
INFO - 2020-09-15 15:09:49 --> Security Class Initialized
DEBUG - 2020-09-15 15:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:09:49 --> Input Class Initialized
INFO - 2020-09-15 15:09:49 --> Language Class Initialized
INFO - 2020-09-15 15:09:49 --> Loader Class Initialized
INFO - 2020-09-15 15:09:49 --> Helper loaded: url_helper
INFO - 2020-09-15 15:09:49 --> Database Driver Class Initialized
INFO - 2020-09-15 15:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:09:49 --> Email Class Initialized
INFO - 2020-09-15 15:09:49 --> Controller Class Initialized
INFO - 2020-09-15 15:09:49 --> Model Class Initialized
INFO - 2020-09-15 15:09:49 --> Model Class Initialized
INFO - 2020-09-15 15:09:49 --> Final output sent to browser
DEBUG - 2020-09-15 15:09:49 --> Total execution time: 0.0480
ERROR - 2020-09-15 15:11:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:11:24 --> Config Class Initialized
INFO - 2020-09-15 15:11:24 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:11:24 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:11:24 --> Utf8 Class Initialized
INFO - 2020-09-15 15:11:24 --> URI Class Initialized
INFO - 2020-09-15 15:11:24 --> Router Class Initialized
INFO - 2020-09-15 15:11:24 --> Output Class Initialized
INFO - 2020-09-15 15:11:24 --> Security Class Initialized
DEBUG - 2020-09-15 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:11:24 --> Input Class Initialized
INFO - 2020-09-15 15:11:24 --> Language Class Initialized
INFO - 2020-09-15 15:11:24 --> Loader Class Initialized
INFO - 2020-09-15 15:11:24 --> Helper loaded: url_helper
INFO - 2020-09-15 15:11:24 --> Database Driver Class Initialized
INFO - 2020-09-15 15:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:11:24 --> Email Class Initialized
INFO - 2020-09-15 15:11:24 --> Controller Class Initialized
INFO - 2020-09-15 15:11:24 --> Model Class Initialized
INFO - 2020-09-15 15:11:24 --> Model Class Initialized
INFO - 2020-09-15 15:11:24 --> Model Class Initialized
INFO - 2020-09-15 15:11:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:11:24 --> Final output sent to browser
DEBUG - 2020-09-15 15:11:24 --> Total execution time: 0.0438
ERROR - 2020-09-15 15:11:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:11:24 --> Config Class Initialized
INFO - 2020-09-15 15:11:24 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:11:24 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:11:24 --> Utf8 Class Initialized
INFO - 2020-09-15 15:11:24 --> URI Class Initialized
INFO - 2020-09-15 15:11:24 --> Router Class Initialized
INFO - 2020-09-15 15:11:24 --> Output Class Initialized
INFO - 2020-09-15 15:11:24 --> Security Class Initialized
DEBUG - 2020-09-15 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:11:24 --> Input Class Initialized
INFO - 2020-09-15 15:11:24 --> Language Class Initialized
INFO - 2020-09-15 15:11:24 --> Loader Class Initialized
INFO - 2020-09-15 15:11:24 --> Helper loaded: url_helper
INFO - 2020-09-15 15:11:24 --> Database Driver Class Initialized
INFO - 2020-09-15 15:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:11:24 --> Email Class Initialized
INFO - 2020-09-15 15:11:24 --> Controller Class Initialized
INFO - 2020-09-15 15:11:24 --> Model Class Initialized
INFO - 2020-09-15 15:11:24 --> Model Class Initialized
INFO - 2020-09-15 15:11:24 --> Final output sent to browser
DEBUG - 2020-09-15 15:11:24 --> Total execution time: 0.0444
ERROR - 2020-09-15 15:11:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:11:31 --> Config Class Initialized
INFO - 2020-09-15 15:11:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:11:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:11:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:11:31 --> URI Class Initialized
INFO - 2020-09-15 15:11:31 --> Router Class Initialized
INFO - 2020-09-15 15:11:31 --> Output Class Initialized
INFO - 2020-09-15 15:11:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:11:31 --> Input Class Initialized
INFO - 2020-09-15 15:11:31 --> Language Class Initialized
INFO - 2020-09-15 15:11:31 --> Loader Class Initialized
INFO - 2020-09-15 15:11:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:11:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:11:31 --> Email Class Initialized
INFO - 2020-09-15 15:11:31 --> Controller Class Initialized
INFO - 2020-09-15 15:11:31 --> Model Class Initialized
INFO - 2020-09-15 15:11:31 --> Model Class Initialized
ERROR - 2020-09-15 15:11:31 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.excel_data_insert; expected 1, got 0 - Invalid query: CALL excel_data_insert()
INFO - 2020-09-15 15:11:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 15:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:13:44 --> Config Class Initialized
INFO - 2020-09-15 15:13:44 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:13:44 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:13:44 --> Utf8 Class Initialized
INFO - 2020-09-15 15:13:44 --> URI Class Initialized
INFO - 2020-09-15 15:13:44 --> Router Class Initialized
INFO - 2020-09-15 15:13:44 --> Output Class Initialized
INFO - 2020-09-15 15:13:44 --> Security Class Initialized
DEBUG - 2020-09-15 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:13:44 --> Input Class Initialized
INFO - 2020-09-15 15:13:44 --> Language Class Initialized
INFO - 2020-09-15 15:13:44 --> Loader Class Initialized
INFO - 2020-09-15 15:13:44 --> Helper loaded: url_helper
INFO - 2020-09-15 15:13:44 --> Database Driver Class Initialized
INFO - 2020-09-15 15:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:13:44 --> Email Class Initialized
INFO - 2020-09-15 15:13:44 --> Controller Class Initialized
INFO - 2020-09-15 15:13:44 --> Model Class Initialized
INFO - 2020-09-15 15:13:44 --> Model Class Initialized
INFO - 2020-09-15 15:13:44 --> Model Class Initialized
INFO - 2020-09-15 15:13:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:13:44 --> Final output sent to browser
DEBUG - 2020-09-15 15:13:44 --> Total execution time: 0.0437
ERROR - 2020-09-15 15:13:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:13:44 --> Config Class Initialized
INFO - 2020-09-15 15:13:44 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:13:44 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:13:44 --> Utf8 Class Initialized
INFO - 2020-09-15 15:13:44 --> URI Class Initialized
INFO - 2020-09-15 15:13:44 --> Router Class Initialized
INFO - 2020-09-15 15:13:44 --> Output Class Initialized
INFO - 2020-09-15 15:13:44 --> Security Class Initialized
DEBUG - 2020-09-15 15:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:13:44 --> Input Class Initialized
INFO - 2020-09-15 15:13:44 --> Language Class Initialized
INFO - 2020-09-15 15:13:44 --> Loader Class Initialized
INFO - 2020-09-15 15:13:44 --> Helper loaded: url_helper
INFO - 2020-09-15 15:13:44 --> Database Driver Class Initialized
INFO - 2020-09-15 15:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:13:44 --> Email Class Initialized
INFO - 2020-09-15 15:13:44 --> Controller Class Initialized
INFO - 2020-09-15 15:13:44 --> Model Class Initialized
INFO - 2020-09-15 15:13:44 --> Model Class Initialized
INFO - 2020-09-15 15:13:44 --> Final output sent to browser
DEBUG - 2020-09-15 15:13:44 --> Total execution time: 0.0461
ERROR - 2020-09-15 15:13:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:13:50 --> Config Class Initialized
INFO - 2020-09-15 15:13:50 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:13:50 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:13:50 --> Utf8 Class Initialized
INFO - 2020-09-15 15:13:50 --> URI Class Initialized
INFO - 2020-09-15 15:13:50 --> Router Class Initialized
INFO - 2020-09-15 15:13:50 --> Output Class Initialized
INFO - 2020-09-15 15:13:50 --> Security Class Initialized
DEBUG - 2020-09-15 15:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:13:50 --> Input Class Initialized
INFO - 2020-09-15 15:13:50 --> Language Class Initialized
INFO - 2020-09-15 15:13:50 --> Loader Class Initialized
INFO - 2020-09-15 15:13:50 --> Helper loaded: url_helper
INFO - 2020-09-15 15:13:50 --> Database Driver Class Initialized
INFO - 2020-09-15 15:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:13:50 --> Email Class Initialized
INFO - 2020-09-15 15:13:50 --> Controller Class Initialized
INFO - 2020-09-15 15:13:50 --> Model Class Initialized
INFO - 2020-09-15 15:13:50 --> Model Class Initialized
INFO - 2020-09-15 15:13:50 --> Model Class Initialized
ERROR - 2020-09-15 15:13:50 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.excel_data_insert; expected 1, got 0 - Invalid query: CALL excel_data_insert()
INFO - 2020-09-15 15:13:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 15:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:17:26 --> Config Class Initialized
INFO - 2020-09-15 15:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:17:26 --> Utf8 Class Initialized
INFO - 2020-09-15 15:17:26 --> URI Class Initialized
INFO - 2020-09-15 15:17:26 --> Router Class Initialized
INFO - 2020-09-15 15:17:26 --> Output Class Initialized
INFO - 2020-09-15 15:17:26 --> Security Class Initialized
DEBUG - 2020-09-15 15:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:17:26 --> Input Class Initialized
INFO - 2020-09-15 15:17:26 --> Language Class Initialized
INFO - 2020-09-15 15:17:26 --> Loader Class Initialized
INFO - 2020-09-15 15:17:26 --> Helper loaded: url_helper
INFO - 2020-09-15 15:17:26 --> Database Driver Class Initialized
INFO - 2020-09-15 15:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:17:26 --> Email Class Initialized
INFO - 2020-09-15 15:17:26 --> Controller Class Initialized
INFO - 2020-09-15 15:17:26 --> Model Class Initialized
INFO - 2020-09-15 15:17:26 --> Model Class Initialized
INFO - 2020-09-15 15:17:26 --> Model Class Initialized
INFO - 2020-09-15 15:17:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:17:26 --> Final output sent to browser
DEBUG - 2020-09-15 15:17:26 --> Total execution time: 0.0486
ERROR - 2020-09-15 15:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:17:26 --> Config Class Initialized
INFO - 2020-09-15 15:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:17:26 --> Utf8 Class Initialized
INFO - 2020-09-15 15:17:26 --> URI Class Initialized
INFO - 2020-09-15 15:17:26 --> Router Class Initialized
INFO - 2020-09-15 15:17:26 --> Output Class Initialized
INFO - 2020-09-15 15:17:26 --> Security Class Initialized
DEBUG - 2020-09-15 15:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:17:26 --> Input Class Initialized
INFO - 2020-09-15 15:17:26 --> Language Class Initialized
INFO - 2020-09-15 15:17:26 --> Loader Class Initialized
INFO - 2020-09-15 15:17:26 --> Helper loaded: url_helper
INFO - 2020-09-15 15:17:26 --> Database Driver Class Initialized
INFO - 2020-09-15 15:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:17:26 --> Email Class Initialized
INFO - 2020-09-15 15:17:26 --> Controller Class Initialized
INFO - 2020-09-15 15:17:26 --> Model Class Initialized
INFO - 2020-09-15 15:17:26 --> Model Class Initialized
INFO - 2020-09-15 15:17:26 --> Final output sent to browser
DEBUG - 2020-09-15 15:17:26 --> Total execution time: 0.0397
ERROR - 2020-09-15 15:17:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:17:31 --> Config Class Initialized
INFO - 2020-09-15 15:17:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:17:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:17:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:17:31 --> URI Class Initialized
INFO - 2020-09-15 15:17:31 --> Router Class Initialized
INFO - 2020-09-15 15:17:31 --> Output Class Initialized
INFO - 2020-09-15 15:17:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:17:31 --> Input Class Initialized
INFO - 2020-09-15 15:17:31 --> Language Class Initialized
INFO - 2020-09-15 15:17:31 --> Loader Class Initialized
INFO - 2020-09-15 15:17:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:17:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:17:31 --> Email Class Initialized
INFO - 2020-09-15 15:17:31 --> Controller Class Initialized
INFO - 2020-09-15 15:17:31 --> Model Class Initialized
INFO - 2020-09-15 15:17:31 --> Model Class Initialized
INFO - 2020-09-15 15:17:31 --> Model Class Initialized
INFO - 2020-09-15 15:17:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:17:31 --> Final output sent to browser
DEBUG - 2020-09-15 15:17:31 --> Total execution time: 0.0467
ERROR - 2020-09-15 15:17:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:17:32 --> Config Class Initialized
INFO - 2020-09-15 15:17:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:17:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:17:32 --> Utf8 Class Initialized
INFO - 2020-09-15 15:17:32 --> URI Class Initialized
INFO - 2020-09-15 15:17:32 --> Router Class Initialized
INFO - 2020-09-15 15:17:32 --> Output Class Initialized
INFO - 2020-09-15 15:17:32 --> Security Class Initialized
DEBUG - 2020-09-15 15:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:17:32 --> Input Class Initialized
INFO - 2020-09-15 15:17:32 --> Language Class Initialized
INFO - 2020-09-15 15:17:32 --> Loader Class Initialized
INFO - 2020-09-15 15:17:32 --> Helper loaded: url_helper
INFO - 2020-09-15 15:17:32 --> Database Driver Class Initialized
INFO - 2020-09-15 15:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:17:32 --> Email Class Initialized
INFO - 2020-09-15 15:17:32 --> Controller Class Initialized
INFO - 2020-09-15 15:17:32 --> Model Class Initialized
INFO - 2020-09-15 15:17:32 --> Model Class Initialized
INFO - 2020-09-15 15:17:32 --> Final output sent to browser
DEBUG - 2020-09-15 15:17:32 --> Total execution time: 0.0364
ERROR - 2020-09-15 15:17:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:17:36 --> Config Class Initialized
INFO - 2020-09-15 15:17:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:17:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:17:36 --> Utf8 Class Initialized
INFO - 2020-09-15 15:17:36 --> URI Class Initialized
INFO - 2020-09-15 15:17:36 --> Router Class Initialized
INFO - 2020-09-15 15:17:36 --> Output Class Initialized
INFO - 2020-09-15 15:17:36 --> Security Class Initialized
DEBUG - 2020-09-15 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:17:36 --> Input Class Initialized
INFO - 2020-09-15 15:17:36 --> Language Class Initialized
INFO - 2020-09-15 15:17:36 --> Loader Class Initialized
INFO - 2020-09-15 15:17:36 --> Helper loaded: url_helper
INFO - 2020-09-15 15:17:36 --> Database Driver Class Initialized
INFO - 2020-09-15 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:17:36 --> Email Class Initialized
INFO - 2020-09-15 15:17:36 --> Controller Class Initialized
INFO - 2020-09-15 15:17:36 --> Model Class Initialized
INFO - 2020-09-15 15:17:36 --> Model Class Initialized
INFO - 2020-09-15 15:17:36 --> Model Class Initialized
ERROR - 2020-09-15 15:17:36 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.excel_data_insert; expected 1, got 0 - Invalid query: CALL excel_data_insert()
INFO - 2020-09-15 15:17:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 15:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:02 --> Config Class Initialized
INFO - 2020-09-15 15:19:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:02 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:02 --> URI Class Initialized
INFO - 2020-09-15 15:19:02 --> Router Class Initialized
INFO - 2020-09-15 15:19:02 --> Output Class Initialized
INFO - 2020-09-15 15:19:02 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:02 --> Input Class Initialized
INFO - 2020-09-15 15:19:02 --> Language Class Initialized
INFO - 2020-09-15 15:19:02 --> Loader Class Initialized
INFO - 2020-09-15 15:19:02 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:02 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:02 --> Email Class Initialized
INFO - 2020-09-15 15:19:02 --> Controller Class Initialized
INFO - 2020-09-15 15:19:02 --> Model Class Initialized
INFO - 2020-09-15 15:19:02 --> Model Class Initialized
INFO - 2020-09-15 15:19:02 --> Model Class Initialized
INFO - 2020-09-15 15:19:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:19:02 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:02 --> Total execution time: 0.0463
ERROR - 2020-09-15 15:19:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:02 --> Config Class Initialized
INFO - 2020-09-15 15:19:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:02 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:02 --> URI Class Initialized
INFO - 2020-09-15 15:19:02 --> Router Class Initialized
INFO - 2020-09-15 15:19:02 --> Output Class Initialized
INFO - 2020-09-15 15:19:02 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:02 --> Input Class Initialized
INFO - 2020-09-15 15:19:02 --> Language Class Initialized
INFO - 2020-09-15 15:19:02 --> Loader Class Initialized
INFO - 2020-09-15 15:19:02 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:02 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:02 --> Email Class Initialized
INFO - 2020-09-15 15:19:02 --> Controller Class Initialized
INFO - 2020-09-15 15:19:02 --> Model Class Initialized
INFO - 2020-09-15 15:19:02 --> Model Class Initialized
INFO - 2020-09-15 15:19:02 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:02 --> Total execution time: 0.0443
ERROR - 2020-09-15 15:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:06 --> Config Class Initialized
INFO - 2020-09-15 15:19:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:06 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:06 --> URI Class Initialized
INFO - 2020-09-15 15:19:06 --> Router Class Initialized
INFO - 2020-09-15 15:19:06 --> Output Class Initialized
INFO - 2020-09-15 15:19:06 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:06 --> Input Class Initialized
INFO - 2020-09-15 15:19:06 --> Language Class Initialized
INFO - 2020-09-15 15:19:06 --> Loader Class Initialized
INFO - 2020-09-15 15:19:06 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:06 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:06 --> Email Class Initialized
INFO - 2020-09-15 15:19:06 --> Controller Class Initialized
INFO - 2020-09-15 15:19:06 --> Model Class Initialized
INFO - 2020-09-15 15:19:06 --> Model Class Initialized
INFO - 2020-09-15 15:19:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:19:06 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:06 --> Total execution time: 0.1468
ERROR - 2020-09-15 15:19:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:06 --> Config Class Initialized
INFO - 2020-09-15 15:19:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:06 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:06 --> URI Class Initialized
INFO - 2020-09-15 15:19:06 --> Router Class Initialized
INFO - 2020-09-15 15:19:06 --> Output Class Initialized
INFO - 2020-09-15 15:19:06 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:06 --> Input Class Initialized
INFO - 2020-09-15 15:19:06 --> Language Class Initialized
INFO - 2020-09-15 15:19:06 --> Loader Class Initialized
INFO - 2020-09-15 15:19:06 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:06 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:07 --> Email Class Initialized
INFO - 2020-09-15 15:19:07 --> Controller Class Initialized
INFO - 2020-09-15 15:19:07 --> Model Class Initialized
INFO - 2020-09-15 15:19:07 --> Model Class Initialized
INFO - 2020-09-15 15:19:07 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:07 --> Total execution time: 0.1404
ERROR - 2020-09-15 15:19:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:38 --> Config Class Initialized
INFO - 2020-09-15 15:19:38 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:38 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:38 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:38 --> URI Class Initialized
INFO - 2020-09-15 15:19:38 --> Router Class Initialized
INFO - 2020-09-15 15:19:38 --> Output Class Initialized
INFO - 2020-09-15 15:19:38 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:38 --> Input Class Initialized
INFO - 2020-09-15 15:19:38 --> Language Class Initialized
INFO - 2020-09-15 15:19:38 --> Loader Class Initialized
INFO - 2020-09-15 15:19:38 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:38 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:38 --> Email Class Initialized
INFO - 2020-09-15 15:19:38 --> Controller Class Initialized
INFO - 2020-09-15 15:19:38 --> Model Class Initialized
INFO - 2020-09-15 15:19:38 --> Model Class Initialized
INFO - 2020-09-15 15:19:38 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:38 --> Total execution time: 0.1307
ERROR - 2020-09-15 15:19:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:39 --> Config Class Initialized
INFO - 2020-09-15 15:19:39 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:39 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:39 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:39 --> URI Class Initialized
INFO - 2020-09-15 15:19:39 --> Router Class Initialized
INFO - 2020-09-15 15:19:39 --> Output Class Initialized
INFO - 2020-09-15 15:19:39 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:39 --> Input Class Initialized
INFO - 2020-09-15 15:19:39 --> Language Class Initialized
INFO - 2020-09-15 15:19:39 --> Loader Class Initialized
INFO - 2020-09-15 15:19:39 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:39 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:39 --> Email Class Initialized
INFO - 2020-09-15 15:19:39 --> Controller Class Initialized
INFO - 2020-09-15 15:19:39 --> Model Class Initialized
INFO - 2020-09-15 15:19:39 --> Model Class Initialized
INFO - 2020-09-15 15:19:39 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:39 --> Total execution time: 0.0340
ERROR - 2020-09-15 15:19:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:19:56 --> Config Class Initialized
INFO - 2020-09-15 15:19:56 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:19:56 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:19:56 --> Utf8 Class Initialized
INFO - 2020-09-15 15:19:56 --> URI Class Initialized
INFO - 2020-09-15 15:19:56 --> Router Class Initialized
INFO - 2020-09-15 15:19:56 --> Output Class Initialized
INFO - 2020-09-15 15:19:56 --> Security Class Initialized
DEBUG - 2020-09-15 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:19:56 --> Input Class Initialized
INFO - 2020-09-15 15:19:56 --> Language Class Initialized
INFO - 2020-09-15 15:19:56 --> Loader Class Initialized
INFO - 2020-09-15 15:19:56 --> Helper loaded: url_helper
INFO - 2020-09-15 15:19:56 --> Database Driver Class Initialized
INFO - 2020-09-15 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:19:56 --> Email Class Initialized
INFO - 2020-09-15 15:19:56 --> Controller Class Initialized
INFO - 2020-09-15 15:19:56 --> Model Class Initialized
INFO - 2020-09-15 15:19:56 --> Model Class Initialized
INFO - 2020-09-15 15:19:56 --> Model Class Initialized
INFO - 2020-09-15 15:19:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:19:56 --> Final output sent to browser
DEBUG - 2020-09-15 15:19:56 --> Total execution time: 0.0427
ERROR - 2020-09-15 15:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:03 --> Config Class Initialized
INFO - 2020-09-15 15:20:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:03 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:03 --> URI Class Initialized
INFO - 2020-09-15 15:20:03 --> Router Class Initialized
INFO - 2020-09-15 15:20:03 --> Output Class Initialized
INFO - 2020-09-15 15:20:03 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:03 --> Input Class Initialized
INFO - 2020-09-15 15:20:03 --> Language Class Initialized
INFO - 2020-09-15 15:20:03 --> Loader Class Initialized
INFO - 2020-09-15 15:20:03 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:03 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:03 --> Email Class Initialized
INFO - 2020-09-15 15:20:03 --> Controller Class Initialized
INFO - 2020-09-15 15:20:03 --> Model Class Initialized
INFO - 2020-09-15 15:20:03 --> Model Class Initialized
INFO - 2020-09-15 15:20:03 --> Model Class Initialized
INFO - 2020-09-15 15:20:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:20:03 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:03 --> Total execution time: 0.0431
ERROR - 2020-09-15 15:20:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:03 --> Config Class Initialized
INFO - 2020-09-15 15:20:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:03 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:03 --> URI Class Initialized
INFO - 2020-09-15 15:20:03 --> Router Class Initialized
INFO - 2020-09-15 15:20:03 --> Output Class Initialized
INFO - 2020-09-15 15:20:03 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:03 --> Input Class Initialized
INFO - 2020-09-15 15:20:03 --> Language Class Initialized
INFO - 2020-09-15 15:20:03 --> Loader Class Initialized
INFO - 2020-09-15 15:20:03 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:03 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:03 --> Email Class Initialized
INFO - 2020-09-15 15:20:03 --> Controller Class Initialized
INFO - 2020-09-15 15:20:03 --> Model Class Initialized
INFO - 2020-09-15 15:20:03 --> Model Class Initialized
INFO - 2020-09-15 15:20:03 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:03 --> Total execution time: 0.0509
ERROR - 2020-09-15 15:20:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:10 --> Config Class Initialized
INFO - 2020-09-15 15:20:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:10 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:10 --> URI Class Initialized
DEBUG - 2020-09-15 15:20:10 --> No URI present. Default controller set.
INFO - 2020-09-15 15:20:10 --> Router Class Initialized
INFO - 2020-09-15 15:20:10 --> Output Class Initialized
INFO - 2020-09-15 15:20:10 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:10 --> Input Class Initialized
INFO - 2020-09-15 15:20:10 --> Language Class Initialized
INFO - 2020-09-15 15:20:10 --> Loader Class Initialized
INFO - 2020-09-15 15:20:10 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:10 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:10 --> Email Class Initialized
INFO - 2020-09-15 15:20:10 --> Controller Class Initialized
INFO - 2020-09-15 15:20:10 --> Model Class Initialized
INFO - 2020-09-15 15:20:10 --> Model Class Initialized
DEBUG - 2020-09-15 15:20:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:20:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 15:20:10 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:10 --> Total execution time: 0.0188
ERROR - 2020-09-15 15:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:25 --> Config Class Initialized
INFO - 2020-09-15 15:20:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:25 --> URI Class Initialized
INFO - 2020-09-15 15:20:25 --> Router Class Initialized
INFO - 2020-09-15 15:20:25 --> Output Class Initialized
INFO - 2020-09-15 15:20:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:25 --> Input Class Initialized
INFO - 2020-09-15 15:20:25 --> Language Class Initialized
INFO - 2020-09-15 15:20:25 --> Loader Class Initialized
INFO - 2020-09-15 15:20:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:25 --> Email Class Initialized
INFO - 2020-09-15 15:20:25 --> Controller Class Initialized
INFO - 2020-09-15 15:20:25 --> Model Class Initialized
INFO - 2020-09-15 15:20:25 --> Model Class Initialized
DEBUG - 2020-09-15 15:20:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 15:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:25 --> Config Class Initialized
INFO - 2020-09-15 15:20:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:25 --> URI Class Initialized
INFO - 2020-09-15 15:20:25 --> Router Class Initialized
INFO - 2020-09-15 15:20:25 --> Output Class Initialized
INFO - 2020-09-15 15:20:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:25 --> Input Class Initialized
INFO - 2020-09-15 15:20:25 --> Language Class Initialized
INFO - 2020-09-15 15:20:25 --> Loader Class Initialized
INFO - 2020-09-15 15:20:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:25 --> Email Class Initialized
INFO - 2020-09-15 15:20:25 --> Controller Class Initialized
INFO - 2020-09-15 15:20:25 --> Model Class Initialized
INFO - 2020-09-15 15:20:25 --> Model Class Initialized
DEBUG - 2020-09-15 15:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:20:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:20:25 --> Model Class Initialized
INFO - 2020-09-15 15:20:25 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:25 --> Total execution time: 0.0266
ERROR - 2020-09-15 15:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:25 --> Config Class Initialized
INFO - 2020-09-15 15:20:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:25 --> URI Class Initialized
INFO - 2020-09-15 15:20:25 --> Router Class Initialized
INFO - 2020-09-15 15:20:25 --> Output Class Initialized
INFO - 2020-09-15 15:20:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:25 --> Input Class Initialized
INFO - 2020-09-15 15:20:25 --> Language Class Initialized
INFO - 2020-09-15 15:20:25 --> Loader Class Initialized
INFO - 2020-09-15 15:20:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:25 --> Email Class Initialized
INFO - 2020-09-15 15:20:25 --> Controller Class Initialized
DEBUG - 2020-09-15 15:20:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:20:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:20:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-15 15:20:25 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:25 --> Total execution time: 0.0267
ERROR - 2020-09-15 15:20:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:31 --> Config Class Initialized
INFO - 2020-09-15 15:20:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:31 --> URI Class Initialized
INFO - 2020-09-15 15:20:31 --> Router Class Initialized
INFO - 2020-09-15 15:20:31 --> Output Class Initialized
INFO - 2020-09-15 15:20:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:31 --> Input Class Initialized
INFO - 2020-09-15 15:20:31 --> Language Class Initialized
INFO - 2020-09-15 15:20:31 --> Loader Class Initialized
INFO - 2020-09-15 15:20:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:31 --> Email Class Initialized
INFO - 2020-09-15 15:20:31 --> Controller Class Initialized
INFO - 2020-09-15 15:20:31 --> Model Class Initialized
INFO - 2020-09-15 15:20:31 --> Model Class Initialized
INFO - 2020-09-15 15:20:31 --> Model Class Initialized
INFO - 2020-09-15 15:20:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:20:31 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:31 --> Total execution time: 0.0441
ERROR - 2020-09-15 15:20:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:32 --> Config Class Initialized
INFO - 2020-09-15 15:20:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:32 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:32 --> URI Class Initialized
INFO - 2020-09-15 15:20:32 --> Router Class Initialized
INFO - 2020-09-15 15:20:32 --> Output Class Initialized
INFO - 2020-09-15 15:20:32 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:32 --> Input Class Initialized
INFO - 2020-09-15 15:20:32 --> Language Class Initialized
INFO - 2020-09-15 15:20:32 --> Loader Class Initialized
INFO - 2020-09-15 15:20:32 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:32 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:32 --> Email Class Initialized
INFO - 2020-09-15 15:20:32 --> Controller Class Initialized
INFO - 2020-09-15 15:20:32 --> Model Class Initialized
INFO - 2020-09-15 15:20:32 --> Model Class Initialized
INFO - 2020-09-15 15:20:33 --> Final output sent to browser
DEBUG - 2020-09-15 15:20:33 --> Total execution time: 0.0425
ERROR - 2020-09-15 15:20:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:20:40 --> Config Class Initialized
INFO - 2020-09-15 15:20:40 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:20:40 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:20:40 --> Utf8 Class Initialized
INFO - 2020-09-15 15:20:40 --> URI Class Initialized
INFO - 2020-09-15 15:20:40 --> Router Class Initialized
INFO - 2020-09-15 15:20:40 --> Output Class Initialized
INFO - 2020-09-15 15:20:40 --> Security Class Initialized
DEBUG - 2020-09-15 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:20:40 --> Input Class Initialized
INFO - 2020-09-15 15:20:40 --> Language Class Initialized
INFO - 2020-09-15 15:20:40 --> Loader Class Initialized
INFO - 2020-09-15 15:20:40 --> Helper loaded: url_helper
INFO - 2020-09-15 15:20:40 --> Database Driver Class Initialized
INFO - 2020-09-15 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:20:40 --> Email Class Initialized
INFO - 2020-09-15 15:20:40 --> Controller Class Initialized
INFO - 2020-09-15 15:20:40 --> Model Class Initialized
INFO - 2020-09-15 15:20:40 --> Model Class Initialized
INFO - 2020-09-15 15:20:40 --> Model Class Initialized
ERROR - 2020-09-15 15:20:40 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.excel_data_insert; expected 1, got 0 - Invalid query: CALL excel_data_insert()
INFO - 2020-09-15 15:20:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 15:23:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:23:29 --> Config Class Initialized
INFO - 2020-09-15 15:23:29 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:23:29 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:23:29 --> Utf8 Class Initialized
INFO - 2020-09-15 15:23:29 --> URI Class Initialized
INFO - 2020-09-15 15:23:29 --> Router Class Initialized
INFO - 2020-09-15 15:23:29 --> Output Class Initialized
INFO - 2020-09-15 15:23:29 --> Security Class Initialized
DEBUG - 2020-09-15 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:23:29 --> Input Class Initialized
INFO - 2020-09-15 15:23:29 --> Language Class Initialized
INFO - 2020-09-15 15:23:29 --> Loader Class Initialized
INFO - 2020-09-15 15:23:29 --> Helper loaded: url_helper
INFO - 2020-09-15 15:23:29 --> Database Driver Class Initialized
INFO - 2020-09-15 15:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:23:29 --> Email Class Initialized
INFO - 2020-09-15 15:23:29 --> Controller Class Initialized
INFO - 2020-09-15 15:23:29 --> Model Class Initialized
INFO - 2020-09-15 15:23:29 --> Model Class Initialized
INFO - 2020-09-15 15:23:29 --> Model Class Initialized
INFO - 2020-09-15 15:23:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:23:29 --> Final output sent to browser
DEBUG - 2020-09-15 15:23:29 --> Total execution time: 0.0447
ERROR - 2020-09-15 15:23:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:23:30 --> Config Class Initialized
INFO - 2020-09-15 15:23:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:23:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:23:30 --> Utf8 Class Initialized
INFO - 2020-09-15 15:23:30 --> URI Class Initialized
INFO - 2020-09-15 15:23:30 --> Router Class Initialized
INFO - 2020-09-15 15:23:30 --> Output Class Initialized
INFO - 2020-09-15 15:23:30 --> Security Class Initialized
DEBUG - 2020-09-15 15:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:23:30 --> Input Class Initialized
INFO - 2020-09-15 15:23:30 --> Language Class Initialized
INFO - 2020-09-15 15:23:30 --> Loader Class Initialized
INFO - 2020-09-15 15:23:30 --> Helper loaded: url_helper
INFO - 2020-09-15 15:23:30 --> Database Driver Class Initialized
INFO - 2020-09-15 15:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:23:30 --> Email Class Initialized
INFO - 2020-09-15 15:23:30 --> Controller Class Initialized
INFO - 2020-09-15 15:23:30 --> Model Class Initialized
INFO - 2020-09-15 15:23:30 --> Model Class Initialized
INFO - 2020-09-15 15:23:30 --> Final output sent to browser
DEBUG - 2020-09-15 15:23:30 --> Total execution time: 0.0412
ERROR - 2020-09-15 15:23:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:23:33 --> Config Class Initialized
INFO - 2020-09-15 15:23:33 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:23:33 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:23:33 --> Utf8 Class Initialized
INFO - 2020-09-15 15:23:33 --> URI Class Initialized
INFO - 2020-09-15 15:23:33 --> Router Class Initialized
INFO - 2020-09-15 15:23:33 --> Output Class Initialized
INFO - 2020-09-15 15:23:33 --> Security Class Initialized
DEBUG - 2020-09-15 15:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:23:33 --> Input Class Initialized
INFO - 2020-09-15 15:23:33 --> Language Class Initialized
INFO - 2020-09-15 15:23:33 --> Loader Class Initialized
INFO - 2020-09-15 15:23:33 --> Helper loaded: url_helper
INFO - 2020-09-15 15:23:33 --> Database Driver Class Initialized
INFO - 2020-09-15 15:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:23:33 --> Email Class Initialized
INFO - 2020-09-15 15:23:33 --> Controller Class Initialized
INFO - 2020-09-15 15:23:33 --> Model Class Initialized
INFO - 2020-09-15 15:23:33 --> Model Class Initialized
INFO - 2020-09-15 15:23:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:23:34 --> Final output sent to browser
DEBUG - 2020-09-15 15:23:34 --> Total execution time: 0.1140
ERROR - 2020-09-15 15:23:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:23:34 --> Config Class Initialized
INFO - 2020-09-15 15:23:34 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:23:34 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:23:34 --> Utf8 Class Initialized
INFO - 2020-09-15 15:23:34 --> URI Class Initialized
INFO - 2020-09-15 15:23:34 --> Router Class Initialized
INFO - 2020-09-15 15:23:34 --> Output Class Initialized
INFO - 2020-09-15 15:23:34 --> Security Class Initialized
DEBUG - 2020-09-15 15:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:23:34 --> Input Class Initialized
INFO - 2020-09-15 15:23:34 --> Language Class Initialized
INFO - 2020-09-15 15:23:34 --> Loader Class Initialized
INFO - 2020-09-15 15:23:34 --> Helper loaded: url_helper
INFO - 2020-09-15 15:23:34 --> Database Driver Class Initialized
INFO - 2020-09-15 15:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:23:34 --> Email Class Initialized
INFO - 2020-09-15 15:23:34 --> Controller Class Initialized
INFO - 2020-09-15 15:23:34 --> Model Class Initialized
INFO - 2020-09-15 15:23:34 --> Model Class Initialized
INFO - 2020-09-15 15:23:34 --> Final output sent to browser
DEBUG - 2020-09-15 15:23:34 --> Total execution time: 0.0427
ERROR - 2020-09-15 15:24:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:24:05 --> Config Class Initialized
INFO - 2020-09-15 15:24:05 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:24:05 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:24:05 --> Utf8 Class Initialized
INFO - 2020-09-15 15:24:05 --> URI Class Initialized
INFO - 2020-09-15 15:24:05 --> Router Class Initialized
INFO - 2020-09-15 15:24:05 --> Output Class Initialized
INFO - 2020-09-15 15:24:05 --> Security Class Initialized
DEBUG - 2020-09-15 15:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:24:05 --> Input Class Initialized
INFO - 2020-09-15 15:24:05 --> Language Class Initialized
INFO - 2020-09-15 15:24:05 --> Loader Class Initialized
INFO - 2020-09-15 15:24:05 --> Helper loaded: url_helper
INFO - 2020-09-15 15:24:05 --> Database Driver Class Initialized
INFO - 2020-09-15 15:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:24:05 --> Email Class Initialized
INFO - 2020-09-15 15:24:05 --> Controller Class Initialized
INFO - 2020-09-15 15:24:05 --> Model Class Initialized
INFO - 2020-09-15 15:24:05 --> Model Class Initialized
INFO - 2020-09-15 15:24:05 --> Final output sent to browser
DEBUG - 2020-09-15 15:24:05 --> Total execution time: 0.1234
ERROR - 2020-09-15 15:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:24:06 --> Config Class Initialized
INFO - 2020-09-15 15:24:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:24:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:24:06 --> Utf8 Class Initialized
INFO - 2020-09-15 15:24:06 --> URI Class Initialized
INFO - 2020-09-15 15:24:06 --> Router Class Initialized
INFO - 2020-09-15 15:24:06 --> Output Class Initialized
INFO - 2020-09-15 15:24:06 --> Security Class Initialized
DEBUG - 2020-09-15 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:24:06 --> Input Class Initialized
INFO - 2020-09-15 15:24:06 --> Language Class Initialized
INFO - 2020-09-15 15:24:06 --> Loader Class Initialized
INFO - 2020-09-15 15:24:06 --> Helper loaded: url_helper
INFO - 2020-09-15 15:24:06 --> Database Driver Class Initialized
INFO - 2020-09-15 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:24:06 --> Email Class Initialized
INFO - 2020-09-15 15:24:06 --> Controller Class Initialized
INFO - 2020-09-15 15:24:06 --> Model Class Initialized
INFO - 2020-09-15 15:24:06 --> Model Class Initialized
INFO - 2020-09-15 15:24:06 --> Final output sent to browser
DEBUG - 2020-09-15 15:24:06 --> Total execution time: 0.0383
ERROR - 2020-09-15 15:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:25:36 --> Config Class Initialized
INFO - 2020-09-15 15:25:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:25:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:25:36 --> Utf8 Class Initialized
INFO - 2020-09-15 15:25:36 --> URI Class Initialized
INFO - 2020-09-15 15:25:36 --> Router Class Initialized
INFO - 2020-09-15 15:25:36 --> Output Class Initialized
INFO - 2020-09-15 15:25:36 --> Security Class Initialized
DEBUG - 2020-09-15 15:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:25:36 --> Input Class Initialized
INFO - 2020-09-15 15:25:36 --> Language Class Initialized
INFO - 2020-09-15 15:25:36 --> Loader Class Initialized
INFO - 2020-09-15 15:25:36 --> Helper loaded: url_helper
INFO - 2020-09-15 15:25:36 --> Database Driver Class Initialized
INFO - 2020-09-15 15:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:25:36 --> Email Class Initialized
INFO - 2020-09-15 15:25:36 --> Controller Class Initialized
INFO - 2020-09-15 15:25:36 --> Model Class Initialized
INFO - 2020-09-15 15:25:36 --> Model Class Initialized
INFO - 2020-09-15 15:25:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:25:36 --> Final output sent to browser
DEBUG - 2020-09-15 15:25:36 --> Total execution time: 0.0396
ERROR - 2020-09-15 15:25:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:25:36 --> Config Class Initialized
INFO - 2020-09-15 15:25:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:25:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:25:36 --> Utf8 Class Initialized
INFO - 2020-09-15 15:25:36 --> URI Class Initialized
INFO - 2020-09-15 15:25:36 --> Router Class Initialized
INFO - 2020-09-15 15:25:36 --> Output Class Initialized
INFO - 2020-09-15 15:25:36 --> Security Class Initialized
DEBUG - 2020-09-15 15:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:25:36 --> Input Class Initialized
INFO - 2020-09-15 15:25:36 --> Language Class Initialized
INFO - 2020-09-15 15:25:36 --> Loader Class Initialized
INFO - 2020-09-15 15:25:36 --> Helper loaded: url_helper
INFO - 2020-09-15 15:25:36 --> Database Driver Class Initialized
INFO - 2020-09-15 15:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:25:36 --> Email Class Initialized
INFO - 2020-09-15 15:25:36 --> Controller Class Initialized
INFO - 2020-09-15 15:25:36 --> Model Class Initialized
INFO - 2020-09-15 15:25:36 --> Model Class Initialized
INFO - 2020-09-15 15:25:36 --> Final output sent to browser
DEBUG - 2020-09-15 15:25:36 --> Total execution time: 0.0413
ERROR - 2020-09-15 15:25:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:25:47 --> Config Class Initialized
INFO - 2020-09-15 15:25:47 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:25:47 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:25:47 --> Utf8 Class Initialized
INFO - 2020-09-15 15:25:47 --> URI Class Initialized
INFO - 2020-09-15 15:25:47 --> Router Class Initialized
INFO - 2020-09-15 15:25:47 --> Output Class Initialized
INFO - 2020-09-15 15:25:47 --> Security Class Initialized
DEBUG - 2020-09-15 15:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:25:47 --> Input Class Initialized
INFO - 2020-09-15 15:25:47 --> Language Class Initialized
INFO - 2020-09-15 15:25:47 --> Loader Class Initialized
INFO - 2020-09-15 15:25:47 --> Helper loaded: url_helper
INFO - 2020-09-15 15:25:47 --> Database Driver Class Initialized
INFO - 2020-09-15 15:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:25:47 --> Email Class Initialized
INFO - 2020-09-15 15:25:47 --> Controller Class Initialized
INFO - 2020-09-15 15:25:47 --> Model Class Initialized
INFO - 2020-09-15 15:25:47 --> Model Class Initialized
INFO - 2020-09-15 15:25:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:25:47 --> Final output sent to browser
DEBUG - 2020-09-15 15:25:47 --> Total execution time: 0.0423
ERROR - 2020-09-15 15:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:25:49 --> Config Class Initialized
INFO - 2020-09-15 15:25:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:25:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:25:49 --> Utf8 Class Initialized
INFO - 2020-09-15 15:25:49 --> URI Class Initialized
INFO - 2020-09-15 15:25:49 --> Router Class Initialized
INFO - 2020-09-15 15:25:49 --> Output Class Initialized
INFO - 2020-09-15 15:25:49 --> Security Class Initialized
DEBUG - 2020-09-15 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:25:49 --> Input Class Initialized
INFO - 2020-09-15 15:25:49 --> Language Class Initialized
INFO - 2020-09-15 15:25:49 --> Loader Class Initialized
INFO - 2020-09-15 15:25:49 --> Helper loaded: url_helper
INFO - 2020-09-15 15:25:49 --> Database Driver Class Initialized
INFO - 2020-09-15 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:25:49 --> Email Class Initialized
INFO - 2020-09-15 15:25:49 --> Controller Class Initialized
INFO - 2020-09-15 15:25:49 --> Model Class Initialized
INFO - 2020-09-15 15:25:49 --> Model Class Initialized
INFO - 2020-09-15 15:25:49 --> Model Class Initialized
INFO - 2020-09-15 15:25:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:25:49 --> Final output sent to browser
DEBUG - 2020-09-15 15:25:49 --> Total execution time: 0.0472
ERROR - 2020-09-15 15:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:25:49 --> Config Class Initialized
INFO - 2020-09-15 15:25:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:25:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:25:49 --> Utf8 Class Initialized
INFO - 2020-09-15 15:25:49 --> URI Class Initialized
INFO - 2020-09-15 15:25:49 --> Router Class Initialized
INFO - 2020-09-15 15:25:49 --> Output Class Initialized
INFO - 2020-09-15 15:25:49 --> Security Class Initialized
DEBUG - 2020-09-15 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:25:49 --> Input Class Initialized
INFO - 2020-09-15 15:25:49 --> Language Class Initialized
INFO - 2020-09-15 15:25:49 --> Loader Class Initialized
INFO - 2020-09-15 15:25:49 --> Helper loaded: url_helper
INFO - 2020-09-15 15:25:49 --> Database Driver Class Initialized
INFO - 2020-09-15 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:25:49 --> Email Class Initialized
INFO - 2020-09-15 15:25:49 --> Controller Class Initialized
INFO - 2020-09-15 15:25:49 --> Model Class Initialized
INFO - 2020-09-15 15:25:49 --> Model Class Initialized
INFO - 2020-09-15 15:25:50 --> Final output sent to browser
DEBUG - 2020-09-15 15:25:50 --> Total execution time: 0.0460
ERROR - 2020-09-15 15:26:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:26:02 --> Config Class Initialized
INFO - 2020-09-15 15:26:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:26:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:26:02 --> Utf8 Class Initialized
INFO - 2020-09-15 15:26:02 --> URI Class Initialized
INFO - 2020-09-15 15:26:02 --> Router Class Initialized
INFO - 2020-09-15 15:26:02 --> Output Class Initialized
INFO - 2020-09-15 15:26:02 --> Security Class Initialized
DEBUG - 2020-09-15 15:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:26:02 --> Input Class Initialized
INFO - 2020-09-15 15:26:02 --> Language Class Initialized
INFO - 2020-09-15 15:26:02 --> Loader Class Initialized
INFO - 2020-09-15 15:26:02 --> Helper loaded: url_helper
INFO - 2020-09-15 15:26:02 --> Database Driver Class Initialized
INFO - 2020-09-15 15:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:26:02 --> Email Class Initialized
INFO - 2020-09-15 15:26:02 --> Controller Class Initialized
INFO - 2020-09-15 15:26:02 --> Model Class Initialized
INFO - 2020-09-15 15:26:02 --> Model Class Initialized
INFO - 2020-09-15 15:26:02 --> Model Class Initialized
ERROR - 2020-09-15 15:26:02 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.excel_data_insert; expected 1, got 0 - Invalid query: CALL excel_data_insert()
INFO - 2020-09-15 15:26:02 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 15:26:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Excel_import.php:189) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-15 15:27:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:27:28 --> Config Class Initialized
INFO - 2020-09-15 15:27:28 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:27:28 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:27:28 --> Utf8 Class Initialized
INFO - 2020-09-15 15:27:28 --> URI Class Initialized
INFO - 2020-09-15 15:27:28 --> Router Class Initialized
INFO - 2020-09-15 15:27:28 --> Output Class Initialized
INFO - 2020-09-15 15:27:28 --> Security Class Initialized
DEBUG - 2020-09-15 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:27:28 --> Input Class Initialized
INFO - 2020-09-15 15:27:28 --> Language Class Initialized
INFO - 2020-09-15 15:27:28 --> Loader Class Initialized
INFO - 2020-09-15 15:27:28 --> Helper loaded: url_helper
INFO - 2020-09-15 15:27:28 --> Database Driver Class Initialized
INFO - 2020-09-15 15:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:27:28 --> Email Class Initialized
INFO - 2020-09-15 15:27:28 --> Controller Class Initialized
INFO - 2020-09-15 15:27:28 --> Model Class Initialized
INFO - 2020-09-15 15:27:28 --> Model Class Initialized
INFO - 2020-09-15 15:27:28 --> Model Class Initialized
INFO - 2020-09-15 15:27:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:27:28 --> Final output sent to browser
DEBUG - 2020-09-15 15:27:28 --> Total execution time: 0.0461
ERROR - 2020-09-15 15:27:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:27:29 --> Config Class Initialized
INFO - 2020-09-15 15:27:29 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:27:29 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:27:29 --> Utf8 Class Initialized
INFO - 2020-09-15 15:27:29 --> URI Class Initialized
INFO - 2020-09-15 15:27:29 --> Router Class Initialized
INFO - 2020-09-15 15:27:29 --> Output Class Initialized
INFO - 2020-09-15 15:27:29 --> Security Class Initialized
DEBUG - 2020-09-15 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:27:29 --> Input Class Initialized
INFO - 2020-09-15 15:27:29 --> Language Class Initialized
INFO - 2020-09-15 15:27:29 --> Loader Class Initialized
INFO - 2020-09-15 15:27:29 --> Helper loaded: url_helper
INFO - 2020-09-15 15:27:29 --> Database Driver Class Initialized
INFO - 2020-09-15 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:27:29 --> Email Class Initialized
INFO - 2020-09-15 15:27:29 --> Controller Class Initialized
INFO - 2020-09-15 15:27:29 --> Model Class Initialized
INFO - 2020-09-15 15:27:29 --> Model Class Initialized
INFO - 2020-09-15 15:27:29 --> Final output sent to browser
DEBUG - 2020-09-15 15:27:29 --> Total execution time: 0.0434
ERROR - 2020-09-15 15:27:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:27:31 --> Config Class Initialized
INFO - 2020-09-15 15:27:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:27:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:27:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:27:31 --> URI Class Initialized
INFO - 2020-09-15 15:27:31 --> Router Class Initialized
INFO - 2020-09-15 15:27:31 --> Output Class Initialized
INFO - 2020-09-15 15:27:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:27:31 --> Input Class Initialized
INFO - 2020-09-15 15:27:31 --> Language Class Initialized
INFO - 2020-09-15 15:27:31 --> Loader Class Initialized
INFO - 2020-09-15 15:27:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:27:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:27:31 --> Email Class Initialized
INFO - 2020-09-15 15:27:31 --> Controller Class Initialized
INFO - 2020-09-15 15:27:31 --> Model Class Initialized
INFO - 2020-09-15 15:27:31 --> Model Class Initialized
INFO - 2020-09-15 15:27:31 --> Model Class Initialized
INFO - 2020-09-15 15:27:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:27:31 --> Final output sent to browser
DEBUG - 2020-09-15 15:27:31 --> Total execution time: 0.0387
ERROR - 2020-09-15 15:27:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:27:31 --> Config Class Initialized
INFO - 2020-09-15 15:27:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:27:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:27:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:27:31 --> URI Class Initialized
INFO - 2020-09-15 15:27:31 --> Router Class Initialized
INFO - 2020-09-15 15:27:31 --> Output Class Initialized
INFO - 2020-09-15 15:27:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:27:31 --> Input Class Initialized
INFO - 2020-09-15 15:27:31 --> Language Class Initialized
INFO - 2020-09-15 15:27:31 --> Loader Class Initialized
INFO - 2020-09-15 15:27:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:27:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:27:31 --> Email Class Initialized
INFO - 2020-09-15 15:27:31 --> Controller Class Initialized
INFO - 2020-09-15 15:27:31 --> Model Class Initialized
INFO - 2020-09-15 15:27:31 --> Model Class Initialized
INFO - 2020-09-15 15:27:31 --> Final output sent to browser
DEBUG - 2020-09-15 15:27:31 --> Total execution time: 0.0405
ERROR - 2020-09-15 15:27:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:27:38 --> Config Class Initialized
INFO - 2020-09-15 15:27:38 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:27:38 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:27:38 --> Utf8 Class Initialized
INFO - 2020-09-15 15:27:38 --> URI Class Initialized
INFO - 2020-09-15 15:27:38 --> Router Class Initialized
INFO - 2020-09-15 15:27:38 --> Output Class Initialized
INFO - 2020-09-15 15:27:38 --> Security Class Initialized
DEBUG - 2020-09-15 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:27:38 --> Input Class Initialized
INFO - 2020-09-15 15:27:38 --> Language Class Initialized
INFO - 2020-09-15 15:27:38 --> Loader Class Initialized
INFO - 2020-09-15 15:27:38 --> Helper loaded: url_helper
INFO - 2020-09-15 15:27:38 --> Database Driver Class Initialized
INFO - 2020-09-15 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:27:38 --> Email Class Initialized
INFO - 2020-09-15 15:27:38 --> Controller Class Initialized
INFO - 2020-09-15 15:27:38 --> Model Class Initialized
INFO - 2020-09-15 15:27:38 --> Model Class Initialized
INFO - 2020-09-15 15:27:38 --> Model Class Initialized
ERROR - 2020-09-15 15:27:38 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.excel_data_insert; expected 1, got 0 - Invalid query: CALL excel_data_insert()
INFO - 2020-09-15 15:27:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 15:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Excel_import.php:189) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-09-15 15:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:29:28 --> Config Class Initialized
INFO - 2020-09-15 15:29:28 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:29:28 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:29:28 --> Utf8 Class Initialized
INFO - 2020-09-15 15:29:28 --> URI Class Initialized
INFO - 2020-09-15 15:29:28 --> Router Class Initialized
INFO - 2020-09-15 15:29:28 --> Output Class Initialized
INFO - 2020-09-15 15:29:28 --> Security Class Initialized
DEBUG - 2020-09-15 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:29:28 --> Input Class Initialized
INFO - 2020-09-15 15:29:28 --> Language Class Initialized
INFO - 2020-09-15 15:29:28 --> Loader Class Initialized
INFO - 2020-09-15 15:29:28 --> Helper loaded: url_helper
INFO - 2020-09-15 15:29:28 --> Database Driver Class Initialized
INFO - 2020-09-15 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:29:28 --> Email Class Initialized
INFO - 2020-09-15 15:29:28 --> Controller Class Initialized
INFO - 2020-09-15 15:29:28 --> Model Class Initialized
INFO - 2020-09-15 15:29:28 --> Model Class Initialized
INFO - 2020-09-15 15:29:28 --> Model Class Initialized
INFO - 2020-09-15 15:29:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:29:28 --> Final output sent to browser
DEBUG - 2020-09-15 15:29:28 --> Total execution time: 0.0419
ERROR - 2020-09-15 15:29:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:29:28 --> Config Class Initialized
INFO - 2020-09-15 15:29:28 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:29:28 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:29:28 --> Utf8 Class Initialized
INFO - 2020-09-15 15:29:28 --> URI Class Initialized
INFO - 2020-09-15 15:29:28 --> Router Class Initialized
INFO - 2020-09-15 15:29:28 --> Output Class Initialized
INFO - 2020-09-15 15:29:28 --> Security Class Initialized
DEBUG - 2020-09-15 15:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:29:28 --> Input Class Initialized
INFO - 2020-09-15 15:29:28 --> Language Class Initialized
INFO - 2020-09-15 15:29:28 --> Loader Class Initialized
INFO - 2020-09-15 15:29:28 --> Helper loaded: url_helper
INFO - 2020-09-15 15:29:28 --> Database Driver Class Initialized
INFO - 2020-09-15 15:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:29:28 --> Email Class Initialized
INFO - 2020-09-15 15:29:28 --> Controller Class Initialized
INFO - 2020-09-15 15:29:28 --> Model Class Initialized
INFO - 2020-09-15 15:29:28 --> Model Class Initialized
INFO - 2020-09-15 15:29:28 --> Final output sent to browser
DEBUG - 2020-09-15 15:29:28 --> Total execution time: 0.0410
ERROR - 2020-09-15 15:39:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:39:58 --> Config Class Initialized
INFO - 2020-09-15 15:39:58 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:39:58 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:39:58 --> Utf8 Class Initialized
INFO - 2020-09-15 15:39:58 --> URI Class Initialized
INFO - 2020-09-15 15:39:58 --> Router Class Initialized
INFO - 2020-09-15 15:39:58 --> Output Class Initialized
INFO - 2020-09-15 15:39:58 --> Security Class Initialized
DEBUG - 2020-09-15 15:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:39:58 --> Input Class Initialized
INFO - 2020-09-15 15:39:58 --> Language Class Initialized
INFO - 2020-09-15 15:39:58 --> Loader Class Initialized
INFO - 2020-09-15 15:39:58 --> Helper loaded: url_helper
INFO - 2020-09-15 15:39:58 --> Database Driver Class Initialized
INFO - 2020-09-15 15:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:39:58 --> Email Class Initialized
INFO - 2020-09-15 15:39:58 --> Controller Class Initialized
INFO - 2020-09-15 15:39:58 --> Model Class Initialized
INFO - 2020-09-15 15:39:58 --> Model Class Initialized
INFO - 2020-09-15 15:39:58 --> Model Class Initialized
INFO - 2020-09-15 15:39:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:39:58 --> Final output sent to browser
DEBUG - 2020-09-15 15:39:58 --> Total execution time: 0.1469
ERROR - 2020-09-15 15:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:39:59 --> Config Class Initialized
INFO - 2020-09-15 15:39:59 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:39:59 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:39:59 --> Utf8 Class Initialized
INFO - 2020-09-15 15:39:59 --> URI Class Initialized
INFO - 2020-09-15 15:39:59 --> Router Class Initialized
INFO - 2020-09-15 15:39:59 --> Output Class Initialized
INFO - 2020-09-15 15:39:59 --> Security Class Initialized
DEBUG - 2020-09-15 15:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:39:59 --> Input Class Initialized
INFO - 2020-09-15 15:39:59 --> Language Class Initialized
INFO - 2020-09-15 15:39:59 --> Loader Class Initialized
INFO - 2020-09-15 15:39:59 --> Helper loaded: url_helper
INFO - 2020-09-15 15:39:59 --> Database Driver Class Initialized
INFO - 2020-09-15 15:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:39:59 --> Email Class Initialized
INFO - 2020-09-15 15:39:59 --> Controller Class Initialized
INFO - 2020-09-15 15:39:59 --> Model Class Initialized
INFO - 2020-09-15 15:39:59 --> Model Class Initialized
INFO - 2020-09-15 15:39:59 --> Final output sent to browser
DEBUG - 2020-09-15 15:39:59 --> Total execution time: 0.0579
ERROR - 2020-09-15 15:40:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:09 --> Config Class Initialized
INFO - 2020-09-15 15:40:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:09 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:09 --> URI Class Initialized
INFO - 2020-09-15 15:40:09 --> Router Class Initialized
INFO - 2020-09-15 15:40:09 --> Output Class Initialized
INFO - 2020-09-15 15:40:09 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:09 --> Input Class Initialized
INFO - 2020-09-15 15:40:09 --> Language Class Initialized
INFO - 2020-09-15 15:40:09 --> Loader Class Initialized
INFO - 2020-09-15 15:40:09 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:09 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:09 --> Email Class Initialized
INFO - 2020-09-15 15:40:09 --> Controller Class Initialized
INFO - 2020-09-15 15:40:09 --> Model Class Initialized
INFO - 2020-09-15 15:40:09 --> Model Class Initialized
INFO - 2020-09-15 15:40:09 --> Model Class Initialized
INFO - 2020-09-15 15:40:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:40:09 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:09 --> Total execution time: 0.0415
ERROR - 2020-09-15 15:40:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:10 --> Config Class Initialized
INFO - 2020-09-15 15:40:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:10 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:10 --> URI Class Initialized
INFO - 2020-09-15 15:40:10 --> Router Class Initialized
INFO - 2020-09-15 15:40:10 --> Output Class Initialized
INFO - 2020-09-15 15:40:10 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:10 --> Input Class Initialized
INFO - 2020-09-15 15:40:10 --> Language Class Initialized
INFO - 2020-09-15 15:40:10 --> Loader Class Initialized
INFO - 2020-09-15 15:40:10 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:10 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:10 --> Email Class Initialized
INFO - 2020-09-15 15:40:10 --> Controller Class Initialized
INFO - 2020-09-15 15:40:10 --> Model Class Initialized
INFO - 2020-09-15 15:40:10 --> Model Class Initialized
INFO - 2020-09-15 15:40:10 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:10 --> Total execution time: 0.0345
ERROR - 2020-09-15 15:40:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:30 --> Config Class Initialized
INFO - 2020-09-15 15:40:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:30 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:30 --> URI Class Initialized
INFO - 2020-09-15 15:40:30 --> Router Class Initialized
INFO - 2020-09-15 15:40:30 --> Output Class Initialized
INFO - 2020-09-15 15:40:30 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:30 --> Input Class Initialized
INFO - 2020-09-15 15:40:30 --> Language Class Initialized
INFO - 2020-09-15 15:40:30 --> Loader Class Initialized
INFO - 2020-09-15 15:40:30 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:30 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:30 --> Email Class Initialized
INFO - 2020-09-15 15:40:30 --> Controller Class Initialized
INFO - 2020-09-15 15:40:30 --> Model Class Initialized
INFO - 2020-09-15 15:40:30 --> Model Class Initialized
INFO - 2020-09-15 15:40:30 --> Model Class Initialized
INFO - 2020-09-15 15:40:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:40:30 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:30 --> Total execution time: 0.0398
ERROR - 2020-09-15 15:40:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:31 --> Config Class Initialized
INFO - 2020-09-15 15:40:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:31 --> URI Class Initialized
INFO - 2020-09-15 15:40:31 --> Router Class Initialized
INFO - 2020-09-15 15:40:31 --> Output Class Initialized
INFO - 2020-09-15 15:40:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:31 --> Input Class Initialized
INFO - 2020-09-15 15:40:31 --> Language Class Initialized
INFO - 2020-09-15 15:40:31 --> Loader Class Initialized
INFO - 2020-09-15 15:40:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:31 --> Email Class Initialized
INFO - 2020-09-15 15:40:31 --> Controller Class Initialized
INFO - 2020-09-15 15:40:31 --> Model Class Initialized
INFO - 2020-09-15 15:40:31 --> Model Class Initialized
INFO - 2020-09-15 15:40:31 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:31 --> Total execution time: 0.0387
ERROR - 2020-09-15 15:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:39 --> Config Class Initialized
INFO - 2020-09-15 15:40:39 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:39 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:39 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:39 --> URI Class Initialized
INFO - 2020-09-15 15:40:39 --> Router Class Initialized
INFO - 2020-09-15 15:40:39 --> Output Class Initialized
INFO - 2020-09-15 15:40:39 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:39 --> Input Class Initialized
INFO - 2020-09-15 15:40:39 --> Language Class Initialized
INFO - 2020-09-15 15:40:39 --> Loader Class Initialized
INFO - 2020-09-15 15:40:39 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:39 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:39 --> Email Class Initialized
INFO - 2020-09-15 15:40:39 --> Controller Class Initialized
INFO - 2020-09-15 15:40:39 --> Model Class Initialized
INFO - 2020-09-15 15:40:39 --> Model Class Initialized
INFO - 2020-09-15 15:40:39 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:39 --> Total execution time: 0.1460
ERROR - 2020-09-15 15:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:39 --> Config Class Initialized
INFO - 2020-09-15 15:40:39 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:39 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:39 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:39 --> URI Class Initialized
INFO - 2020-09-15 15:40:39 --> Router Class Initialized
INFO - 2020-09-15 15:40:39 --> Output Class Initialized
INFO - 2020-09-15 15:40:39 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:39 --> Input Class Initialized
INFO - 2020-09-15 15:40:39 --> Language Class Initialized
INFO - 2020-09-15 15:40:39 --> Loader Class Initialized
INFO - 2020-09-15 15:40:39 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:39 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:39 --> Email Class Initialized
INFO - 2020-09-15 15:40:39 --> Controller Class Initialized
INFO - 2020-09-15 15:40:39 --> Model Class Initialized
INFO - 2020-09-15 15:40:39 --> Model Class Initialized
INFO - 2020-09-15 15:40:39 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:39 --> Total execution time: 0.0439
ERROR - 2020-09-15 15:40:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:40:43 --> Config Class Initialized
INFO - 2020-09-15 15:40:43 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:40:43 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:40:43 --> Utf8 Class Initialized
INFO - 2020-09-15 15:40:43 --> URI Class Initialized
INFO - 2020-09-15 15:40:43 --> Router Class Initialized
INFO - 2020-09-15 15:40:43 --> Output Class Initialized
INFO - 2020-09-15 15:40:43 --> Security Class Initialized
DEBUG - 2020-09-15 15:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:40:43 --> Input Class Initialized
INFO - 2020-09-15 15:40:43 --> Language Class Initialized
INFO - 2020-09-15 15:40:43 --> Loader Class Initialized
INFO - 2020-09-15 15:40:43 --> Helper loaded: url_helper
INFO - 2020-09-15 15:40:43 --> Database Driver Class Initialized
INFO - 2020-09-15 15:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:40:43 --> Email Class Initialized
INFO - 2020-09-15 15:40:43 --> Controller Class Initialized
INFO - 2020-09-15 15:40:43 --> Model Class Initialized
INFO - 2020-09-15 15:40:43 --> Model Class Initialized
INFO - 2020-09-15 15:40:43 --> Model Class Initialized
INFO - 2020-09-15 15:40:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:40:43 --> Final output sent to browser
DEBUG - 2020-09-15 15:40:43 --> Total execution time: 0.0551
ERROR - 2020-09-15 15:41:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:41:16 --> Config Class Initialized
INFO - 2020-09-15 15:41:16 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:41:16 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:41:16 --> Utf8 Class Initialized
INFO - 2020-09-15 15:41:16 --> URI Class Initialized
INFO - 2020-09-15 15:41:16 --> Router Class Initialized
INFO - 2020-09-15 15:41:16 --> Output Class Initialized
INFO - 2020-09-15 15:41:16 --> Security Class Initialized
DEBUG - 2020-09-15 15:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:41:16 --> Input Class Initialized
INFO - 2020-09-15 15:41:16 --> Language Class Initialized
INFO - 2020-09-15 15:41:16 --> Loader Class Initialized
INFO - 2020-09-15 15:41:16 --> Helper loaded: url_helper
INFO - 2020-09-15 15:41:16 --> Database Driver Class Initialized
INFO - 2020-09-15 15:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:41:16 --> Email Class Initialized
INFO - 2020-09-15 15:41:16 --> Controller Class Initialized
INFO - 2020-09-15 15:41:16 --> Model Class Initialized
INFO - 2020-09-15 15:41:16 --> Model Class Initialized
INFO - 2020-09-15 15:41:16 --> Model Class Initialized
INFO - 2020-09-15 15:41:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:41:16 --> Final output sent to browser
DEBUG - 2020-09-15 15:41:16 --> Total execution time: 0.0444
ERROR - 2020-09-15 15:41:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:41:25 --> Config Class Initialized
INFO - 2020-09-15 15:41:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:41:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:41:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:41:25 --> URI Class Initialized
INFO - 2020-09-15 15:41:25 --> Router Class Initialized
INFO - 2020-09-15 15:41:25 --> Output Class Initialized
INFO - 2020-09-15 15:41:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:41:25 --> Input Class Initialized
INFO - 2020-09-15 15:41:25 --> Language Class Initialized
INFO - 2020-09-15 15:41:25 --> Loader Class Initialized
INFO - 2020-09-15 15:41:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:41:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:41:25 --> Email Class Initialized
INFO - 2020-09-15 15:41:25 --> Controller Class Initialized
INFO - 2020-09-15 15:41:25 --> Model Class Initialized
INFO - 2020-09-15 15:41:25 --> Model Class Initialized
INFO - 2020-09-15 15:41:25 --> Model Class Initialized
INFO - 2020-09-15 15:41:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:41:25 --> Final output sent to browser
DEBUG - 2020-09-15 15:41:25 --> Total execution time: 0.1118
ERROR - 2020-09-15 15:41:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:41:46 --> Config Class Initialized
INFO - 2020-09-15 15:41:46 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:41:46 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:41:46 --> Utf8 Class Initialized
INFO - 2020-09-15 15:41:46 --> URI Class Initialized
INFO - 2020-09-15 15:41:46 --> Router Class Initialized
INFO - 2020-09-15 15:41:46 --> Output Class Initialized
INFO - 2020-09-15 15:41:46 --> Security Class Initialized
DEBUG - 2020-09-15 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:41:46 --> Input Class Initialized
INFO - 2020-09-15 15:41:46 --> Language Class Initialized
INFO - 2020-09-15 15:41:46 --> Loader Class Initialized
INFO - 2020-09-15 15:41:46 --> Helper loaded: url_helper
INFO - 2020-09-15 15:41:46 --> Database Driver Class Initialized
INFO - 2020-09-15 15:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:41:46 --> Email Class Initialized
INFO - 2020-09-15 15:41:46 --> Controller Class Initialized
INFO - 2020-09-15 15:41:46 --> Model Class Initialized
INFO - 2020-09-15 15:41:46 --> Model Class Initialized
INFO - 2020-09-15 15:41:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:41:46 --> Final output sent to browser
DEBUG - 2020-09-15 15:41:46 --> Total execution time: 0.0380
ERROR - 2020-09-15 15:41:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:41:47 --> Config Class Initialized
INFO - 2020-09-15 15:41:47 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:41:47 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:41:47 --> Utf8 Class Initialized
INFO - 2020-09-15 15:41:47 --> URI Class Initialized
INFO - 2020-09-15 15:41:47 --> Router Class Initialized
INFO - 2020-09-15 15:41:47 --> Output Class Initialized
INFO - 2020-09-15 15:41:47 --> Security Class Initialized
DEBUG - 2020-09-15 15:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:41:47 --> Input Class Initialized
INFO - 2020-09-15 15:41:47 --> Language Class Initialized
INFO - 2020-09-15 15:41:47 --> Loader Class Initialized
INFO - 2020-09-15 15:41:47 --> Helper loaded: url_helper
INFO - 2020-09-15 15:41:47 --> Database Driver Class Initialized
INFO - 2020-09-15 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:41:47 --> Email Class Initialized
INFO - 2020-09-15 15:41:47 --> Controller Class Initialized
INFO - 2020-09-15 15:41:47 --> Model Class Initialized
INFO - 2020-09-15 15:41:47 --> Model Class Initialized
INFO - 2020-09-15 15:41:47 --> Final output sent to browser
DEBUG - 2020-09-15 15:41:47 --> Total execution time: 0.0363
ERROR - 2020-09-15 15:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:43:14 --> Config Class Initialized
INFO - 2020-09-15 15:43:14 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:43:14 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:43:14 --> Utf8 Class Initialized
INFO - 2020-09-15 15:43:14 --> URI Class Initialized
INFO - 2020-09-15 15:43:14 --> Router Class Initialized
INFO - 2020-09-15 15:43:14 --> Output Class Initialized
INFO - 2020-09-15 15:43:14 --> Security Class Initialized
DEBUG - 2020-09-15 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:43:14 --> Input Class Initialized
INFO - 2020-09-15 15:43:14 --> Language Class Initialized
INFO - 2020-09-15 15:43:14 --> Loader Class Initialized
INFO - 2020-09-15 15:43:14 --> Helper loaded: url_helper
INFO - 2020-09-15 15:43:14 --> Database Driver Class Initialized
INFO - 2020-09-15 15:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:43:14 --> Email Class Initialized
INFO - 2020-09-15 15:43:14 --> Controller Class Initialized
INFO - 2020-09-15 15:43:14 --> Model Class Initialized
INFO - 2020-09-15 15:43:14 --> Model Class Initialized
INFO - 2020-09-15 15:43:14 --> Final output sent to browser
DEBUG - 2020-09-15 15:43:14 --> Total execution time: 0.1293
ERROR - 2020-09-15 15:43:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:43:14 --> Config Class Initialized
INFO - 2020-09-15 15:43:14 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:43:14 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:43:14 --> Utf8 Class Initialized
INFO - 2020-09-15 15:43:14 --> URI Class Initialized
INFO - 2020-09-15 15:43:14 --> Router Class Initialized
INFO - 2020-09-15 15:43:14 --> Output Class Initialized
INFO - 2020-09-15 15:43:14 --> Security Class Initialized
DEBUG - 2020-09-15 15:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:43:14 --> Input Class Initialized
INFO - 2020-09-15 15:43:14 --> Language Class Initialized
INFO - 2020-09-15 15:43:14 --> Loader Class Initialized
INFO - 2020-09-15 15:43:14 --> Helper loaded: url_helper
INFO - 2020-09-15 15:43:14 --> Database Driver Class Initialized
INFO - 2020-09-15 15:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:43:14 --> Email Class Initialized
INFO - 2020-09-15 15:43:14 --> Controller Class Initialized
INFO - 2020-09-15 15:43:14 --> Model Class Initialized
INFO - 2020-09-15 15:43:14 --> Model Class Initialized
INFO - 2020-09-15 15:43:14 --> Final output sent to browser
DEBUG - 2020-09-15 15:43:14 --> Total execution time: 0.0390
ERROR - 2020-09-15 15:43:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:43:18 --> Config Class Initialized
INFO - 2020-09-15 15:43:18 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:43:18 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:43:18 --> Utf8 Class Initialized
INFO - 2020-09-15 15:43:18 --> URI Class Initialized
INFO - 2020-09-15 15:43:18 --> Router Class Initialized
INFO - 2020-09-15 15:43:18 --> Output Class Initialized
INFO - 2020-09-15 15:43:18 --> Security Class Initialized
DEBUG - 2020-09-15 15:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:43:18 --> Input Class Initialized
INFO - 2020-09-15 15:43:18 --> Language Class Initialized
INFO - 2020-09-15 15:43:18 --> Loader Class Initialized
INFO - 2020-09-15 15:43:18 --> Helper loaded: url_helper
INFO - 2020-09-15 15:43:18 --> Database Driver Class Initialized
INFO - 2020-09-15 15:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:43:18 --> Email Class Initialized
INFO - 2020-09-15 15:43:18 --> Controller Class Initialized
INFO - 2020-09-15 15:43:18 --> Model Class Initialized
INFO - 2020-09-15 15:43:18 --> Model Class Initialized
INFO - 2020-09-15 15:43:18 --> Model Class Initialized
INFO - 2020-09-15 15:43:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:43:18 --> Final output sent to browser
DEBUG - 2020-09-15 15:43:18 --> Total execution time: 0.0414
ERROR - 2020-09-15 15:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:43:27 --> Config Class Initialized
INFO - 2020-09-15 15:43:27 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:43:27 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:43:27 --> Utf8 Class Initialized
INFO - 2020-09-15 15:43:27 --> URI Class Initialized
INFO - 2020-09-15 15:43:27 --> Router Class Initialized
INFO - 2020-09-15 15:43:27 --> Output Class Initialized
INFO - 2020-09-15 15:43:27 --> Security Class Initialized
DEBUG - 2020-09-15 15:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:43:27 --> Input Class Initialized
INFO - 2020-09-15 15:43:27 --> Language Class Initialized
INFO - 2020-09-15 15:43:27 --> Loader Class Initialized
INFO - 2020-09-15 15:43:27 --> Helper loaded: url_helper
INFO - 2020-09-15 15:43:27 --> Database Driver Class Initialized
INFO - 2020-09-15 15:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:43:27 --> Email Class Initialized
INFO - 2020-09-15 15:43:27 --> Controller Class Initialized
INFO - 2020-09-15 15:43:27 --> Model Class Initialized
INFO - 2020-09-15 15:43:27 --> Model Class Initialized
INFO - 2020-09-15 15:43:27 --> Model Class Initialized
INFO - 2020-09-15 15:43:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:43:27 --> Final output sent to browser
DEBUG - 2020-09-15 15:43:27 --> Total execution time: 0.0999
ERROR - 2020-09-15 15:43:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:43:27 --> Config Class Initialized
INFO - 2020-09-15 15:43:27 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:43:27 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:43:27 --> Utf8 Class Initialized
INFO - 2020-09-15 15:43:27 --> URI Class Initialized
INFO - 2020-09-15 15:43:27 --> Router Class Initialized
INFO - 2020-09-15 15:43:27 --> Output Class Initialized
INFO - 2020-09-15 15:43:27 --> Security Class Initialized
DEBUG - 2020-09-15 15:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:43:27 --> Input Class Initialized
INFO - 2020-09-15 15:43:27 --> Language Class Initialized
INFO - 2020-09-15 15:43:27 --> Loader Class Initialized
INFO - 2020-09-15 15:43:27 --> Helper loaded: url_helper
INFO - 2020-09-15 15:43:27 --> Database Driver Class Initialized
INFO - 2020-09-15 15:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:43:27 --> Email Class Initialized
INFO - 2020-09-15 15:43:27 --> Controller Class Initialized
INFO - 2020-09-15 15:43:27 --> Model Class Initialized
INFO - 2020-09-15 15:43:27 --> Model Class Initialized
INFO - 2020-09-15 15:43:27 --> Final output sent to browser
DEBUG - 2020-09-15 15:43:27 --> Total execution time: 0.0398
ERROR - 2020-09-15 15:44:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:44:30 --> Config Class Initialized
INFO - 2020-09-15 15:44:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:44:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:44:30 --> Utf8 Class Initialized
INFO - 2020-09-15 15:44:30 --> URI Class Initialized
INFO - 2020-09-15 15:44:30 --> Router Class Initialized
INFO - 2020-09-15 15:44:30 --> Output Class Initialized
INFO - 2020-09-15 15:44:30 --> Security Class Initialized
DEBUG - 2020-09-15 15:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:44:30 --> Input Class Initialized
INFO - 2020-09-15 15:44:30 --> Language Class Initialized
INFO - 2020-09-15 15:44:30 --> Loader Class Initialized
INFO - 2020-09-15 15:44:30 --> Helper loaded: url_helper
INFO - 2020-09-15 15:44:30 --> Database Driver Class Initialized
INFO - 2020-09-15 15:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:44:30 --> Email Class Initialized
INFO - 2020-09-15 15:44:30 --> Controller Class Initialized
INFO - 2020-09-15 15:44:30 --> Model Class Initialized
INFO - 2020-09-15 15:44:30 --> Model Class Initialized
INFO - 2020-09-15 15:44:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:44:30 --> Final output sent to browser
DEBUG - 2020-09-15 15:44:30 --> Total execution time: 0.0386
ERROR - 2020-09-15 15:44:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:44:31 --> Config Class Initialized
INFO - 2020-09-15 15:44:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:44:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:44:31 --> Utf8 Class Initialized
INFO - 2020-09-15 15:44:31 --> URI Class Initialized
INFO - 2020-09-15 15:44:31 --> Router Class Initialized
INFO - 2020-09-15 15:44:31 --> Output Class Initialized
INFO - 2020-09-15 15:44:31 --> Security Class Initialized
DEBUG - 2020-09-15 15:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:44:31 --> Input Class Initialized
INFO - 2020-09-15 15:44:31 --> Language Class Initialized
INFO - 2020-09-15 15:44:31 --> Loader Class Initialized
INFO - 2020-09-15 15:44:31 --> Helper loaded: url_helper
INFO - 2020-09-15 15:44:31 --> Database Driver Class Initialized
INFO - 2020-09-15 15:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:44:31 --> Email Class Initialized
INFO - 2020-09-15 15:44:31 --> Controller Class Initialized
INFO - 2020-09-15 15:44:31 --> Model Class Initialized
INFO - 2020-09-15 15:44:31 --> Model Class Initialized
INFO - 2020-09-15 15:44:31 --> Final output sent to browser
DEBUG - 2020-09-15 15:44:31 --> Total execution time: 0.0404
ERROR - 2020-09-15 15:44:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:44:32 --> Config Class Initialized
INFO - 2020-09-15 15:44:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:44:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:44:32 --> Utf8 Class Initialized
INFO - 2020-09-15 15:44:32 --> URI Class Initialized
INFO - 2020-09-15 15:44:32 --> Router Class Initialized
INFO - 2020-09-15 15:44:32 --> Output Class Initialized
INFO - 2020-09-15 15:44:32 --> Security Class Initialized
DEBUG - 2020-09-15 15:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:44:32 --> Input Class Initialized
INFO - 2020-09-15 15:44:32 --> Language Class Initialized
INFO - 2020-09-15 15:44:32 --> Loader Class Initialized
INFO - 2020-09-15 15:44:32 --> Helper loaded: url_helper
INFO - 2020-09-15 15:44:32 --> Database Driver Class Initialized
INFO - 2020-09-15 15:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:44:32 --> Email Class Initialized
INFO - 2020-09-15 15:44:32 --> Controller Class Initialized
INFO - 2020-09-15 15:44:32 --> Model Class Initialized
INFO - 2020-09-15 15:44:32 --> Model Class Initialized
INFO - 2020-09-15 15:44:32 --> Model Class Initialized
INFO - 2020-09-15 15:44:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:44:32 --> Final output sent to browser
DEBUG - 2020-09-15 15:44:32 --> Total execution time: 0.0465
ERROR - 2020-09-15 15:44:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:44:33 --> Config Class Initialized
INFO - 2020-09-15 15:44:33 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:44:33 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:44:33 --> Utf8 Class Initialized
INFO - 2020-09-15 15:44:33 --> URI Class Initialized
INFO - 2020-09-15 15:44:33 --> Router Class Initialized
INFO - 2020-09-15 15:44:33 --> Output Class Initialized
INFO - 2020-09-15 15:44:33 --> Security Class Initialized
DEBUG - 2020-09-15 15:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:44:33 --> Input Class Initialized
INFO - 2020-09-15 15:44:33 --> Language Class Initialized
INFO - 2020-09-15 15:44:33 --> Loader Class Initialized
INFO - 2020-09-15 15:44:33 --> Helper loaded: url_helper
INFO - 2020-09-15 15:44:33 --> Database Driver Class Initialized
INFO - 2020-09-15 15:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:44:33 --> Email Class Initialized
INFO - 2020-09-15 15:44:33 --> Controller Class Initialized
INFO - 2020-09-15 15:44:33 --> Model Class Initialized
INFO - 2020-09-15 15:44:33 --> Model Class Initialized
INFO - 2020-09-15 15:44:33 --> Final output sent to browser
DEBUG - 2020-09-15 15:44:33 --> Total execution time: 0.0416
ERROR - 2020-09-15 15:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:02 --> Config Class Initialized
INFO - 2020-09-15 15:45:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:02 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:02 --> URI Class Initialized
INFO - 2020-09-15 15:45:02 --> Router Class Initialized
INFO - 2020-09-15 15:45:02 --> Output Class Initialized
INFO - 2020-09-15 15:45:02 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:02 --> Input Class Initialized
INFO - 2020-09-15 15:45:02 --> Language Class Initialized
INFO - 2020-09-15 15:45:02 --> Loader Class Initialized
INFO - 2020-09-15 15:45:02 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:02 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:02 --> Email Class Initialized
INFO - 2020-09-15 15:45:02 --> Controller Class Initialized
INFO - 2020-09-15 15:45:02 --> Model Class Initialized
INFO - 2020-09-15 15:45:02 --> Model Class Initialized
INFO - 2020-09-15 15:45:02 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:02 --> Total execution time: 0.1489
ERROR - 2020-09-15 15:45:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:03 --> Config Class Initialized
INFO - 2020-09-15 15:45:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:03 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:03 --> URI Class Initialized
INFO - 2020-09-15 15:45:03 --> Router Class Initialized
INFO - 2020-09-15 15:45:03 --> Output Class Initialized
INFO - 2020-09-15 15:45:03 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:03 --> Input Class Initialized
INFO - 2020-09-15 15:45:03 --> Language Class Initialized
INFO - 2020-09-15 15:45:03 --> Loader Class Initialized
INFO - 2020-09-15 15:45:03 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:03 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:03 --> Email Class Initialized
INFO - 2020-09-15 15:45:03 --> Controller Class Initialized
INFO - 2020-09-15 15:45:03 --> Model Class Initialized
INFO - 2020-09-15 15:45:03 --> Model Class Initialized
INFO - 2020-09-15 15:45:03 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:03 --> Total execution time: 0.0387
ERROR - 2020-09-15 15:45:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:08 --> Config Class Initialized
INFO - 2020-09-15 15:45:08 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:08 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:08 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:08 --> URI Class Initialized
INFO - 2020-09-15 15:45:08 --> Router Class Initialized
INFO - 2020-09-15 15:45:08 --> Output Class Initialized
INFO - 2020-09-15 15:45:08 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:08 --> Input Class Initialized
INFO - 2020-09-15 15:45:08 --> Language Class Initialized
INFO - 2020-09-15 15:45:08 --> Loader Class Initialized
INFO - 2020-09-15 15:45:08 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:08 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:08 --> Email Class Initialized
INFO - 2020-09-15 15:45:08 --> Controller Class Initialized
INFO - 2020-09-15 15:45:08 --> Model Class Initialized
INFO - 2020-09-15 15:45:08 --> Model Class Initialized
INFO - 2020-09-15 15:45:08 --> Model Class Initialized
INFO - 2020-09-15 15:45:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:45:08 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:08 --> Total execution time: 0.0374
ERROR - 2020-09-15 15:45:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:10 --> Config Class Initialized
INFO - 2020-09-15 15:45:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:10 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:10 --> URI Class Initialized
INFO - 2020-09-15 15:45:10 --> Router Class Initialized
INFO - 2020-09-15 15:45:10 --> Output Class Initialized
INFO - 2020-09-15 15:45:10 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:10 --> Input Class Initialized
INFO - 2020-09-15 15:45:10 --> Language Class Initialized
INFO - 2020-09-15 15:45:10 --> Loader Class Initialized
INFO - 2020-09-15 15:45:10 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:10 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:10 --> Email Class Initialized
INFO - 2020-09-15 15:45:10 --> Controller Class Initialized
INFO - 2020-09-15 15:45:10 --> Model Class Initialized
INFO - 2020-09-15 15:45:10 --> Model Class Initialized
INFO - 2020-09-15 15:45:10 --> Model Class Initialized
INFO - 2020-09-15 15:45:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:45:10 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:10 --> Total execution time: 0.0421
ERROR - 2020-09-15 15:45:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:11 --> Config Class Initialized
INFO - 2020-09-15 15:45:11 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:11 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:11 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:11 --> URI Class Initialized
INFO - 2020-09-15 15:45:11 --> Router Class Initialized
INFO - 2020-09-15 15:45:11 --> Output Class Initialized
INFO - 2020-09-15 15:45:11 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:11 --> Input Class Initialized
INFO - 2020-09-15 15:45:11 --> Language Class Initialized
INFO - 2020-09-15 15:45:11 --> Loader Class Initialized
INFO - 2020-09-15 15:45:11 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:11 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:11 --> Email Class Initialized
INFO - 2020-09-15 15:45:11 --> Controller Class Initialized
INFO - 2020-09-15 15:45:11 --> Model Class Initialized
INFO - 2020-09-15 15:45:11 --> Model Class Initialized
INFO - 2020-09-15 15:45:11 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:11 --> Total execution time: 0.0405
ERROR - 2020-09-15 15:45:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:17 --> Config Class Initialized
INFO - 2020-09-15 15:45:17 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:17 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:17 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:17 --> URI Class Initialized
INFO - 2020-09-15 15:45:17 --> Router Class Initialized
INFO - 2020-09-15 15:45:17 --> Output Class Initialized
INFO - 2020-09-15 15:45:17 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:17 --> Input Class Initialized
INFO - 2020-09-15 15:45:17 --> Language Class Initialized
INFO - 2020-09-15 15:45:17 --> Loader Class Initialized
INFO - 2020-09-15 15:45:17 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:17 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:17 --> Email Class Initialized
INFO - 2020-09-15 15:45:17 --> Controller Class Initialized
INFO - 2020-09-15 15:45:17 --> Model Class Initialized
INFO - 2020-09-15 15:45:17 --> Model Class Initialized
INFO - 2020-09-15 15:45:17 --> Model Class Initialized
INFO - 2020-09-15 15:45:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:45:17 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:17 --> Total execution time: 0.1126
ERROR - 2020-09-15 15:45:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:45:18 --> Config Class Initialized
INFO - 2020-09-15 15:45:18 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:45:18 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:45:18 --> Utf8 Class Initialized
INFO - 2020-09-15 15:45:18 --> URI Class Initialized
INFO - 2020-09-15 15:45:18 --> Router Class Initialized
INFO - 2020-09-15 15:45:18 --> Output Class Initialized
INFO - 2020-09-15 15:45:18 --> Security Class Initialized
DEBUG - 2020-09-15 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:45:18 --> Input Class Initialized
INFO - 2020-09-15 15:45:18 --> Language Class Initialized
INFO - 2020-09-15 15:45:18 --> Loader Class Initialized
INFO - 2020-09-15 15:45:18 --> Helper loaded: url_helper
INFO - 2020-09-15 15:45:18 --> Database Driver Class Initialized
INFO - 2020-09-15 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:45:18 --> Email Class Initialized
INFO - 2020-09-15 15:45:18 --> Controller Class Initialized
INFO - 2020-09-15 15:45:18 --> Model Class Initialized
INFO - 2020-09-15 15:45:18 --> Model Class Initialized
INFO - 2020-09-15 15:45:18 --> Final output sent to browser
DEBUG - 2020-09-15 15:45:18 --> Total execution time: 0.0387
ERROR - 2020-09-15 15:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:47:27 --> Config Class Initialized
INFO - 2020-09-15 15:47:27 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:47:27 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:47:27 --> Utf8 Class Initialized
INFO - 2020-09-15 15:47:27 --> URI Class Initialized
INFO - 2020-09-15 15:47:27 --> Router Class Initialized
INFO - 2020-09-15 15:47:27 --> Output Class Initialized
INFO - 2020-09-15 15:47:27 --> Security Class Initialized
DEBUG - 2020-09-15 15:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:47:27 --> Input Class Initialized
INFO - 2020-09-15 15:47:27 --> Language Class Initialized
INFO - 2020-09-15 15:47:27 --> Loader Class Initialized
INFO - 2020-09-15 15:47:27 --> Helper loaded: url_helper
INFO - 2020-09-15 15:47:27 --> Database Driver Class Initialized
INFO - 2020-09-15 15:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:47:27 --> Email Class Initialized
INFO - 2020-09-15 15:47:27 --> Controller Class Initialized
INFO - 2020-09-15 15:47:27 --> Model Class Initialized
INFO - 2020-09-15 15:47:27 --> Model Class Initialized
INFO - 2020-09-15 15:47:27 --> Final output sent to browser
DEBUG - 2020-09-15 15:47:27 --> Total execution time: 0.1552
ERROR - 2020-09-15 15:47:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:47:27 --> Config Class Initialized
INFO - 2020-09-15 15:47:27 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:47:27 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:47:27 --> Utf8 Class Initialized
INFO - 2020-09-15 15:47:27 --> URI Class Initialized
INFO - 2020-09-15 15:47:27 --> Router Class Initialized
INFO - 2020-09-15 15:47:27 --> Output Class Initialized
INFO - 2020-09-15 15:47:27 --> Security Class Initialized
DEBUG - 2020-09-15 15:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:47:27 --> Input Class Initialized
INFO - 2020-09-15 15:47:27 --> Language Class Initialized
INFO - 2020-09-15 15:47:27 --> Loader Class Initialized
INFO - 2020-09-15 15:47:27 --> Helper loaded: url_helper
INFO - 2020-09-15 15:47:27 --> Database Driver Class Initialized
INFO - 2020-09-15 15:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:47:27 --> Email Class Initialized
INFO - 2020-09-15 15:47:27 --> Controller Class Initialized
INFO - 2020-09-15 15:47:27 --> Model Class Initialized
INFO - 2020-09-15 15:47:27 --> Model Class Initialized
INFO - 2020-09-15 15:47:27 --> Final output sent to browser
DEBUG - 2020-09-15 15:47:27 --> Total execution time: 0.0411
ERROR - 2020-09-15 15:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:47:30 --> Config Class Initialized
INFO - 2020-09-15 15:47:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:47:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:47:30 --> Utf8 Class Initialized
INFO - 2020-09-15 15:47:30 --> URI Class Initialized
INFO - 2020-09-15 15:47:30 --> Router Class Initialized
INFO - 2020-09-15 15:47:30 --> Output Class Initialized
INFO - 2020-09-15 15:47:30 --> Security Class Initialized
DEBUG - 2020-09-15 15:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:47:30 --> Input Class Initialized
INFO - 2020-09-15 15:47:30 --> Language Class Initialized
INFO - 2020-09-15 15:47:30 --> Loader Class Initialized
INFO - 2020-09-15 15:47:30 --> Helper loaded: url_helper
INFO - 2020-09-15 15:47:30 --> Database Driver Class Initialized
INFO - 2020-09-15 15:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:47:30 --> Email Class Initialized
INFO - 2020-09-15 15:47:30 --> Controller Class Initialized
INFO - 2020-09-15 15:47:30 --> Model Class Initialized
INFO - 2020-09-15 15:47:30 --> Model Class Initialized
INFO - 2020-09-15 15:47:30 --> Model Class Initialized
INFO - 2020-09-15 15:47:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:47:30 --> Final output sent to browser
DEBUG - 2020-09-15 15:47:30 --> Total execution time: 0.0514
ERROR - 2020-09-15 15:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:47:37 --> Config Class Initialized
INFO - 2020-09-15 15:47:37 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:47:37 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:47:37 --> Utf8 Class Initialized
INFO - 2020-09-15 15:47:37 --> URI Class Initialized
INFO - 2020-09-15 15:47:37 --> Router Class Initialized
INFO - 2020-09-15 15:47:37 --> Output Class Initialized
INFO - 2020-09-15 15:47:37 --> Security Class Initialized
DEBUG - 2020-09-15 15:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:47:37 --> Input Class Initialized
INFO - 2020-09-15 15:47:37 --> Language Class Initialized
INFO - 2020-09-15 15:47:37 --> Loader Class Initialized
INFO - 2020-09-15 15:47:37 --> Helper loaded: url_helper
INFO - 2020-09-15 15:47:37 --> Database Driver Class Initialized
INFO - 2020-09-15 15:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:47:37 --> Email Class Initialized
INFO - 2020-09-15 15:47:37 --> Controller Class Initialized
INFO - 2020-09-15 15:47:37 --> Model Class Initialized
INFO - 2020-09-15 15:47:37 --> Model Class Initialized
INFO - 2020-09-15 15:47:37 --> Model Class Initialized
INFO - 2020-09-15 15:47:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:47:37 --> Final output sent to browser
DEBUG - 2020-09-15 15:47:37 --> Total execution time: 0.0983
ERROR - 2020-09-15 15:47:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:47:37 --> Config Class Initialized
INFO - 2020-09-15 15:47:37 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:47:37 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:47:37 --> Utf8 Class Initialized
INFO - 2020-09-15 15:47:37 --> URI Class Initialized
INFO - 2020-09-15 15:47:37 --> Router Class Initialized
INFO - 2020-09-15 15:47:37 --> Output Class Initialized
INFO - 2020-09-15 15:47:37 --> Security Class Initialized
DEBUG - 2020-09-15 15:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:47:37 --> Input Class Initialized
INFO - 2020-09-15 15:47:37 --> Language Class Initialized
INFO - 2020-09-15 15:47:37 --> Loader Class Initialized
INFO - 2020-09-15 15:47:37 --> Helper loaded: url_helper
INFO - 2020-09-15 15:47:37 --> Database Driver Class Initialized
INFO - 2020-09-15 15:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:47:37 --> Email Class Initialized
INFO - 2020-09-15 15:47:37 --> Controller Class Initialized
INFO - 2020-09-15 15:47:37 --> Model Class Initialized
INFO - 2020-09-15 15:47:37 --> Model Class Initialized
INFO - 2020-09-15 15:47:37 --> Final output sent to browser
DEBUG - 2020-09-15 15:47:37 --> Total execution time: 0.0385
ERROR - 2020-09-15 15:49:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:49:36 --> Config Class Initialized
INFO - 2020-09-15 15:49:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:49:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:49:36 --> Utf8 Class Initialized
INFO - 2020-09-15 15:49:36 --> URI Class Initialized
INFO - 2020-09-15 15:49:36 --> Router Class Initialized
INFO - 2020-09-15 15:49:36 --> Output Class Initialized
INFO - 2020-09-15 15:49:36 --> Security Class Initialized
DEBUG - 2020-09-15 15:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:49:36 --> Input Class Initialized
INFO - 2020-09-15 15:49:36 --> Language Class Initialized
INFO - 2020-09-15 15:49:36 --> Loader Class Initialized
INFO - 2020-09-15 15:49:36 --> Helper loaded: url_helper
INFO - 2020-09-15 15:49:36 --> Database Driver Class Initialized
INFO - 2020-09-15 15:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:49:36 --> Email Class Initialized
INFO - 2020-09-15 15:49:36 --> Controller Class Initialized
INFO - 2020-09-15 15:49:36 --> Model Class Initialized
INFO - 2020-09-15 15:49:36 --> Model Class Initialized
INFO - 2020-09-15 15:49:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:49:36 --> Final output sent to browser
DEBUG - 2020-09-15 15:49:36 --> Total execution time: 0.0449
ERROR - 2020-09-15 15:49:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:49:37 --> Config Class Initialized
INFO - 2020-09-15 15:49:37 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:49:37 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:49:37 --> Utf8 Class Initialized
INFO - 2020-09-15 15:49:37 --> URI Class Initialized
INFO - 2020-09-15 15:49:37 --> Router Class Initialized
INFO - 2020-09-15 15:49:37 --> Output Class Initialized
INFO - 2020-09-15 15:49:37 --> Security Class Initialized
DEBUG - 2020-09-15 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:49:37 --> Input Class Initialized
INFO - 2020-09-15 15:49:37 --> Language Class Initialized
INFO - 2020-09-15 15:49:37 --> Loader Class Initialized
INFO - 2020-09-15 15:49:37 --> Helper loaded: url_helper
INFO - 2020-09-15 15:49:37 --> Database Driver Class Initialized
INFO - 2020-09-15 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:49:37 --> Email Class Initialized
INFO - 2020-09-15 15:49:37 --> Controller Class Initialized
INFO - 2020-09-15 15:49:37 --> Model Class Initialized
INFO - 2020-09-15 15:49:37 --> Model Class Initialized
INFO - 2020-09-15 15:49:37 --> Final output sent to browser
DEBUG - 2020-09-15 15:49:37 --> Total execution time: 0.0415
ERROR - 2020-09-15 15:49:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:49:51 --> Config Class Initialized
INFO - 2020-09-15 15:49:51 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:49:51 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:49:51 --> Utf8 Class Initialized
INFO - 2020-09-15 15:49:51 --> URI Class Initialized
INFO - 2020-09-15 15:49:51 --> Router Class Initialized
INFO - 2020-09-15 15:49:51 --> Output Class Initialized
INFO - 2020-09-15 15:49:51 --> Security Class Initialized
DEBUG - 2020-09-15 15:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:49:51 --> Input Class Initialized
INFO - 2020-09-15 15:49:51 --> Language Class Initialized
INFO - 2020-09-15 15:49:51 --> Loader Class Initialized
INFO - 2020-09-15 15:49:51 --> Helper loaded: url_helper
INFO - 2020-09-15 15:49:51 --> Database Driver Class Initialized
INFO - 2020-09-15 15:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:49:51 --> Email Class Initialized
INFO - 2020-09-15 15:49:51 --> Controller Class Initialized
INFO - 2020-09-15 15:49:51 --> Model Class Initialized
INFO - 2020-09-15 15:49:51 --> Model Class Initialized
INFO - 2020-09-15 15:49:51 --> Model Class Initialized
INFO - 2020-09-15 15:49:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:49:51 --> Final output sent to browser
DEBUG - 2020-09-15 15:49:51 --> Total execution time: 0.0446
ERROR - 2020-09-15 15:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:50:13 --> Config Class Initialized
INFO - 2020-09-15 15:50:13 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:50:13 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:50:13 --> Utf8 Class Initialized
INFO - 2020-09-15 15:50:13 --> URI Class Initialized
INFO - 2020-09-15 15:50:13 --> Router Class Initialized
INFO - 2020-09-15 15:50:13 --> Output Class Initialized
INFO - 2020-09-15 15:50:13 --> Security Class Initialized
DEBUG - 2020-09-15 15:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:50:13 --> Input Class Initialized
INFO - 2020-09-15 15:50:13 --> Language Class Initialized
INFO - 2020-09-15 15:50:13 --> Loader Class Initialized
INFO - 2020-09-15 15:50:13 --> Helper loaded: url_helper
INFO - 2020-09-15 15:50:13 --> Database Driver Class Initialized
INFO - 2020-09-15 15:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:50:13 --> Email Class Initialized
INFO - 2020-09-15 15:50:13 --> Controller Class Initialized
INFO - 2020-09-15 15:50:13 --> Model Class Initialized
INFO - 2020-09-15 15:50:13 --> Model Class Initialized
INFO - 2020-09-15 15:50:13 --> Model Class Initialized
INFO - 2020-09-15 15:50:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:50:13 --> Final output sent to browser
DEBUG - 2020-09-15 15:50:13 --> Total execution time: 0.1057
ERROR - 2020-09-15 15:50:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:50:13 --> Config Class Initialized
INFO - 2020-09-15 15:50:13 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:50:13 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:50:13 --> Utf8 Class Initialized
INFO - 2020-09-15 15:50:13 --> URI Class Initialized
INFO - 2020-09-15 15:50:13 --> Router Class Initialized
INFO - 2020-09-15 15:50:13 --> Output Class Initialized
INFO - 2020-09-15 15:50:13 --> Security Class Initialized
DEBUG - 2020-09-15 15:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:50:13 --> Input Class Initialized
INFO - 2020-09-15 15:50:13 --> Language Class Initialized
INFO - 2020-09-15 15:50:13 --> Loader Class Initialized
INFO - 2020-09-15 15:50:13 --> Helper loaded: url_helper
INFO - 2020-09-15 15:50:13 --> Database Driver Class Initialized
INFO - 2020-09-15 15:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:50:13 --> Email Class Initialized
INFO - 2020-09-15 15:50:13 --> Controller Class Initialized
INFO - 2020-09-15 15:50:13 --> Model Class Initialized
INFO - 2020-09-15 15:50:13 --> Model Class Initialized
INFO - 2020-09-15 15:50:13 --> Final output sent to browser
DEBUG - 2020-09-15 15:50:13 --> Total execution time: 0.0391
ERROR - 2020-09-15 15:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:50:51 --> Config Class Initialized
INFO - 2020-09-15 15:50:51 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:50:51 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:50:51 --> Utf8 Class Initialized
INFO - 2020-09-15 15:50:51 --> URI Class Initialized
INFO - 2020-09-15 15:50:51 --> Router Class Initialized
INFO - 2020-09-15 15:50:52 --> Output Class Initialized
INFO - 2020-09-15 15:50:52 --> Security Class Initialized
DEBUG - 2020-09-15 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:50:52 --> Input Class Initialized
INFO - 2020-09-15 15:50:52 --> Language Class Initialized
INFO - 2020-09-15 15:50:52 --> Loader Class Initialized
INFO - 2020-09-15 15:50:52 --> Helper loaded: url_helper
INFO - 2020-09-15 15:50:52 --> Database Driver Class Initialized
INFO - 2020-09-15 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:50:52 --> Email Class Initialized
INFO - 2020-09-15 15:50:52 --> Controller Class Initialized
INFO - 2020-09-15 15:50:52 --> Model Class Initialized
INFO - 2020-09-15 15:50:52 --> Model Class Initialized
INFO - 2020-09-15 15:50:52 --> Final output sent to browser
DEBUG - 2020-09-15 15:50:52 --> Total execution time: 0.1270
ERROR - 2020-09-15 15:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:50:52 --> Config Class Initialized
INFO - 2020-09-15 15:50:52 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:50:52 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:50:52 --> Utf8 Class Initialized
INFO - 2020-09-15 15:50:52 --> URI Class Initialized
INFO - 2020-09-15 15:50:52 --> Router Class Initialized
INFO - 2020-09-15 15:50:52 --> Output Class Initialized
INFO - 2020-09-15 15:50:52 --> Security Class Initialized
DEBUG - 2020-09-15 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:50:52 --> Input Class Initialized
INFO - 2020-09-15 15:50:52 --> Language Class Initialized
INFO - 2020-09-15 15:50:52 --> Loader Class Initialized
INFO - 2020-09-15 15:50:52 --> Helper loaded: url_helper
INFO - 2020-09-15 15:50:52 --> Database Driver Class Initialized
INFO - 2020-09-15 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:50:52 --> Email Class Initialized
INFO - 2020-09-15 15:50:52 --> Controller Class Initialized
INFO - 2020-09-15 15:50:52 --> Model Class Initialized
INFO - 2020-09-15 15:50:52 --> Model Class Initialized
INFO - 2020-09-15 15:50:52 --> Final output sent to browser
DEBUG - 2020-09-15 15:50:52 --> Total execution time: 0.0406
ERROR - 2020-09-15 15:51:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:51:03 --> Config Class Initialized
INFO - 2020-09-15 15:51:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:51:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:51:03 --> Utf8 Class Initialized
INFO - 2020-09-15 15:51:03 --> URI Class Initialized
INFO - 2020-09-15 15:51:03 --> Router Class Initialized
INFO - 2020-09-15 15:51:03 --> Output Class Initialized
INFO - 2020-09-15 15:51:03 --> Security Class Initialized
DEBUG - 2020-09-15 15:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:51:03 --> Input Class Initialized
INFO - 2020-09-15 15:51:03 --> Language Class Initialized
INFO - 2020-09-15 15:51:03 --> Loader Class Initialized
INFO - 2020-09-15 15:51:03 --> Helper loaded: url_helper
INFO - 2020-09-15 15:51:03 --> Database Driver Class Initialized
INFO - 2020-09-15 15:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:51:03 --> Email Class Initialized
INFO - 2020-09-15 15:51:03 --> Controller Class Initialized
INFO - 2020-09-15 15:51:03 --> Model Class Initialized
INFO - 2020-09-15 15:51:03 --> Model Class Initialized
INFO - 2020-09-15 15:51:03 --> Final output sent to browser
DEBUG - 2020-09-15 15:51:03 --> Total execution time: 0.1225
ERROR - 2020-09-15 15:51:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:51:04 --> Config Class Initialized
INFO - 2020-09-15 15:51:04 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:51:04 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:51:04 --> Utf8 Class Initialized
INFO - 2020-09-15 15:51:04 --> URI Class Initialized
INFO - 2020-09-15 15:51:04 --> Router Class Initialized
INFO - 2020-09-15 15:51:04 --> Output Class Initialized
INFO - 2020-09-15 15:51:04 --> Security Class Initialized
DEBUG - 2020-09-15 15:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:51:04 --> Input Class Initialized
INFO - 2020-09-15 15:51:04 --> Language Class Initialized
INFO - 2020-09-15 15:51:04 --> Loader Class Initialized
INFO - 2020-09-15 15:51:04 --> Helper loaded: url_helper
INFO - 2020-09-15 15:51:04 --> Database Driver Class Initialized
INFO - 2020-09-15 15:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:51:04 --> Email Class Initialized
INFO - 2020-09-15 15:51:04 --> Controller Class Initialized
INFO - 2020-09-15 15:51:04 --> Model Class Initialized
INFO - 2020-09-15 15:51:04 --> Model Class Initialized
INFO - 2020-09-15 15:51:04 --> Final output sent to browser
DEBUG - 2020-09-15 15:51:04 --> Total execution time: 0.0409
ERROR - 2020-09-15 15:51:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:51:18 --> Config Class Initialized
INFO - 2020-09-15 15:51:18 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:51:18 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:51:18 --> Utf8 Class Initialized
INFO - 2020-09-15 15:51:18 --> URI Class Initialized
INFO - 2020-09-15 15:51:18 --> Router Class Initialized
INFO - 2020-09-15 15:51:18 --> Output Class Initialized
INFO - 2020-09-15 15:51:18 --> Security Class Initialized
DEBUG - 2020-09-15 15:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:51:18 --> Input Class Initialized
INFO - 2020-09-15 15:51:18 --> Language Class Initialized
INFO - 2020-09-15 15:51:18 --> Loader Class Initialized
INFO - 2020-09-15 15:51:18 --> Helper loaded: url_helper
INFO - 2020-09-15 15:51:18 --> Database Driver Class Initialized
INFO - 2020-09-15 15:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:51:18 --> Email Class Initialized
INFO - 2020-09-15 15:51:18 --> Controller Class Initialized
INFO - 2020-09-15 15:51:18 --> Model Class Initialized
INFO - 2020-09-15 15:51:18 --> Model Class Initialized
INFO - 2020-09-15 15:51:18 --> Model Class Initialized
INFO - 2020-09-15 15:51:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:51:18 --> Final output sent to browser
DEBUG - 2020-09-15 15:51:18 --> Total execution time: 0.0345
ERROR - 2020-09-15 15:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:51:25 --> Config Class Initialized
INFO - 2020-09-15 15:51:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:51:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:51:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:51:25 --> URI Class Initialized
INFO - 2020-09-15 15:51:25 --> Router Class Initialized
INFO - 2020-09-15 15:51:25 --> Output Class Initialized
INFO - 2020-09-15 15:51:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:51:25 --> Input Class Initialized
INFO - 2020-09-15 15:51:25 --> Language Class Initialized
INFO - 2020-09-15 15:51:25 --> Loader Class Initialized
INFO - 2020-09-15 15:51:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:51:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:51:25 --> Email Class Initialized
INFO - 2020-09-15 15:51:25 --> Controller Class Initialized
INFO - 2020-09-15 15:51:25 --> Model Class Initialized
INFO - 2020-09-15 15:51:25 --> Model Class Initialized
INFO - 2020-09-15 15:51:25 --> Model Class Initialized
INFO - 2020-09-15 15:51:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:51:25 --> Final output sent to browser
DEBUG - 2020-09-15 15:51:25 --> Total execution time: 0.0974
ERROR - 2020-09-15 15:51:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:51:25 --> Config Class Initialized
INFO - 2020-09-15 15:51:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:51:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:51:25 --> Utf8 Class Initialized
INFO - 2020-09-15 15:51:25 --> URI Class Initialized
INFO - 2020-09-15 15:51:25 --> Router Class Initialized
INFO - 2020-09-15 15:51:25 --> Output Class Initialized
INFO - 2020-09-15 15:51:25 --> Security Class Initialized
DEBUG - 2020-09-15 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:51:25 --> Input Class Initialized
INFO - 2020-09-15 15:51:25 --> Language Class Initialized
INFO - 2020-09-15 15:51:25 --> Loader Class Initialized
INFO - 2020-09-15 15:51:25 --> Helper loaded: url_helper
INFO - 2020-09-15 15:51:25 --> Database Driver Class Initialized
INFO - 2020-09-15 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:51:25 --> Email Class Initialized
INFO - 2020-09-15 15:51:25 --> Controller Class Initialized
INFO - 2020-09-15 15:51:25 --> Model Class Initialized
INFO - 2020-09-15 15:51:25 --> Model Class Initialized
INFO - 2020-09-15 15:51:25 --> Final output sent to browser
DEBUG - 2020-09-15 15:51:25 --> Total execution time: 0.0427
ERROR - 2020-09-15 15:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:51:54 --> Config Class Initialized
INFO - 2020-09-15 15:51:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:51:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:51:54 --> Utf8 Class Initialized
INFO - 2020-09-15 15:51:54 --> URI Class Initialized
INFO - 2020-09-15 15:51:54 --> Router Class Initialized
INFO - 2020-09-15 15:51:54 --> Output Class Initialized
INFO - 2020-09-15 15:51:54 --> Security Class Initialized
DEBUG - 2020-09-15 15:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:51:54 --> Input Class Initialized
INFO - 2020-09-15 15:51:54 --> Language Class Initialized
INFO - 2020-09-15 15:51:54 --> Loader Class Initialized
INFO - 2020-09-15 15:51:54 --> Helper loaded: url_helper
INFO - 2020-09-15 15:51:54 --> Database Driver Class Initialized
INFO - 2020-09-15 15:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:51:54 --> Email Class Initialized
INFO - 2020-09-15 15:51:54 --> Controller Class Initialized
INFO - 2020-09-15 15:51:54 --> Model Class Initialized
INFO - 2020-09-15 15:51:54 --> Model Class Initialized
INFO - 2020-09-15 15:51:54 --> Model Class Initialized
INFO - 2020-09-15 15:51:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:51:54 --> Final output sent to browser
DEBUG - 2020-09-15 15:51:54 --> Total execution time: 0.0401
ERROR - 2020-09-15 15:53:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:53:01 --> Config Class Initialized
INFO - 2020-09-15 15:53:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:53:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:53:01 --> Utf8 Class Initialized
INFO - 2020-09-15 15:53:01 --> URI Class Initialized
INFO - 2020-09-15 15:53:01 --> Router Class Initialized
INFO - 2020-09-15 15:53:01 --> Output Class Initialized
INFO - 2020-09-15 15:53:01 --> Security Class Initialized
DEBUG - 2020-09-15 15:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:53:01 --> Input Class Initialized
INFO - 2020-09-15 15:53:01 --> Language Class Initialized
INFO - 2020-09-15 15:53:01 --> Loader Class Initialized
INFO - 2020-09-15 15:53:01 --> Helper loaded: url_helper
INFO - 2020-09-15 15:53:01 --> Database Driver Class Initialized
INFO - 2020-09-15 15:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:53:01 --> Email Class Initialized
INFO - 2020-09-15 15:53:01 --> Controller Class Initialized
INFO - 2020-09-15 15:53:01 --> Model Class Initialized
INFO - 2020-09-15 15:53:01 --> Model Class Initialized
INFO - 2020-09-15 15:53:01 --> Model Class Initialized
INFO - 2020-09-15 15:53:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:53:01 --> Final output sent to browser
DEBUG - 2020-09-15 15:53:01 --> Total execution time: 0.0369
ERROR - 2020-09-15 15:53:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:53:06 --> Config Class Initialized
INFO - 2020-09-15 15:53:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:53:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:53:06 --> Utf8 Class Initialized
INFO - 2020-09-15 15:53:06 --> URI Class Initialized
INFO - 2020-09-15 15:53:06 --> Router Class Initialized
INFO - 2020-09-15 15:53:06 --> Output Class Initialized
INFO - 2020-09-15 15:53:06 --> Security Class Initialized
DEBUG - 2020-09-15 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:53:06 --> Input Class Initialized
INFO - 2020-09-15 15:53:06 --> Language Class Initialized
INFO - 2020-09-15 15:53:06 --> Loader Class Initialized
INFO - 2020-09-15 15:53:06 --> Helper loaded: url_helper
INFO - 2020-09-15 15:53:06 --> Database Driver Class Initialized
INFO - 2020-09-15 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:53:06 --> Email Class Initialized
INFO - 2020-09-15 15:53:06 --> Controller Class Initialized
INFO - 2020-09-15 15:53:06 --> Model Class Initialized
INFO - 2020-09-15 15:53:06 --> Model Class Initialized
INFO - 2020-09-15 15:53:06 --> Model Class Initialized
INFO - 2020-09-15 15:53:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:53:06 --> Final output sent to browser
DEBUG - 2020-09-15 15:53:06 --> Total execution time: 0.0421
ERROR - 2020-09-15 15:53:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:53:11 --> Config Class Initialized
INFO - 2020-09-15 15:53:11 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:53:11 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:53:11 --> Utf8 Class Initialized
INFO - 2020-09-15 15:53:11 --> URI Class Initialized
INFO - 2020-09-15 15:53:11 --> Router Class Initialized
INFO - 2020-09-15 15:53:11 --> Output Class Initialized
INFO - 2020-09-15 15:53:11 --> Security Class Initialized
DEBUG - 2020-09-15 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:53:11 --> Input Class Initialized
INFO - 2020-09-15 15:53:11 --> Language Class Initialized
INFO - 2020-09-15 15:53:11 --> Loader Class Initialized
INFO - 2020-09-15 15:53:11 --> Helper loaded: url_helper
INFO - 2020-09-15 15:53:11 --> Database Driver Class Initialized
INFO - 2020-09-15 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:53:11 --> Email Class Initialized
INFO - 2020-09-15 15:53:11 --> Controller Class Initialized
INFO - 2020-09-15 15:53:11 --> Model Class Initialized
INFO - 2020-09-15 15:53:11 --> Model Class Initialized
INFO - 2020-09-15 15:53:11 --> Model Class Initialized
INFO - 2020-09-15 15:53:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:53:11 --> Final output sent to browser
DEBUG - 2020-09-15 15:53:11 --> Total execution time: 0.0448
ERROR - 2020-09-15 15:54:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:54:29 --> Config Class Initialized
INFO - 2020-09-15 15:54:29 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:54:29 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:54:29 --> Utf8 Class Initialized
INFO - 2020-09-15 15:54:29 --> URI Class Initialized
DEBUG - 2020-09-15 15:54:29 --> No URI present. Default controller set.
INFO - 2020-09-15 15:54:29 --> Router Class Initialized
INFO - 2020-09-15 15:54:29 --> Output Class Initialized
INFO - 2020-09-15 15:54:29 --> Security Class Initialized
DEBUG - 2020-09-15 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:54:29 --> Input Class Initialized
INFO - 2020-09-15 15:54:29 --> Language Class Initialized
INFO - 2020-09-15 15:54:29 --> Loader Class Initialized
INFO - 2020-09-15 15:54:29 --> Helper loaded: url_helper
INFO - 2020-09-15 15:54:29 --> Database Driver Class Initialized
INFO - 2020-09-15 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:54:29 --> Email Class Initialized
INFO - 2020-09-15 15:54:29 --> Controller Class Initialized
INFO - 2020-09-15 15:54:29 --> Model Class Initialized
INFO - 2020-09-15 15:54:29 --> Model Class Initialized
DEBUG - 2020-09-15 15:54:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:54:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 15:54:29 --> Final output sent to browser
DEBUG - 2020-09-15 15:54:29 --> Total execution time: 0.0223
ERROR - 2020-09-15 15:54:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:54:32 --> Config Class Initialized
INFO - 2020-09-15 15:54:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:54:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:54:32 --> Utf8 Class Initialized
ERROR - 2020-09-15 15:54:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:54:32 --> URI Class Initialized
INFO - 2020-09-15 15:54:32 --> Router Class Initialized
INFO - 2020-09-15 15:54:32 --> Config Class Initialized
INFO - 2020-09-15 15:54:32 --> Hooks Class Initialized
INFO - 2020-09-15 15:54:32 --> Output Class Initialized
DEBUG - 2020-09-15 15:54:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:54:32 --> Utf8 Class Initialized
INFO - 2020-09-15 15:54:32 --> Security Class Initialized
INFO - 2020-09-15 15:54:32 --> URI Class Initialized
DEBUG - 2020-09-15 15:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:54:32 --> Input Class Initialized
INFO - 2020-09-15 15:54:32 --> Router Class Initialized
INFO - 2020-09-15 15:54:32 --> Language Class Initialized
INFO - 2020-09-15 15:54:32 --> Output Class Initialized
INFO - 2020-09-15 15:54:32 --> Loader Class Initialized
INFO - 2020-09-15 15:54:32 --> Security Class Initialized
INFO - 2020-09-15 15:54:32 --> Helper loaded: url_helper
DEBUG - 2020-09-15 15:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:54:32 --> Input Class Initialized
INFO - 2020-09-15 15:54:32 --> Language Class Initialized
INFO - 2020-09-15 15:54:32 --> Loader Class Initialized
INFO - 2020-09-15 15:54:32 --> Helper loaded: url_helper
INFO - 2020-09-15 15:54:32 --> Database Driver Class Initialized
INFO - 2020-09-15 15:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:54:32 --> Database Driver Class Initialized
INFO - 2020-09-15 15:54:32 --> Email Class Initialized
INFO - 2020-09-15 15:54:32 --> Controller Class Initialized
INFO - 2020-09-15 15:54:32 --> Model Class Initialized
INFO - 2020-09-15 15:54:32 --> Model Class Initialized
DEBUG - 2020-09-15 15:54:32 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:54:32 --> Email Class Initialized
INFO - 2020-09-15 15:54:32 --> Controller Class Initialized
INFO - 2020-09-15 15:54:32 --> Model Class Initialized
INFO - 2020-09-15 15:54:32 --> Model Class Initialized
DEBUG - 2020-09-15 15:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:54:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:54:32 --> Model Class Initialized
INFO - 2020-09-15 15:54:32 --> Final output sent to browser
DEBUG - 2020-09-15 15:54:32 --> Total execution time: 0.0272
ERROR - 2020-09-15 15:54:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:54:33 --> Config Class Initialized
INFO - 2020-09-15 15:54:33 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:54:33 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:54:33 --> Utf8 Class Initialized
INFO - 2020-09-15 15:54:33 --> URI Class Initialized
INFO - 2020-09-15 15:54:33 --> Router Class Initialized
INFO - 2020-09-15 15:54:33 --> Output Class Initialized
INFO - 2020-09-15 15:54:33 --> Security Class Initialized
DEBUG - 2020-09-15 15:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:54:33 --> Input Class Initialized
INFO - 2020-09-15 15:54:33 --> Language Class Initialized
INFO - 2020-09-15 15:54:33 --> Loader Class Initialized
INFO - 2020-09-15 15:54:33 --> Helper loaded: url_helper
INFO - 2020-09-15 15:54:34 --> Database Driver Class Initialized
INFO - 2020-09-15 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:54:34 --> Email Class Initialized
INFO - 2020-09-15 15:54:34 --> Controller Class Initialized
DEBUG - 2020-09-15 15:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:54:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:54:34 --> Model Class Initialized
INFO - 2020-09-15 15:54:34 --> Model Class Initialized
INFO - 2020-09-15 15:54:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 15:54:34 --> Final output sent to browser
DEBUG - 2020-09-15 15:54:34 --> Total execution time: 0.0238
ERROR - 2020-09-15 15:54:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:54:43 --> Config Class Initialized
INFO - 2020-09-15 15:54:43 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:54:43 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:54:43 --> Utf8 Class Initialized
INFO - 2020-09-15 15:54:43 --> URI Class Initialized
DEBUG - 2020-09-15 15:54:43 --> No URI present. Default controller set.
INFO - 2020-09-15 15:54:43 --> Router Class Initialized
INFO - 2020-09-15 15:54:43 --> Output Class Initialized
INFO - 2020-09-15 15:54:43 --> Security Class Initialized
DEBUG - 2020-09-15 15:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:54:43 --> Input Class Initialized
INFO - 2020-09-15 15:54:43 --> Language Class Initialized
INFO - 2020-09-15 15:54:43 --> Loader Class Initialized
INFO - 2020-09-15 15:54:43 --> Helper loaded: url_helper
INFO - 2020-09-15 15:54:43 --> Database Driver Class Initialized
INFO - 2020-09-15 15:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:54:43 --> Email Class Initialized
INFO - 2020-09-15 15:54:43 --> Controller Class Initialized
INFO - 2020-09-15 15:54:43 --> Model Class Initialized
INFO - 2020-09-15 15:54:43 --> Model Class Initialized
DEBUG - 2020-09-15 15:54:43 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:54:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 15:54:43 --> Final output sent to browser
DEBUG - 2020-09-15 15:54:43 --> Total execution time: 0.0197
ERROR - 2020-09-15 15:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:01 --> Config Class Initialized
INFO - 2020-09-15 15:55:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:01 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:01 --> URI Class Initialized
INFO - 2020-09-15 15:55:01 --> Router Class Initialized
INFO - 2020-09-15 15:55:01 --> Output Class Initialized
INFO - 2020-09-15 15:55:01 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:01 --> Input Class Initialized
INFO - 2020-09-15 15:55:01 --> Language Class Initialized
INFO - 2020-09-15 15:55:01 --> Loader Class Initialized
INFO - 2020-09-15 15:55:01 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:01 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:01 --> Email Class Initialized
INFO - 2020-09-15 15:55:01 --> Controller Class Initialized
INFO - 2020-09-15 15:55:01 --> Model Class Initialized
INFO - 2020-09-15 15:55:01 --> Model Class Initialized
DEBUG - 2020-09-15 15:55:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:55:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:55:01 --> Model Class Initialized
INFO - 2020-09-15 15:55:01 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:01 --> Total execution time: 0.0224
ERROR - 2020-09-15 15:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:01 --> Config Class Initialized
INFO - 2020-09-15 15:55:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:01 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:01 --> URI Class Initialized
INFO - 2020-09-15 15:55:01 --> Router Class Initialized
INFO - 2020-09-15 15:55:01 --> Output Class Initialized
INFO - 2020-09-15 15:55:01 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:01 --> Input Class Initialized
INFO - 2020-09-15 15:55:01 --> Language Class Initialized
INFO - 2020-09-15 15:55:01 --> Loader Class Initialized
INFO - 2020-09-15 15:55:01 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:01 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:01 --> Email Class Initialized
INFO - 2020-09-15 15:55:01 --> Controller Class Initialized
INFO - 2020-09-15 15:55:01 --> Model Class Initialized
INFO - 2020-09-15 15:55:01 --> Model Class Initialized
DEBUG - 2020-09-15 15:55:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 15:55:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:01 --> Config Class Initialized
INFO - 2020-09-15 15:55:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:01 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:01 --> URI Class Initialized
INFO - 2020-09-15 15:55:01 --> Router Class Initialized
INFO - 2020-09-15 15:55:01 --> Output Class Initialized
INFO - 2020-09-15 15:55:01 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:01 --> Input Class Initialized
INFO - 2020-09-15 15:55:01 --> Language Class Initialized
INFO - 2020-09-15 15:55:01 --> Loader Class Initialized
INFO - 2020-09-15 15:55:01 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:01 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:01 --> Email Class Initialized
INFO - 2020-09-15 15:55:01 --> Controller Class Initialized
DEBUG - 2020-09-15 15:55:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 15:55:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:55:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-09-15 15:55:01 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:01 --> Total execution time: 0.0199
ERROR - 2020-09-15 15:55:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:08 --> Config Class Initialized
INFO - 2020-09-15 15:55:08 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:08 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:08 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:08 --> URI Class Initialized
INFO - 2020-09-15 15:55:08 --> Router Class Initialized
INFO - 2020-09-15 15:55:08 --> Output Class Initialized
INFO - 2020-09-15 15:55:08 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:08 --> Input Class Initialized
INFO - 2020-09-15 15:55:08 --> Language Class Initialized
INFO - 2020-09-15 15:55:08 --> Loader Class Initialized
INFO - 2020-09-15 15:55:08 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:08 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:08 --> Email Class Initialized
INFO - 2020-09-15 15:55:08 --> Controller Class Initialized
INFO - 2020-09-15 15:55:08 --> Model Class Initialized
INFO - 2020-09-15 15:55:08 --> Model Class Initialized
INFO - 2020-09-15 15:55:08 --> Model Class Initialized
INFO - 2020-09-15 15:55:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:55:08 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:08 --> Total execution time: 0.0390
ERROR - 2020-09-15 15:55:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:09 --> Config Class Initialized
INFO - 2020-09-15 15:55:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:09 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:09 --> URI Class Initialized
INFO - 2020-09-15 15:55:09 --> Router Class Initialized
INFO - 2020-09-15 15:55:09 --> Output Class Initialized
INFO - 2020-09-15 15:55:09 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:09 --> Input Class Initialized
INFO - 2020-09-15 15:55:09 --> Language Class Initialized
INFO - 2020-09-15 15:55:09 --> Loader Class Initialized
INFO - 2020-09-15 15:55:09 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:09 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:09 --> Email Class Initialized
INFO - 2020-09-15 15:55:09 --> Controller Class Initialized
INFO - 2020-09-15 15:55:09 --> Model Class Initialized
INFO - 2020-09-15 15:55:09 --> Model Class Initialized
INFO - 2020-09-15 15:55:09 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:09 --> Total execution time: 0.0415
ERROR - 2020-09-15 15:55:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:11 --> Config Class Initialized
INFO - 2020-09-15 15:55:11 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:11 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:11 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:11 --> URI Class Initialized
INFO - 2020-09-15 15:55:11 --> Router Class Initialized
INFO - 2020-09-15 15:55:11 --> Output Class Initialized
INFO - 2020-09-15 15:55:11 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:11 --> Input Class Initialized
INFO - 2020-09-15 15:55:11 --> Language Class Initialized
INFO - 2020-09-15 15:55:11 --> Loader Class Initialized
INFO - 2020-09-15 15:55:11 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:11 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:11 --> Email Class Initialized
INFO - 2020-09-15 15:55:11 --> Controller Class Initialized
INFO - 2020-09-15 15:55:11 --> Model Class Initialized
INFO - 2020-09-15 15:55:11 --> Model Class Initialized
INFO - 2020-09-15 15:55:11 --> Model Class Initialized
INFO - 2020-09-15 15:55:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_assign.php
INFO - 2020-09-15 15:55:11 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:11 --> Total execution time: 0.0378
ERROR - 2020-09-15 15:55:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:36 --> Config Class Initialized
INFO - 2020-09-15 15:55:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:36 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:36 --> URI Class Initialized
INFO - 2020-09-15 15:55:36 --> Router Class Initialized
INFO - 2020-09-15 15:55:36 --> Output Class Initialized
INFO - 2020-09-15 15:55:36 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:36 --> Input Class Initialized
INFO - 2020-09-15 15:55:36 --> Language Class Initialized
INFO - 2020-09-15 15:55:36 --> Loader Class Initialized
INFO - 2020-09-15 15:55:36 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:36 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:36 --> Email Class Initialized
INFO - 2020-09-15 15:55:36 --> Controller Class Initialized
INFO - 2020-09-15 15:55:36 --> Model Class Initialized
INFO - 2020-09-15 15:55:36 --> Model Class Initialized
INFO - 2020-09-15 15:55:36 --> Model Class Initialized
INFO - 2020-09-15 15:55:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 15:55:36 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:36 --> Total execution time: 0.0499
ERROR - 2020-09-15 15:55:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:37 --> Config Class Initialized
INFO - 2020-09-15 15:55:37 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:37 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:37 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:37 --> URI Class Initialized
INFO - 2020-09-15 15:55:37 --> Router Class Initialized
INFO - 2020-09-15 15:55:37 --> Output Class Initialized
INFO - 2020-09-15 15:55:37 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:37 --> Input Class Initialized
INFO - 2020-09-15 15:55:37 --> Language Class Initialized
INFO - 2020-09-15 15:55:37 --> Loader Class Initialized
INFO - 2020-09-15 15:55:37 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:37 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:37 --> Email Class Initialized
INFO - 2020-09-15 15:55:37 --> Controller Class Initialized
INFO - 2020-09-15 15:55:37 --> Model Class Initialized
INFO - 2020-09-15 15:55:37 --> Model Class Initialized
INFO - 2020-09-15 15:55:37 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:37 --> Total execution time: 0.0448
ERROR - 2020-09-15 15:55:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 15:55:44 --> Config Class Initialized
INFO - 2020-09-15 15:55:44 --> Hooks Class Initialized
DEBUG - 2020-09-15 15:55:44 --> UTF-8 Support Enabled
INFO - 2020-09-15 15:55:44 --> Utf8 Class Initialized
INFO - 2020-09-15 15:55:44 --> URI Class Initialized
DEBUG - 2020-09-15 15:55:44 --> No URI present. Default controller set.
INFO - 2020-09-15 15:55:44 --> Router Class Initialized
INFO - 2020-09-15 15:55:44 --> Output Class Initialized
INFO - 2020-09-15 15:55:44 --> Security Class Initialized
DEBUG - 2020-09-15 15:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 15:55:44 --> Input Class Initialized
INFO - 2020-09-15 15:55:44 --> Language Class Initialized
INFO - 2020-09-15 15:55:44 --> Loader Class Initialized
INFO - 2020-09-15 15:55:44 --> Helper loaded: url_helper
INFO - 2020-09-15 15:55:44 --> Database Driver Class Initialized
INFO - 2020-09-15 15:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 15:55:44 --> Email Class Initialized
INFO - 2020-09-15 15:55:44 --> Controller Class Initialized
INFO - 2020-09-15 15:55:44 --> Model Class Initialized
INFO - 2020-09-15 15:55:44 --> Model Class Initialized
DEBUG - 2020-09-15 15:55:44 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 15:55:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 15:55:44 --> Final output sent to browser
DEBUG - 2020-09-15 15:55:44 --> Total execution time: 0.0196
ERROR - 2020-09-15 16:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:02 --> Config Class Initialized
INFO - 2020-09-15 16:02:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:02 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:02 --> URI Class Initialized
INFO - 2020-09-15 16:02:02 --> Router Class Initialized
INFO - 2020-09-15 16:02:02 --> Output Class Initialized
INFO - 2020-09-15 16:02:02 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:02 --> Input Class Initialized
INFO - 2020-09-15 16:02:02 --> Language Class Initialized
INFO - 2020-09-15 16:02:02 --> Loader Class Initialized
INFO - 2020-09-15 16:02:02 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:02 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:02 --> Email Class Initialized
INFO - 2020-09-15 16:02:02 --> Controller Class Initialized
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
DEBUG - 2020-09-15 16:02:02 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 16:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:02 --> Config Class Initialized
INFO - 2020-09-15 16:02:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:02 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:02 --> URI Class Initialized
INFO - 2020-09-15 16:02:02 --> Router Class Initialized
INFO - 2020-09-15 16:02:02 --> Output Class Initialized
INFO - 2020-09-15 16:02:02 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:02 --> Input Class Initialized
INFO - 2020-09-15 16:02:02 --> Language Class Initialized
INFO - 2020-09-15 16:02:02 --> Loader Class Initialized
INFO - 2020-09-15 16:02:02 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:02 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:02 --> Email Class Initialized
INFO - 2020-09-15 16:02:02 --> Controller Class Initialized
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
DEBUG - 2020-09-15 16:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
INFO - 2020-09-15 16:02:02 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:02 --> Total execution time: 0.0247
ERROR - 2020-09-15 16:02:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:02 --> Config Class Initialized
INFO - 2020-09-15 16:02:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:02 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:02 --> URI Class Initialized
INFO - 2020-09-15 16:02:02 --> Router Class Initialized
INFO - 2020-09-15 16:02:02 --> Output Class Initialized
INFO - 2020-09-15 16:02:02 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:02 --> Input Class Initialized
INFO - 2020-09-15 16:02:02 --> Language Class Initialized
INFO - 2020-09-15 16:02:02 --> Loader Class Initialized
INFO - 2020-09-15 16:02:02 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:02 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:02 --> Email Class Initialized
INFO - 2020-09-15 16:02:02 --> Controller Class Initialized
DEBUG - 2020-09-15 16:02:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
INFO - 2020-09-15 16:02:02 --> Model Class Initialized
INFO - 2020-09-15 16:02:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 16:02:02 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:02 --> Total execution time: 0.0231
ERROR - 2020-09-15 16:02:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:11 --> Config Class Initialized
INFO - 2020-09-15 16:02:11 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:11 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:11 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:11 --> URI Class Initialized
INFO - 2020-09-15 16:02:11 --> Router Class Initialized
INFO - 2020-09-15 16:02:11 --> Output Class Initialized
INFO - 2020-09-15 16:02:11 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:11 --> Input Class Initialized
INFO - 2020-09-15 16:02:11 --> Language Class Initialized
INFO - 2020-09-15 16:02:11 --> Loader Class Initialized
INFO - 2020-09-15 16:02:11 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:11 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:11 --> Email Class Initialized
INFO - 2020-09-15 16:02:11 --> Controller Class Initialized
DEBUG - 2020-09-15 16:02:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:11 --> Model Class Initialized
INFO - 2020-09-15 16:02:11 --> Model Class Initialized
INFO - 2020-09-15 16:02:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 16:02:11 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:11 --> Total execution time: 0.0550
ERROR - 2020-09-15 16:02:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:31 --> Config Class Initialized
INFO - 2020-09-15 16:02:31 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:31 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:31 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:31 --> URI Class Initialized
INFO - 2020-09-15 16:02:31 --> Router Class Initialized
INFO - 2020-09-15 16:02:31 --> Output Class Initialized
INFO - 2020-09-15 16:02:31 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:31 --> Input Class Initialized
INFO - 2020-09-15 16:02:31 --> Language Class Initialized
INFO - 2020-09-15 16:02:31 --> Loader Class Initialized
INFO - 2020-09-15 16:02:31 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:31 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:31 --> Email Class Initialized
INFO - 2020-09-15 16:02:31 --> Controller Class Initialized
DEBUG - 2020-09-15 16:02:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:31 --> Model Class Initialized
INFO - 2020-09-15 16:02:31 --> Model Class Initialized
INFO - 2020-09-15 16:02:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 16:02:31 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:31 --> Total execution time: 0.0344
ERROR - 2020-09-15 16:02:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:45 --> Config Class Initialized
INFO - 2020-09-15 16:02:45 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:45 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:45 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:45 --> URI Class Initialized
DEBUG - 2020-09-15 16:02:45 --> No URI present. Default controller set.
INFO - 2020-09-15 16:02:45 --> Router Class Initialized
INFO - 2020-09-15 16:02:45 --> Output Class Initialized
INFO - 2020-09-15 16:02:45 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:45 --> Input Class Initialized
INFO - 2020-09-15 16:02:45 --> Language Class Initialized
INFO - 2020-09-15 16:02:45 --> Loader Class Initialized
INFO - 2020-09-15 16:02:45 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:45 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:45 --> Email Class Initialized
INFO - 2020-09-15 16:02:45 --> Controller Class Initialized
INFO - 2020-09-15 16:02:45 --> Model Class Initialized
INFO - 2020-09-15 16:02:45 --> Model Class Initialized
DEBUG - 2020-09-15 16:02:45 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 16:02:45 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:45 --> Total execution time: 0.0228
ERROR - 2020-09-15 16:02:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:48 --> Config Class Initialized
INFO - 2020-09-15 16:02:48 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:48 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:48 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:48 --> URI Class Initialized
INFO - 2020-09-15 16:02:48 --> Router Class Initialized
INFO - 2020-09-15 16:02:48 --> Output Class Initialized
INFO - 2020-09-15 16:02:48 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:48 --> Input Class Initialized
INFO - 2020-09-15 16:02:48 --> Language Class Initialized
INFO - 2020-09-15 16:02:48 --> Loader Class Initialized
INFO - 2020-09-15 16:02:48 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:48 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:48 --> Email Class Initialized
INFO - 2020-09-15 16:02:48 --> Controller Class Initialized
INFO - 2020-09-15 16:02:48 --> Model Class Initialized
INFO - 2020-09-15 16:02:48 --> Model Class Initialized
DEBUG - 2020-09-15 16:02:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:48 --> Model Class Initialized
INFO - 2020-09-15 16:02:48 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:48 --> Total execution time: 0.0336
ERROR - 2020-09-15 16:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:49 --> Config Class Initialized
INFO - 2020-09-15 16:02:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:49 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:49 --> URI Class Initialized
INFO - 2020-09-15 16:02:49 --> Router Class Initialized
INFO - 2020-09-15 16:02:49 --> Output Class Initialized
INFO - 2020-09-15 16:02:49 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:49 --> Input Class Initialized
INFO - 2020-09-15 16:02:49 --> Language Class Initialized
INFO - 2020-09-15 16:02:49 --> Loader Class Initialized
INFO - 2020-09-15 16:02:49 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:49 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:49 --> Email Class Initialized
INFO - 2020-09-15 16:02:49 --> Controller Class Initialized
INFO - 2020-09-15 16:02:49 --> Model Class Initialized
INFO - 2020-09-15 16:02:49 --> Model Class Initialized
DEBUG - 2020-09-15 16:02:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-09-15 16:02:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:49 --> Config Class Initialized
INFO - 2020-09-15 16:02:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:49 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:49 --> URI Class Initialized
INFO - 2020-09-15 16:02:49 --> Router Class Initialized
INFO - 2020-09-15 16:02:49 --> Output Class Initialized
INFO - 2020-09-15 16:02:49 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:49 --> Input Class Initialized
INFO - 2020-09-15 16:02:49 --> Language Class Initialized
INFO - 2020-09-15 16:02:49 --> Loader Class Initialized
INFO - 2020-09-15 16:02:49 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:49 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:49 --> Email Class Initialized
INFO - 2020-09-15 16:02:49 --> Controller Class Initialized
DEBUG - 2020-09-15 16:02:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:49 --> Model Class Initialized
INFO - 2020-09-15 16:02:49 --> Model Class Initialized
INFO - 2020-09-15 16:02:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 16:02:49 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:49 --> Total execution time: 0.0230
ERROR - 2020-09-15 16:02:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:53 --> Config Class Initialized
INFO - 2020-09-15 16:02:53 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:53 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:53 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:53 --> URI Class Initialized
INFO - 2020-09-15 16:02:53 --> Router Class Initialized
INFO - 2020-09-15 16:02:53 --> Output Class Initialized
INFO - 2020-09-15 16:02:53 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:53 --> Input Class Initialized
INFO - 2020-09-15 16:02:53 --> Language Class Initialized
INFO - 2020-09-15 16:02:53 --> Loader Class Initialized
INFO - 2020-09-15 16:02:53 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:53 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:53 --> Email Class Initialized
INFO - 2020-09-15 16:02:53 --> Controller Class Initialized
DEBUG - 2020-09-15 16:02:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:53 --> Model Class Initialized
INFO - 2020-09-15 16:02:53 --> Model Class Initialized
INFO - 2020-09-15 16:02:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 16:02:53 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:53 --> Total execution time: 0.0199
ERROR - 2020-09-15 16:02:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:02:58 --> Config Class Initialized
INFO - 2020-09-15 16:02:58 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:02:58 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:02:58 --> Utf8 Class Initialized
INFO - 2020-09-15 16:02:58 --> URI Class Initialized
INFO - 2020-09-15 16:02:58 --> Router Class Initialized
INFO - 2020-09-15 16:02:58 --> Output Class Initialized
INFO - 2020-09-15 16:02:58 --> Security Class Initialized
DEBUG - 2020-09-15 16:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:02:58 --> Input Class Initialized
INFO - 2020-09-15 16:02:58 --> Language Class Initialized
INFO - 2020-09-15 16:02:58 --> Loader Class Initialized
INFO - 2020-09-15 16:02:58 --> Helper loaded: url_helper
INFO - 2020-09-15 16:02:58 --> Database Driver Class Initialized
INFO - 2020-09-15 16:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:02:58 --> Email Class Initialized
INFO - 2020-09-15 16:02:58 --> Controller Class Initialized
DEBUG - 2020-09-15 16:02:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:02:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:02:58 --> Model Class Initialized
INFO - 2020-09-15 16:02:58 --> Model Class Initialized
INFO - 2020-09-15 16:02:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 16:02:58 --> Final output sent to browser
DEBUG - 2020-09-15 16:02:58 --> Total execution time: 0.0222
ERROR - 2020-09-15 16:03:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:03:03 --> Config Class Initialized
INFO - 2020-09-15 16:03:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:03:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:03:03 --> Utf8 Class Initialized
INFO - 2020-09-15 16:03:03 --> URI Class Initialized
INFO - 2020-09-15 16:03:03 --> Router Class Initialized
INFO - 2020-09-15 16:03:03 --> Output Class Initialized
INFO - 2020-09-15 16:03:03 --> Security Class Initialized
DEBUG - 2020-09-15 16:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:03:03 --> Input Class Initialized
INFO - 2020-09-15 16:03:03 --> Language Class Initialized
INFO - 2020-09-15 16:03:03 --> Loader Class Initialized
INFO - 2020-09-15 16:03:03 --> Helper loaded: url_helper
INFO - 2020-09-15 16:03:03 --> Database Driver Class Initialized
INFO - 2020-09-15 16:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:03:03 --> Email Class Initialized
INFO - 2020-09-15 16:03:03 --> Controller Class Initialized
DEBUG - 2020-09-15 16:03:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:03:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:03:03 --> Model Class Initialized
INFO - 2020-09-15 16:03:03 --> Model Class Initialized
INFO - 2020-09-15 16:03:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 16:03:03 --> Final output sent to browser
DEBUG - 2020-09-15 16:03:03 --> Total execution time: 0.0239
ERROR - 2020-09-15 16:03:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:03:06 --> Config Class Initialized
INFO - 2020-09-15 16:03:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:03:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:03:06 --> Utf8 Class Initialized
INFO - 2020-09-15 16:03:06 --> URI Class Initialized
INFO - 2020-09-15 16:03:06 --> Router Class Initialized
INFO - 2020-09-15 16:03:06 --> Output Class Initialized
INFO - 2020-09-15 16:03:06 --> Security Class Initialized
DEBUG - 2020-09-15 16:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:03:06 --> Input Class Initialized
INFO - 2020-09-15 16:03:06 --> Language Class Initialized
INFO - 2020-09-15 16:03:06 --> Loader Class Initialized
INFO - 2020-09-15 16:03:06 --> Helper loaded: url_helper
INFO - 2020-09-15 16:03:06 --> Database Driver Class Initialized
INFO - 2020-09-15 16:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:03:06 --> Email Class Initialized
INFO - 2020-09-15 16:03:06 --> Controller Class Initialized
DEBUG - 2020-09-15 16:03:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:03:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:03:06 --> Model Class Initialized
INFO - 2020-09-15 16:03:06 --> Model Class Initialized
INFO - 2020-09-15 16:03:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 16:03:06 --> Final output sent to browser
DEBUG - 2020-09-15 16:03:06 --> Total execution time: 0.0265
ERROR - 2020-09-15 16:03:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:03:09 --> Config Class Initialized
INFO - 2020-09-15 16:03:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:03:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:03:09 --> Utf8 Class Initialized
INFO - 2020-09-15 16:03:09 --> URI Class Initialized
INFO - 2020-09-15 16:03:09 --> Router Class Initialized
INFO - 2020-09-15 16:03:09 --> Output Class Initialized
INFO - 2020-09-15 16:03:09 --> Security Class Initialized
DEBUG - 2020-09-15 16:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:03:09 --> Input Class Initialized
INFO - 2020-09-15 16:03:09 --> Language Class Initialized
INFO - 2020-09-15 16:03:09 --> Loader Class Initialized
INFO - 2020-09-15 16:03:09 --> Helper loaded: url_helper
INFO - 2020-09-15 16:03:09 --> Database Driver Class Initialized
INFO - 2020-09-15 16:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:03:09 --> Email Class Initialized
INFO - 2020-09-15 16:03:09 --> Controller Class Initialized
DEBUG - 2020-09-15 16:03:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:03:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:03:09 --> Model Class Initialized
INFO - 2020-09-15 16:03:09 --> Model Class Initialized
INFO - 2020-09-15 16:03:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 16:03:09 --> Final output sent to browser
DEBUG - 2020-09-15 16:03:09 --> Total execution time: 0.0226
ERROR - 2020-09-15 16:03:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:03:12 --> Config Class Initialized
INFO - 2020-09-15 16:03:12 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:03:12 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:03:12 --> Utf8 Class Initialized
INFO - 2020-09-15 16:03:12 --> URI Class Initialized
INFO - 2020-09-15 16:03:12 --> Router Class Initialized
INFO - 2020-09-15 16:03:12 --> Output Class Initialized
INFO - 2020-09-15 16:03:12 --> Security Class Initialized
DEBUG - 2020-09-15 16:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:03:12 --> Input Class Initialized
INFO - 2020-09-15 16:03:12 --> Language Class Initialized
INFO - 2020-09-15 16:03:12 --> Loader Class Initialized
INFO - 2020-09-15 16:03:12 --> Helper loaded: url_helper
INFO - 2020-09-15 16:03:12 --> Database Driver Class Initialized
INFO - 2020-09-15 16:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:03:12 --> Email Class Initialized
INFO - 2020-09-15 16:03:12 --> Controller Class Initialized
DEBUG - 2020-09-15 16:03:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:03:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:03:12 --> Model Class Initialized
INFO - 2020-09-15 16:03:12 --> Model Class Initialized
INFO - 2020-09-15 16:03:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 16:03:12 --> Final output sent to browser
DEBUG - 2020-09-15 16:03:12 --> Total execution time: 0.0276
ERROR - 2020-09-15 16:03:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:03:36 --> Config Class Initialized
INFO - 2020-09-15 16:03:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:03:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:03:36 --> Utf8 Class Initialized
INFO - 2020-09-15 16:03:36 --> URI Class Initialized
INFO - 2020-09-15 16:03:36 --> Router Class Initialized
INFO - 2020-09-15 16:03:36 --> Output Class Initialized
INFO - 2020-09-15 16:03:36 --> Security Class Initialized
DEBUG - 2020-09-15 16:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:03:36 --> Input Class Initialized
INFO - 2020-09-15 16:03:36 --> Language Class Initialized
INFO - 2020-09-15 16:03:36 --> Loader Class Initialized
INFO - 2020-09-15 16:03:36 --> Helper loaded: url_helper
INFO - 2020-09-15 16:03:36 --> Database Driver Class Initialized
INFO - 2020-09-15 16:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:03:36 --> Email Class Initialized
INFO - 2020-09-15 16:03:36 --> Controller Class Initialized
DEBUG - 2020-09-15 16:03:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:03:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:03:36 --> Model Class Initialized
INFO - 2020-09-15 16:03:36 --> Model Class Initialized
INFO - 2020-09-15 16:03:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 16:03:36 --> Final output sent to browser
DEBUG - 2020-09-15 16:03:36 --> Total execution time: 0.0189
ERROR - 2020-09-15 16:35:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:35:57 --> Config Class Initialized
INFO - 2020-09-15 16:35:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:35:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:35:57 --> Utf8 Class Initialized
INFO - 2020-09-15 16:35:57 --> URI Class Initialized
INFO - 2020-09-15 16:35:57 --> Router Class Initialized
INFO - 2020-09-15 16:35:57 --> Output Class Initialized
INFO - 2020-09-15 16:35:57 --> Security Class Initialized
DEBUG - 2020-09-15 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:35:57 --> Input Class Initialized
INFO - 2020-09-15 16:35:57 --> Language Class Initialized
INFO - 2020-09-15 16:35:57 --> Loader Class Initialized
INFO - 2020-09-15 16:35:57 --> Helper loaded: url_helper
INFO - 2020-09-15 16:35:57 --> Database Driver Class Initialized
INFO - 2020-09-15 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:35:57 --> Email Class Initialized
INFO - 2020-09-15 16:35:57 --> Controller Class Initialized
DEBUG - 2020-09-15 16:35:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:35:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:35:57 --> Model Class Initialized
INFO - 2020-09-15 16:35:57 --> Model Class Initialized
INFO - 2020-09-15 16:35:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 16:35:57 --> Final output sent to browser
DEBUG - 2020-09-15 16:35:57 --> Total execution time: 0.0258
ERROR - 2020-09-15 16:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:45:02 --> Config Class Initialized
INFO - 2020-09-15 16:45:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:45:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:45:02 --> Utf8 Class Initialized
INFO - 2020-09-15 16:45:02 --> URI Class Initialized
INFO - 2020-09-15 16:45:02 --> Router Class Initialized
INFO - 2020-09-15 16:45:02 --> Output Class Initialized
INFO - 2020-09-15 16:45:02 --> Security Class Initialized
DEBUG - 2020-09-15 16:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:45:02 --> Input Class Initialized
INFO - 2020-09-15 16:45:02 --> Language Class Initialized
INFO - 2020-09-15 16:45:02 --> Loader Class Initialized
INFO - 2020-09-15 16:45:02 --> Helper loaded: url_helper
INFO - 2020-09-15 16:45:02 --> Database Driver Class Initialized
INFO - 2020-09-15 16:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:45:02 --> Email Class Initialized
INFO - 2020-09-15 16:45:02 --> Controller Class Initialized
DEBUG - 2020-09-15 16:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:45:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:45:02 --> Model Class Initialized
INFO - 2020-09-15 16:45:02 --> Model Class Initialized
INFO - 2020-09-15 16:45:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 16:45:02 --> Final output sent to browser
DEBUG - 2020-09-15 16:45:02 --> Total execution time: 0.0258
ERROR - 2020-09-15 16:45:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:45:06 --> Config Class Initialized
INFO - 2020-09-15 16:45:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:45:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:45:06 --> Utf8 Class Initialized
INFO - 2020-09-15 16:45:06 --> URI Class Initialized
INFO - 2020-09-15 16:45:06 --> Router Class Initialized
INFO - 2020-09-15 16:45:06 --> Output Class Initialized
INFO - 2020-09-15 16:45:06 --> Security Class Initialized
DEBUG - 2020-09-15 16:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:45:06 --> Input Class Initialized
INFO - 2020-09-15 16:45:06 --> Language Class Initialized
INFO - 2020-09-15 16:45:06 --> Loader Class Initialized
INFO - 2020-09-15 16:45:06 --> Helper loaded: url_helper
INFO - 2020-09-15 16:45:06 --> Database Driver Class Initialized
INFO - 2020-09-15 16:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:45:06 --> Email Class Initialized
INFO - 2020-09-15 16:45:06 --> Controller Class Initialized
DEBUG - 2020-09-15 16:45:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:45:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:45:06 --> Model Class Initialized
INFO - 2020-09-15 16:45:06 --> Model Class Initialized
INFO - 2020-09-15 16:45:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 16:45:06 --> Final output sent to browser
DEBUG - 2020-09-15 16:45:06 --> Total execution time: 0.0189
ERROR - 2020-09-15 16:45:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:45:09 --> Config Class Initialized
INFO - 2020-09-15 16:45:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:45:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:45:09 --> Utf8 Class Initialized
INFO - 2020-09-15 16:45:09 --> URI Class Initialized
INFO - 2020-09-15 16:45:09 --> Router Class Initialized
INFO - 2020-09-15 16:45:09 --> Output Class Initialized
INFO - 2020-09-15 16:45:09 --> Security Class Initialized
DEBUG - 2020-09-15 16:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:45:09 --> Input Class Initialized
INFO - 2020-09-15 16:45:09 --> Language Class Initialized
INFO - 2020-09-15 16:45:09 --> Loader Class Initialized
INFO - 2020-09-15 16:45:09 --> Helper loaded: url_helper
INFO - 2020-09-15 16:45:09 --> Database Driver Class Initialized
INFO - 2020-09-15 16:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:45:09 --> Email Class Initialized
INFO - 2020-09-15 16:45:09 --> Controller Class Initialized
DEBUG - 2020-09-15 16:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:45:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:45:09 --> Model Class Initialized
INFO - 2020-09-15 16:45:09 --> Model Class Initialized
INFO - 2020-09-15 16:45:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 16:45:09 --> Final output sent to browser
DEBUG - 2020-09-15 16:45:09 --> Total execution time: 0.0240
ERROR - 2020-09-15 16:45:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:45:15 --> Config Class Initialized
INFO - 2020-09-15 16:45:15 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:45:15 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:45:15 --> Utf8 Class Initialized
INFO - 2020-09-15 16:45:15 --> URI Class Initialized
INFO - 2020-09-15 16:45:15 --> Router Class Initialized
INFO - 2020-09-15 16:45:15 --> Output Class Initialized
INFO - 2020-09-15 16:45:15 --> Security Class Initialized
DEBUG - 2020-09-15 16:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:45:15 --> Input Class Initialized
INFO - 2020-09-15 16:45:15 --> Language Class Initialized
INFO - 2020-09-15 16:45:15 --> Loader Class Initialized
INFO - 2020-09-15 16:45:15 --> Helper loaded: url_helper
INFO - 2020-09-15 16:45:15 --> Database Driver Class Initialized
INFO - 2020-09-15 16:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:45:15 --> Email Class Initialized
INFO - 2020-09-15 16:45:15 --> Controller Class Initialized
DEBUG - 2020-09-15 16:45:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:45:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:45:15 --> Model Class Initialized
INFO - 2020-09-15 16:45:15 --> Model Class Initialized
INFO - 2020-09-15 16:45:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 16:45:15 --> Final output sent to browser
DEBUG - 2020-09-15 16:45:15 --> Total execution time: 0.0189
ERROR - 2020-09-15 16:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:47:30 --> Config Class Initialized
INFO - 2020-09-15 16:47:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:47:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:47:30 --> Utf8 Class Initialized
INFO - 2020-09-15 16:47:30 --> URI Class Initialized
INFO - 2020-09-15 16:47:30 --> Router Class Initialized
INFO - 2020-09-15 16:47:30 --> Output Class Initialized
INFO - 2020-09-15 16:47:30 --> Security Class Initialized
DEBUG - 2020-09-15 16:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:47:30 --> Input Class Initialized
INFO - 2020-09-15 16:47:30 --> Language Class Initialized
INFO - 2020-09-15 16:47:30 --> Loader Class Initialized
INFO - 2020-09-15 16:47:30 --> Helper loaded: url_helper
INFO - 2020-09-15 16:47:30 --> Database Driver Class Initialized
INFO - 2020-09-15 16:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:47:30 --> Email Class Initialized
INFO - 2020-09-15 16:47:30 --> Controller Class Initialized
DEBUG - 2020-09-15 16:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:47:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:47:30 --> Model Class Initialized
INFO - 2020-09-15 16:47:30 --> Model Class Initialized
INFO - 2020-09-15 16:47:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 16:47:30 --> Final output sent to browser
DEBUG - 2020-09-15 16:47:30 --> Total execution time: 0.0233
ERROR - 2020-09-15 16:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:47:46 --> Config Class Initialized
INFO - 2020-09-15 16:47:46 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:47:46 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:47:46 --> Utf8 Class Initialized
INFO - 2020-09-15 16:47:46 --> URI Class Initialized
INFO - 2020-09-15 16:47:46 --> Router Class Initialized
INFO - 2020-09-15 16:47:46 --> Output Class Initialized
INFO - 2020-09-15 16:47:46 --> Security Class Initialized
DEBUG - 2020-09-15 16:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:47:46 --> Input Class Initialized
INFO - 2020-09-15 16:47:46 --> Language Class Initialized
INFO - 2020-09-15 16:47:46 --> Loader Class Initialized
INFO - 2020-09-15 16:47:46 --> Helper loaded: url_helper
INFO - 2020-09-15 16:47:46 --> Database Driver Class Initialized
INFO - 2020-09-15 16:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:47:46 --> Email Class Initialized
INFO - 2020-09-15 16:47:46 --> Controller Class Initialized
DEBUG - 2020-09-15 16:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:47:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:47:46 --> Model Class Initialized
INFO - 2020-09-15 16:47:46 --> Model Class Initialized
INFO - 2020-09-15 16:47:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 16:47:46 --> Final output sent to browser
DEBUG - 2020-09-15 16:47:46 --> Total execution time: 0.0219
ERROR - 2020-09-15 16:47:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:47:49 --> Config Class Initialized
INFO - 2020-09-15 16:47:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:47:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:47:49 --> Utf8 Class Initialized
INFO - 2020-09-15 16:47:49 --> URI Class Initialized
INFO - 2020-09-15 16:47:49 --> Router Class Initialized
INFO - 2020-09-15 16:47:49 --> Output Class Initialized
INFO - 2020-09-15 16:47:49 --> Security Class Initialized
DEBUG - 2020-09-15 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:47:49 --> Input Class Initialized
INFO - 2020-09-15 16:47:49 --> Language Class Initialized
INFO - 2020-09-15 16:47:49 --> Loader Class Initialized
INFO - 2020-09-15 16:47:49 --> Helper loaded: url_helper
INFO - 2020-09-15 16:47:49 --> Database Driver Class Initialized
INFO - 2020-09-15 16:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:47:49 --> Email Class Initialized
INFO - 2020-09-15 16:47:49 --> Controller Class Initialized
DEBUG - 2020-09-15 16:47:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:47:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:47:49 --> Model Class Initialized
INFO - 2020-09-15 16:47:49 --> Model Class Initialized
INFO - 2020-09-15 16:47:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 16:47:49 --> Final output sent to browser
DEBUG - 2020-09-15 16:47:49 --> Total execution time: 0.0198
ERROR - 2020-09-15 16:47:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:47:57 --> Config Class Initialized
INFO - 2020-09-15 16:47:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:47:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:47:57 --> Utf8 Class Initialized
INFO - 2020-09-15 16:47:57 --> URI Class Initialized
INFO - 2020-09-15 16:47:57 --> Router Class Initialized
INFO - 2020-09-15 16:47:57 --> Output Class Initialized
INFO - 2020-09-15 16:47:57 --> Security Class Initialized
DEBUG - 2020-09-15 16:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:47:57 --> Input Class Initialized
INFO - 2020-09-15 16:47:57 --> Language Class Initialized
INFO - 2020-09-15 16:47:57 --> Loader Class Initialized
INFO - 2020-09-15 16:47:57 --> Helper loaded: url_helper
INFO - 2020-09-15 16:47:57 --> Database Driver Class Initialized
INFO - 2020-09-15 16:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:47:57 --> Email Class Initialized
INFO - 2020-09-15 16:47:57 --> Controller Class Initialized
DEBUG - 2020-09-15 16:47:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:47:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:47:57 --> Model Class Initialized
INFO - 2020-09-15 16:47:57 --> Model Class Initialized
INFO - 2020-09-15 16:47:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 16:47:57 --> Final output sent to browser
DEBUG - 2020-09-15 16:47:57 --> Total execution time: 0.0209
ERROR - 2020-09-15 16:48:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 16:48:00 --> Config Class Initialized
INFO - 2020-09-15 16:48:00 --> Hooks Class Initialized
DEBUG - 2020-09-15 16:48:00 --> UTF-8 Support Enabled
INFO - 2020-09-15 16:48:00 --> Utf8 Class Initialized
INFO - 2020-09-15 16:48:00 --> URI Class Initialized
INFO - 2020-09-15 16:48:00 --> Router Class Initialized
INFO - 2020-09-15 16:48:00 --> Output Class Initialized
INFO - 2020-09-15 16:48:00 --> Security Class Initialized
DEBUG - 2020-09-15 16:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 16:48:00 --> Input Class Initialized
INFO - 2020-09-15 16:48:00 --> Language Class Initialized
INFO - 2020-09-15 16:48:00 --> Loader Class Initialized
INFO - 2020-09-15 16:48:00 --> Helper loaded: url_helper
INFO - 2020-09-15 16:48:00 --> Database Driver Class Initialized
INFO - 2020-09-15 16:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 16:48:00 --> Email Class Initialized
INFO - 2020-09-15 16:48:00 --> Controller Class Initialized
DEBUG - 2020-09-15 16:48:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 16:48:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 16:48:00 --> Model Class Initialized
INFO - 2020-09-15 16:48:00 --> Model Class Initialized
INFO - 2020-09-15 16:48:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 16:48:00 --> Final output sent to browser
DEBUG - 2020-09-15 16:48:00 --> Total execution time: 0.0188
ERROR - 2020-09-15 17:27:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:27:08 --> Config Class Initialized
INFO - 2020-09-15 17:27:08 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:27:08 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:27:08 --> Utf8 Class Initialized
INFO - 2020-09-15 17:27:08 --> URI Class Initialized
INFO - 2020-09-15 17:27:08 --> Router Class Initialized
INFO - 2020-09-15 17:27:08 --> Output Class Initialized
INFO - 2020-09-15 17:27:08 --> Security Class Initialized
DEBUG - 2020-09-15 17:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:27:08 --> Input Class Initialized
INFO - 2020-09-15 17:27:08 --> Language Class Initialized
INFO - 2020-09-15 17:27:08 --> Loader Class Initialized
INFO - 2020-09-15 17:27:08 --> Helper loaded: url_helper
INFO - 2020-09-15 17:27:08 --> Database Driver Class Initialized
INFO - 2020-09-15 17:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:27:08 --> Email Class Initialized
INFO - 2020-09-15 17:27:08 --> Controller Class Initialized
DEBUG - 2020-09-15 17:27:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:27:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:27:08 --> Model Class Initialized
INFO - 2020-09-15 17:27:08 --> Model Class Initialized
ERROR - 2020-09-15 17:27:08 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL sale_rep_list_by_id(29)
INFO - 2020-09-15 17:27:08 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 17:27:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:27:32 --> Config Class Initialized
INFO - 2020-09-15 17:27:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:27:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:27:32 --> Utf8 Class Initialized
INFO - 2020-09-15 17:27:32 --> URI Class Initialized
INFO - 2020-09-15 17:27:32 --> Router Class Initialized
INFO - 2020-09-15 17:27:32 --> Output Class Initialized
INFO - 2020-09-15 17:27:32 --> Security Class Initialized
DEBUG - 2020-09-15 17:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:27:32 --> Input Class Initialized
INFO - 2020-09-15 17:27:32 --> Language Class Initialized
INFO - 2020-09-15 17:27:32 --> Loader Class Initialized
INFO - 2020-09-15 17:27:32 --> Helper loaded: url_helper
INFO - 2020-09-15 17:27:32 --> Database Driver Class Initialized
INFO - 2020-09-15 17:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:27:32 --> Email Class Initialized
INFO - 2020-09-15 17:27:32 --> Controller Class Initialized
DEBUG - 2020-09-15 17:27:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:27:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:27:32 --> Model Class Initialized
INFO - 2020-09-15 17:27:32 --> Model Class Initialized
ERROR - 2020-09-15 17:27:32 --> Query error: Commands out of sync; you can't run this command now - Invalid query: CALL sale_rep_list_by_id(29)
INFO - 2020-09-15 17:27:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 17:27:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:27:57 --> Config Class Initialized
INFO - 2020-09-15 17:27:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:27:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:27:57 --> Utf8 Class Initialized
INFO - 2020-09-15 17:27:57 --> URI Class Initialized
INFO - 2020-09-15 17:27:57 --> Router Class Initialized
INFO - 2020-09-15 17:27:57 --> Output Class Initialized
INFO - 2020-09-15 17:27:57 --> Security Class Initialized
DEBUG - 2020-09-15 17:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:27:57 --> Input Class Initialized
INFO - 2020-09-15 17:27:57 --> Language Class Initialized
INFO - 2020-09-15 17:27:57 --> Loader Class Initialized
INFO - 2020-09-15 17:27:57 --> Helper loaded: url_helper
INFO - 2020-09-15 17:27:57 --> Database Driver Class Initialized
INFO - 2020-09-15 17:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:27:57 --> Email Class Initialized
INFO - 2020-09-15 17:27:57 --> Controller Class Initialized
DEBUG - 2020-09-15 17:27:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:27:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:27:57 --> Model Class Initialized
INFO - 2020-09-15 17:27:57 --> Model Class Initialized
INFO - 2020-09-15 17:27:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:27:57 --> Final output sent to browser
DEBUG - 2020-09-15 17:27:57 --> Total execution time: 0.0223
ERROR - 2020-09-15 17:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:28:38 --> Config Class Initialized
INFO - 2020-09-15 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:38 --> Utf8 Class Initialized
INFO - 2020-09-15 17:28:38 --> URI Class Initialized
INFO - 2020-09-15 17:28:38 --> Router Class Initialized
INFO - 2020-09-15 17:28:38 --> Output Class Initialized
INFO - 2020-09-15 17:28:38 --> Security Class Initialized
DEBUG - 2020-09-15 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:38 --> Input Class Initialized
INFO - 2020-09-15 17:28:38 --> Language Class Initialized
INFO - 2020-09-15 17:28:38 --> Loader Class Initialized
INFO - 2020-09-15 17:28:38 --> Helper loaded: url_helper
INFO - 2020-09-15 17:28:38 --> Database Driver Class Initialized
INFO - 2020-09-15 17:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:28:38 --> Email Class Initialized
INFO - 2020-09-15 17:28:38 --> Controller Class Initialized
INFO - 2020-09-15 17:28:38 --> Model Class Initialized
INFO - 2020-09-15 17:28:38 --> Model Class Initialized
INFO - 2020-09-15 17:28:38 --> Model Class Initialized
INFO - 2020-09-15 17:28:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-09-15 17:28:38 --> Final output sent to browser
DEBUG - 2020-09-15 17:28:38 --> Total execution time: 0.0417
ERROR - 2020-09-15 17:28:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:28:38 --> Config Class Initialized
INFO - 2020-09-15 17:28:38 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:28:38 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:38 --> Utf8 Class Initialized
INFO - 2020-09-15 17:28:38 --> URI Class Initialized
INFO - 2020-09-15 17:28:38 --> Router Class Initialized
INFO - 2020-09-15 17:28:38 --> Output Class Initialized
INFO - 2020-09-15 17:28:38 --> Security Class Initialized
DEBUG - 2020-09-15 17:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:38 --> Input Class Initialized
INFO - 2020-09-15 17:28:38 --> Language Class Initialized
INFO - 2020-09-15 17:28:38 --> Loader Class Initialized
INFO - 2020-09-15 17:28:38 --> Helper loaded: url_helper
INFO - 2020-09-15 17:28:38 --> Database Driver Class Initialized
INFO - 2020-09-15 17:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:28:38 --> Email Class Initialized
INFO - 2020-09-15 17:28:38 --> Controller Class Initialized
INFO - 2020-09-15 17:28:38 --> Model Class Initialized
INFO - 2020-09-15 17:28:38 --> Model Class Initialized
INFO - 2020-09-15 17:28:38 --> Final output sent to browser
DEBUG - 2020-09-15 17:28:38 --> Total execution time: 0.0395
ERROR - 2020-09-15 17:28:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:28:53 --> Config Class Initialized
INFO - 2020-09-15 17:28:53 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:28:53 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:53 --> Utf8 Class Initialized
INFO - 2020-09-15 17:28:53 --> URI Class Initialized
DEBUG - 2020-09-15 17:28:53 --> No URI present. Default controller set.
INFO - 2020-09-15 17:28:53 --> Router Class Initialized
INFO - 2020-09-15 17:28:53 --> Output Class Initialized
INFO - 2020-09-15 17:28:53 --> Security Class Initialized
DEBUG - 2020-09-15 17:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:53 --> Input Class Initialized
INFO - 2020-09-15 17:28:53 --> Language Class Initialized
INFO - 2020-09-15 17:28:53 --> Loader Class Initialized
INFO - 2020-09-15 17:28:53 --> Helper loaded: url_helper
INFO - 2020-09-15 17:28:53 --> Database Driver Class Initialized
INFO - 2020-09-15 17:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:28:53 --> Email Class Initialized
INFO - 2020-09-15 17:28:53 --> Controller Class Initialized
INFO - 2020-09-15 17:28:53 --> Model Class Initialized
INFO - 2020-09-15 17:28:53 --> Model Class Initialized
DEBUG - 2020-09-15 17:28:53 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:28:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-09-15 17:28:53 --> Final output sent to browser
DEBUG - 2020-09-15 17:28:53 --> Total execution time: 0.0206
ERROR - 2020-09-15 17:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-09-15 17:28:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:28:55 --> Config Class Initialized
INFO - 2020-09-15 17:28:55 --> Hooks Class Initialized
INFO - 2020-09-15 17:28:55 --> Config Class Initialized
INFO - 2020-09-15 17:28:55 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:28:55 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:55 --> Utf8 Class Initialized
DEBUG - 2020-09-15 17:28:55 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:55 --> Utf8 Class Initialized
INFO - 2020-09-15 17:28:55 --> URI Class Initialized
INFO - 2020-09-15 17:28:55 --> URI Class Initialized
INFO - 2020-09-15 17:28:55 --> Router Class Initialized
INFO - 2020-09-15 17:28:55 --> Router Class Initialized
INFO - 2020-09-15 17:28:55 --> Output Class Initialized
INFO - 2020-09-15 17:28:55 --> Output Class Initialized
INFO - 2020-09-15 17:28:55 --> Security Class Initialized
INFO - 2020-09-15 17:28:55 --> Security Class Initialized
DEBUG - 2020-09-15 17:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:55 --> Input Class Initialized
DEBUG - 2020-09-15 17:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:55 --> Input Class Initialized
INFO - 2020-09-15 17:28:55 --> Language Class Initialized
INFO - 2020-09-15 17:28:55 --> Language Class Initialized
INFO - 2020-09-15 17:28:55 --> Loader Class Initialized
INFO - 2020-09-15 17:28:55 --> Loader Class Initialized
INFO - 2020-09-15 17:28:55 --> Helper loaded: url_helper
INFO - 2020-09-15 17:28:55 --> Helper loaded: url_helper
INFO - 2020-09-15 17:28:55 --> Database Driver Class Initialized
INFO - 2020-09-15 17:28:55 --> Database Driver Class Initialized
INFO - 2020-09-15 17:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:28:55 --> Email Class Initialized
INFO - 2020-09-15 17:28:55 --> Controller Class Initialized
INFO - 2020-09-15 17:28:55 --> Model Class Initialized
INFO - 2020-09-15 17:28:55 --> Model Class Initialized
DEBUG - 2020-09-15 17:28:55 --> Session class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:28:55 --> Email Class Initialized
INFO - 2020-09-15 17:28:55 --> Controller Class Initialized
INFO - 2020-09-15 17:28:55 --> Model Class Initialized
INFO - 2020-09-15 17:28:55 --> Model Class Initialized
DEBUG - 2020-09-15 17:28:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:28:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:28:55 --> Model Class Initialized
INFO - 2020-09-15 17:28:55 --> Final output sent to browser
DEBUG - 2020-09-15 17:28:55 --> Total execution time: 0.0268
ERROR - 2020-09-15 17:28:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:28:56 --> Config Class Initialized
INFO - 2020-09-15 17:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:56 --> Utf8 Class Initialized
INFO - 2020-09-15 17:28:56 --> URI Class Initialized
INFO - 2020-09-15 17:28:56 --> Router Class Initialized
INFO - 2020-09-15 17:28:56 --> Output Class Initialized
INFO - 2020-09-15 17:28:56 --> Security Class Initialized
DEBUG - 2020-09-15 17:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:56 --> Input Class Initialized
INFO - 2020-09-15 17:28:56 --> Language Class Initialized
INFO - 2020-09-15 17:28:56 --> Loader Class Initialized
INFO - 2020-09-15 17:28:56 --> Helper loaded: url_helper
INFO - 2020-09-15 17:28:56 --> Database Driver Class Initialized
INFO - 2020-09-15 17:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:28:56 --> Email Class Initialized
INFO - 2020-09-15 17:28:56 --> Controller Class Initialized
DEBUG - 2020-09-15 17:28:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:28:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:28:56 --> Model Class Initialized
INFO - 2020-09-15 17:28:56 --> Model Class Initialized
INFO - 2020-09-15 17:28:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 17:28:56 --> Final output sent to browser
DEBUG - 2020-09-15 17:28:56 --> Total execution time: 0.0225
ERROR - 2020-09-15 17:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:28:59 --> Config Class Initialized
INFO - 2020-09-15 17:28:59 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:28:59 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:28:59 --> Utf8 Class Initialized
INFO - 2020-09-15 17:28:59 --> URI Class Initialized
INFO - 2020-09-15 17:28:59 --> Router Class Initialized
INFO - 2020-09-15 17:28:59 --> Output Class Initialized
INFO - 2020-09-15 17:28:59 --> Security Class Initialized
DEBUG - 2020-09-15 17:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:28:59 --> Input Class Initialized
INFO - 2020-09-15 17:28:59 --> Language Class Initialized
INFO - 2020-09-15 17:28:59 --> Loader Class Initialized
INFO - 2020-09-15 17:28:59 --> Helper loaded: url_helper
INFO - 2020-09-15 17:29:00 --> Database Driver Class Initialized
INFO - 2020-09-15 17:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:29:00 --> Email Class Initialized
INFO - 2020-09-15 17:29:00 --> Controller Class Initialized
DEBUG - 2020-09-15 17:29:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:29:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:29:00 --> Model Class Initialized
INFO - 2020-09-15 17:29:00 --> Model Class Initialized
INFO - 2020-09-15 17:29:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:29:00 --> Final output sent to browser
DEBUG - 2020-09-15 17:29:00 --> Total execution time: 0.0227
ERROR - 2020-09-15 17:29:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:29:15 --> Config Class Initialized
INFO - 2020-09-15 17:29:15 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:29:15 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:29:15 --> Utf8 Class Initialized
INFO - 2020-09-15 17:29:15 --> URI Class Initialized
INFO - 2020-09-15 17:29:15 --> Router Class Initialized
INFO - 2020-09-15 17:29:15 --> Output Class Initialized
INFO - 2020-09-15 17:29:15 --> Security Class Initialized
DEBUG - 2020-09-15 17:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:29:15 --> Input Class Initialized
INFO - 2020-09-15 17:29:15 --> Language Class Initialized
INFO - 2020-09-15 17:29:15 --> Loader Class Initialized
INFO - 2020-09-15 17:29:15 --> Helper loaded: url_helper
INFO - 2020-09-15 17:29:15 --> Database Driver Class Initialized
INFO - 2020-09-15 17:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:29:15 --> Email Class Initialized
INFO - 2020-09-15 17:29:15 --> Controller Class Initialized
DEBUG - 2020-09-15 17:29:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:29:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:29:15 --> Model Class Initialized
INFO - 2020-09-15 17:29:15 --> Model Class Initialized
INFO - 2020-09-15 17:29:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:29:15 --> Final output sent to browser
DEBUG - 2020-09-15 17:29:15 --> Total execution time: 0.0221
ERROR - 2020-09-15 17:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:29:18 --> Config Class Initialized
INFO - 2020-09-15 17:29:18 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:29:18 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:29:18 --> Utf8 Class Initialized
INFO - 2020-09-15 17:29:18 --> URI Class Initialized
INFO - 2020-09-15 17:29:18 --> Router Class Initialized
INFO - 2020-09-15 17:29:18 --> Output Class Initialized
INFO - 2020-09-15 17:29:18 --> Security Class Initialized
DEBUG - 2020-09-15 17:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:29:18 --> Input Class Initialized
INFO - 2020-09-15 17:29:18 --> Language Class Initialized
INFO - 2020-09-15 17:29:18 --> Loader Class Initialized
INFO - 2020-09-15 17:29:18 --> Helper loaded: url_helper
INFO - 2020-09-15 17:29:18 --> Database Driver Class Initialized
INFO - 2020-09-15 17:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:29:18 --> Email Class Initialized
INFO - 2020-09-15 17:29:18 --> Controller Class Initialized
DEBUG - 2020-09-15 17:29:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:29:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:29:18 --> Model Class Initialized
INFO - 2020-09-15 17:29:18 --> Model Class Initialized
INFO - 2020-09-15 17:29:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 17:29:18 --> Final output sent to browser
DEBUG - 2020-09-15 17:29:18 --> Total execution time: 0.0340
ERROR - 2020-09-15 17:29:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:29:25 --> Config Class Initialized
INFO - 2020-09-15 17:29:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:29:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:29:25 --> Utf8 Class Initialized
INFO - 2020-09-15 17:29:25 --> URI Class Initialized
INFO - 2020-09-15 17:29:25 --> Router Class Initialized
INFO - 2020-09-15 17:29:25 --> Output Class Initialized
INFO - 2020-09-15 17:29:25 --> Security Class Initialized
DEBUG - 2020-09-15 17:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:29:25 --> Input Class Initialized
INFO - 2020-09-15 17:29:25 --> Language Class Initialized
INFO - 2020-09-15 17:29:25 --> Loader Class Initialized
INFO - 2020-09-15 17:29:25 --> Helper loaded: url_helper
INFO - 2020-09-15 17:29:25 --> Database Driver Class Initialized
INFO - 2020-09-15 17:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:29:25 --> Email Class Initialized
INFO - 2020-09-15 17:29:25 --> Controller Class Initialized
DEBUG - 2020-09-15 17:29:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:29:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:29:25 --> Model Class Initialized
INFO - 2020-09-15 17:29:25 --> Model Class Initialized
INFO - 2020-09-15 17:29:25 --> Model Class Initialized
INFO - 2020-09-15 17:29:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:29:25 --> Final output sent to browser
DEBUG - 2020-09-15 17:29:25 --> Total execution time: 0.0863
ERROR - 2020-09-15 17:31:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:31:49 --> Config Class Initialized
INFO - 2020-09-15 17:31:49 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:31:49 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:31:49 --> Utf8 Class Initialized
INFO - 2020-09-15 17:31:49 --> URI Class Initialized
INFO - 2020-09-15 17:31:49 --> Router Class Initialized
INFO - 2020-09-15 17:31:49 --> Output Class Initialized
INFO - 2020-09-15 17:31:49 --> Security Class Initialized
DEBUG - 2020-09-15 17:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:31:49 --> Input Class Initialized
INFO - 2020-09-15 17:31:49 --> Language Class Initialized
INFO - 2020-09-15 17:31:49 --> Loader Class Initialized
INFO - 2020-09-15 17:31:49 --> Helper loaded: url_helper
INFO - 2020-09-15 17:31:49 --> Database Driver Class Initialized
INFO - 2020-09-15 17:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:31:49 --> Email Class Initialized
INFO - 2020-09-15 17:31:49 --> Controller Class Initialized
DEBUG - 2020-09-15 17:31:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:31:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:31:49 --> Model Class Initialized
INFO - 2020-09-15 17:31:49 --> Model Class Initialized
ERROR - 2020-09-15 17:31:49 --> Query error: Incorrect number of arguments for PROCEDURE purpu1ex_carsm.sale_representative_master_list; expected 0, got 1 - Invalid query: CALL sale_representative_master_list(29)
INFO - 2020-09-15 17:31:49 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-09-15 17:32:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:32:57 --> Config Class Initialized
INFO - 2020-09-15 17:32:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:32:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:32:57 --> Utf8 Class Initialized
INFO - 2020-09-15 17:32:57 --> URI Class Initialized
INFO - 2020-09-15 17:32:57 --> Router Class Initialized
INFO - 2020-09-15 17:32:57 --> Output Class Initialized
INFO - 2020-09-15 17:32:57 --> Security Class Initialized
DEBUG - 2020-09-15 17:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:32:57 --> Input Class Initialized
INFO - 2020-09-15 17:32:57 --> Language Class Initialized
INFO - 2020-09-15 17:32:57 --> Loader Class Initialized
INFO - 2020-09-15 17:32:57 --> Helper loaded: url_helper
INFO - 2020-09-15 17:32:57 --> Database Driver Class Initialized
INFO - 2020-09-15 17:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:32:57 --> Email Class Initialized
INFO - 2020-09-15 17:32:57 --> Controller Class Initialized
DEBUG - 2020-09-15 17:32:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:32:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:32:57 --> Model Class Initialized
INFO - 2020-09-15 17:32:57 --> Model Class Initialized
INFO - 2020-09-15 17:32:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:32:57 --> Final output sent to browser
DEBUG - 2020-09-15 17:32:57 --> Total execution time: 0.0246
ERROR - 2020-09-15 17:33:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:33:06 --> Config Class Initialized
INFO - 2020-09-15 17:33:06 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:33:06 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:33:06 --> Utf8 Class Initialized
INFO - 2020-09-15 17:33:06 --> URI Class Initialized
INFO - 2020-09-15 17:33:06 --> Router Class Initialized
INFO - 2020-09-15 17:33:06 --> Output Class Initialized
INFO - 2020-09-15 17:33:06 --> Security Class Initialized
DEBUG - 2020-09-15 17:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:33:06 --> Input Class Initialized
INFO - 2020-09-15 17:33:06 --> Language Class Initialized
INFO - 2020-09-15 17:33:06 --> Loader Class Initialized
INFO - 2020-09-15 17:33:06 --> Helper loaded: url_helper
INFO - 2020-09-15 17:33:06 --> Database Driver Class Initialized
INFO - 2020-09-15 17:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:33:06 --> Email Class Initialized
INFO - 2020-09-15 17:33:06 --> Controller Class Initialized
DEBUG - 2020-09-15 17:33:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:33:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:33:06 --> Model Class Initialized
INFO - 2020-09-15 17:33:06 --> Model Class Initialized
INFO - 2020-09-15 17:33:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 17:33:06 --> Final output sent to browser
DEBUG - 2020-09-15 17:33:06 --> Total execution time: 0.0230
ERROR - 2020-09-15 17:33:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:33:10 --> Config Class Initialized
INFO - 2020-09-15 17:33:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:33:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:33:10 --> Utf8 Class Initialized
INFO - 2020-09-15 17:33:10 --> URI Class Initialized
INFO - 2020-09-15 17:33:10 --> Router Class Initialized
INFO - 2020-09-15 17:33:10 --> Output Class Initialized
INFO - 2020-09-15 17:33:10 --> Security Class Initialized
DEBUG - 2020-09-15 17:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:33:10 --> Input Class Initialized
INFO - 2020-09-15 17:33:10 --> Language Class Initialized
INFO - 2020-09-15 17:33:10 --> Loader Class Initialized
INFO - 2020-09-15 17:33:10 --> Helper loaded: url_helper
INFO - 2020-09-15 17:33:10 --> Database Driver Class Initialized
INFO - 2020-09-15 17:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:33:10 --> Email Class Initialized
INFO - 2020-09-15 17:33:10 --> Controller Class Initialized
DEBUG - 2020-09-15 17:33:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:33:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:33:10 --> Model Class Initialized
INFO - 2020-09-15 17:33:10 --> Model Class Initialized
INFO - 2020-09-15 17:33:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:33:10 --> Final output sent to browser
DEBUG - 2020-09-15 17:33:10 --> Total execution time: 0.0206
ERROR - 2020-09-15 17:33:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:33:13 --> Config Class Initialized
INFO - 2020-09-15 17:33:13 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:33:13 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:33:13 --> Utf8 Class Initialized
INFO - 2020-09-15 17:33:13 --> URI Class Initialized
INFO - 2020-09-15 17:33:13 --> Router Class Initialized
INFO - 2020-09-15 17:33:13 --> Output Class Initialized
INFO - 2020-09-15 17:33:13 --> Security Class Initialized
DEBUG - 2020-09-15 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:33:13 --> Input Class Initialized
INFO - 2020-09-15 17:33:13 --> Language Class Initialized
INFO - 2020-09-15 17:33:13 --> Loader Class Initialized
INFO - 2020-09-15 17:33:13 --> Helper loaded: url_helper
INFO - 2020-09-15 17:33:13 --> Database Driver Class Initialized
INFO - 2020-09-15 17:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:33:13 --> Email Class Initialized
INFO - 2020-09-15 17:33:13 --> Controller Class Initialized
DEBUG - 2020-09-15 17:33:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:33:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:33:13 --> Model Class Initialized
INFO - 2020-09-15 17:33:13 --> Model Class Initialized
INFO - 2020-09-15 17:33:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-09-15 17:33:13 --> Final output sent to browser
DEBUG - 2020-09-15 17:33:13 --> Total execution time: 0.0170
ERROR - 2020-09-15 17:33:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:33:36 --> Config Class Initialized
INFO - 2020-09-15 17:33:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:33:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:33:36 --> Utf8 Class Initialized
INFO - 2020-09-15 17:33:36 --> URI Class Initialized
INFO - 2020-09-15 17:33:36 --> Router Class Initialized
INFO - 2020-09-15 17:33:36 --> Output Class Initialized
INFO - 2020-09-15 17:33:36 --> Security Class Initialized
DEBUG - 2020-09-15 17:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:33:36 --> Input Class Initialized
INFO - 2020-09-15 17:33:36 --> Language Class Initialized
INFO - 2020-09-15 17:33:36 --> Loader Class Initialized
INFO - 2020-09-15 17:33:36 --> Helper loaded: url_helper
INFO - 2020-09-15 17:33:36 --> Database Driver Class Initialized
INFO - 2020-09-15 17:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:33:36 --> Email Class Initialized
INFO - 2020-09-15 17:33:36 --> Controller Class Initialized
DEBUG - 2020-09-15 17:33:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:33:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:33:36 --> Model Class Initialized
INFO - 2020-09-15 17:33:36 --> Model Class Initialized
INFO - 2020-09-15 17:33:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:33:36 --> Final output sent to browser
DEBUG - 2020-09-15 17:33:36 --> Total execution time: 0.0341
ERROR - 2020-09-15 17:33:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:33:50 --> Config Class Initialized
INFO - 2020-09-15 17:33:50 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:33:50 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:33:50 --> Utf8 Class Initialized
INFO - 2020-09-15 17:33:50 --> URI Class Initialized
INFO - 2020-09-15 17:33:50 --> Router Class Initialized
INFO - 2020-09-15 17:33:50 --> Output Class Initialized
INFO - 2020-09-15 17:33:50 --> Security Class Initialized
DEBUG - 2020-09-15 17:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:33:50 --> Input Class Initialized
INFO - 2020-09-15 17:33:50 --> Language Class Initialized
INFO - 2020-09-15 17:33:50 --> Loader Class Initialized
INFO - 2020-09-15 17:33:50 --> Helper loaded: url_helper
INFO - 2020-09-15 17:33:50 --> Database Driver Class Initialized
INFO - 2020-09-15 17:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:33:50 --> Email Class Initialized
INFO - 2020-09-15 17:33:50 --> Controller Class Initialized
DEBUG - 2020-09-15 17:33:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:33:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:33:50 --> Model Class Initialized
INFO - 2020-09-15 17:33:50 --> Model Class Initialized
INFO - 2020-09-15 17:33:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:33:50 --> Final output sent to browser
DEBUG - 2020-09-15 17:33:50 --> Total execution time: 0.0213
ERROR - 2020-09-15 17:34:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:34:22 --> Config Class Initialized
INFO - 2020-09-15 17:34:22 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:34:22 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:34:22 --> Utf8 Class Initialized
INFO - 2020-09-15 17:34:22 --> URI Class Initialized
INFO - 2020-09-15 17:34:22 --> Router Class Initialized
INFO - 2020-09-15 17:34:22 --> Output Class Initialized
INFO - 2020-09-15 17:34:22 --> Security Class Initialized
DEBUG - 2020-09-15 17:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:34:22 --> Input Class Initialized
INFO - 2020-09-15 17:34:22 --> Language Class Initialized
INFO - 2020-09-15 17:34:22 --> Loader Class Initialized
INFO - 2020-09-15 17:34:22 --> Helper loaded: url_helper
INFO - 2020-09-15 17:34:22 --> Database Driver Class Initialized
INFO - 2020-09-15 17:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:34:22 --> Email Class Initialized
INFO - 2020-09-15 17:34:22 --> Controller Class Initialized
DEBUG - 2020-09-15 17:34:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:34:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:34:22 --> Model Class Initialized
INFO - 2020-09-15 17:34:22 --> Model Class Initialized
INFO - 2020-09-15 17:34:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:34:22 --> Final output sent to browser
DEBUG - 2020-09-15 17:34:22 --> Total execution time: 0.0229
ERROR - 2020-09-15 17:34:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:34:28 --> Config Class Initialized
INFO - 2020-09-15 17:34:28 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:34:28 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:34:28 --> Utf8 Class Initialized
INFO - 2020-09-15 17:34:28 --> URI Class Initialized
INFO - 2020-09-15 17:34:28 --> Router Class Initialized
INFO - 2020-09-15 17:34:28 --> Output Class Initialized
INFO - 2020-09-15 17:34:28 --> Security Class Initialized
DEBUG - 2020-09-15 17:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:34:28 --> Input Class Initialized
INFO - 2020-09-15 17:34:28 --> Language Class Initialized
INFO - 2020-09-15 17:34:28 --> Loader Class Initialized
INFO - 2020-09-15 17:34:28 --> Helper loaded: url_helper
INFO - 2020-09-15 17:34:28 --> Database Driver Class Initialized
INFO - 2020-09-15 17:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:34:28 --> Email Class Initialized
INFO - 2020-09-15 17:34:28 --> Controller Class Initialized
DEBUG - 2020-09-15 17:34:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:34:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:34:28 --> Model Class Initialized
INFO - 2020-09-15 17:34:28 --> Model Class Initialized
INFO - 2020-09-15 17:34:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 17:34:28 --> Final output sent to browser
DEBUG - 2020-09-15 17:34:28 --> Total execution time: 0.0257
ERROR - 2020-09-15 17:34:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:34:32 --> Config Class Initialized
INFO - 2020-09-15 17:34:32 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:34:32 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:34:32 --> Utf8 Class Initialized
INFO - 2020-09-15 17:34:32 --> URI Class Initialized
INFO - 2020-09-15 17:34:32 --> Router Class Initialized
INFO - 2020-09-15 17:34:32 --> Output Class Initialized
INFO - 2020-09-15 17:34:32 --> Security Class Initialized
DEBUG - 2020-09-15 17:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:34:32 --> Input Class Initialized
INFO - 2020-09-15 17:34:32 --> Language Class Initialized
INFO - 2020-09-15 17:34:32 --> Loader Class Initialized
INFO - 2020-09-15 17:34:32 --> Helper loaded: url_helper
INFO - 2020-09-15 17:34:32 --> Database Driver Class Initialized
INFO - 2020-09-15 17:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:34:32 --> Email Class Initialized
INFO - 2020-09-15 17:34:32 --> Controller Class Initialized
DEBUG - 2020-09-15 17:34:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:34:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:34:32 --> Model Class Initialized
INFO - 2020-09-15 17:34:32 --> Model Class Initialized
INFO - 2020-09-15 17:34:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:34:32 --> Final output sent to browser
DEBUG - 2020-09-15 17:34:32 --> Total execution time: 0.0231
ERROR - 2020-09-15 17:46:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:46:11 --> Config Class Initialized
INFO - 2020-09-15 17:46:11 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:46:11 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:46:11 --> Utf8 Class Initialized
INFO - 2020-09-15 17:46:11 --> URI Class Initialized
INFO - 2020-09-15 17:46:11 --> Router Class Initialized
INFO - 2020-09-15 17:46:11 --> Output Class Initialized
INFO - 2020-09-15 17:46:11 --> Security Class Initialized
DEBUG - 2020-09-15 17:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:46:11 --> Input Class Initialized
INFO - 2020-09-15 17:46:11 --> Language Class Initialized
INFO - 2020-09-15 17:46:11 --> Loader Class Initialized
INFO - 2020-09-15 17:46:11 --> Helper loaded: url_helper
INFO - 2020-09-15 17:46:11 --> Database Driver Class Initialized
INFO - 2020-09-15 17:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:46:11 --> Email Class Initialized
INFO - 2020-09-15 17:46:11 --> Controller Class Initialized
DEBUG - 2020-09-15 17:46:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:46:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:46:11 --> Model Class Initialized
INFO - 2020-09-15 17:46:11 --> Model Class Initialized
INFO - 2020-09-15 17:46:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:46:11 --> Final output sent to browser
DEBUG - 2020-09-15 17:46:11 --> Total execution time: 0.0240
ERROR - 2020-09-15 17:46:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:46:18 --> Config Class Initialized
INFO - 2020-09-15 17:46:18 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:46:18 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:46:18 --> Utf8 Class Initialized
INFO - 2020-09-15 17:46:18 --> URI Class Initialized
INFO - 2020-09-15 17:46:18 --> Router Class Initialized
INFO - 2020-09-15 17:46:18 --> Output Class Initialized
INFO - 2020-09-15 17:46:18 --> Security Class Initialized
DEBUG - 2020-09-15 17:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:46:18 --> Input Class Initialized
INFO - 2020-09-15 17:46:18 --> Language Class Initialized
INFO - 2020-09-15 17:46:18 --> Loader Class Initialized
INFO - 2020-09-15 17:46:18 --> Helper loaded: url_helper
INFO - 2020-09-15 17:46:18 --> Database Driver Class Initialized
INFO - 2020-09-15 17:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:46:18 --> Email Class Initialized
INFO - 2020-09-15 17:46:18 --> Controller Class Initialized
DEBUG - 2020-09-15 17:46:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:46:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:46:18 --> Model Class Initialized
INFO - 2020-09-15 17:46:18 --> Model Class Initialized
ERROR - 2020-09-15 17:46:18 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-09-15 17:46:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:46:18 --> Final output sent to browser
DEBUG - 2020-09-15 17:46:18 --> Total execution time: 0.0275
ERROR - 2020-09-15 17:49:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:49:22 --> Config Class Initialized
INFO - 2020-09-15 17:49:22 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:49:22 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:49:22 --> Utf8 Class Initialized
INFO - 2020-09-15 17:49:22 --> URI Class Initialized
INFO - 2020-09-15 17:49:22 --> Router Class Initialized
INFO - 2020-09-15 17:49:22 --> Output Class Initialized
INFO - 2020-09-15 17:49:22 --> Security Class Initialized
DEBUG - 2020-09-15 17:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:49:22 --> Input Class Initialized
INFO - 2020-09-15 17:49:22 --> Language Class Initialized
INFO - 2020-09-15 17:49:22 --> Loader Class Initialized
INFO - 2020-09-15 17:49:22 --> Helper loaded: url_helper
INFO - 2020-09-15 17:49:22 --> Database Driver Class Initialized
INFO - 2020-09-15 17:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:49:22 --> Email Class Initialized
INFO - 2020-09-15 17:49:22 --> Controller Class Initialized
DEBUG - 2020-09-15 17:49:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:49:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:49:22 --> Model Class Initialized
INFO - 2020-09-15 17:49:22 --> Model Class Initialized
ERROR - 2020-09-15 17:49:23 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-09-15 17:49:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:49:23 --> Final output sent to browser
DEBUG - 2020-09-15 17:49:23 --> Total execution time: 0.0309
ERROR - 2020-09-15 17:50:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:50:09 --> Config Class Initialized
INFO - 2020-09-15 17:50:09 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:50:09 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:50:09 --> Utf8 Class Initialized
INFO - 2020-09-15 17:50:09 --> URI Class Initialized
INFO - 2020-09-15 17:50:09 --> Router Class Initialized
INFO - 2020-09-15 17:50:09 --> Output Class Initialized
INFO - 2020-09-15 17:50:09 --> Security Class Initialized
DEBUG - 2020-09-15 17:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:50:09 --> Input Class Initialized
INFO - 2020-09-15 17:50:09 --> Language Class Initialized
INFO - 2020-09-15 17:50:09 --> Loader Class Initialized
INFO - 2020-09-15 17:50:09 --> Helper loaded: url_helper
INFO - 2020-09-15 17:50:09 --> Database Driver Class Initialized
INFO - 2020-09-15 17:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:50:09 --> Email Class Initialized
INFO - 2020-09-15 17:50:09 --> Controller Class Initialized
DEBUG - 2020-09-15 17:50:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:50:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:50:09 --> Model Class Initialized
INFO - 2020-09-15 17:50:09 --> Model Class Initialized
INFO - 2020-09-15 17:50:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-09-15 17:50:09 --> Final output sent to browser
DEBUG - 2020-09-15 17:50:09 --> Total execution time: 0.0220
ERROR - 2020-09-15 17:50:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:50:21 --> Config Class Initialized
INFO - 2020-09-15 17:50:21 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:50:21 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:50:21 --> Utf8 Class Initialized
INFO - 2020-09-15 17:50:21 --> URI Class Initialized
INFO - 2020-09-15 17:50:21 --> Router Class Initialized
INFO - 2020-09-15 17:50:21 --> Output Class Initialized
INFO - 2020-09-15 17:50:21 --> Security Class Initialized
DEBUG - 2020-09-15 17:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:50:21 --> Input Class Initialized
INFO - 2020-09-15 17:50:21 --> Language Class Initialized
INFO - 2020-09-15 17:50:21 --> Loader Class Initialized
INFO - 2020-09-15 17:50:21 --> Helper loaded: url_helper
INFO - 2020-09-15 17:50:21 --> Database Driver Class Initialized
INFO - 2020-09-15 17:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:50:21 --> Email Class Initialized
INFO - 2020-09-15 17:50:21 --> Controller Class Initialized
DEBUG - 2020-09-15 17:50:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:50:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:50:21 --> Model Class Initialized
INFO - 2020-09-15 17:50:21 --> Model Class Initialized
INFO - 2020-09-15 17:50:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 17:50:21 --> Final output sent to browser
DEBUG - 2020-09-15 17:50:21 --> Total execution time: 0.0331
ERROR - 2020-09-15 17:50:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:50:36 --> Config Class Initialized
INFO - 2020-09-15 17:50:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:50:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:50:36 --> Utf8 Class Initialized
INFO - 2020-09-15 17:50:36 --> URI Class Initialized
INFO - 2020-09-15 17:50:36 --> Router Class Initialized
INFO - 2020-09-15 17:50:36 --> Output Class Initialized
INFO - 2020-09-15 17:50:36 --> Security Class Initialized
DEBUG - 2020-09-15 17:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:50:36 --> Input Class Initialized
INFO - 2020-09-15 17:50:36 --> Language Class Initialized
INFO - 2020-09-15 17:50:36 --> Loader Class Initialized
INFO - 2020-09-15 17:50:36 --> Helper loaded: url_helper
INFO - 2020-09-15 17:50:36 --> Database Driver Class Initialized
INFO - 2020-09-15 17:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:50:36 --> Email Class Initialized
INFO - 2020-09-15 17:50:36 --> Controller Class Initialized
DEBUG - 2020-09-15 17:50:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:50:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:50:36 --> Model Class Initialized
INFO - 2020-09-15 17:50:36 --> Model Class Initialized
INFO - 2020-09-15 17:50:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-09-15 17:50:36 --> Final output sent to browser
DEBUG - 2020-09-15 17:50:36 --> Total execution time: 0.0198
ERROR - 2020-09-15 17:51:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:51:28 --> Config Class Initialized
INFO - 2020-09-15 17:51:28 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:51:28 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:51:28 --> Utf8 Class Initialized
INFO - 2020-09-15 17:51:28 --> URI Class Initialized
INFO - 2020-09-15 17:51:28 --> Router Class Initialized
INFO - 2020-09-15 17:51:28 --> Output Class Initialized
INFO - 2020-09-15 17:51:28 --> Security Class Initialized
DEBUG - 2020-09-15 17:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:51:28 --> Input Class Initialized
INFO - 2020-09-15 17:51:28 --> Language Class Initialized
INFO - 2020-09-15 17:51:28 --> Loader Class Initialized
INFO - 2020-09-15 17:51:28 --> Helper loaded: url_helper
INFO - 2020-09-15 17:51:28 --> Database Driver Class Initialized
INFO - 2020-09-15 17:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:51:28 --> Email Class Initialized
INFO - 2020-09-15 17:51:28 --> Controller Class Initialized
DEBUG - 2020-09-15 17:51:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:51:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:51:28 --> Model Class Initialized
INFO - 2020-09-15 17:51:28 --> Model Class Initialized
INFO - 2020-09-15 17:51:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-09-15 17:51:28 --> Final output sent to browser
DEBUG - 2020-09-15 17:51:28 --> Total execution time: 0.0339
ERROR - 2020-09-15 17:52:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:52:18 --> Config Class Initialized
INFO - 2020-09-15 17:52:18 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:52:18 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:52:18 --> Utf8 Class Initialized
INFO - 2020-09-15 17:52:18 --> URI Class Initialized
INFO - 2020-09-15 17:52:18 --> Router Class Initialized
INFO - 2020-09-15 17:52:18 --> Output Class Initialized
INFO - 2020-09-15 17:52:18 --> Security Class Initialized
DEBUG - 2020-09-15 17:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:52:18 --> Input Class Initialized
INFO - 2020-09-15 17:52:18 --> Language Class Initialized
INFO - 2020-09-15 17:52:18 --> Loader Class Initialized
INFO - 2020-09-15 17:52:18 --> Helper loaded: url_helper
INFO - 2020-09-15 17:52:18 --> Database Driver Class Initialized
INFO - 2020-09-15 17:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:52:18 --> Email Class Initialized
INFO - 2020-09-15 17:52:18 --> Controller Class Initialized
DEBUG - 2020-09-15 17:52:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:52:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:52:18 --> Model Class Initialized
INFO - 2020-09-15 17:52:18 --> Model Class Initialized
INFO - 2020-09-15 17:52:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 17:52:18 --> Final output sent to browser
DEBUG - 2020-09-15 17:52:18 --> Total execution time: 0.0240
ERROR - 2020-09-15 17:53:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:53:36 --> Config Class Initialized
INFO - 2020-09-15 17:53:36 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:53:36 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:53:36 --> Utf8 Class Initialized
INFO - 2020-09-15 17:53:36 --> URI Class Initialized
INFO - 2020-09-15 17:53:36 --> Router Class Initialized
INFO - 2020-09-15 17:53:36 --> Output Class Initialized
INFO - 2020-09-15 17:53:36 --> Security Class Initialized
DEBUG - 2020-09-15 17:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:53:36 --> Input Class Initialized
INFO - 2020-09-15 17:53:36 --> Language Class Initialized
INFO - 2020-09-15 17:53:36 --> Loader Class Initialized
INFO - 2020-09-15 17:53:36 --> Helper loaded: url_helper
INFO - 2020-09-15 17:53:36 --> Database Driver Class Initialized
INFO - 2020-09-15 17:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:53:36 --> Email Class Initialized
INFO - 2020-09-15 17:53:36 --> Controller Class Initialized
DEBUG - 2020-09-15 17:53:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:53:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:53:36 --> Model Class Initialized
INFO - 2020-09-15 17:53:36 --> Model Class Initialized
INFO - 2020-09-15 17:53:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:53:36 --> Final output sent to browser
DEBUG - 2020-09-15 17:53:36 --> Total execution time: 0.0267
ERROR - 2020-09-15 17:55:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:55:27 --> Config Class Initialized
INFO - 2020-09-15 17:55:27 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:55:27 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:55:27 --> Utf8 Class Initialized
INFO - 2020-09-15 17:55:27 --> URI Class Initialized
INFO - 2020-09-15 17:55:27 --> Router Class Initialized
INFO - 2020-09-15 17:55:27 --> Output Class Initialized
INFO - 2020-09-15 17:55:27 --> Security Class Initialized
DEBUG - 2020-09-15 17:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:55:27 --> Input Class Initialized
INFO - 2020-09-15 17:55:27 --> Language Class Initialized
INFO - 2020-09-15 17:55:27 --> Loader Class Initialized
INFO - 2020-09-15 17:55:27 --> Helper loaded: url_helper
INFO - 2020-09-15 17:55:27 --> Database Driver Class Initialized
INFO - 2020-09-15 17:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:55:27 --> Email Class Initialized
INFO - 2020-09-15 17:55:27 --> Controller Class Initialized
DEBUG - 2020-09-15 17:55:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:55:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:55:27 --> Model Class Initialized
INFO - 2020-09-15 17:55:27 --> Model Class Initialized
INFO - 2020-09-15 17:55:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:55:27 --> Final output sent to browser
DEBUG - 2020-09-15 17:55:27 --> Total execution time: 0.0242
ERROR - 2020-09-15 17:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:56:01 --> Config Class Initialized
INFO - 2020-09-15 17:56:01 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:56:01 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:56:01 --> Utf8 Class Initialized
INFO - 2020-09-15 17:56:01 --> URI Class Initialized
INFO - 2020-09-15 17:56:01 --> Router Class Initialized
INFO - 2020-09-15 17:56:01 --> Output Class Initialized
INFO - 2020-09-15 17:56:01 --> Security Class Initialized
DEBUG - 2020-09-15 17:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:56:01 --> Input Class Initialized
INFO - 2020-09-15 17:56:01 --> Language Class Initialized
INFO - 2020-09-15 17:56:01 --> Loader Class Initialized
INFO - 2020-09-15 17:56:01 --> Helper loaded: url_helper
INFO - 2020-09-15 17:56:01 --> Database Driver Class Initialized
INFO - 2020-09-15 17:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:56:01 --> Email Class Initialized
INFO - 2020-09-15 17:56:01 --> Controller Class Initialized
DEBUG - 2020-09-15 17:56:01 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:56:01 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:56:01 --> Model Class Initialized
INFO - 2020-09-15 17:56:01 --> Model Class Initialized
INFO - 2020-09-15 17:56:01 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:56:01 --> Final output sent to browser
DEBUG - 2020-09-15 17:56:01 --> Total execution time: 0.0234
ERROR - 2020-09-15 17:56:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 17:56:21 --> Config Class Initialized
INFO - 2020-09-15 17:56:21 --> Hooks Class Initialized
DEBUG - 2020-09-15 17:56:21 --> UTF-8 Support Enabled
INFO - 2020-09-15 17:56:21 --> Utf8 Class Initialized
INFO - 2020-09-15 17:56:21 --> URI Class Initialized
INFO - 2020-09-15 17:56:21 --> Router Class Initialized
INFO - 2020-09-15 17:56:21 --> Output Class Initialized
INFO - 2020-09-15 17:56:21 --> Security Class Initialized
DEBUG - 2020-09-15 17:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 17:56:21 --> Input Class Initialized
INFO - 2020-09-15 17:56:21 --> Language Class Initialized
INFO - 2020-09-15 17:56:21 --> Loader Class Initialized
INFO - 2020-09-15 17:56:21 --> Helper loaded: url_helper
INFO - 2020-09-15 17:56:21 --> Database Driver Class Initialized
INFO - 2020-09-15 17:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 17:56:21 --> Email Class Initialized
INFO - 2020-09-15 17:56:21 --> Controller Class Initialized
DEBUG - 2020-09-15 17:56:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 17:56:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 17:56:21 --> Model Class Initialized
INFO - 2020-09-15 17:56:21 --> Model Class Initialized
INFO - 2020-09-15 17:56:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 17:56:21 --> Final output sent to browser
DEBUG - 2020-09-15 17:56:21 --> Total execution time: 0.0252
ERROR - 2020-09-15 18:17:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:17:25 --> Config Class Initialized
INFO - 2020-09-15 18:17:25 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:17:25 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:17:25 --> Utf8 Class Initialized
INFO - 2020-09-15 18:17:25 --> URI Class Initialized
INFO - 2020-09-15 18:17:25 --> Router Class Initialized
INFO - 2020-09-15 18:17:25 --> Output Class Initialized
INFO - 2020-09-15 18:17:25 --> Security Class Initialized
DEBUG - 2020-09-15 18:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:17:25 --> Input Class Initialized
INFO - 2020-09-15 18:17:25 --> Language Class Initialized
INFO - 2020-09-15 18:17:25 --> Loader Class Initialized
INFO - 2020-09-15 18:17:25 --> Helper loaded: url_helper
INFO - 2020-09-15 18:17:25 --> Database Driver Class Initialized
INFO - 2020-09-15 18:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:17:25 --> Email Class Initialized
INFO - 2020-09-15 18:17:25 --> Controller Class Initialized
DEBUG - 2020-09-15 18:17:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:17:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:17:25 --> Model Class Initialized
INFO - 2020-09-15 18:17:25 --> Model Class Initialized
INFO - 2020-09-15 18:17:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 18:17:25 --> Final output sent to browser
DEBUG - 2020-09-15 18:17:25 --> Total execution time: 0.0242
ERROR - 2020-09-15 18:17:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:17:26 --> Config Class Initialized
INFO - 2020-09-15 18:17:26 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:17:26 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:17:26 --> Utf8 Class Initialized
INFO - 2020-09-15 18:17:26 --> URI Class Initialized
INFO - 2020-09-15 18:17:26 --> Router Class Initialized
INFO - 2020-09-15 18:17:26 --> Output Class Initialized
INFO - 2020-09-15 18:17:26 --> Security Class Initialized
DEBUG - 2020-09-15 18:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:17:26 --> Input Class Initialized
INFO - 2020-09-15 18:17:26 --> Language Class Initialized
INFO - 2020-09-15 18:17:26 --> Loader Class Initialized
INFO - 2020-09-15 18:17:26 --> Helper loaded: url_helper
INFO - 2020-09-15 18:17:26 --> Database Driver Class Initialized
INFO - 2020-09-15 18:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:17:26 --> Email Class Initialized
INFO - 2020-09-15 18:17:26 --> Controller Class Initialized
DEBUG - 2020-09-15 18:17:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:17:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:17:26 --> Model Class Initialized
INFO - 2020-09-15 18:17:26 --> Model Class Initialized
INFO - 2020-09-15 18:17:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 18:17:26 --> Final output sent to browser
DEBUG - 2020-09-15 18:17:26 --> Total execution time: 0.0196
ERROR - 2020-09-15 18:17:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:17:30 --> Config Class Initialized
INFO - 2020-09-15 18:17:30 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:17:30 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:17:30 --> Utf8 Class Initialized
INFO - 2020-09-15 18:17:30 --> URI Class Initialized
INFO - 2020-09-15 18:17:30 --> Router Class Initialized
INFO - 2020-09-15 18:17:30 --> Output Class Initialized
INFO - 2020-09-15 18:17:30 --> Security Class Initialized
DEBUG - 2020-09-15 18:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:17:30 --> Input Class Initialized
INFO - 2020-09-15 18:17:30 --> Language Class Initialized
ERROR - 2020-09-15 18:17:30 --> 404 Page Not Found: Sale_rep/rep_assign_list_for_client
ERROR - 2020-09-15 18:17:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:17:51 --> Config Class Initialized
INFO - 2020-09-15 18:17:51 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:17:51 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:17:51 --> Utf8 Class Initialized
INFO - 2020-09-15 18:17:51 --> URI Class Initialized
INFO - 2020-09-15 18:17:51 --> Router Class Initialized
INFO - 2020-09-15 18:17:51 --> Output Class Initialized
INFO - 2020-09-15 18:17:51 --> Security Class Initialized
DEBUG - 2020-09-15 18:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:17:51 --> Input Class Initialized
INFO - 2020-09-15 18:17:51 --> Language Class Initialized
INFO - 2020-09-15 18:17:51 --> Loader Class Initialized
INFO - 2020-09-15 18:17:51 --> Helper loaded: url_helper
INFO - 2020-09-15 18:17:52 --> Database Driver Class Initialized
INFO - 2020-09-15 18:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:17:52 --> Email Class Initialized
INFO - 2020-09-15 18:17:52 --> Controller Class Initialized
DEBUG - 2020-09-15 18:17:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:17:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:17:52 --> Model Class Initialized
INFO - 2020-09-15 18:17:52 --> Model Class Initialized
INFO - 2020-09-15 18:17:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 18:17:52 --> Final output sent to browser
DEBUG - 2020-09-15 18:17:52 --> Total execution time: 0.0295
ERROR - 2020-09-15 18:17:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:17:59 --> Config Class Initialized
INFO - 2020-09-15 18:17:59 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:17:59 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:17:59 --> Utf8 Class Initialized
INFO - 2020-09-15 18:17:59 --> URI Class Initialized
INFO - 2020-09-15 18:17:59 --> Router Class Initialized
INFO - 2020-09-15 18:17:59 --> Output Class Initialized
INFO - 2020-09-15 18:17:59 --> Security Class Initialized
DEBUG - 2020-09-15 18:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:17:59 --> Input Class Initialized
INFO - 2020-09-15 18:17:59 --> Language Class Initialized
INFO - 2020-09-15 18:17:59 --> Loader Class Initialized
INFO - 2020-09-15 18:17:59 --> Helper loaded: url_helper
INFO - 2020-09-15 18:17:59 --> Database Driver Class Initialized
INFO - 2020-09-15 18:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:17:59 --> Email Class Initialized
INFO - 2020-09-15 18:17:59 --> Controller Class Initialized
DEBUG - 2020-09-15 18:17:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:17:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:17:59 --> Model Class Initialized
INFO - 2020-09-15 18:17:59 --> Model Class Initialized
INFO - 2020-09-15 18:17:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:17:59 --> Final output sent to browser
DEBUG - 2020-09-15 18:17:59 --> Total execution time: 0.0176
ERROR - 2020-09-15 18:19:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:19:54 --> Config Class Initialized
INFO - 2020-09-15 18:19:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:19:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:19:54 --> Utf8 Class Initialized
INFO - 2020-09-15 18:19:54 --> URI Class Initialized
INFO - 2020-09-15 18:19:54 --> Router Class Initialized
INFO - 2020-09-15 18:19:54 --> Output Class Initialized
INFO - 2020-09-15 18:19:54 --> Security Class Initialized
DEBUG - 2020-09-15 18:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:19:54 --> Input Class Initialized
INFO - 2020-09-15 18:19:54 --> Language Class Initialized
INFO - 2020-09-15 18:19:54 --> Loader Class Initialized
INFO - 2020-09-15 18:19:54 --> Helper loaded: url_helper
INFO - 2020-09-15 18:19:54 --> Database Driver Class Initialized
INFO - 2020-09-15 18:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:19:54 --> Email Class Initialized
INFO - 2020-09-15 18:19:54 --> Controller Class Initialized
DEBUG - 2020-09-15 18:19:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:19:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:19:54 --> Model Class Initialized
INFO - 2020-09-15 18:19:54 --> Model Class Initialized
INFO - 2020-09-15 18:19:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:19:54 --> Final output sent to browser
DEBUG - 2020-09-15 18:19:54 --> Total execution time: 0.0226
ERROR - 2020-09-15 18:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:19:57 --> Config Class Initialized
INFO - 2020-09-15 18:19:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:19:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:19:57 --> Utf8 Class Initialized
INFO - 2020-09-15 18:19:57 --> URI Class Initialized
INFO - 2020-09-15 18:19:57 --> Router Class Initialized
INFO - 2020-09-15 18:19:57 --> Output Class Initialized
INFO - 2020-09-15 18:19:57 --> Security Class Initialized
DEBUG - 2020-09-15 18:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:19:57 --> Input Class Initialized
INFO - 2020-09-15 18:19:57 --> Language Class Initialized
INFO - 2020-09-15 18:19:57 --> Loader Class Initialized
INFO - 2020-09-15 18:19:57 --> Helper loaded: url_helper
INFO - 2020-09-15 18:19:57 --> Database Driver Class Initialized
INFO - 2020-09-15 18:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:19:57 --> Email Class Initialized
INFO - 2020-09-15 18:19:57 --> Controller Class Initialized
DEBUG - 2020-09-15 18:19:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:19:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:19:57 --> Model Class Initialized
INFO - 2020-09-15 18:19:57 --> Model Class Initialized
INFO - 2020-09-15 18:19:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 18:19:57 --> Final output sent to browser
DEBUG - 2020-09-15 18:19:57 --> Total execution time: 0.0270
ERROR - 2020-09-15 18:20:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:20:13 --> Config Class Initialized
INFO - 2020-09-15 18:20:13 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:20:13 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:20:13 --> Utf8 Class Initialized
INFO - 2020-09-15 18:20:13 --> URI Class Initialized
INFO - 2020-09-15 18:20:13 --> Router Class Initialized
INFO - 2020-09-15 18:20:13 --> Output Class Initialized
INFO - 2020-09-15 18:20:13 --> Security Class Initialized
DEBUG - 2020-09-15 18:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:20:13 --> Input Class Initialized
INFO - 2020-09-15 18:20:13 --> Language Class Initialized
INFO - 2020-09-15 18:20:13 --> Loader Class Initialized
INFO - 2020-09-15 18:20:13 --> Helper loaded: url_helper
INFO - 2020-09-15 18:20:13 --> Database Driver Class Initialized
INFO - 2020-09-15 18:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:20:13 --> Email Class Initialized
INFO - 2020-09-15 18:20:13 --> Controller Class Initialized
DEBUG - 2020-09-15 18:20:13 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:20:13 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:20:13 --> Model Class Initialized
INFO - 2020-09-15 18:20:13 --> Model Class Initialized
INFO - 2020-09-15 18:20:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:20:13 --> Final output sent to browser
DEBUG - 2020-09-15 18:20:13 --> Total execution time: 0.0201
ERROR - 2020-09-15 18:20:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:20:54 --> Config Class Initialized
INFO - 2020-09-15 18:20:54 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:20:54 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:20:54 --> Utf8 Class Initialized
INFO - 2020-09-15 18:20:54 --> URI Class Initialized
INFO - 2020-09-15 18:20:54 --> Router Class Initialized
INFO - 2020-09-15 18:20:54 --> Output Class Initialized
INFO - 2020-09-15 18:20:54 --> Security Class Initialized
DEBUG - 2020-09-15 18:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:20:54 --> Input Class Initialized
INFO - 2020-09-15 18:20:54 --> Language Class Initialized
INFO - 2020-09-15 18:20:54 --> Loader Class Initialized
INFO - 2020-09-15 18:20:54 --> Helper loaded: url_helper
INFO - 2020-09-15 18:20:54 --> Database Driver Class Initialized
INFO - 2020-09-15 18:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:20:54 --> Email Class Initialized
INFO - 2020-09-15 18:20:54 --> Controller Class Initialized
DEBUG - 2020-09-15 18:20:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:20:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:20:54 --> Model Class Initialized
INFO - 2020-09-15 18:20:54 --> Model Class Initialized
INFO - 2020-09-15 18:20:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:20:54 --> Final output sent to browser
DEBUG - 2020-09-15 18:20:54 --> Total execution time: 0.0195
ERROR - 2020-09-15 18:20:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:20:55 --> Config Class Initialized
INFO - 2020-09-15 18:20:55 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:20:55 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:20:55 --> Utf8 Class Initialized
INFO - 2020-09-15 18:20:55 --> URI Class Initialized
INFO - 2020-09-15 18:20:55 --> Router Class Initialized
INFO - 2020-09-15 18:20:55 --> Output Class Initialized
INFO - 2020-09-15 18:20:55 --> Security Class Initialized
DEBUG - 2020-09-15 18:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:20:55 --> Input Class Initialized
INFO - 2020-09-15 18:20:55 --> Language Class Initialized
INFO - 2020-09-15 18:20:55 --> Loader Class Initialized
INFO - 2020-09-15 18:20:55 --> Helper loaded: url_helper
INFO - 2020-09-15 18:20:55 --> Database Driver Class Initialized
INFO - 2020-09-15 18:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:20:55 --> Email Class Initialized
INFO - 2020-09-15 18:20:55 --> Controller Class Initialized
DEBUG - 2020-09-15 18:20:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:20:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:20:55 --> Model Class Initialized
INFO - 2020-09-15 18:20:55 --> Model Class Initialized
INFO - 2020-09-15 18:20:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 18:20:55 --> Final output sent to browser
DEBUG - 2020-09-15 18:20:55 --> Total execution time: 0.0343
ERROR - 2020-09-15 18:20:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:20:57 --> Config Class Initialized
INFO - 2020-09-15 18:20:57 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:20:57 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:20:57 --> Utf8 Class Initialized
INFO - 2020-09-15 18:20:57 --> URI Class Initialized
INFO - 2020-09-15 18:20:57 --> Router Class Initialized
INFO - 2020-09-15 18:20:57 --> Output Class Initialized
INFO - 2020-09-15 18:20:57 --> Security Class Initialized
DEBUG - 2020-09-15 18:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:20:57 --> Input Class Initialized
INFO - 2020-09-15 18:20:57 --> Language Class Initialized
INFO - 2020-09-15 18:20:57 --> Loader Class Initialized
INFO - 2020-09-15 18:20:57 --> Helper loaded: url_helper
INFO - 2020-09-15 18:20:57 --> Database Driver Class Initialized
INFO - 2020-09-15 18:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:20:57 --> Email Class Initialized
INFO - 2020-09-15 18:20:57 --> Controller Class Initialized
DEBUG - 2020-09-15 18:20:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:20:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:20:57 --> Model Class Initialized
INFO - 2020-09-15 18:20:57 --> Model Class Initialized
INFO - 2020-09-15 18:20:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:20:57 --> Final output sent to browser
DEBUG - 2020-09-15 18:20:57 --> Total execution time: 0.0211
ERROR - 2020-09-15 18:29:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:29:03 --> Config Class Initialized
INFO - 2020-09-15 18:29:03 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:29:03 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:29:03 --> Utf8 Class Initialized
INFO - 2020-09-15 18:29:03 --> URI Class Initialized
INFO - 2020-09-15 18:29:03 --> Router Class Initialized
INFO - 2020-09-15 18:29:03 --> Output Class Initialized
INFO - 2020-09-15 18:29:03 --> Security Class Initialized
DEBUG - 2020-09-15 18:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:29:03 --> Input Class Initialized
INFO - 2020-09-15 18:29:03 --> Language Class Initialized
INFO - 2020-09-15 18:29:03 --> Loader Class Initialized
INFO - 2020-09-15 18:29:03 --> Helper loaded: url_helper
INFO - 2020-09-15 18:29:03 --> Database Driver Class Initialized
INFO - 2020-09-15 18:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:29:03 --> Email Class Initialized
INFO - 2020-09-15 18:29:03 --> Controller Class Initialized
DEBUG - 2020-09-15 18:29:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:29:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:29:03 --> Model Class Initialized
INFO - 2020-09-15 18:29:03 --> Model Class Initialized
INFO - 2020-09-15 18:29:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:29:03 --> Final output sent to browser
DEBUG - 2020-09-15 18:29:03 --> Total execution time: 0.0236
ERROR - 2020-09-15 18:30:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:30:34 --> Config Class Initialized
INFO - 2020-09-15 18:30:34 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:30:34 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:30:34 --> Utf8 Class Initialized
INFO - 2020-09-15 18:30:34 --> URI Class Initialized
INFO - 2020-09-15 18:30:34 --> Router Class Initialized
INFO - 2020-09-15 18:30:34 --> Output Class Initialized
INFO - 2020-09-15 18:30:34 --> Security Class Initialized
DEBUG - 2020-09-15 18:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:30:34 --> Input Class Initialized
INFO - 2020-09-15 18:30:34 --> Language Class Initialized
INFO - 2020-09-15 18:30:34 --> Loader Class Initialized
INFO - 2020-09-15 18:30:34 --> Helper loaded: url_helper
INFO - 2020-09-15 18:30:34 --> Database Driver Class Initialized
INFO - 2020-09-15 18:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:30:34 --> Email Class Initialized
INFO - 2020-09-15 18:30:34 --> Controller Class Initialized
DEBUG - 2020-09-15 18:30:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:30:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:30:34 --> Model Class Initialized
INFO - 2020-09-15 18:30:34 --> Model Class Initialized
INFO - 2020-09-15 18:30:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:30:34 --> Final output sent to browser
DEBUG - 2020-09-15 18:30:34 --> Total execution time: 0.0210
ERROR - 2020-09-15 18:31:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:31:34 --> Config Class Initialized
INFO - 2020-09-15 18:31:34 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:31:34 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:31:34 --> Utf8 Class Initialized
INFO - 2020-09-15 18:31:34 --> URI Class Initialized
INFO - 2020-09-15 18:31:34 --> Router Class Initialized
INFO - 2020-09-15 18:31:34 --> Output Class Initialized
INFO - 2020-09-15 18:31:34 --> Security Class Initialized
DEBUG - 2020-09-15 18:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:31:34 --> Input Class Initialized
INFO - 2020-09-15 18:31:34 --> Language Class Initialized
INFO - 2020-09-15 18:31:34 --> Loader Class Initialized
INFO - 2020-09-15 18:31:34 --> Helper loaded: url_helper
INFO - 2020-09-15 18:31:34 --> Database Driver Class Initialized
INFO - 2020-09-15 18:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:31:34 --> Email Class Initialized
INFO - 2020-09-15 18:31:34 --> Controller Class Initialized
DEBUG - 2020-09-15 18:31:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:31:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:31:34 --> Model Class Initialized
INFO - 2020-09-15 18:31:34 --> Model Class Initialized
INFO - 2020-09-15 18:31:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:31:34 --> Final output sent to browser
DEBUG - 2020-09-15 18:31:34 --> Total execution time: 0.0231
ERROR - 2020-09-15 18:31:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:31:43 --> Config Class Initialized
INFO - 2020-09-15 18:31:43 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:31:43 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:31:43 --> Utf8 Class Initialized
INFO - 2020-09-15 18:31:43 --> URI Class Initialized
INFO - 2020-09-15 18:31:43 --> Router Class Initialized
INFO - 2020-09-15 18:31:43 --> Output Class Initialized
INFO - 2020-09-15 18:31:43 --> Security Class Initialized
DEBUG - 2020-09-15 18:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:31:43 --> Input Class Initialized
INFO - 2020-09-15 18:31:43 --> Language Class Initialized
INFO - 2020-09-15 18:31:43 --> Loader Class Initialized
INFO - 2020-09-15 18:31:43 --> Helper loaded: url_helper
INFO - 2020-09-15 18:31:43 --> Database Driver Class Initialized
INFO - 2020-09-15 18:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:31:43 --> Email Class Initialized
INFO - 2020-09-15 18:31:43 --> Controller Class Initialized
DEBUG - 2020-09-15 18:31:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:31:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:31:43 --> Model Class Initialized
INFO - 2020-09-15 18:31:43 --> Model Class Initialized
INFO - 2020-09-15 18:31:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-09-15 18:31:43 --> Final output sent to browser
DEBUG - 2020-09-15 18:31:43 --> Total execution time: 0.0282
ERROR - 2020-09-15 18:31:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:31:50 --> Config Class Initialized
INFO - 2020-09-15 18:31:50 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:31:50 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:31:50 --> Utf8 Class Initialized
INFO - 2020-09-15 18:31:50 --> URI Class Initialized
INFO - 2020-09-15 18:31:50 --> Router Class Initialized
INFO - 2020-09-15 18:31:50 --> Output Class Initialized
INFO - 2020-09-15 18:31:50 --> Security Class Initialized
DEBUG - 2020-09-15 18:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:31:50 --> Input Class Initialized
INFO - 2020-09-15 18:31:50 --> Language Class Initialized
INFO - 2020-09-15 18:31:50 --> Loader Class Initialized
INFO - 2020-09-15 18:31:50 --> Helper loaded: url_helper
INFO - 2020-09-15 18:31:50 --> Database Driver Class Initialized
INFO - 2020-09-15 18:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:31:50 --> Email Class Initialized
INFO - 2020-09-15 18:31:50 --> Controller Class Initialized
DEBUG - 2020-09-15 18:31:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:31:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:31:50 --> Model Class Initialized
INFO - 2020-09-15 18:31:50 --> Model Class Initialized
INFO - 2020-09-15 18:31:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:31:50 --> Final output sent to browser
DEBUG - 2020-09-15 18:31:50 --> Total execution time: 0.0202
ERROR - 2020-09-15 18:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:31:56 --> Config Class Initialized
INFO - 2020-09-15 18:31:56 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:31:56 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:31:56 --> Utf8 Class Initialized
INFO - 2020-09-15 18:31:56 --> URI Class Initialized
INFO - 2020-09-15 18:31:56 --> Router Class Initialized
INFO - 2020-09-15 18:31:56 --> Output Class Initialized
INFO - 2020-09-15 18:31:56 --> Security Class Initialized
DEBUG - 2020-09-15 18:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:31:56 --> Input Class Initialized
INFO - 2020-09-15 18:31:56 --> Language Class Initialized
INFO - 2020-09-15 18:31:56 --> Loader Class Initialized
INFO - 2020-09-15 18:31:56 --> Helper loaded: url_helper
INFO - 2020-09-15 18:31:56 --> Database Driver Class Initialized
INFO - 2020-09-15 18:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:31:56 --> Email Class Initialized
INFO - 2020-09-15 18:31:56 --> Controller Class Initialized
DEBUG - 2020-09-15 18:31:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:31:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:31:56 --> Model Class Initialized
INFO - 2020-09-15 18:31:56 --> Model Class Initialized
INFO - 2020-09-15 18:31:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 18:31:56 --> Final output sent to browser
DEBUG - 2020-09-15 18:31:56 --> Total execution time: 0.0232
ERROR - 2020-09-15 18:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:32:12 --> Config Class Initialized
INFO - 2020-09-15 18:32:12 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:32:12 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:32:12 --> Utf8 Class Initialized
INFO - 2020-09-15 18:32:12 --> URI Class Initialized
INFO - 2020-09-15 18:32:12 --> Router Class Initialized
INFO - 2020-09-15 18:32:12 --> Output Class Initialized
INFO - 2020-09-15 18:32:12 --> Security Class Initialized
DEBUG - 2020-09-15 18:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:32:12 --> Input Class Initialized
INFO - 2020-09-15 18:32:12 --> Language Class Initialized
INFO - 2020-09-15 18:32:12 --> Loader Class Initialized
INFO - 2020-09-15 18:32:12 --> Helper loaded: url_helper
INFO - 2020-09-15 18:32:12 --> Database Driver Class Initialized
INFO - 2020-09-15 18:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:32:12 --> Email Class Initialized
INFO - 2020-09-15 18:32:12 --> Controller Class Initialized
DEBUG - 2020-09-15 18:32:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:32:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:32:12 --> Model Class Initialized
INFO - 2020-09-15 18:32:12 --> Model Class Initialized
INFO - 2020-09-15 18:32:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:32:12 --> Final output sent to browser
DEBUG - 2020-09-15 18:32:12 --> Total execution time: 0.0231
ERROR - 2020-09-15 18:34:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:34:56 --> Config Class Initialized
INFO - 2020-09-15 18:34:56 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:34:56 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:34:56 --> Utf8 Class Initialized
INFO - 2020-09-15 18:34:56 --> URI Class Initialized
INFO - 2020-09-15 18:34:56 --> Router Class Initialized
INFO - 2020-09-15 18:34:56 --> Output Class Initialized
INFO - 2020-09-15 18:34:56 --> Security Class Initialized
DEBUG - 2020-09-15 18:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:34:56 --> Input Class Initialized
INFO - 2020-09-15 18:34:56 --> Language Class Initialized
INFO - 2020-09-15 18:34:56 --> Loader Class Initialized
INFO - 2020-09-15 18:34:56 --> Helper loaded: url_helper
INFO - 2020-09-15 18:34:56 --> Database Driver Class Initialized
INFO - 2020-09-15 18:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:34:56 --> Email Class Initialized
INFO - 2020-09-15 18:34:56 --> Controller Class Initialized
DEBUG - 2020-09-15 18:34:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:34:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:34:56 --> Model Class Initialized
INFO - 2020-09-15 18:34:56 --> Model Class Initialized
INFO - 2020-09-15 18:34:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 18:34:56 --> Final output sent to browser
DEBUG - 2020-09-15 18:34:56 --> Total execution time: 0.0237
ERROR - 2020-09-15 18:38:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:38:10 --> Config Class Initialized
INFO - 2020-09-15 18:38:10 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:38:10 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:38:10 --> Utf8 Class Initialized
INFO - 2020-09-15 18:38:10 --> URI Class Initialized
INFO - 2020-09-15 18:38:10 --> Router Class Initialized
INFO - 2020-09-15 18:38:10 --> Output Class Initialized
INFO - 2020-09-15 18:38:10 --> Security Class Initialized
DEBUG - 2020-09-15 18:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:38:10 --> Input Class Initialized
INFO - 2020-09-15 18:38:10 --> Language Class Initialized
INFO - 2020-09-15 18:38:10 --> Loader Class Initialized
INFO - 2020-09-15 18:38:10 --> Helper loaded: url_helper
INFO - 2020-09-15 18:38:10 --> Database Driver Class Initialized
INFO - 2020-09-15 18:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:38:10 --> Email Class Initialized
INFO - 2020-09-15 18:38:10 --> Controller Class Initialized
DEBUG - 2020-09-15 18:38:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:38:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:38:10 --> Model Class Initialized
INFO - 2020-09-15 18:38:10 --> Model Class Initialized
ERROR - 2020-09-15 18:38:10 --> Severity: Runtime Notice --> mysqli_next_result(): There is no next result set. Please, call mysqli_more_results()/mysqli::more_results() to check whether to call this function/method /home/purpu1ex/public_html/carsm/system/database/drivers/mysqli/mysqli_result.php 189
INFO - 2020-09-15 18:38:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:38:10 --> Final output sent to browser
DEBUG - 2020-09-15 18:38:10 --> Total execution time: 0.0251
ERROR - 2020-09-15 18:38:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:38:50 --> Config Class Initialized
INFO - 2020-09-15 18:38:50 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:38:50 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:38:50 --> Utf8 Class Initialized
INFO - 2020-09-15 18:38:50 --> URI Class Initialized
INFO - 2020-09-15 18:38:50 --> Router Class Initialized
INFO - 2020-09-15 18:38:50 --> Output Class Initialized
INFO - 2020-09-15 18:38:50 --> Security Class Initialized
DEBUG - 2020-09-15 18:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:38:50 --> Input Class Initialized
INFO - 2020-09-15 18:38:50 --> Language Class Initialized
INFO - 2020-09-15 18:38:50 --> Loader Class Initialized
INFO - 2020-09-15 18:38:50 --> Helper loaded: url_helper
INFO - 2020-09-15 18:38:50 --> Database Driver Class Initialized
INFO - 2020-09-15 18:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:38:50 --> Email Class Initialized
INFO - 2020-09-15 18:38:50 --> Controller Class Initialized
DEBUG - 2020-09-15 18:38:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:38:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:38:50 --> Model Class Initialized
INFO - 2020-09-15 18:38:50 --> Model Class Initialized
INFO - 2020-09-15 18:38:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:38:50 --> Final output sent to browser
DEBUG - 2020-09-15 18:38:50 --> Total execution time: 0.0240
ERROR - 2020-09-15 18:38:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:38:56 --> Config Class Initialized
INFO - 2020-09-15 18:38:56 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:38:56 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:38:56 --> Utf8 Class Initialized
INFO - 2020-09-15 18:38:56 --> URI Class Initialized
INFO - 2020-09-15 18:38:56 --> Router Class Initialized
INFO - 2020-09-15 18:38:56 --> Output Class Initialized
INFO - 2020-09-15 18:38:56 --> Security Class Initialized
DEBUG - 2020-09-15 18:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:38:56 --> Input Class Initialized
INFO - 2020-09-15 18:38:56 --> Language Class Initialized
INFO - 2020-09-15 18:38:56 --> Loader Class Initialized
INFO - 2020-09-15 18:38:56 --> Helper loaded: url_helper
INFO - 2020-09-15 18:38:56 --> Database Driver Class Initialized
INFO - 2020-09-15 18:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:38:56 --> Email Class Initialized
INFO - 2020-09-15 18:38:56 --> Controller Class Initialized
DEBUG - 2020-09-15 18:38:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:38:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:38:56 --> Model Class Initialized
INFO - 2020-09-15 18:38:56 --> Model Class Initialized
INFO - 2020-09-15 18:38:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_assign.php
INFO - 2020-09-15 18:38:56 --> Final output sent to browser
DEBUG - 2020-09-15 18:38:56 --> Total execution time: 0.0227
ERROR - 2020-09-15 18:39:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-09-15 18:39:02 --> Config Class Initialized
INFO - 2020-09-15 18:39:02 --> Hooks Class Initialized
DEBUG - 2020-09-15 18:39:02 --> UTF-8 Support Enabled
INFO - 2020-09-15 18:39:02 --> Utf8 Class Initialized
INFO - 2020-09-15 18:39:02 --> URI Class Initialized
INFO - 2020-09-15 18:39:02 --> Router Class Initialized
INFO - 2020-09-15 18:39:02 --> Output Class Initialized
INFO - 2020-09-15 18:39:02 --> Security Class Initialized
DEBUG - 2020-09-15 18:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-15 18:39:02 --> Input Class Initialized
INFO - 2020-09-15 18:39:02 --> Language Class Initialized
INFO - 2020-09-15 18:39:02 --> Loader Class Initialized
INFO - 2020-09-15 18:39:02 --> Helper loaded: url_helper
INFO - 2020-09-15 18:39:02 --> Database Driver Class Initialized
INFO - 2020-09-15 18:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-15 18:39:02 --> Email Class Initialized
INFO - 2020-09-15 18:39:02 --> Controller Class Initialized
DEBUG - 2020-09-15 18:39:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-09-15 18:39:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-09-15 18:39:02 --> Model Class Initialized
INFO - 2020-09-15 18:39:02 --> Model Class Initialized
INFO - 2020-09-15 18:39:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-09-15 18:39:02 --> Final output sent to browser
DEBUG - 2020-09-15 18:39:02 --> Total execution time: 0.0245
