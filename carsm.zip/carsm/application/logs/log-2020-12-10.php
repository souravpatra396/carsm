<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-10 05:38:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-10 05:38:22 --> Config Class Initialized
INFO - 2020-12-10 05:38:22 --> Hooks Class Initialized
DEBUG - 2020-12-10 05:38:22 --> UTF-8 Support Enabled
INFO - 2020-12-10 05:38:22 --> Utf8 Class Initialized
INFO - 2020-12-10 05:38:22 --> URI Class Initialized
DEBUG - 2020-12-10 05:38:22 --> No URI present. Default controller set.
INFO - 2020-12-10 05:38:22 --> Router Class Initialized
INFO - 2020-12-10 05:38:22 --> Output Class Initialized
INFO - 2020-12-10 05:38:22 --> Security Class Initialized
DEBUG - 2020-12-10 05:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 05:38:22 --> Input Class Initialized
INFO - 2020-12-10 05:38:22 --> Language Class Initialized
INFO - 2020-12-10 05:38:22 --> Loader Class Initialized
INFO - 2020-12-10 05:38:22 --> Helper loaded: url_helper
INFO - 2020-12-10 05:38:22 --> Database Driver Class Initialized
INFO - 2020-12-10 05:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 05:38:22 --> Email Class Initialized
INFO - 2020-12-10 05:38:22 --> Controller Class Initialized
INFO - 2020-12-10 05:38:22 --> Model Class Initialized
INFO - 2020-12-10 05:38:22 --> Model Class Initialized
DEBUG - 2020-12-10 05:38:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-10 05:38:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-12-10 05:38:22 --> Final output sent to browser
DEBUG - 2020-12-10 05:38:22 --> Total execution time: 0.1814
ERROR - 2020-12-10 13:52:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-10 13:52:33 --> Config Class Initialized
INFO - 2020-12-10 13:52:33 --> Hooks Class Initialized
DEBUG - 2020-12-10 13:52:33 --> UTF-8 Support Enabled
INFO - 2020-12-10 13:52:33 --> Utf8 Class Initialized
INFO - 2020-12-10 13:52:33 --> URI Class Initialized
DEBUG - 2020-12-10 13:52:33 --> No URI present. Default controller set.
INFO - 2020-12-10 13:52:33 --> Router Class Initialized
INFO - 2020-12-10 13:52:33 --> Output Class Initialized
INFO - 2020-12-10 13:52:33 --> Security Class Initialized
DEBUG - 2020-12-10 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 13:52:33 --> Input Class Initialized
INFO - 2020-12-10 13:52:33 --> Language Class Initialized
INFO - 2020-12-10 13:52:33 --> Loader Class Initialized
INFO - 2020-12-10 13:52:33 --> Helper loaded: url_helper
INFO - 2020-12-10 13:52:33 --> Database Driver Class Initialized
ERROR - 2020-12-10 13:52:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'purpu1ex_carsm'@'localhost' (using password: YES) /home/portaldev2020/public_html/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-12-10 13:52:33 --> Unable to connect to the database
INFO - 2020-12-10 13:52:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-12-10 13:54:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-10 13:54:16 --> Config Class Initialized
INFO - 2020-12-10 13:54:16 --> Hooks Class Initialized
DEBUG - 2020-12-10 13:54:16 --> UTF-8 Support Enabled
INFO - 2020-12-10 13:54:16 --> Utf8 Class Initialized
INFO - 2020-12-10 13:54:16 --> URI Class Initialized
DEBUG - 2020-12-10 13:54:16 --> No URI present. Default controller set.
INFO - 2020-12-10 13:54:16 --> Router Class Initialized
INFO - 2020-12-10 13:54:16 --> Output Class Initialized
INFO - 2020-12-10 13:54:16 --> Security Class Initialized
DEBUG - 2020-12-10 13:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 13:54:16 --> Input Class Initialized
INFO - 2020-12-10 13:54:16 --> Language Class Initialized
INFO - 2020-12-10 13:54:16 --> Loader Class Initialized
INFO - 2020-12-10 13:54:16 --> Helper loaded: url_helper
INFO - 2020-12-10 13:54:16 --> Database Driver Class Initialized
ERROR - 2020-12-10 13:54:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'portalde_phpadmin'@'localhost' (using password: YES) /home/portaldev2020/public_html/system/database/drivers/mysqli/mysqli_driver.php 135
ERROR - 2020-12-10 13:54:16 --> Unable to connect to the database
INFO - 2020-12-10 13:54:16 --> Language file loaded: language/english/db_lang.php
ERROR - 2020-12-10 13:55:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-10 13:55:52 --> Config Class Initialized
INFO - 2020-12-10 13:55:52 --> Hooks Class Initialized
DEBUG - 2020-12-10 13:55:52 --> UTF-8 Support Enabled
INFO - 2020-12-10 13:55:52 --> Utf8 Class Initialized
INFO - 2020-12-10 13:55:52 --> URI Class Initialized
DEBUG - 2020-12-10 13:55:52 --> No URI present. Default controller set.
INFO - 2020-12-10 13:55:52 --> Router Class Initialized
INFO - 2020-12-10 13:55:52 --> Output Class Initialized
INFO - 2020-12-10 13:55:52 --> Security Class Initialized
DEBUG - 2020-12-10 13:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 13:55:52 --> Input Class Initialized
INFO - 2020-12-10 13:55:52 --> Language Class Initialized
INFO - 2020-12-10 13:55:52 --> Loader Class Initialized
INFO - 2020-12-10 13:55:52 --> Helper loaded: url_helper
INFO - 2020-12-10 13:55:52 --> Database Driver Class Initialized
INFO - 2020-12-10 13:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 13:55:52 --> Email Class Initialized
INFO - 2020-12-10 13:55:52 --> Controller Class Initialized
INFO - 2020-12-10 13:55:52 --> Model Class Initialized
INFO - 2020-12-10 13:55:52 --> Model Class Initialized
DEBUG - 2020-12-10 13:55:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-10 13:55:52 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-10 13:55:52 --> Final output sent to browser
DEBUG - 2020-12-10 13:55:52 --> Total execution time: 0.0658
ERROR - 2020-12-10 13:56:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-12-10 13:56:13 --> Config Class Initialized
INFO - 2020-12-10 13:56:13 --> Hooks Class Initialized
DEBUG - 2020-12-10 13:56:13 --> UTF-8 Support Enabled
INFO - 2020-12-10 13:56:13 --> Utf8 Class Initialized
INFO - 2020-12-10 13:56:13 --> URI Class Initialized
DEBUG - 2020-12-10 13:56:13 --> No URI present. Default controller set.
INFO - 2020-12-10 13:56:13 --> Router Class Initialized
INFO - 2020-12-10 13:56:13 --> Output Class Initialized
INFO - 2020-12-10 13:56:13 --> Security Class Initialized
DEBUG - 2020-12-10 13:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-10 13:56:13 --> Input Class Initialized
INFO - 2020-12-10 13:56:13 --> Language Class Initialized
INFO - 2020-12-10 13:56:13 --> Loader Class Initialized
INFO - 2020-12-10 13:56:13 --> Helper loaded: url_helper
INFO - 2020-12-10 13:56:13 --> Database Driver Class Initialized
INFO - 2020-12-10 13:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-10 13:56:13 --> Email Class Initialized
INFO - 2020-12-10 13:56:13 --> Controller Class Initialized
INFO - 2020-12-10 13:56:13 --> Model Class Initialized
INFO - 2020-12-10 13:56:13 --> Model Class Initialized
DEBUG - 2020-12-10 13:56:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-12-10 13:56:13 --> File loaded: /home/portaldev2020/public_html/application/views/welcome_message.php
INFO - 2020-12-10 13:56:13 --> Final output sent to browser
DEBUG - 2020-12-10 13:56:13 --> Total execution time: 0.0518
