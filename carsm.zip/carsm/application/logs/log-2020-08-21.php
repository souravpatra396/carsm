<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-21 05:46:48 --> Config Class Initialized
INFO - 2020-08-21 05:46:48 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:46:48 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:46:48 --> Utf8 Class Initialized
INFO - 2020-08-21 05:46:48 --> URI Class Initialized
DEBUG - 2020-08-21 05:46:48 --> No URI present. Default controller set.
INFO - 2020-08-21 05:46:48 --> Router Class Initialized
INFO - 2020-08-21 05:46:48 --> Output Class Initialized
INFO - 2020-08-21 05:46:48 --> Security Class Initialized
DEBUG - 2020-08-21 05:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:46:48 --> Input Class Initialized
INFO - 2020-08-21 05:46:48 --> Language Class Initialized
INFO - 2020-08-21 05:46:48 --> Loader Class Initialized
INFO - 2020-08-21 05:46:48 --> Helper loaded: url_helper
INFO - 2020-08-21 05:46:48 --> Database Driver Class Initialized
INFO - 2020-08-21 05:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:46:48 --> Email Class Initialized
INFO - 2020-08-21 05:46:48 --> Controller Class Initialized
INFO - 2020-08-21 05:46:48 --> Model Class Initialized
INFO - 2020-08-21 05:46:48 --> Model Class Initialized
DEBUG - 2020-08-21 05:46:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:46:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:46:48 --> Final output sent to browser
DEBUG - 2020-08-21 05:46:48 --> Total execution time: 0.1797
INFO - 2020-08-21 05:48:13 --> Config Class Initialized
INFO - 2020-08-21 05:48:13 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:48:13 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:48:13 --> Utf8 Class Initialized
INFO - 2020-08-21 05:48:13 --> URI Class Initialized
DEBUG - 2020-08-21 05:48:13 --> No URI present. Default controller set.
INFO - 2020-08-21 05:48:13 --> Router Class Initialized
INFO - 2020-08-21 05:48:13 --> Output Class Initialized
INFO - 2020-08-21 05:48:13 --> Security Class Initialized
DEBUG - 2020-08-21 05:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:48:13 --> Input Class Initialized
INFO - 2020-08-21 05:48:13 --> Language Class Initialized
INFO - 2020-08-21 05:48:13 --> Loader Class Initialized
INFO - 2020-08-21 05:48:13 --> Helper loaded: url_helper
INFO - 2020-08-21 05:48:13 --> Database Driver Class Initialized
INFO - 2020-08-21 05:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:48:13 --> Email Class Initialized
INFO - 2020-08-21 05:48:13 --> Controller Class Initialized
INFO - 2020-08-21 05:48:13 --> Model Class Initialized
INFO - 2020-08-21 05:48:13 --> Model Class Initialized
DEBUG - 2020-08-21 05:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:48:13 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:48:13 --> Final output sent to browser
DEBUG - 2020-08-21 05:48:13 --> Total execution time: 0.0213
INFO - 2020-08-21 05:48:46 --> Config Class Initialized
INFO - 2020-08-21 05:48:46 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:48:46 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:48:46 --> Utf8 Class Initialized
INFO - 2020-08-21 05:48:46 --> URI Class Initialized
INFO - 2020-08-21 05:48:46 --> Router Class Initialized
INFO - 2020-08-21 05:48:46 --> Output Class Initialized
INFO - 2020-08-21 05:48:46 --> Security Class Initialized
DEBUG - 2020-08-21 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:48:46 --> Input Class Initialized
INFO - 2020-08-21 05:48:46 --> Language Class Initialized
INFO - 2020-08-21 05:48:46 --> Loader Class Initialized
INFO - 2020-08-21 05:48:46 --> Helper loaded: url_helper
INFO - 2020-08-21 05:48:46 --> Database Driver Class Initialized
INFO - 2020-08-21 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:48:46 --> Email Class Initialized
INFO - 2020-08-21 05:48:46 --> Controller Class Initialized
INFO - 2020-08-21 05:48:46 --> Model Class Initialized
INFO - 2020-08-21 05:48:46 --> Model Class Initialized
DEBUG - 2020-08-21 05:48:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 05:48:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:48:46 --> Config Class Initialized
INFO - 2020-08-21 05:48:46 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:48:46 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:48:46 --> Utf8 Class Initialized
INFO - 2020-08-21 05:48:46 --> URI Class Initialized
INFO - 2020-08-21 05:48:46 --> Router Class Initialized
INFO - 2020-08-21 05:48:46 --> Output Class Initialized
INFO - 2020-08-21 05:48:46 --> Security Class Initialized
DEBUG - 2020-08-21 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:48:46 --> Input Class Initialized
INFO - 2020-08-21 05:48:46 --> Language Class Initialized
INFO - 2020-08-21 05:48:46 --> Loader Class Initialized
INFO - 2020-08-21 05:48:46 --> Helper loaded: url_helper
INFO - 2020-08-21 05:48:46 --> Database Driver Class Initialized
INFO - 2020-08-21 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:48:46 --> Email Class Initialized
INFO - 2020-08-21 05:48:46 --> Controller Class Initialized
INFO - 2020-08-21 05:48:46 --> Model Class Initialized
INFO - 2020-08-21 05:48:46 --> Model Class Initialized
DEBUG - 2020-08-21 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:48:46 --> Config Class Initialized
INFO - 2020-08-21 05:48:46 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:48:46 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:48:46 --> Utf8 Class Initialized
INFO - 2020-08-21 05:48:46 --> URI Class Initialized
DEBUG - 2020-08-21 05:48:46 --> No URI present. Default controller set.
INFO - 2020-08-21 05:48:46 --> Router Class Initialized
INFO - 2020-08-21 05:48:46 --> Output Class Initialized
INFO - 2020-08-21 05:48:46 --> Security Class Initialized
DEBUG - 2020-08-21 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:48:46 --> Input Class Initialized
INFO - 2020-08-21 05:48:46 --> Language Class Initialized
INFO - 2020-08-21 05:48:46 --> Loader Class Initialized
INFO - 2020-08-21 05:48:46 --> Helper loaded: url_helper
INFO - 2020-08-21 05:48:46 --> Database Driver Class Initialized
INFO - 2020-08-21 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:48:46 --> Email Class Initialized
INFO - 2020-08-21 05:48:46 --> Controller Class Initialized
INFO - 2020-08-21 05:48:46 --> Model Class Initialized
INFO - 2020-08-21 05:48:46 --> Model Class Initialized
DEBUG - 2020-08-21 05:48:46 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:48:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:48:46 --> Final output sent to browser
DEBUG - 2020-08-21 05:48:46 --> Total execution time: 0.0206
INFO - 2020-08-21 05:48:47 --> Config Class Initialized
INFO - 2020-08-21 05:48:47 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:48:47 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:48:47 --> Utf8 Class Initialized
INFO - 2020-08-21 05:48:47 --> URI Class Initialized
DEBUG - 2020-08-21 05:48:47 --> No URI present. Default controller set.
INFO - 2020-08-21 05:48:47 --> Router Class Initialized
INFO - 2020-08-21 05:48:47 --> Output Class Initialized
INFO - 2020-08-21 05:48:47 --> Security Class Initialized
DEBUG - 2020-08-21 05:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:48:47 --> Input Class Initialized
INFO - 2020-08-21 05:48:47 --> Language Class Initialized
INFO - 2020-08-21 05:48:47 --> Loader Class Initialized
INFO - 2020-08-21 05:48:47 --> Helper loaded: url_helper
INFO - 2020-08-21 05:48:47 --> Database Driver Class Initialized
INFO - 2020-08-21 05:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:48:47 --> Email Class Initialized
INFO - 2020-08-21 05:48:47 --> Controller Class Initialized
INFO - 2020-08-21 05:48:47 --> Model Class Initialized
INFO - 2020-08-21 05:48:47 --> Model Class Initialized
DEBUG - 2020-08-21 05:48:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:48:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:48:47 --> Final output sent to browser
DEBUG - 2020-08-21 05:48:47 --> Total execution time: 0.0214
INFO - 2020-08-21 05:49:47 --> Config Class Initialized
INFO - 2020-08-21 05:49:47 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:49:47 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:49:47 --> Utf8 Class Initialized
INFO - 2020-08-21 05:49:47 --> URI Class Initialized
INFO - 2020-08-21 05:49:47 --> Router Class Initialized
INFO - 2020-08-21 05:49:47 --> Output Class Initialized
INFO - 2020-08-21 05:49:47 --> Security Class Initialized
DEBUG - 2020-08-21 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:49:47 --> Input Class Initialized
INFO - 2020-08-21 05:49:47 --> Language Class Initialized
INFO - 2020-08-21 05:49:47 --> Loader Class Initialized
INFO - 2020-08-21 05:49:47 --> Helper loaded: url_helper
INFO - 2020-08-21 05:49:47 --> Database Driver Class Initialized
INFO - 2020-08-21 05:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:49:47 --> Email Class Initialized
INFO - 2020-08-21 05:49:47 --> Controller Class Initialized
INFO - 2020-08-21 05:49:47 --> Model Class Initialized
INFO - 2020-08-21 05:49:47 --> Model Class Initialized
DEBUG - 2020-08-21 05:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:49:47 --> Config Class Initialized
INFO - 2020-08-21 05:49:47 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:49:47 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:49:47 --> Utf8 Class Initialized
INFO - 2020-08-21 05:49:47 --> URI Class Initialized
INFO - 2020-08-21 05:49:47 --> Router Class Initialized
INFO - 2020-08-21 05:49:47 --> Output Class Initialized
INFO - 2020-08-21 05:49:47 --> Security Class Initialized
DEBUG - 2020-08-21 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:49:47 --> Input Class Initialized
INFO - 2020-08-21 05:49:47 --> Language Class Initialized
INFO - 2020-08-21 05:49:47 --> Loader Class Initialized
INFO - 2020-08-21 05:49:47 --> Helper loaded: url_helper
INFO - 2020-08-21 05:49:47 --> Database Driver Class Initialized
INFO - 2020-08-21 05:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:49:47 --> Email Class Initialized
INFO - 2020-08-21 05:49:47 --> Controller Class Initialized
INFO - 2020-08-21 05:49:47 --> Model Class Initialized
INFO - 2020-08-21 05:49:47 --> Model Class Initialized
DEBUG - 2020-08-21 05:49:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 05:49:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:49:47 --> Config Class Initialized
INFO - 2020-08-21 05:49:47 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:49:47 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:49:47 --> Utf8 Class Initialized
INFO - 2020-08-21 05:49:47 --> URI Class Initialized
DEBUG - 2020-08-21 05:49:47 --> No URI present. Default controller set.
INFO - 2020-08-21 05:49:47 --> Router Class Initialized
INFO - 2020-08-21 05:49:47 --> Output Class Initialized
INFO - 2020-08-21 05:49:47 --> Security Class Initialized
DEBUG - 2020-08-21 05:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:49:47 --> Input Class Initialized
INFO - 2020-08-21 05:49:47 --> Language Class Initialized
INFO - 2020-08-21 05:49:47 --> Loader Class Initialized
INFO - 2020-08-21 05:49:47 --> Helper loaded: url_helper
INFO - 2020-08-21 05:49:47 --> Database Driver Class Initialized
INFO - 2020-08-21 05:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:49:47 --> Email Class Initialized
INFO - 2020-08-21 05:49:47 --> Controller Class Initialized
INFO - 2020-08-21 05:49:47 --> Model Class Initialized
INFO - 2020-08-21 05:49:47 --> Model Class Initialized
DEBUG - 2020-08-21 05:49:47 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:49:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:49:47 --> Final output sent to browser
DEBUG - 2020-08-21 05:49:47 --> Total execution time: 0.0392
INFO - 2020-08-21 05:49:48 --> Config Class Initialized
INFO - 2020-08-21 05:49:48 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:49:48 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:49:48 --> Utf8 Class Initialized
INFO - 2020-08-21 05:49:48 --> URI Class Initialized
DEBUG - 2020-08-21 05:49:48 --> No URI present. Default controller set.
INFO - 2020-08-21 05:49:48 --> Router Class Initialized
INFO - 2020-08-21 05:49:48 --> Output Class Initialized
INFO - 2020-08-21 05:49:48 --> Security Class Initialized
DEBUG - 2020-08-21 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:49:48 --> Input Class Initialized
INFO - 2020-08-21 05:49:48 --> Language Class Initialized
INFO - 2020-08-21 05:49:48 --> Loader Class Initialized
INFO - 2020-08-21 05:49:48 --> Helper loaded: url_helper
INFO - 2020-08-21 05:49:48 --> Database Driver Class Initialized
INFO - 2020-08-21 05:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:49:48 --> Email Class Initialized
INFO - 2020-08-21 05:49:48 --> Controller Class Initialized
INFO - 2020-08-21 05:49:48 --> Model Class Initialized
INFO - 2020-08-21 05:49:48 --> Model Class Initialized
DEBUG - 2020-08-21 05:49:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:49:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:49:48 --> Final output sent to browser
DEBUG - 2020-08-21 05:49:48 --> Total execution time: 0.0250
INFO - 2020-08-21 05:50:35 --> Config Class Initialized
INFO - 2020-08-21 05:50:35 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:50:35 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:50:35 --> Utf8 Class Initialized
INFO - 2020-08-21 05:50:35 --> URI Class Initialized
INFO - 2020-08-21 05:50:35 --> Router Class Initialized
INFO - 2020-08-21 05:50:35 --> Output Class Initialized
INFO - 2020-08-21 05:50:35 --> Security Class Initialized
DEBUG - 2020-08-21 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:50:35 --> Input Class Initialized
INFO - 2020-08-21 05:50:35 --> Language Class Initialized
INFO - 2020-08-21 05:50:35 --> Loader Class Initialized
INFO - 2020-08-21 05:50:35 --> Helper loaded: url_helper
INFO - 2020-08-21 05:50:35 --> Database Driver Class Initialized
INFO - 2020-08-21 05:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:50:35 --> Email Class Initialized
INFO - 2020-08-21 05:50:35 --> Controller Class Initialized
INFO - 2020-08-21 05:50:35 --> Model Class Initialized
INFO - 2020-08-21 05:50:35 --> Model Class Initialized
DEBUG - 2020-08-21 05:50:35 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:50:35 --> Config Class Initialized
INFO - 2020-08-21 05:50:35 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:50:35 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:50:35 --> Utf8 Class Initialized
INFO - 2020-08-21 05:50:35 --> URI Class Initialized
INFO - 2020-08-21 05:50:35 --> Router Class Initialized
INFO - 2020-08-21 05:50:35 --> Output Class Initialized
INFO - 2020-08-21 05:50:35 --> Security Class Initialized
DEBUG - 2020-08-21 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:50:35 --> Input Class Initialized
INFO - 2020-08-21 05:50:35 --> Language Class Initialized
INFO - 2020-08-21 05:50:35 --> Loader Class Initialized
INFO - 2020-08-21 05:50:35 --> Helper loaded: url_helper
INFO - 2020-08-21 05:50:36 --> Database Driver Class Initialized
INFO - 2020-08-21 05:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:50:36 --> Email Class Initialized
INFO - 2020-08-21 05:50:36 --> Controller Class Initialized
INFO - 2020-08-21 05:50:36 --> Model Class Initialized
INFO - 2020-08-21 05:50:36 --> Model Class Initialized
DEBUG - 2020-08-21 05:50:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 05:50:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:50:36 --> Config Class Initialized
INFO - 2020-08-21 05:50:36 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:50:36 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:50:36 --> Utf8 Class Initialized
INFO - 2020-08-21 05:50:36 --> URI Class Initialized
DEBUG - 2020-08-21 05:50:36 --> No URI present. Default controller set.
INFO - 2020-08-21 05:50:36 --> Router Class Initialized
INFO - 2020-08-21 05:50:36 --> Output Class Initialized
INFO - 2020-08-21 05:50:36 --> Security Class Initialized
DEBUG - 2020-08-21 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:50:36 --> Input Class Initialized
INFO - 2020-08-21 05:50:36 --> Language Class Initialized
INFO - 2020-08-21 05:50:36 --> Loader Class Initialized
INFO - 2020-08-21 05:50:36 --> Helper loaded: url_helper
INFO - 2020-08-21 05:50:36 --> Database Driver Class Initialized
INFO - 2020-08-21 05:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:50:36 --> Email Class Initialized
INFO - 2020-08-21 05:50:36 --> Controller Class Initialized
INFO - 2020-08-21 05:50:36 --> Model Class Initialized
INFO - 2020-08-21 05:50:36 --> Model Class Initialized
DEBUG - 2020-08-21 05:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:50:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:50:36 --> Final output sent to browser
DEBUG - 2020-08-21 05:50:36 --> Total execution time: 0.0220
INFO - 2020-08-21 05:50:36 --> Config Class Initialized
INFO - 2020-08-21 05:50:36 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:50:36 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:50:36 --> Utf8 Class Initialized
INFO - 2020-08-21 05:50:36 --> URI Class Initialized
DEBUG - 2020-08-21 05:50:36 --> No URI present. Default controller set.
INFO - 2020-08-21 05:50:36 --> Router Class Initialized
INFO - 2020-08-21 05:50:36 --> Output Class Initialized
INFO - 2020-08-21 05:50:36 --> Security Class Initialized
DEBUG - 2020-08-21 05:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:50:36 --> Input Class Initialized
INFO - 2020-08-21 05:50:36 --> Language Class Initialized
INFO - 2020-08-21 05:50:36 --> Loader Class Initialized
INFO - 2020-08-21 05:50:36 --> Helper loaded: url_helper
INFO - 2020-08-21 05:50:36 --> Database Driver Class Initialized
INFO - 2020-08-21 05:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:50:36 --> Email Class Initialized
INFO - 2020-08-21 05:50:36 --> Controller Class Initialized
INFO - 2020-08-21 05:50:36 --> Model Class Initialized
INFO - 2020-08-21 05:50:36 --> Model Class Initialized
DEBUG - 2020-08-21 05:50:36 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:50:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:50:36 --> Final output sent to browser
DEBUG - 2020-08-21 05:50:36 --> Total execution time: 0.0219
INFO - 2020-08-21 05:59:37 --> Config Class Initialized
INFO - 2020-08-21 05:59:37 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:59:37 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:59:37 --> Utf8 Class Initialized
INFO - 2020-08-21 05:59:37 --> URI Class Initialized
DEBUG - 2020-08-21 05:59:37 --> No URI present. Default controller set.
INFO - 2020-08-21 05:59:37 --> Router Class Initialized
INFO - 2020-08-21 05:59:37 --> Output Class Initialized
INFO - 2020-08-21 05:59:37 --> Security Class Initialized
DEBUG - 2020-08-21 05:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:59:37 --> Input Class Initialized
INFO - 2020-08-21 05:59:37 --> Language Class Initialized
INFO - 2020-08-21 05:59:37 --> Loader Class Initialized
INFO - 2020-08-21 05:59:37 --> Helper loaded: url_helper
INFO - 2020-08-21 05:59:37 --> Database Driver Class Initialized
INFO - 2020-08-21 05:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:59:37 --> Email Class Initialized
INFO - 2020-08-21 05:59:37 --> Controller Class Initialized
INFO - 2020-08-21 05:59:37 --> Model Class Initialized
INFO - 2020-08-21 05:59:37 --> Model Class Initialized
DEBUG - 2020-08-21 05:59:37 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:59:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:59:37 --> Final output sent to browser
DEBUG - 2020-08-21 05:59:37 --> Total execution time: 0.0249
INFO - 2020-08-21 05:59:38 --> Config Class Initialized
INFO - 2020-08-21 05:59:38 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:59:38 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:59:38 --> Utf8 Class Initialized
INFO - 2020-08-21 05:59:38 --> URI Class Initialized
DEBUG - 2020-08-21 05:59:38 --> No URI present. Default controller set.
INFO - 2020-08-21 05:59:38 --> Router Class Initialized
INFO - 2020-08-21 05:59:38 --> Output Class Initialized
INFO - 2020-08-21 05:59:38 --> Security Class Initialized
DEBUG - 2020-08-21 05:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:59:38 --> Input Class Initialized
INFO - 2020-08-21 05:59:38 --> Language Class Initialized
INFO - 2020-08-21 05:59:38 --> Loader Class Initialized
INFO - 2020-08-21 05:59:38 --> Helper loaded: url_helper
INFO - 2020-08-21 05:59:38 --> Database Driver Class Initialized
INFO - 2020-08-21 05:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:59:38 --> Email Class Initialized
INFO - 2020-08-21 05:59:38 --> Controller Class Initialized
INFO - 2020-08-21 05:59:38 --> Model Class Initialized
INFO - 2020-08-21 05:59:38 --> Model Class Initialized
DEBUG - 2020-08-21 05:59:38 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:59:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:59:38 --> Final output sent to browser
DEBUG - 2020-08-21 05:59:38 --> Total execution time: 0.0223
INFO - 2020-08-21 05:59:50 --> Config Class Initialized
INFO - 2020-08-21 05:59:50 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:59:50 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:59:50 --> Utf8 Class Initialized
INFO - 2020-08-21 05:59:50 --> URI Class Initialized
INFO - 2020-08-21 05:59:50 --> Router Class Initialized
INFO - 2020-08-21 05:59:50 --> Output Class Initialized
INFO - 2020-08-21 05:59:50 --> Security Class Initialized
DEBUG - 2020-08-21 05:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:59:50 --> Input Class Initialized
INFO - 2020-08-21 05:59:50 --> Language Class Initialized
INFO - 2020-08-21 05:59:50 --> Loader Class Initialized
INFO - 2020-08-21 05:59:50 --> Helper loaded: url_helper
INFO - 2020-08-21 05:59:50 --> Database Driver Class Initialized
INFO - 2020-08-21 05:59:51 --> Config Class Initialized
INFO - 2020-08-21 05:59:51 --> Hooks Class Initialized
INFO - 2020-08-21 05:59:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-21 05:59:51 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:59:51 --> Utf8 Class Initialized
INFO - 2020-08-21 05:59:51 --> URI Class Initialized
INFO - 2020-08-21 05:59:51 --> Router Class Initialized
INFO - 2020-08-21 05:59:51 --> Email Class Initialized
INFO - 2020-08-21 05:59:51 --> Controller Class Initialized
INFO - 2020-08-21 05:59:51 --> Model Class Initialized
INFO - 2020-08-21 05:59:51 --> Output Class Initialized
INFO - 2020-08-21 05:59:51 --> Model Class Initialized
DEBUG - 2020-08-21 05:59:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:59:51 --> Security Class Initialized
DEBUG - 2020-08-21 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:59:51 --> Input Class Initialized
INFO - 2020-08-21 05:59:51 --> Language Class Initialized
INFO - 2020-08-21 05:59:51 --> Loader Class Initialized
INFO - 2020-08-21 05:59:51 --> Helper loaded: url_helper
INFO - 2020-08-21 05:59:51 --> Database Driver Class Initialized
INFO - 2020-08-21 05:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:59:51 --> Email Class Initialized
INFO - 2020-08-21 05:59:51 --> Controller Class Initialized
INFO - 2020-08-21 05:59:51 --> Model Class Initialized
INFO - 2020-08-21 05:59:51 --> Model Class Initialized
DEBUG - 2020-08-21 05:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 05:59:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:59:51 --> Model Class Initialized
INFO - 2020-08-21 05:59:51 --> Final output sent to browser
DEBUG - 2020-08-21 05:59:51 --> Total execution time: 0.0246
INFO - 2020-08-21 05:59:51 --> Config Class Initialized
INFO - 2020-08-21 05:59:51 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:59:51 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:59:51 --> Utf8 Class Initialized
INFO - 2020-08-21 05:59:51 --> URI Class Initialized
INFO - 2020-08-21 05:59:51 --> Router Class Initialized
INFO - 2020-08-21 05:59:51 --> Output Class Initialized
INFO - 2020-08-21 05:59:51 --> Security Class Initialized
DEBUG - 2020-08-21 05:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:59:51 --> Input Class Initialized
INFO - 2020-08-21 05:59:51 --> Language Class Initialized
INFO - 2020-08-21 05:59:51 --> Loader Class Initialized
INFO - 2020-08-21 05:59:51 --> Helper loaded: url_helper
INFO - 2020-08-21 05:59:51 --> Database Driver Class Initialized
INFO - 2020-08-21 05:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:59:51 --> Email Class Initialized
INFO - 2020-08-21 05:59:51 --> Controller Class Initialized
DEBUG - 2020-08-21 05:59:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 05:59:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:59:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-21 05:59:51 --> Final output sent to browser
DEBUG - 2020-08-21 05:59:51 --> Total execution time: 0.0400
INFO - 2020-08-21 05:59:54 --> Config Class Initialized
INFO - 2020-08-21 05:59:54 --> Hooks Class Initialized
DEBUG - 2020-08-21 05:59:54 --> UTF-8 Support Enabled
INFO - 2020-08-21 05:59:54 --> Utf8 Class Initialized
INFO - 2020-08-21 05:59:54 --> URI Class Initialized
DEBUG - 2020-08-21 05:59:54 --> No URI present. Default controller set.
INFO - 2020-08-21 05:59:54 --> Router Class Initialized
INFO - 2020-08-21 05:59:54 --> Output Class Initialized
INFO - 2020-08-21 05:59:54 --> Security Class Initialized
DEBUG - 2020-08-21 05:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 05:59:54 --> Input Class Initialized
INFO - 2020-08-21 05:59:54 --> Language Class Initialized
INFO - 2020-08-21 05:59:54 --> Loader Class Initialized
INFO - 2020-08-21 05:59:54 --> Helper loaded: url_helper
INFO - 2020-08-21 05:59:54 --> Database Driver Class Initialized
INFO - 2020-08-21 05:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 05:59:54 --> Email Class Initialized
INFO - 2020-08-21 05:59:54 --> Controller Class Initialized
INFO - 2020-08-21 05:59:54 --> Model Class Initialized
INFO - 2020-08-21 05:59:54 --> Model Class Initialized
DEBUG - 2020-08-21 05:59:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 05:59:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 05:59:54 --> Final output sent to browser
DEBUG - 2020-08-21 05:59:54 --> Total execution time: 0.0231
INFO - 2020-08-21 07:01:11 --> Config Class Initialized
INFO - 2020-08-21 07:01:11 --> Hooks Class Initialized
INFO - 2020-08-21 07:01:11 --> Config Class Initialized
INFO - 2020-08-21 07:01:11 --> Hooks Class Initialized
DEBUG - 2020-08-21 07:01:11 --> UTF-8 Support Enabled
INFO - 2020-08-21 07:01:11 --> Utf8 Class Initialized
DEBUG - 2020-08-21 07:01:11 --> UTF-8 Support Enabled
INFO - 2020-08-21 07:01:11 --> Utf8 Class Initialized
INFO - 2020-08-21 07:01:11 --> URI Class Initialized
INFO - 2020-08-21 07:01:11 --> URI Class Initialized
INFO - 2020-08-21 07:01:11 --> Router Class Initialized
INFO - 2020-08-21 07:01:11 --> Router Class Initialized
INFO - 2020-08-21 07:01:11 --> Output Class Initialized
INFO - 2020-08-21 07:01:11 --> Output Class Initialized
INFO - 2020-08-21 07:01:11 --> Security Class Initialized
INFO - 2020-08-21 07:01:11 --> Security Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 07:01:11 --> Input Class Initialized
INFO - 2020-08-21 07:01:11 --> Language Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 07:01:11 --> Input Class Initialized
INFO - 2020-08-21 07:01:11 --> Language Class Initialized
INFO - 2020-08-21 07:01:11 --> Loader Class Initialized
INFO - 2020-08-21 07:01:11 --> Loader Class Initialized
INFO - 2020-08-21 07:01:11 --> Helper loaded: url_helper
INFO - 2020-08-21 07:01:11 --> Helper loaded: url_helper
INFO - 2020-08-21 07:01:11 --> Database Driver Class Initialized
INFO - 2020-08-21 07:01:11 --> Database Driver Class Initialized
INFO - 2020-08-21 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 07:01:11 --> Email Class Initialized
INFO - 2020-08-21 07:01:11 --> Controller Class Initialized
INFO - 2020-08-21 07:01:11 --> Model Class Initialized
INFO - 2020-08-21 07:01:11 --> Model Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 07:01:11 --> Email Class Initialized
INFO - 2020-08-21 07:01:11 --> Controller Class Initialized
INFO - 2020-08-21 07:01:11 --> Model Class Initialized
INFO - 2020-08-21 07:01:11 --> Model Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:01:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 07:01:11 --> Config Class Initialized
INFO - 2020-08-21 07:01:11 --> Hooks Class Initialized
DEBUG - 2020-08-21 07:01:11 --> UTF-8 Support Enabled
INFO - 2020-08-21 07:01:11 --> Utf8 Class Initialized
INFO - 2020-08-21 07:01:11 --> URI Class Initialized
INFO - 2020-08-21 07:01:11 --> Router Class Initialized
INFO - 2020-08-21 07:01:11 --> Output Class Initialized
INFO - 2020-08-21 07:01:11 --> Security Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 07:01:11 --> Input Class Initialized
INFO - 2020-08-21 07:01:11 --> Language Class Initialized
INFO - 2020-08-21 07:01:11 --> Loader Class Initialized
INFO - 2020-08-21 07:01:11 --> Helper loaded: url_helper
INFO - 2020-08-21 07:01:11 --> Database Driver Class Initialized
INFO - 2020-08-21 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 07:01:11 --> Email Class Initialized
INFO - 2020-08-21 07:01:11 --> Controller Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:01:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 07:01:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-21 07:01:11 --> Final output sent to browser
DEBUG - 2020-08-21 07:01:11 --> Total execution time: 0.0230
INFO - 2020-08-21 07:01:11 --> Config Class Initialized
INFO - 2020-08-21 07:01:11 --> Hooks Class Initialized
DEBUG - 2020-08-21 07:01:11 --> UTF-8 Support Enabled
INFO - 2020-08-21 07:01:11 --> Utf8 Class Initialized
INFO - 2020-08-21 07:01:11 --> URI Class Initialized
DEBUG - 2020-08-21 07:01:11 --> No URI present. Default controller set.
INFO - 2020-08-21 07:01:11 --> Router Class Initialized
INFO - 2020-08-21 07:01:11 --> Output Class Initialized
INFO - 2020-08-21 07:01:11 --> Security Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 07:01:11 --> Input Class Initialized
INFO - 2020-08-21 07:01:11 --> Language Class Initialized
INFO - 2020-08-21 07:01:11 --> Loader Class Initialized
INFO - 2020-08-21 07:01:11 --> Helper loaded: url_helper
INFO - 2020-08-21 07:01:11 --> Database Driver Class Initialized
INFO - 2020-08-21 07:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 07:01:11 --> Email Class Initialized
INFO - 2020-08-21 07:01:11 --> Controller Class Initialized
INFO - 2020-08-21 07:01:11 --> Model Class Initialized
INFO - 2020-08-21 07:01:11 --> Model Class Initialized
DEBUG - 2020-08-21 07:01:11 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-21 07:01:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-21 07:01:11 --> Final output sent to browser
DEBUG - 2020-08-21 07:01:11 --> Total execution time: 0.0210
INFO - 2020-08-21 07:11:12 --> Config Class Initialized
INFO - 2020-08-21 07:11:12 --> Hooks Class Initialized
DEBUG - 2020-08-21 07:11:12 --> UTF-8 Support Enabled
INFO - 2020-08-21 07:11:12 --> Utf8 Class Initialized
INFO - 2020-08-21 07:11:12 --> URI Class Initialized
INFO - 2020-08-21 07:11:12 --> Router Class Initialized
INFO - 2020-08-21 07:11:12 --> Output Class Initialized
INFO - 2020-08-21 07:11:12 --> Security Class Initialized
DEBUG - 2020-08-21 07:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 07:11:12 --> Input Class Initialized
INFO - 2020-08-21 07:11:12 --> Language Class Initialized
INFO - 2020-08-21 07:11:12 --> Loader Class Initialized
INFO - 2020-08-21 07:11:12 --> Helper loaded: url_helper
INFO - 2020-08-21 07:11:12 --> Database Driver Class Initialized
INFO - 2020-08-21 07:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 07:11:12 --> Email Class Initialized
INFO - 2020-08-21 07:11:12 --> Controller Class Initialized
DEBUG - 2020-08-21 07:11:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:11:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 07:11:12 --> Model Class Initialized
INFO - 2020-08-21 07:11:12 --> Model Class Initialized
INFO - 2020-08-21 07:11:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-21 07:11:12 --> Final output sent to browser
DEBUG - 2020-08-21 07:11:12 --> Total execution time: 0.0539
INFO - 2020-08-21 07:11:21 --> Config Class Initialized
INFO - 2020-08-21 07:11:21 --> Hooks Class Initialized
DEBUG - 2020-08-21 07:11:21 --> UTF-8 Support Enabled
INFO - 2020-08-21 07:11:21 --> Utf8 Class Initialized
INFO - 2020-08-21 07:11:21 --> URI Class Initialized
INFO - 2020-08-21 07:11:21 --> Router Class Initialized
INFO - 2020-08-21 07:11:21 --> Output Class Initialized
INFO - 2020-08-21 07:11:21 --> Security Class Initialized
DEBUG - 2020-08-21 07:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-21 07:11:21 --> Input Class Initialized
INFO - 2020-08-21 07:11:21 --> Language Class Initialized
INFO - 2020-08-21 07:11:21 --> Loader Class Initialized
INFO - 2020-08-21 07:11:21 --> Helper loaded: url_helper
INFO - 2020-08-21 07:11:21 --> Database Driver Class Initialized
INFO - 2020-08-21 07:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-21 07:11:21 --> Email Class Initialized
INFO - 2020-08-21 07:11:21 --> Controller Class Initialized
DEBUG - 2020-08-21 07:11:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-21 07:11:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-21 07:11:21 --> Model Class Initialized
INFO - 2020-08-21 07:11:21 --> Model Class Initialized
INFO - 2020-08-21 07:11:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-21 07:11:21 --> Final output sent to browser
DEBUG - 2020-08-21 07:11:21 --> Total execution time: 0.0256
