<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-27 14:31:05 --> Config Class Initialized
INFO - 2020-08-27 14:31:05 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:05 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:05 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:05 --> URI Class Initialized
DEBUG - 2020-08-27 14:31:05 --> No URI present. Default controller set.
INFO - 2020-08-27 14:31:05 --> Router Class Initialized
INFO - 2020-08-27 14:31:05 --> Output Class Initialized
INFO - 2020-08-27 14:31:05 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:05 --> Input Class Initialized
INFO - 2020-08-27 14:31:05 --> Language Class Initialized
INFO - 2020-08-27 14:31:05 --> Loader Class Initialized
INFO - 2020-08-27 14:31:05 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:05 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:31:05 --> Email Class Initialized
INFO - 2020-08-27 14:31:05 --> Controller Class Initialized
INFO - 2020-08-27 14:31:05 --> Model Class Initialized
INFO - 2020-08-27 14:31:05 --> Model Class Initialized
DEBUG - 2020-08-27 14:31:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-27 14:31:05 --> Final output sent to browser
DEBUG - 2020-08-27 14:31:05 --> Total execution time: 0.1647
INFO - 2020-08-27 14:31:10 --> Config Class Initialized
INFO - 2020-08-27 14:31:10 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:10 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:10 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:10 --> URI Class Initialized
INFO - 2020-08-27 14:31:10 --> Router Class Initialized
INFO - 2020-08-27 14:31:10 --> Output Class Initialized
INFO - 2020-08-27 14:31:10 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:10 --> Input Class Initialized
INFO - 2020-08-27 14:31:10 --> Language Class Initialized
INFO - 2020-08-27 14:31:10 --> Loader Class Initialized
INFO - 2020-08-27 14:31:10 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:10 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:10 --> Config Class Initialized
INFO - 2020-08-27 14:31:10 --> Hooks Class Initialized
INFO - 2020-08-27 14:31:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-08-27 14:31:10 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:10 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:10 --> URI Class Initialized
INFO - 2020-08-27 14:31:10 --> Router Class Initialized
INFO - 2020-08-27 14:31:10 --> Email Class Initialized
INFO - 2020-08-27 14:31:10 --> Controller Class Initialized
INFO - 2020-08-27 14:31:10 --> Model Class Initialized
INFO - 2020-08-27 14:31:10 --> Output Class Initialized
INFO - 2020-08-27 14:31:10 --> Model Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:31:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:10 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:10 --> Input Class Initialized
INFO - 2020-08-27 14:31:10 --> Language Class Initialized
INFO - 2020-08-27 14:31:10 --> Loader Class Initialized
INFO - 2020-08-27 14:31:10 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:10 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:31:10 --> Email Class Initialized
INFO - 2020-08-27 14:31:10 --> Controller Class Initialized
INFO - 2020-08-27 14:31:10 --> Model Class Initialized
INFO - 2020-08-27 14:31:10 --> Model Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:10 --> Config Class Initialized
INFO - 2020-08-27 14:31:10 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:10 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:10 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:10 --> URI Class Initialized
DEBUG - 2020-08-27 14:31:10 --> No URI present. Default controller set.
INFO - 2020-08-27 14:31:10 --> Router Class Initialized
INFO - 2020-08-27 14:31:10 --> Output Class Initialized
INFO - 2020-08-27 14:31:10 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:10 --> Input Class Initialized
INFO - 2020-08-27 14:31:10 --> Language Class Initialized
INFO - 2020-08-27 14:31:10 --> Loader Class Initialized
INFO - 2020-08-27 14:31:10 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:10 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:31:10 --> Email Class Initialized
INFO - 2020-08-27 14:31:10 --> Controller Class Initialized
INFO - 2020-08-27 14:31:10 --> Model Class Initialized
INFO - 2020-08-27 14:31:10 --> Model Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-27 14:31:10 --> Final output sent to browser
DEBUG - 2020-08-27 14:31:10 --> Total execution time: 0.0227
INFO - 2020-08-27 14:31:10 --> Config Class Initialized
INFO - 2020-08-27 14:31:10 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:10 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:10 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:10 --> URI Class Initialized
INFO - 2020-08-27 14:31:10 --> Router Class Initialized
INFO - 2020-08-27 14:31:10 --> Output Class Initialized
INFO - 2020-08-27 14:31:10 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:10 --> Input Class Initialized
INFO - 2020-08-27 14:31:10 --> Language Class Initialized
INFO - 2020-08-27 14:31:10 --> Loader Class Initialized
INFO - 2020-08-27 14:31:10 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:10 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:31:10 --> Email Class Initialized
INFO - 2020-08-27 14:31:10 --> Controller Class Initialized
DEBUG - 2020-08-27 14:31:10 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:31:10 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:10 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-27 14:31:10 --> Final output sent to browser
DEBUG - 2020-08-27 14:31:10 --> Total execution time: 0.0465
INFO - 2020-08-27 14:31:12 --> Config Class Initialized
INFO - 2020-08-27 14:31:12 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:12 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:12 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:12 --> URI Class Initialized
INFO - 2020-08-27 14:31:12 --> Router Class Initialized
INFO - 2020-08-27 14:31:12 --> Output Class Initialized
INFO - 2020-08-27 14:31:12 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:12 --> Input Class Initialized
INFO - 2020-08-27 14:31:12 --> Language Class Initialized
ERROR - 2020-08-27 14:31:12 --> 404 Page Not Found: Dealer/dash.html
INFO - 2020-08-27 14:31:17 --> Config Class Initialized
INFO - 2020-08-27 14:31:17 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:17 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:17 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:17 --> URI Class Initialized
INFO - 2020-08-27 14:31:17 --> Router Class Initialized
INFO - 2020-08-27 14:31:17 --> Output Class Initialized
INFO - 2020-08-27 14:31:17 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:17 --> Input Class Initialized
INFO - 2020-08-27 14:31:17 --> Language Class Initialized
INFO - 2020-08-27 14:31:17 --> Loader Class Initialized
INFO - 2020-08-27 14:31:17 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:17 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:31:17 --> Email Class Initialized
INFO - 2020-08-27 14:31:17 --> Controller Class Initialized
DEBUG - 2020-08-27 14:31:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:31:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-27 14:31:17 --> Final output sent to browser
DEBUG - 2020-08-27 14:31:17 --> Total execution time: 0.0224
INFO - 2020-08-27 14:31:21 --> Config Class Initialized
INFO - 2020-08-27 14:31:21 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:31:21 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:31:21 --> Utf8 Class Initialized
INFO - 2020-08-27 14:31:21 --> URI Class Initialized
INFO - 2020-08-27 14:31:21 --> Router Class Initialized
INFO - 2020-08-27 14:31:21 --> Output Class Initialized
INFO - 2020-08-27 14:31:21 --> Security Class Initialized
DEBUG - 2020-08-27 14:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:31:21 --> Input Class Initialized
INFO - 2020-08-27 14:31:21 --> Language Class Initialized
INFO - 2020-08-27 14:31:21 --> Loader Class Initialized
INFO - 2020-08-27 14:31:21 --> Helper loaded: url_helper
INFO - 2020-08-27 14:31:21 --> Database Driver Class Initialized
INFO - 2020-08-27 14:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:31:21 --> Email Class Initialized
INFO - 2020-08-27 14:31:21 --> Controller Class Initialized
DEBUG - 2020-08-27 14:31:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:31:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:31:21 --> Model Class Initialized
INFO - 2020-08-27 14:31:21 --> Model Class Initialized
INFO - 2020-08-27 14:31:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-27 14:31:21 --> Final output sent to browser
DEBUG - 2020-08-27 14:31:21 --> Total execution time: 0.0621
INFO - 2020-08-27 14:38:07 --> Config Class Initialized
INFO - 2020-08-27 14:38:07 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:38:07 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:38:07 --> Utf8 Class Initialized
INFO - 2020-08-27 14:38:07 --> URI Class Initialized
INFO - 2020-08-27 14:38:07 --> Router Class Initialized
INFO - 2020-08-27 14:38:07 --> Output Class Initialized
INFO - 2020-08-27 14:38:07 --> Security Class Initialized
DEBUG - 2020-08-27 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:38:07 --> Input Class Initialized
INFO - 2020-08-27 14:38:07 --> Language Class Initialized
INFO - 2020-08-27 14:38:07 --> Loader Class Initialized
INFO - 2020-08-27 14:38:07 --> Helper loaded: url_helper
INFO - 2020-08-27 14:38:07 --> Database Driver Class Initialized
INFO - 2020-08-27 14:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:38:07 --> Email Class Initialized
INFO - 2020-08-27 14:38:07 --> Controller Class Initialized
DEBUG - 2020-08-27 14:38:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:38:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:38:07 --> Helper loaded: form_helper
INFO - 2020-08-27 14:38:07 --> Form Validation Class Initialized
INFO - 2020-08-27 14:38:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 14:38:07 --> Final output sent to browser
DEBUG - 2020-08-27 14:38:07 --> Total execution time: 0.0412
INFO - 2020-08-27 14:40:34 --> Config Class Initialized
INFO - 2020-08-27 14:40:34 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:40:34 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:40:34 --> Utf8 Class Initialized
INFO - 2020-08-27 14:40:34 --> URI Class Initialized
INFO - 2020-08-27 14:40:34 --> Router Class Initialized
INFO - 2020-08-27 14:40:34 --> Output Class Initialized
INFO - 2020-08-27 14:40:34 --> Security Class Initialized
DEBUG - 2020-08-27 14:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:40:34 --> Input Class Initialized
INFO - 2020-08-27 14:40:34 --> Language Class Initialized
INFO - 2020-08-27 14:40:34 --> Loader Class Initialized
INFO - 2020-08-27 14:40:34 --> Helper loaded: url_helper
INFO - 2020-08-27 14:40:34 --> Database Driver Class Initialized
INFO - 2020-08-27 14:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:40:34 --> Email Class Initialized
INFO - 2020-08-27 14:40:34 --> Controller Class Initialized
DEBUG - 2020-08-27 14:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:40:34 --> Helper loaded: form_helper
INFO - 2020-08-27 14:40:34 --> Form Validation Class Initialized
INFO - 2020-08-27 14:40:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 14:40:34 --> Final output sent to browser
DEBUG - 2020-08-27 14:40:34 --> Total execution time: 0.0223
INFO - 2020-08-27 14:40:56 --> Config Class Initialized
INFO - 2020-08-27 14:40:56 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:40:56 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:40:56 --> Utf8 Class Initialized
INFO - 2020-08-27 14:40:56 --> URI Class Initialized
INFO - 2020-08-27 14:40:56 --> Router Class Initialized
INFO - 2020-08-27 14:40:56 --> Output Class Initialized
INFO - 2020-08-27 14:40:56 --> Security Class Initialized
DEBUG - 2020-08-27 14:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:40:56 --> Input Class Initialized
INFO - 2020-08-27 14:40:56 --> Language Class Initialized
INFO - 2020-08-27 14:40:56 --> Loader Class Initialized
INFO - 2020-08-27 14:40:56 --> Helper loaded: url_helper
INFO - 2020-08-27 14:40:56 --> Database Driver Class Initialized
INFO - 2020-08-27 14:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:40:56 --> Email Class Initialized
INFO - 2020-08-27 14:40:56 --> Controller Class Initialized
DEBUG - 2020-08-27 14:40:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:40:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:40:56 --> Helper loaded: form_helper
INFO - 2020-08-27 14:40:56 --> Form Validation Class Initialized
INFO - 2020-08-27 14:40:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 14:40:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:71) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:40:56 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 71
INFO - 2020-08-27 14:42:04 --> Config Class Initialized
INFO - 2020-08-27 14:42:04 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:42:04 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:42:04 --> Utf8 Class Initialized
INFO - 2020-08-27 14:42:04 --> URI Class Initialized
INFO - 2020-08-27 14:42:04 --> Router Class Initialized
INFO - 2020-08-27 14:42:04 --> Output Class Initialized
INFO - 2020-08-27 14:42:04 --> Security Class Initialized
DEBUG - 2020-08-27 14:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:42:04 --> Input Class Initialized
INFO - 2020-08-27 14:42:04 --> Language Class Initialized
INFO - 2020-08-27 14:42:04 --> Loader Class Initialized
INFO - 2020-08-27 14:42:04 --> Helper loaded: url_helper
INFO - 2020-08-27 14:42:04 --> Database Driver Class Initialized
INFO - 2020-08-27 14:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:42:04 --> Email Class Initialized
INFO - 2020-08-27 14:42:04 --> Controller Class Initialized
DEBUG - 2020-08-27 14:42:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:42:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:42:04 --> Helper loaded: form_helper
INFO - 2020-08-27 14:42:04 --> Form Validation Class Initialized
INFO - 2020-08-27 14:42:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 14:42:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:71) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:42:04 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 71
INFO - 2020-08-27 14:42:08 --> Config Class Initialized
INFO - 2020-08-27 14:42:08 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:42:08 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:42:08 --> Utf8 Class Initialized
INFO - 2020-08-27 14:42:08 --> URI Class Initialized
INFO - 2020-08-27 14:42:08 --> Router Class Initialized
INFO - 2020-08-27 14:42:08 --> Output Class Initialized
INFO - 2020-08-27 14:42:08 --> Security Class Initialized
DEBUG - 2020-08-27 14:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:42:08 --> Input Class Initialized
INFO - 2020-08-27 14:42:08 --> Language Class Initialized
INFO - 2020-08-27 14:42:08 --> Loader Class Initialized
INFO - 2020-08-27 14:42:08 --> Helper loaded: url_helper
INFO - 2020-08-27 14:42:08 --> Database Driver Class Initialized
INFO - 2020-08-27 14:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:42:08 --> Email Class Initialized
INFO - 2020-08-27 14:42:08 --> Controller Class Initialized
DEBUG - 2020-08-27 14:42:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:42:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:42:08 --> Helper loaded: form_helper
INFO - 2020-08-27 14:42:08 --> Form Validation Class Initialized
INFO - 2020-08-27 14:42:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 14:42:08 --> Final output sent to browser
DEBUG - 2020-08-27 14:42:08 --> Total execution time: 0.0235
INFO - 2020-08-27 14:42:19 --> Config Class Initialized
INFO - 2020-08-27 14:42:19 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:42:19 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:42:19 --> Utf8 Class Initialized
INFO - 2020-08-27 14:42:19 --> URI Class Initialized
INFO - 2020-08-27 14:42:19 --> Router Class Initialized
INFO - 2020-08-27 14:42:19 --> Output Class Initialized
INFO - 2020-08-27 14:42:19 --> Security Class Initialized
DEBUG - 2020-08-27 14:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:42:19 --> Input Class Initialized
INFO - 2020-08-27 14:42:19 --> Language Class Initialized
INFO - 2020-08-27 14:42:19 --> Loader Class Initialized
INFO - 2020-08-27 14:42:19 --> Helper loaded: url_helper
INFO - 2020-08-27 14:42:19 --> Database Driver Class Initialized
INFO - 2020-08-27 14:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:42:19 --> Email Class Initialized
INFO - 2020-08-27 14:42:19 --> Controller Class Initialized
DEBUG - 2020-08-27 14:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:42:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:42:19 --> Helper loaded: form_helper
INFO - 2020-08-27 14:42:19 --> Form Validation Class Initialized
INFO - 2020-08-27 14:42:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 14:42:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:71) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:42:19 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 71
INFO - 2020-08-27 14:50:41 --> Config Class Initialized
INFO - 2020-08-27 14:50:41 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:50:41 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:50:41 --> Utf8 Class Initialized
INFO - 2020-08-27 14:50:41 --> URI Class Initialized
INFO - 2020-08-27 14:50:41 --> Router Class Initialized
INFO - 2020-08-27 14:50:41 --> Output Class Initialized
INFO - 2020-08-27 14:50:41 --> Security Class Initialized
DEBUG - 2020-08-27 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:50:41 --> Input Class Initialized
INFO - 2020-08-27 14:50:41 --> Language Class Initialized
ERROR - 2020-08-27 14:50:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:5) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:50:41 --> Severity: Error --> Trait 'PhpOffice\PhpSpreadsheet\Spreadsheet' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 5
INFO - 2020-08-27 14:52:30 --> Config Class Initialized
INFO - 2020-08-27 14:52:30 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:52:30 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:52:30 --> Utf8 Class Initialized
INFO - 2020-08-27 14:52:30 --> URI Class Initialized
INFO - 2020-08-27 14:52:30 --> Router Class Initialized
INFO - 2020-08-27 14:52:30 --> Output Class Initialized
INFO - 2020-08-27 14:52:30 --> Security Class Initialized
DEBUG - 2020-08-27 14:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:52:30 --> Input Class Initialized
INFO - 2020-08-27 14:52:30 --> Language Class Initialized
ERROR - 2020-08-27 14:52:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:5) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:52:30 --> Severity: Error --> Trait 'PhpOffice\PhpSpreadsheet\Spreadsheet' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 5
INFO - 2020-08-27 14:52:37 --> Config Class Initialized
INFO - 2020-08-27 14:52:37 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:52:37 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:52:37 --> Utf8 Class Initialized
INFO - 2020-08-27 14:52:37 --> URI Class Initialized
INFO - 2020-08-27 14:52:37 --> Router Class Initialized
INFO - 2020-08-27 14:52:37 --> Output Class Initialized
INFO - 2020-08-27 14:52:37 --> Security Class Initialized
DEBUG - 2020-08-27 14:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:52:37 --> Input Class Initialized
INFO - 2020-08-27 14:52:37 --> Language Class Initialized
ERROR - 2020-08-27 14:52:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:5) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:52:37 --> Severity: Error --> Trait 'PhpOffice\PhpSpreadsheet\Spreadsheet' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 5
INFO - 2020-08-27 14:52:42 --> Config Class Initialized
INFO - 2020-08-27 14:52:42 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:52:42 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:52:42 --> Utf8 Class Initialized
INFO - 2020-08-27 14:52:42 --> URI Class Initialized
INFO - 2020-08-27 14:52:42 --> Router Class Initialized
INFO - 2020-08-27 14:52:42 --> Output Class Initialized
INFO - 2020-08-27 14:52:42 --> Security Class Initialized
DEBUG - 2020-08-27 14:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:52:42 --> Input Class Initialized
INFO - 2020-08-27 14:52:42 --> Language Class Initialized
ERROR - 2020-08-27 14:52:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:5) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:52:42 --> Severity: Error --> Trait 'PhpOffice\PhpSpreadsheet\Spreadsheet' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 5
INFO - 2020-08-27 14:52:44 --> Config Class Initialized
INFO - 2020-08-27 14:52:44 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:52:44 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:52:44 --> Utf8 Class Initialized
INFO - 2020-08-27 14:52:44 --> URI Class Initialized
INFO - 2020-08-27 14:52:44 --> Router Class Initialized
INFO - 2020-08-27 14:52:44 --> Output Class Initialized
INFO - 2020-08-27 14:52:44 --> Security Class Initialized
DEBUG - 2020-08-27 14:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:52:44 --> Input Class Initialized
INFO - 2020-08-27 14:52:44 --> Language Class Initialized
INFO - 2020-08-27 14:52:44 --> Loader Class Initialized
INFO - 2020-08-27 14:52:44 --> Helper loaded: url_helper
INFO - 2020-08-27 14:52:44 --> Database Driver Class Initialized
INFO - 2020-08-27 14:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:52:44 --> Email Class Initialized
INFO - 2020-08-27 14:52:44 --> Controller Class Initialized
DEBUG - 2020-08-27 14:52:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:52:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:52:44 --> Model Class Initialized
INFO - 2020-08-27 14:52:44 --> Model Class Initialized
INFO - 2020-08-27 14:52:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-27 14:52:44 --> Final output sent to browser
DEBUG - 2020-08-27 14:52:44 --> Total execution time: 0.0313
INFO - 2020-08-27 14:53:12 --> Config Class Initialized
INFO - 2020-08-27 14:53:12 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:53:12 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:53:12 --> Utf8 Class Initialized
INFO - 2020-08-27 14:53:12 --> URI Class Initialized
INFO - 2020-08-27 14:53:12 --> Router Class Initialized
INFO - 2020-08-27 14:53:12 --> Output Class Initialized
INFO - 2020-08-27 14:53:12 --> Security Class Initialized
DEBUG - 2020-08-27 14:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:53:12 --> Input Class Initialized
INFO - 2020-08-27 14:53:12 --> Language Class Initialized
ERROR - 2020-08-27 14:53:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:5) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:53:12 --> Severity: Error --> Trait 'PhpOffice\PhpSpreadsheet\Spreadsheet' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 5
INFO - 2020-08-27 14:53:30 --> Config Class Initialized
INFO - 2020-08-27 14:53:30 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:53:30 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:53:30 --> Utf8 Class Initialized
INFO - 2020-08-27 14:53:30 --> URI Class Initialized
INFO - 2020-08-27 14:53:30 --> Router Class Initialized
INFO - 2020-08-27 14:53:30 --> Output Class Initialized
INFO - 2020-08-27 14:53:30 --> Security Class Initialized
DEBUG - 2020-08-27 14:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:53:30 --> Input Class Initialized
INFO - 2020-08-27 14:53:30 --> Language Class Initialized
INFO - 2020-08-27 14:53:30 --> Loader Class Initialized
INFO - 2020-08-27 14:53:30 --> Helper loaded: url_helper
INFO - 2020-08-27 14:53:30 --> Database Driver Class Initialized
INFO - 2020-08-27 14:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:53:30 --> Email Class Initialized
INFO - 2020-08-27 14:53:30 --> Controller Class Initialized
DEBUG - 2020-08-27 14:53:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:53:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:53:30 --> Helper loaded: form_helper
INFO - 2020-08-27 14:53:30 --> Form Validation Class Initialized
INFO - 2020-08-27 14:53:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 14:53:30 --> Final output sent to browser
DEBUG - 2020-08-27 14:53:30 --> Total execution time: 0.0251
INFO - 2020-08-27 14:54:32 --> Config Class Initialized
INFO - 2020-08-27 14:54:32 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:54:32 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:54:32 --> Utf8 Class Initialized
INFO - 2020-08-27 14:54:32 --> URI Class Initialized
INFO - 2020-08-27 14:54:32 --> Router Class Initialized
INFO - 2020-08-27 14:54:32 --> Output Class Initialized
INFO - 2020-08-27 14:54:32 --> Security Class Initialized
DEBUG - 2020-08-27 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:54:32 --> Input Class Initialized
INFO - 2020-08-27 14:54:32 --> Language Class Initialized
INFO - 2020-08-27 14:54:32 --> Loader Class Initialized
INFO - 2020-08-27 14:54:32 --> Helper loaded: url_helper
INFO - 2020-08-27 14:54:32 --> Database Driver Class Initialized
INFO - 2020-08-27 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:54:32 --> Email Class Initialized
INFO - 2020-08-27 14:54:32 --> Controller Class Initialized
DEBUG - 2020-08-27 14:54:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:54:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:54:32 --> Helper loaded: form_helper
INFO - 2020-08-27 14:54:32 --> Form Validation Class Initialized
INFO - 2020-08-27 14:54:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 14:54:32 --> Final output sent to browser
DEBUG - 2020-08-27 14:54:32 --> Total execution time: 0.0252
INFO - 2020-08-27 14:54:39 --> Config Class Initialized
INFO - 2020-08-27 14:54:39 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:54:39 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:54:39 --> Utf8 Class Initialized
INFO - 2020-08-27 14:54:39 --> URI Class Initialized
INFO - 2020-08-27 14:54:39 --> Router Class Initialized
INFO - 2020-08-27 14:54:39 --> Output Class Initialized
INFO - 2020-08-27 14:54:39 --> Security Class Initialized
DEBUG - 2020-08-27 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:54:39 --> Input Class Initialized
INFO - 2020-08-27 14:54:39 --> Language Class Initialized
INFO - 2020-08-27 14:54:39 --> Loader Class Initialized
INFO - 2020-08-27 14:54:39 --> Helper loaded: url_helper
INFO - 2020-08-27 14:54:39 --> Database Driver Class Initialized
INFO - 2020-08-27 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:54:39 --> Email Class Initialized
INFO - 2020-08-27 14:54:39 --> Controller Class Initialized
DEBUG - 2020-08-27 14:54:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:54:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:54:39 --> Helper loaded: form_helper
INFO - 2020-08-27 14:54:39 --> Form Validation Class Initialized
INFO - 2020-08-27 14:54:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 14:54:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:72) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:54:39 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 72
INFO - 2020-08-27 14:55:26 --> Config Class Initialized
INFO - 2020-08-27 14:55:26 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:55:26 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:55:26 --> Utf8 Class Initialized
INFO - 2020-08-27 14:55:26 --> URI Class Initialized
INFO - 2020-08-27 14:55:26 --> Router Class Initialized
INFO - 2020-08-27 14:55:26 --> Output Class Initialized
INFO - 2020-08-27 14:55:26 --> Security Class Initialized
DEBUG - 2020-08-27 14:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:55:26 --> Input Class Initialized
INFO - 2020-08-27 14:55:26 --> Language Class Initialized
INFO - 2020-08-27 14:55:26 --> Loader Class Initialized
INFO - 2020-08-27 14:55:26 --> Helper loaded: url_helper
INFO - 2020-08-27 14:55:26 --> Database Driver Class Initialized
INFO - 2020-08-27 14:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:55:26 --> Email Class Initialized
INFO - 2020-08-27 14:55:26 --> Controller Class Initialized
DEBUG - 2020-08-27 14:55:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:55:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:55:26 --> Helper loaded: form_helper
INFO - 2020-08-27 14:55:26 --> Form Validation Class Initialized
INFO - 2020-08-27 14:55:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 14:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:77) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:55:26 --> Severity: Error --> Call to a member function load() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 77
INFO - 2020-08-27 14:55:55 --> Config Class Initialized
INFO - 2020-08-27 14:55:55 --> Hooks Class Initialized
DEBUG - 2020-08-27 14:55:55 --> UTF-8 Support Enabled
INFO - 2020-08-27 14:55:55 --> Utf8 Class Initialized
INFO - 2020-08-27 14:55:55 --> URI Class Initialized
INFO - 2020-08-27 14:55:55 --> Router Class Initialized
INFO - 2020-08-27 14:55:55 --> Output Class Initialized
INFO - 2020-08-27 14:55:55 --> Security Class Initialized
DEBUG - 2020-08-27 14:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 14:55:55 --> Input Class Initialized
INFO - 2020-08-27 14:55:55 --> Language Class Initialized
INFO - 2020-08-27 14:55:55 --> Loader Class Initialized
INFO - 2020-08-27 14:55:55 --> Helper loaded: url_helper
INFO - 2020-08-27 14:55:55 --> Database Driver Class Initialized
INFO - 2020-08-27 14:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 14:55:55 --> Email Class Initialized
INFO - 2020-08-27 14:55:55 --> Controller Class Initialized
DEBUG - 2020-08-27 14:55:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 14:55:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 14:55:55 --> Helper loaded: form_helper
INFO - 2020-08-27 14:55:55 --> Form Validation Class Initialized
INFO - 2020-08-27 14:55:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 14:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:72) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 14:55:55 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 72
INFO - 2020-08-27 15:00:31 --> Config Class Initialized
INFO - 2020-08-27 15:00:31 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:00:31 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:00:31 --> Utf8 Class Initialized
INFO - 2020-08-27 15:00:31 --> URI Class Initialized
INFO - 2020-08-27 15:00:31 --> Router Class Initialized
INFO - 2020-08-27 15:00:31 --> Output Class Initialized
INFO - 2020-08-27 15:00:31 --> Security Class Initialized
DEBUG - 2020-08-27 15:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:00:31 --> Input Class Initialized
INFO - 2020-08-27 15:00:31 --> Language Class Initialized
INFO - 2020-08-27 15:00:31 --> Loader Class Initialized
INFO - 2020-08-27 15:00:31 --> Helper loaded: url_helper
INFO - 2020-08-27 15:00:31 --> Database Driver Class Initialized
INFO - 2020-08-27 15:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:00:31 --> Email Class Initialized
INFO - 2020-08-27 15:00:31 --> Controller Class Initialized
DEBUG - 2020-08-27 15:00:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:00:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:00:31 --> Helper loaded: form_helper
INFO - 2020-08-27 15:00:31 --> Form Validation Class Initialized
INFO - 2020-08-27 15:00:31 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:00:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:75) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:00:31 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 75
INFO - 2020-08-27 15:00:38 --> Config Class Initialized
INFO - 2020-08-27 15:00:38 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:00:38 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:00:38 --> Utf8 Class Initialized
INFO - 2020-08-27 15:00:38 --> URI Class Initialized
INFO - 2020-08-27 15:00:38 --> Router Class Initialized
INFO - 2020-08-27 15:00:38 --> Output Class Initialized
INFO - 2020-08-27 15:00:38 --> Security Class Initialized
DEBUG - 2020-08-27 15:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:00:38 --> Input Class Initialized
INFO - 2020-08-27 15:00:38 --> Language Class Initialized
INFO - 2020-08-27 15:00:38 --> Loader Class Initialized
INFO - 2020-08-27 15:00:38 --> Helper loaded: url_helper
INFO - 2020-08-27 15:00:38 --> Database Driver Class Initialized
INFO - 2020-08-27 15:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:00:38 --> Email Class Initialized
INFO - 2020-08-27 15:00:38 --> Controller Class Initialized
DEBUG - 2020-08-27 15:00:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:00:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:00:38 --> Helper loaded: form_helper
INFO - 2020-08-27 15:00:38 --> Form Validation Class Initialized
INFO - 2020-08-27 15:00:38 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:00:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:75) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:00:38 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 75
ERROR - 2020-08-27 15:07:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:07:43 --> Config Class Initialized
INFO - 2020-08-27 15:07:43 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:07:43 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:07:43 --> Utf8 Class Initialized
INFO - 2020-08-27 15:07:43 --> URI Class Initialized
INFO - 2020-08-27 15:07:43 --> Router Class Initialized
INFO - 2020-08-27 15:07:43 --> Output Class Initialized
INFO - 2020-08-27 15:07:43 --> Security Class Initialized
DEBUG - 2020-08-27 15:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:07:43 --> Input Class Initialized
INFO - 2020-08-27 15:07:43 --> Language Class Initialized
INFO - 2020-08-27 15:07:43 --> Loader Class Initialized
INFO - 2020-08-27 15:07:43 --> Helper loaded: url_helper
INFO - 2020-08-27 15:07:43 --> Database Driver Class Initialized
INFO - 2020-08-27 15:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:07:43 --> Email Class Initialized
INFO - 2020-08-27 15:07:43 --> Controller Class Initialized
DEBUG - 2020-08-27 15:07:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:07:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:07:43 --> Helper loaded: form_helper
INFO - 2020-08-27 15:07:43 --> Form Validation Class Initialized
INFO - 2020-08-27 15:07:43 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:07:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:75) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:07:43 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 75
ERROR - 2020-08-27 15:07:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:07:47 --> Config Class Initialized
INFO - 2020-08-27 15:07:47 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:07:47 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:07:47 --> Utf8 Class Initialized
INFO - 2020-08-27 15:07:47 --> URI Class Initialized
INFO - 2020-08-27 15:07:47 --> Router Class Initialized
INFO - 2020-08-27 15:07:47 --> Output Class Initialized
INFO - 2020-08-27 15:07:47 --> Security Class Initialized
DEBUG - 2020-08-27 15:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:07:47 --> Input Class Initialized
INFO - 2020-08-27 15:07:47 --> Language Class Initialized
INFO - 2020-08-27 15:07:47 --> Loader Class Initialized
INFO - 2020-08-27 15:07:47 --> Helper loaded: url_helper
INFO - 2020-08-27 15:07:47 --> Database Driver Class Initialized
INFO - 2020-08-27 15:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:07:47 --> Email Class Initialized
INFO - 2020-08-27 15:07:47 --> Controller Class Initialized
DEBUG - 2020-08-27 15:07:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:07:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:07:47 --> Helper loaded: form_helper
INFO - 2020-08-27 15:07:47 --> Form Validation Class Initialized
INFO - 2020-08-27 15:07:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:07:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:75) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:07:47 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 75
ERROR - 2020-08-27 15:07:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:07:50 --> Config Class Initialized
INFO - 2020-08-27 15:07:50 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:07:50 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:07:50 --> Utf8 Class Initialized
INFO - 2020-08-27 15:07:50 --> URI Class Initialized
INFO - 2020-08-27 15:07:50 --> Router Class Initialized
INFO - 2020-08-27 15:07:50 --> Output Class Initialized
INFO - 2020-08-27 15:07:50 --> Security Class Initialized
DEBUG - 2020-08-27 15:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:07:50 --> Input Class Initialized
INFO - 2020-08-27 15:07:50 --> Language Class Initialized
INFO - 2020-08-27 15:07:50 --> Loader Class Initialized
INFO - 2020-08-27 15:07:50 --> Helper loaded: url_helper
INFO - 2020-08-27 15:07:50 --> Database Driver Class Initialized
INFO - 2020-08-27 15:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:07:50 --> Email Class Initialized
INFO - 2020-08-27 15:07:50 --> Controller Class Initialized
DEBUG - 2020-08-27 15:07:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:07:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:07:50 --> Helper loaded: form_helper
INFO - 2020-08-27 15:07:50 --> Form Validation Class Initialized
INFO - 2020-08-27 15:07:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:07:50 --> Final output sent to browser
DEBUG - 2020-08-27 15:07:50 --> Total execution time: 0.0188
ERROR - 2020-08-27 15:07:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:07:57 --> Config Class Initialized
INFO - 2020-08-27 15:07:57 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:07:57 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:07:57 --> Utf8 Class Initialized
INFO - 2020-08-27 15:07:57 --> URI Class Initialized
INFO - 2020-08-27 15:07:57 --> Router Class Initialized
INFO - 2020-08-27 15:07:57 --> Output Class Initialized
INFO - 2020-08-27 15:07:57 --> Security Class Initialized
DEBUG - 2020-08-27 15:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:07:57 --> Input Class Initialized
INFO - 2020-08-27 15:07:57 --> Language Class Initialized
INFO - 2020-08-27 15:07:57 --> Loader Class Initialized
INFO - 2020-08-27 15:07:57 --> Helper loaded: url_helper
INFO - 2020-08-27 15:07:57 --> Database Driver Class Initialized
INFO - 2020-08-27 15:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:07:57 --> Email Class Initialized
INFO - 2020-08-27 15:07:57 --> Controller Class Initialized
DEBUG - 2020-08-27 15:07:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:07:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:07:57 --> Helper loaded: form_helper
INFO - 2020-08-27 15:07:57 --> Form Validation Class Initialized
INFO - 2020-08-27 15:07:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:07:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:75) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:07:57 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 75
ERROR - 2020-08-27 15:17:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:17:33 --> Config Class Initialized
INFO - 2020-08-27 15:17:33 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:17:33 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:17:33 --> Utf8 Class Initialized
INFO - 2020-08-27 15:17:33 --> URI Class Initialized
INFO - 2020-08-27 15:17:33 --> Router Class Initialized
INFO - 2020-08-27 15:17:33 --> Output Class Initialized
INFO - 2020-08-27 15:17:33 --> Security Class Initialized
DEBUG - 2020-08-27 15:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:17:33 --> Input Class Initialized
INFO - 2020-08-27 15:17:33 --> Language Class Initialized
INFO - 2020-08-27 15:17:33 --> Loader Class Initialized
INFO - 2020-08-27 15:17:33 --> Helper loaded: url_helper
INFO - 2020-08-27 15:17:33 --> Database Driver Class Initialized
INFO - 2020-08-27 15:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:17:33 --> Email Class Initialized
INFO - 2020-08-27 15:17:33 --> Controller Class Initialized
DEBUG - 2020-08-27 15:17:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:17:33 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-27 15:17:33 --> Unable to load the requested class: Excel_reader
ERROR - 2020-08-27 15:20:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:20:45 --> Config Class Initialized
INFO - 2020-08-27 15:20:45 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:20:45 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:20:45 --> Utf8 Class Initialized
INFO - 2020-08-27 15:20:45 --> URI Class Initialized
INFO - 2020-08-27 15:20:45 --> Router Class Initialized
INFO - 2020-08-27 15:20:45 --> Output Class Initialized
INFO - 2020-08-27 15:20:45 --> Security Class Initialized
DEBUG - 2020-08-27 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:20:45 --> Input Class Initialized
INFO - 2020-08-27 15:20:45 --> Language Class Initialized
INFO - 2020-08-27 15:20:45 --> Loader Class Initialized
INFO - 2020-08-27 15:20:45 --> Helper loaded: url_helper
INFO - 2020-08-27 15:20:45 --> Database Driver Class Initialized
INFO - 2020-08-27 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:20:45 --> Email Class Initialized
INFO - 2020-08-27 15:20:45 --> Controller Class Initialized
DEBUG - 2020-08-27 15:20:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:20:45 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-27 15:20:45 --> Unable to load the requested class: Excel_reader
ERROR - 2020-08-27 15:20:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:20:47 --> Config Class Initialized
INFO - 2020-08-27 15:20:47 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:20:47 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:20:47 --> Utf8 Class Initialized
INFO - 2020-08-27 15:20:47 --> URI Class Initialized
INFO - 2020-08-27 15:20:47 --> Router Class Initialized
INFO - 2020-08-27 15:20:47 --> Output Class Initialized
INFO - 2020-08-27 15:20:47 --> Security Class Initialized
DEBUG - 2020-08-27 15:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:20:47 --> Input Class Initialized
INFO - 2020-08-27 15:20:47 --> Language Class Initialized
INFO - 2020-08-27 15:20:47 --> Loader Class Initialized
INFO - 2020-08-27 15:20:47 --> Helper loaded: url_helper
INFO - 2020-08-27 15:20:47 --> Database Driver Class Initialized
INFO - 2020-08-27 15:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:20:47 --> Email Class Initialized
INFO - 2020-08-27 15:20:47 --> Controller Class Initialized
DEBUG - 2020-08-27 15:20:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:20:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:20:47 --> Model Class Initialized
INFO - 2020-08-27 15:20:47 --> Model Class Initialized
INFO - 2020-08-27 15:20:47 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-27 15:20:47 --> Final output sent to browser
DEBUG - 2020-08-27 15:20:47 --> Total execution time: 0.0249
ERROR - 2020-08-27 15:21:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:21:04 --> Config Class Initialized
INFO - 2020-08-27 15:21:04 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:21:04 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:21:04 --> Utf8 Class Initialized
INFO - 2020-08-27 15:21:04 --> URI Class Initialized
INFO - 2020-08-27 15:21:04 --> Router Class Initialized
INFO - 2020-08-27 15:21:04 --> Output Class Initialized
INFO - 2020-08-27 15:21:04 --> Security Class Initialized
DEBUG - 2020-08-27 15:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:21:04 --> Input Class Initialized
INFO - 2020-08-27 15:21:04 --> Language Class Initialized
INFO - 2020-08-27 15:21:04 --> Loader Class Initialized
INFO - 2020-08-27 15:21:04 --> Helper loaded: url_helper
INFO - 2020-08-27 15:21:04 --> Database Driver Class Initialized
INFO - 2020-08-27 15:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:21:04 --> Email Class Initialized
INFO - 2020-08-27 15:21:04 --> Controller Class Initialized
DEBUG - 2020-08-27 15:21:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:21:04 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-08-27 15:21:04 --> Unable to load the requested class: Excel_reader
ERROR - 2020-08-27 15:21:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:21:30 --> Config Class Initialized
INFO - 2020-08-27 15:21:30 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:21:30 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:21:30 --> Utf8 Class Initialized
INFO - 2020-08-27 15:21:30 --> URI Class Initialized
INFO - 2020-08-27 15:21:30 --> Router Class Initialized
INFO - 2020-08-27 15:21:30 --> Output Class Initialized
INFO - 2020-08-27 15:21:30 --> Security Class Initialized
DEBUG - 2020-08-27 15:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:21:30 --> Input Class Initialized
INFO - 2020-08-27 15:21:30 --> Language Class Initialized
INFO - 2020-08-27 15:21:30 --> Loader Class Initialized
INFO - 2020-08-27 15:21:30 --> Helper loaded: url_helper
INFO - 2020-08-27 15:21:30 --> Database Driver Class Initialized
INFO - 2020-08-27 15:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:21:30 --> Email Class Initialized
INFO - 2020-08-27 15:21:30 --> Controller Class Initialized
DEBUG - 2020-08-27 15:21:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:21:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:21:30 --> Helper loaded: form_helper
INFO - 2020-08-27 15:21:30 --> Form Validation Class Initialized
INFO - 2020-08-27 15:21:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:21:30 --> Final output sent to browser
DEBUG - 2020-08-27 15:21:30 --> Total execution time: 0.0228
ERROR - 2020-08-27 15:25:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:25:09 --> Config Class Initialized
INFO - 2020-08-27 15:25:09 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:25:09 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:25:09 --> Utf8 Class Initialized
INFO - 2020-08-27 15:25:09 --> URI Class Initialized
INFO - 2020-08-27 15:25:09 --> Router Class Initialized
INFO - 2020-08-27 15:25:09 --> Output Class Initialized
INFO - 2020-08-27 15:25:09 --> Security Class Initialized
DEBUG - 2020-08-27 15:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:25:09 --> Input Class Initialized
INFO - 2020-08-27 15:25:09 --> Language Class Initialized
INFO - 2020-08-27 15:25:09 --> Loader Class Initialized
INFO - 2020-08-27 15:25:09 --> Helper loaded: url_helper
INFO - 2020-08-27 15:25:09 --> Database Driver Class Initialized
INFO - 2020-08-27 15:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:25:09 --> Email Class Initialized
INFO - 2020-08-27 15:25:09 --> Controller Class Initialized
DEBUG - 2020-08-27 15:25:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:25:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:25:09 --> Helper loaded: form_helper
INFO - 2020-08-27 15:25:09 --> Form Validation Class Initialized
INFO - 2020-08-27 15:25:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:25:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:76) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:25:09 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 76
ERROR - 2020-08-27 15:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:27:12 --> Config Class Initialized
INFO - 2020-08-27 15:27:12 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:27:12 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:27:12 --> Utf8 Class Initialized
INFO - 2020-08-27 15:27:12 --> URI Class Initialized
INFO - 2020-08-27 15:27:12 --> Router Class Initialized
INFO - 2020-08-27 15:27:12 --> Output Class Initialized
INFO - 2020-08-27 15:27:12 --> Security Class Initialized
DEBUG - 2020-08-27 15:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:27:12 --> Input Class Initialized
INFO - 2020-08-27 15:27:12 --> Language Class Initialized
ERROR - 2020-08-27 15:27:12 --> Severity: Warning --> require(phptoexcel/vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 7
ERROR - 2020-08-27 15:27:12 --> Severity: Warning --> require(phptoexcel/vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 7
ERROR - 2020-08-27 15:27:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:27:12 --> Severity: Compile Error --> require(): Failed opening required 'phptoexcel/vendor/autoload.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 7
ERROR - 2020-08-27 15:29:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:29:05 --> Config Class Initialized
INFO - 2020-08-27 15:29:05 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:29:05 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:29:05 --> Utf8 Class Initialized
INFO - 2020-08-27 15:29:05 --> URI Class Initialized
INFO - 2020-08-27 15:29:06 --> Router Class Initialized
INFO - 2020-08-27 15:29:06 --> Output Class Initialized
INFO - 2020-08-27 15:29:06 --> Security Class Initialized
DEBUG - 2020-08-27 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:29:06 --> Input Class Initialized
INFO - 2020-08-27 15:29:06 --> Language Class Initialized
INFO - 2020-08-27 15:29:06 --> Loader Class Initialized
INFO - 2020-08-27 15:29:06 --> Helper loaded: url_helper
INFO - 2020-08-27 15:29:06 --> Database Driver Class Initialized
INFO - 2020-08-27 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:29:06 --> Email Class Initialized
INFO - 2020-08-27 15:29:06 --> Controller Class Initialized
DEBUG - 2020-08-27 15:29:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:29:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:29:06 --> Helper loaded: form_helper
INFO - 2020-08-27 15:29:06 --> Form Validation Class Initialized
INFO - 2020-08-27 15:29:06 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:29:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:78) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:29:06 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 78
ERROR - 2020-08-27 15:32:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:32:09 --> Config Class Initialized
INFO - 2020-08-27 15:32:09 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:32:09 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:32:09 --> Utf8 Class Initialized
INFO - 2020-08-27 15:32:09 --> URI Class Initialized
INFO - 2020-08-27 15:32:09 --> Router Class Initialized
INFO - 2020-08-27 15:32:09 --> Output Class Initialized
INFO - 2020-08-27 15:32:09 --> Security Class Initialized
DEBUG - 2020-08-27 15:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:32:09 --> Input Class Initialized
INFO - 2020-08-27 15:32:09 --> Language Class Initialized
INFO - 2020-08-27 15:32:09 --> Loader Class Initialized
INFO - 2020-08-27 15:32:09 --> Helper loaded: url_helper
INFO - 2020-08-27 15:32:09 --> Database Driver Class Initialized
INFO - 2020-08-27 15:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:32:09 --> Email Class Initialized
INFO - 2020-08-27 15:32:09 --> Controller Class Initialized
DEBUG - 2020-08-27 15:32:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:32:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:32:09 --> Helper loaded: form_helper
INFO - 2020-08-27 15:32:09 --> Form Validation Class Initialized
INFO - 2020-08-27 15:32:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:32:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:77) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:32:09 --> Severity: Error --> Call to a member function load() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 77
ERROR - 2020-08-27 15:32:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:32:47 --> Config Class Initialized
INFO - 2020-08-27 15:32:47 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:32:47 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:32:47 --> Utf8 Class Initialized
INFO - 2020-08-27 15:32:47 --> URI Class Initialized
INFO - 2020-08-27 15:32:47 --> Router Class Initialized
INFO - 2020-08-27 15:32:47 --> Output Class Initialized
INFO - 2020-08-27 15:32:47 --> Security Class Initialized
DEBUG - 2020-08-27 15:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:32:47 --> Input Class Initialized
INFO - 2020-08-27 15:32:47 --> Language Class Initialized
INFO - 2020-08-27 15:32:47 --> Loader Class Initialized
INFO - 2020-08-27 15:32:47 --> Helper loaded: url_helper
INFO - 2020-08-27 15:32:47 --> Database Driver Class Initialized
INFO - 2020-08-27 15:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:32:47 --> Email Class Initialized
INFO - 2020-08-27 15:32:47 --> Controller Class Initialized
DEBUG - 2020-08-27 15:32:47 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:32:47 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:32:47 --> Helper loaded: form_helper
INFO - 2020-08-27 15:32:47 --> Form Validation Class Initialized
INFO - 2020-08-27 15:32:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:32:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:78) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:32:47 --> Severity: Error --> Call to a member function getActiveSheet() on a non-object /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 78
ERROR - 2020-08-27 15:33:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:33:54 --> Config Class Initialized
INFO - 2020-08-27 15:33:54 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:33:54 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:33:54 --> Utf8 Class Initialized
INFO - 2020-08-27 15:33:54 --> URI Class Initialized
INFO - 2020-08-27 15:33:54 --> Router Class Initialized
INFO - 2020-08-27 15:33:54 --> Output Class Initialized
INFO - 2020-08-27 15:33:54 --> Security Class Initialized
DEBUG - 2020-08-27 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:33:54 --> Input Class Initialized
INFO - 2020-08-27 15:33:54 --> Language Class Initialized
ERROR - 2020-08-27 15:33:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:6) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:33:54 --> Severity: Compile Error --> Cannot use PhpOffice\PhpSpreadsheet\Reader\Xlsx as Xlsx because the name is already in use /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 6
ERROR - 2020-08-27 15:37:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:37:53 --> Config Class Initialized
INFO - 2020-08-27 15:37:53 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:37:53 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:37:53 --> Utf8 Class Initialized
INFO - 2020-08-27 15:37:53 --> URI Class Initialized
INFO - 2020-08-27 15:37:53 --> Router Class Initialized
INFO - 2020-08-27 15:37:53 --> Output Class Initialized
INFO - 2020-08-27 15:37:53 --> Security Class Initialized
DEBUG - 2020-08-27 15:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:37:53 --> Input Class Initialized
INFO - 2020-08-27 15:37:53 --> Language Class Initialized
INFO - 2020-08-27 15:37:53 --> Loader Class Initialized
INFO - 2020-08-27 15:37:53 --> Helper loaded: url_helper
INFO - 2020-08-27 15:37:53 --> Database Driver Class Initialized
INFO - 2020-08-27 15:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:37:53 --> Email Class Initialized
INFO - 2020-08-27 15:37:53 --> Controller Class Initialized
DEBUG - 2020-08-27 15:37:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:37:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:37:53 --> Helper loaded: form_helper
INFO - 2020-08-27 15:37:53 --> Form Validation Class Initialized
INFO - 2020-08-27 15:37:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 15:37:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:79) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 15:37:53 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 79
ERROR - 2020-08-27 15:44:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:44:29 --> Config Class Initialized
INFO - 2020-08-27 15:44:29 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:44:29 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:44:29 --> Utf8 Class Initialized
INFO - 2020-08-27 15:44:29 --> URI Class Initialized
INFO - 2020-08-27 15:44:29 --> Router Class Initialized
INFO - 2020-08-27 15:44:29 --> Output Class Initialized
INFO - 2020-08-27 15:44:29 --> Security Class Initialized
DEBUG - 2020-08-27 15:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:44:29 --> Input Class Initialized
INFO - 2020-08-27 15:44:29 --> Language Class Initialized
ERROR - 2020-08-27 15:44:29 --> 404 Page Not Found: Upload/upload
ERROR - 2020-08-27 15:44:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:44:39 --> Config Class Initialized
INFO - 2020-08-27 15:44:39 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:44:39 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:44:39 --> Utf8 Class Initialized
INFO - 2020-08-27 15:44:39 --> URI Class Initialized
INFO - 2020-08-27 15:44:39 --> Router Class Initialized
INFO - 2020-08-27 15:44:39 --> Output Class Initialized
INFO - 2020-08-27 15:44:39 --> Security Class Initialized
DEBUG - 2020-08-27 15:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:44:39 --> Input Class Initialized
INFO - 2020-08-27 15:44:39 --> Language Class Initialized
ERROR - 2020-08-27 15:44:39 --> 404 Page Not Found: Upload/excle_upload
ERROR - 2020-08-27 15:45:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:45:02 --> Config Class Initialized
INFO - 2020-08-27 15:45:02 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:45:02 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:45:02 --> Utf8 Class Initialized
INFO - 2020-08-27 15:45:02 --> URI Class Initialized
INFO - 2020-08-27 15:45:02 --> Router Class Initialized
INFO - 2020-08-27 15:45:02 --> Output Class Initialized
INFO - 2020-08-27 15:45:02 --> Security Class Initialized
DEBUG - 2020-08-27 15:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:45:02 --> Input Class Initialized
INFO - 2020-08-27 15:45:02 --> Language Class Initialized
INFO - 2020-08-27 15:45:02 --> Loader Class Initialized
INFO - 2020-08-27 15:45:02 --> Helper loaded: url_helper
INFO - 2020-08-27 15:45:02 --> Database Driver Class Initialized
INFO - 2020-08-27 15:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:45:02 --> Email Class Initialized
INFO - 2020-08-27 15:45:02 --> Controller Class Initialized
DEBUG - 2020-08-27 15:45:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:45:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:45:02 --> Helper loaded: form_helper
INFO - 2020-08-27 15:45:02 --> Form Validation Class Initialized
INFO - 2020-08-27 15:45:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:45:02 --> Final output sent to browser
DEBUG - 2020-08-27 15:45:02 --> Total execution time: 0.0229
ERROR - 2020-08-27 15:45:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:45:58 --> Config Class Initialized
INFO - 2020-08-27 15:45:58 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:45:58 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:45:58 --> Utf8 Class Initialized
INFO - 2020-08-27 15:45:58 --> URI Class Initialized
INFO - 2020-08-27 15:45:58 --> Router Class Initialized
INFO - 2020-08-27 15:45:58 --> Output Class Initialized
INFO - 2020-08-27 15:45:58 --> Security Class Initialized
DEBUG - 2020-08-27 15:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:45:58 --> Input Class Initialized
INFO - 2020-08-27 15:45:58 --> Language Class Initialized
INFO - 2020-08-27 15:45:58 --> Loader Class Initialized
INFO - 2020-08-27 15:45:58 --> Helper loaded: url_helper
INFO - 2020-08-27 15:45:58 --> Database Driver Class Initialized
INFO - 2020-08-27 15:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:45:58 --> Email Class Initialized
INFO - 2020-08-27 15:45:58 --> Controller Class Initialized
DEBUG - 2020-08-27 15:45:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:45:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:45:58 --> Helper loaded: form_helper
INFO - 2020-08-27 15:45:58 --> Form Validation Class Initialized
INFO - 2020-08-27 15:45:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:45:58 --> Final output sent to browser
DEBUG - 2020-08-27 15:45:58 --> Total execution time: 0.0225
ERROR - 2020-08-27 15:46:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:46:44 --> Config Class Initialized
INFO - 2020-08-27 15:46:44 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:46:44 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:46:44 --> Utf8 Class Initialized
INFO - 2020-08-27 15:46:44 --> URI Class Initialized
INFO - 2020-08-27 15:46:44 --> Router Class Initialized
INFO - 2020-08-27 15:46:44 --> Output Class Initialized
INFO - 2020-08-27 15:46:44 --> Security Class Initialized
DEBUG - 2020-08-27 15:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:46:44 --> Input Class Initialized
INFO - 2020-08-27 15:46:44 --> Language Class Initialized
INFO - 2020-08-27 15:46:44 --> Loader Class Initialized
INFO - 2020-08-27 15:46:44 --> Helper loaded: url_helper
INFO - 2020-08-27 15:46:44 --> Database Driver Class Initialized
INFO - 2020-08-27 15:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:46:44 --> Email Class Initialized
INFO - 2020-08-27 15:46:44 --> Controller Class Initialized
DEBUG - 2020-08-27 15:46:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:46:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:46:44 --> Helper loaded: form_helper
INFO - 2020-08-27 15:46:44 --> Form Validation Class Initialized
INFO - 2020-08-27 15:46:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:46:44 --> Final output sent to browser
DEBUG - 2020-08-27 15:46:44 --> Total execution time: 0.0216
ERROR - 2020-08-27 15:47:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:47:26 --> Config Class Initialized
INFO - 2020-08-27 15:47:26 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:47:26 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:47:26 --> Utf8 Class Initialized
INFO - 2020-08-27 15:47:26 --> URI Class Initialized
INFO - 2020-08-27 15:47:26 --> Router Class Initialized
INFO - 2020-08-27 15:47:26 --> Output Class Initialized
INFO - 2020-08-27 15:47:26 --> Security Class Initialized
DEBUG - 2020-08-27 15:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:47:26 --> Input Class Initialized
INFO - 2020-08-27 15:47:26 --> Language Class Initialized
INFO - 2020-08-27 15:47:26 --> Loader Class Initialized
INFO - 2020-08-27 15:47:26 --> Helper loaded: url_helper
INFO - 2020-08-27 15:47:26 --> Database Driver Class Initialized
INFO - 2020-08-27 15:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:47:26 --> Email Class Initialized
INFO - 2020-08-27 15:47:26 --> Controller Class Initialized
DEBUG - 2020-08-27 15:47:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:47:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:47:26 --> Helper loaded: form_helper
INFO - 2020-08-27 15:47:26 --> Form Validation Class Initialized
INFO - 2020-08-27 15:47:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:47:26 --> Final output sent to browser
DEBUG - 2020-08-27 15:47:26 --> Total execution time: 0.0200
ERROR - 2020-08-27 15:47:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:47:46 --> Config Class Initialized
INFO - 2020-08-27 15:47:46 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:47:46 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:47:46 --> Utf8 Class Initialized
INFO - 2020-08-27 15:47:46 --> URI Class Initialized
INFO - 2020-08-27 15:47:46 --> Router Class Initialized
INFO - 2020-08-27 15:47:46 --> Output Class Initialized
INFO - 2020-08-27 15:47:46 --> Security Class Initialized
DEBUG - 2020-08-27 15:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:47:46 --> Input Class Initialized
INFO - 2020-08-27 15:47:46 --> Language Class Initialized
INFO - 2020-08-27 15:47:46 --> Loader Class Initialized
INFO - 2020-08-27 15:47:46 --> Helper loaded: url_helper
INFO - 2020-08-27 15:47:46 --> Database Driver Class Initialized
INFO - 2020-08-27 15:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:47:46 --> Email Class Initialized
INFO - 2020-08-27 15:47:46 --> Controller Class Initialized
DEBUG - 2020-08-27 15:47:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:47:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:47:46 --> Helper loaded: form_helper
INFO - 2020-08-27 15:47:46 --> Form Validation Class Initialized
INFO - 2020-08-27 15:47:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:47:46 --> Final output sent to browser
DEBUG - 2020-08-27 15:47:46 --> Total execution time: 0.0244
ERROR - 2020-08-27 15:48:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:48:16 --> Config Class Initialized
INFO - 2020-08-27 15:48:16 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:48:16 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:48:16 --> Utf8 Class Initialized
INFO - 2020-08-27 15:48:16 --> URI Class Initialized
INFO - 2020-08-27 15:48:16 --> Router Class Initialized
INFO - 2020-08-27 15:48:16 --> Output Class Initialized
INFO - 2020-08-27 15:48:16 --> Security Class Initialized
DEBUG - 2020-08-27 15:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:48:16 --> Input Class Initialized
INFO - 2020-08-27 15:48:16 --> Language Class Initialized
INFO - 2020-08-27 15:48:16 --> Loader Class Initialized
INFO - 2020-08-27 15:48:16 --> Helper loaded: url_helper
INFO - 2020-08-27 15:48:16 --> Database Driver Class Initialized
INFO - 2020-08-27 15:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:48:16 --> Email Class Initialized
INFO - 2020-08-27 15:48:16 --> Controller Class Initialized
DEBUG - 2020-08-27 15:48:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:48:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:48:16 --> Helper loaded: form_helper
INFO - 2020-08-27 15:48:16 --> Form Validation Class Initialized
INFO - 2020-08-27 15:48:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:48:16 --> Final output sent to browser
DEBUG - 2020-08-27 15:48:16 --> Total execution time: 0.0244
ERROR - 2020-08-27 15:49:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:49:18 --> Config Class Initialized
INFO - 2020-08-27 15:49:18 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:49:18 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:49:18 --> Utf8 Class Initialized
INFO - 2020-08-27 15:49:18 --> URI Class Initialized
INFO - 2020-08-27 15:49:18 --> Router Class Initialized
INFO - 2020-08-27 15:49:18 --> Output Class Initialized
INFO - 2020-08-27 15:49:18 --> Security Class Initialized
DEBUG - 2020-08-27 15:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:49:18 --> Input Class Initialized
INFO - 2020-08-27 15:49:18 --> Language Class Initialized
INFO - 2020-08-27 15:49:18 --> Loader Class Initialized
INFO - 2020-08-27 15:49:18 --> Helper loaded: url_helper
INFO - 2020-08-27 15:49:18 --> Database Driver Class Initialized
INFO - 2020-08-27 15:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:49:18 --> Email Class Initialized
INFO - 2020-08-27 15:49:18 --> Controller Class Initialized
DEBUG - 2020-08-27 15:49:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:49:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:49:18 --> Helper loaded: form_helper
INFO - 2020-08-27 15:49:18 --> Form Validation Class Initialized
INFO - 2020-08-27 15:49:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:49:18 --> Final output sent to browser
DEBUG - 2020-08-27 15:49:18 --> Total execution time: 0.0179
ERROR - 2020-08-27 15:50:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:50:03 --> Config Class Initialized
INFO - 2020-08-27 15:50:03 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:50:03 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:50:03 --> Utf8 Class Initialized
INFO - 2020-08-27 15:50:03 --> URI Class Initialized
INFO - 2020-08-27 15:50:03 --> Router Class Initialized
INFO - 2020-08-27 15:50:03 --> Output Class Initialized
INFO - 2020-08-27 15:50:03 --> Security Class Initialized
DEBUG - 2020-08-27 15:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:50:03 --> Input Class Initialized
INFO - 2020-08-27 15:50:03 --> Language Class Initialized
INFO - 2020-08-27 15:50:03 --> Loader Class Initialized
INFO - 2020-08-27 15:50:03 --> Helper loaded: url_helper
INFO - 2020-08-27 15:50:03 --> Database Driver Class Initialized
INFO - 2020-08-27 15:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:50:03 --> Email Class Initialized
INFO - 2020-08-27 15:50:03 --> Controller Class Initialized
DEBUG - 2020-08-27 15:50:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:50:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:50:03 --> Helper loaded: form_helper
INFO - 2020-08-27 15:50:03 --> Form Validation Class Initialized
INFO - 2020-08-27 15:50:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:50:03 --> Final output sent to browser
DEBUG - 2020-08-27 15:50:03 --> Total execution time: 0.0213
ERROR - 2020-08-27 15:51:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:51:22 --> Config Class Initialized
INFO - 2020-08-27 15:51:22 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:51:22 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:51:22 --> Utf8 Class Initialized
INFO - 2020-08-27 15:51:22 --> URI Class Initialized
INFO - 2020-08-27 15:51:22 --> Router Class Initialized
INFO - 2020-08-27 15:51:22 --> Output Class Initialized
INFO - 2020-08-27 15:51:22 --> Security Class Initialized
DEBUG - 2020-08-27 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:51:22 --> Input Class Initialized
INFO - 2020-08-27 15:51:22 --> Language Class Initialized
INFO - 2020-08-27 15:51:22 --> Loader Class Initialized
INFO - 2020-08-27 15:51:22 --> Helper loaded: url_helper
INFO - 2020-08-27 15:51:22 --> Database Driver Class Initialized
INFO - 2020-08-27 15:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:51:22 --> Email Class Initialized
INFO - 2020-08-27 15:51:22 --> Controller Class Initialized
DEBUG - 2020-08-27 15:51:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:51:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:51:22 --> Helper loaded: form_helper
INFO - 2020-08-27 15:51:22 --> Form Validation Class Initialized
INFO - 2020-08-27 15:51:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:51:22 --> Final output sent to browser
DEBUG - 2020-08-27 15:51:22 --> Total execution time: 0.0223
ERROR - 2020-08-27 15:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:51:57 --> Config Class Initialized
INFO - 2020-08-27 15:51:57 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:51:57 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:51:57 --> Utf8 Class Initialized
INFO - 2020-08-27 15:51:57 --> URI Class Initialized
INFO - 2020-08-27 15:51:57 --> Router Class Initialized
INFO - 2020-08-27 15:51:57 --> Output Class Initialized
INFO - 2020-08-27 15:51:57 --> Security Class Initialized
DEBUG - 2020-08-27 15:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:51:57 --> Input Class Initialized
INFO - 2020-08-27 15:51:57 --> Language Class Initialized
INFO - 2020-08-27 15:51:57 --> Loader Class Initialized
INFO - 2020-08-27 15:51:57 --> Helper loaded: url_helper
INFO - 2020-08-27 15:51:57 --> Database Driver Class Initialized
INFO - 2020-08-27 15:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:51:57 --> Email Class Initialized
INFO - 2020-08-27 15:51:57 --> Controller Class Initialized
DEBUG - 2020-08-27 15:51:57 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:51:57 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:51:57 --> Helper loaded: form_helper
INFO - 2020-08-27 15:51:57 --> Form Validation Class Initialized
INFO - 2020-08-27 15:51:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:51:57 --> Final output sent to browser
DEBUG - 2020-08-27 15:51:57 --> Total execution time: 0.0205
ERROR - 2020-08-27 15:52:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:52:24 --> Config Class Initialized
INFO - 2020-08-27 15:52:24 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:52:24 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:52:24 --> Utf8 Class Initialized
INFO - 2020-08-27 15:52:24 --> URI Class Initialized
INFO - 2020-08-27 15:52:24 --> Router Class Initialized
INFO - 2020-08-27 15:52:24 --> Output Class Initialized
INFO - 2020-08-27 15:52:24 --> Security Class Initialized
DEBUG - 2020-08-27 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:52:24 --> Input Class Initialized
INFO - 2020-08-27 15:52:24 --> Language Class Initialized
INFO - 2020-08-27 15:52:24 --> Loader Class Initialized
INFO - 2020-08-27 15:52:24 --> Helper loaded: url_helper
INFO - 2020-08-27 15:52:24 --> Database Driver Class Initialized
INFO - 2020-08-27 15:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:52:24 --> Email Class Initialized
INFO - 2020-08-27 15:52:24 --> Controller Class Initialized
DEBUG - 2020-08-27 15:52:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:52:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:52:24 --> Helper loaded: form_helper
INFO - 2020-08-27 15:52:24 --> Form Validation Class Initialized
INFO - 2020-08-27 15:52:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:52:24 --> Final output sent to browser
DEBUG - 2020-08-27 15:52:24 --> Total execution time: 0.0183
ERROR - 2020-08-27 15:54:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:54:12 --> Config Class Initialized
INFO - 2020-08-27 15:54:12 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:54:12 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:54:12 --> Utf8 Class Initialized
INFO - 2020-08-27 15:54:12 --> URI Class Initialized
INFO - 2020-08-27 15:54:12 --> Router Class Initialized
INFO - 2020-08-27 15:54:12 --> Output Class Initialized
INFO - 2020-08-27 15:54:12 --> Security Class Initialized
DEBUG - 2020-08-27 15:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:54:12 --> Input Class Initialized
INFO - 2020-08-27 15:54:12 --> Language Class Initialized
INFO - 2020-08-27 15:54:12 --> Loader Class Initialized
INFO - 2020-08-27 15:54:12 --> Helper loaded: url_helper
INFO - 2020-08-27 15:54:12 --> Database Driver Class Initialized
INFO - 2020-08-27 15:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:54:12 --> Email Class Initialized
INFO - 2020-08-27 15:54:12 --> Controller Class Initialized
DEBUG - 2020-08-27 15:54:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:54:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:54:12 --> Helper loaded: form_helper
INFO - 2020-08-27 15:54:12 --> Form Validation Class Initialized
INFO - 2020-08-27 15:54:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:54:12 --> Final output sent to browser
DEBUG - 2020-08-27 15:54:12 --> Total execution time: 0.0193
ERROR - 2020-08-27 15:54:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:54:43 --> Config Class Initialized
INFO - 2020-08-27 15:54:43 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:54:43 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:54:43 --> Utf8 Class Initialized
INFO - 2020-08-27 15:54:43 --> URI Class Initialized
INFO - 2020-08-27 15:54:43 --> Router Class Initialized
INFO - 2020-08-27 15:54:43 --> Output Class Initialized
INFO - 2020-08-27 15:54:43 --> Security Class Initialized
DEBUG - 2020-08-27 15:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:54:43 --> Input Class Initialized
INFO - 2020-08-27 15:54:43 --> Language Class Initialized
INFO - 2020-08-27 15:54:43 --> Loader Class Initialized
INFO - 2020-08-27 15:54:43 --> Helper loaded: url_helper
INFO - 2020-08-27 15:54:43 --> Database Driver Class Initialized
INFO - 2020-08-27 15:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:54:43 --> Email Class Initialized
INFO - 2020-08-27 15:54:43 --> Controller Class Initialized
DEBUG - 2020-08-27 15:54:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:54:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:54:43 --> Helper loaded: form_helper
INFO - 2020-08-27 15:54:43 --> Form Validation Class Initialized
INFO - 2020-08-27 15:54:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:54:43 --> Final output sent to browser
DEBUG - 2020-08-27 15:54:43 --> Total execution time: 0.0221
ERROR - 2020-08-27 15:54:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:54:48 --> Config Class Initialized
INFO - 2020-08-27 15:54:48 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:54:48 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:54:48 --> Utf8 Class Initialized
INFO - 2020-08-27 15:54:48 --> URI Class Initialized
INFO - 2020-08-27 15:54:48 --> Router Class Initialized
INFO - 2020-08-27 15:54:48 --> Output Class Initialized
INFO - 2020-08-27 15:54:48 --> Security Class Initialized
DEBUG - 2020-08-27 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:54:48 --> Input Class Initialized
INFO - 2020-08-27 15:54:48 --> Language Class Initialized
INFO - 2020-08-27 15:54:48 --> Loader Class Initialized
INFO - 2020-08-27 15:54:48 --> Helper loaded: url_helper
INFO - 2020-08-27 15:54:48 --> Database Driver Class Initialized
INFO - 2020-08-27 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:54:48 --> Email Class Initialized
INFO - 2020-08-27 15:54:48 --> Controller Class Initialized
DEBUG - 2020-08-27 15:54:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:54:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:54:48 --> Helper loaded: form_helper
INFO - 2020-08-27 15:54:48 --> Form Validation Class Initialized
INFO - 2020-08-27 15:54:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:54:48 --> Final output sent to browser
DEBUG - 2020-08-27 15:54:48 --> Total execution time: 0.0232
ERROR - 2020-08-27 15:55:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 15:55:02 --> Config Class Initialized
INFO - 2020-08-27 15:55:02 --> Hooks Class Initialized
DEBUG - 2020-08-27 15:55:02 --> UTF-8 Support Enabled
INFO - 2020-08-27 15:55:02 --> Utf8 Class Initialized
INFO - 2020-08-27 15:55:02 --> URI Class Initialized
INFO - 2020-08-27 15:55:02 --> Router Class Initialized
INFO - 2020-08-27 15:55:02 --> Output Class Initialized
INFO - 2020-08-27 15:55:02 --> Security Class Initialized
DEBUG - 2020-08-27 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 15:55:02 --> Input Class Initialized
INFO - 2020-08-27 15:55:02 --> Language Class Initialized
INFO - 2020-08-27 15:55:02 --> Loader Class Initialized
INFO - 2020-08-27 15:55:02 --> Helper loaded: url_helper
INFO - 2020-08-27 15:55:02 --> Database Driver Class Initialized
INFO - 2020-08-27 15:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 15:55:02 --> Email Class Initialized
INFO - 2020-08-27 15:55:02 --> Controller Class Initialized
DEBUG - 2020-08-27 15:55:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 15:55:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 15:55:02 --> Helper loaded: form_helper
INFO - 2020-08-27 15:55:02 --> Form Validation Class Initialized
INFO - 2020-08-27 15:55:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 15:55:02 --> Final output sent to browser
DEBUG - 2020-08-27 15:55:02 --> Total execution time: 0.0254
ERROR - 2020-08-27 16:18:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:18:48 --> Config Class Initialized
INFO - 2020-08-27 16:18:48 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:18:48 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:18:48 --> Utf8 Class Initialized
INFO - 2020-08-27 16:18:48 --> URI Class Initialized
DEBUG - 2020-08-27 16:18:48 --> No URI present. Default controller set.
INFO - 2020-08-27 16:18:48 --> Router Class Initialized
INFO - 2020-08-27 16:18:48 --> Output Class Initialized
INFO - 2020-08-27 16:18:48 --> Security Class Initialized
DEBUG - 2020-08-27 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:18:48 --> Input Class Initialized
INFO - 2020-08-27 16:18:48 --> Language Class Initialized
INFO - 2020-08-27 16:18:48 --> Loader Class Initialized
INFO - 2020-08-27 16:18:48 --> Helper loaded: url_helper
INFO - 2020-08-27 16:18:48 --> Database Driver Class Initialized
INFO - 2020-08-27 16:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:18:48 --> Email Class Initialized
INFO - 2020-08-27 16:18:48 --> Controller Class Initialized
INFO - 2020-08-27 16:18:48 --> Model Class Initialized
INFO - 2020-08-27 16:18:48 --> Model Class Initialized
DEBUG - 2020-08-27 16:18:48 --> Session class already loaded. Second attempt ignored.
INFO - 2020-08-27 16:18:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-08-27 16:18:48 --> Final output sent to browser
DEBUG - 2020-08-27 16:18:48 --> Total execution time: 0.0190
ERROR - 2020-08-27 16:18:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:18:52 --> Config Class Initialized
INFO - 2020-08-27 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:18:52 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:18:52 --> Utf8 Class Initialized
INFO - 2020-08-27 16:18:52 --> URI Class Initialized
INFO - 2020-08-27 16:18:52 --> Router Class Initialized
INFO - 2020-08-27 16:18:52 --> Output Class Initialized
INFO - 2020-08-27 16:18:52 --> Security Class Initialized
DEBUG - 2020-08-27 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:18:52 --> Input Class Initialized
INFO - 2020-08-27 16:18:52 --> Language Class Initialized
INFO - 2020-08-27 16:18:52 --> Loader Class Initialized
INFO - 2020-08-27 16:18:52 --> Helper loaded: url_helper
INFO - 2020-08-27 16:18:52 --> Database Driver Class Initialized
INFO - 2020-08-27 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:18:52 --> Email Class Initialized
INFO - 2020-08-27 16:18:52 --> Controller Class Initialized
INFO - 2020-08-27 16:18:52 --> Model Class Initialized
INFO - 2020-08-27 16:18:52 --> Model Class Initialized
DEBUG - 2020-08-27 16:18:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 16:18:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 16:18:52 --> Model Class Initialized
INFO - 2020-08-27 16:18:52 --> Final output sent to browser
DEBUG - 2020-08-27 16:18:52 --> Total execution time: 0.0224
ERROR - 2020-08-27 16:18:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:18:52 --> Config Class Initialized
INFO - 2020-08-27 16:18:52 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:18:52 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:18:52 --> Utf8 Class Initialized
INFO - 2020-08-27 16:18:52 --> URI Class Initialized
INFO - 2020-08-27 16:18:52 --> Router Class Initialized
INFO - 2020-08-27 16:18:52 --> Output Class Initialized
INFO - 2020-08-27 16:18:52 --> Security Class Initialized
DEBUG - 2020-08-27 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:18:52 --> Input Class Initialized
INFO - 2020-08-27 16:18:52 --> Language Class Initialized
INFO - 2020-08-27 16:18:52 --> Loader Class Initialized
INFO - 2020-08-27 16:18:52 --> Helper loaded: url_helper
INFO - 2020-08-27 16:18:52 --> Database Driver Class Initialized
INFO - 2020-08-27 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:18:52 --> Email Class Initialized
INFO - 2020-08-27 16:18:52 --> Controller Class Initialized
INFO - 2020-08-27 16:18:52 --> Model Class Initialized
INFO - 2020-08-27 16:18:52 --> Model Class Initialized
DEBUG - 2020-08-27 16:18:52 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-08-27 16:18:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:18:53 --> Config Class Initialized
INFO - 2020-08-27 16:18:53 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:18:53 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:18:53 --> Utf8 Class Initialized
INFO - 2020-08-27 16:18:53 --> URI Class Initialized
INFO - 2020-08-27 16:18:53 --> Router Class Initialized
INFO - 2020-08-27 16:18:53 --> Output Class Initialized
INFO - 2020-08-27 16:18:53 --> Security Class Initialized
DEBUG - 2020-08-27 16:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:18:53 --> Input Class Initialized
INFO - 2020-08-27 16:18:53 --> Language Class Initialized
INFO - 2020-08-27 16:18:53 --> Loader Class Initialized
INFO - 2020-08-27 16:18:53 --> Helper loaded: url_helper
INFO - 2020-08-27 16:18:53 --> Database Driver Class Initialized
INFO - 2020-08-27 16:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 16:18:53 --> Email Class Initialized
INFO - 2020-08-27 16:18:53 --> Controller Class Initialized
DEBUG - 2020-08-27 16:18:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 16:18:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 16:18:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-08-27 16:18:53 --> Final output sent to browser
DEBUG - 2020-08-27 16:18:53 --> Total execution time: 0.0167
ERROR - 2020-08-27 16:26:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:26:17 --> Config Class Initialized
INFO - 2020-08-27 16:26:17 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:26:17 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:26:17 --> Utf8 Class Initialized
INFO - 2020-08-27 16:26:17 --> URI Class Initialized
INFO - 2020-08-27 16:26:17 --> Router Class Initialized
INFO - 2020-08-27 16:26:17 --> Output Class Initialized
INFO - 2020-08-27 16:26:17 --> Security Class Initialized
DEBUG - 2020-08-27 16:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:26:17 --> Input Class Initialized
INFO - 2020-08-27 16:26:17 --> Language Class Initialized
ERROR - 2020-08-27 16:26:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:8) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 16:26:17 --> Severity: Compile Error --> Cannot use PhpOffice\PhpSpreadsheet\Reader\Xlsx as Xlsx because the name is already in use /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 8
ERROR - 2020-08-27 16:26:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:26:21 --> Config Class Initialized
INFO - 2020-08-27 16:26:21 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:26:21 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:26:21 --> Utf8 Class Initialized
INFO - 2020-08-27 16:26:21 --> URI Class Initialized
INFO - 2020-08-27 16:26:21 --> Router Class Initialized
INFO - 2020-08-27 16:26:21 --> Output Class Initialized
INFO - 2020-08-27 16:26:21 --> Security Class Initialized
DEBUG - 2020-08-27 16:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:26:21 --> Input Class Initialized
INFO - 2020-08-27 16:26:21 --> Language Class Initialized
ERROR - 2020-08-27 16:26:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:8) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 16:26:21 --> Severity: Compile Error --> Cannot use PhpOffice\PhpSpreadsheet\Reader\Xlsx as Xlsx because the name is already in use /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 8
ERROR - 2020-08-27 16:37:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 16:37:25 --> Config Class Initialized
INFO - 2020-08-27 16:37:25 --> Hooks Class Initialized
DEBUG - 2020-08-27 16:37:25 --> UTF-8 Support Enabled
INFO - 2020-08-27 16:37:25 --> Utf8 Class Initialized
INFO - 2020-08-27 16:37:25 --> URI Class Initialized
INFO - 2020-08-27 16:37:25 --> Router Class Initialized
INFO - 2020-08-27 16:37:25 --> Output Class Initialized
INFO - 2020-08-27 16:37:25 --> Security Class Initialized
DEBUG - 2020-08-27 16:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 16:37:25 --> Input Class Initialized
INFO - 2020-08-27 16:37:25 --> Language Class Initialized
ERROR - 2020-08-27 16:37:25 --> Severity: Warning --> require(vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 3
ERROR - 2020-08-27 16:37:25 --> Severity: Warning --> require(vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 3
ERROR - 2020-08-27 16:37:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 16:37:25 --> Severity: Compile Error --> require(): Failed opening required 'vendor/autoload.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 3
ERROR - 2020-08-27 17:25:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:25:08 --> Config Class Initialized
INFO - 2020-08-27 17:25:08 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:25:08 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:25:08 --> Utf8 Class Initialized
INFO - 2020-08-27 17:25:08 --> URI Class Initialized
INFO - 2020-08-27 17:25:08 --> Router Class Initialized
INFO - 2020-08-27 17:25:08 --> Output Class Initialized
INFO - 2020-08-27 17:25:08 --> Security Class Initialized
DEBUG - 2020-08-27 17:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:25:08 --> Input Class Initialized
INFO - 2020-08-27 17:25:08 --> Language Class Initialized
ERROR - 2020-08-27 17:25:08 --> Severity: Warning --> require(vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 3
ERROR - 2020-08-27 17:25:08 --> Severity: Warning --> require(vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 3
ERROR - 2020-08-27 17:25:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 17:25:08 --> Severity: Compile Error --> require(): Failed opening required 'vendor/autoload.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 3
ERROR - 2020-08-27 17:25:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:25:49 --> Config Class Initialized
INFO - 2020-08-27 17:25:49 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:25:49 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:25:49 --> Utf8 Class Initialized
INFO - 2020-08-27 17:25:49 --> URI Class Initialized
INFO - 2020-08-27 17:25:49 --> Router Class Initialized
INFO - 2020-08-27 17:25:49 --> Output Class Initialized
INFO - 2020-08-27 17:25:49 --> Security Class Initialized
DEBUG - 2020-08-27 17:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:25:49 --> Input Class Initialized
INFO - 2020-08-27 17:25:49 --> Language Class Initialized
INFO - 2020-08-27 17:25:49 --> Loader Class Initialized
INFO - 2020-08-27 17:25:49 --> Helper loaded: url_helper
INFO - 2020-08-27 17:25:49 --> Database Driver Class Initialized
INFO - 2020-08-27 17:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:25:49 --> Email Class Initialized
INFO - 2020-08-27 17:25:49 --> Controller Class Initialized
DEBUG - 2020-08-27 17:25:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:25:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:25:49 --> Helper loaded: form_helper
INFO - 2020-08-27 17:25:49 --> Form Validation Class Initialized
INFO - 2020-08-27 17:25:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 17:25:49 --> Final output sent to browser
DEBUG - 2020-08-27 17:25:49 --> Total execution time: 0.0212
ERROR - 2020-08-27 17:25:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:25:57 --> Config Class Initialized
INFO - 2020-08-27 17:25:57 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:25:58 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:25:58 --> Utf8 Class Initialized
INFO - 2020-08-27 17:25:58 --> URI Class Initialized
INFO - 2020-08-27 17:25:58 --> Router Class Initialized
INFO - 2020-08-27 17:25:58 --> Output Class Initialized
INFO - 2020-08-27 17:25:58 --> Security Class Initialized
DEBUG - 2020-08-27 17:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:25:58 --> Input Class Initialized
INFO - 2020-08-27 17:25:58 --> Language Class Initialized
INFO - 2020-08-27 17:25:58 --> Loader Class Initialized
INFO - 2020-08-27 17:25:58 --> Helper loaded: url_helper
INFO - 2020-08-27 17:25:58 --> Database Driver Class Initialized
INFO - 2020-08-27 17:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:25:58 --> Email Class Initialized
INFO - 2020-08-27 17:25:58 --> Controller Class Initialized
DEBUG - 2020-08-27 17:25:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:25:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:25:58 --> Helper loaded: form_helper
INFO - 2020-08-27 17:25:58 --> Form Validation Class Initialized
INFO - 2020-08-27 17:25:58 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 17:25:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 17:25:58 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-27 17:28:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:28:40 --> Config Class Initialized
INFO - 2020-08-27 17:28:40 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:28:40 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:28:40 --> Utf8 Class Initialized
INFO - 2020-08-27 17:28:40 --> URI Class Initialized
INFO - 2020-08-27 17:28:40 --> Router Class Initialized
INFO - 2020-08-27 17:28:40 --> Output Class Initialized
INFO - 2020-08-27 17:28:40 --> Security Class Initialized
DEBUG - 2020-08-27 17:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:28:40 --> Input Class Initialized
INFO - 2020-08-27 17:28:40 --> Language Class Initialized
ERROR - 2020-08-27 17:28:40 --> Severity: Warning --> require(/home/purpu1ex/public_html/carsm/application/controllers/vendor/autoload.php): failed to open stream: No such file or directory /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 7
ERROR - 2020-08-27 17:28:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/system/core/Exceptions.php:272) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 17:28:40 --> Severity: Compile Error --> require(): Failed opening required '/home/purpu1ex/public_html/carsm/application/controllers/vendor/autoload.php' (include_path='.:/usr/lib/php:/usr/local/lib/php') /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 7
ERROR - 2020-08-27 17:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:31:29 --> Config Class Initialized
INFO - 2020-08-27 17:31:29 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:31:29 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:31:29 --> Utf8 Class Initialized
INFO - 2020-08-27 17:31:29 --> URI Class Initialized
INFO - 2020-08-27 17:31:29 --> Router Class Initialized
INFO - 2020-08-27 17:31:29 --> Output Class Initialized
INFO - 2020-08-27 17:31:29 --> Security Class Initialized
DEBUG - 2020-08-27 17:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:31:29 --> Input Class Initialized
INFO - 2020-08-27 17:31:29 --> Language Class Initialized
INFO - 2020-08-27 17:31:29 --> Loader Class Initialized
INFO - 2020-08-27 17:31:29 --> Helper loaded: url_helper
INFO - 2020-08-27 17:31:29 --> Database Driver Class Initialized
INFO - 2020-08-27 17:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:31:29 --> Email Class Initialized
INFO - 2020-08-27 17:31:29 --> Controller Class Initialized
DEBUG - 2020-08-27 17:31:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:31:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:31:29 --> Helper loaded: form_helper
INFO - 2020-08-27 17:31:29 --> Form Validation Class Initialized
INFO - 2020-08-27 17:31:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2020-08-27 17:31:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/purpu1ex/public_html/carsm/application/controllers/Upload.php:69) /home/purpu1ex/public_html/carsm/system/core/Common.php 564
ERROR - 2020-08-27 17:31:29 --> Severity: Error --> Class 'PhpOffice\PhpSpreadsheet\Reader\Xlsx' not found /home/purpu1ex/public_html/carsm/application/controllers/Upload.php 69
ERROR - 2020-08-27 17:38:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:38:00 --> Config Class Initialized
INFO - 2020-08-27 17:38:00 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:38:00 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:38:00 --> Utf8 Class Initialized
INFO - 2020-08-27 17:38:00 --> URI Class Initialized
INFO - 2020-08-27 17:38:00 --> Router Class Initialized
INFO - 2020-08-27 17:38:00 --> Output Class Initialized
INFO - 2020-08-27 17:38:00 --> Security Class Initialized
DEBUG - 2020-08-27 17:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:38:00 --> Input Class Initialized
INFO - 2020-08-27 17:38:00 --> Language Class Initialized
INFO - 2020-08-27 17:38:00 --> Loader Class Initialized
INFO - 2020-08-27 17:38:00 --> Helper loaded: url_helper
INFO - 2020-08-27 17:38:00 --> Database Driver Class Initialized
INFO - 2020-08-27 17:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:38:00 --> Email Class Initialized
INFO - 2020-08-27 17:38:00 --> Controller Class Initialized
DEBUG - 2020-08-27 17:38:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:38:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:38:00 --> Helper loaded: form_helper
INFO - 2020-08-27 17:38:00 --> Form Validation Class Initialized
INFO - 2020-08-27 17:38:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 17:38:00 --> Final output sent to browser
DEBUG - 2020-08-27 17:38:00 --> Total execution time: 0.0204
ERROR - 2020-08-27 17:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:38:33 --> Config Class Initialized
INFO - 2020-08-27 17:38:33 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:38:33 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:38:33 --> Utf8 Class Initialized
INFO - 2020-08-27 17:38:33 --> URI Class Initialized
INFO - 2020-08-27 17:38:33 --> Router Class Initialized
INFO - 2020-08-27 17:38:33 --> Output Class Initialized
INFO - 2020-08-27 17:38:33 --> Security Class Initialized
DEBUG - 2020-08-27 17:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:38:33 --> Input Class Initialized
INFO - 2020-08-27 17:38:33 --> Language Class Initialized
INFO - 2020-08-27 17:38:33 --> Loader Class Initialized
INFO - 2020-08-27 17:38:33 --> Helper loaded: url_helper
INFO - 2020-08-27 17:38:33 --> Database Driver Class Initialized
INFO - 2020-08-27 17:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:38:33 --> Email Class Initialized
INFO - 2020-08-27 17:38:33 --> Controller Class Initialized
DEBUG - 2020-08-27 17:38:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:38:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:38:33 --> Model Class Initialized
INFO - 2020-08-27 17:38:33 --> Model Class Initialized
INFO - 2020-08-27 17:38:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-27 17:38:33 --> Final output sent to browser
DEBUG - 2020-08-27 17:38:33 --> Total execution time: 0.0184
ERROR - 2020-08-27 17:38:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:38:36 --> Config Class Initialized
INFO - 2020-08-27 17:38:36 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:38:36 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:38:36 --> Utf8 Class Initialized
INFO - 2020-08-27 17:38:36 --> URI Class Initialized
INFO - 2020-08-27 17:38:36 --> Router Class Initialized
INFO - 2020-08-27 17:38:36 --> Output Class Initialized
INFO - 2020-08-27 17:38:36 --> Security Class Initialized
DEBUG - 2020-08-27 17:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:38:36 --> Input Class Initialized
INFO - 2020-08-27 17:38:36 --> Language Class Initialized
INFO - 2020-08-27 17:38:36 --> Loader Class Initialized
INFO - 2020-08-27 17:38:36 --> Helper loaded: url_helper
INFO - 2020-08-27 17:38:36 --> Database Driver Class Initialized
INFO - 2020-08-27 17:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:38:36 --> Email Class Initialized
INFO - 2020-08-27 17:38:36 --> Controller Class Initialized
DEBUG - 2020-08-27 17:38:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:38:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:38:36 --> Model Class Initialized
INFO - 2020-08-27 17:38:36 --> Model Class Initialized
INFO - 2020-08-27 17:38:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-08-27 17:38:36 --> Final output sent to browser
DEBUG - 2020-08-27 17:38:36 --> Total execution time: 0.0397
ERROR - 2020-08-27 17:38:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:38:55 --> Config Class Initialized
INFO - 2020-08-27 17:38:55 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:38:55 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:38:55 --> Utf8 Class Initialized
INFO - 2020-08-27 17:38:55 --> URI Class Initialized
INFO - 2020-08-27 17:38:55 --> Router Class Initialized
INFO - 2020-08-27 17:38:55 --> Output Class Initialized
INFO - 2020-08-27 17:38:55 --> Security Class Initialized
DEBUG - 2020-08-27 17:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:38:55 --> Input Class Initialized
INFO - 2020-08-27 17:38:55 --> Language Class Initialized
INFO - 2020-08-27 17:38:55 --> Loader Class Initialized
INFO - 2020-08-27 17:38:55 --> Helper loaded: url_helper
INFO - 2020-08-27 17:38:55 --> Database Driver Class Initialized
INFO - 2020-08-27 17:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:38:55 --> Email Class Initialized
INFO - 2020-08-27 17:38:55 --> Controller Class Initialized
DEBUG - 2020-08-27 17:38:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:38:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:38:55 --> Model Class Initialized
INFO - 2020-08-27 17:38:55 --> Model Class Initialized
INFO - 2020-08-27 17:38:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-27 17:38:55 --> Final output sent to browser
DEBUG - 2020-08-27 17:38:55 --> Total execution time: 0.0196
ERROR - 2020-08-27 17:42:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:42:37 --> Config Class Initialized
INFO - 2020-08-27 17:42:37 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:42:37 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:42:37 --> Utf8 Class Initialized
INFO - 2020-08-27 17:42:37 --> URI Class Initialized
INFO - 2020-08-27 17:42:37 --> Router Class Initialized
INFO - 2020-08-27 17:42:37 --> Output Class Initialized
INFO - 2020-08-27 17:42:37 --> Security Class Initialized
DEBUG - 2020-08-27 17:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:42:37 --> Input Class Initialized
INFO - 2020-08-27 17:42:37 --> Language Class Initialized
INFO - 2020-08-27 17:42:37 --> Loader Class Initialized
INFO - 2020-08-27 17:42:37 --> Helper loaded: url_helper
INFO - 2020-08-27 17:42:37 --> Database Driver Class Initialized
INFO - 2020-08-27 17:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:42:37 --> Email Class Initialized
INFO - 2020-08-27 17:42:37 --> Controller Class Initialized
DEBUG - 2020-08-27 17:42:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:42:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:42:37 --> Model Class Initialized
INFO - 2020-08-27 17:42:37 --> Model Class Initialized
INFO - 2020-08-27 17:42:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-08-27 17:42:37 --> Final output sent to browser
DEBUG - 2020-08-27 17:42:37 --> Total execution time: 0.0187
ERROR - 2020-08-27 17:43:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:43:00 --> Config Class Initialized
INFO - 2020-08-27 17:43:00 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:43:00 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:43:00 --> Utf8 Class Initialized
INFO - 2020-08-27 17:43:00 --> URI Class Initialized
INFO - 2020-08-27 17:43:00 --> Router Class Initialized
INFO - 2020-08-27 17:43:00 --> Output Class Initialized
INFO - 2020-08-27 17:43:00 --> Security Class Initialized
DEBUG - 2020-08-27 17:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:43:00 --> Input Class Initialized
INFO - 2020-08-27 17:43:00 --> Language Class Initialized
INFO - 2020-08-27 17:43:00 --> Loader Class Initialized
INFO - 2020-08-27 17:43:00 --> Helper loaded: url_helper
INFO - 2020-08-27 17:43:00 --> Database Driver Class Initialized
INFO - 2020-08-27 17:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:43:00 --> Email Class Initialized
INFO - 2020-08-27 17:43:00 --> Controller Class Initialized
DEBUG - 2020-08-27 17:43:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:43:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:43:00 --> Helper loaded: form_helper
INFO - 2020-08-27 17:43:00 --> Form Validation Class Initialized
INFO - 2020-08-27 17:43:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 17:43:00 --> Final output sent to browser
DEBUG - 2020-08-27 17:43:00 --> Total execution time: 0.0209
ERROR - 2020-08-27 17:43:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:43:04 --> Config Class Initialized
INFO - 2020-08-27 17:43:04 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:43:04 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:43:04 --> Utf8 Class Initialized
INFO - 2020-08-27 17:43:04 --> URI Class Initialized
INFO - 2020-08-27 17:43:04 --> Router Class Initialized
INFO - 2020-08-27 17:43:04 --> Output Class Initialized
INFO - 2020-08-27 17:43:04 --> Security Class Initialized
DEBUG - 2020-08-27 17:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:43:04 --> Input Class Initialized
INFO - 2020-08-27 17:43:04 --> Language Class Initialized
INFO - 2020-08-27 17:43:04 --> Loader Class Initialized
INFO - 2020-08-27 17:43:04 --> Helper loaded: url_helper
INFO - 2020-08-27 17:43:04 --> Database Driver Class Initialized
INFO - 2020-08-27 17:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:43:04 --> Email Class Initialized
INFO - 2020-08-27 17:43:04 --> Controller Class Initialized
DEBUG - 2020-08-27 17:43:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:43:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:43:04 --> Helper loaded: form_helper
INFO - 2020-08-27 17:43:04 --> Form Validation Class Initialized
INFO - 2020-08-27 17:43:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 17:43:04 --> Final output sent to browser
DEBUG - 2020-08-27 17:43:04 --> Total execution time: 0.0214
ERROR - 2020-08-27 17:43:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-08-27 17:43:46 --> Config Class Initialized
INFO - 2020-08-27 17:43:46 --> Hooks Class Initialized
DEBUG - 2020-08-27 17:43:46 --> UTF-8 Support Enabled
INFO - 2020-08-27 17:43:46 --> Utf8 Class Initialized
INFO - 2020-08-27 17:43:46 --> URI Class Initialized
INFO - 2020-08-27 17:43:46 --> Router Class Initialized
INFO - 2020-08-27 17:43:46 --> Output Class Initialized
INFO - 2020-08-27 17:43:46 --> Security Class Initialized
DEBUG - 2020-08-27 17:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-27 17:43:46 --> Input Class Initialized
INFO - 2020-08-27 17:43:46 --> Language Class Initialized
INFO - 2020-08-27 17:43:46 --> Loader Class Initialized
INFO - 2020-08-27 17:43:46 --> Helper loaded: url_helper
INFO - 2020-08-27 17:43:46 --> Database Driver Class Initialized
INFO - 2020-08-27 17:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-27 17:43:46 --> Email Class Initialized
INFO - 2020-08-27 17:43:46 --> Controller Class Initialized
DEBUG - 2020-08-27 17:43:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-08-27 17:43:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-08-27 17:43:46 --> Helper loaded: form_helper
INFO - 2020-08-27 17:43:46 --> Form Validation Class Initialized
INFO - 2020-08-27 17:43:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-08-27 17:43:46 --> Final output sent to browser
DEBUG - 2020-08-27 17:43:46 --> Total execution time: 0.0189
