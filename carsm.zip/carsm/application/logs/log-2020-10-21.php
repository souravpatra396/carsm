<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-21 14:10:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-21 14:10:33 --> Config Class Initialized
INFO - 2020-10-21 14:10:33 --> Hooks Class Initialized
DEBUG - 2020-10-21 14:10:33 --> UTF-8 Support Enabled
INFO - 2020-10-21 14:10:33 --> Utf8 Class Initialized
INFO - 2020-10-21 14:10:33 --> URI Class Initialized
DEBUG - 2020-10-21 14:10:33 --> No URI present. Default controller set.
INFO - 2020-10-21 14:10:33 --> Router Class Initialized
INFO - 2020-10-21 14:10:33 --> Output Class Initialized
INFO - 2020-10-21 14:10:33 --> Security Class Initialized
DEBUG - 2020-10-21 14:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-21 14:10:33 --> Input Class Initialized
INFO - 2020-10-21 14:10:33 --> Language Class Initialized
INFO - 2020-10-21 14:10:33 --> Loader Class Initialized
INFO - 2020-10-21 14:10:33 --> Helper loaded: url_helper
INFO - 2020-10-21 14:10:34 --> Database Driver Class Initialized
INFO - 2020-10-21 14:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-21 14:10:34 --> Email Class Initialized
INFO - 2020-10-21 14:10:34 --> Controller Class Initialized
INFO - 2020-10-21 14:10:34 --> Model Class Initialized
INFO - 2020-10-21 14:10:34 --> Model Class Initialized
DEBUG - 2020-10-21 14:10:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-21 14:10:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-21 14:10:34 --> Final output sent to browser
DEBUG - 2020-10-21 14:10:34 --> Total execution time: 0.2241
