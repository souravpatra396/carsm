<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-10-08 06:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 06:49:30 --> Config Class Initialized
INFO - 2020-10-08 06:49:30 --> Hooks Class Initialized
DEBUG - 2020-10-08 06:49:30 --> UTF-8 Support Enabled
INFO - 2020-10-08 06:49:30 --> Utf8 Class Initialized
INFO - 2020-10-08 06:49:30 --> URI Class Initialized
DEBUG - 2020-10-08 06:49:30 --> No URI present. Default controller set.
INFO - 2020-10-08 06:49:30 --> Router Class Initialized
INFO - 2020-10-08 06:49:30 --> Output Class Initialized
INFO - 2020-10-08 06:49:30 --> Security Class Initialized
DEBUG - 2020-10-08 06:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 06:49:30 --> Input Class Initialized
INFO - 2020-10-08 06:49:30 --> Language Class Initialized
INFO - 2020-10-08 06:49:30 --> Loader Class Initialized
INFO - 2020-10-08 06:49:30 --> Helper loaded: url_helper
INFO - 2020-10-08 06:49:30 --> Database Driver Class Initialized
INFO - 2020-10-08 06:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 06:49:30 --> Email Class Initialized
INFO - 2020-10-08 06:49:30 --> Controller Class Initialized
INFO - 2020-10-08 06:49:30 --> Model Class Initialized
INFO - 2020-10-08 06:49:30 --> Model Class Initialized
DEBUG - 2020-10-08 06:49:30 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 06:49:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 06:49:30 --> Final output sent to browser
DEBUG - 2020-10-08 06:49:30 --> Total execution time: 0.1850
ERROR - 2020-10-08 07:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:31:14 --> Config Class Initialized
INFO - 2020-10-08 07:31:14 --> Hooks Class Initialized
ERROR - 2020-10-08 07:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:31:14 --> Config Class Initialized
INFO - 2020-10-08 07:31:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-08 07:31:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:31:14 --> Utf8 Class Initialized
INFO - 2020-10-08 07:31:14 --> Utf8 Class Initialized
INFO - 2020-10-08 07:31:14 --> URI Class Initialized
INFO - 2020-10-08 07:31:14 --> URI Class Initialized
INFO - 2020-10-08 07:31:14 --> Router Class Initialized
INFO - 2020-10-08 07:31:14 --> Router Class Initialized
INFO - 2020-10-08 07:31:14 --> Output Class Initialized
INFO - 2020-10-08 07:31:14 --> Output Class Initialized
INFO - 2020-10-08 07:31:14 --> Security Class Initialized
INFO - 2020-10-08 07:31:14 --> Security Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-08 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:31:14 --> Input Class Initialized
INFO - 2020-10-08 07:31:14 --> Input Class Initialized
INFO - 2020-10-08 07:31:14 --> Language Class Initialized
INFO - 2020-10-08 07:31:14 --> Language Class Initialized
INFO - 2020-10-08 07:31:14 --> Loader Class Initialized
INFO - 2020-10-08 07:31:14 --> Loader Class Initialized
INFO - 2020-10-08 07:31:14 --> Helper loaded: url_helper
INFO - 2020-10-08 07:31:14 --> Helper loaded: url_helper
INFO - 2020-10-08 07:31:14 --> Database Driver Class Initialized
INFO - 2020-10-08 07:31:14 --> Database Driver Class Initialized
INFO - 2020-10-08 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:31:14 --> Email Class Initialized
INFO - 2020-10-08 07:31:14 --> Controller Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:31:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:31:14 --> Email Class Initialized
INFO - 2020-10-08 07:31:14 --> Controller Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 07:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:31:14 --> Config Class Initialized
INFO - 2020-10-08 07:31:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:31:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:31:14 --> Utf8 Class Initialized
INFO - 2020-10-08 07:31:14 --> URI Class Initialized
DEBUG - 2020-10-08 07:31:14 --> No URI present. Default controller set.
INFO - 2020-10-08 07:31:14 --> Router Class Initialized
INFO - 2020-10-08 07:31:14 --> Output Class Initialized
INFO - 2020-10-08 07:31:14 --> Security Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:31:14 --> Input Class Initialized
INFO - 2020-10-08 07:31:14 --> Language Class Initialized
INFO - 2020-10-08 07:31:14 --> Loader Class Initialized
INFO - 2020-10-08 07:31:14 --> Helper loaded: url_helper
INFO - 2020-10-08 07:31:14 --> Database Driver Class Initialized
INFO - 2020-10-08 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:31:14 --> Email Class Initialized
INFO - 2020-10-08 07:31:14 --> Controller Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:31:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 07:31:14 --> Final output sent to browser
DEBUG - 2020-10-08 07:31:14 --> Total execution time: 0.0239
ERROR - 2020-10-08 07:31:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:31:14 --> Config Class Initialized
INFO - 2020-10-08 07:31:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:31:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:31:14 --> Utf8 Class Initialized
INFO - 2020-10-08 07:31:14 --> URI Class Initialized
INFO - 2020-10-08 07:31:14 --> Router Class Initialized
INFO - 2020-10-08 07:31:14 --> Output Class Initialized
INFO - 2020-10-08 07:31:14 --> Security Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:31:14 --> Input Class Initialized
INFO - 2020-10-08 07:31:14 --> Language Class Initialized
INFO - 2020-10-08 07:31:14 --> Loader Class Initialized
INFO - 2020-10-08 07:31:14 --> Helper loaded: url_helper
INFO - 2020-10-08 07:31:14 --> Database Driver Class Initialized
INFO - 2020-10-08 07:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:31:14 --> Email Class Initialized
INFO - 2020-10-08 07:31:14 --> Controller Class Initialized
DEBUG - 2020-10-08 07:31:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:31:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
INFO - 2020-10-08 07:31:14 --> Model Class Initialized
INFO - 2020-10-08 07:31:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:31:14 --> Final output sent to browser
DEBUG - 2020-10-08 07:31:14 --> Total execution time: 0.0586
ERROR - 2020-10-08 07:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:37:23 --> Config Class Initialized
INFO - 2020-10-08 07:37:23 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:37:23 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:37:23 --> Utf8 Class Initialized
INFO - 2020-10-08 07:37:23 --> URI Class Initialized
INFO - 2020-10-08 07:37:23 --> Router Class Initialized
INFO - 2020-10-08 07:37:23 --> Output Class Initialized
INFO - 2020-10-08 07:37:23 --> Security Class Initialized
DEBUG - 2020-10-08 07:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:37:23 --> Input Class Initialized
INFO - 2020-10-08 07:37:23 --> Language Class Initialized
INFO - 2020-10-08 07:37:23 --> Loader Class Initialized
INFO - 2020-10-08 07:37:23 --> Helper loaded: url_helper
INFO - 2020-10-08 07:37:23 --> Database Driver Class Initialized
INFO - 2020-10-08 07:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:37:23 --> Email Class Initialized
INFO - 2020-10-08 07:37:23 --> Controller Class Initialized
DEBUG - 2020-10-08 07:37:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:37:23 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-08 07:37:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:37:23 --> Config Class Initialized
INFO - 2020-10-08 07:37:23 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:37:23 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:37:23 --> Utf8 Class Initialized
INFO - 2020-10-08 07:37:23 --> URI Class Initialized
DEBUG - 2020-10-08 07:37:23 --> No URI present. Default controller set.
INFO - 2020-10-08 07:37:23 --> Router Class Initialized
INFO - 2020-10-08 07:37:23 --> Output Class Initialized
INFO - 2020-10-08 07:37:23 --> Security Class Initialized
DEBUG - 2020-10-08 07:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:37:23 --> Input Class Initialized
INFO - 2020-10-08 07:37:23 --> Language Class Initialized
INFO - 2020-10-08 07:37:23 --> Loader Class Initialized
INFO - 2020-10-08 07:37:23 --> Helper loaded: url_helper
INFO - 2020-10-08 07:37:23 --> Database Driver Class Initialized
INFO - 2020-10-08 07:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:37:23 --> Email Class Initialized
INFO - 2020-10-08 07:37:23 --> Controller Class Initialized
INFO - 2020-10-08 07:37:23 --> Model Class Initialized
INFO - 2020-10-08 07:37:23 --> Model Class Initialized
DEBUG - 2020-10-08 07:37:23 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:37:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 07:37:23 --> Final output sent to browser
DEBUG - 2020-10-08 07:37:23 --> Total execution time: 0.0193
ERROR - 2020-10-08 07:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:37:38 --> Config Class Initialized
INFO - 2020-10-08 07:37:38 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:37:38 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:37:38 --> Utf8 Class Initialized
INFO - 2020-10-08 07:37:38 --> URI Class Initialized
INFO - 2020-10-08 07:37:38 --> Router Class Initialized
INFO - 2020-10-08 07:37:38 --> Output Class Initialized
INFO - 2020-10-08 07:37:38 --> Security Class Initialized
DEBUG - 2020-10-08 07:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:37:38 --> Input Class Initialized
INFO - 2020-10-08 07:37:38 --> Language Class Initialized
INFO - 2020-10-08 07:37:38 --> Loader Class Initialized
INFO - 2020-10-08 07:37:38 --> Helper loaded: url_helper
INFO - 2020-10-08 07:37:38 --> Database Driver Class Initialized
INFO - 2020-10-08 07:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:37:38 --> Email Class Initialized
INFO - 2020-10-08 07:37:38 --> Controller Class Initialized
INFO - 2020-10-08 07:37:38 --> Model Class Initialized
INFO - 2020-10-08 07:37:38 --> Model Class Initialized
DEBUG - 2020-10-08 07:37:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:37:38 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-08 07:37:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:37:38 --> Config Class Initialized
INFO - 2020-10-08 07:37:38 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:37:38 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:37:38 --> Utf8 Class Initialized
INFO - 2020-10-08 07:37:38 --> URI Class Initialized
INFO - 2020-10-08 07:37:38 --> Router Class Initialized
INFO - 2020-10-08 07:37:38 --> Output Class Initialized
INFO - 2020-10-08 07:37:38 --> Security Class Initialized
DEBUG - 2020-10-08 07:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:37:38 --> Input Class Initialized
INFO - 2020-10-08 07:37:38 --> Language Class Initialized
INFO - 2020-10-08 07:37:38 --> Loader Class Initialized
INFO - 2020-10-08 07:37:38 --> Helper loaded: url_helper
INFO - 2020-10-08 07:37:38 --> Database Driver Class Initialized
INFO - 2020-10-08 07:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:37:38 --> Email Class Initialized
INFO - 2020-10-08 07:37:38 --> Controller Class Initialized
INFO - 2020-10-08 07:37:38 --> Model Class Initialized
INFO - 2020-10-08 07:37:38 --> Model Class Initialized
DEBUG - 2020-10-08 07:37:38 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 07:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:37:39 --> Config Class Initialized
INFO - 2020-10-08 07:37:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:37:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:37:39 --> Utf8 Class Initialized
INFO - 2020-10-08 07:37:39 --> URI Class Initialized
DEBUG - 2020-10-08 07:37:39 --> No URI present. Default controller set.
INFO - 2020-10-08 07:37:39 --> Router Class Initialized
INFO - 2020-10-08 07:37:39 --> Output Class Initialized
INFO - 2020-10-08 07:37:39 --> Security Class Initialized
DEBUG - 2020-10-08 07:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:37:39 --> Input Class Initialized
INFO - 2020-10-08 07:37:39 --> Language Class Initialized
INFO - 2020-10-08 07:37:39 --> Loader Class Initialized
INFO - 2020-10-08 07:37:39 --> Helper loaded: url_helper
INFO - 2020-10-08 07:37:39 --> Database Driver Class Initialized
INFO - 2020-10-08 07:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:37:39 --> Email Class Initialized
INFO - 2020-10-08 07:37:39 --> Controller Class Initialized
INFO - 2020-10-08 07:37:39 --> Model Class Initialized
INFO - 2020-10-08 07:37:39 --> Model Class Initialized
DEBUG - 2020-10-08 07:37:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:37:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 07:37:39 --> Final output sent to browser
DEBUG - 2020-10-08 07:37:39 --> Total execution time: 0.0191
ERROR - 2020-10-08 07:37:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:37:39 --> Config Class Initialized
INFO - 2020-10-08 07:37:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:37:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:37:39 --> Utf8 Class Initialized
INFO - 2020-10-08 07:37:39 --> URI Class Initialized
INFO - 2020-10-08 07:37:39 --> Router Class Initialized
INFO - 2020-10-08 07:37:39 --> Output Class Initialized
INFO - 2020-10-08 07:37:39 --> Security Class Initialized
DEBUG - 2020-10-08 07:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:37:39 --> Input Class Initialized
INFO - 2020-10-08 07:37:39 --> Language Class Initialized
INFO - 2020-10-08 07:37:39 --> Loader Class Initialized
INFO - 2020-10-08 07:37:39 --> Helper loaded: url_helper
INFO - 2020-10-08 07:37:39 --> Database Driver Class Initialized
INFO - 2020-10-08 07:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:37:39 --> Email Class Initialized
INFO - 2020-10-08 07:37:39 --> Controller Class Initialized
DEBUG - 2020-10-08 07:37:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:37:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:37:39 --> Model Class Initialized
INFO - 2020-10-08 07:37:39 --> Model Class Initialized
INFO - 2020-10-08 07:37:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:37:39 --> Final output sent to browser
DEBUG - 2020-10-08 07:37:39 --> Total execution time: 0.0236
ERROR - 2020-10-08 07:41:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:41:29 --> Config Class Initialized
INFO - 2020-10-08 07:41:29 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:41:29 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:41:29 --> Utf8 Class Initialized
INFO - 2020-10-08 07:41:29 --> URI Class Initialized
INFO - 2020-10-08 07:41:29 --> Router Class Initialized
INFO - 2020-10-08 07:41:29 --> Output Class Initialized
INFO - 2020-10-08 07:41:29 --> Security Class Initialized
DEBUG - 2020-10-08 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:41:29 --> Input Class Initialized
INFO - 2020-10-08 07:41:29 --> Language Class Initialized
INFO - 2020-10-08 07:41:29 --> Loader Class Initialized
INFO - 2020-10-08 07:41:29 --> Helper loaded: url_helper
INFO - 2020-10-08 07:41:29 --> Database Driver Class Initialized
INFO - 2020-10-08 07:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:41:29 --> Email Class Initialized
INFO - 2020-10-08 07:41:29 --> Controller Class Initialized
DEBUG - 2020-10-08 07:41:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:41:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:41:29 --> Model Class Initialized
INFO - 2020-10-08 07:41:29 --> Model Class Initialized
INFO - 2020-10-08 07:41:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:41:29 --> Final output sent to browser
DEBUG - 2020-10-08 07:41:29 --> Total execution time: 0.0264
ERROR - 2020-10-08 07:42:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:42:24 --> Config Class Initialized
INFO - 2020-10-08 07:42:24 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:42:24 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:42:24 --> Utf8 Class Initialized
INFO - 2020-10-08 07:42:24 --> URI Class Initialized
INFO - 2020-10-08 07:42:24 --> Router Class Initialized
INFO - 2020-10-08 07:42:24 --> Output Class Initialized
INFO - 2020-10-08 07:42:24 --> Security Class Initialized
DEBUG - 2020-10-08 07:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:42:24 --> Input Class Initialized
INFO - 2020-10-08 07:42:24 --> Language Class Initialized
INFO - 2020-10-08 07:42:24 --> Loader Class Initialized
INFO - 2020-10-08 07:42:24 --> Helper loaded: url_helper
INFO - 2020-10-08 07:42:24 --> Database Driver Class Initialized
INFO - 2020-10-08 07:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:42:24 --> Email Class Initialized
INFO - 2020-10-08 07:42:24 --> Controller Class Initialized
DEBUG - 2020-10-08 07:42:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:42:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:42:24 --> Model Class Initialized
INFO - 2020-10-08 07:42:24 --> Model Class Initialized
INFO - 2020-10-08 07:42:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:42:24 --> Final output sent to browser
DEBUG - 2020-10-08 07:42:24 --> Total execution time: 0.0243
ERROR - 2020-10-08 07:43:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:43:05 --> Config Class Initialized
INFO - 2020-10-08 07:43:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:43:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:43:05 --> Utf8 Class Initialized
INFO - 2020-10-08 07:43:05 --> URI Class Initialized
INFO - 2020-10-08 07:43:05 --> Router Class Initialized
INFO - 2020-10-08 07:43:05 --> Output Class Initialized
INFO - 2020-10-08 07:43:05 --> Security Class Initialized
DEBUG - 2020-10-08 07:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:43:05 --> Input Class Initialized
INFO - 2020-10-08 07:43:05 --> Language Class Initialized
INFO - 2020-10-08 07:43:05 --> Loader Class Initialized
INFO - 2020-10-08 07:43:05 --> Helper loaded: url_helper
INFO - 2020-10-08 07:43:05 --> Database Driver Class Initialized
INFO - 2020-10-08 07:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:43:05 --> Email Class Initialized
INFO - 2020-10-08 07:43:05 --> Controller Class Initialized
DEBUG - 2020-10-08 07:43:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:43:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:43:05 --> Model Class Initialized
INFO - 2020-10-08 07:43:05 --> Model Class Initialized
INFO - 2020-10-08 07:43:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:43:05 --> Final output sent to browser
DEBUG - 2020-10-08 07:43:05 --> Total execution time: 0.0237
ERROR - 2020-10-08 07:49:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:49:32 --> Config Class Initialized
INFO - 2020-10-08 07:49:32 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:49:32 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:49:32 --> Utf8 Class Initialized
INFO - 2020-10-08 07:49:32 --> URI Class Initialized
INFO - 2020-10-08 07:49:32 --> Router Class Initialized
INFO - 2020-10-08 07:49:32 --> Output Class Initialized
INFO - 2020-10-08 07:49:32 --> Security Class Initialized
DEBUG - 2020-10-08 07:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:49:32 --> Input Class Initialized
INFO - 2020-10-08 07:49:32 --> Language Class Initialized
INFO - 2020-10-08 07:49:32 --> Loader Class Initialized
INFO - 2020-10-08 07:49:32 --> Helper loaded: url_helper
INFO - 2020-10-08 07:49:32 --> Database Driver Class Initialized
INFO - 2020-10-08 07:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:49:32 --> Email Class Initialized
INFO - 2020-10-08 07:49:32 --> Controller Class Initialized
DEBUG - 2020-10-08 07:49:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:49:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:49:32 --> Model Class Initialized
INFO - 2020-10-08 07:49:32 --> Model Class Initialized
INFO - 2020-10-08 07:49:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:49:32 --> Final output sent to browser
DEBUG - 2020-10-08 07:49:32 --> Total execution time: 0.0301
ERROR - 2020-10-08 07:50:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:50:33 --> Config Class Initialized
INFO - 2020-10-08 07:50:33 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:50:33 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:50:33 --> Utf8 Class Initialized
INFO - 2020-10-08 07:50:33 --> URI Class Initialized
INFO - 2020-10-08 07:50:33 --> Router Class Initialized
INFO - 2020-10-08 07:50:33 --> Output Class Initialized
INFO - 2020-10-08 07:50:33 --> Security Class Initialized
DEBUG - 2020-10-08 07:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:50:33 --> Input Class Initialized
INFO - 2020-10-08 07:50:33 --> Language Class Initialized
INFO - 2020-10-08 07:50:33 --> Loader Class Initialized
INFO - 2020-10-08 07:50:33 --> Helper loaded: url_helper
INFO - 2020-10-08 07:50:33 --> Database Driver Class Initialized
INFO - 2020-10-08 07:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:50:33 --> Email Class Initialized
INFO - 2020-10-08 07:50:33 --> Controller Class Initialized
DEBUG - 2020-10-08 07:50:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:50:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:50:33 --> Model Class Initialized
INFO - 2020-10-08 07:50:33 --> Model Class Initialized
INFO - 2020-10-08 07:50:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:50:33 --> Final output sent to browser
DEBUG - 2020-10-08 07:50:33 --> Total execution time: 0.0211
ERROR - 2020-10-08 07:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:50:52 --> Config Class Initialized
INFO - 2020-10-08 07:50:52 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:50:52 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:50:52 --> Utf8 Class Initialized
INFO - 2020-10-08 07:50:52 --> URI Class Initialized
INFO - 2020-10-08 07:50:52 --> Router Class Initialized
INFO - 2020-10-08 07:50:52 --> Output Class Initialized
INFO - 2020-10-08 07:50:52 --> Security Class Initialized
DEBUG - 2020-10-08 07:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:50:52 --> Input Class Initialized
INFO - 2020-10-08 07:50:52 --> Language Class Initialized
INFO - 2020-10-08 07:50:52 --> Loader Class Initialized
INFO - 2020-10-08 07:50:52 --> Helper loaded: url_helper
INFO - 2020-10-08 07:50:52 --> Database Driver Class Initialized
INFO - 2020-10-08 07:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:50:52 --> Email Class Initialized
INFO - 2020-10-08 07:50:52 --> Controller Class Initialized
DEBUG - 2020-10-08 07:50:52 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:50:52 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:50:52 --> Model Class Initialized
INFO - 2020-10-08 07:50:52 --> Model Class Initialized
INFO - 2020-10-08 07:50:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:50:52 --> Final output sent to browser
DEBUG - 2020-10-08 07:50:52 --> Total execution time: 0.0240
ERROR - 2020-10-08 07:51:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:51:51 --> Config Class Initialized
INFO - 2020-10-08 07:51:51 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:51:51 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:51:51 --> Utf8 Class Initialized
INFO - 2020-10-08 07:51:51 --> URI Class Initialized
INFO - 2020-10-08 07:51:51 --> Router Class Initialized
INFO - 2020-10-08 07:51:51 --> Output Class Initialized
INFO - 2020-10-08 07:51:51 --> Security Class Initialized
DEBUG - 2020-10-08 07:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:51:51 --> Input Class Initialized
INFO - 2020-10-08 07:51:51 --> Language Class Initialized
INFO - 2020-10-08 07:51:51 --> Loader Class Initialized
INFO - 2020-10-08 07:51:51 --> Helper loaded: url_helper
INFO - 2020-10-08 07:51:51 --> Database Driver Class Initialized
INFO - 2020-10-08 07:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:51:51 --> Email Class Initialized
INFO - 2020-10-08 07:51:51 --> Controller Class Initialized
DEBUG - 2020-10-08 07:51:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:51:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:51:51 --> Model Class Initialized
INFO - 2020-10-08 07:51:51 --> Model Class Initialized
INFO - 2020-10-08 07:51:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:51:51 --> Final output sent to browser
DEBUG - 2020-10-08 07:51:51 --> Total execution time: 0.0189
ERROR - 2020-10-08 07:52:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:52:11 --> Config Class Initialized
INFO - 2020-10-08 07:52:11 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:52:11 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:52:11 --> Utf8 Class Initialized
INFO - 2020-10-08 07:52:11 --> URI Class Initialized
INFO - 2020-10-08 07:52:11 --> Router Class Initialized
INFO - 2020-10-08 07:52:11 --> Output Class Initialized
INFO - 2020-10-08 07:52:11 --> Security Class Initialized
DEBUG - 2020-10-08 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:52:11 --> Input Class Initialized
INFO - 2020-10-08 07:52:11 --> Language Class Initialized
INFO - 2020-10-08 07:52:11 --> Loader Class Initialized
INFO - 2020-10-08 07:52:11 --> Helper loaded: url_helper
INFO - 2020-10-08 07:52:11 --> Database Driver Class Initialized
INFO - 2020-10-08 07:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:52:11 --> Email Class Initialized
INFO - 2020-10-08 07:52:11 --> Controller Class Initialized
DEBUG - 2020-10-08 07:52:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:52:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:52:11 --> Model Class Initialized
INFO - 2020-10-08 07:52:11 --> Model Class Initialized
INFO - 2020-10-08 07:52:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-08 07:52:11 --> Final output sent to browser
DEBUG - 2020-10-08 07:52:11 --> Total execution time: 0.2514
ERROR - 2020-10-08 07:52:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:52:36 --> Config Class Initialized
INFO - 2020-10-08 07:52:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:52:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:52:36 --> Utf8 Class Initialized
INFO - 2020-10-08 07:52:36 --> URI Class Initialized
INFO - 2020-10-08 07:52:36 --> Router Class Initialized
INFO - 2020-10-08 07:52:36 --> Output Class Initialized
INFO - 2020-10-08 07:52:36 --> Security Class Initialized
DEBUG - 2020-10-08 07:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:52:36 --> Input Class Initialized
INFO - 2020-10-08 07:52:36 --> Language Class Initialized
INFO - 2020-10-08 07:52:36 --> Loader Class Initialized
INFO - 2020-10-08 07:52:36 --> Helper loaded: url_helper
INFO - 2020-10-08 07:52:36 --> Database Driver Class Initialized
INFO - 2020-10-08 07:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:52:36 --> Email Class Initialized
INFO - 2020-10-08 07:52:36 --> Controller Class Initialized
DEBUG - 2020-10-08 07:52:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:52:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:52:36 --> Model Class Initialized
INFO - 2020-10-08 07:52:36 --> Model Class Initialized
INFO - 2020-10-08 07:52:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_status_edit.php
INFO - 2020-10-08 07:52:36 --> Final output sent to browser
DEBUG - 2020-10-08 07:52:36 --> Total execution time: 0.0489
ERROR - 2020-10-08 07:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:52:40 --> Config Class Initialized
INFO - 2020-10-08 07:52:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:52:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:52:40 --> Utf8 Class Initialized
INFO - 2020-10-08 07:52:40 --> URI Class Initialized
INFO - 2020-10-08 07:52:40 --> Router Class Initialized
INFO - 2020-10-08 07:52:40 --> Output Class Initialized
INFO - 2020-10-08 07:52:40 --> Security Class Initialized
DEBUG - 2020-10-08 07:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:52:40 --> Input Class Initialized
INFO - 2020-10-08 07:52:40 --> Language Class Initialized
INFO - 2020-10-08 07:52:41 --> Loader Class Initialized
INFO - 2020-10-08 07:52:41 --> Helper loaded: url_helper
INFO - 2020-10-08 07:52:41 --> Database Driver Class Initialized
INFO - 2020-10-08 07:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:52:41 --> Email Class Initialized
INFO - 2020-10-08 07:52:41 --> Controller Class Initialized
DEBUG - 2020-10-08 07:52:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:52:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:52:41 --> Model Class Initialized
INFO - 2020-10-08 07:52:41 --> Model Class Initialized
INFO - 2020-10-08 07:52:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-08 07:52:41 --> Final output sent to browser
DEBUG - 2020-10-08 07:52:41 --> Total execution time: 0.0326
ERROR - 2020-10-08 07:52:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:52:46 --> Config Class Initialized
INFO - 2020-10-08 07:52:46 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:52:46 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:52:46 --> Utf8 Class Initialized
INFO - 2020-10-08 07:52:46 --> URI Class Initialized
INFO - 2020-10-08 07:52:46 --> Router Class Initialized
INFO - 2020-10-08 07:52:46 --> Output Class Initialized
INFO - 2020-10-08 07:52:46 --> Security Class Initialized
DEBUG - 2020-10-08 07:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:52:46 --> Input Class Initialized
INFO - 2020-10-08 07:52:46 --> Language Class Initialized
INFO - 2020-10-08 07:52:46 --> Loader Class Initialized
INFO - 2020-10-08 07:52:46 --> Helper loaded: url_helper
INFO - 2020-10-08 07:52:46 --> Database Driver Class Initialized
INFO - 2020-10-08 07:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:52:46 --> Email Class Initialized
INFO - 2020-10-08 07:52:46 --> Controller Class Initialized
DEBUG - 2020-10-08 07:52:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:52:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:52:46 --> Model Class Initialized
INFO - 2020-10-08 07:52:46 --> Model Class Initialized
INFO - 2020-10-08 07:52:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:52:46 --> Final output sent to browser
DEBUG - 2020-10-08 07:52:46 --> Total execution time: 0.0235
ERROR - 2020-10-08 07:57:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:57:09 --> Config Class Initialized
INFO - 2020-10-08 07:57:09 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:57:09 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:57:09 --> Utf8 Class Initialized
INFO - 2020-10-08 07:57:09 --> URI Class Initialized
INFO - 2020-10-08 07:57:09 --> Router Class Initialized
INFO - 2020-10-08 07:57:09 --> Output Class Initialized
INFO - 2020-10-08 07:57:09 --> Security Class Initialized
DEBUG - 2020-10-08 07:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:57:09 --> Input Class Initialized
INFO - 2020-10-08 07:57:09 --> Language Class Initialized
INFO - 2020-10-08 07:57:09 --> Loader Class Initialized
INFO - 2020-10-08 07:57:09 --> Helper loaded: url_helper
INFO - 2020-10-08 07:57:09 --> Database Driver Class Initialized
INFO - 2020-10-08 07:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:57:09 --> Email Class Initialized
INFO - 2020-10-08 07:57:09 --> Controller Class Initialized
DEBUG - 2020-10-08 07:57:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 07:57:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:57:09 --> Model Class Initialized
INFO - 2020-10-08 07:57:09 --> Model Class Initialized
INFO - 2020-10-08 07:57:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 07:57:09 --> Final output sent to browser
DEBUG - 2020-10-08 07:57:09 --> Total execution time: 0.0205
ERROR - 2020-10-08 07:57:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 07:57:25 --> Config Class Initialized
INFO - 2020-10-08 07:57:25 --> Hooks Class Initialized
DEBUG - 2020-10-08 07:57:25 --> UTF-8 Support Enabled
INFO - 2020-10-08 07:57:25 --> Utf8 Class Initialized
INFO - 2020-10-08 07:57:25 --> URI Class Initialized
DEBUG - 2020-10-08 07:57:25 --> No URI present. Default controller set.
INFO - 2020-10-08 07:57:25 --> Router Class Initialized
INFO - 2020-10-08 07:57:25 --> Output Class Initialized
INFO - 2020-10-08 07:57:25 --> Security Class Initialized
DEBUG - 2020-10-08 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 07:57:25 --> Input Class Initialized
INFO - 2020-10-08 07:57:25 --> Language Class Initialized
INFO - 2020-10-08 07:57:25 --> Loader Class Initialized
INFO - 2020-10-08 07:57:25 --> Helper loaded: url_helper
INFO - 2020-10-08 07:57:25 --> Database Driver Class Initialized
INFO - 2020-10-08 07:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 07:57:25 --> Email Class Initialized
INFO - 2020-10-08 07:57:25 --> Controller Class Initialized
INFO - 2020-10-08 07:57:25 --> Model Class Initialized
INFO - 2020-10-08 07:57:25 --> Model Class Initialized
DEBUG - 2020-10-08 07:57:25 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 07:57:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 07:57:25 --> Final output sent to browser
DEBUG - 2020-10-08 07:57:25 --> Total execution time: 0.0184
ERROR - 2020-10-08 08:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:13:10 --> Config Class Initialized
INFO - 2020-10-08 08:13:10 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:13:10 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:13:10 --> Utf8 Class Initialized
INFO - 2020-10-08 08:13:10 --> URI Class Initialized
INFO - 2020-10-08 08:13:10 --> Router Class Initialized
INFO - 2020-10-08 08:13:10 --> Output Class Initialized
INFO - 2020-10-08 08:13:10 --> Security Class Initialized
DEBUG - 2020-10-08 08:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:13:10 --> Input Class Initialized
INFO - 2020-10-08 08:13:10 --> Language Class Initialized
INFO - 2020-10-08 08:13:10 --> Loader Class Initialized
INFO - 2020-10-08 08:13:10 --> Helper loaded: url_helper
INFO - 2020-10-08 08:13:10 --> Database Driver Class Initialized
INFO - 2020-10-08 08:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:13:10 --> Email Class Initialized
INFO - 2020-10-08 08:13:10 --> Controller Class Initialized
INFO - 2020-10-08 08:13:10 --> Model Class Initialized
INFO - 2020-10-08 08:13:10 --> Model Class Initialized
DEBUG - 2020-10-08 08:13:10 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 08:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:13:11 --> Config Class Initialized
INFO - 2020-10-08 08:13:11 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:13:11 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:13:11 --> Utf8 Class Initialized
INFO - 2020-10-08 08:13:11 --> URI Class Initialized
INFO - 2020-10-08 08:13:11 --> Router Class Initialized
INFO - 2020-10-08 08:13:11 --> Output Class Initialized
INFO - 2020-10-08 08:13:11 --> Security Class Initialized
DEBUG - 2020-10-08 08:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:13:11 --> Input Class Initialized
INFO - 2020-10-08 08:13:11 --> Language Class Initialized
INFO - 2020-10-08 08:13:11 --> Loader Class Initialized
INFO - 2020-10-08 08:13:11 --> Helper loaded: url_helper
INFO - 2020-10-08 08:13:11 --> Database Driver Class Initialized
INFO - 2020-10-08 08:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:13:11 --> Email Class Initialized
INFO - 2020-10-08 08:13:11 --> Controller Class Initialized
DEBUG - 2020-10-08 08:13:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:13:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:13:11 --> Model Class Initialized
INFO - 2020-10-08 08:13:11 --> Model Class Initialized
INFO - 2020-10-08 08:13:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 08:13:11 --> Final output sent to browser
DEBUG - 2020-10-08 08:13:11 --> Total execution time: 0.0542
ERROR - 2020-10-08 08:13:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:13:25 --> Config Class Initialized
INFO - 2020-10-08 08:13:25 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:13:25 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:13:25 --> Utf8 Class Initialized
INFO - 2020-10-08 08:13:25 --> URI Class Initialized
INFO - 2020-10-08 08:13:25 --> Router Class Initialized
INFO - 2020-10-08 08:13:25 --> Output Class Initialized
INFO - 2020-10-08 08:13:25 --> Security Class Initialized
DEBUG - 2020-10-08 08:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:13:25 --> Input Class Initialized
INFO - 2020-10-08 08:13:25 --> Language Class Initialized
INFO - 2020-10-08 08:13:25 --> Loader Class Initialized
INFO - 2020-10-08 08:13:25 --> Helper loaded: url_helper
INFO - 2020-10-08 08:13:25 --> Database Driver Class Initialized
INFO - 2020-10-08 08:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:13:25 --> Email Class Initialized
INFO - 2020-10-08 08:13:25 --> Controller Class Initialized
DEBUG - 2020-10-08 08:13:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:13:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:13:25 --> Model Class Initialized
INFO - 2020-10-08 08:13:25 --> Model Class Initialized
INFO - 2020-10-08 08:13:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:13:25 --> Final output sent to browser
DEBUG - 2020-10-08 08:13:25 --> Total execution time: 0.0627
ERROR - 2020-10-08 08:13:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:13:30 --> Config Class Initialized
INFO - 2020-10-08 08:13:30 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:13:30 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:13:30 --> Utf8 Class Initialized
INFO - 2020-10-08 08:13:30 --> URI Class Initialized
INFO - 2020-10-08 08:13:30 --> Router Class Initialized
INFO - 2020-10-08 08:13:30 --> Output Class Initialized
INFO - 2020-10-08 08:13:30 --> Security Class Initialized
DEBUG - 2020-10-08 08:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:13:30 --> Input Class Initialized
INFO - 2020-10-08 08:13:30 --> Language Class Initialized
INFO - 2020-10-08 08:13:30 --> Loader Class Initialized
INFO - 2020-10-08 08:13:30 --> Helper loaded: url_helper
INFO - 2020-10-08 08:13:30 --> Database Driver Class Initialized
INFO - 2020-10-08 08:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:13:30 --> Email Class Initialized
INFO - 2020-10-08 08:13:30 --> Controller Class Initialized
DEBUG - 2020-10-08 08:13:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:13:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:13:30 --> Model Class Initialized
INFO - 2020-10-08 08:13:30 --> Model Class Initialized
INFO - 2020-10-08 08:13:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:13:30 --> Final output sent to browser
DEBUG - 2020-10-08 08:13:30 --> Total execution time: 0.0330
ERROR - 2020-10-08 08:16:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:16:11 --> Config Class Initialized
INFO - 2020-10-08 08:16:11 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:16:11 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:16:11 --> Utf8 Class Initialized
INFO - 2020-10-08 08:16:11 --> URI Class Initialized
INFO - 2020-10-08 08:16:11 --> Router Class Initialized
INFO - 2020-10-08 08:16:11 --> Output Class Initialized
INFO - 2020-10-08 08:16:11 --> Security Class Initialized
DEBUG - 2020-10-08 08:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:16:11 --> Input Class Initialized
INFO - 2020-10-08 08:16:11 --> Language Class Initialized
INFO - 2020-10-08 08:16:12 --> Loader Class Initialized
INFO - 2020-10-08 08:16:12 --> Helper loaded: url_helper
INFO - 2020-10-08 08:16:12 --> Database Driver Class Initialized
INFO - 2020-10-08 08:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:16:12 --> Email Class Initialized
INFO - 2020-10-08 08:16:12 --> Controller Class Initialized
DEBUG - 2020-10-08 08:16:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:16:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:16:12 --> Model Class Initialized
INFO - 2020-10-08 08:16:12 --> Model Class Initialized
INFO - 2020-10-08 08:16:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 08:16:12 --> Final output sent to browser
DEBUG - 2020-10-08 08:16:12 --> Total execution time: 0.0401
ERROR - 2020-10-08 08:16:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:16:58 --> Config Class Initialized
INFO - 2020-10-08 08:16:58 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:16:58 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:16:58 --> Utf8 Class Initialized
INFO - 2020-10-08 08:16:58 --> URI Class Initialized
INFO - 2020-10-08 08:16:58 --> Router Class Initialized
INFO - 2020-10-08 08:16:58 --> Output Class Initialized
INFO - 2020-10-08 08:16:58 --> Security Class Initialized
DEBUG - 2020-10-08 08:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:16:58 --> Input Class Initialized
INFO - 2020-10-08 08:16:58 --> Language Class Initialized
INFO - 2020-10-08 08:16:58 --> Loader Class Initialized
INFO - 2020-10-08 08:16:58 --> Helper loaded: url_helper
INFO - 2020-10-08 08:16:58 --> Database Driver Class Initialized
INFO - 2020-10-08 08:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:16:58 --> Email Class Initialized
INFO - 2020-10-08 08:16:58 --> Controller Class Initialized
DEBUG - 2020-10-08 08:16:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:16:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:16:58 --> Model Class Initialized
INFO - 2020-10-08 08:16:58 --> Model Class Initialized
INFO - 2020-10-08 08:16:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 08:16:58 --> Final output sent to browser
DEBUG - 2020-10-08 08:16:58 --> Total execution time: 0.0239
ERROR - 2020-10-08 08:17:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:17:06 --> Config Class Initialized
INFO - 2020-10-08 08:17:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:17:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:17:06 --> Utf8 Class Initialized
INFO - 2020-10-08 08:17:06 --> URI Class Initialized
INFO - 2020-10-08 08:17:06 --> Router Class Initialized
INFO - 2020-10-08 08:17:06 --> Output Class Initialized
INFO - 2020-10-08 08:17:06 --> Security Class Initialized
DEBUG - 2020-10-08 08:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:17:06 --> Input Class Initialized
INFO - 2020-10-08 08:17:06 --> Language Class Initialized
INFO - 2020-10-08 08:17:06 --> Loader Class Initialized
INFO - 2020-10-08 08:17:06 --> Helper loaded: url_helper
INFO - 2020-10-08 08:17:06 --> Database Driver Class Initialized
INFO - 2020-10-08 08:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:17:06 --> Email Class Initialized
INFO - 2020-10-08 08:17:06 --> Controller Class Initialized
DEBUG - 2020-10-08 08:17:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:17:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:17:06 --> Model Class Initialized
INFO - 2020-10-08 08:17:06 --> Model Class Initialized
INFO - 2020-10-08 08:17:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:17:06 --> Final output sent to browser
DEBUG - 2020-10-08 08:17:06 --> Total execution time: 0.0245
ERROR - 2020-10-08 08:22:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:22:42 --> Config Class Initialized
INFO - 2020-10-08 08:22:42 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:22:42 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:22:42 --> Utf8 Class Initialized
INFO - 2020-10-08 08:22:42 --> URI Class Initialized
INFO - 2020-10-08 08:22:42 --> Router Class Initialized
INFO - 2020-10-08 08:22:42 --> Output Class Initialized
INFO - 2020-10-08 08:22:42 --> Security Class Initialized
DEBUG - 2020-10-08 08:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:22:42 --> Input Class Initialized
INFO - 2020-10-08 08:22:42 --> Language Class Initialized
INFO - 2020-10-08 08:22:42 --> Loader Class Initialized
INFO - 2020-10-08 08:22:42 --> Helper loaded: url_helper
INFO - 2020-10-08 08:22:42 --> Database Driver Class Initialized
INFO - 2020-10-08 08:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:22:42 --> Email Class Initialized
INFO - 2020-10-08 08:22:42 --> Controller Class Initialized
DEBUG - 2020-10-08 08:22:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:22:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:22:42 --> Model Class Initialized
INFO - 2020-10-08 08:22:42 --> Model Class Initialized
INFO - 2020-10-08 08:22:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:22:43 --> Final output sent to browser
DEBUG - 2020-10-08 08:22:43 --> Total execution time: 0.0242
ERROR - 2020-10-08 08:23:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:23:03 --> Config Class Initialized
INFO - 2020-10-08 08:23:03 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:23:03 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:23:03 --> Utf8 Class Initialized
INFO - 2020-10-08 08:23:03 --> URI Class Initialized
INFO - 2020-10-08 08:23:03 --> Router Class Initialized
INFO - 2020-10-08 08:23:03 --> Output Class Initialized
INFO - 2020-10-08 08:23:03 --> Security Class Initialized
DEBUG - 2020-10-08 08:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:23:03 --> Input Class Initialized
INFO - 2020-10-08 08:23:03 --> Language Class Initialized
INFO - 2020-10-08 08:23:03 --> Loader Class Initialized
INFO - 2020-10-08 08:23:03 --> Helper loaded: url_helper
INFO - 2020-10-08 08:23:03 --> Database Driver Class Initialized
INFO - 2020-10-08 08:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:23:03 --> Email Class Initialized
INFO - 2020-10-08 08:23:03 --> Controller Class Initialized
DEBUG - 2020-10-08 08:23:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:23:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:23:03 --> Model Class Initialized
INFO - 2020-10-08 08:23:03 --> Model Class Initialized
INFO - 2020-10-08 08:23:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-08 08:23:03 --> Final output sent to browser
DEBUG - 2020-10-08 08:23:03 --> Total execution time: 0.0464
ERROR - 2020-10-08 08:23:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:23:50 --> Config Class Initialized
INFO - 2020-10-08 08:23:50 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:23:50 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:23:50 --> Utf8 Class Initialized
INFO - 2020-10-08 08:23:50 --> URI Class Initialized
INFO - 2020-10-08 08:23:50 --> Router Class Initialized
INFO - 2020-10-08 08:23:50 --> Output Class Initialized
INFO - 2020-10-08 08:23:50 --> Security Class Initialized
DEBUG - 2020-10-08 08:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:23:50 --> Input Class Initialized
INFO - 2020-10-08 08:23:50 --> Language Class Initialized
INFO - 2020-10-08 08:23:50 --> Loader Class Initialized
INFO - 2020-10-08 08:23:50 --> Helper loaded: url_helper
INFO - 2020-10-08 08:23:50 --> Database Driver Class Initialized
INFO - 2020-10-08 08:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:23:50 --> Email Class Initialized
INFO - 2020-10-08 08:23:50 --> Controller Class Initialized
DEBUG - 2020-10-08 08:23:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:23:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:23:50 --> Model Class Initialized
INFO - 2020-10-08 08:23:50 --> Model Class Initialized
INFO - 2020-10-08 08:23:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-08 08:23:50 --> Final output sent to browser
DEBUG - 2020-10-08 08:23:50 --> Total execution time: 0.0249
ERROR - 2020-10-08 08:24:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:24:08 --> Config Class Initialized
INFO - 2020-10-08 08:24:08 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:24:08 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:24:08 --> Utf8 Class Initialized
INFO - 2020-10-08 08:24:08 --> URI Class Initialized
INFO - 2020-10-08 08:24:08 --> Router Class Initialized
INFO - 2020-10-08 08:24:08 --> Output Class Initialized
INFO - 2020-10-08 08:24:08 --> Security Class Initialized
DEBUG - 2020-10-08 08:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:24:08 --> Input Class Initialized
INFO - 2020-10-08 08:24:08 --> Language Class Initialized
INFO - 2020-10-08 08:24:08 --> Loader Class Initialized
INFO - 2020-10-08 08:24:08 --> Helper loaded: url_helper
INFO - 2020-10-08 08:24:08 --> Database Driver Class Initialized
INFO - 2020-10-08 08:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:24:08 --> Email Class Initialized
INFO - 2020-10-08 08:24:08 --> Controller Class Initialized
DEBUG - 2020-10-08 08:24:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:24:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:24:08 --> Model Class Initialized
INFO - 2020-10-08 08:24:08 --> Model Class Initialized
INFO - 2020-10-08 08:24:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:24:08 --> Final output sent to browser
DEBUG - 2020-10-08 08:24:08 --> Total execution time: 0.0258
ERROR - 2020-10-08 08:24:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:24:10 --> Config Class Initialized
INFO - 2020-10-08 08:24:10 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:24:10 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:24:10 --> Utf8 Class Initialized
INFO - 2020-10-08 08:24:10 --> URI Class Initialized
INFO - 2020-10-08 08:24:10 --> Router Class Initialized
INFO - 2020-10-08 08:24:10 --> Output Class Initialized
INFO - 2020-10-08 08:24:10 --> Security Class Initialized
DEBUG - 2020-10-08 08:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:24:10 --> Input Class Initialized
INFO - 2020-10-08 08:24:10 --> Language Class Initialized
INFO - 2020-10-08 08:24:10 --> Loader Class Initialized
INFO - 2020-10-08 08:24:11 --> Helper loaded: url_helper
INFO - 2020-10-08 08:24:11 --> Database Driver Class Initialized
INFO - 2020-10-08 08:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:24:11 --> Email Class Initialized
INFO - 2020-10-08 08:24:11 --> Controller Class Initialized
DEBUG - 2020-10-08 08:24:11 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:24:11 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:24:11 --> Model Class Initialized
INFO - 2020-10-08 08:24:11 --> Model Class Initialized
INFO - 2020-10-08 08:24:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-08 08:24:11 --> Final output sent to browser
DEBUG - 2020-10-08 08:24:11 --> Total execution time: 0.0376
ERROR - 2020-10-08 08:24:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:24:45 --> Config Class Initialized
INFO - 2020-10-08 08:24:45 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:24:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:24:45 --> Utf8 Class Initialized
INFO - 2020-10-08 08:24:45 --> URI Class Initialized
INFO - 2020-10-08 08:24:45 --> Router Class Initialized
INFO - 2020-10-08 08:24:45 --> Output Class Initialized
INFO - 2020-10-08 08:24:45 --> Security Class Initialized
DEBUG - 2020-10-08 08:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:24:45 --> Input Class Initialized
INFO - 2020-10-08 08:24:45 --> Language Class Initialized
INFO - 2020-10-08 08:24:45 --> Loader Class Initialized
INFO - 2020-10-08 08:24:45 --> Helper loaded: url_helper
INFO - 2020-10-08 08:24:45 --> Database Driver Class Initialized
INFO - 2020-10-08 08:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:24:45 --> Email Class Initialized
INFO - 2020-10-08 08:24:45 --> Controller Class Initialized
DEBUG - 2020-10-08 08:24:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:24:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:24:45 --> Model Class Initialized
INFO - 2020-10-08 08:24:45 --> Model Class Initialized
INFO - 2020-10-08 08:24:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-08 08:24:45 --> Final output sent to browser
DEBUG - 2020-10-08 08:24:45 --> Total execution time: 0.0219
ERROR - 2020-10-08 08:24:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:24:49 --> Config Class Initialized
INFO - 2020-10-08 08:24:49 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:24:49 --> Utf8 Class Initialized
INFO - 2020-10-08 08:24:49 --> URI Class Initialized
INFO - 2020-10-08 08:24:49 --> Router Class Initialized
INFO - 2020-10-08 08:24:49 --> Output Class Initialized
INFO - 2020-10-08 08:24:49 --> Security Class Initialized
DEBUG - 2020-10-08 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:24:49 --> Input Class Initialized
INFO - 2020-10-08 08:24:49 --> Language Class Initialized
INFO - 2020-10-08 08:24:49 --> Loader Class Initialized
INFO - 2020-10-08 08:24:49 --> Helper loaded: url_helper
INFO - 2020-10-08 08:24:49 --> Database Driver Class Initialized
INFO - 2020-10-08 08:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:24:49 --> Email Class Initialized
INFO - 2020-10-08 08:24:49 --> Controller Class Initialized
DEBUG - 2020-10-08 08:24:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:24:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:24:49 --> Model Class Initialized
INFO - 2020-10-08 08:24:49 --> Model Class Initialized
INFO - 2020-10-08 08:24:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:24:49 --> Final output sent to browser
DEBUG - 2020-10-08 08:24:49 --> Total execution time: 0.0275
ERROR - 2020-10-08 08:25:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:25:15 --> Config Class Initialized
INFO - 2020-10-08 08:25:15 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:25:15 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:25:15 --> Utf8 Class Initialized
INFO - 2020-10-08 08:25:15 --> URI Class Initialized
INFO - 2020-10-08 08:25:15 --> Router Class Initialized
INFO - 2020-10-08 08:25:15 --> Output Class Initialized
INFO - 2020-10-08 08:25:15 --> Security Class Initialized
DEBUG - 2020-10-08 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:25:15 --> Input Class Initialized
INFO - 2020-10-08 08:25:15 --> Language Class Initialized
INFO - 2020-10-08 08:25:15 --> Loader Class Initialized
INFO - 2020-10-08 08:25:15 --> Helper loaded: url_helper
INFO - 2020-10-08 08:25:15 --> Database Driver Class Initialized
INFO - 2020-10-08 08:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:25:15 --> Email Class Initialized
INFO - 2020-10-08 08:25:15 --> Controller Class Initialized
DEBUG - 2020-10-08 08:25:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:25:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:25:15 --> Model Class Initialized
INFO - 2020-10-08 08:25:15 --> Model Class Initialized
INFO - 2020-10-08 08:25:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:25:15 --> Final output sent to browser
DEBUG - 2020-10-08 08:25:15 --> Total execution time: 0.0251
ERROR - 2020-10-08 08:25:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:25:31 --> Config Class Initialized
INFO - 2020-10-08 08:25:31 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:25:31 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:25:31 --> Utf8 Class Initialized
INFO - 2020-10-08 08:25:31 --> URI Class Initialized
INFO - 2020-10-08 08:25:31 --> Router Class Initialized
INFO - 2020-10-08 08:25:31 --> Output Class Initialized
INFO - 2020-10-08 08:25:31 --> Security Class Initialized
DEBUG - 2020-10-08 08:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:25:31 --> Input Class Initialized
INFO - 2020-10-08 08:25:31 --> Language Class Initialized
INFO - 2020-10-08 08:25:31 --> Loader Class Initialized
INFO - 2020-10-08 08:25:31 --> Helper loaded: url_helper
INFO - 2020-10-08 08:25:31 --> Database Driver Class Initialized
INFO - 2020-10-08 08:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:25:31 --> Email Class Initialized
INFO - 2020-10-08 08:25:31 --> Controller Class Initialized
DEBUG - 2020-10-08 08:25:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:25:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:25:31 --> Model Class Initialized
INFO - 2020-10-08 08:25:31 --> Model Class Initialized
INFO - 2020-10-08 08:25:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:25:31 --> Final output sent to browser
DEBUG - 2020-10-08 08:25:31 --> Total execution time: 0.0657
ERROR - 2020-10-08 08:25:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:25:56 --> Config Class Initialized
INFO - 2020-10-08 08:25:56 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:25:56 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:25:56 --> Utf8 Class Initialized
INFO - 2020-10-08 08:25:56 --> URI Class Initialized
INFO - 2020-10-08 08:25:56 --> Router Class Initialized
INFO - 2020-10-08 08:25:56 --> Output Class Initialized
INFO - 2020-10-08 08:25:56 --> Security Class Initialized
DEBUG - 2020-10-08 08:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:25:56 --> Input Class Initialized
INFO - 2020-10-08 08:25:56 --> Language Class Initialized
INFO - 2020-10-08 08:25:56 --> Loader Class Initialized
INFO - 2020-10-08 08:25:56 --> Helper loaded: url_helper
INFO - 2020-10-08 08:25:56 --> Database Driver Class Initialized
INFO - 2020-10-08 08:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:25:56 --> Email Class Initialized
INFO - 2020-10-08 08:25:56 --> Controller Class Initialized
DEBUG - 2020-10-08 08:25:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:25:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:25:56 --> Model Class Initialized
INFO - 2020-10-08 08:25:56 --> Model Class Initialized
INFO - 2020-10-08 08:25:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-08 08:25:56 --> Final output sent to browser
DEBUG - 2020-10-08 08:25:56 --> Total execution time: 0.0324
ERROR - 2020-10-08 08:26:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:26:34 --> Config Class Initialized
INFO - 2020-10-08 08:26:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:26:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:26:34 --> Utf8 Class Initialized
INFO - 2020-10-08 08:26:34 --> URI Class Initialized
INFO - 2020-10-08 08:26:34 --> Router Class Initialized
INFO - 2020-10-08 08:26:34 --> Output Class Initialized
INFO - 2020-10-08 08:26:34 --> Security Class Initialized
DEBUG - 2020-10-08 08:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:26:34 --> Input Class Initialized
INFO - 2020-10-08 08:26:34 --> Language Class Initialized
INFO - 2020-10-08 08:26:34 --> Loader Class Initialized
INFO - 2020-10-08 08:26:34 --> Helper loaded: url_helper
INFO - 2020-10-08 08:26:34 --> Database Driver Class Initialized
INFO - 2020-10-08 08:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:26:34 --> Email Class Initialized
INFO - 2020-10-08 08:26:34 --> Controller Class Initialized
DEBUG - 2020-10-08 08:26:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:26:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:26:34 --> Model Class Initialized
INFO - 2020-10-08 08:26:34 --> Model Class Initialized
INFO - 2020-10-08 08:26:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:26:34 --> Final output sent to browser
DEBUG - 2020-10-08 08:26:34 --> Total execution time: 0.0254
ERROR - 2020-10-08 08:28:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:28:28 --> Config Class Initialized
INFO - 2020-10-08 08:28:28 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:28:28 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:28:28 --> Utf8 Class Initialized
INFO - 2020-10-08 08:28:28 --> URI Class Initialized
INFO - 2020-10-08 08:28:28 --> Router Class Initialized
INFO - 2020-10-08 08:28:28 --> Output Class Initialized
INFO - 2020-10-08 08:28:28 --> Security Class Initialized
DEBUG - 2020-10-08 08:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:28:28 --> Input Class Initialized
INFO - 2020-10-08 08:28:28 --> Language Class Initialized
INFO - 2020-10-08 08:28:28 --> Loader Class Initialized
INFO - 2020-10-08 08:28:28 --> Helper loaded: url_helper
INFO - 2020-10-08 08:28:28 --> Database Driver Class Initialized
INFO - 2020-10-08 08:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:28:28 --> Email Class Initialized
INFO - 2020-10-08 08:28:28 --> Controller Class Initialized
DEBUG - 2020-10-08 08:28:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:28:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:28:28 --> Model Class Initialized
INFO - 2020-10-08 08:28:28 --> Model Class Initialized
INFO - 2020-10-08 08:28:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:28:28 --> Final output sent to browser
DEBUG - 2020-10-08 08:28:28 --> Total execution time: 0.0214
ERROR - 2020-10-08 08:29:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:29:26 --> Config Class Initialized
INFO - 2020-10-08 08:29:26 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:29:26 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:29:26 --> Utf8 Class Initialized
INFO - 2020-10-08 08:29:26 --> URI Class Initialized
INFO - 2020-10-08 08:29:26 --> Router Class Initialized
INFO - 2020-10-08 08:29:26 --> Output Class Initialized
INFO - 2020-10-08 08:29:26 --> Security Class Initialized
DEBUG - 2020-10-08 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:29:26 --> Input Class Initialized
INFO - 2020-10-08 08:29:26 --> Language Class Initialized
INFO - 2020-10-08 08:29:26 --> Loader Class Initialized
INFO - 2020-10-08 08:29:26 --> Helper loaded: url_helper
INFO - 2020-10-08 08:29:26 --> Database Driver Class Initialized
INFO - 2020-10-08 08:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:29:26 --> Email Class Initialized
INFO - 2020-10-08 08:29:26 --> Controller Class Initialized
DEBUG - 2020-10-08 08:29:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:29:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:29:26 --> Model Class Initialized
INFO - 2020-10-08 08:29:26 --> Model Class Initialized
INFO - 2020-10-08 08:29:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-08 08:29:26 --> Final output sent to browser
DEBUG - 2020-10-08 08:29:26 --> Total execution time: 0.0222
ERROR - 2020-10-08 08:34:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:34:26 --> Config Class Initialized
INFO - 2020-10-08 08:34:26 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:34:26 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:34:26 --> Utf8 Class Initialized
INFO - 2020-10-08 08:34:26 --> URI Class Initialized
INFO - 2020-10-08 08:34:26 --> Router Class Initialized
INFO - 2020-10-08 08:34:26 --> Output Class Initialized
INFO - 2020-10-08 08:34:26 --> Security Class Initialized
DEBUG - 2020-10-08 08:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:34:26 --> Input Class Initialized
INFO - 2020-10-08 08:34:26 --> Language Class Initialized
INFO - 2020-10-08 08:34:26 --> Loader Class Initialized
INFO - 2020-10-08 08:34:26 --> Helper loaded: url_helper
INFO - 2020-10-08 08:34:26 --> Database Driver Class Initialized
INFO - 2020-10-08 08:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:34:26 --> Email Class Initialized
INFO - 2020-10-08 08:34:26 --> Controller Class Initialized
DEBUG - 2020-10-08 08:34:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:34:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:34:26 --> Model Class Initialized
INFO - 2020-10-08 08:34:26 --> Model Class Initialized
INFO - 2020-10-08 08:34:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-08 08:34:26 --> Final output sent to browser
DEBUG - 2020-10-08 08:34:26 --> Total execution time: 0.0206
ERROR - 2020-10-08 08:34:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:34:59 --> Config Class Initialized
INFO - 2020-10-08 08:34:59 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:34:59 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:34:59 --> Utf8 Class Initialized
INFO - 2020-10-08 08:34:59 --> URI Class Initialized
INFO - 2020-10-08 08:34:59 --> Router Class Initialized
INFO - 2020-10-08 08:34:59 --> Output Class Initialized
INFO - 2020-10-08 08:34:59 --> Security Class Initialized
DEBUG - 2020-10-08 08:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:34:59 --> Input Class Initialized
INFO - 2020-10-08 08:34:59 --> Language Class Initialized
INFO - 2020-10-08 08:34:59 --> Loader Class Initialized
INFO - 2020-10-08 08:34:59 --> Helper loaded: url_helper
INFO - 2020-10-08 08:34:59 --> Database Driver Class Initialized
INFO - 2020-10-08 08:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:34:59 --> Email Class Initialized
INFO - 2020-10-08 08:34:59 --> Controller Class Initialized
DEBUG - 2020-10-08 08:34:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:34:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:34:59 --> Model Class Initialized
INFO - 2020-10-08 08:34:59 --> Model Class Initialized
INFO - 2020-10-08 08:34:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:34:59 --> Final output sent to browser
DEBUG - 2020-10-08 08:34:59 --> Total execution time: 0.0330
ERROR - 2020-10-08 08:35:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:35:02 --> Config Class Initialized
INFO - 2020-10-08 08:35:02 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:35:02 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:35:02 --> Utf8 Class Initialized
INFO - 2020-10-08 08:35:02 --> URI Class Initialized
INFO - 2020-10-08 08:35:02 --> Router Class Initialized
INFO - 2020-10-08 08:35:02 --> Output Class Initialized
INFO - 2020-10-08 08:35:02 --> Security Class Initialized
DEBUG - 2020-10-08 08:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:35:02 --> Input Class Initialized
INFO - 2020-10-08 08:35:02 --> Language Class Initialized
INFO - 2020-10-08 08:35:02 --> Loader Class Initialized
INFO - 2020-10-08 08:35:02 --> Helper loaded: url_helper
INFO - 2020-10-08 08:35:02 --> Database Driver Class Initialized
INFO - 2020-10-08 08:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:35:02 --> Email Class Initialized
INFO - 2020-10-08 08:35:02 --> Controller Class Initialized
DEBUG - 2020-10-08 08:35:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:35:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:35:02 --> Model Class Initialized
INFO - 2020-10-08 08:35:02 --> Model Class Initialized
INFO - 2020-10-08 08:35:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-10-08 08:35:02 --> Final output sent to browser
DEBUG - 2020-10-08 08:35:02 --> Total execution time: 0.0405
ERROR - 2020-10-08 08:35:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:35:46 --> Config Class Initialized
INFO - 2020-10-08 08:35:46 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:35:46 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:35:46 --> Utf8 Class Initialized
INFO - 2020-10-08 08:35:46 --> URI Class Initialized
INFO - 2020-10-08 08:35:46 --> Router Class Initialized
INFO - 2020-10-08 08:35:46 --> Output Class Initialized
INFO - 2020-10-08 08:35:46 --> Security Class Initialized
DEBUG - 2020-10-08 08:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:35:46 --> Input Class Initialized
INFO - 2020-10-08 08:35:46 --> Language Class Initialized
INFO - 2020-10-08 08:35:46 --> Loader Class Initialized
INFO - 2020-10-08 08:35:46 --> Helper loaded: url_helper
INFO - 2020-10-08 08:35:46 --> Database Driver Class Initialized
INFO - 2020-10-08 08:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:35:46 --> Email Class Initialized
INFO - 2020-10-08 08:35:46 --> Controller Class Initialized
DEBUG - 2020-10-08 08:35:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:35:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:35:46 --> Model Class Initialized
INFO - 2020-10-08 08:35:46 --> Model Class Initialized
INFO - 2020-10-08 08:35:46 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_view.php
INFO - 2020-10-08 08:35:46 --> Final output sent to browser
DEBUG - 2020-10-08 08:35:46 --> Total execution time: 0.0231
ERROR - 2020-10-08 08:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:36:00 --> Config Class Initialized
INFO - 2020-10-08 08:36:00 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:36:00 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:36:00 --> Utf8 Class Initialized
INFO - 2020-10-08 08:36:00 --> URI Class Initialized
INFO - 2020-10-08 08:36:00 --> Router Class Initialized
INFO - 2020-10-08 08:36:00 --> Output Class Initialized
INFO - 2020-10-08 08:36:00 --> Security Class Initialized
DEBUG - 2020-10-08 08:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:36:00 --> Input Class Initialized
INFO - 2020-10-08 08:36:00 --> Language Class Initialized
INFO - 2020-10-08 08:36:00 --> Loader Class Initialized
INFO - 2020-10-08 08:36:00 --> Helper loaded: url_helper
INFO - 2020-10-08 08:36:00 --> Database Driver Class Initialized
INFO - 2020-10-08 08:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:36:00 --> Email Class Initialized
INFO - 2020-10-08 08:36:00 --> Controller Class Initialized
DEBUG - 2020-10-08 08:36:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:36:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:36:00 --> Model Class Initialized
INFO - 2020-10-08 08:36:00 --> Model Class Initialized
INFO - 2020-10-08 08:36:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:36:00 --> Final output sent to browser
DEBUG - 2020-10-08 08:36:00 --> Total execution time: 0.0246
ERROR - 2020-10-08 08:36:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:36:27 --> Config Class Initialized
INFO - 2020-10-08 08:36:27 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:36:27 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:36:27 --> Utf8 Class Initialized
INFO - 2020-10-08 08:36:27 --> URI Class Initialized
INFO - 2020-10-08 08:36:27 --> Router Class Initialized
INFO - 2020-10-08 08:36:27 --> Output Class Initialized
INFO - 2020-10-08 08:36:27 --> Security Class Initialized
DEBUG - 2020-10-08 08:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:36:27 --> Input Class Initialized
INFO - 2020-10-08 08:36:27 --> Language Class Initialized
INFO - 2020-10-08 08:36:27 --> Loader Class Initialized
INFO - 2020-10-08 08:36:27 --> Helper loaded: url_helper
INFO - 2020-10-08 08:36:27 --> Database Driver Class Initialized
INFO - 2020-10-08 08:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:36:27 --> Email Class Initialized
INFO - 2020-10-08 08:36:27 --> Controller Class Initialized
DEBUG - 2020-10-08 08:36:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:36:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:36:27 --> Model Class Initialized
INFO - 2020-10-08 08:36:27 --> Model Class Initialized
INFO - 2020-10-08 08:36:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-08 08:36:27 --> Final output sent to browser
DEBUG - 2020-10-08 08:36:27 --> Total execution time: 0.0296
ERROR - 2020-10-08 08:40:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:04 --> Config Class Initialized
INFO - 2020-10-08 08:40:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:04 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:04 --> URI Class Initialized
INFO - 2020-10-08 08:40:04 --> Router Class Initialized
INFO - 2020-10-08 08:40:04 --> Output Class Initialized
INFO - 2020-10-08 08:40:04 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:04 --> Input Class Initialized
INFO - 2020-10-08 08:40:04 --> Language Class Initialized
INFO - 2020-10-08 08:40:04 --> Loader Class Initialized
INFO - 2020-10-08 08:40:04 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:04 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:04 --> Email Class Initialized
INFO - 2020-10-08 08:40:04 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:04 --> Model Class Initialized
INFO - 2020-10-08 08:40:04 --> Model Class Initialized
INFO - 2020-10-08 08:40:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-08 08:40:04 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:04 --> Total execution time: 0.0238
ERROR - 2020-10-08 08:40:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:15 --> Config Class Initialized
INFO - 2020-10-08 08:40:15 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:15 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:15 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:15 --> URI Class Initialized
INFO - 2020-10-08 08:40:15 --> Router Class Initialized
INFO - 2020-10-08 08:40:15 --> Output Class Initialized
INFO - 2020-10-08 08:40:15 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:15 --> Input Class Initialized
INFO - 2020-10-08 08:40:15 --> Language Class Initialized
INFO - 2020-10-08 08:40:15 --> Loader Class Initialized
INFO - 2020-10-08 08:40:15 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:15 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:15 --> Email Class Initialized
INFO - 2020-10-08 08:40:15 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:15 --> Model Class Initialized
INFO - 2020-10-08 08:40:15 --> Model Class Initialized
INFO - 2020-10-08 08:40:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-08 08:40:15 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:15 --> Total execution time: 0.0209
ERROR - 2020-10-08 08:40:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:16 --> Config Class Initialized
INFO - 2020-10-08 08:40:16 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:16 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:16 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:16 --> URI Class Initialized
INFO - 2020-10-08 08:40:16 --> Router Class Initialized
INFO - 2020-10-08 08:40:16 --> Output Class Initialized
INFO - 2020-10-08 08:40:16 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:16 --> Input Class Initialized
INFO - 2020-10-08 08:40:16 --> Language Class Initialized
INFO - 2020-10-08 08:40:16 --> Loader Class Initialized
INFO - 2020-10-08 08:40:16 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:16 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:16 --> Email Class Initialized
INFO - 2020-10-08 08:40:16 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:16 --> Model Class Initialized
INFO - 2020-10-08 08:40:16 --> Model Class Initialized
INFO - 2020-10-08 08:40:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 08:40:16 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:16 --> Total execution time: 0.0220
ERROR - 2020-10-08 08:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:34 --> Config Class Initialized
INFO - 2020-10-08 08:40:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:34 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:34 --> URI Class Initialized
INFO - 2020-10-08 08:40:34 --> Router Class Initialized
INFO - 2020-10-08 08:40:34 --> Output Class Initialized
INFO - 2020-10-08 08:40:34 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:34 --> Input Class Initialized
INFO - 2020-10-08 08:40:34 --> Language Class Initialized
INFO - 2020-10-08 08:40:34 --> Loader Class Initialized
INFO - 2020-10-08 08:40:34 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:34 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:34 --> Email Class Initialized
INFO - 2020-10-08 08:40:34 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:34 --> Model Class Initialized
INFO - 2020-10-08 08:40:34 --> Model Class Initialized
INFO - 2020-10-08 08:40:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-08 08:40:34 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:34 --> Total execution time: 0.0326
ERROR - 2020-10-08 08:40:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:34 --> Config Class Initialized
INFO - 2020-10-08 08:40:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:34 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:34 --> URI Class Initialized
INFO - 2020-10-08 08:40:34 --> Router Class Initialized
INFO - 2020-10-08 08:40:34 --> Output Class Initialized
INFO - 2020-10-08 08:40:34 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:34 --> Input Class Initialized
INFO - 2020-10-08 08:40:34 --> Language Class Initialized
INFO - 2020-10-08 08:40:34 --> Loader Class Initialized
INFO - 2020-10-08 08:40:34 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:34 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:34 --> Email Class Initialized
INFO - 2020-10-08 08:40:34 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:34 --> Model Class Initialized
INFO - 2020-10-08 08:40:34 --> Model Class Initialized
INFO - 2020-10-08 08:40:34 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:34 --> Total execution time: 0.0251
ERROR - 2020-10-08 08:40:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:45 --> Config Class Initialized
INFO - 2020-10-08 08:40:45 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:45 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:45 --> URI Class Initialized
INFO - 2020-10-08 08:40:45 --> Router Class Initialized
INFO - 2020-10-08 08:40:45 --> Output Class Initialized
INFO - 2020-10-08 08:40:45 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:45 --> Input Class Initialized
INFO - 2020-10-08 08:40:45 --> Language Class Initialized
INFO - 2020-10-08 08:40:45 --> Loader Class Initialized
INFO - 2020-10-08 08:40:45 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:45 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:45 --> Email Class Initialized
INFO - 2020-10-08 08:40:45 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:45 --> Model Class Initialized
INFO - 2020-10-08 08:40:45 --> Model Class Initialized
INFO - 2020-10-08 08:40:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-08 08:40:45 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:45 --> Total execution time: 0.0314
ERROR - 2020-10-08 08:40:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:40:46 --> Config Class Initialized
INFO - 2020-10-08 08:40:46 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:40:46 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:40:46 --> Utf8 Class Initialized
INFO - 2020-10-08 08:40:46 --> URI Class Initialized
INFO - 2020-10-08 08:40:46 --> Router Class Initialized
INFO - 2020-10-08 08:40:46 --> Output Class Initialized
INFO - 2020-10-08 08:40:46 --> Security Class Initialized
DEBUG - 2020-10-08 08:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:40:46 --> Input Class Initialized
INFO - 2020-10-08 08:40:46 --> Language Class Initialized
INFO - 2020-10-08 08:40:46 --> Loader Class Initialized
INFO - 2020-10-08 08:40:46 --> Helper loaded: url_helper
INFO - 2020-10-08 08:40:46 --> Database Driver Class Initialized
INFO - 2020-10-08 08:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:40:46 --> Email Class Initialized
INFO - 2020-10-08 08:40:46 --> Controller Class Initialized
DEBUG - 2020-10-08 08:40:46 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:40:46 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:40:46 --> Model Class Initialized
INFO - 2020-10-08 08:40:46 --> Model Class Initialized
INFO - 2020-10-08 08:40:46 --> Final output sent to browser
DEBUG - 2020-10-08 08:40:46 --> Total execution time: 0.0231
ERROR - 2020-10-08 08:41:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:41:02 --> Config Class Initialized
INFO - 2020-10-08 08:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:41:02 --> Utf8 Class Initialized
INFO - 2020-10-08 08:41:02 --> URI Class Initialized
INFO - 2020-10-08 08:41:02 --> Router Class Initialized
INFO - 2020-10-08 08:41:02 --> Output Class Initialized
INFO - 2020-10-08 08:41:02 --> Security Class Initialized
DEBUG - 2020-10-08 08:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:41:02 --> Input Class Initialized
INFO - 2020-10-08 08:41:02 --> Language Class Initialized
INFO - 2020-10-08 08:41:02 --> Loader Class Initialized
INFO - 2020-10-08 08:41:02 --> Helper loaded: url_helper
INFO - 2020-10-08 08:41:02 --> Database Driver Class Initialized
INFO - 2020-10-08 08:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:41:02 --> Email Class Initialized
INFO - 2020-10-08 08:41:02 --> Controller Class Initialized
DEBUG - 2020-10-08 08:41:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:41:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:41:02 --> Model Class Initialized
INFO - 2020-10-08 08:41:02 --> Model Class Initialized
INFO - 2020-10-08 08:41:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-08 08:41:02 --> Final output sent to browser
DEBUG - 2020-10-08 08:41:02 --> Total execution time: 0.0252
ERROR - 2020-10-08 08:41:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:41:03 --> Config Class Initialized
INFO - 2020-10-08 08:41:03 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:41:03 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:41:03 --> Utf8 Class Initialized
INFO - 2020-10-08 08:41:03 --> URI Class Initialized
INFO - 2020-10-08 08:41:03 --> Router Class Initialized
INFO - 2020-10-08 08:41:03 --> Output Class Initialized
INFO - 2020-10-08 08:41:03 --> Security Class Initialized
DEBUG - 2020-10-08 08:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:41:03 --> Input Class Initialized
INFO - 2020-10-08 08:41:03 --> Language Class Initialized
INFO - 2020-10-08 08:41:03 --> Loader Class Initialized
INFO - 2020-10-08 08:41:03 --> Helper loaded: url_helper
INFO - 2020-10-08 08:41:03 --> Database Driver Class Initialized
INFO - 2020-10-08 08:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:41:03 --> Email Class Initialized
INFO - 2020-10-08 08:41:03 --> Controller Class Initialized
DEBUG - 2020-10-08 08:41:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:41:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:41:03 --> Model Class Initialized
INFO - 2020-10-08 08:41:03 --> Model Class Initialized
INFO - 2020-10-08 08:41:03 --> Final output sent to browser
DEBUG - 2020-10-08 08:41:03 --> Total execution time: 0.0284
ERROR - 2020-10-08 08:41:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:41:37 --> Config Class Initialized
INFO - 2020-10-08 08:41:37 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:41:37 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:41:37 --> Utf8 Class Initialized
INFO - 2020-10-08 08:41:37 --> URI Class Initialized
INFO - 2020-10-08 08:41:37 --> Router Class Initialized
INFO - 2020-10-08 08:41:37 --> Output Class Initialized
INFO - 2020-10-08 08:41:37 --> Security Class Initialized
DEBUG - 2020-10-08 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:41:37 --> Input Class Initialized
INFO - 2020-10-08 08:41:37 --> Language Class Initialized
INFO - 2020-10-08 08:41:37 --> Loader Class Initialized
INFO - 2020-10-08 08:41:37 --> Helper loaded: url_helper
INFO - 2020-10-08 08:41:37 --> Database Driver Class Initialized
INFO - 2020-10-08 08:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:41:37 --> Email Class Initialized
INFO - 2020-10-08 08:41:37 --> Controller Class Initialized
DEBUG - 2020-10-08 08:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:41:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:41:37 --> Model Class Initialized
INFO - 2020-10-08 08:41:37 --> Model Class Initialized
INFO - 2020-10-08 08:41:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-08 08:41:37 --> Final output sent to browser
DEBUG - 2020-10-08 08:41:37 --> Total execution time: 0.0226
ERROR - 2020-10-08 08:41:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:41:37 --> Config Class Initialized
INFO - 2020-10-08 08:41:37 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:41:37 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:41:37 --> Utf8 Class Initialized
INFO - 2020-10-08 08:41:37 --> URI Class Initialized
INFO - 2020-10-08 08:41:37 --> Router Class Initialized
INFO - 2020-10-08 08:41:37 --> Output Class Initialized
INFO - 2020-10-08 08:41:37 --> Security Class Initialized
DEBUG - 2020-10-08 08:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:41:37 --> Input Class Initialized
INFO - 2020-10-08 08:41:37 --> Language Class Initialized
INFO - 2020-10-08 08:41:37 --> Loader Class Initialized
INFO - 2020-10-08 08:41:37 --> Helper loaded: url_helper
INFO - 2020-10-08 08:41:37 --> Database Driver Class Initialized
INFO - 2020-10-08 08:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:41:37 --> Email Class Initialized
INFO - 2020-10-08 08:41:37 --> Controller Class Initialized
DEBUG - 2020-10-08 08:41:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:41:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:41:37 --> Model Class Initialized
INFO - 2020-10-08 08:41:37 --> Model Class Initialized
INFO - 2020-10-08 08:41:37 --> Final output sent to browser
DEBUG - 2020-10-08 08:41:37 --> Total execution time: 0.0237
ERROR - 2020-10-08 08:41:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:41:43 --> Config Class Initialized
INFO - 2020-10-08 08:41:43 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:41:43 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:41:43 --> Utf8 Class Initialized
INFO - 2020-10-08 08:41:43 --> URI Class Initialized
INFO - 2020-10-08 08:41:43 --> Router Class Initialized
INFO - 2020-10-08 08:41:43 --> Output Class Initialized
INFO - 2020-10-08 08:41:43 --> Security Class Initialized
DEBUG - 2020-10-08 08:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:41:43 --> Input Class Initialized
INFO - 2020-10-08 08:41:43 --> Language Class Initialized
INFO - 2020-10-08 08:41:43 --> Loader Class Initialized
INFO - 2020-10-08 08:41:43 --> Helper loaded: url_helper
INFO - 2020-10-08 08:41:43 --> Database Driver Class Initialized
INFO - 2020-10-08 08:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:41:43 --> Email Class Initialized
INFO - 2020-10-08 08:41:43 --> Controller Class Initialized
DEBUG - 2020-10-08 08:41:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:41:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:41:43 --> Model Class Initialized
INFO - 2020-10-08 08:41:43 --> Model Class Initialized
INFO - 2020-10-08 08:41:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-08 08:41:43 --> Final output sent to browser
DEBUG - 2020-10-08 08:41:43 --> Total execution time: 0.0347
ERROR - 2020-10-08 08:41:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:41:44 --> Config Class Initialized
INFO - 2020-10-08 08:41:44 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:41:44 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:41:44 --> Utf8 Class Initialized
INFO - 2020-10-08 08:41:44 --> URI Class Initialized
INFO - 2020-10-08 08:41:44 --> Router Class Initialized
INFO - 2020-10-08 08:41:44 --> Output Class Initialized
INFO - 2020-10-08 08:41:44 --> Security Class Initialized
DEBUG - 2020-10-08 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:41:44 --> Input Class Initialized
INFO - 2020-10-08 08:41:44 --> Language Class Initialized
INFO - 2020-10-08 08:41:44 --> Loader Class Initialized
INFO - 2020-10-08 08:41:44 --> Helper loaded: url_helper
INFO - 2020-10-08 08:41:44 --> Database Driver Class Initialized
INFO - 2020-10-08 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:41:44 --> Email Class Initialized
INFO - 2020-10-08 08:41:44 --> Controller Class Initialized
DEBUG - 2020-10-08 08:41:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:41:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:41:44 --> Model Class Initialized
INFO - 2020-10-08 08:41:44 --> Model Class Initialized
INFO - 2020-10-08 08:41:44 --> Final output sent to browser
DEBUG - 2020-10-08 08:41:44 --> Total execution time: 0.0244
ERROR - 2020-10-08 08:42:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:08 --> Config Class Initialized
INFO - 2020-10-08 08:42:08 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:08 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:08 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:08 --> URI Class Initialized
INFO - 2020-10-08 08:42:08 --> Router Class Initialized
INFO - 2020-10-08 08:42:08 --> Output Class Initialized
INFO - 2020-10-08 08:42:08 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:08 --> Input Class Initialized
INFO - 2020-10-08 08:42:08 --> Language Class Initialized
INFO - 2020-10-08 08:42:08 --> Loader Class Initialized
INFO - 2020-10-08 08:42:08 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:08 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:08 --> Email Class Initialized
INFO - 2020-10-08 08:42:08 --> Controller Class Initialized
DEBUG - 2020-10-08 08:42:08 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:42:08 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:08 --> Model Class Initialized
INFO - 2020-10-08 08:42:08 --> Model Class Initialized
INFO - 2020-10-08 08:42:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-08 08:42:08 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:08 --> Total execution time: 0.0269
ERROR - 2020-10-08 08:42:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:09 --> Config Class Initialized
INFO - 2020-10-08 08:42:09 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:09 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:09 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:09 --> URI Class Initialized
INFO - 2020-10-08 08:42:09 --> Router Class Initialized
INFO - 2020-10-08 08:42:09 --> Output Class Initialized
INFO - 2020-10-08 08:42:09 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:09 --> Input Class Initialized
INFO - 2020-10-08 08:42:09 --> Language Class Initialized
INFO - 2020-10-08 08:42:09 --> Loader Class Initialized
INFO - 2020-10-08 08:42:09 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:09 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:09 --> Email Class Initialized
INFO - 2020-10-08 08:42:09 --> Controller Class Initialized
DEBUG - 2020-10-08 08:42:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:42:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:09 --> Model Class Initialized
INFO - 2020-10-08 08:42:09 --> Model Class Initialized
INFO - 2020-10-08 08:42:09 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:09 --> Total execution time: 0.0276
ERROR - 2020-10-08 08:42:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:12 --> Config Class Initialized
INFO - 2020-10-08 08:42:12 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:12 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:12 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:12 --> URI Class Initialized
INFO - 2020-10-08 08:42:12 --> Router Class Initialized
INFO - 2020-10-08 08:42:12 --> Output Class Initialized
INFO - 2020-10-08 08:42:12 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:12 --> Input Class Initialized
INFO - 2020-10-08 08:42:12 --> Language Class Initialized
INFO - 2020-10-08 08:42:12 --> Loader Class Initialized
INFO - 2020-10-08 08:42:12 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:12 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:12 --> Email Class Initialized
INFO - 2020-10-08 08:42:12 --> Controller Class Initialized
DEBUG - 2020-10-08 08:42:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:42:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:12 --> Model Class Initialized
INFO - 2020-10-08 08:42:12 --> Model Class Initialized
INFO - 2020-10-08 08:42:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 08:42:12 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:12 --> Total execution time: 0.0240
ERROR - 2020-10-08 08:42:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:18 --> Config Class Initialized
INFO - 2020-10-08 08:42:18 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:18 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:18 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:18 --> URI Class Initialized
INFO - 2020-10-08 08:42:18 --> Router Class Initialized
INFO - 2020-10-08 08:42:18 --> Output Class Initialized
INFO - 2020-10-08 08:42:18 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:18 --> Input Class Initialized
INFO - 2020-10-08 08:42:18 --> Language Class Initialized
INFO - 2020-10-08 08:42:18 --> Loader Class Initialized
INFO - 2020-10-08 08:42:18 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:18 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:19 --> Email Class Initialized
INFO - 2020-10-08 08:42:19 --> Controller Class Initialized
DEBUG - 2020-10-08 08:42:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:42:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:19 --> Model Class Initialized
INFO - 2020-10-08 08:42:19 --> Model Class Initialized
INFO - 2020-10-08 08:42:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 08:42:19 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:19 --> Total execution time: 0.0296
ERROR - 2020-10-08 08:42:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:29 --> Config Class Initialized
INFO - 2020-10-08 08:42:29 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:29 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:29 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:29 --> URI Class Initialized
DEBUG - 2020-10-08 08:42:29 --> No URI present. Default controller set.
INFO - 2020-10-08 08:42:29 --> Router Class Initialized
INFO - 2020-10-08 08:42:29 --> Output Class Initialized
INFO - 2020-10-08 08:42:29 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:29 --> Input Class Initialized
INFO - 2020-10-08 08:42:29 --> Language Class Initialized
INFO - 2020-10-08 08:42:29 --> Loader Class Initialized
INFO - 2020-10-08 08:42:29 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:29 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:29 --> Email Class Initialized
INFO - 2020-10-08 08:42:29 --> Controller Class Initialized
INFO - 2020-10-08 08:42:29 --> Model Class Initialized
INFO - 2020-10-08 08:42:29 --> Model Class Initialized
DEBUG - 2020-10-08 08:42:29 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 08:42:29 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:29 --> Total execution time: 0.0213
ERROR - 2020-10-08 08:42:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:49 --> Config Class Initialized
INFO - 2020-10-08 08:42:49 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:49 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:49 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:49 --> URI Class Initialized
INFO - 2020-10-08 08:42:49 --> Router Class Initialized
INFO - 2020-10-08 08:42:49 --> Output Class Initialized
INFO - 2020-10-08 08:42:49 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:49 --> Input Class Initialized
INFO - 2020-10-08 08:42:49 --> Language Class Initialized
INFO - 2020-10-08 08:42:49 --> Loader Class Initialized
INFO - 2020-10-08 08:42:49 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:49 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:49 --> Email Class Initialized
INFO - 2020-10-08 08:42:49 --> Controller Class Initialized
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
DEBUG - 2020-10-08 08:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:42:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
INFO - 2020-10-08 08:42:49 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:49 --> Total execution time: 0.0271
ERROR - 2020-10-08 08:42:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:49 --> Config Class Initialized
INFO - 2020-10-08 08:42:49 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:49 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:49 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:49 --> URI Class Initialized
INFO - 2020-10-08 08:42:49 --> Router Class Initialized
INFO - 2020-10-08 08:42:49 --> Output Class Initialized
INFO - 2020-10-08 08:42:49 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:49 --> Input Class Initialized
INFO - 2020-10-08 08:42:49 --> Language Class Initialized
INFO - 2020-10-08 08:42:49 --> Loader Class Initialized
INFO - 2020-10-08 08:42:49 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:49 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:49 --> Email Class Initialized
INFO - 2020-10-08 08:42:49 --> Controller Class Initialized
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
DEBUG - 2020-10-08 08:42:49 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 08:42:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:42:49 --> Config Class Initialized
INFO - 2020-10-08 08:42:49 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:42:49 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:42:49 --> Utf8 Class Initialized
INFO - 2020-10-08 08:42:49 --> URI Class Initialized
INFO - 2020-10-08 08:42:49 --> Router Class Initialized
INFO - 2020-10-08 08:42:49 --> Output Class Initialized
INFO - 2020-10-08 08:42:49 --> Security Class Initialized
DEBUG - 2020-10-08 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:42:49 --> Input Class Initialized
INFO - 2020-10-08 08:42:49 --> Language Class Initialized
INFO - 2020-10-08 08:42:49 --> Loader Class Initialized
INFO - 2020-10-08 08:42:49 --> Helper loaded: url_helper
INFO - 2020-10-08 08:42:49 --> Database Driver Class Initialized
INFO - 2020-10-08 08:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:42:49 --> Email Class Initialized
INFO - 2020-10-08 08:42:49 --> Controller Class Initialized
DEBUG - 2020-10-08 08:42:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:42:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
INFO - 2020-10-08 08:42:49 --> Model Class Initialized
INFO - 2020-10-08 08:42:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 08:42:49 --> Final output sent to browser
DEBUG - 2020-10-08 08:42:49 --> Total execution time: 0.0617
ERROR - 2020-10-08 08:44:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:44:02 --> Config Class Initialized
INFO - 2020-10-08 08:44:02 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:44:02 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:44:02 --> Utf8 Class Initialized
INFO - 2020-10-08 08:44:02 --> URI Class Initialized
INFO - 2020-10-08 08:44:02 --> Router Class Initialized
INFO - 2020-10-08 08:44:02 --> Output Class Initialized
INFO - 2020-10-08 08:44:02 --> Security Class Initialized
DEBUG - 2020-10-08 08:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:44:02 --> Input Class Initialized
INFO - 2020-10-08 08:44:02 --> Language Class Initialized
INFO - 2020-10-08 08:44:02 --> Loader Class Initialized
INFO - 2020-10-08 08:44:02 --> Helper loaded: url_helper
INFO - 2020-10-08 08:44:02 --> Database Driver Class Initialized
INFO - 2020-10-08 08:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:44:02 --> Email Class Initialized
INFO - 2020-10-08 08:44:02 --> Controller Class Initialized
DEBUG - 2020-10-08 08:44:02 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:44:02 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:44:02 --> Model Class Initialized
INFO - 2020-10-08 08:44:02 --> Model Class Initialized
INFO - 2020-10-08 08:44:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 08:44:02 --> Final output sent to browser
DEBUG - 2020-10-08 08:44:02 --> Total execution time: 0.0253
ERROR - 2020-10-08 08:45:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:45:09 --> Config Class Initialized
INFO - 2020-10-08 08:45:09 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:45:09 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:45:09 --> Utf8 Class Initialized
INFO - 2020-10-08 08:45:09 --> URI Class Initialized
INFO - 2020-10-08 08:45:09 --> Router Class Initialized
INFO - 2020-10-08 08:45:09 --> Output Class Initialized
INFO - 2020-10-08 08:45:09 --> Security Class Initialized
DEBUG - 2020-10-08 08:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:45:09 --> Input Class Initialized
INFO - 2020-10-08 08:45:09 --> Language Class Initialized
INFO - 2020-10-08 08:45:09 --> Loader Class Initialized
INFO - 2020-10-08 08:45:09 --> Helper loaded: url_helper
INFO - 2020-10-08 08:45:09 --> Database Driver Class Initialized
INFO - 2020-10-08 08:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:45:09 --> Email Class Initialized
INFO - 2020-10-08 08:45:09 --> Controller Class Initialized
DEBUG - 2020-10-08 08:45:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:45:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:45:09 --> Model Class Initialized
INFO - 2020-10-08 08:45:09 --> Model Class Initialized
INFO - 2020-10-08 08:45:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 08:45:09 --> Final output sent to browser
DEBUG - 2020-10-08 08:45:09 --> Total execution time: 0.0227
ERROR - 2020-10-08 08:46:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:46:49 --> Config Class Initialized
INFO - 2020-10-08 08:46:49 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:46:49 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:46:49 --> Utf8 Class Initialized
INFO - 2020-10-08 08:46:49 --> URI Class Initialized
INFO - 2020-10-08 08:46:49 --> Router Class Initialized
INFO - 2020-10-08 08:46:49 --> Output Class Initialized
INFO - 2020-10-08 08:46:49 --> Security Class Initialized
DEBUG - 2020-10-08 08:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:46:49 --> Input Class Initialized
INFO - 2020-10-08 08:46:49 --> Language Class Initialized
INFO - 2020-10-08 08:46:49 --> Loader Class Initialized
INFO - 2020-10-08 08:46:49 --> Helper loaded: url_helper
INFO - 2020-10-08 08:46:49 --> Database Driver Class Initialized
INFO - 2020-10-08 08:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:46:49 --> Email Class Initialized
INFO - 2020-10-08 08:46:49 --> Controller Class Initialized
DEBUG - 2020-10-08 08:46:49 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:46:49 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:46:49 --> Model Class Initialized
INFO - 2020-10-08 08:46:49 --> Model Class Initialized
INFO - 2020-10-08 08:46:49 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 08:46:49 --> Final output sent to browser
DEBUG - 2020-10-08 08:46:49 --> Total execution time: 0.0250
ERROR - 2020-10-08 08:47:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:47:30 --> Config Class Initialized
INFO - 2020-10-08 08:47:30 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:47:30 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:47:30 --> Utf8 Class Initialized
INFO - 2020-10-08 08:47:30 --> URI Class Initialized
INFO - 2020-10-08 08:47:30 --> Router Class Initialized
INFO - 2020-10-08 08:47:30 --> Output Class Initialized
INFO - 2020-10-08 08:47:30 --> Security Class Initialized
DEBUG - 2020-10-08 08:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:47:30 --> Input Class Initialized
INFO - 2020-10-08 08:47:30 --> Language Class Initialized
INFO - 2020-10-08 08:47:30 --> Loader Class Initialized
INFO - 2020-10-08 08:47:30 --> Helper loaded: url_helper
INFO - 2020-10-08 08:47:30 --> Database Driver Class Initialized
INFO - 2020-10-08 08:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:47:30 --> Email Class Initialized
INFO - 2020-10-08 08:47:30 --> Controller Class Initialized
DEBUG - 2020-10-08 08:47:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:47:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:47:30 --> Model Class Initialized
INFO - 2020-10-08 08:47:30 --> Model Class Initialized
INFO - 2020-10-08 08:47:30 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 08:47:30 --> Final output sent to browser
DEBUG - 2020-10-08 08:47:30 --> Total execution time: 0.0327
ERROR - 2020-10-08 08:47:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:47:35 --> Config Class Initialized
INFO - 2020-10-08 08:47:35 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:47:35 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:47:35 --> Utf8 Class Initialized
INFO - 2020-10-08 08:47:35 --> URI Class Initialized
INFO - 2020-10-08 08:47:35 --> Router Class Initialized
INFO - 2020-10-08 08:47:35 --> Output Class Initialized
INFO - 2020-10-08 08:47:35 --> Security Class Initialized
DEBUG - 2020-10-08 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:47:35 --> Input Class Initialized
INFO - 2020-10-08 08:47:35 --> Language Class Initialized
INFO - 2020-10-08 08:47:35 --> Loader Class Initialized
INFO - 2020-10-08 08:47:35 --> Helper loaded: url_helper
INFO - 2020-10-08 08:47:35 --> Database Driver Class Initialized
INFO - 2020-10-08 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:47:35 --> Email Class Initialized
INFO - 2020-10-08 08:47:35 --> Controller Class Initialized
DEBUG - 2020-10-08 08:47:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:47:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:47:35 --> Model Class Initialized
INFO - 2020-10-08 08:47:35 --> Model Class Initialized
INFO - 2020-10-08 08:47:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 08:47:35 --> Final output sent to browser
DEBUG - 2020-10-08 08:47:35 --> Total execution time: 0.0203
ERROR - 2020-10-08 08:47:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:47:41 --> Config Class Initialized
INFO - 2020-10-08 08:47:41 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:47:41 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:47:41 --> Utf8 Class Initialized
INFO - 2020-10-08 08:47:41 --> URI Class Initialized
INFO - 2020-10-08 08:47:41 --> Router Class Initialized
INFO - 2020-10-08 08:47:41 --> Output Class Initialized
INFO - 2020-10-08 08:47:41 --> Security Class Initialized
DEBUG - 2020-10-08 08:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:47:41 --> Input Class Initialized
INFO - 2020-10-08 08:47:41 --> Language Class Initialized
INFO - 2020-10-08 08:47:41 --> Loader Class Initialized
INFO - 2020-10-08 08:47:41 --> Helper loaded: url_helper
INFO - 2020-10-08 08:47:41 --> Database Driver Class Initialized
INFO - 2020-10-08 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:47:41 --> Email Class Initialized
INFO - 2020-10-08 08:47:41 --> Controller Class Initialized
DEBUG - 2020-10-08 08:47:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:47:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:47:41 --> Model Class Initialized
INFO - 2020-10-08 08:47:41 --> Model Class Initialized
INFO - 2020-10-08 08:47:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 08:47:41 --> Final output sent to browser
DEBUG - 2020-10-08 08:47:41 --> Total execution time: 0.0527
ERROR - 2020-10-08 08:50:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:50:07 --> Config Class Initialized
INFO - 2020-10-08 08:50:07 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:50:07 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:50:07 --> Utf8 Class Initialized
INFO - 2020-10-08 08:50:07 --> URI Class Initialized
INFO - 2020-10-08 08:50:07 --> Router Class Initialized
INFO - 2020-10-08 08:50:07 --> Output Class Initialized
INFO - 2020-10-08 08:50:07 --> Security Class Initialized
DEBUG - 2020-10-08 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:50:07 --> Input Class Initialized
INFO - 2020-10-08 08:50:07 --> Language Class Initialized
INFO - 2020-10-08 08:50:07 --> Loader Class Initialized
INFO - 2020-10-08 08:50:07 --> Helper loaded: url_helper
INFO - 2020-10-08 08:50:07 --> Database Driver Class Initialized
INFO - 2020-10-08 08:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:50:07 --> Email Class Initialized
INFO - 2020-10-08 08:50:07 --> Controller Class Initialized
DEBUG - 2020-10-08 08:50:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:50:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:50:07 --> Model Class Initialized
INFO - 2020-10-08 08:50:07 --> Model Class Initialized
INFO - 2020-10-08 08:50:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 08:50:07 --> Final output sent to browser
DEBUG - 2020-10-08 08:50:07 --> Total execution time: 0.0202
ERROR - 2020-10-08 08:50:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:50:25 --> Config Class Initialized
INFO - 2020-10-08 08:50:25 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:50:25 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:50:25 --> Utf8 Class Initialized
INFO - 2020-10-08 08:50:25 --> URI Class Initialized
INFO - 2020-10-08 08:50:25 --> Router Class Initialized
INFO - 2020-10-08 08:50:25 --> Output Class Initialized
INFO - 2020-10-08 08:50:25 --> Security Class Initialized
DEBUG - 2020-10-08 08:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:50:25 --> Input Class Initialized
INFO - 2020-10-08 08:50:25 --> Language Class Initialized
INFO - 2020-10-08 08:50:25 --> Loader Class Initialized
INFO - 2020-10-08 08:50:25 --> Helper loaded: url_helper
INFO - 2020-10-08 08:50:25 --> Database Driver Class Initialized
INFO - 2020-10-08 08:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:50:25 --> Email Class Initialized
INFO - 2020-10-08 08:50:25 --> Controller Class Initialized
DEBUG - 2020-10-08 08:50:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:50:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:50:25 --> Model Class Initialized
INFO - 2020-10-08 08:50:25 --> Model Class Initialized
INFO - 2020-10-08 08:50:25 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 08:50:25 --> Final output sent to browser
DEBUG - 2020-10-08 08:50:25 --> Total execution time: 0.0197
ERROR - 2020-10-08 08:50:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:50:27 --> Config Class Initialized
INFO - 2020-10-08 08:50:27 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:50:27 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:50:27 --> Utf8 Class Initialized
INFO - 2020-10-08 08:50:27 --> URI Class Initialized
INFO - 2020-10-08 08:50:27 --> Router Class Initialized
INFO - 2020-10-08 08:50:27 --> Output Class Initialized
INFO - 2020-10-08 08:50:27 --> Security Class Initialized
DEBUG - 2020-10-08 08:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:50:27 --> Input Class Initialized
INFO - 2020-10-08 08:50:27 --> Language Class Initialized
INFO - 2020-10-08 08:50:27 --> Loader Class Initialized
INFO - 2020-10-08 08:50:27 --> Helper loaded: url_helper
INFO - 2020-10-08 08:50:27 --> Database Driver Class Initialized
INFO - 2020-10-08 08:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:50:27 --> Email Class Initialized
INFO - 2020-10-08 08:50:27 --> Controller Class Initialized
DEBUG - 2020-10-08 08:50:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:50:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:50:27 --> Model Class Initialized
INFO - 2020-10-08 08:50:27 --> Model Class Initialized
INFO - 2020-10-08 08:50:27 --> Model Class Initialized
INFO - 2020-10-08 08:50:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-08 08:50:27 --> Final output sent to browser
DEBUG - 2020-10-08 08:50:27 --> Total execution time: 0.0447
ERROR - 2020-10-08 08:50:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:50:55 --> Config Class Initialized
INFO - 2020-10-08 08:50:55 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:50:55 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:50:55 --> Utf8 Class Initialized
INFO - 2020-10-08 08:50:55 --> URI Class Initialized
INFO - 2020-10-08 08:50:55 --> Router Class Initialized
INFO - 2020-10-08 08:50:55 --> Output Class Initialized
INFO - 2020-10-08 08:50:55 --> Security Class Initialized
DEBUG - 2020-10-08 08:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:50:55 --> Input Class Initialized
INFO - 2020-10-08 08:50:55 --> Language Class Initialized
INFO - 2020-10-08 08:50:55 --> Loader Class Initialized
INFO - 2020-10-08 08:50:55 --> Helper loaded: url_helper
INFO - 2020-10-08 08:50:55 --> Database Driver Class Initialized
INFO - 2020-10-08 08:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:50:55 --> Email Class Initialized
INFO - 2020-10-08 08:50:55 --> Controller Class Initialized
DEBUG - 2020-10-08 08:50:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:50:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:50:55 --> Model Class Initialized
INFO - 2020-10-08 08:50:55 --> Model Class Initialized
INFO - 2020-10-08 08:50:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 08:50:55 --> Final output sent to browser
DEBUG - 2020-10-08 08:50:55 --> Total execution time: 0.0210
ERROR - 2020-10-08 08:51:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:51:14 --> Config Class Initialized
INFO - 2020-10-08 08:51:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:51:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:51:14 --> Utf8 Class Initialized
INFO - 2020-10-08 08:51:14 --> URI Class Initialized
INFO - 2020-10-08 08:51:14 --> Router Class Initialized
INFO - 2020-10-08 08:51:14 --> Output Class Initialized
INFO - 2020-10-08 08:51:14 --> Security Class Initialized
DEBUG - 2020-10-08 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:51:14 --> Input Class Initialized
INFO - 2020-10-08 08:51:14 --> Language Class Initialized
INFO - 2020-10-08 08:51:14 --> Loader Class Initialized
INFO - 2020-10-08 08:51:14 --> Helper loaded: url_helper
INFO - 2020-10-08 08:51:14 --> Database Driver Class Initialized
INFO - 2020-10-08 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:51:14 --> Email Class Initialized
INFO - 2020-10-08 08:51:14 --> Controller Class Initialized
DEBUG - 2020-10-08 08:51:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:51:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:51:14 --> Model Class Initialized
INFO - 2020-10-08 08:51:14 --> Model Class Initialized
INFO - 2020-10-08 08:51:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 08:51:14 --> Final output sent to browser
DEBUG - 2020-10-08 08:51:14 --> Total execution time: 0.0271
ERROR - 2020-10-08 08:51:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:51:20 --> Config Class Initialized
INFO - 2020-10-08 08:51:20 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:51:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:51:20 --> Utf8 Class Initialized
INFO - 2020-10-08 08:51:20 --> URI Class Initialized
INFO - 2020-10-08 08:51:20 --> Router Class Initialized
INFO - 2020-10-08 08:51:20 --> Output Class Initialized
INFO - 2020-10-08 08:51:20 --> Security Class Initialized
DEBUG - 2020-10-08 08:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:51:20 --> Input Class Initialized
INFO - 2020-10-08 08:51:20 --> Language Class Initialized
INFO - 2020-10-08 08:51:20 --> Loader Class Initialized
INFO - 2020-10-08 08:51:20 --> Helper loaded: url_helper
INFO - 2020-10-08 08:51:20 --> Database Driver Class Initialized
INFO - 2020-10-08 08:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:51:20 --> Email Class Initialized
INFO - 2020-10-08 08:51:20 --> Controller Class Initialized
DEBUG - 2020-10-08 08:51:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:51:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:51:20 --> Model Class Initialized
INFO - 2020-10-08 08:51:20 --> Model Class Initialized
INFO - 2020-10-08 08:51:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 08:51:20 --> Final output sent to browser
DEBUG - 2020-10-08 08:51:20 --> Total execution time: 0.0210
ERROR - 2020-10-08 08:51:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:51:24 --> Config Class Initialized
INFO - 2020-10-08 08:51:24 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:51:24 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:51:24 --> Utf8 Class Initialized
INFO - 2020-10-08 08:51:24 --> URI Class Initialized
INFO - 2020-10-08 08:51:24 --> Router Class Initialized
INFO - 2020-10-08 08:51:24 --> Output Class Initialized
INFO - 2020-10-08 08:51:24 --> Security Class Initialized
DEBUG - 2020-10-08 08:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:51:24 --> Input Class Initialized
INFO - 2020-10-08 08:51:24 --> Language Class Initialized
INFO - 2020-10-08 08:51:24 --> Loader Class Initialized
INFO - 2020-10-08 08:51:24 --> Helper loaded: url_helper
INFO - 2020-10-08 08:51:24 --> Database Driver Class Initialized
INFO - 2020-10-08 08:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:51:24 --> Email Class Initialized
INFO - 2020-10-08 08:51:24 --> Controller Class Initialized
DEBUG - 2020-10-08 08:51:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:51:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:51:24 --> Model Class Initialized
INFO - 2020-10-08 08:51:24 --> Model Class Initialized
INFO - 2020-10-08 08:51:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 08:51:24 --> Final output sent to browser
DEBUG - 2020-10-08 08:51:24 --> Total execution time: 0.0279
ERROR - 2020-10-08 08:51:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:51:41 --> Config Class Initialized
INFO - 2020-10-08 08:51:41 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:51:41 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:51:41 --> Utf8 Class Initialized
INFO - 2020-10-08 08:51:41 --> URI Class Initialized
INFO - 2020-10-08 08:51:41 --> Router Class Initialized
INFO - 2020-10-08 08:51:41 --> Output Class Initialized
INFO - 2020-10-08 08:51:41 --> Security Class Initialized
DEBUG - 2020-10-08 08:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:51:41 --> Input Class Initialized
INFO - 2020-10-08 08:51:41 --> Language Class Initialized
INFO - 2020-10-08 08:51:41 --> Loader Class Initialized
INFO - 2020-10-08 08:51:41 --> Helper loaded: url_helper
INFO - 2020-10-08 08:51:41 --> Database Driver Class Initialized
INFO - 2020-10-08 08:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:51:41 --> Email Class Initialized
INFO - 2020-10-08 08:51:41 --> Controller Class Initialized
DEBUG - 2020-10-08 08:51:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 08:51:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:51:41 --> Model Class Initialized
INFO - 2020-10-08 08:51:41 --> Model Class Initialized
INFO - 2020-10-08 08:51:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 08:51:41 --> Final output sent to browser
DEBUG - 2020-10-08 08:51:41 --> Total execution time: 0.0198
ERROR - 2020-10-08 08:51:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 08:51:54 --> Config Class Initialized
INFO - 2020-10-08 08:51:54 --> Hooks Class Initialized
DEBUG - 2020-10-08 08:51:54 --> UTF-8 Support Enabled
INFO - 2020-10-08 08:51:54 --> Utf8 Class Initialized
INFO - 2020-10-08 08:51:54 --> URI Class Initialized
DEBUG - 2020-10-08 08:51:54 --> No URI present. Default controller set.
INFO - 2020-10-08 08:51:54 --> Router Class Initialized
INFO - 2020-10-08 08:51:54 --> Output Class Initialized
INFO - 2020-10-08 08:51:54 --> Security Class Initialized
DEBUG - 2020-10-08 08:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 08:51:54 --> Input Class Initialized
INFO - 2020-10-08 08:51:54 --> Language Class Initialized
INFO - 2020-10-08 08:51:54 --> Loader Class Initialized
INFO - 2020-10-08 08:51:54 --> Helper loaded: url_helper
INFO - 2020-10-08 08:51:54 --> Database Driver Class Initialized
INFO - 2020-10-08 08:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 08:51:54 --> Email Class Initialized
INFO - 2020-10-08 08:51:54 --> Controller Class Initialized
INFO - 2020-10-08 08:51:54 --> Model Class Initialized
INFO - 2020-10-08 08:51:54 --> Model Class Initialized
DEBUG - 2020-10-08 08:51:54 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 08:51:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 08:51:54 --> Final output sent to browser
DEBUG - 2020-10-08 08:51:54 --> Total execution time: 0.0190
ERROR - 2020-10-08 09:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:07:51 --> Config Class Initialized
INFO - 2020-10-08 09:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:07:51 --> Utf8 Class Initialized
INFO - 2020-10-08 09:07:51 --> URI Class Initialized
INFO - 2020-10-08 09:07:51 --> Router Class Initialized
INFO - 2020-10-08 09:07:51 --> Output Class Initialized
INFO - 2020-10-08 09:07:51 --> Security Class Initialized
DEBUG - 2020-10-08 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:07:51 --> Input Class Initialized
ERROR - 2020-10-08 09:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:07:51 --> Language Class Initialized
INFO - 2020-10-08 09:07:51 --> Config Class Initialized
INFO - 2020-10-08 09:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:07:51 --> Utf8 Class Initialized
INFO - 2020-10-08 09:07:51 --> URI Class Initialized
INFO - 2020-10-08 09:07:51 --> Router Class Initialized
INFO - 2020-10-08 09:07:51 --> Output Class Initialized
INFO - 2020-10-08 09:07:51 --> Security Class Initialized
DEBUG - 2020-10-08 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:07:51 --> Input Class Initialized
INFO - 2020-10-08 09:07:51 --> Language Class Initialized
INFO - 2020-10-08 09:07:51 --> Loader Class Initialized
INFO - 2020-10-08 09:07:51 --> Helper loaded: url_helper
INFO - 2020-10-08 09:07:51 --> Loader Class Initialized
INFO - 2020-10-08 09:07:51 --> Helper loaded: url_helper
INFO - 2020-10-08 09:07:51 --> Database Driver Class Initialized
INFO - 2020-10-08 09:07:51 --> Database Driver Class Initialized
INFO - 2020-10-08 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:07:51 --> Email Class Initialized
INFO - 2020-10-08 09:07:51 --> Controller Class Initialized
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
DEBUG - 2020-10-08 09:07:51 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:07:51 --> Email Class Initialized
INFO - 2020-10-08 09:07:51 --> Controller Class Initialized
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
DEBUG - 2020-10-08 09:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:07:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
INFO - 2020-10-08 09:07:51 --> Final output sent to browser
DEBUG - 2020-10-08 09:07:51 --> Total execution time: 0.0387
ERROR - 2020-10-08 09:07:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:07:51 --> Config Class Initialized
INFO - 2020-10-08 09:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:07:51 --> Utf8 Class Initialized
INFO - 2020-10-08 09:07:51 --> URI Class Initialized
INFO - 2020-10-08 09:07:51 --> Router Class Initialized
INFO - 2020-10-08 09:07:51 --> Output Class Initialized
INFO - 2020-10-08 09:07:51 --> Security Class Initialized
DEBUG - 2020-10-08 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:07:51 --> Input Class Initialized
INFO - 2020-10-08 09:07:51 --> Language Class Initialized
INFO - 2020-10-08 09:07:51 --> Loader Class Initialized
INFO - 2020-10-08 09:07:51 --> Helper loaded: url_helper
INFO - 2020-10-08 09:07:51 --> Database Driver Class Initialized
INFO - 2020-10-08 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:07:51 --> Email Class Initialized
INFO - 2020-10-08 09:07:51 --> Controller Class Initialized
DEBUG - 2020-10-08 09:07:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:07:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
INFO - 2020-10-08 09:07:51 --> Model Class Initialized
INFO - 2020-10-08 09:07:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 09:07:51 --> Final output sent to browser
DEBUG - 2020-10-08 09:07:51 --> Total execution time: 0.0371
ERROR - 2020-10-08 09:08:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:08:09 --> Config Class Initialized
INFO - 2020-10-08 09:08:09 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:08:09 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:08:09 --> Utf8 Class Initialized
INFO - 2020-10-08 09:08:09 --> URI Class Initialized
DEBUG - 2020-10-08 09:08:09 --> No URI present. Default controller set.
INFO - 2020-10-08 09:08:09 --> Router Class Initialized
INFO - 2020-10-08 09:08:09 --> Output Class Initialized
INFO - 2020-10-08 09:08:09 --> Security Class Initialized
DEBUG - 2020-10-08 09:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:08:09 --> Input Class Initialized
INFO - 2020-10-08 09:08:09 --> Language Class Initialized
INFO - 2020-10-08 09:08:09 --> Loader Class Initialized
INFO - 2020-10-08 09:08:09 --> Helper loaded: url_helper
INFO - 2020-10-08 09:08:09 --> Database Driver Class Initialized
INFO - 2020-10-08 09:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:08:09 --> Email Class Initialized
INFO - 2020-10-08 09:08:09 --> Controller Class Initialized
INFO - 2020-10-08 09:08:09 --> Model Class Initialized
INFO - 2020-10-08 09:08:09 --> Model Class Initialized
DEBUG - 2020-10-08 09:08:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:08:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:08:09 --> Final output sent to browser
DEBUG - 2020-10-08 09:08:09 --> Total execution time: 0.0198
ERROR - 2020-10-08 09:08:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:08:25 --> Config Class Initialized
INFO - 2020-10-08 09:08:25 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:08:25 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:08:25 --> Utf8 Class Initialized
INFO - 2020-10-08 09:08:25 --> URI Class Initialized
INFO - 2020-10-08 09:08:25 --> Router Class Initialized
INFO - 2020-10-08 09:08:25 --> Output Class Initialized
INFO - 2020-10-08 09:08:25 --> Security Class Initialized
DEBUG - 2020-10-08 09:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:08:25 --> Input Class Initialized
INFO - 2020-10-08 09:08:25 --> Language Class Initialized
INFO - 2020-10-08 09:08:25 --> Loader Class Initialized
INFO - 2020-10-08 09:08:25 --> Helper loaded: url_helper
INFO - 2020-10-08 09:08:25 --> Database Driver Class Initialized
INFO - 2020-10-08 09:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:08:25 --> Email Class Initialized
INFO - 2020-10-08 09:08:25 --> Controller Class Initialized
INFO - 2020-10-08 09:08:25 --> Model Class Initialized
INFO - 2020-10-08 09:08:25 --> Model Class Initialized
DEBUG - 2020-10-08 09:08:25 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:08:25 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:08:25 --> Model Class Initialized
INFO - 2020-10-08 09:08:25 --> Final output sent to browser
DEBUG - 2020-10-08 09:08:25 --> Total execution time: 0.0227
ERROR - 2020-10-08 09:08:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:08:25 --> Config Class Initialized
INFO - 2020-10-08 09:08:25 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:08:25 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:08:25 --> Utf8 Class Initialized
INFO - 2020-10-08 09:08:25 --> URI Class Initialized
INFO - 2020-10-08 09:08:25 --> Router Class Initialized
INFO - 2020-10-08 09:08:25 --> Output Class Initialized
INFO - 2020-10-08 09:08:25 --> Security Class Initialized
DEBUG - 2020-10-08 09:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:08:25 --> Input Class Initialized
INFO - 2020-10-08 09:08:25 --> Language Class Initialized
INFO - 2020-10-08 09:08:25 --> Loader Class Initialized
INFO - 2020-10-08 09:08:25 --> Helper loaded: url_helper
INFO - 2020-10-08 09:08:25 --> Database Driver Class Initialized
INFO - 2020-10-08 09:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:08:25 --> Email Class Initialized
INFO - 2020-10-08 09:08:25 --> Controller Class Initialized
INFO - 2020-10-08 09:08:25 --> Model Class Initialized
INFO - 2020-10-08 09:08:25 --> Model Class Initialized
DEBUG - 2020-10-08 09:08:25 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 09:08:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:08:26 --> Config Class Initialized
INFO - 2020-10-08 09:08:26 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:08:26 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:08:26 --> Utf8 Class Initialized
INFO - 2020-10-08 09:08:26 --> URI Class Initialized
INFO - 2020-10-08 09:08:26 --> Router Class Initialized
INFO - 2020-10-08 09:08:26 --> Output Class Initialized
INFO - 2020-10-08 09:08:26 --> Security Class Initialized
DEBUG - 2020-10-08 09:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:08:26 --> Input Class Initialized
INFO - 2020-10-08 09:08:26 --> Language Class Initialized
INFO - 2020-10-08 09:08:26 --> Loader Class Initialized
INFO - 2020-10-08 09:08:26 --> Helper loaded: url_helper
INFO - 2020-10-08 09:08:26 --> Database Driver Class Initialized
INFO - 2020-10-08 09:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:08:26 --> Email Class Initialized
INFO - 2020-10-08 09:08:26 --> Controller Class Initialized
DEBUG - 2020-10-08 09:08:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:08:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:08:26 --> Model Class Initialized
INFO - 2020-10-08 09:08:26 --> Model Class Initialized
INFO - 2020-10-08 09:08:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 09:08:26 --> Final output sent to browser
DEBUG - 2020-10-08 09:08:26 --> Total execution time: 0.0263
ERROR - 2020-10-08 09:08:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:08:32 --> Config Class Initialized
INFO - 2020-10-08 09:08:32 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:08:32 --> Utf8 Class Initialized
INFO - 2020-10-08 09:08:32 --> URI Class Initialized
INFO - 2020-10-08 09:08:32 --> Router Class Initialized
INFO - 2020-10-08 09:08:32 --> Output Class Initialized
INFO - 2020-10-08 09:08:32 --> Security Class Initialized
DEBUG - 2020-10-08 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:08:32 --> Input Class Initialized
INFO - 2020-10-08 09:08:32 --> Language Class Initialized
INFO - 2020-10-08 09:08:32 --> Loader Class Initialized
INFO - 2020-10-08 09:08:32 --> Helper loaded: url_helper
INFO - 2020-10-08 09:08:32 --> Database Driver Class Initialized
INFO - 2020-10-08 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:08:32 --> Email Class Initialized
INFO - 2020-10-08 09:08:32 --> Controller Class Initialized
DEBUG - 2020-10-08 09:08:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:08:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:08:32 --> Model Class Initialized
INFO - 2020-10-08 09:08:32 --> Model Class Initialized
INFO - 2020-10-08 09:08:32 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:08:32 --> Final output sent to browser
DEBUG - 2020-10-08 09:08:32 --> Total execution time: 0.0233
ERROR - 2020-10-08 09:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:13:08 --> Config Class Initialized
INFO - 2020-10-08 09:13:08 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:13:08 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:13:08 --> Utf8 Class Initialized
INFO - 2020-10-08 09:13:08 --> URI Class Initialized
DEBUG - 2020-10-08 09:13:08 --> No URI present. Default controller set.
INFO - 2020-10-08 09:13:08 --> Router Class Initialized
INFO - 2020-10-08 09:13:08 --> Output Class Initialized
INFO - 2020-10-08 09:13:08 --> Security Class Initialized
DEBUG - 2020-10-08 09:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:13:08 --> Input Class Initialized
INFO - 2020-10-08 09:13:08 --> Language Class Initialized
INFO - 2020-10-08 09:13:08 --> Loader Class Initialized
INFO - 2020-10-08 09:13:08 --> Helper loaded: url_helper
INFO - 2020-10-08 09:13:08 --> Database Driver Class Initialized
INFO - 2020-10-08 09:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:13:08 --> Email Class Initialized
INFO - 2020-10-08 09:13:08 --> Controller Class Initialized
INFO - 2020-10-08 09:13:08 --> Model Class Initialized
INFO - 2020-10-08 09:13:08 --> Model Class Initialized
DEBUG - 2020-10-08 09:13:08 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:13:08 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:13:08 --> Final output sent to browser
DEBUG - 2020-10-08 09:13:08 --> Total execution time: 0.0167
ERROR - 2020-10-08 09:13:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:13:33 --> Config Class Initialized
INFO - 2020-10-08 09:13:33 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:13:33 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:13:33 --> Utf8 Class Initialized
INFO - 2020-10-08 09:13:33 --> URI Class Initialized
INFO - 2020-10-08 09:13:33 --> Router Class Initialized
INFO - 2020-10-08 09:13:33 --> Output Class Initialized
INFO - 2020-10-08 09:13:33 --> Security Class Initialized
DEBUG - 2020-10-08 09:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:13:33 --> Input Class Initialized
INFO - 2020-10-08 09:13:33 --> Language Class Initialized
INFO - 2020-10-08 09:13:33 --> Loader Class Initialized
INFO - 2020-10-08 09:13:33 --> Helper loaded: url_helper
INFO - 2020-10-08 09:13:33 --> Database Driver Class Initialized
INFO - 2020-10-08 09:13:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:13:33 --> Email Class Initialized
INFO - 2020-10-08 09:13:33 --> Controller Class Initialized
DEBUG - 2020-10-08 09:13:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:13:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:13:33 --> Model Class Initialized
INFO - 2020-10-08 09:13:33 --> Model Class Initialized
INFO - 2020-10-08 09:13:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:13:33 --> Final output sent to browser
DEBUG - 2020-10-08 09:13:33 --> Total execution time: 0.0244
ERROR - 2020-10-08 09:15:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:15:43 --> Config Class Initialized
INFO - 2020-10-08 09:15:43 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:15:43 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:15:43 --> Utf8 Class Initialized
INFO - 2020-10-08 09:15:43 --> URI Class Initialized
INFO - 2020-10-08 09:15:43 --> Router Class Initialized
INFO - 2020-10-08 09:15:43 --> Output Class Initialized
INFO - 2020-10-08 09:15:43 --> Security Class Initialized
DEBUG - 2020-10-08 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:15:43 --> Input Class Initialized
INFO - 2020-10-08 09:15:43 --> Language Class Initialized
INFO - 2020-10-08 09:15:43 --> Loader Class Initialized
INFO - 2020-10-08 09:15:43 --> Helper loaded: url_helper
INFO - 2020-10-08 09:15:43 --> Database Driver Class Initialized
INFO - 2020-10-08 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:15:43 --> Email Class Initialized
INFO - 2020-10-08 09:15:43 --> Controller Class Initialized
DEBUG - 2020-10-08 09:15:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:15:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:15:43 --> Model Class Initialized
INFO - 2020-10-08 09:15:43 --> Model Class Initialized
INFO - 2020-10-08 09:15:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:15:43 --> Final output sent to browser
DEBUG - 2020-10-08 09:15:43 --> Total execution time: 0.0243
ERROR - 2020-10-08 09:16:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:16:21 --> Config Class Initialized
INFO - 2020-10-08 09:16:21 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:16:21 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:16:21 --> Utf8 Class Initialized
INFO - 2020-10-08 09:16:21 --> URI Class Initialized
INFO - 2020-10-08 09:16:21 --> Router Class Initialized
INFO - 2020-10-08 09:16:21 --> Output Class Initialized
INFO - 2020-10-08 09:16:21 --> Security Class Initialized
DEBUG - 2020-10-08 09:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:16:21 --> Input Class Initialized
INFO - 2020-10-08 09:16:21 --> Language Class Initialized
INFO - 2020-10-08 09:16:21 --> Loader Class Initialized
INFO - 2020-10-08 09:16:21 --> Helper loaded: url_helper
INFO - 2020-10-08 09:16:21 --> Database Driver Class Initialized
INFO - 2020-10-08 09:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:16:21 --> Email Class Initialized
INFO - 2020-10-08 09:16:21 --> Controller Class Initialized
DEBUG - 2020-10-08 09:16:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:16:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:16:21 --> Model Class Initialized
INFO - 2020-10-08 09:16:21 --> Model Class Initialized
INFO - 2020-10-08 09:16:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:16:21 --> Final output sent to browser
DEBUG - 2020-10-08 09:16:21 --> Total execution time: 0.0228
ERROR - 2020-10-08 09:17:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:17:19 --> Config Class Initialized
INFO - 2020-10-08 09:17:19 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:17:19 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:17:19 --> Utf8 Class Initialized
INFO - 2020-10-08 09:17:19 --> URI Class Initialized
INFO - 2020-10-08 09:17:19 --> Router Class Initialized
INFO - 2020-10-08 09:17:19 --> Output Class Initialized
INFO - 2020-10-08 09:17:19 --> Security Class Initialized
DEBUG - 2020-10-08 09:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:17:19 --> Input Class Initialized
INFO - 2020-10-08 09:17:19 --> Language Class Initialized
INFO - 2020-10-08 09:17:19 --> Loader Class Initialized
INFO - 2020-10-08 09:17:19 --> Helper loaded: url_helper
INFO - 2020-10-08 09:17:19 --> Database Driver Class Initialized
INFO - 2020-10-08 09:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:17:19 --> Email Class Initialized
INFO - 2020-10-08 09:17:19 --> Controller Class Initialized
DEBUG - 2020-10-08 09:17:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:17:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:17:19 --> Model Class Initialized
INFO - 2020-10-08 09:17:19 --> Model Class Initialized
INFO - 2020-10-08 09:17:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:17:19 --> Final output sent to browser
DEBUG - 2020-10-08 09:17:19 --> Total execution time: 0.0213
ERROR - 2020-10-08 09:18:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:18:03 --> Config Class Initialized
INFO - 2020-10-08 09:18:03 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:18:03 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:18:03 --> Utf8 Class Initialized
INFO - 2020-10-08 09:18:03 --> URI Class Initialized
INFO - 2020-10-08 09:18:03 --> Router Class Initialized
INFO - 2020-10-08 09:18:03 --> Output Class Initialized
INFO - 2020-10-08 09:18:03 --> Security Class Initialized
DEBUG - 2020-10-08 09:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:18:03 --> Input Class Initialized
INFO - 2020-10-08 09:18:03 --> Language Class Initialized
INFO - 2020-10-08 09:18:03 --> Loader Class Initialized
INFO - 2020-10-08 09:18:03 --> Helper loaded: url_helper
INFO - 2020-10-08 09:18:03 --> Database Driver Class Initialized
INFO - 2020-10-08 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:18:03 --> Email Class Initialized
INFO - 2020-10-08 09:18:03 --> Controller Class Initialized
DEBUG - 2020-10-08 09:18:03 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:18:03 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:18:03 --> Model Class Initialized
INFO - 2020-10-08 09:18:03 --> Model Class Initialized
INFO - 2020-10-08 09:18:03 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:18:03 --> Final output sent to browser
DEBUG - 2020-10-08 09:18:03 --> Total execution time: 0.0225
ERROR - 2020-10-08 09:18:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:18:44 --> Config Class Initialized
INFO - 2020-10-08 09:18:44 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:18:44 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:18:44 --> Utf8 Class Initialized
INFO - 2020-10-08 09:18:44 --> URI Class Initialized
INFO - 2020-10-08 09:18:44 --> Router Class Initialized
INFO - 2020-10-08 09:18:44 --> Output Class Initialized
INFO - 2020-10-08 09:18:44 --> Security Class Initialized
DEBUG - 2020-10-08 09:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:18:44 --> Input Class Initialized
INFO - 2020-10-08 09:18:44 --> Language Class Initialized
INFO - 2020-10-08 09:18:44 --> Loader Class Initialized
INFO - 2020-10-08 09:18:44 --> Helper loaded: url_helper
INFO - 2020-10-08 09:18:44 --> Database Driver Class Initialized
INFO - 2020-10-08 09:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:18:44 --> Email Class Initialized
INFO - 2020-10-08 09:18:44 --> Controller Class Initialized
DEBUG - 2020-10-08 09:18:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:18:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:18:44 --> Model Class Initialized
INFO - 2020-10-08 09:18:44 --> Model Class Initialized
INFO - 2020-10-08 09:18:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:18:44 --> Final output sent to browser
DEBUG - 2020-10-08 09:18:44 --> Total execution time: 0.0251
ERROR - 2020-10-08 09:19:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:19:31 --> Config Class Initialized
INFO - 2020-10-08 09:19:31 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:19:31 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:19:31 --> Utf8 Class Initialized
INFO - 2020-10-08 09:19:31 --> URI Class Initialized
INFO - 2020-10-08 09:19:31 --> Router Class Initialized
INFO - 2020-10-08 09:19:31 --> Output Class Initialized
INFO - 2020-10-08 09:19:31 --> Security Class Initialized
DEBUG - 2020-10-08 09:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:19:31 --> Input Class Initialized
INFO - 2020-10-08 09:19:31 --> Language Class Initialized
INFO - 2020-10-08 09:19:31 --> Loader Class Initialized
INFO - 2020-10-08 09:19:31 --> Helper loaded: url_helper
INFO - 2020-10-08 09:19:31 --> Database Driver Class Initialized
INFO - 2020-10-08 09:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:19:31 --> Email Class Initialized
INFO - 2020-10-08 09:19:31 --> Controller Class Initialized
DEBUG - 2020-10-08 09:19:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:19:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:19:31 --> Model Class Initialized
INFO - 2020-10-08 09:19:31 --> Model Class Initialized
INFO - 2020-10-08 09:19:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:19:31 --> Final output sent to browser
DEBUG - 2020-10-08 09:19:31 --> Total execution time: 0.0229
ERROR - 2020-10-08 09:21:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:21:05 --> Config Class Initialized
INFO - 2020-10-08 09:21:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:21:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:21:05 --> Utf8 Class Initialized
INFO - 2020-10-08 09:21:05 --> URI Class Initialized
INFO - 2020-10-08 09:21:05 --> Router Class Initialized
INFO - 2020-10-08 09:21:05 --> Output Class Initialized
INFO - 2020-10-08 09:21:05 --> Security Class Initialized
DEBUG - 2020-10-08 09:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:21:05 --> Input Class Initialized
INFO - 2020-10-08 09:21:05 --> Language Class Initialized
INFO - 2020-10-08 09:21:05 --> Loader Class Initialized
INFO - 2020-10-08 09:21:05 --> Helper loaded: url_helper
INFO - 2020-10-08 09:21:06 --> Database Driver Class Initialized
INFO - 2020-10-08 09:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:21:06 --> Email Class Initialized
INFO - 2020-10-08 09:21:06 --> Controller Class Initialized
DEBUG - 2020-10-08 09:21:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:21:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:21:06 --> Model Class Initialized
INFO - 2020-10-08 09:21:06 --> Model Class Initialized
INFO - 2020-10-08 09:21:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:21:06 --> Final output sent to browser
DEBUG - 2020-10-08 09:21:06 --> Total execution time: 0.0250
ERROR - 2020-10-08 09:21:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:21:35 --> Config Class Initialized
INFO - 2020-10-08 09:21:35 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:21:35 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:21:35 --> Utf8 Class Initialized
INFO - 2020-10-08 09:21:35 --> URI Class Initialized
INFO - 2020-10-08 09:21:35 --> Router Class Initialized
INFO - 2020-10-08 09:21:35 --> Output Class Initialized
INFO - 2020-10-08 09:21:35 --> Security Class Initialized
DEBUG - 2020-10-08 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:21:35 --> Input Class Initialized
INFO - 2020-10-08 09:21:35 --> Language Class Initialized
INFO - 2020-10-08 09:21:35 --> Loader Class Initialized
INFO - 2020-10-08 09:21:35 --> Helper loaded: url_helper
INFO - 2020-10-08 09:21:35 --> Database Driver Class Initialized
INFO - 2020-10-08 09:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:21:35 --> Email Class Initialized
INFO - 2020-10-08 09:21:35 --> Controller Class Initialized
DEBUG - 2020-10-08 09:21:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:21:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:21:35 --> Model Class Initialized
INFO - 2020-10-08 09:21:35 --> Model Class Initialized
INFO - 2020-10-08 09:21:35 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:21:35 --> Final output sent to browser
DEBUG - 2020-10-08 09:21:35 --> Total execution time: 0.0221
ERROR - 2020-10-08 09:22:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:22:31 --> Config Class Initialized
INFO - 2020-10-08 09:22:31 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:22:31 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:22:31 --> Utf8 Class Initialized
INFO - 2020-10-08 09:22:31 --> URI Class Initialized
INFO - 2020-10-08 09:22:31 --> Router Class Initialized
INFO - 2020-10-08 09:22:31 --> Output Class Initialized
INFO - 2020-10-08 09:22:31 --> Security Class Initialized
DEBUG - 2020-10-08 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:22:31 --> Input Class Initialized
INFO - 2020-10-08 09:22:31 --> Language Class Initialized
INFO - 2020-10-08 09:22:31 --> Loader Class Initialized
INFO - 2020-10-08 09:22:31 --> Helper loaded: url_helper
INFO - 2020-10-08 09:22:31 --> Database Driver Class Initialized
INFO - 2020-10-08 09:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:22:31 --> Email Class Initialized
INFO - 2020-10-08 09:22:31 --> Controller Class Initialized
DEBUG - 2020-10-08 09:22:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:22:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:22:31 --> Model Class Initialized
INFO - 2020-10-08 09:22:31 --> Model Class Initialized
INFO - 2020-10-08 09:22:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:22:31 --> Final output sent to browser
DEBUG - 2020-10-08 09:22:31 --> Total execution time: 0.0250
ERROR - 2020-10-08 09:23:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:23:12 --> Config Class Initialized
INFO - 2020-10-08 09:23:12 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:23:12 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:23:12 --> Utf8 Class Initialized
INFO - 2020-10-08 09:23:12 --> URI Class Initialized
INFO - 2020-10-08 09:23:12 --> Router Class Initialized
INFO - 2020-10-08 09:23:12 --> Output Class Initialized
INFO - 2020-10-08 09:23:12 --> Security Class Initialized
DEBUG - 2020-10-08 09:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:23:12 --> Input Class Initialized
INFO - 2020-10-08 09:23:12 --> Language Class Initialized
INFO - 2020-10-08 09:23:12 --> Loader Class Initialized
INFO - 2020-10-08 09:23:12 --> Helper loaded: url_helper
INFO - 2020-10-08 09:23:12 --> Database Driver Class Initialized
INFO - 2020-10-08 09:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:23:12 --> Email Class Initialized
INFO - 2020-10-08 09:23:12 --> Controller Class Initialized
DEBUG - 2020-10-08 09:23:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:23:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:23:12 --> Model Class Initialized
INFO - 2020-10-08 09:23:12 --> Model Class Initialized
INFO - 2020-10-08 09:23:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:23:12 --> Final output sent to browser
DEBUG - 2020-10-08 09:23:12 --> Total execution time: 0.0239
ERROR - 2020-10-08 09:23:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:23:55 --> Config Class Initialized
INFO - 2020-10-08 09:23:55 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:23:55 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:23:55 --> Utf8 Class Initialized
INFO - 2020-10-08 09:23:55 --> URI Class Initialized
INFO - 2020-10-08 09:23:55 --> Router Class Initialized
INFO - 2020-10-08 09:23:55 --> Output Class Initialized
INFO - 2020-10-08 09:23:55 --> Security Class Initialized
DEBUG - 2020-10-08 09:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:23:55 --> Input Class Initialized
INFO - 2020-10-08 09:23:55 --> Language Class Initialized
INFO - 2020-10-08 09:23:55 --> Loader Class Initialized
INFO - 2020-10-08 09:23:55 --> Helper loaded: url_helper
INFO - 2020-10-08 09:23:55 --> Database Driver Class Initialized
INFO - 2020-10-08 09:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:23:55 --> Email Class Initialized
INFO - 2020-10-08 09:23:55 --> Controller Class Initialized
DEBUG - 2020-10-08 09:23:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:23:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:23:55 --> Model Class Initialized
INFO - 2020-10-08 09:23:55 --> Model Class Initialized
INFO - 2020-10-08 09:23:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:23:55 --> Final output sent to browser
DEBUG - 2020-10-08 09:23:55 --> Total execution time: 0.0218
ERROR - 2020-10-08 09:24:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:06 --> Config Class Initialized
INFO - 2020-10-08 09:24:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:06 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:06 --> URI Class Initialized
INFO - 2020-10-08 09:24:06 --> Router Class Initialized
INFO - 2020-10-08 09:24:06 --> Output Class Initialized
INFO - 2020-10-08 09:24:06 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:06 --> Input Class Initialized
INFO - 2020-10-08 09:24:06 --> Language Class Initialized
INFO - 2020-10-08 09:24:06 --> Loader Class Initialized
INFO - 2020-10-08 09:24:06 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:06 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:06 --> Email Class Initialized
INFO - 2020-10-08 09:24:06 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:06 --> Model Class Initialized
INFO - 2020-10-08 09:24:06 --> Model Class Initialized
INFO - 2020-10-08 09:24:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-08 09:24:06 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:06 --> Total execution time: 0.0359
ERROR - 2020-10-08 09:24:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:20 --> Config Class Initialized
INFO - 2020-10-08 09:24:20 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:20 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:20 --> URI Class Initialized
INFO - 2020-10-08 09:24:20 --> Router Class Initialized
INFO - 2020-10-08 09:24:20 --> Output Class Initialized
INFO - 2020-10-08 09:24:20 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:20 --> Input Class Initialized
INFO - 2020-10-08 09:24:20 --> Language Class Initialized
INFO - 2020-10-08 09:24:20 --> Loader Class Initialized
INFO - 2020-10-08 09:24:20 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:20 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:20 --> Email Class Initialized
INFO - 2020-10-08 09:24:20 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:20 --> Model Class Initialized
INFO - 2020-10-08 09:24:20 --> Model Class Initialized
INFO - 2020-10-08 09:24:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:24:20 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:20 --> Total execution time: 0.0226
ERROR - 2020-10-08 09:24:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:24 --> Config Class Initialized
INFO - 2020-10-08 09:24:24 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:24 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:24 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:24 --> URI Class Initialized
INFO - 2020-10-08 09:24:24 --> Router Class Initialized
INFO - 2020-10-08 09:24:24 --> Output Class Initialized
INFO - 2020-10-08 09:24:24 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:24 --> Input Class Initialized
INFO - 2020-10-08 09:24:24 --> Language Class Initialized
INFO - 2020-10-08 09:24:24 --> Loader Class Initialized
INFO - 2020-10-08 09:24:24 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:24 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:24 --> Email Class Initialized
INFO - 2020-10-08 09:24:24 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:24 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:24 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:24 --> Model Class Initialized
INFO - 2020-10-08 09:24:24 --> Model Class Initialized
INFO - 2020-10-08 09:24:24 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-08 09:24:24 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:24 --> Total execution time: 0.0210
ERROR - 2020-10-08 09:24:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:29 --> Config Class Initialized
INFO - 2020-10-08 09:24:29 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:29 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:29 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:29 --> URI Class Initialized
INFO - 2020-10-08 09:24:29 --> Router Class Initialized
INFO - 2020-10-08 09:24:29 --> Output Class Initialized
INFO - 2020-10-08 09:24:29 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:29 --> Input Class Initialized
INFO - 2020-10-08 09:24:29 --> Language Class Initialized
INFO - 2020-10-08 09:24:29 --> Loader Class Initialized
INFO - 2020-10-08 09:24:29 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:29 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:29 --> Email Class Initialized
INFO - 2020-10-08 09:24:29 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:29 --> Model Class Initialized
INFO - 2020-10-08 09:24:29 --> Model Class Initialized
INFO - 2020-10-08 09:24:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:24:29 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:29 --> Total execution time: 0.0340
ERROR - 2020-10-08 09:24:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:30 --> Config Class Initialized
INFO - 2020-10-08 09:24:30 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:30 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:30 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:30 --> URI Class Initialized
INFO - 2020-10-08 09:24:30 --> Router Class Initialized
INFO - 2020-10-08 09:24:30 --> Output Class Initialized
INFO - 2020-10-08 09:24:30 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:30 --> Input Class Initialized
INFO - 2020-10-08 09:24:30 --> Language Class Initialized
INFO - 2020-10-08 09:24:30 --> Loader Class Initialized
INFO - 2020-10-08 09:24:30 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:30 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:30 --> Email Class Initialized
INFO - 2020-10-08 09:24:30 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:30 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:30 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:30 --> Model Class Initialized
INFO - 2020-10-08 09:24:30 --> Model Class Initialized
INFO - 2020-10-08 09:24:31 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_edit.php
INFO - 2020-10-08 09:24:31 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:31 --> Total execution time: 0.0356
ERROR - 2020-10-08 09:24:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:31 --> Config Class Initialized
INFO - 2020-10-08 09:24:31 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:31 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:31 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:31 --> URI Class Initialized
INFO - 2020-10-08 09:24:31 --> Router Class Initialized
INFO - 2020-10-08 09:24:31 --> Output Class Initialized
INFO - 2020-10-08 09:24:31 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:31 --> Input Class Initialized
INFO - 2020-10-08 09:24:31 --> Language Class Initialized
INFO - 2020-10-08 09:24:31 --> Loader Class Initialized
INFO - 2020-10-08 09:24:31 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:31 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:31 --> Email Class Initialized
INFO - 2020-10-08 09:24:31 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:31 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:31 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:31 --> Model Class Initialized
INFO - 2020-10-08 09:24:31 --> Model Class Initialized
INFO - 2020-10-08 09:24:31 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:31 --> Total execution time: 0.0303
ERROR - 2020-10-08 09:24:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:24:40 --> Config Class Initialized
INFO - 2020-10-08 09:24:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:24:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:24:40 --> Utf8 Class Initialized
INFO - 2020-10-08 09:24:40 --> URI Class Initialized
INFO - 2020-10-08 09:24:40 --> Router Class Initialized
INFO - 2020-10-08 09:24:40 --> Output Class Initialized
INFO - 2020-10-08 09:24:40 --> Security Class Initialized
DEBUG - 2020-10-08 09:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:24:40 --> Input Class Initialized
INFO - 2020-10-08 09:24:40 --> Language Class Initialized
INFO - 2020-10-08 09:24:40 --> Loader Class Initialized
INFO - 2020-10-08 09:24:40 --> Helper loaded: url_helper
INFO - 2020-10-08 09:24:40 --> Database Driver Class Initialized
INFO - 2020-10-08 09:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:24:40 --> Email Class Initialized
INFO - 2020-10-08 09:24:40 --> Controller Class Initialized
DEBUG - 2020-10-08 09:24:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:24:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:24:40 --> Model Class Initialized
INFO - 2020-10-08 09:24:40 --> Model Class Initialized
INFO - 2020-10-08 09:24:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:24:40 --> Final output sent to browser
DEBUG - 2020-10-08 09:24:40 --> Total execution time: 0.0238
ERROR - 2020-10-08 09:29:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:29:43 --> Config Class Initialized
INFO - 2020-10-08 09:29:43 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:29:43 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:29:43 --> Utf8 Class Initialized
INFO - 2020-10-08 09:29:43 --> URI Class Initialized
INFO - 2020-10-08 09:29:43 --> Router Class Initialized
INFO - 2020-10-08 09:29:43 --> Output Class Initialized
INFO - 2020-10-08 09:29:43 --> Security Class Initialized
DEBUG - 2020-10-08 09:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:29:43 --> Input Class Initialized
INFO - 2020-10-08 09:29:43 --> Language Class Initialized
INFO - 2020-10-08 09:29:43 --> Loader Class Initialized
INFO - 2020-10-08 09:29:43 --> Helper loaded: url_helper
INFO - 2020-10-08 09:29:43 --> Database Driver Class Initialized
INFO - 2020-10-08 09:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:29:43 --> Email Class Initialized
INFO - 2020-10-08 09:29:43 --> Controller Class Initialized
DEBUG - 2020-10-08 09:29:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:29:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:29:43 --> Model Class Initialized
INFO - 2020-10-08 09:29:43 --> Model Class Initialized
INFO - 2020-10-08 09:29:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:29:43 --> Final output sent to browser
DEBUG - 2020-10-08 09:29:43 --> Total execution time: 0.0278
ERROR - 2020-10-08 09:33:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:33:04 --> Config Class Initialized
INFO - 2020-10-08 09:33:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:33:04 --> Utf8 Class Initialized
INFO - 2020-10-08 09:33:04 --> URI Class Initialized
INFO - 2020-10-08 09:33:04 --> Router Class Initialized
INFO - 2020-10-08 09:33:04 --> Output Class Initialized
INFO - 2020-10-08 09:33:04 --> Security Class Initialized
DEBUG - 2020-10-08 09:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:33:04 --> Input Class Initialized
INFO - 2020-10-08 09:33:04 --> Language Class Initialized
INFO - 2020-10-08 09:33:04 --> Loader Class Initialized
INFO - 2020-10-08 09:33:04 --> Helper loaded: url_helper
INFO - 2020-10-08 09:33:04 --> Database Driver Class Initialized
INFO - 2020-10-08 09:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:33:04 --> Email Class Initialized
INFO - 2020-10-08 09:33:04 --> Controller Class Initialized
DEBUG - 2020-10-08 09:33:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:33:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:33:04 --> Model Class Initialized
INFO - 2020-10-08 09:33:04 --> Model Class Initialized
INFO - 2020-10-08 09:33:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:33:04 --> Final output sent to browser
DEBUG - 2020-10-08 09:33:04 --> Total execution time: 0.0262
ERROR - 2020-10-08 09:35:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:35:39 --> Config Class Initialized
INFO - 2020-10-08 09:35:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:35:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:35:39 --> Utf8 Class Initialized
INFO - 2020-10-08 09:35:39 --> URI Class Initialized
INFO - 2020-10-08 09:35:39 --> Router Class Initialized
INFO - 2020-10-08 09:35:39 --> Output Class Initialized
INFO - 2020-10-08 09:35:39 --> Security Class Initialized
DEBUG - 2020-10-08 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:35:39 --> Input Class Initialized
INFO - 2020-10-08 09:35:39 --> Language Class Initialized
INFO - 2020-10-08 09:35:39 --> Loader Class Initialized
INFO - 2020-10-08 09:35:39 --> Helper loaded: url_helper
INFO - 2020-10-08 09:35:39 --> Database Driver Class Initialized
INFO - 2020-10-08 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:35:39 --> Email Class Initialized
INFO - 2020-10-08 09:35:39 --> Controller Class Initialized
DEBUG - 2020-10-08 09:35:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:35:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:35:39 --> Model Class Initialized
INFO - 2020-10-08 09:35:39 --> Model Class Initialized
INFO - 2020-10-08 09:35:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:35:39 --> Final output sent to browser
DEBUG - 2020-10-08 09:35:39 --> Total execution time: 0.0260
ERROR - 2020-10-08 09:46:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:46:40 --> Config Class Initialized
INFO - 2020-10-08 09:46:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:46:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:46:40 --> Utf8 Class Initialized
INFO - 2020-10-08 09:46:40 --> URI Class Initialized
INFO - 2020-10-08 09:46:40 --> Router Class Initialized
INFO - 2020-10-08 09:46:40 --> Output Class Initialized
INFO - 2020-10-08 09:46:40 --> Security Class Initialized
DEBUG - 2020-10-08 09:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:46:40 --> Input Class Initialized
INFO - 2020-10-08 09:46:40 --> Language Class Initialized
INFO - 2020-10-08 09:46:40 --> Loader Class Initialized
INFO - 2020-10-08 09:46:40 --> Helper loaded: url_helper
INFO - 2020-10-08 09:46:40 --> Database Driver Class Initialized
INFO - 2020-10-08 09:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:46:40 --> Email Class Initialized
INFO - 2020-10-08 09:46:40 --> Controller Class Initialized
DEBUG - 2020-10-08 09:46:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:46:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:46:40 --> Model Class Initialized
INFO - 2020-10-08 09:46:40 --> Model Class Initialized
INFO - 2020-10-08 09:46:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:46:40 --> Final output sent to browser
DEBUG - 2020-10-08 09:46:40 --> Total execution time: 0.0244
ERROR - 2020-10-08 09:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:48:14 --> Config Class Initialized
INFO - 2020-10-08 09:48:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:48:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:48:14 --> Utf8 Class Initialized
INFO - 2020-10-08 09:48:14 --> URI Class Initialized
INFO - 2020-10-08 09:48:14 --> Router Class Initialized
INFO - 2020-10-08 09:48:14 --> Output Class Initialized
INFO - 2020-10-08 09:48:14 --> Security Class Initialized
DEBUG - 2020-10-08 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:48:14 --> Input Class Initialized
INFO - 2020-10-08 09:48:14 --> Language Class Initialized
INFO - 2020-10-08 09:48:14 --> Loader Class Initialized
INFO - 2020-10-08 09:48:14 --> Helper loaded: url_helper
INFO - 2020-10-08 09:48:14 --> Database Driver Class Initialized
INFO - 2020-10-08 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:48:14 --> Email Class Initialized
INFO - 2020-10-08 09:48:14 --> Controller Class Initialized
DEBUG - 2020-10-08 09:48:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:48:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:48:14 --> Model Class Initialized
INFO - 2020-10-08 09:48:14 --> Model Class Initialized
INFO - 2020-10-08 09:48:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:48:14 --> Final output sent to browser
DEBUG - 2020-10-08 09:48:14 --> Total execution time: 0.0219
ERROR - 2020-10-08 09:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:48:41 --> Config Class Initialized
INFO - 2020-10-08 09:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:48:41 --> Utf8 Class Initialized
INFO - 2020-10-08 09:48:41 --> URI Class Initialized
INFO - 2020-10-08 09:48:41 --> Router Class Initialized
INFO - 2020-10-08 09:48:41 --> Output Class Initialized
INFO - 2020-10-08 09:48:41 --> Security Class Initialized
DEBUG - 2020-10-08 09:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:48:41 --> Input Class Initialized
INFO - 2020-10-08 09:48:41 --> Language Class Initialized
INFO - 2020-10-08 09:48:41 --> Loader Class Initialized
INFO - 2020-10-08 09:48:41 --> Helper loaded: url_helper
INFO - 2020-10-08 09:48:41 --> Database Driver Class Initialized
INFO - 2020-10-08 09:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:48:41 --> Email Class Initialized
INFO - 2020-10-08 09:48:41 --> Controller Class Initialized
DEBUG - 2020-10-08 09:48:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:48:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:48:41 --> Model Class Initialized
INFO - 2020-10-08 09:48:41 --> Model Class Initialized
INFO - 2020-10-08 09:48:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:48:41 --> Final output sent to browser
DEBUG - 2020-10-08 09:48:41 --> Total execution time: 0.0238
ERROR - 2020-10-08 09:49:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:49:12 --> Config Class Initialized
INFO - 2020-10-08 09:49:12 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:49:12 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:49:12 --> Utf8 Class Initialized
INFO - 2020-10-08 09:49:12 --> URI Class Initialized
INFO - 2020-10-08 09:49:12 --> Router Class Initialized
INFO - 2020-10-08 09:49:12 --> Output Class Initialized
INFO - 2020-10-08 09:49:12 --> Security Class Initialized
DEBUG - 2020-10-08 09:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:49:12 --> Input Class Initialized
INFO - 2020-10-08 09:49:12 --> Language Class Initialized
INFO - 2020-10-08 09:49:12 --> Loader Class Initialized
INFO - 2020-10-08 09:49:12 --> Helper loaded: url_helper
INFO - 2020-10-08 09:49:12 --> Database Driver Class Initialized
INFO - 2020-10-08 09:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:49:12 --> Email Class Initialized
INFO - 2020-10-08 09:49:12 --> Controller Class Initialized
DEBUG - 2020-10-08 09:49:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:49:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:49:12 --> Model Class Initialized
INFO - 2020-10-08 09:49:12 --> Model Class Initialized
INFO - 2020-10-08 09:49:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:49:12 --> Final output sent to browser
DEBUG - 2020-10-08 09:49:12 --> Total execution time: 0.0213
ERROR - 2020-10-08 09:49:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:49:59 --> Config Class Initialized
INFO - 2020-10-08 09:49:59 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:49:59 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:49:59 --> Utf8 Class Initialized
INFO - 2020-10-08 09:49:59 --> URI Class Initialized
INFO - 2020-10-08 09:49:59 --> Router Class Initialized
INFO - 2020-10-08 09:49:59 --> Output Class Initialized
INFO - 2020-10-08 09:49:59 --> Security Class Initialized
DEBUG - 2020-10-08 09:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:49:59 --> Input Class Initialized
INFO - 2020-10-08 09:49:59 --> Language Class Initialized
INFO - 2020-10-08 09:49:59 --> Loader Class Initialized
INFO - 2020-10-08 09:49:59 --> Helper loaded: url_helper
INFO - 2020-10-08 09:49:59 --> Database Driver Class Initialized
INFO - 2020-10-08 09:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:49:59 --> Email Class Initialized
INFO - 2020-10-08 09:49:59 --> Controller Class Initialized
DEBUG - 2020-10-08 09:49:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:49:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:49:59 --> Model Class Initialized
INFO - 2020-10-08 09:49:59 --> Model Class Initialized
INFO - 2020-10-08 09:49:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:49:59 --> Final output sent to browser
DEBUG - 2020-10-08 09:49:59 --> Total execution time: 0.0242
ERROR - 2020-10-08 09:50:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:50:23 --> Config Class Initialized
INFO - 2020-10-08 09:50:23 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:50:23 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:50:23 --> Utf8 Class Initialized
INFO - 2020-10-08 09:50:23 --> URI Class Initialized
INFO - 2020-10-08 09:50:23 --> Router Class Initialized
INFO - 2020-10-08 09:50:23 --> Output Class Initialized
INFO - 2020-10-08 09:50:23 --> Security Class Initialized
DEBUG - 2020-10-08 09:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:50:23 --> Input Class Initialized
INFO - 2020-10-08 09:50:23 --> Language Class Initialized
INFO - 2020-10-08 09:50:23 --> Loader Class Initialized
INFO - 2020-10-08 09:50:23 --> Helper loaded: url_helper
INFO - 2020-10-08 09:50:23 --> Database Driver Class Initialized
INFO - 2020-10-08 09:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:50:23 --> Email Class Initialized
INFO - 2020-10-08 09:50:23 --> Controller Class Initialized
DEBUG - 2020-10-08 09:50:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:50:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:50:23 --> Model Class Initialized
INFO - 2020-10-08 09:50:23 --> Model Class Initialized
INFO - 2020-10-08 09:50:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:50:23 --> Final output sent to browser
DEBUG - 2020-10-08 09:50:23 --> Total execution time: 0.0205
ERROR - 2020-10-08 09:50:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:50:38 --> Config Class Initialized
INFO - 2020-10-08 09:50:38 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:50:38 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:50:38 --> Utf8 Class Initialized
INFO - 2020-10-08 09:50:38 --> URI Class Initialized
INFO - 2020-10-08 09:50:38 --> Router Class Initialized
INFO - 2020-10-08 09:50:38 --> Output Class Initialized
INFO - 2020-10-08 09:50:38 --> Security Class Initialized
DEBUG - 2020-10-08 09:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:50:38 --> Input Class Initialized
INFO - 2020-10-08 09:50:38 --> Language Class Initialized
INFO - 2020-10-08 09:50:38 --> Loader Class Initialized
INFO - 2020-10-08 09:50:38 --> Helper loaded: url_helper
INFO - 2020-10-08 09:50:38 --> Database Driver Class Initialized
INFO - 2020-10-08 09:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:50:38 --> Email Class Initialized
INFO - 2020-10-08 09:50:38 --> Controller Class Initialized
DEBUG - 2020-10-08 09:50:38 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:50:38 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:50:38 --> Model Class Initialized
INFO - 2020-10-08 09:50:38 --> Model Class Initialized
INFO - 2020-10-08 09:50:38 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:50:38 --> Final output sent to browser
DEBUG - 2020-10-08 09:50:38 --> Total execution time: 0.0211
ERROR - 2020-10-08 09:50:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:50:53 --> Config Class Initialized
INFO - 2020-10-08 09:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:50:53 --> Utf8 Class Initialized
INFO - 2020-10-08 09:50:53 --> URI Class Initialized
INFO - 2020-10-08 09:50:53 --> Router Class Initialized
INFO - 2020-10-08 09:50:53 --> Output Class Initialized
INFO - 2020-10-08 09:50:53 --> Security Class Initialized
DEBUG - 2020-10-08 09:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:50:53 --> Input Class Initialized
INFO - 2020-10-08 09:50:53 --> Language Class Initialized
INFO - 2020-10-08 09:50:53 --> Loader Class Initialized
INFO - 2020-10-08 09:50:53 --> Helper loaded: url_helper
INFO - 2020-10-08 09:50:53 --> Database Driver Class Initialized
INFO - 2020-10-08 09:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:50:53 --> Email Class Initialized
INFO - 2020-10-08 09:50:53 --> Controller Class Initialized
DEBUG - 2020-10-08 09:50:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:50:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:50:53 --> Model Class Initialized
INFO - 2020-10-08 09:50:53 --> Model Class Initialized
INFO - 2020-10-08 09:50:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:50:53 --> Final output sent to browser
DEBUG - 2020-10-08 09:50:53 --> Total execution time: 0.0240
ERROR - 2020-10-08 09:51:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:51:21 --> Config Class Initialized
INFO - 2020-10-08 09:51:21 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:51:21 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:51:21 --> Utf8 Class Initialized
INFO - 2020-10-08 09:51:21 --> URI Class Initialized
INFO - 2020-10-08 09:51:21 --> Router Class Initialized
INFO - 2020-10-08 09:51:21 --> Output Class Initialized
INFO - 2020-10-08 09:51:21 --> Security Class Initialized
DEBUG - 2020-10-08 09:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:51:21 --> Input Class Initialized
INFO - 2020-10-08 09:51:21 --> Language Class Initialized
INFO - 2020-10-08 09:51:21 --> Loader Class Initialized
INFO - 2020-10-08 09:51:21 --> Helper loaded: url_helper
INFO - 2020-10-08 09:51:21 --> Database Driver Class Initialized
INFO - 2020-10-08 09:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:51:21 --> Email Class Initialized
INFO - 2020-10-08 09:51:21 --> Controller Class Initialized
DEBUG - 2020-10-08 09:51:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:51:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:51:21 --> Model Class Initialized
INFO - 2020-10-08 09:51:21 --> Model Class Initialized
INFO - 2020-10-08 09:51:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:51:21 --> Final output sent to browser
DEBUG - 2020-10-08 09:51:21 --> Total execution time: 0.0257
ERROR - 2020-10-08 09:52:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:52:56 --> Config Class Initialized
INFO - 2020-10-08 09:52:56 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:52:56 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:52:56 --> Utf8 Class Initialized
INFO - 2020-10-08 09:52:56 --> URI Class Initialized
INFO - 2020-10-08 09:52:56 --> Router Class Initialized
INFO - 2020-10-08 09:52:56 --> Output Class Initialized
INFO - 2020-10-08 09:52:56 --> Security Class Initialized
DEBUG - 2020-10-08 09:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:52:56 --> Input Class Initialized
INFO - 2020-10-08 09:52:56 --> Language Class Initialized
INFO - 2020-10-08 09:52:56 --> Loader Class Initialized
INFO - 2020-10-08 09:52:56 --> Helper loaded: url_helper
INFO - 2020-10-08 09:52:56 --> Database Driver Class Initialized
INFO - 2020-10-08 09:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:52:56 --> Email Class Initialized
INFO - 2020-10-08 09:52:56 --> Controller Class Initialized
DEBUG - 2020-10-08 09:52:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:52:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:52:56 --> Model Class Initialized
INFO - 2020-10-08 09:52:56 --> Model Class Initialized
INFO - 2020-10-08 09:52:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:52:56 --> Final output sent to browser
DEBUG - 2020-10-08 09:52:56 --> Total execution time: 0.0244
ERROR - 2020-10-08 09:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:53:39 --> Config Class Initialized
INFO - 2020-10-08 09:53:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:53:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:53:39 --> Utf8 Class Initialized
INFO - 2020-10-08 09:53:39 --> URI Class Initialized
DEBUG - 2020-10-08 09:53:39 --> No URI present. Default controller set.
INFO - 2020-10-08 09:53:39 --> Router Class Initialized
INFO - 2020-10-08 09:53:39 --> Output Class Initialized
INFO - 2020-10-08 09:53:39 --> Security Class Initialized
DEBUG - 2020-10-08 09:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:53:39 --> Input Class Initialized
INFO - 2020-10-08 09:53:39 --> Language Class Initialized
INFO - 2020-10-08 09:53:39 --> Loader Class Initialized
INFO - 2020-10-08 09:53:39 --> Helper loaded: url_helper
INFO - 2020-10-08 09:53:39 --> Database Driver Class Initialized
INFO - 2020-10-08 09:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:53:39 --> Email Class Initialized
INFO - 2020-10-08 09:53:39 --> Controller Class Initialized
INFO - 2020-10-08 09:53:39 --> Model Class Initialized
INFO - 2020-10-08 09:53:39 --> Model Class Initialized
DEBUG - 2020-10-08 09:53:39 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:53:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:53:39 --> Final output sent to browser
DEBUG - 2020-10-08 09:53:39 --> Total execution time: 0.0184
ERROR - 2020-10-08 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:53:52 --> Config Class Initialized
INFO - 2020-10-08 09:53:52 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:53:52 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:53:52 --> Utf8 Class Initialized
INFO - 2020-10-08 09:53:52 --> URI Class Initialized
DEBUG - 2020-10-08 09:53:52 --> No URI present. Default controller set.
INFO - 2020-10-08 09:53:52 --> Router Class Initialized
INFO - 2020-10-08 09:53:52 --> Output Class Initialized
INFO - 2020-10-08 09:53:52 --> Security Class Initialized
DEBUG - 2020-10-08 09:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:53:52 --> Input Class Initialized
INFO - 2020-10-08 09:53:52 --> Language Class Initialized
INFO - 2020-10-08 09:53:52 --> Loader Class Initialized
INFO - 2020-10-08 09:53:52 --> Helper loaded: url_helper
INFO - 2020-10-08 09:53:52 --> Database Driver Class Initialized
INFO - 2020-10-08 09:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:53:52 --> Email Class Initialized
INFO - 2020-10-08 09:53:52 --> Controller Class Initialized
INFO - 2020-10-08 09:53:52 --> Model Class Initialized
INFO - 2020-10-08 09:53:52 --> Model Class Initialized
DEBUG - 2020-10-08 09:53:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:53:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:53:52 --> Final output sent to browser
DEBUG - 2020-10-08 09:53:52 --> Total execution time: 0.0209
ERROR - 2020-10-08 09:54:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:02 --> Config Class Initialized
INFO - 2020-10-08 09:54:02 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:02 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:02 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:02 --> URI Class Initialized
DEBUG - 2020-10-08 09:54:02 --> No URI present. Default controller set.
INFO - 2020-10-08 09:54:02 --> Router Class Initialized
INFO - 2020-10-08 09:54:02 --> Output Class Initialized
INFO - 2020-10-08 09:54:02 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:02 --> Input Class Initialized
INFO - 2020-10-08 09:54:02 --> Language Class Initialized
INFO - 2020-10-08 09:54:02 --> Loader Class Initialized
INFO - 2020-10-08 09:54:02 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:02 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:02 --> Email Class Initialized
INFO - 2020-10-08 09:54:02 --> Controller Class Initialized
INFO - 2020-10-08 09:54:02 --> Model Class Initialized
INFO - 2020-10-08 09:54:02 --> Model Class Initialized
DEBUG - 2020-10-08 09:54:02 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:02 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:54:02 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:02 --> Total execution time: 0.0189
ERROR - 2020-10-08 09:54:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:05 --> Config Class Initialized
INFO - 2020-10-08 09:54:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:05 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:05 --> URI Class Initialized
INFO - 2020-10-08 09:54:05 --> Router Class Initialized
INFO - 2020-10-08 09:54:05 --> Output Class Initialized
INFO - 2020-10-08 09:54:05 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:05 --> Input Class Initialized
INFO - 2020-10-08 09:54:05 --> Language Class Initialized
INFO - 2020-10-08 09:54:05 --> Loader Class Initialized
INFO - 2020-10-08 09:54:05 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:05 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:05 --> Email Class Initialized
INFO - 2020-10-08 09:54:05 --> Controller Class Initialized
INFO - 2020-10-08 09:54:05 --> Model Class Initialized
INFO - 2020-10-08 09:54:05 --> Model Class Initialized
DEBUG - 2020-10-08 09:54:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:54:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:05 --> Model Class Initialized
INFO - 2020-10-08 09:54:05 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:05 --> Total execution time: 0.0293
ERROR - 2020-10-08 09:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:06 --> Config Class Initialized
INFO - 2020-10-08 09:54:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:06 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:06 --> URI Class Initialized
INFO - 2020-10-08 09:54:06 --> Router Class Initialized
INFO - 2020-10-08 09:54:06 --> Output Class Initialized
INFO - 2020-10-08 09:54:06 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:06 --> Input Class Initialized
INFO - 2020-10-08 09:54:06 --> Language Class Initialized
INFO - 2020-10-08 09:54:06 --> Loader Class Initialized
INFO - 2020-10-08 09:54:06 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:06 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:06 --> Email Class Initialized
INFO - 2020-10-08 09:54:06 --> Controller Class Initialized
INFO - 2020-10-08 09:54:06 --> Model Class Initialized
INFO - 2020-10-08 09:54:06 --> Model Class Initialized
DEBUG - 2020-10-08 09:54:06 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 09:54:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:06 --> Config Class Initialized
INFO - 2020-10-08 09:54:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:06 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:06 --> URI Class Initialized
INFO - 2020-10-08 09:54:06 --> Router Class Initialized
INFO - 2020-10-08 09:54:06 --> Output Class Initialized
INFO - 2020-10-08 09:54:06 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:06 --> Input Class Initialized
INFO - 2020-10-08 09:54:06 --> Language Class Initialized
INFO - 2020-10-08 09:54:06 --> Loader Class Initialized
INFO - 2020-10-08 09:54:06 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:06 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:06 --> Email Class Initialized
INFO - 2020-10-08 09:54:06 --> Controller Class Initialized
DEBUG - 2020-10-08 09:54:06 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:54:06 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:06 --> Model Class Initialized
INFO - 2020-10-08 09:54:06 --> Model Class Initialized
INFO - 2020-10-08 09:54:06 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 09:54:06 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:06 --> Total execution time: 0.0204
ERROR - 2020-10-08 09:54:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:14 --> Config Class Initialized
INFO - 2020-10-08 09:54:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:14 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:14 --> URI Class Initialized
DEBUG - 2020-10-08 09:54:14 --> No URI present. Default controller set.
INFO - 2020-10-08 09:54:14 --> Router Class Initialized
INFO - 2020-10-08 09:54:14 --> Output Class Initialized
INFO - 2020-10-08 09:54:14 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:14 --> Input Class Initialized
INFO - 2020-10-08 09:54:14 --> Language Class Initialized
INFO - 2020-10-08 09:54:14 --> Loader Class Initialized
INFO - 2020-10-08 09:54:14 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:14 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:14 --> Email Class Initialized
INFO - 2020-10-08 09:54:14 --> Controller Class Initialized
INFO - 2020-10-08 09:54:14 --> Model Class Initialized
INFO - 2020-10-08 09:54:14 --> Model Class Initialized
DEBUG - 2020-10-08 09:54:14 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:54:14 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:14 --> Total execution time: 0.0178
ERROR - 2020-10-08 09:54:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:33 --> Config Class Initialized
INFO - 2020-10-08 09:54:33 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:33 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:33 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:33 --> URI Class Initialized
INFO - 2020-10-08 09:54:33 --> Router Class Initialized
INFO - 2020-10-08 09:54:33 --> Output Class Initialized
INFO - 2020-10-08 09:54:33 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:33 --> Input Class Initialized
INFO - 2020-10-08 09:54:33 --> Language Class Initialized
INFO - 2020-10-08 09:54:33 --> Loader Class Initialized
INFO - 2020-10-08 09:54:33 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:33 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:33 --> Email Class Initialized
INFO - 2020-10-08 09:54:33 --> Controller Class Initialized
INFO - 2020-10-08 09:54:33 --> Model Class Initialized
INFO - 2020-10-08 09:54:33 --> Model Class Initialized
DEBUG - 2020-10-08 09:54:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:54:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:33 --> Model Class Initialized
INFO - 2020-10-08 09:54:33 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:33 --> Total execution time: 0.0256
ERROR - 2020-10-08 09:54:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:34 --> Config Class Initialized
INFO - 2020-10-08 09:54:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:34 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:34 --> URI Class Initialized
INFO - 2020-10-08 09:54:34 --> Router Class Initialized
INFO - 2020-10-08 09:54:34 --> Output Class Initialized
INFO - 2020-10-08 09:54:34 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:34 --> Input Class Initialized
INFO - 2020-10-08 09:54:34 --> Language Class Initialized
INFO - 2020-10-08 09:54:34 --> Loader Class Initialized
INFO - 2020-10-08 09:54:34 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:34 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:34 --> Email Class Initialized
INFO - 2020-10-08 09:54:34 --> Controller Class Initialized
INFO - 2020-10-08 09:54:34 --> Model Class Initialized
INFO - 2020-10-08 09:54:34 --> Model Class Initialized
DEBUG - 2020-10-08 09:54:34 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 09:54:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:34 --> Config Class Initialized
INFO - 2020-10-08 09:54:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:34 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:34 --> URI Class Initialized
INFO - 2020-10-08 09:54:34 --> Router Class Initialized
INFO - 2020-10-08 09:54:34 --> Output Class Initialized
INFO - 2020-10-08 09:54:34 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:34 --> Input Class Initialized
INFO - 2020-10-08 09:54:34 --> Language Class Initialized
INFO - 2020-10-08 09:54:34 --> Loader Class Initialized
INFO - 2020-10-08 09:54:34 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:34 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:34 --> Email Class Initialized
INFO - 2020-10-08 09:54:34 --> Controller Class Initialized
DEBUG - 2020-10-08 09:54:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:54:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:34 --> Model Class Initialized
INFO - 2020-10-08 09:54:34 --> Model Class Initialized
INFO - 2020-10-08 09:54:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 09:54:34 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:34 --> Total execution time: 0.0253
ERROR - 2020-10-08 09:54:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:54:56 --> Config Class Initialized
INFO - 2020-10-08 09:54:56 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:54:56 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:54:56 --> Utf8 Class Initialized
INFO - 2020-10-08 09:54:56 --> URI Class Initialized
INFO - 2020-10-08 09:54:56 --> Router Class Initialized
INFO - 2020-10-08 09:54:56 --> Output Class Initialized
INFO - 2020-10-08 09:54:56 --> Security Class Initialized
DEBUG - 2020-10-08 09:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:54:56 --> Input Class Initialized
INFO - 2020-10-08 09:54:56 --> Language Class Initialized
INFO - 2020-10-08 09:54:56 --> Loader Class Initialized
INFO - 2020-10-08 09:54:56 --> Helper loaded: url_helper
INFO - 2020-10-08 09:54:56 --> Database Driver Class Initialized
INFO - 2020-10-08 09:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:54:56 --> Email Class Initialized
INFO - 2020-10-08 09:54:56 --> Controller Class Initialized
DEBUG - 2020-10-08 09:54:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:54:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:54:56 --> Model Class Initialized
INFO - 2020-10-08 09:54:56 --> Model Class Initialized
INFO - 2020-10-08 09:54:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:54:56 --> Final output sent to browser
DEBUG - 2020-10-08 09:54:56 --> Total execution time: 0.0206
ERROR - 2020-10-08 09:56:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:10 --> Config Class Initialized
INFO - 2020-10-08 09:56:10 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:10 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:10 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:10 --> URI Class Initialized
INFO - 2020-10-08 09:56:10 --> Router Class Initialized
INFO - 2020-10-08 09:56:10 --> Output Class Initialized
INFO - 2020-10-08 09:56:10 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:10 --> Input Class Initialized
INFO - 2020-10-08 09:56:10 --> Language Class Initialized
INFO - 2020-10-08 09:56:10 --> Loader Class Initialized
INFO - 2020-10-08 09:56:10 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:10 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:10 --> Email Class Initialized
INFO - 2020-10-08 09:56:10 --> Controller Class Initialized
INFO - 2020-10-08 09:56:10 --> Model Class Initialized
INFO - 2020-10-08 09:56:10 --> Model Class Initialized
INFO - 2020-10-08 09:56:11 --> Model Class Initialized
INFO - 2020-10-08 09:56:11 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/excel_upload.php
INFO - 2020-10-08 09:56:11 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:11 --> Total execution time: 0.3710
ERROR - 2020-10-08 09:56:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:11 --> Config Class Initialized
INFO - 2020-10-08 09:56:11 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:11 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:11 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:11 --> URI Class Initialized
INFO - 2020-10-08 09:56:11 --> Router Class Initialized
INFO - 2020-10-08 09:56:11 --> Output Class Initialized
INFO - 2020-10-08 09:56:11 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:11 --> Input Class Initialized
INFO - 2020-10-08 09:56:11 --> Language Class Initialized
INFO - 2020-10-08 09:56:11 --> Loader Class Initialized
INFO - 2020-10-08 09:56:11 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:11 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:11 --> Email Class Initialized
INFO - 2020-10-08 09:56:11 --> Controller Class Initialized
INFO - 2020-10-08 09:56:11 --> Model Class Initialized
INFO - 2020-10-08 09:56:11 --> Model Class Initialized
INFO - 2020-10-08 09:56:11 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:11 --> Total execution time: 0.0449
ERROR - 2020-10-08 09:56:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:15 --> Config Class Initialized
INFO - 2020-10-08 09:56:15 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:15 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:15 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:15 --> URI Class Initialized
INFO - 2020-10-08 09:56:15 --> Router Class Initialized
INFO - 2020-10-08 09:56:15 --> Output Class Initialized
INFO - 2020-10-08 09:56:15 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:15 --> Input Class Initialized
INFO - 2020-10-08 09:56:15 --> Language Class Initialized
INFO - 2020-10-08 09:56:15 --> Loader Class Initialized
INFO - 2020-10-08 09:56:15 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:15 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:15 --> Email Class Initialized
INFO - 2020-10-08 09:56:15 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:15 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:15 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:15 --> Model Class Initialized
INFO - 2020-10-08 09:56:15 --> Model Class Initialized
INFO - 2020-10-08 09:56:15 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:56:15 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:15 --> Total execution time: 0.0258
ERROR - 2020-10-08 09:56:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:18 --> Config Class Initialized
INFO - 2020-10-08 09:56:18 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:18 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:18 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:18 --> URI Class Initialized
INFO - 2020-10-08 09:56:18 --> Router Class Initialized
INFO - 2020-10-08 09:56:18 --> Output Class Initialized
INFO - 2020-10-08 09:56:18 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:18 --> Input Class Initialized
INFO - 2020-10-08 09:56:18 --> Language Class Initialized
INFO - 2020-10-08 09:56:18 --> Loader Class Initialized
INFO - 2020-10-08 09:56:18 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:19 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:19 --> Email Class Initialized
INFO - 2020-10-08 09:56:19 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:19 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:19 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:19 --> Model Class Initialized
INFO - 2020-10-08 09:56:19 --> Model Class Initialized
INFO - 2020-10-08 09:56:19 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:56:19 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:19 --> Total execution time: 0.0255
ERROR - 2020-10-08 09:56:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:23 --> Config Class Initialized
INFO - 2020-10-08 09:56:23 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:23 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:23 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:23 --> URI Class Initialized
INFO - 2020-10-08 09:56:23 --> Router Class Initialized
INFO - 2020-10-08 09:56:23 --> Output Class Initialized
INFO - 2020-10-08 09:56:23 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:23 --> Input Class Initialized
INFO - 2020-10-08 09:56:23 --> Language Class Initialized
INFO - 2020-10-08 09:56:23 --> Loader Class Initialized
INFO - 2020-10-08 09:56:23 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:23 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:23 --> Email Class Initialized
INFO - 2020-10-08 09:56:23 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:23 --> Model Class Initialized
INFO - 2020-10-08 09:56:23 --> Model Class Initialized
INFO - 2020-10-08 09:56:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 09:56:23 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:23 --> Total execution time: 0.0232
ERROR - 2020-10-08 09:56:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:26 --> Config Class Initialized
INFO - 2020-10-08 09:56:26 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:26 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:26 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:26 --> URI Class Initialized
INFO - 2020-10-08 09:56:26 --> Router Class Initialized
INFO - 2020-10-08 09:56:26 --> Output Class Initialized
INFO - 2020-10-08 09:56:26 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:26 --> Input Class Initialized
INFO - 2020-10-08 09:56:26 --> Language Class Initialized
INFO - 2020-10-08 09:56:26 --> Loader Class Initialized
INFO - 2020-10-08 09:56:26 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:26 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:26 --> Email Class Initialized
INFO - 2020-10-08 09:56:26 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:26 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:26 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:26 --> Model Class Initialized
INFO - 2020-10-08 09:56:26 --> Model Class Initialized
INFO - 2020-10-08 09:56:26 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 09:56:26 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:26 --> Total execution time: 0.0220
ERROR - 2020-10-08 09:56:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:29 --> Config Class Initialized
INFO - 2020-10-08 09:56:29 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:29 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:29 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:29 --> URI Class Initialized
INFO - 2020-10-08 09:56:29 --> Router Class Initialized
INFO - 2020-10-08 09:56:29 --> Output Class Initialized
INFO - 2020-10-08 09:56:29 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:29 --> Input Class Initialized
INFO - 2020-10-08 09:56:29 --> Language Class Initialized
INFO - 2020-10-08 09:56:29 --> Loader Class Initialized
INFO - 2020-10-08 09:56:29 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:29 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:29 --> Email Class Initialized
INFO - 2020-10-08 09:56:29 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:29 --> Model Class Initialized
INFO - 2020-10-08 09:56:29 --> Model Class Initialized
INFO - 2020-10-08 09:56:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 09:56:29 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:29 --> Total execution time: 0.0265
ERROR - 2020-10-08 09:56:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:40 --> Config Class Initialized
INFO - 2020-10-08 09:56:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:40 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:40 --> URI Class Initialized
INFO - 2020-10-08 09:56:40 --> Router Class Initialized
INFO - 2020-10-08 09:56:40 --> Output Class Initialized
INFO - 2020-10-08 09:56:40 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:40 --> Input Class Initialized
INFO - 2020-10-08 09:56:40 --> Language Class Initialized
INFO - 2020-10-08 09:56:40 --> Loader Class Initialized
INFO - 2020-10-08 09:56:40 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:40 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:40 --> Email Class Initialized
INFO - 2020-10-08 09:56:40 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:40 --> Model Class Initialized
INFO - 2020-10-08 09:56:40 --> Model Class Initialized
INFO - 2020-10-08 09:56:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 09:56:40 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:40 --> Total execution time: 0.0234
ERROR - 2020-10-08 09:56:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:48 --> Config Class Initialized
INFO - 2020-10-08 09:56:48 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:48 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:48 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:48 --> URI Class Initialized
INFO - 2020-10-08 09:56:48 --> Router Class Initialized
INFO - 2020-10-08 09:56:48 --> Output Class Initialized
INFO - 2020-10-08 09:56:48 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:48 --> Input Class Initialized
INFO - 2020-10-08 09:56:48 --> Language Class Initialized
INFO - 2020-10-08 09:56:48 --> Loader Class Initialized
INFO - 2020-10-08 09:56:48 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:48 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:48 --> Email Class Initialized
INFO - 2020-10-08 09:56:48 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:48 --> Model Class Initialized
INFO - 2020-10-08 09:56:48 --> Model Class Initialized
INFO - 2020-10-08 09:56:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/user_view.php
INFO - 2020-10-08 09:56:48 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:48 --> Total execution time: 0.0347
ERROR - 2020-10-08 09:56:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:51 --> Config Class Initialized
INFO - 2020-10-08 09:56:51 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:51 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:51 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:51 --> URI Class Initialized
INFO - 2020-10-08 09:56:51 --> Router Class Initialized
INFO - 2020-10-08 09:56:51 --> Output Class Initialized
INFO - 2020-10-08 09:56:51 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:51 --> Input Class Initialized
INFO - 2020-10-08 09:56:51 --> Language Class Initialized
INFO - 2020-10-08 09:56:51 --> Loader Class Initialized
INFO - 2020-10-08 09:56:51 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:51 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:51 --> Email Class Initialized
INFO - 2020-10-08 09:56:51 --> Controller Class Initialized
DEBUG - 2020-10-08 09:56:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:56:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:51 --> Model Class Initialized
INFO - 2020-10-08 09:56:51 --> Model Class Initialized
INFO - 2020-10-08 09:56:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 09:56:51 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:51 --> Total execution time: 0.0212
ERROR - 2020-10-08 09:56:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:56:57 --> Config Class Initialized
INFO - 2020-10-08 09:56:57 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:56:57 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:56:57 --> Utf8 Class Initialized
INFO - 2020-10-08 09:56:57 --> URI Class Initialized
DEBUG - 2020-10-08 09:56:57 --> No URI present. Default controller set.
INFO - 2020-10-08 09:56:57 --> Router Class Initialized
INFO - 2020-10-08 09:56:57 --> Output Class Initialized
INFO - 2020-10-08 09:56:57 --> Security Class Initialized
DEBUG - 2020-10-08 09:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:56:57 --> Input Class Initialized
INFO - 2020-10-08 09:56:57 --> Language Class Initialized
INFO - 2020-10-08 09:56:57 --> Loader Class Initialized
INFO - 2020-10-08 09:56:57 --> Helper loaded: url_helper
INFO - 2020-10-08 09:56:57 --> Database Driver Class Initialized
INFO - 2020-10-08 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:56:57 --> Email Class Initialized
INFO - 2020-10-08 09:56:57 --> Controller Class Initialized
INFO - 2020-10-08 09:56:57 --> Model Class Initialized
INFO - 2020-10-08 09:56:57 --> Model Class Initialized
DEBUG - 2020-10-08 09:56:57 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:56:57 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:56:57 --> Final output sent to browser
DEBUG - 2020-10-08 09:56:57 --> Total execution time: 0.0178
ERROR - 2020-10-08 09:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:04 --> Config Class Initialized
INFO - 2020-10-08 09:57:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:04 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:04 --> URI Class Initialized
INFO - 2020-10-08 09:57:04 --> Router Class Initialized
INFO - 2020-10-08 09:57:04 --> Output Class Initialized
INFO - 2020-10-08 09:57:04 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:04 --> Input Class Initialized
INFO - 2020-10-08 09:57:04 --> Language Class Initialized
INFO - 2020-10-08 09:57:04 --> Loader Class Initialized
INFO - 2020-10-08 09:57:04 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:04 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:04 --> Email Class Initialized
INFO - 2020-10-08 09:57:04 --> Controller Class Initialized
INFO - 2020-10-08 09:57:04 --> Model Class Initialized
INFO - 2020-10-08 09:57:04 --> Model Class Initialized
DEBUG - 2020-10-08 09:57:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:04 --> Model Class Initialized
INFO - 2020-10-08 09:57:04 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:04 --> Total execution time: 0.0200
ERROR - 2020-10-08 09:57:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:04 --> Config Class Initialized
INFO - 2020-10-08 09:57:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:04 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:04 --> URI Class Initialized
INFO - 2020-10-08 09:57:04 --> Router Class Initialized
INFO - 2020-10-08 09:57:04 --> Output Class Initialized
INFO - 2020-10-08 09:57:04 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:04 --> Input Class Initialized
INFO - 2020-10-08 09:57:04 --> Language Class Initialized
INFO - 2020-10-08 09:57:04 --> Loader Class Initialized
INFO - 2020-10-08 09:57:04 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:04 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:04 --> Email Class Initialized
INFO - 2020-10-08 09:57:04 --> Controller Class Initialized
INFO - 2020-10-08 09:57:04 --> Model Class Initialized
INFO - 2020-10-08 09:57:04 --> Model Class Initialized
DEBUG - 2020-10-08 09:57:04 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 09:57:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:05 --> Config Class Initialized
INFO - 2020-10-08 09:57:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:05 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:05 --> URI Class Initialized
INFO - 2020-10-08 09:57:05 --> Router Class Initialized
INFO - 2020-10-08 09:57:05 --> Output Class Initialized
INFO - 2020-10-08 09:57:05 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:05 --> Input Class Initialized
INFO - 2020-10-08 09:57:05 --> Language Class Initialized
INFO - 2020-10-08 09:57:05 --> Loader Class Initialized
INFO - 2020-10-08 09:57:05 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:05 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:05 --> Email Class Initialized
INFO - 2020-10-08 09:57:05 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:05 --> Model Class Initialized
INFO - 2020-10-08 09:57:05 --> Model Class Initialized
INFO - 2020-10-08 09:57:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 09:57:05 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:05 --> Total execution time: 0.0227
ERROR - 2020-10-08 09:57:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:09 --> Config Class Initialized
INFO - 2020-10-08 09:57:09 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:09 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:09 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:09 --> URI Class Initialized
INFO - 2020-10-08 09:57:09 --> Router Class Initialized
INFO - 2020-10-08 09:57:09 --> Output Class Initialized
INFO - 2020-10-08 09:57:09 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:09 --> Input Class Initialized
INFO - 2020-10-08 09:57:09 --> Language Class Initialized
INFO - 2020-10-08 09:57:09 --> Loader Class Initialized
INFO - 2020-10-08 09:57:09 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:09 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:09 --> Email Class Initialized
INFO - 2020-10-08 09:57:09 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:09 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:09 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:09 --> Model Class Initialized
INFO - 2020-10-08 09:57:09 --> Model Class Initialized
INFO - 2020-10-08 09:57:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 09:57:09 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:09 --> Total execution time: 0.0318
ERROR - 2020-10-08 09:57:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:27 --> Config Class Initialized
INFO - 2020-10-08 09:57:27 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:27 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:27 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:27 --> URI Class Initialized
INFO - 2020-10-08 09:57:27 --> Router Class Initialized
INFO - 2020-10-08 09:57:27 --> Output Class Initialized
INFO - 2020-10-08 09:57:27 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:27 --> Input Class Initialized
INFO - 2020-10-08 09:57:27 --> Language Class Initialized
INFO - 2020-10-08 09:57:27 --> Loader Class Initialized
INFO - 2020-10-08 09:57:27 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:27 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:27 --> Email Class Initialized
INFO - 2020-10-08 09:57:27 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:27 --> Model Class Initialized
INFO - 2020-10-08 09:57:27 --> Model Class Initialized
INFO - 2020-10-08 09:57:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 09:57:27 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:27 --> Total execution time: 0.0506
ERROR - 2020-10-08 09:57:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:33 --> Config Class Initialized
INFO - 2020-10-08 09:57:33 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:33 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:33 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:33 --> URI Class Initialized
INFO - 2020-10-08 09:57:33 --> Router Class Initialized
INFO - 2020-10-08 09:57:33 --> Output Class Initialized
INFO - 2020-10-08 09:57:33 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:33 --> Input Class Initialized
INFO - 2020-10-08 09:57:33 --> Language Class Initialized
INFO - 2020-10-08 09:57:33 --> Loader Class Initialized
INFO - 2020-10-08 09:57:33 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:33 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:33 --> Email Class Initialized
INFO - 2020-10-08 09:57:33 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:33 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:33 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:33 --> Model Class Initialized
INFO - 2020-10-08 09:57:33 --> Model Class Initialized
INFO - 2020-10-08 09:57:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-08 09:57:33 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:33 --> Total execution time: 0.0276
ERROR - 2020-10-08 09:57:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:35 --> Config Class Initialized
INFO - 2020-10-08 09:57:35 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:35 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:35 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:35 --> URI Class Initialized
INFO - 2020-10-08 09:57:35 --> Router Class Initialized
INFO - 2020-10-08 09:57:35 --> Output Class Initialized
INFO - 2020-10-08 09:57:35 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:35 --> Input Class Initialized
INFO - 2020-10-08 09:57:35 --> Language Class Initialized
INFO - 2020-10-08 09:57:35 --> Loader Class Initialized
INFO - 2020-10-08 09:57:35 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:35 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:35 --> Email Class Initialized
INFO - 2020-10-08 09:57:35 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:35 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:35 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:35 --> Model Class Initialized
INFO - 2020-10-08 09:57:35 --> Model Class Initialized
INFO - 2020-10-08 09:57:35 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:35 --> Total execution time: 0.0222
ERROR - 2020-10-08 09:57:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:36 --> Config Class Initialized
INFO - 2020-10-08 09:57:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:36 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:36 --> URI Class Initialized
INFO - 2020-10-08 09:57:36 --> Router Class Initialized
INFO - 2020-10-08 09:57:36 --> Output Class Initialized
INFO - 2020-10-08 09:57:36 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:36 --> Input Class Initialized
INFO - 2020-10-08 09:57:36 --> Language Class Initialized
INFO - 2020-10-08 09:57:36 --> Loader Class Initialized
INFO - 2020-10-08 09:57:36 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:36 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:36 --> Email Class Initialized
INFO - 2020-10-08 09:57:36 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:36 --> Model Class Initialized
INFO - 2020-10-08 09:57:36 --> Model Class Initialized
INFO - 2020-10-08 09:57:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/rep_assign_list_for_client.php
INFO - 2020-10-08 09:57:36 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:36 --> Total execution time: 0.0334
ERROR - 2020-10-08 09:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:41 --> Config Class Initialized
INFO - 2020-10-08 09:57:41 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:41 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:41 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:41 --> URI Class Initialized
INFO - 2020-10-08 09:57:41 --> Router Class Initialized
INFO - 2020-10-08 09:57:41 --> Output Class Initialized
INFO - 2020-10-08 09:57:41 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:41 --> Input Class Initialized
INFO - 2020-10-08 09:57:41 --> Language Class Initialized
INFO - 2020-10-08 09:57:41 --> Loader Class Initialized
INFO - 2020-10-08 09:57:41 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:41 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:41 --> Email Class Initialized
INFO - 2020-10-08 09:57:41 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:41 --> Model Class Initialized
INFO - 2020-10-08 09:57:41 --> Model Class Initialized
INFO - 2020-10-08 09:57:41 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-08 09:57:41 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:41 --> Total execution time: 0.0272
ERROR - 2020-10-08 09:57:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:42 --> Config Class Initialized
INFO - 2020-10-08 09:57:42 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:42 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:42 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:42 --> URI Class Initialized
INFO - 2020-10-08 09:57:42 --> Router Class Initialized
INFO - 2020-10-08 09:57:42 --> Output Class Initialized
INFO - 2020-10-08 09:57:42 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:42 --> Input Class Initialized
INFO - 2020-10-08 09:57:42 --> Language Class Initialized
INFO - 2020-10-08 09:57:42 --> Loader Class Initialized
INFO - 2020-10-08 09:57:42 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:42 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:42 --> Email Class Initialized
INFO - 2020-10-08 09:57:42 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:42 --> Model Class Initialized
INFO - 2020-10-08 09:57:42 --> Model Class Initialized
INFO - 2020-10-08 09:57:42 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:42 --> Total execution time: 0.0233
ERROR - 2020-10-08 09:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:54 --> Config Class Initialized
INFO - 2020-10-08 09:57:54 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:54 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:54 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:54 --> URI Class Initialized
INFO - 2020-10-08 09:57:54 --> Router Class Initialized
INFO - 2020-10-08 09:57:54 --> Output Class Initialized
INFO - 2020-10-08 09:57:54 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:54 --> Input Class Initialized
INFO - 2020-10-08 09:57:54 --> Language Class Initialized
INFO - 2020-10-08 09:57:54 --> Loader Class Initialized
INFO - 2020-10-08 09:57:54 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:54 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:54 --> Email Class Initialized
INFO - 2020-10-08 09:57:54 --> Controller Class Initialized
DEBUG - 2020-10-08 09:57:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:57:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:54 --> Model Class Initialized
INFO - 2020-10-08 09:57:54 --> Model Class Initialized
INFO - 2020-10-08 09:57:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 09:57:54 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:54 --> Total execution time: 0.0200
ERROR - 2020-10-08 09:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:57:59 --> Config Class Initialized
INFO - 2020-10-08 09:57:59 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:57:59 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:57:59 --> Utf8 Class Initialized
INFO - 2020-10-08 09:57:59 --> URI Class Initialized
DEBUG - 2020-10-08 09:57:59 --> No URI present. Default controller set.
INFO - 2020-10-08 09:57:59 --> Router Class Initialized
INFO - 2020-10-08 09:57:59 --> Output Class Initialized
INFO - 2020-10-08 09:57:59 --> Security Class Initialized
DEBUG - 2020-10-08 09:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:57:59 --> Input Class Initialized
INFO - 2020-10-08 09:57:59 --> Language Class Initialized
INFO - 2020-10-08 09:57:59 --> Loader Class Initialized
INFO - 2020-10-08 09:57:59 --> Helper loaded: url_helper
INFO - 2020-10-08 09:57:59 --> Database Driver Class Initialized
INFO - 2020-10-08 09:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:57:59 --> Email Class Initialized
INFO - 2020-10-08 09:57:59 --> Controller Class Initialized
INFO - 2020-10-08 09:57:59 --> Model Class Initialized
INFO - 2020-10-08 09:57:59 --> Model Class Initialized
DEBUG - 2020-10-08 09:57:59 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:57:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 09:57:59 --> Final output sent to browser
DEBUG - 2020-10-08 09:57:59 --> Total execution time: 0.0198
ERROR - 2020-10-08 09:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:59:16 --> Config Class Initialized
INFO - 2020-10-08 09:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:59:16 --> Utf8 Class Initialized
INFO - 2020-10-08 09:59:16 --> URI Class Initialized
INFO - 2020-10-08 09:59:16 --> Router Class Initialized
INFO - 2020-10-08 09:59:16 --> Output Class Initialized
INFO - 2020-10-08 09:59:16 --> Security Class Initialized
DEBUG - 2020-10-08 09:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:59:16 --> Input Class Initialized
INFO - 2020-10-08 09:59:16 --> Language Class Initialized
INFO - 2020-10-08 09:59:16 --> Loader Class Initialized
INFO - 2020-10-08 09:59:16 --> Helper loaded: url_helper
INFO - 2020-10-08 09:59:16 --> Database Driver Class Initialized
INFO - 2020-10-08 09:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:59:16 --> Email Class Initialized
INFO - 2020-10-08 09:59:16 --> Controller Class Initialized
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
DEBUG - 2020-10-08 09:59:16 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 09:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:59:16 --> Config Class Initialized
INFO - 2020-10-08 09:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:59:16 --> Utf8 Class Initialized
INFO - 2020-10-08 09:59:16 --> URI Class Initialized
INFO - 2020-10-08 09:59:16 --> Router Class Initialized
INFO - 2020-10-08 09:59:16 --> Output Class Initialized
INFO - 2020-10-08 09:59:16 --> Security Class Initialized
DEBUG - 2020-10-08 09:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:59:16 --> Input Class Initialized
INFO - 2020-10-08 09:59:16 --> Language Class Initialized
INFO - 2020-10-08 09:59:16 --> Loader Class Initialized
INFO - 2020-10-08 09:59:16 --> Helper loaded: url_helper
INFO - 2020-10-08 09:59:16 --> Database Driver Class Initialized
INFO - 2020-10-08 09:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:59:16 --> Email Class Initialized
INFO - 2020-10-08 09:59:16 --> Controller Class Initialized
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
DEBUG - 2020-10-08 09:59:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:59:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
INFO - 2020-10-08 09:59:16 --> Final output sent to browser
DEBUG - 2020-10-08 09:59:16 --> Total execution time: 0.0224
ERROR - 2020-10-08 09:59:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:59:16 --> Config Class Initialized
INFO - 2020-10-08 09:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:59:16 --> Utf8 Class Initialized
INFO - 2020-10-08 09:59:16 --> URI Class Initialized
INFO - 2020-10-08 09:59:16 --> Router Class Initialized
INFO - 2020-10-08 09:59:16 --> Output Class Initialized
INFO - 2020-10-08 09:59:16 --> Security Class Initialized
DEBUG - 2020-10-08 09:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:59:16 --> Input Class Initialized
INFO - 2020-10-08 09:59:16 --> Language Class Initialized
INFO - 2020-10-08 09:59:16 --> Loader Class Initialized
INFO - 2020-10-08 09:59:16 --> Helper loaded: url_helper
INFO - 2020-10-08 09:59:16 --> Database Driver Class Initialized
INFO - 2020-10-08 09:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:59:16 --> Email Class Initialized
INFO - 2020-10-08 09:59:16 --> Controller Class Initialized
DEBUG - 2020-10-08 09:59:16 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:59:16 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
INFO - 2020-10-08 09:59:16 --> Model Class Initialized
INFO - 2020-10-08 09:59:16 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 09:59:16 --> Final output sent to browser
DEBUG - 2020-10-08 09:59:16 --> Total execution time: 0.0205
ERROR - 2020-10-08 09:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:59:40 --> Config Class Initialized
INFO - 2020-10-08 09:59:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:59:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:59:40 --> Utf8 Class Initialized
INFO - 2020-10-08 09:59:40 --> URI Class Initialized
INFO - 2020-10-08 09:59:40 --> Router Class Initialized
INFO - 2020-10-08 09:59:40 --> Output Class Initialized
INFO - 2020-10-08 09:59:40 --> Security Class Initialized
DEBUG - 2020-10-08 09:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:59:40 --> Input Class Initialized
INFO - 2020-10-08 09:59:40 --> Language Class Initialized
INFO - 2020-10-08 09:59:40 --> Loader Class Initialized
INFO - 2020-10-08 09:59:40 --> Helper loaded: url_helper
INFO - 2020-10-08 09:59:40 --> Database Driver Class Initialized
INFO - 2020-10-08 09:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:59:40 --> Email Class Initialized
INFO - 2020-10-08 09:59:40 --> Controller Class Initialized
DEBUG - 2020-10-08 09:59:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:59:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:59:40 --> Model Class Initialized
INFO - 2020-10-08 09:59:40 --> Model Class Initialized
INFO - 2020-10-08 09:59:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 09:59:40 --> Final output sent to browser
DEBUG - 2020-10-08 09:59:40 --> Total execution time: 0.0221
ERROR - 2020-10-08 09:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 09:59:59 --> Config Class Initialized
INFO - 2020-10-08 09:59:59 --> Hooks Class Initialized
DEBUG - 2020-10-08 09:59:59 --> UTF-8 Support Enabled
INFO - 2020-10-08 09:59:59 --> Utf8 Class Initialized
INFO - 2020-10-08 09:59:59 --> URI Class Initialized
INFO - 2020-10-08 09:59:59 --> Router Class Initialized
INFO - 2020-10-08 09:59:59 --> Output Class Initialized
INFO - 2020-10-08 09:59:59 --> Security Class Initialized
DEBUG - 2020-10-08 09:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 09:59:59 --> Input Class Initialized
INFO - 2020-10-08 09:59:59 --> Language Class Initialized
INFO - 2020-10-08 09:59:59 --> Loader Class Initialized
INFO - 2020-10-08 09:59:59 --> Helper loaded: url_helper
INFO - 2020-10-08 09:59:59 --> Database Driver Class Initialized
INFO - 2020-10-08 09:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 09:59:59 --> Email Class Initialized
INFO - 2020-10-08 09:59:59 --> Controller Class Initialized
DEBUG - 2020-10-08 09:59:59 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 09:59:59 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 09:59:59 --> Model Class Initialized
INFO - 2020-10-08 09:59:59 --> Model Class Initialized
INFO - 2020-10-08 09:59:59 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_view.php
INFO - 2020-10-08 09:59:59 --> Final output sent to browser
DEBUG - 2020-10-08 09:59:59 --> Total execution time: 0.0353
ERROR - 2020-10-08 10:00:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:04 --> Config Class Initialized
INFO - 2020-10-08 10:00:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:04 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:04 --> URI Class Initialized
INFO - 2020-10-08 10:00:04 --> Router Class Initialized
INFO - 2020-10-08 10:00:04 --> Output Class Initialized
INFO - 2020-10-08 10:00:04 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:04 --> Input Class Initialized
INFO - 2020-10-08 10:00:04 --> Language Class Initialized
INFO - 2020-10-08 10:00:04 --> Loader Class Initialized
INFO - 2020-10-08 10:00:04 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:04 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:04 --> Email Class Initialized
INFO - 2020-10-08 10:00:04 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:04 --> Model Class Initialized
INFO - 2020-10-08 10:00:04 --> Model Class Initialized
INFO - 2020-10-08 10:00:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 10:00:04 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:04 --> Total execution time: 0.0221
ERROR - 2020-10-08 10:00:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:06 --> Config Class Initialized
INFO - 2020-10-08 10:00:06 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:06 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:06 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:06 --> URI Class Initialized
INFO - 2020-10-08 10:00:06 --> Router Class Initialized
INFO - 2020-10-08 10:00:06 --> Output Class Initialized
INFO - 2020-10-08 10:00:06 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:06 --> Input Class Initialized
INFO - 2020-10-08 10:00:06 --> Language Class Initialized
INFO - 2020-10-08 10:00:06 --> Loader Class Initialized
INFO - 2020-10-08 10:00:06 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:06 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:07 --> Email Class Initialized
INFO - 2020-10-08 10:00:07 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:07 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:07 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:07 --> Model Class Initialized
INFO - 2020-10-08 10:00:07 --> Model Class Initialized
INFO - 2020-10-08 10:00:07 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_edit.php
INFO - 2020-10-08 10:00:07 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:07 --> Total execution time: 0.0407
ERROR - 2020-10-08 10:00:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:12 --> Config Class Initialized
INFO - 2020-10-08 10:00:12 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:12 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:12 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:12 --> URI Class Initialized
INFO - 2020-10-08 10:00:12 --> Router Class Initialized
INFO - 2020-10-08 10:00:12 --> Output Class Initialized
INFO - 2020-10-08 10:00:12 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:12 --> Input Class Initialized
INFO - 2020-10-08 10:00:12 --> Language Class Initialized
INFO - 2020-10-08 10:00:12 --> Loader Class Initialized
INFO - 2020-10-08 10:00:12 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:12 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:12 --> Email Class Initialized
INFO - 2020-10-08 10:00:12 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:12 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:12 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:12 --> Model Class Initialized
INFO - 2020-10-08 10:00:12 --> Model Class Initialized
INFO - 2020-10-08 10:00:12 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 10:00:12 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:12 --> Total execution time: 0.0239
ERROR - 2020-10-08 10:00:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:27 --> Config Class Initialized
INFO - 2020-10-08 10:00:27 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:27 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:27 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:27 --> URI Class Initialized
INFO - 2020-10-08 10:00:27 --> Router Class Initialized
INFO - 2020-10-08 10:00:27 --> Output Class Initialized
INFO - 2020-10-08 10:00:27 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:27 --> Input Class Initialized
INFO - 2020-10-08 10:00:27 --> Language Class Initialized
INFO - 2020-10-08 10:00:27 --> Loader Class Initialized
INFO - 2020-10-08 10:00:27 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:27 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:27 --> Email Class Initialized
INFO - 2020-10-08 10:00:27 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:27 --> Model Class Initialized
INFO - 2020-10-08 10:00:27 --> Model Class Initialized
INFO - 2020-10-08 10:00:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:00:27 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:27 --> Total execution time: 0.0231
ERROR - 2020-10-08 10:00:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:37 --> Config Class Initialized
INFO - 2020-10-08 10:00:37 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:37 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:37 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:37 --> URI Class Initialized
INFO - 2020-10-08 10:00:37 --> Router Class Initialized
INFO - 2020-10-08 10:00:37 --> Output Class Initialized
INFO - 2020-10-08 10:00:37 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:37 --> Input Class Initialized
INFO - 2020-10-08 10:00:37 --> Language Class Initialized
INFO - 2020-10-08 10:00:37 --> Loader Class Initialized
INFO - 2020-10-08 10:00:37 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:37 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:37 --> Email Class Initialized
INFO - 2020-10-08 10:00:37 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:37 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:37 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:37 --> Model Class Initialized
INFO - 2020-10-08 10:00:37 --> Model Class Initialized
INFO - 2020-10-08 10:00:37 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:00:37 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:37 --> Total execution time: 0.0232
ERROR - 2020-10-08 10:00:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:50 --> Config Class Initialized
INFO - 2020-10-08 10:00:50 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:50 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:50 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:50 --> URI Class Initialized
INFO - 2020-10-08 10:00:50 --> Router Class Initialized
INFO - 2020-10-08 10:00:50 --> Output Class Initialized
INFO - 2020-10-08 10:00:50 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:50 --> Input Class Initialized
INFO - 2020-10-08 10:00:50 --> Language Class Initialized
INFO - 2020-10-08 10:00:50 --> Loader Class Initialized
INFO - 2020-10-08 10:00:50 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:50 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:50 --> Email Class Initialized
INFO - 2020-10-08 10:00:50 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:50 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:50 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:50 --> Model Class Initialized
INFO - 2020-10-08 10:00:50 --> Model Class Initialized
INFO - 2020-10-08 10:00:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:00:50 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:50 --> Total execution time: 0.0248
ERROR - 2020-10-08 10:00:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:55 --> Config Class Initialized
INFO - 2020-10-08 10:00:55 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:55 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:55 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:55 --> URI Class Initialized
INFO - 2020-10-08 10:00:55 --> Router Class Initialized
INFO - 2020-10-08 10:00:55 --> Output Class Initialized
INFO - 2020-10-08 10:00:55 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:55 --> Input Class Initialized
INFO - 2020-10-08 10:00:55 --> Language Class Initialized
INFO - 2020-10-08 10:00:55 --> Loader Class Initialized
INFO - 2020-10-08 10:00:55 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:55 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:55 --> Email Class Initialized
INFO - 2020-10-08 10:00:55 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:55 --> Model Class Initialized
INFO - 2020-10-08 10:00:55 --> Model Class Initialized
INFO - 2020-10-08 10:00:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_add.php
INFO - 2020-10-08 10:00:55 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:55 --> Total execution time: 0.0345
ERROR - 2020-10-08 10:00:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:00:58 --> Config Class Initialized
INFO - 2020-10-08 10:00:58 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:00:58 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:00:58 --> Utf8 Class Initialized
INFO - 2020-10-08 10:00:58 --> URI Class Initialized
INFO - 2020-10-08 10:00:58 --> Router Class Initialized
INFO - 2020-10-08 10:00:58 --> Output Class Initialized
INFO - 2020-10-08 10:00:58 --> Security Class Initialized
DEBUG - 2020-10-08 10:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:00:58 --> Input Class Initialized
INFO - 2020-10-08 10:00:58 --> Language Class Initialized
INFO - 2020-10-08 10:00:58 --> Loader Class Initialized
INFO - 2020-10-08 10:00:58 --> Helper loaded: url_helper
INFO - 2020-10-08 10:00:58 --> Database Driver Class Initialized
INFO - 2020-10-08 10:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:00:58 --> Email Class Initialized
INFO - 2020-10-08 10:00:58 --> Controller Class Initialized
DEBUG - 2020-10-08 10:00:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:00:58 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:00:58 --> Model Class Initialized
INFO - 2020-10-08 10:00:58 --> Model Class Initialized
INFO - 2020-10-08 10:00:58 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:00:58 --> Final output sent to browser
DEBUG - 2020-10-08 10:00:58 --> Total execution time: 0.0212
ERROR - 2020-10-08 10:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:01:00 --> Config Class Initialized
INFO - 2020-10-08 10:01:00 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:01:00 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:01:00 --> Utf8 Class Initialized
INFO - 2020-10-08 10:01:00 --> URI Class Initialized
INFO - 2020-10-08 10:01:00 --> Router Class Initialized
INFO - 2020-10-08 10:01:00 --> Output Class Initialized
INFO - 2020-10-08 10:01:00 --> Security Class Initialized
DEBUG - 2020-10-08 10:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:01:00 --> Input Class Initialized
INFO - 2020-10-08 10:01:00 --> Language Class Initialized
INFO - 2020-10-08 10:01:00 --> Loader Class Initialized
INFO - 2020-10-08 10:01:00 --> Helper loaded: url_helper
INFO - 2020-10-08 10:01:00 --> Database Driver Class Initialized
INFO - 2020-10-08 10:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:01:00 --> Email Class Initialized
INFO - 2020-10-08 10:01:00 --> Controller Class Initialized
DEBUG - 2020-10-08 10:01:00 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:01:00 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:01:00 --> Model Class Initialized
INFO - 2020-10-08 10:01:00 --> Model Class Initialized
INFO - 2020-10-08 10:01:00 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-08 10:01:00 --> Final output sent to browser
DEBUG - 2020-10-08 10:01:00 --> Total execution time: 0.0382
ERROR - 2020-10-08 10:01:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:01:05 --> Config Class Initialized
INFO - 2020-10-08 10:01:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:01:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:01:05 --> Utf8 Class Initialized
INFO - 2020-10-08 10:01:05 --> URI Class Initialized
INFO - 2020-10-08 10:01:05 --> Router Class Initialized
INFO - 2020-10-08 10:01:05 --> Output Class Initialized
INFO - 2020-10-08 10:01:05 --> Security Class Initialized
DEBUG - 2020-10-08 10:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:01:05 --> Input Class Initialized
INFO - 2020-10-08 10:01:05 --> Language Class Initialized
INFO - 2020-10-08 10:01:05 --> Loader Class Initialized
INFO - 2020-10-08 10:01:05 --> Helper loaded: url_helper
INFO - 2020-10-08 10:01:05 --> Database Driver Class Initialized
INFO - 2020-10-08 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:01:05 --> Email Class Initialized
INFO - 2020-10-08 10:01:05 --> Controller Class Initialized
DEBUG - 2020-10-08 10:01:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:01:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:01:05 --> Model Class Initialized
INFO - 2020-10-08 10:01:05 --> Model Class Initialized
INFO - 2020-10-08 10:01:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:01:05 --> Final output sent to browser
DEBUG - 2020-10-08 10:01:05 --> Total execution time: 0.3430
ERROR - 2020-10-08 10:01:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:01:29 --> Config Class Initialized
INFO - 2020-10-08 10:01:29 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:01:29 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:01:29 --> Utf8 Class Initialized
INFO - 2020-10-08 10:01:29 --> URI Class Initialized
INFO - 2020-10-08 10:01:29 --> Router Class Initialized
INFO - 2020-10-08 10:01:29 --> Output Class Initialized
INFO - 2020-10-08 10:01:29 --> Security Class Initialized
DEBUG - 2020-10-08 10:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:01:29 --> Input Class Initialized
INFO - 2020-10-08 10:01:29 --> Language Class Initialized
INFO - 2020-10-08 10:01:29 --> Loader Class Initialized
INFO - 2020-10-08 10:01:29 --> Helper loaded: url_helper
INFO - 2020-10-08 10:01:29 --> Database Driver Class Initialized
INFO - 2020-10-08 10:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:01:29 --> Email Class Initialized
INFO - 2020-10-08 10:01:29 --> Controller Class Initialized
DEBUG - 2020-10-08 10:01:29 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:01:29 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:01:29 --> Model Class Initialized
INFO - 2020-10-08 10:01:29 --> Model Class Initialized
INFO - 2020-10-08 10:01:29 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:01:29 --> Final output sent to browser
DEBUG - 2020-10-08 10:01:29 --> Total execution time: 0.0214
ERROR - 2020-10-08 10:01:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:01:34 --> Config Class Initialized
INFO - 2020-10-08 10:01:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:01:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:01:34 --> Utf8 Class Initialized
INFO - 2020-10-08 10:01:34 --> URI Class Initialized
INFO - 2020-10-08 10:01:34 --> Router Class Initialized
INFO - 2020-10-08 10:01:34 --> Output Class Initialized
INFO - 2020-10-08 10:01:34 --> Security Class Initialized
DEBUG - 2020-10-08 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:01:34 --> Input Class Initialized
INFO - 2020-10-08 10:01:34 --> Language Class Initialized
INFO - 2020-10-08 10:01:34 --> Loader Class Initialized
INFO - 2020-10-08 10:01:34 --> Helper loaded: url_helper
INFO - 2020-10-08 10:01:34 --> Database Driver Class Initialized
INFO - 2020-10-08 10:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:01:34 --> Email Class Initialized
INFO - 2020-10-08 10:01:34 --> Controller Class Initialized
DEBUG - 2020-10-08 10:01:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:01:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:01:34 --> Model Class Initialized
INFO - 2020-10-08 10:01:34 --> Model Class Initialized
INFO - 2020-10-08 10:01:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_edit.php
INFO - 2020-10-08 10:01:34 --> Final output sent to browser
DEBUG - 2020-10-08 10:01:34 --> Total execution time: 0.0208
ERROR - 2020-10-08 10:01:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:01:36 --> Config Class Initialized
INFO - 2020-10-08 10:01:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:01:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:01:36 --> Utf8 Class Initialized
INFO - 2020-10-08 10:01:36 --> URI Class Initialized
INFO - 2020-10-08 10:01:36 --> Router Class Initialized
INFO - 2020-10-08 10:01:36 --> Output Class Initialized
INFO - 2020-10-08 10:01:36 --> Security Class Initialized
DEBUG - 2020-10-08 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:01:36 --> Input Class Initialized
INFO - 2020-10-08 10:01:36 --> Language Class Initialized
INFO - 2020-10-08 10:01:36 --> Loader Class Initialized
INFO - 2020-10-08 10:01:36 --> Helper loaded: url_helper
INFO - 2020-10-08 10:01:36 --> Database Driver Class Initialized
INFO - 2020-10-08 10:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:01:36 --> Email Class Initialized
INFO - 2020-10-08 10:01:36 --> Controller Class Initialized
DEBUG - 2020-10-08 10:01:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 10:01:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:01:36 --> Model Class Initialized
INFO - 2020-10-08 10:01:36 --> Model Class Initialized
INFO - 2020-10-08 10:01:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 10:01:36 --> Final output sent to browser
DEBUG - 2020-10-08 10:01:36 --> Total execution time: 0.0276
ERROR - 2020-10-08 10:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 10:01:50 --> Config Class Initialized
INFO - 2020-10-08 10:01:50 --> Hooks Class Initialized
DEBUG - 2020-10-08 10:01:50 --> UTF-8 Support Enabled
INFO - 2020-10-08 10:01:50 --> Utf8 Class Initialized
INFO - 2020-10-08 10:01:50 --> URI Class Initialized
DEBUG - 2020-10-08 10:01:50 --> No URI present. Default controller set.
INFO - 2020-10-08 10:01:50 --> Router Class Initialized
INFO - 2020-10-08 10:01:50 --> Output Class Initialized
INFO - 2020-10-08 10:01:50 --> Security Class Initialized
DEBUG - 2020-10-08 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 10:01:50 --> Input Class Initialized
INFO - 2020-10-08 10:01:50 --> Language Class Initialized
INFO - 2020-10-08 10:01:50 --> Loader Class Initialized
INFO - 2020-10-08 10:01:50 --> Helper loaded: url_helper
INFO - 2020-10-08 10:01:50 --> Database Driver Class Initialized
INFO - 2020-10-08 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 10:01:50 --> Email Class Initialized
INFO - 2020-10-08 10:01:50 --> Controller Class Initialized
INFO - 2020-10-08 10:01:50 --> Model Class Initialized
INFO - 2020-10-08 10:01:50 --> Model Class Initialized
DEBUG - 2020-10-08 10:01:50 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 10:01:50 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 10:01:50 --> Final output sent to browser
DEBUG - 2020-10-08 10:01:50 --> Total execution time: 0.0171
ERROR - 2020-10-08 16:47:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 16:47:34 --> Config Class Initialized
INFO - 2020-10-08 16:47:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 16:47:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 16:47:34 --> Utf8 Class Initialized
INFO - 2020-10-08 16:47:34 --> URI Class Initialized
DEBUG - 2020-10-08 16:47:34 --> No URI present. Default controller set.
INFO - 2020-10-08 16:47:34 --> Router Class Initialized
INFO - 2020-10-08 16:47:34 --> Output Class Initialized
INFO - 2020-10-08 16:47:34 --> Security Class Initialized
DEBUG - 2020-10-08 16:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 16:47:34 --> Input Class Initialized
INFO - 2020-10-08 16:47:34 --> Language Class Initialized
INFO - 2020-10-08 16:47:34 --> Loader Class Initialized
INFO - 2020-10-08 16:47:34 --> Helper loaded: url_helper
INFO - 2020-10-08 16:47:34 --> Database Driver Class Initialized
INFO - 2020-10-08 16:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 16:47:34 --> Email Class Initialized
INFO - 2020-10-08 16:47:34 --> Controller Class Initialized
INFO - 2020-10-08 16:47:34 --> Model Class Initialized
INFO - 2020-10-08 16:47:34 --> Model Class Initialized
DEBUG - 2020-10-08 16:47:34 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 16:47:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 16:47:34 --> Final output sent to browser
DEBUG - 2020-10-08 16:47:34 --> Total execution time: 0.0228
ERROR - 2020-10-08 16:55:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 16:55:57 --> Config Class Initialized
INFO - 2020-10-08 16:55:57 --> Hooks Class Initialized
DEBUG - 2020-10-08 16:55:57 --> UTF-8 Support Enabled
INFO - 2020-10-08 16:55:57 --> Utf8 Class Initialized
INFO - 2020-10-08 16:55:57 --> URI Class Initialized
INFO - 2020-10-08 16:55:57 --> Router Class Initialized
INFO - 2020-10-08 16:55:57 --> Output Class Initialized
INFO - 2020-10-08 16:55:57 --> Security Class Initialized
DEBUG - 2020-10-08 16:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 16:55:57 --> Input Class Initialized
INFO - 2020-10-08 16:55:57 --> Language Class Initialized
INFO - 2020-10-08 16:55:57 --> Loader Class Initialized
INFO - 2020-10-08 16:55:57 --> Helper loaded: url_helper
INFO - 2020-10-08 16:55:57 --> Database Driver Class Initialized
INFO - 2020-10-08 16:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 16:55:57 --> Email Class Initialized
INFO - 2020-10-08 16:55:57 --> Controller Class Initialized
INFO - 2020-10-08 16:55:57 --> Model Class Initialized
INFO - 2020-10-08 16:55:57 --> Model Class Initialized
DEBUG - 2020-10-08 16:55:57 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 16:55:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 16:55:58 --> Config Class Initialized
INFO - 2020-10-08 16:55:58 --> Hooks Class Initialized
DEBUG - 2020-10-08 16:55:58 --> UTF-8 Support Enabled
INFO - 2020-10-08 16:55:58 --> Utf8 Class Initialized
INFO - 2020-10-08 16:55:58 --> URI Class Initialized
INFO - 2020-10-08 16:55:58 --> Router Class Initialized
INFO - 2020-10-08 16:55:58 --> Output Class Initialized
INFO - 2020-10-08 16:55:58 --> Security Class Initialized
DEBUG - 2020-10-08 16:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 16:55:58 --> Input Class Initialized
INFO - 2020-10-08 16:55:58 --> Language Class Initialized
INFO - 2020-10-08 16:55:58 --> Loader Class Initialized
INFO - 2020-10-08 16:55:58 --> Helper loaded: url_helper
INFO - 2020-10-08 16:55:58 --> Database Driver Class Initialized
INFO - 2020-10-08 16:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 16:55:58 --> Email Class Initialized
INFO - 2020-10-08 16:55:58 --> Controller Class Initialized
INFO - 2020-10-08 16:55:58 --> Model Class Initialized
INFO - 2020-10-08 16:55:58 --> Model Class Initialized
DEBUG - 2020-10-08 16:55:58 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 16:55:58 --> Email class already loaded. Second attempt ignored.
ERROR - 2020-10-08 16:56:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 16:56:01 --> Config Class Initialized
INFO - 2020-10-08 16:56:01 --> Hooks Class Initialized
DEBUG - 2020-10-08 16:56:01 --> UTF-8 Support Enabled
INFO - 2020-10-08 16:56:01 --> Utf8 Class Initialized
INFO - 2020-10-08 16:56:01 --> URI Class Initialized
INFO - 2020-10-08 16:56:01 --> Router Class Initialized
INFO - 2020-10-08 16:56:01 --> Output Class Initialized
INFO - 2020-10-08 16:56:01 --> Security Class Initialized
DEBUG - 2020-10-08 16:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 16:56:01 --> Input Class Initialized
INFO - 2020-10-08 16:56:01 --> Language Class Initialized
INFO - 2020-10-08 16:56:01 --> Loader Class Initialized
INFO - 2020-10-08 16:56:01 --> Helper loaded: url_helper
INFO - 2020-10-08 16:56:01 --> Database Driver Class Initialized
INFO - 2020-10-08 16:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 16:56:01 --> Email Class Initialized
INFO - 2020-10-08 16:56:01 --> Controller Class Initialized
INFO - 2020-10-08 16:56:01 --> Model Class Initialized
INFO - 2020-10-08 16:56:01 --> Model Class Initialized
DEBUG - 2020-10-08 16:56:01 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 16:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 16:56:04 --> Config Class Initialized
INFO - 2020-10-08 16:56:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 16:56:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 16:56:04 --> Utf8 Class Initialized
INFO - 2020-10-08 16:56:04 --> URI Class Initialized
INFO - 2020-10-08 16:56:04 --> Router Class Initialized
INFO - 2020-10-08 16:56:04 --> Output Class Initialized
INFO - 2020-10-08 16:56:04 --> Security Class Initialized
DEBUG - 2020-10-08 16:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 16:56:04 --> Input Class Initialized
INFO - 2020-10-08 16:56:04 --> Language Class Initialized
INFO - 2020-10-08 16:56:04 --> Loader Class Initialized
INFO - 2020-10-08 16:56:04 --> Helper loaded: url_helper
INFO - 2020-10-08 16:56:04 --> Database Driver Class Initialized
INFO - 2020-10-08 16:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 16:56:04 --> Email Class Initialized
INFO - 2020-10-08 16:56:04 --> Controller Class Initialized
DEBUG - 2020-10-08 16:56:04 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 16:56:04 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 16:56:04 --> Model Class Initialized
INFO - 2020-10-08 16:56:04 --> Model Class Initialized
INFO - 2020-10-08 16:56:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 16:56:04 --> Final output sent to browser
DEBUG - 2020-10-08 16:56:04 --> Total execution time: 0.0577
ERROR - 2020-10-08 16:56:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 16:56:05 --> Config Class Initialized
INFO - 2020-10-08 16:56:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 16:56:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 16:56:05 --> Utf8 Class Initialized
INFO - 2020-10-08 16:56:05 --> URI Class Initialized
DEBUG - 2020-10-08 16:56:05 --> No URI present. Default controller set.
INFO - 2020-10-08 16:56:05 --> Router Class Initialized
INFO - 2020-10-08 16:56:05 --> Output Class Initialized
INFO - 2020-10-08 16:56:05 --> Security Class Initialized
DEBUG - 2020-10-08 16:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 16:56:05 --> Input Class Initialized
INFO - 2020-10-08 16:56:05 --> Language Class Initialized
INFO - 2020-10-08 16:56:05 --> Loader Class Initialized
INFO - 2020-10-08 16:56:05 --> Helper loaded: url_helper
INFO - 2020-10-08 16:56:05 --> Database Driver Class Initialized
INFO - 2020-10-08 16:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 16:56:05 --> Email Class Initialized
INFO - 2020-10-08 16:56:05 --> Controller Class Initialized
INFO - 2020-10-08 16:56:05 --> Model Class Initialized
INFO - 2020-10-08 16:56:05 --> Model Class Initialized
DEBUG - 2020-10-08 16:56:05 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 16:56:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 16:56:05 --> Final output sent to browser
DEBUG - 2020-10-08 16:56:05 --> Total execution time: 0.0228
ERROR - 2020-10-08 17:07:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:07:17 --> Config Class Initialized
INFO - 2020-10-08 17:07:17 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:07:17 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:07:17 --> Utf8 Class Initialized
INFO - 2020-10-08 17:07:17 --> URI Class Initialized
DEBUG - 2020-10-08 17:07:17 --> No URI present. Default controller set.
INFO - 2020-10-08 17:07:17 --> Router Class Initialized
INFO - 2020-10-08 17:07:17 --> Output Class Initialized
INFO - 2020-10-08 17:07:17 --> Security Class Initialized
DEBUG - 2020-10-08 17:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:07:17 --> Input Class Initialized
INFO - 2020-10-08 17:07:17 --> Language Class Initialized
INFO - 2020-10-08 17:07:17 --> Loader Class Initialized
INFO - 2020-10-08 17:07:17 --> Helper loaded: url_helper
INFO - 2020-10-08 17:07:17 --> Database Driver Class Initialized
INFO - 2020-10-08 17:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:07:17 --> Email Class Initialized
INFO - 2020-10-08 17:07:17 --> Controller Class Initialized
INFO - 2020-10-08 17:07:17 --> Model Class Initialized
INFO - 2020-10-08 17:07:17 --> Model Class Initialized
DEBUG - 2020-10-08 17:07:17 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:07:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 17:07:17 --> Final output sent to browser
DEBUG - 2020-10-08 17:07:17 --> Total execution time: 0.0201
ERROR - 2020-10-08 17:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:10:20 --> Config Class Initialized
INFO - 2020-10-08 17:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:10:20 --> Utf8 Class Initialized
INFO - 2020-10-08 17:10:20 --> URI Class Initialized
INFO - 2020-10-08 17:10:20 --> Router Class Initialized
INFO - 2020-10-08 17:10:20 --> Output Class Initialized
INFO - 2020-10-08 17:10:20 --> Security Class Initialized
DEBUG - 2020-10-08 17:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:10:20 --> Input Class Initialized
INFO - 2020-10-08 17:10:20 --> Language Class Initialized
INFO - 2020-10-08 17:10:20 --> Loader Class Initialized
INFO - 2020-10-08 17:10:20 --> Helper loaded: url_helper
INFO - 2020-10-08 17:10:20 --> Database Driver Class Initialized
INFO - 2020-10-08 17:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:10:20 --> Email Class Initialized
INFO - 2020-10-08 17:10:20 --> Controller Class Initialized
INFO - 2020-10-08 17:10:20 --> Model Class Initialized
INFO - 2020-10-08 17:10:20 --> Model Class Initialized
DEBUG - 2020-10-08 17:10:20 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 17:10:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:10:20 --> Config Class Initialized
INFO - 2020-10-08 17:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:10:20 --> Utf8 Class Initialized
INFO - 2020-10-08 17:10:20 --> URI Class Initialized
INFO - 2020-10-08 17:10:20 --> Router Class Initialized
INFO - 2020-10-08 17:10:20 --> Output Class Initialized
INFO - 2020-10-08 17:10:20 --> Security Class Initialized
DEBUG - 2020-10-08 17:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:10:20 --> Input Class Initialized
INFO - 2020-10-08 17:10:20 --> Language Class Initialized
INFO - 2020-10-08 17:10:20 --> Loader Class Initialized
INFO - 2020-10-08 17:10:20 --> Helper loaded: url_helper
INFO - 2020-10-08 17:10:20 --> Database Driver Class Initialized
INFO - 2020-10-08 17:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:10:20 --> Email Class Initialized
INFO - 2020-10-08 17:10:20 --> Controller Class Initialized
INFO - 2020-10-08 17:10:20 --> Model Class Initialized
INFO - 2020-10-08 17:10:20 --> Model Class Initialized
DEBUG - 2020-10-08 17:10:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:10:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:10:20 --> Model Class Initialized
INFO - 2020-10-08 17:10:20 --> Final output sent to browser
DEBUG - 2020-10-08 17:10:20 --> Total execution time: 0.0195
ERROR - 2020-10-08 17:10:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:10:21 --> Config Class Initialized
INFO - 2020-10-08 17:10:21 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:10:21 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:10:21 --> Utf8 Class Initialized
INFO - 2020-10-08 17:10:21 --> URI Class Initialized
INFO - 2020-10-08 17:10:21 --> Router Class Initialized
INFO - 2020-10-08 17:10:21 --> Output Class Initialized
INFO - 2020-10-08 17:10:21 --> Security Class Initialized
DEBUG - 2020-10-08 17:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:10:21 --> Input Class Initialized
INFO - 2020-10-08 17:10:21 --> Language Class Initialized
INFO - 2020-10-08 17:10:21 --> Loader Class Initialized
INFO - 2020-10-08 17:10:21 --> Helper loaded: url_helper
INFO - 2020-10-08 17:10:21 --> Database Driver Class Initialized
INFO - 2020-10-08 17:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:10:21 --> Email Class Initialized
INFO - 2020-10-08 17:10:21 --> Controller Class Initialized
DEBUG - 2020-10-08 17:10:21 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:10:21 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:10:21 --> Model Class Initialized
INFO - 2020-10-08 17:10:21 --> Model Class Initialized
INFO - 2020-10-08 17:10:21 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 17:10:21 --> Final output sent to browser
DEBUG - 2020-10-08 17:10:21 --> Total execution time: 0.0209
ERROR - 2020-10-08 17:11:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:11:22 --> Config Class Initialized
INFO - 2020-10-08 17:11:22 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:11:22 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:11:22 --> Utf8 Class Initialized
INFO - 2020-10-08 17:11:22 --> URI Class Initialized
DEBUG - 2020-10-08 17:11:22 --> No URI present. Default controller set.
INFO - 2020-10-08 17:11:22 --> Router Class Initialized
INFO - 2020-10-08 17:11:22 --> Output Class Initialized
INFO - 2020-10-08 17:11:22 --> Security Class Initialized
DEBUG - 2020-10-08 17:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:11:22 --> Input Class Initialized
INFO - 2020-10-08 17:11:22 --> Language Class Initialized
INFO - 2020-10-08 17:11:22 --> Loader Class Initialized
INFO - 2020-10-08 17:11:22 --> Helper loaded: url_helper
INFO - 2020-10-08 17:11:22 --> Database Driver Class Initialized
INFO - 2020-10-08 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:11:22 --> Email Class Initialized
INFO - 2020-10-08 17:11:22 --> Controller Class Initialized
INFO - 2020-10-08 17:11:22 --> Model Class Initialized
INFO - 2020-10-08 17:11:22 --> Model Class Initialized
DEBUG - 2020-10-08 17:11:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:11:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 17:11:22 --> Final output sent to browser
DEBUG - 2020-10-08 17:11:22 --> Total execution time: 0.0231
ERROR - 2020-10-08 17:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:11:32 --> Config Class Initialized
INFO - 2020-10-08 17:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:11:32 --> Utf8 Class Initialized
INFO - 2020-10-08 17:11:32 --> URI Class Initialized
INFO - 2020-10-08 17:11:32 --> Router Class Initialized
INFO - 2020-10-08 17:11:32 --> Output Class Initialized
INFO - 2020-10-08 17:11:32 --> Security Class Initialized
DEBUG - 2020-10-08 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:11:32 --> Input Class Initialized
INFO - 2020-10-08 17:11:32 --> Language Class Initialized
INFO - 2020-10-08 17:11:32 --> Loader Class Initialized
INFO - 2020-10-08 17:11:32 --> Helper loaded: url_helper
INFO - 2020-10-08 17:11:32 --> Database Driver Class Initialized
INFO - 2020-10-08 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:11:32 --> Email Class Initialized
INFO - 2020-10-08 17:11:32 --> Controller Class Initialized
INFO - 2020-10-08 17:11:32 --> Model Class Initialized
INFO - 2020-10-08 17:11:32 --> Model Class Initialized
DEBUG - 2020-10-08 17:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:11:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:11:32 --> Model Class Initialized
INFO - 2020-10-08 17:11:32 --> Final output sent to browser
DEBUG - 2020-10-08 17:11:32 --> Total execution time: 0.0252
ERROR - 2020-10-08 17:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:11:32 --> Config Class Initialized
INFO - 2020-10-08 17:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:11:32 --> Utf8 Class Initialized
INFO - 2020-10-08 17:11:32 --> URI Class Initialized
INFO - 2020-10-08 17:11:32 --> Router Class Initialized
INFO - 2020-10-08 17:11:32 --> Output Class Initialized
INFO - 2020-10-08 17:11:32 --> Security Class Initialized
DEBUG - 2020-10-08 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:11:32 --> Input Class Initialized
INFO - 2020-10-08 17:11:32 --> Language Class Initialized
INFO - 2020-10-08 17:11:32 --> Loader Class Initialized
INFO - 2020-10-08 17:11:32 --> Helper loaded: url_helper
INFO - 2020-10-08 17:11:32 --> Database Driver Class Initialized
INFO - 2020-10-08 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:11:32 --> Email Class Initialized
INFO - 2020-10-08 17:11:32 --> Controller Class Initialized
INFO - 2020-10-08 17:11:32 --> Model Class Initialized
INFO - 2020-10-08 17:11:32 --> Model Class Initialized
DEBUG - 2020-10-08 17:11:32 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 17:11:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:11:32 --> Config Class Initialized
INFO - 2020-10-08 17:11:32 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:11:32 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:11:32 --> Utf8 Class Initialized
INFO - 2020-10-08 17:11:32 --> URI Class Initialized
INFO - 2020-10-08 17:11:32 --> Router Class Initialized
INFO - 2020-10-08 17:11:32 --> Output Class Initialized
INFO - 2020-10-08 17:11:32 --> Security Class Initialized
DEBUG - 2020-10-08 17:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:11:32 --> Input Class Initialized
INFO - 2020-10-08 17:11:32 --> Language Class Initialized
INFO - 2020-10-08 17:11:32 --> Loader Class Initialized
INFO - 2020-10-08 17:11:32 --> Helper loaded: url_helper
INFO - 2020-10-08 17:11:32 --> Database Driver Class Initialized
INFO - 2020-10-08 17:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:11:32 --> Email Class Initialized
INFO - 2020-10-08 17:11:32 --> Controller Class Initialized
DEBUG - 2020-10-08 17:11:32 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:11:32 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:11:32 --> Model Class Initialized
INFO - 2020-10-08 17:11:33 --> Model Class Initialized
INFO - 2020-10-08 17:11:33 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 17:11:33 --> Final output sent to browser
DEBUG - 2020-10-08 17:11:33 --> Total execution time: 0.0633
ERROR - 2020-10-08 17:26:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:26:18 --> Config Class Initialized
INFO - 2020-10-08 17:26:18 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:26:18 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:26:18 --> Utf8 Class Initialized
INFO - 2020-10-08 17:26:18 --> URI Class Initialized
INFO - 2020-10-08 17:26:18 --> Router Class Initialized
INFO - 2020-10-08 17:26:18 --> Output Class Initialized
INFO - 2020-10-08 17:26:18 --> Security Class Initialized
DEBUG - 2020-10-08 17:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:26:18 --> Input Class Initialized
INFO - 2020-10-08 17:26:18 --> Language Class Initialized
INFO - 2020-10-08 17:26:18 --> Loader Class Initialized
INFO - 2020-10-08 17:26:18 --> Helper loaded: url_helper
INFO - 2020-10-08 17:26:18 --> Database Driver Class Initialized
INFO - 2020-10-08 17:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:26:18 --> Email Class Initialized
INFO - 2020-10-08 17:26:18 --> Controller Class Initialized
DEBUG - 2020-10-08 17:26:18 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:26:18 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:26:18 --> Model Class Initialized
INFO - 2020-10-08 17:26:18 --> Model Class Initialized
INFO - 2020-10-08 17:26:18 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 17:26:18 --> Final output sent to browser
DEBUG - 2020-10-08 17:26:18 --> Total execution time: 0.0240
ERROR - 2020-10-08 17:26:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:26:44 --> Config Class Initialized
INFO - 2020-10-08 17:26:44 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:26:44 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:26:44 --> Utf8 Class Initialized
INFO - 2020-10-08 17:26:44 --> URI Class Initialized
INFO - 2020-10-08 17:26:44 --> Router Class Initialized
INFO - 2020-10-08 17:26:44 --> Output Class Initialized
INFO - 2020-10-08 17:26:44 --> Security Class Initialized
DEBUG - 2020-10-08 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:26:44 --> Input Class Initialized
INFO - 2020-10-08 17:26:44 --> Language Class Initialized
INFO - 2020-10-08 17:26:44 --> Loader Class Initialized
INFO - 2020-10-08 17:26:44 --> Helper loaded: url_helper
INFO - 2020-10-08 17:26:44 --> Database Driver Class Initialized
INFO - 2020-10-08 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:26:44 --> Email Class Initialized
INFO - 2020-10-08 17:26:44 --> Controller Class Initialized
DEBUG - 2020-10-08 17:26:44 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:26:44 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:26:44 --> Model Class Initialized
INFO - 2020-10-08 17:26:44 --> Model Class Initialized
INFO - 2020-10-08 17:26:44 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 17:26:44 --> Final output sent to browser
DEBUG - 2020-10-08 17:26:44 --> Total execution time: 0.0266
ERROR - 2020-10-08 17:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:37:04 --> Config Class Initialized
INFO - 2020-10-08 17:37:04 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:37:04 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:37:04 --> Utf8 Class Initialized
INFO - 2020-10-08 17:37:04 --> URI Class Initialized
DEBUG - 2020-10-08 17:37:04 --> No URI present. Default controller set.
INFO - 2020-10-08 17:37:04 --> Router Class Initialized
INFO - 2020-10-08 17:37:04 --> Output Class Initialized
INFO - 2020-10-08 17:37:04 --> Security Class Initialized
DEBUG - 2020-10-08 17:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:37:04 --> Input Class Initialized
INFO - 2020-10-08 17:37:04 --> Language Class Initialized
INFO - 2020-10-08 17:37:04 --> Loader Class Initialized
INFO - 2020-10-08 17:37:04 --> Helper loaded: url_helper
INFO - 2020-10-08 17:37:04 --> Database Driver Class Initialized
INFO - 2020-10-08 17:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:37:04 --> Email Class Initialized
INFO - 2020-10-08 17:37:04 --> Controller Class Initialized
INFO - 2020-10-08 17:37:04 --> Model Class Initialized
INFO - 2020-10-08 17:37:04 --> Model Class Initialized
DEBUG - 2020-10-08 17:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:37:04 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 17:37:04 --> Final output sent to browser
DEBUG - 2020-10-08 17:37:04 --> Total execution time: 0.0260
ERROR - 2020-10-08 17:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:37:36 --> Config Class Initialized
INFO - 2020-10-08 17:37:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:37:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:37:36 --> Utf8 Class Initialized
INFO - 2020-10-08 17:37:36 --> URI Class Initialized
INFO - 2020-10-08 17:37:36 --> Router Class Initialized
INFO - 2020-10-08 17:37:36 --> Output Class Initialized
INFO - 2020-10-08 17:37:36 --> Security Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:37:36 --> Input Class Initialized
INFO - 2020-10-08 17:37:36 --> Language Class Initialized
INFO - 2020-10-08 17:37:36 --> Loader Class Initialized
INFO - 2020-10-08 17:37:36 --> Helper loaded: url_helper
INFO - 2020-10-08 17:37:36 --> Database Driver Class Initialized
ERROR - 2020-10-08 17:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:37:36 --> Config Class Initialized
INFO - 2020-10-08 17:37:36 --> Hooks Class Initialized
INFO - 2020-10-08 17:37:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-08 17:37:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:37:36 --> Utf8 Class Initialized
INFO - 2020-10-08 17:37:36 --> URI Class Initialized
INFO - 2020-10-08 17:37:36 --> Router Class Initialized
INFO - 2020-10-08 17:37:36 --> Email Class Initialized
INFO - 2020-10-08 17:37:36 --> Controller Class Initialized
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
INFO - 2020-10-08 17:37:36 --> Output Class Initialized
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:37:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
INFO - 2020-10-08 17:37:36 --> Security Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:37:36 --> Input Class Initialized
INFO - 2020-10-08 17:37:36 --> Language Class Initialized
INFO - 2020-10-08 17:37:36 --> Final output sent to browser
INFO - 2020-10-08 17:37:36 --> Loader Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Total execution time: 0.0228
INFO - 2020-10-08 17:37:36 --> Helper loaded: url_helper
INFO - 2020-10-08 17:37:36 --> Database Driver Class Initialized
INFO - 2020-10-08 17:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:37:36 --> Email Class Initialized
INFO - 2020-10-08 17:37:36 --> Controller Class Initialized
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 17:37:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:37:36 --> Config Class Initialized
INFO - 2020-10-08 17:37:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:37:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:37:36 --> Utf8 Class Initialized
INFO - 2020-10-08 17:37:36 --> URI Class Initialized
INFO - 2020-10-08 17:37:36 --> Router Class Initialized
INFO - 2020-10-08 17:37:36 --> Output Class Initialized
INFO - 2020-10-08 17:37:36 --> Security Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:37:36 --> Input Class Initialized
INFO - 2020-10-08 17:37:36 --> Language Class Initialized
INFO - 2020-10-08 17:37:36 --> Loader Class Initialized
INFO - 2020-10-08 17:37:36 --> Helper loaded: url_helper
INFO - 2020-10-08 17:37:36 --> Database Driver Class Initialized
INFO - 2020-10-08 17:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:37:36 --> Email Class Initialized
INFO - 2020-10-08 17:37:36 --> Controller Class Initialized
DEBUG - 2020-10-08 17:37:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:37:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
INFO - 2020-10-08 17:37:36 --> Model Class Initialized
INFO - 2020-10-08 17:37:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 17:37:36 --> Final output sent to browser
DEBUG - 2020-10-08 17:37:36 --> Total execution time: 0.0666
ERROR - 2020-10-08 17:58:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:58:28 --> Config Class Initialized
INFO - 2020-10-08 17:58:28 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:58:28 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:58:28 --> Utf8 Class Initialized
INFO - 2020-10-08 17:58:28 --> URI Class Initialized
INFO - 2020-10-08 17:58:28 --> Router Class Initialized
INFO - 2020-10-08 17:58:28 --> Output Class Initialized
INFO - 2020-10-08 17:58:28 --> Security Class Initialized
DEBUG - 2020-10-08 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:58:28 --> Input Class Initialized
INFO - 2020-10-08 17:58:28 --> Language Class Initialized
INFO - 2020-10-08 17:58:28 --> Loader Class Initialized
INFO - 2020-10-08 17:58:28 --> Helper loaded: url_helper
INFO - 2020-10-08 17:58:28 --> Database Driver Class Initialized
INFO - 2020-10-08 17:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:58:28 --> Email Class Initialized
INFO - 2020-10-08 17:58:28 --> Controller Class Initialized
DEBUG - 2020-10-08 17:58:28 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:58:28 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:58:28 --> Model Class Initialized
INFO - 2020-10-08 17:58:28 --> Model Class Initialized
INFO - 2020-10-08 17:58:28 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 17:58:28 --> Final output sent to browser
DEBUG - 2020-10-08 17:58:28 --> Total execution time: 0.0259
ERROR - 2020-10-08 17:59:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 17:59:55 --> Config Class Initialized
INFO - 2020-10-08 17:59:55 --> Hooks Class Initialized
DEBUG - 2020-10-08 17:59:55 --> UTF-8 Support Enabled
INFO - 2020-10-08 17:59:55 --> Utf8 Class Initialized
INFO - 2020-10-08 17:59:55 --> URI Class Initialized
INFO - 2020-10-08 17:59:55 --> Router Class Initialized
INFO - 2020-10-08 17:59:55 --> Output Class Initialized
INFO - 2020-10-08 17:59:55 --> Security Class Initialized
DEBUG - 2020-10-08 17:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 17:59:55 --> Input Class Initialized
INFO - 2020-10-08 17:59:55 --> Language Class Initialized
INFO - 2020-10-08 17:59:55 --> Loader Class Initialized
INFO - 2020-10-08 17:59:55 --> Helper loaded: url_helper
INFO - 2020-10-08 17:59:55 --> Database Driver Class Initialized
INFO - 2020-10-08 17:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 17:59:55 --> Email Class Initialized
INFO - 2020-10-08 17:59:55 --> Controller Class Initialized
DEBUG - 2020-10-08 17:59:55 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 17:59:55 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 17:59:55 --> Model Class Initialized
INFO - 2020-10-08 17:59:55 --> Model Class Initialized
INFO - 2020-10-08 17:59:55 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 17:59:55 --> Final output sent to browser
DEBUG - 2020-10-08 17:59:55 --> Total execution time: 0.0260
ERROR - 2020-10-08 18:01:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:01:27 --> Config Class Initialized
INFO - 2020-10-08 18:01:27 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:01:27 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:01:27 --> Utf8 Class Initialized
INFO - 2020-10-08 18:01:27 --> URI Class Initialized
INFO - 2020-10-08 18:01:27 --> Router Class Initialized
INFO - 2020-10-08 18:01:27 --> Output Class Initialized
INFO - 2020-10-08 18:01:27 --> Security Class Initialized
DEBUG - 2020-10-08 18:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:01:27 --> Input Class Initialized
INFO - 2020-10-08 18:01:27 --> Language Class Initialized
INFO - 2020-10-08 18:01:27 --> Loader Class Initialized
INFO - 2020-10-08 18:01:27 --> Helper loaded: url_helper
INFO - 2020-10-08 18:01:27 --> Database Driver Class Initialized
INFO - 2020-10-08 18:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:01:27 --> Email Class Initialized
INFO - 2020-10-08 18:01:27 --> Controller Class Initialized
DEBUG - 2020-10-08 18:01:27 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:01:27 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:01:27 --> Model Class Initialized
INFO - 2020-10-08 18:01:27 --> Model Class Initialized
INFO - 2020-10-08 18:01:27 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 18:01:27 --> Final output sent to browser
DEBUG - 2020-10-08 18:01:27 --> Total execution time: 0.0222
ERROR - 2020-10-08 18:02:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:02:34 --> Config Class Initialized
INFO - 2020-10-08 18:02:34 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:02:34 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:02:34 --> Utf8 Class Initialized
INFO - 2020-10-08 18:02:34 --> URI Class Initialized
INFO - 2020-10-08 18:02:34 --> Router Class Initialized
INFO - 2020-10-08 18:02:34 --> Output Class Initialized
INFO - 2020-10-08 18:02:34 --> Security Class Initialized
DEBUG - 2020-10-08 18:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:02:34 --> Input Class Initialized
INFO - 2020-10-08 18:02:34 --> Language Class Initialized
INFO - 2020-10-08 18:02:34 --> Loader Class Initialized
INFO - 2020-10-08 18:02:34 --> Helper loaded: url_helper
INFO - 2020-10-08 18:02:34 --> Database Driver Class Initialized
INFO - 2020-10-08 18:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:02:34 --> Email Class Initialized
INFO - 2020-10-08 18:02:34 --> Controller Class Initialized
DEBUG - 2020-10-08 18:02:34 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:02:34 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:02:34 --> Model Class Initialized
INFO - 2020-10-08 18:02:34 --> Model Class Initialized
INFO - 2020-10-08 18:02:34 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 18:02:34 --> Final output sent to browser
DEBUG - 2020-10-08 18:02:34 --> Total execution time: 0.0235
ERROR - 2020-10-08 18:05:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:05:43 --> Config Class Initialized
INFO - 2020-10-08 18:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:05:43 --> Utf8 Class Initialized
INFO - 2020-10-08 18:05:43 --> URI Class Initialized
INFO - 2020-10-08 18:05:43 --> Router Class Initialized
INFO - 2020-10-08 18:05:43 --> Output Class Initialized
INFO - 2020-10-08 18:05:43 --> Security Class Initialized
DEBUG - 2020-10-08 18:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:05:43 --> Input Class Initialized
INFO - 2020-10-08 18:05:43 --> Language Class Initialized
INFO - 2020-10-08 18:05:43 --> Loader Class Initialized
INFO - 2020-10-08 18:05:43 --> Helper loaded: url_helper
INFO - 2020-10-08 18:05:43 --> Database Driver Class Initialized
INFO - 2020-10-08 18:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:05:43 --> Email Class Initialized
INFO - 2020-10-08 18:05:43 --> Controller Class Initialized
DEBUG - 2020-10-08 18:05:43 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:05:43 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:05:43 --> Model Class Initialized
INFO - 2020-10-08 18:05:43 --> Model Class Initialized
INFO - 2020-10-08 18:05:43 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash.php
INFO - 2020-10-08 18:05:43 --> Final output sent to browser
DEBUG - 2020-10-08 18:05:43 --> Total execution time: 0.0261
ERROR - 2020-10-08 18:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:06:42 --> Config Class Initialized
INFO - 2020-10-08 18:06:42 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:06:42 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:06:42 --> Utf8 Class Initialized
INFO - 2020-10-08 18:06:42 --> URI Class Initialized
INFO - 2020-10-08 18:06:42 --> Router Class Initialized
INFO - 2020-10-08 18:06:42 --> Output Class Initialized
INFO - 2020-10-08 18:06:42 --> Security Class Initialized
DEBUG - 2020-10-08 18:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:06:42 --> Input Class Initialized
INFO - 2020-10-08 18:06:42 --> Language Class Initialized
INFO - 2020-10-08 18:06:42 --> Loader Class Initialized
INFO - 2020-10-08 18:06:42 --> Helper loaded: url_helper
INFO - 2020-10-08 18:06:42 --> Database Driver Class Initialized
INFO - 2020-10-08 18:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:06:42 --> Email Class Initialized
INFO - 2020-10-08 18:06:42 --> Controller Class Initialized
DEBUG - 2020-10-08 18:06:42 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:06:42 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:06:42 --> Model Class Initialized
INFO - 2020-10-08 18:06:42 --> Model Class Initialized
INFO - 2020-10-08 18:06:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 18:06:42 --> Final output sent to browser
DEBUG - 2020-10-08 18:06:42 --> Total execution time: 0.0396
ERROR - 2020-10-08 18:06:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:06:51 --> Config Class Initialized
INFO - 2020-10-08 18:06:51 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:06:51 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:06:51 --> Utf8 Class Initialized
INFO - 2020-10-08 18:06:51 --> URI Class Initialized
INFO - 2020-10-08 18:06:51 --> Router Class Initialized
INFO - 2020-10-08 18:06:51 --> Output Class Initialized
INFO - 2020-10-08 18:06:51 --> Security Class Initialized
DEBUG - 2020-10-08 18:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:06:51 --> Input Class Initialized
INFO - 2020-10-08 18:06:51 --> Language Class Initialized
INFO - 2020-10-08 18:06:51 --> Loader Class Initialized
INFO - 2020-10-08 18:06:51 --> Helper loaded: url_helper
INFO - 2020-10-08 18:06:51 --> Database Driver Class Initialized
INFO - 2020-10-08 18:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:06:51 --> Email Class Initialized
INFO - 2020-10-08 18:06:51 --> Controller Class Initialized
DEBUG - 2020-10-08 18:06:51 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:06:51 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:06:51 --> Model Class Initialized
INFO - 2020-10-08 18:06:51 --> Model Class Initialized
INFO - 2020-10-08 18:06:51 --> Model Class Initialized
INFO - 2020-10-08 18:06:51 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_add.php
INFO - 2020-10-08 18:06:51 --> Final output sent to browser
DEBUG - 2020-10-08 18:06:51 --> Total execution time: 0.0253
ERROR - 2020-10-08 18:09:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:09:45 --> Config Class Initialized
INFO - 2020-10-08 18:09:45 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:09:45 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:09:45 --> Utf8 Class Initialized
INFO - 2020-10-08 18:09:45 --> URI Class Initialized
INFO - 2020-10-08 18:09:45 --> Router Class Initialized
INFO - 2020-10-08 18:09:45 --> Output Class Initialized
INFO - 2020-10-08 18:09:45 --> Security Class Initialized
DEBUG - 2020-10-08 18:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:09:45 --> Input Class Initialized
INFO - 2020-10-08 18:09:45 --> Language Class Initialized
INFO - 2020-10-08 18:09:45 --> Loader Class Initialized
INFO - 2020-10-08 18:09:45 --> Helper loaded: url_helper
INFO - 2020-10-08 18:09:45 --> Database Driver Class Initialized
INFO - 2020-10-08 18:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:09:45 --> Email Class Initialized
INFO - 2020-10-08 18:09:45 --> Controller Class Initialized
DEBUG - 2020-10-08 18:09:45 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:09:45 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:09:45 --> Model Class Initialized
INFO - 2020-10-08 18:09:45 --> Model Class Initialized
INFO - 2020-10-08 18:09:45 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 18:09:45 --> Final output sent to browser
DEBUG - 2020-10-08 18:09:45 --> Total execution time: 0.0225
ERROR - 2020-10-08 18:09:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:09:48 --> Config Class Initialized
INFO - 2020-10-08 18:09:48 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:09:48 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:09:48 --> Utf8 Class Initialized
INFO - 2020-10-08 18:09:48 --> URI Class Initialized
INFO - 2020-10-08 18:09:48 --> Router Class Initialized
INFO - 2020-10-08 18:09:48 --> Output Class Initialized
INFO - 2020-10-08 18:09:48 --> Security Class Initialized
DEBUG - 2020-10-08 18:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:09:48 --> Input Class Initialized
INFO - 2020-10-08 18:09:48 --> Language Class Initialized
INFO - 2020-10-08 18:09:48 --> Loader Class Initialized
INFO - 2020-10-08 18:09:48 --> Helper loaded: url_helper
INFO - 2020-10-08 18:09:48 --> Database Driver Class Initialized
INFO - 2020-10-08 18:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:09:48 --> Email Class Initialized
INFO - 2020-10-08 18:09:48 --> Controller Class Initialized
DEBUG - 2020-10-08 18:09:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:09:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:09:48 --> Model Class Initialized
INFO - 2020-10-08 18:09:48 --> Model Class Initialized
INFO - 2020-10-08 18:09:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-08 18:09:48 --> Final output sent to browser
DEBUG - 2020-10-08 18:09:48 --> Total execution time: 0.0309
ERROR - 2020-10-08 18:10:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:10:14 --> Config Class Initialized
INFO - 2020-10-08 18:10:14 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:10:14 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:10:14 --> Utf8 Class Initialized
INFO - 2020-10-08 18:10:14 --> URI Class Initialized
INFO - 2020-10-08 18:10:14 --> Router Class Initialized
INFO - 2020-10-08 18:10:14 --> Output Class Initialized
INFO - 2020-10-08 18:10:14 --> Security Class Initialized
DEBUG - 2020-10-08 18:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:10:14 --> Input Class Initialized
INFO - 2020-10-08 18:10:14 --> Language Class Initialized
INFO - 2020-10-08 18:10:14 --> Loader Class Initialized
INFO - 2020-10-08 18:10:14 --> Helper loaded: url_helper
INFO - 2020-10-08 18:10:14 --> Database Driver Class Initialized
INFO - 2020-10-08 18:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:10:14 --> Email Class Initialized
INFO - 2020-10-08 18:10:14 --> Controller Class Initialized
DEBUG - 2020-10-08 18:10:14 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:10:14 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:10:14 --> Model Class Initialized
INFO - 2020-10-08 18:10:14 --> Model Class Initialized
INFO - 2020-10-08 18:10:14 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_view.php
INFO - 2020-10-08 18:10:14 --> Final output sent to browser
DEBUG - 2020-10-08 18:10:14 --> Total execution time: 0.0212
ERROR - 2020-10-08 18:10:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:10:22 --> Config Class Initialized
INFO - 2020-10-08 18:10:22 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:10:22 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:10:22 --> Utf8 Class Initialized
INFO - 2020-10-08 18:10:22 --> URI Class Initialized
INFO - 2020-10-08 18:10:22 --> Router Class Initialized
INFO - 2020-10-08 18:10:22 --> Output Class Initialized
INFO - 2020-10-08 18:10:22 --> Security Class Initialized
DEBUG - 2020-10-08 18:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:10:22 --> Input Class Initialized
INFO - 2020-10-08 18:10:22 --> Language Class Initialized
INFO - 2020-10-08 18:10:22 --> Loader Class Initialized
INFO - 2020-10-08 18:10:22 --> Helper loaded: url_helper
INFO - 2020-10-08 18:10:22 --> Database Driver Class Initialized
INFO - 2020-10-08 18:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:10:22 --> Email Class Initialized
INFO - 2020-10-08 18:10:22 --> Controller Class Initialized
DEBUG - 2020-10-08 18:10:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:10:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:10:22 --> Model Class Initialized
INFO - 2020-10-08 18:10:22 --> Model Class Initialized
INFO - 2020-10-08 18:10:22 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 18:10:22 --> Final output sent to browser
DEBUG - 2020-10-08 18:10:22 --> Total execution time: 0.0314
ERROR - 2020-10-08 18:10:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:10:48 --> Config Class Initialized
INFO - 2020-10-08 18:10:48 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:10:48 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:10:48 --> Utf8 Class Initialized
INFO - 2020-10-08 18:10:48 --> URI Class Initialized
INFO - 2020-10-08 18:10:48 --> Router Class Initialized
INFO - 2020-10-08 18:10:48 --> Output Class Initialized
INFO - 2020-10-08 18:10:48 --> Security Class Initialized
DEBUG - 2020-10-08 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:10:48 --> Input Class Initialized
INFO - 2020-10-08 18:10:48 --> Language Class Initialized
INFO - 2020-10-08 18:10:48 --> Loader Class Initialized
INFO - 2020-10-08 18:10:48 --> Helper loaded: url_helper
INFO - 2020-10-08 18:10:48 --> Database Driver Class Initialized
INFO - 2020-10-08 18:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:10:48 --> Email Class Initialized
INFO - 2020-10-08 18:10:48 --> Controller Class Initialized
DEBUG - 2020-10-08 18:10:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:10:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:10:48 --> Model Class Initialized
INFO - 2020-10-08 18:10:48 --> Model Class Initialized
INFO - 2020-10-08 18:10:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 18:10:48 --> Final output sent to browser
DEBUG - 2020-10-08 18:10:48 --> Total execution time: 0.0219
ERROR - 2020-10-08 18:11:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:05 --> Config Class Initialized
INFO - 2020-10-08 18:11:05 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:05 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:05 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:05 --> URI Class Initialized
INFO - 2020-10-08 18:11:05 --> Router Class Initialized
INFO - 2020-10-08 18:11:05 --> Output Class Initialized
INFO - 2020-10-08 18:11:05 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:05 --> Input Class Initialized
INFO - 2020-10-08 18:11:05 --> Language Class Initialized
INFO - 2020-10-08 18:11:05 --> Loader Class Initialized
INFO - 2020-10-08 18:11:05 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:05 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:05 --> Email Class Initialized
INFO - 2020-10-08 18:11:05 --> Controller Class Initialized
DEBUG - 2020-10-08 18:11:05 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:05 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:05 --> Model Class Initialized
INFO - 2020-10-08 18:11:05 --> Model Class Initialized
INFO - 2020-10-08 18:11:05 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 18:11:05 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:05 --> Total execution time: 0.0326
ERROR - 2020-10-08 18:11:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:17 --> Config Class Initialized
INFO - 2020-10-08 18:11:17 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:17 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:17 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:17 --> URI Class Initialized
INFO - 2020-10-08 18:11:17 --> Router Class Initialized
INFO - 2020-10-08 18:11:17 --> Output Class Initialized
INFO - 2020-10-08 18:11:17 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:17 --> Input Class Initialized
INFO - 2020-10-08 18:11:17 --> Language Class Initialized
INFO - 2020-10-08 18:11:17 --> Loader Class Initialized
INFO - 2020-10-08 18:11:17 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:17 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:17 --> Email Class Initialized
INFO - 2020-10-08 18:11:17 --> Controller Class Initialized
DEBUG - 2020-10-08 18:11:17 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:17 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:17 --> Model Class Initialized
INFO - 2020-10-08 18:11:17 --> Model Class Initialized
INFO - 2020-10-08 18:11:17 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list_admin_wise.php
INFO - 2020-10-08 18:11:17 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:17 --> Total execution time: 0.0429
ERROR - 2020-10-08 18:11:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:36 --> Config Class Initialized
INFO - 2020-10-08 18:11:36 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:36 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:36 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:36 --> URI Class Initialized
INFO - 2020-10-08 18:11:36 --> Router Class Initialized
INFO - 2020-10-08 18:11:36 --> Output Class Initialized
INFO - 2020-10-08 18:11:36 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:36 --> Input Class Initialized
INFO - 2020-10-08 18:11:36 --> Language Class Initialized
INFO - 2020-10-08 18:11:36 --> Loader Class Initialized
INFO - 2020-10-08 18:11:36 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:36 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:36 --> Email Class Initialized
INFO - 2020-10-08 18:11:36 --> Controller Class Initialized
DEBUG - 2020-10-08 18:11:36 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:36 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:36 --> Model Class Initialized
INFO - 2020-10-08 18:11:36 --> Model Class Initialized
INFO - 2020-10-08 18:11:36 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/campain_master_list.php
INFO - 2020-10-08 18:11:36 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:36 --> Total execution time: 0.0234
ERROR - 2020-10-08 18:11:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:39 --> Config Class Initialized
INFO - 2020-10-08 18:11:39 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:39 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:39 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:39 --> URI Class Initialized
INFO - 2020-10-08 18:11:39 --> Router Class Initialized
INFO - 2020-10-08 18:11:39 --> Output Class Initialized
INFO - 2020-10-08 18:11:39 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:39 --> Input Class Initialized
INFO - 2020-10-08 18:11:39 --> Language Class Initialized
INFO - 2020-10-08 18:11:39 --> Loader Class Initialized
INFO - 2020-10-08 18:11:39 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:39 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:39 --> Email Class Initialized
INFO - 2020-10-08 18:11:39 --> Controller Class Initialized
DEBUG - 2020-10-08 18:11:39 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:39 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:39 --> Model Class Initialized
INFO - 2020-10-08 18:11:39 --> Model Class Initialized
INFO - 2020-10-08 18:11:39 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_master_list.php
INFO - 2020-10-08 18:11:39 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:39 --> Total execution time: 0.0247
ERROR - 2020-10-08 18:11:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:41 --> Config Class Initialized
INFO - 2020-10-08 18:11:41 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:41 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:41 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:41 --> URI Class Initialized
INFO - 2020-10-08 18:11:41 --> Router Class Initialized
INFO - 2020-10-08 18:11:41 --> Output Class Initialized
INFO - 2020-10-08 18:11:41 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:41 --> Input Class Initialized
INFO - 2020-10-08 18:11:41 --> Language Class Initialized
INFO - 2020-10-08 18:11:41 --> Loader Class Initialized
INFO - 2020-10-08 18:11:41 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:41 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:41 --> Email Class Initialized
INFO - 2020-10-08 18:11:41 --> Controller Class Initialized
DEBUG - 2020-10-08 18:11:41 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:41 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:41 --> Model Class Initialized
INFO - 2020-10-08 18:11:41 --> Model Class Initialized
INFO - 2020-10-08 18:11:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dealer_view.php
INFO - 2020-10-08 18:11:42 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:42 --> Total execution time: 0.0422
ERROR - 2020-10-08 18:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:52 --> Config Class Initialized
INFO - 2020-10-08 18:11:52 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:52 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:52 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:52 --> URI Class Initialized
DEBUG - 2020-10-08 18:11:52 --> No URI present. Default controller set.
INFO - 2020-10-08 18:11:52 --> Router Class Initialized
INFO - 2020-10-08 18:11:52 --> Output Class Initialized
INFO - 2020-10-08 18:11:52 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:52 --> Input Class Initialized
INFO - 2020-10-08 18:11:52 --> Language Class Initialized
INFO - 2020-10-08 18:11:52 --> Loader Class Initialized
INFO - 2020-10-08 18:11:52 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:52 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:52 --> Email Class Initialized
INFO - 2020-10-08 18:11:52 --> Controller Class Initialized
INFO - 2020-10-08 18:11:52 --> Model Class Initialized
INFO - 2020-10-08 18:11:52 --> Model Class Initialized
DEBUG - 2020-10-08 18:11:52 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:52 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 18:11:52 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:52 --> Total execution time: 0.0197
ERROR - 2020-10-08 18:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:56 --> Config Class Initialized
INFO - 2020-10-08 18:11:56 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:56 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:56 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:56 --> URI Class Initialized
INFO - 2020-10-08 18:11:56 --> Router Class Initialized
INFO - 2020-10-08 18:11:56 --> Output Class Initialized
INFO - 2020-10-08 18:11:56 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:56 --> Input Class Initialized
INFO - 2020-10-08 18:11:56 --> Language Class Initialized
INFO - 2020-10-08 18:11:56 --> Loader Class Initialized
INFO - 2020-10-08 18:11:56 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:56 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:56 --> Email Class Initialized
INFO - 2020-10-08 18:11:56 --> Controller Class Initialized
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
DEBUG - 2020-10-08 18:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
INFO - 2020-10-08 18:11:56 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:56 --> Total execution time: 0.0224
ERROR - 2020-10-08 18:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:56 --> Config Class Initialized
INFO - 2020-10-08 18:11:56 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:56 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:56 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:56 --> URI Class Initialized
INFO - 2020-10-08 18:11:56 --> Router Class Initialized
INFO - 2020-10-08 18:11:56 --> Output Class Initialized
INFO - 2020-10-08 18:11:56 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:56 --> Input Class Initialized
INFO - 2020-10-08 18:11:56 --> Language Class Initialized
INFO - 2020-10-08 18:11:56 --> Loader Class Initialized
INFO - 2020-10-08 18:11:56 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:56 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:56 --> Email Class Initialized
INFO - 2020-10-08 18:11:56 --> Controller Class Initialized
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
DEBUG - 2020-10-08 18:11:56 --> Session class already loaded. Second attempt ignored.
ERROR - 2020-10-08 18:11:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:11:56 --> Config Class Initialized
INFO - 2020-10-08 18:11:56 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:11:56 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:11:56 --> Utf8 Class Initialized
INFO - 2020-10-08 18:11:56 --> URI Class Initialized
INFO - 2020-10-08 18:11:56 --> Router Class Initialized
INFO - 2020-10-08 18:11:56 --> Output Class Initialized
INFO - 2020-10-08 18:11:56 --> Security Class Initialized
DEBUG - 2020-10-08 18:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:11:56 --> Input Class Initialized
INFO - 2020-10-08 18:11:56 --> Language Class Initialized
INFO - 2020-10-08 18:11:56 --> Loader Class Initialized
INFO - 2020-10-08 18:11:56 --> Helper loaded: url_helper
INFO - 2020-10-08 18:11:56 --> Database Driver Class Initialized
INFO - 2020-10-08 18:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:11:56 --> Email Class Initialized
INFO - 2020-10-08 18:11:56 --> Controller Class Initialized
DEBUG - 2020-10-08 18:11:56 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:11:56 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
INFO - 2020-10-08 18:11:56 --> Model Class Initialized
INFO - 2020-10-08 18:11:56 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 18:11:56 --> Final output sent to browser
DEBUG - 2020-10-08 18:11:56 --> Total execution time: 0.0206
ERROR - 2020-10-08 18:12:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:12:22 --> Config Class Initialized
INFO - 2020-10-08 18:12:22 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:12:22 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:12:22 --> Utf8 Class Initialized
INFO - 2020-10-08 18:12:22 --> URI Class Initialized
INFO - 2020-10-08 18:12:22 --> Router Class Initialized
INFO - 2020-10-08 18:12:22 --> Output Class Initialized
INFO - 2020-10-08 18:12:22 --> Security Class Initialized
DEBUG - 2020-10-08 18:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:12:22 --> Input Class Initialized
INFO - 2020-10-08 18:12:22 --> Language Class Initialized
INFO - 2020-10-08 18:12:22 --> Loader Class Initialized
INFO - 2020-10-08 18:12:22 --> Helper loaded: url_helper
INFO - 2020-10-08 18:12:22 --> Database Driver Class Initialized
INFO - 2020-10-08 18:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:12:22 --> Email Class Initialized
INFO - 2020-10-08 18:12:22 --> Controller Class Initialized
DEBUG - 2020-10-08 18:12:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:12:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:12:22 --> Model Class Initialized
INFO - 2020-10-08 18:12:23 --> Model Class Initialized
INFO - 2020-10-08 18:12:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash2.php
INFO - 2020-10-08 18:12:23 --> Final output sent to browser
DEBUG - 2020-10-08 18:12:23 --> Total execution time: 0.0212
ERROR - 2020-10-08 18:12:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:12:40 --> Config Class Initialized
INFO - 2020-10-08 18:12:40 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:12:40 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:12:40 --> Utf8 Class Initialized
INFO - 2020-10-08 18:12:40 --> URI Class Initialized
INFO - 2020-10-08 18:12:40 --> Router Class Initialized
INFO - 2020-10-08 18:12:40 --> Output Class Initialized
INFO - 2020-10-08 18:12:40 --> Security Class Initialized
DEBUG - 2020-10-08 18:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:12:40 --> Input Class Initialized
INFO - 2020-10-08 18:12:40 --> Language Class Initialized
INFO - 2020-10-08 18:12:40 --> Loader Class Initialized
INFO - 2020-10-08 18:12:40 --> Helper loaded: url_helper
INFO - 2020-10-08 18:12:40 --> Database Driver Class Initialized
INFO - 2020-10-08 18:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:12:40 --> Email Class Initialized
INFO - 2020-10-08 18:12:40 --> Controller Class Initialized
DEBUG - 2020-10-08 18:12:40 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:12:40 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:12:40 --> Model Class Initialized
INFO - 2020-10-08 18:12:40 --> Model Class Initialized
INFO - 2020-10-08 18:12:40 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_master_list.php
INFO - 2020-10-08 18:12:40 --> Final output sent to browser
DEBUG - 2020-10-08 18:12:40 --> Total execution time: 0.0396
ERROR - 2020-10-08 18:12:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:12:48 --> Config Class Initialized
INFO - 2020-10-08 18:12:48 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:12:48 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:12:48 --> Utf8 Class Initialized
INFO - 2020-10-08 18:12:48 --> URI Class Initialized
INFO - 2020-10-08 18:12:48 --> Router Class Initialized
INFO - 2020-10-08 18:12:48 --> Output Class Initialized
INFO - 2020-10-08 18:12:48 --> Security Class Initialized
DEBUG - 2020-10-08 18:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:12:48 --> Input Class Initialized
INFO - 2020-10-08 18:12:48 --> Language Class Initialized
INFO - 2020-10-08 18:12:48 --> Loader Class Initialized
INFO - 2020-10-08 18:12:48 --> Helper loaded: url_helper
INFO - 2020-10-08 18:12:48 --> Database Driver Class Initialized
INFO - 2020-10-08 18:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:12:48 --> Email Class Initialized
INFO - 2020-10-08 18:12:48 --> Controller Class Initialized
DEBUG - 2020-10-08 18:12:48 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:12:48 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:12:48 --> Model Class Initialized
INFO - 2020-10-08 18:12:48 --> Model Class Initialized
INFO - 2020-10-08 18:12:48 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/sale_rep_master_list.php
INFO - 2020-10-08 18:12:48 --> Final output sent to browser
DEBUG - 2020-10-08 18:12:48 --> Total execution time: 0.0301
ERROR - 2020-10-08 18:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:12:53 --> Config Class Initialized
INFO - 2020-10-08 18:12:53 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:12:53 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:12:53 --> Utf8 Class Initialized
INFO - 2020-10-08 18:12:53 --> URI Class Initialized
INFO - 2020-10-08 18:12:53 --> Router Class Initialized
INFO - 2020-10-08 18:12:53 --> Output Class Initialized
INFO - 2020-10-08 18:12:53 --> Security Class Initialized
DEBUG - 2020-10-08 18:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:12:53 --> Input Class Initialized
INFO - 2020-10-08 18:12:53 --> Language Class Initialized
INFO - 2020-10-08 18:12:53 --> Loader Class Initialized
INFO - 2020-10-08 18:12:53 --> Helper loaded: url_helper
INFO - 2020-10-08 18:12:53 --> Database Driver Class Initialized
INFO - 2020-10-08 18:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:12:53 --> Email Class Initialized
INFO - 2020-10-08 18:12:53 --> Controller Class Initialized
DEBUG - 2020-10-08 18:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:12:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:12:53 --> Model Class Initialized
INFO - 2020-10-08 18:12:53 --> Model Class Initialized
INFO - 2020-10-08 18:12:53 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_status_wise.php
INFO - 2020-10-08 18:12:53 --> Final output sent to browser
DEBUG - 2020-10-08 18:12:53 --> Total execution time: 0.0286
ERROR - 2020-10-08 18:12:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:12:53 --> Config Class Initialized
INFO - 2020-10-08 18:12:53 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:12:53 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:12:53 --> Utf8 Class Initialized
INFO - 2020-10-08 18:12:53 --> URI Class Initialized
INFO - 2020-10-08 18:12:53 --> Router Class Initialized
INFO - 2020-10-08 18:12:53 --> Output Class Initialized
INFO - 2020-10-08 18:12:53 --> Security Class Initialized
DEBUG - 2020-10-08 18:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:12:53 --> Input Class Initialized
INFO - 2020-10-08 18:12:53 --> Language Class Initialized
INFO - 2020-10-08 18:12:53 --> Loader Class Initialized
INFO - 2020-10-08 18:12:53 --> Helper loaded: url_helper
INFO - 2020-10-08 18:12:53 --> Database Driver Class Initialized
INFO - 2020-10-08 18:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:12:53 --> Email Class Initialized
INFO - 2020-10-08 18:12:53 --> Controller Class Initialized
DEBUG - 2020-10-08 18:12:53 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:12:53 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:12:53 --> Model Class Initialized
INFO - 2020-10-08 18:12:53 --> Model Class Initialized
INFO - 2020-10-08 18:12:53 --> Final output sent to browser
DEBUG - 2020-10-08 18:12:53 --> Total execution time: 0.0212
ERROR - 2020-10-08 18:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:13:09 --> Config Class Initialized
INFO - 2020-10-08 18:13:09 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:13:09 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:13:09 --> Utf8 Class Initialized
INFO - 2020-10-08 18:13:09 --> URI Class Initialized
DEBUG - 2020-10-08 18:13:09 --> No URI present. Default controller set.
INFO - 2020-10-08 18:13:09 --> Router Class Initialized
INFO - 2020-10-08 18:13:09 --> Output Class Initialized
INFO - 2020-10-08 18:13:09 --> Security Class Initialized
DEBUG - 2020-10-08 18:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:13:09 --> Input Class Initialized
INFO - 2020-10-08 18:13:09 --> Language Class Initialized
INFO - 2020-10-08 18:13:09 --> Loader Class Initialized
INFO - 2020-10-08 18:13:09 --> Helper loaded: url_helper
INFO - 2020-10-08 18:13:09 --> Database Driver Class Initialized
INFO - 2020-10-08 18:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:13:09 --> Email Class Initialized
INFO - 2020-10-08 18:13:09 --> Controller Class Initialized
INFO - 2020-10-08 18:13:09 --> Model Class Initialized
INFO - 2020-10-08 18:13:09 --> Model Class Initialized
DEBUG - 2020-10-08 18:13:09 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:13:09 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 18:13:09 --> Final output sent to browser
DEBUG - 2020-10-08 18:13:09 --> Total execution time: 0.0187
ERROR - 2020-10-08 18:13:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:13:22 --> Config Class Initialized
INFO - 2020-10-08 18:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:13:22 --> Utf8 Class Initialized
INFO - 2020-10-08 18:13:22 --> URI Class Initialized
INFO - 2020-10-08 18:13:22 --> Router Class Initialized
INFO - 2020-10-08 18:13:22 --> Output Class Initialized
INFO - 2020-10-08 18:13:22 --> Security Class Initialized
DEBUG - 2020-10-08 18:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:13:22 --> Input Class Initialized
INFO - 2020-10-08 18:13:22 --> Language Class Initialized
INFO - 2020-10-08 18:13:22 --> Loader Class Initialized
INFO - 2020-10-08 18:13:22 --> Helper loaded: url_helper
INFO - 2020-10-08 18:13:22 --> Database Driver Class Initialized
INFO - 2020-10-08 18:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:13:22 --> Email Class Initialized
INFO - 2020-10-08 18:13:22 --> Controller Class Initialized
INFO - 2020-10-08 18:13:22 --> Model Class Initialized
ERROR - 2020-10-08 18:13:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:13:22 --> Model Class Initialized
DEBUG - 2020-10-08 18:13:22 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:13:22 --> Config Class Initialized
INFO - 2020-10-08 18:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:13:22 --> Utf8 Class Initialized
INFO - 2020-10-08 18:13:22 --> URI Class Initialized
INFO - 2020-10-08 18:13:22 --> Router Class Initialized
INFO - 2020-10-08 18:13:22 --> Output Class Initialized
INFO - 2020-10-08 18:13:22 --> Security Class Initialized
DEBUG - 2020-10-08 18:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:13:22 --> Input Class Initialized
INFO - 2020-10-08 18:13:22 --> Language Class Initialized
INFO - 2020-10-08 18:13:22 --> Loader Class Initialized
INFO - 2020-10-08 18:13:22 --> Helper loaded: url_helper
INFO - 2020-10-08 18:13:22 --> Database Driver Class Initialized
INFO - 2020-10-08 18:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:13:22 --> Email Class Initialized
INFO - 2020-10-08 18:13:22 --> Controller Class Initialized
INFO - 2020-10-08 18:13:22 --> Model Class Initialized
INFO - 2020-10-08 18:13:22 --> Model Class Initialized
DEBUG - 2020-10-08 18:13:22 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:13:22 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:13:22 --> Model Class Initialized
INFO - 2020-10-08 18:13:22 --> Final output sent to browser
DEBUG - 2020-10-08 18:13:22 --> Total execution time: 0.0243
ERROR - 2020-10-08 18:13:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:13:23 --> Config Class Initialized
INFO - 2020-10-08 18:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:13:23 --> Utf8 Class Initialized
INFO - 2020-10-08 18:13:23 --> URI Class Initialized
INFO - 2020-10-08 18:13:23 --> Router Class Initialized
INFO - 2020-10-08 18:13:23 --> Output Class Initialized
INFO - 2020-10-08 18:13:23 --> Security Class Initialized
DEBUG - 2020-10-08 18:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:13:23 --> Input Class Initialized
INFO - 2020-10-08 18:13:23 --> Language Class Initialized
INFO - 2020-10-08 18:13:23 --> Loader Class Initialized
INFO - 2020-10-08 18:13:23 --> Helper loaded: url_helper
INFO - 2020-10-08 18:13:23 --> Database Driver Class Initialized
INFO - 2020-10-08 18:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:13:23 --> Email Class Initialized
INFO - 2020-10-08 18:13:23 --> Controller Class Initialized
DEBUG - 2020-10-08 18:13:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:13:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:13:23 --> Model Class Initialized
INFO - 2020-10-08 18:13:23 --> Model Class Initialized
INFO - 2020-10-08 18:13:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 18:13:23 --> Final output sent to browser
DEBUG - 2020-10-08 18:13:23 --> Total execution time: 0.0196
ERROR - 2020-10-08 18:13:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:13:54 --> Config Class Initialized
INFO - 2020-10-08 18:13:54 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:13:54 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:13:54 --> Utf8 Class Initialized
INFO - 2020-10-08 18:13:54 --> URI Class Initialized
INFO - 2020-10-08 18:13:54 --> Router Class Initialized
INFO - 2020-10-08 18:13:54 --> Output Class Initialized
INFO - 2020-10-08 18:13:54 --> Security Class Initialized
DEBUG - 2020-10-08 18:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:13:54 --> Input Class Initialized
INFO - 2020-10-08 18:13:54 --> Language Class Initialized
INFO - 2020-10-08 18:13:54 --> Loader Class Initialized
INFO - 2020-10-08 18:13:54 --> Helper loaded: url_helper
INFO - 2020-10-08 18:13:54 --> Database Driver Class Initialized
INFO - 2020-10-08 18:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:13:54 --> Email Class Initialized
INFO - 2020-10-08 18:13:54 --> Controller Class Initialized
DEBUG - 2020-10-08 18:13:54 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:13:54 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:13:54 --> Model Class Initialized
INFO - 2020-10-08 18:13:54 --> Model Class Initialized
INFO - 2020-10-08 18:13:54 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-08 18:13:54 --> Final output sent to browser
DEBUG - 2020-10-08 18:13:54 --> Total execution time: 0.0214
ERROR - 2020-10-08 18:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:14:20 --> Config Class Initialized
INFO - 2020-10-08 18:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:14:20 --> Utf8 Class Initialized
INFO - 2020-10-08 18:14:20 --> URI Class Initialized
INFO - 2020-10-08 18:14:20 --> Router Class Initialized
INFO - 2020-10-08 18:14:20 --> Output Class Initialized
INFO - 2020-10-08 18:14:20 --> Security Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:14:20 --> Input Class Initialized
INFO - 2020-10-08 18:14:20 --> Language Class Initialized
INFO - 2020-10-08 18:14:20 --> Loader Class Initialized
INFO - 2020-10-08 18:14:20 --> Helper loaded: url_helper
INFO - 2020-10-08 18:14:20 --> Database Driver Class Initialized
INFO - 2020-10-08 18:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:14:20 --> Email Class Initialized
INFO - 2020-10-08 18:14:20 --> Controller Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 18:14:20 --> Final output sent to browser
DEBUG - 2020-10-08 18:14:20 --> Total execution time: 0.0444
ERROR - 2020-10-08 18:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2020-10-08 18:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:14:20 --> Config Class Initialized
INFO - 2020-10-08 18:14:20 --> Hooks Class Initialized
INFO - 2020-10-08 18:14:20 --> Config Class Initialized
INFO - 2020-10-08 18:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:14:20 --> Utf8 Class Initialized
ERROR - 2020-10-08 18:14:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
DEBUG - 2020-10-08 18:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:14:20 --> Utf8 Class Initialized
INFO - 2020-10-08 18:14:20 --> URI Class Initialized
INFO - 2020-10-08 18:14:20 --> URI Class Initialized
INFO - 2020-10-08 18:14:20 --> Router Class Initialized
INFO - 2020-10-08 18:14:20 --> Config Class Initialized
INFO - 2020-10-08 18:14:20 --> Hooks Class Initialized
INFO - 2020-10-08 18:14:20 --> Router Class Initialized
INFO - 2020-10-08 18:14:20 --> Output Class Initialized
DEBUG - 2020-10-08 18:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:14:20 --> Utf8 Class Initialized
INFO - 2020-10-08 18:14:20 --> Security Class Initialized
INFO - 2020-10-08 18:14:20 --> Output Class Initialized
INFO - 2020-10-08 18:14:20 --> URI Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:14:20 --> Input Class Initialized
INFO - 2020-10-08 18:14:20 --> Security Class Initialized
INFO - 2020-10-08 18:14:20 --> Language Class Initialized
INFO - 2020-10-08 18:14:20 --> Router Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:14:20 --> Input Class Initialized
INFO - 2020-10-08 18:14:20 --> Output Class Initialized
INFO - 2020-10-08 18:14:20 --> Language Class Initialized
INFO - 2020-10-08 18:14:20 --> Loader Class Initialized
INFO - 2020-10-08 18:14:20 --> Security Class Initialized
INFO - 2020-10-08 18:14:20 --> Helper loaded: url_helper
DEBUG - 2020-10-08 18:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:14:20 --> Input Class Initialized
INFO - 2020-10-08 18:14:20 --> Language Class Initialized
INFO - 2020-10-08 18:14:20 --> Loader Class Initialized
INFO - 2020-10-08 18:14:20 --> Helper loaded: url_helper
INFO - 2020-10-08 18:14:20 --> Loader Class Initialized
INFO - 2020-10-08 18:14:20 --> Database Driver Class Initialized
INFO - 2020-10-08 18:14:20 --> Helper loaded: url_helper
INFO - 2020-10-08 18:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:14:20 --> Database Driver Class Initialized
INFO - 2020-10-08 18:14:20 --> Database Driver Class Initialized
INFO - 2020-10-08 18:14:20 --> Email Class Initialized
INFO - 2020-10-08 18:14:20 --> Controller Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-08 18:14:20 --> Final output sent to browser
DEBUG - 2020-10-08 18:14:20 --> Total execution time: 0.0321
INFO - 2020-10-08 18:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:14:20 --> Email Class Initialized
INFO - 2020-10-08 18:14:20 --> Controller Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 18:14:20 --> Final output sent to browser
DEBUG - 2020-10-08 18:14:20 --> Total execution time: 0.0397
INFO - 2020-10-08 18:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:14:20 --> Email Class Initialized
INFO - 2020-10-08 18:14:20 --> Controller Class Initialized
DEBUG - 2020-10-08 18:14:20 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:14:20 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> Model Class Initialized
INFO - 2020-10-08 18:14:20 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/client_list_for_rep_wise.php
INFO - 2020-10-08 18:14:20 --> Final output sent to browser
DEBUG - 2020-10-08 18:14:20 --> Total execution time: 0.0468
ERROR - 2020-10-08 18:14:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:14:23 --> Config Class Initialized
INFO - 2020-10-08 18:14:23 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:14:23 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:14:23 --> Utf8 Class Initialized
INFO - 2020-10-08 18:14:23 --> URI Class Initialized
INFO - 2020-10-08 18:14:23 --> Router Class Initialized
INFO - 2020-10-08 18:14:23 --> Output Class Initialized
INFO - 2020-10-08 18:14:23 --> Security Class Initialized
DEBUG - 2020-10-08 18:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:14:23 --> Input Class Initialized
INFO - 2020-10-08 18:14:23 --> Language Class Initialized
INFO - 2020-10-08 18:14:23 --> Loader Class Initialized
INFO - 2020-10-08 18:14:23 --> Helper loaded: url_helper
INFO - 2020-10-08 18:14:23 --> Database Driver Class Initialized
INFO - 2020-10-08 18:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:14:23 --> Email Class Initialized
INFO - 2020-10-08 18:14:23 --> Controller Class Initialized
DEBUG - 2020-10-08 18:14:23 --> Session class already loaded. Second attempt ignored.
DEBUG - 2020-10-08 18:14:23 --> Email class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:14:23 --> Model Class Initialized
INFO - 2020-10-08 18:14:23 --> Model Class Initialized
INFO - 2020-10-08 18:14:23 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/dash3.php
INFO - 2020-10-08 18:14:23 --> Final output sent to browser
DEBUG - 2020-10-08 18:14:23 --> Total execution time: 0.0257
ERROR - 2020-10-08 18:14:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
INFO - 2020-10-08 18:14:42 --> Config Class Initialized
INFO - 2020-10-08 18:14:42 --> Hooks Class Initialized
DEBUG - 2020-10-08 18:14:42 --> UTF-8 Support Enabled
INFO - 2020-10-08 18:14:42 --> Utf8 Class Initialized
INFO - 2020-10-08 18:14:42 --> URI Class Initialized
DEBUG - 2020-10-08 18:14:42 --> No URI present. Default controller set.
INFO - 2020-10-08 18:14:42 --> Router Class Initialized
INFO - 2020-10-08 18:14:42 --> Output Class Initialized
INFO - 2020-10-08 18:14:42 --> Security Class Initialized
DEBUG - 2020-10-08 18:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-08 18:14:42 --> Input Class Initialized
INFO - 2020-10-08 18:14:42 --> Language Class Initialized
INFO - 2020-10-08 18:14:42 --> Loader Class Initialized
INFO - 2020-10-08 18:14:42 --> Helper loaded: url_helper
INFO - 2020-10-08 18:14:42 --> Database Driver Class Initialized
INFO - 2020-10-08 18:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-08 18:14:42 --> Email Class Initialized
INFO - 2020-10-08 18:14:42 --> Controller Class Initialized
INFO - 2020-10-08 18:14:42 --> Model Class Initialized
INFO - 2020-10-08 18:14:42 --> Model Class Initialized
DEBUG - 2020-10-08 18:14:42 --> Session class already loaded. Second attempt ignored.
INFO - 2020-10-08 18:14:42 --> File loaded: /home/purpu1ex/public_html/carsm/application/views/welcome_message.php
INFO - 2020-10-08 18:14:42 --> Final output sent to browser
DEBUG - 2020-10-08 18:14:42 --> Total execution time: 0.0218
